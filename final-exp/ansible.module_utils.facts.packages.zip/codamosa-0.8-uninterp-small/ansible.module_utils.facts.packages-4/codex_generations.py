

# Generated at 2022-06-24 23:21:37.176572
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():

    pkg_mgrs = get_all_pkg_managers()
    assert 'redhatpkgmgr' in pkg_mgrs


# Generated at 2022-06-24 23:21:39.050130
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    cli_mgr_0 = CLIMgr()
    assert cli_mgr_0.is_available() is False


# Generated at 2022-06-24 23:21:43.393639
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    item_0 = PkgMgr()
    item_1, item_2, item_3 = None, None, None
    item_0.list_installed = lambda x: ({item_0, item_3})
    pkg_mgr_0 = item_0.get_packages()



# Generated at 2022-06-24 23:21:45.301692
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    pkg_mgr_0 = PkgMgr()
    pkg_mgr_0.get_package_details('package')


# Generated at 2022-06-24 23:21:52.214948
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    try:
        PkgMgr.is_available()
    except NotImplementedError:
        pass
    else:
        assert False, "PkgMgr.is_available() did not raise NotImplementedError"


# Generated at 2022-06-24 23:21:54.479766
# Unit test for constructor of class LibMgr
def test_LibMgr():
    _libmgr_0 = LibMgr()
    assert _libmgr_0 is not None, "Failed to create object of class LibMgr"


# Generated at 2022-06-24 23:22:00.053492
# Unit test for constructor of class LibMgr
def test_LibMgr():
    lib_mgr_0 = LibMgr()
    assert lib_mgr_0.LIB is None
    assert lib_mgr_0._lib is None


# Generated at 2022-06-24 23:22:01.142410
# Unit test for constructor of class LibMgr
def test_LibMgr():
    pkg_mgr = LibMgr()



# Generated at 2022-06-24 23:22:02.770764
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    pkg_mgr_0 = CLIMgr()
    assert pkg_mgr_0._cli is None


# Generated at 2022-06-24 23:22:09.974464
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    cli_mgr_0 = CLIMgr()
    cli_mgr_0.CLI = "yum"
    cli_mgr_0.is_available()
    cli_mgr_0.CLI = "apt-get"
    cli_mgr_0.is_available()
    cli_mgr_0.CLI = None
    cli_mgr_0.is_available()


# Generated at 2022-06-24 23:22:18.358471
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    # Test case: No installation of package manager
    # Input: Operation get_package_details
    # Expected output: Raise exception
    try:
        pkg_mgr_0 = PkgMgr()
        pkg_mgr_0.get_package_details('test_pkg')
    except:
        pass
    else:
        raise Exception('test_case_0 failed')


# Generated at 2022-06-24 23:22:26.523322
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    pkg_mgr_1 = CLIMgr()
    # No CLI is provided
    assert not pkg_mgr_1.is_available()
    # No CLI is found in PATH
    pkg_mgr_2 = CLIMgr()
    pkg_mgr_2.CLI = 'totally_random_package_manager_cli'
    assert not pkg_mgr_2.is_available()
    # CLI is found in PATH
    pkg_mgr_3 = CLIMgr()
    pkg_mgr_3.CLI = 'ls'
    assert pkg_mgr_3.is_available()

# Generated at 2022-06-24 23:22:30.454388
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():

    # Positive test case, when is_available is called, it returns True
    pkg_mgr = PkgMgr()
    assert pkg_mgr.is_available()



# Generated at 2022-06-24 23:22:34.693420
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    pkg_mgr = CLIMgr()
    pkg_mgr.CLI = "random"
    assert pkg_mgr.is_available() == False


# Generated at 2022-06-24 23:22:36.835236
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    cli_mgr_0 = CLIMgr()
    result = cli_mgr_0.is_available()


# Generated at 2022-06-24 23:22:38.441262
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    libmgr = LibMgr()
    assert libmgr.is_available() == False


# Generated at 2022-06-24 23:22:40.935527
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():

    test_mgr = CLIMgr()
    test_mgr.CLI = "test_CLI"
    assert test_mgr.is_available() == False



# Generated at 2022-06-24 23:22:43.360911
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pkg_mgr_0 = PkgMgr()
    z = pkg_mgr_0.is_available()
    assert z == NotImplemented


# Generated at 2022-06-24 23:22:45.790835
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    pkg_mgr_obj = PkgMgr()
    result = pkg_mgr_obj.get_packages()
    assert result is None, "Expected result is None"


# Generated at 2022-06-24 23:22:54.165497
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    class TestPkgMgr(PkgMgr):

        def is_available(self):
            pass

        def list_installed(self):
            return [1, 2]

        def get_package_details(self, package):
            return package

    test_pkg_mgr = TestPkgMgr()
    result = test_pkg_mgr.get_packages()

    assert result is not None
    assert len(result) == 2
    assert list(result.keys()) == [1, 2]
    assert result[1] == [1]
    assert result[2] == [2]

# Generated at 2022-06-24 23:23:06.816719
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():

    try:
        PkgMgr().is_available()
        raise AssertionError('Not implemented method test_PkgMgr_is_available')
    except NotImplementedError:
        pass


# Generated at 2022-06-24 23:23:08.434562
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    flake = LibMgr()
    flake.LIB = 'flake8'
    flake.is_available()


# Generated at 2022-06-24 23:23:14.641876
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pkg_mgr_0 = PkgMgr()
    # This should raise a TypeError
    try:
        pkg_mgr_0.is_available()
    except TypeError:
        pass
    else:
        raise AssertionError


# Generated at 2022-06-24 23:23:15.733928
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pkg_mgr = PkgMgr()
    assert False

# Generated at 2022-06-24 23:23:17.138272
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    result = get_all_pkg_managers()
    assert type(result) is dict
    assert len(result) > 0

# Generated at 2022-06-24 23:23:20.297679
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    pass


# Generated at 2022-06-24 23:23:22.317393
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    pkg_mgr = PkgMgr()
    pkg_mgr.get_packages()

# Generated at 2022-06-24 23:23:23.695287
# Unit test for constructor of class LibMgr
def test_LibMgr():
    pkg_mgr_1 = LibMgr()


# Generated at 2022-06-24 23:23:25.217257
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    pkg_mgr = get_all_pkg_managers()

    assert(len(pkg_mgr) > 0)

# Generated at 2022-06-24 23:23:31.675964
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    # check that package manager can be instantiated
    test_case = [PkgMgr, LibMgr, CLIMgr]
    for pkg_mgr in test_case:
        pkg_mgr_0 = pkg_mgr()
        assert pkg_mgr_0 is not None

    # Check that package manager is available and installed packages can be listed
    test_case = [PkgMgr, LibMgr, CLIMgr]
    for pkg_mgr in test_case:
        pkg_mgr_1 = pkg_mgr()
        assert pkg_mgr_1.get_packages() is not None

# Generated at 2022-06-24 23:23:41.970891
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class Test(CLIMgr):
        CLI = 'test'

    Test().is_available()

# Generated at 2022-06-24 23:23:44.630502
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    try:
        var_0 = get_bin_path('apt-cache')
    except ValueError:
        res_0 = False
    else:
        res_0 = True
    assert res_0 == test_CLIMgr_is_available.expected_result


# Generated at 2022-06-24 23:23:47.382310
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    var_0 = PkgMgr()



# Generated at 2022-06-24 23:23:50.037305
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    # Test case with invalid parameter
    try:
        var_1 = CLIMgr()
        var_2 = var_1.is_available()
    except ValueError as e:
        assert True


# Generated at 2022-06-24 23:23:52.623929
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    var_0 = CLIMgr()
    var_1 = var_0.is_available()


# Generated at 2022-06-24 23:23:54.169267
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pkgMgr = PkgMgr()
    assert not pkgMgr.is_available()


# Generated at 2022-06-24 23:23:57.038443
# Unit test for constructor of class LibMgr
def test_LibMgr():
    var_1 = get_all_pkg_managers()
    var_2 = test_case_0()
    for var_3 in var_1:
        var_4 = var_1[var_3]
        var_5 = var_4()


# Generated at 2022-06-24 23:24:01.717640
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():

    # Parameters for method
    lib = PkgMgr.LIB

    # Instance of class
    var_1 = LibMgr()

    # Verify if method is_available of class PkgMgr is called successfully
    if var_1.is_available():
        print("Test Passed")
    else:
        print("Test Failed")


# Generated at 2022-06-24 23:24:08.696344
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    test_class = PkgMgr()
    test_package = {'name': "name", 'version': "version", 'source': "source", 'versions': ["version"]}
    result = test_class.get_package_details(test_package)
    assert result == {'name': "name", 'version': "version", 'source': "source", 'versions': ["version"]}, "Test result got changed unexpectedly"
    assert result['name'] == "name", "Test result got changed unexpectedly"
    assert result['version'] == "version", "Test result got changed unexpectedly"
    assert result['source'] == "source", "Test result got changed unexpectedly"
    assert result['versions'] == ["version"], "Test result got changed unexpectedly"


# Generated at 2022-06-24 23:24:14.365346
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    method_name = get_package_details
    assert (not hasattr(method_name, '__call__')), \
        'Method PkgMgr.{name} is not callable'.format(
            name=method_name.__name__)


# Generated at 2022-06-24 23:24:33.351495
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    assert PkgMgr.__abstractmethods__ == frozenset(['get_package_details', 'list_installed', 'is_available'])


# Generated at 2022-06-24 23:24:34.420208
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    # TODO
    var_0 = CLIMgr()
    var_0.is_available()


# Generated at 2022-06-24 23:24:35.881333
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    var_0 = CLIMgr()
    var_0.is_available()
    assert var_0._cli is None



# Generated at 2022-06-24 23:24:36.653756
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    assert True



# Generated at 2022-06-24 23:24:41.772946
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    fixture_0 = PkgMgr()
    assert fixture_0.is_available() == NotImplementedError


# Generated at 2022-06-24 23:24:43.212462
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pass

# Generated at 2022-06-24 23:24:48.448714
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    var_0 = get_all_pkg_managers()
    var_1 = dict()
    for var_2 in var_0:
        var_3 = var_0[var_2]()
        var_4 = var_3.is_available()
        var_1[var_2] = var_4
    return var_1


# Generated at 2022-06-24 23:24:52.399012
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    # var_0 should be instantiated in init method
    var_0 = PkgMgr()
    with pytest.raises(NotImplementedError):
        var_0.is_available()


# Generated at 2022-06-24 23:25:01.837649
# Unit test for constructor of class LibMgr
def test_LibMgr():
    # Example for function get_all_subclasses

    var_0 = get_all_subclasses(PkgMgr)
    var_0 = get_all_subclasses(PkgMgr)
    var_0 = get_all_subclasses(PkgMgr)
    var_0 = get_all_subclasses(PkgMgr)

    # Example for function get_bin_path

    var_0 = get_bin_path('/path/to/file')
    var_0 = get_bin_path('/path/to/file')
    var_0 = get_bin_path('/path/to/file')
    var_0 = get_bin_path('/path/to/file')
    # Example for function get_all_pkg_managers

    var_0 = get_all_pkg_managers()

# Generated at 2022-06-24 23:25:04.840642
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    var_0 = LibMgr()
    res = var_0.is_available()


# Generated at 2022-06-24 23:25:46.505982
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgr
    var_PkgMgr_object = PkgMgr()
    if var_PkgMgr_object.is_available():
        package = var_PkgMgr_object.list_installed()[0]
        var_PkgMgr_object.get_package_details(package)

# Generated at 2022-06-24 23:25:47.313918
# Unit test for constructor of class LibMgr
def test_LibMgr():
    lib_mgr_0 = LibMgr()


# Generated at 2022-06-24 23:25:48.438292
# Unit test for constructor of class LibMgr
def test_LibMgr():
    assert (LibMgr() is not None)


# Generated at 2022-06-24 23:25:52.849149
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    class PkgMgr_0(PkgMgr):
        _lib = None
        def list_installed(self):
            pass
    obj_0 = PkgMgr_0()
    obj_0.list_installed()


# Generated at 2022-06-24 23:25:53.600003
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pass


# Generated at 2022-06-24 23:25:55.040122
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
  # get_packages.
  pass


# Generated at 2022-06-24 23:25:56.659688
# Unit test for constructor of class LibMgr
def test_LibMgr():
    assert not test_LibMgr.__dict__['_LibMgr__Lib']


# Generated at 2022-06-24 23:26:02.641291
# Unit test for constructor of class LibMgr
def test_LibMgr():
    test_obj = LibMgr()
    assert(isinstance(test_obj, LibMgr))


# Generated at 2022-06-24 23:26:05.393578
# Unit test for constructor of class LibMgr
def test_LibMgr():
    from ansible.module_utils.common.common import AnsibleModule

    module = AnsibleModule(supports_check_mode=True)

    # test cases
    with module.paramiko_conn(host='127.0.0.1', port=22, username='vagrant', password='vagrant') as conn:
        res = test_case_0()


# Generated at 2022-06-24 23:26:08.710693
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    try:
        var_1 = LibMgr()
        var_1.is_available()
    except Exception:
        raise Exception('Failed to read from var_1')


# Generated at 2022-06-24 23:27:32.888891
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    var_0 = CLIMgr()
    var_0.CLI = 'foobar'
    var_0.is_available() == False
    var_0.CLI = 'pip'
    var_0.is_available() == True


# Generated at 2022-06-24 23:27:37.493374
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    var_0 = LibMgr()
    var_1 = var_0.is_available()
    
    assert var_1 == True, "Test case failed"


# Generated at 2022-06-24 23:27:38.706358
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    var_1 = PkgMgr()
    var_2 = var_1.is_available()
    assert(var_2 is None)


# Generated at 2022-06-24 23:27:39.505065
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():

    var_1 = LibMgr()
    var_2 = var_1.is_available()


# Generated at 2022-06-24 23:27:40.474667
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    obj = CLIMgr()
    actual = obj.is_available()
    expected = False
    assert actual == expected


# Generated at 2022-06-24 23:27:42.534011
# Unit test for constructor of class LibMgr
def test_LibMgr():
    print("Test for constructor of class LibMgr")
    try:
        var_1 = LibMgr()
        test_case_0(var_1)
    except Exception:
        print("Exception raised in constructor of class LibMgr")


# Generated at 2022-06-24 23:27:47.932768
# Unit test for method get_packages of class PkgMgr

# Generated at 2022-06-24 23:27:51.864457
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    try:
        obj = CLIMgr()
    except Exception as error:
        raise error
    return


# Generated at 2022-06-24 23:27:55.952689
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pm = PkgMgr()
    assert pm.list_installed() == []

# Generated at 2022-06-24 23:27:57.379538
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    return PkgMgr().get_packages()

# Basic unit test

# Generated at 2022-06-24 23:31:09.652343
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():

    def run_case(case_num):
        case_input = globals()['var_' + str(case_num)]
        try:
            with open('test_case_input.json', 'w') as f:
                json.dump(case_input, f)
        except Exception as e:
            print(e)
            f.close()
        func_name = 'test_case_' + str(case_num)
        globals()[func_name]()

    test_cases = [
        0,
    ]

    for case_num in test_cases:
        run_case(case_num)


# Generated at 2022-06-24 23:31:14.593802
# Unit test for constructor of class LibMgr
def test_LibMgr():
    var_1 = LibMgr()


# Generated at 2022-06-24 23:31:15.888435
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    var_1 = PkgMgr
    var_1.list_installed()


# Generated at 2022-06-24 23:31:17.962854
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    # Test case 0
    var_0 = LibMgr()
    var_0.is_available()


# Generated at 2022-06-24 23:31:19.504811
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    packages = get_all_pkg_managers().get('LibMgr')()
    # packages.get_packages()


# Generated at 2022-06-24 23:31:24.561375
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    try:
        cli_mgr = CLIMgr()
    except Exception as err:
        print("Test case for constructor of Class CLIMgr failed: %s" % str(err))


# Generated at 2022-06-24 23:31:25.757263
# Unit test for constructor of class LibMgr
def test_LibMgr():
    assert type(LibMgr()) == LibMgr


# Generated at 2022-06-24 23:31:28.180184
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    cli = CLIMgr()
    return isinstance(cli, CLIMgr)


# Generated at 2022-06-24 23:31:36.269550
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    test_instance = PkgMgr()
    assert not test_instance.get_packages()

    test_instance.list_installed = lambda : ['package_1', 'package_2', 'package_2',]
    test_instance.get_package_details =\
        lambda p : {'name': p, 'version': '1.0.0'} if 'package_1' in p else {'name': p, 'version': '2.0.0'}

    # test_instance.list_installed = lambda : ['package_2', 'package_2',]
    # test_instance.get_package_details = lambda p : {'name': p, 'version': '2.0.0'}

    package_list = test_instance.get_packages()

    assert len(package_list) == 2