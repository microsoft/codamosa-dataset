

# Generated at 2022-06-24 23:21:36.262564
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    c_l_i_mgr_1 = CLIMgr()

if __name__ == '__main__':
    # test_case_0()
    test_LibMgr_is_available()

# Generated at 2022-06-24 23:21:37.300694
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    test_case_0()


# Generated at 2022-06-24 23:21:39.169600
# Unit test for constructor of class LibMgr
def test_LibMgr():
    libMgr = LibMgr()
    if libMgr:
        return True
    else:
        return False


# Generated at 2022-06-24 23:21:41.678502
# Unit test for constructor of class LibMgr
def test_LibMgr():
    c_l_i_mgr_0 = LibMgr()
    assert c_l_i_mgr_0 is not None, "Fail test_LibMgr"


# Generated at 2022-06-24 23:21:49.520808
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    pkg_managers = get_all_pkg_managers()
    assert 'apt' in pkg_managers
    assert 'ports' in pkg_managers
    assert 'chocolatey' in pkg_managers
    assert 'yum' in pkg_managers
    assert 'pkgng' in pkg_managers
    assert 'dnf' in pkg_managers
    assert 'zypper' in pkg_managers
    assert 'homebrew' in pkg_managers
    assert 'pacman' in pkg_managers
    assert 'apk' in pkg_managers
    assert 'go' in pkg_managers
    assert 'npm' in pkg_managers
    assert 'pip' in pkg_managers
    assert 'pear' in pkg_managers

# Generated at 2022-06-24 23:21:53.139805
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    # Setup
    c_l_i_mgr_0 = CLIMgr()

    # Test proper functionality
    assert c_l_i_mgr_0.is_available() == False



# Generated at 2022-06-24 23:21:54.956251
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():

    c_l_i_mgr = CLIMgr()
    assert c_l_i_mgr.is_available() == False


# Generated at 2022-06-24 23:21:59.126633
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    assert PkgMgr.get_packages(PkgMgr) == None

# Generated at 2022-06-24 23:22:00.343461
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    l_i_b_mgr_0 = LibMgr()


# Generated at 2022-06-24 23:22:02.529044
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    c_l_i_mgr_0 = CLIMgr()
    package = "string"
    __ret = c_l_i_mgr_0.get_package_details(package)


# Generated at 2022-06-24 23:22:09.145894
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():

    pkgmgr = PkgMgr()
    if not pkgmgr.is_available():
        raise ImportError("PkgMgr not available")

    assert pkgmgr.list_installed()



# Generated at 2022-06-24 23:22:14.752310
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    result_PkgMgr_get_packages = PkgMgr.get_packages(PkgMgr)
    assert result_PkgMgr_get_packages is not None
    assert type(result_PkgMgr_get_packages) == dict


# Generated at 2022-06-24 23:22:16.257474
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    obj = PkgMgr()
    package = ""
    obj.get_package_details(package)


# Generated at 2022-06-24 23:22:17.711078
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    assert PkgMgr.get_packages(test_case_0()) == 'test'

# Generated at 2022-06-24 23:22:23.080013
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    c_l_i_mgr_2 = CLIMgr()
    c_l_i_mgr_2.get_package_details()


# Generated at 2022-06-24 23:22:27.031815
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    pkg_mgr_0 = PkgMgr()
    package_0 = 'package_0'
    ret = pkg_mgr_0.get_package_details(package_0)


# Generated at 2022-06-24 23:22:29.299313
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    cm_test = CLIMgr()
    result = cm_test.is_available()
    assert result == False, "Checking if CLIMgr.is_available returns False"


# Generated at 2022-06-24 23:22:35.316828
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    lib_mgr_0 = LibMgr()
    lib_mgr_0.LIB = "pathlib"
    is_available_ret_val = lib_mgr_0.is_available()
    assert is_available_ret_val is True


# Generated at 2022-06-24 23:22:38.082475
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    l_i_b_mgr_0 = LibMgr()
    x_0 = l_i_b_mgr_0.is_available()
    assert x_0


# Generated at 2022-06-24 23:22:40.065978
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    c_l_i_mgr_0 = CLIMgr()
    assert c_l_i_mgr_0 != None


# Generated at 2022-06-24 23:22:52.077122
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    lib_mgr_0 = LibMgr()


# Generated at 2022-06-24 23:22:54.133466
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    l_i_b_mgr_0 = LibMgr()
    assert l_i_b_mgr_0.is_available() == None


# Generated at 2022-06-24 23:23:01.362715
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    pkg_mgr = PkgMgr()
    package = ''
    try:
        pkg_mgr.get_package_details(package)
    except NotImplementedError:
        pass
    else:
        assert False, 'ExpectedNotImplementedError'


# Generated at 2022-06-24 23:23:05.505994
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    c_l_i_mgr_0 = CLIMgr()


# Generated at 2022-06-24 23:23:07.265624
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    c_l_i_mgr_0 = CLIMgr()
    c_l_i_mgr_0.is_available() == True


# Generated at 2022-06-24 23:23:08.569367
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    print("Testing method get_packages of class PkgMgr")
    pkgmgr = PkgMgr()
    assert not pkgmgr



# Generated at 2022-06-24 23:23:11.764212
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    with mock.patch.object(PkgMgr, 'get_packages') as mock_get_packages_method:
        mock_get_packages_method.return_value = 'default value'
        test_pm = PkgMgr()
        test_pm.get_packages()
        assert mock_get_packages_method.call_count == 1


# Generated at 2022-06-24 23:23:16.636369
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    c_l_i_mgr_0 = CLIMgr()
    expected_result_0 = True
    result_0 = c_l_i_mgr_0.is_available()
    assert (result_0 == expected_result_0)


# Generated at 2022-06-24 23:23:28.233495
# Unit test for method get_packages of class PkgMgr

# Generated at 2022-06-24 23:23:30.903665
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    c_l_i_mgr_0 = CLIMgr()
    package = {}
    expected = 0
    actual = len(c_l_i_mgr_0.get_package_details(package))
    assert actual == expected


# Generated at 2022-06-24 23:23:54.650945
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    h_e_l_p_e_r_i_n_f_o_0 = get_all_pkg_managers()
    c_l_i_mgr_0 = CLIMgr()
    r_e_s_u_l_t_0 = c_l_i_mgr_0.is_available()
    assert True == r_e_s_u_l_t_0
    l_i_b_mgr_0 = LibMgr()
    r_e_s_u_l_t_1 = l_i_b_mgr_0.is_available()
    assert True == r_e_s_u_l_t_1

# Generated at 2022-06-24 23:23:58.539143
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    # Path of the library used to test method is_available of class LibMgr
    # TODO: Insert the path of the library
    path_to_lib = 'path/to/lib'
    lib_mgr_0 = LibMgr()
    LibMgr.LIB = path_to_lib
    LibMgr.LIB = lib_mgr_0.is_available()


# Generated at 2022-06-24 23:23:59.930192
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    instance = LibMgr()
    assert instance.is_available()


# Generated at 2022-06-24 23:24:07.824705
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    # Find a class that implements is_available and list_installed
    class MyPkgMgr(PkgMgr):
        def is_available(self):
            return True

        def list_installed(self):
            return ['python-ldap', 'python-mysql']

        def get_package_details(self, package):
            return {'name': package, 'version': '2.4.19'}

    pkg_mgr = MyPkgMgr()
    all_pkgs = pkg_mgr.get_packages()
    assert 'python-ldap' in all_pkgs
    assert 'python-mysql' in all_pkgs
    assert len(all_pkgs['python-ldap']) == 1
    assert len(all_pkgs['python-mysql']) == 1

# Generated at 2022-06-24 23:24:16.321359
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    class pkgmgr_test(PkgMgr):
        def is_available(self):
            return True

        def get_package_details(self, package):
            return {'name':package}

        def list_installed(self):
            return ['pkg1', 'pkg2']

    pkgmgr_test_obj = pkgmgr_test()
    installed_packages = pkgmgr_test_obj.get_packages()
    installed_package_names = installed_packages.keys()
    # assert 'pkg1' in installed_package_names
    # assert 'pkg2' in installed_package_names



# Generated at 2022-06-24 23:24:21.019153
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    c_l_i_mgr_0 = CLIMgr()
    assert not c_l_i_mgr_0.list_installed()


# Generated at 2022-06-24 23:24:22.761079
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pkg_mgr = PkgMgr()
    # Test failure of abstract method
    assert (pkg_mgr.list_installed() == NotImplemented)


# Generated at 2022-06-24 23:24:24.359429
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    c_l_i_mgr = CLIMgr()
    assert c_l_i_mgr.is_available() == False


# Generated at 2022-06-24 23:24:25.786349
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    result = get_all_pkg_managers()
    assert isinstance(result, dict)


# Generated at 2022-06-24 23:24:27.737956
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    c_l_i_mgr_0 = test_case_0()
    bool_0 = c_l_i_mgr_0.is_available()
    assert bool_0


# Generated at 2022-06-24 23:24:46.903604
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    for key in get_all_pkg_managers().keys():
        obj = get_all_pkg_managers()[key]()
        if not hasattr(obj, 'list_installed'):
            raise TypeError
            break


# Generated at 2022-06-24 23:24:48.607507
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    c_l_i_mgr_0 = CLIMgr()
    assert c_l_i_mgr_0 is not None


# Generated at 2022-06-24 23:24:49.692906
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    test_case_0()

# Generated at 2022-06-24 23:24:51.057057
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    l_i_b_mgr_0 = LibMgr()
    assert l_i_b_mgr_0.is_available() is False

# Generated at 2022-06-24 23:24:54.613894
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    l_i_b_mgr_0 = LibMgr()
    assert l_i_b_mgr_0.is_available() == None


# Generated at 2022-06-24 23:24:55.833131
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    assert get_all_pkg_managers()



# Generated at 2022-06-24 23:24:57.467526
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    lib_mgr_0 = LibMgr()
    assert lib_mgr_0.is_available() == None


# Generated at 2022-06-24 23:25:01.268261
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    test_case_0()

# Generated at 2022-06-24 23:25:04.435276
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    c_l_i_mgr = CLIMgr()
    assert c_l_i_mgr.is_available() == False


# Generated at 2022-06-24 23:25:06.713258
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    pkgmgr_0 = PkgMgr()
    assert pkgmgr_0.get_packages() == {}

# Generated at 2022-06-24 23:25:47.294784
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    c_l_i_mgr_0 = CLIMgr()
    c_l_i_mgr_0.is_available()


# Generated at 2022-06-24 23:25:50.845813
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    print("Test start")
    c_l_i_mgr_0 = CLIMgr()
    print("Test ends")


# Generated at 2022-06-24 23:25:51.687351
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    test_case_0()


# Generated at 2022-06-24 23:25:55.651457
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    c_l_i_mgr_0 = CLIMgr()
    try:
        c_l_i_mgr_0.get_package_details()
    except TypeError:
        pass
    else:
        print('PkgMgr.get_package_details() has not been applied to all subclasses of it')


# Generated at 2022-06-24 23:25:57.695835
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    c_l_i_mgr_0 = CLIMgr()
    assert c_l_i_mgr_0.is_available() != True


# Generated at 2022-06-24 23:26:03.035437
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    """Test case for method is_available"""
    test_case_0()



# Generated at 2022-06-24 23:26:05.511526
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    c_l_i_mgr_0 = CLIMgr()
    # CLIMgr.is_available is a non-abstract method, therefore it should be tested,
    # and also it is not a public method, so we cover this as well
    assert c_l_i_mgr_0.is_available() == False


# Generated at 2022-06-24 23:26:08.837576
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    c_l_i_mgr_0 = CLIMgr()
    result = c_l_i_mgr_0.is_available()
    assert result


# Generated at 2022-06-24 23:26:10.552714
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    try:
        assert( test_case_0() == None )
    except NameError:
        print('CLIMgr constructor failed')
        return 1
    return 0


# Generated at 2022-06-24 23:26:14.477545
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    # Testing with a dummy library
    lib_mgr_0 = LibMgr()
    lib_mgr_0.LIB = "socket"
    lib_mgr_0_is_available = lib_mgr_0.is_available()
    assert lib_mgr_0_is_available == True


# Generated at 2022-06-24 23:26:56.403312
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():

    assert test_case_0().is_available() == False



# Generated at 2022-06-24 23:27:01.760411
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    ht_d_t_mgr_0 = PkgMgr()
    ht_d_t_mgr_0.get_package_details("package")


# Generated at 2022-06-24 23:27:03.277635
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    result = PkgMgr().get_packages()
    assert result is None


# Generated at 2022-06-24 23:27:05.337640
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    test_obj = PkgMgr()
    # Test method can be called (pylint)
    test_obj.list_installed()


# Generated at 2022-06-24 23:27:10.712816
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    test_pkg_mgr = PkgMgr()
    with pytest.raises(NotImplementedError):
        test_pkg_mgr.get_package_details("test")


# Generated at 2022-06-24 23:27:15.640244
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    c_l_i_mgr_0 = LibMgr()
    c_l_i_mgr_0.LIB = '__future__'
    c_l_i_mgr_0.is_available()


# Generated at 2022-06-24 23:27:20.098733
# Unit test for constructor of class LibMgr
def test_LibMgr():
    lib_mgr = LibMgr()
    assert lib_mgr is not None, 'Class LibMgr has not been instantiated'


# Generated at 2022-06-24 23:27:29.556415
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    import mock
    import sys
    import os
    import inspect
    import pkg_resources

    pkgutil = pkg_resources
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()
    test_case_13()
    test_case_14()
    test_case_15()
    test_case_16()
    test_case_17()
    test_case_18()
    test_case_19()
    test_case_20

# Generated at 2022-06-24 23:27:32.092139
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    assert PkgMgr.get_package_details({'name': 'foo', 'version': '1.2.3'}) # == {'name': 'foo', 'version': '1.2.3'}


# Generated at 2022-06-24 23:27:37.106420
# Unit test for constructor of class LibMgr
def test_LibMgr():
    lm = LibMgr()
    assert not lm.is_available()


# Generated at 2022-06-24 23:28:23.931182
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    # Initialise a PkgMgr object
    # Check value of get_packages method, return should be an empty dictionary
    p_kg_mgr = PkgMgr()
    assert p_kg_mgr.get_packages() == {}

# Generated at 2022-06-24 23:28:25.000725
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    c_l_i_mgr_1 = CLIMgr()


# Generated at 2022-06-24 23:28:30.844272
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    c_l_i_mgr_0 = CLIMgr()
    assert c_l_i_mgr_0.list_installed()
    lib_mgr_0 = LibMgr()
    assert lib_mgr_0.list_installed()


# Generated at 2022-06-24 23:28:33.181459
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    '''
    Unit test for method get_packages of class PkgMgr
    '''
    pkg_mgr_0 = PkgMgr()
    pkg_mgr_0.get_packages()


# Generated at 2022-06-24 23:28:34.937519
# Unit test for constructor of class LibMgr
def test_LibMgr():
    l_i_b_mgr_0 = LibMgr()


# Generated at 2022-06-24 23:28:40.000858
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():

    print("\nChecking if the system has the 'mach' module imported")
    libmgr = LibMgr()
    libmgr.LIB = 'mach'
    print("Checking if the system has the 'mach' module imported:",libmgr.is_available())



# Generated at 2022-06-24 23:28:43.281673
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    c_l_i_mgr_1 = CLIMgr()
    assert c_l_i_mgr_1.is_available() == None



# Generated at 2022-06-24 23:28:50.431597
# Unit test for constructor of class LibMgr
def test_LibMgr():
    # Initialization
    c_l_i_mgr_0 = LibMgr()

    # Testing of 'is_available' method
    #
    # Call to is_available()
    #
    # Call to abstract method
    # AssertionError: Call to abstract method
    with pytest.raises(AssertionError) as excinfo0:
        c_l_i_mgr_0.is_available()

    # Testing of 'list_installed' method
    #
    # Call to list_installed()
    #
    # Call to abstract method
    # AssertionError: Call to abstract method
    with pytest.raises(AssertionError) as excinfo1:
        c_l_i_mgr_0.list_installed()

    # Testing of 'get_package_details' method
    #

# Generated at 2022-06-24 23:28:55.036601
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    p_mgr_0 = PkgMgr()
    p_mgr_0.list_installed = lambda: ['pkg0', 'pkg1', 'pkg2', 'pkg3']

    p_mgr_0.get_package_details = lambda pkg: {'name': pkg}

    packages = p_mgr_0.get_packages()
    assert packages == {'pkg0': [{'source': 'PkgMgr', 'name': 'pkg0'}],
                        'pkg1': [{'source': 'PkgMgr', 'name': 'pkg1'}],
                        'pkg2': [{'source': 'PkgMgr', 'name': 'pkg2'}],
                        'pkg3': [{'source': 'PkgMgr', 'name': 'pkg3'}]}


# Generated at 2022-06-24 23:28:57.160208
# Unit test for constructor of class LibMgr
def test_LibMgr():
    assert LibMgr()


# Generated at 2022-06-24 23:29:53.484187
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    pkgmgr = PkgMgr()
    try:
        pkgmgr.get_package_details('package')
        assert False
    except NotImplementedError:
        assert True


# Generated at 2022-06-24 23:29:55.064749
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    c_l_i_mgr_0 = CLIMgr()
    assert not c_l_i_mgr_0.is_available()
    assert c_l_i_mgr_0._cli is None


# Generated at 2022-06-24 23:29:57.812279
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    c_l_i_mgr_0 = CLIMgr()
    c_l_i_mgr_0.is_available()


# Generated at 2022-06-24 23:30:02.125710
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    pkgmgr_obj = PkgMgr()
    assert pkgmgr_obj.get_packages() == {}


# Generated at 2022-06-24 23:30:06.137591
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    import pytest
    pytest.main(["unit_test.py", ])

if __name__ == "__main__":
    test_CLIMgr()

# Generated at 2022-06-24 23:30:12.640239
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():

    print("Test Case: PkgMgr_get_package_details")

    try:
        c_l_i_mgr_1 = CLIMgr()
        c_l_i_mgr_1.get_package_details()

    except Exception as e:
        print("Test Case: PkgMgr_get_package_details")
        if str(e) == "TypeError: get_package_details() missing 1 required positional argument: 'package'":
            print("Test Case: PASS")
        else:
            print("Test Case: FAIL")


# Generated at 2022-06-24 23:30:18.332044
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    import pytest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts import DefaultCloudDetector
    pytest.importorskip("apt")
    pytest.importorskip("yum")
    pytest.importorskip("pacman")
    pytest.importorskip("apk")
    pytest.importorskip("pkg_resources")
    pytest.importorskip("rpm")
    pytest.importorskip("rpmUtils")
    pytest.importorskip("rpmUtils.arch")
    pytest.importorskip("libvirt")
    pytest.importorskip("cffi")
    pytest.importorskip("zope.interface")
    pytest.importorskip("requests")
   

# Generated at 2022-06-24 23:30:19.191172
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pass


# Generated at 2022-06-24 23:30:20.714984
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    test_instance = PkgMgr()
    assert PkgMgr.is_available(test_instance) == NotImplementedError


# Generated at 2022-06-24 23:30:23.694916
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():

    assert 1



# Generated at 2022-06-24 23:31:15.350988
# Unit test for constructor of class LibMgr
def test_LibMgr():
    obj_0 = LibMgr()
    assert obj_0 is not None
    assert obj_0.is_available() is False


# Generated at 2022-06-24 23:31:17.182472
# Unit test for constructor of class LibMgr
def test_LibMgr():
    mgr_0 = LibMgr()


# Generated at 2022-06-24 23:31:18.045109
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    test_obj = CLIMgr()


# Generated at 2022-06-24 23:31:20.892813
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
  var_0 = {"version":"1.0.8", "name":"python-virtualenv"}
  expect = {"name":"python-virtualenv", "version":"1.0.8"}
  actual = PkgMgr().get_package_details(var_0)
  assert expect == actual, "Expected output does not match with actual output"


# Generated at 2022-06-24 23:31:23.800559
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    cli = CLIMgr()
    assert cli.is_available() == True


# Generated at 2022-06-24 23:31:25.137997
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert(issubclass(CLIMgr, PkgMgr))