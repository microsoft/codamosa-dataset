

# Generated at 2022-06-24 23:21:41.537141
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    if not test_PkgMgr_is_available():
        raise BaseException("Ensure test_PkgMgr_is_available passed before running test_PkgMgr_list_installed")

    pkg_mgr = PkgMgr()
    installed_packages = pkg_mgr.list_installed()
    # Check that list is not empty and the elements of the list are all strings
    if len(installed_packages) == 0:
        raise BaseException("No installed packages found")
    for package in installed_packages:
        if not isinstance(package, str):
            raise BaseException("One or more installed packages were not strings")


# Generated at 2022-06-24 23:21:44.297133
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    cli_mgr_0 = CLIMgr()
    assert (cli_mgr_0.__class__.__name__ == 'CLIMgr')


# Generated at 2022-06-24 23:21:46.424282
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    mgr = CLIMgr()
    assert mgr.is_available() == False
    mgr.CLI = ''
    assert mgr.is_available() == False


# Generated at 2022-06-24 23:21:50.450129
# Unit test for constructor of class CLIMgr

# Generated at 2022-06-24 23:21:59.332981
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    assert hasattr(PkgMgr, 'get_packages'), 'Class PkgMgr does not have method get_packages.'

    lib_mgr_0 = LibMgr()
    assert lib_mgr_0 != None, 'Unable to instantiate LibMgr.'
    assert hasattr(lib_mgr_0, 'is_available'), 'Class LibMgr does not have method is_available.'
    assert hasattr(lib_mgr_0, 'list_installed'), 'Class LibMgr does not have method list_installed.'
    assert hasattr(lib_mgr_0, 'get_package_details'), 'Class LibMgr does not have method get_package_details.'

    lib_mgr_0 = LibMgr()
    lib_mgr_0.LIB = 'ansible'

# Generated at 2022-06-24 23:22:01.072063
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    for obj in get_all_subclasses(PkgMgr):
        assert obj().list_installed() == obj().get_packages().keys()

# Generated at 2022-06-24 23:22:02.962030
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    cmd = '/bin/true'
    cli_mgr_0 = CLIMgr()
    assert cli_mgr_0.is_available() == True


# Generated at 2022-06-24 23:22:10.507401
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    def get_package_details(self, package):
      return package
    lib_mgr_0 = LibMgr()
    lib_mgr_0.get_package_details = get_package_details.__get__(lib_mgr_0,type(lib_mgr_0))
    lib_mgr_0.list_installed = lambda: ["test_string"]
    assert(lib_mgr_0.get_packages() == {"test_string": [{"name": "test_string", "source": "libmgr"}]})



# Generated at 2022-06-24 23:22:13.598618
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    assert True, "I like pytest"
    assert get_all_pkg_managers()['apt'].get_packages() is not None

# Generated at 2022-06-24 23:22:18.561675
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    # Test case 0: check that returned packages is non empty and has non-empty 'name' and 'version'
    pkg = PkgMgr()
    installed_packages = pkg.get_packages()
    assert installed_packages != {}
    for name, versions in installed_packages.items():
        for installed_version in versions:
            assert 'name' in installed_version
            assert 'version' in installed_version

# Generated at 2022-06-24 23:22:27.836100
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    return_value = False
    lib_mgr_0 = CLIMgr()
    if lib_mgr_0 is None:
        raise AssertionError("line 'lib_mgr_0 = CLIMgr()' of method 'test_CLIMgr_is_available' failed")
    return_value = lib_mgr_0.is_available()
    return return_value


# Generated at 2022-06-24 23:22:29.636388
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    cli_mgr_0 = CLIMgr()
    assert cli_mgr_0 is not None

# Generated at 2022-06-24 23:22:33.892216
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    lib_mgr = LibMgr()



# Generated at 2022-06-24 23:22:35.550688
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    lib_mgr = LibMgr()
    lib_mgr.list_installed()


# Generated at 2022-06-24 23:22:37.955553
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    cli_mgr = CLIMgr()
    cli_mgr.CLI = "pip"
    assert cli_mgr.is_available() == True

# Generated at 2022-06-24 23:22:39.946424
# Unit test for constructor of class LibMgr
def test_LibMgr():
    lib_mgr_0 = LibMgr()
    return {
        "result": True,
        "commands": []
    }



# Generated at 2022-06-24 23:22:45.073849
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    pkg_name = 'ansible-lint'
    installed_packages = {}
    installed_packages[pkg_name] = [{'installed_version': '3.4.19-1.el6', 'installed_release': '1.el6', 'installed_epoch': '0', 'installed_arch': 'noarch', 'installed_name': 'ansible-lint', 'name': 'ansible-lint'}]
    assert installed_packages[pkg_name] == pkg_name


# Generated at 2022-06-24 23:22:46.196579
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
        a=PkgMgr()
        assert hasattr(a,'list_installed')

# Generated at 2022-06-24 23:22:46.751422
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    pass

# Generated at 2022-06-24 23:22:52.634093
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    cli_mgr_0 = CLIMgr()
    cli_mgr_0.is_available()


# Generated at 2022-06-24 23:23:03.292954
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    import ansible.module_utils.facts.system.pkg_mgr as pkg_mgr

    try:
        __import__('libmagic')
    except ImportError:
        print('module not found')
        assert False

    ml = pkg_mgr.LibMgr()
    ml.LIB = 'libmagic'
    ml.is_available()



# Generated at 2022-06-24 23:23:07.639312
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    test_obj = PkgMgr()
    try:
        test_obj.is_available()
    except TypeError:
        assert True
    else:
        assert False


# Generated at 2022-06-24 23:23:08.784257
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    case_0_PkgMgr = PkgMgr()
    assert case_0_PkgMgr.get_packages()

# Generated at 2022-06-24 23:23:13.835446
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    # Create an instance of class LibMgr
    var_0 = LibMgr()
    assert True == var_0.is_available()


# Generated at 2022-06-24 23:23:15.410555
# Unit test for constructor of class LibMgr
def test_LibMgr():
    assert LibMgr() is not None


# Generated at 2022-06-24 23:23:16.779630
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    var_0 = CLIMgr()
    var_1 = var_0.is_available()


# Generated at 2022-06-24 23:23:20.246803
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    pass


# Generated at 2022-06-24 23:23:22.317919
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    cli_mgr = CLIMgr()
    cli_mgr.is_available()


# Generated at 2022-06-24 23:23:27.157907
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    # Create instance of class
    obj_CLIMgr = CLIMgr()
    # Call method is_available
    method_retval_CLIMgr_is_available = obj_CLIMgr.is_available()
    # Return assertion
    #assert method_retval_CLIMgr_is_available == False
    "Return assertion"
    # Return assertion
    #assert obj_CLIMgr._cli == None
    "Return assertion"


# Generated at 2022-06-24 23:23:30.353690
# Unit test for constructor of class LibMgr
def test_LibMgr():
    # Test if instance of class LibMgr is created
    lib_mgr = LibMgr()
    if not isinstance(lib_mgr, LibMgr):
        raise AssertionError("%s is not instance of class LibMgr" % repr(lib_mgr))


# Generated at 2022-06-24 23:23:39.261832
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    var_0 = LibMgr()
    var_1 = var_0.is_available()

# Generated at 2022-06-24 23:23:42.539409
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    var_1 = LibMgr()
    var_1.LIB = ''
    var_2 = var_1.is_available()
    assert var_2 == False


# Generated at 2022-06-24 23:23:43.834959
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    a = LibMgr()
    var_0 = a.is_available()


# Generated at 2022-06-24 23:23:44.596977
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pass


# Generated at 2022-06-24 23:23:48.816921
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    mgr_cli_01 = CLIMgr()
    mgr_cli_01.CLI = "wget"
    assert mgr_cli_01.is_available()



# Generated at 2022-06-24 23:23:51.658691
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    obj = CLIMgr()
    retval = obj.is_available()
    assert retval == (None)



# Generated at 2022-06-24 23:23:55.252444
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    var_0 = CLIMgr()
    try:
        var_0.is_available()
    except Exception:
        var_1 = False
    else:
        var_1 = True
    assert var_1

test_case_0()
test_CLIMgr_is_available()

# Generated at 2022-06-24 23:23:58.069700
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    assert True


# Generated at 2022-06-24 23:24:00.962800
# Unit test for constructor of class CLIMgr
def test_CLIMgr():

    obj = CLIMgr()
    var_1 = obj.is_available()
    var_2 = obj.list_installed()
    var_3 = obj.get_package_details('test')


# Generated at 2022-06-24 23:24:05.299990
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    mocker = init_mocker()
    instance = CLIMgr()
    if isinstance(mocker, mock.Mock):
        mocker.patch('ansible.module_utils.common.process.get_bin_path')
    ansible.module_utils.common.process.get_bin_path.return_value = "path"
    assert instance.is_available() == True


# Generated at 2022-06-24 23:24:19.728710
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    class_0 = CLIMgr()


# Generated at 2022-06-24 23:24:21.541812
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    # test case id: 0
    var_0 = get_all_pkg_managers()

# Generated at 2022-06-24 23:24:27.193716
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    var_0 = CLIMgr()
    test_case_0()
    test_case_0()
    var_0.is_available()
    test_case_0()


# Generated at 2022-06-24 23:24:27.945889
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    pass


# Generated at 2022-06-24 23:24:33.767056
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    # create instance of the class
    var_1 = CLIMgr()
    # execute method
    var_2 = var_1.is_available()
    # assert the return type
    assert isinstance(var_2, bool)
    # assert that return value is false
    assert var_2 is False


# Generated at 2022-06-24 23:24:36.141359
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    # Create a PkgMgr object
    p1 = PkgMgr()
    # Verify that the is_available method of PkgMgr returns false
    assert(p1.is_available() == False)


# Generated at 2022-06-24 23:24:41.397375
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    var_0 = LibMgr()
    var_1 = var_0.is_available()


# Generated at 2022-06-24 23:24:43.210593
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    pass


# Generated at 2022-06-24 23:24:46.897302
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    mock_self = PkgMgr()
    actual = mock_self.get_packages()
    expect = {}
    assert actual == expect
    # Since there are no assertions in the original method, I just do a comfort assert here

# Generated at 2022-06-24 23:24:48.607678
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    obj = PkgMgr()
    try:
        obj.is_available()
    except NotImplementedError:
        pass


# Generated at 2022-06-24 23:25:22.445490
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    pkg_mgr_obj = PkgMgr()
    ret = pkg_mgr_obj.get_packages()
    if ret != {}:
        print("Failed get_packages.")

# Test case func

# Generated at 2022-06-24 23:25:24.381920
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    var_0 = LibMgr()


# Generated at 2022-06-24 23:25:25.942779
# Unit test for constructor of class LibMgr
def test_LibMgr():
    lib_mgr = LibMgr()


# Generated at 2022-06-24 23:25:28.065835
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    var_1 = LibMgr()
    test_case_0()
    var_2 = var_1.is_available()
    assert var_2 == None


# Generated at 2022-06-24 23:25:31.140121
# Unit test for constructor of class LibMgr
def test_LibMgr():
    LibMgr()


# Generated at 2022-06-24 23:25:32.348948
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    test_object = CLIMgr()
    test_object.is_available()


# Generated at 2022-06-24 23:25:35.405393
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    f = open("/tmp/installed.packages", "w+")
    f.write("xserver-xorg-input-synaptics:amd64")
    f.close()
    a = CLIMgr()
    a.is_available()
    a._cli = ""
    a.CLI = "dpkg-query"
    a.get_packages()

# Generated at 2022-06-24 23:25:39.919507
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    from ansible.module_utils.facts.virtual.base import get_all_pkg_managers as A_get_all_pkg_managers

    print("Test 0")
    test_case_0()

# Generated at 2022-06-24 23:25:40.858876
# Unit test for constructor of class LibMgr
def test_LibMgr():
    assert LibMgr() is not None


# Generated at 2022-06-24 23:25:47.789523
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    mock_lib_mgr = LibMgr()
    mock_lib_mgr.list_installed = lambda: ["lib1", "lib2"]
    mock_lib_mgr.get_package_details = lambda pkg: {"name": "lib1", "version": "1.0", "source": "LibMgr"}
    pkgs = mock_lib_mgr.get_packages()
    assert pkgs["lib1"][0]["source"] == "LibMgr"

# Generated at 2022-06-24 23:27:10.529605
# Unit test for constructor of class LibMgr
def test_LibMgr():
    var_1 = LibMgr()


# Generated at 2022-06-24 23:27:14.444413
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    # Renamed to avoid collisions with other test cases
    var_1 = {}
    var_2 = PkgMgr()
    var_3 = var_2.list_installed()


# Generated at 2022-06-24 23:27:16.189585
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    obj = CLIMgr()
    assert obj.is_available() == True

# Generated at 2022-06-24 23:27:20.271929
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    assert var_0 != None

# Generated at 2022-06-24 23:27:27.032229
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    var_0 = CLIMgr()
    var_1 = CLIMgr()
    var_1._cli = "var_4"
    var_2 = CLIMgr()
    var_2._cli = "var_3"
    var_3 = {'var_1': [var_1], 'var_0': [var_2]}
    var_0.get_packages()
    assert var_0.get_packages() == var_3


# Generated at 2022-06-24 23:27:33.807825
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    # Test cases for method get_packages
    test_cases = {
        '0': {
            'expected': [],
            'return': '0'
        },
        '1': {
            'expected': [],
            'return': '1'
        },
        '2': {
            'expected': [],
            'return': '2'
        },
        '3': {
            'expected': [],
            'return': '3'
        },
        '4': {
            'expected': [],
            'return': '4'
        }
    }

    for test_case in test_cases:
        expected = test_cases[test_case]['expected']
        return_val = test_cases[test_case]['return']

        mock_obj = PkgMgr()

# Generated at 2022-06-24 23:27:37.014372
# Unit test for constructor of class LibMgr
def test_LibMgr():
    obj = LibMgr()
    assert obj


# Generated at 2022-06-24 23:27:38.591909
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    var_0 = get_all_pkg_managers()
    var_1 = var_0['dpkg_mgr'].list_installed()


# Generated at 2022-06-24 23:27:40.552935
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    # Create instance of class
    pkg_mgr = PkgMgr()
    # Check that method returns expected value
    assert pkg_mgr.list_installed() == NotImplemented


# Generated at 2022-06-24 23:27:45.458975
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    pass


# Generated at 2022-06-24 23:30:55.160992
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    # 1. Check that value returned by function is_available of class LibMgr is type boolean
    var_1 = get_all_pkg_managers()
    var_2 = var_1['pkgin']
    var_3 = var_2.is_available()
    assert(type(var_3) == bool)


# Generated at 2022-06-24 23:30:57.786665
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    pass


# Generated at 2022-06-24 23:30:58.718154
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    obj = PkgMgr()
    obj.is_available()


# Generated at 2022-06-24 23:31:00.139090
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    pass


# Generated at 2022-06-24 23:31:01.353919
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    var_1 = LibMgr()
    assert var_1.is_available() == None


# Generated at 2022-06-24 23:31:09.360246
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    # Declaration of class PkgMgr
    class PkgMgr(object):
        pass
    # Declaration of package details dictionary
    package_details = dict()
    package_details['name'] = "ansible"
    package_details['epoch'] = 0
    package_details['release'] = "1"
    package_details['version'] = "2.7.0"
    package_details['architecture'] = "noarch"
    pkg_mgr = PkgMgr()
    assert pkg_mgr.get_package_details(package_details) == package_details


# Generated at 2022-06-24 23:31:12.940554
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    pass


# Generated at 2022-06-24 23:31:14.692276
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    # Test 1
    test_obj = LibMgr()
    out_put = test_obj.is_available()
    assert (out_put == 0)


# Generated at 2022-06-24 23:31:16.889510
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    obj_0 = PkgMgr()
    # The following line should fail
    obj_0.get_package_details("abc")

# Generated at 2022-06-24 23:31:17.761071
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    manager = CLIMgr()