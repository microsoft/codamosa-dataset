

# Generated at 2022-06-24 23:21:34.998504
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    instance = CLIMgr()
    assert isinstance(instance, CLIMgr)


# Generated at 2022-06-24 23:21:37.049960
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    var_0 = LibMgr()
    var_0.is_available()


# Generated at 2022-06-24 23:21:46.351708
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    var_1 = LibMgr()
    var_3 = True
    var_4 = False
    var_5 = True
    var_6 = var_1.is_available()
    if var_6:
        var_2 = var_1.is_available()
        var_7 = var_2
        var_8 = var_6
    else:
        var_2 = var_1.is_available()
        var_9 = var_3 and var_4
        var_10 = var_6
        var_8 = var_9
        var_7 = var_10
    var_11 = var_7
    var_12 = var_8
    var_14 = True
    var_15 = var_11 or var_12 or var_14 or var_5
    var_13 = var_15

# Generated at 2022-06-24 23:21:51.999120
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    # Declare the parameter 'args'
    args = None
    # Call the method
    pkgMgr = PkgMgr()
    pkgMgr.is_available(args)


# Generated at 2022-06-24 23:21:52.925863
# Unit test for constructor of class LibMgr
def test_LibMgr():
    var_1 = LibMgr()


# Generated at 2022-06-24 23:21:55.061779
# Unit test for constructor of class LibMgr
def test_LibMgr():
    test_obj_0 = LibMgr()
    # No return value, returns a type
    assert(type(test_obj_0) == LibMgr)


# Generated at 2022-06-24 23:21:58.797712
# Unit test for constructor of class LibMgr
def test_LibMgr():
    LibMgr()


# Generated at 2022-06-24 23:22:00.600275
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    var_1 = PkgMgr()
    with pytest.raises(SystemExit):
        var_1.list_installed()


# Generated at 2022-06-24 23:22:01.386751
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    obj = CLIMgr()


# Generated at 2022-06-24 23:22:02.183579
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    var_0 = CLIMgr()


# Generated at 2022-06-24 23:22:15.158143
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    path = 'tests.unit.ansible_collections.ansible.community.plugins.modules.software.package_context.PkgMgr'
    target_method_name = 'is_available'

    # Constructor and method
    PkgMgr_Class = load_class(path)
    PkgMgr_Constructor = load_constructor(PkgMgr_Class)
    PkgMgr_Method = load_method(PkgMgr_Constructor, target_method_name)

    # Constructor invocation and method invocation
    PkgMgr_Object = PkgMgr_Constructor()
    PkgMgr_Method(PkgMgr_Object)


# Generated at 2022-06-24 23:22:17.936804
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    obj = None
    try:
        obj = CLIMgr()
    except Exception as e:
        print(e)

    ret = obj.is_available()  # TODO
    assert(ret)


# Generated at 2022-06-24 23:22:25.061510
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    mock_object = {
        'CLI': 'rpm'
    }
    environment = {
        'PATH': '/bin:/usr/bin'
    }
    instance = CLIMgr()
    instance.__dict__.update(mock_object)
    instance.__init__()
    assert instance.CLI == 'rpm'
    assert instance._cli == '/bin/rpm'


# Generated at 2022-06-24 23:22:28.656601
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    temp_0 = LibMgr()
    assert isinstance(temp_0.is_available(), bool)


# Generated at 2022-06-24 23:22:29.954813
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    c = CLIMgr()
    c.CLI = 'test'
    c.is_available()



# Generated at 2022-06-24 23:22:34.170729
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    var_0 = CLIMgr()
    assert var_0.is_available() == False


# Generated at 2022-06-24 23:22:36.653814
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    var_0 = CLIMgr()
    var_0.CLI = "apt-get"
    assert var_0.is_available()


# Generated at 2022-06-24 23:22:37.913850
# Unit test for constructor of class LibMgr
def test_LibMgr():
    LibMgr_Instance = LibMgr()


# Generated at 2022-06-24 23:22:46.743155
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    var_0 = get_all_pkg_managers()
    if var_0 is not None:
        var_1 = list(var_0.keys())
        if 'apk' in var_1:
            pass
        else:
            raise Exception('Unit test for function "get_all_pkg_managers" failed: The required element "apk" does not appear in the returned value.')
        if 'apt' in var_1:
            pass
        else:
            raise Exception('Unit test for function "get_all_pkg_managers" failed: The required element "apt" does not appear in the returned value.')
        if 'apt_pkg' in var_1:
            pass

# Generated at 2022-06-24 23:22:51.578098
# Unit test for constructor of class LibMgr
def test_LibMgr():
    obj = LibMgr()
    # test for the default of "_lib"
    assert obj._lib == None, "The default value of '_lib' is wrong!"


# Generated at 2022-06-24 23:22:58.286673
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    var_0 = CLIMgr()


# Generated at 2022-06-24 23:23:04.686865
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    for pkg_mgr in get_all_pkg_managers().values():
        if not pkg_mgr.is_available():
            continue

        pkg_mgr_instance = pkg_mgr()
        result = pkg_mgr_instance.list_installed()

        assert isinstance(result, list), 'result must be a list of strings'
        assert len(result) > 0, 'result must contain at least one element'
        assert isinstance(result[0], str), 'result elements must be strings'


# Generated at 2022-06-24 23:23:07.706353
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    # Create a new instance of the class PkgMgr
    var_1 = PkgMgr()

    # Call the method get_packages with arguments
    var_1.get_packages()


# Generated at 2022-06-24 23:23:09.569677
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    var_0 = CLIMgr()
    if not var_0.is_available():
        print('Failed')
    else:
        print('Succeeded')


# Generated at 2022-06-24 23:23:16.728667
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    # Create object
    LibMgr = LibMgr()
    LibMgr.__init__()
    # Call test function
    LibMgr.is_available()
    LibMgr.is_available()
    LibMgr.is_available()
    LibMgr.is_available()


# Generated at 2022-06-24 23:23:20.830444
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    obj = CLIMgr()
    assert obj._cli == None


# Generated at 2022-06-24 23:23:23.090437
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    var_1 = get_all_pkg_managers()
    assert False, "Unimplemented test, please debug"


# Generated at 2022-06-24 23:23:24.986364
# Unit test for constructor of class LibMgr
def test_LibMgr():
    expected_result = ''
    actual_result = LibMgr()
    assert type(actual_result) == LibMgr


# Generated at 2022-06-24 23:23:30.047117
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    var_0 = PkgMgr()
    var_0.list_installed = lambda: ["p"]
    var_0.get_package_details = lambda p: {"name": "python", "version": "2.7"}
    var_0.get_packages()

# Generated at 2022-06-24 23:23:31.105109
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    var_0 = get_all_pkg_managers()


# Generated at 2022-06-24 23:23:43.085608
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    lib = LibMgr()
    result = lib.is_available()
    if result == True:
        print('is_available method passed.')
    else:
        print('is_available method failed.')


# Generated at 2022-06-24 23:23:43.651896
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    pass


# Generated at 2022-06-24 23:23:45.815891
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    # Here we should test for invalid values for the args to fail ...
    var_0 = LibMgr(None)
    var_0.LIB = None
    var_1 = var_0.is_available()


# Generated at 2022-06-24 23:23:47.875115
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pkgmgr = PkgMgr()
    pkgmgr.list_installed()


# Generated at 2022-06-24 23:23:50.157564
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    test_instance = LibMgr()
    assert test_instance.is_available() == True
    assert type(test_instance.is_available()) is bool


# Generated at 2022-06-24 23:23:51.896033
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    cli_mgr = CLIMgr()

    assert cli_mgr.is_available() == False


# Generated at 2022-06-24 23:23:54.807479
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    # Create an instance of class LibMgr
    libmgr_instance = LibMgr()
    # unit test for method is_available of class LibMgr
    assert libmgr_instance.is_available() == True


# Generated at 2022-06-24 23:23:56.770114
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    var_1 = CLIMgr()
    var_1.CLI = 'apt'
    var_2 = var_1.is_available()


# Generated at 2022-06-24 23:23:58.261063
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    assert PkgMgr().get_packages() == {}

# Generated at 2022-06-24 23:24:00.843833
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    var_0 = PkgMgr()
    var_1 = list()
    var_2 = var_0.list_installed()
    AssertionError()


# Generated at 2022-06-24 23:24:13.430388
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    print("Testing PkgMgr::list_installed")

    assert False


# Generated at 2022-06-24 23:24:15.828664
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    obj_test=CLIMgr()
    assert (getattr(obj_test,"_cli","none")=="none")


# Generated at 2022-06-24 23:24:19.737435
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    clm = CLIMgr()


# Generated at 2022-06-24 23:24:23.214961
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    from unittest import TestCase
    from ansible.module_utils.six.moves.builtins import isinstance

    class Dummy(CLIMgr):
        CLI = 'Dummy'
    dummy = Dummy()

    TestCase().assertEqual(__name__, '__main__')
    TestCase().assertIsInstance(dummy, CLIMgr)


# Generated at 2022-06-24 23:24:25.201858
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    # Simple verification that test_PkgMgr_get_package_details is running
    print('Method get_package_details of class PkgMgr is running')


# Generated at 2022-06-24 23:24:32.353370
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    PkgMgr_get_packages_child = PkgMgr()
    PkgMgr_get_packages_child.list_installed = lambda: ['test']
    PkgMgr_get_packages_child.get_package_details = lambda a: {'name': 'test'}
    assert PkgMgr_get_packages_child.get_packages() == {'test': [{'name': 'test', 'source': 'pkgmgr'}]}



# Generated at 2022-06-24 23:24:33.029394
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    var_0 = CLIMgr()


# Generated at 2022-06-24 23:24:35.358331
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pkgmgr_testvar_0 = PkgMgr()
    res_0 = pkgmgr_testvar_0.is_available()
    if(res_0):
        return 0
    else:
        return 1


# Generated at 2022-06-24 23:24:39.199804
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    var_0 = CLIMgr()
    try:
        var_0.is_available()
        _ok = var_0 == var_0
    except Exception as exc:
        raise Exception("Fail. Method is_available raised an exception with the following message {}".format(exc))
    else:
        if _ok:
            print("Success. Method is_available executed as expected")
        else:
            raise Exception("Fail. Method is_available does not execute as expected. Expected: {}".format(var_0))


# Generated at 2022-06-24 23:24:41.015688
# Unit test for constructor of class LibMgr
def test_LibMgr():
    obj = LibMgr()


# Generated at 2022-06-24 23:24:56.863914
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    a = LibMgr()
    print(a.is_available())



# Generated at 2022-06-24 23:24:58.179470
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    # class instantiation
    lib_mgr = LibMgr()
    # call the method
    result = lib_mgr.is_available()


# Generated at 2022-06-24 23:25:08.614325
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    packages = dict()

    def list_installed():
        packages['name 1'] = 'version 1'
        packages['name 2'] = 'version 2'

    def get_package_details(package):
        details = dict()
        details['name'] = package
        details['version'] = packages[package]
        return details

    class TestClass(PkgMgr):
        def list_installed(self):
            return list_installed()

        def get_package_details(self, package):
            return get_package_details(package)

    test_class = TestClass()
    packages_result = test_class.get_packages()


# Generated at 2022-06-24 23:25:13.345069
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():

    # Create a CLIMgr object
    test_obj = CLIMgr()

    # Call the method
    result = test_obj.is_available()

    # Use assert to verify the result
    assert result == True


# Generated at 2022-06-24 23:25:17.775251
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    test_0 = LibMgr()
    # TODO: Randomize library names
    test_0.LIB = 'ldap'
    # test_0.is_available() == False
    # test_0.is_available() == True


# Generated at 2022-06-24 23:25:20.127496
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    m = CLIMgr()
    assert m.is_available() == False


# Generated at 2022-06-24 23:25:21.254964
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    assert PkgMgr().is_available() == NotImplemented


# Generated at 2022-06-24 23:25:22.815112
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    var_0 = PkgMgr()
    var_1 = var_0.get_package_details(1)


# Generated at 2022-06-24 23:25:26.606399
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    # Instantiate a dummy package manager
    dummy_mgr = PkgMgr()
    assert not dummy_mgr.get_packages()


test_case_0()

# Generated at 2022-06-24 23:25:32.049693
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    assert [{'name': 'foo', 'version': '1.0', 'source': 'apt', 'extra': 'bar'}, {'name': 'foo', 'version': '2.0', 'source': 'apt', 'extra': 'bar'}] == PkgMgr().get_packages()


# Generated at 2022-06-24 23:26:16.114073
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    var_0 = PkgMgr()
    var_0.list_installed = lambda: ['a', 'b', 'c']
    var_0.get_package_details = lambda x: {'name': x}
    var_0.get_packages()


# Generated at 2022-06-24 23:26:20.531840
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    try:
        i = 0
    except ValueError:
        print("test is expected to fail, ValueError")



# Generated at 2022-06-24 23:26:21.758575
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
	var_1 = PkgMgr()
	var_2 = var_1.is_available()


# Generated at 2022-06-24 23:26:26.507198
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    test_instance = PkgMgr()
    test_instance.list_installed = lambda : ['item_0']
    test_instance.get_package_details = lambda arg: arg
    assert test_instance.get_packages() == {'item_0': ['item_0']}


# Generated at 2022-06-24 23:26:27.250988
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pass


# Generated at 2022-06-24 23:26:31.029403
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    var_1 = PkgMgr()
    var_2 = var_1.get_package_details('parameter1')
    if isinstance(var_2, dict):
        pass
    else:
        raise AssertionError


# Generated at 2022-06-24 23:26:33.366279
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    mgr = CLIMgr()
    mgr.is_available()
    try:
        mgr._cli is not None
    except AttributeError:
        raise RuntimeError("CLI manager is not available.")


# Generated at 2022-06-24 23:26:37.772235
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    mock_package = []
    obj = PkgMgr()
    mock_package = obj.get_package_details(mock_package)


# Generated at 2022-06-24 23:26:39.373988
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    var_1 = PkgMgr()
    var_2 = var_1.list_installed()


# Generated at 2022-06-24 23:26:45.220930
# Unit test for constructor of class LibMgr
def test_LibMgr():
    import ansible.module_utils.common._collections_compat as collections_compat
    assert isinstance(LibMgr(),LibMgr)
    assert isinstance(LibMgr()._lib,collections_compat.MutableMapping)


# Generated at 2022-06-24 23:28:15.677068
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    var_0 = PkgMgr()
    var_1 = var_0.get_packages()


# Generated at 2022-06-24 23:28:20.057155
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    test_obj = CLIMgr()
    test_CLIMgr_instance = isinstance(test_obj, CLIMgr)
    assert test_CLIMgr_instance == True



# Generated at 2022-06-24 23:28:21.532598
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():

    assert(test_LibMgr() == True)
    assert(test_LibMgr() != False)


# Generated at 2022-06-24 23:28:24.631848
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    test_LibMgr = LibMgr()
    var_1 = test_LibMgr.is_available()


# Generated at 2022-06-24 23:28:27.026440
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    print("In test_CLIMgr_is_available ...")
    for name, cls in get_all_pkg_managers().items():
        pm = cls()
        print("\t{} {}".format(name,pm.is_available()))

# Generated at 2022-06-24 23:28:33.418547
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    # create PkgMgr class
    PkgMgr_class = PkgMgr()
    # create expected output
    expected_output = None
    # get the actual output
    actual_output = PkgMgr_class.get_packages()
    # assert that actual output equals expected output
    assert expected_output == actual_output

# Main function

# Generated at 2022-06-24 23:28:34.973529
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    assert get_all_pkg_managers() is not None


# Generated at 2022-06-24 23:28:43.389732
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    var_1 = ['ansible']
    var_2 = []
    var_2 = ['ansible']
    var_3 = {'source': 'brew', 'name': 'ansible', 'version': '2.7.2'}
    var_1 = var_2
    var_1 = var_3
    var_4 = {'ansible': [{'source': 'brew', 'name': 'ansible', 'version': '2.7.2'}]}
    var_1 = var_4

# auto-generate test methods for all classes that inherit from PkgMgr

# Generated at 2022-06-24 23:28:44.234460
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    pm = PkgMgr()
    pm.get_packages()

# Generated at 2022-06-24 23:28:45.316233
# Unit test for constructor of class LibMgr
def test_LibMgr():
    var_0 = LibMgr()
