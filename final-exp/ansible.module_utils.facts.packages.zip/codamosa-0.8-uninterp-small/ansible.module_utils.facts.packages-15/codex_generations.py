

# Generated at 2022-06-24 23:21:34.733777
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    lib_mgr = LibMgr()
    # This should at least force a ImportError exception
    assert lib_mgr.is_available() == False


# Generated at 2022-06-24 23:21:37.610815
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    pkg_mgr_0 = PkgMgr()
    package = "numpy"
    pkg_mgr_0.get_package_details(package)


# Generated at 2022-06-24 23:21:39.442847
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    pkg_mgr = PkgMgr()
    assert {} == pkg_mgr.get_packages()


# Generated at 2022-06-24 23:21:40.861422
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    pkg_mgr_1 = CLIMgr()


# Generated at 2022-06-24 23:21:44.675113
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pkg_mgr = PkgMgr()
    list_installed = pkg_mgr.list_installed()     # TypeError: Can't instantiate abstract class PkgMgr with abstract methods list_installed

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 23:21:46.167748
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    with pytest.raises(TypeError):
        pkg_mgr_list_installed()



# Generated at 2022-06-24 23:21:57.183860
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    pkg_mgr_0 = PkgMgr()
    pkg_mgr_0.list_installed = lambda : ['package0', 'package1', 'package2']
    pkg_mgr_0.get_package_details = lambda package: {'name': package, 'version': '1.0.0'}
    installed_packages = pkg_mgr_0.get_packages()

# Generated at 2022-06-24 23:22:00.647580
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pkg_mgr_0 = PkgMgr()
    with pytest.raises(NotImplementedError):
        pkg_mgr_0.is_available()


# Generated at 2022-06-24 23:22:01.432982
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    cli_mgr = CLIMgr()


# Generated at 2022-06-24 23:22:03.076956
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    pkg_mgr_0 = PkgMgr()
    assert pkg_mgr_0.get_packages() == {}


# Generated at 2022-06-24 23:22:08.301822
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    get_all_pkg_managers()

# Generated at 2022-06-24 23:22:10.411277
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    cli_mgr = CLIMgr()


# Generated at 2022-06-24 23:22:13.243922
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    lm = LibMgr()
    assert not lm.is_available()


# Generated at 2022-06-24 23:22:15.649749
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    pkg_mgr = LibMgr()
    pkg_mgr.LIB = 'os'
    assert pkg_mgr.is_available() is True


# Generated at 2022-06-24 23:22:17.300864
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    assert PkgMgr.is_available is PkgMgr.is_available


# Generated at 2022-06-24 23:22:19.197080
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    pkg_mgr_1 = CLIMgr()
    assert(pkg_mgr_1.is_available() == False)


# Generated at 2022-06-24 23:22:23.397116
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    try:
        cli_mgr = CLIMgr()
    except TypeError:
        pass
    else:
        assert False, "Exception expected"



# Generated at 2022-06-24 23:22:23.970216
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    pass

# Generated at 2022-06-24 23:22:24.946785
# Unit test for constructor of class CLIMgr
def test_CLIMgr():

    pkg_mgr_0 = CLIMgr()


# Generated at 2022-06-24 23:22:31.588653
# Unit test for constructor of class LibMgr
def test_LibMgr():
    import unittest2 as unittest
    class Test_LibMgr(unittest.TestCase):

        def test_LibMgr_init(self):
            pkg_mgr = LibMgr()
            pkg_mgr._is_available = lambda : True
            pkg_mgr.is_available()

    unittest.main(argv=['ignored', '-v'], exit=False)


# Generated at 2022-06-24 23:22:37.361240
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    obj = PkgMgr()
    assert type(obj) == PkgMgr
    assert not obj.is_available()


# Generated at 2022-06-24 23:22:41.624184
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    # Initialize the class
    PkgMgr_obj = PkgMgr()
    # Initialize the method with dummy arguments
    PkgMgr_obj.get_package_details('python-regex')
    
    # Check if the method raises an exception
    assertRaises(NotImplementedError)
    

# Generated at 2022-06-24 23:22:42.189902
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    assert True

# Generated at 2022-06-24 23:22:45.082308
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    var_0 = get_all_pkg_managers()
    for i in var_0.values():
        i = i()
        if i.is_available():
            break
    else:
        assert False



# Generated at 2022-06-24 23:22:47.559421
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    test_PkgMgr = PkgMgr()
    try:
        test_PkgMgr.is_available()
    except NotImplementedError:
        pass


# Generated at 2022-06-24 23:22:52.429623
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert(CLIMgr().is_available() == False)


# Generated at 2022-06-24 23:22:54.996092
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    test_case_0()
    assert os.path.exists('/etc/puppetlabs/puppet/puppet.conf')
    var_0 = CLIMgr()
    var_0.is_available()
    assert os.path.exists('/etc/puppetlabs/puppet/puppet.conf')



# Generated at 2022-06-24 23:22:58.287489
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    var_0 = CLIMgr()


# Generated at 2022-06-24 23:22:59.887720
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    obj = CLIMgr()


# Generated at 2022-06-24 23:23:01.238703
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    try:
        PkgMgr()
    except TypeError:
        pass


# Generated at 2022-06-24 23:23:13.289654
# Unit test for constructor of class LibMgr
def test_LibMgr():
    # no exception expected
    var_0 = LibMgr()


# Generated at 2022-06-24 23:23:14.935931
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pass


# Generated at 2022-06-24 23:23:18.894287
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    # Create instance of class PkgMgr
    test_PkgMgr_get_package_details_instance = PkgMgr()
    # Try to call method get_package_details of PkgMgr
    try:
        test_PkgMgr_get_package_details_instance.get_package_details(package)
    except:
        # This should only fail due to abstractmethod not being implemented
        pass
    else:
        assert False


# Generated at 2022-06-24 23:23:22.468922
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    # Executing method is_available of class PkgMgr
    var_0 = PkgMgr()
    var_1 = var_0.is_available()


# Generated at 2022-06-24 23:23:23.828278
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    var_0 = CLIMgr.is_available(CLIMgr())


# Generated at 2022-06-24 23:23:25.681511
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    var_1 = CLIMgr()
    var_2 = CLIMgr.is_available(var_1)


# Generated at 2022-06-24 23:23:28.953621
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    CLIMgr()


# Generated at 2022-06-24 23:23:33.001720
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    # get_all_pkg_managers()
    var_2 = get_all_pkg_managers()

    # iterate over var_2
    for var_4 in var_2:
        # create new PkgMgr instance
        var_1 = var_2.get(var_4)()
        # test call to is_available
        var_3 = var_1.is_available()


# Generated at 2022-06-24 23:23:36.938579
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    cls = PkgMgr()
    result = cls.get_packages()
    assert(False)


# Generated at 2022-06-24 23:23:37.932914
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    var_0 = get_all_pkg_managers()

# Generated at 2022-06-24 23:23:52.555308
# Unit test for constructor of class LibMgr
def test_LibMgr():
    var_0 = LibMgr()


# Generated at 2022-06-24 23:23:54.139120
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    var_1 = CLIMgr()
    var_2 = var_1.is_available()

    pass


# Generated at 2022-06-24 23:23:55.636419
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    var_1 = PkgMgr()
    print(var_1.list_installed())


# Generated at 2022-06-24 23:23:58.853081
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    var_0 = LibMgr()
    var_1 = var_0.is_available()
    

# Generated at 2022-06-24 23:24:01.001336
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    # Create a object of class LibMgr
    var_1 = LibMgr()
    assert var_1.is_available() == False


# Generated at 2022-06-24 23:24:03.885492
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    for cls in get_all_subclasses(CLIMgr):
        if cls is PkgMgr:
            continue
        c = cls()
        test_case_0()
        c.is_available()

# Generated at 2022-06-24 23:24:10.904976
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    # testing basic case, empty package list
    # empty list is returned as expected when there are no packages installed
    pkg_mgr_test_0 = PkgMgr()
    pkg_mgr_test_0.list_installed = lambda: []
    assert pkg_mgr_test_0.get_packages() == {}
    # testing with one package
    # correct package is returned as expected when one package is installed
    pkg_mgr_test_1 = PkgMgr()
    pkg_mgr_test_1.list_installed = lambda: ['a']
    pkg_mgr_test_1.get_package_details = lambda x: {'name': x, 'version': '1.0'}

# Generated at 2022-06-24 23:24:11.898722
# Unit test for constructor of class LibMgr
def test_LibMgr():
    pass


# Generated at 2022-06-24 23:24:15.314300
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    obj = CLIMgr()
    try:
        ret = obj.is_available()
    except Exception:
        if '_obj' in locals():
            del _obj
        raise ValueError("Unexpected exception")
    if '_obj' in locals():
        del _obj


# Generated at 2022-06-24 23:24:19.394680
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    lib_mgr = LibMgr()
    lib_mgr.is_available()


# Generated at 2022-06-24 23:24:49.911438
# Unit test for constructor of class LibMgr
def test_LibMgr():
    assert "LibMgr" == LibMgr.__name__


# Generated at 2022-06-24 23:24:50.803157
# Unit test for constructor of class LibMgr
def test_LibMgr():
    obj = LibMgr()
    assert(obj != None)


# Generated at 2022-06-24 23:24:52.255318
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    pass # TODO: write test and update this comment

# Generated at 2022-06-24 23:24:54.419952
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    #self.fail('Test Not Implemented')
    return


# Generated at 2022-06-24 23:24:56.279499
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    e = PkgMgr()
    output = e.get_packages()
    assert(output == dict)



# Generated at 2022-06-24 23:25:02.045161
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    var_0 = get_all_pkg_managers()
    var_1 = var_0["apt"]()
    var_1.is_available()
    return var_1.list_installed()


# Generated at 2022-06-24 23:25:08.254444
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    # available
    cli_mgr = CLIMgr()
    cli_mgr.CLI = 'ls'
    result = cli_mgr.is_available()
    assert result
    # not available
    cli_mgr.CLI = 'fake-binary'
    result = cli_mgr.is_available()
    assert not result


# Generated at 2022-06-24 23:25:13.314829
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    var_0 = get_all_pkg_managers()
    for var_1 in var_0:
        pass
    var_2 = var_0.get('apk')
    var_3 = var_2.list_installed()


# Generated at 2022-06-24 23:25:14.678276
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    # Test coverage for when no arguments are provided
    pm = PkgMgr(None)
    assert pm.get_package_details() is None

# Generated at 2022-06-24 23:25:16.096615
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    inst = CLIMgr()
    assert inst.is_available() == None


# Generated at 2022-06-24 23:26:33.333651
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    # Simple object initialization
    obj_0 = PkgMgr()
    # Invoke method
    var_0 = obj_0.get_packages()


# Generated at 2022-06-24 23:26:37.922814
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    libmgr = LibMgr()
    # Real world code uses a lib that is not available, so we check that this works
    assert libmgr.is_available() == False


# Generated at 2022-06-24 23:26:38.361648
# Unit test for constructor of class LibMgr
def test_LibMgr():
    var_0 = LibMgr()

# Generated at 2022-06-24 23:26:40.826987
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    # test that get_packages returns a dictionary when the class is not implemented
    class PkgMgrTest(PkgMgr): # create a class with no methods implemented
        pass
    var_1 = PkgMgrTest.get_packages()
    var_2 = isinstance(var_1, dict)
    assert var_2 == True


# Generated at 2022-06-24 23:26:44.111559
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    var_1 = PkgMgr.is_available(object)


# Generated at 2022-06-24 23:26:47.469183
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    testcase_0_mock_lib_mgr = MockLibMgr()
    assert testcase_0_mock_lib_mgr.get_packages() == {}, "Unit test failure"
    testcase_1_mock_cli_mgr = MockCLIMgr()
    assert testcase_1_mock_cli_mgr.get_packages() == {}, "Unit test failure"


# Generated at 2022-06-24 23:26:51.547473
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    _ret_0 = LibMgr().is_available()


# Generated at 2022-06-24 23:26:59.391914
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    def get_package_details(self, package):
        return {
            'name': package,
            'version': '0.0.0'
        }

    class TestMgrA(PkgMgr):

        def list_installed(self):
            return ['a', 'b']

    TestMgrA.get_package_details = get_package_details

    mgr = TestMgrA()
    packages = mgr.get_packages()
    assert len(packages) == 2
    assert 'a' in packages
    assert 'b' in packages
    assert packages['a'][0]['version'] == '0.0.0'
    assert packages['a'][0]['name'] == 'a'
    assert packages['b'][0]['version'] == '0.0.0'

# Generated at 2022-06-24 23:27:02.965725
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    test = CLIMgr()
    test.CLI = ''
    test_case_0()
    assert len(test.CLI) <= 0


# Generated at 2022-06-24 23:27:03.833176
# Unit test for constructor of class LibMgr
def test_LibMgr():
   pass


# Generated at 2022-06-24 23:30:01.552249
# Unit test for constructor of class LibMgr
def test_LibMgr():
    obj_case_0 = LibMgr()
    var_0 = obj_case_0.LIB


# Generated at 2022-06-24 23:30:02.875910
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    var_1 = CLIMgr()
    var_2 = var_1.is_available()


# Generated at 2022-06-24 23:30:05.767079
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    pass


# Generated at 2022-06-24 23:30:10.994160
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    var_0 = PkgMgr()
    var_1 = var_0.get_package_details()
    assert var_1 != None


# Generated at 2022-06-24 23:30:12.589740
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    pkg_mgr_obj = PkgMgr()
    result = pkg_mgr_obj.get_packages()
    assert isinstance(result, dict)

# Generated at 2022-06-24 23:30:13.230471
# Unit test for constructor of class LibMgr
def test_LibMgr():
    var_1 = LibMgr()


# Generated at 2022-06-24 23:30:18.387502
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    obj_0 = CLIMgr()
    obj_0.CLI = '\x5d\x60\x6b\x7a\x43\x68\x46\x59'
    assert obj_0.is_available() == False


# Generated at 2022-06-24 23:30:20.594138
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    if  isinstance(PkgMgr.list_installed, abc.abstractmethod):
        raise TypeError('list_installed should be implemented in PkgMgr.list_installed')


# Generated at 2022-06-24 23:30:24.685987
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    assert(1 == 1)

    # Test method on parent class, this is a no-op
    p = PkgMgr()
    assert(p.get_packages() is None)



# Generated at 2022-06-24 23:30:27.742167
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    if test_CLIMgr_is_available.__did_it:
        return

    test_CLIMgr_is_available.__did_it = True

    # Test implementation ...
    pass

test_CLIMgr_is_available.__did_it = False
