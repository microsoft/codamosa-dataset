

# Generated at 2022-06-24 23:21:35.105755
# Unit test for constructor of class LibMgr
def test_LibMgr():
    pkg_mgr_0 = LibMgr()


# Generated at 2022-06-24 23:21:36.749401
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pm = PkgMgr()
    assert pm.is_available() is not True, "Class PkgMgr -> method is_available -> is_available of class PkgMgr should be abstract method"

# Generated at 2022-06-24 23:21:42.457604
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    """Test that get_all_pkg_managers() returns the correct dict of classes"""

    ret = get_all_pkg_managers()
    expected_klass_names = ['apt', 'apk', 'dnf', 'pacman', 'pip', 'pkgng', 'pkg5', 'portage', 'portinstall', 'rpm', 'up2date', 'yum']

    assert set(ret.keys()) == set(expected_klass_names)


# Generated at 2022-06-24 23:21:48.783579
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    pkg_mgr = PkgMgr()
    pkg_mgr.list_installed = lambda: ['dummmy1', 'dummy2']
    pkg_mgr.get_package_details = lambda pkg: {'name': pkg, 'version': pkg}
    assert pkg_mgr.get_packages() == {'dummmy1': [{'name': 'dummmy1', 'version': 'dummmy1', 'source': 'pkgmgr'}],
                                      'dummy2': [{'name': 'dummy2', 'version': 'dummy2', 'source': 'pkgmgr'}]}

# Generated at 2022-06-24 23:21:50.248832
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    pkg_mgr_1 = CLIMgr()



# Generated at 2022-06-24 23:21:52.348558
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    temp_pkg_mgr = CLIMgr()

# Generated at 2022-06-24 23:21:54.243109
# Unit test for constructor of class LibMgr
def test_LibMgr():
    libmgr = LibMgr()
    if libmgr == None:
        raise Exception("LibMgr constructor does not work")


# Generated at 2022-06-24 23:21:57.232261
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    pkg_mgr_0 = PkgMgr()
    with pytest.raises(AttributeError) as attribute_error:
        pkg_mgr_0.get_packages()

    assert attribute_error.type == AttributeError
    assert "Can't call abstract methods" in str(attribute_error.value)



# Generated at 2022-06-24 23:21:59.872400
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    pkg_mgr_0 = PkgMgr()
    pkg_mgr_0.get_package_details("test")


# Generated at 2022-06-24 23:22:00.557453
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pass


# Generated at 2022-06-24 23:22:09.046885
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    check_CLIMgr = CLIMgr()

    # Call is_available method to check if it works correctly
    check_CLIMgr.is_available()
    return check_CLIMgr



# Generated at 2022-06-24 23:22:13.114657
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    var_0 = CLIMgr()
    assert var_0.CLI is None
    assert var_0._cli is None


# Generated at 2022-06-24 23:22:13.995365
# Unit test for constructor of class LibMgr
def test_LibMgr():
    lib = LibMgr()


# Generated at 2022-06-24 23:22:22.725485
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    # assert var_0 == expected

    # Initialize an object of class CLIMgr
    var_0 = CLIMgr()
    var_1 = var_0.is_available()
    var_2 = var_0.CLI
    var_3 = var_0._cli
    var_4 = var_0.list_installed()
    var_5 = var_0.get_package_details()
    var_6 = var_0.get_packages()
    var_7 = var_0._lib
    assert var_1 == None
    assert var_2 == None
    assert var_3 == None
    assert var_4 == None
    assert var_5 == None
    assert var_6 == None
    assert var_7 == None


# Generated at 2022-06-24 23:22:25.842277
# Unit test for constructor of class LibMgr
def test_LibMgr():
    assert True


# Generated at 2022-06-24 23:22:30.047029
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    var_1 = PkgMgr()
    try:
        var_1.is_available()
    except NotImplementedError:
        return 0
    return 1


# Generated at 2022-06-24 23:22:34.190896
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    l = LibMgr()
    l._lib = None
    assert l.is_available() == False


# Generated at 2022-06-24 23:22:35.884101
# Unit test for constructor of class LibMgr
def test_LibMgr():
    var_0 = LibMgr()
    assert var_0.is_available()


# Generated at 2022-06-24 23:22:38.218373
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    var_0 = CLIMgr()
    var_1 = get_bin_path('yum')
    assert var_0._cli == var_1


# Generated at 2022-06-24 23:22:40.186226
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():

    """
    Test the default package manager - rpm

    """

    var_1 = LibMgr.is_available(LibMgr)


# Generated at 2022-06-24 23:22:58.094652
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    from collections import OrderedDict
    X = OrderedDict()
    X['name'] = "ansible"
    X['version'] = "2.6.0"
    Y = OrderedDict()
    Y['name'] = "ansible"
    Y['version'] = "2.5.1"
    package_list = [X, Y]
    def test_list_installed():
        return package_list
    def test_get_package_details(package):
        return package
    m = PkgMgr()
    m.list_installed = test_list_installed
    m.get_package_details = test_get_package_details

# Generated at 2022-06-24 23:23:00.922414
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    cli_mgr = CLIMgr()
    assert cli_mgr is not None
    assert cli_mgr._cli is None


# Generated at 2022-06-24 23:23:09.802674
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    # check that is_available always returns an instance of bool or None
    var_0 = PkgMgr()
    var_1 = var_0.is_available()
    var_2 = isinstance(var_1, bool)
    var_3 = isinstance(var_1, type(None))
    assert isinstance(var_1, bool) or isinstance(var_1, type(None)), "is_available does not return a bool or None"
    assert var_2 or var_3, "is_available does not return a bool or None"


# Generated at 2022-06-24 23:23:15.985010
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    try:
        var_1 = LibMgr()
    except ImportError:
        var_2 = False
    except Exception:
        var_2 = True
    assert var_2 == False


# Generated at 2022-06-24 23:23:17.064202
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    # TODO: add test
    pass


# Generated at 2022-06-24 23:23:28.266582
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    try:
        assert test_case_0()
        print("Passed")
        assert True
    except AssertionError:
        print("Failed")
        assert False

if __name__ == "main":
    test_get_all_pkg_managers()

# Generated at 2022-06-24 23:23:29.792818
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    var_0 = CLIMgr()
    assert var_0.is_available() is True


# Generated at 2022-06-24 23:23:30.568815
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    test = CLIMgr()


# Generated at 2022-06-24 23:23:31.589026
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    instance = CLIMgr()
    var_0 = instance._cli


# Generated at 2022-06-24 23:23:33.725179
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    var_0 = CLIMgr()
    var_0.CLI = 'foo'    
    var_0.is_available()
    var_0.is_available()


# Generated at 2022-06-24 23:23:49.312741
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    var_0 = LibMgr()


# Generated at 2022-06-24 23:23:51.850341
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    var_1 = LibMgr()
    var_2 = var_1.is_available()


# Generated at 2022-06-24 23:23:55.108975
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert type(CLIMgr()) == CLIMgr, "The object created using CLIMgr() should be of type CLIMgr"
    assert type(CLIMgr()) != LibMgr, "The object created using CLIMgr() should not be of type LibMgr"


# Generated at 2022-06-24 23:23:55.894716
# Unit test for constructor of class LibMgr
def test_LibMgr():
    pr = LibMgr()



# Generated at 2022-06-24 23:24:05.821925
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    # Import needed modules
    import logging
    import pytest
    import sys
    import unittest

    # Create the test object
    obj = PkgMgr()
    with pytest.raises(NotImplementedError):
        obj.is_available()

try:
    from ansible.module_utils.common.process import get_bin_path
except ImportError:
    pass
else:
    # Unit test for method is_available of class CLIMgr
    def test_CLIMgr_is_available():
        # Import needed modules
        import logging
        import pytest
        import sys
        import unittest

        # Create the test object
        obj = CLIMgr()
        with pytest.raises(NotImplementedError):
            obj.is_available()
    


# Generated at 2022-06-24 23:24:07.602585
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():

    # Test case 0:
    # This test case is used to test that a connected client can return information
    var_0 = LibMgr()
    assert var_0.is_available() == False


# Generated at 2022-06-24 23:24:09.788633
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    case_0 = PkgMgr
    try:
        test_case_0()
    except Exception as exp:
        print('Exception message: ' + str(exp))
        print('Traceback: ' + str(traceback.format_exc()))
        assert False


# Generated at 2022-06-24 23:24:12.780062
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    libMgr = get_all_pkg_managers()['libmgr']()
    var_0 = libMgr.is_available()


# Generated at 2022-06-24 23:24:14.955712
# Unit test for constructor of class LibMgr
def test_LibMgr():
    cls = LibMgr()
    cls._lib = True
    return (True if cls.is_available() == True else False)


# Generated at 2022-06-24 23:24:21.234076
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    print("is_available")
    # Set up a PkgMgr class object.
    obj = PkgMgr()
    # Call is_available with the object.
    is_available(obj)
    # Raise exception if method is_available of class PkgMgr fails.
    assert "is_available is not implemented"


# Generated at 2022-06-24 23:24:55.336290
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    from ansible.module_utils.facts.system.pkg_mgr.package_manager import PkgMgr
    test_PkgMgr = PkgMgr()
    assert test_PkgMgr.get_packages() is None


# Generated at 2022-06-24 23:24:56.491590
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    var_1 = CLIMgr()
    assert var_1 is not None

# Generated at 2022-06-24 23:24:57.001440
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    pass

# Generated at 2022-06-24 23:24:57.741507
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    obj = CLIMgr()
    assert obj != None


# Generated at 2022-06-24 23:24:58.944994
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    # this is pytest variable
    var_pkg_mgr = PkgMgr()
    # this is pytest variable
    var_packages = var_pkg_mgr.get_packages()

# Generated at 2022-06-24 23:25:00.653771
# Unit test for constructor of class LibMgr
def test_LibMgr():
    instance_of_LibMgr = LibMgr()
    test_case_0()


# Generated at 2022-06-24 23:25:01.440359
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    pass


# Generated at 2022-06-24 23:25:02.268409
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    var_1 = CLIMgr()
    assert var_1.is_available()


# Generated at 2022-06-24 23:25:04.276213
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    var_0 = CLIMgr()


# Generated at 2022-06-24 23:25:06.155665
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    libMgr = LibMgr();
    var_0 = libMgr.is_available(); # Test


# Generated at 2022-06-24 23:26:23.577755
# Unit test for constructor of class LibMgr
def test_LibMgr():
    # test_case_0
    assert test_case_0()


# Generated at 2022-06-24 23:26:25.933332
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    try:
        get_bin_path(None)
    except ValueError:
        return True
    return False


# Generated at 2022-06-24 23:26:26.707220
# Unit test for constructor of class LibMgr
def test_LibMgr():
    LibMgr()


# Generated at 2022-06-24 23:26:29.170708
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():

    test = LibMgr()
    test._lib = {'test': 'test'}
    if test.is_available() == True:
        print('Test passed')
    else:
        print('Test failed')


# Generated at 2022-06-24 23:26:30.543028
# Unit test for constructor of class LibMgr
def test_LibMgr():
    try:
        LibMgr()
        assert True
    except:
        assert False


# Generated at 2022-06-24 23:26:32.381672
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    var_0 = PkgMgr()
    try:
        var_0.is_available()
        assert False
    except NotImplementedError:
        pass


# Generated at 2022-06-24 23:26:33.113761
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    var_0 = LibMgr()


# Generated at 2022-06-24 23:26:34.526961
# Unit test for constructor of class LibMgr
def test_LibMgr():
  
    lm = LibMgr()
    assert lm
    assert LibMgr
    assert LibMgr.LIB == None



# Generated at 2022-06-24 23:26:38.769273
# Unit test for constructor of class LibMgr
def test_LibMgr():
    LibMgr()


# Generated at 2022-06-24 23:26:39.855896
# Unit test for constructor of class LibMgr
def test_LibMgr():
    assert isinstance(LibMgr(),LibMgr)


# Generated at 2022-06-24 23:29:39.889764
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    x = CLIMgr()
    assert hasattr(CLIMgr, 'is_available')
    assert isinstance(CLIMgr.is_available, object)

# Generated at 2022-06-24 23:29:42.608405
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    var_0 = LibMgr()


# Generated at 2022-06-24 23:29:43.794138
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    var_0 = LibMgr()
    var_0.is_available()



# Generated at 2022-06-24 23:29:45.365286
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    assert var_0 is not None, "var_0 is not None"

# Generated at 2022-06-24 23:29:53.188491
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    # Create mock instance
    test_PkgMgr = PkgMgr()
    # Create function call
    # Returned value will be assigned to mock_call_return_value
    #run_mock = MagicMock(return_value=mock_call_return_value)
    #test_PkgMgr.run_command = run_mock
    # Execute function call
    test_result = test_PkgMgr.list_installed()
    # Verify the results
    #assertEqual(test_result, expected_return_value)
    assert True


# Generated at 2022-06-24 23:29:54.363966
# Unit test for constructor of class LibMgr
def test_LibMgr():
    var_0 = LibMgr()
    assert var_0.is_available() == False
    assert var_0._lib == None


# Generated at 2022-06-24 23:29:55.339264
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    test_CLIMgr = CLIMgr()


# Generated at 2022-06-24 23:29:57.873134
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    mgr = CLIMgr()
    assert not mgr.is_available()


# Generated at 2022-06-24 23:29:58.463287
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pass



# Generated at 2022-06-24 23:30:08.084902
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestLibMgr(LibMgr):
        def __init__(self):
            super().__init__()

        def is_available(self):
            return True

        def list_installed(self):
            return []

        def get_package_details(self, package):
            return {}

    # Test with imports
    TestLibMgr.LIB = "ansible.module_utils.facts.other.system.pkg_mgrs"
    pkg_mgr = TestLibMgr()
    assert pkg_mgr.is_available() is True

    # Test without imports
    TestLibMgr.LIB = "no.such.module"
    pkg_mgr = TestLibMgr()
    assert pkg_mgr.is_available() is False

