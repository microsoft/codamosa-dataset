

# Generated at 2022-06-24 23:21:38.318886
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    # create the class
    c_l_i_mgr_1 = CLIMgr()
    # check for exception
    try:
        c_l_i_mgr_1.get_package_details('pkg')
    except AttributeError:
        pass
    else:
        raise AssertionError
    # both cases pass without errors

# Generated at 2022-06-24 23:21:47.387095
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr.__doc__ != None, "You must provide docstring for class"
    assert CLIMgr.CLI == None, "You must provide CLI for class"
    assert CLIMgr.is_available.__doc__ != None, "You must provide docstring for function"
    assert CLIMgr.list_installed.__doc__ != None, "You must provide docstring for function"
    assert CLIMgr.get_package_details.__doc__ != None, "You must provide docstring for function"
    assert CLIMgr.get_packages.__doc__ != None, "You must provide docstring for function"
    assert CLIMgr.__init__.__doc__ != None, "You must provide docstring for constructor"
    assert isinstance(test_case_0(),object), "Constructor is not returning any object"

# Generated at 2022-06-24 23:21:51.028653
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    c_l_i_mgr_1 = CLIMgr()
    assert(c_l_i_mgr_1 is not None)


# Generated at 2022-06-24 23:21:52.511727
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    base_1 = PkgMgr()
    assert base_1.is_available() == NotImplementedError


# Generated at 2022-06-24 23:21:54.421343
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    lib_mgr_0 = LibMgr()
    assert not lib_mgr_0.is_available()


# Generated at 2022-06-24 23:21:59.656202
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    try:
        test_case_0()
        assert True
    except ImportError:
        assert False

# Generated at 2022-06-24 23:22:00.780387
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    assert not PkgMgr.is_available()


# Generated at 2022-06-24 23:22:01.846960
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    assert (False == CLIMgr().is_available())


# Generated at 2022-06-24 23:22:02.577625
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    assert True == PkgMgr.is_available()


# Generated at 2022-06-24 23:22:08.964195
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    if LibMgr.is_available():
        print("True")
    else:
        print("False")


# Generated at 2022-06-24 23:22:15.687905
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    # Todo: Add up meaningful testcase
    c_l_i_mgr_0 = CLIMgr()
    assert c_l_i_mgr_0.is_available()

# Generated at 2022-06-24 23:22:16.272302
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    pass



# Generated at 2022-06-24 23:22:22.114846
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():

    # Test get_package_details() of PkgMgr without subclass
    test_PkgMgr_obj = PkgMgr()

    try:
        test_PkgMgr_obj.get_package_details('dummy_package_name')
    except NotImplementedError:
        print("get_package_details() not implemented for PkgMgr")
    else:
        raise Exception("get_package_details() should not be implemented for PkgMgr")


# Generated at 2022-06-24 23:22:26.980907
# Unit test for constructor of class LibMgr
def test_LibMgr():

    for pkg_mgr in get_all_pkg_managers().values():
        if isinstance(pkg_mgr, LibMgr):
            pkg_mgr()


# Generated at 2022-06-24 23:22:35.354367
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    c_l_i_mgr_0 = CLIMgr()
    assert c_l_i_mgr_0.is_available() is False, "Return value mismatch"

test_case_0()

test_case_1()

test_case_2()

test_case_3()

test_case_4()

test_case_5()

test_case_6()

test_case_7()

test_case_8()

test_case_9()

test_case_10()

test_case_11()

test_case_12()

test_case_13()

test_case_14()

test_case_15()

test_case_16()

test_case_17()

test_case_18()

test_case

# Generated at 2022-06-24 23:22:44.570484
# Unit test for function get_all_pkg_managers

# Generated at 2022-06-24 23:22:45.714993
# Unit test for constructor of class LibMgr
def test_LibMgr():
    lib_mgr_0 = LibMgr()


# Generated at 2022-06-24 23:22:50.735393
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    # Test to check method is_available works
    c_l_i_mgr = CLIMgr()
    assert c_l_i_mgr.is_available() == False


# Generated at 2022-06-24 23:22:52.453490
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    lib_mgr_0 = LibMgr()
    assert lib_mgr_0.is_available() == False


# Generated at 2022-06-24 23:22:53.961594
# Unit test for constructor of class LibMgr
def test_LibMgr():
    lib_mgr = LibMgr()
    assert isinstance(lib_mgr, LibMgr)
    assert isinstance(lib_mgr, PkgMgr)


# Generated at 2022-06-24 23:22:59.171825
# Unit test for constructor of class LibMgr
def test_LibMgr():
    var_1 = LibMgr()


# Generated at 2022-06-24 23:23:06.078305
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    import os
    import mock
    import ansible
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.collectors.pkg_mgr import CLIMgr, LibMgr, PkgMgr, get_all_pkg_managers
    from ansible.module_utils.facts.collectors.pkg_mgr.ec2 import EC2Mgr
    from ansible.module_utils.facts.collectors.pkg_mgr.apk import APKMgr
    from ansible.module_utils.facts.collectors.pkg_mgr.apt import APTMgr
    from ansible.module_utils.facts.collectors.pkg_mgr.apt_rpm import ARPMgr
    from ansible.module_utils.facts.collectors.pkg_mgr.bsd import B

# Generated at 2022-06-24 23:23:06.928044
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    return


# Generated at 2022-06-24 23:23:08.257415
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    var_0 = PkgMgr()
    var_0.is_available()


# Generated at 2022-06-24 23:23:10.022980
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    var_1 = CLIMgr()
    with pytest.raises(NotImplementedError):
        var_1.is_available()


# Generated at 2022-06-24 23:23:16.498094
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():

    # Check if get_package_details method raises NotImplementedError if called with no arguments
    with pytest.raises(NotImplementedError):
        pkg_mgr = PkgMgr()
        pkg_mgr.get_package_details()


# Generated at 2022-06-24 23:23:22.467437
# Unit test for constructor of class LibMgr
def test_LibMgr():
    from ansible.module_utils.facts.pkg_mgr import LibMgr
    libmgr = LibMgr()


# Generated at 2022-06-24 23:23:24.819179
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    var_0 = get_all_pkg_managers()
    var_1 = PkgMgr()
    var_2 = var_1.list_installed


# Generated at 2022-06-24 23:23:26.313635
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    var_0 = PkgMgr()
    var_1 = var_0.list_installed()


# Generated at 2022-06-24 23:23:30.794024
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    assert PkgMgr().get_package_details("") == None


# Generated at 2022-06-24 23:23:47.232299
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    var_0 = get_all_pkg_managers()

# Generated at 2022-06-24 23:23:49.880619
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    test_cases = [0]
    for test_case in test_cases:
        globals()['test_case_%s' % test_case]()

test_PkgMgr_get_packages()

# Generated at 2022-06-24 23:23:57.425751
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    from ansible.module_utils.facts.system.pkg_mgr import get_all_pkg_managers
    PkgMgr_instance = get_all_pkg_managers()["debmgr"]()
    PkgMgr_instance.is_available = lambda : True
    PkgMgr_instance.list_installed = lambda : ["package1", "package2", "package3"]
    PkgMgr_instance.get_package_details = lambda x: {"name": x}
    PkgMgr_instance.get_packages()


test_case_0()
test_PkgMgr_get_packages()

# Generated at 2022-06-24 23:24:00.882905
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    print('PkgMgr')
    var_0 = PkgMgr()
    try:
        print(var_0.get_packages())
    except NotImplementedError:
        print('Caught NotImplementedError')


# Generated at 2022-06-24 23:24:02.343689
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    var_0 = LibMgr()
    var_0.is_available()


# Generated at 2022-06-24 23:24:04.971555
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    var_0 = PkgMgr()
    var_0.get_package_details("")

# Generated at 2022-06-24 23:24:08.877584
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    # Create a mock PkgMgr object
    var_0 = PkgMgr()
    try:
        # Call the method (TODO)
        ret_val = var_0.get_packages()
    except Exception as e:
        # Check exception is None
        return (type(e) == type(None))
    # Check if can retrieve package information
    if 'example_package' not in ret_val:
        return False
    # Check if can retrieve version information
    if '1.2.3' not in ret_val['example_package'][0]['version']:
        return False
    return True

# Generated at 2022-06-24 23:24:12.819661
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    with pytest.raises(TypeError) as excinfo:
        CLIMgr()
    assert "Can't instantiate abstract class CLIMgr with abstract methods CLI" in str(excinfo.value)


# Generated at 2022-06-24 23:24:13.600798
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    var_1 = CLIMgr()

# Generated at 2022-06-24 23:24:16.277973
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    var_0 = get_all_pkg_managers()
    var_1 = test_case_0()
    var_2 = CLIMgr()
    var_3 = var_2.is_available()


# Generated at 2022-06-24 23:24:34.001648
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    var_0 = CLIMgr()


# Generated at 2022-06-24 23:24:36.895200
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():

    # Declare variables used in this test
    var_0 = None
    var_1 = None

    # Define test values for method's arguments
    package = None

    # Call the method
    var_0 = PkgMgr.list_installed(package)

    # Assert return code
    assert var_0 is None


# Generated at 2022-06-24 23:24:44.627232
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    obj0 = get_all_pkg_managers()
    var_0 = [('apk', ApkMgr), ('apt', AptMgr), ('dnf', DnfMgr), ('pkg5', Pkg5Mgr), ('pkgin', PkginMgr), ('portage', PortageMgr), ('ports', PortsMgr), ('swdepot', SwdepotMgr), ('up2date', Up2dateMgr), ('yum', YumMgr), ('zypper', ZypperMgr), ('pacman', PacmanMgr), ('pkgng', PkgNgMgr), ('pip', PipMgr), ('rpm', RpmMgr), ('pkgr', PkgrMgr), ('rpm-ostree', OstreeMgr), ('solpkg', SolpkgMgr)]

# Generated at 2022-06-24 23:24:46.803101
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    var_1 = PkgMgr()
    var_2 = var_1.is_available()



# Generated at 2022-06-24 23:24:52.147005
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    import types
    a_CLIMgr = CLIMgr()
    assert isinstance(a_CLIMgr.is_available(), bool)
    assert isinstance(a_CLIMgr.is_available(), types.BooleanType)


# Generated at 2022-06-24 23:24:54.660529
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    cls = PkgMgr()
    cls.is_available()


# Generated at 2022-06-24 23:24:56.492159
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    _object = CLIMgr()
    _object.CLI = "git"
    test_result = _object.is_available()


# Generated at 2022-06-24 23:24:58.107900
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    var_0 = CLIMgr()
    res = var_0.is_available()


# Generated at 2022-06-24 23:25:01.292767
# Unit test for constructor of class LibMgr
def test_LibMgr():

    var_1 = LibMgr()


# Generated at 2022-06-24 23:25:04.113476
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    obj = CLIMgr()
    assert obj.is_available() == False


# Generated at 2022-06-24 23:25:47.148029
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    assert False


# Generated at 2022-06-24 23:25:48.210929
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    assert get_all_pkg_managers()

# Generated at 2022-06-24 23:25:52.648939
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    # Test scenario 1
    libMgr_1 = LibMgr()
    libMgr_1.LIB = "unittest.mock"
    assert libMgr_1.is_available() == True


# Generated at 2022-06-24 23:25:53.695019
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    # TODO - please add unit tests
    #assert(False)
    pass

# Generated at 2022-06-24 23:25:57.130322
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    # Create class instance
    pkgmgr = CLIMgr()

    b_retval = pkgmgr.is_available()

    # Ensure return value is boolean
    assert isinstance(b_retval, bool)


# Generated at 2022-06-24 23:26:03.045896
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    test_lib_mgr_obj = LibMgr()
    assert test_lib_mgr_obj.is_available() == False


# Generated at 2022-06-24 23:26:03.793612
# Unit test for constructor of class LibMgr
def test_LibMgr():
    try:
        LibMgr()
    except:
        pass


# Generated at 2022-06-24 23:26:08.675002
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    try:
        for cls in get_all_subclasses(PkgMgr):
            if cls not in (CLIMgr, LibMgr):
                obj = cls()
                obj.is_available()
    except NameError:
        assert False


# Generated at 2022-06-24 23:26:16.866176
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    # Testing the return value of method get_packages with valid inputs
    var_0 = get_all_pkg_managers()
    var_1 = var_0["pkgmgr"]
    inst_0 = var_1()
    var_2 = inst_0.get_packages()
    var_3 = var_0["pkgmgr"]
    inst_1 = var_3()
    var_4 = inst_1.get_packages()

    # Testing the return value of method get_packages with valid inputs
    var_0 = get_all_pkg_managers()
    var_1 = var_0["pkgmgr"]
    inst_0 = var_1()
    var_2 = inst_0.get_packages()
    var_3 = var_0["pkgmgr"]
    inst_1 = var_3()
   

# Generated at 2022-06-24 23:26:19.266370
# Unit test for constructor of class LibMgr
def test_LibMgr():
    test_case_0()

# Generated at 2022-06-24 23:28:02.392378
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    var_0 = get_all_pkg_managers()
    for var_1 in var_0.values():
        var_2 = var_1()
        var_3 = var_2.is_available()
        if var_3:
            var_4 = var_2.get_packages()
            var_5 = type(var_4)
            var_6 = dict
            if var_5 != var_6:
                raise Exception("Failed to get the packages list")


# Generated at 2022-06-24 23:28:03.618554
# Unit test for constructor of class CLIMgr
def test_CLIMgr():

    var_0 = CLIMgr()
    assert isinstance(var_0, CLIMgr)


# Generated at 2022-06-24 23:28:09.098700
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    # Set up test environment

    # Create new CLIMgr object
    instance = CLIMgr()
    
    # Test is_available method
    returned_value = instance.is_available()
    assert returned_value == True


# Generated at 2022-06-24 23:28:11.323431
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    var_0 = get_all_pkg_managers()
    for var_key in var_0:
        var_1 = var_0.get(var_key)
        var_1.list_installed()


# Generated at 2022-06-24 23:28:15.342730
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    pkg = LibMgr()
    pkg.is_available()


# Generated at 2022-06-24 23:28:18.528771
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    var_0 = LibMgr()
    var_1 = var_0.is_available()


# Generated at 2022-06-24 23:28:19.833583
# Unit test for constructor of class LibMgr
def test_LibMgr():
    obj_LibMgr = LibMgr()


# Generated at 2022-06-24 23:28:24.261795
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    var_0 = PkgMgr()
    var_0.is_available = lambda: None
    var_0.list_installed = lambda: None
    var_0.get_package_details = lambda arg: None
    var_0.get_packages()


# Generated at 2022-06-24 23:28:25.659352
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    input = ['CLIMgr()']
    output = (True, False)
    result = output

    assert result == output


# Generated at 2022-06-24 23:28:28.818392
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    # TODO: Add test cases for method PkgMgr.get_package_details
    raise NotImplementedError()
