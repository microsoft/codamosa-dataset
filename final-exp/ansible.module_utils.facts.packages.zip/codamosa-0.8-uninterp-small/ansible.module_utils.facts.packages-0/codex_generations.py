

# Generated at 2022-06-24 23:21:35.199483
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    cli_mgr_0 = CLIMgr()
    assert not cli_mgr_0.is_available()

# Generated at 2022-06-24 23:21:36.260740
# Unit test for constructor of class LibMgr
def test_LibMgr():
    import pytest
    lm = LibMgr()

    assert lm._lib == None


# Generated at 2022-06-24 23:21:37.261217
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():

    pass


# Generated at 2022-06-24 23:21:38.153112
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    assert test_case_0()



# Generated at 2022-06-24 23:21:40.234589
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    mgr = PkgMgr()
    try:
        mgr.get_package_details(None)
    except Exception as e:
        if not isinstance(e, NotImplementedError):
            raise Exception('NotImplementedError exception was not raised for method get_package_details of class PkgMgr')


# Generated at 2022-06-24 23:21:41.584630
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    mgr = PkgMgr()
    assert False



# Generated at 2022-06-24 23:21:43.998566
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    test_mgr = CLIMgr()
    assert test_mgr.CLI == None
    assert test_mgr._cli == None


# Generated at 2022-06-24 23:21:47.793167
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    # Define instance to be tested
    lib_mgr_0 = LibMgr()

    # Check if method is_available throws exception
    try:
        lib_mgr_0.is_available()
    except:
        pass
    else:
        catchFlag = False

    # Check function return value
    assert lib_mgr_0.is_available() == False


# Generated at 2022-06-24 23:21:50.646775
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    lib_mgr_0 = LibMgr()
    assert lib_mgr_0.is_available() == False


# Generated at 2022-06-24 23:21:52.349985
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    test_case_0()

# Generated at 2022-06-24 23:21:59.565670
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    x = CLIMgr()
    assert x.is_available()
    return


# Generated at 2022-06-24 23:22:07.850151
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    # Default values for parameters `package` and `installed_packages`
    param_installed_packages = {'python2-setuptools': [{'name': 'python2-setuptools', 'version': '8.2', 'source': 'yum'}, {'name': 'python2-setuptools', 'version': '9.4', 'source': 'yum'}]}
    param_package = {'name': 'python2-setuptools', 'version': '8.2', 'source': 'yum'}

    cls_PkgMgr = PkgMgr()

# Generated at 2022-06-24 23:22:09.441753
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    obj = LibMgr()
    assert obj.is_available() == NotImplementedError


# Generated at 2022-06-24 23:22:12.240110
# Unit test for constructor of class LibMgr
def test_LibMgr():
    pass


# Generated at 2022-06-24 23:22:17.253106
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    # create an instance of PkgMgr
    var_0 = PkgMgr()
    # test method
    var_0.is_available()


# Generated at 2022-06-24 23:22:18.841952
# Unit test for constructor of class LibMgr
def test_LibMgr():
    obj = LibMgr()
    assert isinstance(obj, LibMgr)


# Generated at 2022-06-24 23:22:23.463006
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():

    # Case 1: Pass an invalid path to getbinpath
    obj = CLIMgr()
    obj.CLI = 'dummy'

    result = obj.is_available()
    print(result)


# Generated at 2022-06-24 23:22:24.793125
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    # TODO: Perhaps this should error out
    var_0 = PkgMgr()


# Generated at 2022-06-24 23:22:25.762288
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    var_0 = LibMgr()


# Generated at 2022-06-24 23:22:29.265040
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    instance_0 = CLIMgr()
    assert isinstance(instance_0, CLIMgr)


# Generated at 2022-06-24 23:22:39.390180
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():

    class AptMgr(LibMgr):
        LIB = 'apt'

    apt_mgr = AptMgr()
    assert apt_mgr.is_available() == True


# Generated at 2022-06-24 23:22:40.979776
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    # TODO: Implement the test for this method
    raise NotImplementedError('This method has not been implemented')


# Generated at 2022-06-24 23:22:43.403759
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    # Instantiating LibMgr
    obj = LibMgr()
    # Calling is_available method
    status = obj.is_available()
    # Add your own assertions


# Generated at 2022-06-24 23:22:45.184027
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    test_obj = CLIMgr()
    test_obj.CLI = 'apt-get'
    assert test_obj.CLI == 'apt-get'
    assert test_obj.is_available() == True


# Generated at 2022-06-24 23:22:47.904676
# Unit test for constructor of class LibMgr
def test_LibMgr():
    lib_mgr = LibMgr() # Initialize object
    test_pass = 1
    if lib_mgr.is_available():
        test_pass = 0
    # End of test
    return test_pass


# Generated at 2022-06-24 23:22:52.759284
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    new_LibMgr = LibMgr()
    assert new_LibMgr.is_available() == True


# Generated at 2022-06-24 23:22:59.137238
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    import sys
    import types
    import inspect

    # TODO: test required classes, i.e. PkgMgr()

    # Check PkgMgr() is an instance of the PkgMgr class
    assert isinstance(PkgMgr(), PkgMgr)

    # TODO: test get_all_pkg_managers()

    # Check if get_all_pkg_managers() is a type of function
    assert isinstance(get_all_pkg_managers, types.FunctionType)

    # TODO: test get_all_subclasses()

    # Check if get_all_subclasses() is a type of function
    assert isinstance(get_all_subclasses, types.FunctionType)

    # Check if get_all_subclasses() is a type of function

# Generated at 2022-06-24 23:23:04.160499
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    obj = CLIMgr()
    print("ansible_pkg_mgr.py::CLIMgr object created")
    assert(obj.CLI == None)
    print("ansible_pkg_mgr.py::CLIMgr.CLI attribute set")
    assert(obj._cli == None)
    print("ansible_pkg_mgr.py::CLIMgr._cli attribute set")
    

# Generated at 2022-06-24 23:23:07.853904
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    cli_mgr = CLIMgr()
    assert cli_mgr.is_available() == False

if __name__ == "__main__":

    test_case_0()
    test_CLIMgr_is_available()

# Generated at 2022-06-24 23:23:08.620247
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    LibMgr().is_available()


# Generated at 2022-06-24 23:23:24.126286
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    pass


# Generated at 2022-06-24 23:23:25.640707
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    var_0 = get_all_pkg_managers()["dnf"].is_available()


# Generated at 2022-06-24 23:23:31.727033
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    var_0 = get_all_pkg_managers()
    for var_1 in var_0:
        var_2 = var_0.get(var_1)
        var_3 = var_2.list_installed()


# Generated at 2022-06-24 23:23:38.144843
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    var_0 = var_0
    var_1 = var_0.PkgMgr
    var_2 = getattr(var_1, 'get_package_details')
    var_3 = instancemethod
    if isinstance(var_2, instancemethod):
        var_2 = var_2.__func__
        pass
    var_4 = dir(var_2).count('get_package_details')
    var_5 = getattr(var_2, '__code__')
    var_6 = var_5.co_argcount
    var_7 = getattr(var_2, '__code__')
    var_8 = var_7.co_argcount
    var_9 = var_8 > 0
    var_10 = var_9 and var_6
    assert var_10


# Generated at 2022-06-24 23:23:40.364741
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    def test_case_0():
        var_0 = CLIMgr()
        var_1 = var_0.is_available()

test_CLIMgr_is_available()
print('end')

# Generated at 2022-06-24 23:23:42.418594
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    # <create object>
    obj = LibMgr()
    # <method is_available>
    obj.is_available()


# Generated at 2022-06-24 23:23:45.917347
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    # Create a new object of PkgMgr and assign the method to variable var_0
    var_0 = PkgMgr.get_packages
    # Assert that the variable contains an object
    assert isinstance(var_0, object)
    # Assert that var_0 is an instance of PkgMgr, using isinstance type checker
    assert isinstance(var_0, PkgMgr)

# Generated at 2022-06-24 23:23:52.669270
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    var_1 = PkgMgr()
    try:
        with pytest.raises(NotImplementedError) as var_2:
            PkgMgr.is_available(var_1)
        assert var_2.value.args[0] == 'abstractmethod is_available must be implemented by subclass'
    except Exception as e:
        pytest.fail('Exception raised when calling abstractmethod is_available: ' + str(e))


# Generated at 2022-06-24 23:23:54.845858
# Unit test for constructor of class LibMgr
def test_LibMgr():
    # Verify exception is thrown for abstract class
    try:
        var_1 = LibMgr()
    except TypeError:
        assert True
    else:
        assert False


# Generated at 2022-06-24 23:23:55.674599
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    assert var_0


# Generated at 2022-06-24 23:24:28.236571
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    # create dummy object of LibMgr
    obj_0 = LibMgr()
    try:
        # call is_available method
        var_0 = obj_0.is_available()
    except:
        raise Exception('test_LibMgr_is_available() exception raised')



# Generated at 2022-06-24 23:24:33.004391
# Unit test for constructor of class LibMgr
def test_LibMgr():
    try:
        libmgr = LibMgr()
    except Exception:
        print("Failed to create instance of class LibMgr")
        assert False


# Generated at 2022-06-24 23:24:33.692207
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    instance = CLIMgr()


# Generated at 2022-06-24 23:24:35.228664
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    test_CLIMgr = CLIMgr()
    assert type(test_CLIMgr) == CLIMgr


# Generated at 2022-06-24 23:24:36.815840
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    test_case = LibMgr()
    if test_case.is_available == True :
        return True
    else:
        return False


# Generated at 2022-06-24 23:24:41.749258
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    assert get_all_pkg_managers()



# Generated at 2022-06-24 23:24:44.392275
# Unit test for constructor of class LibMgr
def test_LibMgr():
    x = LibMgr()
    assert x is not None, 'Failed to create LibMgr'


# Generated at 2022-06-24 23:24:45.904472
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():

    pass


# Generated at 2022-06-24 23:24:51.902046
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    var_1 = CLIMgr()
    assert var_1._cli is None


# Generated at 2022-06-24 23:24:54.025976
# Unit test for constructor of class LibMgr
def test_LibMgr():
    LibMgr.is_available(var_0)


# Generated at 2022-06-24 23:26:11.077522
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    pass

# Generated at 2022-06-24 23:26:13.815113
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    var_0 = PkgMgr()
    ret = var_0.is_available()
    assert ret is None, "Expected return value to be None"


# Generated at 2022-06-24 23:26:15.001787
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    var_0 = PkgMgr()
    var_1 = var_0.is_available()


# Generated at 2022-06-24 23:26:16.724428
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    manager_1 = CLIMgr()
    var_1 = manager_1.is_available()


# Generated at 2022-06-24 23:26:20.586699
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    PkgMgr = get_all_pkg_managers()["homebrew"]()
    result = PkgMgr.get_packages()


# Generated at 2022-06-24 23:26:26.672710
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    obj = CLIMgr()
    # Verify the is_available fucntion returns true if the self._cli is set correctly

    # Test with self._cli = 'some_path' and assert that the returned value is True
    obj._cli = 'some_path'
    assert obj.is_available()
    # Test with self._cli = None and assert that the returned value is False
    obj._cli = None
    assert obj.is_available() is False


# Generated at 2022-06-24 23:26:27.419966
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    # TODO : stub
    assert 0

# Generated at 2022-06-24 23:26:29.354980
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    test_pkg_mgr = PkgMgr()
    if not test_pkg_mgr.get_packages():
        return 0
    else:
        return 1


# Generated at 2022-06-24 23:26:30.722943
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    try:
        result = CLIMgr.is_available()
    except:
        pass


# Generated at 2022-06-24 23:26:31.472600
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    var_0 = CLIMgr()


# Generated at 2022-06-24 23:29:43.196472
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    b_0 = CLIMgr()
    b_0.is_available()


# Generated at 2022-06-24 23:29:46.132753
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    var_0 = CLIMgr()
    var_0.CLI = 'var_1'
    var_1 = CLIMgr()
    var_2 = CLIMgr()
    var_3 = CLIMgr()


# Generated at 2022-06-24 23:29:49.583025
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    # Instantiating the class
    PkgMgr_obj = PkgMgr()
    PkgMgr_obj.get_packages()


# Generated at 2022-06-24 23:29:52.913361
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    tmp_LibMgr = LibMgr()
    result = tmp_LibMgr.is_available()


# Generated at 2022-06-24 23:29:54.098228
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    bMgr = LibMgr()
    if bMgr.is_available():
        print("LibMgr is available")


# Generated at 2022-06-24 23:29:55.835790
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    var_1 = PkgMgr()
    try:
        var_1.is_available()
    except Exception as e:
        print(e)


# Generated at 2022-06-24 23:30:03.600112
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    # Try creating object using constructor of the class
    try:
        object = CLIMgr()
    except Exception as e:
        print("Could not create object using constructor of the class CLIMgr")
        raise e
    else:
        print("Successfully created object using constructor of the class CLIMgr")
        print("Following is the object that was created")
        print("\n")
        print(object)
        print("\n")


# Generated at 2022-06-24 23:30:06.683804
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    var_1 = PkgMgr()
    assert var_1.get_package_details(var_0) == {}

# Generated at 2022-06-24 23:30:11.494977
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    # Creating a class object
    var_0 = PkgMgr()
    # Calling the is_available method
    var_1 = var_0.is_available()
    # Evaluating and returning the result
    if var_1:
        return 0
    return 1


# Generated at 2022-06-24 23:30:12.657864
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    var_0 = LibMgr()
    var_0.is_available()
