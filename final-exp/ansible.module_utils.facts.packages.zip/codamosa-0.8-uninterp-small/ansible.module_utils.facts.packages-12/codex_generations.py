

# Generated at 2022-06-24 23:21:36.024026
# Unit test for constructor of class LibMgr
def test_LibMgr():
    lib_mgr_0 = LibMgr()


# Generated at 2022-06-24 23:21:37.439854
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    cli_mgr_0 = CLIMgr()


# Generated at 2022-06-24 23:21:39.287979
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    pkg_mgr_1 = CLIMgr()
    assert pkg_mgr_1.is_available() is False


# Generated at 2022-06-24 23:21:41.440098
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    dict_pkgs = PkgMgr().get_package_details('package')
    print('package information is: ', dict_pkgs)


# Generated at 2022-06-24 23:21:43.137274
# Unit test for constructor of class LibMgr
def test_LibMgr():
    pkg_mgr_lib = LibMgr()


# Generated at 2022-06-24 23:21:47.914270
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    for pkg_mgr in get_all_pkg_managers().values():
        if pkg_mgr().is_available():
            installed_packages = pkg_mgr().list_installed()

            assert isinstance(installed_packages, list)
            assert len(installed_packages) >= 0
            assert len(pkg_mgr().list_installed()) > 0

            for item in installed_packages:
                assert isinstance(item, str)

            break


# Generated at 2022-06-24 23:21:48.813583
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    cli_mgr = CLIMgr()


# Generated at 2022-06-24 23:21:51.370344
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    PkgMgr_obj = PkgMgr()
    PkgMgr_obj.get_package_details("package")


# Generated at 2022-06-24 23:21:52.141363
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    pkg_mgr_1 = LibMgr()


# Generated at 2022-06-24 23:21:54.053666
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    try:
        test_case_0()
    except TypeError:
        raise AssertionError("This class can not be instantiated")

# Generated at 2022-06-24 23:22:06.638970
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    pytest_module_names = ['test_pip', 'test_rpm']
    package_name_containing_pytest = 'pytest'
    pytest_package_name = 'test_package'
    package_without_pytest = 'test_package2'
    test_package_name = "test_package"
    test_package_version = "0.0.1.0"
    expected_installed_packages = {test_package_name: [{'name': test_package_name, 'source': 'pkgmgr', 'version': test_package_version, 'id': test_package_name}]}

    for pytest_module_name in pytest_module_names:
        test_package_mgr = PkgMgr()

# Generated at 2022-06-24 23:22:08.970319
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    pkg_mgr_0 = CLIMgr()



# Generated at 2022-06-24 23:22:12.722986
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    cls = LibMgr()
    assert cls.is_available() == False


# Generated at 2022-06-24 23:22:15.487548
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    pkg_mgr_0 = CLIMgr()
    pkg_mgr_1 = CLIMgr()
    assert pkg_mgr_0 == pkg_mgr_1


# Generated at 2022-06-24 23:22:17.938568
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pkg_mgr_0 = PkgMgr()
    with pytest.raises(TypeError):
        pkg_mgr_0.is_available()


# Generated at 2022-06-24 23:22:23.701325
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    pkg_mgr = PkgMgr()
    installed_packages = pkg_mgr.get_packages()
    assert len(installed_packages) == 0
    assert isinstance(installed_packages, dict)


# Generated at 2022-06-24 23:22:24.595153
# Unit test for constructor of class LibMgr
def test_LibMgr():

    class TempLibMgr(LibMgr):
        pass

    obj = TempLibMgr()


# Generated at 2022-06-24 23:22:28.656407
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pkg_mgr_0 = PkgMgr()
    assert (pkg_mgr_0.is_available() == NotImplemented)


# Generated at 2022-06-24 23:22:31.752155
# Unit test for constructor of class LibMgr
def test_LibMgr():
    lib_mgr_0 = LibMgr()


# Generated at 2022-06-24 23:22:33.745653
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    assert False


# Generated at 2022-06-24 23:22:37.615322
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    pass

# Generated at 2022-06-24 23:22:39.569336
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pkg_mgr = PkgMgr()
    assert pkg_mgr.list_installed() == NotImplemented


# Generated at 2022-06-24 23:22:43.192940
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    # Init an instance of class LibMgr with the mock object
    libMgr_obj = LibMgr()
    # set the values of the call to the mock object
    libMgr_obj._lib = 'Lib'
    assert libMgr_obj.is_available() == True


# Generated at 2022-06-24 23:22:44.050088
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    var_1 = CLIMgr()


# Generated at 2022-06-24 23:22:50.999031
# Unit test for function get_all_pkg_managers

# Generated at 2022-06-24 23:22:53.634018
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    var_0 = get_all_pkg_managers()
    var_0 = var_0[Object1]
    var_0 = var_0()
    var_0 = var_0.get_package_details("foo")


# Generated at 2022-06-24 23:23:02.241387
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return [1,2,3]
        def get_package_details(self, package):
            return {'name': "test", 'version': package}

    pkgmgr = TestPkgMgr()

    actual = pkgmgr.get_packages()

    expected = {'test': [{'name': 'test', 'version': 1, 'source': 'testpkgmgr'},
                         {'name': 'test', 'version': 2, 'source': 'testpkgmgr'},
                         {'name': 'test', 'version': 3, 'source': 'testpkgmgr'}]}

# Generated at 2022-06-24 23:23:08.946406
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    with open('test.yml', 'w') as outfile:
        myclass = CLIMgr()
        outfile.write(myclass.__class__.__name__ + '\n')
        outfile.write('CLIMgr\n')
        outfile.write(str(myclass.__dict__) + '\n')
        outfile.write(str(myclass) + '\n')



# Generated at 2022-06-24 23:23:15.329409
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    libmgr = LibMgr()
    result = libmgr.is_available()
    assert result == None


# Generated at 2022-06-24 23:23:17.518585
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    test_LibMgr = LibMgr()
    assert test_LibMgr._lib == None
    test_case_1()
    assert test_LibMgr._lib != None


# Generated at 2022-06-24 23:23:25.118458
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pass


# Generated at 2022-06-24 23:23:30.491999
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    var_1 = CLIMgr()


# Generated at 2022-06-24 23:23:31.795385
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    var_0 = LibMgr()
    var_0.is_available()


# Generated at 2022-06-24 23:23:38.190513
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    var_9 = None
    var_10 = None
    var_11 = None
    var_12 = None
    var_13 = None
    var_14 = None
    var_15 = None
    var_16 = None
    var_17 = None
    var_18 = None
    var_19 = None
    var_20 = None
    var_21 = None
    var_22 = None
    var_23 = None
    var_24 = None
    var_25 = None
    var_26 = None
    var_27 = None
    var_

# Generated at 2022-06-24 23:23:40.648637
# Unit test for constructor of class LibMgr
def test_LibMgr():
    try:
        cls = LibMgr
        cls_instance = cls()
        cls_object = cls.__new__(LibMgr())
    except Exception as e:
        print("Exception occurred: ", e)


# Generated at 2022-06-24 23:23:41.527418
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    pass


# Generated at 2022-06-24 23:23:42.848353
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    cliMgr = CLIMgr()
    cliMgr_0 = cliMgr



# Generated at 2022-06-24 23:23:43.599054
# Unit test for constructor of class CLIMgr
def test_CLIMgr():

    var_3 = CLIMgr()


# Generated at 2022-06-24 23:23:44.356272
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    var_0 = get_all_pkg_managers()

# Generated at 2022-06-24 23:23:48.061210
# Unit test for constructor of class LibMgr
def test_LibMgr():
    test_obj = LibMgr()
    var_1 = test_obj._lib
    assert None == var_1


# Generated at 2022-06-24 23:24:06.336717
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    var_0 = CLIMgr()
    # Assign

    # Act
    var_1 = var_0.is_available()

    # Assert
    var_0_expected = None # Type: Any
    var_1_expected = None # Type: Any
    assert var_0_expected == var_1_expected


# Generated at 2022-06-24 23:24:08.596751
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    var_CLI = "CLI"
    var_ret = CLIMgr()
    assert var_ret._cli == None
    assert var_ret.CLI == var_CLI
    assert var_ret.LIST_INSTALLED == None


# Generated at 2022-06-24 23:24:12.310816
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pkg_mgr = PkgMgr()
    assert isinstance(pkg_mgr.is_available(), bool)
    # assert 'foo'.upper() == 'FOO'


# Generated at 2022-06-24 23:24:15.692120
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    # Create a list of arguments including the class name
    args = [LibMgr]
    # Make an instance of LibMgr class
    obj = LibMgr(*args)
    # Unit test for method is_available of class LibMgr
    result = obj.is_available()


# Generated at 2022-06-24 23:24:22.272773
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    from ansible.module_utils.common._utils import get_all_subclasses

    for obj in get_all_subclasses(PkgMgr):
        #print(obj.__name__)
        o = obj()
        if o.is_available():
            print(obj.__name__, o.get_packages())


# Generated at 2022-06-24 23:24:22.998958
# Unit test for constructor of class LibMgr
def test_LibMgr():
    assert LibMgr() is not None


# Generated at 2022-06-24 23:24:33.351011
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    # Setup
    var_0 = type('', (), {})()
    var_0.CLI = 'dnf'
    L2 = CLIMgr()
    L3 = CLIMgr()
    L4 = CLIMgr()
    L4.CLI = 'dnf'
    L4.is_available = test_CLIMgr_is_available_L4_0
    L5 = CLIMgr()
    L5.CLI = 'dnf'
    L5.is_available = test_CLIMgr_is_available_L5_0
    L6 = CLIMgr()
    L6.CLI = 'dnf'
    L6.is_available = test_CLIMgr_is_available_L6_0

    # Test

# Generated at 2022-06-24 23:24:35.592767
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    var_2 = CLIMgr()
    var_3 = var_2.is_available()

# Generated at 2022-06-24 23:24:36.728460
# Unit test for constructor of class LibMgr
def test_LibMgr():
    obj = LibMgr()
    assert __name__ == '__main__'


# Generated at 2022-06-24 23:24:41.983429
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    try:
        var_1 = PkgMgr()
        var_1.list_installed()
    except:
        raise Exception("Method list_installed is not implemented in class PkgMgr")


# Generated at 2022-06-24 23:25:10.466126
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    var_0 = CLIMgr()


# Generated at 2022-06-24 23:25:13.469870
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():

    # Constructor test
    pkg_mgr = PkgMgr()

    # Method correct output
    # Test case 0
    package = {}
    details = pkg_mgr.get_package_details(package)


# Generated at 2022-06-24 23:25:14.633560
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    # init test class
    # test method
    # assert return value
    assert 0


# Generated at 2022-06-24 23:25:15.715574
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    test = CLIMgr()
    test.is_available()


# Generated at 2022-06-24 23:25:20.539639
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    pkg_mgr = PkgMgr()
    assert pkg_mgr is not None

if __name__ == '__main__':
    test_PkgMgr_get_packages()

# Generated at 2022-06-24 23:25:22.980074
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    pkgmgr_inst_0 = PkgMgr()
    arg_0 = 'aaaa'
    out_0 = pkgmgr_inst_0.get_package_details(arg_0)
    return out_0


# Generated at 2022-06-24 23:25:26.035498
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    cli_mgr = CLIMgr()
    assert cli_mgr == cli_mgr

# Generated at 2022-06-24 23:25:26.939333
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    var_0 = CLIMgr()


# Generated at 2022-06-24 23:25:30.490980
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():

    var_0 = LibMgr()
    assert var_0.is_available()


# Generated at 2022-06-24 23:25:31.441328
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    assert True


# Generated at 2022-06-24 23:26:49.476512
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    var_1 = get_all_pkg_managers()
    var_2 = var_1['apt']()
    var_2.list_installed = lambda: ["a=b", "c=b"]
    var_2.get_package_details = lambda: {"name": "a", "version": "b"}
    var_3 = var_2.get_packages()

# Generated at 2022-06-24 23:26:52.981412
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    var_0 = PkgMgr()
    print(var_0.get_packages())

# Generated at 2022-06-24 23:26:57.193046
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    # Instantiate class
    var_1 = PkgMgr()
    # var_1 is an instance of the PkgMgr class.
    # Call method get_packages of var_1
    var_1.get_packages()


# Generated at 2022-06-24 23:26:58.754710
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    pm = CLIMgr()
    assert pm.is_available() == True, "CLIMgr.is_available() expected: %s, got %s" % ('True', pm.is_available())


# Generated at 2022-06-24 23:27:00.169737
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    var_a = LibMgr()
    var_b = var_a.is_available()


# Generated at 2022-06-24 23:27:02.788196
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    var_0 = CLIMgr
    # TBD: write test


# Generated at 2022-06-24 23:27:03.892825
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    #test_CLIMgr
    var_1 = CLIMgr()


# Generated at 2022-06-24 23:27:08.029381
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    var_1 = PkgMgr()
    var_2 = var_1.list_installed()


# Generated at 2022-06-24 23:27:10.134893
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    temp_0 = get_all_pkg_managers()
    temp_1 = temp_0['yumpkgmgr']
    temp_2 = temp_1()
    temp_3 = temp_2.is_available()

# Generated at 2022-06-24 23:27:15.365136
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    var_1 = dict([(obj.__name__.lower(), obj) for obj in get_all_subclasses(PkgMgr)])
    var_2 = PkgMgr()
    var_3 = var_2.get_packages()


# Generated at 2022-06-24 23:30:11.069346
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():

    # Positive test
    var_0 = CLIMgr()

    # Negative test
    # var_0 = CLIMgr()



# Generated at 2022-06-24 23:30:11.967811
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    assert CLIMgr().is_available() == None



# Generated at 2022-06-24 23:30:14.154606
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    mock_args = {}
    mock_args['self'] = CLIMgr()
    test = mock_args['self'].is_available()


# Generated at 2022-06-24 23:30:18.422368
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    print("test_PkgMgr_is_available begins")
    try:
        a = PkgMgr()
    except Exception as e:
        return
    assert False, "Exception should be thrown"
    print("test_PkgMgr_is_available ends")


# Generated at 2022-06-24 23:30:19.858512
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    var_0 = CLIMgr()
    var_1 = var_0.is_available()


# Generated at 2022-06-24 23:30:24.536001
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    test_obj = get_all_pkg_managers()['pkgmgr_apt']
    param_1 = dict(version="1.1.0", source="apt", name='package_manager')
    test_obj.get_package_details(param_1)

# Generated at 2022-06-24 23:30:25.663180
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    var_0 = LibMgr()
    var_1 = var_0.is_available()


# Generated at 2022-06-24 23:30:26.291189
# Unit test for constructor of class LibMgr
def test_LibMgr():
    libMgr = LibMgr()


# Generated at 2022-06-24 23:30:28.235852
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    obj = PkgMgr()
    assert obj.list_installed() == None


# Generated at 2022-06-24 23:30:28.905512
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pass # Stub
