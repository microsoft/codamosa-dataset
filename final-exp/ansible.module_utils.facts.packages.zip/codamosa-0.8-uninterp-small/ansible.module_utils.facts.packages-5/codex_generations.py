

# Generated at 2022-06-24 23:21:36.357316
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    cli_mgr = CLIMgr()
    assert(cli_mgr)


# Generated at 2022-06-24 23:21:38.029129
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    lib_mgr_0 = LibMgr()
    lib_mgr_0.get_packages()

# Generated at 2022-06-24 23:21:41.105322
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    # Test 0
    lib_mgr_0 = LibMgr()
    # is_available missing from LibMgr

    # Test 1
    lib_mgr_1 = LibMgr()
    # is_available missing from LibMgr



# Generated at 2022-06-24 23:21:44.547465
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    # Create new CLIMgr
    test_lib = CLIMgr()
    assert test_lib.is_available() == False
    # Call method is_available
    assert test_lib.is_available() == False


# Generated at 2022-06-24 23:21:45.746028
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    cli_mgr = CLIMgr()


# Generated at 2022-06-24 23:21:52.664603
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    lib_mgr_0 = LibMgr()
    # Unit test for method is_available
    # Ensure that exception ImportError is thrown in case of missing module
    try:
        lib_mgr_0.is_available()
    except ImportError:
        pass


# Generated at 2022-06-24 23:21:54.557114
# Unit test for constructor of class LibMgr
def test_LibMgr():
    lib_mgr_0 = LibMgr()
    assert not lib_mgr_0.is_available()


# Generated at 2022-06-24 23:22:05.819699
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    assert 'pip' in get_all_pkg_managers()
    pkg_mgr = get_all_pkg_managers()['pip']()
    assert pkg_mgr.is_available() == True
    installed_packages = pkg_mgr.get_packages()
    assert 'jinja2' in installed_packages
    assert 'jinja2' in installed_packages['jinja2'][0]['name']
    assert installed_packages['jinja2'][0]['version'] not in ['',None]
    assert installed_packages['jinja2'][0]['source'] == 'pip'

if __name__ == '__main__':
    print('Adding tests for get_packages of class PkgMgr')

# Generated at 2022-06-24 23:22:07.175624
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    lib_mgr = LibMgr()
    assert lib_mgr.is_available() == False



# Generated at 2022-06-24 23:22:08.844597
# Unit test for constructor of class LibMgr
def test_LibMgr():
    lib_mgr = LibMgr()
    assert lib_mgr == lib_mgr
    assert lib_mgr != None


# Generated at 2022-06-24 23:22:17.415631
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    lib_mgr = LibMgr()
    assert lib_mgr.list_installed() == None, "'list_installed' method of 'LibMgr' class needs to be implemented."


# Generated at 2022-06-24 23:22:18.642706
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    cli_mgr_0 = CLIMgr()



# Generated at 2022-06-24 23:22:23.474560
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    lib_mgr_0 = LibMgr()
    lib_mgr_0_result = lib_mgr_0.get_packages()
    assert not lib_mgr_0_result


# Generated at 2022-06-24 23:22:29.920956
# Unit test for method get_packages of class PkgMgr

# Generated at 2022-06-24 23:22:34.439112
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    lib_mgr_0 = LibMgr()
    assert lib_mgr_0.is_available() == False



# Generated at 2022-06-24 23:22:36.564893
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    lib_mgr_0 = LibMgr()
    assert lib_mgr_0.is_available() == False


# Generated at 2022-06-24 23:22:45.599549
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    lib_mgr_0 = CLIMgr()
    lib_mgr_0.__class__.CLI = 'test'
    try:
        result = lib_mgr_0.is_available()
    except ValueError:
        print("Caught an unexpected exception")
    else:
        assert isinstance(result, bool)
    try:
        result = lib_mgr_0.is_available()
    except ValueError:
        print("Caught an unexpected exception")
    else:
        assert result == False
    try:
        lib_mgr_0.__class__.CLI = 'which'
        result = lib_mgr_0.is_available()
    except ValueError:
        print("Caught an unexpected exception")
    else:
        assert result == True


# Generated at 2022-06-24 23:22:50.908351
# Unit test for constructor of class LibMgr
def test_LibMgr():
    lib_mgr_0 = LibMgr()
    assert lib_mgr_0._lib is None

if __name__ == '__main__':
    test_case_0()
    test_LibMgr()

# Generated at 2022-06-24 23:22:51.837575
# Unit test for constructor of class LibMgr
def test_LibMgr():
    lib_mgr_0 = LibMgr()


# Generated at 2022-06-24 23:22:53.240916
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    lib_mgr_0 = LibMgr()
    ret_val = lib_mgr_0.is_available()
    assert isinstance(ret_val, bool)


# Generated at 2022-06-24 23:23:08.620983
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    # Test case 0
    lib_mgr_0 = LibMgr()
    lib_mgr_0.LIB = 'unavailable'
    lib_mgr_0.is_available = MagicMock(return_value=False)
    lib_mgr_0.list_installed = MagicMock()
    lib_mgr_0.get_package_details = MagicMock()
    packages = lib_mgr_0.get_packages()



# Generated at 2022-06-24 23:23:18.753593
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    import sys
    import os
    import tempfile
    import shutil
    import mock
    # Create a fake python library to import
    PYLIB = tempfile.gettempdir() + os.sep + 'ansible_collections'
    os.mkdir(PYLIB)
    os.mkdir(PYLIB + os.sep + 'pylib_test')
    file = open(PYLIB + os.sep + '__init__.py', 'w')
    file.write('__import__("pkg_resources").declare_namespace(__name__)\n')
    file.close()
    file = open(PYLIB + os.sep + 'pylib_test' + os.sep + '__init__.py', 'w')

# Generated at 2022-06-24 23:23:20.788108
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    assert True
    return True


# Generated at 2022-06-24 23:23:28.893769
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    # create object LibMgr() without __init__()
    lib_mgr_obj = LibMgr.__new__(LibMgr)
    lib_mgr_obj.__init__()
    # set values of attributes
    lib_mgr_obj.LIB = 'json'
    # call test function
    assert(lib_mgr_obj.is_available) == True
    # create object LibMgr() without __init__()
    lib_mgr_obj = LibMgr.__new__(LibMgr)
    lib_mgr_obj.__init__()
    # set values of attributes
    lib_mgr_obj.LIB = 'jsoneeee'
    # call test function
    assert(lib_mgr_obj.is_available) == False



# Generated at 2022-06-24 23:23:30.464727
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    lib_mgr_1 = LibMgr()
    lib_mgr_1.list_installed()


# Generated at 2022-06-24 23:23:32.075067
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    pkg_mgr = CLIMgr()
    assert pkg_mgr.is_available() == False



# Generated at 2022-06-24 23:23:33.662330
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    pkg_mgr = PkgMgr()
    assert pkg_mgr.get_packages() is None


# Generated at 2022-06-24 23:23:37.892065
# Unit test for constructor of class LibMgr
def test_LibMgr():
    lib_mgr_0 = LibMgr()
    assert type(lib_mgr_0) == LibMgr
    assert not hasattr(lib_mgr_0, 'is_available')


# Generated at 2022-06-24 23:23:39.654523
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    mgr_0 = PkgMgr()
    mgr_0.get_package_details('test')


# Generated at 2022-06-24 23:23:44.802837
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    pkg_mgr = PkgMgr()
    try:
        pkg_mgr.get_package_details(package='')
    except Exception as e:
        if "abstract" in e.message:
            print (' (failed) ')
        else:
            raise
    else:
        raise Exception('Error: method get_package_details of class PkgMgr did not raise exception when subclassed')


# Generated at 2022-06-24 23:23:54.730067
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    k = get_all_pkg_managers()
    for i in sorted(k.keys()):
        print("===",i)
        print(k[i].get_packages())


# Generated at 2022-06-24 23:23:55.561321
# Unit test for constructor of class LibMgr
def test_LibMgr():
    test_case_0()


# Generated at 2022-06-24 23:23:59.242352
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    PkgMgr_0 = PkgMgr()
    assert PkgMgr_0.is_available() == False


# Generated at 2022-06-24 23:24:01.359420
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():

    lib_mgr_0 = LibMgr()
    print(lib_mgr_0.is_available())


# Generated at 2022-06-24 23:24:04.706242
# Unit test for constructor of class LibMgr
def test_LibMgr():
    assert getattr(test_case_0, '_lib') is None


# Generated at 2022-06-24 23:24:06.759554
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    lib_mgr_0 = LibMgr()
    lib_mgr_0.list_installed()
    try:
        assert True
    except AssertionError:
        assert False, 'AssertionError raised, list_installed() does not return a list'

# Generated at 2022-06-24 23:24:09.097657
# Unit test for constructor of class LibMgr
def test_LibMgr():
    lib_mgr_0 = LibMgr()
    assert isinstance(lib_mgr_0, LibMgr)



# Generated at 2022-06-24 23:24:14.080427
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    mgr = PkgMgr()
    packages = mgr.get_packages()
    assert packages == {}

# Generated at 2022-06-24 23:24:16.381877
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    assert(CLIMgr()).is_available() == True


# Generated at 2022-06-24 23:24:22.570309
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    if 1002 in test_CLIMgr_is_available.__dict__:
        test_CLIMgr_is_available.__dict__[1002](test_case_0)
    if 1003 in test_CLIMgr_is_available.__dict__:
        test_CLIMgr_is_available.__dict__[1003](test_case_0)



# Generated at 2022-06-24 23:24:36.070006
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    from ansible.module_utils.common._collections_compat import Mapping

    obj = PkgMgr()

    package = "dummy"
    retval = obj.get_package_details(package)
    assert isinstance(retval, Mapping)
    assert retval.get('name') is not None, \
        "PkgMgr.get_package_details() returned not dict"
    assert retval.get('version') is not None, \
        "PkgMgr.get_package_details() returned not dict"



# Generated at 2022-06-24 23:24:40.878762
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pass



# Generated at 2022-06-24 23:24:43.702045
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    try:
        lib_mgr_0 = LibMgr()
    except:
        return False
    return True


# Generated at 2022-06-24 23:24:49.692034
# Unit test for method is_available of class LibMgr

# Generated at 2022-06-24 23:24:51.235003
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    lib_mgr_0 = LibMgr()
    assert lib_mgr_0.is_available() == 0 == lib_mgr_0.is_available()

# Generated at 2022-06-24 23:24:55.008044
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    test_instance = PkgMgr()
    test_input = "testinput"
    test_output = test_instance.get_package_details(test_input)
    assert test_output is None


# Generated at 2022-06-24 23:24:56.792560
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    lib_mgr_0 = LibMgr()
    assert lib_mgr_0.is_available() is False


# Generated at 2022-06-24 23:25:01.747261
# Unit test for constructor of class LibMgr
def test_LibMgr():
    lib_mgr_0 = LibMgr()
    assert not hasattr(lib_mgr_0, '_lib')


# Generated at 2022-06-24 23:25:02.886254
# Unit test for constructor of class LibMgr
def test_LibMgr():
    try:
        lib_mgr_0 = LibMgr()
        assert lib_mgr_0.LIB == None
    except BaseException as e:
        print(e)


# Generated at 2022-06-24 23:25:03.676777
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    lib_mgr = LibMgr()
    assert lib_mgr.is_available() == False


# Generated at 2022-06-24 23:25:23.038868
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.software_management import get_all_pkg_managers
    from ansible.module_utils.software_management.repos import RepoMgr
    from ansible.module_utils.software_management.gems import RubyGem, Gem
    from ansible.module_utils.software_management.pips import PIP
    from ansible.module_utils.software_management.pips import PIP2

    var_0 = get_all_pkg_managers()
    var_1 = var_0['climgr']
    var_2 = var_0['pacman']

    # Test case 1:
    print("\nTest case 1:")
   

# Generated at 2022-06-24 23:25:26.034490
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    assert get_bin_path("pip") == "/usr/bin/pip"

    return True


# Generated at 2022-06-24 23:25:31.630795
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    # Init
    var_0 = CLIMgr()
    # Execution
    var_0.is_available()
    # Validate
    if None is None:
        print("Test Case 0: [OK]")
    else:
        print("Test Case 0: [FAIL]")


# Generated at 2022-06-24 23:25:32.319049
# Unit test for constructor of class LibMgr
def test_LibMgr():
    LibMgr()


# Generated at 2022-06-24 23:25:34.018573
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    instance = LibMgr()
    instance.LIB = "abc"
    is_available = instance.is_available()
    assert is_available == False


# Generated at 2022-06-24 23:25:43.578905
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    assert PkgMgr.get_package_details(self) == 'PkgMgr'
    assert PkgMgr.get_package_details(self) == 'PkgMgr'
    assert PkgMgr.get_package_details(self) == 'PkgMgr'
    assert PkgMgr.get_package_details(self) == 'PkgMgr'
    assert PkgMgr.get_package_details(self) == 'PkgMgr'
    assert PkgMgr.get_package_details(self) == 'PkgMgr'
    assert PkgMgr.get_package_details(self) == 'PkgMgr'
    assert PkgMgr.get_package_details(self) == 'PkgMgr'
    assert PkgMgr.get_package_details(self)

# Generated at 2022-06-24 23:25:46.522894
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    pass


# Generated at 2022-06-24 23:25:47.554177
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    var_0 = PkgMgr()
    var_1 = var_0.list_installed()


# Generated at 2022-06-24 23:25:50.845367
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    mgr = CLIMgr()
    assert(mgr is not None)


# Generated at 2022-06-24 23:25:52.291898
# Unit test for constructor of class LibMgr
def test_LibMgr():
    test_LibMgr = LibMgr()
    assert test_LibMgr != None


# Generated at 2022-06-24 23:26:16.798750
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO
    import sys
    stdout_org = sys.stdout
    setattr(sys, 'stdout', StringIO())
    ansible_pkg_mgr = PkgMgr()
    ansible_pkg_mgr.get_packages()
    sys.stdout = stdout_org
    assert(False)


# Generated at 2022-06-24 23:26:20.974622
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    # Set up mock object for the class CLIMgr
    myCLIMgr = CLIMgr()
    if myCLIMgr:
        # Initialize the mock object by invoking the constructor
        pass


# Generated at 2022-06-24 23:26:25.934853
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    # Check for expected behavior of method get_packages
    var_1 = None
    var_2 = None
    var_3 = None
    obj_1 = PkgMgr()
    method_result = obj_1.get_packages('var_1', 'var_2', 'var_3')
    return method_result


# Generated at 2022-06-24 23:26:26.984585
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    assert False, "TODO: Implement testcase"


# Generated at 2022-06-24 23:26:32.002022
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    # instantiate
    # print(LibMgr.__subclasses__())
    # for module in LibMgr.__subclasses__():
    #     if module.LIB == 'apt':
    #         lib_obj = module()
    lib_obj = None
    for lib_obj in LibMgr.__subclasses__():
        if lib_obj.LIB == 'apt':
            break

    # call method
    res = lib_obj.is_available()

    # verify the result
    assert res == True


# Generated at 2022-06-24 23:26:33.781642
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    var_0 = LibMgr()
    var_0.LIB = 'md5'
    assert var_0.is_available() == True


# Generated at 2022-06-24 23:26:39.511161
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():

    # Remove the following and use assertEqual
    assert True == True, "Implement the test case to test list_installed of the class PkgMgr"
    

# Generated at 2022-06-24 23:26:42.848811
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    assert True


# Generated at 2022-06-24 23:26:44.188872
# Unit test for constructor of class LibMgr
def test_LibMgr():
    var_1 = LibMgr()


# Generated at 2022-06-24 23:26:49.033797
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    # Test class instantiation
    new_var = PkgMgr()
    new_var.get_package_details = lambda package: dict(name='package_name', version='package_version', source='source_pkg_mgr')
    new_var.list_installed = lambda: ['package_name']
    assert new_var.get_packages() == dict(package_name=[dict(name='package_name', version='package_version', source='source_pkg_mgr')])


# Generated at 2022-06-24 23:27:37.270867
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    var_1 = PkgMgr()
    try:
        var_1.is_available()
    except TypeError:
        pass


# Generated at 2022-06-24 23:27:38.620538
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    var_1 = PkgMgr()
    with pytest.raises(TypeError):
        var_1.list_installed()


# Generated at 2022-06-24 23:27:39.877163
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    mock_obj = PkgMgr()
    assert mock_obj.get_package_details(package='test') is not None


# Generated at 2022-06-24 23:27:41.132804
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():

    fake_LibMgr = LibMgr()
    var_0 = fake_LibMgr.is_available()


# Generated at 2022-06-24 23:27:45.542617
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    var_0 = CLIMgr()


# Generated at 2022-06-24 23:27:46.155508
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    test_case_0()

# Generated at 2022-06-24 23:27:46.979535
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    var = CLIMgr()
    var.is_available()


# Generated at 2022-06-24 23:27:48.139680
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    mgr = PkgMgr()
    packages = mgr.get_packages()
    if packages:
        print(packages)


# Generated at 2022-06-24 23:27:52.232290
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    var_pkg_mgr = PkgMgr()
    assert var_pkg_mgr.get_packages() is None

# Generated at 2022-06-24 23:27:56.202898
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    var_0 = LibMgr()
    var_1 = var_0.is_available()


# Generated at 2022-06-24 23:29:36.570535
# Unit test for constructor of class LibMgr
def test_LibMgr():
    obj = LibMgr()
    if obj.LIB is not None:
        test_case_0()


# Generated at 2022-06-24 23:29:37.098272
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    test_case_0()

# Generated at 2022-06-24 23:29:37.631963
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    var_2 = CLIMgr()


# Generated at 2022-06-24 23:29:38.235445
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pass


# Generated at 2022-06-24 23:29:42.571942
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    Test = LibMgr()
    Test.LIB = 'distro'
    Test.is_available()


# Generated at 2022-06-24 23:29:44.224428
# Unit test for constructor of class LibMgr
def test_LibMgr():
    var_LibMgr = LibMgr()
    assert(isinstance(var_LibMgr, LibMgr))


# Generated at 2022-06-24 23:29:48.188160
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    methods = get_all_pkg_managers()
    for method in methods:
        method = methods[method]()
        if method.is_available():
            method.get_packages()


# Generated at 2022-06-24 23:29:49.815018
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():

    #local variable to test method
    var_1 = ["abc"]

    #the class we are testing
    obj_1 = PkgMgr()
    assert obj_1.get_package_details(var_1) == None


# Generated at 2022-06-24 23:29:53.917512
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    # Test case 0
    # Test case 0
    # Test case 0
    var_0 = get_all_pkg_managers()
    for i in var_0:
        var_1 = var_0[i]()
        var_1.is_available()



# Generated at 2022-06-24 23:29:59.839407
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    # Local variable(s) to be used in the unit test
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    # Set the local variables according to their names.
    var_0 = get_all_pkg_managers()
    # The package name could be taken from the variable var_0.
    var_1 = 'pkgutil'
    # The package name could be taken from the variable var_0.
    var_2 = 'gem'
    # The package name could be taken from the variable var_0.
    var_3 = 'rpm'
    # The package name could be taken from the variable var_0.
    var_4 = 'deb'
    # The package name could be