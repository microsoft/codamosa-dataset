

# Generated at 2022-06-24 23:21:38.152221
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    import ansible.module_utils.common.packages.apk
    apk = ansible.module_utils.common.packages.apk.PkgMgr()
    apk.is_available()
    apk.list_installed()
    apk.get_package_details()


# Generated at 2022-06-24 23:21:40.087107
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    assert True
    # Do not use this term in the assert statement
    # var_1 = get_package_details()


# Generated at 2022-06-24 23:21:41.440161
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    p = PkgMgr()
    p.list_installed()


# Generated at 2022-06-24 23:21:44.888597
# Unit test for constructor of class LibMgr
def test_LibMgr():
    from ansible.module_utils.facts.system.pkg_mgr import LibMgr
    try:
        test_instance = LibMgr()
    except Exception as e:
        print(e)
    finally:
        pass


# Generated at 2022-06-24 23:21:47.451257
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class PkgMgr_sub(PkgMgr):
        pass
    PkgMgr_sub_obj = PkgMgr_sub()
    var_0 = PkgMgr_sub_obj.get_packages()


# Generated at 2022-06-24 23:21:50.601203
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    var_1 = PkgMgr()
    assert var_1._is_available() == NotImplementedError



# Generated at 2022-06-24 23:21:54.340320
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    try:
        # instantiate the  object
        obj = reader_0001()
    except Exception as e:
        pass
    else:
        # call the method
        var_0 = obj.is_available()


# Generated at 2022-06-24 23:21:55.401792
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    c = CLIMgr()
    c.is_available()


# Generated at 2022-06-24 23:21:59.481602
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    cli = CLIMgr()
    print(cli.__dict__)


# Generated at 2022-06-24 23:22:00.923003
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    try:
        CLIMgr()
        assert True
    except:
        assert False


# Generated at 2022-06-24 23:22:06.311409
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    pkgmgr_obj = PkgMgr()
    result = pkgmgr_obj.get_packages()
    assert result is None


# Generated at 2022-06-24 23:22:08.275236
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    var_0 = CLIMgr()



# Generated at 2022-06-24 23:22:12.723895
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    var_1 = get_bin_path('foo')
    var_2 = get_bin_path('foo')
    var_3 = get_bin_path('foo')

# Generated at 2022-06-24 23:22:13.634708
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    assert True is True


# Generated at 2022-06-24 23:22:14.714814
# Unit test for constructor of class LibMgr
def test_LibMgr():
    var_1 = LibMgr()


# Generated at 2022-06-24 23:22:15.568811
# Unit test for constructor of class LibMgr
def test_LibMgr():
    LibMgr()


# Generated at 2022-06-24 23:22:23.169349
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    from ansible.module_utils.basic import AnsibleFallbackNotFound
    from ansible.module_utils.six import PY2

    try:
        from ansible.module_utils.basic import AnsibleFallbackNotFound
        import ansible.module_utils.common._utils as utils

        if PY2:
            try:
                utils.LibMgr.is_available()
            except ImportError:
                assert True

            try:
                utils.LibMgr()
            except ImportError:
                assert False

        else:
            utils.LibMgr.is_available()
            utils.LibMgr()

    except ImportError:
        assert False


# Generated at 2022-06-24 23:22:25.874075
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    pass


# Generated at 2022-06-24 23:22:29.411754
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    try:
        CLIMgr()
    except NameError as e:
        assert False


# Generated at 2022-06-24 23:22:33.819024
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    libobj = LibMgr()
    libobj.is_available


# Generated at 2022-06-24 23:22:47.697526
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    var = PkgMgr()
    var._PkgMgr__init__()
    var.list_installed = lambda *args, **kwargs: ['test_package_installed']
    var.get_package_details = lambda *args, **kwargs: {'name': 'test_package_installed', 'version': '1'}
    assert var.get_packages() == {'test_package_installed': [{'name': 'test_package_installed', 'version': '1', 'source': 'pkgmgr'}]}

# Generated at 2022-06-24 23:22:53.349961
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    var_0 = CLIMgr()
    var_0.CLI = "ansible"
    var_1 = var_0.is_available()
    var_0.CLI = "apt-get"
    var_2 = var_0.is_available()
    var_0.CLI = "python"
    var_3 = var_0.is_available()
    var_0.CLI = "python3"
    var_4 = var_0.is_available()
    var_0.CLI = "python2"
    var_5 = var_0.is_available()
    var_0.CLI = "pip"
    var_6 = var_0.is_available()
    var_0.CLI = "pip2"
    var_7 = var_0.is_available()

# Generated at 2022-06-24 23:22:54.250131
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    var_1 = CLIMgr()


# Generated at 2022-06-24 23:23:00.249256
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    pkgmgr = PkgMgr()
    assert pkgmgr.get_package_details is not None, 'get_package_details method is not implemented in the base class'

# Generated at 2022-06-24 23:23:04.307447
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    instance = CLIMgr()
    assert instance is not None


# Generated at 2022-06-24 23:23:07.492583
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    try:
        var_1 = CLIMgr()
        var_1.is_available()
    except Exception as e:
        print(e)


# Generated at 2022-06-24 23:23:10.075415
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    # Test with no params
    ansible_module = AnsibleModule(
        argument_spec = dict()
    )
    pkgMgr_class = PkgMgr()
    ansible_module.exit_json(**pkgMgr_class.list_installed())


# Generated at 2022-06-24 23:23:10.788487
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    # test case 0
    test_case_0()

# Generated at 2022-06-24 23:23:15.165161
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    package_manager = CLIMgr()
    assert not package_manager.is_available()


# Generated at 2022-06-24 23:23:17.098989
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    # Test call with some dummy values
    obj = LibMgr()
    obj.LIB = None
    assert obj.is_available() == False


# Generated at 2022-06-24 23:23:42.889534
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    from ansible.module_utils.facts.system.pkg_mgr import AptMgr
    from ansible.module_utils.facts.system.pkg_mgr import AptitudeMgr
    from ansible.module_utils.facts.system.pkg_mgr import PacmanMgr
    from ansible.module_utils.facts.system.pkg_mgr import YumMgr
    from ansible.module_utils.facts.system.pkg_mgr import ZypperMgr
    # Create a instance of AptMgr
    var_1 = AptMgr()
    # Verify whether the return value of the is_available is True
    assert var_1.is_available() == True
    # Create a instance of AptitudeMgr
    var_2 = AptitudeMgr()
    # Verify whether the return value of the

# Generated at 2022-06-24 23:23:44.459221
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    test_CLIMgr_instance = CLIMgr()
    test_CLIMgr_instance.is_available()


# Generated at 2022-06-24 23:23:45.606484
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    test_k = PkgMgr()
    assert test_k.is_available() != None


# Generated at 2022-06-24 23:23:47.876803
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    # Default constructor
    test_case_CLIMgr_1 = CLIMgr()


# Generated at 2022-06-24 23:23:49.464630
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    var_0 = LibMgr()
    assert var_0.is_available() is not None


# Generated at 2022-06-24 23:23:51.094142
# Unit test for constructor of class LibMgr
def test_LibMgr():
    obj_0 = LibMgr()


# Generated at 2022-06-24 23:23:54.246119
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    try:
        import sys
        sys.modules['yum'] = sys
        var_0 = LibMgr()
        assert var_0.is_available() == True
    except Exception as e:
        print(e)


# Generated at 2022-06-24 23:23:56.838611
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    package = PkgMgr()
    assert package.list_installed() == []
    assert package.get_package_details(None) == None
    assert package.get_packages() == {}
    assert package.is_available() == False


# Generated at 2022-06-24 23:23:58.262220
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    image = CLIMgr()


# Generated at 2022-06-24 23:24:06.729009
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    var_1 = get_all_pkg_managers()
    var_2 = var_1['pacman']()
    var_3 = var_2.is_available()
    var_4 = var_1['dpkg']()
    var_5 = var_4.is_available()
    var_6 = var_1['yum']()
    var_7 = var_6.is_available()
    var_8 = var_1['pip']()
    var_9 = var_8.is_available()
    var_10 = var_1['npm']()
    var_11 = var_10.is_available()
    var_12 = var_1['gem']()
    var_13 = var_12.is_available()
    var_14 = var_1['easy_install']()
    var

# Generated at 2022-06-24 23:24:46.803351
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    # Test the get_packages method of class PkgMgr
    # get_packages():
    # Take all of the above and return a dictionary of lists of dictionaries (package = list of installed versions)
    #
    # Setup:
    #
    # Exercise:
    #
    # Verify:
    #
    # Cleanup:
    #
    # Return:
    return None

# Generated at 2022-06-24 23:24:51.896043
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    test = CLIMgr()
    assert(test is not None)


# Generated at 2022-06-24 23:24:54.419568
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    test = PkgMgr()
    assert test.is_available() == NotImplemented


# Generated at 2022-06-24 23:24:55.297129
# Unit test for constructor of class LibMgr
def test_LibMgr():
    my_var = LibMgr()


# Generated at 2022-06-24 23:24:56.792268
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr() is not None, 'Constructor CLIMgr() works.'


# Generated at 2022-06-24 23:24:57.536409
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    assert get_all_pkg_managers()


# Generated at 2022-06-24 23:25:00.479269
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    """ Test method is_available of class PkgMgr. """

    pkg_mgr = PkgMgr()
    assert isinstance(pkg_mgr.is_available(), bool)


# Generated at 2022-06-24 23:25:01.972224
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    assert True, 'Tests not implemented'


# Generated at 2022-06-24 23:25:12.145286
# Unit test for constructor of class CLIMgr
def test_CLIMgr():

    # This affects the functionality of the test
    # TODO: (okite) Mock subprocess.Popen() to control env
    # TODO: (okite) How to mock the get_bin_path()? Subprocess.Popen() is a part of get_bin_path()
    # TODO: (okite) Bug: How to mock the get_bin_path()? Subprocess.Popen() is a part of get_bin_path()

    # Test 1: If class CLIMgr exists
    try:
        var_1 = CLIMgr()
    except NameError:
        assert False
    else:
        assert True

    # Test 2: The constructor of CLIMgr should not fail
    try:
        var_1 = CLIMgr()
    except Exception:
        assert False
    else:
        assert True

# Unit

# Generated at 2022-06-24 23:25:14.342546
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    cli = get_bin_path('pacman')
    try:
        var_1 = cli
    except ValueError:
        var_1 = 'pacman_cli'
    finally:
        assert var_1 == True


# Generated at 2022-06-24 23:26:45.496488
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pkg_mgr_obj = PkgMgr()
    try:
        __result = pkg_mgr_obj.is_available()
    except NotImplementedError:
        pass


# Generated at 2022-06-24 23:26:46.434488
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    obj = CLIMgr()
    obj.is_available()


# Generated at 2022-06-24 23:26:46.910482
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    assert True

# Generated at 2022-06-24 23:26:51.764430
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    var_0 = LibMgr()
    assert isinstance(var_0.is_available(), bool)


# Generated at 2022-06-24 23:26:52.884212
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    pkg = CLIMgr()
    assert pkg.is_available() == None



# Generated at 2022-06-24 23:27:00.095838
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    pkgmgr = PkgMgr()
    # pkgmgr is an instance of PkgMgr
    assert isinstance(pkgmgr, PkgMgr)
    # pkgmgr is not an instance of LibMgr
    assert not isinstance(pkgmgr, LibMgr)
    # pkgmgr is not an instance of CLIMgr
    assert not isinstance(pkgmgr, CLIMgr)
    # pkgmgr.LIB is not defined
    assert not hasattr(pkgmgr, 'LIB')
    # pkgmgr.CLI is not defined
    assert not hasattr(pkgmgr, 'CLI')
    # pkgmgr._lib is not defined
    assert not hasattr(pkgmgr, '_lib')
    # pkgmgr._cli is not defined
    assert not has

# Generated at 2022-06-24 23:27:03.277000
# Unit test for constructor of class LibMgr
def test_LibMgr():

    try:
        var_1 = LibMgr()
        assert True
    except Exception:
        assert False


# Generated at 2022-06-24 23:27:10.310444
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    obj = CLIMgr()
    assert len(obj.__class__.__name__) > 0
    assert obj.__class__.__name__ == 'CLIMgr'
    assert obj.__class__.__doc__ == '\n    Base class for all CLI based package managers\n    '
    assert len(obj.__class__.__module__) > 0
    assert obj.__class__.__module__ == 'ansible.module_utils.facts.system.pkg_mgr'


# Generated at 2022-06-24 23:27:11.588700
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    var_1 = CLIMgr()
    var_2 = var_1.is_available()


# Generated at 2022-06-24 23:27:15.365698
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    obj = LibMgr()
    assert isinstance(obj.is_available(), bool)


# Generated at 2022-06-24 23:30:48.968607
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    var_0 = PkgMgr()
    var_1 = var_0.is_available()
    assert var_1

# test_case_1

# test_case_0


# Generated at 2022-06-24 23:30:50.435223
# Unit test for constructor of class LibMgr
def test_LibMgr():
    obj = LibMgr()
    assert obj._lib == None, "ERROR : Expected Attribute Value : None, Actual : %s"%(obj._lib)


# Generated at 2022-06-24 23:30:54.624970
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    mock_self = PkgMgr()
    mock_self.list_installed = lambda: ['package_1', 'package_2']
    mock_self.get_package_details = lambda package: {'name': package, 'version': '1.0'}
    assert mock_self.get_packages() == {'package_1': [{'name': 'package_1', 'version': '1.0', 'source': 'PkgMgr'}], 'package_2': [{'name': 'package_2', 'version': '1.0', 'source': 'PkgMgr'}]}


# Generated at 2022-06-24 23:30:58.400739
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    assert True


# Generated at 2022-06-24 23:30:59.080974
# Unit test for constructor of class LibMgr
def test_LibMgr():
    var_1 = LibMgr()

# Generated at 2022-06-24 23:31:01.701545
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    if not test_case_0():
        print('Failed to run test_case_0')
    else:
        print('Test case passed')

test_PkgMgr_get_packages()

# Generated at 2022-06-24 23:31:11.553410
# Unit test for method get_package_details of class PkgMgr

# Generated at 2022-06-24 23:31:14.700161
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    var_1 = CLIMgr()


# Generated at 2022-06-24 23:31:17.266303
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pkg_mgr_obj = PkgMgr()
    result = pkg_mgr_obj.is_available()
    assert result == NotImplementedError


# Generated at 2022-06-24 23:31:18.126457
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    assert False

