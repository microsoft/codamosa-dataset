

# Generated at 2022-06-24 23:21:36.359962
# Unit test for constructor of class LibMgr
def test_LibMgr():
    lib_mgr_1 = LibMgr()
    pass


# Generated at 2022-06-24 23:21:39.608048
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    pass


# Generated at 2022-06-24 23:21:40.575109
# Unit test for constructor of class LibMgr
def test_LibMgr():
    assert(test_case_0())


# Generated at 2022-06-24 23:21:43.437136
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    lib_mgr_0 = LibMgr()
    package = ()
    lib_mgr_0.get_package_details(package)


# Generated at 2022-06-24 23:21:44.339121
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    Manager = CLIMgr()



# Generated at 2022-06-24 23:21:46.460299
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    # Arrange
    pm = PkgMgr()

    # Act
    result = pm.get_packages()

    # Assert
    assert result == {}


# Generated at 2022-06-24 23:21:50.450756
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    cli_mgr = CLIMgr()
    assert cli_mgr.is_available() == False


# Generated at 2022-06-24 23:21:53.229955
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    cli_mgr_0 = CLIMgr()
    assert cli_mgr_0 is not None


# Generated at 2022-06-24 23:21:56.549901
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    pm = PkgMgr()
    info = pm.get_package_details('libc6')
    assert info['name'] == 'libc6'
    assert info['version'] == '2.27-3ubuntu1'
    assert info['source'] == 'yum'


if __name__ == '__main__':

    test_case_0()

# Generated at 2022-06-24 23:21:58.965991
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    test_case_0()



# Generated at 2022-06-24 23:22:03.992803
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    assert True


# Generated at 2022-06-24 23:22:08.860368
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    # Initialize an object of class CLIMgr
    var_1 = CLIMgr()
    # call the test function
    var_0 = test_case_0()


# Generated at 2022-06-24 23:22:13.072275
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    var_0 = PkgMgr()
    var_1 = var_0.get_package_details('package')


# Generated at 2022-06-24 23:22:16.472979
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    # Create an instance of PkgMgr
    pkgMgr = PkgMgr()

    # Check if not implemented
    try:
        pkgMgr.get_packages()
        assert False
    except NotImplementedError as e:
        assert True

# Generated at 2022-06-24 23:22:17.936988
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    pm = PkgMgr()
    pm.get_package_details("ABC")

# Generated at 2022-06-24 23:22:24.001720
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    mock_LibMgr = LibMgr()
    mock_LibMgr.LIB = "mock_LibMgr_LIB"
    mock_value_0 = mock_LibMgr.is_available()
    assert (mock_value_0 == None)

# Generated at 2022-06-24 23:22:24.976382
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    obj = CLIMgr()
    assert not obj.is_available()


# Generated at 2022-06-24 23:22:30.857468
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():

    class test_class_1(PkgMgr):

        def is_available(self):
            pass

        def list_installed(self):
            pass

        def get_package_details(self, package):
            pass

    var_0 = test_class_1()
    var_0.get_package_details('package')


# Generated at 2022-06-24 23:22:40.077594
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    # Instantiate mock object of class PkgMgr
    mock_PkgMgr_obj = PkgMgr()
    # Mock object of method list_installed of class PkgMgr
    with patch.object(mock_PkgMgr_obj, 'list_installed') as mock_PkgMgr_list_installed:
        # Execute method list_installed of class PkgMgr
        mock_PkgMgr_list_installed()
        # Assert that method list_installed of class PkgMgr was called
        mock_PkgMgr_list_installed.assert_called_with()
        # Assert that method list_installed of class PkgMgr was called only once
        assert mock_PkgMgr_list_installed.call_count == 1


# Generated at 2022-06-24 23:22:41.623791
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():

    # Nothing to test as method is_available doesn't do anything
    pass


# Generated at 2022-06-24 23:22:58.199841
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    print("Testing method get_packages of class PkgMgr")

    test_PkgMgr_get_packages_expected_result_0 = "dict"
    test_PkgMgr_get_packages_result_0 = None

    test_PkgMgr_get_packages_expected_result_1 = "dict"
    test_PkgMgr_get_packages_result_1 = None


    for i in range(2):
        if i == 0:
            test_PkgMgr_get_packages_result_0 = get_all_pkg_managers()
        if test_PkgMgr_get_packages_result_0 != "dict":
            print("Self check failed")

# Generated at 2022-06-24 23:23:01.271527
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    # Instantiating an object without passing in any parameters
    var_0 = CLIMgr()
    # Calling method is_available() on object var_0
    var_0.is_available()


# Generated at 2022-06-24 23:23:05.088728
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    var_1 = CLIMgr()


# Generated at 2022-06-24 23:23:06.369004
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    climgr = CLIMgr()
    

# Generated at 2022-06-24 23:23:08.622404
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class DummyLibMgr(LibMgr):
        LIB = 'package_manager_collection.library'
    dummyLibMgr = DummyLibMgr()
    dummyLibMgr.is_available()

# Generated at 2022-06-24 23:23:14.343817
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    var_0 = PkgMgr()
    try:
        assert var_0.is_available()
    except AssertionError:
        raise


# Generated at 2022-06-24 23:23:17.298608
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    expected_result = True
    libMgr = get_all_pkg_managers()['apt']()
    result_value = libMgr.is_available()
    if result_value != expected_result:
        raise ValueError('test_LibMgr_is_available failed')


# Generated at 2022-06-24 23:23:21.305073
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    var_0 = PkgMgr()
    var_1 = var_0.get_packages()


# Generated at 2022-06-24 23:23:23.197031
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    # Default constructor
    cli1 = CLIMgr()
    assert(cli1 is not None)


# Generated at 2022-06-24 23:23:24.779633
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    a = PkgMgr
    a.get_package_details(None)


# Generated at 2022-06-24 23:23:42.150121
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    pkg_mgr = PkgMgr()
    pkg_mgr.get_packages()

# Generated at 2022-06-24 23:23:42.917180
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    test_case_0()

# Generated at 2022-06-24 23:23:45.469021
# Unit test for constructor of class LibMgr
def test_LibMgr():
    var_1 = test_case_0()
    var_2 = CLIMgr()
    var_3 = var_2.is_available()
    var_4 = var_2.get_packages()
    var_5 = type(var_4)
    


# Generated at 2022-06-24 23:23:47.105795
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    pass


# Generated at 2022-06-24 23:23:56.599730
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    var_0 = get_all_pkg_managers()
    var_1 = 'deb'
    var_2 = var_0[var_1]
    var_3 = var_2('/tmp/ansible_inPrfj_/apt_list_installed')
    var_3.list_installed()
    #assert var_3.list_installed() ==
    var_4 = 'dnf'
    var_5 = var_0[var_4]
    var_6 = var_5('/tmp/ansible_inPrfj_/dnf_list_installed')
    var_6.list_installed()
    #assert var_6.list_installed() ==
    var_7 = 'pip'
    var_8 = var_0[var_7]

# Generated at 2022-06-24 23:23:58.544328
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class_under_test = CLIMgr()


# Generated at 2022-06-24 23:24:00.413066
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():

        var_0 = LibMgr()
        var_0.is_available()


# Generated at 2022-06-24 23:24:01.944494
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    lib_mgr = LibMgr()
    assert lib_mgr.is_available()


# Generated at 2022-06-24 23:24:03.886055
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    obj_0 = PkgMgr()
    var_0 = obj_0.get_packages()
    assert var_0 == {}


# Generated at 2022-06-24 23:24:04.657139
# Unit test for constructor of class LibMgr
def test_LibMgr():
    pass


# Generated at 2022-06-24 23:24:41.410303
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    var_0 = PkgMgr()
    assert var_0.is_available() == False


# Generated at 2022-06-24 23:24:46.348003
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    package = None
    try:
        PkgMgr.get_package_details(package)
    except NotImplementedError:
        pass
    else:
        raise Exception('Expected NotImplementedError')


# Generated at 2022-06-24 23:24:52.283926
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    var_0 = get_all_pkg_managers()
    l = []
    for i in var_0:
        r = var_0[i].get_package_details(PkgMgr())
        l.append(r)
    return l


# Generated at 2022-06-24 23:24:56.130230
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    # Checks if checks if value of LIB is not empty
    assert(CLIMgr.LIB is not None)
    # Checks if checks if value of CLI is not empty
    assert(CLIMgr.CLI is not None)


# Generated at 2022-06-24 23:25:01.159866
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    assert False


# Generated at 2022-06-24 23:25:04.643467
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    mgr_0 = PkgMgr()
    assert mgr_0.get_packages() == {}, "Invalid return from method get_packages of class PkgMgr"


# Generated at 2022-06-24 23:25:06.928851
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pkgMgr = PkgMgr()
    pkgMgr.list_installed()


# Generated at 2022-06-24 23:25:09.353045
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    # Initialize a PkgMgr object for testing and call get_packages method
    var_0 = PkgMgr()
    var_1 = var_0.get_packages()



# Generated at 2022-06-24 23:25:10.759041
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    var_0 = PkgMgr()
    var_0.get_package_details("package")


# Generated at 2022-06-24 23:25:12.364047
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    # Declare var1 and initialize it
    var1 = {'the': 'dict', '__class__': 'PkgMgr'}
    var1['__init__'] = 'launched'
    PkgMgr.list_installed(var1)


# Generated at 2022-06-24 23:26:38.808961
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    pass


# Generated at 2022-06-24 23:26:46.393011
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    var_1 = get_all_pkg_managers()

    x = var_1.get('apk').get_packages()
    y = x.get('ansible').pop()
    assert y.get('name') == 'ansible'
    assert y.get('version') == '2.5.3-r0'
    assert y.get('release') == 'r0'
    assert y.get('source') == 'apk'
    assert y.get('arch') == 'x86_64'

# Generated at 2022-06-24 23:26:48.248994
# Unit test for constructor of class LibMgr
def test_LibMgr():
    LibMgr()


# Generated at 2022-06-24 23:26:53.542831
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    # Make a new PkgMgr object
    x = PkgMgr()
    # list_installed should be implemented by the subclass and not be abstract
    assert hasattr(x.list_installed(),"__call__")


# Generated at 2022-06-24 23:26:58.476878
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    var_0 = get_all_pkg_managers()
    var_1 = PkgMgr()
    var_list = [var_0, var_1]
    libmgr_0 = LibMgr
    assert libmgr_0.is_available(var_list[0]) == var_list[1].is_available(var_list[0])


# Generated at 2022-06-24 23:26:59.250460
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    test_obj = CLIMgr()


# Generated at 2022-06-24 23:27:02.226517
# Unit test for constructor of class LibMgr
def test_LibMgr():
    libmgr = LibMgr()
    assert isinstance(libmgr,LibMgr)


# Generated at 2022-06-24 23:27:04.180550
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    var_0 = get_all_pkg_managers()
    var_1 = var_0['dnf']().list_installed()
    print(var_1)


# Generated at 2022-06-24 23:27:09.333927
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    try:
        var_1 = PkgMgr.list_installed(test_PkgMgr_list_installed)
    except Exception as var_2:
        print("Exception caught: {}".format(var_2))
        raise


# Generated at 2022-06-24 23:27:11.554043
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    var_1 = PkgMgr()
    package = None
    result = var_1.get_package_details(package)
    assert result == None


# Generated at 2022-06-24 23:30:30.278053
# Unit test for constructor of class LibMgr
def test_LibMgr():
    print("Testing: __init__ in class LibMgr")
    assert hasattr(LibMgr, 'is_available')
    assert hasattr(LibMgr, 'list_installed')
    assert hasattr(LibMgr, 'get_package_details')
    assert hasattr(LibMgr, 'get_packages')



# Generated at 2022-06-24 23:30:36.968908
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    import mock
    import json
    import copy
    import ansible.module_utils.cloudstack.cs_package_mgr as cs_package_mgr

    json_str = r"""
{
  "packageDetails": [
    {
      "packageName": "gdbm-1.10",
      "packageDescription": "GNU dbm is a set of database routines that use extensible hashing and work similar to the standard UNIX dbm routines.",
      "packageVersion": "1.10",
      "packageRelease": "4",
      "packageArch": "x86_64",
      "packageSize": "104096",
      "packageSource": "Centos",
      "packageFilename": "gdbm-1.10-4.el6.x86_64.rpm"
    }
  ]
}
"""
    expected

# Generated at 2022-06-24 23:30:42.252152
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    var_0 = PkgMgr()
    var_0.list_installed = lambda : [0]
    var_0.get_package_details = lambda x: {'name': 'test', 'version': '0'};
    var_0.get_packages()


# Generated at 2022-06-24 23:30:45.718250
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    var_0 = CLIMgr()
    var_0.is_available()
    assert var_0._cli == '/usr/bin/ansible'
    assert var_0.is_available()


# Generated at 2022-06-24 23:30:49.351596
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    obj = PkgMgr()
    res = obj.is_available()


# Generated at 2022-06-24 23:30:56.833806
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():

    # import the class with the is_available function and create a new object
    from ansible.module_utils.common._pkg_mgr_classes import CLIMgr
    var_0 = CLIMgr()

    # The CLI should be set to the name of the command-line tool for your package manager
    var_0.CLI = 'example_cli'
    # This method is supposed to return True/False if the package manager is currently installed/usable
    # The CLI is in the path, thus it should return True
    var_1 = var_0.is_available()
    assert var_1



# Generated at 2022-06-24 23:30:59.486811
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    myobj = PkgMgr()
    myobj.list_installed()
    # unit test for PkgMgr method list_installed
    test_case_0()
    test_case_1()


# Generated at 2022-06-24 23:31:00.784895
# Unit test for constructor of class LibMgr
def test_LibMgr():
    assert LibMgr()._lib == None


# Generated at 2022-06-24 23:31:06.381528
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    expected_result = False
    result = PkgMgr.is_available()
    assert expected_result == result


# Generated at 2022-06-24 23:31:07.572327
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    mgr = get_all_pkg_managers()["dnf"]()
    assert mgr.get_packages()