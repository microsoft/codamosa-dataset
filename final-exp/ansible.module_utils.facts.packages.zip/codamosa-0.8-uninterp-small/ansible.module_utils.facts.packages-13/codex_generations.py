

# Generated at 2022-06-24 23:21:36.362878
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    # test many
    var_0 =  PkgMgr()
    try:
        var_0.list_installed()
    except NotImplementedError:
        pass


# Generated at 2022-06-24 23:21:39.766664
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    # Just for testing if the method __init__ is executed. The name should not be "obj"
    obj = LibMgr()
    # Just for testing if the method is_available is actually executed. The name should not be "result"
    result = obj.is_available()


# Generated at 2022-06-24 23:21:42.301014
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    ev = LibMgr()
    ev.LIB = 'ansible.module_utils.facts.system.pkg_mgr.Test'
    ev.is_available()


# Generated at 2022-06-24 23:21:43.832427
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    # 'apt-get'
    pass


# Generated at 2022-06-24 23:21:46.874063
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    case_0 = {'key_0': 'val_0', 'key_1': None}
    obj_0 = PkgMgr()
    res_0 = obj_0.list_installed(case_0)
    assert res_0 == None


# Generated at 2022-06-24 23:21:49.719599
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    obj = PkgMgr()
    obj.get_packages()


# Generated at 2022-06-24 23:21:53.972518
# Unit test for constructor of class LibMgr
def test_LibMgr():
    try:
        obj = LibMgr()
    except TypeError:
        # If we catch a TypeError, it means the constructor is trying to
        # to use the superclass constructor, which is not allowed
        print('FAIL')
        return
    print('PASS')


# Generated at 2022-06-24 23:21:56.609139
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    var_0 = get_all_pkg_managers()
    for entry in var_0:
        package_manager = var_0[entry]()
        if package_manager.is_available():
            var_1 = package_manager.get_packages()


# Generated at 2022-06-24 23:22:01.142487
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    var_0 = CLIMgr()
    if var_0 is not None:
        var_1 = var_0.is_available()
        if var_1 is not None:
            assert True
        else:
            assert False
    else:
        assert False



# Generated at 2022-06-24 23:22:01.541183
# Unit test for constructor of class LibMgr
def test_LibMgr():
    LibMgr()

# Generated at 2022-06-24 23:22:07.141771
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    var_0 = get_all_pkg_managers()
    var_1 = var_0['pip']()
    var_1.is_available()


# Generated at 2022-06-24 23:22:08.808445
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    o_obj = CLIMgr()
    ret_val = o_obj.is_available()
    assert not ret_val


# Generated at 2022-06-24 23:22:13.716453
# Unit test for constructor of class LibMgr
def test_LibMgr():

    # Test case 1
    try:
        var_1 = LibMgr()
        var_1.is_available()
    except:
        print("Unexpected exception for test case 1")


# Generated at 2022-06-24 23:22:17.225653
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    print("running test case: LibMgr_is_available")
    # initialize LibMgr object
    LibMgr_obj = LibMgr()
    # call the is_available method
    LibMgr_obj.is_available()
    assert(True)


# Generated at 2022-06-24 23:22:21.969977
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():

    from ansible.module_utils.common.process import get_bin_path

    pkg_mgr_inst = LibMgr()
    pkg_mgr_inst.LIB = 'ansible.module_utils.common.json_utils'
    pkg_mgr_inst.is_available()
    pkg_mgr_inst.is_available()



# Generated at 2022-06-24 23:22:27.180401
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    # declare a class object
    obj_CLIMgr = CLIMgr()
    # call is_available method
    ret_val = obj_CLIMgr.is_available()
    # print the return value
    print(ret_val)



# Generated at 2022-06-24 23:22:28.643556
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    var_1 = PkgMgr()
    var_2 = var_1.list_installed()


# Generated at 2022-06-24 23:22:35.029367
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():

    import platform
    import ansible.module_utils.ansible_release
    import ansible.module_utils.facts.collector
    import tempfile
    import sys
    import os

    # Make sure ansible-release doesn't exist to test that the CLI manager
    # can handle it being missing without error.
    if os.path.exists(os.path.join(os.path.dirname(__file__), '../../../ansible-release')):
        raise Exception('Tests require ansible-release to be absent')

    # Create a mock module that looks like it was run by the Python interpreter
    # provided in the path to the test suite.
    python_bin = sys.executable
    t = tempfile.NamedTemporaryFile()

# Generated at 2022-06-24 23:22:40.799369
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    print("########## In test_PkgMgr_get_package_details ##########")
    pm = PkgMgr()
    ret_dict = pm.get_package_details('test_pkg')
    print("Return type of get_package_details is: %s" %type(ret_dict))
    print("Return Val of get_package_details is: %s" %ret_dict)
    assert type(ret_dict) == dict


# Generated at 2022-06-24 23:22:42.514603
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    test_PkgMgr = PkgMgr()
    test_PkgMgr.get_package_details()

# Generated at 2022-06-24 23:22:54.515512
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    for var_0 in get_all_pkg_managers().values():
        var_1 = PkgMgr()
        var_2 = var_1.get_packages()

if __name__ == '__main__':
    test_case_0()
    test_PkgMgr_get_packages()

# Generated at 2022-06-24 23:23:03.607106
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    package_managers = get_all_pkg_managers()
    for _, package_manager in package_managers.items():
        if isinstance(package_manager, CLIMgr):
            try:
                package_manager().is_available()
            except (AttributeError, TypeError):
                status = False
            else:
                status = True
            assert status is True, 'Method is_available() is missing from class CLIMgr'


# Generated at 2022-06-24 23:23:06.515680
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    var_0 = CLIMgr()


# Generated at 2022-06-24 23:23:09.313560
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    # case 0
    var_0 = CLIMgr()
    var_0.CLI = 'invalid_CLI'
    expected_0 = False
    actual_0 = var_0.is_available()
    assert actual_0 == expected_0


# Generated at 2022-06-24 23:23:13.983505
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
   pm = PkgMgr()
   assert pm == None


# Generated at 2022-06-24 23:23:14.975069
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    try:
        CLIMgr()
    except Exception:
        assert True
    else:
        assert False


# Generated at 2022-06-24 23:23:16.311469
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    var_1 = get_all_pkg_managers()
    test_case_0()
    var_2 = var_1['packageutils']
    var_2.is_available()


# Generated at 2022-06-24 23:23:19.658476
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    def test_is_available_failure():
        global var_0
        var_0 = get_all_pkg_managers()
        assert var_0['java'].is_available() == False

    def test_is_available_success():
        global var_0
        assert var_0['python'].is_available() == True

    # Default test
    test_is_available_failure()
    test_is_available_success()



# Generated at 2022-06-24 23:23:24.085585
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    # Initialize test objects
    pkgMgr = PkgMgr()
    # Test for method get_package_details
    # Exception should be thrown for abstract class method
    with pytest.raises(NotImplementedError):
        pkgMgr.get_package_details('')


# Generated at 2022-06-24 23:23:25.582053
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    var_0 = CLIMgr()
    var_0.is_available()


# Generated at 2022-06-24 23:23:42.112463
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    p = PkgMgr()
    assert p.get_packages() is None

# Generated at 2022-06-24 23:23:42.883195
# Unit test for constructor of class LibMgr
def test_LibMgr():
    LibMgr()


# Generated at 2022-06-24 23:23:43.904818
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    var_1 = get_all_pkg_managers()


# Generated at 2022-06-24 23:23:45.790547
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    var_0 = PkgMgr()
    var_1 = var_0.get_package_details('key1')
    var_2 = var_0.get_package_details('key1')


# Generated at 2022-06-24 23:23:55.895375
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    # This test is the equivalent of a unit test for the method is_available of the class CLIMgr.
    # This test is a basic example of how to test a method of a class.
    # First, let's instantiate the CLIMgr class.
    # Note that we need to pass the __init__ method some argument so that we can instantiate the class.
    # In this case, we just pass the CLI argument, which is required by the __init__ method.
    var_CLIMgr = CLIMgr(CLI="hello")

    # Then, let's call the method we want to test.
    ret_obj = var_CLIMgr.is_available()

    # Finally, check the return object to see if it is correct.
    if ret_obj != None:
        raise Exception("Test failed. Return object is not correct!")


# Unit

# Generated at 2022-06-24 23:23:59.644916
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    obj_CLIMgr = CLIMgr()
    obj_CLIMgr.CLI = 'yum'
    obj_CLIMgr.is_available()


# Generated at 2022-06-24 23:24:00.624136
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pass


# Generated at 2022-06-24 23:24:02.417909
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    obj = PkgMgr()
    result = obj.is_available()
    assert result == NotImplemented


# Generated at 2022-06-24 23:24:04.782536
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    var_0 = PkgMgr()


# Generated at 2022-06-24 23:24:06.107222
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    var_1 = PkgMgr()
    var_2 = var_1.get_packages()



# Generated at 2022-06-24 23:24:42.151311
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    assert get_all_pkg_managers()
    assert get_all_pkg_managers()
    assert get_all_pkg_managers()

test_case_0()

test_PkgMgr_get_packages()

# Generated at 2022-06-24 23:24:42.619724
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pass


# Generated at 2022-06-24 23:24:43.744074
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pass


# Generated at 2022-06-24 23:24:47.031171
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    var_0 = PkgMgr()
    with pytest.raises(NotImplementedError):
        var_0.list_installed()


# Generated at 2022-06-24 23:24:51.509843
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    var_0 = get_bin_path("pip")
    assert var_0 is not False


# Generated at 2022-06-24 23:24:56.422271
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    var_0 = PkgMgr()
    try:
        var_0.is_available()
    except NotImplementedError as exception:
        if exception.args[0] != 'is_available method not implemented by PkgMgr':
            raise
    else:
        raise Exception('Expected exception NotImplementedError not raised')


# Generated at 2022-06-24 23:25:02.731728
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():

    # Create an object of LibMgr
    obj_LibMgr = LibMgr()
    # Call the method is_available of the object LibMgr
    var_result = obj_LibMgr.is_available()
    # Check result
    if var_result is None:
        print("No result returned.")
        return
    print(var_result)


# Generated at 2022-06-24 23:25:06.713521
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    var_0 = PkgMgr()
    expected_value = None
    var_0_is_available = var_0.is_available()
    assert expected_value == var_0_is_available


# Generated at 2022-06-24 23:25:13.190717
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    global var_0

    var_0 = None

    test_case_0()

    try:
        print(var_0)
    except Exception as e:
        print(e)

test_PkgMgr_list_installed()

# Generated at 2022-06-24 23:25:13.874512
# Unit test for constructor of class LibMgr
def test_LibMgr():
    var_0 = LibMgr()


# Generated at 2022-06-24 23:26:39.374370
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    test_object = LibMgr()
    test_object.is_available()


# Generated at 2022-06-24 23:26:46.618512
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    import pytest
    package_1 = {'name': 'ansible', 'version': '2.5'}
    package_2 = {'name': 'ansible', 'version': '2.6'}
    var_1 = PkgMgr()
    with pytest.raises(NotImplementedError):
        var_1.get_package_details(package_1)
        var_1.get_package_details(package_2)


# Generated at 2022-06-24 23:26:50.664817
# Unit test for constructor of class LibMgr
def test_LibMgr():
    # Pass
    return



# Generated at 2022-06-24 23:26:52.523313
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    # Instantiate a CLIMgr class
    var_0 = CLIMgr()
    # Call method is_available on var_0
    var_1 = var_0.is_available()


# Generated at 2022-06-24 23:26:53.400487
# Unit test for constructor of class LibMgr
def test_LibMgr():
    obj = LibMgr()
    test_case_0()

# Generated at 2022-06-24 23:26:54.480910
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pm = PkgMgr("PkgMgr")
    pm.list_installed()


# Generated at 2022-06-24 23:26:57.588794
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    var_1 = CLIMgr()
    var_2 = var_1.is_available()


# Generated at 2022-06-24 23:26:58.377592
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    '''Test is_available()'''
    assert True


# Generated at 2022-06-24 23:26:59.835140
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    my_CLI = CLIMgr()
    assert my_CLI.is_available() == True


# Generated at 2022-06-24 23:27:02.789187
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    var_0 = PkgMgr()
    var_0.is_available()


# Generated at 2022-06-24 23:30:12.073514
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pkgmgr = PkgMgr()
    assert pkgmgr.is_available() != None


# Generated at 2022-06-24 23:30:12.758415
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    var_1 = CLIMgr()


# Generated at 2022-06-24 23:30:15.839583
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    assert get_bin_path(mocker, '/usr/bin/ansible-lint')
    # Instantiate a PkgMgr class
    var_1 = PkgMgr()
    # Test if method is_available of PkgMgr returns a boolean value when called with 'self'
    assert is_instance(var_1.is_available(), bool)

# Generated at 2022-06-24 23:30:17.630846
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    var_0 = get_all_pkg_managers()
    var_1 = "yum"
    var_2 = var_0.get(var_1)()
    var_3 = var_2.list_installed()


# Generated at 2022-06-24 23:30:18.820196
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    var_0 = LibMgr()
    assert var_0.is_available() == None


# Generated at 2022-06-24 23:30:20.499790
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    try:
        raise NotImplementedError
    except NotImplementedError as e:
        print(e)


# Generated at 2022-06-24 23:30:21.912886
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    pass

# Generated at 2022-06-24 23:30:27.032744
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    obj = CLIMgr()
    assert isinstance(obj, CLIMgr)


# Generated at 2022-06-24 23:30:28.538416
# Unit test for constructor of class LibMgr
def test_LibMgr():
    obj = LibMgr()
    if not isinstance(obj, LibMgr):
        raise Exception('Library class was not instantiated')


# Generated at 2022-06-24 23:30:30.519830
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    var_1 = PkgMgr()
    # abstract method, just test if it exists
    assert hasattr(var_1, 'is_available')
