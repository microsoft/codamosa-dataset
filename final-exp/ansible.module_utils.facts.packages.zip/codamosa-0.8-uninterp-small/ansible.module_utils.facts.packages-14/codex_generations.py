

# Generated at 2022-06-24 23:21:36.497607
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    cli_mgr = CLIMgr()


# Generated at 2022-06-24 23:21:40.130581
# Unit test for constructor of class LibMgr
def test_LibMgr():
    test = LibMgr()
    assert test is not None, 'Failed to create LibMgr object!'


# Generated at 2022-06-24 23:21:41.487801
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    obj_CLIMgr = CLIMgr()


# Generated at 2022-06-24 23:21:42.070449
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    pass

# Generated at 2022-06-24 23:21:45.093486
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pkgmgr_instance = PkgMgr()
    try:
        pkgmgr_instance.is_available()
    except NotImplementedError:
        pass



# Generated at 2022-06-24 23:21:45.633557
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pass

# Generated at 2022-06-24 23:21:49.181784
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    var_1 = CLIMgr()

# Generated at 2022-06-24 23:21:54.517694
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    print('Testing method get_packages of class PkgMgr')
    pkgMgr_obj = PkgMgr()
    try:
        pkgMgr_obj.get_packages()
    except NotImplementedError:
        print('Test get_packages of class PkgMgr has passed')
        assert True
    except:
        raise


# Generated at 2022-06-24 23:21:59.387833
# Unit test for constructor of class LibMgr
def test_LibMgr():
    libmgr = LibMgr()
    assert libmgr is not None


# Generated at 2022-06-24 23:22:01.421534
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    # 1. Arrange
    a = CLIMgr()

    # 2. Act
    a.is_available()

    # 3. Assert

# Generated at 2022-06-24 23:22:05.887499
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    test = PkgMgr()
    test.get_packages()


# Generated at 2022-06-24 23:22:06.777553
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    var_0 = LibMgr()
    var_0.is_available()


# Generated at 2022-06-24 23:22:08.088516
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    try:
        f = LibMgr()
    except AssertionError:
        pass


# Generated at 2022-06-24 23:22:13.205116
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    var_0 = None
    var_1 = None
    var_0 = get_all_pkg_managers()
    var_1 = var_0.get('apt')
    var_2 = var_1.is_available()


# Generated at 2022-06-24 23:22:17.847456
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    var_0 = get_all_pkg_managers()
    assert 'dnf' in var_0
    assert 'yum' in var_0
    assert 'apt' in var_0
    assert 'apk' in var_0
    assert 'portage' in var_0
    assert 'emerge' in var_0
    assert 'zypper' in var_0

# Generated at 2022-06-24 23:22:20.031472
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    cLI_1 = CLIMgr()


# Generated at 2022-06-24 23:22:27.433055
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():

    class TestPkgMgr(PkgMgr):
        pass

    names = ['package_name']
    versions = ['0.0.1', '1.0.0']
    tests = list()
    for n in names:
        for v in versions:
            tests.append({'name': n, 'version': v})

    for i in range(len(names)):
        for j in range(len(versions)):
            test = TestPkgMgr()
            result = test.get_package_details({'name': names[i], 'version': versions[j]})
            assert result == tests[i * len(versions) + j]



# Generated at 2022-06-24 23:22:30.762879
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    var_0 = get_all_pkg_managers()
    var_1 = var_0.items()
    var_2 = var_1[0]
    var_3 = var_2[1]()
    var_4 = var_3.is_available()
    var_5 = var_3.is_available()


# Generated at 2022-06-24 23:22:40.224933
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class PkgMgr1(PkgMgr):
        def list_installed(self):
            return ["Pkg1", "Pkg2"]
        def get_package_details(self, package):
            dic = {
                "Pkg1": {
                    "name": "Pkg1",
                    "version": "1.0.0",
                    "install_date": "2018-04-20",
                    "publisher": "Example"
                },
                "Pkg2": {
                    "name": "Pkg2",
                    "version": "2.0.0",
                    "install_date": "2018-05-06",
                    "publisher": "Example"
                }
            }
            return dic[package]

# Generated at 2022-06-24 23:22:44.807704
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    manager = var_0['pip']
    # record call and return values of method is_available
    with patch.object(PkgMgr, 'is_available', return_value=True) as mock_method:
        mock_method.return_value = True
        ret_value = manager.is_available()
        assert(ret_value == True)


# Generated at 2022-06-24 23:22:53.711493
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    print('Calling test case 0')
    test_case_0()
    
test_CLIMgr_is_available()

# Generated at 2022-06-24 23:22:55.181102
# Unit test for constructor of class LibMgr
def test_LibMgr():
    instance = LibMgr()
    assert isinstance(instance, PkgMgr)


# Generated at 2022-06-24 23:23:04.577751
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():

    class Mock_CLIMgr(CLIMgr):
        CLI = "package_manager"

    mock_CLIMgr = Mock_CLIMgr()
    mock_CLIMgr.is_available = CLIMgr.is_available
    
    # Unit test for method get_bin_path of module process
    def test_get_bin_path():
        try:
            mock_CLIMgr._cli = get_bin_path(mock_CLIMgr.CLI)
        except ValueError:
            mock_CLIMgr._cli = None
        assert mock_CLIMgr._cli == mock_CLIMgr.CLI

# Generated at 2022-06-24 23:23:06.489861
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    var_0 = LibMgr()

    var_1 = var_0.is_available()


# Generated at 2022-06-24 23:23:07.573805
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr().is_available() == True


# Generated at 2022-06-24 23:23:08.933476
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    assert not (['pack1', 'pack2'] == PkgMgr().get_packages())


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 23:23:14.974985
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    variable_0 = LibMgr()
    variable_0.is_available()


# Generated at 2022-06-24 23:23:16.571946
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    if get_all_pkg_managers() is None:
        return False
    else:
        return True


# Generated at 2022-06-24 23:23:24.002293
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    print("testing get_package_details")
    var_1 = PkgMgr()
    # TODO: replace with some real input data
    var_2 = None
    expected = None
    actual = var_1.get_package_details(var_2)
    # TODO: check against expected result
    assert actual == expected



# Generated at 2022-06-24 23:23:25.484939
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():

    test_obj = CLIMgr()
    assert test_obj.is_available() != None


# Generated at 2022-06-24 23:23:41.390581
# Unit test for constructor of class LibMgr
def test_LibMgr():
    var_0 = LibMgr()


# Generated at 2022-06-24 23:23:42.454115
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    CLI = "yum"
    LIB = "yum"
    pass

# Generated at 2022-06-24 23:23:43.732833
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    inst = LibMgr()
    var_0 = inst.is_available()


# Generated at 2022-06-24 23:23:44.768964
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    abc = LibMgr()
    abc.is_available()


# Generated at 2022-06-24 23:23:49.465349
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    # Setting up parameters
    param_CLIMgr_arg_0 = ''

    # Setting up other parameters
    param_CLIMgr_arg_1 = ''

    # Setting up the return value
    param_CLIMgr_return = ''
    return param_CLIMgr_return

# Generated at 2022-06-24 23:23:51.095185
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pass


# Generated at 2022-06-24 23:23:53.288358
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    # The method is not abstract
    p = LibMgr()
    assert p.is_available() == None


# Generated at 2022-06-24 23:24:00.201522
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    var_1 = CLIMgr()
    var_2 = {"self._cli": None}
    assert hasattr(var_1, "_cli")
    assert not hasattr(var_1, "CLI")
    assert hasattr(var_1, "is_available")
    assert hasattr(var_1, "list_installed")
    assert hasattr(var_1, "get_package_details")
    assert hasattr(var_1, "get_packages")
    assert var_1.__init__.__code__.co_varnames == ('self',)
    assert var_1.__init__.__code__.co_argcount == 1
    assert var_1.__dict__ == var_2
    assert var_1.is_available.__code__.co_varnames == ('self',)
   

# Generated at 2022-06-24 23:24:07.955695
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    obj_0 = PkgMgr()
    # Get a list of installed packages and a corresponding list of package details
    installed_packages = obj_0.list_installed()
    expected_package_details = []
    for package in installed_packages:
        package_details = obj_0.get_package_details(package)
        expected_package_details.append(package_details)
    actual_package_details = []
    for package_detail in expected_package_details:
        actual_package_details.append(obj_0.get_package_details(package_detail))
    result = obj_0.get_packages()
    assert result == actual_package_details
    # Test with no packages installed
    installed_packages = []

# Generated at 2022-06-24 23:24:08.695362
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    pm = PkgMgr()
    pm.get_package_details("bash")

# Generated at 2022-06-24 23:24:42.228202
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    var_0 = get_all_pkg_managers()
    # Tested method call
    PkgMgr.get_packages()

# Generated at 2022-06-24 23:24:42.711753
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    var_1 = CLIMgr()


# Generated at 2022-06-24 23:24:45.382873
# Unit test for constructor of class LibMgr
def test_LibMgr():
    var_1 = LibMgr()
    assert var_1.__class__.__name__ =="LibMgr"


# Generated at 2022-06-24 23:24:47.977480
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    var_0 = PkgMgr()
    try:
        var_0.list_installed()
    except:
        assert False, "Abstact method not yet implemented"

# Generated at 2022-06-24 23:24:54.628447
# Unit test for method is_available of class LibMgr

# Generated at 2022-06-24 23:24:55.520413
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    var_0 = CLIMgr()


# Generated at 2022-06-24 23:24:56.386041
# Unit test for constructor of class LibMgr
def test_LibMgr():
    var_1 = LibMgr()


# Generated at 2022-06-24 23:25:02.346365
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    # Initialization of the class type
    temp_PkgMgr = PkgMgr()
    # Testing the abstract method
    if(temp_PkgMgr.get_package_details == None):
        return True;
    else:
        return False;


# Generated at 2022-06-24 23:25:04.275998
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    var_0 = CLIMgr()


# Generated at 2022-06-24 23:25:06.155904
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    test_CLIMgr = CLIMgr()
    # Failing case:


# Generated at 2022-06-24 23:26:28.431034
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    pass


# Generated at 2022-06-24 23:26:31.307961
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():

    pkgmgr = PkgMgr()
    package = int()
    exp = None
    act = pkgmgr.get_package_details(package)
    assert exp == act, "'%s' failed" % inspect.stack()[0][3]


# Generated at 2022-06-24 23:26:32.033451
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    var_0 = CLIMgr()


# Generated at 2022-06-24 23:26:32.783523
# Unit test for constructor of class LibMgr
def test_LibMgr():
    libMgr = LibMgr()


# Generated at 2022-06-24 23:26:34.042419
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    var_1 = LibMgr()
    assert var_1.is_available() == False


# Generated at 2022-06-24 23:26:39.512508
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    try:
        PkgMgr.get_package_details(pkg)
        test_case_0()
    except:
        print ("Exception")
        assert False


# Generated at 2022-06-24 23:26:45.776810
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    var_0 = get_all_pkg_managers()['pkgmgr']().is_available()
    var_0 = get_all_pkg_managers()['climgr']().is_available()
    var_0 = get_all_pkg_managers()['libmgr']().is_available()

# Generated at 2022-06-24 23:26:51.226849
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed(): 
    assert isinstance(PkgMgr.list_installed(PkgMgr), list), \
        "Method 'list_installed' of class 'PkgMgr' returns an object that is not a list."


# Generated at 2022-06-24 23:26:52.606978
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    var_1 = PkgMgr()


# Generated at 2022-06-24 23:26:53.485663
# Unit test for constructor of class LibMgr
def test_LibMgr():
    test_case_0()

test_LibMgr()

# Generated at 2022-06-24 23:30:01.269626
# Unit test for constructor of class LibMgr
def test_LibMgr():
    libMgr = LibMgr()


# Generated at 2022-06-24 23:30:06.411040
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():

    assert True

    # mocker.patch('ansible.module_utils.common.process.get_bin_path', return_value=True)

    # pkgmgr = PkgMgr()
    # result = pkgmgr.list_installed()

    # print(result)



# Generated at 2022-06-24 23:30:11.621342
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    CLIMgr.CLI = 'ansible.module_utils.basic._anaconda_common.list_pkgs'
    assert CLIMgr.is_available() == False
    CLIMgr.CLI = 'ls'
    assert CLIMgr.is_available() == True



# Generated at 2022-06-24 23:30:14.263590
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    var_0 = CLIMgr()
    function_name = "CLIMgr.is_available"

    # test case 0
    # base case
    # test case 1
    # test case 2
    # test case 3



# Generated at 2022-06-24 23:30:17.995499
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    obj = PkgMgr()
    assert obj.get_packages() == {}, "The PkgMgr get_packages implementation doesn't return the default value"


# Generated at 2022-06-24 23:30:18.474253
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    pass

# Generated at 2022-06-24 23:30:19.924674
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    var_0 = PkgMgr()
    var_0.list_installed()


# Generated at 2022-06-24 23:30:21.249375
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    var_1 = PkgMgr.list_installed()


# Generated at 2022-06-24 23:30:23.473656
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pass

# Generated at 2022-06-24 23:30:27.110274
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr().__init__() is None

# Unit tests for constructor of class LibMgr