

# Generated at 2022-06-23 00:27:12.697078
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
  print("List of installed packages by apt-get")
  pkgmgr = PkgMgr()
  pkglist = pkgmgr.list_installed()
  for item in pkglist:
    print(item)


# Generated at 2022-06-23 00:27:14.130574
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    test = CLIMgr()
    assert(test.is_available() == False)

# Generated at 2022-06-23 00:27:15.287547
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    lm = LibMgr()
    assert lm.is_available() == True, 'LibMgr.is_available() should return True'


# Generated at 2022-06-23 00:27:17.893076
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    result = PkgMgr.is_available()
    assert result is None


# Generated at 2022-06-23 00:27:18.522929
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    pass

# Generated at 2022-06-23 00:27:19.499843
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    assert False, "Test not implemented"


# Generated at 2022-06-23 00:27:23.344573
# Unit test for constructor of class LibMgr
def test_LibMgr():

    assert hasattr(LibMgr, 'LIB')

    libmgr = LibMgr()
    assert hasattr(libmgr, '_lib')
    assert libmgr._lib is None


# Generated at 2022-06-23 00:27:25.383768
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    obj = PkgMgr()
    return isinstance(obj, PkgMgr)


# Generated at 2022-06-23 00:27:34.159831
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    import mock
    import ansible.module_utils.common.pkg_mgr as pkg_mgr
    import ansible.module_utils.common.process as process
    import unittest

    class TestCliMgr(pkg_mgr.CLIMgr):
        CLI = 'apt'

    with mock.patch.object(process, 'get_bin_path', return_value='/usr/bin/apt'):
        test_cli_mgr = TestCliMgr()
        assert test_cli_mgr.is_available() == True
        assert test_cli_mgr._cli == '/usr/bin/apt'

    with mock.patch.object(process, 'get_bin_path', side_effect=ValueError):
        test_cli_mgr = TestCliMgr()
        assert test_cli_m

# Generated at 2022-06-23 00:27:35.366459
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    pass


# Generated at 2022-06-23 00:27:45.948931
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    pkg_mgr_obj = PkgMgr()

    class MockPkgMgr(PkgMgr):
        def get_package_details(self, package):
            return {'name': 'nfs-utils', 'version': '2.2.2-5.el7'}

    mock_pkg_mgr_obj = MockPkgMgr()

    # The following test cases will test the working of the
    # get_package_details() method.
    assert pkg_mgr_obj.get_package_details is None
    assert mock_pkg_mgr_obj.get_package_details is not None
    assert mock_pkg_mgr_obj.get_package_details("nfs-utils")['name'] == 'nfs-utils'
    assert mock_pkg_mgr_obj.get_package_details

# Generated at 2022-06-23 00:27:47.247357
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    t = PkgMgr()
    assert t


# Generated at 2022-06-23 00:27:49.534050
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    # return False if the package manager is currently installed/usable
    assert PkgMgr.is_available() == False


# Generated at 2022-06-23 00:27:51.776526
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    CLIMgrInst = CLIMgr()
    CLIMgrInst.CLI = "python"
    assert CLIMgrInst.is_available()

# Generated at 2022-06-23 00:27:54.839891
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    ret = PyPI_LibMgr().is_available()
    if ret is True:
        print("PyPI is available")
    #print("Expected False, got %s"%ret)
    return


# Generated at 2022-06-23 00:27:56.698553
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    if 'manager_details' in globals():
        manager_details.get_package_details(None)


# Generated at 2022-06-23 00:28:08.236531
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pkg_mgrs = get_all_pkg_managers()

# Generated at 2022-06-23 00:28:14.078084
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class FakePkgMgr(PkgMgr):
        def __init__(self):
            self.list_installed = lambda: ['a', 'b', 'c']
            self.get_package_details = lambda x: {'name': x}
    p = FakePkgMgr()
    assert p.get_packages() == {'a': [{'name': 'a'}], 'b': [{'name': 'b'}], 'c': [{'name': 'c'}]}


# Generated at 2022-06-23 00:28:17.209890
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestLibMgr(LibMgr):
        LIB = 'test_LibMgr'
    TestLibMgr()


# Generated at 2022-06-23 00:28:20.692463
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    pkgMgr = CLIMgr()

    assert pkgMgr.is_available() == False

    pkgMgr.CLI = 'python'

    assert pkgMgr.is_available() == True


# Generated at 2022-06-23 00:28:22.374695
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    x = CLIMgr()
    assert(x)
    assert(x._cli is None)


# Generated at 2022-06-23 00:28:25.953260
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class CLIMgrTest(CLIMgr):
        CLI = 'pip'
    assert CLIMgrTest().is_available()



# Generated at 2022-06-23 00:28:26.531780
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr()

# Generated at 2022-06-23 00:28:37.887069
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    try:
        import nose2
        from nose2.tools import params
    except ImportError:
        import nose
        from nose.tools import params

    class TestPkgMgr(PkgMgr):

        def is_available(self):
            pass

        def list_installed(self):
            pass

        def get_package_details(self, package=dict(name="pkg_name", version="3.2.1")):
            return package

    @params('pkg_name', 'pkg_name-3.2.1', 'pkg_name-3.2.1-1.el6', 'pkg_name-3.2.1-1.el6.x86_64')
    def test_get_package_details(package_name):
        pkg_mgr = TestPkgMgr()
        pkg_details

# Generated at 2022-06-23 00:28:40.108268
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class Test(LibMgr):
        LIB = "test"

    obj = Test()
    assert obj._lib is None


# Generated at 2022-06-23 00:28:47.696997
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    # The test class is not abstract and can be instantiated
    class DummyCLIMgr(CLIMgr):
        CLI = 'dummy'

    # The CLI command does not exist
    dummy_mgr = DummyCLIMgr()
    assert not dummy_mgr.CLI
    assert not dummy_mgr.is_available()

    # The CLI command does exists
    import os
    dummy_path = '/tmp/'
    dummy_file = 'dummy'
    dummy = os.path.join(dummy_path, dummy_file)
    os.system('touch %s' % dummy)
    assert os.path.exists(dummy)

    dummy_mgr = DummyCLIMgr()
    assert dummy_mgr.CLI == dummy_file
    assert dummy_mgr._cli == dummy
    assert dummy

# Generated at 2022-06-23 00:28:48.772743
# Unit test for constructor of class PkgMgr
def test_PkgMgr():

    assert(PkgMgr)


# Generated at 2022-06-23 00:28:54.205583
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():

    # This is not an actual unit test, just a test that we can retrieve the known package managers
    # The aim of this test is to fail when a new package manager is added so that 'get_all_pkg_managers' is updated as well
    assert 'apt_pkg' == get_all_pkg_managers()['apt_pkg'].__name__

# Generated at 2022-06-23 00:28:59.636665
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():

    # Test case: successful import of python module
    my_pkg_mgr = LibMgr()
    my_pkg_mgr.LIB = "test_mock_lib_module_for_PkgMgr"
    assert my_pkg_mgr.is_available()

    # Test case: unsuccessful import of python module
    my_pkg_mgr = LibMgr()
    my_pkg_mgr.LIB = "this_is_not_a_valid_python_module"
    assert not my_pkg_mgr.is_available()

# Generated at 2022-06-23 00:29:06.066255
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():

    pm_classes = get_all_pkg_managers().values()
    for pm_class in pm_classes:
        pm = pm_class()
        if not pm.is_available():
            print("WARNING: %s not available" % (pm_class.__name__))
            continue
        print(pm.list_installed())


# Generated at 2022-06-23 00:29:08.410943
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():

    # Assert that get_all_pkg_managers() returns a dict
    assert isinstance(get_all_pkg_managers(), dict)


# Generated at 2022-06-23 00:29:09.982817
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    assert get_all_pkg_managers()['pkggem']().list_installed() is not None

# Generated at 2022-06-23 00:29:14.247784
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    classes = get_all_pkg_managers()
    for name, cls in classes.items():
        assert isinstance(cls, PkgMgr)
        assert hasattr(cls, '__name__')
        assert cls.__name__.lower() == name

# Generated at 2022-06-23 00:29:19.035069
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    class TestPkgMgr(PkgMgr):
        def __init__(self):
            super(TestPkgMgr, self).__init__()

    pkg_mgr = TestPkgMgr()
    assert pkg_mgr


# Generated at 2022-06-23 00:29:22.143766
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    mangary = get_all_pkg_managers()
    assert type(mangary) is dict
    for value in mangary.values():
        assert type(value) is type

# Generated at 2022-06-23 00:29:24.156949
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    import apt
    test_class = apt.AptPkgMgr()
    test_class.list_installed()

# Generated at 2022-06-23 00:29:29.496313
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    """Unit test for method is_available of class LibMgr"""
    class TestLibMgr(LibMgr):
        LIB = 'test_import'

    assert TestLibMgr().is_available() is True
    assert TestLibMgr.is_available(TestLibMgr()) is True
    assert TestLibMgr.is_available(TestLibMgr) is False


# Generated at 2022-06-23 00:29:34.112045
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class testLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.collector.os'

    test_object = testLibMgr()
    test_object.is_available()
    assert test_object._lib is not None


# Generated at 2022-06-23 00:29:35.063034
# Unit test for constructor of class LibMgr
def test_LibMgr():
    pass


# Generated at 2022-06-23 00:29:44.535664
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    print(">>>>>>> Unit test for method list_installed of class PkgMgr")

    from ansible.module_utils.package_manager.pip_manager import PipPkgMgr
    pkg_mgr = PipPkgMgr()

    if not pkg_mgr.is_available():
        print("No pip install in this environment, skip this test")
        return

    installed_packages = pkg_mgr.list_installed()
    assert installed_packages
    for package in installed_packages:
        print(package)


# Generated at 2022-06-23 00:29:49.651114
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():

    assert 'pip' in get_all_pkg_managers()
    assert 'apt' in get_all_pkg_managers()


# Load all subclasses from package manager modules
from . import apt
from . import dpkg
from . import git
from . import yum
from . import zypper
from . import pip

# Generated at 2022-06-23 00:29:54.173220
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    class testCLIMgr(CLIMgr):
        CLI = 'python2.7'

    obj = CLIMgr()
    assert obj.is_available() == False

    obj = testCLIMgr()
    assert obj.is_available() == True
    assert obj._cli.endswith('python2.7')



# Generated at 2022-06-23 00:29:56.303098
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    for obj in get_all_pkg_managers():
        test = get_all_pkg_managers()[obj].list_installed()
        assert (isinstance(test, list))


# Generated at 2022-06-23 00:29:57.520312
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pBase = PkgMgr()
    assert pBase.list_installed() is None

# Generated at 2022-06-23 00:29:59.673667
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr.CLI == None
    assert CLIMgr().CLI == None
    assert CLIMgr()._cli == None


# Generated at 2022-06-23 00:30:00.666508
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    assert isinstance(PkgMgr(), object)

# Generated at 2022-06-23 00:30:02.335741
# Unit test for constructor of class LibMgr
def test_LibMgr():

    obj = LibMgr()
    assert isinstance(obj, LibMgr)


# Generated at 2022-06-23 00:30:09.078341
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    # Stub class, the is_available method is not an abstract method in PkgMgr, so it can be overriden
    class StubMgr(PkgMgr):
        def is_available(self):
            return True

        # Empty methods, don't do anything
        def list_installed(self):
            pass
        def get_package_details(self, package):
            pass

    mgr = StubMgr()
    assert mgr.get_packages() == {}, "get_packages still needs to be implemented"

# Generated at 2022-06-23 00:30:19.757281
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    myCLIMgr = CLIMgr()
    assert myCLIMgr._cli is None
    assert myCLIMgr.CLI is not None

    # test method get_bin_path
    # path = '/usr/bin/yum'
    # class mock_exception(Exception):
    #     pass
    #
    # class mock_get_bin_path:
    #     path = None
    #     def mock_get_bin_path(s):
    #         if s == path:
    #             return s
    #         else:
    #             raise mock_exception
    #
    # def test_get_bin_path():
    #     path = '/usr/bin/yum'
    #     assert get_bin_path(path) == path
    #
    #     try:
    #         get_

# Generated at 2022-06-23 00:30:23.753451
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    result = get_all_pkg_managers()
    assert 'aptpkg' in result
    assert 'dnf' in result
    assert 'zypp' in result
    assert 'yumpkg' in result
    assert 'apkg' in result

# Generated at 2022-06-23 00:30:29.532533
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():

    from ansible.module_utils.common.ansible_pkg_mgrs import get_all_pkg_managers

    pkg_managers = get_all_pkg_managers()

    assert pkg_managers
    assert 'apt' in pkg_managers
    assert 'yum' in pkg_managers
    assert 'dnf' in pkg_managers
    assert 'zypper' in pkg_managers

# Generated at 2022-06-23 00:30:42.082873
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            file=dict(type='path'),
            name=dict(type='str')
        )
    )

    found_package = None
    pkg_managers = get_all_pkg_managers()
    for pkg_mgr in pkg_managers.values():
        mgr = pkg_mgr()
        if mgr.is_available():
            if mgr.list_installed():
                found_package = mgr.list_installed()[0]
                break

    if not found_package:
        module.fail_json(msg='No packages were found for testing - this should not happen')

    package_details = mgr.get_package_details(found_package)
    module

# Generated at 2022-06-23 00:30:46.367255
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():

    from ansible.module_utils.facts.system.pip import PipMgr

    pip_mgr = PipMgr()
    pip_mgr_is_available = pip_mgr.is_available()
    assert 'pip' in pip_mgr.LIB
    assert isinstance(pip_mgr_is_available, bool)


# Generated at 2022-06-23 00:30:53.329738
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():

    # Test that it returns a dict of classes
    assert isinstance(get_all_pkg_managers(), dict)
    assert 'apk' in get_all_pkg_managers()
    assert 'apt' in get_all_pkg_managers()
    assert 'yum' in get_all_pkg_managers()
    assert 'dnf' in get_all_pkg_managers()
    assert get_all_pkg_managers()['apk'].__name__ == 'APK'
    assert get_all_pkg_managers()['apt'].__name__ == 'DPKG'
    assert get_all_pkg_managers()['yum'].__name__ == 'Yum'
    assert get_all_pkg_managers()['dnf'].__name__ == 'DNF'



# Generated at 2022-06-23 00:30:56.793147
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    pm = PkgMgr()
    rval = pm.get_package_details('test_package')
    if 'name' in rval and 'version' in rval:
        return 0
    else:
        return 1

# Generated at 2022-06-23 00:31:00.465676
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    pkg_mgr_classes = get_all_pkg_managers()
    assert type(pkg_mgr_classes) is dict
    assert 'dnf' in pkg_mgr_classes
    assert issubclass(pkg_mgr_classes['dnf'], PkgMgr)

# Generated at 2022-06-23 00:31:02.560364
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    for cls in get_all_pkg_managers().values():
        assert isinstance(cls().is_available(), bool)

# Generated at 2022-06-23 00:31:06.290807
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    assert isinstance(PkgMgr().is_available(), bool)
    assert isinstance(LibMgr().is_available(), bool)
    assert isinstance(CLIMgr().is_available(), bool)

# Generated at 2022-06-23 00:31:10.668917
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class test_PkgMgr(PkgMgr):
        def get_package_details(self, package):
            return package
    assert 'a' == test_PkgMgr().get_package_details('a')


# Generated at 2022-06-23 00:31:12.498132
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    """
    Unit test to check method is_available of class LibMgr

    :return:
    """
    pass

# Generated at 2022-06-23 00:31:15.069235
# Unit test for constructor of class LibMgr
def test_LibMgr():
    temp_lib_mgr = LibMgr()
    temp_lib_mgr._lib = "data"
    assert temp_lib_mgr._lib == "data"


# Generated at 2022-06-23 00:31:19.601010
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    p = PkgMgr()
    try:
        p.list_installed()
    except NotImplementedError:
        pass
    else:
        assert False, "list_installed() is not implemented"


# Generated at 2022-06-23 00:31:27.661620
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    class TestPkgMgr1(PkgMgr):
        def __init__(self):
            super(TestPkgMgr1, self).__init__()

        def list_installed(self):
            return ['TestPackage1', 'TestPackage2', 'TestPackage3']

        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}

    obj = TestPkgMgr1()
    assert obj.list_installed() == ['TestPackage1', 'TestPackage2', 'TestPackage3']


# Generated at 2022-06-23 00:31:39.062728
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    from nose import with_setup
    from mock import patch, PropertyMock
    from io import StringIO

    with patch.multiple('ansible.module_utils.common.pkg_utils',
       list_installed=PropertyMock(return_value=['fake1', 'fake2']),
       get_package_details=PropertyMock(return_value=dict(name='fake', version='1.0.0'))
    ):
        pkg_mgr = PkgMgr()
        installed_packages = pkg_mgr.get_packages()
        assert type(installed_packages) == dict
        assert len(installed_packages) == 1
        assert 'fake' in installed_packages
        assert installed_packages['fake'][0]['version'] == '1.0.0'

# Generated at 2022-06-23 00:31:40.791411
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pm = PkgMgr
    assert pm.list_installed is not None


# Generated at 2022-06-23 00:31:43.685357
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    mgr = CLIMgr()
    assert mgr.is_available() == False


# Generated at 2022-06-23 00:31:45.431255
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    assert get_all_pkg_managers()["apt"].is_available() == True

# Generated at 2022-06-23 00:31:55.161105
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class TestPkgMgr(PkgMgr):
        def __init__(self):
            self.test_data = [{"package": '{"name":"test","version":"1.0"}'}, {"package": '{"name":"test","version":"2.0"}'}]

        def list_installed(self):
            return self.test_data

        def get_package_details(self, package):
            return package

    pkg_mgr_test_obj = TestPkgMgr()
    assert (pkg_mgr_test_obj.get_packages() == {'test': [{'package': '{"name":"test","version":"1.0"}'}, {'package': '{"name":"test","version":"2.0"}'}]})


# Generated at 2022-06-23 00:31:55.989343
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    assert False

# Generated at 2022-06-23 00:31:57.784230
# Unit test for constructor of class LibMgr
def test_LibMgr():
    test_class = LibMgr()
    assert test_class._lib is None


# Generated at 2022-06-23 00:32:00.241408
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    assert hasattr(LibMgr, 'is_available'), "Method 'is_available' is missing"


# Generated at 2022-06-23 00:32:02.969914
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    """Unit test for constructor of class PkgMgr"""
    # No parameters passed
    obj = PkgMgr()


# Generated at 2022-06-23 00:32:05.009375
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    import subprocess
    assert subprocess.call(['ansible-test', 'units', __file__, '-vv']) == 0

# Generated at 2022-06-23 00:32:09.020858
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    from ansible.module_utils.common._collections_compat import Mapping
    package = PkgMgr()
    packages = package.get_package_details("")
    assert isinstance(packages, Mapping)

# Generated at 2022-06-23 00:32:14.576957
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    # pick a manager
    pm = PkgMgr()
    pm._lib = { }                 # replace the library methods
    pm._cli = { }                 # replace the cli methods
    pm.__class__.__name__.lower() # replace the class name

    # stub the methods
    pm._lib.list_installed.return_value = "this is the list of installed packages"
    pm._lib.get_package_details.return_value = "this is a dictionary with the package information"

    # check if the package manager is available
    if not pm.is_available():
        # package manager is not available
        assert False

    # check if the list of installed packages is available
    installed_packages = pm.list_installed()
    if not installed_packages:
        # nothing installed on the system
        assert False

    # loop over all

# Generated at 2022-06-23 00:32:19.878710
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():

    class LibMgrTest(LibMgr):

        LIB = ''

    # ImportError
    lm = LibMgrTest()
    assert lm.is_available() is False

    # no exception
    LibMgrTest.LIB = 'os'
    assert lm.is_available() is True


# Generated at 2022-06-23 00:32:21.479191
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    assert len(get_all_pkg_managers()) > 0

# Generated at 2022-06-23 00:32:24.140311
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():

    pm = PkgMgr()
    print("Please test method get_package_details of class PkgMgr")



# Generated at 2022-06-23 00:32:26.365947
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestMgr(CLIMgr):
        CLI = 'test_CLI'

    assert TestMgr().is_available() == True

# Generated at 2022-06-23 00:32:28.448454
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    # check if class PkgMgr is created
    assert PkgMgr


# Generated at 2022-06-23 00:32:34.674138
# Unit test for method is_available of class LibMgr

# Generated at 2022-06-23 00:32:39.765920
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    from ansible.module_utils.common.os.pkgmgr.apt import AptMgr
    from ansible.module_utils.common.os.pkgmgr.yum import YumMgr

    expected = {
        'aptmgr': AptMgr,
        'yummgr': YumMgr,
    }
    assert get_all_pkg_managers().keys() == expected.keys()
    assert get_all_pkg_managers().values() == expected.values()

# Generated at 2022-06-23 00:32:40.983671
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    assert(isinstance(PkgMgr(), object))

# Generated at 2022-06-23 00:32:52.330299
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    assert get_all_pkg_managers()['apt']().is_available()
    assert get_all_pkg_managers()['portage']().is_available()
    assert get_all_pkg_managers()['dnf']().is_available()

    pkgs = get_all_pkg_managers()
    dummy_pkgs = ["python3", "python2", "python", "python-pytest"]

    # Method is supposed to return a dict with info on each passed package
    # Name and version are minimum requirements
    for pkg in dummy_pkgs:
        for manager in pkgs:
            package_details = pkgs[manager]().get_package_details(pkg)
            assert type(package_details) == dict
            assert 'name' in package_details
            assert 'version' in package_

# Generated at 2022-06-23 00:32:57.372171
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():

    from ansible.module_utils import basic

    all_pkg_managers = get_all_pkg_managers()
    assert isinstance(all_pkg_managers, dict)
    for name, pkg_mgr in all_pkg_managers.items():
        assert isinstance(pkg_mgr, PkgMgr)
        assert issubclass(pkg_mgr, PkgMgr)



# Generated at 2022-06-23 00:32:58.906248
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class Test_(LibMgr):

        LIB = 'os'

    assert Test_()._lib is None


# Generated at 2022-06-23 00:33:10.241766
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class PkgMgrTest(PkgMgr):
        def is_available(self):
            pass

        def list_installed(self):
            return ['package1', 'package2']

        def get_package_details(self, package):
            return {'name': package, 'version': '1.0', 'release': '1'}

    pkgmgr = PkgMgrTest()
    pkg = pkgmgr.get_packages()
    assert(len(pkg) == 2)
    assert('package1' in pkg and 'package2' in pkg)
    for i in range(2):
        assert(len(pkg['package1']) == 1)

# Generated at 2022-06-23 00:33:18.905739
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class PkgMgrTest(PkgMgr):
        def list_installed(self):
            return ['package1', 'package2', 'package3']

        def get_package_details(self, package):
            return {'name': package, 'version': '2.0'}

    pmt = PkgMgrTest()
    pkgs = pmt.get_packages()
    assert pkgs['package3'][0]['name'] == 'package3'
    assert pkgs['package3'][0]['version'] == '2.0'

# Generated at 2022-06-23 00:33:30.799499
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    from os import remove
    from os.path import join
    from tempfile import mkdtemp
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six.moves import configparser

    # Writing a dummy executable file
    temp_dir = mkdtemp()
    file_path = join(temp_dir, "iam_dummy_cli_mgr")
    with open(file_path, 'w') as f:
        f.write(to_bytes(''))

    # Writing a dummy module
    # ConfigParser was chosen because it will not work on windows if the file is not a valid ini file
    config = configparser.ConfigParser()
    config.add_section('ansible')
    config.set('ansible', 'CACHE_PLUGIN', 'jsonfile')
    config

# Generated at 2022-06-23 00:33:32.101045
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    result = get_all_pkg_managers()
    assert isinstance(result, dict)

# Generated at 2022-06-23 00:33:33.614435
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    pkg = PkgMgr()
    assert pkg is not None


# Generated at 2022-06-23 00:33:37.412370
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():

    for pkgmgr in get_all_pkg_managers().values():
        assert pkgmgr.__bases__[0] == PkgMgr


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-23 00:33:41.192964
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    lib = LibMgr()
    lib.LIB = 'os'
    assert lib.is_available() == True
    lib.LIB = 'not_a_real_library'
    assert lib.is_available() == False


# Generated at 2022-06-23 00:33:44.528415
# Unit test for constructor of class CLIMgr
def test_CLIMgr():

    # A class with no CLI attribute defined
    class CLIMgrTest(CLIMgr):
        pass
    test_cli_mgr = CLIMgrTest()

    # Test that it returns false
    assert test_cli_mgr.is_available() is False

# Generated at 2022-06-23 00:33:50.452983
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    from ansible.module_utils.facts.pkg_mgr import get_all_pkg_managers
    pkg_managers = get_all_pkg_managers()
    assert 'apt' in pkg_managers
    assert 'dnf' in pkg_managers
    assert 'freebsd_pkg' in pkg_managers
    assert 'pacman' in pkg_managers
    assert 'pip' in pkg_managers

# Generated at 2022-06-23 00:33:52.090465
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr().is_available() is False

# Generated at 2022-06-23 00:33:54.194982
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    with pytest.raises(TypeError):
        PkgMgr().is_available()


# Generated at 2022-06-23 00:33:59.656932
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    # An instance of CLIMgr without CLI set
    apt = CLIMgr()
    assert apt._cli is None
    assert apt.is_available() is False

    # An instance of CLIMgr with CLI set
    apt = CLIMgr()
    apt.CLI = 'fake'
    assert apt.is_available() is False

# Generated at 2022-06-23 00:34:01.503941
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
 
    assert LibMgr().is_available() == False


# Generated at 2022-06-23 00:34:08.942416
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    pm = PkgMgr()
    installed_packages = {'abc': [{'name': 'abc', 'version': '1.0.0'}, {'name': 'abc', 'version': '1.1.0'}]}
    pm.list_installed = lambda: ['abc']
    pm.get_package_details = lambda package: {'name': 'abc', 'version': '1.0.0'}
    assert pm.get_packages() == installed_packages

# Generated at 2022-06-23 00:34:13.616612
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    test_mgr = PkgMgr()
    pkg_mgrs = get_all_pkg_managers()
    assert list(pkg_mgrs.keys()) == ['pkgmgr']
    assert pkg_mgrs['pkgmgr'].__name__ == 'PkgMgr'
    assert pkg_mgrs['pkgmgr'].is_available() == False

# Generated at 2022-06-23 00:34:19.618438
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class BasePkgMgr(PkgMgr):
        def is_available(self):
            return False
        def list_installed(self):
            return []
        def get_package_details(self, package):
            return {}
    cp = BasePkgMgr()
    assert cp.get_packages() == {}


# Unit tests for all PkgMgr subclasses

# Generated at 2022-06-23 00:34:24.678463
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    # one has the binary
    cm = CLIMgr()
    cm.CLI = 'cat'
    assert cm.is_available()
    # won't find a non-existent binary
    cm.CLI = 'not-a-real-binary'
    assert not cm.is_available()


# Generated at 2022-06-23 00:34:27.259852
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class AlibMgr(LibMgr):
        LIB = "asdfasdf"

    assert not AlibMgr().is_available()



# Generated at 2022-06-23 00:34:28.523419
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pkgMgr = PkgMgr()
    assert pkgMgr.list_installed() is None


# Generated at 2022-06-23 00:34:32.617833
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    # Create a LibMgr object
    lm1 = LibMgr()
    # Assign a value to the class attribute LIB
    LibMgr.LIB = "cffi"
    # Call the is_available method. It should return True
    assert(lm1.is_available())
    return True


# Generated at 2022-06-23 00:34:37.771801
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    class TestPkgMgr(PkgMgr):
        def __init__(self):
            super(TestPkgMgr, self).__init__()
        def list_installed(self):
            pass
        def get_package_details(self, pkg):
            pass
    obj = TestPkgMgr()
    try:
        obj.is_available()
    except NotImplementedError:
        pass


# Generated at 2022-06-23 00:34:48.706990
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    pkg_mgrs = get_all_pkg_managers()
    assert 'apt' in pkg_mgrs
    assert 'apk' in pkg_mgrs
    assert 'yum' in pkg_mgrs
    assert 'dnf' in pkg_mgrs
    assert 'pkgng' in pkg_mgrs
    assert 'emerge' in pkg_mgrs
    assert 'pacman' in pkg_mgrs
    assert 'pkg5' in pkg_mgrs
    assert 'pip' in pkg_mgrs
    assert 'pkgin' in pkg_mgrs
    assert 'rpm' in pkg_mgrs
    assert 'ports' in pkg_mgrs
    assert 'xbps' in pkg_mgrs
   

# Generated at 2022-06-23 00:34:51.513200
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    for package_manager in get_all_pkg_managers().values():
        if package_manager().is_available():
            package_manager().list_installed()



# Generated at 2022-06-23 00:34:53.808510
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    pm = PkgMgr()
    assert pm

# Generated at 2022-06-23 00:34:54.812071
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    assert CLIMgr() is not None

# Generated at 2022-06-23 00:34:55.925232
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    return False

# Generated at 2022-06-23 00:34:57.891841
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    results = get_all_pkg_managers()
    assert('dpkg' in results)

# Generated at 2022-06-23 00:35:05.399882
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True

        def list_installed(self):
            return ["package1", "package2"]

        def get_package_details(self, package):
            return {"name": package, "version": "1.0.0"}

    pkg = TestPkgMgr()
    installed_packages = pkg.get_packages()
    assert "package1" in installed_packages
    assert "package2" in installed_packages
    assert installed_packages["package1"][0]["version"] == "1.0.0"

# Generated at 2022-06-23 00:35:11.602442
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    """
    Searches all subclasses of PkgMgr and tests if the list_installed method returns a list.
    Returns a list of failed tests.
    """
    failed = []
    for cls_name, cls in get_all_pkg_managers().items():
        pkg_inst = cls()
        if pkg_inst.is_available():
            if not isinstance(pkg_inst.list_installed(), (list)):
                failed.append("%s.list_installed() returns not a list" % cls_name)
    return failed


# Generated at 2022-06-23 00:35:17.580358
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['test_package']
        def get_package_details(self, package):
            return {'name': package, 'version':42}

    pkgmgr = TestPkgMgr()
    assert(pkgmgr.is_available() == True)


# Generated at 2022-06-23 00:35:23.297307
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class PkgMgr_My(PkgMgr):
        def is_available(self):
            raise NotImplementedError()
        def list_installed(self):
            raise NotImplementedError()
        def get_package_details(self, package):
            raise NotImplementedError()
    pm = PkgMgr_My()
    assert pm.get_packages() == {}

# Generated at 2022-06-23 00:35:23.897852
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():

	pass

# Generated at 2022-06-23 00:35:26.072422
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    myCLIMgr = CLIMgr()
    assert isinstance(myCLIMgr, CLIMgr)

# Generated at 2022-06-23 00:35:35.662536
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    """
    This test is based on a test for the old method get_all_package_names_from_facts of module_utils.facts_collection
    """

    class PkgMgrEmpty(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return []
        def get_package_details(self, package):
            return {}

    assert PkgMgrEmpty().get_packages() == {}

    class PkgMgrMultiple(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return []
        def get_package_details(self, package):
            return {'name': 'foo', 'version': '1.2.3'}


# Generated at 2022-06-23 00:35:37.169526
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    with pytest.raises(NotImplementedError):
        PkgMgr().list_installed()


# Generated at 2022-06-23 00:35:40.383184
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    from ansible.module_utils.common.collector import LibMgr
    lib_mgr = LibMgr()
    assert lib_mgr.is_available() == False


# Generated at 2022-06-23 00:35:48.657250
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    import json
    import sys
    import os

    from ansible.module_utils.common.text.formatters import human_to_bytes
    # check for python 3
    pkg_managers = get_all_pkg_managers()
    if sys.version_info >= (3, 0):
        for pkg_manager in pkg_managers:
            manager_instance = pkg_managers[pkg_manager]()
            assert manager_instance.is_available() is not None, "This projecet needs the package {}".format(pkg_manager)

    available = True
    if sys.version_info <= (2, 7):
        try:
            import rpm  # noqa
        except ImportError:
            available = False
        assert available, "This project needs python-rpm package"


# Generated at 2022-06-23 00:35:58.196591
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    all_pkg_managers = get_all_pkg_managers()
    assert 'deb' in all_pkg_managers
    assert 'pacman' in all_pkg_managers
    assert 'portage' in all_pkg_managers
    assert 'pkg5' in all_pkg_managers
    assert 'pkgng' in all_pkg_managers
    assert 'slackpkg' in all_pkg_managers
    assert 'rpm' in all_pkg_managers
    assert 'zypper' in all_pkg_managers
    assert 'dnf' in all_pkg_managers
    assert 'yum' in all_pkg_managers
    assert 'apt' in all_pkg_managers
    assert 'pkgutil' in all_pkg_managers
    assert 'sw_vers' in all_pkg_managers


# Generated at 2022-06-23 00:36:01.923077
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pmgr = PkgMgr()
    try:
        pmgr.list_installed()
    except NotImplementedError as e:
        print(e)


# Generated at 2022-06-23 00:36:09.133623
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    class TestPkgmgr(PkgMgr):
        def list_installed(self):
            pass
        def get_package_details(self, package):
            pass

    test_pkgmgr = TestPkgmgr()

    test_pkgmgr.is_available = lambda: True
    assert test_pkgmgr.is_available() == True
    test_pkgmgr.is_available = lambda: False
    assert test_pkgmgr.is_available() == False



# Generated at 2022-06-23 00:36:10.653154
# Unit test for constructor of class PkgMgr
def test_PkgMgr():

    p = PkgMgr()


# Generated at 2022-06-23 00:36:13.633170
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():

    assert(PkgMgr.is_available(PkgMgr)) == False


# Generated at 2022-06-23 00:36:15.477311
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    pkgmgr = PkgMgr()
    pkgmgr.is_available()


# Generated at 2022-06-23 00:36:18.433093
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    from ansible.module_utils.common.process import get_bin_path
    class Dummy(CLIMgr):
        CLI = 'ls'

    assert Dummy().is_available() == True
    assert Dummy()._cli == get_bin_path('ls')

# Generated at 2022-06-23 00:36:20.193786
# Unit test for constructor of class LibMgr
def test_LibMgr():
    try:
        P = LibMgr()
    except ImportError:
        # This is ok, we just won't have support for this class
        pass
    except:
        raise

# Generated at 2022-06-23 00:36:22.071419
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    check_CLI = CLIMgr()
    assert check_CLI

# Generated at 2022-06-23 00:36:29.472278
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class LibTest(LibMgr):
        LIB = 'sys'
        def list_installed(self):
            return []
        def get_package_details():
            return {}
    mgr = LibTest()
    assert mgr.is_available() == True
    class LibTest2(LibMgr):
        LIB = 'bad_name'
        def list_installed(self):
            return []
        def get_package_details():
            return {}
    mgr = LibTest2()
    assert mgr.is_available() == False


# Generated at 2022-06-23 00:36:33.835110
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class foo(LibMgr):
        LIB = 'grp'
    assert foo().is_available() == True
    # import grp imported, not existing lib:
    class foo(LibMgr):
        LIB = 'gr7'
    assert foo().is_available() == False


# Generated at 2022-06-23 00:36:41.453383
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    # this is a dummy class to test the PkgMgr class
    class Dummy_PkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['p1', 'p2', 'p3', 'p4', 'p5']

# Generated at 2022-06-23 00:36:42.140702
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    return True

# Generated at 2022-06-23 00:36:45.491593
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    test_LibMgr = LibMgr()
    if test_LibMgr.is_available() == True:
        print("Test: Passed")
    else:
        print("Test failed")


# Generated at 2022-06-23 00:36:48.809992
# Unit test for constructor of class LibMgr
def test_LibMgr():
    libmgr = LibMgr()
    assert libmgr
    assert hasattr(libmgr, '_lib')
    assert libmgr._lib is None


# Generated at 2022-06-23 00:36:50.708002
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    p = PkgMgr()
    assert hasattr(p, "list_installed")


# Generated at 2022-06-23 00:36:51.527463
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    pass


# Generated at 2022-06-23 00:36:55.167553
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pkg_mgr = PkgMgr()
    assert pkg_mgr.list_installed() is None


# Generated at 2022-06-23 00:37:00.565942
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCLIMgr(CLIMgr):
        CLI = 'no_cmd_exists'
    cli_pkg_mgr = TestCLIMgr()
    assert not cli_pkg_mgr.is_available()


# Generated at 2022-06-23 00:37:02.390081
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    class_object = CLIMgr()
    assert class_object._cli is None


# Generated at 2022-06-23 00:37:07.501603
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    # class PkgMgr is an ABC, instantiating it should raise TypeError
    try:
        obj = PkgMgr()
    except TypeError:
        pass
    except Exception:
        raise Exception("Instantiation of class PkgMgr without abstract methods should raise TypeError")
    else:
        raise Exception("Instantiation of class PkgMgr without abstract methods should raise TypeError")


# Generated at 2022-06-23 00:37:10.656608
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestClass(LibMgr):
        LIB = "toto"

    test1 = TestClass()
    test1.is_available()