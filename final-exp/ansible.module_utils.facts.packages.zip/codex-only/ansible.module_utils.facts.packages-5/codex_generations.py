

# Generated at 2022-06-23 00:27:04.460432
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    p = PkgMgr()
    assert p.get_package_details('crud') == {}


# Generated at 2022-06-23 00:27:15.383294
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    import platform
    if platform.system() == 'Darwin':
        from ansible_collections.misc.not_a_real_collection.plugins.module_utils.packaging.os_package_manager import DarwinPkg
        xPkgMgr = DarwinPkg()
    elif platform.system() == 'Linux':
        from ansible_collections.misc.not_a_real_collection.plugins.module_utils.packaging.os_package_manager import LinuxPkg
        xPkgMgr = LinuxPkg()
    else:
        raise Exception("test_PkgMgr_get_package_details: not able to run the test on this platform")
    #
    # Test if the dictionary contains the key 'version'
    #
    print('Test if the dictionary contains the key "version"')
    package = xPkgM

# Generated at 2022-06-23 00:27:18.757359
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestLibMgr(LibMgr):
        pass

    lib_test = TestLibMgr()
    assert lib_test._lib is None


# Generated at 2022-06-23 00:27:29.292776
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgr, CLIMgr
    import sys
    import pytest
    class TestCLIMgr(CLIMgr):
        # noinspection PyAbstractClass
        class TestPkgMgr(PkgMgr):
            CLI = "test_pkg_mgr"
            def __init__(self):
                super(__class__,self).__init__()

            def is_available(self):
                return True

            def list_installed(self):
                return ["a", "b", "c"]

            def get_package_details(self, package):
                return {"name": package}
    t=TestCLIMgr.TestPkgMgr()
    res=t.get_packages()
    assert "a" in res
    assert "b"

# Generated at 2022-06-23 00:27:30.825231
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    mgr = CLIMgr()
    assert mgr._cli is None


# Generated at 2022-06-23 00:27:33.210963
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    class TestCLIMgr(CLIMgr):
        CLI = 'test'
    assert TestCLIMgr().is_available() == False


# Generated at 2022-06-23 00:27:36.172268
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    from . import pkg_mgr_macports
    from . import pkg_mgr_homebrew
    pkgmgr = PkgMgr()
    assert pkgmgr

# Generated at 2022-06-23 00:27:45.119402
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    print("test_PkgMgr_list_installed")

    for pkg_mgr in get_all_pkg_managers().values():
        print("testing: %s" % pkg_mgr.__name__)
        try:
            instance = pkg_mgr()
            if  instance.is_available():
                result = instance.list_installed()
                print("result: %s" % result)
            else:
                print("%s not available on this system" % pkg_mgr.__name__)
        except Exception as e:
            print("%s raised an exception %s" % (pkg_mgr.__name__, e))


# Generated at 2022-06-23 00:27:46.345820
# Unit test for constructor of class LibMgr
def test_LibMgr():
    pm = LibMgr()


# Generated at 2022-06-23 00:27:50.676612
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    class SamplePkgMgr(PkgMgr):
        def is_available(self):
            return False

        def list_installed(self):
            return None

        def get_package_details(self, package):
            return None
    assert SamplePkgMgr.__name__.lower() in get_all_pkg_managers()

# Generated at 2022-06-23 00:27:52.866471
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    expected_ans = False
    mgr = CLIMgr()
    actual_ans = mgr.is_available()
    assert actual_ans == expected_ans

# Generated at 2022-06-23 00:27:54.694424
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    for mgr in get_all_pkg_managers():
        assert mgr().is_available()

# Generated at 2022-06-23 00:27:57.422132
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    # Checks if given path of command is present in PATH variable
    # If we are unable to find executable then it fails, otherwise passes
    assert CLIMgr().is_available() == True

# Generated at 2022-06-23 00:28:02.033581
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    """
    test_LibMgr_is_available
    """
    lm=LibMgr()
    lm.LIB="testdata_fail"
    assert lm.is_available() is False
    lm.LIB="testdata_pass"
    assert lm.is_available() is True


# Generated at 2022-06-23 00:28:04.503673
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    mpm = CLIMgr()
    assert(mpm is not None)


# Generated at 2022-06-23 00:28:08.083771
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():

    class LibMgrTest(LibMgr):

        LIB = 'unittest.mock'

    manager = LibMgrTest()
    is_available = manager.is_available()

    assert is_available == True


# Generated at 2022-06-23 00:28:10.744511
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    results = get_all_pkg_managers()
    assert isinstance(results, dict)
    assert 'pkg_mgr_cli_test' in results


# Generated at 2022-06-23 00:28:11.959320
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    pm = CLIMgr()
    assert(pm) is not None


# Generated at 2022-06-23 00:28:15.351251
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    class MockPkgMgr(PkgMgr):
        def __init__(self):
            super(MockPkgMgr, self).__init__()

        def is_available(self):
            return True
    obj = MockPkgMgr()
    result = obj.is_available()
    assert result is True


# Generated at 2022-06-23 00:28:19.579760
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    try:
        x = PkgMgr()
    except TypeError:
        print("constructor of class PkgMgr works correctly")
    else:
        raise RuntimeError("constructor of class PkgMgr failed to raise TypeError")
    print("")


# Generated at 2022-06-23 00:28:21.542306
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    assert len(get_all_pkg_managers()) > 0

# Generated at 2022-06-23 00:28:24.299673
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    package_manager = get_all_pkg_managers().values()[0]
    assert package_manager().is_available()


# Generated at 2022-06-23 00:28:33.403450
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class TestPkgMgr(PkgMgr):
        def list_installed(self):
            return []
        def get_package_details(self, pkg):
            return {'name': 'foo', 'version': 'bar', 'source': 'baz'}

    p = TestPkgMgr()
    result = p.get_package_details({'name': 'foo'})
    assert result['name'] == 'foo', 'test of PkgMgr get_package_details failed!'
    assert result['version'] == 'bar', 'test of PkgMgr get_package_details failed!'
    assert result['source'] == 'baz', 'test of PkgMgr get_package_details failed!'


# Generated at 2022-06-23 00:28:35.279386
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    mgr = CLIMgr()
    assert mgr


# Generated at 2022-06-23 00:28:37.629313
# Unit test for constructor of class LibMgr
def test_LibMgr():
    test = LibMgr()
    assert isinstance(test, PkgMgr)
    return


# Generated at 2022-06-23 00:28:39.514547
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pm = PkgMgr()
    assert pm.is_available is NotImplemented


# Generated at 2022-06-23 00:28:40.163286
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    pass

# Generated at 2022-06-23 00:28:41.868683
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    p = PkgMgr()
    assert not p.list_installed()


# Generated at 2022-06-23 00:28:52.759986
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True

        def list_installed(self):
            return ['package_one', 'package_two', 'package_three']

        def get_package_details(self, package):
            return {'name': package.split('_')[1], 'version': package.split('_')[-1]}

    pkgs = TestPkgMgr()
    result = pkgs.get_packages()

# Generated at 2022-06-23 00:28:54.064241
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr().CLI == None



# Generated at 2022-06-23 00:28:55.625220
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    pkg = PkgMgr()
    assert isinstance(pkg, PkgMgr)


# Generated at 2022-06-23 00:28:57.427664
# Unit test for constructor of class LibMgr
def test_LibMgr():
    assert issubclass(LibMgr, PkgMgr)
    assert type(LibMgr()) == LibMgr


# Generated at 2022-06-23 00:29:01.324620
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    package_managers = get_all_pkg_managers()
    assert 'dnf' in package_managers
    assert 'zypper' in package_managers
    assert 'apt' in package_managers
    assert 'yum' in package_managers
    assert 'pacman' in package_managers

# Generated at 2022-06-23 00:29:03.886971
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    assert PkgMgr.get_packages(None) == None

# Generated at 2022-06-23 00:29:12.130058
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    # Note: cls must be a subclass of PkgMgr
    def test_case(cls):
        mgr = cls()
        if not mgr.is_available():
            return
        packages = mgr.get_packages()
        assert isinstance(packages, dict)
        for pkgs in packages.values():
            assert isinstance(pkgs, list)
            for pkg in pkgs:
                assert isinstance(pkg, dict)
                assert 'name' in pkg
                assert 'version' in pkg

    for cls in get_all_pkg_managers().values():
        yield test_case, cls

# Generated at 2022-06-23 00:29:15.482460
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    # Unit test to check if method returns False if package manager is not installed
    pkgmgr = PkgMgr()
    assert pkgmgr.is_available() == False


# Generated at 2022-06-23 00:29:19.699687
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class LibMgrMock(LibMgr):
        LIB = "ast"

    libmgr = LibMgrMock()
    assert libmgr.is_available(), 'is_available() should return true if the library is available'


# Generated at 2022-06-23 00:29:23.274707
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestLibMgr(LibMgr):
        LIB = 'test'

    libmgr = TestLibMgr()

    assert libmgr._lib is None
    assert libmgr.is_available() is False


# Generated at 2022-06-23 00:29:34.194368
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    import unittest
    from ansible.module_utils.six import PY3
    import platform
    import sys

    class TestPkgMgr(PkgMgr):
        def is_available(self):
            pass

        def list_installed(self):
                return ["python"]

    # python version based on requirement
    req = ('python (>= 2.6)' if sys.version_info[0] == 2 else 'python (>= 3.4)')
    ver = platform.python_version()
    if PY3:
        # python3.x.y -> python-3.x.y
        reqname = 'python-{}.{}'.format(
            sys.version_info.major, sys.version_info.minor)
    else:
        # python2.x -> python-2.x
        reqname

# Generated at 2022-06-23 00:29:37.674943
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    def fake_list():
        return ['test1', 'test2']

    FakePkgMgr = type('FakePkgMgr', (PkgMgr,), {'list_installed': fake_list})

    FakeInstance = FakePkgMgr()
    assert len(FakeInstance.list_installed()) == 2


# Generated at 2022-06-23 00:29:39.102015
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    pass


# Generated at 2022-06-23 00:29:41.188323
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    assert PkgMgr.list_installed() == NotImplemented


# Generated at 2022-06-23 00:29:42.212764
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pass


# Generated at 2022-06-23 00:29:44.452393
# Unit test for constructor of class LibMgr
def test_LibMgr():
    obj = LibMgr()
    assert obj is not None


# Generated at 2022-06-23 00:29:45.599176
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    assert True

# Generated at 2022-06-23 00:29:46.269938
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    pass

# Generated at 2022-06-23 00:29:48.778632
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    actual = get_all_pkg_managers()
    assert actual is not None
    assert len(actual) > 0
    assert 'apt' in actual

# Generated at 2022-06-23 00:29:49.870830
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    assert False

# Generated at 2022-06-23 00:29:51.944852
# Unit test for constructor of class LibMgr
def test_LibMgr():
    cli = CLIMgr()
    print(cli.is_available())



# Generated at 2022-06-23 00:30:02.253017
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    from ansible.module_utils.facts import package_mgr
    package_mgr.FACT_SUBSETS["pkg_mgr"] = {'all': ['get_all_pkg_managers'], '*': []}
    from ansible.modules.system import setup
    from ansible.module_utils._text import to_bytes
    import json
    setup_obj = setup.Setup(dict(ANSIBLE_MODULE_ARGS={}, ANSIBLE_FACTS={}))
    setup_obj.populate_facts()
    all_package_managers = json.loads(to_bytes(setup_obj._display.display(setup_obj.ansible_facts, 'all', setup_obj.options)))['ansible_pkg_mgr']
    no_package_managers = len(all_package_managers)


# Generated at 2022-06-23 00:30:08.719942
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    all_pkg_managers = get_all_pkg_managers()
    assert 'pip' in all_pkg_managers
    assert 'gem' in all_pkg_managers
    assert 'composer' in all_pkg_managers
    assert 'dnf' in all_pkg_managers
    assert 'yum' in all_pkg_managers
    assert 'dnf' not in all_pkg_managers
    assert 'dnf' in all_pkg_managers

# Generated at 2022-06-23 00:30:15.539075
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    for pkg_mgr in get_all_pkg_managers().values():
        if isinstance(pkg_mgr, LibMgr):
            assert pkg_mgr().is_available() == True, 'The package manager {} should be available.'.format(pkg_mgr.__name__)
        else:
            assert pkg_mgr().is_available() == False, 'The package manager {} should not be available.'.format(pkg_mgr.__name__)


# Generated at 2022-06-23 00:30:17.245674
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():

    myclass = PkgMgr()
    assert not myclass.is_available()


# Generated at 2022-06-23 00:30:22.822970
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    from ansible.module_utils.facts.pkg_mgr.pkg_mgr_yum import Yum
    m = Yum()
    assert m.is_available() == True

    from ansible.module_utils.facts.pkg_mgr.pkg_mgr_dpkg import Dpkg
    m = Dpkg()
    assert m.is_available() == False



# Generated at 2022-06-23 00:30:29.738840
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def list_installed(self):
            return ['test', 'test2']
        def get_package_details(self, package):
            return {'name': package, 'version': '1'}
    tpm = TestPkgMgr()
    packages = tpm.get_packages()
    assert len(packages) == 2
    assert 'test' in packages
    assert 'test2' in packages
    assert len(packages['test']) == 1
    assert len(packages['test2']) == 1

# Generated at 2022-06-23 00:30:31.133619
# Unit test for constructor of class LibMgr
def test_LibMgr():
    obj = LibMgr()
    assert obj

# Generated at 2022-06-23 00:30:37.948974
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class Foo(CLIMgr):
        CLI = 'foo'

    orignal_function = CLIMgr.is_available

    CLIMgr.is_available = lambda self: 'foo'
    assert Foo().is_available() == 'foo'

    CLIMgr.is_available = lambda self: None
    assert not Foo().is_available()

    CLIMgr.is_available = orignal_function

# Generated at 2022-06-23 00:30:47.359899
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():

    # Create basic PkgMgr subclass
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            pass

        def list_installed(self):
            pass

        def get_package_details(self, package):
            pass

    # Create basic CLIMgr subclass
    class TestCLIMgr(CLIMgr):
        CLI = 'test'

        def list_installed(self):
            pass

        def get_package_details(self, package):
            pass

    # Create basic LibMgr subclass
    class TestLibMgr(LibMgr):
        LIB = 'test'

        def list_installed(self):
            pass

        def get_package_details(self, package):
            pass

    # Create test instances
    pkg_mgr = TestPkgMgr()
    cli

# Generated at 2022-06-23 00:30:51.445315
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():

    try:
        import platform
    except ImportError:
        sys.exit('platform is not installed')

    # test for a package manager for which the library is installed
    lib_mgr = LibMgr()
    lib_mgr.LIB = 'platform'
    assert lib_mgr.is_available() == True

    # test for a package manager for which the library is not installed
    lib_mgr.LIB = 'urllib2'
    assert lib_mgr.is_available() == False



# Generated at 2022-06-23 00:31:02.192840
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class PkgMgrImplementation(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return [
                {'name': 'package-1', 'version': '0.1'},
                {'name': 'package-1', 'version': '0.2'},
                {'name': 'package-2', 'version': '0.1', 'source': 'rpm'},
                {'name': 'package-2', 'version': '0.2', 'source': 'dnf'},
                {'name': 'package-2', 'version': '0.3', 'source': 'yum'}
            ]
        def get_package_details(self, package):
            return package

# Generated at 2022-06-23 00:31:13.861694
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():

    class PkgMgr(PkgMgr):

        def __init__(self):
            self._lib = None
            super(PkgMgr, self).__init__()

        def is_available(self):
            found = False
            try:
                found = True
            except ImportError:
                pass
            return found

        def list_installed(self):
            return ["first", "second"]

        def get_package_details(self, package):
            return { "name": package, "version": "1.0"}

    test = PkgMgr()
    assert test.is_available()

# Generated at 2022-06-23 00:31:20.715930
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    from ansible.module_utils.common.os import yum
    from ansible.module_utils.common.os import rubygem
    from ansible.module_utils.common.os import apk
    from ansible.module_utils.common.os import apt
    from ansible.module_utils.common.os import apk
    from ansible.module_utils.common.os import dnf
    from ansible.module_utils.common.os import freebsd_pkg
    from ansible.module_utils.common.os import pacman
    from ansible.module_utils.common.os import pkg5
    from ansible.module_utils.common.os import pkgng
    from ansible.module_utils.common.os import pip
    from ansible.module_utils.common.os import wart

# Generated at 2022-06-23 00:31:28.245884
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    import pytest

    class CLIDummyMgr(CLIMgr):
        CLI = 'CLIDummy'

    class CLIInvalidMgr(CLIMgr):
        CLI = 'CLIInvalid'

    try:
        mgr = CLIDummyMgr()
        assert mgr.is_available() is True
        mgr = CLIInvalidMgr()
        assert mgr.is_available() is False
    except ModuleNotFoundError as e:
        pytest.skip("One of the module used for this test is missing: '{0}'.".format(e))

# Generated at 2022-06-23 00:31:31.602182
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class CLIMgrSubClass(CLIMgr):
        CLI = 'foo'
    obj = CLIMgrSubClass()
    assert not obj.is_available()

# Generated at 2022-06-23 00:31:36.318343
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    for PKG in PkgMgr.__subclasses__():
        if PKG.__name__ != "CLIMgr" and PKG.__name__ != "LibMgr" :
            pkg = PKG()
            pkg.is_available()
            p = pkg.list_installed()



# Generated at 2022-06-23 00:31:37.488020
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    assert PkgMgr()


# Generated at 2022-06-23 00:31:42.831010
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    package_details = dict()
    package_details['name'] = 'ansible'
    package_details['version'] = '2.8.1'
    package_managers = get_all_pkg_managers()
    pkgmgr = package_managers.get('pkgmgr')
    pkgmgr.get_package_details = mock.Mock(return_value=package_details)
    package = pkgmgr.get_package_details('ansible')
    assert package['name'] == 'ansible'
    assert package['version'] == '2.8.1'


# Generated at 2022-06-23 00:31:53.775003
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    all_pkg_managers = get_all_pkg_managers()
    assert 'yumpkg' in all_pkg_managers
    assert 'dpkg' in all_pkg_managers
    assert 'freebsdpkg' in all_pkg_managers
    assert 'pacmanpkg' in all_pkg_managers
    assert 'apkg' in all_pkg_managers
    assert 'brewpkg' in all_pkg_managers
    assert 'dnfpkg' in all_pkg_managers
    assert 'portagepkg' in all_pkg_managers
    assert 'gentoopkg' in all_pkg_managers
    assert 'pkgngpkg' in all_pkg_managers
    assert 'aptpkg' in all_pkg_managers
    assert 'slackpkg' in all_pkg_managers

# Generated at 2022-06-23 00:32:01.990822
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    class TestPkgMgr(PkgMgr):
        def __init__(self):
            self.test_flag = False
            super(TestPkgMgr, self).__init__()
        def is_available(self):
            self.test_flag = True
            return self.test_flag

    TestPkgMgr_object = TestPkgMgr()
    TestPkgMgr_object.is_available()

    if TestPkgMgr_object.test_flag:
        return True
    else:
        return False


# Generated at 2022-06-23 00:32:04.685001
# Unit test for constructor of class LibMgr
def test_LibMgr():
    lib_mgr = LibMgr()
    assert lib_mgr.is_available() is False
    assert lib_mgr._lib is None


# Generated at 2022-06-23 00:32:08.444004
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    import os

    mock_cli = os.path.realpath(__file__)
    mock_climgr = CLIMgr()
    mock_climgr.CLI = mock_cli

    assert mock_climgr.is_available() is True

# Generated at 2022-06-23 00:32:14.184116
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    from packaging_ansible.get_package_info import PkgMgr
    pkg_mgr = PkgMgr()
    pkg_mgr.list_installed = lambda: ["hello"]
    pkg_mgr.get_package_details = lambda x: None
    pkgs = pkg_mgr.get_packages()
    assert pkgs[0]["source"] == "pkg_mgr"

# Generated at 2022-06-23 00:32:17.071562
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    c = CLIMgr()
    c.CLI = "no_such_binary"
    assert not c.is_available()


# Generated at 2022-06-23 00:32:24.342210
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    import sys
    test_dict = {'test_package': {'name': 'test_package', 'version': '0.0.1'}}
    test_pkgmgr = PkgMgr()
    test_pkgmgr._package_info = test_dict
    assert test_pkgmgr.get_package_details('test_package') == {'name': 'test_package', 'version': '0.0.1', 'source': 'pkgmgr'}


# Generated at 2022-06-23 00:32:27.474153
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    # Check that it is an instance of PkgMgr
    assert isinstance(CLIMgr(), PkgMgr)
    # Check that it is an instance of Meta
    assert isinstance(CLIMgr, type)

# Generated at 2022-06-23 00:32:33.680550
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.common.json import from_json

    import mock

    from ansible.module_utils.facts.pkg_mgr.yum import YumPkgMgr


# Generated at 2022-06-23 00:32:35.043927
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr()._cli is None


# Generated at 2022-06-23 00:32:41.742032
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    import sys
    import os

    # Temporary change of directories for importing idna
    sys.path.append(os.getcwd())
    import idna

    # Suppress the warning for importing idna. idna.PkgMgr.__init__() calls super().__init__() which calls __init__()
    # again in idna.PkgMgr class (https://www.python.org/dev/peps/pep-3135/), this causes the warning.
    # https://github.com/ansible/ansible/issues/51982
    import warnings
    warnings.filterwarnings(
        "ignore", message="object.__init__() takes no parameters",
        category=DeprecationWarning, module="idna"
    )
    idna_obj = idna.PkgMgr()

# Generated at 2022-06-23 00:32:48.222277
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    # Test with CLI being existent
    test_obj = CLIMgr()
    setattr(test_obj, 'CLI', 'echo')
    assert test_obj.is_available() == True

    # Test with CLI being non-existent
    test_obj = CLIMgr()
    setattr(test_obj, 'CLI', 'blah')
    assert test_obj.is_available() == False

# Generated at 2022-06-23 00:32:49.524931
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    assert CLIMgr().is_available() == False


# Generated at 2022-06-23 00:32:54.953349
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():

    class PkgMgrTest(PkgMgr):

        def list_installed(self):

            return ['pkg1', 'pkg2', 'pkg3']

        def get_package_details(self, package):

            return {'name': package}

    obj = PkgMgrTest()
    result = obj.get_packages()
    assert isinstance(result, dict)
    assert len(result) == 3

# Generated at 2022-06-23 00:32:57.404619
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    all_managers = get_all_pkg_managers()
    assert 'dnf' in all_managers
    assert 'gem' in all_managers
    assert 'apt' in all_managers



# Generated at 2022-06-23 00:33:09.550544
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    # testing for class CLIMgr
    cliMgr = CLIMgr()
    # testing for command which is not available
    cliMgr.CLI = 'command_which_is_not_available'
    assert cliMgr.is_available() is False
    # testing for command which is available
    cliMgr.CLI = 'ls'
    assert cliMgr.is_available() is True
    # testing for class LibMgr
    libMgr = LibMgr()
    # testing for lib which is not available
    libMgr.LIB = 'lib_which_is_not_available'
    assert libMgr.is_available() is False
    # testing for lib which is available
    libMgr.LIB = 'sys'
    assert libMgr.is_available() is True

# Unit test

# Generated at 2022-06-23 00:33:15.244201
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    ret = {}
    ret['returncode'] = 0
    ret['stdout'] = b"stdout line1\nstdout line2"
    ret['stderr'] = b"stderr line1\nstderr line2"
    o = CLIMgr()
    o.CLI = 'cat'
    o.is_available()
    assert o._cli is not None

# Generated at 2022-06-23 00:33:19.170020
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    lm = LibMgr()
    lm._lib = None
    assert not lm.is_available()
    lm._lib = {'name': 'python'}
    assert lm.is_available()



# Generated at 2022-06-23 00:33:25.223788
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():

    # contains all package managers that are a subclass of PkgMgr
    pkg_mgrs = get_all_pkg_managers()
    assert 'CLIMgr' not in pkg_mgrs
    assert 'LibMgr' not in pkg_mgrs
    assert 'PkgMgr' not in pkg_mgrs
    assert 'Yum' in pkg_mgrs
    assert 'Apt' in pkg_mgrs

# Generated at 2022-06-23 00:33:28.078752
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    assert PkgMgr.is_available() == NotImplementedError("is_available method not implemented")


# Generated at 2022-06-23 00:33:31.887617
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestLibMgr(LibMgr):
        LIB = 'testlibrary'
    assert TestLibMgr()
    assert TestLibMgr()._lib == None
    assert TestLibMgr().LIB == 'testlibrary'


# Generated at 2022-06-23 00:33:42.316345
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    import os
    import shutil
    import sys
    import tempfile

    # Mock the environment by creating some dummy directories
    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-23 00:33:51.468658
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    result = get_all_pkg_managers()
    assert sorted(result.keys()) == [
        'apk',
        'apt',
        'chocolatey',
        'cpan',
        'cpanm',
        'dnf',
        'eopkg',
        'freebsd',
        'gem',
        'nix',
        'npm',
        'openbsd',
        'openpkg',
        'pacman',
        'pip',
        'pkgng',
        'portage',
        'smart',
        'slackware',
        'sorcery',
        'sun',
        'swdepot',
        'urpmi',
        'yum',
        'zypper',
    ]

# Generated at 2022-06-23 00:33:53.565643
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    pygpgme = __import__('gpgme')
    assert pygpgme




# Generated at 2022-06-23 00:34:03.509245
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    class MockPkgMgr(PkgMgr):

        def __init__(self):
            super(MockPkgMgr, self).__init__()

        def is_available(self):
            return True

        def list_installed(self):
            return ['foo', 'bar']

        def get_package_details(self, package):
            # This takes a 'package' item and returns a dictionary with the package information, name and version are minimal requirements
            if package == 'foo':
                return {'name':'foo', 'version':'1.0'}
            elif package == 'bar':
                return {'name':'bar', 'version':'2.0'}


# Generated at 2022-06-23 00:34:04.906712
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    assert CLIMgr().is_available() == False


# Generated at 2022-06-23 00:34:08.585035
# Unit test for constructor of class LibMgr
def test_LibMgr():
    lm = LibMgr()
    assert not lm.is_available()
    lm._lib = "dummy_class"
    assert lm.is_available()


# Generated at 2022-06-23 00:34:11.111556
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    """Checking if the list_installed method of base class exists.

    """
    pkgmgr = PkgMgr()
    pkgmgr.list_installed()



# Generated at 2022-06-23 00:34:17.300088
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    # tests that get_all_pkg_managers returns the right class for a given string
    # tests that get_all_pkg_managers returns the right number of classes
    all_mgrs = get_all_pkg_managers()
    assert 'pip' in all_mgrs
    assert issubclass(all_mgrs['pip'], PkgMgr)
    assert len(all_mgrs) == 14

# Generated at 2022-06-23 00:34:19.847711
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    pkg_mgr_obj = PkgMgr
    assert (not pkg_mgr_obj.get_packages()), "Should return False"

# Generated at 2022-06-23 00:34:24.059122
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    fail = False
    pm = PkgMgr()
    try:
        pm.get_package_details("test")
    except NotImplementedError:
        pass
    except Exception:
        fail = True
    assert not fail


# Generated at 2022-06-23 00:34:27.852725
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class PkgMgrTester(CLIMgr):
        CLI = 'python'
    pkg = PkgMgrTester()
    assert pkg.is_available() == True
    pkg.CLI = 'non-existent'
    assert pkg.is_available() == False

# Generated at 2022-06-23 00:34:28.441761
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    pass

# Generated at 2022-06-23 00:34:32.901303
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    mgrs = get_all_pkg_managers()
    for mgr in mgrs:
        try:
            if mgrs[mgr]().is_available():
                print("%s is available" % mgr)
            else:
                print("%s is not available" % mgr)
        except:
            pass


# Generated at 2022-06-23 00:34:43.469070
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():

    class PkgMgrTest(PkgMgr):
        def __init__(self):
            self.pkg_list = [
                {'name': 'pkg1', 'version': '1.0'},
                {'name': 'pkg2', 'version': '2.0'},
                {'name': 'pkg3', 'version': '3.0'},
            ]
            self.ret = 0

        def is_available(self):
            return True

        def list_installed(self):
            for pkg in self.pkg_list:
                yield pkg

        def get_package_details(self, package):
            return package

        def get_packages(self):
            return dict([(package['name'], [package]) for package in self.pkg_list])

    pm_test = PkgMgrTest()


# Generated at 2022-06-23 00:34:48.086268
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    from ansible_collections.notstdlib.moveitallout.tests.unit.mock.mock_pkg_mgrs import CLIMgr
    cli_mgr = CLIMgr()
    assert cli_mgr.is_available() == True or False



# Generated at 2022-06-23 00:34:49.987348
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    # Use of assertRaises function
    try:
        PkgMgr().list_installed()
    except TypeError as a:
        assert True


# Generated at 2022-06-23 00:34:56.434340
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    from ansible.module_utils.facts import default
    from ansible.module_utils.facts.system.pkg_mgr import get_all_pkg_managers
    pkg_mgrs_dict = get_all_pkg_managers()
    assert 'rpm' in pkg_mgrs_dict
    assert 'apt' in pkg_mgrs_dict
    assert 'apk' in pkg_mgrs_dict
    assert 'openbsd_pkg' in pkg_mgrs_dict
    assert 'freebsd_pkgng' in pkg_mgrs_dict
    assert 'pacman' in pkg_mgrs_dict
    assert 'pkgng' in pkg_mgrs_dict
    assert 'portage' in pkg_mgrs_dict

# Generated at 2022-06-23 00:34:58.056367
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    cm = CLIMgr()
    assert cm

# Generated at 2022-06-23 00:35:01.453289
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class CLIMgr_is_available(CLIMgr):
        CLI = None
    assert(CLIMgr_is_available().is_available() == False)
    import mock

# Generated at 2022-06-23 00:35:10.316466
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():

    pkg_managers = get_all_pkg_managers()
    assert 'AptPkgMgr' in pkg_managers
    assert 'DnfPkgMgr' in pkg_managers
    assert 'YumPkgMgr' in pkg_managers
    assert 'PipPkgMgr' in pkg_managers
    assert 'RubyGemsPkgMgr' in pkg_managers
    assert 'ZypperPkgMgr' in pkg_managers
    assert 'PkgsrcPkgMgr' in pkg_managers
    assert 'OpenbsdPkgMgr' in pkg_managers
    assert 'PortagePkgMgr' in pkg_managers
    assert 'PacmanPkgMgr' in pkg_managers

# Generated at 2022-06-23 00:35:11.959300
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    p = PkgMgr()
    assert p

# Generated at 2022-06-23 00:35:14.704614
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    for pkg_mgr in get_all_pkg_managers():
        assert get_all_pkg_managers()[pkg_mgr]().is_available()

# Generated at 2022-06-23 00:35:18.030112
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    assert 'apkgmgr' in get_all_pkg_managers()
    assert 'bpkglibmgr' in get_all_pkg_managers()
    assert 'cpkgclimgr' in get_all_pkg_managers()

# Generated at 2022-06-23 00:35:29.046800
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    # The purpose of this test is to ensure that the method get_packages
    # of class PkgMgr returns a list of installed packages. The list
    # returned by get_packages is a list of dictionaries, with
    # each dictionary containing a package name and version.

    # The test will pass if get_packages returns a list of dictionaries.
    # The test will fail if get_packages does not return a list of dictionaries.

    # Get a list of installed packages.
    # The list of installed packages is a list of dictionaries.
    # Each dictionary contains a package name, and a package version.
    installed_packages = get_all_pkg_managers()['brew']().get_packages()

    # Check that the list of installed packages is a list of dictionaries.
    # If the list of installed packages is not a list of dictionaries,


# Generated at 2022-06-23 00:35:36.804829
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    #Test for case where the module is successfully imported
    test_obj_1 = LibMgr()
    test_obj_1.LIB = "paramiko"
    assert test_obj_1.is_available()

    #Test for case where the module is not present
    test_obj_2 = LibMgr()
    test_obj_2.LIB = "iDontExist"
    assert not test_obj_2.is_available()

    #Test for case where the module is present but not importable
    test_obj_3 = LibMgr()
    test_obj_3.LIB = "os"
    assert not test_obj_3.is_available()



# Generated at 2022-06-23 00:35:39.825094
# Unit test for constructor of class LibMgr
def test_LibMgr():
    from ansible.module_utils.common._collections_compat import MutableSequence
    assert issubclass(LibMgr, MutableSequence)
    assert isinstance(LibMgr(), LibMgr)
    assert isinstance(LibMgr, type)


# Generated at 2022-06-23 00:35:41.028975
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    assert(False)


# Generated at 2022-06-23 00:35:45.334631
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():

    assert len(get_all_pkg_managers()) > 0
    assert len(get_all_pkg_managers().keys()) > 0
    assert 'homebrew' in get_all_pkg_managers().keys()
    assert type(get_all_pkg_managers()['homebrew']) is type



# Generated at 2022-06-23 00:35:50.048570
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    # Test: CLIMgr instance is available
    test_instance = CLIMgr()
    assert test_instance.is_available()

    # Test: CLIMgr instance is not available
    test_instance = CLIMgr()
    test_instance.CLI = 'INVALID-CLI'
    assert not test_instance.is_available()

# Generated at 2022-06-23 00:35:53.608486
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    """Unit test for method is_available of class LibMgr."""
    class TestLibMgr(LibMgr):
        LIB = 'ansible_facts.first'

    test = TestLibMgr()
    assert test.is_available()


# Generated at 2022-06-23 00:35:56.374250
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    """
    Instantiate a CLIMgr class, call is_available method, ensure it returns True
    :return:
    """
    test_class = CLIMgr()
    assert test_class.is_available() == True

# Generated at 2022-06-23 00:36:09.053249
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    class TestPkgMgr(PkgMgr):

        def is_available(self):

            return True

        def list_installed(self):

            return ['package_1-1.0',
                    'package_2-2.0',
                    'package_2-2.1',
                    'package_3-3.0']

        def get_package_details(self, package):

            name = package.split('-')[0]
            version = package.split('-')[1]

            return {
                'name': name,
                'version': version
            }

    tpm = TestPkgMgr()

# Generated at 2022-06-23 00:36:16.834165
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    from ansible.module_utils.facts.collector.pkg_mgrs import PkgMgr
    from ansible.module_utils.facts.collector.pkg_mgrs.portage import Portage
    p = Portage()
    if p.is_available():
        assert isinstance(p.list_installed(), list)
    else:
        assert isinstance(p.list_installed(), list)


# Generated at 2022-06-23 00:36:17.614295
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pass


# Generated at 2022-06-23 00:36:23.321535
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    my_pkg_mgr = object.__new__(PkgMgr)
    my_pkg_mgr.list_installed = lambda: ['pkg1.1', 'pkg1.2', 'pkg2.1']
    my_pkg_mgr.get_package_details = lambda package: {'name': package.split('.')[0], 'version': package.split('.')[1]}
    expected_output = {'pkg1': [{'name': 'pkg1', 'version': '1', 'source': 'pkgmgr'}, {'name': 'pkg1', 'version': '2', 'source': 'pkgmgr'}],
                       'pkg2': [{'name': 'pkg2', 'version': '1', 'source': 'pkgmgr'}]}

# Generated at 2022-06-23 00:36:31.003785
# Unit test for constructor of class LibMgr
def test_LibMgr():

    class DummyLibMgr(LibMgr):

        LIB = 'dummy_lib'

        def list_installed(self):
            print(self._lib)

        def get_package_details(self, package):
            print(package)

    dummy = DummyLibMgr()
    assert dummy.is_available()
    assert dummy.list_installed.__get__(dummy)
    assert dummy.get_package_details.__get__(dummy)
    assert dummy.get_packages.__get__(dummy)


# Generated at 2022-06-23 00:36:35.083068
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    # Test when CLI isn't installed
    test_ob = CLIMgr()
    assert(not test_ob.is_available())

    # Test when CLI is installed
    test_ob.CLI = "which"
    assert(test_ob.is_available())


# Generated at 2022-06-23 00:36:40.419676
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class test(PkgMgr):
        pass

    l = test()
    list = l.list_installed()
    print("list installed package:")
    print(list)

    for i in list:
        print("Package " + i + " details:")
        print(l.get_package_details(i))

#test_PkgMgr_get_package_details()

# Generated at 2022-06-23 00:36:43.385089
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    # Arrange
    cmd = 'python'

    # Act
    cli = CLIMgr()

    # Assert
    assert cli.CLI is None

# Generated at 2022-06-23 00:36:52.800857
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    from ansible.module_utils.six import PY3

    if not PY3:
        import sys
        reload(sys)
    # Python 2.x reloaded module sys has no attribute 'setdefaultencoding'
        sys.setdefaultencoding('utf-8')


    class MockPkgMgr(PkgMgr):

        def is_available(self):
            return True


# Generated at 2022-06-23 00:37:01.835301
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def __init__(self):
            self.installed_packages = [{
                'name': 'foo',
                'version': '1.0.0',
            }, {
                'name': 'qux',
                'version': '2.0.0',
            }, {
                'name': 'foo',
                'version': '2.0.0',
            }]
            super(TestPkgMgr, self).__init__()

        def is_available(self):
            return True

        def list_installed(self):
            return self.installed_packages

        def get_package_details(self, package):
            return package

    test_pkg_mgr = TestPkgMgr()
    packages = test_pkg_mgr.get_packages()


# Generated at 2022-06-23 00:37:06.248579
# Unit test for constructor of class CLIMgr
def test_CLIMgr():

    from ansible.module_utils.software_management import CLIMgr

    class TestClass(CLIMgr):

        CLI = None

    TestClass = TestClass()
    TestClass.is_available()
    TestClass.list_installed()
    TestClass.get_package_details('package')
    TestClass.get_packages()
