

# Generated at 2022-06-23 00:27:07.355618
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pkg_managers = get_all_pkg_managers()
    for pkg_manager in pkg_managers:
        assert pkg_managers[pkg_manager].is_available()


# Generated at 2022-06-23 00:27:08.272892
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    assert CLIMgr().is_available()

# Generated at 2022-06-23 00:27:12.089123
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    package_details = {}
    test_instance = PkgMgr()
    result_package_details = test_instance.get_package_details(package_details)
    assert result_package_details == {}


# Generated at 2022-06-23 00:27:23.675473
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        # lists emulating the output of list_installed and get_package_details methods
        # the get_package_details list contains a dummy item for testing the source field
        _list_installed_list = ['a1', 'a2', 'b1', 'b2']
        _get_package_details_list = [{'name': 'a', 'version': '1', 'source': 'test'},
                                     {'name': 'a', 'version': '2'},
                                     {'name': 'b', 'version': '1'},
                                     {'name': 'b', 'version': '2'}]

        def list_installed(self):
            return self._list_installed_list

        def get_package_details(self, package):
            return self._get_

# Generated at 2022-06-23 00:27:26.353033
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    test_cli = CLIMgr()
    assert not hasattr(test_cli, '_cli')
    assert test_cli.CLI is None

# Generated at 2022-06-23 00:27:36.333813
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    '''
    Test method CLIMgr.is_available() with real package names and
    fake ones.
    '''
    try:
        get_bin_path('grep')
        print('get_bin_path() works ok')
    except:
        print('get_bin_path() failed. Cannot run CLIMgr test 1')
        return

    fakep = CLIMgr()
    fakep.CLI = 'grep'
    assert fakep.is_available(), \
        "get_bin_path() returned false for a real package"

    fakep.CLI = 'gblorg'
    assert not fakep.is_available(), \
        "get_bin_path() returned true for a fake package"



# Generated at 2022-06-23 00:27:42.948431
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    test_cli = 'rpm'
    #
    # Constructor of class CLIMgr
    #
    pkg_mgr_test = CLIMgr()
    pkg_mgr_test.CLI = test_cli
    #
    # Check if CLI is available or not
    #
    assert pkg_mgr_test.is_available() is True
    #
    # Return the value of _cli
    #
    assert not pkg_mgr_test._cli == None

# Generated at 2022-06-23 00:27:49.409757
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():

    class DummyManager(PkgMgr):

        def is_available(self):
            return True

        def list_installed(self):
            return [{'name': 'test_pkg', 'version': '1.0'}]

        def get_package_details(self, package):
            return package

    dummy_manager = DummyManager()
    assert dummy_manager.get_package_details({'name': 'test_pkg', 'version': '1.0'}) == {'name': 'test_pkg', 'version': '1.0'}


# Generated at 2022-06-23 00:27:52.462209
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    try:
        temp = PkgMgr()
        raise Exception("Failed: instantiating of PkgMgr class should raise 'TypeError'")
    except TypeError as e:
        pass


# Generated at 2022-06-23 00:27:58.049104
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCLIMgr(CLIMgr):
        CLI = 'python'
    test_mgr = TestCLIMgr()
    if test_mgr.is_available() == 1:
        print('Method is_available of class CLIMgr is working correctly.')
    else:
        print('Method is_available of class CLIMgr has some error.')
# test for class CLIMgr ends


# Generated at 2022-06-23 00:28:09.484873
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    # Create a PkgMgr instance
    mgr = PkgMgr()
    # Method list_installed returns a list of packages
    # Method get_package_details returns a dictionary with the package information
    def list_installed():
        return ['a', 'b']
    def get_package_details(package):
        return {'name': package, 'version': '1'}
    # Add custom methods to the PkgMgr instance
    mgr.list_installed = list_installed
    mgr.get_package_details = get_package_details
    # Expected result
    expected = {'a': [{'name': 'a', 'version': '1', 'source': 'pkgmgr'}],
                'b': [{'name': 'b', 'version': '1', 'source': 'pkgmgr'}]}



# Generated at 2022-06-23 00:28:10.830429
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    pm = PkgMgr()
    assert pm is not None


# Generated at 2022-06-23 00:28:14.502900
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    pkg_managers = get_all_pkg_managers()
    assert 'dpkg' in pkg_managers
    assert 'apt' in pkg_managers
    assert 'yum' in pkg_managers
    assert 'zypper' in pkg_managers
    assert 'dnf' in pkg_managers

# Generated at 2022-06-23 00:28:18.107084
# Unit test for constructor of class LibMgr
def test_LibMgr():
    lib = LibMgr()
    lib.LIB = 'test'
    lib.is_available()
    lib._lib = None
    lib.is_available()


# Generated at 2022-06-23 00:28:28.537471
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    import sys

    if sys.version_info[0] > 2:
        from ansible.module_utils.common.utils import py3_compat

        filter = py3_compat.filter
    else:
        filter = filter

    # If a package manager is added, this test will fail so a new entry can be added
    expected_managers = ['pacman', 'pip', 'portage', 'zypper', 'yum', 'apt']
    managers = list(filter(lambda p: p != 'rpmdb', get_all_pkg_managers()))

    if not set(expected_managers) == set(managers):
        raise AssertionError("Expected %s, got %s" % (expected_managers, managers))

# Generated at 2022-06-23 00:28:31.089056
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    from ansible.module_utils._text import to_bytes

    pkg = PkgMgr()
    assert pkg.list_installed() is None

# Generated at 2022-06-23 00:28:32.509025
# Unit test for constructor of class PkgMgr
def test_PkgMgr():

    assert 'PkgMgr' == PkgMgr.__name__


# Generated at 2022-06-23 00:28:38.515259
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def get_package_details(self, package):
            return package

    test_pm = TestPkgMgr()
    installed_packages = test_pm.list_installed()

    assert(installed_packages != [])


# Generated at 2022-06-23 00:28:39.918961
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    assert len(get_all_pkg_managers()) >= 8

# Generated at 2022-06-23 00:28:40.528406
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    pass

# Generated at 2022-06-23 00:28:41.868279
# Unit test for constructor of class LibMgr
def test_LibMgr():
    lm = LibMgr()
    assert lm



# Generated at 2022-06-23 00:28:44.927737
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    test_class = LibMgr()
    test_class.LIB = 'ansible.module_utils.distro'
    if not test_class.is_available():
        print('ansible.module_utils.distro is not imported')
        exit(1)


# Generated at 2022-06-23 00:28:49.010087
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    answer = {'name':'foo' , 'version' : '1.0' , 'source' : 'PkgMgr'}
    p = PkgMgr()
    assert dict(p.get_package_details('foo')) == answer


# Generated at 2022-06-23 00:28:51.016406
# Unit test for constructor of class LibMgr
def test_LibMgr():
    package = LibMgr()
    assert package._lib == None


# Generated at 2022-06-23 00:28:54.300291
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pm = PkgMgr()
    try:
        pm.is_available()
        raise AssertionError("Abstract method was called")
    except NotImplementedError:
        pass


# Generated at 2022-06-23 00:29:01.532539
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    """ Unit test for is_available of class LibMgr

    Args:
      None
    Returns:
      None
    Raises:
      None
    """

    class LibMgr_test(LibMgr):
        __test__ = False
        LIB = 'test'
        def list_installed(self):
            return []
        def get_package_details(self, package):
            return {}

    libmgr_test = LibMgr_test()
    assert libmgr_test.is_available() is False

    class LibMgr_test(LibMgr):
        __test__ = False
        LIB = 'test'
        def list_installed(self):
            return []
        def get_package_details(self, package):
            return {}

    libmgr_test = LibMgr_test()

# Generated at 2022-06-23 00:29:10.323083
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    test_pkgman = get_all_pkg_managers()
    assert 'dpkg' in test_pkgman
    assert 'yum' in test_pkgman
    assert 'pacman' in test_pkgman
    assert 'pacman' in test_pkgman

# Unit test is_available
from ansible.module_utils.facts.system.pkg_mgr import Dpkg, RedHatPkg, Pacman, Zypper
from ansible.module_utils.facts.system.pkg_mgr import Pip, Pip3
from ansible.module_utils.facts.system.pkg_mgr import Portage


# Generated at 2022-06-23 00:29:19.536269
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    class TestCLI:
        CLI = None
    class TestCLIMgr(CLIMgr, TestCLI):
        pass

    TestCLIMgr.CLI = 'dpkg'

    obj_test = TestCLIMgr()

    if obj_test.is_available() == False:
        raise AssertionError("TestCLIMgr not available")
    #import ipdb; ipdb.set_trace()
    assert obj_test == obj_test._cli, "obj_test._cli wasn't defined"
    assert obj_test == '/usr/bin/dpkg', "obj_test._cli wasn't defined"

# Generated at 2022-06-23 00:29:20.874738
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    cli_mgr = CLIMgr()
    # nothing to test


# Generated at 2022-06-23 00:29:32.030008
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    from . import apt
    from . import dpkg
    from . import yum
    from . import pip
    from . import pip3
    from . import yum
    # Test apt CLI package manager
    apt = apt.Apt()
    assert apt.is_available()
    # Test dpkg CLI package manager
    dpkg = dpkg.Dpkg()
    assert dpkg.is_available()
    # Test yum CLI package manager
    yum = yum.Yum()
    assert yum.is_available()
    # Test pip CLI package manager
    pip = pip.Pip()
    assert pip.is_available()
    # Test pip3 CLI package manager
    pip3 = pip3.Pip3()
    assert pip3.is_available()
    # Test yum lib based package manager
    yumAdmin = y

# Generated at 2022-06-23 00:29:33.979273
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    expected = True
    actual = LibMgr().is_available()
    assert expected == actual


# Generated at 2022-06-23 00:29:36.967590
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    class TestPkgMgr(PkgMgr):
        def list_installed(self):
            pass
        def get_package_details(self, package):
            pass
    result = TestPkgMgr().is_available()
    assert result == False


# Generated at 2022-06-23 00:29:39.537962
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    test_climgr = CLIMgr()
    assert test_climgr


# Generated at 2022-06-23 00:29:40.227435
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():

    assert PkgMgr.is_available() == False

# Generated at 2022-06-23 00:29:49.062356
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    import inspect
    import os
    import sys
    import tempfile
    temp = tempfile.gettempdir()
    TEST_PACKAGES_FILE = os.path.join(temp, 'pytest_test_packages.json')
    test_PkgMgr_list_installed.args = {}
    test_PkgMgr_list_installed.args['packages_file'] = TEST_PACKAGES_FILE
    def get_all_pkg_managers():
        from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-23 00:29:51.358682
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():

    pkg_mgr = PkgMgr()
    assert pkg_mgr.is_available() == NotImplemented


# Generated at 2022-06-23 00:29:59.673072
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():

    # create a dummy class inherited from class PkgMgr
    class test_PkgMgr_list_installed(PkgMgr):

        def list_installed(self):
            return ['pkg1', 'pkg2']

        def get_package_details(self, package):
            return {'name': package, 'version': '1.0.0'}

    # create an instance
    test_instance = test_PkgMgr_list_installed()

    # test calling of method list_installed
    assert test_instance.list_installed() == ['pkg1', 'pkg2']


# Generated at 2022-06-23 00:30:09.841712
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    all_pkg_managers = get_all_pkg_managers()
    assert "apt" in all_pkg_managers
    assert "yum" in all_pkg_managers
    assert "dnf" in all_pkg_managers
    assert "zypper" in all_pkg_managers
    assert "pacman" in all_pkg_managers
    assert "apk" in all_pkg_managers
    assert "pac" in all_pkg_managers
    assert "yast2" in all_pkg_managers
    assert "portage" in all_pkg_managers
    assert "pkg" in all_pkg_managers
    assert "pkgng" in all_pkg_managers
    assert "rpm" in all_pkg_managers
    assert "opkg" in all_pkg_managers

# Generated at 2022-06-23 00:30:11.232604
# Unit test for constructor of class LibMgr
def test_LibMgr():
    libmgr = LibMgr
    libmgr()


# Generated at 2022-06-23 00:30:22.446698
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    foo = os.path.dirname(os.path.realpath(__file__))
    foo1 = os.path.join(foo, "pkg_mgr_classes.py")
    foo2 = os.path.join(foo, "pkg_mgr_classes.pyc")
    fo = file("__init__.py", "w+")
    fo.close()
    if os.path.exists(foo1):
        os.remove(foo1)
    if os.path.exists(foo2):
        os.remove(foo2)
    class Pep8Mgr(LibMgr):
        LIB = "pkg_mgr_classes"
        pass
    pep8mgr = Pep8Mgr()
    pep8mgr.is_available()


# Generated at 2022-06-23 00:30:25.029835
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    for pkg in get_all_pkg_managers().values():
        if pkg.CLI is not None:
            assert pkg().is_available()

# Generated at 2022-06-23 00:30:33.082620
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    from os import environ
    from os.path import join, dirname, exists  
    from tempfile import mkdtemp
    from shutil import rmtree

    def make_mock_bin(mock_cli):
        mock_path = mkdtemp()
        mock_bin = join(mock_path, mock_cli)
        open(mock_bin, 'a').close()
        return mock_bin

    mock_cli = 'mock_cli'
    mock_bin = make_mock_bin(mock_cli)

    # If mock_bin is in PATH, then the CLI is available
    SPATH = environ['PATH'].split(':')
    environ['PATH'] = ':'.join([mock_path] + SPATH)
    assert exists(mock_bin)
    assert CLIMgr

# Generated at 2022-06-23 00:30:37.216884
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    class TestPkgMgr(PkgMgr):
        def list_installed(self):
            return []
    tpm = TestPkgMgr()
    assert tpm.list_installed() == []

# Generated at 2022-06-23 00:30:41.058559
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    pkg_managers = get_all_pkg_managers()
    for manager in pkg_managers:
        obj = pkg_managers[manager]()
        if obj.CLI is not None:
            assert obj.is_available() == True

# Generated at 2022-06-23 00:30:42.029592
# Unit test for constructor of class LibMgr
def test_LibMgr():
    assert LibMgr()._lib is None

# Generated at 2022-06-23 00:30:43.009192
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    assert PkgMgr() is not None

# Generated at 2022-06-23 00:30:45.350697
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    print('No unit test yet for PkgMgr_list_installed')


# Generated at 2022-06-23 00:30:50.537941
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pkg_managers = get_all_pkg_managers()
    print("Test PkgMgr is_available:")
    for pkg_manager in pkg_managers:
        output = pkg_managers[pkg_manager]().is_available()
        if output:
            print("{0} is available".format(pkg_manager))
        else:
            print("{0} is unavailable".format(pkg_manager))


# Generated at 2022-06-23 00:30:54.151689
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestLibMgr(LibMgr):
        LIB = 'abc'

    lib = TestLibMgr()

    assert lib._lib is None


# Generated at 2022-06-23 00:31:01.024707
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    def list_installed():
        package_list = ['python-pkg-resources', 'python-yaml', 'python-django']
        return(package_list)

    class PkgMgrTest(PkgMgr):
        def list_installed(self):
            return list_installed()

    # list all packages
    pkg_mgr = PkgMgrTest()
    packages = pkg_mgr.list_installed()
    assert packages == ['python-pkg-resources', 'python-yaml', 'python-django']


# Generated at 2022-06-23 00:31:02.804549
# Unit test for constructor of class LibMgr
def test_LibMgr():
    """Test the constructor of the LibMgr class."""
    assert LibMgr() is not None


# Generated at 2022-06-23 00:31:14.645412
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class ConcretePkgMgr(PkgMgr):
        def is_available():
            return True
        def list_installed():
            return [('pack1', '1.0'), ('pack2', '2.0')]
        def get_package_details(package):
            return {'name': package[0], 'version': package[1]}

    my_pkg_mgr = ConcretePkgMgr()
    assert(my_pkg_mgr.get_packages() == {'pack1': [{'name': 'pack1', 'version': '1.0', 'source': 'concretepkgmgr'}],
                                        'pack2': [{'name': 'pack2', 'version': '2.0', 'source': 'concretepkgmgr'}]})



# Generated at 2022-06-23 00:31:26.413701
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.process import get_bin_path

    class TestMgr(CLIMgr):
        CLI = 'test'

    settings = ImmutableDict(
        no_log=True,
        ansible_module_generated_at=None,
        ansible_module_name=None,
        ansible_tmp=None,
        ansible_verbosity=1,
        ansible_command=None,
        ansible_playbook=None,
        ansible_playbook_python=None,
    )

    # This should return true
    original_get_bin_path = get_bin_path

# Generated at 2022-06-23 00:31:29.879010
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    managers = get_all_pkg_managers()
    for manager in managers.values():
        assert manager().is_available() in (True, False), "Method is_available in class %s should return True or False" % manager.__name__


# Generated at 2022-06-23 00:31:31.019574
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    assert PkgMgr()

# Generated at 2022-06-23 00:31:36.507047
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    class TestPkgMgr(PkgMgr):

        def list_installed(self):
            return ['test-package-0.0.1-test-1', 'test-package-0.0.2-test-1', 'test-package-2.0.0-test-1']

        def get_package_details(self, package):
            return {'name': 'test-package', 'version': '0.0.1'}

        def is_available(self):
            return True

    pkg = TestPkgMgr()

# Generated at 2022-06-23 00:31:38.861353
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    assert isinstance(get_all_pkg_managers(), dict)
    assert len(get_all_pkg_managers()) > 0

# Generated at 2022-06-23 00:31:48.581878
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    class SubPkgMgr(PkgMgr):
        def is_available(self):
            return True
    class SubCLIMgr(CLIMgr):
        CLI = 'ls'
    class SubLibMgr(LibMgr):
        LIB = 'os'

    subPkgMgr = SubPkgMgr()
    assert subPkgMgr.is_available() == True
    subCLIMgr = SubCLIMgr()
    assert subCLIMgr.is_available() == True
    subLibMgr = SubLibMgr()
    assert subLibMgr.is_available() == True

# Generated at 2022-06-23 00:31:54.141191
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    mock_list_installed = []
    class MockPkgMgr(PkgMgr):
        def list_installed(self):
            mock_list_installed.append("mock called")
            return []

    _mock_PkgMgr = MockPkgMgr()
    assert _mock_PkgMgr.list_installed() == []
    assert mock_list_installed == ["mock called"]


# Generated at 2022-06-23 00:31:55.636667
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    assert isinstance(get_all_pkg_managers(), dict)

# Generated at 2022-06-23 00:31:57.397877
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    test_class = LibMgr()
    assert test_class.is_available() == False


# Generated at 2022-06-23 00:32:04.203470
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    def get_bin_path(app):
        return app

    package_managers = get_all_pkg_managers()
    for name, clazz in package_managers.items():
        obj = clazz()
        setattr(obj, '_cli', None)
        if name == 'yum':
            setattr(obj, '_cli', 'yum')
        assert obj.is_available()
        assert obj._cli == 'yum'

# Generated at 2022-06-23 00:32:12.894894
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    import unittest
    import sys
    if sys.version_info[0] == 2:
        import mock
    else:
        from unittest import mock

    class TestClass(PkgMgr):
        def is_available(self):
            pass
        def list_installed(self):
            pass
        def get_package_details(self, package):
            pass

    t = TestClass()
    try:
        with mock.patch.object(t, 'is_available', return_value=True):
            assert t.is_available()
    except Exception as e:
        print(e)


# Generated at 2022-06-23 00:32:13.446849
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pass

# Generated at 2022-06-23 00:32:14.713150
# Unit test for constructor of class LibMgr
def test_LibMgr():
    assert LibMgr()._lib is None


# Generated at 2022-06-23 00:32:18.214770
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class A(LibMgr):
        LIB = "lib"

    assert A.LIB == "lib"
    assert isinstance(A()._lib, type(None))


# Generated at 2022-06-23 00:32:22.351443
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    assert hasattr(PkgMgr(), 'is_available')
    assert hasattr(PkgMgr(), 'list_installed')
    assert hasattr(PkgMgr(), 'get_package_details')
    assert hasattr(PkgMgr(), 'get_packages')

# Generated at 2022-06-23 00:32:27.090099
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():

    print("Testing PkgMgr ", end="")
    libmgr = LibMgr()
    climgr = CLIMgr()

    if not libmgr.is_available():
        print("FAILED: no python lib found")
        return

    if not climgr.is_available():
        print("FAILED: no cli found")
        return

    print("SUCCEEDED")
    return


if __name__ == '__main__':

    test_PkgMgr_is_available()

# Generated at 2022-06-23 00:32:38.409375
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    # create a new class that inherits the PkgMgr class and implements the abstract methods
    class test_PkgMgr(PkgMgr):

        def is_available(self):
            return True

        def list_installed(self):
            return ['package1-version1-arch1', 'package1-version2-arch1', 'package2-version1-arch1']

        def get_package_details(self, package):
            return {'name': package[:-14], 'version': package[-13:-5], 'arch':package[-5:]}

    # instantiate the class and call the get_packages method
    pkgmgr = test_PkgMgr()
    result = pkgmgr.get_packages()
    # check the result is as expected

# Generated at 2022-06-23 00:32:41.359327
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    mgr = PkgMgr()
    assert mgr.get_packages() == {}


# Generated at 2022-06-23 00:32:43.982078
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    pm = PkgMgr()
    assert isinstance(pm, PkgMgr)


# Generated at 2022-06-23 00:32:49.126433
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():

    class TestPkgMgr(PkgMgr):
        def get_package_details():
            pass

    pkgmgr = TestPkgMgr()

    if pkgmgr.get_package_details() is None:
        print(True)
    else:
        print(False)

test_PkgMgr_get_package_details()


# Generated at 2022-06-23 00:32:50.560402
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    assert CLIMgr().is_available() is True


# Generated at 2022-06-23 00:32:55.458354
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    packages = [{'version': '3.1.2-2.fc28.noarch'}, {'version': '3.1.2-2.fc28.noarch', 'name': 'python3-pip'}]
    for package in packages:
        self = PkgMgr()
        self.get_package_details(package)


# Generated at 2022-06-23 00:32:57.549773
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    CLI = 'python'
    mgr = CLIMgr()
    mgr.CLI = CLI
    assert mgr.CLI == CLI


# Generated at 2022-06-23 00:33:00.225094
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    obj = PkgMgr()
    assert obj


# Generated at 2022-06-23 00:33:05.644778
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    import sys
    p = sys.executable
    try:
        sys.executable = '/usr/bin/python'
        for obj in get_all_subclasses(CLIMgr):
            cli = obj()
            assert cli.is_available() == True
    finally:
        sys.executable = p


# Generated at 2022-06-23 00:33:12.571580
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    # Test for Python 2.7
    from ansible_collections.community.general.plugins.modules.system.package_facts.yum import Yum

    yum = Yum()
    packages = yum.get_packages()
    assert type(packages) == dict
    assert len(packages) > 0
    for package in packages:
        assert type(packages[package]) == list
        for p in packages[package]:
            assert type(p) == dict
            assert 'name' in p
            assert 'version' in p

# Generated at 2022-06-23 00:33:14.172916
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    assert PkgMgr().is_available() == NotImplemented


# Generated at 2022-06-23 00:33:15.290892
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr()


# Generated at 2022-06-23 00:33:19.159963
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    gm_name = 'CONS'
    pkg_mgr = PkgMgr()
    if pkg_mgr.__class__.__name__ == gm_name:
        return True
    else:
        return False


# Generated at 2022-06-23 00:33:31.060808
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class MyPkgMgr(PkgMgr):
        def is_available(self):
            return True

        def list_installed(self):
            return ['a1.1', 'a2.2', 'b1.1']

        def get_package_details(self, package):
            return {'name': package[0], 'version': package[1:]}

    p = MyPkgMgr()
    r = p.get_packages()

    assert isinstance(r, dict)
    assert r['a'] == [{'version': '1.1', 'source': 'mypkgmgr', 'name': 'a'}, {'version': '2.2', 'source': 'mypkgmgr', 'name': 'a'}]

# Generated at 2022-06-23 00:33:41.530297
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class my_PkgMgr(PkgMgr):
        def __init__(self, package_list):
            self.package_list = package_list
            super(my_PkgMgr, self).__init__()

        def is_available(self):
            return True

        def list_installed(self):
            return self.package_list

        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}

    my_package_list = ['package1', 'package2', 'package1']
    my_PkgMgr_obj = my_PkgMgr(my_package_list)

# Generated at 2022-06-23 00:33:43.378743
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class Test(LibMgr):

        LIB = 'os'

    assert Test().is_available()


# Generated at 2022-06-23 00:33:44.387273
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    p = CLIMgr()

# Generated at 2022-06-23 00:33:54.931100
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class TestlibManager(LibMgr):
        LIB = "ansible.module_utils.common.packages.known_package_managers.apt_dpkg"

    class TestCLIManager(CLIMgr):
        CLI = "ansible.module_utils.common.packages.known_package_managers.rpm"

    package = "package_name"
    apt_mgr = TestlibManager()
    rpm_mgr = TestCLIManager()
    assert not apt_mgr.is_available()
    assert not rpm_mgr.is_available()
    assert 'name' in rpm_mgr.get_package_details(package)
    assert rpm_mgr.get_package_details(package)['name'] == package
    assert 'version' in rpm_mgr.get_package_details(package)

# Generated at 2022-06-23 00:33:57.197205
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    assert PkgMgr.list_installed == "Needs to be implemented in subclass"


# Generated at 2022-06-23 00:33:59.773494
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    class TEST(CLIMgr):
        CLI = 'test'

    cm = TEST()

    assert cm._cli is None


# Generated at 2022-06-23 00:34:06.907482
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    import unittest

    class PkgMgrTest(PkgMgr):
        def list_installed(self):
            pass

        def get_package_details(self, package):
            pass

    with unittest.TestCase() as tc:
        pkgmgr = PkgMgrTest()
        package = "ansible"
        details = pkgmgr.get_package_details(package)
        assert details['name'] == package

# Generated at 2022-06-23 00:34:17.336425
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    from mock import MagicMock
    from os import path
    from ansible.module_utils._text import to_bytes


    class PkgMgrStub(PkgMgr):
        def is_available(self):
            return True

        def list_installed(self):
            return ["foo", "bar", "baz"]

        def get_package_details(self, package):
            return {"name": package,
                    "version": "1"}

    mod_path = path.join(path.dirname(path.realpath(__file__)), 'module_utils', 'packaging')
    mod_path_orig = to_bytes(mod_path)

    # mock _load_params
    from ansible.module_utils.facts import _load_params
    _load_params = MagicMock()

    # import module_utils

# Generated at 2022-06-23 00:34:19.847258
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    cli = CLIMgr()
    assert cli.CLI is None
    assert cli._cli is None


# Generated at 2022-06-23 00:34:28.049464
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    pkgMgr = PkgMgr()
    pkgMgr.list_installed = MagicMock(return_value=['pkg1', 'pkg2'])
    pkgMgr.get_package_details = MagicMock(return_value={'name': 'pkg1', 'version': '1.0.0'})
    result = pkgMgr.get_packages()
    assert result == {'pkg1': [{'name': 'pkg1', 'version': '1.0.0', 'source': 'PkgMgr'}]}


# Generated at 2022-06-23 00:34:30.220692
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    mgr = CLIMgr()
    mgr.CLI = 'python'
    assert (mgr.is_available() == True)


# Generated at 2022-06-23 00:34:36.624033
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    # test_fake_pm is a fake package manager that inherits class PkgMgr
    # test_fake_pm.is_available() should return True
    # test_fake_pm.list_installed() should return a list of packages with len(list) > 0
    # test_fake_pm.get_package_details(package) should return a dict with package information
    # test_fake_pm.get_packages() should return a dict with lists of dicts of packages

    results = test_fake_pm().get_packages()
    if not results:
        raise AssertionError("get_packages of test_fake_pm returned no results")
    for name, packages in results.items():
        if not name:
            raise AssertionError("one of the names returned by get_packages of test_fake_pm was empty")

# Generated at 2022-06-23 00:34:39.501045
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    
    pkg_mgr = PkgMgr()
    assert pkg_mgr.is_available() == False


# Generated at 2022-06-23 00:34:48.476205
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCLIMgr(CLIMgr):
        CLI = 'test'
    test_cli_mgr = TestCLIMgr()
    from ansible.module_utils._text import to_text
    def get_bin_path(test):
        return "test_dir"
    test_cli_mgr.get_bin_path = get_bin_path
    assert test_cli_mgr.is_available() == True

    def get_bin_path(test):
        raise ValueError("test exception")
    test_cli_mgr.get_bin_path = get_bin_path
    assert test_cli_mgr.is_available() == False


# Generated at 2022-06-23 00:34:49.563353
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    testobj = PkgMgr()
    assert testobj

# Generated at 2022-06-23 00:34:59.957937
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    pkg_mgrs = get_all_pkg_managers()
    assert len(pkg_mgrs) > 0, "get_all_pkg_managers() should return at least one package manager"
    for pkg_mgr in pkg_mgrs.values():
        assert hasattr(pkg_mgr, 'is_available'), "method is_available does not exist for package manager:  {0}".format(pkg_mgr)
        assert callable(getattr(pkg_mgr, 'is_available')), "method is_available is not callable for package manager: {0}".format(pkg_mgr)
        assert hasattr(pkg_mgr, 'CLI'), "attribute CLI does not exist for package manager: {0}".format(pkg_mgr)

# Generated at 2022-06-23 00:35:01.729052
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    print("Test: PkgMgr_get_package_details")



# Generated at 2022-06-23 00:35:11.808211
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class dummyPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['pkg1', 'pkg2', 'pkg1']
        def get_package_details(self, package):
            return {'name': package, 'version': '0.0', 'source': 'dummy'}

    dummy_mgr = dummyPkgMgr()
    dummy_mgr_result = dummy_mgr.get_packages()
    assert dummy_mgr_result['pkg1'][0]['source'] == 'dummy'
    assert len(dummy_mgr_result['pkg2']) == 1



# Generated at 2022-06-23 00:35:13.850404
# Unit test for constructor of class LibMgr
def test_LibMgr():
    try:
        LibMgr()
        assert True
    except:
        assert False


# Generated at 2022-06-23 00:35:15.828756
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    pkg_managers = get_all_pkg_managers()
    assert len(pkg_managers) > 0

# Generated at 2022-06-23 00:35:18.491955
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():

    class TestLibMgr(LibMgr):
        LIB = 'os'

    lib_mgr = TestLibMgr()
    assert lib_mgr.is_available()


# Generated at 2022-06-23 00:35:20.587614
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():

    assert PkgMgr.list_installed(1) == NotImplemented


# Generated at 2022-06-23 00:35:23.698350
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True
    tpm = TestPkgMgr()
    assert tpm.is_available() is True

# Generated at 2022-06-23 00:35:29.825785
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():

    # Create mock object for CLIMgr
    CLIMgrInst = CLIMgr()
    CLIMgrInst.CLI = 'bogus_cli'
    CLIMgrInst._cli = 'bogus_cli'

    # Call the method
    assert CLIMgrInst.is_available() == True

    # Assert the CLI variable is set to the command path
    assert CLIMgrInst._cli == 'bogus_cli'



# Generated at 2022-06-23 00:35:37.605645
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    import sys
    sys.path.append('library')
    import choco
    import yum
    yum_mgr = yum.YumMgr()
    yum_mgr.is_available()
    yum_mgr.list_installed()
    if len(yum_mgr.list_installed()) > 0:
        yum_mgr.get_package_details(yum_mgr.list_installed()[0])
    choco_mgr = choco.ChocoMgr()
    choco_mgr.is_available()
    choco_mgr.list_installed()
    if len(choco_mgr.list_installed()) > 0:
        choco_mgr.get_package_details(choco_mgr.list_installed()[0])


# Generated at 2022-06-23 00:35:39.192738
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    assert PkgMgr.list_installed() is None



# Generated at 2022-06-23 00:35:43.089121
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    print('Testing %s' % test_CLIMgr.__name__)
    pm = CLIMgr()
    assert pm._cli is None, 'CLI should be None after instantiation of class'



# Generated at 2022-06-23 00:35:47.847556
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    from ansible.module_utils.common._utils import get_all_subclasses
    
    for mgr in get_all_subclasses(CLIMgr):
        if mgr not in (CLIMgr,):
            print("Testing: %s" % mgr.__name__)
            assert mgr().is_available() == True

# Generated at 2022-06-23 00:35:52.294435
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():

    for pkg_mgr_class in get_all_pkg_managers().values():
        pkg_mgr = pkg_mgr_class()
        assert pkg_mgr.is_available()
        installed_pkgs = pkg_mgr.list_installed()
        assert installed_pkgs

# Generated at 2022-06-23 00:35:59.247123
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def __init__(self):
            self.installed_package_list = ['a', 'b']
            self.get_package_details_return_value = {'name': 'name', 'version': 'version'}
            super(TestPkgMgr, self).__init__()

        def is_available(self):
            return True

        def list_installed(self):
            return self.installed_package_list

        def get_package_details(self, package):
            return self.get_package_details_return_value

    test_pkg_mgr = TestPkgMgr()
    packages = test_pkg_mgr.get_packages()
    assert set(packages.keys()) == {'name'}

# Generated at 2022-06-23 00:36:01.709368
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    cm = CLIMgr()
    assert not cm.is_available()

# Generated at 2022-06-23 00:36:05.490458
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    # Test if the CLI command returns a valid path or not
    assert CLIMgr.is_available("/usr/bin/apt") == True
    assert CLIMgr.is_available("/usr/bin/not_available") == False

# Generated at 2022-06-23 00:36:12.406508
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():

    managers = get_all_pkg_managers()
    if len(managers) != 0:
        assert 'apt' in managers
        assert 'yum' in managers
        assert 'zypper' in managers
        assert 'pkgng' in managers
        assert 'apk' in managers
        assert 'pacman' in managers
        assert 'pkg5' in managers
        assert 'port' in managers
        assert 'brew' in managers
        assert 'pkg' in managers
        assert 'rpm' in managers

# Generated at 2022-06-23 00:36:18.416055
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCLIMgr(CLIMgr):
        CLI = 'test'
    test_cli_mgr = TestCLIMgr()
    res = test_cli_mgr.is_available()
    assert res == False, 'is_available failed'
    global get_bin_path_res
    get_bin_path_res = None
    res = test_cli_mgr.is_available()
    assert res == False, 'is_available failed'


# Generated at 2022-06-23 00:36:21.867171
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    pkg = PkgMgr()
    try:
        info = pkg.get_package_details('python')
        assert False, "calling get_package_details() of class PkgMgr (abstract class) should throw NotImplementedError"
    except NotImplementedError:
        pass


# Generated at 2022-06-23 00:36:23.188393
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    assert isinstance(get_all_pkg_managers(), dict)

# Generated at 2022-06-23 00:36:24.177230
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    assert PkgMgr()

# Generated at 2022-06-23 00:36:29.015179
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    def import_(name):
        raise ImportError()
    import_original = __import__
    __import__ = import_
    lm = LibMgr()
    lm.LIB = 'this is not a valid package name'
    assert lm.is_available() == False
    import_ = import_original

# Generated at 2022-06-23 00:36:30.177247
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    assert CLIMgr().is_available() == False

# Generated at 2022-06-23 00:36:32.481287
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    test_object = CLIMgr()
    test_object.CLI = "ansible-galaxy"
    assert test_object.is_available() == True

# Generated at 2022-06-23 00:36:36.324061
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    testCases = [
        ('yum', '/usr/bin/yum'),
        ('rpm', '/bin/rpm'),
    ]

    for cli, expected in testCases:
        cm = CLIMgr()
        cm.CLI = cli
        actual = cm.is_available()
        if actual:
            actual = cm._cli
        assert expected == actual

# Generated at 2022-06-23 00:36:47.416757
# Unit test for method get_packages of class PkgMgr

# Generated at 2022-06-23 00:36:57.314103
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    
    class TestPkgMgr(PkgMgr):
        def __init__(self):
            self.package_details_dict = {'name':'test_pkgmgr', 'version':'1.0', 'source':'test_pkgmgr'}
        def is_available(self):
            return True
        def list_installed(self):
            return [1]
        def get_package_details(self, package):
            return self.package_details_dict

    test_pkgmgr = TestPkgMgr()
    installed_packages = test_pkgmgr.get_packages()

    assert installed_packages.get('test_pkgmgr') == [{'name':'test_pkgmgr', 'version':'1.0', 'source':'test_pkgmgr'}]

# Generated at 2022-06-23 00:37:04.012212
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():

    """
    This unit test is written to test if the function is_available() is able to determine the availability of the
    package manager.
    """

    c = CLIMgr()
    c.CLI = "uname"
    assert c.is_available()
    c.CLI = "nonexist"
    assert not c.is_available()

# End of unit test for method is_available of class CLIMgr()
