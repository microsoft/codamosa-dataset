

# Generated at 2022-06-23 00:27:08.496428
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    assert PkgMgr()


# Generated at 2022-06-23 00:27:10.375406
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    obj = CLIMgr()
    assert obj._cli is None

# Generated at 2022-06-23 00:27:17.288560
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    def pkg_mgr_list_installed(pkg_mgr):
        try:
            pkg_mgr().list_installed()
            return True
        except:
            return False
    for pkg_mgr_class in get_all_subclasses(PkgMgr):
        if pkg_mgr_class.__name__.lower() == 'PkgMgr':
            continue
        assert pkg_mgr_list_installed(pkg_mgr_class)

# Generated at 2022-06-23 00:27:28.497711
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():

    class TestPkgMgr(PkgMgr):

        def is_available(self):
            return True

        def list_installed(self):
            return ['foo', 'bar']

        def get_package_details(self, package):
            if package == 'foo':
                return {'name': 'foo', 'version': '2.0'}
            elif package == 'bar':
                return {'name': 'foo', 'version': '1.0'}
            else:
                raise AssertionError("This line should not be reached")

    test_pkg_mgr = TestPkgMgr()
    package_details = test_pkg_mgr.get_packages()

    # Check number of packages
    assert len(package_details) == 1

    # Check package list length

# Generated at 2022-06-23 00:27:31.640446
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    package_managers = get_all_pkg_managers()
    for pkg_mgr in package_managers:
        assert package_managers[pkg_mgr]().is_available()

# Generated at 2022-06-23 00:27:33.591139
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    print ("Testing if class CLIMgr can return true")
    CLIMgr().is_available()


# Generated at 2022-06-23 00:27:35.693350
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    libmgr = LibMgr()
    assert not libmgr.is_available()


# Generated at 2022-06-23 00:27:36.754132
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    c = CLIMgr()
    assert c

# Generated at 2022-06-23 00:27:37.881060
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    mgr = CLIMgr()
    assert mgr

# Generated at 2022-06-23 00:27:42.782572
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():

    class AptMgr(CLIMgr):
        CLI = 'apt'

    class CpanMgr(CLIMgr):
        CLI = 'cpan'

    class PkgMgr(PkgMgr):
        pass

    pkg_mgrs = get_all_pkg_managers()

    assert pkg_mgrs['aptmgr'] == AptMgr
    assert 'pkgmgr' not in pkg_mgrs
    assert 'cpanmgr' in pkg_mgrs

# Generated at 2022-06-23 00:27:45.687808
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    assert PkgMgr.list_installed() is None, "Method PkgMgr.list_installed() returned %s instead of None" % PkgMgr.list_installed()


# Generated at 2022-06-23 00:27:49.408633
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    all_pkg_managers = get_all_pkg_managers()
    assert all_pkg_managers
    assert all_pkg_managers['apt']
    assert all_pkg_managers['dnf']
    assert all_pkg_managers['zypper']


# Generated at 2022-06-23 00:27:52.891551
# Unit test for constructor of class LibMgr
def test_LibMgr():
    package_mgr = LibMgr()
    # test for instance of class LibMgr
    assert isinstance(package_mgr, LibMgr)
    # test for information of instance LibMgr
    assert package_mgr is not None

# Generated at 2022-06-23 00:27:54.698015
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    lm = LibMgr()
    lm.LIB = ''
    assert lm.is_available() == False


# Generated at 2022-06-23 00:27:59.981869
# Unit test for constructor of class PkgMgr
def test_PkgMgr():

    class TestPkgMgr(PkgMgr):

        def __init__(self):
            super(TestPkgMgr, self).__init__()

        def is_available(self):
            pass

        def list_installed(self):
            pass

        def get_package_details(self, package):
            pass

    assert TestPkgMgr()


# Generated at 2022-06-23 00:28:06.843350
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    test_results = dict()

    for pkg_mgr in get_all_pkg_managers().values():
        manager = pkg_mgr()
        if manager.is_available():
            for package in manager.list_installed():
                test_results[package] = manager.get_package_details(package)
                if 'name' not in test_results[package]:
                    del test_results[package]

    return test_results


# Generated at 2022-06-23 00:28:08.276305
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():

    assert isinstance(get_all_pkg_managers(), dict)

# Generated at 2022-06-23 00:28:16.572485
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    # Creating a class which will have the same inheritance tree as LibMgr
    class TempLibMgr(PkgMgr):
        pass

    # Creating another class which will inherit from TempLibMgr, so that is_available() is called while checking
    # availability of the package
    class DependentLibMgr(TempLibMgr):
        LIB = 'yum'

        def is_available(self):
            # Creating a temporary file which will act as 'yum' module
            with open(temp_file.name, 'r+') as file_obj:
                file_obj.write('abc')
                __import__(self.LIB)
            return super(DependentLibMgr, self).is_available()

        def list_installed(self):
            pass

        def get_package_details(self, package):
            pass


# Generated at 2022-06-23 00:28:19.342134
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestLibMgr(LibMgr):
        LIB = 'AnsibleModule'
    l = TestLibMgr()
    assert l._lib == None


# Generated at 2022-06-23 00:28:21.054440
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    lm = LibMgr()
    assert not lm.is_available()


# Generated at 2022-06-23 00:28:23.401620
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    available = True
    try:
        self._lib = __import__(self.LIB)
    except ImportError:
        available = False
    assert available == True


# Generated at 2022-06-23 00:28:26.689215
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    pkg_mgr = PkgMgr()
    assert isinstance(pkg_mgr, PkgMgr)
    assert pkg_mgr.is_available() is None


# Generated at 2022-06-23 00:28:31.582257
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class PkgMgrSub(PkgMgr):
        def is_available(self):
            pass
        def list_installed(self):
            pass
        def get_package_details(self, package):
            pass
    pkg = PkgMgrSub()
    assert pkg.get_package_details("test").keys() == ['name', 'version']

# Generated at 2022-06-23 00:28:42.850684
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    from ansible.module_utils.facts import PackageManager

    for manager in PackageManager.get_all():
        try:
            package_manager = PackageManager.factory(manager)
            packages = package_manager.get_packages()
        except Exception:
            pass
        else:
            assert isinstance(packages, dict), "PkgMgr.get_packages() must return dict"
            for pkg in packages.values():
                assert isinstance(pkg, list), "PkgMgr.get_package() must return list"
                for details in pkg:
                    assert isinstance(details, dict), "PkgMgr.get_package_details() must return dict"
                    assert 'name' in details, "PkgMgr.get_package_details() must return dict with key 'name'"

# Generated at 2022-06-23 00:28:48.818268
# Unit test for constructor of class PkgMgr
def test_PkgMgr():

    class TestPkgMgr(PkgMgr):

        def is_available(self):
            return True

        def is_not_available(self):
            return False

        def list_installed(self):
            return []

    obj = TestPkgMgr()
    assert obj.is_available()
    assert not obj.is_not_available()
    assert obj.list_installed() == []


# Generated at 2022-06-23 00:28:51.991075
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    available_managers = get_all_pkg_managers()
    assert len(available_managers)>0
    assert 'dpkg' in available_managers

# Generated at 2022-06-23 00:28:55.457586
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    import pytest
    class LibMgrTest(LibMgr):
        LIB = '__import__'
    pkg_mgr = LibMgrTest()
    assert pkg_mgr.is_available() == True

# Generated at 2022-06-23 00:28:56.955908
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    assert PkgMgr is not None, 'Unable to import PkgMgr class'


# Generated at 2022-06-23 00:29:01.725800
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():

    for obj in get_all_subclasses(LibMgr):
        if obj not in (CLIMgr, LibMgr):
            obj_inst = obj()
            if obj_inst.is_available():
                print(obj.__name__, obj_inst.is_available())
                assert obj_inst.is_available() == True
            if obj_inst.is_available() == False:
                print(obj.__name__, obj_inst.is_available())
                assert obj_inst.is_available() == False

test_LibMgr_is_available()


# Generated at 2022-06-23 00:29:07.124936
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    import pytest
    pm = PkgMgr()
    with pytest.raises(NotImplementedError) as nei:
        pm.is_available()
    assert str(nei.value) == 'unevaluated" class method "is_available" invoked'



# Generated at 2022-06-23 00:29:14.874545
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    """
    mock class LibMgr to test is_available method returns True / False
    """
    class MockLibMgr(LibMgr):
        def __init__(self):
            super(MockLibMgr, self).__init__()
            self._lib = None
        def is_available(self):
            try:
                self._lib = __import__("string")
                return True
            except ImportError:
                return False

    m = MockLibMgr()
    result = m.is_available()
    assert result == True
    assert m._lib is not None


# Generated at 2022-06-23 00:29:20.838419
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
	import ast
	p = PkgMgr()
	name = "name"
	version = "version"
	details = '{"name":' + '"' + name + '"' + ',"version":' + '"' + version + '"' + '}'
	
	package = ast.literal_eval(details)
	assert p.get_package_details(package) == package


# Generated at 2022-06-23 00:29:22.925097
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    try:
        obj = CLIMgr()
        assert obj is not None
    except:
        assert False

# Generated at 2022-06-23 00:29:33.792133
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    from lib.pmgr_linux import DpkgMgr, RpmMgr
    from lib.pmgr_unix import BsdMgr


    cli_mgr = CLIMgr()
    # If CLI is set and binary can be found, is_available() should return True
    # If CLI is set but binary can't be found, is_available() should return False
    # If CLI is not set, is_available() should raise an AttributeError
    try:
        cli_mgr.CLI = 'foo'
    except:
        assert False

    try:
        cli_mgr.is_available()
    except AttributeError:
        assert False

    try:
        cli_mgr.CLI = 'dpkg'
    except:
        assert False


# Generated at 2022-06-23 00:29:39.439304
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    # normal test
    class TestCLIMgr(CLIMgr):
        CLI = 'true'
    test_mgr = TestCLIMgr()
    assert test_mgr.is_available()
    test_mgr._cli = 'foo'
    assert test_mgr.is_available()
    # not exists cli test
    class Test2CLIMgr(CLIMgr):
        CLI = 'cmd'
    test2_mgr = Test2CLIMgr()
    assert not test2_mgr.is_available()

test_CLIMgr_is_available()


# Generated at 2022-06-23 00:29:48.108012
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class TestPkgMgr(PkgMgr):
        def __init__(self):
            super(PkgMgr, self).__init__()
        def list_installed(self):
            return [{'name': 'foo', 'version': '1.0.0'}]
        def is_available(self):
            pass
        def get_package_details(self, package):
            pass
    pkgmgr = TestPkgMgr()
    result = pkgmgr.get_package_details({'name': 'foo', 'version': '1.0.0'})
    assert result['name'] == 'foo'
    assert result['version'] == '1.0.0'


# Generated at 2022-06-23 00:29:58.960084
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    for cls in get_all_subclasses(PkgMgr):
        if hasattr(cls, 'list_installed'):
            if (cls.is_available()):
                ret = cls.list_installed()
                # list_installed returns a list
                if not isinstance(ret, list):
                    raise TypeError('{0} method list_installed should return a list'.format(cls.__name__))
                # the list is not empty
                if not ret:
                    raise ValueError('{0} method list_installed should not return an empty list'.format(cls.__name__))
                # all items of the list are strings

# Generated at 2022-06-23 00:30:00.383920
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    assert_equal(PkgMgr.is_available(), None)



# Generated at 2022-06-23 00:30:03.472833
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    pkg_manager_list = get_all_pkg_managers()
    assert 'apt' in pkg_manager_list
    assert 'apk' in pkg_manager_list
    assert 'dnf' in pkg_manager_list

# Generated at 2022-06-23 00:30:06.685378
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class PkgMgrClass(LibMgr):
        LIB = "test_lib"

    pkgmgr = PkgMgrClass()
    assert pkgmgr._lib == None


# Generated at 2022-06-23 00:30:11.233583
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    # Test for import error
    pkg_manager = LibMgr()
    pkg_manager.LIB = 'no_such_library'
    assert pkg_manager.is_available() == False

    # Test for successful import
    pkg_manager.LIB = 'os'
    assert pkg_manager.is_available() == True



# Generated at 2022-06-23 00:30:13.603287
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    assert PkgMgr.is_available(PkgMgr) is None



# Generated at 2022-06-23 00:30:18.152270
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class TestPkgMgr(PkgMgr):
        def get_package_details(self, package):
            return {'name': package, 'version': '1.0.0'}

    tpm = TestPkgMgr()
    assert tpm.get_package_details('package_name')['name'] == 'package_name'

# Generated at 2022-06-23 00:30:19.945593
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    pkgmgr = PkgMgr()
    assert pkgmgr is not None


# Generated at 2022-06-23 00:30:30.407133
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    import os
    import unittest
    import mock

    class TestPkgMgr(PkgMgr):
        def is_available(self):
            pass
        def list_packages(self):
            pass
        def get_package_details(self, package):
            pass

    package_manager = TestPkgMgr()
    package_manager.get_package_details = mock.Mock(return_value={"name":"test_package", "installed_version":"2.2.2", "source": "apt"})
    package_manager.list_packages = mock.Mock(return_value=["test_package", "test_package"])

    result = package_manager.get_packages()


# Generated at 2022-06-23 00:30:32.338235
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    class CLI(CLIMgr):
        CLI = 'test'

    cli = CLI()
    assert cli._cli is None

# Generated at 2022-06-23 00:30:36.418384
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    '''
    Create a PkgMgr object
    '''
    pm = PkgMgr()
    assert isinstance(pm, PkgMgr)


# Generated at 2022-06-23 00:30:44.485376
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    from ansible.module_utils.facts import PackageManager
    from ansible.module_utils.facts.packages.pkg_mgr import CLIMgr
    package_manager = PackageManager()
    package_manager._namespace = 'pkg'
    package_manager.all_package_managers = {}
    package_manager.all_package_managers['test_CLIMgr'] = {}
    package_manager.all_package_managers['test_CLIMgr']['pkg_mgr_class_name'] = 'CLIMgr'
    test_CLIMgr = CLIMgr()
    assert test_CLIMgr is not None

# Generated at 2022-06-23 00:30:47.646645
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    pkg_managers = get_all_pkg_managers()
    assert len(pkg_managers) > 0
    for pkg_mgr in pkg_managers:
        assert pkg_mgr

# Generated at 2022-06-23 00:30:50.709006
# Unit test for constructor of class LibMgr
def test_LibMgr():

    try:
        test_class = LibMgr()
        assert test_class.is_available() == False, "Test LibMgr constructor fail"
    except Exception as err:
        raise AssertionError('LibMgr constructor test fail - {0}'.format(err))


# Generated at 2022-06-23 00:30:54.823432
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    test_pkgMgr = PkgMgr()
    try:
        test_pkgMgr.is_available()
        raise AssertionError
    except NotImplementedError:
        assert True


# Generated at 2022-06-23 00:31:05.467471
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestLibMgr(LibMgr):

        LIB = 'pkg_resources'

        def list_installed(self):
            return self._lib.working_set

        def get_package_details(self, package):
            return {'name': package.project_name, 'version': package.version}

    class TestCLIMgr(CLIMgr):

        CLI = 'pip'

        def list_installed(self):
            cmd = [self._cli, 'list', '--format=freeze']
            (rc, stdout, stderr) = self._module.run_command(cmd, check_rc=True)
            installed = [pkg.split('==') for pkg in stdout.split('\n') if pkg]
            return installed


# Generated at 2022-06-23 00:31:16.890654
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    import pytest
    failed = []
    for subclass in get_all_subclasses(PkgMgr):
        if subclass.__name__.lower() in ('climgr', 'libmgr'):
            continue
        pkg = subclass()
        if not pkg.is_available():
            continue
        if subclass.__name__.lower() == 'yumpkgmgr':
            pytest.skip('yum is not supported on all os')
        try:
            for package in pkg.list_installed():
                try:
                    result = pkg.get_package_details(package)
                    print(result)
                except:
                    failed.append(subclass.__name__)
                    break
        except:
            failed.append(subclass.__name__)

# Generated at 2022-06-23 00:31:18.800548
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    assert PkgMgr.get_package_details("test_package") == "test_package"


# Generated at 2022-06-23 00:31:23.245837
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pkg_mgr = PkgMgr()
    try:
        pkg_list = pkg_mgr.list_installed()
        # no exception
        assert False
    except:
        # exception
        assert True


# Generated at 2022-06-23 00:31:25.099572
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    obj = LibMgr()
    assert not(obj.is_available())



# Generated at 2022-06-23 00:31:27.502374
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    pm = PkgMgr()
    package = {}
    assert pm.get_package_details(package) == dict()


# Generated at 2022-06-23 00:31:29.299739
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    pm = CLIMgr()
    assert pm.is_available() == False


# Generated at 2022-06-23 00:31:31.060252
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    a = PkgMgr()
    print(a)


# Generated at 2022-06-23 00:31:32.636262
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    mgr = CLIMgr()
    assert mgr is not None


# Generated at 2022-06-23 00:31:36.271935
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    class TestCLIMgr(CLIMgr):
        CLI = 'ls'
    assert TestCLIMgr().is_available() == True
    assert TestCLIMgr()._cli == get_bin_path('ls')

# Generated at 2022-06-23 00:31:40.412043
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    managers = get_all_pkg_managers()
    assert 'apt' in managers
    assert 'yum' in managers
    assert 'apk' in managers
    assert 'pacman' in managers
    assert 'pip' in managers
    assert 'port' in managers
    assert 'rpm' in managers
    assert 'snap' in managers

# Generated at 2022-06-23 00:31:44.801295
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCLIMgr(CLIMgr):
        CLI = 'nonsense'
    cli_mgr = TestCLIMgr()
    assert cli_mgr.is_available() is False


# Generated at 2022-06-23 00:31:46.739100
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pm = PkgMgr
    assert pm.is_available() == NotImplemented


# Generated at 2022-06-23 00:31:48.629926
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    assert PkgMgr.list_installed() is None


# Generated at 2022-06-23 00:31:50.972129
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    obj = CLIMgr()
    assert(obj.CLI is None)
    assert(obj._cli is None)
    

# Generated at 2022-06-23 00:32:01.183821
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestPkgMgr(CLIMgr):
        CLI = "test"

    tpm = TestPkgMgr()
    assert tpm._cli is None
    assert tpm.is_available() == False

    from ansible.module_utils.common._collections_compat import MutableMapping
    class FakeVarsModule(MutableMapping):
        def __init__(self, container=None):
            self.__container = container if container is not None else {}
        def __iter__(self):
            return iter(self.__container)
        def __len__(self):
            return len(self.__container)
        def __getitem__(self, key):
            return self.__container[key]
        def __setitem__(self, key, value):
            self.__container[key] = value

# Generated at 2022-06-23 00:32:03.741622
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class test_class(LibMgr):
        pass
    a = test_class()
    assert not a.is_available()


# Generated at 2022-06-23 00:32:06.743015
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    from ansible.module_utils.common.install import get_all_pkg_managers
    assert len(get_all_pkg_managers()) == 0
    get_all_pkg_managers()

# Generated at 2022-06-23 00:32:18.261005
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():

    class PkgMgr_get_package_details_Mocked(PkgMgr):
        def __init__(self):
            self.pkg_name = None
            self.pkg_version = None

        def list_installed(self):
            return [self.pkg_name]

        def get_package_details(self, package):
            return {'name': self.pkg_name, 'version': self.pkg_version}

    pkg_mgr = PkgMgr_get_package_details_Mocked()
    assert pkg_mgr is not None

    pkg_mgr.pkg_name = 'test_pkg_1'
    pkg_mgr.pkg_version = '1.0'

    # Test

# Generated at 2022-06-23 00:32:20.358058
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    pkg_mgrs = get_all_pkg_managers()
    assert len(pkg_mgrs) > 0

# Generated at 2022-06-23 00:32:24.343996
# Unit test for method is_available of class LibMgr

# Generated at 2022-06-23 00:32:26.158952
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    assert CLIMgr().is_available() is False
    assert LibMgr().is_available() is False

# Generated at 2022-06-23 00:32:27.805480
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    assert PkgMgr.get_package_details() is not NotImplemented

# Generated at 2022-06-23 00:32:29.296784
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    mgr = PkgMgr()
    assert mgr.__class__.__name__ == 'PkgMgr'
    # TODO: More unit tests to be added


# Generated at 2022-06-23 00:32:36.055915
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class MyLibMgr(LibMgr):
        LIB = "pip"

    p = MyLibMgr()
    p.is_available()
    assert p._lib is not None

    assert "is_available" in dir(p)
    assert "list_installed" in dir(p)
    assert "get_package_details" in dir(p)
    assert "get_packages" in dir(p)


# Generated at 2022-06-23 00:32:39.479050
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    obj = CLIMgr()
    obj.CLI = 'test'
    is_available = obj.is_available()
    assert is_available==False

# Generated at 2022-06-23 00:32:46.415173
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class FakePkgMgr(PkgMgr):
        def is_available(self):
            pass
        def list_installed(self):
            return [{'name': 'foo'}]
        def get_package_details(self, package):
            pass
    pkg = FakePkgMgr()
    assert pkg.get_package_details({'name': 'foo'})['name'] == 'foo'

# Generated at 2022-06-23 00:32:49.301154
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestLibMgr(LibMgr):

        LIB = "unittest"

    test_mgr = TestLibMgr()
    assert test_mgr.is_available() is False


# Generated at 2022-06-23 00:32:52.873372
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():

    # Instance of PkgMgr
    # Tested method should raise a TypeError
    mgr = PkgMgr()

    try:
        mgr.is_available()
    except TypeError:
        pass



# Generated at 2022-06-23 00:33:01.000496
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    class TestPkgMgr(PkgMgr):
        def __init__(self):
            self.installed = []
            super(TestPkgMgr, self).__init__()

        def list_installed(self):
            return self.installed

        def get_package_details(self, package):
            return {'name': package}

    p = TestPkgMgr()

    # test empty list
    assert(p.list_installed() == [])

    # test list with items
    p.installed = ["foo", "bar"]
    assert(p.list_installed() == ["foo", "bar"])

    # test with set
    p.installed = set(["foo", "bar"])
    assert(sorted(p.list_installed()) == ["bar", "foo"])


# Generated at 2022-06-23 00:33:04.288974
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    from ansible.module_utils.ansible_release import __version__ as ansible_version
    assert LibMgr().is_available() is True
    

# Generated at 2022-06-23 00:33:11.212409
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class FakePkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['pkg1', 'pkg2', 'pkg3', 'pkg2']
        def get_package_details(self, package):
            return {'name': 'pkg' + package[-1], 'version': '1.0'}

    fpm = FakePkgMgr()
    packages = fpm.get_packages()
    assert packages
    assert packages['pkg1']
    assert packages['pkg2']
    assert packages['pkg3']

# Generated at 2022-06-23 00:33:23.292459
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    from ansible.module_utils.os_pkg import APT, PIP, Yum, ZYpp, Rpm, Dnf, Pkg, Pkgin, Pkgng, Homebrew, Portage, Pacman
    from ansible.module_utils.os_pkg import DPKG, RPM
    pkg_managers = {'apt': APT, 'pip': PIP, 'yum': Yum, 'zypp': ZYpp, 'rpm': Rpm, 'dnf': Dnf, 'pkg': Pkg, 'pkgin': Pkgin,
                    'pkgng': Pkgng, 'homebrew': Homebrew, 'portage': Portage, 'pacman': Pacman, 'dpkg': DPKG, 'rpm': RPM}
    assert get_all_pkg_managers() == pkg_managers

# Generated at 2022-06-23 00:33:26.567587
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    cli_mgr = CLIMgr()
    result = cli_mgr.is_available()
    assert result is True or result is False


# Generated at 2022-06-23 00:33:29.810653
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    from ansible.module_utils.facts.packages import AptPkgMgr
    assert AptPkgMgr().get_package_details('ansible')['name'] == 'ansible'

# Generated at 2022-06-23 00:33:30.929360
# Unit test for constructor of class LibMgr
def test_LibMgr():
    assert LibMgr


# Generated at 2022-06-23 00:33:35.505588
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    package_manager_dict = get_all_pkg_managers()
    assert package_manager_dict
    if 'os' not in package_manager_dict:
        return
    package_manager_obj = package_manager_dict['os']()
    result = package_manager_obj.is_available()
    assert result, 'Failed to locate package manager'

# Generated at 2022-06-23 00:33:36.102056
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    pass

# Generated at 2022-06-23 00:33:37.509524
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    assert isinstance(get_all_pkg_managers(), dict), 'Could not get dict'

# Generated at 2022-06-23 00:33:40.870234
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class PyPkgMgr(LibMgr):
        LIB = 'platform'

    pkg_mgr = PyPkgMgr()
    assert not pkg_mgr.is_available()


# Generated at 2022-06-23 00:33:42.136088
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    assert isinstance(get_all_pkg_managers(), dict)

# Generated at 2022-06-23 00:33:45.936891
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    mgr = LibMgr()
    # Test case #1
    mgr.LIB = 'json'
    assert mgr.is_available()
    # Test case #2
    mgr.LIB = 'jsonn'
    assert not mgr.is_available()


# Generated at 2022-06-23 00:33:48.357780
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    managers = get_all_pkg_managers()
    assert 'dnf' in managers
    assert 'apt' in managers


# Generated at 2022-06-23 00:33:51.340556
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    class PkgMgr_test(PkgMgr):
        pass
    pkgr = PkgMgr_test()
    assert pkgr is not None


# Generated at 2022-06-23 00:33:52.511253
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    pass


# Generated at 2022-06-23 00:33:54.138693
# Unit test for constructor of class LibMgr
def test_LibMgr():
    package = LibMgr()
    assert package._lib is None



# Generated at 2022-06-23 00:33:55.785976
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    pk = PkgMgr()
    assert not pk


# Generated at 2022-06-23 00:34:00.927740
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    cli_path = get_bin_path('yum')
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.facts.packages.yum import Yum
    yum = Yum()
    assert(yum.is_available())


# Generated at 2022-06-23 00:34:02.674303
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    assert CLIMgr.is_available(CLIMgr) == False

# Generated at 2022-06-23 00:34:06.860774
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    data = {
        'CLI': 'pytest'
    }
    cli_mgr = CLIMgr()
    assert cli_mgr.CLI is None


# Generated at 2022-06-23 00:34:16.887531
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    class DummyPkgMgr(PkgMgr):
        def __init__(self):
            self.packages = [{'name': 'Package1', 'version': '1.0'},
                             {'name': 'Package2', 'version': '2.0'},
                             {'name': 'Package3', 'version': '3.0'},
                             {'name': 'Package1', 'version': '4.0'},
                             {'name': 'Package2', 'version': '5.0'},
                             {'name': 'Package3', 'version': '6.0'}]
            super(DummyPkgMgr, self).__init__()

        def list_installed(self):
            return self.packages


# Generated at 2022-06-23 00:34:18.223899
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    assert PkgMgr()

# Generated at 2022-06-23 00:34:21.565044
# Unit test for constructor of class LibMgr
def test_LibMgr():

    lm = LibMgr()
    assert not lm.is_available()

    lm._lib = True
    assert lm.is_available()



# Generated at 2022-06-23 00:34:24.781222
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class MockLibMgr(LibMgr):
        LIB = 'testlib'
    obj = MockLibMgr()
    assert obj._lib is None
    assert obj.is_available() is False


# Generated at 2022-06-23 00:34:31.815720
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class PkgMgr_Test(PkgMgr):
        def is_available(self):
            pass
        def list_installed(self):
            return ["test_pkg_1", "test_pkg_2", "test_pkg_3"]
        def get_package_details(self, package):
            package_dict = {}
            if package == "test_pkg_1":
                package_dict['name'] = "test_pkg_1"
                package_dict['version'] = "test_pkg_1_ver_1"
            elif package == "test_pkg_2":
                package_dict['name'] = "test_pkg_2"
                package_dict['version'] = "test_pkg_2_ver_1"
                package_dict['arch'] = "test_pkg_2_arch_1"
                package

# Generated at 2022-06-23 00:34:42.210587
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    import unittest
    import tempfile
    import os
    from ansible.module_utils.common._text import to_bytes

    class CLIMgrTest(unittest.TestCase):

        CLI = 'doesnotexist'

        def test_CLIMgr(self):
            self.assertEqual(CLIMgrTest().is_available(), False)

    class CLIMgrTest2(unittest.TestCase):

        CLI = 'sh'

        def test_CLIMgr(self):
            self.assertEqual(CLIMgrTest2().is_available(), True)

    class CLIMgrTest3(unittest.TestCase):

        CLI = 'sh'

        def test_CLIMgr(self):
            fd, path = tempfile.mkstemp()

# Generated at 2022-06-23 00:34:44.066460
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    p = CLIMgr()
    assert p.is_available() == True

# Generated at 2022-06-23 00:34:49.984969
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    pkg_mgr_dict = get_all_pkg_managers()
    assert 'dpkg' in pkg_mgr_dict
    assert 'apt' in pkg_mgr_dict
    assert 'rpm' in pkg_mgr_dict
    assert 'yum' in pkg_mgr_dict
    assert 'dnf' in pkg_mgr_dict

# Generated at 2022-06-23 00:34:54.342251
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():

    import os
    import sys
    import platform
    import subprocess
    import pytest

    #############################################
    # Set up inputs, outputs and side effects
    #############################################

    # get_bin_path()
    # mock side effects of get_bin_path
    def mock_get_bin_path(exe_name, required=True):
        if exe_name == 'apt-get':
            exe_path = '/usr/bin/apt-get'
        elif exe_name == 'yum':
            exe_path = '/usr/bin/yum'
        else:
            raise ValueError
        return exe_path
    
    # Popen()
    # mock side effects of Popen

# Generated at 2022-06-23 00:34:55.890412
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    assert __import__('sys').version_info[0] == 2

# Generated at 2022-06-23 00:34:58.287613
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    class a(PkgMgr):
        pass
    p = a()
    print(p.list_installed())

# Generated at 2022-06-23 00:35:07.242593
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class test_PkgMgr_get_packages(PkgMgr):

        def is_available(self):
            return True

        def list_installed(self):
            return ['test_package']

        def get_package_details(self, package):
            if package == 'test_package':
                return {'name': 'test_package', 'version': '1.0', 'source': 'test'}
            else:
                return None

    tpm = test_PkgMgr_get_packages()
    expected_result = {'test_package': [{'name': 'test_package', 'version': '1.0', 'source': 'test'}]}
    res = tpm.get_packages()
    assert res == expected_result

# Generated at 2022-06-23 00:35:13.850783
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    """Unit test for constructor of class CLIMgr"""
    cm = CLIMgr()
    assert cm._cli is None

    # Set the CLI
    CLIMgr.CLI = "test"
    cm = CLIMgr()
    assert cm._cli is None

    # Now set the CLI to a system command and check if it returns a value other than None
    CLIMgr.CLI = "yum"
    cm = CLIMgr()
    assert cm._cli is not None



# Generated at 2022-06-23 00:35:20.715923
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class PkgMgrTest(PkgMgr):
        def list_installed(self):
            return ["package1", "package2", "package3"]

        def get_package_details(self, package):
            return dict(name=package, version="1", source="source")
    pkg_mgr_test = PkgMgrTest()
    installed_packages = pkg_mgr_test.get_packages()
    assert installed_packages == {'package1': [{'name': 'package1', 'version': '1', 'source': 'source'}]}

# Generated at 2022-06-23 00:35:22.644354
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pm = PkgMgr()
    assert pm.is_available() == NotImplemented


# Generated at 2022-06-23 00:35:28.803667
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class TestPkgMgr(PkgMgr):
        def get_package_details(self, package):
            return {'name': package, 'version': '2.7'}
    package_manager = TestPkgMgr()
    expected_output = {'name': 'pkgname', 'version': '2.7'}
    assert package_manager.get_package_details('pkgname') == expected_output


# Generated at 2022-06-23 00:35:36.276495
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    pkg_managers = get_all_pkg_managers()
    assert 'apkgmgr' in pkg_managers
    assert 'aptpkgmgr' in pkg_managers
    assert 'dnfpkgmgr' in pkg_managers
    assert 'pkgmgr' in pkg_managers
    assert 'pippkgmgr' in pkg_managers
    assert 'pkgngpkgmgr' in pkg_managers
    assert 'portspkgmgr' in pkg_managers
    assert 'rpmpkgmgr' in pkg_managers
    assert 'slpkgmgr' in pkg_managers

# Generated at 2022-06-23 00:35:44.055407
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():

    module_name = "ansible.module_utils.common.packaging.package_manager"

    package_managers = get_all_pkg_managers()
    assert len(package_managers) > 0
    for pkg_mgr_name, pkg_mgr in package_managers.items():
        assert pkg_mgr_name == pkg_mgr.__name__.lower()
        assert module_name in str(pkg_mgr)

# Generated at 2022-06-23 00:35:45.012721
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    assert get_all_pkg_managers()

# Generated at 2022-06-23 00:35:45.978126
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    assert True == False


# Generated at 2022-06-23 00:35:47.756547
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    pkg = PkgMgr()
    pkg.get_package_details('test')
# ======

# Generated at 2022-06-23 00:35:52.937757
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    from ansible.module_utils.distro import get_all_pkg_managers
    pkg_managers = get_all_pkg_managers()
    for pkg_manager in pkg_managers.values():
        if pkg_manager().is_available():
            assert pkg_manager().list_installed() is not None


# Generated at 2022-06-23 00:35:54.273924
# Unit test for constructor of class LibMgr
def test_LibMgr():
    cls = LibMgr()
    assert cls._lib is None

# Generated at 2022-06-23 00:35:56.062698
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    result = get_all_pkg_managers()
    assert len(result.keys()) == 12

# Generated at 2022-06-23 00:36:05.635956
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    from ansible.module_utils.package_manager.apt import CLIApt
    from ansible.module_utils.package_manager.yum import CLIYum

    pkg_mgr_cls = get_all_pkg_managers()
    apt_pkg_mgr = pkg_mgr_cls['cli_apt']()
    yum_pkg_mgr = pkg_mgr_cls['cli_yum']()

    assert isinstance(apt_pkg_mgr, CLIApt)
    assert isinstance(yum_pkg_mgr, CLIYum)

# Generated at 2022-06-23 00:36:07.356565
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
  cli_mgr = CLIMgr()
  assert cli_mgr is not None

# Generated at 2022-06-23 00:36:17.793749
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    from ansible.module_utils.package import PkgMgr, get_all_pkg_managers
    from json import dumps

    class DummyPkgMgr(PkgMgr):

        def list_installed(self):
            return ['foo']

        def get_package_details(self, package):
            return dict(name='bar')

    def pkg_mgr_pinning_order(name):
        # Return the subset containing one specific package manager.
        # By default, the order is not important: it will be sorted by package names
        if name == 'dummy':
            return {'dummy': DummyPkgMgr()}
        else:
            return get_all_pkg_managers()

    d = DummyPkgMgr()

# Generated at 2022-06-23 00:36:19.707848
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class DummyCLIMgr(CLIMgr):
        CLI = 'dummy'

    dummy = DummyCLIMgr()
    assert dummy.is_available() is True

# Generated at 2022-06-23 00:36:30.928169
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():

    pkg_mgr_dict = get_all_pkg_managers()
    assert 'aptpkgmgr' in pkg_mgr_dict
    assert 'yumpkgmgr' in pkg_mgr_dict
    assert 'dnfpkgmgr' in pkg_mgr_dict
    assert 'zyppkgmgr' in pkg_mgr_dict
    assert 'pacmanpkgmgr' in pkg_mgr_dict
    assert 'rpm_pkgmgr' in pkg_mgr_dict
    assert 'freebsd_pkgmgr' in pkg_mgr_dict
    assert 'apkpkgmgr' in pkg_mgr_dict
    assert 'yummod_pkgmgr' in pkg_mgr_dict
    assert 'dnfmod_pkgmgr' in pkg_

# Generated at 2022-06-23 00:36:35.459011
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    class TestMgr(CLIMgr):
        CLI = "/bin/test"

    test_mgr = TestMgr()
    assert hasattr(test_mgr, '_cli')
    assert test_mgr._cli is None
    assert test_mgr.CLI == "/bin/test"


# Generated at 2022-06-23 00:36:37.289685
# Unit test for constructor of class LibMgr
def test_LibMgr():

    mgr = LibMgr()
    assert mgr._lib == None
    assert mgr.LIB == None


# Generated at 2022-06-23 00:36:39.172154
# Unit test for constructor of class LibMgr
def test_LibMgr():
    libmgr = LibMgr()
    assert libmgr is not None


# Generated at 2022-06-23 00:36:40.252669
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    assert get_all_pkg_managers()

# Generated at 2022-06-23 00:36:42.825478
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class CLIMgrTest(CLIMgr):
        CLI = 'ls'
    assert CLIMgrTest().is_available()


# Generated at 2022-06-23 00:36:45.894066
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class A(LibMgr):
        LIB = None

    a = A()
    assert a.is_available() == False



# Generated at 2022-06-23 00:36:56.361700
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    class TestPkgMgr(PkgMgr):

        def is_available(self):

            return True

        def list_installed(self):

            return ['package_A-1.2.3', 'package_A-1.2.4', 'package_B-1.2.5']

        def get_package_details(self, package):

            details = package.split('-')
            return {'name': details[0], 'version': details[1]}

    test = TestPkgMgr()
    packages = test.get_packages()
    assert len(packages) == 2
    assert len(packages['package_A']) == 2
    assert len(packages['package_B']) == 1
    assert packages['package_A'][0]['name'] == 'package_A'

# Generated at 2022-06-23 00:37:04.011953
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    # Test with an existing binary
    class TestCLIMgr(CLIMgr):
        CLI = "cat"

    cli_mgr = TestCLIMgr()
    assert cli_mgr.is_available()

    # Test with a non-existing binary
    class TestCLIMgr(CLIMgr):
        CLI = "blablabla"

    cli_mgr = TestCLIMgr()
    assert not cli_mgr.is_available()


# Generated at 2022-06-23 00:37:12.467191
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    from ansible.module_utils.packaging import CLIMgr
    import tempfile
    import os
    # Test the case CLIMgr._cli is not None
    testCliMgr = CLIMgr()
    testCliMgr._cli = 'random_string'
    assert testCliMgr.is_available()

    # Test the case CLIMgr._cli is None
    testCliMgr._cli = None
    # Create a temp file and add it to the PATH
    with tempfile.NamedTemporaryFile(delete=False) as f:
        temp_file = f.name
    f.close()
    os.chmod(temp_file, 0o755)
    # Add the temp file to the current PATH
    path_old = os.environ.get('PATH', '')