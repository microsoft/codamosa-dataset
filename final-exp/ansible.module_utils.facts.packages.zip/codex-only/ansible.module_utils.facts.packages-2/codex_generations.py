

# Generated at 2022-06-23 00:27:05.376709
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    assert isinstance(get_all_pkg_managers(), dict)

# Generated at 2022-06-23 00:27:06.522081
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    pm1 = PkgMgr()
    assert pm1 is not None


# Generated at 2022-06-23 00:27:07.770980
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    climgr = CLIMgr()
    assert type(climgr) == CLIMgr

# Generated at 2022-06-23 00:27:18.567151
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    test_class = PkgMgr()
    test_class.list_installed = lambda: [{'name': 'test1', 'version': '1'}, {'name': 'test2', 'version': '2'}]
    test_class.get_package_details = lambda package: {'name': package['name'], 'version': package['version']}
    expected = {'test1': [{'name': 'test1', 'version': '1'}], 'test2': [{'name': 'test2', 'version': '2'}]}
    assert test_class.get_packages() == expected, "Test failed: expected %s and got %s" % (expected, test_class.get_packages())


# Generated at 2022-06-23 00:27:19.254048
# Unit test for constructor of class LibMgr
def test_LibMgr():
    pip = LibMgr()
    assert pip.LIB == None
    assert pip._lib == None


# Generated at 2022-06-23 00:27:20.181896
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    pass


# Generated at 2022-06-23 00:27:26.909735
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    from ansible.module_utils import facts

    if not facts.is_linux():
        return

    c_pkg_mgr = CLIMgr()
    c_pkg_mgr.CLI = 'yum'
    assert c_pkg_mgr.is_available() == True

    c_pkg_mgr.CLI = 'zum'
    assert c_pkg_mgr.is_available() == False

# Generated at 2022-06-23 00:27:36.069195
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class PkgMgr_test(PkgMgr):

        def is_available(self):
            return True

        def list_installed(self):
            return ['package_name']

        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}

    pkg_mgr = PkgMgr_test()
    packages = pkg_mgr.get_packages()
    assert len(packages.keys()) == 1
    assert packages.get('package_name')[0]['version'] == '1.0'
    assert packages.get('package_name')[0]['name'] == 'package_name'

# Generated at 2022-06-23 00:27:43.131561
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    all_pkg_managers = get_all_pkg_managers()
    for pm_name in all_pkg_managers:
        pkg_man = all_pkg_managers[pm_name]
        if pkg_man.is_available():
            pkgs = pkg_man().get_packages()
            assert(isinstance(pkgs, dict))
            for pkg_name in pkgs:
                for pkg in pkgs[pkg_name]:
                    assert(isinstance(pkg, dict))
                    assert('name' in pkg)
                    assert('version' in pkg)
                    assert(pkg['name'] == pkg_name)
                    assert(isinstance(pkg['version'], basestring))
                    assert('release' in pkg)

# Generated at 2022-06-23 00:27:43.857033
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pass



# Generated at 2022-06-23 00:27:48.801139
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():

    class TestLibMgr(LibMgr):

        LIB = 'test_lib'

    class TestLibFail(TestLibMgr):

        LIB = 'test_failed'

    # When the class variable LIB points to module that exists the method returns True
    assert TestLibMgr().is_available()

    # When the class variable LIB points to module that does not exists the method returns False
    assert not TestLibFail().is_available()



# Generated at 2022-06-23 00:27:53.828669
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    # Check if _cli was initialized after instanciating class CLIMgr
    mgr = CLIMgr()
    assert (mgr._cli is None)
    # Check  is_available for a CLI which is not available returns True
    mgr.CLI = 'notAvailable'
    assert(mgr.is_available() == False)

# Generated at 2022-06-23 00:27:56.447320
# Unit test for constructor of class LibMgr
def test_LibMgr():

    lm = LibMgr()
    assert lm.is_available() == False
    lm._lib = None
    assert lm.is_available() == False


# Generated at 2022-06-23 00:28:04.181340
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class PyPkgMgr(PkgMgr):

        def is_available(self):
            return True

        def list_installed(self):
            return False

        def get_package_details(self, package):
            return {'name': 'package_1', 'version': '1.0.0'}

    b = PyPkgMgr().get_package_details('test_package')
    assert b['name'] == 'package_1'
    assert b['version'] == '1.0.0'

# Generated at 2022-06-23 00:28:13.881296
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    import os
    import tempfile
    import shutil
    import unittest
    import ansible.module_utils.common._utils as utils
    from ansible.module_utils.common._utils import get_all_subclasses

    class TestMgr(CLIMgr):
        CLI = "foobar"

    class TestMgr2(CLIMgr):
        CLI = "foobar2"

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.test_dir = tempfile.mkdtemp()
            self.cwd = os.getcwd()
            os.chdir(self.test_dir)

        def tearDown(self):
            os.chdir(self.cwd)
            shutil.rmtree(self.test_dir)


# Generated at 2022-06-23 00:28:16.254553
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():

    # TODO: implement this test
    assert False, "FIXME: Implement this method"


# Generated at 2022-06-23 00:28:22.331353
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    from ansible.module_utils.common.pkg.package_manager.yum import Yum

    '''
    result = PkgMgr.get_all_pkg_managers()

    assert('yum' in result)
    assert('aix' in result)
    assert(result['yum'] is Yum)
    '''
    assert(Yum.is_available() is True)

test_PkgMgr()

# Generated at 2022-06-23 00:28:33.508117
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    pkg_managers = get_all_pkg_managers()

    assert 'apt' in pkg_managers
    assert 'dnf' in pkg_managers
    assert 'ebuild' in pkg_managers
    assert 'homebrew' in pkg_managers
    assert 'macports' in pkg_managers
    assert 'pacman' in pkg_managers
    assert 'pkg5' in pkg_managers
    assert 'portage' in pkg_managers
    assert 'rpm' in pkg_managers
    assert 'slpkg' in pkg_managers
    assert 'urpm' in pkg_managers
    assert 'yum' in pkg_managers
    assert 'zypper' in pkg_managers



# Generated at 2022-06-23 00:28:44.234598
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    from datetime import datetime
    import json
    import base64
    from ansible.module_utils.facts.os_specific import Linux
    from ansible.module_utils.facts.os_specific import Windows
    from ansible.module_utils.facts.os_specific import Solaris
    from ansible.module_utils.facts.os_specific import SmartOS
    from ansible.module_utils.facts.os_specific import OpenBSD
    from ansible.module_utils.facts.os_specific import FreeBSD

    # load json file into dictionary
    with open('test/pkgmgr_output.json') as f:
        data = json.load(f)

    tests = []
    # Create tests for Linux
    linux_os = Linux()
    linux_tests = data['linux']

# Generated at 2022-06-23 00:28:47.504665
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    class dummy(PkgMgr):
        def list_installed(self):
            return "test"

    d = dummy()
    assert isinstance(d.list_installed(), str)


# Generated at 2022-06-23 00:28:49.338803
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pkgmgr = PkgMgr()
    assert not pkgmgr.is_available()



# Generated at 2022-06-23 00:28:52.914310
# Unit test for constructor of class LibMgr
def test_LibMgr():
    manager = LibMgr()
    assert manager.__class__.__name__ == "LibMgr"
    assert manager._cli is None
    assert manager._lib is None


# Generated at 2022-06-23 00:28:54.954916
# Unit test for constructor of class LibMgr
def test_LibMgr():
    """ Test for class LibMgr """

    lm = LibMgr()
    assert lm._lib is None


# Generated at 2022-06-23 00:28:58.468901
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    from ansible.module_utils.facts import default as default_mgr

    pkg_mgrs = get_all_pkg_managers()
    assert pkg_mgrs is not None
    assert pkg_mgrs.keys() is not None
    assert len(pkg_mgrs) > 10
    assert 'default' in pkg_mgrs.keys()
    assert pkg_mgrs['default'] == default_mgr

# Generated at 2022-06-23 00:28:59.820463
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    pass



# Generated at 2022-06-23 00:29:00.474294
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr()

# Generated at 2022-06-23 00:29:09.982632
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    import os
    old_value = os.environ.get('PATH', '')
    try:
        os.environ['PATH'] = '/bin'
        if CLIMgr().is_available():
            raise AssertionError("CLIMgr.is_available() returned True for non-existent binary")
        os.environ['PATH'] = os.pathsep.join([os.environ['PATH'], '/sbin'])
        if not CLIMgr().is_available():
            raise AssertionError("CLIMgr.is_available() returned False for existing binary")
    finally:
        os.environ['PATH'] = old_value

# Generated at 2022-06-23 00:29:12.045227
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():

    assert(PkgMgr.is_available(PkgMgr()) == False)


# Generated at 2022-06-23 00:29:14.573219
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    all_pkg_managers = get_all_pkg_managers()
    for cls_name in all_pkg_managers:
        cls = all_pkg_managers[cls_name]
        if cls.is_available():
            all_installed_pkgs = cls.list_installed()
            assert isinstance(all_installed_pkgs, list)
            #TODO
            assert 1 == 2


# Generated at 2022-06-23 00:29:18.406832
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():

    class FakeLibMgr(LibMgr):

        LIB = 'ansible.module_utils.fake_lib_mgr'

    lib = FakeLibMgr()
    assert lib.is_available()


# Generated at 2022-06-23 00:29:23.544791
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    from . import CLIMgr

    class TestCLIMgr(CLIMgr):
        CLI = "fake_cli"

    # when fake_cli does not exist, it should return False
    manager = TestCLIMgr()
    assert not manager.is_available()

    # when fake_cli does exist, it should return True
    import os
    with open("fake_cli", "w") as fd:
        fd.write("#!")
    try:
        manager = TestCLIMgr()
        manager.is_available()
        assert manager._cli == "fake_cli"
    finally:
        os.remove("fake_cli")

# Generated at 2022-06-23 00:29:27.035464
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():

    all_pkg_managers = get_all_pkg_managers()
    assert all_pkg_managers
    assert get_all_pkg_managers().keys() == ['apt', 'apk', 'dnf', 'emerge', 'brew', 'yum']

# Generated at 2022-06-23 00:29:29.103758
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():

    assert PkgMgr.is_available(PkgMgr()) == False

# Generated at 2022-06-23 00:29:30.588110
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    pm_obj = PkgMgr()


# Generated at 2022-06-23 00:29:33.657628
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    assert issubclass(PkgMgr, object)
    pm = PkgMgr()
    assert pm.list_installed.__class__ is not None


# Generated at 2022-06-23 00:29:35.369834
# Unit test for constructor of class LibMgr
def test_LibMgr():

    class Foo(LibMgr):
        pass

    foo = Foo()
    assert foo._lib is None



# Generated at 2022-06-23 00:29:37.261975
# Unit test for constructor of class CLIMgr
def test_CLIMgr():

    assert CLIMgr()

# Generated at 2022-06-23 00:29:42.711453
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    mm = get_all_pkg_managers()
    assert 'apt' in mm
    assert 'dnf' in mm
    assert 'yum' in mm
    assert 'apk' in mm
    assert 'pacman' in mm
    assert 'nix' in mm
    assert 'eopkg' in mm

# Generated at 2022-06-23 00:29:45.409734
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    cli_mgr = CLIMgr()
    is_available = cli_mgr.is_available()
    return is_available

# Generated at 2022-06-23 00:29:46.054131
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pass

# Generated at 2022-06-23 00:29:49.384957
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    cli_mgr = CLIMgr()
    cli_mgr.CLI = "ls"
    cli_mgr.is_available()
    assert(cli_mgr._cli.endswith("ls"))

# Generated at 2022-06-23 00:29:51.254356
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    vlc = CLIMgr()
    result = vlc.is_available()
    assert result == False


# Generated at 2022-06-23 00:29:54.319468
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    for obj in get_all_pkg_managers().values():
        cli = obj()
        if cli.is_available():
            assert len(cli.list_installed()) > 0

# Generated at 2022-06-23 00:29:55.797127
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    assert PkgMgr.list_installed() == None


# Generated at 2022-06-23 00:29:59.416819
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'mock'
    test_mgr = TestLibMgr()
    assert test_mgr.is_available() == False
    test_mgr._lib = 'something'
    assert test_mgr.is_available() == True


# Generated at 2022-06-23 00:30:00.807921
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
  assert True == PkgMgr.is_available()


# Generated at 2022-06-23 00:30:05.000508
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    class PkgMgrTest(PkgMgr):
        def is_available(self):
            pass
        def list_installed(self):
            pass
        def get_package_details(self, package):
            pass

    pkgmgr = PkgMgrTest()
    assert(pkgmgr is not None)
    return True


# Generated at 2022-06-23 00:30:16.150441
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def list_installed(self):
            return ['php7.0-common-7.0.27-0ubuntu0.16.04.1']

        def get_package_details(self, package):
            return {'name': 'php7.0-common', 'version': '7.0.27-0ubuntu0.16.04.1'}

    tpm = TestPkgMgr()
    pkg = tpm.get_packages()
    assert(pkg)
    for i in pkg:
        assert(i == 'php7.0-common')
        for j in pkg[i]:
            for k, v in j.items():
                if k == 'name':
                    assert(v == 'php7.0-common')

# Generated at 2022-06-23 00:30:17.539132
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    pm = CLIMgr()
    assert pm is not None


# Generated at 2022-06-23 00:30:22.359588
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    for cls in get_all_pkg_managers().values():
        if issubclass(cls, CLIMgr):
            assert cls().is_available() == bool(get_bin_path(cls.CLI)), "CLIMgr.is_available for class '{}'".format(cls)

# Generated at 2022-06-23 00:30:31.777839
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class MockPkgMgr(PkgMgr):
        def is_available(self):
            return True

        def list_installed(self):
            return ['pkg1', 'pkg2', 'pkg3']

        def get_package_details(self, package):
            return {'name': package, 'version': '0.1'}
    mock_pkgmgr = MockPkgMgr()
    packages = mock_pkgmgr.get_packages()

# Generated at 2022-06-23 00:30:43.720556
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.common._text import to_text
    from ansible.module_utils.facts.packages.yum import Yum
    from ansible.module_utils.facts.packages.dnf import Dnf
    from ansible.module_utils.facts.packages.apt import Apt

    pkgmgrs = {'yum': Yum, 'dnf': Dnf, 'apt': Apt}
    pkgs = {'yum': 'gnupg2', 'dnf': 'yum', 'apt': 'libpam-systemd'}

    for pkgmgr in pkgs.keys():
        pmgr = get_all_pkg_managers()[pkgmgr]()

# Generated at 2022-06-23 00:30:50.431420
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    # When a subclass does not override the is_available method, it is inherited from PkgMgr
    # The default implementation of is_available raises NotImplementedError
    # When raising NotImplementedError, the is_available method of the subclass returns False

    class MockPkgMgrSubclass(PkgMgr):
        pass
    mps = MockPkgMgrSubclass()
    assert mps.is_available() is False, "is_available should return False for when a subclass does not override the method"


# Generated at 2022-06-23 00:30:52.213261
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    # class CLIMgr
    assert CLIMgr().is_available() == True


# Generated at 2022-06-23 00:31:01.024881
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    class PkgMgrTest(PkgMgr):
        def list_installed(self):
            return ['a', 'b', 'c']
    pkgmgr = PkgMgrTest()
    assert pkgmgr.list_installed() == ['a', 'b', 'c']
    assert pkgmgr.get_packages() == {'a': [{'name': 'a', 'source': 'pkgmgrtest'}], 'b': [{'name': 'b', 'source': 'pkgmgrtest'}], 'c': [{'name': 'c', 'source': 'pkgmgrtest'}]}


# Generated at 2022-06-23 00:31:02.162524
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pass


# Generated at 2022-06-23 00:31:05.551199
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    # It is better to use type as object's constructor can be overridden
    assert type(CLIMgr()) == CLIMgr
    assert type(LibMgr()) == LibMgr

# Generated at 2022-06-23 00:31:09.585696
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestMgr(LibMgr):

        LIB = 'os'

    tm = TestMgr()
    assert tm.is_available()
    tm._lib = None
    assert not tm.is_available()


# Generated at 2022-06-23 00:31:10.161610
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pass

# Generated at 2022-06-23 00:31:12.559478
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    pkg_mgr = PkgMgr()
    packages = pkg_mgr.get_packages()
    assert packages == {}

# Generated at 2022-06-23 00:31:15.543664
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    class PkgMgrMock(PkgMgr):
        pass
    pkgManager = PkgMgrMock()
    assert pkgManager.list_installed() == NotImplemented


# Generated at 2022-06-23 00:31:25.742064
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    class TestPkgMgr(PkgMgr):

        def is_available(self):
            return True

        def list_installed(self):
            return ['package1', 'package2']

        def get_package_details(self, package):
            return dict(name=package, version='1.0.0')

    tpm = TestPkgMgr()
    assert tpm.get_packages() == dict(
        package1=[dict(name='package1', version='1.0.0', source='testpkgmgr')],
        package2=[dict(name='package2', version='1.0.0', source='testpkgmgr')]
    )

# Generated at 2022-06-23 00:31:37.253875
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    from ansible.module_utils.common.process import _binary_replace
    all_pkg_managers = get_all_pkg_managers()
    # all_pkg_managers.keys() = ['dnf','apt','yum','pacman','zypper','pkgng','portage','pip','apk','chocolatey','homebrew']
    for i in all_pkg_managers.keys():
        if i == 'dnf':
            class_obj = all_pkg_managers[i]
            class_obj.CLI = _binary_replace('dnf')
        elif i == 'apt':
            class_obj = all_pkg_managers[i]
            class_obj.CLI = _binary_replace('apt-get')
        elif i == 'yum':
            class_obj = all_pkg_

# Generated at 2022-06-23 00:31:38.555380
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    pass

# Generated at 2022-06-23 00:31:41.842200
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    test_class = get_all_pkg_managers()
    assert len(test_class) == 2, "Number of package manager classes should be 2, but found {}".format(len(test_class))

# Generated at 2022-06-23 00:31:53.564938
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    import subprocess
    import types

    mock_subprocess = types.ModuleType('mock_subprocess')
    mock_subprocess.CalledProcessError = subprocess.CalledProcessError
    mock_subprocess.Popen = subprocess.Popen

    def mock_get_bin_path(*args):
        return args[0]

    class TestLibMgr(LibMgr):
        LIB = 'urllib'

    test_LibMgr = TestLibMgr()
    test_LibMgr._lib = None
    assert not test_LibMgr.is_available()
    test_LibMgr._lib = mock_subprocess
    assert test_LibMgr.is_available()

    with mock.patch.object(mock_subprocess, 'Popen') as mock_popen:
        mock_popen.side

# Generated at 2022-06-23 00:31:57.909857
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pkg_managers = get_all_pkg_managers()
    for name, manager in pkg_managers.items():
        assert(hasattr(manager, 'is_available'))
        assert(callable(manager.is_available))
        assert(manager.is_available() == False)


# Generated at 2022-06-23 00:32:09.602599
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    import json
    import yaml
    class Mock_PkgMgr(PkgMgr):
        def __init__(self, name):
            self.name = name
        def is_available(self):
            return True
        def list_installed(self):
            return ['test1', 'test2', 'test3', 'test4']
        def get_package_details(self, package):
            return {'name':package, 'version':'1.2.3'}
    class Mock_PkgMgr_empty(PkgMgr):
        def __init__(self, name):
            self.name = name
        def is_available(self):
            return True
        def list_installed(self):
            return []

# Generated at 2022-06-23 00:32:11.227110
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    package_manager = CLIMgr()
    package_manager.CLI = "python"
    assert package_manager.is_available()

# Generated at 2022-06-23 00:32:12.980866
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    pkgmgr = PkgMgr()
    assert pkgmgr

# Generated at 2022-06-23 00:32:14.188428
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    object = CLIMgr()
    assert object is not None


# Generated at 2022-06-23 00:32:15.174754
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    assert PkgMgr.get_packages() == None

# Generated at 2022-06-23 00:32:26.951305
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class MockLibMgr(LibMgr):
        LIB = 'mock_lib'

        def list_installed(self):
            return ['pkg1', 'pkg2']

        def get_package_details(self, package):
            if package == 'pkg1':
                return {'name': 'pkg1', 'version': '1.0'}
            if package == 'pkg2':
                return {'name': 'pkg2', 'version': '1.0'}

    class MockCLIMgr(CLIMgr):
        CLI = 'mock_cli'

        def list_installed(self):
            return ['pkg2', 'pkg3']

        def get_package_details(self, package):
            if package == 'pkg2':
                return {'name': 'pkg2', 'version': '2.0'}

# Generated at 2022-06-23 00:32:30.385330
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = None
    obj = TestLibMgr()
    assert obj.is_available() == False


# Generated at 2022-06-23 00:32:36.552807
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    pkgs = get_all_pkg_managers()
    assert 'pacman' in pkgs
    assert 'yum' in pkgs
    assert 'apt' in pkgs
    assert 'pkgng' in pkgs
    assert 'dnf' in pkgs
    assert 'pip' in pkgs
    assert 'gem' in pkgs
    assert 'python' in pkgs

# Generated at 2022-06-23 00:32:38.922750
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    # Test for super class and the empty method
    for pkg_mgr in get_all_subclasses(PkgMgr):
        assert pkg_mgr.list_installed() == []



# Generated at 2022-06-23 00:32:51.191542
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    import inspect
    import os

    def _test_libmgr_is_available(test_obj):
        cls = test_obj['cls']
        L = inspect.getmembers(cls._lib, predicate=inspect.ismodule)
        return test_obj['name'] + os.path.sep + L[0][0].lower() == cls.LIB

    import os
    import sys

    # Fake the existence of the openvswitch library
    if getattr(sys, 'real_prefix', None):
        # We are in a virtualenv
        lib_directory = os.path.join(sys.prefix, 'local/lib/python{}.{}/site-packages'.format(sys.version_info.major, sys.version_info.minor))
        os.makedirs(lib_directory)
        open

# Generated at 2022-06-23 00:32:53.571074
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    pkgs = get_all_pkg_managers()
    assert 'apt' in pkgs
    assert 'dnf' in pkgs

# Generated at 2022-06-23 00:32:59.922447
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    # test if the object is created
    testObj = CLIMgr()
    assert isinstance(testObj, CLIMgr)

    # test when there is no cli
    testObj.CLI = 'dummy'
    assert testObj.is_available() == False

    # test when there is cli
    testObj.CLI = 'yum'
    assert testObj.is_available() == True


# Generated at 2022-06-23 00:33:03.154084
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():

    all_pkg_managers = get_all_pkg_managers()
    assert "apt" in all_pkg_managers
    assert "yum" in all_pkg_managers

# Generated at 2022-06-23 00:33:04.854130
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    try:
        cli = CLIMgr()
        assert True
    except Exception as e:
        print("Test Fail: %s" % e)
        assert False


# Generated at 2022-06-23 00:33:07.607963
# Unit test for constructor of class LibMgr
def test_LibMgr():
    try:
        test_obj = LibMgr()
        assert test_obj
    except AssertionError:
        raise AssertionError("assertion is false")


# Generated at 2022-06-23 00:33:17.638905
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgr

    def test_get_all_pkg_managers_internal(self):
        pkg_managers_list = get_all_pkg_managers()
        if not pkg_managers_list:
            return False
        if not isinstance(pkg_managers_list, dict):
            return False
        for pkg_mgr in pkg_managers_list.values():
            if not issubclass(pkg_mgr, PkgMgr) or pkg_mgr is PkgMgr:
                return False
        return True

    return test_get_all_pkg_managers_internal(PkgMgr)

# Generated at 2022-06-23 00:33:20.611369
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    """
    Tests the method is_available() of class PkgMgr.
    """
    p = PkgMgr()
    assert p.is_available() == NotImplementedError



# Generated at 2022-06-23 00:33:22.091408
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    assert False


# Generated at 2022-06-23 00:33:23.369263
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    test = PkgMgr()
    assert isinstance(test.list_installed(), list)

# Generated at 2022-06-23 00:33:29.655334
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    try:
        # Intantiate object of class PkgMgr
        pkg_mgr = PkgMgr()
        # Call method get_package_details of class PkgMgr
        pkg_mgr.get_package_details('dummy')
    except TypeError:
        print("Accepted")
    else:
        raise Exception('TypeError not raised')
    # Test passed

# Generated at 2022-06-23 00:33:33.528260
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():

    pkg_mgr_list = get_all_pkg_managers()
    assert isinstance(pkg_mgr_list, dict)
    for pkg in pkg_mgr_list:
        assert isinstance(pkg_mgr_list[pkg], object)

# Generated at 2022-06-23 00:33:36.152958
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    cli_mgr = CLIMgr()
    cli_mgr.CLI = 'tee'
    assert cli_mgr.is_available()


# Generated at 2022-06-23 00:33:37.185948
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    assert PkgMgr


# Generated at 2022-06-23 00:33:40.636351
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class CLIMgr_subclass(CLIMgr):
        CLI = "TestCLI"

    pkg_mgr = CLIMgr_subclass()
    assert not pkg_mgr.is_available()

# Generated at 2022-06-23 00:33:44.290612
# Unit test for constructor of class LibMgr
def test_LibMgr():
    ''' test_LibMgr()

        test the constructor of class LibMgr
    '''
    libMgr_obj = LibMgr()
    libMgr_obj._lib = None
    assert None == libMgr_obj._lib


# Generated at 2022-06-23 00:33:47.491114
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    obj = PkgMgr()
    try:
        result = obj.is_available()
    except Exception as e:
        if isinstance(e, NotImplementedError):
            pass
        else:
            raise


# Generated at 2022-06-23 00:33:50.481737
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class MockLibMgr(LibMgr):
        LIB = 'lib'

    lm = MockLibMgr()
    assert lm._lib is None


# Generated at 2022-06-23 00:33:54.513918
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    pkg_managers = get_all_pkg_managers()
    assert set(pkg_managers) == set(['apt', 'dnf', 'homebrew', 'pip', 'pkgng', 'portage', 'yum'])

# Generated at 2022-06-23 00:33:59.014489
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    # Dummy class for testing the is_available method of class LibMgr
    class DummyLibMgr(LibMgr):
        LIB = 'cloudinit_helpers'

    P = DummyLibMgr()
    assert P.is_available() == True
#----------------------------------------------

# Generated at 2022-06-23 00:34:11.087436
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():

    from ansible.module_utils.facts.pkg_mgr import CLIMgr, AbootMgr, AptMgr, DpkgMgr, EopkgMgr, PacmanMgr, PkgMgr, PortageMgr, RpmMgr, ZypperMgr

    # Test for the case that the package does not exist
    result = DpkgMgr().get_package_details('does_not_exist')
    assert type(result) is dict
    assert 'name' in result
    assert 'version' in result

    # Test for the case that the package exists, but no details can be retrieved
    result = AbootMgr().get_package_details('aboot')
    assert type(result) is dict
    assert 'name' in result
    assert 'version' in result

    # Test for the case that the package exists and details can

# Generated at 2022-06-23 00:34:16.870063
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class CLIMgrTest(CLIMgr):
        pass

    test_cli_mgr = CLIMgrTest()
    test_cli_mgr.CLI = "__a_non_existing_command__"
    assert False == test_cli_mgr.is_available()

    test_cli_mgr.CLI = "python"
    assert True == test_cli_mgr.is_available()

# Generated at 2022-06-23 00:34:20.283188
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():

    my_PkgMgr = PkgMgr()
    my_list = my_PkgMgr.list_installed()
    assert my_list is not None, "Test failed. Test object is None."


# Generated at 2022-06-23 00:34:22.656822
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    x = PkgMgr()
    assert x.list_installed() is None


# Generated at 2022-06-23 00:34:24.718295
# Unit test for constructor of class LibMgr
def test_LibMgr():
    lib = LibMgr()
    assert lib._lib == None
    assert isinstance(lib, PkgMgr)


# Generated at 2022-06-23 00:34:27.176881
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    sample_pkg_mgr = PkgMgr()
    pkg_mgr_list_installed = sample_pkg_mgr.list_installed()
    assert(pkg_mgr_list_installed is not None)


# Generated at 2022-06-23 00:34:28.985042
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    base_mgr = CLIMgr()
    assert base_mgr._cli is None



# Generated at 2022-06-23 00:34:29.460125
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    PkgMgr()

# Generated at 2022-06-23 00:34:30.441349
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    obj = LibMgr()
    assert isinstance(obj, LibMgr)

# Generated at 2022-06-23 00:34:31.615534
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    assert PkgMgr.list_installed() is None


# Generated at 2022-06-23 00:34:32.477456
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    assert PkgMgr()


# Generated at 2022-06-23 00:34:33.465033
# Unit test for constructor of class LibMgr
def test_LibMgr():
    assert LibMgr != None


# Generated at 2022-06-23 00:34:39.772382
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():

    class FakeMgr(PkgMgr):

        def is_available(self):
            return True

        def list_installed(self):
            pass

        def get_package_details(self, package):
            pass

    assert FakeMgr().is_available() == True

    class FakeMgr(PkgMgr):

        def is_available(self):
            return False

        def list_installed(self):
            pass

        def get_package_details(self, package):
            pass

    assert FakeMgr().is_available() == False


# Generated at 2022-06-23 00:34:44.870087
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True

        def list_installed(self):
            return []

        def get_package_details(self, package):
            return {}

    pkg = TestPkgMgr()
    assert not pkg.list_installed()
    assert pkg.is_available()


# Generated at 2022-06-23 00:34:49.373151
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = "test.test_package_manager"

    # Test that is_available finds a package when its there
    testlibmgr = TestLibMgr()
    # test that it returns True when the LIB actually exists
    assert testlibmgr.is_available()

    # Test that is_avilable returns False when the LIB doesn't exist
    class TestLibMgr2(LibMgr):
        LIB = "this_package_doesnt_exist"

    testlibmgr2 = TestLibMgr2()
    assert not testlibmgr.is_available()


# Generated at 2022-06-23 00:34:50.913617
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    obj = CLIMgr()
    assert obj


# Generated at 2022-06-23 00:34:54.294521
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True

    test_pkg_mgr = TestPkgMgr()
    assert test_pkg_mgr.is_available()

# Generated at 2022-06-23 00:34:59.369513
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class FakeCLIMgr(CLIMgr):
        CLI = 'fake'
    a = FakeCLIMgr()
    a._cli = 'fake_path'
    # This test does not work if the fake binary is in PATH
    if a.is_available():
        raise Exception('CLIMgr.is_available returning True for a binary that should not be in PATH')


# Generated at 2022-06-23 00:35:00.537446
# Unit test for constructor of class LibMgr
def test_LibMgr():
    mgr = LibMgr()
    assert mgr


# Generated at 2022-06-23 00:35:03.066778
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestClass(LibMgr):
        LIB = 'os'
    t = TestClass()
    assert t.is_available()
    assert t._lib is not None


# Generated at 2022-06-23 00:35:04.494621
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr() is not None

# Generated at 2022-06-23 00:35:07.061716
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    assert PkgMgr.is_available == LibMgr.is_available


# Generated at 2022-06-23 00:35:07.952653
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pass


# Generated at 2022-06-23 00:35:18.454400
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():

    class TestManager(LibMgr):
        def __init__(self):
            self.LIB = 'test'
            super(TestManager, self).__init__()

        def list_installed(self):
            """
            Dummy method for unit tests
            """
            pass

        def get_package_details(self):
            """
            Dummy method for unit tests
            """
            pass

    mgr = TestManager()
    assert mgr.is_available(False) == False

    class TestManager(LibMgr):
        def __init__(self):
            self.LIB = 'random'
            super(TestManager, self).__init__()

        def list_installed(self):
            """
            Dummy method for unit tests
            """
            pass


# Generated at 2022-06-23 00:35:20.335687
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():

    CLIMgr_instance = CLIMgr()
    assert not CLIMgr_instance.is_available()

# Generated at 2022-06-23 00:35:23.003470
# Unit test for constructor of class CLIMgr
def test_CLIMgr():

    obj = CLIMgr()
    assert isinstance(obj, CLIMgr)
    obj._cli = "/usr/bin/pip"
    assert obj._cli == "/usr/bin/pip"


# Generated at 2022-06-23 00:35:24.849328
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    lib = LibMgr()
    lib.LIB = 'pkg_resources'
    assert lib.is_available() == True



# Generated at 2022-06-23 00:35:25.564664
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    pass

# Generated at 2022-06-23 00:35:27.828096
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pkg_mgr = PkgMgr()
    available = pkg_mgr.is_available()
    assert(not available)

# Generated at 2022-06-23 00:35:28.962256
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    assert False, "test not implemented"


# Generated at 2022-06-23 00:35:38.044119
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    pkg_managers = get_all_pkg_managers()
    assert 'dnf' in pkg_managers
    assert 'apt' in pkg_managers
    assert 'easyinstall' in pkg_managers
    assert 'pip' in pkg_managers
    assert 'npm' in pkg_managers
    assert 'gem' in pkg_managers
    assert 'pear' in pkg_managers
    assert 'pecl' in pkg_managers
    assert 'pip' in pkg_managers
    assert 'yum' in pkg_managers
    assert 'zypper' in pkg_managers
    assert 'portage' in pkg_managers
    assert 'eix' in pkg_managers
    assert 'gem' in pkg_managers

# Generated at 2022-06-23 00:35:39.615951
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    pkg = PkgMgr()
    assert pkg != None


# Generated at 2022-06-23 00:35:43.134660
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    class TestCLI(CLIMgr):
        CLI = 'apt'
    mgr = TestCLI()
    assert(type(mgr) == TestCLI)


# Generated at 2022-06-23 00:35:54.008153
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    # Test 1:
    # Test if is_available method can detect when a library exists
    # 1.1 Test if method is_available returns False when the library doesn't exist
    test_libmgr_is_available_1_1 = LibMgr()
    test_libmgr_is_available_1_1.LIB = "doesnt_exist"
    assert test_libmgr_is_available_1_1.is_available() == False
    # 1.2 Test if method is_available returns True when the library exists
    test_libmgr_is_available_1_2 = LibMgr()
    test_libmgr_is_available_1_2.LIB = "socket"
    assert test_libmgr_is_available_1_2.is_available() == True


# Generated at 2022-06-23 00:35:55.401153
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():

    assert get_all_pkg_managers()



# Generated at 2022-06-23 00:36:00.187236
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():

    pkg_mgrs = get_all_pkg_managers()
    assert pkg_mgrs.keys() == ['apt', 'yum', 'zypper', 'chocolatey', 'homebrew', 'apk', 'apkg', 'emerge', 'dnf', 'brew']

# Generated at 2022-06-23 00:36:05.490560
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    from ansible.module_utils.facts.system.pkg_mgrs import CLIMgr

    cli_mgr = CLIMgr()

    assert not cli_mgr.is_available()

    cli_mgr.CLI = 'python'

    assert cli_mgr.is_available()

# Generated at 2022-06-23 00:36:06.374600
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    PkgMgr()

# Generated at 2022-06-23 00:36:09.421120
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    c = CLIMgr()
    c._cli = 'test_CLIMgr'
    # test_CLIMgr is not run
    assert c.is_available() == False

# Generated at 2022-06-23 00:36:11.267100
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    assert PkgMgr.is_available(PkgMgr()) == NotImplemented


# Generated at 2022-06-23 00:36:18.031888
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class TestPkgMgr(PkgMgr):
        def list_installed(self):
            return ['package1', 'package2']

        def get_package_details(self, package):
            return {'name': 'package1', 'version': '1.2.3'}
    assert get_all_pkg_managers()['testpkgmgr']().get_packages() == {'package1': [{'name': 'package1', 'version': '1.2.3', 'source': 'testpkgmgr'}]}

# Generated at 2022-06-23 00:36:19.119496
# Unit test for constructor of class LibMgr
def test_LibMgr():

    pm = LibMgr()
    assert pm._lib is None


# Generated at 2022-06-23 00:36:30.280263
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    from collections import OrderedDict

    class TestMgr(PkgMgr):

        def __init__(self):
            self.pkg_list = []
            super(TestMgr, self).__init__()

        def is_available(self):
            return True

        def list_installed(self):
            return self.pkg_list

        def get_package_details(self, package):
            if 'installed' not in package:
                package['installed'] = 'yes'
            return package

    test_mgr = TestMgr()


# Generated at 2022-06-23 00:36:33.012292
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    import pytest
    args = ['name','version','source']
    with pytest.raises(NotImplementedError):
        PkgMgr().get_package_details(args)

# Generated at 2022-06-23 00:36:35.405242
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    test_mgr = CLIMgr()
    assert type(test_mgr) is CLIMgr
    assert test_mgr._cli is None

# Generated at 2022-06-23 00:36:37.331537
# Unit test for constructor of class CLIMgr
def test_CLIMgr():

    class TestCLIMgr(CLIMgr):

        CLI = 'ls'

    assert TestCLIMgr().is_available()

# Generated at 2022-06-23 00:36:42.647698
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    c = CLIMgr()
    c._cli = None
    c._bin_path = None

    c = CLIMgr()
    c._cli = '/bin/test'

    c = CLIMgr()
    c._bin_path = '/bin/test'

    # Wrong type in _cli
    c = CLIMgr()
    c._cli = 1
    c._bin_path = '/bin/test'

    # Wrong type in _bin_path
    c = CLIMgr()
    c._cli = '/bin/test'
    c._bin_path = 1

    # Both set
    c = CLIMgr()
    c._cli = '/bin/test'
    c._bin_path = '/bin/test'

# Generated at 2022-06-23 00:36:45.840918
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    pm = LibMgr()
    assert pm.is_available() == False, "Unable to find the Library"


# Generated at 2022-06-23 00:36:46.826506
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr().CLI is None

# Generated at 2022-06-23 00:36:49.355592
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    pkgMgr = CLIMgr()
    assert pkgMgr is not None


# Generated at 2022-06-23 00:36:54.592944
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    from ansible.module_utils import basic

    libmgr = LibMgr()
    libmgr.LIB = 'distro'
    assert libmgr.is_available()
    libmgr.LIB = 'non_existing_module'
    assert not libmgr.is_available()
    try:
        libmgr.is_available()
        assert False
    except Exception:
        assert True


# Generated at 2022-06-23 00:37:03.287816
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    print("Testing PkgMgr class")
    print("Test list installed methods of all package manager classes")
    #assert(False)
    pkg_mgr_names = get_all_pkg_managers()
    for pkg_mgr_name in pkg_mgr_names:
        print("class: %s" % pkg_mgr_name)
        pkg_mgr = pkg_mgr_names[pkg_mgr_name]()
        available = pkg_mgr.is_available()
        # only test the list_installed method if the package manager is available
        if available:
            installed_list = pkg_mgr.list_installed()
            print("  installed list: %s" % installed_list)
        else:
            print("  not available")
