

# Generated at 2022-06-23 00:27:13.948856
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():

    from ansible.module_utils.common.utils import _load_params
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.facts.system.pkg_mgr import get_all_pkg_managers

    assert 'apt' in get_all_pkg_managers()
    assert 'zypper' in get_all_pkg_managers()

    # Load params and create a dict with expected keys
    params = _load_params(ImmutableDict(ansible_facts={}))
    expected_keys = ['ansible_pkg_mgr', 'ansible_pkg_mgr_os_family', 'ansible_pkg_mgr_python_version']
    expected_keys.extend(list(get_all_pkg_managers().keys()))

    # Check that the

# Generated at 2022-06-23 00:27:16.793298
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    f = PkgMgr()
    assert f.is_available() == NotImplemented, "PkgMgr.is_available() should return NotImplemented"


# Generated at 2022-06-23 00:27:21.117186
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():

    class TestCLIMgr(CLIMgr):
        CLI = "test_CLIMgr_is_available"

    class FailedCLIMgr(CLIMgr):
        CLI = "failed"

    assert TestCLIMgr().is_available()
    assert FailedCLIMgr().is_available() is False

# Generated at 2022-06-23 00:27:21.690205
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    assert LibMgr.is_available(LibMgr) == False


# Generated at 2022-06-23 00:27:26.435783
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    mgr = CLIMgr()
    mgr.CLI = "asdf"
    assert mgr.is_available() == False
    mgr.CLI = "ls"
    assert mgr.is_available() == True

# Generated at 2022-06-23 00:27:27.777401
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    assert(PkgMgr().is_available() == True)


# Generated at 2022-06-23 00:27:38.873737
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    """Test the output of a PkgMgr.get_package_details for a valid package."""

    class DummyPkgManager(PkgMgr):
        pass

    pkgmgr = DummyPkgManager()
    package = 'foopkg'
    version = '2.2'
    release = '7'
    architecture = 'x86_64'
    pkgmgr.get_package_details = lambda x: {'name': package, 'version': version, 'release': release, 'architecture': architecture}

    output = pkgmgr.get_package_details(package)
    assert isinstance(output, dict)
    assert output['name'] == package
    assert output['version'] == version
    assert output['release'] == release
    assert output['architecture'] == architecture

# Generated at 2022-06-23 00:27:42.615955
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():

    class TestPkgMgr(PkgMgr):

        def is_available(self):
            return True

        def list_installed(self):
            pass

        def get_package_details(self):
            pass

    assert TestPkgMgr().is_available() == True


# Generated at 2022-06-23 00:27:43.621224
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    cm = CLIMgr()
    assert cm

# Generated at 2022-06-23 00:27:52.008162
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    testdata = {
        'installed_packages': ['python', 'python-ldap'],
        'result-python': {u'name': u'python', u'version': u'3.5.1'},
        'result-python-ldap': {u'name': u'python-ldap', u'version': u'2.4.43'}
    }

# Generated at 2022-06-23 00:27:55.094295
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.common._utils'

    assert TestLibMgr().LIB == 'ansible.module_utils.common._utils'


# Generated at 2022-06-23 00:28:06.689092
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    import sys
    from ansible.module_utils.common._utils import get_all_subclasses
    is_64bits = sys.maxsize > 2**32 # Check if python is running in 64bits or 32bits
    lib_managers_64bits = ["Yum", "Dnf"]
    lib_managers_32bits = ["Yum", "Dnf"]
    for lib_mgr in get_all_subclasses(LibMgr):
        if is_64bits and lib_mgr.__name__ in lib_managers_64bits:
            assert lib_mgr().is_available() == True
        elif is_64bits == False and lib_mgr.__name__ in lib_managers_32bits:
            assert lib_mgr().is_available() == True
        else:
            assert lib_mgr

# Generated at 2022-06-23 00:28:08.535796
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():

    pkg_managers = get_all_pkg_managers()
    assert 'pacman' in pkg_managers

# Generated at 2022-06-23 00:28:10.789245
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class TestPkgMgr(PkgMgr):
        pass
    obj = TestPkgMgr()
    obj.get_package_details('test')

# Generated at 2022-06-23 00:28:12.314826
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    x = PkgMgr()
    assert x.list_installed() == []


# Generated at 2022-06-23 00:28:13.441024
# Unit test for constructor of class LibMgr
def test_LibMgr():
    pm = LibMgr()
    assert pm._lib is None


# Generated at 2022-06-23 00:28:20.952432
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True

        def list_installed(self):
            return [
                "package1",
                "package2",
                "package2",
                "package3"]

        def get_package_details(self, package):
            return {'name': package, 'version': '1.1.1', 'release': '1.1.1-1.1.el7', 'installdate': 'Tue 25 Feb 2020 10:11:12 PM PST'}

    result = TestPkgMgr().get_packages()

# Generated at 2022-06-23 00:28:25.926942
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    test_LibMgr = LibMgr()
    test_LibMgr.LIB = 'ansible.module_utils.common._collections_compat'
    assert test_LibMgr.is_available() is True
    test_LibMgr.LIB = '_collections_compat'
    assert test_LibMgr.is_available() is False

# Generated at 2022-06-23 00:28:33.748764
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    from ansible_collections.community.general.plugins.module_utils.facts.pkg_mgr import LibMgr, get_all_pkg_managers
    pmgrs = get_all_pkg_managers()

    for pname, pclass in pmgrs.items():
        # Since we have no control over the package managers, not all tests will pass,
        # so we need to filter out a few known cases.
        if pname == 'pip':
            continue
        pm = pclass()
        if issubclass(pclass, LibMgr):
            assert pm.is_available() != False


# Generated at 2022-06-23 00:28:42.718965
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    # Define a subclass of PkgMgr
    class _TestPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return [1, 2, 3]
        def get_package_details(self, package):
            return {'name': package}
    # Instantiate a class object
    instance = _TestPkgMgr()
    # Run the test
    if not len(instance.list_installed()) == 3:
        print("Failed test on method list_installed of class PkgMgr")
        return False
    return True


# Generated at 2022-06-23 00:28:49.223002
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.common.collections import ImmutableDict
    import ansible_collections.misc.not_a_real_collection.plugins.module_utils.hwc_package

    modules = {
        'hwc_package': ansible_collections.misc.not_a_real_collection.plugins.module_utils.hwc_package.__dict__.copy(),
        }
    module_args = ImmutableDict(
        {'state': 'present'}
    )

# Generated at 2022-06-23 00:28:53.546328
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    p = PkgMgr()
    # Implemented abstractmethods
    assert p.is_available()==None
    assert p.list_installed()==None
    assert p.get_package_details('test')==None


# Generated at 2022-06-23 00:28:55.831837
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class Test(LibMgr):
        LIB = 'test'
    a = Test()
    a.is_available()
    assert a._lib == 'test'


# Generated at 2022-06-23 00:29:04.877102
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    # Ensure all imported classes are included in list
    all_pkg_managers = get_all_pkg_managers()
    assert(len(all_pkg_managers) > 0)
    assert(len(all_pkg_managers) >= 4)
    assert('dnf' in all_pkg_managers)
    assert('pacman' in all_pkg_managers)
    assert('pulpprover' in all_pkg_managers)
    assert('yum' in all_pkg_managers)
    # Non-module classes should not be included
    assert('pkgmgr' not in all_pkg_managers)
    assert('libmgr' not in all_pkg_managers)
    assert('climgr' not in all_pkg_managers)

# Generated at 2022-06-23 00:29:15.483899
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    # Test Case 1: If the variable passed to get_package_details is not a str object,then exception needs to be raised
    # Expected Result: test_get_package_details should raise exception for this test
    pkgMgr = PkgMgr()
    try:
        pkgMgr.get_package_details([]);
    except Exception as e:
        print("Test Case 1: Passed")
    else:
        print("Test Case 1: Failed")

    # Test Case 2: If the variable passed to get_package_details is None, then exception needs to be raised
    # Expected Result: test_get_package_details should raise exception for this test
    pkgMgr = PkgMgr()

# Generated at 2022-06-23 00:29:16.545778
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    assert True

# Generated at 2022-06-23 00:29:18.180102
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert False, "Test is not implemented"


# Generated at 2022-06-23 00:29:21.445895
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    from ansible.module_utils.pycompat24 import get_exception

    pm = PkgMgr()
    try:
        pm.list_installed()
    except Exception as err:
        assert 'not implemented' in str(err)


# Generated at 2022-06-23 00:29:22.237033
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    assert PkgMgr()


# Generated at 2022-06-23 00:29:33.101629
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    class TestPkgMgr(PkgMgr):

        def __init__(self):

            self._all_packages = {}
            self._installed_packages = {}
            self._package_details = {}
            super(TestPkgMgr, self).__init__()

        def _set_all_packages(self, packages):
            self._all_packages = packages

        def _set_installed_packages(self, packages):
            self._installed_packages = packages

        def _set_package_details(self, package_details):
            self._package_details = package_details

        def is_available(self):
            return True

        def list_installed(self):
            return self._installed_packages.keys()

        def get_package_details(self, package):
            return self._package_details[package]

    # set

# Generated at 2022-06-23 00:29:34.334934
# Unit test for constructor of class PkgMgr
def test_PkgMgr():

    pm = PkgMgr()
    assert pm != None



# Generated at 2022-06-23 00:29:46.580160
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    class Test_PkgMgr(PkgMgr):
        def list_installed(self):
            list_installed_packages = []
            list_installed_packages.append('package1')
            list_installed_packages.append('package2')
            return list_installed_packages

        def get_package_details(self, package):
            details = {}
            details['name'] = package
            details['version'] = 'version_' + package
            return details

    test_pkg_mgr = Test_PkgMgr()

    assert test_pkg_mgr.is_available() == True
    assert test_pkg_mgr.list_installed() == ['package1', 'package2']

# Generated at 2022-06-23 00:29:57.774896
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    all_pkg_managers = get_all_pkg_managers()
    assert "apt" in all_pkg_managers
    assert "dnf" in all_pkg_managers
    assert "yum" in all_pkg_managers
    assert "portage" in all_pkg_managers
    assert "pkgng" in all_pkg_managers
    assert "apk" in all_pkg_managers
    assert "pacman" in all_pkg_managers
    assert "pkg5" in all_pkg_managers
    assert "pip" in all_pkg_managers
    assert "gem" in all_pkg_managers
    assert "fink" in all_pkg_managers
    assert "chocolatey" in all_pkg_managers
    assert "conda" in all_pkg_managers


# Generated at 2022-06-23 00:30:03.740481
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    pkg_mgr = get_all_pkg_managers()
    for pkg_mgr_key in pkg_mgr:
        cli_mgr = pkg_mgr[pkg_mgr_key]
        if isinstance(cli_mgr, CLIMgr):
            pkg_mgr_obj = cli_mgr()
            pkg_mgr_obj.is_available()
            assert pkg_mgr_obj._cli is not None

# Generated at 2022-06-23 00:30:05.367521
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    assert CLIMgr().is_available() is False
    assert CLIMgr.is_available() is False


# Generated at 2022-06-23 00:30:16.537182
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    """
    Run unit tests for get_packages() method of PkgMgr class

    Returns:
        True in case of success and False otherwise
    """
    from ansible.module_utils.common._utils import FakeModule

    fake_module = FakeModule()

    # sample package data

# Generated at 2022-06-23 00:30:17.153686
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pass

# Generated at 2022-06-23 00:30:28.079079
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    class NewMgr(PkgMgr):

        installed_packages = [('ansible', '2.0'), ('py-yaml', '5.2')]
        _packages = {}

        def __init__(self):
            super(NewMgr, self).__init__()
            for package in self.installed_packages:
                if package[0] not in self._packages:
                    self._packages[package[0]] = []
                self._packages[package[0]].append({'version': package[1]})

        def is_available(self):
            return True

        def list_installed(self):
            return self.installed_packages

        def get_package_details(self, package):
            return self._packages[package[0]][0]

    obj = NewMgr()
    pkgs = obj.get

# Generated at 2022-06-23 00:30:39.961337
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():

    # Test if class LibMgr has attribute __name__
    assert hasattr(LibMgr(), '__name__'), "Class LibMgr has no attribute __name__"

    # Test if class LibMgr has method is_available
    assert hasattr(LibMgr(), 'is_available'), "Class LibMgr has no method is_available"

    # Test if attribute __name__ of class LibMgr has type str
    assert isinstance(LibMgr().__name__, str), "Attribute __name__ of class LibMgr is not of type str"

    # Test if attribute __name__ of class LibMgr has value LibMgr
    assert LibMgr().__name__ == 'LibMgr', "Attribute __name__ of class LibMgr does not have value LibMgr"

    # Test if method is_available of class LibMgr has type

# Generated at 2022-06-23 00:30:42.175930
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    class A(object):
        def __init__(self):
            self.x = 1
    a = A()
    assert(a.x == 1)

# Generated at 2022-06-23 00:30:51.971114
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    import unittest
    from unittest.mock import patch
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgr
    from ansible.module_utils.common._collections_compat import Mapping

    class MockPkgMgr(PkgMgr):

        def list_installed(self):
            return [{'name': 'mock'}, {'name': 'mock1'}, {'name': 'mock2'}]


# Generated at 2022-06-23 00:31:01.527705
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pkg_mgr_dict = get_all_pkg_managers()
    for pkg_mgr_name in pkg_mgr_dict:
        pkg_mgr = pkg_mgr_dict[pkg_mgr_name]()
        if pkg_mgr.is_available():
            assert (type(pkg_mgr.list_installed()) == list), 'list_installed() should return a list'
        else:
            assert (type(pkg_mgr.list_installed()) == list), 'list_installed() should return an empty list when unavailable'
            assert not pkg_mgr.list_installed(), 'list_installed() should return an empty list when unavailable'


# Generated at 2022-06-23 00:31:04.378291
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    pkgObj = PkgMgr()
    assert pkgObj.get_package_details() == "abstract method"

# Generated at 2022-06-23 00:31:09.445656
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    import ansible.module_utils.common.pkg_mgr as pkg_mgr
    c = pkg_mgr.PkgMgr()
    assert c.is_available() is None
    assert c.list_installed() is None
    assert c.get_package_details('c') == {}
    assert c.get_packages() == {}

# Generated at 2022-06-23 00:31:12.312872
# Unit test for constructor of class LibMgr
def test_LibMgr():
    libmgr = LibMgr()
    assert libmgr._lib is None
    assert libmgr.__class__.__name__ == 'LibMgr'


# Generated at 2022-06-23 00:31:13.310901
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    p = PkgMgr()
    assert p

# Generated at 2022-06-23 00:31:15.162705
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    assert isinstance(PkgMgr.is_available(), NotImplementedError)


# Generated at 2022-06-23 00:31:17.070343
# Unit test for constructor of class LibMgr
def test_LibMgr():
    pkg = LibMgr()
    assert pkg


# Generated at 2022-06-23 00:31:18.234356
# Unit test for constructor of class CLIMgr
def test_CLIMgr():

    assert CLIMgr().is_available() == False

# Generated at 2022-06-23 00:31:22.295750
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class CLIMgr_mocked(CLIMgr):
        CLI = 'missingcmd'

    cliMgr = CLIMgr_mocked()
    assert cliMgr.is_available() == False


# Generated at 2022-06-23 00:31:24.921865
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class MockLibMgr(LibMgr):
        LIB = 'json'

    libmgr = MockLibMgr()
    assert libmgr.is_available()


# Generated at 2022-06-23 00:31:27.662455
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    available_package_managers = get_all_pkg_managers()
    for package_manager in available_package_managers.values():
        assert package_manager().is_available() == True

# Generated at 2022-06-23 00:31:30.661096
# Unit test for constructor of class LibMgr
def test_LibMgr():

    # LibMgr is an abstract class; instantiating this class will raise TypeError
    pkg_manager = LibMgr()
    assert TypeError == type(Exception())

# Generated at 2022-06-23 00:31:32.266699
# Unit test for constructor of class PkgMgr
def test_PkgMgr():

    pkg_mgr = PkgMgr()
    print(pkg_mgr)

# Generated at 2022-06-23 00:31:36.645853
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'requests'
    try:
        import requests
        test_LibMgr = TestLibMgr()
        assert test_LibMgr.is_available()
    except ImportError:
        pass


# Generated at 2022-06-23 00:31:38.314674
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    manager = PkgMgr()
    assert manager


# Generated at 2022-06-23 00:31:42.279118
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.collector.os'

    test_object = TestLibMgr()

    assert test_object.is_available()


# Generated at 2022-06-23 00:31:53.650265
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    pkg_mgr = PkgMgr()

    # This method is abstract and is not supposed to be implemented in class PkgMgr.
    # The value returned by methods list_installed and get_package_details is not tested,
    # so we just return a tuple or a dict and get_packages will return a dict.
    pkg_mgr.list_installed = lambda: ('str1', 'str2', 'str3')
    pkg_mgr.get_package_details = lambda package: {'name': package, 'version': '.'.join(package)}


# Generated at 2022-06-23 00:31:55.989757
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pkgmgr = PkgMgr()
    result = pkgmgr.is_available()
    assert result is None


# Generated at 2022-06-23 00:32:00.793886
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    bin = 'date'
    pkgmgr = CLIMgr()
    setattr(pkgmgr, 'CLI', bin)
    assert pkgmgr.is_available()

# example: if you want to find out if this module is available,
# you can do it with the following code:

# Generated at 2022-06-23 00:32:12.305959
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    def get_package_details(package):
        return {'name': package}

    def list_installed():
        return ['packageA', 'packageB', 'packageA']

    class TestClass(PkgMgr):
        def __init__(self):
            super(TestClass, self).__init__()

        def is_available(self):
            return True

        def list_installed(self):
            return list_installed()

        def get_package_details(self, package):
            return get_package_details(package)

    testClass = TestClass()

# Generated at 2022-06-23 00:32:18.025197
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    class TestPkgMgr(PkgMgr):

        def is_available(self):
            return True

        def list_installed(self):
            packages = [
                {
                    'name': 'cat',
                    'version': '0.9',
                    'release': '1'
                },
                {
                    'name': 'cat',
                    'version': '0.9',
                    'release': '2'
                },
                {
                    'name': 'dog',
                    'version': '1.0',
                    'release': '3'
                },
                {
                    'name': 'dog',
                    'version': '1.0',
                    'release': '4'
                }
            ]
            return packages

        def get_package_details(self, package):
            return package

    pkg_mgr

# Generated at 2022-06-23 00:32:29.203002
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    import json
    import subprocess
    # retrive the list of installed packages to test against apt
    try:
        cmd = ['pip3', 'list', '--format', 'json']
        result = subprocess.check_output(cmd)
        packages = json.loads(result.decode('utf-8'))
    except OSError as e:
        raise Exception("Cannot execute command %s: %s" % (cmd, str(e)))
    except json.JSONDecodeError as e:
        raise Exception("Cannot decode JSON from command %s: %s" % (cmd, str(e)))

    # Now test the is_available method for all package managers
    for pmgr, val in get_all_pkg_managers().items():
        pmgr = val()

# Generated at 2022-06-23 00:32:39.156068
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['package1', 'package2']
        def get_package_details(self, package):
            return {'name': package,
                    'version': '1.0'}

    pkg_mgr = TestPkgMgr()
    result = pkg_mgr.get_packages()
    assert result == {'package1': [{'name': 'package1', 'version': '1.0', 'source': 'testpkgmgr'}],
                      'package2': [{'name': 'package2', 'version': '1.0', 'source': 'testpkgmgr'}]}

# Generated at 2022-06-23 00:32:41.304460
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    manager = CLIMgr()
    assert manager._cli == None


# Generated at 2022-06-23 00:32:43.925980
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class test(LibMgr):
        LIB = 'os'
    assert test().is_available()


# Generated at 2022-06-23 00:32:48.719774
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():

    class TestPkgMgr(PkgMgr):

        def is_available(self):
            return True

        def list_installed(self):
            return []

        def get_package_details(self, package):
            return {}

    assert 'testpkgmgr' in get_all_pkg_managers()



# Generated at 2022-06-23 00:32:53.017152
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    try:
        cm = CLIMgr()
        cm._cli = get_bin_path('nonexisting')
        assert cm._cli == 'nonexisting'
    except ValueError:
        pass
    except Exception as e:
        assert False, 'Failed with %s' % e

# Generated at 2022-06-23 00:32:54.808176
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pm = PkgMgr()
    pm.list_installed()


# Generated at 2022-06-23 00:32:58.746041
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestPkgMgr(CLIMgr):
        CLI = '/non/existing/path'
    mgr = TestPkgMgr()
    assert not mgr.is_available()
    class TestPkgMgr(CLIMgr):
        CLI = 'ls'
    mgr = TestPkgMgr()
    assert mgr.is_available()

# Generated at 2022-06-23 00:33:07.770854
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    #import os
    #import sys
    #sys.path.append("/etc/ansible/library")

    #print("cwd: %s" % os.getcwd())
    #print("Path: %s" % sys.path)

    pkgs = get_all_pkg_managers()
    assert 'yum' in pkgs
    assert 'apt' in pkgs
    assert 'pacman' in pkgs
    assert 'pip' in pkgs
    assert 'gem' in pkgs
    assert 'pacman' in pkgs

# Generated at 2022-06-23 00:33:18.904407
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    from importlib import import_module
    from ansible.module_utils.common._collections_compat import Mapping
    pkg_managers = get_all_pkg_managers()
    assert isinstance(pkg_managers, Mapping)
    for pkg_mgr in pkg_managers:
        pkg_mgr_class = "ansible.module_utils.facts.system.pkg_mgr.{}".format(pkg_mgr)
        pkg_mgr_obj = import_module(pkg_mgr_class)
        pkg_mgr_class = getattr(pkg_mgr_obj, pkg_mgr)
        pkg_mgr_obj = pkg_mgr_class()
        assert isinstance(pkg_mgr_obj, PkgMgr)

# Generated at 2022-06-23 00:33:30.803668
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    # Test a mock class to make sure its returning the expected dictionary.
    class PkgMgr_Test(PkgMgr):
        def is_available(self):
            return True

        def list_installed(self):
            return ["package_1", "package_2", "package_3"]

        def get_package_details(self, package):
            return {"name": package.replace("_", " ")}

    pkg_mgr_test = PkgMgr_Test()
    installed_packages = pkg_mgr_test.get_packages()

    assert "package 1" in installed_packages
    assert isinstance(installed_packages["package 1"], list)
    assert len(installed_packages["package 1"]) == 3

# Generated at 2022-06-23 00:33:32.253394
# Unit test for constructor of class LibMgr
def test_LibMgr():

    pkg_mgr = LibMgr()
    assert pkg_mgr._lib == None

# Generated at 2022-06-23 00:33:37.759721
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.package.os_package import CLIMgr

    module = AnsibleModule(argument_spec={})

    cli_mgr = CLIMgr()
    cli_mgr.CLI = 'dummy.sh'

    ret = cli_mgr.is_available()
    assert ret is False


# Generated at 2022-06-23 00:33:39.961870
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    assert isinstance(get_all_pkg_managers(), dict)
    assert len(get_all_pkg_managers()) > 0

# Generated at 2022-06-23 00:33:43.646823
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    # Check to ensure an exception is raised if the method is not implemented
    libmgr = LibMgr()
    with pytest.raises(NotImplementedError) as e:
        libmgr.get_package_details('package')


# Generated at 2022-06-23 00:33:45.792387
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    assert hasattr(PkgMgr(), 'list_installed'), "The PkgMgr class should have a 'list_installed' method"


# Generated at 2022-06-23 00:33:49.628257
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    test_PkgMgr_list_installed.__test__ = False
    pkgmgr = PkgMgr()
    packages = pkgmgr.list_installed()
    assert len(packages) > 0


# Generated at 2022-06-23 00:33:53.565551
# Unit test for constructor of class LibMgr
def test_LibMgr():

    # Use case:
    # Test LibMgr class constructor, LibMgr().__init__()
    libmgr = LibMgr()

    # Assertion:
    assert libmgr._lib is None


# Generated at 2022-06-23 00:33:56.592475
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class P(CLIMgr):
        CLI = "this_does_not_exist"
    pm = P()
    assert pm.is_available() == False


# Generated at 2022-06-23 00:33:57.491736
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr() is not None

# Generated at 2022-06-23 00:33:59.131692
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    assert(get_all_pkg_managers() == dict())

# Generated at 2022-06-23 00:34:01.446123
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    assert isinstance(PkgMgr.get_package_details,abc.abstractmethod)


# Generated at 2022-06-23 00:34:02.266041
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr()

# Generated at 2022-06-23 00:34:08.985645
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    test_package = 'libselinux-python-2.5-14.fc28.x86_64'
    subclasses = get_all_subclasses(PkgMgr)
    for sub in subclasses:
        if sub != CLIMgr and sub != LibMgr:
            pmgr = sub()
            if pmgr.is_available():
                assert pmgr.get_package_details(test_package)



# Generated at 2022-06-23 00:34:11.553325
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pkg = PkgMgr()
    try:
        pkg.list_installed()
    except AttributeError:
        pass
    else:
        raise AssertionError

# Generated at 2022-06-23 00:34:15.206928
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    dummy = PkgMgr()
    dummy.list_installed = lambda: [1]
    dummy.get_package_details = lambda package: package
    pkgs = dummy.get_packages()
    assert pkgs == {1:[1]}

# Generated at 2022-06-23 00:34:17.197769
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    pkgmgr = PkgMgr()
    assert pkgmgr


# Generated at 2022-06-23 00:34:23.348038
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    # Class PkgMgr contains only abstract methods, hence this code is a part of unit test for class CLIMgr
    pi = CLIMgr()
    pi.CLI = 'apt-cache'
    pi.is_available()
    assert ( pi.get_package_details("libpython-stdlib")['name'] == "libpython-stdlib" )


# Generated at 2022-06-23 00:34:25.223857
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class FakeCLIMgr(CLIMgr):
        CLI = "fake"
    assert FakeCLIMgr().is_available() == False


# Generated at 2022-06-23 00:34:27.415692
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class LibMgrLibTest(LibMgr):
        LIB = "json"

    if LibMgrLibTest().is_available():
        pass
    else:
        raise ValueError


# Generated at 2022-06-23 00:34:28.996235
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    inst = CLIMgr()
    inst.CLI = "ls"
    assert inst.is_available() == True


# Generated at 2022-06-23 00:34:30.417030
# Unit test for constructor of class PkgMgr
def test_PkgMgr():

    pm = PkgMgr()
    assert pm is not None


# Generated at 2022-06-23 00:34:34.747002
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    from ansible.module_utils.common.collections import ImmutableDict
    class UbuntuPkgMgr(CLIMgr):
        CLI = 'apt-get'

    apt_get = UbuntuPkgMgr()
    if apt_get.is_available():
        assert apt_get._cli == '/usr/bin/apt-get'
    else:
        assert apt_get._cli == None


if __name__ == '__main__':
    test_CLIMgr_is_available()

# Generated at 2022-06-23 00:34:35.923355
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    pm = CLIMgr()
    assert pm._cli is None

# Generated at 2022-06-23 00:34:39.109945
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    obj = LibMgr()
    assert not obj.is_available()
    obj.LIB = 'platform'
    assert obj.is_available()


# Generated at 2022-06-23 00:34:49.298403
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    # init PyPiMgr instance
    pass_pip_mgr = PyPiMgr()
    # return True
    assert pass_pip_mgr.is_available() == True
    # init RubyGemMgr instance
    pass_rubygem_mgr = RubyGemMgr()
    # return True
    assert pass_rubygem_mgr.is_available() == True
    # init NpmMgr instance
    pass_npm_mgr = NpmMgr()
    # return True
    assert pass_npm_mgr.is_available() == True
    # init PEARMgr instance
    pass_pear_mgr = PEARMgr()
    # return True
    assert pass_pear_mgr.is_available() == True
    # init YumMgr instance
    pass_y

# Generated at 2022-06-23 00:34:53.633306
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    class TestCLIMgr(CLIMgr):
        CLI = 'test'
    # TestCLIMgr.CLI = 'test'
    assert TestCLIMgr.CLI == 'test'
    assert TestCLIMgr()._cli is None
    assert TestCLIMgr().is_available() is False


# Generated at 2022-06-23 00:34:58.704972
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    print("Start testing:\n")
    test_PkgMgr = PkgMgr()
    print("Test if function get_package_details is abstract \n")
    if hasattr(test_PkgMgr, "get_package_details"):
        print("Ran successfully")
    else:
        print("Error, package details can not be retrieved")



# Generated at 2022-06-23 00:35:09.794306
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    import os
    import tempfile
    import shutil
    import mock

    test_data = {}
    test_data['directory_path'] = tempfile.mkdtemp()
    test_data['file_name'] = "test_is_available.tmp"
    test_data['file_path'] = os.path.join(test_data['directory_path'], test_data['file_name'])

    # Create the empty tmp file
    open(test_data['file_path'], 'a').close()

    # Mock the get_bin_path method
    with mock.patch("ansible.module_utils.common.process.get_bin_path") as mock_get_bin_path:

        # Mock get_bin_path which returns the path to the tmp file
        mock_get_bin_path.return_value = test

# Generated at 2022-06-23 00:35:19.912233
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    """
    Test case to verify correct functioning of get_packages method
    """
    class PkgMgr_stub(PkgMgr):
        def __init__(self):
            super(PkgMgr, self).__init__()

        def list_installed(self):
            if self.is_available():
                return [{'name':'pkgmgr_test', 'version':'0.0.1'}]
            else:
                return []

        def get_package_details(self, package):
            return package
        def is_available(self):
            return True

    pkgmgr_stub = PkgMgr_stub()

# Generated at 2022-06-23 00:35:29.631575
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    """
    Testing method - get_package_details of class PkgMgr
    """
    # Testing valid packages
    # Ubuntu OS
    # Testing version with letters
    package = "openssh-server"
    PkgMgr.get_package_details(package)
    # Testing version with numbers
    package = "openssh-sftp-server"
    PkgMgr.get_package_details(package)
    # Windows OS

    # Testing invalid packages
    package = "openssh-server-"
    PkgMgr.get_package_details(package)
    package = "openssh-sftp-server-"
    PkgMgr.get_package_details(package)

# Generated at 2022-06-23 00:35:31.102537
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    assert PkgMgr.is_available()
    assert not PkgMgr.is_available()

# Generated at 2022-06-23 00:35:33.204061
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    pkgmgr = PkgMgr()
    assert pkgmgr is not None  # will not get here if exception is thrown in constructor


# Generated at 2022-06-23 00:35:35.218190
# Unit test for constructor of class LibMgr
def test_LibMgr():

    class test_LibMgr(LibMgr):

        LIB = 'socket'

    clazz = test_LibMgr()

    assert clazz.is_available()


# Generated at 2022-06-23 00:35:46.617813
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():

    def test_class_is_available(cls):
        if hasattr(cls, 'is_available'):
            return cls().is_available()
        else:
            return False

    if not get_all_pkg_managers():
        assert test_class_is_available(PkgMgr)
        assert test_class_is_available(CLIMgr)
        assert test_class_is_available(LibMgr)

    else:
        for cls in get_all_pkg_managers():
            assert test_class_is_available(cls), '{} class does not have working is_available() method'.format(cls.__name__)

    assert 'pkg_mgr' not in globals()
    assert 'lib_mgr' not in globals()

# Generated at 2022-06-23 00:35:47.986996
# Unit test for constructor of class LibMgr
def test_LibMgr():
    pkg = LibMgr()
    assert pkg


# Generated at 2022-06-23 00:35:49.562015
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    assert PkgMgr.is_available == 'is_available'


# Generated at 2022-06-23 00:35:50.212458
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr()

# Generated at 2022-06-23 00:35:54.287895
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    result = get_all_pkg_managers()
    module.exit_json(changed=False, **result)


if __name__ == '__main__':
    test_get_all_pkg_managers()

# Generated at 2022-06-23 00:35:55.356272
# Unit test for constructor of class PkgMgr
def test_PkgMgr():

    pgk = PkgMgr()

# Generated at 2022-06-23 00:35:58.246628
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    p = PkgMgr()
    output = p.get_package_details(None)
    assert isinstance(output, dict)

# Generated at 2022-06-23 00:36:05.867157
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    from ansible.module_utils.facts.pkg_mgr import (
        PkgMgr,
        get_all_pkg_managers,
        CLIMgr,
        LibMgr,
    )
    pkg_mgrs = get_all_pkg_managers()
    assert 'PkgMgr' not in pkg_mgrs
    assert 'CLIMgr' not in pkg_mgrs
    assert 'LibMgr' not in pkg_mgrs

# Generated at 2022-06-23 00:36:08.537685
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    class testCLIMgr(CLIMgr):
        CLI = 'ls'
        def list_installed(self):
            pass
        def get_package_details(self, package):
            pass
    testCLIMgr()


# Generated at 2022-06-23 00:36:11.366577
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    test_obj = PkgMgr()
    assert test_obj.get_package_details("python-ipaddress")["name"] == "python-ipaddress"



# Generated at 2022-06-23 00:36:20.771859
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    from ansible.module_utils.facts.system.pkg_mgr import CLIMgr, LibMgr
    import ansible.module_utils.facts.system.pkg_mgr.apt_get
    import ansible.module_utils.facts.system.pkg_mgr.dnf
    import ansible.module_utils.facts.system.pkg_mgr.emerge
    import ansible.module_utils.facts.system.pkg_mgr.pacman
    import ansible.module_utils.facts.system.pkg_mgr.zypper
    import ansible.module_utils.facts.system.pkg_mgr.pkgng
    import ansible.module_utils.facts.system.pkg_mgr.rpm_dandified
    import ansible.module_utils.facts.system.pkg_mgr.rpm_pyth

# Generated at 2022-06-23 00:36:26.089337
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    try:
        cli = get_bin_path('vagrant')
    except ValueError:
        cli = None
    if cli == None:
        assert is_available(CLIMgr.is_available)== False
    else:
        assert is_available(CLIMgr.is_available) == True



# Generated at 2022-06-23 00:36:34.794512
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    from ansible.module_utils.facts.packages.pkg_mgrs.pkg_mgr_dpkg import DpkgMgr
    from ansible.module_utils.facts.packages.pkg_mgrs.pkg_mgr_pacman import PacmanMgr
    from ansible.module_utils.facts.packages.pkg_mgrs.pkg_mgr_apk import ApkMgr
    from ansible.module_utils.facts.packages.pkg_mgrs.pkg_mgr_yum import YumMgr
    from ansible.module_utils.facts.packages.pkg_mgrs.pkg_mgr_zypper import ZypperMgr
    cli_managers = [DpkgMgr(), PacmanMgr(), ApkMgr(), YumMgr(), ZypperMgr()]

# Generated at 2022-06-23 00:36:36.252278
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr()._cli == None
    assert CLIMgr().CLI == None

# Generated at 2022-06-23 00:36:40.797121
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    """
    In this test case we are mocking PkgMgr class to test the is_available() of the LibMgr class.
    Here we are checking if the python module is imported or not.
    """
    lib_mgr = LibMgr()
    assert lib_mgr.is_available() == False


# Generated at 2022-06-23 00:36:43.329087
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    obj = CLIMgr()
    obj._cli = "/usr/bin/id"
    assert obj.is_available() == True

# Generated at 2022-06-23 00:36:45.684913
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    assert PkgMgr.is_available(PkgMgr) == False


# Generated at 2022-06-23 00:36:47.490996
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    assert get_all_pkg_managers()



# Generated at 2022-06-23 00:36:49.681532
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    mgr = PkgMgr()
    assert type(mgr) is PkgMgr


# Generated at 2022-06-23 00:36:50.707444
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    assert True


# Generated at 2022-06-23 00:36:56.275610
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    from ansible.module_utils.common.packages.yum_package_manager import Yum
    from ansible.module_utils.common.packages.dnf_package_manager import Dnf
    from ansible.module_utils.common.packages.zyp_package_manager import Zyp
    from ansible.module_utils.common.packages.apt_package_manager import Apt
    from ansible.module_utils.common.packages.apk_package_manager import Apk
    from ansible.module_utils.common.packages.pacman_package_manager import Pacman
    from ansible.module_utils.common.packages.pkgng_package_manager import Pkgng
    from ansible.module_utils.common.packages.emerge_package_manager import Emerge

# Generated at 2022-06-23 00:37:02.778954
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    # Test1:
    try:
        pip_path = get_bin_path("pip")
    except ValueError:
        pip_path = None
    assert pip_path is not None

    # Test2:
    try:
        nova_path = get_bin_path("nova")
    except ValueError:
        nova_path = None
    assert nova_path is None

# Generated at 2022-06-23 00:37:04.546582
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    assert PkgMgr.get_package_details(PkgMgr, package=None) is None