

# Generated at 2022-06-23 00:27:10.279037
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    obj = PkgMgr()
    with pytest.raises(RuntimeError):
        obj.get_package_details('foo')

# Generated at 2022-06-23 00:27:12.089521
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    results = get_all_pkg_managers()
    assert(results)

# Generated at 2022-06-23 00:27:21.502463
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    # Test 1
    pm = PkgMgr()
    try:
        pm.is_available()
    except AttributeError:
        assert True
    # Test 2
    assert(CLIMgr().is_available() is False)
    # Test 3
    assert(LibMgr().is_available() is False)
    # Test 4
    cli_mgr = CLIMgr()
    try:
        cli_mgr.is_available()
    except AttributeError:
        assert True
    # Test 5
    lib_mgr = LibMgr()
    try:
        lib_mgr.is_available()
    except AttributeError:
        assert True


# Generated at 2022-06-23 00:27:24.974988
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    from ansible.module_utils.facts.packages.elastic_beats import ElasticBeats
    assert ElasticBeats().is_available() is True

# Generated at 2022-06-23 00:27:29.857927
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    # Test if command exists
    class CLIMgr_test_is_available1(CLIMgr):
        CLI = 'echo'
    assert(CLIMgr_test_is_available1().is_available())

    # Test if command doesn't exists
    class CLIMgr_test_is_available2(CLIMgr):
        CLI = 'not_exists_command'
    assert(not CLIMgr_test_is_available2().is_available())

# Generated at 2022-06-23 00:27:34.868313
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    pm = PkgMgr()
    pm.list_installed = lambda: [{"name": "test1"}, {"name": "test2"}, {"name": "test"}]
    pm.get_package_details = lambda x: x
    assert pm.get_packages() == {"test1": [{"name": "test1"}], "test2": [{"name": "test2"}], "test": [{"name": "test"}]}

# Generated at 2022-06-23 00:27:36.689120
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pm = PkgMgr()
    assert pm.is_available() is None


# Generated at 2022-06-23 00:27:38.718025
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    test_PkgMgr = PkgMgr()
    assert test_PkgMgr is not None


# Generated at 2022-06-23 00:27:42.648855
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    from ansible.module_utils.common._utils import get_all_subclasses
    pkgmgr_list = get_all_subclasses(PkgMgr)
    for pkgmgr in pkgmgr_list:
        pkgmgr_instance = pkgmgr()
        pkgmgr_instance.is_available()

# Generated at 2022-06-23 00:27:44.456446
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    import yum
    test_obj = LibMgr()
    test_obj.LIB = 'yum'
    assert test_obj.is_available() is True


# Generated at 2022-06-23 00:27:44.947689
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    assert True

# Generated at 2022-06-23 00:27:50.589766
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    # Call the function being tested
    obj = PkgMgr()
    # Now "try" to call the abstract method is_available.
    # It should throw a NotImplementedError
    try:
        obj.is_available()
    except NotImplementedError:
        obj_available = True
    except:
        obj_available = False
    # The method should throw a NotImplementedError
    assert obj_available


# Generated at 2022-06-23 00:28:01.528175
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():

    try:
        class PkgMgr1(PkgMgr):
            pass
        class PkgMgr2(PkgMgr):
            def get_package_details(self, package):
                return {'name': package, 'version': package}
        class PkgMgr3(PkgMgr):
            def list_installed(self):
                return {'test1', 'test2'}
        class PkgMgr4(PkgMgr):
            def list_installed(self):
                return {'test1', 'test2'}
            def get_package_details(self, package):
                return {'name': package, 'version': package}
    except SyntaxError as e:
        print("Classe PkgMgr non definie {0}".format(e))


# Generated at 2022-06-23 00:28:12.352202
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    """Ensure that PkgMgr.get_packages() method works properly."""

    # If a package manager is not found, the list_installed() and get_package_details() methods should not be called
    # The method should then return an empty dictionary {}
    class TestPkgMgr(PkgMgr):
        def list_installed(self):
            raise AssertionError("list_installed() should not be called.")
        def get_package_details(self, package):
            raise AssertionError("get_package_details() should not be called.")
        def is_available(self):
            return False

    test_package_manager = TestPkgMgr()
    assert test_package_manager.get_packages() == {}
    assert test_package_manager.is_available() == False

    # If a package manager is found, the

# Generated at 2022-06-23 00:28:15.584228
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    cli_mgr = CLIMgr()
    assert not cli_mgr.is_available()
    cli_mgr.CLI = '/tmp/doesntexist'
    assert cli_mgr.is_available()
    cli_mgr.CLI = 'python'
    assert cli_mgr.is_available()

# Generated at 2022-06-23 00:28:17.294636
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr().__init__() == None


# Generated at 2022-06-23 00:28:29.117912
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    import os
    import sys
    import shutil
    import tempfile
    import StringIO
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgr, LibMgr
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return super(TestPkgMgr, self).is_available()

    class TestLibMgr(LibMgr):
        LIB = 'testlibmgr'
        def is_available(self):
            return super(TestLibMgr, self).is_available()

    test_pkg_mgrs = [PkgMgr, LibMgr, TestPkgMgr, TestLibMgr]
    for test_pkg_mgr in test_pkg_mgrs:
        tmppath = tempfile.mkdtemp()

# Generated at 2022-06-23 00:28:31.042632
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pass
#     p = PkgMgr()
#     p.is_available()



# Generated at 2022-06-23 00:28:32.464741
# Unit test for constructor of class LibMgr
def test_LibMgr():
    lm = LibMgr()
    print(type(lm))


# Generated at 2022-06-23 00:28:38.042504
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    pkg = PkgMgr()
    assert pkg.is_available() == NotImplemented
    assert pkg.list_installed() == NotImplemented
    assert pkg.get_package_details("package") == NotImplemented
    assert pkg.get_packages() == NotImplemented


# Generated at 2022-06-23 00:28:43.482239
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            pass

        def list_installed(self):
            pass

    package = {'name': 'Test', 'version': '1.0'}
    package_details = TestPkgMgr().get_package_details(package)
    assert package_details['name'] == 'Test'
    assert package_details['version'] == '1.0'

# Generated at 2022-06-23 00:28:49.338588
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    class TestPkgMgr(PkgMgr):
        def list_installed(self):
            return ['abc', 'bcd', 'cde', 'def']

        def get_package_details(self, package):
            return {'name': package}

    test_pkgmgr = TestPkgMgr()
    assert len(test_pkgmgr.list_installed()) == 4


# Generated at 2022-06-23 00:28:57.034141
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True

        def list_installed(self):
            return ['ansible']

        def get_package_details(self, name):
            return {'name': name, 'version': '2.7.15'}

    test_pkg_mgr = TestPkgMgr()
    assert test_pkg_mgr.get_packages() == {'ansible': [{'name': 'ansible', 'version': '2.7.15', 'source': 'testpkgmgr'}]}

# Generated at 2022-06-23 00:28:57.809260
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    assert type(PkgMgr()) is PkgMgr


# Generated at 2022-06-23 00:29:01.334740
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    # Default case
    class testCLIMgr_default_case(CLIMgr):
        CLI = 'beaker'
    test_instance = testCLIMgr_default_case()
    assert test_instance.is_available() is False

# Generated at 2022-06-23 00:29:02.983288
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    packageManager = PkgMgr()

# Generated at 2022-06-23 00:29:07.123494
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class LibMgrTest(LibMgr):
        LIB = 'sys'

    package_info = LibMgrTest()
    assert package_info.LIB == 'sys'
    assert package_info._lib is None


# Generated at 2022-06-23 00:29:08.718028
# Unit test for constructor of class LibMgr
def test_LibMgr():
    man = LibMgr()
    assert man.is_available() is False


# Generated at 2022-06-23 00:29:14.346084
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    # Create a class without implementing the abstract methods
    class TestClass(PkgMgr):
        pass

    # The class will not have implemented the required abstract methods and should raise a TypeError
    try:
        test_obj = TestClass()
    except TypeError:
        pass
    else:
        raise AssertionError("test_PkgMgr failed: TestClass should have raised an exception but did not")


# Generated at 2022-06-23 00:29:23.119161
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    import pytest
    from ansible.module_utils.common.process import get_bin_path
    test_cli = "my_test_cli"

    # setup
    def mock_get_bin_path(self, bin_path, required=False):
        raise ValueError("No such file or directory")
    setattr(get_bin_path, 'side_effect', mock_get_bin_path)

    # run
    test_mgr = CLIMgr()
    test_mgr.CLI = test_cli
    result = test_mgr.is_available()

    # assert
    assert result == False
    get_bin_path.assert_called_once_with(test_cli, required=False)

    # cleanup
    delattr(get_bin_path, 'side_effect')



# Generated at 2022-06-23 00:29:27.028467
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCLIMgr(CLIMgr):
        CLI = None
    assert TestCLIMgr().is_available() == False
    TestCLIMgr.CLI = 'ls'
    assert TestCLIMgr().is_available() == True


# Generated at 2022-06-23 00:29:28.466272
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    assert PkgMgr.list_installed() == NotImplemented


# Generated at 2022-06-23 00:29:30.738988
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    pkgmgr = PkgMgr()
    assert(pkgmgr.get_package_details("dummy") == {})



# Generated at 2022-06-23 00:29:37.518058
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    class PkgMgrTest(PkgMgr):
        def is_available(self):
            return False
        def list_installed(self):
            return ['package1', 'package2', 'package3']
        def get_package_details(self, package):
            dummy_package = {'name': package, 'version': '1.2.3'}
            return dummy_package
    pkg_manager = PkgMgrTest()
    result = pkg_manager.list_installed()
    assert(result == ['package1', 'package2', 'package3'])


# Generated at 2022-06-23 00:29:39.442491
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    cli = CLIMgr()
    assert(cli is not None)

# Generated at 2022-06-23 00:29:41.522670
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():

    packages = get_all_pkg_managers()
    assert packages['apt']

# Generated at 2022-06-23 00:29:48.472059
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pkglist = get_all_pkg_managers()
    found_types = 0
    try:
        for pkg in pkglist:
            pkglist[pkg] = pkglist[pkg]()
            if pkglist[pkg].is_available():
                found_types += 1
    except:
        pass
    return found_types

# Unit test that list_installed method of PkgMgr returns a list.

# Generated at 2022-06-23 00:29:56.521659
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    packages = {
        'p1': {
            'name': 'p1',
            'version': '1.0',
            'source': 'source1'
        },
        'p2': {
            'name': 'p2',
            'version': '1.1',
            'source': 'source2'
        }
    }
    obj = PkgMgr()
    obj.get_package_details = lambda x: packages[x]
    obj.list_installed = lambda: packages.keys()
    assert obj.get_packages() == packages


# Generated at 2022-06-23 00:30:03.886163
# Unit test for constructor of class LibMgr
def test_LibMgr():
    from ansible.module_utils.common._collections_compat import Mapping
    libmgr = LibMgr()
    assert isinstance(libmgr, LibMgr)
    assert isinstance(libmgr, PkgMgr)
    assert issubclass(LibMgr, PkgMgr)
    assert issubclass(LibMgr, Mapping)
    assert isinstance(libmgr, Mapping)

    assert libmgr == LibMgr()
    assert not libmgr != LibMgr()
    assert libmgr != 42

    assert libmgr._lib is None


# Generated at 2022-06-23 00:30:14.942397
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    from ansible.module_utils.ansible_release import __version__
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.common.process import get_bin_path

    # Expect true if bin_path returns value
    class CLIMgr_Available(CLIMgr):
        CLI = "ls"

    mgr = CLIMgr_Available()
    assert mgr.is_available()

    # Expect false if bin_path throws ValueError
    class CLIMgr_NotAvailable(CLIMgr_Available):
        def is_available(self):
            try:
                get_bin_path("NOTAVAILABLE")
            except ValueError:
                return False
            return True

    mgr = CLIMgr_NotAvailable()

# Generated at 2022-06-23 00:30:18.251626
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():

    got = get_all_pkg_managers()
    assert len(got) == 4

    assert 'apkg' in got
    assert 'dpkg' in got
    assert 'hpkg' in got
    assert 'yum' in got



# Generated at 2022-06-23 00:30:23.433938
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    '''
    test to see if CLIMgr.is_available()
    returns false when get_bin_path() raises
    a ValueError
    '''
    class TestCLIMgr(CLIMgr):
        CLI = 'foo'

    test_mgr = TestCLIMgr()
    assert test_mgr.is_available() == False

# Generated at 2022-06-23 00:30:32.446196
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():

    class TestClass(PkgMgr):                                                               # Create a test class
        def __init__(self):                                                                 #
            super(TestClass, self).__init__(self)                                           #

# Generated at 2022-06-23 00:30:38.270706
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    from ansible.module_utils.distro import Distro

    distro = Distro()
    distro.get_distro_info()
    distro_name = distro.version_info.distro_name
    pmgr = get_all_pkg_managers().get(distro_name)
    assert pmgr

# Generated at 2022-06-23 00:30:47.547253
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    assert len(get_all_pkg_managers()) == 0


if __name__ == '__main__':
    from ansible.module_utils.common._collections_compat import OrderedDict
    yield_pkgmgr = OrderedDict([('dnf', {'name': 'dnf',
                                         'source': 'dnf',
                                         'version': '0.6.4'}),
                                ('pam', {'name': 'pam',
                                         'source': 'dnf',
                                         'version': '1.1.8'}),
                                ('python-dnf', {'name': 'python-dnf',
                                                'source': 'dnf',
                                                'version': '0.6.4'})])

# Generated at 2022-06-23 00:30:48.881514
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    p = PkgMgr()
    assert p is not None

# Generated at 2022-06-23 00:31:00.816061
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    from ansible.module_utils.facts.system.pkg_mgr.yum import Yum
    from ansible.module_utils.facts.system.pkg_mgr.apt import Apt
    from ansible.module_utils.facts.system.pkg_mgr.pacman import Pacman
    from ansible.module_utils.facts.system.pkg_mgr.brew import Brew
    from ansible.module_utils.facts.system.pkg_mgr.pkg5 import Pkg5
    from ansible.module_utils.facts.system.pkg_mgr.pip import Pip
    from ansible.module_utils.facts.system.pkg_mgr.conda import Conda
    from ansible.module_utils.facts.system.pkg_mgr.gems import Gems

# Generated at 2022-06-23 00:31:05.720803
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    class DummyPkgMgr(PkgMgr):

        def list_installed(self):
            return []

        def get_package_details(self, package):
            return {}

    dummypkgmgr = DummyPkgMgr()
    assert dummypkgmgr.get_packages() == {}

# Generated at 2022-06-23 00:31:17.167291
# Unit test for method get_package_details of class PkgMgr

# Generated at 2022-06-23 00:31:18.718527
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    cli = CLIMgr()
    assert cli is not None

# Generated at 2022-06-23 00:31:20.690307
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    libmgr = LibMgr()
    assert libmgr


# Generated at 2022-06-23 00:31:31.737853
# Unit test for method list_installed of class PkgMgr

# Generated at 2022-06-23 00:31:35.262376
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgr

    for manager in get_all_pkg_managers():
        assert issubclass(get_all_pkg_managers()[manager], PkgMgr)

# Generated at 2022-06-23 00:31:37.204333
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    print(LibMgr.is_available(PkgMgr))


# Generated at 2022-06-23 00:31:40.682744
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    for obj in get_all_subclasses(PkgMgr):
        if hasattr(obj, 'list_installed'):
            package_list = obj().list_installed()
            assert isinstance(package_list, list)
            for package in package_list:
                assert isinstance(package, str)

# Generated at 2022-06-23 00:31:45.696920
# Unit test for constructor of class LibMgr
def test_LibMgr():
    try:
        __import__('apt')
        apt = LibMgr()
        assert(apt.is_available() == True)
    except ImportError:
        pass
    else:
        assert(apt.LIB == "apt")


# Generated at 2022-06-23 00:31:55.530092
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    from ansible.module_utils.facts import pkg_mgr
    from ansible.module_utils.facts.pkg_mgr.brew import Brew
    from ansible.module_utils.facts.pkg_mgr.conda import Conda
    from ansible.module_utils.facts.pkg_mgr.gem import Gem
    from ansible.module_utils.facts.pkg_mgr.npm import Npm
    from ansible.module_utils.facts.pkg_mgr.pip import Pip
    from ansible.module_utils.facts.pkg_mgr.rpm import Rpm
    from ansible.module_utils.facts.pkg_mgr.apt import Apt
    from ansible.module_utils.facts.pkg_mgr.portage import Portage

# Generated at 2022-06-23 00:32:03.113037
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    import platform
    if platform.system() != 'Linux':
        print('\nOnly Linux machines have supported package managers')
        return
    args = ['dpkg', 'yum', 'pacman', 'rpm']
    pkg_managers = get_all_pkg_managers()
    for manager in args:
        assert manager in pkg_managers
        try:
            assert pkg_managers[manager]().is_available()
        except NotImplementedError:
            pass


# Generated at 2022-06-23 00:32:06.166852
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    from ansible.module_utils.common.process import get_bin_path

    class LibMgrTest(LibMgr):

        LIB = "os"

    l = LibMgrTest()
    assert l.is_available() is True


# Generated at 2022-06-23 00:32:13.778060
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    obj1 = PkgMgr()
    obj2 = CLIMgr()
    obj3 = LibMgr()
    result_obj1 = obj1.is_available()
    result_obj2 = obj2.is_available()
    result_obj3 = obj3.is_available()
    assert result_obj1 is False
    assert (result_obj2 is True or result_obj2 is False)
    assert (result_obj3 is True or result_obj3 is False)


# Generated at 2022-06-23 00:32:25.483868
# Unit test for function get_all_pkg_managers

# Generated at 2022-06-23 00:32:30.431250
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    # The function is_available should return a boolean
    # when called in PkgMgr. It is an abstract method so
    # it should always return false when called.
    assert isinstance(PkgMgr().is_available(),bool)
    assert PkgMgr().is_available() == False


# Generated at 2022-06-23 00:32:32.342687
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    lm = LibMgr()
    import sys
    if sys.version_info >= (3, 4):
        assert lm.is_available() == True
    else:
        assert lm.is_available() == False


# Generated at 2022-06-23 00:32:40.883502
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    class TestPkgMgr(PkgMgr):

        def __init__(self):
            super(TestPkgMgr, self).__init__()

        def is_available(self):
            return True

        def list_installed(self):
            return [
                {'name': 'package-1', 'version': '1.0.0'},
                {'name': 'package-1', 'version': '2.0.0'},
                {'name': 'package-2', 'version': '1.0.0'},
            ]

        def get_package_details(self, package):
            return package

    packages = TestPkgMgr().get_packages()

# Generated at 2022-06-23 00:32:43.064372
# Unit test for constructor of class LibMgr
def test_LibMgr():
    l = LibMgr()
    assert (l._lib is None)

# Generated at 2022-06-23 00:32:46.897288
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    cmgr = CLIMgr()
    assert (cmgr.is_available() == False)
    cmgr.CLI = 'test_CLI'
    assert (cmgr.is_available() == False)


# Generated at 2022-06-23 00:32:52.330253
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class DummyLibMgr(LibMgr):
        LIB = 'dummylib'
    lm = DummyLibMgr()
    # test import failure
    assert not lm.is_available()

    # test import success
    class DummyLib1(object):
        pass
    sys.modules['dummylib'] = DummyLib1()
    assert lm.is_available()


# Generated at 2022-06-23 00:32:56.137993
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    from ansible.module_utils.common._text.utils import assert_is_instance
    pkgmgr_list = get_all_pkg_managers()
    for pkgmgr in pkgmgr_list:
        assert_is_instance(pkgmgr_list[pkgmgr]().get_packages(), dict)

# Generated at 2022-06-23 00:32:57.162779
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    assert PkgMgr().is_available() is False


# Generated at 2022-06-23 00:33:01.364213
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    class T(PkgMgr):
        def list_installed(self): pass

    print(T)
    t = T()
    t.list_installed()
    return True


# Generated at 2022-06-23 00:33:03.153880
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr().CLI is None


# Generated at 2022-06-23 00:33:13.637193
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):

        def __init__(self):
            self.packages = dict()
            self.packages['test1'] = dict()
            self.packages['test1']['name'] = "test1"
            self.packages['test1']['version'] = "1.0"
            self.packages['test1']['source'] = "test"
            self.packages['test2'] = dict()
            self.packages['test2']['name'] = "test2"
            self.packages['test2']['version'] = "1.1"
            self.packages['test2']['source'] = "test"
            self.packages['test2']['path'] = "/usr/local/bin/test2"
            self.packages['test3'] = dict()


# Generated at 2022-06-23 00:33:17.065551
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    
    pkgmgr_obj = PkgMgr()
    assert pkgmgr_obj.is_available() == False


# Generated at 2022-06-23 00:33:17.706899
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    assert isinstance(PkgMgr._list_installed(), list)


# Generated at 2022-06-23 00:33:20.082088
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    pkg_manager = LibMgr()
    pkg_manager.LIB = 'sys'
    assert(pkg_manager.is_available())



# Generated at 2022-06-23 00:33:24.305889
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():

    # Initialize test class object
    class TestCLIMgr(CLIMgr):

        CLI = 'ls'

    test_cli_mgr = TestCLIMgr()
    result = test_cli_mgr.is_available()
    assert result


# Generated at 2022-06-23 00:33:31.479542
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    import sys
    sys.modules["ansible.module_utils.common.process"] = __import__("mock")
    import ansible.module_utils.common.process
    ansible.module_utils.common.process.get_bin_path = lambda x: "ansible"
    from ansible.modules.system.package_index import CLIMgr

    assert isinstance(CLIMgr().is_available(), bool)


# Generated at 2022-06-23 00:33:34.068711
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    found = False
    try:
        __import__('subprocess')
        found = True
    except ImportError:
        pass
    assert found == True


# Generated at 2022-06-23 00:33:36.751139
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():

    class TestLibMgr(LibMgr):
        LIB = 'x'

    tlm = TestLibMgr()
    assert not tlm.is_available()


# Generated at 2022-06-23 00:33:38.240667
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    assert False, "No test for abstract method 'get_package_details'."


# Generated at 2022-06-23 00:33:42.877921
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return False

        def list_installed(self):
            pass

        def get_package_details(self, package):
            pass

    try:
        PkgMgr()
        assert False
    except TypeError:
        assert True

# Generated at 2022-06-23 00:33:48.135044
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    try:
        import ansible.modules.system.packaging.os_package_facts.CLIMgr
        managers = get_all_pkg_managers()
        for pkgmgr in managers:
            manager = managers[pkgmgr]()
            if manager.is_available():
                assert True
            else:
                assert False
    except ImportError:
        assert True


# Generated at 2022-06-23 00:33:52.973829
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class _CLIMgr(CLIMgr):
        CLI = 'dummy_executable'

    mgr = _CLIMgr()
    assert not mgr.is_available()
    assert mgr.CLI == 'dummy_executable'
    assert mgr._cli is None


# Generated at 2022-06-23 00:33:54.592926
# Unit test for constructor of class LibMgr
def test_LibMgr():
    mgr = LibMgr()
    assert mgr._lib is None

# Generated at 2022-06-23 00:33:58.138025
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    class TestPkgMgr(PkgMgr):
        pass

    test_pkg_mgr = TestPkgMgr()
    assert test_pkg_mgr.is_available() is None



# Generated at 2022-06-23 00:34:03.494311
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    """
    Test method CLIMgr.is_available()
    """
    from ansible.module_utils.facts.system import PkgMgr

    tester = CLIMgr()

    if tester.is_available():
        print("OK")
    else:
        print("KO")


# Generated at 2022-06-23 00:34:07.166760
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():

    class TestLibMgr(LibMgr):
        LIB = 'not_exists'

    pkg_mgr = TestLibMgr()
    assert pkg_mgr.is_available() is False


# Generated at 2022-06-23 00:34:08.942173
# Unit test for constructor of class LibMgr
def test_LibMgr():
    libmgr = LibMgr()
    assert libmgr is not None


# Generated at 2022-06-23 00:34:11.158041
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    test_pm = CLIMgr()
    assert test_pm.is_available() is False


## Package manager classes below


# Generated at 2022-06-23 00:34:19.978040
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    tmp_dict = dict()
    tmp_dict['name'] = 'test1'
    tmp_dict['version'] = '9999'
    tmp_list_installed = [tmp_dict]

    class test_subclass(PkgMgr):
        def list_installed(self):
            return tmp_list_installed
        def get_package_details(self, package):
            return package

    subclass_instance = test_subclass()
    packages = subclass_instance.get_packages()
    assert packages == {'test1': [{'name': 'test1', 'version': '9999', 'source': 'test_subclass'}]}


# Generated at 2022-06-23 00:34:30.954559
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    import datetime
    import sys
    import unittest

    from ansible.module_utils._text import to_bytes

    from ansible.module_utils.facts import default_collectors

    class FactsGetter(object):
        def __init__(self):
            self._facts = {}

        def __call__(self, *args):
            return lambda collector_name: self._get_fact(collector_name)

        def _get_fact(self, fact_name):
            if fact_name not in self._facts:
                collector = default_collectors[fact_name](None)
                self._facts[fact_name] = collector.collect()
            return self._facts[fact_name]


# Generated at 2022-06-23 00:34:32.710365
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():

    pmgr = PkgMgr()
    assert pmgr.is_available() == False


# Generated at 2022-06-23 00:34:39.941505
# Unit test for constructor of class LibMgr
def test_LibMgr():
    test_pkg_managers = ("Apt", "Aptitude", "Aptdaemon", "AptPkg", "Archive", "DNF", "YaST", "Yum")
    for pkg_manager in test_pkg_managers:
        p = getattr(__import__('ansible.module_utils.facts.packages', globals(), locals(), [pkg_manager], 1), pkg_manager)()
        if p.LIB is not None:
            assert isinstance(p, LibMgr)


# Generated at 2022-06-23 00:34:42.005905
# Unit test for constructor of class LibMgr
def test_LibMgr():
    a = LibMgr()
    assert isinstance(a, LibMgr) is True


# Generated at 2022-06-23 00:34:43.794596
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    p = PkgMgr()

    assert p.get_packages() == {}

# Generated at 2022-06-23 00:34:53.096800
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest
    class TestPkgMgr(PkgMgr):
        def list_installed(self):
            return [1, 2]
        def get_package_details(self, package):
            return package

    class Test(unittest.TestCase):
        def test_list_installed(self):
            pkg_mgr_obj = TestPkgMgr()
            self.assertEqual(pkg_mgr_obj.list_installed(), [1, 2])
    if __name__ == '__main__':
        unittest.main()

# Generated at 2022-06-23 00:34:56.649959
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    test_class = PkgMgr()
    test_packages = test_class.get_packages()
    assert isinstance(test_packages,type({})), 'method get_packages not returning a dictionary of lists'

# Generated at 2022-06-23 00:34:58.478536
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    cli = CLIMgr()
    assert cli.is_available() == False


# Generated at 2022-06-23 00:35:03.988393
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    classes = get_all_pkg_managers()
    assert classes.keys() == ['port_pkg', 'portage_pkg', 'pacman_pkg', 'pkgng_pkg', 'rpm_pkg', 'homebrew_pkg', 'yum_pkg', 'apk_pkg', 'deb_pkg', 'zypper_pkg', 'pkg5_pkg', 'pip_pkg', 'sorcery_pkg', 'pkgsrc_pkg']

# Generated at 2022-06-23 00:35:07.272959
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'test'

    try:
        assert TestLibMgr().is_available() == False
    except Exception:
        pass

# Generated at 2022-06-23 00:35:08.620496
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    assert PkgMgr.get_package_details(PkgMgr(), '1')

# Generated at 2022-06-23 00:35:18.934903
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.common._json_compat import JSONEncoder
    import json

    class pkgMgrSubclass(LibMgr, MutableMapping, JSONEncoder):
        LIB = "json"

        def __init__(self):
            self._mutable = dict()
            super(LibMgr, self).__init__()

        def __len__(self):
            return len(self._mutable)

        def __getitem__(self, key):
            return self._mutable[key]

        def __setitem__(self, key, value):
            self._mutable[key] = value

        def __delitem__(self, key):
            del self._mutable[key]


# Generated at 2022-06-23 00:35:20.016670
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    mgr = PkgMgr()
    assert(mgr)

# Generated at 2022-06-23 00:35:22.578573
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    test_invalid_package_manager = PkgMgr()
    assert not test_invalid_package_manager.is_available()


# Generated at 2022-06-23 00:35:27.587092
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    from ansible.module_utils.facts.packages.pip import PipMgr
    from ansible.module_utils.facts.packages.gem import GemMgr
    result = get_all_pkg_managers()
    assert result['gemmgr'] == GemMgr
    assert result['pipmgr'] == PipMgr


# Generated at 2022-06-23 00:35:28.949998
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    # TODO: This is not a good unit test
    pass

# Generated at 2022-06-23 00:35:30.977400
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():

    results = get_all_pkg_managers()
    for name, pkgmgr in results.items():
        assert name == pkgmgr.__name__.lower()

# Generated at 2022-06-23 00:35:32.822308
# Unit test for constructor of class PkgMgr
def test_PkgMgr():

    pmgr = PkgMgr()
    assert isinstance(pmgr, PkgMgr)


# Generated at 2022-06-23 00:35:44.670555
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.basic import AnsibleModule
    # Test setup
    PATH_TO_TEST_DATA = './test_data/'
    module = AnsibleModule(argument_spec=dict())

    # Mock get_bin_path to return a path to test data
    old_get_bin_path = get_bin_path
    def mock_get_bin_path(name, opt_dirs=[]):
        return PATH_TO_TEST_DATA + name
    get_bin_path = mock_get_bin_path

    # Test all package managers
    all_pkg_managers = get_all_pkg_managers()

# Generated at 2022-06-23 00:35:50.155169
# Unit test for constructor of class LibMgr
def test_LibMgr():

    assert LibMgr.__name__ == 'LibMgr'
    assert hasattr(LibMgr, 'is_available')
    assert hasattr(LibMgr, 'list_installed')
    assert hasattr(LibMgr, 'get_package_details')
    lm = LibMgr()
    assert hasattr(lm, '_lib')
    assert lm._lib is None


# Generated at 2022-06-23 00:35:59.174492
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    from mock import Mock

    def side_effect_list(*args):
        # return a list [Mock(return_value=True),Mock(return_value=True)]
        return [Mock(**kwargs) for kwargs in args]
    list_result = side_effect_list({'return_value': True}, {'return_value': True})

    pkg_mgr = PkgMgr()
    # mock list_installed method
    pkg_mgr.list_installed = Mock()
    pkg_mgr.list_installed.side_effect = list_result

    # mock get_package_details
    pkg_mgr.get_package_details = Mock(return_value={'name': 'name', 'version': 'version'})
    result = pkg_mgr.get_packages()

# Generated at 2022-06-23 00:36:10.551329
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True

        def list_installed(self):
            return [
                'ansible',
                'ansible-doc',
                'ansible-lint',
                'ansibullbot',
                'ansibullbot-shell',
            ]

        def get_package_details(self, package):
            parts = package.split('-')
            d = {'name': parts[0]}
            if len(parts) > 1:
                d['version'] = parts[1]
            return d
    tpm = TestPkgMgr()

# Generated at 2022-06-23 00:36:18.500703
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    #FIXME: is this test doing anything?
    #FIXME: this test doesn't seem to actually do anything?
    mgrs = get_all_pkg_managers()
    for cls in mgrs:
        for mgr in mgrs[cls]:
            if 'CLI' in mgr.__dict__:
                result = get_bin_path(mgr.CLI)
                assert result is not False

            elif 'LIB' in mgr.__dict__:
                try:
                    assert getattr(__import__(mgr.LIB), '__version__') is not None

                except ImportError:
                    continue

# Generated at 2022-06-23 00:36:27.472466
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    pkg_mgr = PkgMgr()
    pkg_mgr.list_installed = lambda: ['package_1', 'package_2']
    pkg_mgr.get_package_details = lambda package: {'name': package, 'version': '1.0'}
    result = pkg_mgr.get_packages()
    assert isinstance(result, dict)
    assert len(result) == 2
    assert 'package_1' in result
    assert 'package_2' in result
    assert len(result['package_1']) == 1
    assert len(result['package_2']) == 1

# Generated at 2022-06-23 00:36:31.953093
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    import pytest

    class TestPkgMgr(PkgMgr):
        def is_available(self): return True
        def list_installed(self): return []

    test_pkg_mgr = TestPkgMgr()
    with pytest.raises(NotImplementedError):
        test_pkg_mgr.get_package_details({})

# Generated at 2022-06-23 00:36:33.825114
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TstMgr(CLIMgr):
        CLI = "test_BIN"
    tst = TstMgr()
    assert tst.is_available()


# Generated at 2022-06-23 00:36:38.381201
# Unit test for constructor of class PkgMgr
def test_PkgMgr():

    pkg_mgr = PkgMgr()
    assert pkg_mgr.is_available() == NotImplemented
    assert pkg_mgr.list_installed() == NotImplemented
    assert pkg_mgr.get_package_details(None) == NotImplemented


# Generated at 2022-06-23 00:36:41.244254
# Unit test for constructor of class LibMgr
def test_LibMgr():
    libmgr = LibMgr()
    libmgr._lib = 'test_lib'
    assert libmgr._lib == 'test_lib'


# Generated at 2022-06-23 00:36:42.359935
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    p = PkgMgr()

# Generated at 2022-06-23 00:36:47.852257
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():

    # class defined above
    class Try(LibMgr):
        LIB = 'os'

    assert Try().is_available()

    class Try(LibMgr):
        LIB = 'some_non_existing_name'

    assert Try().is_available() is False



# Generated at 2022-06-23 00:36:49.143566
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    assert True


# Generated at 2022-06-23 00:36:51.000292
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    manager = PkgMgr()
    assert isinstance(manager, PkgMgr)



# Generated at 2022-06-23 00:36:56.896901
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    print("\nUnit test for the constructor of class CLIMgr")
    try:
        obj = CLIMgr()
        print("Unit test for the constructor of class CLIMgr: PASSED")
    except Exception:
        print("Unit test for the constructor of class CLIMgr: FAILED")


# Generated at 2022-06-23 00:37:07.781169
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class Test(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['a', 'b']
        def get_package_details(self, package):
            return {'name': 'a', 'version': '0.1'}
    t = Test()
    # When package is not a dict with 'name' and 'version', get_package_details is called
    assert(t.get_package_details('a') == {'name': 'a', 'version': '0.1'})
    # When package is a dict, then it is returned as is, without calling get_package_details