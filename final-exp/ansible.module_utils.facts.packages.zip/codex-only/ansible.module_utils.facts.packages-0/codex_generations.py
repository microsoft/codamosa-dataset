

# Generated at 2022-06-23 00:27:09.020297
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    mgr = PkgMgr()
    assert mgr


# Generated at 2022-06-23 00:27:14.826863
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    try:
        import apt
        test = CLIMgr()
        test.CLI = 'apt'
        assert test.is_available() == False
    except ImportError:
        pass
    try:
        import apt_pkg
        test = CLIMgr()
        test.CLI = 'apt'
        assert test.is_available() == True
    except ImportError:
        pass

# Generated at 2022-06-23 00:27:26.898417
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    # TODO: Write better tests for this method
    from ansible.module_utils.common.os.linux_distribution import LinuxDistribution
    from ansible.module_utils.common.os.pkg_managers import PkgMgr
    import sys
    import re
    import json

    def get_all_packages():
        # Get all packages using all available pkg managers and return a list of dictionaries
        pkg_managers = PkgMgr.get_all_pkg_managers().values()
        pkg_managers_ok = [pkg_manager for pkg_manager in pkg_managers if pkg_manager().is_available()]
        all_pkgs = []
        for pkg_manager in pkg_managers_ok:
            all_pkgs += pkg_manager().get_packages().values()


# Generated at 2022-06-23 00:27:28.256667
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    mgr = CLIMgr()
    assert mgr._cli is None

# Generated at 2022-06-23 00:27:30.518597
# Unit test for constructor of class LibMgr
def test_LibMgr():
    # Passing
    lib_mgr = LibMgr()
    _lib = lib_mgr
    assert _lib is not None


# Generated at 2022-06-23 00:27:31.808387
# Unit test for constructor of class LibMgr
def test_LibMgr():
    pass

# Generated at 2022-06-23 00:27:35.641380
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():

    # Instantiating PkgMgr class object
    pkg_mgr_obj = PkgMgr()
    # Invoking list_installed method of class PkgMgr
    pkg_mgr_obj.list_installed()

# Generated at 2022-06-23 00:27:36.759108
# Unit test for constructor of class LibMgr
def test_LibMgr():
    pass


# Generated at 2022-06-23 00:27:39.200464
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pkgmgr = PkgMgr()
    with pytest.raises(TypeError):
        pkgmgr.is_available()

# Generated at 2022-06-23 00:27:42.954278
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    def mock_list_installed(self):
        return ['foo', 'bar']
    pm = PkgMgr()
    pm.list_installed = mock_list_installed
    result = [p for p in pm.list_installed()]
    assert result == ['foo', 'bar']


# Generated at 2022-06-23 00:27:44.768778
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    class TestClass(PkgMgr):
        pass
    test_instance = TestClass()
    assert isinstance(test_instance, PkgMgr)


# Generated at 2022-06-23 00:27:47.921472
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():

    assert isinstance(get_all_pkg_managers(), dict)
    assert 'apt' in get_all_pkg_managers()
    assert get_all_pkg_managers()['apt'].__name__ == 'Apt'

# Generated at 2022-06-23 00:27:50.578156
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    class ExampleCLI(CLIMgr):
        CLI = 'ls'
    obj = ExampleCLI()
    assert obj._cli == get_bin_path('ls')


# Generated at 2022-06-23 00:27:51.724197
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    pass


# Generated at 2022-06-23 00:27:53.208993
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    assert True == PkgMgr().is_available()


# Generated at 2022-06-23 00:27:56.651061
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():

    class _CLI_Mgr(CLIMgr):

        CLI = 'pip'

    pkg_mgr = _CLI_Mgr()
    assert pkg_mgr.is_available() == True



# Generated at 2022-06-23 00:27:58.565466
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    # Unit test for class PkgMgr list_installed method
    assert 1 == 1



# Generated at 2022-06-23 00:28:01.020585
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pkg_mgr = CLIMgr()
    assert hasattr(pkg_mgr, 'list_installed')


# Generated at 2022-06-23 00:28:03.083171
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    mgr = CLIMgr()
    assert mgr.is_available() == False

# Generated at 2022-06-23 00:28:05.906502
# Unit test for constructor of class LibMgr
def test_LibMgr():
    a = LibMgr()
    assert hasattr(a, "LIB")
    assert hasattr(a, "_lib")
    assert a._lib is None


# Generated at 2022-06-23 00:28:07.360517
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    assert CLIMgr.is_available(CLIMgr) == False


# Generated at 2022-06-23 00:28:10.510776
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class_CLIMgr = CLIMgr()
    class_CLIMgr.CLI = "pip"
    assert class_CLIMgr.is_available() == True


# Generated at 2022-06-23 00:28:17.421293
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def __init__(self):
            super(TestPkgMgr, self).__init__()

        def is_available(self):
            return True

        def list_installed(self):
            return ["test_package"]

        def get_package_details(self, package):
            return {'name': 'test_package_name', 'version': 'test_package_version'}

    package_manager = TestPkgMgr()
    installed_packages = package_manager.get_packages()
    assert 'test_package_name' in installed_packages

    assert installed_packages['test_package_name'][0]['name'] == "test_package_name"

# Generated at 2022-06-23 00:28:20.677749
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    class test_CLIMgr(CLIMgr):
        CLI = 'test'
    obj = test_CLIMgr()
    assert obj == obj


# Generated at 2022-06-23 00:28:32.099422
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    from ansible.module_utils.common.process import get_bin_path, get_bin_paths
    
    import sys, os
    sys.path.append(os.path.dirname(os.path.abspath(__file__)))
    import __mock__

    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['foo', 'bar', 'baz']
        def get_package_details(self, package):
            return {'name': package, 'version': '2.3'}
    res = TestPkgMgr().get_packages()
    assert res.get('foo')
    assert len(res['foo']) == 1
    assert res['foo'][0]['name'] == 'foo'

# Generated at 2022-06-23 00:28:38.884456
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    class PkgManagerTest(PkgMgr):
        def is_available(self):
            pass

        def list_installed(self):
            pass

        def get_package_details(self, package):
            pass

    try:
        PkgManagerTest()
        assert True
    except Exception as e:
        assert False, "Constructor test failed for {}: {}".format(PkgMgr, e)

# Generated at 2022-06-23 00:28:41.615452
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    # makes sure that the method is_available finds all the available package managers
    package_managers = get_all_pkg_managers()
    for pkg_mgr in package_managers:
        assert package_managers[pkg_mgr]().is_available() is True

# Generated at 2022-06-23 00:28:44.141555
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():

    assert isinstance(get_all_pkg_managers(), dict)
    assert len(get_all_pkg_managers()) > 0
    assert isinstance(get_all_pkg_managers().get('yum'), type)

# Generated at 2022-06-23 00:28:48.288374
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    pmgr = PkgMgr()
    assert not pmgr.is_available()
    assert len(pmgr.list_installed()) == 0
    assert len(pmgr.get_package_details('pkgmgr')) == 0
    assert len(pmgr.get_packages()) == 0

# Generated at 2022-06-23 00:28:53.745761
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.system.pkg_mgr.mock_lib'
        pass
    pkg_mgr = TestLibMgr()
    if pkg_mgr.is_available():
        assert True
    else:
        assert False


# Generated at 2022-06-23 00:28:57.313333
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    class test_CLIMgr(CLIMgr):
        CLI = "test_this_CLI"
    test_CLIMgr_class = test_CLIMgr()
    assert test_CLIMgr_class._cli == None, "CLIMgr.__init__() has failed"


# Generated at 2022-06-23 00:28:58.343427
# Unit test for constructor of class LibMgr
def test_LibMgr():
    obj = LibMgr()
    assert isinstance(obj, LibMgr)


# Generated at 2022-06-23 00:28:59.998630
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
  
    assert CLIMgr().is_available() == False
 

# Generated at 2022-06-23 00:29:03.631932
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():

    assert PkgMgr.list_installed().__doc__ is not None, 'list_installed() should have a docstring'


# Generated at 2022-06-23 00:29:06.995395
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    pkg_mgr_list = get_all_pkg_managers()
    for key, obj in pkg_mgr_list.items():
        assert type(obj().is_available()) == bool


# Generated at 2022-06-23 00:29:08.578429
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    class MyPkgMgr(PkgMgr):
        pass
    MyPkgMgr()

# Generated at 2022-06-23 00:29:19.817944
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    # Mock get_package_details and list_installed:
    class MockPkgMgr(PkgMgr):
        def list_installed(self):
            return ['pkg1', 'pkg2']
        def get_package_details(self, package):
            return {'name': package, 'version': '1.0', 'source': 'test_source'}
    # Create the MockPkgMgr object:
    testpkgmgr = MockPkgMgr()
    # Use the get_packages method:
    packages = testpkgmgr.get_packages()
    # Verify the result:

# Generated at 2022-06-23 00:29:21.522862
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    m = LibMgr()
    #assert m.is_available() is False


# Generated at 2022-06-23 00:29:26.930087
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestClass(LibMgr):
        LIB = 'mock'
    TestObj = TestClass()
    TestObj._is_available = True
    TestObj._lib = object
    assert TestObj.is_available() is True
    assert TestObj._lib is object
    assert TestObj.LIB is 'mock'

# Generated at 2022-06-23 00:29:28.772268
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
	x=PkgMgr()
	assert x.is_available()==""


# Generated at 2022-06-23 00:29:33.552092
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pkg_mgr = PkgMgr()
    # NOTE: Using assertRaises throws TypeError: list_installed() takes exactly 1 argument (0 given)
    try:
        pkg_mgr.list_installed()
        assert False, 'Abstract method not implemented'
    except NotImplementedError:
        assert True


# Generated at 2022-06-23 00:29:35.460245
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    test1 = PkgMgr()
    print(test1.get_packages())
    assert(False)


# Generated at 2022-06-23 00:29:38.579807
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    assert type(get_all_pkg_managers()) == dict

# Generated at 2022-06-23 00:29:42.399751
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    mock_is_available = CLIMgr()
    mock_is_available.CLI = 'not_available_CLI'
    assert mock_is_available.is_available() == False


# Generated at 2022-06-23 00:29:47.215380
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    from ansible.module_utils.facts.pkg_mgr import PkgMgr
    pkg_mgr = PkgMgr()
    assert pkg_mgr.list_installed() == None, "PkgMgr class should return None by default"


# Generated at 2022-06-23 00:29:49.077424
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    obj = PkgMgr()
    assert(obj.is_available() == NotImplemented)


# Generated at 2022-06-23 00:29:52.460666
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    cmd = 'apt-get'
    mgr = CLIMgr()
    mgr.CLI = cmd
    assert mgr.CLI == cmd
    assert mgr._cli is None



# Generated at 2022-06-23 00:29:55.695585
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.system.distribution.linux'
    t = TestMgr()
    assert t.is_available()

# Generated at 2022-06-23 00:30:04.993223
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    from ansible.module_utils.facts.pkg_mgr import PkgMgr
    class pkgmgr(PkgMgr):
        def list_installed(self):
            return ['package1', 'package2']
        def get_package_details(self, package):
            return {'name': package, 'version': '1.1.1'}

    expected_result = {u'package1': [{u'name': u'package1', u'version': u'1.1.1', 'source': 'pkgmgr'}], u'package2': [{u'name': u'package2', u'version': u'1.1.1', 'source': 'pkgmgr'}]}
    result = pkgmgr().get_packages()
    assert result == expected_result

# Generated at 2022-06-23 00:30:06.449745
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    mgr = PkgMgr()

# Generated at 2022-06-23 00:30:08.320726
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    o = CLIMgr()
    assert not o.is_available()
    assert o._cli is None



# Generated at 2022-06-23 00:30:09.696172
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    assert PkgMgr.get_package_details('TODO') == False

# Generated at 2022-06-23 00:30:11.045398
# Unit test for constructor of class LibMgr
def test_LibMgr():
    lm = LibMgr()
    assert lm.LIB == None


# Generated at 2022-06-23 00:30:13.124362
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    yum = CLIMgr()
    assert yum.is_available() == True

# Generated at 2022-06-23 00:30:16.866301
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    import sys
    class PackageManager(CLIMgr):
        CLI = 'python'
    p = PackageManager()
    assert p.CLI == 'python'
    assert p.is_available() == True
    assert p._cli == sys.executable


# Generated at 2022-06-23 00:30:17.488085
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    PkgMgr()

# Generated at 2022-06-23 00:30:18.549203
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
  assert True


# Generated at 2022-06-23 00:30:22.121834
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestLibMgr(LibMgr):
        LIB = 'urllib'
    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr.is_available()


# Generated at 2022-06-23 00:30:31.603586
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():

    class TestPkgMgr(PkgMgr):

        def list_installed(self): return ['package1', 'package2']

        def get_package_details(self, package): return {'name': package, 'version': '1.0'}

    pm = TestPkgMgr()
    packages = pm.get_packages()
    assert packages == {'package1': [{'name': 'package1', 'version': '1.0', 'source': 'testpkgmgr'}],
                        'package2': [{'name': 'package2', 'version': '1.0', 'source': 'testpkgmgr'}]}, \
                        'test_PkgDetails_get_package_details failed'
    print('test_PkgMgr_get_package_details succeeeded')


# Generated at 2022-06-23 00:30:38.109332
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    # To test this method, we need to create a new subclass
    class MyMgr(PkgMgr):
        def list_installed(self):
            return ['packageA', 'packageB']

    # We instantiate the new subclass
    mgr = MyMgr()
    # We invoke the method we are testing
    assert mgr.list_installed() == ['packageA', 'packageB']

# Generated at 2022-06-23 00:30:42.277891
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():

    # arrange
    expected_result = ['B', 'A', 'C']

    pkgmgr = PkgMgr()

    # act
    actual_result = pkgmgr.list_installed()

    # assert
    assert actual_result == expected_result

# Generated at 2022-06-23 00:30:46.961120
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    p = PkgMgr()
    try:
        p.get_package_details(package=None)
        raise AssertionError("Expected not implemented exception")
    except NotImplementedError:
        pass


# Generated at 2022-06-23 00:30:49.000904
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    
    # Call is_available method of class PkgMgr
    cli = CLIMgr()
    cli.is_available()

# Generated at 2022-06-23 00:30:52.842408
# Unit test for constructor of class LibMgr
def test_LibMgr():

    lib_mgr = LibMgr()
    lib_mgr._lib = 'test'
    assert lib_mgr._lib == 'test'


# Generated at 2022-06-23 00:30:55.714562
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCLIMgr(CLIMgr):
        CLI = 'not_installed_cli'

    assert not TestCLIMgr().is_available()

# Generated at 2022-06-23 00:30:56.693238
# Unit test for constructor of class LibMgr
def test_LibMgr():
    assert LibMgr is not None

# Generated at 2022-06-23 00:31:08.074893
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    assert get_all_pkg_managers().keys() == ['apk', 'deb', 'dnf', 'eopkg', 'pacman', 'pkg', 'pkg5', 'pkg5_legacy', 'portage', 'rpm', 'swdepot', 'xbps']
    assert type(get_all_pkg_managers()['apk']) == type(PkgMgr)
    assert get_all_pkg_managers()['apk'].__name__ == 'APK'
    assert type(get_all_pkg_managers()['eopkg']) == type(PkgMgr)
    assert get_all_pkg_managers()['eopkg'].__name__ == 'EOPKG'

# Generated at 2022-06-23 00:31:09.805126
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    lm = LibMgr()
    assert lm.is_available() == False


# Generated at 2022-06-23 00:31:11.082235
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    pass


# Generated at 2022-06-23 00:31:12.498104
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    cm = CLIMgr()
    assert cm._cli is None


# Generated at 2022-06-23 00:31:15.480830
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    import os
    class Test(CLIMgr):
        CLI = 'test_cli'

    t = Test()
    os.environ["PATH"] = os.pathsep.join(['', './test'])
    assert t.is_available() == True
    t.CLI = 'test_cli_not_found'
    assert t.is_available() == False

# Generated at 2022-06-23 00:31:27.135322
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():

    pkg_mgrs = get_all_pkg_managers()


# Generated at 2022-06-23 00:31:38.350305
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class PkgMgrTest(PkgMgr):
        def list_installed(self):
            return ["test_package1", "test_package2", "test_package3"]

        def get_package_details(self, package):
            return {"name": "test_package", "version": "1.0"}

    pkg_mgr = PkgMgrTest()
    assert pkg_mgr.get_packages() == {"test_package": [{"name": "test_package", "version": "1.0", "source": "pkgmgrtest"}, {"name": "test_package", "version": "1.0", "source": "pkgmgrtest"}, {"name": "test_package", "version": "1.0", "source": "pkgmgrtest"}]}

# Generated at 2022-06-23 00:31:50.595586
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def list_installed(self):
            return ['test_pkg1', 'test_pkg2']
        def get_package_details(self, package):
            return {'name': 'test_pkg', 'version': package}
    tpm = TestPkgMgr()
    packages = tpm.get_packages()
    assert('test_pkg' in packages.keys())
    assert(len(packages['test_pkg']) == 2)
    assert(packages['test_pkg'][0] == {'name': 'test_pkg', 'version': 'test_pkg1', 'source': 'testpkgmgr'})

# Generated at 2022-06-23 00:32:00.399901
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    import sys
    import os
    import tempfile
    from ansible.module_utils.common._text_compat import to_text
    import shutil
    tmp_dir = tempfile.mkdtemp()
    python_version = 'python{}.{}'.format(sys.version_info.major, sys.version_info.minor)
    test_python_bin = os.path.join(tmp_dir, python_version)
    os.symlink(sys.executable, test_python_bin)

    class TestCLIMgr(CLIMgr):
        CLI = 'foobar'
    cli_mgr = TestCLIMgr()


# Generated at 2022-06-23 00:32:02.032023
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    assert LibMgr().is_available() is None


# Generated at 2022-06-23 00:32:03.287043
# Unit test for constructor of class LibMgr
def test_LibMgr():
    LibMgr()


# Generated at 2022-06-23 00:32:08.789406
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    from ansible.module_utils.facts import default_collectors
    from ansible_collections.trellisworks.common_package_facts.plugins.module_utils.package_manager import CLIMgr, LibMgr

    facts = default_collectors.get('dummy')(None)
    pkgmgr_dict = facts['package_mgrs']
    expected_pkgmgr_dict = {
        'cli': ['apk', 'dpkg', 'eix', 'emerge', 'zypper'],
        'lib': ['apt', 'freebsd_pkg', 'pkgutil', 'pip', 'portage', 'yum']
    }

    # Test pkg_mgr_dict with all cli pkg managers
    assert pkgmgr_dict['cli'] == expected_pkgmgr_dict['cli']



# Generated at 2022-06-23 00:32:10.849890
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():

    test_class = PkgMgr()
    test_class._cli = True
    assert test_class.is_available()



# Generated at 2022-06-23 00:32:13.151766
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    pkgMgr = CLIMgr()
    assert pkgMgr.is_available() == False

# Generated at 2022-06-23 00:32:21.190991
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    from ansible.module_utils.common.process import get_bin_path
    a = CLIMgr()
    assert a.CLI == None
    assert a._cli == None
    a.CLI = "python"
    # a.is_available()
    b = get_bin_path("python")
    assert b == "/System/Library/Frameworks/Python.framework/Versions/2.7/bin/python"
    assert a._cli == "/System/Library/Frameworks/Python.framework/Versions/2.7/bin/python"

# Generated at 2022-06-23 00:32:24.652697
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    # Initialize PkgMgr, since it is an abstract class, it is expected to raise NotImplementedError
    pkg_mgr = PkgMgr()
    pass


# Generated at 2022-06-23 00:32:31.401531
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    import sys
    import string
    import random
    import tempfile
    import shutil

    pkgmgrs = get_all_pkg_managers()

    # test against all LibMgr and CLIMgr subclasses
    for cls in pkgmgrs.values():
        if issubclass(cls, LibMgr):
            print(cls)
            # test if class is available when lib exists
            cls_instance = cls()
            cls_instance._lib = 1
            assert cls_instance.is_available() == True
            # test if class is not available when lib does not exist
            cls_instance = cls()
            cls_instance._lib = 0
            assert cls_instance.is_available() == False

# Generated at 2022-06-23 00:32:40.446514
# Unit test for constructor of class LibMgr
def test_LibMgr():
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.package.os_package import LibMgr
    class Test1(LibMgr):
        LIB = 'importlib'
    class Test2(LibMgr):
        LIB = 'ansible_collections.notstdlib.moveitallout.plugins.module_utils.package.os_package'
    class Test3(LibMgr):
        LIB = 'calendar'
    class Test4(LibMgr):
        LIB = 'os_package'
    test_list = [Test1(), Test2(), Test3(), Test4()]
    expected_results = {'Test1': True, 'Test2': True, 'Test3': True, 'Test4': False}

# Generated at 2022-06-23 00:32:41.149612
# Unit test for constructor of class LibMgr
def test_LibMgr():
    assert LibMgr()

# Generated at 2022-06-23 00:32:48.018469
# Unit test for constructor of class LibMgr
def test_LibMgr():
    with open('./glance.txt') as f:
        for line in f:
            words = line.split(' ')
            name = words[-1].strip()
            if name:
                try:
                    __import__(name)
                    print('name: %s' % name)
                except ImportError:
                    print('ImportError')

if __name__=='__main__':
    test_LibMgr()

# Generated at 2022-06-23 00:32:54.351835
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    pkg_managers = get_all_pkg_managers()
    assert('cli_mgr' in pkg_managers)
    assert('lib_mgr' in pkg_managers)
    assert(pkg_managers['cli_mgr'] == CLIMgr)
    assert(pkg_managers['lib_mgr'] == LibMgr)



# Generated at 2022-06-23 00:33:05.895169
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    import unittest

    class TestPkgMgr(PkgMgr):

        def __init__(self):
            super(TestPkgMgr, self).__init__()

        def is_available(self):
            return True

        def list_installed(self):
            return []

        def get_package_details(self, package):
            return {'name': package, 'version': 1, 'source': self.__class__.__name__.lower()}

    DICT = {'name': 'test_package', 'version': 1, 'source': 'testpkgmgr'}

    class TestPkgMgrTestCase(unittest.TestCase):
        def test_get_package_details(self):
            testPkgMgr = TestPkgMgr()

# Generated at 2022-06-23 00:33:08.314692
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    ma = TestPkgMgr()
    packages = ma.get_packages()
    assert isinstance(packages, dict)


# Generated at 2022-06-23 00:33:12.375134
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    import os
    import sys
    my_dir = os.path.dirname(os.path.abspath(__file__))
    test_files = my_dir + "/files"
    sys.path.append(test_files)
    from test_PkgMgr_subclass import PkgsMgrSubclass

    test_subclass = PkgsMgrSubclass(0)

    def test_dict_of_lists_of_dicts(dict_of_lists_of_dicts):
        """
        Checks if the input is an instance of 'dict' and that all of its items are lists with type 'dict'
        :param dict_of_lists_of_dicts:
        :return:
        """
        assert isinstance(dict_of_lists_of_dicts, dict)

# Generated at 2022-06-23 00:33:15.338638
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    assert isinstance(get_all_pkg_managers(), dict)


if __name__ == "__main__":

    import pytest
    pytest.main([__file__])

# Generated at 2022-06-23 00:33:17.447795
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    with pytest.raises(NotImplementedError):
        CLIMgr()

# Generated at 2022-06-23 00:33:22.681994
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    """
    Make sure that each PkgMgr inherits from PkgMgr and implements list_installed()
    """
    for name, obj in get_all_pkg_managers().items():
        assert issubclass(obj, PkgMgr)
        assert callable(obj.list_installed)
        assert callable(getattr(obj, 'list_installed'))


# Generated at 2022-06-23 00:33:32.964507
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class PkgManagerStub(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['pkg1', 'pkg2']
        def get_package_details(self, package):
            return {'name': package, 'version': '0.1'}
    expected_packages = {'pkg1': [{'name': 'pkg1', 'version': '0.1', 'source': 'pkgmanagerstub'}],
                         'pkg2': [{'name': 'pkg2', 'version': '0.1', 'source': 'pkgmanagerstub'}]}
    assert expected_packages == PkgManagerStub().get_packages()

# Generated at 2022-06-23 00:33:34.625824
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    test_cli = CLIMgr()
    assert test_cli.CLI == None
    assert test_cli._cli == None

# Generated at 2022-06-23 00:33:37.366351
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():

    pkg_mgr_obj = PkgMgr()
    result = pkg_mgr_obj.is_available()
    assert result is True


# Generated at 2022-06-23 00:33:38.852914
# Unit test for constructor of class LibMgr
def test_LibMgr():
    mgr = LibMgr()
    assert None == mgr._lib


# Generated at 2022-06-23 00:33:41.314139
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pkgMgr = PkgMgr()
    assert pkgMgr.list_installed() == NotImplemented


# Generated at 2022-06-23 00:33:43.514597
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestClass(CLIMgr):
        CLI = "notinstalled"
    
    assert not TestClass().is_available()


# Generated at 2022-06-23 00:33:54.130598
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    import ansible.module_utils.facts.pkg_mgrs.apt
    package_manager = ansible.module_utils.facts.pkg_mgrs.apt.PkgMgr()

    assert package_manager.get_package_details('apt') == {"name": "apt", "version": "1.6.10"}
    assert package_manager.get_package_details('invalid-package') == {"name": "invalid-package", "version": "Unknown"}

    from ansible.module_utils.facts.pkg_mgrs.zypper import PkgMgr as zypper_mgr
    zypper_mgr = zypper_mgr()
    assert zypper_mgr.get_package_details('zypper') == {"name": "zypper", "version": "1.14.14"}



# Generated at 2022-06-23 00:34:02.204856
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():

    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.system.pkg_mgr.package_manager'

    instance = TestLibMgr()
    assert instance.is_available() == True

    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.system.pkg_mgr.package_manager1'

    instance = TestLibMgr()
    assert instance.is_available() == False


# Generated at 2022-06-23 00:34:13.776307
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    from ansible.module_utils.common.fact_collector import get_distribution

    dist_list = get_distribution()

    # Check that all of the defined CLI-based subclasses of CLIMgr have the CLI defined as a variable.
    for manager_class in CLIMgr.__subclasses__():
        assert hasattr(manager_class, 'CLI'), "'CLI' variable not defined for class %s" % manager_class.__name__

    # For each distribution check that the CLI-basd package managers are only available if the package manager exists
    # in the OS
    for dist in dist_list:
        dist_obj = dist_list[dist]()
        available_pmgrs = dist_obj.get_package_manager_names(with_pkg_tool=False)

# Generated at 2022-06-23 00:34:16.592746
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    # Testing is_available method of class PkgMgr, this method should return False
    assert(PkgMgr().is_available() == False)

# Generated at 2022-06-23 00:34:20.441175
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestClass(LibMgr):
        LIB = "libx"

    test_class = TestClass()
    assert isinstance(test_class, LibMgr)
    assert test_class._lib is None


# Generated at 2022-06-23 00:34:23.348184
# Unit test for constructor of class LibMgr
def test_LibMgr():
    lm = LibMgr()
    assert lm.__class__.LIB is None
    assert lm._lib is None


# Generated at 2022-06-23 00:34:27.320957
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True

        def list_installed(self):
            return ['test.package']

    package_details_dict = {'name': 'test.package', 'version': '1.2.3'}

    instance = TestPkgMgr()
    result = instance.get_package_details.__func__(instance, 'test.package')
    assert result == package_details_dict, "Incorrect package details returned"

# Generated at 2022-06-23 00:34:33.153753
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class MockedCLIMgr(CLIMgr):
        CLI = None

    assert MockedCLIMgr()._cli == None  # pylint: disable=protected-access

    class MockedCLIMgr2(CLIMgr):
        CLI = 'foo'
        def _get_bin_path(self, binary, required=False):
            raise ValueError

    assert MockedCLIMgr2()._cli == None  # pylint: disable=protected-access

    class MockedCLIMgr3(CLIMgr):
        CLI = 'foo'
        def _get_bin_path(self, binary, required=False):
            return 'foo'

    assert MockedCLIMgr3()._cli == 'foo'  # pylint: disable=protected-access



# Generated at 2022-06-23 00:34:37.610847
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class MyCLIMgr(CLIMgr):
        CLI = 'command'
    cli = MyCLIMgr()
    assert cli.is_available() is True
    def mock_get_bin_path(path):
        raise ValueError()
    cli.get_bin_path = mock_get_bin_path
    assert cli.is_available() is False


# Generated at 2022-06-23 00:34:42.310008
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    # Test PkgMgr with NotImplementedError
    class MyPkgMgr(PkgMgr):
        pass

    MyPkgMgrTest = MyPkgMgr()
    assert MyPkgMgrTest.is_available() == NotImplementedError


# Generated at 2022-06-23 00:34:54.004563
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            pass

        def list_installed(self):
            pass

    pkgmgr = TestPkgMgr()

    name = 'foo'
    version = '1.2.3'
    release = '4'
    details = {'name': name, 'version': version, 'release': release, 'source': 'test'}
    assert pkgmgr.get_package_details(details) == details

    assert pkgmgr.get_package_details({}) == {'name': 'UNKNOWN', 'version': 'UNKNOWN', 'source': 'test'}


# Generated at 2022-06-23 00:35:01.073939
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class PkgMgrTest(PkgMgr):
        class SubCLIMgr(CLIMgr):
            CLI = 'apt-get'

        def list_installed(self):
            return ['python']

        def get_package_details(self, package):
            return {'name': 'python', 'version': '2.7.12-1ubuntu0~16.04.4'}

    pkmg = PkgMgrTest()
    assert pkmg.get_package_details('python') == {'name': 'python', 'version': '2.7.12-1ubuntu0~16.04.4'}

# Generated at 2022-06-23 00:35:06.454697
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    class TestCLIMgr(CLIMgr):
        CLI = 'grep'
    climgr = TestCLIMgr()
    assert climgr.CLI == 'grep'
    assert climgr._cli is None


# Generated at 2022-06-23 00:35:08.845413
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    assert sorted(get_all_pkg_managers()) == ['apt', 'brew', 'dnf', 'portage', 'rpm', 'yum']


# Generated at 2022-06-23 00:35:09.749038
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pass


# Generated at 2022-06-23 00:35:13.223992
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    test_class = PkgMgr()
    assert issubclass(type(test_class), __builtins__['object'])
    assert callable(test_class.list_installed)


# Generated at 2022-06-23 00:35:14.090258
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    LibMgr()

# Generated at 2022-06-23 00:35:16.432561
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert 'CLIMgr' in PkgMgr.__subclasses__
    assert CLIMgr.CLI is None


# Generated at 2022-06-23 00:35:22.488894
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    l = LibMgr()
    assert l._lib is None
    l.LIB = 'foo'
    assert l.is_available() is False
    l.LIB = 'ansiballz.test'
    assert l.is_available() is True
    assert l._lib is not None
    assert l._lib.__name__ == 'ansiballz.test'


# Generated at 2022-06-23 00:35:26.732452
# Unit test for constructor of class LibMgr
def test_LibMgr():
    '''
    Test constructor of class LibMgr
    '''
    try:
        assert LibMgr is not None
    except (AssertionError, NameError):
        raise AssertionError('Class LibMgr could not be instantiated')


# Generated at 2022-06-23 00:35:30.071876
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    class TestPkgMgr(PkgMgr):
        pass
    test_pkg_mgr = TestPkgMgr()
    result = test_pkg_mgr.is_available()
    assert result is False


# Generated at 2022-06-23 00:35:31.416774
# Unit test for constructor of class LibMgr
def test_LibMgr():
    lib_mgr = LibMgr()


# Generated at 2022-06-23 00:35:38.685943
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts.system.pkg_mgr.rpm import RPMMgr
    from ansible.module_utils.facts.system.pkg_mgr.yum import YUMMgr
    args = {
        'yum': {'CLI': 'yum'},
        'rpm': {'CLI': 'rpm'},
        'unavailable': {'CLI': 'non_exists'}
    }
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True),
            args=dict(type='dict', required=False)
        ),
        supports_check_mode=True
    )
    name = module.params['name']
    args = module.params['args']

# Generated at 2022-06-23 00:35:39.751488
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr().CLI is None

# Generated at 2022-06-23 00:35:44.518216
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    """ PkgMgr class is an abstract class and is expected to raise NotImplementedError when is_available method is called.
    """

    with pytest.raises(NotImplementedError):
        pkg_mgr = PkgMgr()
        pkg_mgr.is_available()


# Generated at 2022-06-23 00:35:49.134222
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    # Test if object is instantiated
    assert LibMgr()
    # Test if object is an instance of the class
    assert isinstance(LibMgr(), LibMgr)
    # test for failure as the method is_available is abstract now
    try:
        LibMgr().is_available()
    except:
        assert True



# Generated at 2022-06-23 00:35:51.629149
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestLibMgr(LibMgr):
        LIB = 'test'

    mgr = TestLibMgr()
    assert mgr._lib is None

test_LibMgr()


# Generated at 2022-06-23 00:35:53.737597
# Unit test for constructor of class LibMgr
def test_LibMgr():
    libmgr_obj = LibMgr()
    assert libmgr_obj._lib is None


# Generated at 2022-06-23 00:35:55.444316
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    lmgr = LibMgr()
    assert lmgr.is_available() == False


# Generated at 2022-06-23 00:36:08.253320
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():

    # Make sure the abstract PkgMgr class cannot be created on its own
    try:
        PkgMgr()
        assert False, "PkgMgr should not have been instantiated!"
    except TypeError:
        assert True

    # Make sure that LibMgr can be subclassed properly
    test_LibMgr = type('TestLibMgr', (LibMgr, object), {})
    try:
        test_LibMgr()
    except Exception as e:
        assert False, "LibMgr failed to instantiate: {0}".format(e)

    # Make sure that LibMgr cannot be instantiated without specifying the
    # 'LIB' class variable.
    try:
        LibMgr()
        assert False, "LibMgr should not have been instantiated!"
    except TypeError:
        assert True

    # Make

# Generated at 2022-06-23 00:36:09.511274
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pass  # TODO


# Generated at 2022-06-23 00:36:14.899287
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    # Test case 1: import the package successfully
    import platform
    test_libmgr = LibMgr()
    test_libmgr.LIB = "platform"
    assert test_libmgr.is_available()

    # Test case 2: import the module failed
    test_libmgr.LIB = 'not_exist'
    assert test_libmgr.is_available() == False


# Generated at 2022-06-23 00:36:16.266572
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    pkg = CLIMgr()
    assert pkg is not None


# Generated at 2022-06-23 00:36:24.949257
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    # pkg_managers = dict of dict of class
    # pkg_managers[manager][os] = class
    # manager is one of "apk", "apt", "aptitude", "dnf", "emerge", "homebrew", "pkg", "pkg5", "rpm", "yum", "zypper"
    # os is one of "Darwin", "FreeBSD", "Linux"
    # note: "pip" is NOT a package manager!
    # note: "pkg5" is the old name for "pkg" but it doesn't seem to be detected on FreeBSD 12.0-CURRENT
    pkg_managers = get_all_pkg_managers()
    # check if we found all the pkg managers

# Generated at 2022-06-23 00:36:28.614145
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    all_pkg_managers = get_all_pkg_managers()
    assert 'macports' in all_pkg_managers
    assert all_pkg_managers['macports'].__name__ == 'MacPorts'

# Generated at 2022-06-23 00:36:39.494378
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    from ansible.module_utils.common.os.package.yum import Yum
    from ansible.module_utils.common.os.package.zypper import Zypper
    from ansible.module_utils.common.os.package.pacman import Pacman
    from ansible.module_utils.common.os.package.urpmi import Urpmi
    from ansible.module_utils.common.os.package.apk import Apk
    from ansible.module_utils.common.os.package.pkg5 import Pkg5
    from ansible.module_utils.common.os.package.pkg5 import Pkg5
    from ansible.module_utils.common.os.package.pkg5 import Pkg5
    from ansible.module_utils.common.os.package.pkg5 import Pkg5

    cli_

# Generated at 2022-06-23 00:36:41.076658
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():

    managers = get_all_pkg_managers()

    assert len(managers) > 0

# Generated at 2022-06-23 00:36:44.909399
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    results = get_all_pkg_managers()
    print("Found : ")
    print(results)
    assert(len(results) >= 0)

if __name__ == '__main__':
    test_get_all_pkg_managers()

# Generated at 2022-06-23 00:36:51.143376
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pm_obj = PkgMgr()
    got = pm_obj.is_available()
    expect = False
    #    assert got == expect, 'got :%s expect:%s' % (got, expect)
    print('unit test %s expect :%s got:%s' % ('PkgMgr_is_available', expect, got))



# Generated at 2022-06-23 00:36:54.581272
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    assert(PkgMgr.get_packages(None) == {})

# Generated at 2022-06-23 00:36:58.687513
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'test_lib'

    p = TestLibMgr()
    assert p.is_available, "Library is available, while it should not be"



# Generated at 2022-06-23 00:37:03.764795
# Unit test for constructor of class LibMgr
def test_LibMgr():
    try:
        PkgMgr()
        raise AssertionError("Should've raised TypeError due to missing methods")
    except TypeError:
        pass
    try:
        LibMgr()
        raise AssertionError("Should've raised NotImplementedError due to missing member LIB")
    except NotImplementedError:
        pass


# Generated at 2022-06-23 00:37:05.133591
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    cli = CLIMgr()
    assert cli.is_available() is False

# Generated at 2022-06-23 00:37:06.483535
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    assert False, "Unit tests for class PkgMgr are not implemented yet"

# Generated at 2022-06-23 00:37:07.449621
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    PkgMgr()

# Generated at 2022-06-23 00:37:10.122714
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    pm = PkgMgr()
    assert pm.get_package_details(None) is None
