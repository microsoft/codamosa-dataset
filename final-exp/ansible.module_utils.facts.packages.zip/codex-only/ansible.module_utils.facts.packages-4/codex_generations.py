

# Generated at 2022-06-23 00:27:07.987423
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():

    if not PkgMgr.list_installed(__import__("ansible.module_utils.basic.PkgMgr")):
        return False
    return True



# Generated at 2022-06-23 00:27:16.853857
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    import os
    import sys
    import subprocess

    # Get the module with which we are working.
    module = AnsibleModule(argument_spec={})

    # Get the list of subclasses of class PkgMgr.
    pkg_mgrs = get_all_pkg_managers()

    # For each subclass, run the list_installed() method to make sure it does not fail.
    for cls in pkg_mgrs:
        pkg_mgr = pkg_mgrs[cls]()

        if pkg_mgr.is_available():
            pkg_mgr.list_installed()

# Generated at 2022-06-23 00:27:28.214570
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():

    # See if 'pip' package manager is installed and usable
    """
    Currently, this unit test only checks if pip package list_installed is usable or not.
    Implementation of the test is not complete
    """
    # Set the variable 'pip_mgr' to the class of package manager 'pip'
    pip_mgr = get_all_pkg_managers()['pip']

    # If pip package manager is not installed and usable, skip the test
    if not pip_mgr().is_available():
        return False

    # Check if pip package manager list_installed method is available
    if not hasattr(pip_mgr(), 'list_installed'):
        return False

    # Get a list of installed packages
    class_obj = pip_mgr()
    installed_packages = class_obj.list_installed()

    #

# Generated at 2022-06-23 00:27:30.507453
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    p = PkgMgr()
    assert p.is_available() is None
    # test_PkgMgr_is_available()


# Generated at 2022-06-23 00:27:35.199043
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    #Creating object of class PkgMgr
    pm = PkgMgr()

    # Class PkgMgr doesnt have the method get_package_details, so when called
    # it should raise an Exception
    with pytest.raises(TypeError):
        pm.get_package_details()


# Generated at 2022-06-23 00:27:38.014748
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    _lib = mock.MagicMock()
    class Test(LibMgr):
        LIB = 'mylib'
    lib = Test()
    lib._is_available = _lib

    lib_available = lib.is_available()



# Generated at 2022-06-23 00:27:47.375097
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    from package_facts.epel import Epel
    from package_facts.pip import Pip
    from package_facts.apk import Apk
    assert Epel().get_package_details('gcc') == {'name': 'gcc', 'version': '4.8.5-24.el7_7.1', 'source': 'epel'}
    assert Pip().get_package_details('ansible') == {'name': 'ansible', 'version': '2.7.15', 'source': 'pip'}
    assert Apk().get_package_details('curl') == {'name': 'curl', 'version': '7.59.0-r1', 'source': 'apk'}


# Generated at 2022-06-23 00:27:52.944678
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    from ansible.module_utils import basic

    basic_climgr = CLIMgr()
    result = basic_climgr.is_available()
    try:
        assert result == True
    except AssertionError:
        print("\n")
        print("Error: method is_available of class CLIMgr does not work as expected.")
        print("\n")
        quit()


# Generated at 2022-06-23 00:27:58.512534
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB='ansible.module_utils.ansible_pkg_mgrs.libmgr.test_libmgr'
        def list_installed(self):
            return None
        def get_package_details(self, package):
            return None
    test_libmgr = TestLibMgr()
    assert test_libmgr.is_available()


# Generated at 2022-06-23 00:28:04.126386
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class test_LibMgr(LibMgr):
        LIB = "test_module"

    test = test_LibMgr()
    assert test.is_available() is False

    import test_module
    assert test.is_available() is True

    del test_module
    assert test.is_available() is False



# Generated at 2022-06-23 00:28:04.798604
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pass

# Generated at 2022-06-23 00:28:10.427715
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class ConcreteCLIMgr(CLIMgr):
        CLI = 'cat'

    pkgmgr = ConcreteCLIMgr()
    assert pkgmgr.is_available() is True

    class ConcreteCLIMgr(CLIMgr):
        CLI = 'nonexistingcli'

    pkgmgr = ConcreteCLIMgr()
    assert pkgmgr.is_available() is False


# Generated at 2022-06-23 00:28:17.404898
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class MockPkgMgr(PkgMgr):
        def is_available(self):
            return True

        def list_installed(self):
            return ["package1", "package2"]

        def get_package_details(self, package):
            return {
                'name': package,
                'version': '1.0.0',
                'source': 'MockPkgMgr'
            }

    pkg_mgr = MockPkgMgr()
    installed_packages = pkg_mgr.get_packages()


# Generated at 2022-06-23 00:28:20.677762
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    mgr = CLIMgr()
    assert mgr
    # pylint: disable=protected-access
    assert mgr._cli is None


# Generated at 2022-06-23 00:28:23.073069
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    assert PkgMgr().__class__ == PkgMgr
    assert PkgMgr()._proxy is None
    assert PkgMgr()._path is None


# Generated at 2022-06-23 00:28:32.509401
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():

    import sys
    from ansible.module_utils.basic import AnsibleModule

    class PkgMgrTest(PkgMgr):
        def list_installed(self):
            return ['test_package']

        def get_package_details(self, package):
            # This takes a 'package' item and returns a dictionary with the package information, name and version are minimal requirements
            return {'name': 'test', 'ver': '1.0'}
    pkg = PkgMgrTest()
    pkg.is_available()
    package_details = pkg.get_package_details('test_package')
    assert package_details['name'] == 'test'
    assert package_details['ver'] == '1.0'

# Generated at 2022-06-23 00:28:33.405468
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pass

# Generated at 2022-06-23 00:28:44.151378
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    """ Test class PkgMgr, method get_package_details """

    from ansible.module_utils.common._utils import AnsibleFallbackNotFound
    try:
        from packaging import version
    except ImportError:
        raise AnsibleFallbackNotFound("Failed to import required module (packaging)")

    pack_name='Pack1'
    pack_ver='1.0'

    class SubPkgMgr(PkgMgr):
        def list_installed(self):
            return [pack_name]

    pack_mgr = SubPkgMgr()
    pack_mgr._cli = '/bin/cat'

    # Test with every possible pair of a version string and an integer number

# Generated at 2022-06-23 00:28:46.697683
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():

    pkg_mgrs = get_all_pkg_managers()
    pkg_mgrs['apt']


# Generated at 2022-06-23 00:28:57.115406
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    from ansible.module_utils.software_management.windows import MSI, PIP, PS, Nuget, Chocolatey
    from ansible.module_utils.software_management.linux import Apt, Dnf, Pip, AptPip, DnfPip, Yum, YumLib, Pacman
    from ansible.module_utils.software_management.freebsd import Pkg

    class TestClass(PkgMgr):
        def list_installed(self):
            return ['p1', 'p2', 'p3']
        def get_package_details(self, package):
            return {'name': package, 'version': '2.0'}

    pkgmgr = TestClass()


# Generated at 2022-06-23 00:28:57.912212
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    p=PkgMgr()
    assert p.list_installed() == ([])

# Generated at 2022-06-23 00:29:07.384846
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    """
    simple unit test for method is_available of class CLIMgr
    Expected to find the method is_available of class CLIMgr
    """
    # define a class that inherits from CLIMgr
    class CLIMgrTest(CLIMgr):
        CLI = '/run/bin/python'

    # create an instance of the class CLIMgrTest
    cli = CLIMgrTest()
    # check if the method is_available is present in the class CLIMgrTest
    assert hasattr(cli, "is_available"), "method is_available for class CLIMgrTest not found"


# Generated at 2022-06-23 00:29:08.621222
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    cm = CLIMgr()
    assert bool(cm._cli) is False

# Generated at 2022-06-23 00:29:09.175020
# Unit test for constructor of class LibMgr
def test_LibMgr():
    assert 1 == 1

# Generated at 2022-06-23 00:29:10.748732
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    assert PkgMgr.get_package_details(self)==package_details


# Generated at 2022-06-23 00:29:15.112203
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():

    # Instantiates the PkgMgr class
    pm = PkgMgr()

    # Check that the method is_available of class PkgMgr is an instance of the class method
    assert isinstance(pm.is_available(), classmethod)


# Generated at 2022-06-23 00:29:17.323346
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    pm = PkgMgr()
    assert pm


# Generated at 2022-06-23 00:29:21.630773
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():

    class TestLibMgr(LibMgr):
        LIB = 'socket'

    tlm = TestLibMgr()
    assert(tlm.is_available())
    tlm._lib = None
    assert(not tlm.is_available())
    tlm._lib = False
    assert(not tlm.is_available())


# Generated at 2022-06-23 00:29:29.457102
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    class PkgMgr_list_installed(PkgMgr):
        def __init__(self):
            pass
        def is_available(self):
            pass
        def list_installed(self):
            return ['package1','package2','package3']
        def get_package_details(self):
            pass
    # Create an instance of PkgMgr_list_installed class
    pm = PkgMgr_list_installed()

    # Call this method
    package_list = pm.list_installed()

    # Assert if the output of this method is a list
    assert isinstance(package_list, list)


# Generated at 2022-06-23 00:29:31.981073
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pm = PkgMgr()
    assert pm.list_installed() == NotImplemented


# Generated at 2022-06-23 00:29:35.970067
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    """
    Tests if the is_available method of class PkgMgr returns True or False
    This only tests the method itself, and not the actual package availability
    """
    pm = PkgMgr()
    assert pm.is_available() == None
    # Other methods are tested by the individual package manager classes

# Generated at 2022-06-23 00:29:41.070387
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    class PkgMgrTest(PkgMgr):
        def is_available(self):
            return False
    pkgtest = PkgMgrTest()
    assert pkgtest.is_available() is False


# Generated at 2022-06-23 00:29:45.412108
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCLIMgr(CLIMgr):
        CLI = "echo"

    try:
        assert TestCLIMgr().is_available() == True
    except:
        assert TestCLIMgr().is_available() == False
    return True

# Generated at 2022-06-23 00:29:56.623283
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class testPkgMgr(PkgMgr):
        def __init__(self):
            return

        def is_available(self):
            return True

        def list_installed(self):
            testPackages = ["package1", "package2", "package3"]
            return testPackages

        def get_package_details(self, package):
            return {'name': package,
                    'version': '1.1.1',
                    'summary': 'dummy',
                    'arch': 'amd64'}

    test_mgr = testPkgMgr()
    installed_packages = test_mgr.get_packages()
    assert type(installed_packages)==dict
    assert installed_packages["package1"][0]['name'] == 'package1'

# Generated at 2022-06-23 00:30:04.143313
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class LibMgr_Test(LibMgr):
        pass

    # Set the value of LIB
    LibMgr_Test.LIB = "foobar"
    # Check that the value of _lib is not set
    assert LibMgr_Test()._lib is None
    # Check that is_available() returns False if foobar does not exist
    assert LibMgr_Test().is_available() is False
    # Set the value of LIB
    LibMgr_Test.LIB = "os"
    # Check that is_available() returns True if foobar does not exist
    assert LibMgr_Test().is_available() is True


# Generated at 2022-06-23 00:30:07.908397
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    assert set(get_all_pkg_managers().keys()) == set(['dnf', 'gem', 'homebrew', 'pkgin', 'pkgng', 'pkginfo', 'portage', 'port', 'rpm', 'slpkg'])

# Generated at 2022-06-23 00:30:08.851093
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    manager = CLIMgr()
    assert manager is not None

# Generated at 2022-06-23 00:30:19.568545
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    from ansible.module_utils.common.packages import Package
    from ansible.module_utils.common.process import get_bin_path

    installed_package = Package(name='ansible', version="2.5.1", source='pip')
    expected_packages = {'ansible': [installed_package.dump_dict()]}

    def is_available(self):
        return True
    def list_installed(self):
        return [installed_package]
    def get_package_details(self, package):
        return package.dump_dict()

    class FakeMgr(CLIMgr):
        CLI = 'pip'
    FakeMgr.is_available = is_available.__get__(FakeMgr())
    FakeMgr.list_installed = list_installed.__get__(FakeMgr())
    FakeM

# Generated at 2022-06-23 00:30:24.751390
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():

    # Mock object for instance of PkgMgr
    class MockPkgMgr(PkgMgr):

        def is_available(self):
            return True

    mock_pm = MockPkgMgr()

    assert mock_pm.list_installed() == NotImplemented


# Generated at 2022-06-23 00:30:32.942468
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    import unittest
    import mock
    import sys

    major_version = sys.version_info.major
    module_name = 'ansible.module_utils.package_manager.{0}.{1}'

    class MockLib(LibMgr):
        LIB = 'lib'

        def list_installed(self):
            return ['package1', 'package2', 'package3']

        def get_package_details(self, package):
            return {'name': package.split('package')[1], 'version': '1.0.0'}

    class MockCLI(CLIMgr):
        CLI = 'cli'

        def list_installed(self):
            return ['package1', 'package2', 'package3']


# Generated at 2022-06-23 00:30:37.200395
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    # Expecting an error, since abstract method has no implementation
    with pytest.raises(TypeError):
        package_manager = PkgMgr()
        package_manager.list_installed()



# Generated at 2022-06-23 00:30:38.270404
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    p = PkgMgr()


# Generated at 2022-06-23 00:30:40.075737
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    assert PkgMgr.list_installed() is NotImplemented

# Generated at 2022-06-23 00:30:41.541448
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    pass

# Generated at 2022-06-23 00:30:43.589499
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    mgr = CLIMgr()
    assert mgr._cli is None
    assert mgr._lib is None


# Generated at 2022-06-23 00:30:45.693555
# Unit test for constructor of class LibMgr
def test_LibMgr():

    assert LibMgr()._lib is None


# Generated at 2022-06-23 00:30:47.982629
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    class TestCLIMgr(CLIMgr):
        CLI = None
    assert TestCLIMgr().is_available() is False
    return

# Generated at 2022-06-23 00:30:50.342689
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pass


# Generated at 2022-06-23 00:30:52.212673
# Unit test for constructor of class LibMgr
def test_LibMgr():
    x = LibMgr()
    assert x is not None


# Generated at 2022-06-23 00:30:58.943075
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    from ansible.module_utils._text import to_native

    class TestCLIMgr(CLIMgr):
        CLI = 'test_cli'

    test_cli_mgr = TestCLIMgr()
    test_cli_mgr.is_available()

    if to_native(test_cli_mgr._cli) != to_native(get_bin_path(TestCLIMgr.CLI)):
        return False

    return True

# Generated at 2022-06-23 00:31:00.899162
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    cli = CLIMgr()
    assert cli.CLI is None
    assert cli._cli is None


# Generated at 2022-06-23 00:31:04.424977
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    import pytest
    pm = PkgMgr()
    with pytest.raises(NotImplementedError):
        pm.is_available()


# Generated at 2022-06-23 00:31:15.257480
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class VersionMgr(PkgMgr):
        def is_available(self):
            return True

        def get_package_details(self, package):
            return {'name': package, 'version': 'test', 'source': self.__class__.__name__.lower()}

        def list_installed(self):
            return ['package1', 'package2', 'package3']

    pkg_mgr = VersionMgr()
    packages = pkg_mgr.get_packages()


# Generated at 2022-06-23 00:31:17.165738
# Unit test for constructor of class LibMgr
def test_LibMgr():
    l = LibMgr()
    assert l is not None


# Generated at 2022-06-23 00:31:20.094592
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    pkg_mgr = PkgMgr()
    assert pkg_mgr.get_package_details("Sample_Package") is None
    assert pkg_mgr.get_package_details("Sample_Package_No_Version") is None

# Generated at 2022-06-23 00:31:24.877839
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    package = "bison"
    version = "3.0.5"
    class Test(PkgMgr):
        pass
    test_object = Test()
    assert test_object.get_package_details(package) == {'name': package, 'version': version}


# Generated at 2022-06-23 00:31:26.627557
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    x = PkgMgr()
    assert isinstance(x,PkgMgr)


# Generated at 2022-06-23 00:31:30.611671
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():

    class MyPyPkg(LibMgr):
        LIB='mypy'

    pkg_mgr = MyPyPkg()
    ret = pkg_mgr.is_available()
    assert(ret is not None)



# Generated at 2022-06-23 00:31:36.320021
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():

    import pytest
    with pytest.raises(TypeError) as excinfo:
        # Test that calling abstract method is_available() raises a TypeError
        test = PkgMgr()
        test.is_available()
    assert "Can't instantiate abstract class PkgMgr with abstract methods is_available" in str(excinfo.value)



# Generated at 2022-06-23 00:31:47.689517
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    import json
    json_str = """{
        "name": "ansible",
        "version": "2.5.5",
        "release": "3",
        "arch": "noarch",
        "summary": "Simple IT automation",
        "description": "Reference implementation of an Ansible module using python-base.  See http://ansible.com/ for more information.",
        "url": "https://github.com/ansible/ansible",
        "source": "yum"
    }"""

    json_dict = json.loads(json_str)
    pkgMgr = PkgMgr()
    result = pkgMgr.get_package_details('ansible')
    assert result == json_dict


# Generated at 2022-06-23 00:31:50.157555
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    libmgr = LibMgr()
    assert libmgr.is_available() == False


# Generated at 2022-06-23 00:31:59.005546
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    import os
    from ansible.module_utils.facts.system.pkg_mgr import get_all_pkg_managers

    pkg_mgrs = get_all_pkg_managers()
    assert pkg_mgrs != {}

    cmd = 'which {}'
    for name, cls in pkg_mgrs.items():
        pkg_mgr = cls()
        if pkg_mgr.is_available():
            try:
                # cmd_name = pkg_mgr.CLI if cls.CLI is not None else pkg_mgr.LIB
                # cmd_path = os.popen(cmd.format(cmd_name)).read().strip()

                pkg_mgr.list_installed()
            except AttributeError:
                continue
        else:
            continue

# Generated at 2022-06-23 00:32:00.938932
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pkgmgr = PkgMgr()
    assert pkgmgr.list_installed() == None


# Generated at 2022-06-23 00:32:01.528153
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    assert True

# Generated at 2022-06-23 00:32:03.704337
# Unit test for constructor of class LibMgr
def test_LibMgr():
    test_lib_mgr = LibMgr()
    assert test_lib_mgr._lib is None


# Generated at 2022-06-23 00:32:05.305320
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    """ Unit test for method is_available of class CLIMgr"""
    assert CLIMgr().is_available() == False

# Generated at 2022-06-23 00:32:07.315416
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    assert PkgMgr.is_available() == PkgMgr()


# Generated at 2022-06-23 00:32:08.617748
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    assert len(get_all_pkg_managers()) > 0

# Generated at 2022-06-23 00:32:11.553716
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    import sys

    class TestLibMgr(LibMgr):
        LIB = 'sys'

    pkg_mgr = TestLibMgr()
    assert pkg_mgr.is_available() == True
    assert pkg_mgr._lib == sys


# Generated at 2022-06-23 00:32:14.975462
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'test_lib_mgr'
    test_lib_mgr = TestLibMgr()
    try:
        assert not test_lib_mgr.is_available()
        test_lib_mgr._lib = __import__(test_lib_mgr.LIB)
        assert test_lib_mgr.is_available()
    except ImportError:
        assert False


# Generated at 2022-06-23 00:32:16.768832
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    assert list_installed() == {}


# Generated at 2022-06-23 00:32:21.524491
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    # Importing CLIMgr throws ValueError as _cli is None
    # Should throw error
    try:
        CLIMgr()
    except ValueError:
        pass

    # _cli is not None
    # Should not throw error
    try:
        CLIMgr().is_available()
    except ValueError:
        pass

# Generated at 2022-06-23 00:32:26.828216
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    from ansible.module_utils.facts.utils import get_distribution
    for pkgmgr in get_all_pkg_managers().values():
        if isinstance(pkgmgr, CLIMgr):
            if get_distribution() in pkgmgr.DISTRO or pkgmgr.DISTRO is None:
                assert pkgmgr().is_available() == True

# Generated at 2022-06-23 00:32:38.271794
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    from ansible.module_utils.common.package import get_all_pkg_managers
    from ansible.module_utils.common.package.portage import PortagePkgMgr
    from ansible.module_utils.common.package.rpm import RPMPkgMgr
    from ansible.module_utils.common.package.yum import YUMPkgMgr
    from ansible.module_utils.common.package.apt import AptPkgMgr
    from ansible.module_utils.common.package.apk import APKPkgMgr
    from ansible.module_utils.common.package.rabbitvcs import RabbitVcsPkgMgr
    from ansible.module_utils.common.package.pac import PACPkgMgr
    from ansible.module_utils.common.package.dmg import DMGPkg

# Generated at 2022-06-23 00:32:49.300324
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
  class TestPkgMgr(PkgMgr):
    def __init__(self):
      super(TestPkgMgr, self).__init__()
    def is_available(self):
      return True
    def list_installed(self):
      return ['package1', 'package2']
    def get_package_details(self, package):
      return {'name': package, 'version': '1.0', 'source': 'test'}
  res = TestPkgMgr().list_installed()
  assert res == ['package1', 'package2'], 'test_PkgMgr_list_installed returned {} instead of ["package1", "package2"]'.format(res)


# Generated at 2022-06-23 00:32:49.878332
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    pass

# Generated at 2022-06-23 00:32:59.208499
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    from .yumpkg import YumPkgMgr as Yum
    from .dnfpkg import DnfPkgMgr as Dnf
    from .aptpkg import AptPkgMgr as Apt
    from .macportspkg import MacportsPkgMgr as Macports
    from .pacmanpkg import PacmanPkgMgr as Pacman
    from .pippkg import PipPkgMgr as Pip
    from .gempkg import GemPkgMgr as Gem
    from .freebsdpkg import FreebsdPkgMgr as FreebsdPkg
    from .composerpkg import ComposerPkgMgr as Composer
    from .puppetserverpkg import PuppetServerPkgMgr as PuppetServer
    from .perlpkg import PerlPkgMgr as Perl
    from .apkpkg import ApkP

# Generated at 2022-06-23 00:33:00.171217
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    mgr = CLIMgr()
    assert 'CLIMgr' in mgr.__repr__()


# Generated at 2022-06-23 00:33:10.870161
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class testPkgMgr(PkgMgr):
        def is_available(self):
            return True

        def list_installed(self):
            return ["foo", "bar", "foo"]

        def get_package_details(self, package):
            return {'name': package,
                    'version': "0.42",
                    'source': self.__class__.__name__.lower()}
    test_class = testPkgMgr()
    packages_list = test_class.get_packages()

# Generated at 2022-06-23 00:33:13.214910
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    b = CLIMgr()
    assert b
    assert isinstance(b, PkgMgr)

# Generated at 2022-06-23 00:33:17.401586
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    assert issubclass(PkgMgr,object)
    assert hasattr(PkgMgr,'list_installed')
    assert callable(PkgMgr.list_installed)


# Generated at 2022-06-23 00:33:19.043680
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    cm = LibMgr()
    assert cm.is_available() == False


# Generated at 2022-06-23 00:33:22.512290
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    # Check if the method raises NotImplementedError
    with pytest.raises(NotImplementedError):
        test_obj = PkgMgr()
        test_obj.get_packages()

# Generated at 2022-06-23 00:33:29.094453
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = "os"
    class TestLibMgr1(LibMgr):
        LIB = "os1"
    test_lib = TestLibMgr()
    test_lib1 = TestLibMgr1()
    assert test_lib.is_available() == True
    assert test_lib1.is_available() == False


# Generated at 2022-06-23 00:33:30.602592
# Unit test for constructor of class LibMgr
def test_LibMgr():
    pm = LibMgr()
    assert pm._lib is None


# Generated at 2022-06-23 00:33:31.887767
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    assert 1 == PkgMgr.get_package_details(1)

# Generated at 2022-06-23 00:33:33.394447
# Unit test for constructor of class LibMgr
def test_LibMgr():
    obj = LibMgr()
    assert obj


# Generated at 2022-06-23 00:33:35.000456
# Unit test for constructor of class LibMgr
def test_LibMgr():
    lm = LibMgr()

    assert lm._lib, "The library part of a package manager is not set."

# Generated at 2022-06-23 00:33:36.940710
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    test_mgr = PkgMgr()
    assert test_mgr.is_available() is False



# Generated at 2022-06-23 00:33:38.858934
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pkgmgr=PkgMgr()
    pkgmgr.list_installed()



# Generated at 2022-06-23 00:33:49.175634
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    from ansible.module_utils.package.os_package_manager import OSMgr

    cls = OSMgr()
    cls.list_installed = lambda: [('bash', '4.2.46', '2.fc19.i686', 'fedora', '19', 'i386'), ('bash', '4.2.46', '2.fc19.x86_64', 'fedora', '19', 'x86_64')]
    cls.get_package_details = lambda p: {'name': p[0], 'version': p[1], 'release': p[2], 'distribution': p[3], 'distribution_version': p[4], 'arch': p[5]}

# Generated at 2022-06-23 00:33:52.161605
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():

    class LibMgrSubclass(LibMgr):

        LIB = 'time'

    pm = LibMgrSubclass()
    assert pm.is_available() is True

# Generated at 2022-06-23 00:33:54.809194
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    pkg_mgr = PkgMgr()
    assert pkg_mgr is not None


# Generated at 2022-06-23 00:33:56.520124
# Unit test for constructor of class LibMgr
def test_LibMgr():
    obj = LibMgr()
    assert obj._lib is None



# Generated at 2022-06-23 00:33:58.676594
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    x = CLIMgr()
    assert x._cli is None
    assert x.CLI is None


# Generated at 2022-06-23 00:34:04.008790
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    cli_mgr = CLIMgr()
    cli_mgr.CLI = 'ls'
    assert cli_mgr.is_available() == True

    cli_mgr.CLI = 'cd'
    assert cli_mgr.is_available()  == False


# Generated at 2022-06-23 00:34:07.686520
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    pkg = PkgMgr()
    assert pkg is not None, "Can't construct class PkgMgr"

if __name__ == "__main__":
    test_PkgMgr()

# Generated at 2022-06-23 00:34:09.729843
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class MyTestClass(LibMgr):
        LIB = 'mytestlib'
    obj = MyTestClass()
    assert obj._lib is None

# Generated at 2022-06-23 00:34:11.205191
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    cm = CLIMgr()
    assert cm.CLI == None

# Generated at 2022-06-23 00:34:16.188179
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    list_installed = "test"
    class TestPkgMgr(PkgMgr):
        def list_installed(self):
            return list_installed
        def get_package_details(self, package):
            return package
    tpm = TestPkgMgr()
    result = tpm.get_packages()
    assert result == list_installed

# Generated at 2022-06-23 00:34:17.289991
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    obj = PkgMgr()

# Generated at 2022-06-23 00:34:19.480826
# Unit test for constructor of class PkgMgr
def test_PkgMgr():

    obj = PkgMgr()
    assert isinstance(obj, PkgMgr)



# Generated at 2022-06-23 00:34:23.696117
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    class TestPkgMgr(PkgMgr):
        def list_installed(self):
            return []

    test_mgr = TestPkgMgr()
    assert test_mgr.list_installed() == []


# Generated at 2022-06-23 00:34:33.694695
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    class AptMgr(CLIMgr):
        CLI = 'apt'

        def list_installed(self):
            # This method should return a list of installed packages, each list item will be passed to get_package_details
            pass

        def get_package_details(self, package):
            # This takes a 'package' item and returns a dictionary with the package information, name and version are minimal requirements
            pass

    class YumMgr(CLIMgr):
        CLI = 'yum'

        def list_installed(self):
            # This method should return a list of installed packages, each list item will be passed to get_package_details
            pass

        def get_package_details(self, package):
            # This takes a 'package' item and returns a dictionary with the package information, name and version are minimal requirements
            pass

    ap = A

# Generated at 2022-06-23 00:34:34.750598
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    return None


# Generated at 2022-06-23 00:34:37.461329
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class Mock(LibMgr):
        LIB = 'ansible.module_utils.facts.virtual.yum.yum'

    mock = Mock()
    assert mock.is_available() is True


# Generated at 2022-06-23 00:34:47.319109
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    # get_all_pkg_managers()
    list_pkgmgr = get_all_pkg_managers()
    #assert len(list_pkgmgr) > 0
    #assert type(list_pkgmgr) == dict
    #assert 'yumpkgmgr' in list_pkgmgr
    #assert 'yumpkgmgrsubclass' in list_pkgmgr
    #type(list_pkgmgr['yumpkgmgrsubclass']) == type(YumPkgMgr)
    #type(list_pkgmgr['yumpkgmgrsubclass']('test')) == type(YumPkgMgr('test'))
    return list_pkgmgr

# Generated at 2022-06-23 00:34:49.405582
# Unit test for constructor of class LibMgr
def test_LibMgr():
    l = LibMgr()
    assert l._lib is None
    assert l.LIB is None


# Generated at 2022-06-23 00:34:50.439383
# Unit test for constructor of class CLIMgr
def test_CLIMgr():

    pkg_mgr = CLIMgr()
    assert pkg_mgr is not None

# Generated at 2022-06-23 00:34:58.705592
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    # Test if the base class returns false
    pkmgr = PkgMgr()
    assert not pkmgr.is_available()

    # Test if the CLIMgr subclass returns false
    class TestCLIMgr(CLIMgr):
        CLI = 'test_cli_command'

    pkmgr = TestCLIMgr()
    assert not pkmgr.is_available()

    # Test if the LibMgr subclass returns false
    class TestLibMgr(LibMgr):
        LIB = 'test_lib_module'

    pkmgr = TestLibMgr()
    assert not pkmgr.is_available()


# Generated at 2022-06-23 00:35:02.048871
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    pkg_managers = get_all_pkg_managers()
    print(pkg_managers)
    assert isinstance(pkg_managers, dict)
    assert len(pkg_managers) > 0

# Generated at 2022-06-23 00:35:13.396683
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class PkgMgrUnitTest(PkgMgr):
        def __init__(self):
            pass

        def is_available(self):
            return True
        def list_installed(self):
            return ['test_package1', 'test_package2']
        def get_package_details(self, package):
            return dict(name="%s" % package, version="%s" % package)

    pkgMgr = PkgMgrUnitTest()

# Generated at 2022-06-23 00:35:14.556411
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    cm = CLIMgr()
    assert cm is not None

# Generated at 2022-06-23 00:35:20.932226
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    from ansible.module_utils._text import to_bytes

    class test_LibMgr(LibMgr):
        # This will always fail...
        LIB = 'not_a_real_lib'
    obj = test_LibMgr()
    assert not obj.is_available()

    class test_LibMgr(LibMgr):
        # This is not a real lib, but it passes the test
        LIB = 'make_ansible_happy'
    obj = test_LibMgr()
    assert obj.is_available()



# Generated at 2022-06-23 00:35:23.649464
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    ''' Test for method is_available of class LibMgr '''
    # Test with a python module that doesn't exist
    assert LibMgr().is_available() == False


# Generated at 2022-06-23 00:35:24.963576
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    pkgmgr = PkgMgr()


# Generated at 2022-06-23 00:35:26.429462
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    obj = PkgMgr()
    assert obj is not None


# Generated at 2022-06-23 00:35:29.389814
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    class Test(PkgMgr):
        def __init__(self):
            pass
        def is_available(self):
            return True
    assert Test().is_available() == True


# Generated at 2022-06-23 00:35:32.994560
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():

    class LibMgrTest(LibMgr):
        LIB = "os" # "os" is always available so we will use it for testing

    assert LibMgrTest().is_available() == True, "Method is_available of LibMgr class did not return True"


# Generated at 2022-06-23 00:35:33.593408
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pass

# Generated at 2022-06-23 00:35:39.596966
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    result = module.exit_json(changed=False)
    assert result['changed'] is False
    class TestLibMgr(LibMgr):
        LIB = 'test'
    assert TestLibMgr().is_available() is False


# Generated at 2022-06-23 00:35:42.705674
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    for cls in get_all_pkg_managers().values():
        p = cls()
        assert p.is_available()

# Generated at 2022-06-23 00:35:49.081852
# Unit test for constructor of class LibMgr
def test_LibMgr():
    libmgr = LibMgr()
    assert libmgr._lib is None
    assert hasattr(libmgr, 'is_available')
    assert hasattr(libmgr, 'list_installed')
    assert hasattr(libmgr, 'get_package_details')
    assert hasattr(libmgr, 'get_packages') or hasattr(libmgr, 'get_packages_classic')
    assert hasattr(libmgr, 'LIB')


# Generated at 2022-06-23 00:35:49.726145
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    pass

# Generated at 2022-06-23 00:35:58.890484
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    class MockPkgMgr(PkgMgr):

        @abstractmethod
        def is_available(self):
            pass

        @abstractmethod
        def list_installed(self):
            pass

        @abstractmethod
        def get_package_details(self, package):
            pass

    # Create test package details dictionary
    package_details = dict()
    package_details['name'] = 'test_name'
    package_details['version'] = 'test_version'
    package_details['source'] = 'test_source'

    # Create test PkgMgr object
    mock_pkg_mgr = MockPkgMgr()
    # Mock the list_installed method to return the package_details dictionary
    mock_pkg_mgr.list_installed = lambda: [package_details]
    # Mock the get_package_

# Generated at 2022-06-23 00:36:00.257106
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    pass


# Generated at 2022-06-23 00:36:02.981486
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    assert PkgMgr.is_available(), "PkgMgr.is_available() should always return True."

# Generated at 2022-06-23 00:36:03.829061
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    assert False

# Generated at 2022-06-23 00:36:07.116242
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    pkg_mgrs = get_all_pkg_managers()

    assert isinstance(pkg_mgrs, dict)
    assert len(pkg_mgrs) == 3

# Generated at 2022-06-23 00:36:07.901600
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    pass

# Generated at 2022-06-23 00:36:16.594471
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    class pkgmgr(PkgMgr):
        def is_available(self):
            pass
        def list_installed(self):
            return ['A']
        def get_package_details(self, package):
            return {'source': 'test', 'name': 'A', 'version': '1.0'}

    installed_packages = pkgmgr().get_packages()
    assert len(installed_packages) == 1
    assert installed_packages['A'][0]['source'] == 'test'
    assert installed_packages['A'][0]['name'] == 'A'
    assert installed_packages['A'][0]['version'] == '1.0'

# Generated at 2022-06-23 00:36:19.629359
# Unit test for constructor of class LibMgr
def test_LibMgr():
    test_lib_mgr = LibMgr()
    assert test_lib_mgr.LIB is None
    assert test_lib_mgr._lib is None


# Generated at 2022-06-23 00:36:23.709326
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    from ansible_collections.ansible.community.plugins.module_utils.package import aptpkg
    apt_mgr = aptpkg.APT()
    results = apt_mgr.list_installed()
    assert len(results) != 0


# Generated at 2022-06-23 00:36:28.187072
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pm_list = get_all_pkg_managers()
    for _, pm in pm_list.items():
        if not pm.is_available():
            continue
        pkgs = pm.list_installed()
        assert(isinstance(pkgs, list))


# Generated at 2022-06-23 00:36:32.956562
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = '_test_libmgr_lib'

    import sys
    sys.modules['_test_libmgr_lib'] = 'lalala'
    pkgmgr = TestLibMgr()
    assert pkgmgr.is_available()


# Generated at 2022-06-23 00:36:34.447235
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    assert PkgMgr
    method_test = PkgMgr()
    type(method_test.is_available()) is bool


# Generated at 2022-06-23 00:36:36.405457
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    libMgr = LibMgr()
    assert libMgr.is_available() == True



# Generated at 2022-06-23 00:36:42.824879
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    import types

    assert not CLIMgr().is_available()

    class FakeCLI(CLIMgr):
        CLI = '__FAKE__'

    assert not FakeCLI().is_available()

    # FakeCLI() must be an instance of class CLIMgr
    assert isinstance(FakeCLI(), types.InstanceType)
    # FakeCLI().is_available() equals to False
    assert not FakeCLI().is_available()

# Generated at 2022-06-23 00:36:45.076151
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pkgMgr = PkgMgr()
    assert False == pkgMgr.is_available()


# Generated at 2022-06-23 00:36:47.644582
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    pkg_managers = get_all_pkg_managers()
    assert(pkg_managers)

# Generated at 2022-06-23 00:36:54.364311
# Unit test for constructor of class LibMgr
def test_LibMgr():
    lm = LibMgr()
    assert lm._lib is None
    LibMgr.LIB = 'ansible_collections.ansible.community.plugins.modules.system.pip.lib'
    lm = LibMgr()
    assert lm._lib is None
    LibMgr.LIB = 'ansible_collections.ansible.community.plugins.modules.system.pyenv.lib'
    lm = LibMgr()
    assert lm._lib is None


# Generated at 2022-06-23 00:36:58.951824
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class test(LibMgr):
        LIB = None
    assert test().is_available() is False
    test.LIB = ''
    assert test().is_available() is False
    test.LIB = 'abc'
    assert test().is_available() is False
    test.LIB = 'ansible.module_utils.common._utils'
    assert isinstance(test()._lib, object)
    return True


# Generated at 2022-06-23 00:37:00.380379
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    assert isinstance(PkgMgr.is_available(PkgMgr), NotImplementedError)


# Generated at 2022-06-23 00:37:03.414996
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class SubLibMgr(LibMgr):
        LIB = 'sublib'
    test_libmgr = SubLibMgr()
    assert test_libmgr._lib is None
    

# Generated at 2022-06-23 00:37:05.504445
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class CLIMgrMock(CLIMgr):
        CLI = 'foo'

    assert CLIMgrMock().is_available() == True

# Generated at 2022-06-23 00:37:07.232517
# Unit test for constructor of class LibMgr
def test_LibMgr():
    lm = LibMgr()
    assert(lm._lib == None)
