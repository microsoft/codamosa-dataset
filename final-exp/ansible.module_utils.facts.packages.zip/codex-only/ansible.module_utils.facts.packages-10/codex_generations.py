

# Generated at 2022-06-23 00:27:14.658578
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    # Importing the class to test
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgr

    # create an instance of the class
    my_pkg_mgr_class = PkgMgr()

    # create an instance of the class
    my_pkg_mgr_class.list_installed = lambda : ['foo', 'bar']
    my_pkg_mgr_class.get_package_details = lambda package: {'name': package, 'version': '1.0'}
    expected = {'foo': [{'name': 'foo', 'version': '1.0', 'source': 'pkg_mgr'}], 'bar': [{'name': 'bar', 'version': '1.0', 'source': 'pkg_mgr'}] }

    # test the result with the expected


# Generated at 2022-06-23 00:27:16.338076
# Unit test for constructor of class LibMgr
def test_LibMgr():
    manager = LibMgr()
    assert manager


# Generated at 2022-06-23 00:27:18.134907
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    assert callable(PkgMgr.list_installed)


# Generated at 2022-06-23 00:27:20.926217
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class MockLibMgr(LibMgr):
        LIB = 'example_lib'
    manager = MockLibMgr()
    assert manager.LIB == 'example_lib'
    assert manager._lib is None

# Generated at 2022-06-23 00:27:31.727180
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    # Get a list of all available package managers
    available_package_managers = get_all_pkg_managers()

    # Check all managers have is_available()
    for pkg_manager in available_package_managers.keys():
        if not available_package_managers[pkg_manager]().is_available():
            raise NotImplementedError("Function is_available is not implemented for " + pkg_manager + " package manager")

    # Check all managers have list_installed()
    for pkg_manager in available_package_managers.keys():
        if not available_package_managers[pkg_manager]().list_installed():
            raise NotImplementedError("Function list_installed is not implemented for " + pkg_manager + " package manager")

    # Check all managers have get_package_details()

# Generated at 2022-06-23 00:27:33.264010
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    obj = PkgMgr()
    assert obj


# Generated at 2022-06-23 00:27:35.797306
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    print("Testing PkgMgr_is_available")
    assert PkgMgr.is_available() == NotImplementedError


# Generated at 2022-06-23 00:27:40.789466
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    import sys

    class LibraryMgr(LibMgr):
        LIB = "sys"

    lm = LibraryMgr()
    # libmgr.is_available() will set _lib to sys module
    assert lm._lib is None
    assert lm.is_available()
    assert lm._lib is sys


# Generated at 2022-06-23 00:27:48.890820
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    class PkgMgr0(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['PkgMgr0_Test']
        def get_package_details(self, package):
            return dict({'name': package})
    pm = PkgMgr0()
    assert pm.is_available() == True
    assert len(pm.list_installed()) == 1
    assert 'PkgMgr0_Test' in pm.list_installed()
    assert pm.get_package_details('PkgMgr0_Test') == dict({'name': 'PkgMgr0_Test'})


# Generated at 2022-06-23 00:27:50.785119
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    pm = CLIMgr()
    pm._cli = 'test'
    assert pm.is_available()

# Generated at 2022-06-23 00:27:54.984433
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():

    class PkgMgrTester(PkgMgr):
        def is_available(self):
            pass

        def list_installed(self):
            pass

        def get_package_details(self, package):
            pass

    pm = PkgMgrTester()
    assert pm.is_available() == NotImplemented


# Generated at 2022-06-23 00:27:58.212757
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestLibMgr(LibMgr):
        LIB='TestLibMgr'
    a = TestLibMgr()
    assert a.__class__.__name__ != 'TestLibMgr'

# Generated at 2022-06-23 00:28:00.128673
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pm = PkgMgr()
    assert pm.is_available() == False

# Generated at 2022-06-23 00:28:01.831478
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    res = LibMgr.is_available
    assert res



# Generated at 2022-06-23 00:28:04.287584
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pkgmgr = PkgMgr()
    assert pkgmgr.list_installed() == None


# Generated at 2022-06-23 00:28:06.222656
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    libmgr = LibMgr()
    assert libmgr.is_available() == False


# Generated at 2022-06-23 00:28:10.562887
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    import unittest
    class PkgMgr_list_installed(unittest.TestCase):
        def test_list_installed(self):
            pm = PkgMgr()

            self.assertRaises(NotImplementedError, pm.list_installed())
    unittest.main()

# Generated at 2022-06-23 00:28:15.094960
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    lib = LibMgr()
    cli = CLIMgr()
    if not lib.is_available():
        assert lib.is_available() is False
    else:
        assert lib.is_available() is True

    if not cli.is_available():
        assert cli.is_available() is False
    else:
        assert cli.is_available() is True



# Generated at 2022-06-23 00:28:17.209208
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    c = CLIMgr()
    assert c._cli == None
    assert c.CLI == None



# Generated at 2022-06-23 00:28:18.269598
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    assert True

# Generated at 2022-06-23 00:28:25.624401
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    test_class = PkgMgr()
    # The method is_available of class PkgMgr is abstract.
    # So we must use it to test the class is abstract.
    # If the class is abstract, the test will not pass.
    test_instance = test_class()
    try:
        test_instance.is_available()
    except NotImplementedError:
        pass
    else:
        raise AssertionError('The test should not pass because the method is_available of class PkgMgr is abstract.')


# Generated at 2022-06-23 00:28:26.865637
# Unit test for constructor of class LibMgr
def test_LibMgr():
    mgr = LibMgr()
    assert mgr is not None


# Generated at 2022-06-23 00:28:29.737908
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    """ Unit test for method get_packages of class PkgMgr """
    import sys
    import imp
    import os

    plugin_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'plugins')
    sys.path.append(plugin_path)

    import dpkg
    imp.reload(dpkg)
    pm = dpkg.Dpkg()
    assert pm.is_available()
    assert len(pm.get_packages()) > 1

# Generated at 2022-06-23 00:28:36.658082
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    from ansible.module_utils.facts.system.pkg_mgr.pkg_mgr import CLIMgr
    class MyCLIMgr(CLIMgr):
        CLI = 'my_cli'
    #
    # Test if CLI is returned correctly
    #
    # 1. CLI is present in PATH
    my_CLIMgr_1 = MyCLIMgr()
    assert my_CLIMgr_1.is_available() is True
    # 2. CLI is not present in PATH
    my_CLIMgr_2 = MyCLIMgr()
    my_CLIMgr_2.CLI = '/not/present/in/PATH'
    assert my_CLIMgr_2.is_available() is False

# Generated at 2022-06-23 00:28:44.671542
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class PackageMgrTester(PkgMgr):
        def is_available(self):
            return True

        def list_installed(self):
            return [{'name': 'a', 'version': '1'}, {'name': 'a', 'version': '2'}]

        def get_package_details(self, package):
            package['source'] = 'source'
            return package

    pkg = PackageMgrTester()
    assert pkg.get_packages() == {'a': [{'name': 'a', 'version': '1', 'source': 'source'}, {'name': 'a', 'version': '2', 'source': 'source'}]}

# Generated at 2022-06-23 00:28:55.792293
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    import unittest

    class PkgMgr_get_packages_test(PkgMgr):

        def list_installed(self):

            return [1, 2, 3]

        def get_package_details(self, package):

            return {'name': package, 'version': package}

    assert PkgMgr_get_packages_test().get_packages() == {1: [{'name': 1, 'version': 1, 'source': 'pkgmgr_get_packages_test'}],
                                                         2: [{'name': 2, 'version': 2, 'source': 'pkgmgr_get_packages_test'}],
                                                         3: [{'name': 3, 'version': 3, 'source': 'pkgmgr_get_packages_test'}]}


# Execute unit tests with
#  

# Generated at 2022-06-23 00:28:59.281829
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    class MyPkgMgr(PkgMgr):
        def is_available(self):
            pass
        def list_installed(self):
            pass
        def get_package_details(self, package):
            pass

    pkgmgr = MyPkgMgr()
    assert pkgmgr is not None


# Generated at 2022-06-23 00:29:01.260784
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    got = PkgMgr.is_available()
    assert got == NotImplementedError


# Generated at 2022-06-23 00:29:10.406608
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    # Override __import__ to check that import is not called
    def __import__(mod,*args,**kwargs):
        raise ImportError

    old_import = __builtins__.__import__
    try:
        __builtins__.__import__ = __import__
        # Test with false expected result
        pkg = CLIMgr()
        assert pkg.CLI == None
        assert not pkg.is_available()
        # Test with true expected result
        pkg.CLI = 'python'
        assert pkg.is_available()
    finally:
        __builtins__.__import__ = old_import

# Generated at 2022-06-23 00:29:11.540854
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    pass


# Generated at 2022-06-23 00:29:12.169852
# Unit test for constructor of class LibMgr
def test_LibMgr():
    assert LibMgr() is not None

# Generated at 2022-06-23 00:29:15.523350
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    """
    Unit test for `get_bin_path` that is used by CLIMgr
    """
    assert get_bin_path('python') is not None
    assert get_bin_path('nosuchapp') is None

# Generated at 2022-06-23 00:29:17.702710
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    mgr = CLIMgr()
    assert mgr._cli == None


# Generated at 2022-06-23 00:29:19.536752
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    pm = PkgMgr()
    packages = pm.get_packages()
    assert packages == {}

# Generated at 2022-06-23 00:29:28.466931
# Unit test for constructor of class LibMgr
def test_LibMgr():
    import copy
    from ansible.module_utils.common.collections import ImmutableDict

    class test_LibMgr(LibMgr):

        LIB = "test"
        
        def list_installed(self):
            return []

        def get_package_details(self, package):
            return {package: {}}

    pkg_mgr = test_LibMgr()

    assert pkg_mgr.is_available() == True
    assert pkg_mgr._lib != None
    assert pkg_mgr._cli == None
    assert pkg_mgr.get_packages() == {}


# Generated at 2022-06-23 00:29:35.431885
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    # A basic test to ensure get_packages is implemented for all PkgMgr subclasses
    # Note: The implementation of each PkgMgr subclass is tested elsewhere
    for pkg_mgr in get_all_pkg_managers().values():
        pkg_mgr_obj = pkg_mgr()
        if pkg_mgr_obj.is_available():
            pkg_res = pkg_mgr_obj.get_packages()
            assert isinstance(pkg_res, dict)

# Generated at 2022-06-23 00:29:41.414761
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pkg_mgr_list = get_all_pkg_managers()
    for pkg_mgr in pkg_mgr_list:
        pkg_mgr_list[pkg_mgr].is_available()


# Generated at 2022-06-23 00:29:42.755203
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    assert LibMgr().is_available() == False


# Generated at 2022-06-23 00:29:46.344506
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class MyMgr(CLIMgr):
        CLI = "test"
    my_mgr = MyMgr()
    assert isinstance(my_mgr.is_available(), bool) == True


# Generated at 2022-06-23 00:29:50.121449
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class Foo(LibMgr):
        LIB = 'FakeLib'

    foo = Foo()
    # Does not throw an exception (and there should not be an import warning)
    assert foo.is_available() is False



# Generated at 2022-06-23 00:29:52.199333
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    obj = PkgMgr()
    assert isinstance(obj, PkgMgr)


# Generated at 2022-06-23 00:30:02.420258
# Unit test for method get_packages of class PkgMgr

# Generated at 2022-06-23 00:30:03.437423
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr() is not None

# Generated at 2022-06-23 00:30:07.527484
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    libmgr = LibMgr()
    # The class variable LIB should not be empty in order to test the method
    assert libmgr.LIB is not None
    # The default implementation of is_available() should return False
    assert libmgr.is_available() is False


# Generated at 2022-06-23 00:30:10.029848
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    test_package = 'Test_Package'
    pkg_mgr = PkgMgr()
    pkg_mgr.get_package_details(test_package)


# Generated at 2022-06-23 00:30:16.437976
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    from ansible.module_utils.facts import PkgMgrFactCollector
    pkgmgrs = PkgMgrFactCollector(module=None)
    for pkgmgr in pkgmgrs.pkg_mgrs:
        for info in pkgmgrs.pkg_mgrs[pkgmgr].list_installed():
            assert info is not None
            assert isinstance(info, str)


# Generated at 2022-06-23 00:30:17.748980
# Unit test for constructor of class LibMgr
def test_LibMgr():
    lm = LibMgr()
    assert lm._lib is None

# Generated at 2022-06-23 00:30:27.135497
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    PkgMgr = __import__('ansible.module_utils.facts.system.pkg_mgr').PkgMgr
    mgr = PkgMgr()
    mgr.__class__.__bases__ = (CLIMgr,)
    mgr.CLI = 'echo'
    mgr.get_package_details = lambda x: {'name':'pack', 'version':'1.0.0'}
    mgr.list_installed = lambda: ['PACK']
    assert mgr.get_packages() == {'pack': [{'name': 'pack', 'version': '1.0.0', 'source': 'CLIMgr'}]}



# Generated at 2022-06-23 00:30:27.827110
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
     assert CLIMgr


# Generated at 2022-06-23 00:30:32.093078
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class DummyCLIMgr(CLIMgr):
        CLI = '/any/bin'
    inst = DummyCLIMgr()
    import mock
    with mock.patch('ansible.module_utils.common._utils.get_bin_path') as mock_get_bin_path:
        mock_get_bin_path.return_value = 'any_path'
        assert inst.is_available() == True

# Generated at 2022-06-23 00:30:38.692843
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():

    from ansible.module_utils.facts.collector.pkg_mgrs.pip import PipMgr
    pip_mgr = PipMgr()
    pip_bin_path = get_bin_path('pip')
    assert pip_mgr.is_available() is True
    assert pip_mgr._cli == pip_bin_path


# Generated at 2022-06-23 00:30:42.201461
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    class PkgMgr(PkgMgr):
        def list_installed(self):
            print('foo')
            return 'bar'

        def get_package_details(self, package):
            pass

    test = PkgMgr()
    result = test.list_installed()
    assert result == 'bar'

# Generated at 2022-06-23 00:30:43.850595
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():

    libmgr = LibMgr()
    assert libmgr.is_available() == False


# Generated at 2022-06-23 00:30:47.220827
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    class PM(PkgMgr):
        pass

    assert not PM().is_available(), "Should not return true for unimplemented abstract class."



# Generated at 2022-06-23 00:30:53.672904
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    import unittest
    class TestPkgMgr(PkgMgr):
        def list_installed(self):
            return ['calc', 'vim']
        def get_package_details(self, package):
            package_details = {}
            if package == 'calc': 
                package_details['name'] = 'calc'
                package_details['version'] = '1.0.0'
            elif package == 'vim':
                package_details['name'] = 'vim'
                package_details['version'] = '1.1.1'
            return package_details
    class Test(unittest.TestCase):
        def test_get_package_details(self):
            test_pkgmgr = TestPkgMgr()

# Generated at 2022-06-23 00:31:04.734288
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():

    try:
        import os
        import pytest
        from ansible.module_utils.common.process import get_bin_path
    except ImportError:
        pytest.skip('module pytest or one of its dependencies is missing')

    # 'pytest' is required due to the use of 'popen' in 'get_bin_path',
    # it creates an isolated environment for 'popen', so we can mock missing binaries.
    class DummyPkgMgr(PkgMgr):

        CLI = 'dummy'

        def is_available(self):
            return True

        def list_installed(self):
            return []

        def get_package_details(self, package):
            return {}

    class DummyCLIMgr(CLIMgr):

        CLI = 'dummy'


# Generated at 2022-06-23 00:31:15.590672
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    class FakePkgMgr(PkgMgr):

        def is_available(self):
            return True

        def list_installed(self):
            return ['foo', 'bar', 'bar']

        def get_package_details(self, package):
            return {'name': package, 'version': package + '_version'}

    pkg_mgr = FakePkgMgr()

# Generated at 2022-06-23 00:31:17.703281
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    obj = CLIMgr()
    assert obj.CLI is None


# Generated at 2022-06-23 00:31:19.993730
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():

    manager = PkgMgr()
    assert manager.get_package_details("test") is None

# Generated at 2022-06-23 00:31:23.835806
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    managers = get_all_pkg_managers()

    # If we get an empty dictionary, the test has failed
    assert managers != {}

    # And the expected managers are present
    assert 'apt' in managers
    assert 'apt_rpm' in managers

# Generated at 2022-06-23 00:31:34.899335
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return False
        def list_installed(self):
            return [{}, {}]
        def get_package_details(self, package):
            return {'name': package.get('name', 'test'), 'version': package.get('version', '1.0')}

    p = TestPkgMgr()
    assert p.get_package_details({'name': 'test_name', 'version': 'test_version'}) == {'name': 'test_name', 'version': 'test_version'}
    assert p.get_packages() == {'test': [{'name': 'test', 'version': '1.0'}, {'name': 'test', 'version': '1.0'}]}


# Generated at 2022-06-23 00:31:36.693164
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr().CLI is None



# Generated at 2022-06-23 00:31:40.172927
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pkgmgr = PkgMgr()
    installed_pkgs = pkgmgr.list_installed()
    assert isinstance(installed_pkgs, list)


# Generated at 2022-06-23 00:31:48.730571
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    import tempfile
    # test a successful construct of CLIMgr
    path = '/tmp/pkg_mgr'
    open(path, 'w').close()
    fake_cli = CLIMgr()
    fake_cli.CLI = path
    assert fake_cli.is_available() == True
    # test a construct failure of CLIMgr
    fake_cli = CLIMgr()
    fake_cli.CLI = '/tmp/does_not_exist'
    assert fake_cli.is_available() == False

# Generated at 2022-06-23 00:31:50.641998
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    pm = PkgMgr()
    pm.get_package_details()


# Generated at 2022-06-23 00:31:50.998407
# Unit test for constructor of class LibMgr
def test_LibMgr():
    pass

# Generated at 2022-06-23 00:31:52.312475
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    assert isinstance(get_all_pkg_managers(), dict)

# Generated at 2022-06-23 00:31:59.085075
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    # Test with a the class test_PkgMgr_get_packages
    class TestPkgMgr(PkgMgr):
        def list_installed(self):
            # This method should return a list of installed packages, each list item will be passed to get_package_details
            pass

        def get_package_details(self, package):
            # This takes a 'package' item and returns a dictionary with the package information, name and version are minimal requirements
            return dict(name="package_name", version="package_version")

    result = TestPkgMgr().get_packages()
    assert len(result) == 1
    assert "package_name" in result
    assert result["package_name"][0]["version"] == "package_version"
    assert "source" in result["package_name"][0]

# Generated at 2022-06-23 00:32:02.031309
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    """
    Test that get_all_pkg_managers returns all subclasses of PkgMgr.
    """
    assert len(get_all_pkg_managers()) > 0



# Generated at 2022-06-23 00:32:06.166941
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    mgr = CLIMgr()
    assert mgr._cli is None
    mgr.CLI = '/usr/bin/ls'
    assert mgr._cli is None
    assert mgr.is_available()
    assert mgr._cli == '/usr/bin/ls'


# Generated at 2022-06-23 00:32:09.555063
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class MockCLIMgr(CLIMgr):
        CLI = 'foo'
    manager = MockCLIMgr()
    assert manager.is_available() is False



# Generated at 2022-06-23 00:32:13.791226
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():

    class PkgMgrFake():

        def list_packages(self):
            return {}

    class PkgMgrFakeSub(PkgMgrFake):

        def list_packages(self):
            return [ 'PACKAGE' ]

    assert(len(PkgMgr.list_installed()) == 0)
    pkgmgr = PkgMgrFake()
    assert(len(pkgmgr.list_installed()) == 0)
    pkgmgr = PkgMgrFakeSub()
    assert(pkgmgr.list_installed() == ['PACKAGE'])


# Generated at 2022-06-23 00:32:25.485307
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    import sys
    pm = get_all_pkg_managers()
    test_cases = {}
    test_cases['system'] = sys.platform
    if 'system' in test_cases:
        for test_case in test_cases['system'].split():
            for pkg_mgr in pm:
                if test_case == pm[pkg_mgr]().__module__.split('.')[-1]:
                    pkg_details = pm[pkg_mgr]().get_package_details('ansible')
                    if 'name' in pkg_details and 'version' in pkg_details:
                        print("passed test case %s with package manager %s" % (test_case, pkg_mgr))

# Generated at 2022-06-23 00:32:31.886265
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    # Fake class for testing, will be removed later
    class TestCLIMgr(CLIMgr):
        CLI = 'python'

        def list_installed(self):
            return ['python2.7']

        def get_package_details(self, package):
            return {'name': 'python2.7', 'version': '2.7.12', 'source': 'test'}

    test_climgr = TestCLIMgr()
    pkgs = test_climgr.get_packages()
    assert 'python2.7' in pkgs, "Package python2.7 is not found."
    assert pkgs['python2.7'][0]['version'] == '2.7.12', "Package python2.7 version is not 2.7.12."

# Generated at 2022-06-23 00:32:34.674348
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class DummyLibMgr(LibMgr):
        LIB = 'os'

    DummyLibMgr()


# Generated at 2022-06-23 00:32:38.992083
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    # Test case 1:
    # Test description: PkgMgr_get_package_details_1
    # Input:
    # Test Output:
    # Assertion/validation
    # Assertion:
    # cleanup:
    print("get_package_details is an abstractmethod. test_PkgMgr_get_package_details is not implemented")


# Generated at 2022-06-23 00:32:44.553278
# Unit test for constructor of class PkgMgr
def test_PkgMgr():

    with pytest.raises(TypeError) as excinfo:
        pm = PkgMgr()
 
    assert "Can't instantiate abstract class PkgMgr with abstract methods get_package_details, is_available, list_installed" in str(excinfo.value)

# Generated at 2022-06-23 00:32:50.760274
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    """
    Tests get_package_details of class PkgMgr
    """

    class TestPkgMgr(PkgMgr):

        def is_available(self):
            pass

        def list_installed(self):
            pass

        def get_package_details(self, package):
            return package

    tpm = TestPkgMgr()

    assert tpm.get_package_details({'a': 1}) == {'a': 1}


# Generated at 2022-06-23 00:32:51.916873
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pass


# Generated at 2022-06-23 00:32:57.470883
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():

    from ansible.module_utils.common.packages.rpm import RPMMgr
    from ansible.module_utils.common.packages.yumpkg import YumMgr
    from ansible.module_utils.common.packages.apk import ApkMgr
    pkg_managers = get_all_pkg_managers()
    assert pkg_managers == {'rpm': RPMMgr, 'yumpkg': YumMgr, 'apk': ApkMgr}

# Generated at 2022-06-23 00:33:09.634115
# Unit test for method is_available of class PkgMgr

# Generated at 2022-06-23 00:33:11.136945
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    cm = CLIMgr()
    assert (cm.CLI is None)
    assert (cm._cli is None)

# Generated at 2022-06-23 00:33:13.469550
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    # test constructor of PkgMgr class
    obj = PkgMgr()
    return True



# Generated at 2022-06-23 00:33:14.597421
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    pass

# Generated at 2022-06-23 00:33:17.448060
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr() is not None
    assert CLIMgr()._cli is None
    assert CLIMgr().is_available() == False


# Generated at 2022-06-23 00:33:19.072136
# Unit test for constructor of class LibMgr
def test_LibMgr():
    test = LibMgr()
    assert test.LIB is None
    assert test._lib is None


# Generated at 2022-06-23 00:33:24.400329
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    def list_installed(self):
        return ["python-mysql.connector", "docker-engine", "mysql-server"]

    PkgMgr.list_installed = list_installed
    p = PkgMgr()
    assert p.list_installed() == ["python-mysql.connector", "docker-engine", "mysql-server"]


# Generated at 2022-06-23 00:33:29.943596
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():

    dict_test = dict()
    dict_test["name"] = "test"
    dict_test["version"] = "0.0.0.0"
    dict_test["source"] = "test"

    assert PkgMgr.get_package_details("test", dict_test) == dict_test


# Generated at 2022-06-23 00:33:35.373627
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    # The following class is used for testing
    class Test_LibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.collector.system.distribution'

    testObj = Test_LibMgr()

    # Check if an error raises when wrong library name is provided
    testObj.LIB = 'testlib'
    assert testObj.is_available() is False



# Generated at 2022-06-23 00:33:38.007832
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    class PkgMgrTest(PkgMgr):
        def is_available(self):
            return True
    assert PkgMgrTest().is_available() is True


# Generated at 2022-06-23 00:33:40.964510
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    manager = CLIMgr()
    if not manager.is_available():
        print("Invalid CLI: {}".format(CLIMgr.CLI))
        return False
    return True

# Generated at 2022-06-23 00:33:42.920899
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    assert set(['apt', 'yum', 'dnf', 'zypper']).issubset(set(get_all_pkg_managers().keys()))

# Generated at 2022-06-23 00:33:48.134176
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class Foo(LibMgr):
        LIB = 'some_lib'
    # an ImportError should return false
    foo = Foo()
    assert not foo.is_available()

    # an ImportError for the correct library should return true
    class Bar(LibMgr):
        LIB = 'ansible.module_utils.common.package'
    bar = Bar()
    assert bar.is_available()



# Generated at 2022-06-23 00:33:51.109272
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    try:
        PkgMgr()
    except TypeError:
        pass
    else:
        raise AssertionError('Expected `TypeError` to be raised, got no exception ')

# Generated at 2022-06-23 00:33:53.679025
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():

    from ansible.module_utils.facts.packages import get_all_pkg_managers

    assert get_all_pkg_managers()

# Generated at 2022-06-23 00:33:56.290878
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    pmgrs = get_all_pkg_managers()
    for pmgr in pmgrs.values():
        pmgr.get_packages()

# Generated at 2022-06-23 00:34:03.228572
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    package_1 = {'name': 'ansible'}
    package_2 = {'name': 'git'}
    packages = [package_1, package_2]
    pm = PkgMgr()
    pm.get_package_details = lambda x: x
    pm.list_installed = lambda: packages
    packages = pm.get_packages()
    assert packages['ansible'] == [package_1]
    assert packages['git'] == [package_2]

if __name__ == '__main__':
    test_PkgMgr_get_packages()

# Generated at 2022-06-23 00:34:08.441134
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    pkg_managers = get_all_pkg_managers()
    for pkg_manager in pkg_managers.values():
        if isinstance(pkg_manager, CLIMgr):
            assert pkg_manager().is_available()
        else:
            assert not pkg_manager().is_available()



# Generated at 2022-06-23 00:34:09.351853
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    assert PkgMgr()


# Generated at 2022-06-23 00:34:10.777321
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    assert isinstance(PkgMgr(), PkgMgr)



# Generated at 2022-06-23 00:34:12.419512
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pm = PkgMgr()
    assert pm.is_available() is None


# Generated at 2022-06-23 00:34:13.014245
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr()

# Generated at 2022-06-23 00:34:15.719365
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    pkgmgr_object = PkgMgr()
    assert pkgmgr_object.get_package_details('vim') == {}

# Generated at 2022-06-23 00:34:18.446551
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    class foo(PkgMgr):
        pass
    p = foo()
    assert p is not None

# Generated at 2022-06-23 00:34:23.074566
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    plugin_manager = get_all_pkg_managers()
    for pkgmgr_name in plugin_manager:
        if not plugin_manager[pkgmgr_name]().is_available():
            print("%s is not available" % pkgmgr_name)
    pass

# Generated at 2022-06-23 00:34:27.536882
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    '''
    Unit test for method get_package_details of class PkgMgr
    '''
    obj = PkgMgr()
    try:
        obj.get_package_details('mysql-connectors-community-5.5.52-1.linux_glibc2.5.x86_64')
    except NotImplementedError:
        print('get_package_details was not implemented')



# Generated at 2022-06-23 00:34:29.827887
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    c = PkgMgr()
    package = {'name': 'ansible', 'version': '2.6.1', 'source': 'pip', 'release': '2'}
    assert c.get_package_details(package) == package

# Generated at 2022-06-23 00:34:36.295826
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    all = get_all_pkg_managers()
    assert 'apt' in all.keys()
    assert 'yum' in all.keys()
    assert 'dnf' in all.keys()
    assert 'portage' in all.keys()
    assert 'pacman' in all.keys()
    assert 'pip' in all.keys()
    assert 'npm' in all.keys()
    assert 'gem' in all.keys()
    assert 'pkgin' in all.keys()
    assert 'apk' in all.keys()
    assert 'gem' in all.keys()
    assert 'chocolatey' in all.keys()
    assert 'git' in all.keys()
    assert 'freebsd_pkgng' in all.keys()
    assert 'freebsd_portmaster' in all.keys()


# Generated at 2022-06-23 00:34:36.905933
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    pass

# Generated at 2022-06-23 00:34:43.536668
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    with pytest.raises(TypeError) as exec_info:
        PkgMgr()
    assert 'Can\'t instantiate abstract class PkgMgr with abstract methods get_package_details, is_available, list_installed' in str(exec_info.value)
    assert 'test_package_managers.py', exec_info.traceback[-1].filename
    assert 8, exec_info.traceback[-1].lineno

# Generated at 2022-06-23 00:34:49.030595
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    """
    Unit test for method is_available of class CLIMgr

    """
    import os

    class testMgr(CLIMgr):
        CLI = 'test'

    dummy = testMgr()
    assert dummy.is_available() is False
    os.system('touch /bin/test')
    assert dummy.is_available() is True

# Generated at 2022-06-23 00:34:50.605313
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    """
    Check if module 'os' is imported
    """
    from importlib import import_module
    assert import_module('os')


# Generated at 2022-06-23 00:34:52.405181
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    all_pkg_managers = get_all_pkg_managers()
    assert('apt' in all_pkg_managers)
    assert('yum' in all_pkg_managers)

# Generated at 2022-06-23 00:34:54.481806
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    package_manager = PkgMgr()
    assert package_manager


# Generated at 2022-06-23 00:34:57.193489
# Unit test for constructor of class LibMgr
def test_LibMgr():
    try:
        LibMgr()
    except Exception as e:
        assert True, "construction of LibMgr failed with exception {}".format(e)


# Generated at 2022-06-23 00:35:07.176004
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({}, {})
    for pkg_manager in get_all_pkg_managers().values():
        if pkg_manager.__name__ in ('RpmMgr', 'YumMgr', 'DnfMgr'):
            if module.params['platform_family'] != 'rhel':
                continue
        if pkg_manager.__name__ in ('AptMgr', 'DpkgMgr'):
            if module.params['platform_family'] != 'debian':
                continue
        a = pkg_manager()
        try:
            a.is_available()
        except ImportError:
            print('ImportError: ' + pkg_manager.__name__)

# Generated at 2022-06-23 00:35:10.247050
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    l = LibMgr()
    try:
        l._lib = __import__("ansible.module_utils.facts.system.dummy")
    except ImportError:
        pass
    assert l.is_available()



# Generated at 2022-06-23 00:35:12.666502
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():

    result = get_all_pkg_managers()

    assert isinstance(result, dict)
    assert 'cli' in result

# Generated at 2022-06-23 00:35:17.125615
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    package = "a test package"
    pkg_mgr = PkgMgr()
    package_details = pkg_mgr.get_package_details(package)
    assert package_details == {'name': package, 'version': None, 'source': 'pkgmgr'}


# Generated at 2022-06-23 00:35:18.757886
# Unit test for constructor of class LibMgr
def test_LibMgr():
    pass


# Generated at 2022-06-23 00:35:21.699725
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    pkg = PkgMgr()
    assert pkg.get_package_details({"name": "hello"}) == {"name": "hello"}


# Generated at 2022-06-23 00:35:23.740056
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    test = PkgMgr()
    result = test.get_package_details("test")
    assert (result == None)


# Generated at 2022-06-23 00:35:25.079180
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    assert PkgMgr().get_packages() == {}

# Generated at 2022-06-23 00:35:26.530432
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    cli = CLIMgr()
    assert cli.is_available() == False

# Generated at 2022-06-23 00:35:27.927399
# Unit test for constructor of class LibMgr
def test_LibMgr():
    test = LibMgr()
    assert test._lib is None


# Generated at 2022-06-23 00:35:28.949831
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pass


# Generated at 2022-06-23 00:35:38.004488
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
  from mock import Mock, patch
  from collections import namedtuple
  m = Mock
  l = namedtuple('l', ['name', 'version', 'source'])
  Package = namedtuple('Package', ['name', 'version'])
  p = Package
  expected_package_dict = {'pkg1': [l(name='pkg1', version='2.0', source='apt')]}

  with patch.object(PkgMgr, 'list_installed', return_value=['pkg1']):
    with patch.object(PkgMgr, 'get_package_details', return_value=p('pkg1', '2.0')):
      mgr = PkgMgr()
      assert expected_package_dict == mgr.get_packages()

if __name__ == '__main__':
  test_PkgM

# Generated at 2022-06-23 00:35:47.755212
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    test = PkgMgr()
    # test if PkgMgr class exists
    assert test
    # test if the method is_available is abstract and raises exception
    try:
        test.is_available()
        # If is_available is not abstract, hence it will not raise exception then it will be False
        assert False
    except NotImplementedError:
        # If is_available is abstract, hence it will raise exception then it will be True
        assert True
    except Exception as e:
        # If is_available is abstract but still raise exception
        assert False, e
    # test if the method list_installed is abstract and raises exception

# Generated at 2022-06-23 00:35:50.155511
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pkgmgr = PkgMgr()
    res = pkgmgr.is_available()
    assert res is False


# Generated at 2022-06-23 00:35:51.660446
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    assert ( PkgMgr().is_available()==None )


# Generated at 2022-06-23 00:35:53.736403
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    test = PkgMgr()
    assert isinstance(test.is_available(), bool)


# Generated at 2022-06-23 00:35:56.149831
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    try:
        import pip
        assert LibMgr.is_available() == True
    except ImportError:
        assert LibMgr.is_available() == False


# Generated at 2022-06-23 00:35:57.581228
# Unit test for constructor of class LibMgr
def test_LibMgr():
    assert LibMgr

# Generated at 2022-06-23 00:36:07.429459
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class DummyPkgMgr(PkgMgr):
        def is_available(self):
            pass

        def list_installed(self):
            pass

        def get_package_details(self, package):
            pass

    dummy_mgr = DummyPkgMgr()
    # Test with valid params
    assert dummy_mgr.get_package_details(package={'name': 'ansible', 'version': '2.5.1'}) == {'name': 'ansible', 'version': '2.5.1', 'source': 'DummyPkgMgr'}


# Generated at 2022-06-23 00:36:08.589081
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    pass # FIXME


# Generated at 2022-06-23 00:36:10.628288
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    Mgr = CLIMgr()
    assert not Mgr.is_available()


# Generated at 2022-06-23 00:36:12.717928
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr()


# Generated at 2022-06-23 00:36:14.173377
# Unit test for constructor of class LibMgr
def test_LibMgr():
    assert get_all_pkg_managers()


# Generated at 2022-06-23 00:36:16.872507
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():

    for obj in get_all_subclasses(PkgMgr):
        assert obj().is_available() == True


# Generated at 2022-06-23 00:36:18.840393
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    pkgmgr = CLIMgr()
    pkgmgr._cli = None
    pkgmgr.__init__()
    assert pkgmgr is not None

# Generated at 2022-06-23 00:36:23.524390
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():

    assert set(get_all_pkg_managers().keys()) == set([
        'aptpkg',
        'dnfpkg',
        'eopkg',
        'pacmanpkg',
        'portagepkg',
        'swappkg',
        'yumpkg'
    ])

# Generated at 2022-06-23 00:36:24.132656
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    assert True

# Generated at 2022-06-23 00:36:28.613427
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    for obj in get_all_subclasses(PkgMgr):
        if obj not in (CLIMgr, LibMgr):
            pm = obj()
            result = pm.is_available()
            assert(isinstance(result, bool))


# Generated at 2022-06-23 00:36:31.796517
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    class testPkgMgr(PkgMgr):
        pass

    test_instance = testPkgMgr()
    assert isinstance(test_instance, PkgMgr)


# Generated at 2022-06-23 00:36:42.940568
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    assert isinstance(get_all_pkg_managers(), dict)

# Generated at 2022-06-23 00:36:47.909432
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    pkg_mgrs = get_all_pkg_managers()
    assert(len(pkg_mgrs) > 0)
    assert('aptpkgmgr' in pkg_mgrs)
    assert('yumpkgmgr' in pkg_mgrs)

# Generated at 2022-06-23 00:36:57.679168
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    import os
    import sys
    import unittest

    try:
        from unittest.mock import MagicMock, patch
    except ImportError:
        from mock import MagicMock, patch

    sys.path.append(os.path.join('lib', 'ansible', 'modules', 'system', 'packaging'))
    # Should not move this import ahead of previous sys.path.append, else it will import a wrong module.
    from package_facts import PkgMgr

    class MockPkgMgr(PkgMgr):
        def __init__(self):
            super(MockPkgMgr, self).__init__()

        def is_available(self):
            return True

        def list_installed(self):
            return ['package1', 'package2']


# Generated at 2022-06-23 00:37:07.278307
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    pkg_mgr = get_all_pkg_managers()
    assert 'apt' in pkg_mgr
    assert 'apk' in pkg_mgr
    assert 'pkgin' in pkg_mgr
    assert 'dnf' in pkg_mgr
    assert 'yum' in pkg_mgr
    assert 'zypper' in pkg_mgr
    assert 'packagekit' in pkg_mgr
    assert 'portage' in pkg_mgr
    assert 'pip' in pkg_mgr
    assert 'gem' in pkg_mgr
    assert 'rpm' in pkg_mgr
    assert 'pkg5' in pkg_mgr