

# Generated at 2022-06-23 00:27:09.447884
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    """Test if method list_installed is abstract in base class."""
    import abc
    assert issubclass(PkgMgr, abc.ABCMeta)
    assert isinstance(PkgMgr.list_installed, abc.abstractmethod)

# Generated at 2022-06-23 00:27:11.207471
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    cli = PkgMgr()
    assert cli.is_available() == False

# Generated at 2022-06-23 00:27:18.084534
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    # test_PkgMgr_get_package_details()
    class PkgMgr_test(PkgMgr):
        def list_installed(self):
            pass
        def get_package_details(self, package):
            pass
    pkgmgr_test = PkgMgr_test()
    assert (type(pkgmgr_test).__name__ == 'PkgMgr_test')


# Generated at 2022-06-23 00:27:23.430522
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    from ansible.module_utils.facts.system.pkg_mgrs import DpkgMgr
    dpkg_mgr = DpkgMgr()
    pkgs = dpkg_mgr.get_packages()
    assert 'python-apt' in pkgs  # verify that at least one package is present from the system


# Generated at 2022-06-23 00:27:32.871921
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    ret = get_all_pkg_managers()
    assert ret

    try:
        import yum
    except ImportError:
        assert "yum" not in ret

    try:
        import dnf
    except ImportError:
        assert "dnf" not in ret

    try:
        import apt
    except ImportError:
        assert "apt" not in ret

    try:
        import zypper
    except ImportError:
        assert "zypper" not in ret

    try:
        import urpmi
    except ImportError:
        assert "urpmi" not in ret

    try:
        import pacman
    except ImportError:
        assert "pacman" not in ret

    try:
        import portage
    except ImportError:
        assert "portage" not in ret


# Generated at 2022-06-23 00:27:35.420918
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    cli = CLIMgr()
    assert cli._cli is None

# Test of method is_available of class CLIMgr

# Generated at 2022-06-23 00:27:45.984015
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    class TestPkgMgr(PkgMgr):

        def list_installed(self):
            return ['foo', 'foo', 'bar']

        def get_package_details(self, package):
            return {'name': package, 'version': '1.0.0'}

    pkg_mgr = TestPkgMgr()
    packages = pkg_mgr.get_packages()

    assert 'foo' in packages
    assert 'bar' in packages
    assert len(packages['foo']) == 2
    assert len(packages['bar']) == 1

    for pkg in packages['foo']:
        assert pkg['name'] == 'foo'
        assert pkg['version'] == '1.0.0'
        assert pkg['source'] == 'testpkgmgr'

# Generated at 2022-06-23 00:27:49.575946
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    class D_PkgMgr(PkgMgr):
        def is_available(self):
            return True
    # Test is_available
    d_pkg_mgr = D_PkgMgr()
    assert d_pkg_mgr.is_available() is True

# Generated at 2022-06-23 00:27:53.100785
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    pkg_mgr = LibMgr()
    pkg_mgr.LIB = 'pip'
    assert pkg_mgr.is_available()
    # clean up
    pkg_mgr._lib = None


# Generated at 2022-06-23 00:27:54.133049
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    pass


# Generated at 2022-06-23 00:27:55.977383
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    pkg_mgr = PkgMgr()
    print(pkg_mgr)
    assert True


# Generated at 2022-06-23 00:27:57.479509
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    assert PkgMgr.is_available() == False


# Generated at 2022-06-23 00:28:03.906526
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    # Test normal constructor
    cm = CLIMgr()
    assert isinstance(cm, object)
    assert isinstance(cm, PkgMgr)
    assert cm._cli is None
    assert cm.CLI is None

    # Test constructor with a CLI parameter provided
    cm = CLIMgr('CLI')
    assert cm._cli is None
    assert cm.CLI is 'CLI'


# Generated at 2022-06-23 00:28:05.001909
# Unit test for constructor of class LibMgr
def test_LibMgr():
    assert LibMgr().LIB is None


# Generated at 2022-06-23 00:28:14.431893
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class PkgMgrTest(PkgMgr):
        pass
    class BadPkgMgrTest(PkgMgr):
        def get_package_details(self, package):
            return "test"
    class GoodPkgMgrTest(PkgMgr):
        def get_package_details(self, package):
            return {"test": "test"}

    t = PkgMgrTest()
    try:
        t.get_package_details({"test": "test"})
    except NotImplementedError:
        pass
    except Exception as e:
        raise AssertionError("PkgMgr.get_package_details() returned: %s (expecting NotImplementedError)" % e)

    t = BadPkgMgrTest()

# Generated at 2022-06-23 00:28:22.990292
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    class TestPkgMgr(PkgMgr):

        def is_available(self):
            return True

        def list_installed(self):
            return [{"name": "test", "version": "1.0"}]

        def get_package_details(self, package):
            return {"name": package["name"], "version": package["version"]}

    tpm = TestPkgMgr()

    assert len(tpm.get_packages()) == 1
    assert tpm.get_packages() == {"test": [{"name": "test", "version": "1.0", "source": "testpkgmgr"}]}

# Generated at 2022-06-23 00:28:27.103969
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    
    class test_pkg(PkgMgr):
        def list_installed(self):
            self.installed = True
            return None

    pkg = test_pkg()
    assert pkg.list_installed() == None


# Generated at 2022-06-23 00:28:28.296056
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    #  Call CLIMgr class constructor
    CLIMgr()

# Generated at 2022-06-23 00:28:36.992214
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['package1','package2','package3']
        def get_package_details(self, package):
            return {'name': 'name' + package[-1]}
    packages = TestPkgMgr().get_packages()
    assert 3 == len(packages)
    for package in packages:
        assert 1 == len(packages[package])
    assert packages['name1'][0]['name'] == 'name1'

# Generated at 2022-06-23 00:28:43.455111
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():

    p = PkgMgr()
    package_details = p.get_package_details('neutron-fwaas_1.5.0-2_all.deb')
    assert package_details['name'] == 'neutron-fwaas'
    assert package_details['version'] == '1.5.0-2'
    assert package_details['release'] == 'all'
    assert package_details['arch'] == 'deb'
    assert package_details['source'] == 'pkgmgr'


# Generated at 2022-06-23 00:28:48.109497
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestManager(CLIMgr):
        CLI = 'ls'

    test_manager = TestManager()
    if test_manager.is_available():
        print("Success")
    else:
        print("Failed")

# test_CLIMgr_is_available()



# Generated at 2022-06-23 00:28:53.607234
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    class PkgMgrTest(PkgMgr):

        LIB = None
        CLI = None

        def list_installed(self):
            pass

        def get_package_details(self, package):
            pass

    # Test creation of the class PkgMgrTest
    pmt = PkgMgrTest()


# Generated at 2022-06-23 00:29:01.146411
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    import pytest
    import sys
    import os
    import tempfile

    # Mock a python module
    testmodule = "testmodulename"
    with tempfile.NamedTemporaryFile(mode='w', dir=tempfile.gettempdir(), delete=False) as fp:
        fp.write("import sys\n")
        fp.write("x = 'testmodule'\n")

    # Ensure testmodule isn't in sys.path
    sys.path_orig = list(sys.path)
    sys.path = [path for path in sys.path if path != os.path.dirname(fp.name)]
    # Ensure the testmodule isn't in sys.modules
    # (this is required for the mock to work)
    sys.modules.pop(testmodule)


# Generated at 2022-06-23 00:29:08.667702
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    from ansible.module_utils.common.packages import PkgMgr
    from ansible.module_utils.common.packages import RPM, DPKG

    pkgMgr = PkgMgr()
    rpm = RPM()
    dpkg = DPKG()
    assert rpm.list_installed()
    assert dpkg.list_installed()
    try:
        pkgMgr.list_installed()
    except NotImplementedError:
        pass



# Generated at 2022-06-23 00:29:19.577593
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True

        def list_installed(self):
            return ['testpkg']

        def get_package_details(self, package):
            return {'name': package, 'version': '0.0.0-r0'}

    pm = TestPkgMgr()
    pkg = pm.get_packages()
    assert pkg is not None
    assert len(pkg) == 1
    assert 'testpkg' in pkg
    assert len(pkg['testpkg']) == 1
    assert pkg['testpkg'][0]['name'] == 'testpkg'
    assert pkg['testpkg'][0]['version'] == '0.0.0-r0'


# Generated at 2022-06-23 00:29:28.196410
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    import tempfile
    import shutil
    import os
    import json
    import sys

    class PkgMgrTest(PkgMgr):
        def is_available(self):
                return True

        def list_installed(self):
            # This returns a list of two names
            return ["pkg1", "pkg2"]

        def get_package_details(self, package):
            # For this test we return the same info for both package 1 and 2
            return {"name": "pkg1", "version": "1"}

    # Create a temporary directory
    tmp_dir = tempfile.mkdtemp()

    # Create a temporary file
    temp_file = os.path.join(tmp_dir, "test_PkgMgr_get_packages.tmp")

    # Copy all modules to temp directory
    module_directory = os.path

# Generated at 2022-06-23 00:29:34.869199
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    class DummyPkgMgr(PkgMgr):
        def __init__(self):
            super(DummyPkgMgr, self).__init__()
        def is_available(self):
            return True
        def list_installed(self):
            return [1, 2, 3]
        def get_package_details(self):
            return {}
    p = DummyPkgMgr()
    assert p.list_installed() == [1, 2, 3]


# Generated at 2022-06-23 00:29:38.975447
# Unit test for constructor of class LibMgr
def test_LibMgr():

    mgr = LibMgr()
    assert mgr.is_available() == False

# Generated at 2022-06-23 00:29:41.069525
# Unit test for constructor of class LibMgr
def test_LibMgr():
    l = LibMgr()
    assert isinstance(l, LibMgr)

# Generated at 2022-06-23 00:29:42.121141
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pass


# Generated at 2022-06-23 00:29:53.200127
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.facts.system.pkg_mgr import Yum, Apt, Pacman

    """
    In order to run this test, install epel-release package (for Fedora and RHEL).
    For Fedora, also install sudo and policycoreutils-python-utils.
    """
    yum_available = False
    apt_available = False
    pacman_available = False
    try:
        get_bin_path('yum')
        get_bin_path('rpm')
        yum_available = True
    except ValueError:
        pass
    try:
        get_bin_path('apt-get')
        apt_available = True
    except ValueError:
        pass

# Generated at 2022-06-23 00:29:55.527729
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    class TestCLI(CLIMgr):
        # CLI = "abcd"
        pass

    test_cli = TestCLI()
    assert 'None' == test_cli._cli

# Unit test

# Generated at 2022-06-23 00:29:56.762172
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pkgmgr = PkgMgr()
    assert pkgmgr.list_installed() == None


# Generated at 2022-06-23 00:29:57.404342
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr()



# Generated at 2022-06-23 00:30:03.507964
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():

    import ansible.module_utils.common.collectors.pkg_managers.rpm
    import ansible.module_utils.common.collectors.pkg_managers.pacman
    rpm = ansible.module_utils.common.collectors.pkg_managers.rpm.RPM()
    pacman = ansible.module_utils.common.collectors.pkg_managers.pacman.Pacman()

    assert rpm.is_available() == True
    assert pacman.is_available() == True


# Generated at 2022-06-23 00:30:04.785454
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    assert LibMgr().is_available() == False


# Generated at 2022-06-23 00:30:08.589255
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestLibMgr(LibMgr):
        LIB = 'test_lib'
    lm = TestLibMgr()
    assert lm.__class__.__name__ == 'TestLibMgr'


# Generated at 2022-06-23 00:30:09.982443
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
  assert CLIMgr().is_available() == False


# Generated at 2022-06-23 00:30:15.211860
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    import pytest


    class PkgMgrImpl(PkgMgr):
        def is_available(self):
            return True


        def list_installed(self):
            pass


        def get_package_details(self, package):
            pass


    assert PkgMgrImpl().is_available()



# Generated at 2022-06-23 00:30:16.958485
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    pkg_mgr = PkgMgr()
    assert pkg_mgr is not None


# Generated at 2022-06-23 00:30:27.851089
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    uninstalled_package_a = {
        # Test uninstalled package
        "package": "test_pkg_A",
        "status": "uninstalled"
    }
    installed_package_a = {
        # Test installed package
        "package": "test_pkg_B",
        "status": "installed",
        "version": "6.3"
    }
    uninstalled_package_c = {
        # Test uninstalled package
        "package": "test_pkg_C",
        "status": "uninstalled"
    }
    installed_package_c = {
        # Test installed package
        "package": "test_pkg_C",
        "status": "installed",
        "version": "6.3"
    }

# Generated at 2022-06-23 00:30:32.362726
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCLIMgr(CLIMgr):
        CLI = 'test_CLI'
    test_CLIMgr = TestCLIMgr()
    test_CLIMgr._cli = 'nothing'
    assert not test_CLIMgr.is_available()

    def get_bin_path(CLI):
        return 'something'
    test_CLIMgr._cli = 'something'
    assert test_CLIMgr.is_available()

# Generated at 2022-06-23 00:30:33.899578
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    cm = CLIMgr()
    assert cm is not None

# Generated at 2022-06-23 00:30:45.023547
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    class mock_PkgMgr(PkgMgr):
        def list_installed(self):
            return ['mockPkgMgr.list_installed.dummy_package']
        def get_package_details(self, package):
            return dict(name='mockPkgMgr.get_package_details.dummy_package_name')
    mock_PkgMgr = mock_PkgMgr()
    mock_PkgMgr.is_available = lambda: True
    mock_PkgMgr.get_package_details = lambda x: getattr(mock_PkgMgr, 'get_package_details')(x)
    result = mock_PkgMgr.get_packages()

# Generated at 2022-06-23 00:30:46.960791
# Unit test for constructor of class LibMgr
def test_LibMgr():
    try:
        a = LibMgr()
    except:
        return False
    return True


# Generated at 2022-06-23 00:30:48.681306
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    test_obj = PkgMgr()
    assert test_obj is not None


# Generated at 2022-06-23 00:30:51.771416
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pkgManager = PkgMgr()
    assert pkgManager.list_installed() == []


# Generated at 2022-06-23 00:30:56.413056
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    manager = PkgMgr()
    try:
        result = manager.get_package_details('foo')
    except NotImplementedError:
        result = None
    assert result is None, 'PkgMgr.get_package_details() did not raise error'



# Generated at 2022-06-23 00:31:07.827163
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    from mock import Mock, patch
    from ansible.module_utils.pycompat24 import get_exception

    class CLIMgrTest(CLIMgr):
        def __init__(self):
            CLIMgr.__init__(self)

        def is_available(self):
            return CLIMgr.is_available(self)

    with patch.object(CLIMgrTest, 'CLI') as mock_cli:
        with patch.object(get_bin_path, 'get_bin_path') as get_bin_path_mock:
            c = CLIMgrTest()

            mock_cli = 'mock_cli'

            get_bin_path_mock.side_effect = get_exception(False)

            assert c.is_available() == False

            get_bin_path_mock.side_

# Generated at 2022-06-23 00:31:15.350649
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    import unittest
    import ansible.module_utils.common._utils as utils
    from ansible.module_utils.common._utils import get_all_subclasses

    class PkgMgrTest(PkgMgr):

        def is_available(self):
            pass

        def list_installed(self):
            pass

        def get_package_details(self, package):
            pass

    class SubClassTest(PkgMgrTest):
        pass
    assert utils.get_all_subclasses(PkgMgrTest) == [SubClassTest]


# Generated at 2022-06-23 00:31:23.877369
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    # Test case: When the CLI of a package manager is not found.
    # The function should return False
    class TestClass(CLIMgr):
        CLI = 'NotExists'

    test_obj = TestClass()
    assert test_obj.is_available() == False

    # Test case: When the CLI of a package manager is found.
    # The function should return True
    class TestClass(CLIMgr):
        CLI = 'python'

    test_obj = TestClass()
    assert test_obj.is_available() == True

# Generated at 2022-06-23 00:31:34.897884
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    # Test the module by creating a class that inherits the abstract class PkgMgr
    # We first use a class name that starts with "Test" to test the functionality of get_all_pkg_managers()
    # and then we use a class name that does not start with "Test" to test the functionality of is_available()
    class TestCLIMgr(CLIMgr):
        CLI = '???BLABLA???'

    assert test_class.TestCLIMgr.__name__.lower() not in get_all_pkg_managers()

    class TestCLIMgr(CLIMgr):
        CLI = 'echo'

    assert test_class.TestCLIMgr.__name__.lower() in get_all_pkg_managers()

# Generated at 2022-06-23 00:31:36.690286
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    pkg_type = CLIMgr()
    assert pkg_type == pkg_type

# Generated at 2022-06-23 00:31:38.693863
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    pkgmgr = PkgMgr()
    assert pkgmgr is not None


# Generated at 2022-06-23 00:31:40.114476
# Unit test for constructor of class LibMgr
def test_LibMgr():
    test = LibMgr()
    assert test is not None


# Generated at 2022-06-23 00:31:41.467363
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    pass


# Generated at 2022-06-23 00:31:43.229741
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    assert False, "Test not implemented"


# Generated at 2022-06-23 00:31:46.680060
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    test_dict = get_all_pkg_managers()
    for key, value in test_dict.items():
        if 'pkg_mgr' in key:
            assert issubclass(value, PkgMgr)

# Generated at 2022-06-23 00:31:48.922347
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    nos = CLIMgr()
    nos.CLI = 'nos'
    assert nos.CLI == 'nos'

# Generated at 2022-06-23 00:31:50.830290
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    assert PkgMgr.get_package_details('a') == NotImplemented


# Generated at 2022-06-23 00:31:52.384121
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class MockLibMgr(LibMgr):
        LIB = None

    mock_obj = MockLibMgr()
    assert isinstance(mock_obj, PkgMgr)


# Generated at 2022-06-23 00:31:54.044885
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    assert(PkgMgr() != None)

# Generated at 2022-06-23 00:31:55.634992
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    x = PkgMgr()
    assert x

# Generated at 2022-06-23 00:32:00.398504
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    # Instance of class PkgMgr
    t_pkgmgr = PkgMgr()

    # Raise exception as method needs to be implemented in subclasses
    try:
        t_pkgmgr.get_package_details("test")
    except NotImplementedError:
        pass
    else:
        assert False

# Generated at 2022-06-23 00:32:01.377764
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    pkg = PkgMgr()


# Generated at 2022-06-23 00:32:12.810636
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    from ansible_collections.misc.not_a_real_collection.plugins.module_utils.package.package_manager import CLIMgr
    from ansible_collections.misc.not_a_real_collection.plugins.module_utils.package.package_manager import get_all_pkg_managers
    import mock

    gem = get_all_pkg_managers()['gem']()
    assert isinstance(gem, CLIMgr)

    mock_get_bin_path = mock.Mock(return_value='/usr/bin/gem')
    with mock.patch('ansible_collections.misc.not_a_real_collection.plugins.module_utils.package.package_manager.get_bin_path', mock_get_bin_path):
        assert gem.is_available() is True

    mock_get_bin_

# Generated at 2022-06-23 00:32:14.390767
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    p = PkgMgr()

# Unit tests for constructor and is_available of class LibMgr

# Generated at 2022-06-23 00:32:14.984541
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pass

# Generated at 2022-06-23 00:32:24.499212
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    # Create a concrete implementation of PkgMgr and override get_package_details with a dummy implementation to test
    class PkgMgrTest(PkgMgr):
        def get_package_details(self, package):
            return {'name': 'test-package', 'version': '1.0'}

    pkgmgr_test_obj = PkgMgrTest()

    # Test get_package_details of class PkgMgr
    assert pkgmgr_test_obj.get_package_details('pkg1') == {'name': 'test-package', 'version': '1.0'}



# Generated at 2022-06-23 00:32:33.245500
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    assert 'is_available' in dir(PkgMgr)
    assert 'is_available' in dir(PkgMgr())
    assert 'list_installed' in dir(PkgMgr)
    assert 'list_installed' in dir(PkgMgr())
    assert 'get_package_details' in dir(PkgMgr)
    assert 'get_package_details' in dir(PkgMgr())
    assert 'get_packages' in dir(PkgMgr)
    assert 'get_packages' in dir(PkgMgr())
    assert 'name' in dir(PkgMgr)

# Generated at 2022-06-23 00:32:41.174689
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    
    class DummyPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['packA', 'packB', 'packC']
        def get_package_details(self, package):
            return {'name': package, 'version': '1'}

    dummy_pkg_mgr = DummyPkgMgr()
    result = dummy_pkg_mgr.get_packages()


# Generated at 2022-06-23 00:32:45.668148
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class ExampleCLIMgr(CLIMgr):
        CLI = "ls"
    ex_mgr = ExampleCLIMgr()
    print(ex_mgr.is_available())
    assert ex_mgr.is_available() == True



# Generated at 2022-06-23 00:32:46.579131
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    assert len(get_all_pkg_managers()) > 0

# Generated at 2022-06-23 00:32:53.571056
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    class PkgMgrTest(PkgMgr):
        installed_packages = ['pkg1', 'pkg2']

        def is_available(self):
            pass

        def list_installed(self):
            return self.installed_packages

        def get_package_details(self, package):
            return {}

    pkg_mgr = PkgMgrTest()
    assert pkg_mgr.list_installed() == ['pkg1', 'pkg2']

# Generated at 2022-06-23 00:32:55.927614
# Unit test for constructor of class LibMgr
def test_LibMgr():
    libmgr = LibMgr()
    print(libmgr)
    print(libmgr.is_available())
    return 0


# Generated at 2022-06-23 00:33:07.901888
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class MockPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['foo', 'bar', 'baz']
        def get_package_details(self, package):
            if package == 'foo':
                return {'name': 'foo', 'version': 1}
            elif package == 'bar':
                return {'name': 'bar', 'version': 2}
            elif package == 'baz':
                return {'name': 'baz', 'version': 1}
            else:
                assert False, "unexpected package"
    res = MockPkgMgr().get_packages()
    assert isinstance(res, dict), "get_packages returned a non-dict"

# Generated at 2022-06-23 00:33:11.573029
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['pkg1', 'pkg2']
        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}

    pkgmgr = TestPkgMgr()
    pkgs = pkgmgr.get_packages()
    assert len(pkgs) == 2
    assert len(pkgs['pkg1']) == 1
    assert len(pkgs['pkg2']) == 1
    assert pkgs['pkg1'][0]['version'] == '1.0'

# Generated at 2022-06-23 00:33:13.551685
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    # Just test if it works or fails
    all_pkg_managers = get_all_pkg_managers()

# Generated at 2022-06-23 00:33:15.484398
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    assert CLIMgr.is_available(PkgMgr) == True


# Generated at 2022-06-23 00:33:17.209562
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pass


# Generated at 2022-06-23 00:33:21.791300
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    class PkgMgr_instance(PkgMgr):

        @abstractmethod
        def list_installed(self):
            pass

    result = PkgMgr_instance().list_installed()

    # Assert type of result
    assert(isinstance(result, list))


# Generated at 2022-06-23 00:33:33.138617
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class PkgMgr_test(PkgMgr):
        def __init__(self):
            super(PkgMgr_test, self).__init__()

        def is_available(self):
            return True

        def list_installed(self):
            return ['package1', 'package2', 'package3']

        def get_package_details(self, package):
            if package == 'package1':
                return {'name': 'test_package1', 'version': '1.0.0'}
            if package == 'package2':
                return {'name': 'test_package1', 'version': '2.0.0'}
            if package == 'package3':
                return {'name': 'test_package2', 'version': '1.0.0'}

    pkgmgr = PkgM

# Generated at 2022-06-23 00:33:34.751767
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    pkgMgr = PkgMgr()
    assert pkgMgr.get_packages() == {}

# Generated at 2022-06-23 00:33:35.961374
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    assert False, "Test not implemented"

# Generated at 2022-06-23 00:33:38.241755
# Unit test for constructor of class LibMgr
def test_LibMgr():
    libmgr = LibMgr()
    assert libmgr.LIB is None
    assert libmgr._lib is None


# Generated at 2022-06-23 00:33:40.005367
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    test = CLIMgr()
    test.CLI = 'apt-get'
    assert test.is_available()

# Generated at 2022-06-23 00:33:42.007586
# Unit test for constructor of class LibMgr
def test_LibMgr():
    l = LibMgr()
    l._lib = ''
    assert l._lib == ''


# Generated at 2022-06-23 00:33:42.920757
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    obj = PkgMgr()


# Generated at 2022-06-23 00:33:45.491072
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    for pkgmgr in get_all_pkg_managers().values():
        if isinstance(pkgmgr, LibMgr):
            assert pkgmgr.is_available()

# Generated at 2022-06-23 00:33:57.328031
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgr, CLIMgr, LibMgr, get_all_pkg_managers
    all_pkgs = get_all_pkg_managers()
    # Test class PkgMgr
    pkgs = PkgMgr()
    assert pkgs.is_available() == True
    # Test class CLIMgr
    pkgs = CLIMgr()
    assert pkgs.is_available() == True
    # Test class LibMgr
    pkgs = LibMgr()
    assert pkgs.is_available() == True
    # Test method is_available of class CLIMgr
    pkgs = all_pkgs['yumpkg']
   

# Generated at 2022-06-23 00:33:59.208743
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    for obj in get_all_subclasses(PkgMgr):
        assert obj().is_available() == True

# Generated at 2022-06-23 00:34:01.051038
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    pm = PkgMgr()
    assert pm is not None

# Generated at 2022-06-23 00:34:05.681838
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pm = PkgMgr()
    # This is expected to fail
    try:
        pm.list_installed()
    except NotImplementedError:
        pass
    else:
        raise AssertionError("This function is not yet implemented, it shouldn't pass here.")


# Generated at 2022-06-23 00:34:16.298740
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():

    class TestPkgMgr(PkgMgr):

        def is_available(self):
            pass

        def list_installed(self):
            pass

        def get_package_details(self, package):
            pass

    tpm = TestPkgMgr()

    package = {"name": "foo", "version": "1.2.3", "source": "bar"}
    assert tpm.get_package_details(package) == {"name": "foo",
                                                "source": "bar",
                                                "version": "1.2.3"}
    package = {"name": "foo", "version": "1.2.3"}

# Generated at 2022-06-23 00:34:23.739974
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    # Initialize the class
    lm = LibMgr()
    # Run the method
    result = lm.is_available()
    # Check if the result is correct or not
    assert result == False
    # Initialize the class, overriding the LIB variable
    lm = LibMgr()
    lm.LIB = 'os'
    # Run the method
    result = lm.is_available()
    # Check if the result is correct or not
    assert result == True


# Generated at 2022-06-23 00:34:25.192819
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    cliMgr = CLIMgr()
    assert cliMgr != None

# Generated at 2022-06-23 00:34:28.145313
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class DummyLibMgr(LibMgr):
        LIB = 'os.path'

    dlm = DummyLibMgr()

    assert dlm.is_available() == True


# Generated at 2022-06-23 00:34:29.127940
# Unit test for constructor of class LibMgr
def test_LibMgr():
    l = LibMgr()
    assert l._lib is None



# Generated at 2022-06-23 00:34:32.046768
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():

    class TestMgr(CLIMgr):
        CLI = 'echo'

    mgr = TestMgr()
    assert mgr.is_available() is True
    assert mgr._cli == 'echo'


# Generated at 2022-06-23 00:34:33.546836
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    assert(PkgMgr.get_package_details is PkgMgr.get_package_details)


# Generated at 2022-06-23 00:34:35.248135
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    expected_CLI = None
    assert CLIMgr().CLI == expected_CLI


# Generated at 2022-06-23 00:34:37.269144
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    mgrs = get_all_pkg_managers()

    assert isinstance(mgrs, dict)
    assert len(mgrs) >= 4

# Generated at 2022-06-23 00:34:44.129417
# Unit test for constructor of class LibMgr
def test_LibMgr():
    # No lib name provided
    mylibmgr = LibMgr()
    assert mylibmgr._lib == None
    # No available lib
    assert not mylibmgr.is_available()
    # Available lib
    class my_lib_class():
        pass
    mylibmgr.LIB = 'my_lib_class'
    assert mylibmgr.is_available()
    assert isinstance(mylibmgr._lib, my_lib_class)


# Generated at 2022-06-23 00:34:47.338340
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():

    test_class_is_available_exception = LibMgr()
    assert not test_class_is_available_exception.is_available()


# Generated at 2022-06-23 00:34:50.337950
# Unit test for constructor of class CLIMgr
def test_CLIMgr():

    class DummyCLIMgr(CLIMgr):

        CLI = 'hello_cli'

    dummy_obj = DummyCLIMgr()
    assert dummy_obj._cli is None

# Generated at 2022-06-23 00:34:51.821966
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    p = PkgMgr()
    assert p


# Generated at 2022-06-23 00:34:52.809879
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert(CLIMgr())

# Generated at 2022-06-23 00:35:03.021053
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    from ansible.module_utils.common._collections_compat import Sequence

    @with_metaclass(ABCMeta, PkgMgr)
    class testPkgMgr(PkgMgr):

        def __init__(self):
            self.installed_packages = set()
            super(testPkgMgr, self).__init__()

        def is_available(self):
            return True

        def list_installed(self):
            return self.installed_packages

        def get_package_details(self, package):
            return package

    pm = testPkgMgr()

    # Test with no packages at all installed
    res = pm.get_packages()
    assert isinstance(res, dict), "Result of get_packages should be a dictionary"

# Generated at 2022-06-23 00:35:04.846277
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    assert PkgMgr().is_available() == NotImplemented


# Generated at 2022-06-23 00:35:08.071435
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    deps = get_all_pkg_managers()
    lm = deps['dnf']()
    lm.is_available()



# Generated at 2022-06-23 00:35:11.295894
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    # test for valid constructor for class CLIMgr
    c = CLIMgr()
    assert c.CLI is None
    assert c._cli is None

# Test for constructor of class PkgMgr

# Generated at 2022-06-23 00:35:13.234707
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    mgr = LibMgr()
    assert mgr.is_available() is False


# Generated at 2022-06-23 00:35:22.868132
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    from ansible.module_utils.basic import AnsibleModule as Module

    params = {
        'installed': {
            'foo': [
                {
                    'n': 'foo',
                    'v': '1.0',
                    's': 'AptPkgManager'
                },
                {
                    'n': 'foo',
                    'v': '2.0',
                    's': 'AptPkgManager'
                }
            ],
            'bar': [
                {
                    'n': 'bar',
                    'v': '1.0',
                    's': 'AptPkgManager'
                },
            ]
        }
    }


# Generated at 2022-06-23 00:35:29.796688
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    all_pkgs = get_all_pkg_managers()
    assert(all_pkgs['apt'].__name__ == 'Apt')
    assert(all_pkgs['yum'].__name__ == 'Yum')
    assert(all_pkgs['dnf'].__name__ == 'Dnf')
    assert(all_pkgs['zypper'].__name__ == 'Zypper')
    assert(all_pkgs['portage'].__name__ == 'Portage')
    assert(all_pkgs['pkgng'].__name__ == 'Pkgng')

# Generated at 2022-06-23 00:35:33.724928
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
        for obj in get_all_subclasses(PkgMgr):
            if obj.__name__ == "PkgMgr":
                continue
            print(obj.__name__)
            p = obj()
            p.is_available()
            p.list_installed()


# Generated at 2022-06-23 00:35:45.298773
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    # This function should return a dict of all available pkg managers

    # pylint: disable=unused-variable
    class PkgMgr1(PkgMgr):
        def is_available(self):
            return True

        def list_installed(self):
            return []

        def get_package_details(self, package):
            return {}

    class PkgMgr2(PkgMgr):
        def is_available(self):
            return True

        def list_installed(self):
            return []

        def get_package_details(self, package):
            return {}

    class PkgMgr3(PkgMgr):
        def is_available(self):
            return False

        def list_installed(self):
            return []

        def get_package_details(self, package):
            return {}



# Generated at 2022-06-23 00:35:46.325383
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr()._cli is None

# Generated at 2022-06-23 00:35:47.706384
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    pkgmgr = CLIMgr()



# Generated at 2022-06-23 00:35:57.528991
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    # This method should return a dictionary of lists of dictionaries (look above)
    # without a list_installed method get_packages throws a NotImplementedError
    # without a get_package_details method, get_packages will throw a valueError

    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True

    test = TestPkgMgr()

    try:
        test.get_packages()
    except NotImplementedError:
        assert(True)
    else:
        assert(False)

    class TestPkgMgr2(PkgMgr):
        def is_available(self):
            return True

        def list_installed(self):
            return ["python", "gcc"]

    test = TestPkgMgr2()


# Generated at 2022-06-23 00:36:02.069510
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    
    from ansible.module_utils.common.text.package_manager import PkgMgr
    
    pkg_mgr = PkgMgr()
    
    assert pkg_mgr.get_package_details("aaa") == None

# Generated at 2022-06-23 00:36:04.471153
# Unit test for constructor of class LibMgr
def test_LibMgr():
    # test that the class is there
    assert LibMgr

    # test that the class can be instantiated
    assert LibMgr()


# Generated at 2022-06-23 00:36:07.402497
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    mgr = CLIMgr()
    assert mgr._cli is None
    assert mgr.CLI is None



# Generated at 2022-06-23 00:36:12.785332
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class CLIMgrNoCLI(CLIMgr):
        CLI = "no_cli_install"
    pm = CLIMgrNoCLI()
    assert pm.is_available() == False

    class CLIMgrCLI(CLIMgr):
        CLI = "echo"
    pm = CLIMgrCLI()
    assert pm.is_available() == True

# Generated at 2022-06-23 00:36:15.435252
# Unit test for constructor of class LibMgr
def test_LibMgr():
    lMgr = LibMgr()
    assert lMgr._lib == None


# Generated at 2022-06-23 00:36:19.481248
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    p = PkgMgr()
    try:
        p.get_package_details("")
    except NotImplementedError as e:
        print(e)
        print("method get_package_details of class PkgMgr is not implemented")
    except Exception as e:
        print("testing get_package_details of class PkgMgr failed with unexpected error")
        print(e)


# Generated at 2022-06-23 00:36:20.402951
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    pass



# Generated at 2022-06-23 00:36:23.428214
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    p = PkgMgr()
    p.is_available()
    l = p.list_installed()
    assert isinstance(l, list)


# Generated at 2022-06-23 00:36:29.014910
# Unit test for constructor of class LibMgr
def test_LibMgr():
    import platform
    if platform.system() == 'Linux':
        from ansible.module_utils.linux_distribution import lib2pkg_map
        import yum as yummodule
        yum = LibMgr()
        yum.LIB = lib2pkg_map['yum']
        yum._lib = yummodule
        assert yum._lib != None



# Generated at 2022-06-23 00:36:30.178229
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():

    assert get_all_pkg_managers()

# Generated at 2022-06-23 00:36:32.903282
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    class TargetClass(CLIMgr):
        CLI = '/bin/foo'
    target_obj = TargetClass()

    assert target_obj._cli is None


# Generated at 2022-06-23 00:36:37.063848
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    class_list = get_all_pkg_managers()
    assert 'a' in class_list
    assert 'b' in class_list
    assert 'climgr' not in class_list
    assert 'libmgr' not in class_list

# Generated at 2022-06-23 00:36:41.201334
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    class PkgMgr_list_installed(PkgMgr):
        def is_available(self):
            return True

        def list_installed(self):
            return ['foo']
    assert PkgMgr_list_installed().list_installed() == ['foo']


# Generated at 2022-06-23 00:36:42.824482
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    assert isinstance(PkgMgr(), PkgMgr)


# Generated at 2022-06-23 00:36:46.855421
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    p = PkgMgr()
    result = p.get_package_details('python-dateutil')
    assert isinstance(result, dict)
    assert 'name' in result
    assert 'version' in result
    assert 'type' in result
    assert result['type'] == 'unknown'

# Generated at 2022-06-23 00:36:48.915638
# Unit test for constructor of class LibMgr
def test_LibMgr():
    lm = LibMgr()
    assert lm is not None


# Generated at 2022-06-23 00:36:50.814100
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():

    assert get_bin_path('apt-get')
    assert not get_bin_path('apt-get-mock')

# Generated at 2022-06-23 00:36:55.856357
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class MyLib(LibMgr):
        LIB = 'lib_name'
    import os
    test_lib = MyLib()
    assert not test_lib._lib
    os.environ['ANSIBLE_DISCOVERY_DEPENDENCIES'] = '{0}={1}'.format(MyLib.LIB, 'lib_path')
    assert test_lib.is_available()
    assert test_lib._lib

# Generated at 2022-06-23 00:37:06.117316
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    mgr = CLIMgr()
    # get_bin_path will return True if the path to the binary exists and valid, so we need to mock the method
    # from ansible.module_utils.common.process import get_bin_path
    def is_available_mock(path):
        if path == "/usr/bin/apt-get":
            return "/usr/bin/apt-get"
        else:
            raise ValueError
    mgr.CLI = "apt-get"
    mgr.is_available = is_available_mock
    assert mgr.is_available()
    mgr.CLI = "yum"
    assert not mgr.is_available()