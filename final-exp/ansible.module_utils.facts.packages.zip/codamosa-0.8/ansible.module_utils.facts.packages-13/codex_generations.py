

# Generated at 2022-06-11 03:56:49.520243
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():

    # Unit test for characteristic True
    assert True == PkgMgr.__subclasses__()[0].is_available()

    # Unit test for characteristic False
    assert False == PkgMgr.__subclasses__()[1].is_available()


# Generated at 2022-06-11 03:56:51.609627
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    manager = LibMgr()
    assert manager.is_available() is False



# Generated at 2022-06-11 03:56:54.205489
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert str(CLIMgr()) == "<ansible.module_utils.facts.system.pkg_mgr.CLIMgr object at 0x7f43d872f850>"

# Generated at 2022-06-11 03:56:56.027354
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    testMgr = PkgMgr()
    assert testMgr.list_installed() == None

# Generated at 2022-06-11 03:57:01.107285
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    from ansible_collections.ansible.community.plugins.module_utils.common.utils import get_all_pkg_managers
    l_managers = get_all_pkg_managers()
    assert 'pkg_mgr' in l_managers
    assert callable(l_managers['pkg_mgr'].get_package_details)


## Test suite


# Generated at 2022-06-11 03:57:02.471277
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    print(CLIMgr().__class__.__name__)


# Generated at 2022-06-11 03:57:10.492685
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    # LibMgr is an ABC, create a subclass to actually test
    class dummyLibMgr(LibMgr):
        def __init__(self, import_name):
            self.LIB = import_name
            super(dummyLibMgr, self).__init__()

        def list_installed(self):
            pass

        def get_package_details(self, package):
            pass

    # Test that when a lib is available the is_available method returns true
    assert dummyLibMgr('os.path').is_available()
    # Test that when a lib is not available the is_available method returns false
    assert not dummyLibMgr('fooLib').is_available()



# Generated at 2022-06-11 03:57:19.158880
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class Sub_LibMgr(LibMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return [1, 2]
        def get_package_details(self, package):
            return {'name': package, 'version': package}

    class Sub_CLIMgr(CLIMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return [1, 2, 3]
        def get_package_details(self, package):
            return {'name': package, 'version': package}

    # LibMgr
    sub_lib = Sub_LibMgr()

# Generated at 2022-06-11 03:57:20.090142
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    assert CLIMgr.is_available(None) == False

# Generated at 2022-06-11 03:57:31.038645
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    # pylint: disable=unused-argument,no-self-use
    """This function unit test the method PkgMgr.is_available().

    It tests the successful execution with a valid binary path and a
    ValueError exception when the binary path is not found.

    This only works when the CLI is set to a valid binary path.
    """
    class MockCLIMgr(CLIMgr):
        CLI = "ls"

    mock_mgr = MockCLIMgr()
    assert mock_mgr.is_available() is True

    class MockCLIMgr(CLIMgr):
        CLI = "not_a_valid_binary"

    mock_mgr = MockCLIMgr()
    try:
        mock_mgr.is_available()
        assert False
    except ValueError:
        assert True



# Generated at 2022-06-11 03:57:38.844921
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'os'
    assert TestLibMgr().is_available() is True
    class TestLibMgr(LibMgr):
        LIB = 'fake_lib'
    assert TestLibMgr().is_available() is False



# Generated at 2022-06-11 03:57:45.277170
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class FakeCLIMgr(CLIMgr):
        CLI = "Fake"

    # Mock module_utils.common.process.get_bin_path
    import sys
    import os
    sys.modules['ansible.module_utils.common.process'] = FakeProcess()
    sys.modules['ansible.module_utils'] = FakeUtils()
    sys.modules['ansible'] = FakeAnsible()
    fake_cli_mgr = FakeCLIMgr()
    assert fake_cli_mgr.is_available() == True

    # Remove fake modules
    del sys.modules['ansible.module_utils.common.process']
    del sys.modules['ansible.module_utils']
    del sys.modules['ansible']

# Mock classes to test CLIMgr

# Generated at 2022-06-11 03:57:48.989213
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCLI(CLIMgr):
        CLI = 'test'

    test_CLI = TestCLI()
    test_CLI._cli = None
    assert not test_CLI.is_available()

    test_CLI._cli = '/bin/test'
    assert test_CLI.is_available()

# Generated at 2022-06-11 03:57:55.278857
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    pm=PkgMgr()
    cf=CLIMgr()
    pkg_list=["python", "pip"]
    pm.list_installed=lambda: pkg_list
    pm.get_package_details=lambda x: dict(name=x, version="1.0.0")
    expected = dict(python=[dict(name="python", version="1.0.0", source="pkgmgr")])
    actual = pm.get_packages()
    assert expected == actual


# Generated at 2022-06-11 03:57:56.702976
# Unit test for constructor of class LibMgr
def test_LibMgr():
    assert LibMgr()._lib is None


# Generated at 2022-06-11 03:57:58.844106
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    pkgs = []
    pgm = PkgMgr()
    pkgs = pgm.get_packages()
    assert pkgs == {}

# Generated at 2022-06-11 03:58:03.343014
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    try:
        __import__('json')
    except ImportError:
        json_available = False
    else:
        json_available = True

    class JsonMgr(LibMgr):

        LIB = 'json'

    jmgr = JsonMgr()
    assert jmgr.is_available() == json_available


# Generated at 2022-06-11 03:58:04.294848
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    assert PkgMgr().list_installed() == None

# Generated at 2022-06-11 03:58:07.444596
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    # Test for None
    test_PkgMgr = PkgMgr()
    result = test_PkgMgr.get_packages()
    assert result is None, 'Did not return None for expected None'


# Generated at 2022-06-11 03:58:09.272738
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    from ansible.module_utils.common._collections_compat import Mapping
    assert isinstance(get_all_pkg_managers(), Mapping)

# Generated at 2022-06-11 03:58:17.174636
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    test_class = CLIMgr()
    test_class.CLI = 'ls'
    assert test_class.is_available() == True
    test_class.CLI = 'doesnotexist'
    assert test_class.is_available() == False

# Generated at 2022-06-11 03:58:27.739370
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    from ansible.module_utils.facts.system.pkg_mgr import CLIMgr, LibMgr
    import os

    # Test 1: Pass a CLI that exists, is_available should return True
    climgr = CLIMgr()
    climgr.CLI = 'ls'

    if not climgr.is_available():
        os._exit(1)

    # Test 2: Pass a CLI that does not exist, is_available should return False
    climgr.CLI = 'does_not_exist'
    if climgr.is_available():
        os._exit(2)

    # Test 3: Pass None to CLI and use an abstract method, is_available should raise a NotImplementedError
    # Or does not implement the abstract method
    climgr.CLI = None

# Generated at 2022-06-11 03:58:31.492361
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class SubLibMgr(LibMgr):
        LIB = 'test.lib'
    lm = SubLibMgr()
    assert lm.is_available() == False
    import test.lib
    assert lm.is_available() == True


# Generated at 2022-06-11 03:58:37.515207
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():

    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['python', 'python-simplejson']
        def get_package_details(self, package):
            package_details = {'name': package}
            if package == 'python':
                package_details['version'] = '2.7.5'
            elif package == 'python-simplejson':
                package_details['version'] = '3.5.5'
            return package_details
        def get_packages(self):
            return dict()
    ansible_pkg_mgr = TestPkgMgr()

    package_details_python = ansible_pkg_mgr.get_package_details('python')

# Generated at 2022-06-11 03:58:42.777785
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class LibMgr_Mock(LibMgr):
        LIB = "package"
        def __init__(self):
            super(LibMgr_Mock, self).__init__()
    lm = LibMgr_Mock()
    lm._lib = __import__("package")

    assert(lm.is_available() == True)


# Generated at 2022-06-11 03:58:44.410139
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    obj = LibMgr()
    assert obj.is_available() == False

# Generated at 2022-06-11 03:58:50.356560
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    import sys
    if sys.version_info < (2,3):
        raise AssertionError("Needs Python 2.3 or above");
    lib = LibMgr()
    lib.LIB = 'sys'
    assert (lib.is_available() == True)
    assert (lib._lib.version_info >= (2,3))
    lib.LIB = 'doesntexist'
    assert (lib.is_available() == False)


# Generated at 2022-06-11 03:58:53.614704
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    try:
        import pkg_resources
        lib = pkg_resources.get_distribution('ansible').version
        mgr = LibMgr()
        assert mgr.is_available()
    except ImportError:
        pass


# Generated at 2022-06-11 03:58:54.930580
# Unit test for constructor of class LibMgr
def test_LibMgr():
    assert LibMgr().is_available() is False


# Generated at 2022-06-11 03:58:57.893722
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    # Check if the package manager is available (usually by checking if the required library is importable)
    # This is used to decide if the package manager can be used and should be tested first
    assert LibMgr().is_available() is True


# Generated at 2022-06-11 03:59:04.632203
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestClass(LibMgr):
        def __init__(self):
            super(TestClass, self).__init__()
    testClass = TestClass()
    testClass._lib = 1
    assert testClass._lib == 1


# Generated at 2022-06-11 03:59:06.471394
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    test_cli = CLIMgr()
    test_cli.CLI = 'test_cli'
    assert not test_cli.is_available()


# Generated at 2022-06-11 03:59:07.472786
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    pass


# Generated at 2022-06-11 03:59:15.896632
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    from ansible.module_utils.common import distribution
    distro = distribution.detect()

    # FIXME: We need to test LibMgr.is_available() in some distros

    # Instantiating LibMgr.is_available() of class LibMgr
    LibMgr_is_available = LibMgr()

    # Testing LibMgr.is_available() of class LibMgr
    # All is_available() implementation in subclasses should return False if the package manager is not found
    if distro.lower() in ('centos', 'debian', 'ubuntu'):
        assert LibMgr_is_available.is_available() is True
    else:
        assert LibMgr_is_available.is_available() is False


# Generated at 2022-06-11 03:59:23.400055
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    import ansible.module_utils.common.process as process
    import tempfile
    import os

    # If not available -> False
    class DummyCLIMgr(CLIMgr):
        CLI = 'CLI'
    cli = DummyCLIMgr()
    old_get_bin_path = process.get_bin_path
    process.get_bin_path = lambda x: raise_value_error
    assert cli.is_available() is False
    process.get_bin_path = old_get_bin_path

    # If available -> True
    def get_bin_path(binary):
        tmp = tempfile.gettempdir()
        file_name = os.path.join(tmp, 'test')

# Generated at 2022-06-11 03:59:24.162079
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    pass



# Generated at 2022-06-11 03:59:29.908631
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    bad_package_name = 'test_package'
    pkg_mgr = PkgMgr()
    try:
        pkg_mgr.get_package_details(bad_package_name)
    except NotImplementedError:
        # Good, this is the correct behaviour
        return
    except Exception:
        raise Exception("Unexpected exception when calling PkgMgr.get_package_details with a bad package name")
    raise Exception("Calling PkgMgr.get_package_details with a bad package name did not raise a NotImplementedError")

# Generated at 2022-06-11 03:59:32.065166
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    manager = CLIMgr()
    assert manager.is_available() == False
    manager.CLI = 'python'
    assert manager.is_available() == True


# Generated at 2022-06-11 03:59:38.719939
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    import sys
    import inspect
    from ansible.module_utils.common.process import get_bin_path

    pkg_mgr = CLIMgr()
    cli = 'apt-get'
    pkg_mgr.CLI = cli

    pkg_mgr.__module__ = sys.modules[inspect.getmodule(pkg_mgr).__name__]

    assert pkg_mgr.is_available() == True
    assert isinstance(pkg_mgr._cli, str)
    assert pkg_mgr._cli == get_bin_path(cli)


# Generated at 2022-06-11 03:59:40.507680
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class LibMgr_T(LibMgr):
        LIB = 'x'
    LibMgr_T()

# Generated at 2022-06-11 03:59:48.508969
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    def mock_get_bin_path(item):
        return 'mock'
    CLIMgr.CLI = 'dpkg'
    p = CLIMgr()
    # Test for when get_bin_path returns a valid path
    if not p.is_available():
        print('CLIMgr is_available() method does not return True for a valid path')
    # Test for when get_bin_path returns an invalid path
    CLIMgr.CLI = 'invalid-path'
    p = CLIMgr()
    # Monkey-patch get_bin_path to return an invalid path
    CLIMgr.get_bin_path = mock_get_bin_path
    if p.is_available():
        print('CLIMgr is_available() method does not return False for an invalid path')


# Generated at 2022-06-11 03:59:49.733105
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    assert CLIMgr.is_available("pip") == None


# Generated at 2022-06-11 03:59:53.877137
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    cmd = 'ansible-pkg-mgr'
    try:
        get_bin_path(cmd)
        return True
    except ValueError:
        return False


if __name__ == "__main__":
    print(test_CLIMgr_is_available())

# Generated at 2022-06-11 03:59:54.784618
# Unit test for constructor of class LibMgr
def test_LibMgr():
    pm = LibMgr()



# Generated at 2022-06-11 03:59:58.004264
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class CLIMgrTest(CLIMgr):
        CLI = 'nmap'
    
    objCLIMgrTest = CLIMgrTest()
    objCLIMgrTest.is_available()
    assert objCLIMgrTest._cli == '/usr/bin/nmap'

# Generated at 2022-06-11 04:00:03.071126
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    mgr = PkgMgr()
    result = mgr.get_packages()
    assert result is {}

    mgr.list_installed = lambda: ['a', 'b']
    mgr.get_package_details = lambda package: {'name': package}
    result = mgr.get_packages()
    assert result == {'a': [{'name': 'a'}], 'b': [{'name': 'b'}]}

# Generated at 2022-06-11 04:00:05.985132
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    test_lib = 'os.path'
    lib_object = LibMgr()
    lib_object.LIB = test_lib
    assert lib_object.is_available()


# Generated at 2022-06-11 04:00:11.607956
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class TestClass(object):
        def __init__(self):
            self.package = None
        def is_available(self):
            return True
        def list_installed(self):
            return []
        def get_package_details(self):
            return self.package
    test = TestClass()
    for item in ['foo', 'foobar', 'foobarbaz', None]:
        test.package = item
        assert PkgMgr(test).get_package_details == item

# Generated at 2022-06-11 04:00:12.860571
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    assert PkgMgr().is_available() == NotImplemented

# Generated at 2022-06-11 04:00:14.708418
# Unit test for constructor of class LibMgr
def test_LibMgr():
    test_class = LibMgr()
    assert test_class.is_available() == False


# Generated at 2022-06-11 04:00:24.750546
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    CLI_MGR_INSTANCE = CLIMgr()
    CLI_MGR_INSTANCE.CLI = 'ls'
    assert CLI_MGR_INSTANCE.is_available() == True
    CLI_MGR_INSTANCE.CLI = 'ls_fake'
    assert CLI_MGR_INSTANCE.is_available() == False


# Generated at 2022-06-11 04:00:25.304859
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    pass


# Generated at 2022-06-11 04:00:27.350486
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():

    assert GLibMgr().is_available()
    assert GLibMgr()._lib.__name__.lower() == 'gi'

    assert NotImplementedError


# Generated at 2022-06-11 04:00:31.957124
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    class FakePkgMgr(PkgMgr):

        def is_available(self):
            return True

        def list_installed(self):
            return ['my_pkg', 'my_pkg2']

        def get_package_details(self, package):
            return {'name': package}

    fake_pkg_mgr = FakePkgMgr()
    assert fake_pkg_mgr.get_packages() == {'my_pkg': [{'name': 'my_pkg'}], 'my_pkg2': [{'name': 'my_pkg2'}]}

# Generated at 2022-06-11 04:00:40.281765
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    """Test for method ``PkgMgr.get_packages``."""

    class _PkgMgr(PkgMgr):
        """Test of class PkgMgr."""

        def __init__(self):
            """Definition of variables."""

            self.lib = None
            super(_PkgMgr, self).__init__()

        def is_available(self):
            """Installation verification."""

            found = False
            try:
                self.lib = __import__(self.LIB)
                found = True
            except ImportError:
                pass
            return found

        def list_installed(self):
            """List of installed packages."""

            return tuple("packages")

        def get_package_details(self, package):
            """Package details."""

            package_details = dict()

# Generated at 2022-06-11 04:00:41.408110
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    assert CLIMgr.is_available() == False


# Generated at 2022-06-11 04:00:41.947395
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pass



# Generated at 2022-06-11 04:00:43.637212
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    a = CLIMgr()
    assert isinstance(a,CLIMgr)


# Generated at 2022-06-11 04:00:44.845723
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    obj = CLIMgr()
    assert obj._cli == None

# Generated at 2022-06-11 04:00:47.749465
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCLIMgr(CLIMgr):
        CLI = 'ls'
    test_cli_mgr = TestCLIMgr()
    assert isinstance(test_cli_mgr.is_available(), bool)



# Generated at 2022-06-11 04:01:04.244354
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pass



# Generated at 2022-06-11 04:01:05.666451
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    climgr = CLIMgr()
    assert climgr is not None

# Generated at 2022-06-11 04:01:08.020995
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    pkgmgr = PkgMgr()
    installed_packages = pkgmgr.get_packages()
    assert len(installed_packages) == 0

# Generated at 2022-06-11 04:01:09.995258
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():

    class CLIMgrTest(CLIMgr):
        CLI = 'ls'

    cmgr = CLIMgrTest()
    assert cmgr.is_available()

# Generated at 2022-06-11 04:01:12.539684
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    c = CLIMgr()
    if c._cli is not None:
        return True
    return False

if __name__ == '__main__':
    print(test_CLIMgr())

# Generated at 2022-06-11 04:01:14.786715
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    assert hasattr(PkgMgr, 'list_installed'), 'Method list_installed should be implemented in PkgMgr'


# Generated at 2022-06-11 04:01:15.303281
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    pass

# Generated at 2022-06-11 04:01:16.322165
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    """
    Test to check creation of class CLIMgr
    """
    c = CLIMgr()
    assert(isinstance(c, CLIMgr))

# Generated at 2022-06-11 04:01:21.234039
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():

    class MockPkgMgr(PkgMgr):
        def __init__(self):
            super(MockPkgMgr, self).__init__()

        def is_available(self):
            return True

        def list_installed(self):
            return ['1', '2']

    my_pkg = MockPkgMgr()
    expected_packages = ['1', '2']
    assert my_pkg.list_installed() == expected_packages


# Generated at 2022-06-11 04:01:25.531441
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    mgr = PkgMgr()
    with open('get_package_details.txt') as fd:
        line = fd.readline()
        pack_info = mgr.get_package_details(line)
        assert pack_info['name'] == 'setup'
        assert pack_info['architecture'] == 'noarch'
        assert pack_info['version'] == '3.6'


# Generated at 2022-06-11 04:02:02.290337
# Unit test for constructor of class LibMgr
def test_LibMgr():
    lib_mgr = LibMgr()
    assert lib_mgr is not None


# Generated at 2022-06-11 04:02:09.116043
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    from ansible.module_utils.facts.pkg_mgr import CLIMgr
    from ansible.module_utils._text import to_bytes, to_native

    class TestCLIMgr(CLIMgr):
        CLI = 'unknown'

    # Test cli is not available
    TestCLIMgr._cli = TestCLIMgr.CLI
    TestCLIMgr.is_available()
    assert TestCLIMgr._cli != TestCLIMgr.CLI

    # Test cli is available
    TestCLIMgr.CLI = 'true'
    TestCLIMgr.is_available()
    assert TestCLIMgr._cli == to_native(to_bytes(TestCLIMgr.CLI))


# Generated at 2022-06-11 04:02:10.569698
# Unit test for constructor of class LibMgr
def test_LibMgr():
    libmgr = LibMgr()
    assert libmgr._lib is None


# Generated at 2022-06-11 04:02:12.151204
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    for pm in get_all_pkg_managers().values():
        print(pm.is_available())


# Generated at 2022-06-11 04:02:12.972136
# Unit test for constructor of class CLIMgr
def test_CLIMgr():

    assert(CLIMgr().is_available() == False)

# Generated at 2022-06-11 04:02:21.993373
# Unit test for constructor of class LibMgr
def test_LibMgr():
    from ansible.module_utils.facts.system.pkg_mgr import LibMgr
    import ansible.module_utils.facts.system.pkg_mgr.pip as pip
    import pytest

    lib_mgr = LibMgr()
    assert not lib_mgr._lib

    lib_mgr.LIB = 'ansible.module_utils.facts.system.pkg_mgr.pip'
    assert lib_mgr.is_available()
    assert lib_mgr._lib == pip

    lib_mgr.LIB = 'ansible.module_utils.facts.system.pkg_mgr.not_a_lib'
    assert not lib_mgr.is_available()
    assert not lib_mgr._lib

    lib_mgr = LibMgr()

# Generated at 2022-06-11 04:02:22.870110
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    # Not really testable
    pass


# Generated at 2022-06-11 04:02:24.073362
# Unit test for constructor of class LibMgr
def test_LibMgr():
    obj = LibMgr()
    assert obj is not None


# Generated at 2022-06-11 04:02:32.924451
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    import sys
    from io import StringIO
    from unittest.mock import patch
    from ansible.module_utils.facts import PackageFile

    sys.stdout = captured = StringIO()

    # Test for error - AttributeError for missing 'package' argument
    with patch.object(PkgMgr, 'get_package_details', return_value={}):
        # Mock 'get_package_details' method and call it to get an AttributeError
        with patch.object(PackageFile, 'add_package'):
            package = {}
            PackageFile.add_package(package)
            captured.seek(0)
            assert "get_package_details() missing 1 required positional argument: 'package'" in captured.getvalue()


# Generated at 2022-06-11 04:02:33.496406
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    print("Testing PkgMgr get_package_details")
    assert False

# Generated at 2022-06-11 04:03:42.588352
# Unit test for constructor of class LibMgr
def test_LibMgr():
    obj = LibMgr()
    assert obj._lib is None

# Generated at 2022-06-11 04:03:44.520548
# Unit test for constructor of class LibMgr
def test_LibMgr():
    lib = LibMgr()
    lib.LIB = 'test_lib'
    assert(lib._lib is None)
    assert(lib.is_available() is False)


# Generated at 2022-06-11 04:03:46.230235
# Unit test for constructor of class LibMgr
def test_LibMgr():
    # Test for successful instantiation of LibMgr class
    pm = LibMgr()

    assert pm is not None



# Generated at 2022-06-11 04:03:49.263740
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():

    # test with CLI available
    try:
        cli = get_bin_path('ls')
    except ValueError:
        cli = None
    assert CLIMgr.is_available(CLIMgr(), cli) == True


# Generated at 2022-06-11 04:03:50.623521
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    pass


# Generated at 2022-06-11 04:03:53.651935
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    from ansible.module_utils.facts.system.pkg_mgr import CLIMgr
    class TestCLIMgr(CLIMgr):
        CLI = "ls"
    test = TestCLIMgr()
    assert isinstance(test.is_available(), bool)


# Generated at 2022-06-11 04:03:55.938654
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class cli_mgr(CLIMgr):
        CLI="ls"
    cm = cli_mgr()
    assert cm.is_available() == True, "is_available was not true"

# Generated at 2022-06-11 04:03:56.635796
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    pass


# Generated at 2022-06-11 04:04:00.359547
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
  from ansible.module_utils.common.collections import ImmutableDict
  from ansible.module_utils.facts.system import virtual

  facts = virtual._get_facts()
  for package_manager in get_all_pkg_managers().values():
      assert package_manager().is_available() is not None


# Generated at 2022-06-11 04:04:02.495496
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'chardet'
    ml = TestLibMgr()
    assert ml.is_available() == True
