

# Generated at 2022-06-11 03:56:56.027734
# Unit test for constructor of class CLIMgr
def test_CLIMgr():

    class AptCLI(CLIMgr):

        CLI = 'apt-get'

        # required, but not used in the test
        def list_installed(self):
            pass

        # required, but not used in the test
        def get_package_details(self, package):
            pass

    assert AptCLI()._cli == None
    assert AptCLI().is_available() == False
    p = get_bin_path('apt-get')
    assert AptCLI().is_available() == True
    assert AptCLI()._cli == p


# Generated at 2022-06-11 03:56:58.000605
# Unit test for constructor of class LibMgr
def test_LibMgr():
    try:
        lib_mgr = LibMgr()
    except:
        raise AssertionError


# Generated at 2022-06-11 03:56:58.572067
# Unit test for constructor of class LibMgr
def test_LibMgr():
    assert LibMgr

# Generated at 2022-06-11 03:57:00.297316
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    lm = LibMgr()
    assert not lm.is_available()


# Generated at 2022-06-11 03:57:01.700632
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    assert LibMgr.is_available(LibMgr()) == False


# Generated at 2022-06-11 03:57:06.012825
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    all_managers = get_all_pkg_managers()
    for manager in all_managers.values():
        if manager.is_available():
            packages = manager.get_packages()
            assert packages
            for package in packages.values():
                for info in package:
                    assert 'name' in info
                    assert 'version' in info

# Generated at 2022-06-11 03:57:11.137582
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class TestPkgMgr(PkgMgr):
        def get_package_details(self, package):
            return {'name': 'pkg_name', 'version': '1.1'}

    test_pkg_mgr = TestPkgMgr()
    assert test_pkg_mgr.get_package_details('some_package') == {'name': 'pkg_name', 'version': '1.1'}

# Generated at 2022-06-11 03:57:12.390542
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    cm = CLIMgr()
    assert not hasattr(cm,'_cli')

# Generated at 2022-06-11 03:57:13.999091
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    pkg = CLIMgr()
    assert pkg.is_available() == False


# Generated at 2022-06-11 03:57:19.843943
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    test_class = CLIMgr()
    actual = test_class._cli
    expected = None
    assert expected == actual

#####


# Fedora:
#   The dnf package manager is available on RHEL 8 and Fedora.
#   DNF replaces both yum and PackageKit as the default package manager.
#   It’s compatible with yum and provides the same functionality, but with added features and improved stability.
#   See: https://fedoraproject.org/wiki/Features/DNF

# Legacy class for compatibility with old versions of Fedora.

# Generated at 2022-06-11 03:57:33.686331
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    libs = ['ansible.plugins.inventory.yaml.yaml',
            'ansible.plugins.bilbo.bilbo',
            'ansible.plugins.bilbo.guest']
    for lib in libs:
        lib_name = lib.split('.')[-1]
        exec(lib_name + "_mgr = LibMgr()")
        exec(lib_name + "_mgr.LIB = '" + lib + "'")
        exec("assert(type(" + lib_name + "_mgr) == LibMgr)")
        exec("assert(" + lib_name + "_mgr.LIB == '" + lib + "')")
        exec("assert(" + lib_name + "_mgr.is_available() is True)")


# Generated at 2022-06-11 03:57:37.812504
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    not_installed_cli = '_not_exist_'
    installed_cli = 'ls'

    # Test not installed CLI
    manager = CLIMgr()
    manager.CLI = not_installed_cli
    assert not manager.is_available()
    # Test installed CLI
    manager.CLI = installed_cli
    assert manager.is_available()

# Generated at 2022-06-11 03:57:38.865657
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    obj = CLIMgr()
    assert isinstance(obj, CLIMgr)
    assert obj._cli is None


# Generated at 2022-06-11 03:57:41.140141
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():

    class TestLibMgr(LibMgr):
        pass

    test_obj = TestLibMgr()

    test_obj._lib = None
    assert not test_obj.is_available()

    test_obj._lib = 1
    assert test_obj.is_available()


# Generated at 2022-06-11 03:57:42.551004
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    lm = LibMgr()
    assert lm.is_available() == False, 'Failed to determine status of an unavailable library.'


# Generated at 2022-06-11 03:57:47.095111
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    """
    Unit test for method is_available of class PkgMgr.
    """
    class MyPkgMgr(PkgMgr):

        def is_available(self):
            pass

        def list_installed(self):
            pass

        def get_package_details(self, package):
            pass

    pm = MyPkgMgr()
    assert pm.is_available() is False


# Generated at 2022-06-11 03:57:48.679849
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr().is_available() == False, "Unable to create CLIMgr object"


# Generated at 2022-06-11 03:57:56.022334
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class MyPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ["1", "2"]
        def get_package_details(self, package):
            return {"name": "name", "version": "version", "source": "source"}

    packages = MyPkgMgr().get_packages()
    assert len(packages) == 1
    assert packages["name"] == [{"name": "name", "version": "version", "source": "source"}, {"name": "name", "version": "version", "source": "source"}]

# Generated at 2022-06-11 03:57:57.907565
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    pkg = PkgMgr()
    assert pkg.get_package_details(None) == {}

# Generated at 2022-06-11 03:58:01.678139
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCLIMgr(CLIMgr):
        CLI = "ls"
    pkg_mg = TestCLIMgr()
    assert pkg_mg.is_available() is True
    assert pkg_mg._cli is not None

# Generated at 2022-06-11 03:58:15.887223
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    # Initialize a PkgMgr object, feed it some get_package_details() data and verify output of get_packages()
    class MockPkgMgr(PkgMgr):
        def is_available(self):
            return True

        def list_installed(self):
            return ["a", "b", "c", "b", "b", "c", "c"]

        def get_package_details(self, package):
            return {'name': package, 'version': "v%s" % package, 'source': 'mock'}

    mgr = MockPkgMgr()
    package_data = mgr.get_packages()

# Generated at 2022-06-11 03:58:17.174838
# Unit test for constructor of class LibMgr
def test_LibMgr():
    assert LibMgr() is not None

# Generated at 2022-06-11 03:58:19.224528
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    mgr = CLIMgr()
    mgr._cli = 'fake'
    assert mgr._cli == 'fake'


# Generated at 2022-06-11 03:58:29.166733
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    class TestPkgMgr(PkgMgr):

        def is_available(self):
            return True
        
        def list_installed(self):
            return ['package1', 'package2']

        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}

    tpm = TestPkgMgr()
    assert tpm.get_packages() == {
        'package1': [
            {'name': 'package1', 'version': '1.0', 'source': 'testpkgmgr'}
        ],
        'package2': [
            {'name': 'package2', 'version': '1.0', 'source': 'testpkgmgr'}
        ]
    }

# Generated at 2022-06-11 03:58:30.296195
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    raise NotImplementedError


# Generated at 2022-06-11 03:58:37.035299
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    from ansible.module_utils.common.parsing import parse_package_details
    class MockPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['foo']
        def get_package_details(self, package):
            return parse_package_details(package)
    mock_pkg_mgr = MockPkgMgr()
    assert mock_pkg_mgr.get_package_details('foo') == {'name': 'foo'}
    assert mock_pkg_mgr.get_package_details('foo-1.2.3') == {'name': 'foo', 'version': '1.2.3'}

# Generated at 2022-06-11 03:58:41.205780
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
  class TestCLIMgr(CLIMgr):
    CLI = '/bin/echo'
  mgr = TestCLIMgr()
  assert mgr.is_available() == True
  mgr.CLI = '/bin/not_exists'
  assert mgr.is_available() == False

# Generated at 2022-06-11 03:58:51.619301
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    import unittest

    class StubPkgMgr(PkgMgr):
        def __init__(self):
            self.calledListInstalled = False
            self.calledGetPackageDetails = False
            self.called = False

        def is_available(self):
            self.called = True
            return False

        def list_installed(self):
            self.calledListInstalled = True
            return []

        def get_package_details(self, packages):
            self.calledGetPackageDetails = True
            return []

    class StubCLIPkgMgr(CLIMgr):
        def __init__(self):
            super(StubCLIPkgMgr, self).__init__()
            self.calledListInstalled = False
            self.calledGetPackageDetails = False
            self.called = False


# Generated at 2022-06-11 03:59:00.444827
# Unit test for constructor of class LibMgr
def test_LibMgr():
    package_list = ['PkgDnfMgr', 'PkgZypperMgr', 'PkgAptMgr', 'PkgPacmanMgr', 'PkgPipMgr', 'PkgPortageMgr', 'PkgYumMgr', 'PkgFreebsdMgr']
    package_dict = {}
    for package in package_list:
        package_dict[package.lower()] = package
    installed_packages = {}
    for pkg in package_dict.keys():
        pkg_mgr = getattr(__import__('ansible.module_utils.common.packaging.package.' + package_dict[pkg]), package_dict[pkg])()
        if pkg_mgr.is_available():
            installed_packages = pkg_mgr.get_packages()
            break

# Generated at 2022-06-11 03:59:03.292001
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB="datetime"
    PkgMgr = TestLibMgr()
    assert PkgMgr.is_available() == True


# Generated at 2022-06-11 03:59:19.627332
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
        p = PkgMgr()
        assert p.is_available() == None


# Generated at 2022-06-11 03:59:26.079182
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class A(PkgMgr):
        def is_available(self):
            pass
        def list_installed(self):
            pass
        def get_package_details(self, package):
            self.package = package
            return {'name': package}
    test_package_details = {'name':'test_package'}
    a = A()
    a.get_package_details('test_package')
    assert a.package == test_package_details['name']
    assert test_package_details == a.get_package_details('test_package')


# Generated at 2022-06-11 03:59:27.234532
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    cm = CLIMgr()
    assert isinstance(cm, CLIMgr)

# Generated at 2022-06-11 03:59:28.895532
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    pm = PkgMgr()
    assert pm.get_packages() == {}, "get_packages should return empty dict if list_installed method is not overloaded"

# Generated at 2022-06-11 03:59:34.406396
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():

    class MockClass(CLIMgr):
        pass

    # Test when the CLI is not on the PATH
    mock = MockClass()
    mock.CLI = 'mock_CLI'
    assert mock.is_available() == False

    # Add it to PATH
    import os
    os.environ['PATH'] = '%s:%s' % (os.curdir, os.environ['PATH'])
    assert mock.is_available() == True

# Generated at 2022-06-11 03:59:35.559472
# Unit test for constructor of class LibMgr
def test_LibMgr():
    libmgr = LibMgr()
    assert libmgr != None


# Generated at 2022-06-11 03:59:37.794864
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    obj = CLIMgr()
    assert obj.is_available()==True
    obj.CLI='no'
    assert obj.is_available()==False


# Generated at 2022-06-11 03:59:39.035724
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    assert CLIMgr().is_available() == False


# Generated at 2022-06-11 03:59:39.558468
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr()

# Generated at 2022-06-11 03:59:41.036584
# Unit test for constructor of class LibMgr
def test_LibMgr():
    obj = LibMgr()

    assert obj._lib == None


# Generated at 2022-06-11 04:00:15.040070
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    # import platform as plat
    try:
        __import__('yum')
        l = LibMgr()
        l.LIB = 'yum'
        assert l.is_available()
    except ImportError:
        pass

# Generated at 2022-06-11 04:00:23.055743
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class test_PkgMgr(PkgMgr):
        def is_available(self):
            pass
        def list_installed(self):
            return ['test1', 'test2']
        def get_package_details(self, package):
            return {'name': package, 'version': '1.0.0'}
    test_pkgmgr = test_PkgMgr()
    assert test_pkgmgr.get_packages() == {'test1': [{'name': 'test1', 'version': '1.0.0', 'source': 'test_pkgmgr'}], 'test2': [{'name': 'test2', 'version': '1.0.0', 'source': 'test_pkgmgr'}]}

# Generated at 2022-06-11 04:00:24.448602
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    climgr = CLIMgr()
    assert climgr.is_available() == True

# Generated at 2022-06-11 04:00:25.404232
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():

    self.fail('Placeholder')

# Generated at 2022-06-11 04:00:28.328462
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class GoodLibMgr(LibMgr):
        LIB = 'os'

    class BadLibMgr(LibMgr):
        LIB = 'idontexist'

    assert GoodLibMgr().is_available() and not BadLibMgr().is_available()


# Generated at 2022-06-11 04:00:28.777238
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pass

# Generated at 2022-06-11 04:00:30.536019
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pm = PkgMgr()
    try:
        pm.is_available()
    except NotImplementedError:
        pass


# Generated at 2022-06-11 04:00:38.474166
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    import unittest
    import sys

    class LibMgrTester(LibMgr):
        LIB = 'sys'

    lib_mgr_tester = LibMgrTester()
    if not hasattr(sys, '_called_from_test'):
        setattr(sys, '_called_from_test', True)
        tests = unittest.TestLoader().loadTestsFromTestCase(LibMgrTester)
        unittest.TextTestRunner(verbosity=2).run(tests)
    else:
        class TestLibMgr(unittest.TestCase):
            def test_is_available(self):
                self.assertTrue(lib_mgr_tester.is_available())


# Generated at 2022-06-11 04:00:42.205336
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    for pkg_mgr in get_all_pkg_managers().values():
        if not pkg_mgr().is_available():
            continue
        try:
            pkg_mgr().get_package_details("test")
        except NotImplementedError:
            continue
        except Exception as e:
            raise e

# Generated at 2022-06-11 04:00:51.005803
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    p = {'name': 'python'}

    def my_list_installed():
        return [p]

    def my_get_package_details(p):
        return {'name': 'python', 'version': '2.7.10'}

    class PkgMgrTester(PkgMgr):
        def list_installed(self):
            return my_list_installed()
        def get_package_details(self, package):
            return my_get_package_details(package)

    tester = PkgMgrTester()

    packages = tester.get_packages()

    assert packages == {'python': [{'name': 'python', 'version': '2.7.10', 'source': 'pkgmgrtester'}]}, "Return value was " + str(packages)



# Generated at 2022-06-11 04:02:04.135540
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            pass
        def list_installed(self):
            return ["list_1", "list_2"]
        def get_package_details(self, package):
            return {'name': package, 'version': '3.0.0', 'source': 'TestSource'}

    test_mgr = TestPkgMgr()
    expected = {'list_1': [{'name': 'list_1', 'version': '3.0.0', 'source': 'TestSource'}],
                'list_2': [{'name': 'list_2', 'version': '3.0.0', 'source': 'TestSource'}]}

    assert test_mgr.get_packages() == expected

# Generated at 2022-06-11 04:02:06.244646
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    c = CLIMgr()
    c.CLI = "npm"
    assert c.is_available()

# Unit testing for constructor of class LibMgr

# Generated at 2022-06-11 04:02:07.992785
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'json'

    TestLibMgr().is_available()


# Generated at 2022-06-11 04:02:11.912944
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    # If package manager binary path is registered
    # assert is_available returns true
    if get_bin_path("apt-get"):
        assert CLIMgr().is_available()

    # If package manager binary path is not registered
    # assert is_available returns false
    if not get_bin_path("apt-get"):
        assert not CLIMgr().is_available()

# Generated at 2022-06-11 04:02:15.872143
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    ''' Test the methods in class CLIMgr. '''

    # Test the methods in class CLIMgr.
    # Given a package manager installed
    pkg_mgr = CLIMgr()
    # When I run is_available method
    # Then the method should return true
    assert pkg_mgr.is_available()


# Generated at 2022-06-11 04:02:17.153653
# Unit test for constructor of class LibMgr
def test_LibMgr():

    assert LibMgr()._lib is None


# Generated at 2022-06-11 04:02:21.612246
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class test_LibMgr(LibMgr):
        """
        Fake package manager class.
        """
        LIB = 'test_library'

    lib_mgr = test_LibMgr()

    assert lib_mgr._lib is None
    lib_mgr.is_available()
    assert lib_mgr._lib.__name__ == 'test_library'


# Generated at 2022-06-11 04:02:26.216959
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    # Check if specific package manager is available
    from ansible.module_utils.facts import pkgmgr
    assert pkgmgr.apk.is_available()
    assert pkgmgr.rpm.is_available()
    # Check if apt is available. May be not present in Docker image.
    if "apt" in pkgmgr._pkg_mgr:
        assert pkgmgr.apt.is_available()

# Generated at 2022-06-11 04:02:27.017348
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    assert CLIMgr().is_available()

# Generated at 2022-06-11 04:02:32.132000
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class LibMgr_test(LibMgr):
        def __init__(self):
            self.LIB = 'os'
            super(LibMgr_test, self).__init__()

    LibMgr_test_obj = LibMgr_test()
    result = LibMgr_test_obj.is_available()
    assert(result == True)



# Generated at 2022-06-11 04:05:19.935092
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    assert CLIMgr.is_available() == False


# Generated at 2022-06-11 04:05:22.965340
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    pkg_manager = get_all_pkg_managers()['dpkg']()
    pkg_list = pkg_manager.get_packages()
    # Assert that the list returned is of type dictionary
    assert isinstance(pkg_list,dict)

# Generated at 2022-06-11 04:05:29.800872
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    with open('testing/pkgmgrtest.py', 'r') as p:
        lines = p.read().splitlines()
    lines = [l for l in lines if l.startswith('class ')]

    for l in lines:
        pkgmgr_class_name = l.split('(')[0].split(' ')[1]
        pkgmgr_instance = globals()[pkgmgr_class_name]()
        result = pkgmgr_instance.is_available()
        print(pkgmgr_class_name, 'is available:', result)
        #assert result.__class__.__name__ == 'bool'



# Generated at 2022-06-11 04:05:31.101537
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    assert LibMgr().is_available() == False


# Generated at 2022-06-11 04:05:38.375179
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    import re
    from ansible.module_utils.facts.system.pkg_mgr import get_pkg_mgr

    pkg_mgr_facts = get_pkg_mgr()
    for pkg in pkg_mgr_facts['packages']:
        if 'phantomjs' in pkg:
            # issue with phantomjs/2.1.1-15 on centos7
            continue
        if 'pango' in pkg:
            continue
        if '2.2-2' in pkg:
            # issue with perl-5.24.1-5.fc25.x86_64
            continue
        if '1:1.8.3.1' in pkg:
            # issue with 1:virt-manager-1.4.0-2.fc25.noarch
            continue

# Generated at 2022-06-11 04:05:41.264062
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    lm = LibMgr()
    lm.LIB = "unittest_LibMgr_is_available"
    assert not lm.is_available()
    lm.LIB = "time"
    assert lm.is_available()


# Generated at 2022-06-11 04:05:48.700895
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def __init__(self, expected_value, expected_package_details):
            self.expected_value = expected_value
            self.expected_package_details = expected_package_details
            super(TestPkgMgr, self).__init__()

        def is_available(self):
            return True

        def list_installed(self):
            return self.expected_value

        def get_package_details(self, package):
            return self.expected_package_details
    expected_value = ['package1', 'package2']
    expected_package_details = {'name': 'package1', 'version': '1.0.0', 'source': TestPkgMgr.__name__.lower()}

# Generated at 2022-06-11 04:05:49.770549
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    assert LibMgr().is_available() == False

# Generated at 2022-06-11 04:05:50.237842
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    assert False, "Test not implemented"


# Generated at 2022-06-11 04:05:51.225863
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    assert PkgMgr().get_packages == object.get_packages