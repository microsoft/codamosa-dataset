

# Generated at 2022-06-11 03:56:56.735409
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    pkg_managers = get_all_pkg_managers()
    assert len(pkg_managers) > 0
    assert isinstance(pkg_managers, dict)
    assert 'aptmgr' in pkg_managers
    assert 'apmgr' in pkg_managers
    assert 'dnfpmgr' in pkg_managers
    assert 'eopkgpmgr' in pkg_managers
    assert 'pacmanpmgr' in pkg_managers
    assert 'pkgngpmgr' in pkg_managers
    assert 'yumpmgr' in pkg_managers
    assert 'zypperpmgr' in pkg_managers

# Generated at 2022-06-11 03:57:04.766704
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():

    class PkgMgr_test(PkgMgr):
        def is_available(self):
            pass
        def get_package_details(self, package):
            return {'name':'test', 'version':'1.0'}
        def list_installed(self):
            return ['test']

    pkg_mgr = PkgMgr_test()
    results = pkg_mgr.get_packages()
    assert 'test' in results
    assert results['test'][0]['name'] == 'test'
    assert results['test'][0]['version'] == '1.0'


# Generated at 2022-06-11 03:57:06.183098
# Unit test for constructor of class LibMgr
def test_LibMgr():
    assert PkgMgr is not None
    assert LibMgr is not None
    assert isinstance(LibMgr(), PkgMgr)


# Generated at 2022-06-11 03:57:07.058103
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    pass


# Generated at 2022-06-11 03:57:13.195389
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    class TestPkgMgr(PkgMgr):
        def list_installed(self):
            return ['x', 'y', 'z']

        def get_package_details(self, package):
            return {'name': 'test_name', 'version': 'test_version'}
    test_obj = TestPkgMgr()
    test_obj.is_available = lambda: True
    assert(test_obj.list_installed() == ['x', 'y', 'z'])


# Generated at 2022-06-11 03:57:19.565717
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    class CLIMgr_test(CLIMgr):
        CLI = 'CLI'
        def list_installed(self):
            return [1,2,3]
        def get_package_details(self, package):
            return {'name': 'package_name'}

    climgr_obj = CLIMgr_test()
    assert climgr_obj.CLI == 'CLI'
    assert climgr_obj._cli == None
    assert isinstance(climgr_obj, CLIMgr)
    assert isinstance(climgr_obj, PkgMgr)



# Generated at 2022-06-11 03:57:21.947070
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class PackageManger(LibMgr):
        LIB = 'os'

    manager = PackageManger()
    assert manager.is_available() == True


# Generated at 2022-06-11 03:57:25.871709
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    pm = CLIMgr()
    pm.CLI = 'ansible'
    assert pm.is_available() is True
    pm.CLI = 'ansible123'
    assert pm.is_available() is False

# Generated at 2022-06-11 03:57:28.934015
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    pkg_managers = get_all_pkg_managers()
    for name, manager in pkg_managers.items():
        if issubclass(manager, CLIMgr):
            assert manager().is_available()

# Generated at 2022-06-11 03:57:38.245683
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    # Create class for testing
    class TestPkgMgr(PkgMgr):
        def __init__(self):
            super(TestPkgMgr, self).__init__()

        def is_available(self):
            return True

        def list_installed(self):
            return ['package1', 'package2']

        def get_package_details(self, name):
            return {'name': name, 'version': '2.2.2'}

    tpm = TestPkgMgr()
    expected = {'package1': [{'name': 'package1', 'version': '2.2.2', 'source': 'testpkgmgr'}],
                'package2': [{'name': 'package2', 'version': '2.2.2', 'source': 'testpkgmgr'}]}

   

# Generated at 2022-06-11 03:57:48.465482
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    import sys
    import_exception = None
    try:
        import test_LibMgr_is_available
    except ImportError as e:
        import_exception = e

    class TestLibMgr(LibMgr):
        LIB = 'test_LibMgr_is_available'

    # test a package manager with a non-existing module
    lm = TestLibMgr()
    assert lm.is_available() == False

    # test a package manager with an existing module
    sys.modules['test_LibMgr_is_available'] = True
    assert lm.is_available() == True


# Generated at 2022-06-11 03:57:49.081506
# Unit test for constructor of class LibMgr
def test_LibMgr():
    pass

# Generated at 2022-06-11 03:57:51.882508
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCLIMgr(CLIMgr):
        CLI = 'test_cli'
    test_cli = TestCLIMgr()
    assert(test_cli.is_available() == False)


# Generated at 2022-06-11 03:58:01.771502
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgr
    from ansible.module_utils.facts.system.pkg_mgr.aptpkg import AptPkg
    from ansible.module_utils.facts.system.pkg_mgr.yumpkg import YumPkg
    pkg1 = ['python-crypto_2.6-3ubuntu0.1_all.deb', 'python-crypto_2.6-3ubuntu0.1_armhf.deb', 'python-crypto-dbg_2.6-3ubuntu0.1_armhf.deb']

# Generated at 2022-06-11 03:58:02.817141
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    pass


# Generated at 2022-06-11 03:58:03.783105
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    cm = CLIMgr()
    assert cm != None

# Generated at 2022-06-11 03:58:06.207883
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestClass(PkgMgr):
        def is_available(self):
            return True

    obj = TestClass()
    assert obj.get_packages() == {}

# Generated at 2022-06-11 03:58:07.819719
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    libmgr = LibMgr()
    assert libmgr.is_available() == False

# Generated at 2022-06-11 03:58:08.583348
# Unit test for constructor of class LibMgr
def test_LibMgr():
    libmgr = LibMgr()
    assert not libmgr.is_available()

# Generated at 2022-06-11 03:58:13.653020
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    '''
        The test for CLIMgr class is_available method
    '''
    test_input = ['a','b','c']
    test_output =[True, False, False]
    test_class = CLIMgr()
    for i in range(3):
        test_class.CLI = test_input[i]
        if test_class.is_available() == test_output[i]:
            print(test_input[i] + ": Success")
        else:
            print(test_input[i] + ": Failed")

# Generated at 2022-06-11 03:58:23.720564
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'ansible_collections'
        def list_installed(self):
            return True

    test = TestLibMgr()
    assert test.is_available()


# Generated at 2022-06-11 03:58:27.552347
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    from ansible.module_utils.facts.collector import CLIMgr
    test = CLIMgr()
    test.CLI = "dne"
    # Return False for none existing command
    assert test.is_available() == False


# Generated at 2022-06-11 03:58:30.937013
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    mock_class = type('', (CLIMgr,), {'CLI': 'mock_cli'})()
    assert mock_class.CLI == 'mock_cli'
    assert mock_class._cli == None


# Generated at 2022-06-11 03:58:32.575817
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    c = CLIMgr()
    c.is_available()
    assert c._cli is not None

# Generated at 2022-06-11 03:58:42.777552
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    import os
    import tempfile
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.common.text.converters import to_bytes

    # This is like the Python designed __temp_bin_path for writing files
    fd, tmp_path = tempfile.mkstemp()
    os.close(fd)
    with open(tmp_path, 'wb') as f:
        f.write(to_bytes("#!/bin/sh\necho 1.2.3\n"))
    os.chmod(tmp_path, 0o555)

    class TestCLIMgr(CLIMgr):
        CLI = '__temp_bin_path'
        def __init__(self):
            self._cli = None
            super(TestCLIMgr, self).__init

# Generated at 2022-06-11 03:58:53.166787
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    class TestPkgMgr(PkgMgr):

        def is_available(self):
            return True

        def list_installed(self):
            return [
                ['package1', '1.1', 'x86'],
                ['package1', '1.2', 'x86'],
                ['package1-dev', '1.2', 'x86']
            ]

        def get_package_details(self, package):
            return {
                'name': package[0],
                'version': package[1],
                'arch': package[2]
            }

    pkgmgr = TestPkgMgr()

# Generated at 2022-06-11 03:59:01.586063
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    from ansible.module_utils.common.compat.tests.ansible_module_common import AnsibleModule
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.system.pkg_mgr.base import PkgMgr
    import sys
    import time

    pkg_mgrs = get_all_pkg_managers()
    orig_module_args = dict(gather_subset='min')
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all', '!min'], type='list'),
        ),
    )
    result = dict(changed=False)

    base_fact_subsets = [
        'default',
        'pkg_mgr'
    ]

    # Get list of enabled facts subs

# Generated at 2022-06-11 03:59:04.179715
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    c = CLIMgr()
    assert c._cli is None
    assert CLIMgr.CLI is None
    assert CLIMgr.is_available(c) is False
    assert c._cli is None

# Generated at 2022-06-11 03:59:07.848470
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    """
    Check if is_available method returns True or False of class CLIMgr
    """
    assert (get_bin_path('ls') == get_bin_path('ls')) is True
    assert (get_bin_path('_ls__') == get_bin_path('_ls__')) is False

# Generated at 2022-06-11 03:59:12.540396
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    pkg_managers = get_all_pkg_managers()
    assert 'pkgin' in pkg_managers
    assert 'rpm' in pkg_managers
    assert 'yum' in pkg_managers
    assert 'dnf' in pkg_managers
    assert 'apt' in pkg_managers
    assert 'gem' in pkg_managers

# Generated at 2022-06-11 03:59:28.511619
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():

    class TestLibMgr(LibMgr):

        LIB = None

    # Test with a non-existing module
    tlm = TestLibMgr()
    result = tlm.is_available()
    assert result is False


# Generated at 2022-06-11 03:59:34.684244
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    try:
        from ansible.module_utils.common._collections_compat import Mapping
    except ImportError:
        # Python 2.6 and 2.6 need collections.Mapping as a base class
        # Python 3.2 and 3.3 have collections but no Mapping
        from collections import Mapping
    package = {'name': 'vim'}
    assert(PkgMgr.get_package_details(PkgMgr, package) == {})
    assert(isinstance(PkgMgr.get_packages(PkgMgr), Mapping))

# Generated at 2022-06-11 03:59:36.886220
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():

    class PkgMgrTest(LibMgr):
        LIB = "pkg_resources"

    pm = PkgMgrTest()
    assert pm.is_available()



# Generated at 2022-06-11 03:59:38.800650
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class pkg(CLIMgr):
        CLI = 'test'

    o = pkg()
    assert o.is_available() == False

# Generated at 2022-06-11 03:59:40.918475
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class LibMgrImp(LibMgr):
        LIB = 'pkg_resources'
    assert LibMgrImp().is_available()


# Generated at 2022-06-11 03:59:50.146767
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    # Test that CLIMgr.is_available finds existing binary
    import tempfile
    def get_bin_path_success(path):
        return path
    def get_bin_path_failure(path):
        raise ValueError

    temp_file = tempfile.NamedTemporaryFile()
    found_with_success = CLIMgr()
    found_with_success._get_bin_path = get_bin_path_success
    found_with_success.CLI = temp_file.name

    assert found_with_success.is_available() == True

    # Test that CLIMgr.is_available does not find non-existing binary
    not_found_with_failure = CLIMgr()
    not_found_with_failure._get_bin_path = get_bin_path_failure
    not_found_

# Generated at 2022-06-11 03:59:53.918392
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    try:
        for c in get_all_subclasses(CLIMgr):
            c()
    except:
        assert False, 'constructor of CLIMgr failed'
    assert True, 'constructor of CLIMgr passed'

# Generated at 2022-06-11 03:59:54.827725
# Unit test for constructor of class LibMgr
def test_LibMgr():
    assert LibMgr



# Generated at 2022-06-11 04:00:03.575728
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    test_dict = get_all_pkg_managers()
    assert isinstance(test_dict, dict)
    assert 'rpm' in test_dict
    assert 'yumpkg' in test_dict
    assert 'pip' in test_dict
    assert 'pippkg' in test_dict
    assert 'npm' in test_dict
    assert 'npmkg' in test_dict
    assert 'gem' in test_dict
    assert 'gempkg' in test_dict
    assert 'dpkg' in test_dict
    assert 'aptpkg' in test_dict
    assert 'portage' in test_dict
    assert 'portagepkg' in test_dict
    assert 'pkgng' in test_dict
    assert 'pkgngpkg' in test_dict
    assert 'chocolatey' in test_dict

# Generated at 2022-06-11 04:00:07.137162
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    try:
        CLIMgr_test = CLIMgr()
        assert CLIMgr_test is not None
    except Exception as ex:
        assert False, "CLIMgr() constructor not working, or package manager not installed"


# Generated at 2022-06-11 04:00:36.799012
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    import sys
    lib = sys.modules[__name__]
    if not hasattr(lib, 'xml'):
        setattr(lib, 'xml', None)
    assert lib.xml is None, "Expected xml is None"


# Generated at 2022-06-11 04:00:45.082597
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestManager(PkgMgr):
        def __init__(self):
            super(TestManager, self).__init__()
        def is_available(self):
            pass
        def list_installed(self):
            return [b'a', b'b', b'c', b'd']
        def get_package_details(self,package):
            return {'name': package.upper(), 'version': '1.0.0'}

    pkgmgr = TestManager()
    packages = pkgmgr.get_packages()

# Generated at 2022-06-11 04:00:50.203618
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class PkgMgr(object):
        def list_installed(self):
            return ['testpackage']

        def get_package_details(self,package):
            return {'name':'testpackage', 'version':'1.2.3'}

    expected_result = {'testpackage': [{'name': 'testpackage', 'version': '1.2.3'}]}
    assert(expected_result == PkgMgr().get_packages())

# Generated at 2022-06-11 04:00:58.548156
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class DummyCLIMgr(CLIMgr):
        def __init__(self, is_available_flag=True, binary_path='/bin/echo'):
            self._cli = None
            self._is_available_flag = is_available_flag
            self._binary_path = binary_path
            super(DummyCLIMgr, self).__init__()

        def is_available(self):
            try:
                self._cli = get_bin_path('echo')
                if self._is_available_flag:
                    return True
                else:
                    raise ValueError
            except ValueError:
                return False

    d_mgr = DummyCLIMgr()
    actual = d_mgr.is_available()
    assert actual == True, 'is_available() doesn\'t return True'

    d_mgr

# Generated at 2022-06-11 04:00:59.808800
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    a = PkgMgr()
    assert a.is_available() == True


# Generated at 2022-06-11 04:01:06.124658
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    class CLIMgrMock(CLIMgr):
        CLI = "apt-get"
    cli_mgr = CLIMgrMock()
    assert not cli_mgr.is_available()
    assert cli_mgr._cli is None
    try:
        get_bin_path('apt-get')
    except ValueError:
        pass
    else:
        assert cli_mgr.is_available()
        assert cli_mgr._cli is not None


# Generated at 2022-06-11 04:01:11.294825
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def __init__(self):
            pass

        def is_available(self):
            pass

        def list_installed(self):
            pass

        def get_package_details(self, package):
            return {}

    test_obj = TestPkgMgr()
    assert test_obj.get_packages() == {}


# Generated at 2022-06-11 04:01:14.336073
# Unit test for constructor of class LibMgr
def test_LibMgr():
   class TestLibMgr(LibMgr):
       LIB = 'test_lib'

   assert get_bin_path('cat') is not None
   assert get_bin_path('non_existing_exec') is None

# Generated at 2022-06-11 04:01:17.751499
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    package = 'foo'
    lst = {
        'name': 'foo',
        'version': '1.0',
    }
    pkgmgr = PkgMgr()
    result = pkgmgr.get_package_details(package)
    assert result == lst


# Generated at 2022-06-11 04:01:19.545774
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    pkg_manager = PkgMgr()
    assert pkg_manager.get_package_details('test_pkg') is None


# Generated at 2022-06-11 04:02:25.172163
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    cM = CLIMgr()
    assert cM.is_available() == False, \
        "Method is_available does not return False if CLI does not exist."


# Generated at 2022-06-11 04:02:27.557607
# Unit test for constructor of class CLIMgr
def test_CLIMgr():

    pkg_mgr = CLIMgr()
    pkg_mgr._cli = '/bin/ls'
    assert pkg_mgr._cli == '/bin/ls'

# Generated at 2022-06-11 04:02:30.594770
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class DummyCLIMgr(CLIMgr):
        CLI = 'zpp1'

    cli = DummyCLIMgr()
    assert not cli.is_available()


# Generated at 2022-06-11 04:02:37.985987
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def list_installed(self):
            return ['pkg1', 'pkg2']

        def get_package_details(self, package):
            return {'name': package.replace('pkg', 'foobar'), 'version': '0.0.1'}

    class TestCLIMgr(CLIMgr):
        CLI = 'echo'

        def list_installed(self):
            return ['pkg1', 'pkg2']

        def get_package_details(self, package):
            return {'name': package.replace('pkg', 'foobar'), 'version': '0.0.1'}

    class TestLibMgr(LibMgr):
        LIB = 'sys'

        def list_installed(self):
            return ['pkg1', 'pkg2']


# Generated at 2022-06-11 04:02:43.694216
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestLibMgr(LibMgr):
        LIB = 'compare_mgr'

    mgr = TestLibMgr()
    assert mgr
    assert mgr._lib is None
    assert mgr.__class__.LIB == 'compare_mgr'

    assert mgr.is_available()
    assert mgr._lib is not None

    assert isinstance(mgr.__class__, type)
    assert isinstance(mgr, TestLibMgr)

# Generated at 2022-06-11 04:02:45.689019
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    pk = PkgMgr()
    pk.get_package_details("libselinux-python")

# Generated at 2022-06-11 04:02:55.083241
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True

        def list_installed(self):
            return [
                "a_package_1-0-0",
                "b_package_1-0-0",
                "b_package_2-0-0",
            ]

        def get_package_details(self, package):
            parts = package.split('_')
            name = parts[0]
            version = parts[1]

            return {
                'name': name,
                'version': version,
            }

    test_class = TestPkgMgr()
    packages = test_class.get_packages()
    assert isinstance(packages, dict)
    assert len(packages) == 2

# Generated at 2022-06-11 04:02:59.763428
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class PkgMgr1(PkgMgr):
        def is_available(self):
            pass
        def list_installed(self):
            pass
        def get_package_details(self, package):
            return {'name': 'pkg1', 'version': '1.0'}

    pm1 = PkgMgr1()
    assert pm1.get_package_details("a") == {'name': 'pkg1', 'version': '1.0'}



# Generated at 2022-06-11 04:03:05.081192
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    from ansible.module_utils.common._collections_compat import MutableMapping

    is_available = CLIMgr.__dict__['is_available']

    class DummyCLI(CLIMgr):
        CLI = 'dummy_cli'

    dummy_cli = DummyCLI()

    # If a CLI exists, is_available is True
    def get_bin_path_true(cli):
        return 'dummy_path'
    dummy_cli_instance = DummyCLI()
    dummy_cli_instance.get_bin_path = get_bin_path_true
    assert is_available(dummy_cli_instance) is True

    # If a CLI does not exist, is_available is False
    def get_bin_path_false(*args, **kwargs):
        raise ValueError('N/A')

# Generated at 2022-06-11 04:03:06.665165
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    mgr = LibMgr()
    assert mgr.is_available() == False


# Generated at 2022-06-11 04:05:48.806023
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    pm = get_all_pkg_managers()
    if pm:
        for pkg in pm:
            if pm[pkg].is_available():
                pkg_dict = pm[pkg].get_packages()
                assert isinstance(pkg_dict, dict)
                assert pkg_dict
                assert all([isinstance(value, list) for value in pkg_dict.values()])



# Generated at 2022-06-11 04:05:51.497514
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    pkg_managers = get_all_pkg_managers()
    for manager in pkg_managers:
        if pkg_managers[manager].LIB:
            assert type(pkg_managers[manager]().is_available()) is bool


# Generated at 2022-06-11 04:06:01.307934
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.facts import collector

    class DummyPkgMgr(PkgMgr):
        def is_available(self):
            try:
                get_bin_path(self.CLI)
            except ValueError:
                return False
            return True

        def list_installed(self):
            return [
                {
                    'name': 'ansible'
                },
                {
                    'name': 'gcc'
                }
            ]

        def get_package_details(self, package):
            return {'name': package['name'], 'version': 'foo'}


# Generated at 2022-06-11 04:06:02.367225
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    x = CLIMgr()
    print(x.is_available())


# Generated at 2022-06-11 04:06:11.615460
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    # Make a class that subclasses PkgMgr and overwrites the methods.
    class MyCLIMgr(CLIMgr):

        CLI = 'ls'

        def list_installed(self):
            return ['/usr/local', '/usr/bin']

        def get_package_details(self, package):
            return {'name': package, 'version': 'any'}

    # Instantiate class and call get_packages function.
    mgr = MyCLIMgr()
    mgr.is_available()
    packages = mgr.get_packages()

    # Check if the result is what we expect.

# Generated at 2022-06-11 04:06:13.003492
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    """
    test the constructor of the CLIMgr class
    """
    assert CLIMgr()._cli is None



# Generated at 2022-06-11 04:06:15.074376
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestLibMgr(LibMgr):
        def is_available(self):
            pass
        def list_installed(self):
            pass
        def get_package_details(self):
            pass

    TestLibMgr().is_available()

# Generated at 2022-06-11 04:06:16.318521
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    test = CLIMgr()
    test.CLI = 'test'
    assert not test.is_available()

# Generated at 2022-06-11 04:06:17.073082
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pass


# Generated at 2022-06-11 04:06:20.553161
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    try:
        class TestPkgMgr(PkgMgr):
            def list_installed(self):
                pass

        test_cls = TestPkgMgr()
    except TypeError:
        raise AssertionError('TestPkgMgr should derive from PkgMgr class')

