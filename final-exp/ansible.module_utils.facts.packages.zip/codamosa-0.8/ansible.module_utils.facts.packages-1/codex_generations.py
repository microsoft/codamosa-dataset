

# Generated at 2022-06-11 03:56:49.176883
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'pkg_resources'
    p = TestLibMgr()
    assert p.is_available()


# Generated at 2022-06-11 03:56:52.383123
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class MockCLIMgr(CLIMgr):
        CLI = '_mock_cli'
    m = MockCLIMgr()
    assert m.is_available() == False
    #assert m.is_available() == True

# Generated at 2022-06-11 03:57:00.297198
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    class DummyCLI(CLIMgr):
        CLI = 'dummycli'

    dummy_mgr = DummyCLI()
    # For CLI attribute, we only need to check whether it is equal to 'dummycli'
    assert DummyCLI.CLI == 'dummycli'
    # For is_available() method, the only place variable 'self._cli' is set, is in the is_available() method.
    # So we can check the variable to test the function
    dummy_mgr.is_available()
    assert dummy_mgr._cli == get_bin_path('dummycli')

# Generated at 2022-06-11 03:57:02.870602
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    class DummyCLIMgr(CLIMgr):
        CLI = 'somenonexistentcommand'
    d = DummyCLIMgr()
    assert not d.is_available()

# Generated at 2022-06-11 03:57:04.628890
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    assert PkgMgr.is_available(PkgMgr()) == NotImplementedError


# Generated at 2022-06-11 03:57:05.888637
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    test=CLIMgr()
    assert test.CLI is None


# Generated at 2022-06-11 03:57:10.593013
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    test_object = PkgMgr()
    test_object.is_available()
    test_object.list_installed()
    test_object.get_package_details('package')
    try:
        result = test_object.get_packages()
        # test passes, this code will never run
        assert False
    except NotImplementedError:
        assert True

# Generated at 2022-06-11 03:57:14.386547
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    import os
    import imp
    sys_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', '..', '..')
    imp.load_source('LibMgr', sys_path+'/library/package_mgr/LibMgr.py')
    from LibMgr import LibMgr
    test_lib = 'pkg_resources'
    test_libmgr = LibMgr()
    test_libmgr.LIB = test_lib
    assert test_libmgr.is_available() == True


# Generated at 2022-06-11 03:57:15.873110
# Unit test for constructor of class LibMgr
def test_LibMgr():
    """
    Test to see if LibMgr is a subclass of PkgMgr.
    """
    assert issubclass(LibMgr, PkgMgr)


# Generated at 2022-06-11 03:57:16.830398
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    assert PkgMgr.list_installed() != None
    pass


# Generated at 2022-06-11 03:57:24.082723
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():

    class FakeLibMgr(LibMgr):
        def is_available(self):
            return super(FakeLibMgr, self).is_available()

    test = FakeLibMgr()
    assert test.is_available() == False


# Generated at 2022-06-11 03:57:32.837535
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    try:
        from ansible.module_utils.common._collections_compat import Mapping
    except ImportError:
        from collections import Mapping
    from six import assertRaisesRegex
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.software_managers import PkgMgr
    module = AnsibleModule({}, supports_check_mode=True)
    pkg_mgr = PkgMgr()
    assertRaisesRegex(module, Exception, "Method get_package_details is not implemented") == assertRaisesRegex(module, Exception, pkg_mgr.get_package_details('python-pip'))

# Generated at 2022-06-11 03:57:41.436682
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    #mock object
    class object():
        pass

    #mock get_bin_path function
    def get_bin_path(cli):
        return 1
    get_bin_path.__name__ = "get_bin_path"

    cli = object()
    cli.CLI = "test"
    cli.get_bin_path = get_bin_path
    assert cli.is_available() == True

    #mock get_bin_path function
    def get_bin_path(cli):
        raise ValueError
    get_bin_path.__name__ = "get_bin_path"

    cli2 = object()
    cli2.CLI = "test"
    cli2.get_bin_path = get_bin_path

# Generated at 2022-06-11 03:57:43.056754
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class DummyCLIMgr(CLIMgr):
        CLI = 'doesnotexist'

    assert not DummyCLIMgr().is_available()

# Generated at 2022-06-11 03:57:45.201819
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestMgr(LibMgr):
        LIB = "sys"
    test_mgr = TestMgr()
    assert test_mgr.is_available()


# Generated at 2022-06-11 03:57:47.825136
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestLib(LibMgr):
        LIB = 'pkg_resources'
    assert TestLib().LIB == 'pkg_resources'

if __name__ == '__main__':
    test_LibMgr()

# Generated at 2022-06-11 03:57:49.489891
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():

    test_class = LibMgr()
    assert test_class.is_available() == False


# Generated at 2022-06-11 03:57:59.223558
# Unit test for method get_packages of class PkgMgr

# Generated at 2022-06-11 03:58:01.816885
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    lib_mgr = LibMgr()
    lib_mgr.list_installed()
    cli_mgr = CLIMgr()
    cli_mgr.list_installed()

# Generated at 2022-06-11 03:58:04.002202
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    from ansible.module_utils.common._facts_packages import Apt
    a = Apt()
    assert a.is_available()

# Generated at 2022-06-11 03:58:08.833560
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    class TestPkgMgr(PkgMgr):

        def is_available():
            pass
    TestPkgMgr.is_available()



# Generated at 2022-06-11 03:58:09.814576
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    assert isinstance(get_all_pkg_managers(), dict)

# Generated at 2022-06-11 03:58:17.917588
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class NPM(CLIMgr):
        CLI = 'npm'

    npm_mgr = NPM()
    # initially is_available should return False
    assert not npm_mgr.is_available()

    # check if is_available changes to True after running
    npm_mgr.is_available()
    assert isinstance(npm_mgr._cli, basestring)

    # check if you get an error if CLI does not exist
    class NPM_absent(CLIMgr):
        CLI = 'npm-absent'

    npm_absent_mgr = NPM_absent()
    assert not npm_absent_mgr.is_available()

# Generated at 2022-06-11 03:58:26.172947
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    import mock
    with mock.patch('ansible.module_utils.basic.AnsibleModule') as mock_AnsibleModule:
        with mock.patch('ansible.module_utils.basic.get_bin_path') as mock_get_bin_path:
            import datetime
            now = datetime.datetime.now()
            mock_get_bin_path.return_value = "Python"
            assert CLIMgr().is_available() == True
            mock_get_bin_path.return_value = None
            assert CLIMgr().is_available() == False


# Generated at 2022-06-11 03:58:28.788971
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    import sys

    if sys.version_info[0] < 3:
        pkg_mgr = CLIMgr()
        assert(pkg_mgr is not None)

# Generated at 2022-06-11 03:58:32.050892
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    pkg_mgr = PkgMgr()
    installed_packages = pkg_mgr.get_packages()
    assert(isinstance(installed_packages, dict))
    assert(not len(installed_packages))


# Generated at 2022-06-11 03:58:42.268158
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    class TestPkgMgr(PkgMgr):

        def list_installed(self):
            return ['test_package_a-1.0', 'test_package_b-1.0', 'test_package_a-1.1']

        def get_package_details(self, package):
            return {'name': package.split('-', 1)[0], 'version': package.split('-', 1)[1]}


# Generated at 2022-06-11 03:58:52.650634
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    is_available_result = {'toast': False, 'chicken': True, 'eggs': False, 'cheese': False}
    list_installed_results = {'chicken': ['chicken_dinner', 'chicken_supper']}
    get_package_details_result = {'chicken': {'name': 'chicken', 'version': '0.1'}}
    get_packages_result = {'chicken': [{'name': 'chicken', 'version': '0.1', 'source': 'chicken'}]}

    # stubs
    def test_is_available(self):
        return is_available_result[self.__class__.__name__]
    def test_list_installed(self):
        return list_installed_results[self.__class__.__name__]

# Generated at 2022-06-11 03:58:54.744166
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    try:
        import rpm
        assert(rpm != None)
        return True
    except ImportError:
        return False

# Generated at 2022-06-11 03:59:02.535680
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    from ansible.module_utils.common._collections_compat import Sequence
    class MockPkgMgr(PkgMgr):
        def is_available(self):
            self.is_available_called = True
            return True
        def list_installed(self):
            self.list_installed_called = True
            return ["pkg1", "pkg2"]
        def get_package_details(self, package):
            self.get_package_details_called = True
            return {"name": package, "version": "1"}

    a = MockPkgMgr()
    r = a.get_packages()
    assert a.is_available_called
    assert a.list_installed_called
    assert a.get_package_details_called
    assert isinstance(r, dict)

# Generated at 2022-06-11 03:59:07.682727
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    pm = PkgMgr()
    assert isinstance(pm.get_package_details(None), dict)

# Generated at 2022-06-11 03:59:09.356011
# Unit test for constructor of class CLIMgr
def test_CLIMgr():

    mgr = CLIMgr()
    assert mgr.CLI is None
    assert mgr._cli is None

# Generated at 2022-06-11 03:59:11.870182
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgr
    pkg = PkgMgr()
    assert(pkg.is_available() is False)

# Generated at 2022-06-11 03:59:20.300829
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    import os
    import unittest
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgr

    class TestPkgMgr(PkgMgr):

        def is_available(self):
            return True

        def list_installed(self):
            return [{'name': '0.1'}, {'name': '0.2'}, {'name': '0.3'}]

        def get_package_details(self, package):
            return {"name": package["name"]}

    class TestPkgMgrGetPackages(unittest.TestCase):
        def setUp(self):
            import sys

# Generated at 2022-06-11 03:59:24.057923
# Unit test for constructor of class CLIMgr
def test_CLIMgr():

    test1 = CLIMgr()
    test1.is_available()

    test2 = CLIMgr()
    test2.CLI = '/bin/false'
    test2.is_available()
    assert test2._cli is None


# Generated at 2022-06-11 03:59:25.188519
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pkgmgr = PkgMgr()
    assert pkgmgr.is_available() == False

# Generated at 2022-06-11 03:59:26.717339
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    yum = CLIMgr()
    assert yum.is_available() == True


# Generated at 2022-06-11 03:59:33.360772
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    import ansible.module_utils.os_package_manager.yum as yum
    yum_instance = yum.Yum()
    packages = yum_instance.get_packages()
    assert isinstance(packages, dict)
    for key, value in packages.items():
        assert isinstance(key, str)
        assert isinstance(value, list)


if __name__ == '__main__':
    # import sys
    # import pytest
    # pytest.main([__file__])
    test_PkgMgr_get_packages()
    sys.exit(0)

# Generated at 2022-06-11 03:59:36.278199
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    # Check that the method raises an exception when the class is not subclassed
    try:
        PkgMgr().get_packages()
    except NotImplementedError:
        pass
    else:
        assert False, "Expected an exception"

# Generated at 2022-06-11 03:59:37.833376
# Unit test for constructor of class CLIMgr
def test_CLIMgr():

    foo = CLIMgr()
    assert foo.CLI is None
    assert foo._cli is None


# Generated at 2022-06-11 03:59:54.374678
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class PkgMgrTest(PkgMgr):
        def __init__(self):
            super(PkgMgrTest, self).__init__()
        def is_available(self):
            return True
        def list_installed(self):
            return [{'name': 'a'}, {'name': 'a'}, {'name': 'b'}, {'name': 'c'}]
        def get_package_details(self, package):
            return {'name': package['name'], 'version': '1.0.0'}

    pkg_mgr_test = PkgMgrTest()

# Generated at 2022-06-11 03:59:55.888688
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    obj = LibMgr()
    assert obj.is_available() == False


# Generated at 2022-06-11 03:59:57.457897
# Unit test for constructor of class LibMgr
def test_LibMgr():
    pkg = LibMgr()
    assert isinstance(pkg, PkgMgr)


# Generated at 2022-06-11 04:00:06.828830
# Unit test for constructor of class CLIMgr
def test_CLIMgr():

    from ansible.module_utils.package_management.yum import Yum
    from ansible.module_utils.package_management.dnf import DNF
    from ansible.module_utils.package_management.apt import Apt
    from ansible.module_utils.package_management.apk import Apk
    from ansible.module_utils.package_management.chocolatey import Chocolatey
    from ansible.module_utils.package_management.eopkg import EOPKG
    from ansible.module_utils.package_management.pacman import Pacman
    from ansible.module_utils.package_management.pkg5 import Pkg5
    from ansible.module_utils.package_management.pkgng import Pkgng
    from ansible.module_utils.package_management.portage import Portage

# Generated at 2022-06-11 04:00:12.490188
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():

    pkg_manager_dict = get_all_pkg_managers()
    assert isinstance(pkg_manager_dict, dict), "Returned variable is not a dictionary."
    assert len(pkg_manager_dict) > 0, "Dictionary is empty."
    for item in pkg_manager_dict:
        assert len(item) > 0, "Item in the dictionary has zero length."
        assert pkg_manager_dict[item] is not None, "No class specified for %s package manager." % (item)

# Generated at 2022-06-11 04:00:21.266402
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    import unittest
    import sys

    if sys.version_info[0] == 2:
        import mock
    else:
        from unittest import mock

    class TestPkgMgr(PkgMgr):

        def is_available(self):
            return True

        def list_installed(self):
            return ["name1", "name2", "name3"]

        def get_package_details(self, package):
            return {"name": package, "version": "0"}

    class TestCLIMgr(CLIMgr):

        CLI = "test"

        def is_available(self):
            return True

        def list_installed(self):
            return ["name1", "name2", "name3"]


# Generated at 2022-06-11 04:00:23.103772
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    p = PkgMgr()
    assert p.is_available() == False


# Generated at 2022-06-11 04:00:24.877453
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class LibTest(LibMgr):
        LIB = 'distro'

    x = LibTest()
    if x.is_available():
        print('is available')
    else:
        print('not available')


# Generated at 2022-06-11 04:00:25.443378
# Unit test for constructor of class LibMgr
def test_LibMgr():
    LibMgr()


# Generated at 2022-06-11 04:00:29.475400
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    test_cli_mgr = CLIMgr()
    assert test_cli_mgr.is_available() == False
    test_cli_mgr.CLI = 'not_a_real_cli'
    assert test_cli_mgr.is_available() == False
    test_cli_mgr.CLI = 'echo'
    assert test_cli_mgr.is_available() == True

# Generated at 2022-06-11 04:00:48.429030
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    '''
    Test cases for method is_available of class CLIMgr
    :return: None
    '''
    a = CLIMgr()

    # case 1: when command is not found
    a.CLI = "nonexistent"
    assert not a.is_available()

    # case 2: when command is found
    a.CLI = "/bin/ls"
    assert a.is_available()

# Generated at 2022-06-11 04:00:49.876507
# Unit test for constructor of class LibMgr
def test_LibMgr():
    
    p = LibMgr()
    assert p._lib is None


# Generated at 2022-06-11 04:00:51.376066
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    c = CLIMgr()
    c.CLI = 'which'
    return c.is_available()


# Generated at 2022-06-11 04:00:54.202319
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestLibMgr(LibMgr):
        LIB = 'test_lib_name'

    m = TestLibMgr()
    assert m._lib is None
    assert m.is_available() is False



# Generated at 2022-06-11 04:00:56.165713
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    mgr = CLIMgr()
    assert mgr is not None
    assert mgr.is_available() is False


# Generated at 2022-06-11 04:00:57.943279
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    for mgr in get_all_pkg_managers().values():
        assert mgr().is_available() is not None


# Generated at 2022-06-11 04:00:58.412628
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pass

# Generated at 2022-06-11 04:01:01.505356
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    class Test(CLIMgr):
        CLI = "test"
  
    cmd = get_bin_path(Test.CLI)
    t = Test()
    # Test if CLI is set
    assert Test.CLI == "test"
    # Test is_available method
    assert t.is_available()
    # Test if CLI is found within is_available method
    assert t._cli == cmd 


# Generated at 2022-06-11 04:01:02.824447
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    assert PkgMgr().is_available() is True


# Generated at 2022-06-11 04:01:08.724671
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    import subprocess
    solution= "Error while running tests: Command '['/usr/bin/pkg-config', '--version']' returned non-zero exit status 1"
    try:
        subprocess.check_output(['/usr/bin/pkg-config','--version'], universal_newlines=True, stderr = subprocess.STDOUT)
        assert True
    except subprocess.CalledProcessError as e:
        assert e.output == solution

# Generated at 2022-06-11 04:01:39.649008
# Unit test for constructor of class LibMgr
def test_LibMgr():
    obj = LibMgr()
    assert hasattr(obj, 'is_available')
    assert hasattr(obj, '_lib')
    assert not obj.is_available()


# Generated at 2022-06-11 04:01:40.742433
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    assert PkgMgr.is_available() is False


# Generated at 2022-06-11 04:01:43.381851
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    class CLIForTesting(CLIMgr):
        ''' This class for testing purpose '''
        CLI = "cli"
    try:
        CLIForTesting()
        assert False
    except Exception as e:
        assert isinstance(e, TypeError)

# Generated at 2022-06-11 04:01:45.040906
# Unit test for constructor of class LibMgr
def test_LibMgr():
    pm_class = LibMgr()
    pm_class._lib = 'a'
    assert pm_class._lib == 'a'


# Generated at 2022-06-11 04:01:47.373132
# Unit test for constructor of class LibMgr
def test_LibMgr():
    test_libmgr = LibMgr()
    assert test_libmgr._lib is None
    test_libmgr.is_available()
    assert test_libmgr._lib is not None


# Generated at 2022-06-11 04:01:49.099619
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    pm = PkgMgr()
    package_details = pm.get_package_details('package')
    assert not package_details


# Generated at 2022-06-11 04:01:56.322423
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    from ansible.module_utils.common.process import get_bin_path
    import ansible
    import os
    import unittest
    class Test_LibMgr_is_available(unittest.TestCase):
        def test_returnValue(self):
            from ansible.module_utils.pkginst import LibMgr

            lib_mgr_obj = LibMgr()
            lib_mgr_obj.LIB = 'ansible'
            self.assertEqual(lib_mgr_obj.is_available(), True)
            lib_mgr_obj.LIB = 'ansible_test'
            self.assertEqual(lib_mgr_obj.is_available(), False)
            self.assertEqual(hasattr(lib_mgr_obj, '_lib'), True)

    unittest.main

# Generated at 2022-06-11 04:01:58.853101
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    pkg_mgrs = get_all_pkg_managers()
    assert sorted(pkg_mgrs.keys()) == sorted(['apt_get', 'dnf', 'yum', 'pacman'])

# Generated at 2022-06-11 04:01:59.857087
# Unit test for constructor of class LibMgr
def test_LibMgr():
    assert LibMgr.__name__ == 'LibMgr'


# Generated at 2022-06-11 04:02:05.101623
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    cmd = 'x'
    cm = CLIMgr()
    cm.CLI = cmd

    # temporary file does not exist
    assert cm.is_available() == False

    # temporary file exists
    with open('/tmp/test_cli_mgr_is_available', 'w') as f:
        f.write('')
    try:
        assert cm.is_available() == True
    finally:
        os.remove('/tmp/test_cli_mgr_is_available')

# Generated at 2022-06-11 04:03:06.713059
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pass

# Generated at 2022-06-11 04:03:08.222859
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    assert (PkgMgr.list_installed(PkgMgr)) == NotImplemented


# Generated at 2022-06-11 04:03:14.574609
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class MockListInstalled(PkgMgr):

        def __init__(self, *args, **kwargs):
            PkgMgr.__init__(self, *args, **kwargs)
            self.package_list = ['pkg1', 'pkg2']

        def list_installed(self):
            return self.package_list

        def get_package_details(self, package):
            return {'name': 'pkg1'}

    test = MockListInstalled()
    assert test.get_packages() == {'pkg1': [{'name': 'pkg1', 'source': 'mocklistinstalled'}]}

# Generated at 2022-06-11 04:03:16.316711
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    # a valid command should return True
    assert CLIMgr().is_available() == True


# Generated at 2022-06-11 04:03:25.098857
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    # Dummy classes
    class P(PkgMgr):
        def is_available(self):
            return True

    class P1(P):
        def list_installed(self):
            return ['a', 'b', 'c']

    class P2(P):
        def list_installed(self):
            return ['a', 'b', 'c', 'c', 'd']

    class P3(P):
        def list_installed(self):
            return ['1', '2', '3', '4', '5']

    class P4(P):
        def list_installed(self):
            return ['a', 'b', 'c', '1', '2']

    class P5(P):
        def list_installed(self):
            return ['1', '2', '3']


# Generated at 2022-06-11 04:03:32.064482
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class PkgMgrTest(PkgMgr):

        def is_available(self):
            return True

        def list_installed(self):
            return ['aaa', 'bbb']

        def get_package_details(self, package):
            return {'name': package + '_name', 'version': '1.0'}

    pmt = PkgMgrTest()
    packages = pmt.get_packages()
    assert 'aaa_name' in packages
    assert 'bbb_name' in packages
    assert packages['aaa_name'][0]['source'] == 'pkgmgrtest'
    assert packages['bbb_name'][0]['source'] == 'pkgmgrtest'

# Generated at 2022-06-11 04:03:40.475940
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    import datetime

    class MyPkgMgr(PkgMgr):
        def list_installed(self):
            return ['PackageA', 'PackageB', 'PackageC']


# Generated at 2022-06-11 04:03:42.715751
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    class TestPkgMgr(CLIMgr):
        CLI = 'dummy'
    temp = TestPkgMgr()
    assert isinstance(temp, CLIMgr)
    assert temp._cli is None

# Generated at 2022-06-11 04:03:45.182256
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    try:
        cli = get_bin_path('bash')
        return True
    except ValueError:
        return False

if __name__ == '__main__':
    print(CLIMgr.is_available(CLIMgr()))

# Generated at 2022-06-11 04:03:46.986048
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    manager = CLIMgr()
    assert manager._cli is None
    assert manager.is_available() is True


# Generated at 2022-06-11 04:06:41.104467
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCliMgr(CLIMgr):
        CLI = "cat"
    
    cat_cli = TestCliMgr()
    assert cat_cli.is_available() is True

    class TestCliMgr(CLIMgr):
        CLI = "badcli"

    bad_cli = TestCliMgr()
    assert bad_cli.is_available() is False

    class TestCliMgr(CLIMgr):
        CLI = "badcli"

    bad_cli_2 = TestCliMgr()
    assert bad_cli_2.is_available() is False


# Generated at 2022-06-11 04:06:45.858024
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():

    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['pkg1','pkg2','pkg3']
        def get_package_details(self, package):
            return {'name': package, 'version': '1.0.1'}

    testpkgmgr = TestPkgMgr()
    lst = testpkgmgr.list_installed()
    assert(lst == [])
