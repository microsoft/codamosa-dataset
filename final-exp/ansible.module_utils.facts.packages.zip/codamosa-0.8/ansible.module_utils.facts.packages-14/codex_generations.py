

# Generated at 2022-06-11 03:56:49.176323
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    class TestCliMgr(CLIMgr):
        CLI = 'abc'
    assert TestCliMgr()._cli is None



# Generated at 2022-06-11 03:56:59.778226
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class MockPkgMgr(PkgMgr):

        def is_available():
            return True

        def list_installed():
            return ['list_installed_1', 'list_installed_2']

        def get_package_details(package):
            if package == 'list_installed_1':
                return {'name': 'mock_name1', 'version': '1.0'}
            return {'name': 'mock_name2', 'version': '2.0'}
    mock_pkgmgr = MockPkgMgr()

# Generated at 2022-06-11 03:57:09.348187
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    from ansible.module_utils.facts.packages.pkg_mgr import get_all_pkg_managers
    from ansible.module_utils.facts.packages.pkg_mgr import _COMMUNITY_PACKAGE_MANAGERS_MOCK as COMMUNITY_PACKAGE_MANAGERS_MOCK

    pkg_mgrs = get_all_pkg_managers()
    for mgr in pkg_mgrs:
        if mgr in COMMUNITY_PACKAGE_MANAGERS_MOCK:
            pkg_mgrs[mgr].list_installed = _generate_list_installed_mock(mgr)
            pkg_mgrs[mgr].get_package_details = _generate_get_package_details(mgr)

# Generated at 2022-06-11 03:57:13.566528
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    try:
        class TestPkgMgr(PkgMgr):
            def list_installed(self):
                return ["aaa", "bbb", "ccc"]
        test = TestPkgMgr()
        assert test.list_installed() == ["aaa", "bbb", "ccc"]
    except Exception as e:
        raise


# Generated at 2022-06-11 03:57:19.365905
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    from ansible.module_utils.common.text.converters import to_native
    Mgr = PkgMgr()
    name_version = '(test_text)'
    name = '(test_text)'
    version = ''
    package = {'name': name, 'version': version}
    try:
        Mgr.get_package_details(package)
    except NotImplementedError:
        pass
    else:
        raise AssertionError(to_native("'get_package_details' method is not properly implemented."))


# Generated at 2022-06-11 03:57:20.256257
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    assert True == False


# Generated at 2022-06-11 03:57:27.034678
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    # Create a LibMgr instance
    libmgr_1 = LibMgr()
    # Assign the LIB variable with a valid python library
    libmgr_1.LIB = 'os'
    assert libmgr_1.is_available() == True
    # Assign the LIB variable with an invalid python library
    libmgr_1.LIB = 'xyz'
    assert libmgr_1.is_available() == False


# Generated at 2022-06-11 03:57:29.909892
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    cm = CLIMgr()
    assert(cm.CLI is None)
    assert(cm._cli is None)
    assert(isinstance(cm, PkgMgr))


# Generated at 2022-06-11 03:57:39.127206
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    import unittest

    class TestPkgMgr(PkgMgr):

        def is_available(self):
            return False

        def list_installed(self):
            return []

        def get_package_details(self, package):
            pass

    class TestPkgMgr1(TestPkgMgr):

        def get_package_details(self, package):
            return {
                'name':'test',
                'version':'1.0'
            }

    class TestPkgMgr2(TestPkgMgr):

        def get_package_details(self, package):
            return {
                'name':'test',
                'version':'2.0',
                'source':'test'
            }


# Generated at 2022-06-11 03:57:40.111099
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pkgmgr = PkgMgr()
    assert pkgmgr.is_available() is False


# Generated at 2022-06-11 03:57:47.867631
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class CLIMgrTester(CLIMgr):
        pass
    CLIMgrTester.CLI = 'dummy'
    climgr = CLIMgrTester()
    if climgr.is_available():
        assert (climgr._cli is not None)
    else:
        assert (climgr._cli is None)

# Generated at 2022-06-11 03:57:49.537013
# Unit test for constructor of class LibMgr
def test_LibMgr():
    assert LibMgr() != None
    assert PkgMgr() != None


# Generated at 2022-06-11 03:57:51.649790
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pkg_mgr = PkgMgr()
    assert pkg_mgr.list_installed() == NotImplemented


# Generated at 2022-06-11 03:57:52.962861
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    a = CLIMgr()
    assert a


# Generated at 2022-06-11 03:57:54.339121
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    lib = LibMgr()
    assert lib.is_available() == False

# Generated at 2022-06-11 03:57:57.219991
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class MockLibMgr(LibMgr):
        LIB = 'os'

    mock_LibMgr = MockLibMgr()
    assert mock_LibMgr.is_available()

# Generated at 2022-06-11 03:57:58.329893
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    CLIMgr().is_available()


# Generated at 2022-06-11 03:58:00.346115
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class Child(PkgMgr):
        pass

    token = Child()
    assert not token.get_package_details('package')

# Generated at 2022-06-11 03:58:04.848908
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    lib_list = [
        'platform', 'rpm', 'pip',
    ]
    for lib_mgr in lib_list:
        lib = __import__('ansible.module_utils.common.packages.' + lib_mgr)
        getattr(lib, lib_mgr).is_available()


# Generated at 2022-06-11 03:58:13.076974
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    from ansible.module_utils.common.package_manager.pkgutil import PkgUtil
    from ansible.module_utils.common.package_manager.yumpkg import YumPkg
    from ansible.module_utils.common.package_manager.aptpkg import AptPkg
    from ansible.module_utils.common.package_manager.zypperpkg import ZypperPkg
    from ansible.module_utils.common.package_manager.pkg5pkg import Pkg5Pkg
    from ansible.module_utils.common.package_manager.portpkg import PortPkg
    from ansible.module_utils.common.package_manager.pacmanpkg import PacmanPkg

    pkg_util = PkgUtil()

# Generated at 2022-06-11 03:58:22.885436
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class Test(LibMgr):
        LIB = 'ansible'

    test = Test()
    assert id(test) == id(test)


# Generated at 2022-06-11 03:58:33.110746
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    # test classes
    class TestPkgMgr1(PkgMgr):

        def is_available(self):
            return True

        def list_installed(self):
            return ['p1', 'p2', 'p3']

        def get_package_details(self, package):
            return {
                'name': package,
                'version': '1.0',
            }

    class TestPkgMgr2(PkgMgr):

        def is_available(self):
            return True

        def list_installed(self):
            return ['p1']

        def get_package_details(self, package):
            return {
                'name': package,
                'version': '1.0',
            }


# Generated at 2022-06-11 03:58:33.739160
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    pass

# Generated at 2022-06-11 03:58:41.480097
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    # 1st test with a real command (available)
    class TestCLIMgr(CLIMgr):
        CLI='ls'

    mytest1=TestCLIMgr()
    assert mytest1.is_available()
    assert isinstance(mytest1._cli, str)

    # 2nd test with a command not available
    class Test2CLIMgr(CLIMgr):
        CLI='notexistingcommand'

    mytest2 = Test2CLIMgr()
    assert not mytest2.is_available()
    assert mytest2._cli is None



# Generated at 2022-06-11 03:58:51.855097
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    class TestPkgMgr(PkgMgr):

        def is_available(self):
            return True

        def list_installed(self):
            return [1, 2]

        def get_package_details(self, package):
            return {'name': str(package).lower(), 'version': '1.0', 'arch': 'x86_64'}

    pkgmgr = TestPkgMgr()
    result = pkgmgr.get_packages()
    assert result == {'1': [{'name': '1', 'version': '1.0', 'arch': 'x86_64', 'source': 'testpkgmgr'}],
                      '2': [{'name': '2', 'version': '1.0', 'arch': 'x86_64', 'source': 'testpkgmgr'}]}

# Generated at 2022-06-11 03:58:55.421195
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    expected_output = {'name': 'test_package_name',
                       'version': 'test_package_version'}
    actual_output = PkgMgr.get_package_details('test_package_name')
    assert expected_output == actual_output


# Generated at 2022-06-11 03:59:02.905010
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    from ansible.module_utils.facts.system.pkg_mgr.pkg_mgr import CLIMgr

    class MyCLIMgr(CLIMgr):
        CLI = "mycli"
    pkg_mgr = MyCLIMgr()

    # Mock the get_bin_path function
    test_get_bin_path = {
        "mycli": "mycli/path"
    }
    def fake_get_bin_path(program):
        return test_get_bin_path[program]
    pkg_mgr.get_bin_path = fake_get_bin_path

    # Test the is_available function
    assert pkg_mgr.is_available() == True


# Generated at 2022-06-11 03:59:07.131167
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    # Test case when list contains packages and None
    pkgmgr = PkgMgr()
    pkgmgr.list_installed = list()
    assert isinstance(pkgmgr.list_installed, list)

    # Test case when list is empty
    pkgmgr.list_installed.clear()
    assert isinstance(pkgmgr.list_installed, list)


# Generated at 2022-06-11 03:59:16.331362
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TmpPkgMgr(PkgMgr):
        def is_available(self):
            return True

        def list_installed(self):
            return ['package_mock', 'other_package_mock']

        def get_package_details(self, package):
            if package == 'package_mock':
                return {'name': 'package_mock', 'version': '1.1.1'}
            return {'name': 'other_package_mock', 'version': '1.1.1'}

    pkg_mgr = TmpPkgMgr()

# Generated at 2022-06-11 03:59:17.714842
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():

    class DummyLibMgr(LibMgr):
        LIB = 'dummy_lib'

    mgr = DummyLibMgr()
    assert mgr.is_available() == False


# Generated at 2022-06-11 03:59:32.992181
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    # TODO
    pass


# Generated at 2022-06-11 03:59:41.841892
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    import platform
    import re
    import os
    import sys

    # PkgMgr is an abstract class so we need to create a child class and instantiate it
    class TestPkgMgr(PkgMgr):
        def __init__(self):
            super(PkgMgr, self).__init__()
        def is_available(self):
            return True
        def list_installed(self):
            return [{'name':'module_utils/common/network/module_utils/network_lsb',
                     'version':platform.python_version()}]
        def get_package_details(self, package):
            return {'name':package['name'], 'version':package['version']}

    class TestPkgMgr_Wrong(PkgMgr):
        def __init__(self):
            super

# Generated at 2022-06-11 03:59:43.338926
# Unit test for constructor of class LibMgr
def test_LibMgr():
    lib_mgr = LibMgr()
    assert lib_mgr

# Generated at 2022-06-11 03:59:46.683136
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    # Positive test
    expected = True
    actual = PkgMgr().is_available()
    assert expected == actual
    # Negative test
    expected = False
    actual = PkgMgr().is_available()
    assert expected == actual

# Generated at 2022-06-11 03:59:47.914849
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    assert LibMgr().is_available() is False


# Generated at 2022-06-11 03:59:48.754686
# Unit test for constructor of class LibMgr
def test_LibMgr():
    lm = LibMgr()
    assert lm

# Generated at 2022-06-11 03:59:49.937934
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    package_details = PkgMgr().get_package_details("")


# Generated at 2022-06-11 03:59:59.481963
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():

    # Mock a PkgMgr class that inherits from LibMgr
    class MockLibMgr(LibMgr):

        LIB = 'sys'

        def __init__(self):
            self.is_available_returned = None
            super(MockLibMgr, self).__init__()

        def is_available(self):
            self.is_available_returned = super(MockLibMgr, self).is_available()
            return self.is_available_returned

    # Object with LIB not available
    mock_obj_no_lib = MockLibMgr()

    # Object with LIB available
    mock_obj_lib = MockLibMgr()

    # Call is_available() on mock_obj_no_lib (LIB not available)
    assert mock_obj_no_lib.is_available() is False



# Generated at 2022-06-11 04:00:09.038433
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class PkgMgrImpl(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['pkg1', 'pkg2', 'pkg3', 'pkg1']
        def get_package_details(self, package):
            return {'name': package}
    pm = PkgMgrImpl()
    assert pm.get_packages() == {'pkg1': [{'name': 'pkg1', 'source': 'pkgmgrimpl'}, {'name': 'pkg1', 'source': 'pkgmgrimpl'}], 'pkg2': [{'name': 'pkg2', 'source': 'pkgmgrimpl'}], 'pkg3': [{'name': 'pkg3', 'source': 'pkgmgrimpl'}]}


# Generated at 2022-06-11 04:00:11.563087
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    class TestCLIMgr(CLIMgr):
        CLI = "test_cli"

    mgr = TestCLIMgr()
    assert mgr.CLI == 'test_cli'
    assert mgr._cli == None

# Generated at 2022-06-11 04:00:43.063211
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCLIMgr(CLIMgr):
        CLI = "ls"

    t = TestCLIMgr()
    assert t.is_available()

# Generated at 2022-06-11 04:00:44.318077
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    assert CLIMgr().is_available() is False


# Generated at 2022-06-11 04:00:46.786819
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCLIMgr(CLIMgr):
        CLI = 'foo'
    lib_mgr = TestCLIMgr()
    assert lib_mgr.is_available() is False


# Generated at 2022-06-11 04:00:48.409257
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    assert PkgMgr.list_installed() == "Not Implemented"


# Generated at 2022-06-11 04:00:49.836629
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    assert PkgMgr().is_available() == NotImplementedError


# Generated at 2022-06-11 04:00:53.958737
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class MockPkgMgr(PkgMgr):
        def is_available(self):
            return False

        def list_installed(self):
            return ['package1', 'package2']

    with pytest.raises(NotImplementedError):
        p = MockPkgMgr()
        p.get_package_details('package1')


# Generated at 2022-06-11 04:00:55.224563
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr()._cli is None


# Generated at 2022-06-11 04:00:59.661957
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    is_available_return_value = [{'name': 'ansible'}, {'name': 'python'}]
    PkgMgr.list_installed = lambda x: is_available_return_value
    is_available_return_value = [{'name': 'ansible'}, {'name': 'python'}]
    assert PkgMgr.list_installed({}) == is_available_return_value


# Generated at 2022-06-11 04:01:04.149634
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    # Create a mock class
    p = PkgMgr()
    assert p.is_available() == False
    # Now, create a mock class that returns both true and false
    p2 = PkgMgr()
    p2.is_available = lambda : True
    assert p2.is_available() == True


# Generated at 2022-06-11 04:01:10.237397
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():

    class TestCLIMgr(CLIMgr):
        CLI = 'test'

    # case of CLI executable available
    test_CLIMgr1 = TestCLIMgr()
    assert test_CLIMgr1.is_available() is True

    # case of CLI executable not available
    class TestCLIMgr2(CLIMgr):
        CLI = 'test_not'

    test_CLIMgr2 = TestCLIMgr2()
    assert test_CLIMgr2.is_available() is False

# Generated at 2022-06-11 04:02:24.601169
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    pkgmgr = PkgMgr()
    pkgmgr.__class__.__dict__.update({
        'is_available': lambda self: True,
        'list_installed': lambda self: ['package1', 'package2'],
        'get_package_details': lambda self, package: {'name': package, 'version': '1.0'},
    })
    assert pkgmgr.get_packages() == {'package1': [{'version': '1.0', 'name': 'package1', 'source': 'pkgmgr'}],
                                     'package2': [{'version': '1.0', 'name': 'package2', 'source': 'pkgmgr'}]}

# Generated at 2022-06-11 04:02:32.726003
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    # defined a derived class of PkgMgr
    class MyPkgMgr(PkgMgr):
        pass

    # define the two required abstract methods of PkgMgr
    def list_installed(self):
        return [1, 2, 3]
    MyPkgMgr.list_installed = list_installed

    def get_package_details(self, package):
        return {'name': package}
    MyPkgMgr.get_package_details = get_package_details

    # get the packages and test them
    my_pkg_mgr = MyPkgMgr()
    packages = my_pkg_mgr.get_packages()
    assert len(packages) == 3

# Generated at 2022-06-11 04:02:36.157924
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    mgr1 = CLIMgr()
    mgr1.CLI = 'ls'
    assert mgr1.is_available()

    mgr2 = CLIMgr()
    mgr2.CLI = 'doesntexists'
    assert not mgr2.is_available()



# Generated at 2022-06-11 04:02:45.379523
# Unit test for constructor of class LibMgr
def test_LibMgr():

    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.facts import profiler

    cls = LibMgr()

    assert hasattr(cls, '_lib')
    assert isinstance(cls._lib, type(None))
    assert isinstance(cls, PkgMgr)
    assert isinstance(cls, object)

    assert hasattr(cls, 'is_available')
    assert callable(getattr(cls, 'is_available', None))

    assert hasattr(cls, 'list_installed')
    assert callable(getattr(cls, 'list_installed', None))

    assert hasattr(cls, 'get_package_details')

# Generated at 2022-06-11 04:02:48.363190
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():

    assert CLIMgr().is_available() == False
    # change implementation of is_available
    CLIMgr().is_available = lambda: False
    assert CLIMgr().is_available() == False

# Generated at 2022-06-11 04:02:51.958305
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    # Sample importable library
    library = 'json'

    # Instantiate an object of class LibMgr with sample library
    lib = LibMgr()

    # Check if the object is available
    print(lib.is_available())
    return True


# Generated at 2022-06-11 04:02:53.891841
# Unit test for constructor of class LibMgr
def test_LibMgr():

    class MockLibMgr(LibMgr):
        pass

    a = MockLibMgr()
    assert a._lib is None


# Generated at 2022-06-11 04:02:55.513373
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    self = CLIMgr()
    assert self.is_available() == False


# Generated at 2022-06-11 04:02:56.395762
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr().CLI is None

# Generated at 2022-06-11 04:02:57.486513
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    mgr = CLIMgr()
    assert mgr._cli is None

# Generated at 2022-06-11 04:05:51.938433
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    import mock
    import os

    test_path = '/usr/bin/apt'
    test_path_not_found = '__bad__'
    test_class_cli = 'apt'

    with mock.patch.object(os.path, 'exists', return_value=True):
        test_obj = CLIMgr()
        test_obj.CLI = test_class_cli
        test_obj.is_available()

    with mock.patch.object(os.path, 'exists', return_value=False):
        test_obj = CLIMgr()
        test_obj.CLI = test_class_cli
        test_obj.is_available()


# Generated at 2022-06-11 04:05:54.071336
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    assert LibMgr.is_available(LibMgr)


# Generated at 2022-06-11 04:06:02.866374
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    from ansible.module_utils import facts_hash

    pkg_mgr_obj = PkgMgr()
    pkg_mgr_obj.list_installed = lambda: ['pkg1', 'pkg2']
    pkg_mgr_obj.get_package_details = lambda x: {'name': x, 'version': '1.0', 'source': 'PkgMgr'}
    installed_pkgs = pkg_mgr_obj.get_packages()

    assert len(installed_pkgs) == 2
    assert 'pkg1' in installed_pkgs
    assert len(installed_pkgs['pkg1']) == 1
    assert installed_pkgs['pkg1'][0] == {'name': 'pkg1', 'version': '1.0', 'source': 'PkgMgr'}
    assert facts_

# Generated at 2022-06-11 04:06:04.509268
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    mgr = CLIMgr()
    assert mgr.is_available() == True


# Generated at 2022-06-11 04:06:05.768438
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pkg = PkgMgr()
    pkg.list_installed()
    assert True

# Generated at 2022-06-11 04:06:07.276882
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():

    assert (PkgMgr.is_available("echo")) == False


# Generated at 2022-06-11 04:06:08.592905
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    assert PkgMgr.get_package_details(None) is None

# Generated at 2022-06-11 04:06:15.549780
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    from ansible.module_utils.common._text import to_text

    class PkgMgrFaked(PkgMgr):
        def is_available(self):
            return True

        def list_installed(self):
            return {'installed_pkgs': ['pkg1', 'pkg2', 'pkg3']}

        def get_package_details(self, package):
            if package == 'pkg2':
                raise Exception('Package %s not found' % package)
            return {'name': package, 'version': '1.0'}

    packages = {}
    pkg_mgr = PkgMgrFaked()
    packages = pkg_mgr.get_packages()
    assert len(packages) == 3, to_text(packages)
    assert 'pkg1' in packages and 'pkg3' in packages, to_

# Generated at 2022-06-11 04:06:17.989213
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    try:
        assert("not implemented" == PkgMgr.list_installed())
    except AssertionError:
        raise AssertionError("Method list_installed() of class PkgMgr is not implemented")



# Generated at 2022-06-11 04:06:21.701024
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    # When the package manager installed,
    # the list_installed method should return the installed packages list.
    class PkgMgrChild(PkgMgr):
        def list_installed(self):
            return ["foo", "bar"]

    pm = PkgMgrChild()
    assert pm.list_installed() == ["foo", "bar"]

