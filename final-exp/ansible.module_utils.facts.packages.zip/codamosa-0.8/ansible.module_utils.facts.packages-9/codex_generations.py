

# Generated at 2022-06-11 03:56:49.512891
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    obj = CLIMgr()
    # Checking expected vars got initialized
    assert obj._cli == None


# Generated at 2022-06-11 03:56:59.687474
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():

    class TestLibMgr(LibMgr):

        LIB = "test_LibMgr_is_available"

    import sys
    import imp

    expected_result = False
    test_mgr = TestLibMgr()
    assert test_mgr.is_available() == expected_result

    # Create the test module
    sys.modules["test_LibMgr_is_available"] = imp.new_module("test_LibMgr_is_available")

    expected_result = True
    assert test_mgr.is_available() == expected_result

    # Delete the test module
    del sys.modules["test_LibMgr_is_available"]

    expected_result = False
    assert test_mgr.is_available() == expected_result


# Generated at 2022-06-11 03:57:04.194961
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    #import pdb; pdb.set_trace()
    pkgmgr = CLIMgr()
    assert pkgmgr.is_available() == False
    class Dummy_CLIMgr(CLIMgr):
        CLI = 'test'
    dummy = Dummy_CLIMgr()
    assert dummy.is_available() == True

# Generated at 2022-06-11 03:57:06.077889
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():

    libs = ['ansible', 'ldap']
    for lib in libs:
        class TestLibMgr(LibMgr):
            LIB = lib

        mgr = TestLibMgr()
        assert mgr.is_available()



# Generated at 2022-06-11 03:57:13.279087
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    import mock
    from ansible.module_utils.facts.packages import PkgMgr

    # create a mock class with a mock get_package_details
    class PkgMgrMock(PkgMgr):
        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}

    # create an instance of the mock class and run the method
    pm = PkgMgrMock()
    result = pm.get_package_details('testpackage')
    assert result == {'name': 'testpackage', 'version': '1.0'}



# Generated at 2022-06-11 03:57:15.036062
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pkgmgr = PkgMgr()
    assert not pkgmgr.is_available()


# Generated at 2022-06-11 03:57:24.082712
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    from ansible.module_utils.common._collections_compat import Sequence
    # mock python-apt library for this test
    mock_apt = Sequence()
    # Let's patch builtin '__import__' function
    mock_builtin_import = Sequence()
    # Let's patch python-apt library
    mock_apt_Module = Sequence()
    mock_apt_Module.__name__ = 'apt'

    # mock python-apt module
    mock_apt_Module.cache = Sequence()
    mock_apt_Module.cache.Cache = Sequence()

    mock_apt_Module.package = Sequence()
    mock_apt_Module.package.Version = '1.1.1'

    mock_builtin_import.return_value = mock_apt_Module
    # patch builtin __import__ with custom one
    mock_LibMgr

# Generated at 2022-06-11 03:57:27.870905
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pkg_mgr = PkgMgr()
    result = pkg_mgr.is_available()
    assert result is None, "PkgMgr is_available should not be implemented in PkgMgr class"


# Generated at 2022-06-11 03:57:37.278890
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    test_PkgMgr = PkgMgr()
    test_PkgMgr.list_installed = lambda: [1, 2, 3]
    test_PkgMgr.get_package_details = lambda x: {'name': 'pkg' + str(x), 'version': x, 'source': 'my_source'}
    packages = test_PkgMgr.get_packages()
    assert isinstance(packages, dict)
    assert len(packages) == 1
    name = list(packages.keys())[0]
    assert name == "pkg1"
    packages = packages[name]
    assert isinstance(packages, list)
    for package in packages:
        assert isinstance(package, dict)
        assert 'name' in package
        assert 'version' in package
        assert 'source' in package

# Generated at 2022-06-11 03:57:38.081838
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():

    test_instance = LibMgr()
    assert test_instance.is_available() == False


# Generated at 2022-06-11 03:57:45.224703
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    pgm = PkgMgr()
    pgm.is_available =  lambda : True
    pgm.list_installed = lambda: ['test_package']
    assert(pgm.get_package_details('test_package')['name'] == 'test_package')
    assert('version' in pgm.get_package_details('test_package'))
    assert('arch' in pgm.get_package_details('test_package'))
    assert('source' in pgm.get_package_details('test_package'))


# Generated at 2022-06-11 03:57:47.187781
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    class FakeCLIMgr(CLIMgr):
        CLI = "fake-cli"

    assert FakeCLIMgr()

# Generated at 2022-06-11 03:57:48.803851
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    pkgmgr=CLIMgr()
    assert pkgmgr.is_available == False

# Generated at 2022-06-11 03:57:52.332646
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    gt = LibMgr()
    def __import__(name, globals=None, locals=None, fromlist=None, level=-1):
        raise ImportError()
    __import__ = gt.is_available

    assert __import__('dummy') == False


# Generated at 2022-06-11 03:58:02.264034
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True

        def list_installed(self):
            return ['package1', 'package2']

        def get_package_details(self, package):
            if (package == 'package1'):
                return {'name': package, 'version': '1.0.0', 'source': 'source1'}
            elif (package == 'package2'):
                return {'name': package, 'version': '2.0.0', 'source': 'source2'}
            else:
                return {'name': package}

    pkg_mgr = TestPkgMgr()

# Generated at 2022-06-11 03:58:11.060016
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    from ansible.module_utils.common.process import get_bin_path

    def get_package_details(name):
        ''' this method should wrap what get_package_details really does,
            and should return a list of dictionaries, with name and version keys.
            The method is only part of the test, it's not actually called, it's the _get_package_details_cmd that's called
        '''
        packages.append({"name": name, "version": "1.0", "source": "Debian"})

    def _get_package_details_cmd():
        ''' this method should return the actual command for get_package_details, the output of which is parsed by the called method '''

# Generated at 2022-06-11 03:58:15.065449
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    gvmapper = LibMgr()
    gvmapper.LIB = 'gvmapper'
    assert gvmapper.is_available()

    no_lib = LibMgr()
    no_lib.LIB = 'no_lib'
    assert not no_lib.is_available()


# Generated at 2022-06-11 03:58:17.959835
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    assert isinstance(PkgMgr.get_package_details, abstractmethod), "PkgMgr class needs to implement get_package_details"


# Generated at 2022-06-11 03:58:28.611599
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    from ansible.module_utils.package.osquery import Osquery
    from ansible.module_utils.package.composer import Composer
    from ansible.module_utils.package.go_lang import GoLang
    from ansible.module_utils.package.npm import Npm
    from ansible.module_utils.package.gems import Gems
    from ansible.module_utils.package.easy_install import EasyInstall
    from ansible.module_utils.package.pip import Pip
    from ansible.module_utils.package.pip3 import Pip3
    from ansible.module_utils.package.go_app import GoApp
    from ansible.module_utils.package.homebrew import Homebrew
    from ansible.module_utils.package.deb import Deb

# Generated at 2022-06-11 03:58:30.832212
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    PkgMgr_inst = PkgMgr()
    PkgMgr_inst.is_available()


# Generated at 2022-06-11 03:58:35.861896
# Unit test for constructor of class LibMgr
def test_LibMgr():
    print("Test LibMgr constructor")
    assert LibMgr()
    print("Test success")


# Generated at 2022-06-11 03:58:41.768620
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    from ansible.module_utils.common.process import get_bin_path

    class CLIMgr_is_available(CLIMgr):
        CLI = 'ansible'

    x = CLIMgr_is_available()
    assert x.is_available() is True

    x.CLI = 'ansible_is_not_available'
    assert x.is_available() is False



# Generated at 2022-06-11 03:58:44.879890
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    class AptMgr(CLIMgr):
        CLI = 'apt'

    apt = AptMgr()
    apt.is_available()
    assert apt._cli == '/usr/bin/apt'


# Generated at 2022-06-11 03:58:47.232426
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    #assert isinstance(test_data.test_pacman_str, str)
    assert isinstance(CLIMgr.__name__, str)

# Generated at 2022-06-11 03:58:49.327023
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    mgr = CLIMgr()
    mgr.CLI = 'python'
    assert mgr.is_available() is True


# Generated at 2022-06-11 03:58:55.868774
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    class TestPkgMgr(PkgMgr):

        def list_installed(self):
            return ['a', 'b', 'c']

        def get_package_details(self, package):
            return {'name': package, 'version': package, 'source': 'TestPkgMgr'}

    # Verify that the function returns a list of dictionaries
    assert isinstance(TestPkgMgr().get_packages(), dict)

    for item in TestPkgMgr().get_packages():
        assert isinstance(item, dict)

# Generated at 2022-06-11 03:58:56.765265
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    raise NotImplementedError


# Generated at 2022-06-11 03:58:57.162806
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    assert PkgMgr.get_packages() == {}

# Generated at 2022-06-11 03:58:57.922547
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pm = PkgMgr()
    assert pm.is_available() is NotImplemented


# Generated at 2022-06-11 03:58:59.440112
# Unit test for constructor of class CLIMgr
def test_CLIMgr():

    k = CLIMgr()
    assert isinstance(k, CLIMgr)


# Generated at 2022-06-11 03:59:08.025057
# Unit test for constructor of class CLIMgr
def test_CLIMgr():

    m = CLIMgr()
    assert m._cli is None
    assert isinstance(m, PkgMgr)


# Generated at 2022-06-11 03:59:13.407601
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    from ansible.module_utils.common.collections import ImmutablDict as immutable_dict # noqa

    apk_mgr = CLIMgr()
    apk_mgr.CLI = "/usr/bin/apk"
    assert apk_mgr.is_available()

    setattr(apk_mgr, 'CLI', 'unknown')
    assert not apk_mgr.is_available()


# Generated at 2022-06-11 03:59:14.296206
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    assert True


# Generated at 2022-06-11 03:59:20.005996
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    pm = PkgMgr()
    pm.list_installed = lambda: ['unittest']
    pm.get_package_details = lambda x: {'name': 'unittest', 'version': '1'}
    result = pm.get_packages()
    assert(len(result) == 1)
    assert(len(result['unittest']) == 1)
    assert(result['unittest'][0] == {'name': 'unittest', 'version': '1', 'source': 'pkgmgr'})

# Generated at 2022-06-11 03:59:21.850973
# Unit test for constructor of class LibMgr
def test_LibMgr():
    from ansible.module_utils.common.process import get_bin_path
    lm = LibMgr()
    assert lm is not None


# Generated at 2022-06-11 03:59:23.101726
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    cm = CLIMgr()
    cm.CLI = 'ls'
    assert cm.is_available()

# Generated at 2022-06-11 03:59:29.048288
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():

    final_data = []

    # Base class PkgMgr
    class_base = PkgMgr()
    final_data.append(class_base.get_package_details(None))

    # Class LibMgr
    class_lib = LibMgr()
    final_data.append(class_lib.get_package_details(None))

    # Class CLIMgr
    class_cli = CLIMgr()
    final_data.append(class_cli.get_package_details(None))

    if [] in final_data:
        raise AssertionError("FAIL: Method get_package_details of class PkgMgr returns {}".format(final_data))
    else:
        print("PASS: Method get_package_details of class PkgMgr returns {}".format(final_data))

# Generated at 2022-06-11 03:59:30.798646
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    ls_test_object = LibMgr()
    assert not ls_test_object.is_available()


# Generated at 2022-06-11 03:59:33.360399
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.packages.test.fake_module'
    assert TestLibMgr().is_available()


# Generated at 2022-06-11 03:59:35.242788
# Unit test for constructor of class LibMgr
def test_LibMgr():
    lib_mgr = LibMgr()
    assert lib_mgr._lib is None
    assert lib_mgr.LIB is None


# Generated at 2022-06-11 03:59:58.248948
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    libmgr = LibMgr()

    # Do not expect self._lib to be set to anything
    assert not libmgr._lib

    # Changing LIB attribute to reflect an already present library
    libmgr.LIB = 'ansible.module_utils.common.collections'

    # LIB is present, is_available should return True
    assert libmgr.is_available()

    # self._lib should now be set to the library
    assert libmgr._lib

    # Changing LIB attribute to reflect a non-present library
    libmgr.LIB = 'ansible.module_utils.common.fake'

    # LIB is not present, is_available should return False
    assert not libmgr.is_available()

    # self._lib should remain to be set to the previously set library
    assert libmgr._lib


# Generated at 2022-06-11 04:00:07.390925
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class TestPkgMgr(PkgMgr):
        def list_installed(self):
            return ['pkg1', 'pkg2']
        def get_package_details(self, package):
            if(package == 'pkg1'):
                return dict(
                        name='pkg1',
                        version='1.0'
                        )
            else:
                return dict(
                        name='pkg2',
                        version='2.0'
                        )
    pmgr = TestPkgMgr()
    assert pmgr.get_package_details('pkg1') == dict(
            name='pkg1',
            version='1.0'
            )
    assert pmgr.get_package_details('pkg2') == dict(
            name='pkg2',
            version='2.0'
            )

# Generated at 2022-06-11 04:00:08.679226
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    assert PkgMgr.list_installed == NotImplemented


# Generated at 2022-06-11 04:00:15.936028
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    from ansible.module_utils.common.collections import from_module_utils

    test_lib_mgr = from_module_utils(LibMgr)

    test_lib_mgr.LIB = "platform"

    # Test when the library exists
    assert test_lib_mgr.is_available() == True

    # Test when the library does not exists
    test_lib_mgr.LIB = "sadfkjhsadfkjhsadfkjhsdfkjhsadfkjhsdfkjhsdfkjhsdfkjhsdfkjhsdfkjh"
    assert test_lib_mgr.is_available() == False


# Generated at 2022-06-11 04:00:18.407210
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCLIMgr(CLIMgr):
        CLI = 'ls'
    tcm = TestCLIMgr()
    if tcm.is_available():
        assert True
    else:
        assert False

# Generated at 2022-06-11 04:00:24.186454
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.facts.collectors.package.pip import CLIMgr as PipCLIMgr
    from ansible.module_utils.facts.collectors.package.gem import CLIMgr as GemCLIMgr
    from ansible.module_utils.facts.collectors.package.rpm import CLIMgr as RpmCLIMgr
    from ansible.module_utils.facts.collectors.package.deb import CLIMgr as DebCLIMgr
    from ansible.module_utils.facts.collectors.package.apk import CLIMgr as ApkCLIMgr
    from ansible.module_utils.facts.collectors.package.brew import CLIMgr as BrewCLIMgr

    class TestPkgMgr():
        CLI = ''



# Generated at 2022-06-11 04:00:29.315585
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    pm = PkgMgr()
    pm.list_installed = lambda: ['a', 'b', 'c']
    pm.get_package_details = lambda p: {'name': 'test_package', 'version': p}
    packages = pm.get_packages()
    assert packages == {'test_package': [{'version': 'a', 'name': 'test_package'}, {'version': 'b', 'name': 'test_package'}, {'version': 'c', 'name': 'test_package'}]}

# Generated at 2022-06-11 04:00:29.772790
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    assert True

# Generated at 2022-06-11 04:00:30.712453
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    pass


# Generated at 2022-06-11 04:00:31.684579
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    cm = CLIMgr()
    assert cm

# Generated at 2022-06-11 04:01:04.923539
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    import unittest
    import os

    class TestMgr(PkgMgr):

        def is_available(self):
            return True

        def list_installed(self):
            return os.listdir("/tmp")

    class PkgMgrTestCase(unittest.TestCase):

        def test_PkgMgr_list_installed(self):
            tm = TestMgr()
            assert isinstance(tm.list_installed(), list)
    unittest.main()

# Generated at 2022-06-11 04:01:14.747639
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    import sys
    import inspect
    import imp

    from ansible.module_utils.common._utils import get_all_subclasses

    class FakeCLIMgr():
        CLI = None
    all_classes = set([FakeCLIMgr])

    all_classes.update(get_all_subclasses(CLIMgr))

    for cls in all_classes:
        cli_name = cls.CLI
        if cli_name.endswith('-config'):
            cli_name = '%s' % (cli_name[0:-7])

# Generated at 2022-06-11 04:01:22.768882
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    import sys

    class PkgMgr1(PkgMgr):
        def list_installed(self):
            return ['pkg1', 'pkg2', 'pkg3']
        def get_package_details(self, package):
            return {'name': package, 'version': '1', 'installed_version': '1'}

    class PkgMgr2(PkgMgr):
        def list_installed(self):
            return ['pkg1', 'pkg2' , 'pkg4', 'pkg4']
        def get_package_details(self, package):
            return {'name': package, 'version': '1', 'installed_version': '1'}


# Generated at 2022-06-11 04:01:23.279847
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    pass

# Generated at 2022-06-11 04:01:32.932958
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    ansible_python_version = "3.6.3"
    list_installed_packages = [{
        "name": "ansible-base",
        "version": "2.7.1"
    }, {
        "name": "python",
        "version": ansible_python_version
    }]

    class TestClass(PkgMgr):
        def __init__(self):
            pass

        def list_installed(self):
            return list_installed_packages

        def get_package_details(self, package):
            return package

    test_object = TestClass()
    result = test_object.get_packages()
    assert result["ansible-base"] == [{
        "name": "ansible-base",
        "version": "2.7.1"
    }]

# Generated at 2022-06-11 04:01:33.745527
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    pass


# Generated at 2022-06-11 04:01:41.781946
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    from ansible.module_utils.facts.system.pkg_mgr.pkg_mgr_yum import Yum
    from ansible.module_utils.facts.system.pkg_mgr.pkg_mgr_dnf import Dnf
    from ansible.module_utils.facts.system.pkg_mgr.pkg_mgr_apt import Apt
    from ansible.module_utils.facts.system.pkg_mgr.pkg_mgr_zypper import Zypper
    from ansible.module_utils.facts.system.pkg_mgr.pkg_mgr_apk import Apk

    output = {'passed':[], 'failed':[]}

    test_yum = Yum()

# Generated at 2022-06-11 04:01:44.401133
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    class SubPkgMgr(PkgMgr):
        def is_available(self):
            return False

    sub_pkg_mgr = SubPkgMgr()
    assert sub_pkg_mgr.is_available() == False



# Generated at 2022-06-11 04:01:46.480300
# Unit test for constructor of class LibMgr
def test_LibMgr():
    try:
        LibMgr()
    except Exception as e:
        raise AssertionError('__init__() raised %s unexpectedly' % (e,))


# Generated at 2022-06-11 04:01:47.264420
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pass


# Generated at 2022-06-11 04:02:55.596201
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():

    class PkgMgrTest(PkgMgr):
        def is_available(self):
            pass
        def list_installed(self):
            pass
        def get_package_details(self, *args, **kwargs):
            pass
    pm = PkgMgrTest()
    assert pm.get_package_details('first', 'second') == {}


# Generated at 2022-06-11 04:02:56.643982
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class Test(LibMgr):
        LIB = 'sys'

    t = Test()

    assert t.is_available() == True
    return True


# Generated at 2022-06-11 04:03:03.038059
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class PkgMgrTest(PkgMgr):
        def list_installed(self):
            return [{'name':'python3-ansible', 'version':'2.7.6', 'description':'Python SSH Automation Library', 'author':'Ansible, Inc.', 'release':'6cef17e', 'source':'apt'}]


# Generated at 2022-06-11 04:03:03.825823
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    assert CLIMgr.is_available()

# Generated at 2022-06-11 04:03:05.962574
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():

    actual = get_all_pkg_managers()
    assert type(actual) is dict
    for item in actual:
        assert item in ('apt', 'yum', 'rpm', 'deb')

# Generated at 2022-06-11 04:03:07.528999
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    p = PkgMgr()
    assert (p.is_available() is None)



# Generated at 2022-06-11 04:03:16.151906
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    import itertools

    class MyPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['a-b-c', 'a-b-d', 'a-b-e']
        def get_package_details(self, package):
            name = package.split('-')[:2]
            return {'name': '-'.join(name), 'version': package.split('-')[-1]}

    pkgmgr = MyPkgMgr()
    packages = pkgmgr.get_packages()

# Generated at 2022-06-11 04:03:18.613303
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    from ansible.module_utils.common._pkg_resources import setuptools

    lib_mgr = LibMgr()
    lib_mgr.LIB = 'setuptools'

    assert lib_mgr.is_available() == True


# Generated at 2022-06-11 04:03:27.779101
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    class TestPkgMgr(PkgMgr):
        def list_installed(self):
            return ['pkg1', 'pkg2']

        def get_package_details(self, package):
            return {
                'pkg1': {
                    'name': 'pkg1',
                    'version': '1.0',
                    'release': '100'
                },
                'pkg2': {
                    'name': 'pkg2',
                    'version': '1.0',
                    'release': '10',
                    'source': 'source2'
                }
            }[package]

    tpm = TestPkgMgr()

# Generated at 2022-06-11 04:03:35.836229
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    import sys
    import os

    bin_path = [os.path.dirname(os.path.realpath(__file__))]

    # Ensure that pytest is imported to avoid the following ImportError:
    # No module named _pytest
    try:
        import pytest
    except ImportError as e:
        print(e)
        sys.exit(1)

    sys.path.extend(bin_path)

    import rpm  # noqa E402

    class TestLibMgr(LibMgr):

        LIB = "rpm"

    tlm = TestLibMgr()
    if tlm.is_available() is False:
        sys.path.remove(bin_path[0])
        raise ValueError("LibMgr is not available for the rpm module")

# Generated at 2022-06-11 04:06:15.759218
# Unit test for constructor of class LibMgr
def test_LibMgr():
	
	m = LibMgr()
	assert not m.__dict__['_lib']
	m.is_available()
	assert m.__dict__['_lib']


# Generated at 2022-06-11 04:06:23.656819
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():

    class FakePackageMgr(PkgMgr):

        def is_available(self):
            pass

        def list_installed(self):
            pass

        def get_package_details(self, package):
            return {'name': 'fakepackage', 'version': '1.0'}

    # This is the expected result
    expected_result = {'name': 'fakepackage', 'version': '1.0', 'source': "fakepackagemgr"}

    # It should return the expected result (expected tests)
    assert expected_result == FakePackageMgr().get_package_details('fakepackage')

    # It should return a dict with name and version (value tests)
    result = FakePackageMgr().get_package_details('fakepackage')
    assert result['name'] == 'fakepackage'

# Generated at 2022-06-11 04:06:25.995852
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    cli_mgr = CLIMgr()
    assert cli_mgr.is_available() == True
    assert cli_mgr._cli == '/usr/bin/apt-get'


# Generated at 2022-06-11 04:06:28.756047
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    import unittest

    class CLIMgrSubclass(CLIMgr):
        CLI = "test"
    obj = CLIMgrSubclass()
    type(obj)._cli = "/bin/test"
    assert True == obj.is_available()



# Generated at 2022-06-11 04:06:30.800604
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    cli_mgr = CLIMgr()
    assert cli_mgr is not None


# Test case for is_available method of class CLIMgr

# Generated at 2022-06-11 04:06:32.330606
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    # In the future, this test can be replaced by the tests of its subclasses
    assert True

# Generated at 2022-06-11 04:06:34.465524
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pm = PkgMgr()
    try:
        pm.is_available()
    except NotImplementedError:
        assert True
    except:
        assert False

# Generated at 2022-06-11 04:06:35.506918
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    assert PkgMgr.list_installed() is None


# Generated at 2022-06-11 04:06:40.877573
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    #CLIMgr.CLI = 'invented_cli'
    test_cli_mgr = CLIMgr()
    assert test_cli_mgr.CLI == 'invented_cli'
    assert test_cli_mgr.is_available()


from ansible.module_utils.facts import collector
from ansible.module_utils.facts.collector import BaseFactCollector, BaseFileFactCollector
from ansible.module_utils.facts.system import SystemFactCollector
from ansible.module_utils.facts.network import NetworkFactCollector



# Generated at 2022-06-11 04:06:47.916045
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():

    pkg_managers = get_all_pkg_managers()
    assert isinstance(pkg_managers, dict), "pkg_managers is not a dict"

    for key in pkg_managers:
        if issubclass(pkg_managers[key], LibMgr):
            assert hasattr(pkg_managers[key](), 'LIB'), "pkg_manager {0} has no attribute LIB".format(key)
            assert hasattr(pkg_managers[key](), '_lib'), "pkg_manager {0} has no private attribute _lib".format(key)
            assert hasattr(pkg_managers[key]().is_available(), '__call__'), "pkg_manager {0} is_available is not a method".format(key)
