

# Generated at 2022-06-11 03:56:47.616871
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    test=PkgMgr
    assert test.is_available() == True


# Generated at 2022-06-11 03:56:55.518358
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():

    # test for method is_available of class PkgMgr
    # check if the method is_available can identify the pkg manager program
    # check if "cls" and "%s" are in the output of the method is_available
    # check if the method is_available can properly identify the pkg manager program

    sys.path.insert(0, os.path.dirname(__file__))

    from lib_pkg_mgr import ArgylePkgMgr

    my_test_mgr = ArgylePkgMgr()
    assert(my_test_mgr.is_available() == True)


# Generated at 2022-06-11 03:56:57.507772
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    obj = PkgMgr()
    assert obj.is_available() is False


# Generated at 2022-06-11 03:57:00.870391
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    from ansible.module_utils.common.collections import ImmutableDict

    pm = PkgMgr()
    details = pm.get_package_details(None)
    assert details == ImmutableDict()



# Generated at 2022-06-11 03:57:02.239416
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
  CLI = CLIMgr()
  assert not CLI.is_available()


# Generated at 2022-06-11 03:57:04.812844
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class FooClass(LibMgr):
        LIB = '_Absc_'
    f = FooClass()
    f._lib = None
    assert f.is_available() == False

# Generated at 2022-06-11 03:57:09.476239
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    import json
    import yaml
    from ansible.module_utils.facts.system.pkg_mgr.pkg_mgr import PkgMgr
    import ansible_collections.cloud.common.plugins.module_utils.cloud.common.facts.system.pkg_mgr.rpm_mgr as rpm_mgr

    rpm_mgr_obj = rpm_mgr.RPMMgr()
    # Build the list of installed packages
    installed_packages = rpm_mgr_obj.get_packages()
    # Test that each package in installed_packages has the correct format
    for package_name in installed_packages:
        # Test that the package contains an array of dictionaries
        assert isinstance(installed_packages[package_name], list)

# Generated at 2022-06-11 03:57:18.490226
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    from ansible.module_utils.software_management.test_pkg_mgr import CLIMgr
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.common.collections import ImmutableDict
    import os

    def mock_get_bin_path(*args, **kwargs):
        return os.path.abspath('/usr/bin/rpm')

    def mock__get_bin_path_none(*args, **kwargs):
        raise ValueError('No executable found by the name rpm')

    test_db = ImmutableDict({'get_bin_path': mock_get_bin_path,
                             'get_bin_path_none': mock__get_bin_path_none
                             })

    cli_mgr = CLIMgr()


# Generated at 2022-06-11 03:57:19.106445
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    assert True

# Generated at 2022-06-11 03:57:23.599701
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    for obj in get_all_subclasses(PkgMgr):
        if obj not in (CLIMgr, LibMgr):
            pm = obj()
            if pm.is_available():
                assert len(pm.list_installed()) > 0
                break
    else:
        assert 0


# Generated at 2022-06-11 03:57:36.810088
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    import os
    import tempfile
    from ansible.module_utils.ansible_release import __version__

    # Create temporary CLI file
    cliName = 'test'
    (fh, cli) = tempfile.mkstemp(prefix=cliName)
    os.write(fh, b'#!/bin/sh\necho %s' % __version__.encode())
    os.close(fh)
    # Make it executable
    os.chmod(cli, 0o755)
    # Create instance of CLIMgr class
    cliMgr = CLIMgr()
    # Force is_available to use cli file
    cliMgr.CLI = cliName
    # Make sure is_available returns the correct value

# Generated at 2022-06-11 03:57:38.082323
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():

    assert PkgMgr().is_available() == NotImplemented

# Generated at 2022-06-11 03:57:42.770085
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    class PkgMgrSub(PkgMgr):

        def is_available(self):
            return True

        def list_installed(self):
            return [1, 2]

        def get_package_details(self, package):
            return {'name': package}

    x = PkgMgrSub()
    assert x.get_packages() == {1: [{'name': 1, 'source': 'pkgmgrsub'}], 2: [{'name': 2, 'source': 'pkgmgrsub'}]}

# Generated at 2022-06-11 03:57:51.649673
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    from ansible_collections.community.general.plugins.module_utils.os.package.ipkg import Ipkg

    ipkg = Ipkg()
    ipkg.is_available()

    package = {
        'name': 'coreutils-base',
        'version': '8.30-r0.0.1.8'
    }

    result = ipkg.get_package_details(package)
    assert result['name'] == 'coreutils-base'
    assert result['version'] == '8.30-r0.0.1.8'

    package.pop('version')
    result = ipkg.get_package_details(package)
    assert result['name'] == 'coreutils-base'
    assert result['version'] == ''

    package.pop('name')
    result = ipkg.get_package_details

# Generated at 2022-06-11 03:57:56.426764
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    '''
    ensure that is_available returns True if the library is available and False if it is not
    '''
    assert LibMgr().is_available() is False
    class DummyLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts'
    assert DummyLibMgr().is_available() is True


# Generated at 2022-06-11 03:57:58.928200
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():

    class PkgMgr(CLIMgr):

        CLI = 'toto'

    pm = PkgMgr()
    assert (pm.is_available()) is False

# Generated at 2022-06-11 03:58:01.358539
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    #Testing for the "PM" command
    pm = CLIMgr()
    pm.CLI = "PM"
    assert pm.is_available() == True


# Generated at 2022-06-11 03:58:10.413672
# Unit test for constructor of class CLIMgr
def test_CLIMgr():

    try:
        from ansible.module_utils import core
    except ImportError:
        from ansible.module_utils import basic as core
    import inspect

    _test_subclass = type(b'test_subclass', (CLIMgr,), {'CLI': b'test_subclass'})
    _test_subclass_instance = _test_subclass()
    assert isinstance(_test_subclass_instance, CLIMgr)
    assert isinstance(_test_subclass_instance, PkgMgr)
    assert isinstance(_test_subclass_instance, core.AnsibleModule)
    assert _test_subclass_instance.CLI == b'test_subclass'
    assert inspect.isabstract(_test_subclass) is True
    assert inspect.isabstract(CLIMgr) is True

# Generated at 2022-06-11 03:58:20.288546
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    class TestPkgMgr(PkgMgr):

        def is_available(self):
            return True

        def list_installed(self):
            return ['pkg1','pkg2','pkg3','pkg4','pkg2']

        def get_package_details(self, package):
            return {
                'name': package,
                'version': 1,
                'source': 'test'
            }

    import copy
    p = TestPkgMgr()
    packages = p.get_packages()

    # test the right number of packages are returned

# Generated at 2022-06-11 03:58:22.177029
# Unit test for constructor of class LibMgr
def test_LibMgr():
    lib_mgr = LibMgr()
    assert lib_mgr._lib is None


# Generated at 2022-06-11 03:58:30.977799
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    assert PkgMgr.list_installed(PkgMgr) == NotImplemented


# Generated at 2022-06-11 03:58:36.688392
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    str_package_details = {'name': 'foo', 'version': '1'}
    assert PkgMgr().get_packages() == {}
    assert PkgMgr().get_packages(
        package_list=['foo'],
        package_details=str_package_details
    ) == {'foo': [str_package_details]}
    assert PkgMgr().get_packages(
        package_list=['bar', 'foo'],
        package_details={
            'bar': str_package_details,
            'foo': str_package_details,
        }
    ) == {'foo': [str_package_details], 'bar': [str_package_details]}

# Generated at 2022-06-11 03:58:38.539816
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    assert CLIMgr().is_available() == False
    assert CLIMgr().is_available() == False

# Generated at 2022-06-11 03:58:49.232008
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    from ansible.module_utils.common.common import is_executable
    # Prepare a stub for get_bin_path
    try:
        from ansible.module_utils.common.process import get_bin_path
    except ImportError:
        pass
    else:
        real_get_bin_path = get_bin_path
        import mock
        get_bin_path = mock.Mock(side_effect=real_get_bin_path)
    # Prepare a stub for is_executable
    # We may have to change this test to mock this functionality if it depends on a missing library function (libacl1)
    real_is_executable = is_executable
    is_executable = mock.Mock(side_effect=real_is_executable)
    # Check that this method is abstract and cannot be called
    result

# Generated at 2022-06-11 03:58:50.640909
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    c1 = CLIMgr()
    assert c1._cli is None


# Generated at 2022-06-11 03:58:53.491737
# Unit test for constructor of class CLIMgr
def test_CLIMgr():

    class CLIMgrTest(CLIMgr):
        CLI = 'ls'

    cli_mgr = CLIMgrTest()
    assert cli_mgr._cli == '/bin/ls'

# Generated at 2022-06-11 03:58:54.695779
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():

    obj = LibMgr()
    assert obj.__class__.__name__ == 'LibMgr'
    assert obj.is_available() == False


# Generated at 2022-06-11 03:58:57.688883
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    pkg_manager = CLIMgr()
    pkg_manager.CLI = 'pwd'
    assert pkg_manager.is_available()
    assert pkg_manager._cli == get_bin_path('pwd')


# Generated at 2022-06-11 03:58:59.684696
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    mgr = LibMgr()
    assert mgr.is_available() == False, "No library installed, return False"

if __name__ == "__main__":
    import sys
    import pytest
    sys.exit(pytest.main(['-x', __file__]))

# Generated at 2022-06-11 03:59:06.132000
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return [{'a': 1}, {'b': 2}]
        def get_package_details(self, package):
            return {'name': 'Test', 'version': '1.0.0'}
    installed_packages = TestPkgMgr().get_packages()
    assert 'Test' in installed_packages
    assert len(installed_packages['Test']) == 2
    assert installed_packages['Test'][0]['version'] == '1.0.0'

# Generated at 2022-06-11 03:59:26.791971
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    install_packages = PkgMgr()
    install_packages.list_installed = lambda: ['test-package']
    install_packages.get_package_details = lambda package: {'name': 'test-package', 'version': '1.0', 'source': 'test-source'}
    result = {'test-package': [{'name': 'test-package', 'version': '1.0', 'source': 'test-source'}]}
    assert install_packages.get_packages() == result


# Generated at 2022-06-11 03:59:29.820513
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'test_LibMgr_is_available'

    pkg_mgr = TestLibMgr()
    assert not pkg_mgr.is_available()


# Generated at 2022-06-11 03:59:33.360102
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():

    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.facts.system.pkg_mgr.apt import Apt
    apt = Apt(None)
    assert apt.is_available()
    assert apt._cli == get_bin_path('apt-get')

# Generated at 2022-06-11 03:59:36.278870
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    cli_mgr = CLIMgr()
    assert cli_mgr.__class__.__name__ == "CLIMgr"
    assert cli_mgr._cli == None # pylint: disable=protected-access


# Generated at 2022-06-11 03:59:38.162918
# Unit test for constructor of class LibMgr
def test_LibMgr():
    pkgmgr = LibMgr()
    assert pkgmgr._lib is None
    assert pkgmgr.LIB is None


# Generated at 2022-06-11 03:59:40.588317
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    mgr = PkgMgr()
    assert len(mgr.get_packages()) == 0, "PkgMgr get_packages() should return empty dict"


# Generated at 2022-06-11 03:59:47.524196
# Unit test for constructor of class LibMgr
def test_LibMgr():
    from ansible.module_utils.common.compat import mock

    lib_obj = LibMgr()
    # no import for module, test for ImportError exception
    with mock.patch('__builtin__.__import__') as mocked:
        mocked.side_effect = ImportError
        assert lib_obj.is_available() is False
    # __import__ for module
    with mock.patch('__builtin__.__import__') as mocked:
        mocked.return_value = mock.MagicMock()
        assert lib_obj.is_available() is True



# Generated at 2022-06-11 03:59:49.137660
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    for pmgr in get_all_pkg_managers():
        pkg_mgr = get_all_pkg_managers()[pmgr]()
        if pkg_mgr.is_available():
            pass
        else:
            assert False



# Generated at 2022-06-11 03:59:57.005491
# Unit test for constructor of class LibMgr
def test_LibMgr():

    LIB = 'ansible.module_utils.facts.system.platform.LibMgr'

    class LibMgr(PkgMgr):

        #LIB = 'ansible.module_utils.facts.system.platform.LibMgr'

        def is_available(self):
            found = False
            try:
                self._lib = __import__(self.LIB)
                found = True
            except ImportError:
                pass
            return found

        def list_installed(self):
            pass

        def get_package_details(self, package):
            pass

    l = LibMgr()
    l.is_available()


# Generated at 2022-06-11 04:00:06.128917
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    class Dummy(PkgMgr):

        def __init__(self, list_installed_result, get_package_details_result):
            self.list_installed_result = list_installed_result
            self.get_package_details_result = get_package_details_result
            super(Dummy, self).__init__()

        def list_installed(self):
            return self.list_installed_result

        def get_package_details(self, package):
            return self.get_package_details_result

    expected = {
        'name': [{'version': '1.0', 'source': 'dummy'}, {'version': '2.0', 'source': 'dummy'}]
    }

# Generated at 2022-06-11 04:00:37.636175
# Unit test for constructor of class LibMgr
def test_LibMgr():
    # The instantiation should not raise an exception.
    libmgr = LibMgr()
    assert libmgr is not None

# Generated at 2022-06-11 04:00:38.165460
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    pass

# Generated at 2022-06-11 04:00:46.588294
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgrSubClass(PkgMgr):
        def is_available(self):
            return True

        def list_installed(self):
            return [
                "test-package-1",
                "test-package-2",
                "test-package-3",
                "test-package-4"
            ]

        def get_package_details(self, package):
            return dict(
                name=package,
                version="1.0",
                source=self.__class__.__name__.lower()
            )
    test_pkg_mgr = TestPkgMgrSubClass()
    packages = test_pkg_mgr.get_packages()
    assert len(packages) == 4
    for package_name in packages:
        assert len(packages[package_name]) == 1

# Generated at 2022-06-11 04:00:47.496855
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    assert CLIMgr().is_available()

# Generated at 2022-06-11 04:00:56.286029
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    import json

    class PkgMgrUnitTest(PkgMgr):
        def __init__(self):
            self._packages = [{'name': 'pkg1', 'version': '1.0'}, {'name': 'pkg2', 'version': '2.0'}]
            super(PkgMgrUnitTest, self).__init__()

        def is_available(self):
            return True

        def list_installed(self):
            return ['pkg1', 'pkg2']

        def get_package_details(self, package=None):
            if package:
                return next(item for item in self._packages if item["name"] == package)
            else:
                return self._packages

    pkg_mgr = PkgMgrUnitTest()

# Generated at 2022-06-11 04:00:57.207117
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():

    p = PkgMgr()
    assert p.is_available() == NotImplemented


# Generated at 2022-06-11 04:01:00.185449
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    from ansible.module_utils.common.collections import ImmutableDict
    my_pm = PkgMgr()
    assert my_pm.is_available() == False



# Generated at 2022-06-11 04:01:02.267804
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    # Arrange
    pm = CLIMgr()

    # Act
    res = pm.is_available()

    # Assert
    assert res is False

# Generated at 2022-06-11 04:01:10.236967
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    """
    Returns list of installed packages
    """
    class PkgMgrMock(PkgMgr):
        def __init__(self):
            super(PkgMgrMock, self).__init__()

        def is_available(self):
            pass

        def list_installed(self):
            return ["package1", "package2"]

        def get_package_details(self, package):
            pass
    pkg_mgr = PkgMgrMock()
    installed_packages = pkg_mgr.list_installed()
    assert installed_packages == ["package1", "package2"]



# Generated at 2022-06-11 04:01:12.138074
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    foo = CLIMgr()
    assert foo.CLI is None, "foo.CLI not initialized correctly"


# Generated at 2022-06-11 04:02:22.297648
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    assert LibMgr().is_available() == False


# Generated at 2022-06-11 04:02:23.862928
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():

    assert PkgMgr.is_available(PkgMgr) == NotImplemented


# Generated at 2022-06-11 04:02:25.424258
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    assert PkgMgr.get_packages is not None, "No get_packages method found for class PkgMgr"

# Generated at 2022-06-11 04:02:26.373222
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    assert CLIMgr().is_available() == False

# Generated at 2022-06-11 04:02:28.171824
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    cli_mgr = CLIMgr()
    assert cli_mgr is not None


# Generated at 2022-06-11 04:02:30.454891
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestPkgManager(CLIMgr):
        CLI = 'which'
    mgr = TestPkgManager()
    assert mgr.is_available()

# Generated at 2022-06-11 04:02:32.846589
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():

    pkg_mgr = PkgMgr()
    result = pkg_mgr.list_installed()
    assert isinstance(result, list) is True


# Generated at 2022-06-11 04:02:35.283160
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    class PkgMgrTest(CLIMgr):
        CLI = 'ls'

    manager = PkgMgrTest()
    assert manager._cli == 'ls'

# Generated at 2022-06-11 04:02:36.078350
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    assert True


# Generated at 2022-06-11 04:02:45.290582
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestMgr(CLIMgr):
        CLI = 'test-cli'
    from ansible.module_utils.common.process import get_bin_path
    import tempfile
    import os
    with tempfile.NamedTemporaryFile() as tmp:
        os.chmod(tmp.name, 0o755)
        assert TestMgr().is_available() == False
        assert TestMgr(path=tmp.name).is_available() == True
    assert TestMgr(path='/bin/false').is_available() == False
    assert TestMgr(path='/bin/true').is_available() == True
    import ansible.module_utils.basic
    cur_env = ansible.module_utils.basic.get_env_dict()

# Generated at 2022-06-11 04:05:35.858441
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    obj = PkgMgr()
    success, _ = obj.is_available()
    assert success == False


# Generated at 2022-06-11 04:05:40.524022
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    pm = PkgMgr()
    pm.list_installed = lambda: ['a', 'b']
    pm.get_package_details = lambda x: {'name': x, 'version': '1'}
    assert(pm.get_packages() == {'a': [{'name': 'a', 'source': 'pkgmgr', 'version': '1'}], 'b': [{'name': 'b', 'source': 'pkgmgr', 'version': '1'}]})

# Generated at 2022-06-11 04:05:47.954048
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.dict2nested import dict2nested

    class DummyMgr(PkgMgr):

        def is_available(self):
            return True

        def list_installed(self):
            return self.list_installed_packages

        def get_package_details(self, package):
            return self.package_details

    def test_get_package_details_returns_dict():

        mgr = DummyMgr()
        mgr.list_installed_packages = ['a', 'b', 'c']
        mgr.package_details = 'dummy_info'

        result = mgr.get_packages()

# Generated at 2022-06-11 04:05:48.735016
# Unit test for constructor of class LibMgr
def test_LibMgr():

    lm = LibMgr()
    assert lm

# Generated at 2022-06-11 04:05:52.647247
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['test']
        def get_package_details(self, package):
            return {'name': 'test'}

    # Program does not throw any exception
    test_pkgmgr = TestPkgMgr()
    assert 'test' in test_pkgmgr.get_packages()


# Generated at 2022-06-11 04:05:55.031480
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pkgmgr = PkgMgr()
    assert (pkgmgr.is_available() == False)


# Generated at 2022-06-11 04:05:59.174609
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class test(LibMgr):
        pass
    package_manager = test()
    assert not package_manager.is_available()

    class test(LibMgr):
        LIB = 'ansible.module_utils.facts.system.distribution'
    package_manager = test()
    assert package_manager.is_available()


# Generated at 2022-06-11 04:06:02.435621
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class TestPkgMgr(PkgMgr):
        def __init__(self):
            pass
        def is_available(self):
            pass
        def list_installed(self):
            pass

    a = TestPkgMgr()
    assert not a.get_package_details(None)


# Generated at 2022-06-11 04:06:05.173582
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCLIMgr(CLIMgr):
        CLI = "python3"
    test_cli_mgr = TestCLIMgr()
    assert test_cli_mgr.is_available()


# Generated at 2022-06-11 04:06:13.491335
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    from ansible.module_utils.facts.package_manager.pip import Pip
    from ansible.module_utils.facts.package_manager.portage import Portage
    from ansible.module_utils.facts.package_manager.pkgng import Pkgng
    from ansible.module_utils.facts.package_manager.dnf import DNF
    from ansible.module_utils.facts.package_manager.zypper import Zypper
    from ansible.module_utils.facts.package_manager.yum import Yum
    from ansible.module_utils.facts.package_manager.apk import Apk
    from ansible.module_utils.facts.package_manager.apt import Apt
    from ansible.module_utils.facts.package_manager.pkgin import Pkgin

    pkg = Pip().get_package