

# Generated at 2022-06-11 03:56:51.036646
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    import ansible.module_utils.common.network.pkgng as pkgng
    pkgng_model = pkgng.CLIMgr()
    assert pkgng_model.CLI == 'pkg'

# Generated at 2022-06-11 03:56:55.327676
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    from ansible.module_utils.common._utils import get_all_subclasses
    for obj in get_all_subclasses(LibMgr):
        print("testing " + obj.__name__, end='')
        print("\t: " + str(obj().is_available()))


# Generated at 2022-06-11 03:56:55.888444
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pass

# Generated at 2022-06-11 03:57:00.237163
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    lib_mgr = LibMgr()

    test_passed = lib_mgr.is_available() and hasattr(lib_mgr, '_lib') and lib_mgr._lib is None
    print('test_LibMgr_is_available: %s' % test_passed)


# Generated at 2022-06-11 03:57:09.773369
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    import shutil
    import tempfile
    import os
    import sys
    # Prepare content of python package
    dirpath = tempfile.mkdtemp()
    os.mkdir(os.path.join(dirpath, 'libpk_manager'))
    _setup_py = '''
from setuptools import setup

setup(
    name='libpk_manager',
    version='0.1',
    py_modules=['libpk_manager'],
)
'''
    with open(os.path.join(dirpath, 'libpk_manager', '__init__.py'), 'w') as _init_py:
        _init_py.write("__version__=\'0.1\'")



# Generated at 2022-06-11 03:57:11.581129
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    pkgmgr = LibMgr()
    assert pkgmgr.is_available() == False


# Generated at 2022-06-11 03:57:13.086697
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    cli_mgr = CLIMgr()
    cli_mgr._cli = None
    cli_mgr._cli = '/usr/bin/yum'
    assert cli_mgr.is_available()

# Generated at 2022-06-11 03:57:13.998917
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    pass



# Generated at 2022-06-11 03:57:17.451911
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    # Define a subclass of PkgMgr
    class PkgMgrSubClass(PkgMgr):
        pass
    # Create an instance of PkgMgrSubClass
    pm_sc = PkgMgrSubClass()
    assert pm_sc.is_available() == None

# Generated at 2022-06-11 03:57:18.824551
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    apt = CLIMgr()
    assert apt.is_available() == True

# Generated at 2022-06-11 03:57:26.893957
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    assert get_all_pkg_managers()['pkg'].test_PkgMgr_is_available() == True
    assert get_all_pkg_managers()['pkg'].test_PkgMgr_is_available() == True


# Generated at 2022-06-11 03:57:29.397987
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class InvalidPackageMgr(PkgMgr):
        pass

    pm = InvalidPackageMgr()
    assert pm.get_package_details({}) == {}


# Generated at 2022-06-11 03:57:30.772569
# Unit test for constructor of class LibMgr
def test_LibMgr():
    libmgr = LibMgr()
    assert libmgr is not None

# Generated at 2022-06-11 03:57:39.830863
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    class MyPkgMgr(PkgMgr):

        def is_available(self):
            return True

        def list_installed(self):
            return list(['package1', 'package2', 'package2'])

        def get_package_details(self, package):
            return dict(name=package, version=1)

    my_pkg_mgr = MyPkgMgr()

    packages = my_pkg_mgr.get_packages()

    assert sorted(packages.keys()) == sorted(['package1', 'package2'])
    assert packages['package1'] == [dict(name='package1', version=1, source='mypkgmgr')]

# Generated at 2022-06-11 03:57:44.030693
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    pkgmgr = CLIMgr()
    assert pkgmgr.is_available() == False
    assert pkgmgr.CLI is None
    assert pkgmgr._cli is None
    pkgmgr = CLIMgr()
    pkgmgr.CLI = '/bin/cp'
    assert pkgmgr.is_available() == True
    assert pkgmgr.CLI == '/bin/cp'
    assert pkgmgr._cli == '/bin/cp'

# Generated at 2022-06-11 03:57:45.239295
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    cm = CLIMgr()
    assert cm.is_available() == True


# Generated at 2022-06-11 03:57:51.162618
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class TestedClass(PkgMgr):
        def __init__(self):
            pass

        def list_installed(self):
            return ['a', 'b']

        def get_package_details(self, package):
            return {'name': package}

    test = TestedClass()
    assert test.get_packages() == {'a': [{'name': 'a', 'source': 'testedclass'}], 'b': [{'name': 'b', 'source': 'testedclass'}]}

# Generated at 2022-06-11 03:57:52.822922
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    assert(PkgMgr.list_installed(object) == NotImplemented)


# Generated at 2022-06-11 03:57:55.773995
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class LibMgr_Sub(LibMgr):
        LIB = '_ast'

    mgr = LibMgr_Sub()
    assert mgr.is_available() == True


# Generated at 2022-06-11 03:58:03.388404
# Unit test for constructor of class LibMgr
def test_LibMgr():
    import ansible.module_utils.common.packaging.pip as pip
    a = pip.Pip()
    assert isinstance(a, pip.Pip)
    assert hasattr(a, '_lib')
    assert hasattr(a, 'LIB')
    assert hasattr(a, 'list_installed')
    assert hasattr(a, 'get_package_details')
    assert isinstance(a.is_available(), bool)
    assert not a.is_available()
    assert isinstance(a.get_packages(), dict)
    assert not a.get_packages()


# Generated at 2022-06-11 03:58:13.744549
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    cli_pkg_mgr = CLIMgr()
    assert cli_pkg_mgr._cli is None
    assert cli_pkg_mgr.CLI
    assert cli_pkg_mgr.LIB is None
    assert cli_pkg_mgr._lib is None


# Generated at 2022-06-11 03:58:15.948863
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pmgr = PkgMgr()
    assert pmgr.is_available() is None


# Generated at 2022-06-11 03:58:20.289946
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class Test1(CLIMgr):
        CLI = "test1"
    class Test2(CLIMgr):
        CLI = "test2"
    test1 = Test1()
    test2 = Test2()
    assert test1.is_available() == False
    assert test2.is_available() == False

# Generated at 2022-06-11 03:58:21.758977
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():

    assert 'pip_pkg_mgr' in get_all_pkg_managers()

# Generated at 2022-06-11 03:58:23.972182
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class Test:
        CLI = 'test'

    test = Test()
    assert CLIMgr.is_available(test) == False


# Generated at 2022-06-11 03:58:28.980670
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():

    class TestLibMgr(LibMgr):

        LIB = 'subprocess'

    lib = TestLibMgr()
    test_result = lib.is_available()
    expected_result = True
    assert test_result == expected_result
    print('Test of method is_available of class LibMgr passed')



# Generated at 2022-06-11 03:58:30.815554
# Unit test for constructor of class LibMgr
def test_LibMgr():
    lib_mgr = LibMgr()
    assert(lib_mgr._lib == None)


# Generated at 2022-06-11 03:58:37.280998
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    all_packages = get_all_pkg_managers()
    for pkg, pkginstance in all_packages.items():
        if pkginstance().is_available():
            my_packages = pkginstance().get_packages()
            for pkg,versions in my_packages.items():
                for version in versions:
                    assert 'source' in version, "%s %s %s %s"%(pkg, version['version'], version['source'],'source' not in version)
                    assert 'name' in version, "%s %s %s %s"%(pkg, version['version'], version['source'],'name' not in version)
                    assert 'version' in version, "%s %s %s %s"%(pkg, version['version'], version['source'],'version' not in version)

# Generated at 2022-06-11 03:58:39.868692
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    cm = CLIMgr()
    cm.CLI = 'echo'
    assert cm.is_available() == True



# Generated at 2022-06-11 03:58:50.272545
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    import tempfile
    import ansible.module_utils.facts.system.pkg_mgr as pkg_mgr
    import json
    import os
    from ansible.module_utils.facts.system.pkg_mgr.aix import AixPkgMgr
    from ansible.module_utils.facts.system.pkg_mgr.apk import ApkPkgMgr
    from ansible.module_utils.facts.system.pkg_mgr.apt import AptPkgMgr
    from ansible.module_utils.facts.system.pkg_mgr.aptitude import AptitudePkgMgr
    from ansible.module_utils.facts.system.pkg_mgr.apt_cyg import AptCygPkgMgr

# Generated at 2022-06-11 03:59:13.456268
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class PkgMgrMock(PkgMgr):
        def get_package_details(self, package):
            if package == 'package1':
                return {'name': 'package1', 'size': 42}
            raise ValueError('package')
    test_pkg_mgr = PkgMgrMock()
    test_package_details = test_pkg_mgr.get_package_details('package1')
    assert 'size' in test_package_details
    assert test_package_details['name'] == 'package1'
    assert test_package_details['size'] == 42
    try:
        test_pkg_mgr.get_package_details('package2')
    except ValueError:
        assert True

# Generated at 2022-06-11 03:59:21.536848
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class PkgBuild(PkgMgr):
        def is_available(self):
            return True

        def list_installed(self):
            return ['package1', 'package2']

        def get_package_details(self, package):
            # return dummy package details
            return {'name': package, 'version': '1.0.0'}

    class PkgBuildMultipleVersions(PkgMgr):
        def is_available(self):
            return True

        def list_installed(self):
            return ['package1', 'package1', 'package2']

        def get_package_details(self, package):
            # return dummy package details
            return {'name': package, 'version': '1.0.0'}


# Generated at 2022-06-11 03:59:24.924153
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    # this test the function is_available
    input_is_available_value = LibMgr.is_available()

    actual_return_value = input_is_available_value
    expected_return_value = None

    assert actual_return_value == expected_return_value


# Generated at 2022-06-11 03:59:26.374983
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    pm = LibMgr()
    assert pm.is_available() == False


# Generated at 2022-06-11 03:59:32.992265
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    pkg_mgr = PkgMgr()
    pkg_mgr.list_installed = lambda: ["libansible"]
    pkg_mgr.get_package_details = lambda package: {"name": "libansible",
                                                   "version": "2.9.1-1ubuntu1",
                                                   "source": "apt"}
    packages = pkg_mgr.get_packages()
    assert packages["libansible"][0] == {"name": "libansible",
                                         "version": "2.9.1-1ubuntu1",
                                         "source": "apt"}

# Generated at 2022-06-11 03:59:41.840043
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    import copy

    class Pkg(object):
        # Fake class returning a dictionary representing a package
        def __init__(self, name, version):
            self.name = name
            self.version = version

        def __repr__(self):
            return self.name

        def __eq__(self, other):
            return self.name == other.name and self.version == other.version

        def __getitem__(self, item):
            if item == 'name':
                return self.name
            if item == 'version':
                return self.version

        def fake_get(self, item):
            return self.__getitem__(item)


# Generated at 2022-06-11 03:59:43.720770
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    dpkg = CLIMgr()
    assert isinstance(dpkg, CLIMgr)


# Generated at 2022-06-11 03:59:47.714560
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    packages_installed = [{'name': 'gcc', 'version': '3.3.3'}, {'name': 'python', 'version': '3.3.3'}]
    result = CLIMgr.is_available(packages_installed)
    assert(result == True)


# Generated at 2022-06-11 03:59:48.741484
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    try:
        import xml.etree.ElementTree as ET
        return ET.__name__
    except ImportError:
        return False

# Generated at 2022-06-11 03:59:50.950928
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    try:
        __import__('rpm')
    except ImportError:
        test_result = True
    else:
        test_result = False

    assert test_result

# Generated at 2022-06-11 04:00:20.715825
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    pass

# Generated at 2022-06-11 04:00:29.314375
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    from ansible.module_utils.facts.system.pkg_mgr import get_all_pkg_managers
    from ansible.module_utils.common.process import get_bin_path
    import sys

    package_manager = None
    # Loop among all the package managers and see which ones we find
    for package_manager_factory in get_all_pkg_managers().values():
        pm = package_manager_factory()
        if pm.is_available():
            package_manager = pm
            break

    if package_manager is None:
        print("Couldn't find a package manager, skipping package facts test")
        sys.exit(0)

    print("Testing %s package manager" % package_manager.__class__.__name__)
    print(package_manager.get_packages())



# Generated at 2022-06-11 04:00:37.420492
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    mgr = PkgMgr()
    mgr.list_installed = lambda: ['one', 'two', 'three']
    mgr.get_package_details = lambda package: {'name': package, 'version': '1.0'}
    result = mgr.get_packages()
    expected = {'one': [{'name': 'one', 'version': '1.0', 'source': 'pkgmgr'}],
                'two': [{'name': 'two', 'version': '1.0', 'source': 'pkgmgr'}],
                'three': [{'name': 'three', 'version': '1.0', 'source': 'pkgmgr'}]}
    assert result == expected

# Generated at 2022-06-11 04:00:41.643392
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    import unittest
    class PkgMgrTest(unittest.TestCase):
        def test_PkgMgr_is_available(self):
            pkg_managers = get_all_pkg_managers()
            for key in pkg_managers:
                pm = pkg_managers[key]()
                self.assertEqual(pm.is_available(), True)
    unittest.main()

# Generated at 2022-06-11 04:00:45.004951
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    from ansible.module_utils.facts.system.pkg_mgr.pkg_mgr import LibMgr
    lm = LibMgr()
    test_return_false = lm.is_available()
    assert not test_return_false


# Generated at 2022-06-11 04:00:46.183468
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    PkgMgr().list_installed()


# Generated at 2022-06-11 04:00:47.411787
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    test = CLIMgr()
    assert test._cli is None

# Generated at 2022-06-11 04:00:54.444782
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    from ansible.module_utils.common._utils import get_subclasses
    sub_classes = get_subclasses(PkgMgr)
    for sub_class in sub_classes:
        if sub_class is not CLIMgr and sub_class is not LibMgr:
            sub_class_instance = sub_class()
            if sub_class_instance.is_available():
                sub_class_instance.list_installed()
                if len(sub_class_instance.list_installed()) > 0:
                    return sub_class_instance.get_package_details(sub_class_instance.list_installed()[0])
    return None


# Generated at 2022-06-11 04:00:55.729323
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr()._cli == None


# Generated at 2022-06-11 04:00:59.982116
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    """Function returns all available package managers"""
    all_pkg_mgrs = get_all_pkg_managers()
    assert isinstance(all_pkg_mgrs, dict)
    for pkg_mgr in all_pkg_mgrs:
        assert isinstance(all_pkg_mgrs[pkg_mgr], type)
        assert not all_pkg_mgrs[pkg_mgr].is_available()


# Generated at 2022-06-11 04:02:05.113774
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    p = PkgMgr()
    return p.get_package_details({})=='TODO'


# Generated at 2022-06-11 04:02:06.661331
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pkgmgr = PkgMgr()
    assert pkgmgr.is_available() is False


# Generated at 2022-06-11 04:02:14.740194
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    # Test success
    pkg = PkgMgr()
    pkg.list_installed = MagicMock(return_value=['pkg1', 'pkg2'])
    pkg.get_package_details = MagicMock(return_value={'name': 'name', 'version': 'version'})
    results = pkg.get_packages()
    # check if list_installed has been called
    assert pkg.list_installed.call_count == 1
    # check if get_package_details has been called twice
    assert pkg.get_package_details.call_count == 2
    # check if expected list of packages has been returned

# Generated at 2022-06-11 04:02:16.797851
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    p = CLIMgr()
    print(p.is_available())
    print(p.CLI)


# Generated at 2022-06-11 04:02:25.560495
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    """Check if PkgMgr is looking for the package manager in the right place."""
    from tempfile import mkdtemp
    from shutil import rmtree
    from os import chdir, environ, mkdir, remove
    from os.path import join
    from ansible.module_utils.common._utils import ensure_bytes
    from ansible.module_utils.six import PY2

    class CLIMgrTest(CLIMgr):
        CLI = 'dummy'

    cli_mgr = CLIMgrTest()


# Generated at 2022-06-11 04:02:32.011467
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    # The module_utils/common/process.py is not importable. TestLibMgr is a mock-up for that
    class TestLibMgr(LibMgr):
        LIB = 'module_utils.common.process'
    lib_mgr = TestLibMgr()
    if lib_mgr.is_available() is not True:
        assert False, "test_LibMgr_is_available: The method is_available of class LibMgr fails"
    else:
        assert True


# Generated at 2022-06-11 04:02:34.255856
# Unit test for constructor of class LibMgr
def test_LibMgr():
    try:
        obj = LibMgr()
        assert obj != None
    except:
        return False
    return True


# Generated at 2022-06-11 04:02:35.850561
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    class TestCLIMgr(CLIMgr):
        class CLI(str):
            pass
    assert TestCLIMgr()._cli is None


# Generated at 2022-06-11 04:02:39.730659
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    # Test the get_package_details method of class PkgMgr
    # It should throw an NotImplementedError exception
    p = PkgMgr()
    try:
        pkg = p.get_package_details('test')
    except NotImplementedError:
        pass
    else:
        raise Exception("Error: get_package_details does not raise NotImplementedError")

# Generated at 2022-06-11 04:02:44.859028
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    import sys
    import os
    import mock

    mock_path = {'get_bin_path': mock.MagicMock(return_value=sys.prefix)}

    with mock.patch.dict(os.environ, {'PATH': '/foo'}):
        with mock.patch.multiple(CLIMgr, **mock_path):
            assert CLIMgr().is_available()

# Generated at 2022-06-11 04:05:37.085592
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    import sys
    import pytest
    class StubPkgMgr(PkgMgr):
        def __init__(self):
            super(StubPkgMgr, self).__init__()

        def is_available(self):
            return True

        def list_installed(self):
            return ['stubpkg1', 'stubpkg2']

        def get_package_details(self, package):
            if package == 'stubpkg1':
                return {'name': 'stubpkg1', 'version': 1}
            else:
                return {'name': 'stubpkg2', 'version': 2, 'other_key': 'other_value'}


# Generated at 2022-06-11 04:05:44.737041
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    # This test is to ensure that package manager's is_available method is called correctly
    class PkgMgr_Test_1(PkgMgr):
        def __init__(self):
            PkgMgr.__init__(self)
        def is_available(self):
            return True
    pkg_mgr_test1 = PkgMgr_Test_1()
    assert pkg_mgr_test1.is_available()
    class PkgMgr_Test_2(PkgMgr):
        def __init__(self):
            PkgMgr.__init__(self)
        def is_available(self):
            return False
    pkg_mgr_test2 = PkgMgr_Test_2()
    assert pkg_mgr_test2.is_available() is False


#

# Generated at 2022-06-11 04:05:46.933317
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    # Test to see if is_available of class PkgMgr returns true
    pkgmgr = PkgMgr()

    assert pkgmgr.is_available() == True


# Generated at 2022-06-11 04:05:49.735567
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    try:
        pip_bin = get_bin_path('pip')
        assert True
    except ValueError:
        assert False
    try:
        pip_bin = get_bin_path('adfasdfasd')
        assert False
    except ValueError:
        assert True

# Generated at 2022-06-11 04:05:54.078792
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    expected_values = [True, False]
    test_values = [
        'ansible',  # available
        'this_command_should_not_exist'  # not available
    ]
    for test_value, expected_value in zip(test_values, expected_values):
        # Create a CLIMgr subclass that we can use to test
        class TestCLIMgr(CLIMgr):
            CLI = test_value
        # Install the test_value command
        test_CLIMgr = TestCLIMgr()
        # Test it
        assert test_CLIMgr.is_available() == expected_value

# Generated at 2022-06-11 04:05:58.668800
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    expected_return_code = 0
    return_code = 0
    try:
        cli_mgr = CLIMgr()
        if cli_mgr.CLI is None:
            return_code = 1
    except:
        print("Error: Unexpected failure in test_CLIMgr()")
        assert return_code == expected_return_code


# Generated at 2022-06-11 04:05:59.742963
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    pass


# Generated at 2022-06-11 04:06:00.540779
# Unit test for constructor of class LibMgr
def test_LibMgr():
    assert LibMgr.LIB is None

# Generated at 2022-06-11 04:06:01.041167
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    pass

# Generated at 2022-06-11 04:06:02.368375
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
	
	my_instance = CLIMgr()
	assert my_instance is not None
