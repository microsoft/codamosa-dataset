

# Generated at 2022-06-11 03:56:55.886439
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    import unittest
    import mock
    import collections

    class PkgMgr_Mock(PkgMgr):
        def __init__(self):
            self.package_list = ['foo','bar','baz','qux']
            self.package_detail = {
                'name': 'name',
                'version': 'version',
                'source': 'source'
            }

        def is_available(self):
            return True

        def list_installed(self):
            return self.package_list

        def get_package_details(self, package):
            return self.package_detail

    class test_get_packages(unittest.TestCase):
        def setUp(self):
            self.package_mgr_obj = PkgMgr_Mock()

# Generated at 2022-06-11 03:56:56.571734
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr()

# Generated at 2022-06-11 03:56:58.477483
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pm = PkgMgr()
    assert pm.list_installed() == None


# Generated at 2022-06-11 03:57:08.031834
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    class TestPkgMgr(PkgMgr):
        def __init__(self):
            self.packages = {
                'pkg1': {'name': 'pkg1', 'version': '1.0', 'source': 'testpkgmgr'},
                'pkg2': {'name': 'pkg2', 'version': '1.0', 'source': 'testpkgmgr'},
                'pkg3': {'name': 'pkg3', 'version': '1.0', 'source': 'testpkgmgr'},
                'pkg4': {'name': 'pkg4', 'version': '1.0', 'source': 'testpkgmgr'}
            }

        def list_installed(self):
            return self.packages.keys()


# Generated at 2022-06-11 03:57:17.090047
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    import unittest
    import os

    class CLIMgrMock(CLIMgr):
        CLI = "true"

    with unittest.mock.patch.dict(os.environ, {'PATH': ''}):
        mock = CLIMgrMock()
        assert mock.is_available() is False

    with unittest.mock.patch.dict(os.environ, {'PATH': '/tmp/doesnotexist'}):
        mock = CLIMgrMock()
        assert mock.is_available() is False

    with unittest.mock.patch.dict(os.environ, {'PATH': '/bin:/sbin:/usr/sbin'}):
        mock = CLIMgrMock()
        assert mock.is_available() is True

# Generated at 2022-06-11 03:57:20.258759
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    class TestCLIMgr(CLIMgr):
        CLI = 'ls'

    test_obj = TestCLIMgr()
    assert hasattr(test_obj, '_cli')
    assert test_obj._cli == '/bin/ls'


# Generated at 2022-06-11 03:57:23.168907
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    pk = CLIMgr()
    pk.CLI = "cat"
    pk.is_available()
    assert pk._cli == "cat"

# Generated at 2022-06-11 03:57:26.463704
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    p = PkgMgr()
    try:
      p.list_installed()
      assert False
    except NotImplementedError:
      assert True


# Generated at 2022-06-11 03:57:36.027153
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    import pytest

    class MockPkgMgr(PkgMgr):
        def is_available(self):
            return True

        def list_installed(self):
            return ['mypackage1', 'mypackage2', 'mypackage3']

        def get_package_details(self, package):
            return {'name': package, 'version': '1.0.0'}

    mock_package_manager = MockPkgMgr()

    # mock_package_manager.get_packages() returns an empty dictionary, if mock_package_manager.list_installed() returns an empty list
    mock_package_manager.list_installed = lambda: []
    assert mock_package_manager.get_packages() == {}

    # mock_package_manager.get_packages() returns a dictionary with a key and a list, if mock_package_manager.list

# Generated at 2022-06-11 03:57:38.045315
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    class TestPkgMgr(PkgMgr):
        pass
    TestPkgMgr().is_available()

# Generated at 2022-06-11 03:57:43.692494
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    man = PkgMgr()
    assert isinstance(man.list_installed(), list)


# Generated at 2022-06-11 03:57:52.788650
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():

    # test mocked pkg_mgr
    class MockPkgMgr(PkgMgr):
        pass
    class MockPkgMgr1(MockPkgMgr):
        pass
    class MockPkgMgr2(MockPkgMgr):
        pass
    class MockPkgMgr3(PkgMgr):
        pass

    pkg_mgr_list = get_all_pkg_managers()
    assert MockPkgMgr.__name__.lower() not in pkg_mgr_list
    assert MockPkgMgr1.__name__.lower() in pkg_mgr_list
    assert MockPkgMgr2.__name__.lower() in pkg_mgr_list
    assert MockPkgMgr3.__name__.lower() in pkg_mgr_list

# Generated at 2022-06-11 03:57:54.115696
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    assert PkgMgr.list_installed() == NotImplemented


# Generated at 2022-06-11 03:58:02.970604
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    d = {'n': [{'n': 1, 'v': 1}, {'n': 1, 'v': 2}], 'n2': [{'n': 2, 'v': 3, 's': 's2'}, {'n': 2, 'v': 4, 's': 's2'}]}
    import mock
    class MockPkgMgr(PkgMgr):
        def list_installed(self):
            return ['1', '2']

        def get_package_details(self, package):
            return d[package]

    m = MockPkgMgr()
    m.get_packages = mock.Mock(wraps=m.get_packages)
    assert m.get_packages() == d

# Generated at 2022-06-11 03:58:11.689135
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    from ansible.module_utils import facts

    results = {}
    for pkg_mgr in get_all_pkg_managers().values():
        installed_packages = {}
        pkg_mgr = pkg_mgr()
        if not pkg_mgr.is_available():
            continue
        installed_packages = pkg_mgr.get_packages()

        for package in pkg_mgr.list_installed():
            package_details = pkg_mgr.get_package_details(package)
            if 'source' not in package_details:
                package_details['source'] = pkg_mgr.__class__.__name__.lower()
            name = package_details['name']
            if name not in installed_packages:
                installed_packages[name] = [package_details]

# Generated at 2022-06-11 03:58:13.430776
# Unit test for constructor of class LibMgr
def test_LibMgr():
    # constructor
    libmgr = LibMgr()
    assert libmgr._lib is None
    assert libmgr.LIB is None


# Generated at 2022-06-11 03:58:23.921897
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class PkgMgr_class(PkgMgr):
        def list_installed(self):
            return [1, 2, 3, 4]
        def get_package_details(self, package):
            return { 'name': str(package) }
    pmc = PkgMgr_class()
    assert pmc.get_packages() == { '1': [ {'name': '1', 'source': 'pkgmgr_class'} ],
                                  '2': [ {'name': '2', 'source': 'pkgmgr_class'} ],
                                  '3': [ {'name': '3', 'source': 'pkgmgr_class'} ],
                                  '4': [ {'name': '4', 'source': 'pkgmgr_class'} ] }

# Generated at 2022-06-11 03:58:30.510310
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    # In these two classes we intend to force LibMgr.__init__() to fail by raising ImportError
    class LibMgrFail(LibMgr):
        LIB = 'fails'

    class LibMgrFail2(LibMgr):
        LIB = 'fails.again'

    result = LibMgrFail().is_available()
    assert result == False
    result = LibMgrFail2().is_available()
    assert result == False


# Generated at 2022-06-11 03:58:31.750877
# Unit test for constructor of class LibMgr
def test_LibMgr():
    test_class = LibMgr()
    assert test_class._lib == None


# Generated at 2022-06-11 03:58:32.951702
# Unit test for constructor of class LibMgr
def test_LibMgr():
    lm = LibMgr()
    assert lm is not None


# Generated at 2022-06-11 03:58:51.479904
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    # Test data
    list_installed = [1, 2, 3, 4]
    package_details = {'name': 'foo', 'version': 'bar'}

    # Test class for overriding default PkgMgr class
    class TestPkgMgr(PkgMgr):

        def __init__(self):

            # Inject test data into TestPkgMgr
            self.list_installed = list_installed
            self.package_details = package_details
            super(TestPkgMgr, self).__init__()

        def is_available(self):

            return True

        def list_installed(self):

            return list_installed

        def get_package_details(self, package):

            return package_details

    # Test data set

# Generated at 2022-06-11 03:58:53.968135
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    class DummyCLIMgr(CLIMgr):
        CLI = "dummycli"
    d = DummyCLIMgr()
    assert d._cli == None

# Generated at 2022-06-11 03:59:02.089851
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def list_installed(self):
            return ['test_package_1-1.0', 'test_package_1-1.1']

        def get_package_details(self, package):
            if package == 'test_package_1-1.0':
                return {'name': 'test_package_1', 'version': '1.0', 'release': '1', 'status': 'installed'}
            elif package == 'test_package_1-1.1':
                return {'name': 'test_package_1', 'version': '1.1', 'release': '1', 'status': 'installed'}

    pkgmgr = TestPkgMgr()
    installed_packages = pkgmgr.get_packages()


# Generated at 2022-06-11 03:59:08.109446
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    class A(PkgMgr):
        def is_available(self):
            return False
        def list_installed(self):
            return []
        def get_package_details(self, package):
            return []
    assert A().is_available() == False
    class B(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return []
        def get_package_details(self, package):
            return []
    assert B().is_available() == True


# Generated at 2022-06-11 03:59:10.526031
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pm = PkgMgr()
    print ("\nTesting PkgMgr::list_installed\n")
    print (pm.list_installed())


# Generated at 2022-06-11 03:59:18.366014
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    mgr = CLIMgr()

    # default value of _cli is None
    assert mgr._cli is None

    # _cli should not be modified if CLI is None
    mgr.CLI = None
    mgr.is_available()
    assert mgr._cli is None

    # _cli should not be modified if CLI is not None and CLI is not on the system
    mgr.CLI = 'no-cli'
    mgr.is_available()
    assert mgr._cli is None

    # _cli should be modified if CLI is not None and CLI is on the system
    mgr.CLI = 'ls'
    mgr.is_available()
    assert mgr._cli is not None


# Generated at 2022-06-11 03:59:22.791521
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    # Test 1
    class TestCLIMgr(CLIMgr):
        CLI = 'dummy-not-to-be-available-on-any-system'

    x = TestCLIMgr()
    assert x.is_available() == False

    # Test 2
    class TestCLIMgr(CLIMgr):
        CLI = 'echo'

    x = TestCLIMgr()
    assert x.is_available() == True


# Generated at 2022-06-11 03:59:26.074884
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    # Success case
    cli_mgr = CLIMgr()
    cli_mgr.CLI = 'python'
    assert cli_mgr.is_available()

    # Failure case
    cli_mgr.CLI = 'python123'
    assert not cli_mgr.is_available()

# Generated at 2022-06-11 03:59:31.626354
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    test_case_class_array = get_all_pkg_managers().values()
    for test_case_class in test_case_class_array:
        if test_case_class.is_available():
            test_case_class_instance = test_case_class()
            assert test_case_class_instance.get_package_details("Doesnt_exist") == None
            assert test_case_class_instance.get_package_details("Doesnt exist either") == None


# Generated at 2022-06-11 03:59:34.554010
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    # This only tests that it can be imported and is a subclass of PkgMgr
    # Individual package managers are responsible for testing their own is_available

    # Test empty object
    P = PkgMgr()
    assert P



# Generated at 2022-06-11 03:59:54.986542
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():

    class MyCLIMgr(CLIMgr):

        CLI = 'test_file'

    test_cli_mgr = MyCLIMgr()

    assert test_cli_mgr.is_available() == False
    assert test_cli_mgr._cli == None


# Generated at 2022-06-11 03:59:58.909018
# Unit test for constructor of class LibMgr
def test_LibMgr():
    """
    >>> class UnderTest(LibMgr):
    ...     """

# Generated at 2022-06-11 04:00:03.950672
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    pkg_mgr = CLIMgr()
    pkg_mgr.CLI = 'fake_cmd'
    assert pkg_mgr._cli is None
    assert pkg_mgr.is_available() == False
    pkg_mgr.CLI = 'python'
    assert pkg_mgr.is_available() == True
    assert pkg_mgr._cli.endswith('python')

# Generated at 2022-06-11 04:00:13.364266
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    from ansible.module_utils.common.collections import ImmutableDict
    # This test is performed on a simplified version of class PkgMgr
    class SimplifiedPkgMgr(PkgMgr):

        def __init__(self, installed_packages):


            self.list_installed_packages = installed_packages
            super(SimplifiedPkgMgr, self).__init__()

        def list_installed(self):
            return self.list_installed_packages

        def get_package_details(self, package):

            return {'name': package}

    # list_installed returns a list of installed packages, each list item will be passed to get_package_details

# Generated at 2022-06-11 04:00:15.936987
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    class TestPkgMgr(CLIMgr):
        CLI = 'test_cli'

    mgr = TestPkgMgr()
    assert mgr._cli is None



# Generated at 2022-06-11 04:00:16.499945
# Unit test for constructor of class LibMgr
def test_LibMgr():
    manager = LibMgr()
    assert manager


# Generated at 2022-06-11 04:00:18.599088
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    pkgname = "PkgMgr"
    pkgversion = "1.2.1"
    pkgrelease = "14.10"
    package = pkgname + "-" + pkgversion + "-" + pkgrelease
    pkg = PkgMgr()
    pkg.get_package_details(package)

# Generated at 2022-06-11 04:00:19.697269
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    assert LibMgr().is_available() == False


# Generated at 2022-06-11 04:00:20.528290
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pass


# Generated at 2022-06-11 04:00:29.149086
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    """Test whether method is_available in class CLIMgr works properly
    
    This method tests whether method CLIMgr.is_avalable() can find the correct binary file
    """
    import unittest
    import itertools
    import os
    
    class CLIMgrTest(unittest.TestCase):
        def test_CLIMgr_is_available(self):
            self.assertTrue(CLIMgrTest.is_available(self))
        
        def is_available(self, path='/bin/ls'):
            """Test whether method CLIMgr.is_available() can find the correct binary file.
            
            This method tests whether method CLIMgr.is_avalable() can find the correct binary file
            """
            
            CLI = __import__("ansible.module_utils.common.process")
            path

# Generated at 2022-06-11 04:01:05.060068
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():

    assert issubclass(PkgMgr, object) is True
    assert callable(PkgMgr.is_available) is True



# Generated at 2022-06-11 04:01:07.086174
# Unit test for constructor of class LibMgr
def test_LibMgr():
    assert LibMgr().__class__.__name__ == 'LibMgr'



# Generated at 2022-06-11 04:01:09.253400
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():

    class TestLibMgr(LibMgr):
        LIB = 'os'

    assert TestLibMgr().is_available()


# Generated at 2022-06-11 04:01:12.139559
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    # if is_available return False then test passed
    class TestMgr(PkgMgr):
        def is_available():
            return False
    test = TestMgr()
    assert not test.is_available()


# Generated at 2022-06-11 04:01:15.138714
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    test_cli_mgr = CLIMgr()
    test_cli_mgr.CLI = "cli"
    assert test_cli_mgr.CLI == "cli"


# Generated at 2022-06-11 04:01:16.642489
# Unit test for constructor of class LibMgr
def test_LibMgr():
    pkgMgr = LibMgr()
    assert pkgMgr is not None


# Generated at 2022-06-11 04:01:18.138513
# Unit test for constructor of class LibMgr
def test_LibMgr():
    assert LibMgr().__class__.__name__ == 'LibMgr'


# Generated at 2022-06-11 04:01:26.105420
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    # If CLI is None, ValueError should be raised
    class Test1(CLIMgr):
        pass

    t1 = Test1()
    try:
        t1.is_available()
    except ValueError:
        # The ValueError exception is correct
        pass
    else:
        # The test fails because no ValueError exception is raised
        raise Exception
    # If CLI is empty, ValueError should be raised
    class Test2(CLIMgr):
        CLI = ''

    t2 = Test2()
    try:
        t2.is_available()
    except ValueError:
        # The ValueError exception is correct
        pass
    else:
        # The test fails because no ValueError exception is raised
        raise Exception
    # If CLI is found, True should be returned

# Generated at 2022-06-11 04:01:27.383312
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    assert not PkgMgr.list_installed()


# Generated at 2022-06-11 04:01:30.284545
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    result = PkgMgr.get_packages(PkgMgr)
    assert result == {}, "Result should be an empty dictionary"

# Generated at 2022-06-11 04:02:51.776541
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class FakeCLI(CLIMgr):
        CLI = "pip"

    # Command exist
    pip = FakeCLI()
    assert(pip.is_available())

    # Command do not exist
    class FakeCLI(CLIMgr):
        CLI = "unexistCommand"

    fake_cli = FakeCLI()
    assert(not fake_cli.is_available())

# Generated at 2022-06-11 04:02:57.340539
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class MockPkgMgr(PkgMgr):
        def is_available(self):
            pass
        def list_installed(self):
            pass
    package = {"name": "foo", "version": "3.1.2"}
    pkgmgr = MockPkgMgr()
    result = pkgmgr.get_package_details(package)
    assert result["name"] == package["name"]
    assert result["version"] == package["version"]
    assert result["source"] == "mockpkgmgr"

# Generated at 2022-06-11 04:03:05.188710
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class DummyPkgMgr(PkgMgr):
        def __init__(self):
            self._lib = None
            super(PkgMgr, self).__init__()

        def is_available(self):
            return True

        def list_installed(self):
            return ["package1", "package2"]

        def get_package_details(self, package):
            # This takes a 'package' item and returns a dictionary with the package information
            return {"name": package}

    dummy_pkg_mgr = DummyPkgMgr()
    assert dummy_pkg_mgr.is_available() is True

# Generated at 2022-06-11 04:03:12.846993
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class PkgMgrTest(PkgMgr):
        def list_installed(self):
            return ['foo', 'bar']

        def get_package_details(self, package):
            # this is not an exhaustive list of all the possible options
            # for for a package details dictionary, but it is all that is
            # used by the get_packages method
            return {'name': 'foo', 'version': '0.0.1'}

    pkg_mgr = PkgMgrTest()
    assert pkg_mgr.get_packages() == {'foo': [{'name': 'foo', 'version': '0.0.1', 'source': 'PkgMgrTest'}]}


# Generated at 2022-06-11 04:03:20.700767
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    # Test data
    test_list = ['package1-1.0', 'package1-1.1', 'package2-2.0', 'package2-2.1']
    test_pkg1 = {'name': 'package1', 'version': '1.0', 'source': '__init__.py'}
    test_pkg2 = {'name': 'package1', 'version': '1.1', 'source': '__init__.py'}
    test_pkg3 = {'name': 'package2', 'version': '2.0', 'source': '__init__.py'}
    test_pkg4 = {'name': 'package2', 'version': '2.1', 'source': '__init__.py'}

# Generated at 2022-06-11 04:03:23.673799
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    class cli_test(CLIMgr):
        CLI = 'testcli'
    test_cli = cli_test()
    assert test_cli.CLI == 'testcli'


# Generated at 2022-06-11 04:03:27.593708
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    """
    LibMgr.is_available returns None if import of Lib fails
    """
    class TestLibMgr(LibMgr):
        LIB = 'some_lib'
    libmgr = TestLibMgr()
    assert libmgr.is_available() is None


# Generated at 2022-06-11 04:03:35.623961
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    from ansible.module_utils.common.collections import ImmutableDict

    class testPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ["pkg1", "pkg2"]
        def get_package_details(self, package):
            return ImmutableDict(dict(name=package, version="version", source="source"))

    # Test if the list_installed is taken as list and also if it contains integers
    class testPkgMgr2(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return [1, 2]
        def get_package_details(self, package):
            return ImmutableDict(dict(name=package, version="version", source="source"))

# Generated at 2022-06-11 04:03:38.532662
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    import unittest
    class TestLibMgrClass(LibMgr):
        LIB = "missing_module"

    test_class = TestLibMgrClass()
    assert test_class.is_available() == False
    assert test_class._lib == None


# Generated at 2022-06-11 04:03:39.984916
# Unit test for constructor of class LibMgr
def test_LibMgr():
    obj = LibMgr()
    assert obj._lib is None
