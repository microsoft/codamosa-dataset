

# Generated at 2022-06-11 03:56:53.193093
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():

    class SampleCLIMgr(CLIMgr):
        CLI = 'sampleCLIMgr'

    sampleCLIMgr = SampleCLIMgr()

    with mock.patch('ansible.module_utils.common._utils.get_bin_path') as mock_get_bin_path:
        mock_get_bin_path.return_value = 'foo/bar'
        assert sampleCLIMgr.is_available()

    with mock.patch('ansible.module_utils.common._utils.get_bin_path') as mock_get_bin_path:
        mock_get_bin_path.side_effect = ValueError()
        assert not sampleCLIMgr.is_available()

# Generated at 2022-06-11 03:56:55.418243
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    class TestCLIMgr(CLIMgr):
        CLI = 'testcli'
    manager = TestCLIMgr()
    assert manager._cli is None

# Generated at 2022-06-11 03:56:58.189400
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    pmgr = PkgMgr()
    packages = pmgr.get_packages()
    assert isinstance(packages, dict)
    assert len(packages) == 0


# Generated at 2022-06-11 03:56:59.545409
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    assert(PkgMgr.get_packages() is None)

# Generated at 2022-06-11 03:57:04.013452
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    import pytest

    pkgmgr_obj_list = [PkgMgr(), LibMgr(), CLIMgr()]

    for pkgmgr_obj in pkgmgr_obj_list:
        result = pkgmgr_obj.get_package_details("test")
        assert result == {}



# Generated at 2022-06-11 03:57:08.324508
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    class foo(PkgMgr):
        # Here we overwrite the abstract method is_available of PkgMgr
        def is_available(self):
            return True

        def list_installed(self):
            return ['pkg1', 'pkg2']

        def get_package_details(self, package):
            return {'name': package, 'version': '6.6.6'}

    p = foo()
    assert p.get_packages() == {'pkg1': [{'version': '6.6.6', 'name': 'pkg1', 'source': 'foo'}],
                                'pkg2': [{'version': '6.6.6', 'name': 'pkg2', 'source': 'foo'}]}

# Generated at 2022-06-11 03:57:10.119396
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    lm = LibMgr()
    assert lm.is_available() == False


# Generated at 2022-06-11 03:57:10.728018
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
   assert 'Hello' == 'Hello'

# Generated at 2022-06-11 03:57:11.506019
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    assert LibMgr().is_available() == False


# Generated at 2022-06-11 03:57:13.594400
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    import ansible.module_utils.ansible_free.package_manager.package_manager as pm
    test_package_manager = pm.CLIMgr()
    assert isinstance(test_package_manager, type(pm.CLIMgr))
    assert test_package_manager.is_available() == True


# Generated at 2022-06-11 03:57:21.843016
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    class PkgMgr2(PkgMgr):
        def is_available(self):
            return True
    pkg_mgr = PkgMgr2()
    pkg_mgr.list_installed = lambda: ['test']
    pkg_mgr.get_package_details = lambda x: {'name': 'test', 'version': '1.0.0'}
    pkgs = pkg_mgr.get_packages()
    assert pkgs == {'test': [{'name': 'test', 'version': '1.0.0', 'source': 'pkg_mgr2'}]}, 'test_PkgMgr_get_packages failed'

# Generated at 2022-06-11 03:57:26.331791
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class MyCLIMgr(CLIMgr):
        pass

    my_cli_mgr = MyCLIMgr()
    my_cli_mgr.CLI = 'missing_binary'
    assert not my_cli_mgr.is_available()

# Generated at 2022-06-11 03:57:29.629911
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    '''
    Test for checking if package list is empty which is fail case
    '''
    pkg_mgr_obj = PkgMgr()
    assert pkg_mgr_obj.list_installed() == []


# Generated at 2022-06-11 03:57:34.008088
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class CLIMgrTest(CLIMgr):
        CLI = 'uname'

    c = CLIMgrTest()
    assert c.is_available()

    class CLIMgrTest2(CLIMgr):
        CLI = 'unknown'

    c2 = CLIMgrTest2()
    assert not c2.is_available()

# Generated at 2022-06-11 03:57:40.321989
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    from ansible.module_utils.common.os import get_os_version_info

    os_info = get_os_version_info()
    pkgs = get_all_pkg_managers()
    for pkg_name, pkg_class in pkgs.items():
        pkg_instance = pkg_class()
        if pkg_instance.is_available():
            result = pkg_instance.list_installed()
            assert result, "list_installed returned None"
            assert isinstance(result, list), "list_installed returned incorrect value"


# Generated at 2022-06-11 03:57:41.494404
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    assert PkgMgr.list_installed is PkgMgr.list_installed


# Generated at 2022-06-11 03:57:49.989481
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class MyMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['mysql-server', 'mysql', 'mysql-client']
        def get_package_details(self, package):
            return {'name': package, 'version': '2.0.1'}
    mgr = MyMgr()
    pkgs = mgr.get_packages()

# Generated at 2022-06-11 03:57:55.854629
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    class PkgMgr_test(PkgMgr):
        def __init__(self):
            super(PkgMgr_test, self).__init__()
        def list_installed(self):
            return ['one', 'two']
        def get_package_details(self, package):
            return package
    pkgmgr = PkgMgr_test()
    assert pkgmgr.list_installed() == ['one', 'two']


# Generated at 2022-06-11 03:57:57.260739
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    cm = CLIMgr()
    assert cm.is_available() == False

# Generated at 2022-06-11 03:58:03.740442
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():

    class TestLibMgr(LibMgr):

        LIB = 'testlib'

    class TestCLIMgr(CLIMgr):

        CLI = 'testcli'

    test_libmgr1 = TestLibMgr()
    print(test_libmgr1.is_available())
    test_libmgr2 = TestCLIMgr()
    print(test_libmgr2.is_available())


if __name__ == '__main__':
    test_LibMgr_is_available()

# Generated at 2022-06-11 03:58:15.146475
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class CLIMgrTest(CLIMgr):
        CLI = 'test'

    plm = CLIMgrTest()
    with mock.patch('ansible.module_utils.common.process.get_bin_path', return_value=False) as mocked_get_bin_path:
        assert plm.is_available() == False
    with mock.patch('ansible.module_utils.common.process.get_bin_path', return_value=True) as mocked_get_bin_path:
        assert plm.is_available() == True

# Generated at 2022-06-11 03:58:16.531631
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert(CLIMgr())


# Generated at 2022-06-11 03:58:19.043890
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr.CLI is None
    assert CLIMgr()._cli is None
    assert CLIMgr().is_available() is False


# Generated at 2022-06-11 03:58:29.754736
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    class TestLibMgr(LibMgr):
        '''
        This is a test class for method get_packages of class PkgMgr
        TestLibMgr is inherited from LibMgr
        '''
        def list_installed(self):
            return ['pkg1', 'pkg2']

        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}

    class TestCLIMgr(CLIMgr):
        '''
        This is a test class for method get_packages of class PkgMgr
        TestCLIMgr is inherited from CLIMgr
        '''
        def list_installed(self):
            return ['pkg1', 'pkg2', 'pkg3']


# Generated at 2022-06-11 03:58:35.749999
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    mgr = CLIMgr()
    assert mgr.CLI is None
    assert mgr._cli is None

    # the class PkgMgr is the superclass
    assert isinstance(mgr, PkgMgr)

    # get_bin_path() raises a ValueError if the CLI is not found
    try:
        mgr._cli = get_bin_path(mgr.CLI)
    except ValueError:
        assert True
    except Exception:
        assert False, "unexpected exception raised"
    else:
        assert False, "expected ValueError not raised"



# Generated at 2022-06-11 03:58:38.588319
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    class TestCLIMgr(CLIMgr):
        CLI = 'cli'
    c = TestCLIMgr()
    assert isinstance(c, CLIMgr)



# Generated at 2022-06-11 03:58:40.329792
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr().CLI is None


# Generated at 2022-06-11 03:58:43.187941
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestClass(PkgMgr):
        def __init__(self):
            self.LIB = 'test'
    test_obj = TestClass()
    assert test_obj.is_available() == False

# Generated at 2022-06-11 03:58:44.409609
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    assert False


# Generated at 2022-06-11 03:58:46.485620
# Unit test for constructor of class LibMgr
def test_LibMgr():
    lm = LibMgr()
    assert lm
    assert lm._lib is None


# Generated at 2022-06-11 03:59:03.829123
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    from ansible.module_utils.common.os import ping

    # test_01: class LibMgr should return True if import of module py-ping succeeds
    assert LibMgr().is_available()

    # test_02: class LibMgr should return False if import of module py-ping fails
    assert not LibMgr().is_available()



# Generated at 2022-06-11 03:59:05.643418
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class test(LibMgr):
        LIB = 'test'

    obj = test()
    assert isinstance(obj, LibMgr)


# Generated at 2022-06-11 03:59:08.693376
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
  PkgMgr_obj = PkgMgr()
  try:
    PkgMgr_obj.list_installed()
  except NotImplementedError:
    return True
  else:
    return False


# Generated at 2022-06-11 03:59:10.064576
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    clm = CLIMgr()
    assert clm._cli is None


# Generated at 2022-06-11 03:59:12.197785
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pkgmgr = PkgMgr()
    assert pkgmgr.list_installed() == NotImplemented


# Generated at 2022-06-11 03:59:16.853103
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    import json
    from ansible.module_utils.facts.packages.pip import Pip

    pip = Pip()
    pip.is_available()
    installed_packages = pip.get_packages()
    print(json.dumps(installed_packages, indent=4, sort_keys=True))

if __name__ == '__main__':
    test_PkgMgr_get_packages()

# Generated at 2022-06-11 03:59:18.012971
# Unit test for constructor of class LibMgr
def test_LibMgr():
    obj = LibMgr()
    assert obj._lib is None


# Generated at 2022-06-11 03:59:19.260233
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pm = PkgMgr()
    packages = pm.list_installed()
    assert isinstance(packages, list), "list_installed must return a list"


# Generated at 2022-06-11 03:59:22.271743
# Unit test for constructor of class LibMgr
def test_LibMgr():
    with open('pkgmgr_test.py', 'w') as f:
        f.write('class pkgmgr_test(object):\n    pass')
    lm = LibMgr()
    assert lm._lib is None


# Generated at 2022-06-11 03:59:23.001430
# Unit test for constructor of class LibMgr
def test_LibMgr():
    LibMgr()


# Generated at 2022-06-11 03:59:52.037734
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    c_mgr = CLIMgr()
    assert c_mgr.is_available() == False

# Generated at 2022-06-11 03:59:54.177948
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    pkg_mgr = LibMgr()
    assert pkg_mgr.is_available() == False


# Generated at 2022-06-11 04:00:01.430534
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    import unittest
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgr

    class TestPkgMgr(PkgMgr):
        def list_installed(self):
            return ['foo']

        def get_package_details(self, package):
            pkg_dict = {'name': 'foo', 'version': '0.0.2', 'release': '1'}
            return pkg_dict

    mgr = TestPkgMgr()
    assert mgr.get_package_details('foo') == {'name': 'foo', 'version': '0.0.2', 'release': '1'}


# Generated at 2022-06-11 04:00:02.828627
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
	assert PkgMgr.is_available()==None


# Generated at 2022-06-11 04:00:12.171656
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class MacMock(PkgMgr):
        def __init__(self):
            pass
        def is_available(self):
            return True
        def list_installed(self):
            return ['shell', 'uname', 'ls']
        def get_package_details(self, package):
            package_info = {'name': package, 'version':'1.0'}
            return package_info
    m = MacMock()
    package_info = m.get_packages()
    assert package_info['shell'] == [{'name': 'shell', 'version': '1.0'}]
    assert package_info['uname'] == [{'name': 'uname', 'version': '1.0'}]

# Generated at 2022-06-11 04:00:20.963475
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def list_installed(self):
            return ['a', 'b']

        def get_package_details(self, package):
            return {}

    pkg_mgr = TestPkgMgr()

    pkg_mgr.list_installed = MagicMock(return_value=['a', 'b', 'c'])
    pkg_mgr.get_package_details = MagicMock(return_value={'name': 'd', 'version': '1.2.3'})
    res = pkg_mgr.get_packages()
    assert res == {'d': [{'name': 'd', 'version': '1.2.3', 'source': 'testpkgmgr'}]}
    pkg_mgr.get_package_details.assert_

# Generated at 2022-06-11 04:00:28.686076
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    # Testing with sample data
    package = 'kernel-image-2.6.32-5-686'
    expected_result = {'name': 'kernel-image-2.6.32-5-686',
                       'version': '2.6.32-27',
                       'arch': 'i386',
                       'release': '2',
                       'source': 'apt'}
    # Fetching data from Debian package manager
    from ansible.module_utils.facts import debian as debian_module
    debian = debian_module.AptFactCollector()
    actual_result = debian.get_package_details(package)
    # Comparing the results
    assert actual_result == expected_result

# Generated at 2022-06-11 04:00:31.514141
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class LibMgr_test(LibMgr):
        LIB = 'ansible.module_utils.facts.packages.apt'

    lm = LibMgr_test()
    assert lm.is_available() == True


# Generated at 2022-06-11 04:00:32.719411
# Unit test for constructor of class LibMgr
def test_LibMgr():
    instance = LibMgr()
    assert instance


# Generated at 2022-06-11 04:00:33.569745
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    assert PkgMgr.list_installed() is None

# Generated at 2022-06-11 04:01:36.916324
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    class TestPkgMgr(PkgMgr):

        def is_available(self):
            return True

        def list_installed(self):
            return ['a', 'b']

        def get_package_details(self, package):
            return {'name': package, 'version': package}

    tpm = TestPkgMgr()
    result = tpm.get_packages()
    expected = {'a': [{'name': 'a', 'version': 'a', 'source': 'testpkgmgr'}],
                'b': [{'name': 'b', 'version': 'b', 'source': 'testpkgmgr'}]}

    assert result == expected

# Generated at 2022-06-11 04:01:38.982195
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class DummyCLIMgr(CLIMgr):
        CLI = None
    dummy_CLIMgr = DummyCLIMgr()
    assert dummy_CLIMgr.is_available() is False

# Generated at 2022-06-11 04:01:46.769123
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class test_PkgMgr(PkgMgr):
        def __init__(self):
            super(test_PkgMgr, self).__init__()

        def is_available(self):
            return True

        def list_installed(self):
            return ['nameA 1.0.0', 'nameB 2.0.0', 'nameC 1.0.0']

        def get_package_details(self, package):
            package = package.split()
            return {'name': package[0], 'version': package[1]}
    cls = test_PkgMgr()
    packages = cls.get_packages()

    assert packages['nameA'] == [{'name': 'nameA', 'version': '1.0.0', 'source': 'test_pkgmgr'}]

# Generated at 2022-06-11 04:01:53.811397
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    import sys
    cli = CLIMgr()
    sys.modules['ansible_collections.ansible.community.plugins.module_utils.facts.system.pkg_mgr'] = cli
    sys.modules['ansible_collections.ansible.community.plugins.module_utils.facts.system.pkg_mgr.CLIMgr'] = cli
    mgr = PkgMgr()
    assert mgr._cli is None
    del sys.modules['ansible_collections.ansible.community.plugins.module_utils.facts.system.pkg_mgr']
    del sys.modules['ansible_collections.ansible.community.plugins.module_utils.facts.system.pkg_mgr.CLIMgr']


# Generated at 2022-06-11 04:02:01.816802
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    #test_list = ['one', 'two', 'three', 'four']
    #test_dict = {'name': 'test', 'version': '0.0.1'}
    #test_list_of_dict = [test_dict]

    #test_parent = PkgMgr()

    #test_parent.list_installed = lambda: test_list
    #test_parent.get_package_details = lambda x: test_dict

    #assert test_parent.get_packages() == {'test': [test_dict, test_dict, test_dict, test_dict]}


    test_list = ['one', 'two', 'three', 'four']
    test_dict = {'name': 'test', 'version': '0.0.1'}
    test_list_of_dict = [test_dict]



# Generated at 2022-06-11 04:02:04.743680
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():

    import unittest

    class TestPkgMgrListInstalled(unittest.TestCase):
        def test_list_installed(self):
            self.fail("Not Implemented")

    unittest.main(module='test_PkgMgr', exit=False)

# Generated at 2022-06-11 04:02:05.520048
# Unit test for constructor of class LibMgr
def test_LibMgr():
    assert LibMgr()



# Generated at 2022-06-11 04:02:13.578443
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():

    class DummyCLIMgr(CLIMgr):
        CLI = 'dummy'

    class DummyPkgMgrs:
        dummy = DummyCLIMgr()

    # Check if it is available when PATH contains it.
    import ansible.module_utils.common.utils
    import os
    import shutil
    import tempfile
    import stat

    path = ansible.module_utils.common.utils.get_bin_path('python')
    if not path:
        raise AssertionError('python executable not found in PATH')
    dummy_cli_dir = tempfile.mkdtemp()
    dummy_cli_path = os.path.join(dummy_cli_dir, 'dummy')
    shutil.copy(path, dummy_cli_path)

# Generated at 2022-06-11 04:02:15.962903
# Unit test for constructor of class LibMgr
def test_LibMgr():

    # Arrange
    _LibMgr = LibMgr()

    # Act

    # Assert
    assert _LibMgr is not None


# Generated at 2022-06-11 04:02:17.229595
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    installed_packages = {}
    PkgMgr.get_packages(installed_packages)

# Generated at 2022-06-11 04:04:36.233912
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():

    assert(PkgMgr.get_package_details({"name": "test"}) == {"name": "test"})


# Generated at 2022-06-11 04:04:37.631437
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    test_pkg_mgr = PkgMgr()
    assert test_pkg_mgr.list_installed()


# Generated at 2022-06-11 04:04:38.387251
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    manager_object = CLIMgr()

# Generated at 2022-06-11 04:04:45.079572
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    """
    Test custom method get_packages for class PkgMgr
    """
    # Define a dummy class inheriting from PkgMgr
    class DummyPkgMgr(PkgMgr):
        def is_available(self):
            return True

        def list_installed(self):
            return ["packageA", "packageB"]

        def get_package_details(self, package):
            return {'name': package, 'version': "1.0", 'source': "dummy"}

    # Initialize the class and test the method
    dummy_pkgmgr = DummyPkgMgr()
    result = dummy_pkgmgr.get_packages()

    # Prepare expected result

# Generated at 2022-06-11 04:04:49.481405
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    class myPkgMgr(PkgMgr):

        def is_available(self):
            return True

        def list_installed(self):
            return ['pkg1', 'pkg2']

        def get_package_details(self, package):
            package_details = {
                'name': package,
                'version': '0.0.1',
            }
            return package_details

    pkgmgr = myPkgMgr()
    packages = pkgmgr.get_packages()
    assert len(packages['pkg1']) == 1
    assert len(packages['pkg2']) == 1

# Generated at 2022-06-11 04:04:50.360666
# Unit test for constructor of class LibMgr
def test_LibMgr():
    new_libmgr = LibMgr()



# Generated at 2022-06-11 04:04:50.947177
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    assert(False)



# Generated at 2022-06-11 04:04:52.953634
# Unit test for constructor of class LibMgr
def test_LibMgr():

    class testPkgMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.system.pkg_mgrs.test'

    l = testPkgMgr()
    assert l.is_available() == False


# Generated at 2022-06-11 04:04:55.449324
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class MyCLIMgr(CLIMgr):
        CLI = "Fake_CLI"

    m = MyCLIMgr()

    assert m.is_available() == False

    class MyCLIMgr(CLIMgr):
        CLI = "python"

    m = MyCLIMgr()

    assert m.is_available() == True

# Generated at 2022-06-11 04:04:57.515583
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class NoLib(LibMgr):
        LIB = 'nonexistent'
    assert NoLib().is_available() is False
    class SomeLib(LibMgr):
        LIB = 're'
    assert SomeLib().is_available() is True
