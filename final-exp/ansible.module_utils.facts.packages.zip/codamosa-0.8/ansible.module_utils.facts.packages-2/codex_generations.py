

# Generated at 2022-06-11 03:56:59.309003
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    import sys
    import os
    import json
    import tempfile
    import shutil
    import operator

    class MockPkgMgr(PkgMgr):

        def __init__(self):
            super(MockPkgMgr, self).__init__()

        def is_available(self):
            return True

        def list_installed(self):
            return ['pkg1', 'pkg2', 'pkg3', 'pkg3-2']

        def get_package_details(self, package):
            if package == 'pkg1':
                pkg_name = 'pkg1'
                pkg_version = '1.0'
            elif package == 'pkg2':
                pkg_name = 'pkg2'
                pkg_version = '1.0'
            elif package == 'pkg3':
                p

# Generated at 2022-06-11 03:57:03.055387
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    from ansible.module_utils.common.process import get_bin_path
    P = CLIMgr()
    assert P.is_available() == False
    P.CLI = "python"
    assert P.is_available() == True



# Generated at 2022-06-11 03:57:12.474193
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    import sys
    from ansible.module_utils._text import to_text, to_native

    # Test the following scenario
    # Given the magicmock version module does not exist (version is not imported)
    # When magicmock version is imported
    # Then the result is False
    # And the version module is not in the syspath
    import sys as sysmock
    with mock.patch.dict(sysmock.modules, {}):
        # Given magicmock version module does not exist
        assert 'version' not in sysmock.modules
        # When magicmock version is imported
        with mock.patch('ansible.module_utils.facts.collector.version.__name__', 'version'):
            # Then the result is True
            assert is_available()
            # And the version module is imported
            assert 'version'

# Generated at 2022-06-11 03:57:14.896407
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    try:
        import pkg_resources
        pkg_resources  # workaround pyflakes issue #13
    except ImportError:
        return False
    return True


# Generated at 2022-06-11 03:57:18.694911
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():

    test_object = LibMgr()
    # __init__ 'method' will be invoked
    assert test_object._lib is None
    # is_available 'method' will be invoked
    if test_object.is_available():
        assert test_object._lib is not None
    else:
        assert test_object._lib is None


# Generated at 2022-06-11 03:57:21.339671
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pm = PkgMgr()
    # Test if is_available return False
    if pm.is_available():
        raise AssertionError("Test if is_available return False failed")


# Generated at 2022-06-11 03:57:30.949093
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    def mock_list_installed():
        return listinstalled

    def mock_get_package_details(package):
        return package

    listinstalled = ['package1', 'package2']
    pkg_mgr = PkgMgr()
    pkg_mgr.list_installed = mock_list_installed
    pkg_mgr.get_package_details = mock_get_package_details
    assert pkg_mgr.get_packages() == dict([
        ('package1', [{'name': 'package1'}]),
        ('package2', [{'name': 'package2'}])
    ])

test_PkgMgr_get_package_details()

# Generated at 2022-06-11 03:57:33.459040
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    class TestCLIMgr(CLIMgr):
        CLI = 'test'
    assert TestCLIMgr()._cli is None
    assert TestCLIMgr().CLI == 'test'

# Generated at 2022-06-11 03:57:40.765644
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    from ansible.module_utils.common.process import get_bin_path
    from ansible_collections.ansible.ansible_galaxy.plugins.modules.package_facts import get_managed_packages
    from ansible_collections.ansible.ansible_galaxy.plugins.module_utils.package.yum import Yum
    pkg_mgr = Yum()
    if pkg_mgr.is_available():
        pkg_mgr.list_installed()
        pkg_mgr.get_package_details('bash')
        pkg_mgr.get_packages()
        get_managed_packages()
    else:
        pass

# Generated at 2022-06-11 03:57:42.000165
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pm = PkgMgr()
    assert(False == pm.list_installed())


# Generated at 2022-06-11 03:57:56.110665
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():

    try:
        from ansible.module_utils.common._collections_compat import OrderedDict
    except ImportError:
        from collections import OrderedDict

    from ansible.module_utils.facts import collector

    dummy_pkg_mgr = collector.PackageManagerFactCollector()
    dummy_pkg_mgr.pkg_mgr = PkgMgr()

    # Test if method list_installed(self), which is abstract and must be overriden
    # by a subclass, raises a TypeError as intended.
    try:
        dummy_pkg_mgr.pkg_mgr.list_installed()
        raise AssertionError("Expected 'TypeError' is not raised by abstract method,"
                             " list_installed(self).")
    except TypeError:
        pass

    # Test if method get_package_details(

# Generated at 2022-06-11 03:58:04.849760
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    # Check that CLI is set
    class TestCLIMgr1(CLIMgr):
        CLI = None

    # Check that class is available
    class TestCLIMgr2(CLIMgr):
        CLI = 'fake_binary'

    test_class1 = TestCLIMgr1()
    assert test_class1.CLI is None
    assert test_class1.is_available() is False

    test_class2 = TestCLIMgr2()
    assert test_class2.CLI == 'fake_binary'
    # Simulate unavailability
    test_class2.is_available = lambda: False
    assert test_class2.is_available() is False
    assert test_class2._cli is None



# Generated at 2022-06-11 03:58:07.613676
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'sys'

    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr.is_available() == True


# Generated at 2022-06-11 03:58:10.935082
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCLIMgr(CLIMgr):
        CLI = 'test_CLIMgr'

    test_CLIMgr = TestCLIMgr()

    # No CLI executable found
    assert test_CLIMgr.is_available() == False

    # CLI executable found
    test_CLIMgr._cli = 'test_CLIMgr_available'
    assert test_CLIMgr.is_available()

# Generated at 2022-06-11 03:58:12.124700
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    pkg_mgr = CLIMgr()
    assert pkg_mgr is not None

# Generated at 2022-06-11 03:58:19.362522
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    class TestPkgMgr(PkgMgr):

        def list_installed(self):
            return ["package_item"]

        def get_package_details(self, package):
            return {'name': 'package_name', 'version': 'package_version', 'source': 'test_pkg_mgr'}

    pm = TestPkgMgr()

    assert pm.get_packages() == {'package_name': [{'name': 'package_name', 'version': 'package_version', 'source': 'test_pkg_mgr'}]}

# Generated at 2022-06-11 03:58:30.158499
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    # Test case 1: _cli is not None
    try:
        import shutil
        shutil.which = lambda x: True
        shutil.which.__name__ = "True"
        from ansible.module_utils.ansible_release import CLIMgr
        if CLIMgr.CLI is None:
            assert True
    except ImportError:
        assert True
    else:
        assert True

    # Test case 2: _cli is None

# Generated at 2022-06-11 03:58:32.783074
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():

    class TestLibMgr(LibMgr):

        LIB = 'datetime'

    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr.is_available()

# Generated at 2022-06-11 03:58:33.549729
# Unit test for constructor of class LibMgr
def test_LibMgr():
    assert LibMgr()
    assert PkgMgr()

# Generated at 2022-06-11 03:58:40.475587
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    import os
    import tempfile
    temp_file = tempfile.NamedTemporaryFile(mode='w', delete=False)
    temp_file.close()
    os.chmod(temp_file.name, 0o755)
    test_mgr = CLIMgr()
    test_mgr.CLI = temp_file.name
    assert test_mgr.is_available()
    os.remove(temp_file.name)
    assert test_mgr.is_available() == False


# Generated at 2022-06-11 03:58:54.013438
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class MyPkgMgr(PkgMgr):
        def list_installed(self):
            return ["vim"]

        def get_package_details(self, package):
            return {'name': package, 'version': '2.0', 'source': 'cli'}

    m = MyPkgMgr()
    assert isinstance(m.get_packages(), dict)

# Generated at 2022-06-11 03:59:02.117980
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    from ansible.module_utils.facts.packages import PkgMgr
    # test 1
    pm = PkgMgr()
    assert pm.is_available() == False
    # test 2
    class PkgMgr_sc(PkgMgr):
        CLI = 'sh'
        def __init__(self):
            self._cli = None
            super(PkgMgr, self).__init__()
    pm = PkgMgr_sc()
    assert pm.is_available() == True
    # test 3
    class PkgMgr_sc2(PkgMgr):
        CLI = 'python'
        def __init__(self):
            self._cli = None
            super(PkgMgr, self).__init__()
    pm = PkgMgr_sc2()

# Generated at 2022-06-11 03:59:03.370289
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    assert LibMgr().is_available()


# Generated at 2022-06-11 03:59:12.498262
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    test_cases=( {'pacman':{'name':'pacman','version':'5.1.2','source':'pacman'},'pacman-5.1.2':{'name':'pacman','version':'5.1.2','source':'pacman'},'pacman-5.1.2-1':{'name':'pacman','version':'5.1.2-1','source':'pacman'},'pacman-5.1.2-1-x86_64':{'name':'pacman','version':'5.1.2-1-x86_64','source':'pacman'}})
    for test_case in test_cases:
        for input, output in test_case.items():
         result = PkgMgr().get_package_details(input)

# Generated at 2022-06-11 03:59:13.761280
# Unit test for constructor of class LibMgr
def test_LibMgr():

    libmgr = LibMgr()
    assert libmgr


# Generated at 2022-06-11 03:59:21.749939
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():

    packages = {}
    packages["package1"] = {"name": "package1", "version": "1.0.0"}
    packages["package2"] = {"name": "package2", "version": "2.0.0"}
    packages["package3"] = {"name": "package1", "version": "1.0.1"}

    class CMgr(PkgMgr):
        def list_installed(self):
            return list(packages.keys())

        def get_package_details(self, package):
            return packages.get(package)

    cmgr = CMgr()

    # test dict with packages
    packages_dict = cmgr.get_packages()
    assert len(packages_dict.keys()) == 2
    assert len(packages_dict.get("package1")) == 2

# Generated at 2022-06-11 03:59:23.500163
# Unit test for constructor of class LibMgr
def test_LibMgr():
    lib = LibMgr()
    lib._lib = __import__('__missing__')

    assert(lib.is_available() == False)


# Generated at 2022-06-11 03:59:24.888756
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    c = CLIMgr()
    assert c.CLI == None
    assert c._cli == None


# Generated at 2022-06-11 03:59:30.455812
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    import os
    import os.path
    import unittest
    import sys
    
    class LibMgr_is_available(LibMgr, unittest.TestCase):
        def setUp(self):
            LibMgr.__init__(self)
            unittest.TestCase.__init__(self)
            self.LIB = 'undefined'
        def runTest(self):
            self.assertFalse(self.is_available())
            
    class LibMgr_is_available_faked_lib(LibMgr, unittest.TestCase):
        def setUp(self):
            LibMgr.__init__(self)
            unittest.TestCase.__init__(self)
            self.LIB = 'faked_lib'
        def runTest(self):
            self.assertFalse

# Generated at 2022-06-11 03:59:33.974798
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    pkgmgr=PkgMgr()
    try:
        pkgmgr.get_package_details('abc')
    except NotImplementedError:
        print('test_PkgMgr_get_package_details passed.')
        return True
    return False


# Generated at 2022-06-11 03:59:59.687884
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    # Test if the method returns a dictionary as expected
    # Nothing to assert/verify here, just set up the mocks and test whether the
    # method returns the expected value or throws an exception

    class MockPkgMgr(PkgMgr):
        def __init__(self):
            super(MockPkgMgr, self).__init__()

        def is_available(self):
            return False

        def list_installed(self):
            return []

        def get_package_details(self, package):
            return {}

    mock_pkg_mgr = MockPkgMgr()

    # Test whether the method returns a dictionary
    assert isinstance(mock_pkg_mgr.get_packages(), dict)

# Generated at 2022-06-11 04:00:08.601774
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    import ansible.module_utils.common.systemd as systemd

    class PkgManager:
        def list_installed(self):
            return ['foo']

        def get_package_details(self, package):
            if package == 'foo':
                return systemd.Systemd._get_unit_info('foobar.service')
            return {}

    pkg_manager = PkgManager()
    pkg_manager.list_installed = pkg_manager.list_installed
    pkg_manager.get_package_details = pkg_manager.get_package_details
    packages = pkg_manager.get_packages()
    assert packages['foobar.service'] == [pkg_manager.get_package_details('foo')], packages['foobar.service']

# Generated at 2022-06-11 04:00:17.484042
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    pkg_mgr = get_all_pkg_managers()
    # First make sure we have classes that extend the class LibMgr
    assert len(pkg_mgr) > 0
    # Check that each package manager class in fact extends the class LibMgr
    for pkg in pkg_mgr:
        assert issubclass(pkg_mgr[pkg], LibMgr)
    # Create a list of available package managers
    available_pkg_mgr = []
    for pkg in pkg_mgr:
        try:
            p = pkg_mgr[pkg]()
            assert p.is_available()
            available_pkg_mgr.append(p)
        except ValueError:
            pass
    # Make sure that the list of available package managers contains at least one package manager

# Generated at 2022-06-11 04:00:18.861262
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCLIMgr(CLIMgr):
        CLI = 'python'
    t = TestCLIMgr()
    assert t.is_available()


# Generated at 2022-06-11 04:00:22.455938
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    try:
        exec('from ansible.module_utils.facts.system.pkg_mgr.{0} import {0}'.format('apk'))
        test_mgr = apk()
        test_mgr.is_available()
        assert True
    except ImportError:
        assert True

# Generated at 2022-06-11 04:00:23.977679
# Unit test for constructor of class LibMgr
def test_LibMgr():
    test_class = LibMgr()
    assert isinstance(test_class, PkgMgr)
    assert test_class._lib == None


# Generated at 2022-06-11 04:00:25.595589
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():

    assert PkgMgr.get_package_details(PkgMgr,'asdf') == {}

# Generated at 2022-06-11 04:00:29.112329
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    if __name__ == "__main__":
        my_CLIMgr = CLIMgr()
        CLI_path = my_CLIMgr.is_available()
        if CLI_path:
            print("CLI path is: " + CLI_path)
        else:
            print("CLI path is not set")


# Generated at 2022-06-11 04:00:32.064316
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():

    class TestClass(LibMgr):
        LIB = 'test' 

        def __init__(self):
            super(TestClass, self).__init__()

    tc = TestClass()
    assert tc.is_available() == None


# Generated at 2022-06-11 04:00:40.396612
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    import sys
    import platform
    import os

    #Test empty CLI
    test_lib_mgr = LibMgr()
    test_lib_mgr.LIB = ''
    if not test_lib_mgr.is_available():
        print('Test for empty CLI passed')
    else:
        print('Test for empty CLI failed')

    #Test platform
    if platform.system() == 'Linux':
        test_lib_mgr.LIB = 'platform'
        if test_lib_mgr.is_available():
            print('Test for CLI platform passed')
        else:
            print('Test for CLI platform failed')

    #Test os
    test_lib_mgr.LIB = 'os'
    if test_lib_mgr.is_available():
        print('Test for CLI os passed')
    else:
        print

# Generated at 2022-06-11 04:01:20.345065
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():

    # Verify that the function returns a dictionary and that the count of items in the dictionary is as expected
    # Future: once we have a more specific answer to what the expected number is, we can add that as an expectation to this test
    pkg_managers = get_all_pkg_managers()
    assert type(pkg_managers) == dict
    assert len(pkg_managers) > 0

# Generated at 2022-06-11 04:01:22.654953
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    # Test case 1

    # Expected result is False
    # Second argument is the CLI to be searched
    assert CLIMgr.is_available(CLIMgr(), "wafwaf") == False



# Generated at 2022-06-11 04:01:25.101560
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    assert len(get_all_pkg_managers()) > 0
    for pkg_mgr in get_all_pkg_managers():
        assert pkg_mgr.is_available() == True



# Generated at 2022-06-11 04:01:30.748981
# Unit test for constructor of class LibMgr
def test_LibMgr():

    class TestMgr(LibMgr):
        LIB = 'yaml'

    assert TestMgr().is_available() is bool(get_bin_path('yaml-config'))
    assert TestMgr().get_packages() is None
    assert TestMgr().list_installed() is None
    assert TestMgr().get_package_details('package_not_exist') is None


# Generated at 2022-06-11 04:01:31.967833
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    mgr = CLIMgr()
    assert mgr._cli is None


# Generated at 2022-06-11 04:01:33.792756
# Unit test for constructor of class LibMgr
def test_LibMgr():
    try:
        lm = LibMgr()
    except NameError:
        assert True
    else:
        assert False



# Generated at 2022-06-11 04:01:36.672998
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    class testMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['abc']
    cls = testMgr()
    assert cls.list_installed() == ['abc']

# Generated at 2022-06-11 04:01:39.901208
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    assert(not PkgMgr.is_available(None))
    assert(not PkgMgr.list_installed(None))
    assert(not PkgMgr.get_package_details(None, None))
    assert(not PkgMgr.get_packages(None))


# Generated at 2022-06-11 04:01:40.743122
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    assert True



# Generated at 2022-06-11 04:01:48.470863
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    import os, sys
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgr
    from ansible.module_utils.facts.system.pkg_mgr import LibMgr
    from ansible.module_utils.facts.system.pkg_mgr import CLIMgr

    def setup_module():

        # directories in which we will create files
        dir_d = dict(
            # have a directory that has no packages
            dir_no_pkg_files="dir_no_pkg_files",
            # have a directory that has packages
            dir_pkg_files="dir_pkg_files",
            # have a directory that is not available
            dir_does_not_exist="dir_does_not_exist",
        )

        # create the directories

# Generated at 2022-06-11 04:03:09.524705
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():

    pkgmgr = PkgMgr()
    package_details = pkgmgr.get_package_details()
    assert package_details['name'] is not None
    assert package_details['version'] is not None


# Generated at 2022-06-11 04:03:17.773090
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class SubPkgMgr(PkgMgr):
        def list_installed(self):
            return ['package_1', 'package_2', 'package_3']

        def get_package_details(self, package):
            details = {'name': package, 'version': '1.0.0'}
            return details

    instance = SubPkgMgr()
    packages = instance.get_packages()

# Generated at 2022-06-11 04:03:26.149083
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    test_package_information = {'name': 'ansible'}
    test_package = PkgMgr()
    assert test_package.get_packages() == {}
    test_package.list_installed = lambda x, y: [1]
    test_package.get_package_details = lambda x, y: test_package_information
    result = test_package.get_packages()
    assert isinstance(result, dict)
    assert result == {'ansible': [test_package_information]}
    assert result == {'ansible': [{'name': 'ansible', 'source': 'pkgmgr'}]}


if __name__ == '__main__':

    exit(test_PkgMgr_get_packages())

# Generated at 2022-06-11 04:03:29.157577
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
  pkg_mgr = PkgMgr()
  try:
    pkg_mgr.list_installed()
  except NotImplementedError:
    pass
  else:
    assert False, 'Expected NotImplementedError'


# Generated at 2022-06-11 04:03:31.995794
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    from ansible.module_utils.facts.system.pkg_mgr import AptMgr
    mm = AptMgr()
    print(mm.list_installed())


if __name__ == '__main__':
    test_PkgMgr_list_installed()

# Generated at 2022-06-11 04:03:39.844728
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):

        def is_available(self):
            return False

        def list_installed(self):
            return [{'name': 'a'}, {'name': 'b'}]

        def get_package_details(self, package):
            return package

    test_pkg = TestPkgMgr()
    result = test_pkg.get_packages()
    assert isinstance(result, dict)
    assert len(result) == 2
    assert isinstance(result['a'], list)
    assert result['a'][0]['name'] == 'a'
    assert isinstance(result['b'], list)
    assert result['b'][0]['name'] == 'b'

# Generated at 2022-06-11 04:03:41.078630
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    module = PkgMgr()
    assert module.list_installed() is not None


# Generated at 2022-06-11 04:03:49.128805
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    import os
    import shutil
    import tempfile
    import distutils.sysconfig
    import pkg_resources

    class PkgMgrTest(LibMgr):
        LIB = 'distutils.sysconfig'

        def list_installed(self):
            return [pkg_resources.packaging.version.Version('1.4')]

        def get_package_details(self, package):
            return {'name': self.__class__.__name__.lower(),
                    'version': str(package),
                    'source': 'test'}

    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-11 04:03:57.632920
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    # Test for ansible-pkg_mgm.py
    import ansible.module_utils.ansible_pkg_mgm as ansible_pkg_mgm
    import ansible.module_utils.ansible_pkg_mgm.dpkg as dpkg
    import ansible.module_utils.ansible_pkg_mgm.rpm as rpm
    import ansible.module_utils.ansible_pkg_mgm.pacman as pacman
    import ansible.module_utils.ansible_pkg_mgm.yum as yum
    import ansible.module_utils.ansible_pkg_mgm.apk as apk
    import ansible.module_utils.ansible_pkg_mgm.pkgutil as pkgutil


# Generated at 2022-06-11 04:03:59.249129
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    test_obj = LibMgr()
    avail = test_obj.is_available()
    assert avail == False
