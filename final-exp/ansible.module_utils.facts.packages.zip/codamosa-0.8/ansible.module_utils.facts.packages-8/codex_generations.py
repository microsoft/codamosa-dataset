

# Generated at 2022-06-11 03:56:52.528575
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    try:
        cli_mgr = CLIMgr()
    except AttributeError:
        print('AttributeError raised whilst instantiating CLIMgr')
    except TypeError:
        print('TypeError raised whilst instantiating CLIMgr')
    except Exception:
        print('Other exception whilst instantiating CLIMgr')


# Base for all library-based package managers

# Generated at 2022-06-11 03:57:00.441196
# Unit test for constructor of class LibMgr
def test_LibMgr():

    class Apt(LibMgr):

        LIB = 'apt'

    class B(LibMgr):

        LIB = 'b'

    # These import_module calls MUST be here, because the class MgrDependencies
    # (the super class above) parses the modules with the import time of the
    # constructor of the classes
    try:
        __import__(Apt.LIB)
        __import__(B.LIB)
    except ImportError:
        pass

    apt = Apt()
    assert apt.is_available()

    b = B()
    assert not b.is_available()

# Generated at 2022-06-11 03:57:02.608682
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    # return False
    ret = PkgMgr.is_available()
    assert type(ret) is bool
    assert ret == False


# Generated at 2022-06-11 03:57:04.486327
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    a = CLIMgr()
    a.CLI = 'echo'
    b = CLIMgr()
    b.CLI = 'not_echo'
    assert a.is_available() == True
    assert b.is_available() == False


# Generated at 2022-06-11 03:57:05.723319
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    lm = LibMgr()
    assert(lm.is_available()==False)
    assert(lm._lib==None)


# Generated at 2022-06-11 03:57:07.676460
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():

    pkg_mgrs = get_all_pkg_managers()
    assert isinstance(pkg_mgrs, dict)
    assert 'apt' in pkg_mgrs
    assert 'zypper' in pkg_mgrs


# Generated at 2022-06-11 03:57:15.316712
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class TestMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return [{"name": "ansible", "version": "2.6.0"}]
        def get_package_details(self, package):
            return {"name": package["name"], "version": package["version"]}

    pkg_mgr = TestMgr()
    assert pkg_mgr.get_package_details({"name": "ansible", "version": "2.6.0"}) == {"name": "ansible", "version": "2.6.0"}


# Generated at 2022-06-11 03:57:17.267184
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    mgr = CLIMgr()
    assert mgr._cli is None
    assert mgr.is_available() is False

# Generated at 2022-06-11 03:57:28.164245
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestMgr(CLIMgr):
        CLI = "test"

    mgr = TestMgr()

    # test failure
    get_bin_path_mock = {'succeed': False, 'exp_bin': 'test'}

    def mocked_get_bin_path(*args, **kwargs):
        if not get_bin_path_mock['succeed']:
            raise ValueError("test")
        if get_bin_path_mock['exp_bin'] == args[0]:
            return args[0]
        raise ValueError("test")

    get_bin_path_orig = get_bin_path
    get_bin_path = mocked_get_bin_path
    result = mgr.is_available()
    get_bin_path = get_bin_path_orig

# Generated at 2022-06-11 03:57:34.007419
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestMgr(LibMgr):
        LIB = "test_lib"
    class TestMgrNotAvailable(LibMgr):
        LIB = "test_lib_not_available"
    tm = TestMgr()
    assert tm.is_available() == True, 'TestMgr is available'
    tmna = TestMgrNotAvailable()
    assert tmna.is_available() == False, 'TestMgr is not available'


# Generated at 2022-06-11 03:57:41.730349
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    class Child(CLIMgr):
        CLI = 'ls'
    assert Child().CLI == 'ls'

# Generated at 2022-06-11 03:57:43.991517
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    # Initiate object of class CLIMgr
    class_object = CLIMgr()
    # Return true if method is_available return true
    assert class_object.is_available() is True


# Generated at 2022-06-11 03:57:48.317467
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    cmd = 'command'
    with mock.patch('ansible.module_utils.common._utils.get_bin_path', side_effect=ValueError('error')):
        assert CLIMgr() is not None
    with mock.patch('ansible.module_utils.common._utils.get_bin_path', return_value=cmd):
        assert CLIMgr() is not None

# Generated at 2022-06-11 03:57:49.988915
# Unit test for constructor of class LibMgr
def test_LibMgr():
    test_libmgr = LibMgr()
    assert test_libmgr._lib is None


# Generated at 2022-06-11 03:57:59.720436
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    from collections import Counter
    fail_msg = "get_package_details() does not return the expected dictionary for package {}"
    for cls in get_all_subclasses(PkgMgr):
        if cls not in (CLIMgr, LibMgr):
            pkg_mgr = cls()

            if pkg_mgr.is_available():
                pkg_dict = {'installed': pkg_mgr.get_packages()}

                for package_name in pkg_dict['installed']:
                    # Verify that the package name is returned by get_package_details()
                    package_dict = pkg_mgr.get_package_details(package_name)
                    assert 'name' in package_dict,\
                        "%s package name is not in package dictionary %s" % (package_name, package_dict)


# Generated at 2022-06-11 03:58:01.538165
# Unit test for constructor of class LibMgr
def test_LibMgr():
    assert LibMgr().__class__.__name__ == 'LibMgr'


# Generated at 2022-06-11 03:58:07.319141
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    class TestPkgMgr(PkgMgr):

        def is_available(self):
            return True

        def list_installed(self):
            return ['test_package']

        def get_package_details(self, package):
            return {'name': 'test_package', 'version': '1.0', 'source': 'testPkgMgr'}

    test = TestPkgMgr()
    assert isinstance(test.get_packages(), dict)


# Generated at 2022-06-11 03:58:09.464493
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    lib_mgr = LibMgr()
    assert not lib_mgr.is_available(), "Test should have passed if is_available method was implemented"


# Generated at 2022-06-11 03:58:11.214999
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    # Create instance of class CLIMgr
    test_instance = CLIMgr()
    # Check method is_available of class CLIMgr
    assert test_instance.is_available() == False

# Generated at 2022-06-11 03:58:12.730115
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    manager = PkgMgr()
    assert manager.is_available() is None


# Generated at 2022-06-11 03:58:27.691914
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():

    test_method_name = LibMgr.is_available.__name__
    print("Testing %s method of LibMgr" % test_method_name)

    class MockLibMgr(LibMgr):

        def __init__(self):
            self.LIB = 'mock.package'
            super(MockLibMgr, self).__init__()
            self.is_available_called = False

    # Test 1: try import real module
    mock_lib_mgr = MockLibMgr()
    assert True == mock_lib_mgr.is_available()


# Generated at 2022-06-11 03:58:29.842860
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    libmgr = LibMgr()
    libmgr.is_available()
    assert libmgr._lib is not None


# Generated at 2022-06-11 03:58:31.210791
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class MyLibrary(LibMgr):
        LIB = 'mylibrary'
    assert MyLibrary().LIB == 'mylibrary'


# Generated at 2022-06-11 03:58:32.641718
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    test_module = LibMgr()
    assert test_module.is_available() is False

# Generated at 2022-06-11 03:58:36.000604
# Unit test for constructor of class LibMgr
def test_LibMgr():
    obj = LibMgr()

    try:
        assert obj._lib is None
    except AssertionError:
        raise AssertionError('Object ' + obj.__class__.__name__ + ' initialization failed')
    else:
        del obj


# Generated at 2022-06-11 03:58:39.459733
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    result = get_all_pkg_managers()
    assert len(result.keys()) > 0
    assert 'apt' in result.keys()
    assert issubclass(result['apt'], CLIMgr)

# Generated at 2022-06-11 03:58:41.014223
# Unit test for constructor of class LibMgr
def test_LibMgr():
    assert LibMgr()._lib is None


# Generated at 2022-06-11 03:58:43.502159
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    print("Testing function list_installed of class PkgMgr...")
    pkgmgr = PkgMgr()
    pkgmgr.list_installed()



# Generated at 2022-06-11 03:58:48.127378
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    for mgr in get_all_pkg_managers().values():
        if isinstance(mgr, CLIMgr):
            if mgr.CLI:
                found = mgr().is_available()
                if not found:
                    raise Exception('cli for %s not found' % mgr.__name__)

# Generated at 2022-06-11 03:58:52.602655
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    from ansible_collections.netapp.ontap.plugins.modules.na_ontap_package import LibMgr

    class MyLibMgr(LibMgr):
        LIB = "does_not_exist"

    libmgr = MyLibMgr()

    assert (not libmgr.is_available())


# Generated at 2022-06-11 03:59:02.089343
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    from ansible.module_utils.basic import AnsibleModule
    try:
        module = AnsibleModule(argument_spec={})
    except TypeError as e:
        assert False, e
    except Exception as e:
        assert True, e


# Generated at 2022-06-11 03:59:04.631797
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    from ansible.module_utils.facts import PkgMgr
    assert PkgMgr.is_available()==False
    assert PkgMgr.is_available()==False
    

# Generated at 2022-06-11 03:59:07.634510
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class PACKAGEMGR(CLIMgr):
        CLI = "test"
    PACKAGEMGR = PACKAGEMGR()
    PACKAGEMGR.is_available()
    assert PACKAGEMGR._cli == "test"

# Generated at 2022-06-11 03:59:11.619899
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    # Create an instance of PkgMgr and call get_packages method
    # get_packages method should have default implementation and will, therafore, work out of the box
    testPkgManager = PkgMgr()
    result = testPkgManager.get_packages()
    assert (not result)

# Generated at 2022-06-11 03:59:20.079268
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    pkg_mgr = LibMgr()

    pkg_mgr.is_available = MagicMock(return_value=True)
    pkg_mgr.list_installed = MagicMock(return_value=['foo', 'bar', 'foo', 'bar'])
    pkg_mgr.get_package_details = MagicMock(return_value={'name': 'foo', 'version': '1.0.2'})

    package_dict = pkg_mgr.get_packages()


# Generated at 2022-06-11 03:59:27.990995
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class MockPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['package_installed_1']
        def get_package_details(self, package):
            details = dict(
                name = 'name',
                version = 'version',
                release = 'release'
            )
            return details
    mock_pkg_mgr = MockPkgMgr()
    result = mock_pkg_mgr.get_package_details('package_installed_1')
    assert result.get('name') == 'name'
    assert result.get('version') == 'version'
    assert result.get('release') == 'release'


# Generated at 2022-06-11 03:59:30.407711
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():

    class TestLibMgr(LibMgr):

        LIB = "libmgr"

    lib = TestLibMgr()
    assert lib.is_available() == True


# Generated at 2022-06-11 03:59:31.272918
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    assert True == True


# Generated at 2022-06-11 03:59:39.872068
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class MockPkgMgr(PkgMgr):
        def __init__(self):
            self.package_list = []
            self.package_details = {}
            super(MockPkgMgr, self).__init__()
        def is_available(self):
            return True
        def list_installed(self):
            return self.package_list
        def get_package_details(self, package):
            return self.package_details
    pkg_mgr = MockPkgMgr()
    pkg_mgr.package_list = ["foo-1.2.3", "foo-2.2.2", "bar-1.2.1"]
    pkg_mgr.package_details = {"name": "foo", "version": "1.2.3"}


# Generated at 2022-06-11 03:59:49.348224
# Unit test for constructor of class LibMgr
def test_LibMgr():
    from ansible.module_utils.common.process import get_bin_path
    assert 'CLI' not in dir(LibMgr)
    assert 'is_available()' in dir(LibMgr)
    assert 'availability_method' not in dir(LibMgr)
    assert 'LIB' in dir(LibMgr)
    assert '__init__()' in dir(LibMgr)
    from ansible.module_utils.pkginstaller.libmgr import PIP
    assert 'PIP' not in dir(LibMgr)
    assert 'is_available()' in dir(PIP)
    assert 'list_installed()' in dir(PIP)
    assert 'get_package_details()' in dir(PIP)
    assert 'is_available()' in dir(CLIMgr)

# Generated at 2022-06-11 04:00:03.992055
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
  # stub for get bin path
  def _get_bin_path(*args, **kwargs):
    return '/usr/bin/python'
  # all pkg managers
  pkg_managers = get_all_pkg_managers()
  # set get_bin_path stub
  for pkg_mgr in pkg_managers:
    if issubclass(pkg_managers[pkg_mgr], CLIMgr):
      pkg_managers[pkg_mgr].get_bin_path = _get_bin_path
  # test
  for pkg_mgr in pkg_managers:
    assert pkg_managers[pkg_mgr]().is_available() == True

# Generated at 2022-06-11 04:00:07.189160
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    test_CLIMgr_is_available.cli_mgr = CLIMgr()
    assert test_CLIMgr_is_available.cli_mgr.is_available() == CLIMgr._cli is not None

# Generated at 2022-06-11 04:00:16.222260
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    import sys
    import os
    # Case 1: path of testlib.py other than current working directory
    python_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'testlib/')
    if python_path not in sys.path:
        sys.path.append(python_path)

    class TestLibMgr(LibMgr):
        LIB = 'testlib'

    lm = TestLibMgr()
    assert lm.is_available() is True
    # Case 2: path of testlib.py is same as current working directory (for backward compatibility)
    python_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), '')
    if python_path not in sys.path:
        sys.path

# Generated at 2022-06-11 04:00:17.035610
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class testCLIMgr(CLIMgr):
        CLI = 'python'
    assert testCLIMgr().is_available() is True

# Generated at 2022-06-11 04:00:22.534255
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    from ansible.module_utils.common.packages.pip import PIP
    from ansible.module_utils.common.packages.podman import Podman
    from ansible.module_utils.common.packages.rpm import RPM
    from ansible.module_utils.common.packages.gem import Gem
    from ansible.module_utils.common.packages.deb import Dpkg
    from ansible.module_utils.common.packages.homebrew import Brew
    from ansible.module_utils.common.packages.homebrew_cask import BrewCask
    from ansible.module_utils.common.packages.pkgin import Pkgin
    from ansible.module_utils.common.packages.yum import Yum


# Generated at 2022-06-11 04:00:25.939133
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class LibMgrTest(LibMgr):
        LIB = 'ansible.module_utils.common.process'

    pkgmgr_test = LibMgrTest()
    result = pkgmgr_test.is_available()
    assert result


# Generated at 2022-06-11 04:00:27.349139
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    assert PkgMgr.is_available(PkgMgr()) == False


# Generated at 2022-06-11 04:00:35.442591
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():

    import sys
    import os

    # Create a tmp file for testing
    tmp_file_name = 'tmp_file'
    tmp_file = open(tmp_file_name, 'w+')
    sys.path.insert(0, os.getcwd())

    # Create class for testing
    class testLibMgr(LibMgr):
        LIB = 'testLibMgr'

        def __init__(self):
            super(testLibMgr, self).__init__()

        def is_available(self):
            return True

    # test if is_available return True
    testlib = testLibMgr()
    assert testlib.is_available() == True

    # test if is_available return False
    class testLibMgr1(testLibMgr):
        LIB = 'testLibMgr1'

    test

# Generated at 2022-06-11 04:00:38.766516
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class Mock(LibMgr):
        LIB = 'cryptography'
    libmgr = Mock()
    print("testing is_available method of Mock object")
    if libmgr.is_available():
        print("is available")
    else:
        print("not available")


# Generated at 2022-06-11 04:00:44.603168
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    # no platform module
    class LibMgrSubclassNoPlatformModule(LibMgr):
        LIB = "platform"

    libMgr = LibMgrSubclassNoPlatformModule()
    assert libMgr.is_available() == False

    # platform module available with no version specified
    class LibMgrSubclassPlatformModuleNoVersion(LibMgr):
        LIB = "ansible.module_utils.ansible_release.platform"

    libMgr = LibMgrSubclassPlatformModuleNoVersion()
    assert libMgr.is_available() == True

# Generated at 2022-06-11 04:01:07.229994
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():

    # test with success response
    available_pkgs = {}
    for pkgmgr in get_all_pkg_managers().values():
        try:
            result = pkgmgr().is_available()
            if result:
                available_pkgs[pkgmgr.__name__.lower()] = result
        except:
            pass

    assert any(available_pkgs) == True
    assert available_pkgs['gem'].__class__.__name__ == 'Gem'
    assert available_pkgs['gem'].is_available() == True
    assert available_pkgs['pip3'].__class__.__name__ == 'Pip'


# Generated at 2022-06-11 04:01:11.013420
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():

    global __name__
    is_available = False

    if __name__ == '__ansible_managed':
        try:
            import requests
            is_available = True
        except ImportError:
            is_available = False
    else:
        is_available = False

    return is_available

# Generated at 2022-06-11 04:01:13.279481
# Unit test for constructor of class LibMgr
def test_LibMgr():
    obj_1 = LibMgr()
    assert obj_1.LIB is None
    assert obj_1._lib is None


# Generated at 2022-06-11 04:01:15.221177
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    testobj = CLIMgr()
    assert testobj._cli is None
    ret = testobj.is_available()
    assert ret is False

# Generated at 2022-06-11 04:01:23.278655
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    # Given
    class FakeCLIMgr(CLIMgr):
        pass
    fake_cli_mgr = FakeCLIMgr()

    class FakeGetBinPath:
        def __init__(self, value_to_return=None):
            self._value_to_return = value_to_return

        def __call__(self, *args, **kwargs):
            return self._value_to_return

    bin_path_returns_none = FakeGetBinPath(None)
    bin_path_returns_cli_path = FakeGetBinPath('/tmp/fake_CLI')

    # When
    result_get_bin_path_returns_none = fake_cli_mgr.is_available()

# Generated at 2022-06-11 04:01:30.113009
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    # Test on non existing CLI
    TestCLIMgr = type('TestCLIMgr', (CLIMgr, ), dict(CLI='non_existing_cli'))
    test_cli_mgr = TestCLIMgr()
    assert test_cli_mgr.is_available() is False
    # Test on existing CLI
    TestCLIMgr = type('TestCLIMgr', (CLIMgr, ), dict(CLI='ls'))
    test_cli_mgr = TestCLIMgr()
    assert test_cli_mgr.is_available() is True

# Generated at 2022-06-11 04:01:31.406863
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    assert callable(PkgMgr.list_installed)


# Generated at 2022-06-11 04:01:33.286863
# Unit test for constructor of class LibMgr
def test_LibMgr():
    pkg = LibMgr()
    assert pkg._lib is None
    assert not pkg.is_available()


# Generated at 2022-06-11 04:01:35.061676
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pkg_mgr = PkgMgr()
    assert pkg_mgr.is_available() == True


# Generated at 2022-06-11 04:01:43.097268
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    import contextlib
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.facts import PkgMgr
    class PkgMgrTest(PkgMgr):
        def __init__(self):
            super(PkgMgrTest, self).__init__()

        def list_installed(self):
            return ['a', 'b']

        def get_package_details(self, package):
            return {'name': package, 'version': '1.2'}

# Generated at 2022-06-11 04:02:21.025534
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    assert callable(getattr(get_all_pkg_managers()['apt'], 'get_packages', None))
    assert callable(getattr(get_all_pkg_managers()['apt'], 'list_installed', None))
    assert callable(getattr(get_all_pkg_managers()['apt'], 'get_package_details', None))

# Generated at 2022-06-11 04:02:23.540888
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    lib = LibMgr()
    lib.LIB = None
    assert lib.is_available() == False
    lib.LIB = "xx"
    assert lib.is_available() == False
    return


# Generated at 2022-06-11 04:02:24.370015
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    pass


# Generated at 2022-06-11 04:02:25.644041
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    instance = CLIMgr()
    assert isinstance(instance, CLIMgr)

# Generated at 2022-06-11 04:02:26.258771
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    pass

# Generated at 2022-06-11 04:02:28.404781
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pkgmgr = PkgMgr()
    assert pkgmgr.is_available() == NotImplemented


# Generated at 2022-06-11 04:02:32.172602
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    mgr = CLIMgr()
    assert mgr is not None, 'Test fail: Constructor of class CLIMgr should not return None'
    assert type(mgr) is CLIMgr, 'Test fail: Constructor of class CLIMgr should return an object of type CLIMgr'

# Generated at 2022-06-11 04:02:33.679303
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    assert "PkgMgr" == PkgMgr.__name__

# Generated at 2022-06-11 04:02:39.290642
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():

    pkg_managers = get_all_pkg_managers()
    assert len(pkg_managers) == 3
    assert type(pkg_managers) == dict
    assert list(pkg_managers.keys()) == ['apt', 'yum', 'zypper']
    assert 'PkgMgr' not in pkg_managers
    assert 'CLIMgr' not in pkg_managers
    assert 'LibMgr' not in pkg_managers
    assert issubclass(pkg_managers['apt'], CLIMgr)
    assert issubclass(pkg_managers['yum'], CLIMgr)
    assert issubclass(pkg_managers['zypper'], CLIMgr)

# Generated at 2022-06-11 04:02:40.312859
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    cm = CLIMgr()
    assert cm != None

# Generated at 2022-06-11 04:03:44.976750
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    mgr = PkgMgr()
    package = dict()
    result = mgr.get_package_details(package)
    assert isinstance(result, dict)


# Generated at 2022-06-11 04:03:47.621620
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class LibMgrTest(LibMgr):
        LIB = 'random'
    lm = LibMgrTest()
    assert not lm.is_available()
    import random
    assert lm.is_available()


# Generated at 2022-06-11 04:03:48.344597
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    a=CLIMgr()


# Generated at 2022-06-11 04:03:52.324188
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pkg = PkgMgr()
    try:
        assert pkg.is_available == pkg.is_available()
    except AssertionError:
        raise AssertionError("PkgMgr is_available is not correct")


# Generated at 2022-06-11 04:03:53.684409
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():

    libmgr = LibMgr()
    assert not libmgr.is_available()


# Generated at 2022-06-11 04:03:54.858937
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    assert PkgMgr.get_packages(None) == None

# Generated at 2022-06-11 04:03:55.844642
# Unit test for constructor of class LibMgr
def test_LibMgr():
    this = LibMgr()
    assert this


# Generated at 2022-06-11 04:03:59.803824
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():

    # Here we try to import a module which does not exist
    class myCLIMgr(CLIMgr):

        CLI = 'nox'

    assert not myCLIMgr().is_available()

    # Here we try to import a non existing module
    class myCLIMgr2(CLIMgr):

        CLI = 'ls'

    assert myCLIMgr2().is_available()

# Generated at 2022-06-11 04:04:00.267090
# Unit test for constructor of class LibMgr
def test_LibMgr():
    assert LibMgr()

# Generated at 2022-06-11 04:04:02.928246
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class test_LibMgr(LibMgr):
        LIB = "test_lib"
    lm = test_LibMgr()
    assert lm.LIB is "test_lib"
    assert lm.is_available() is False
