

# Generated at 2022-06-11 03:56:47.064789
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr() is not None

# Generated at 2022-06-11 03:56:49.424323
# Unit test for constructor of class LibMgr
def test_LibMgr():
    pkg = LibMgr()
    assert isinstance(pkg, LibMgr)
    assert pkg.is_available() is False
    assert pkg._lib is None


# Generated at 2022-06-11 03:56:50.942189
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    l = PkgMgr()
    print(l)


# Generated at 2022-06-11 03:56:52.481194
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    test_cli = CLIMgr()
    assert test_cli._cli is None

# Generated at 2022-06-11 03:57:01.969240
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():

    class CLIMgrDummy(CLIMgr):
        CLI = 'CLI_Dummy'

    class CLIMgrDummyFalse(CLIMgr):
        CLI = 'CLI_Dummy_False'

    class CLIMgrFalse(PkgMgr):

        def is_available(self):
            return False

    CLI_Mgr_Dummy = CLIMgrDummy()
    CLI_Mgr_Dummy_False = CLIMgrDummyFalse()
    CLI_Mgr_False = CLIMgrFalse()
    assert CLI_Mgr_Dummy.is_available() == True
    assert CLI_Mgr_Dummy_False.is_available() == False
    assert CLI_Mgr_False.is_available() == False


# Generated at 2022-06-11 03:57:03.392397
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    assert LibMgr.is_available(LibMgr) is True


# Generated at 2022-06-11 03:57:12.719262
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    # Since most good cli functions have a list_installed function, let's test that
    # construct a base class and make sure the method is abstract
    class PkgMgr_test(PkgMgr):
        return_value = None
        def list_installed(self):
            return PkgMgr_test.return_value
    pkgMgr = PkgMgr_test()
    try:
        pkgMgr.list_installed()
    except TypeError as e:
        assert "Can't instantiate abstract class" in str(e)
    # now add the method to the class and test it
    class PkgMgr_test(PkgMgr):
        return_value = ['test']
        def list_installed(self):
            return PkgMgr_test.return_value
    pkgMgr = PkgM

# Generated at 2022-06-11 03:57:18.763712
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    class MockPkgMgr(PkgMgr):

        def is_available(self):
            return True

        def list_installed(self):
            return ['foo', 'bar']

        def get_package_details(self, package):
            return {'name': 'name', 'version': 'version'}

    pkg_mgr = MockPkgMgr()
    assert pkg_mgr.get_packages() == {'name': [{'name': 'name', 'version': 'version', 'source': 'mockpkgmgr'}]}

# Generated at 2022-06-11 03:57:29.630777
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class FakePkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return [{'name': 'package1', 'version': 'version1'},
                    {'name': 'package2', 'version': 'version2'},
                    {'name': 'package1', 'version': 'version2'}]
        def get_package_details(self, package):
            return package
    packages = FakePkgMgr().get_packages()
    assert packages == {'package1': [{'name': 'package1', 'version': 'version1'},
                                     {'name': 'package1', 'version': 'version2'}],
                        'package2': [{'name': 'package2', 'version': 'version2'}]}

# Generated at 2022-06-11 03:57:30.991544
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    obj = CLIMgr()
    assert isinstance(obj, CLIMgr)

# Generated at 2022-06-11 03:57:41.435342
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    pm = PkgMgr()
    pm.list_installed = lambda: (('package1', 'package2'),)
    pm.get_package_details = lambda p: {'name': p, 'version': {'full': '1.0'}}
    assert pm.get_packages() == {'package1': [{'source': 'pkgmgr', 'name': 'package1', 'version': {'full': '1.0'}}],
                                 'package2': [{'source': 'pkgmgr', 'name': 'package2', 'version': {'full': '1.0'}}]}

# Generated at 2022-06-11 03:57:42.753768
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    t = CLIMgr()
    assert t.is_available() == True


# Generated at 2022-06-11 03:57:43.840264
# Unit test for constructor of class LibMgr
def test_LibMgr():
    pm = LibMgr()
    assert pm._lib is None


# Generated at 2022-06-11 03:57:45.727299
# Unit test for constructor of class LibMgr
def test_LibMgr():
    """test_LibMgr: Test the constructor of class LibMgr"""

    assert(LibMgr()) is not None


# Generated at 2022-06-11 03:57:55.186073
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    # Test for the situation when there is a package manager
    # Return True
    cli_name = 'CLI'
    lib_name = 'Lib'

    class TestMgr(PkgMgr):
        def __init__(self):
            super(TestMgr, self).__init__()
            self._cli = cli_name
            self._lib = lib_name

        def is_available(self):
            self._cli = cli_name
            self._lib = lib_name
            return True

 
    package = TestMgr()

    # Test && verify
    try:
        available = package.is_available()
        assert available == True
    except AssertionError:
        print("1. The unit test is failed !", file=sys.stderr)
        raise


# Generated at 2022-06-11 03:57:57.774113
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():

    class TestLibMgr(LibMgr):

        LIB = 'sys'

    lm = TestLibMgr()
    assert lm.is_available() == True


# Generated at 2022-06-11 03:58:01.310063
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    l1 = LibMgr()
    assert not l1.is_available()
    l1.LIB = 'os'
    assert l1.is_available()
    l1.LIB = 'foo'
    assert not l1.is_available()


# Generated at 2022-06-11 03:58:06.127599
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    class PkgMgrMock(PkgMgr):
        def list_installed(self):
            return ['vim', 'python']
        def get_package_details(self, package):
            return package
    pkgmgr = PkgMgrMock()
    assert pkgmgr.list_installed() == ['vim', 'python']


# Generated at 2022-06-11 03:58:08.068217
# Unit test for constructor of class LibMgr
def test_LibMgr():
    t = LibMgr()
    assert t._lib is None
    assert t.is_available() is False
    return


# Generated at 2022-06-11 03:58:11.724460
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class PkgMgrTest(PkgMgr):
        def is_available(self):
            pass
        def list_installed(self):
            pass
        def get_package_details(self, package):
            return {'name': 1, 'version': 2}
    pm = PkgMgrTest()
    assert pm.get_package_details(1) == {'name': 1, 'version': 2}

# Generated at 2022-06-11 03:58:26.596018
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    if sys.version_info[:2] < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    class MockPkgMgr(PkgMgr):
        def is_available(self):
            return True

    class MockLibMgr(LibMgr):
        LIB = 'lib'
        def is_available(self):
            return True

    class MockCLIMgr(CLIMgr):
        CLI = 'cli'
        def is_available(self):
            return True

    class TestPkgMgr(unittest.TestCase):
        def test_not_implemented_exception(self):
            pmgr = MockPkgMgr()
            self.assertRaises(NotImplementedError, pmgr.list_installed)


# Generated at 2022-06-11 03:58:27.599758
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pass


# Generated at 2022-06-11 03:58:29.386168
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    mgr = PkgMgr()
    assert mgr.get_package_details('test_package_1') is not None

# Generated at 2022-06-11 03:58:30.161212
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr()

# Generated at 2022-06-11 03:58:32.202784
# Unit test for constructor of class LibMgr
def test_LibMgr():
    PkgMgr_Class = LibMgr()
    assert hasattr(PkgMgr_Class,'is_available')


# Generated at 2022-06-11 03:58:33.848472
# Unit test for constructor of class LibMgr
def test_LibMgr():
    # Test class of the LibMgr with empty attributes
    assert LibMgr().__class__ == LibMgr


# Generated at 2022-06-11 03:58:35.568066
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    test_mgr = CLIMgr()
    assert test_mgr._cli is None


# Generated at 2022-06-11 03:58:46.258286
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    all_pkg_managers = get_all_pkg_managers()
    print("Unit test of PkgMgr.get_packages()")
    print("\nPart 1: Check all installed packages")
    for name, manager in all_pkg_managers.items():
        if manager().is_available():
            print("\nManager: %s:" % name)

            packages = manager().get_packages()
            #print("debug packages:", packages)
            for package, versions in packages.items():
                print("Package: %s:" % package)
                for version in versions:
                    #print("debug version:", version)
                    print("Version: %s" % version['version'])


if __name__ == '__main__':
    test_PkgMgr_get_packages()

# Generated at 2022-06-11 03:58:51.527839
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    pm = cli_mgr()
    pm.CLI = '/nonexistent'
    assert pm.is_available() == False

    import tempfile

    pm.CLI = tempfile.mkstemp()[1]
    assert pm.is_available() == True

    import os
    os.remove(pm.CLI)
    assert pm.is_available() == False


# Generated at 2022-06-11 03:58:53.258448
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():

    assert PkgMgr.is_available("PkgMgr") is False


# Generated at 2022-06-11 03:58:58.919930
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    myCLIMgr = CLIMgr()
    assert myCLIMgr.is_available() == None
    assert myCLIMgr == CLIMgr()

# Generated at 2022-06-11 03:59:02.397309
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    c = CLIMgr()
    c.CLI = 'ansible-connection.py'
    assert c.is_available() == True
    c.CLI = 'ansible-connecti.py'
    assert c.is_available() == False
    c.CLI = None
    assert c.is_available() == False # Should return false if CLI is not set


# Generated at 2022-06-11 03:59:02.934611
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    pass

# Generated at 2022-06-11 03:59:04.752338
# Unit test for constructor of class LibMgr
def test_LibMgr():
    '''Test if constructor of LibMgr works'''
    libmgr = LibMgr()
    assert libmgr._lib == None

# Generated at 2022-06-11 03:59:13.968058
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    from unittest import mock, TestCase

    class MockPkgMgr(PkgMgr):

        def is_available(self):
            return True

        def list_installed(self):
            return ["pkg1", "pkg2"]

        def get_package_details(self, package):
            names = {
                "pkg1": "mock_pkg1",
                "pkg2": "mock_pkg2"
            }
            return {"name": names[package], "version": "1.0"}

    mgr = MockPkgMgr()


# Generated at 2022-06-11 03:59:15.199858
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    mgr = CLIMgr()
    assert mgr is not None


# Generated at 2022-06-11 03:59:19.593203
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    from ansible.module_utils.package.osx.osx_pkg import OSXPkg

    import fake_pkg_mgr
    fake_pkg_mgr.install_fake_package_manager()

    pkg_mgr = OSXPkg()
    assert pkg_mgr.is_available()
    fake_pkg_mgr.uninstall_fake_package_manager()


# Generated at 2022-06-11 03:59:20.925844
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    pkg_manager = CLIMgr()
    assert pkg_manager._cli is None


# Generated at 2022-06-11 03:59:22.935128
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'unittest_import_mock'

    t = TestLibMgr()
    assert t.is_available()


# Generated at 2022-06-11 03:59:23.910331
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    # Validate that the __init__ method does not raise an exception
    assert CLIMgr()

# Generated at 2022-06-11 03:59:35.241006
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    # Create instance of CLIMgr
    class PkgMgr_CLI(CLIMgr):
        CLI = 'ls'
    pm = PkgMgr_CLI()
    # Check if the CLI is availbale on the system
    assert pm.is_available() == True


# Generated at 2022-06-11 03:59:39.511932
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    from ansible.module_utils.common.test_utils import TestAnsibleModule

    cli = CLIMgr()
    cli.CLI = "ls"
    assert cli.is_available() == True

    cli = CLIMgr()
    cli.CLI = "ls_"
    assert cli.is_available() == False



# Generated at 2022-06-11 03:59:41.636337
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pkginstalled = PkgMgr()
    assert pkginstalled.list_installed() is not None


# Generated at 2022-06-11 03:59:43.859817
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    return {'failure': 'Test not implemented yet', 'changed': False, 'msg': 'Test not implemented yet', 'rc': 1}


# Generated at 2022-06-11 03:59:48.458744
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    pkg_manager = CLIMgr()
    # define CLI variable
    pkg_manager.CLI = 'dmidecode'
    # call is_available() method
    assert pkg_manager.is_available()
    # define CLI variable
    pkg_manager.CLI = 'unknown'
    # call is_available() method
    assert not pkg_manager.is_available()

# Generated at 2022-06-11 03:59:53.173423
# Unit test for constructor of class LibMgr
def test_LibMgr():
    pkg_mgr = LibMgr()
    pkg_mgr.LIB = "ansible.module_utils.facts.system.app_paths.pkg_mgrs.pkgutil"
    assert isinstance(pkg_mgr, PkgMgr)
    assert isinstance(pkg_mgr, LibMgr)


# Generated at 2022-06-11 04:00:02.011101
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    dpkg_list = ['linux-headers-4.4.0-138', 'linux-headers-4.4.0-138-generic', 'linux-image-4.4.0-138-generic', 'linux-image-extra-4.4.0-138-generic', 'linux-signed-image-4.4.0-138-generic']

# Generated at 2022-06-11 04:00:11.480870
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    class TestPkgMgr(PkgMgr):

        def is_available(self):
            return True

        def list_installed(self):
            return ['testPkg:testVersion', 'testPkg2:testVersion2']

        def get_package_details(self, package):
            ret = dict(name=package.split(':')[0], version=package.split(':')[1])
            return ret

    test_pkg_mgr = TestPkgMgr()

# Generated at 2022-06-11 04:00:18.673467
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def list_installed(self):
            return (1, 2)
        def get_package_details(self, package):
            dict = {}
            dict['name'] = "test"
            dict['version'] = package
            return dict
    test_pkg_mgr = TestPkgMgr()
    assert(test_pkg_mgr.get_packages() == {'test': [{'version': 1, 'name': 'test', 'source': 'testpkgmgr'}, {'version': 2, 'name': 'test', 'source': 'testpkgmgr'}]})


# Generated at 2022-06-11 04:00:20.418595
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    exception_raised = False
    try:
        package_details = PkgMgr.get_package_details("apache2")
    except:
        exception_raised = True
    assert exception_raised == True


# Generated at 2022-06-11 04:00:37.077901
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    result = PkgMgr.get_packages(None)
    assert {} == result


# Generated at 2022-06-11 04:00:38.766028
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    # This test passes the CLI value along with generating the manager object
    assert CLIMgr(CLI='yum').is_available() == True



# Generated at 2022-06-11 04:00:40.822585
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    the_manager = PkgMgr()
    assert(the_manager.get_package_details("not_a_real_package") == {})



# Generated at 2022-06-11 04:00:44.150142
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    class TestPkgMgr(PkgMgr):
        def list_installed(self):
            return ['foo', 'bar']
    mgr = TestPkgMgr()
    assert mgr.list_installed() == ['foo', 'bar']


# Generated at 2022-06-11 04:00:50.888394
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class FakeLibMgr(LibMgr):
        def __init__(self):
            super(FakeLibMgr, self).__init__()
            self.LIB = "fakelib"

    # FakeLibMgr.__init__() is called, but self._lib is None
    fake_libmgr = FakeLibMgr()
    assert fake_libmgr.is_available() is False
    # FakeLibMgr.__init__() is called, and self._lib is set
    fake_libmgr._lib = 1
    assert fake_libmgr.is_available() is True


# Generated at 2022-06-11 04:00:58.303833
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    '''
    test CLIMgr
    '''

    class TestCLIMgr(CLIMgr):
        pass

    TestCLIMgr._cli = None
    TestCLIMgr.CLI = 'ls'
    test_cli_mgr = TestCLIMgr()

    assert test_cli_mgr is not None

    assert test_cli_mgr.CLI == 'ls'
    assert test_cli_mgr._cli is None

    assert test_cli_mgr.is_available()

    assert test_cli_mgr._cli is not None

    TestCLIMgr.CLI = 'unavailable_program'
    assert test_cli_mgr.is_available() is False


# Generated at 2022-06-11 04:00:59.596743
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    test_object = LibMgr()
    assert test_object.is_available() == False


# Generated at 2022-06-11 04:01:01.551595
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    libMgr1 = LibMgr()
    assert libMgr1.is_available() == False


# Generated at 2022-06-11 04:01:03.644706
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    # test_pkg_mgr = LibMgr()
    # assert test_pkg_mgr.is_available() is False
    pass


# Generated at 2022-06-11 04:01:13.602064
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    # Get a PkgMgr class
    from ansible.module_utils.facts.system.distribution import DistributionFiles
    distro = DistributionFiles()
    distro.detect()

    for pkg_type in distro.pkg_mgr.supported_pkg_mgr.keys():
        pkg_mgr = distro.pkg_mgr.supported_pkg_mgr[pkg_type]()
        if pkg_mgr.is_available():
            pkg_mgr_dict = pkg_mgr.get_packages()
            assert isinstance(pkg_mgr_dict, dict)
            for key in pkg_mgr_dict.keys():
                assert isinstance(pkg_mgr_dict[key], list)

# Generated at 2022-06-11 04:01:46.911131
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    """Test constructor of class CLIMgr"""
    assert CLIMgr()



# Generated at 2022-06-11 04:01:48.292349
# Unit test for constructor of class LibMgr
def test_LibMgr():
    pm = LibMgr()
    assert pm.LIB is None and pm._lib is None


# Generated at 2022-06-11 04:01:49.135389
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    get_all_pkg_managers()

# Generated at 2022-06-11 04:01:50.806882
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    from .apt import AptMgr
    obj = LibMgr()
    assert obj.is_available()==True


# Generated at 2022-06-11 04:01:56.729980
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class mock_lib_import(object):
        def __init__(self, lib_import):
            self._found = True if lib_import else False

        def __enter__(self):
            return self._found

        def __exit__(self, exc_type, exc_value, traceback):
            pass

    class lib_mgr(LibMgr):
        pass

    lib_mgr = lib_mgr()
    assert not lib_mgr.is_available()

    with mock_lib_import(False):
        assert not lib_mgr.is_available()

    with mock_lib_import(True):
        assert lib_mgr.is_available()


# Generated at 2022-06-11 04:02:04.571380
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class TestClass(PkgMgr):
        def is_available(self):
            return True

        def list_installed(self):
            return ['my_package']

        def get_package_details(self, package):
            return {'name': 'package', 'version': '1.0'}

    class TestClass2(PkgMgr):
        def is_available(self):
            return True

        def list_installed(self):
            return ['my_package']

        def get_package_details(self, package):
            return {'name': 'package', 'version': '1.0', 'source': 'something'}

    # Test class TestClass
    test_class = TestClass()
    assert test_class.list_installed() == ['my_package'], "list_installed() failed for TestClass"

# Generated at 2022-06-11 04:02:09.014867
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():

    for pkg_manager in get_all_pkg_managers():
        # Check that the is_available method returns False for a non-existing package manager
        if pkg_manager not in ['apt']:
            continue
        pkg_mgr = get_all_pkg_managers()[pkg_manager]()
        pkg_mgr.is_available()
        assert isinstance(pkg_mgr.list_installed(), list)


# Generated at 2022-06-11 04:02:11.840882
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class __LibMgr(LibMgr):
        LIB = "test"
    libmgr = __LibMgr()
    assert libmgr._lib is None
    assert libmgr.LIB == "test"


# Generated at 2022-06-11 04:02:14.388085
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    def noop():
        pass
    pkg_mgr = PkgMgr()
    pkg_mgr.get_package_details = noop
    assert not pkg_mgr.get_package_details

# Generated at 2022-06-11 04:02:16.009444
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    pkgmgr_instance = CLIMgr()
    assert pkgmgr_instance.is_available() == False

# Generated at 2022-06-11 04:03:30.886489
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():

    class TestLib(LibMgr):
        LIB = 'magic'

    import sys
    import os
    import sysconfig
    import pytest

    #test for ImportError
    for name in sys.modules.keys():
        if 'site-packages' in name:
            del sys.modules[name]

    test_lib = TestLib()
    assert test_lib.is_available() == False

    #test for ImportError
    for name in sys.modules.keys():
        if 'magic' in name:
            del sys.modules[name]

    #test for ImportError
    test_lib = TestLib()
    assert test_lib.is_available() == False

    #test for ImportException
    pytest.raises(ImportError,test_lib.is_available())

    #test for ImportError
    sys.path.append

# Generated at 2022-06-11 04:03:33.198335
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class FakeCLIMgr(CLIMgr):
        CLI = "fake_pkg_mgr"

    manager = FakeCLIMgr()
    assert(manager.is_available() == True)



# Generated at 2022-06-11 04:03:34.465130
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    clm = CLIMgr()

# Generated at 2022-06-11 04:03:36.805971
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    # Create instance of class LibMgr
    obj = LibMgr()
    # Check that available variable is false
    assert obj.is_available() == False

# Unit test of method is_available of class CLIMgr

# Generated at 2022-06-11 04:03:40.505659
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    from . import apkg
    cli = CLIMgr()
    cli.CLI = 'mocked_cli'

    apkg.get_bin_path = lambda x: False
    assert not cli.is_available()

    apkg.get_bin_path = lambda x: True
    assert cli.is_available()



# Generated at 2022-06-11 04:03:42.457515
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    l = LibMgr()
    l.LIB = 'ansible.module_utils.basic'
    l.is_available()
    assert l._lib is not None


# Generated at 2022-06-11 04:03:44.661129
# Unit test for constructor of class LibMgr
def test_LibMgr():

    # Create instance of LibMgr class
    lib_mgr = LibMgr()

    # Assert that object is instance of LibMgr
    assert isinstance(lib_mgr, LibMgr)



# Generated at 2022-06-11 04:03:46.732846
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    import pytest
    c = CLIMgr()
    c.CLI = r".\test_path.py"
    assert c.is_available() == True


# Generated at 2022-06-11 04:03:51.134142
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class MockLibMgr(LibMgr):
        LIB = 'mock-lib'
    obj = MockLibMgr()
    assert obj.is_available() == False
    import mock
    mock.patch.dict('sys.modules', {'mock-lib': None})
    assert obj.is_available() == True

# Generated at 2022-06-11 04:03:52.931147
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCLIMgr(CLIMgr):
        CLI = 'ls'
    assert TestCLIMgr.is_available(TestCLIMgr)