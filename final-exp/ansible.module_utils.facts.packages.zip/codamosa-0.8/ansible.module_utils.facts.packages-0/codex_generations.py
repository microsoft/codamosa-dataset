

# Generated at 2022-06-11 03:56:58.385617
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    """
    Test the is_available method of class LibMgr
    """
    from ansible.module_utils.six import PY3
    import ansible.module_utils.common.ansible_collector.common.plugin_manager as pm

    if not PY3:
        import mock

        mock_import = mock.MagicMock()
        # path to the package or module that we want to import
        path_to_module = "ansible.module_utils.common.ansible_collector.common.plugin_manager"
        with mock.patch(path_to_module + ".__import__", side_effect=mock_import):
            mock_import.side_effect = ImportError
            result = pm.LibMgr.is_available()
            assert not result
            mock_import.side_effect = False

# Generated at 2022-06-11 03:57:06.173893
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class test_PkgMgr(PkgMgr):
        def is_available(self):
            return True # Does not matter for this test
        def list_installed(self):
            return ["fake_package"] # Does not matter for this test
        def get_package_details(self, package):
            return {'name': 'fake_package', 'version': '1.2.3'}
    pm = test_PkgMgr()
    details = pm.get_package_details("fake_package")
    assert(details['name'] == 'fake_package')
    assert(details['version'] == '1.2.3')

# Generated at 2022-06-11 03:57:07.484181
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    assert(CLIMgr().is_available() == False)


# Generated at 2022-06-11 03:57:13.957490
# Unit test for constructor of class LibMgr
def test_LibMgr():
    assert LibMgr.__name__ == 'LibMgr'
    assert LibMgr.__module__ == 'ansible.module_utils.facts.packages.pkg_mgr'
    assert LibMgr not in PkgMgr.__subclasses__()
    assert PkgMgr not in LibMgr.__subclasses__()
    assert issubclass(LibMgr, PkgMgr)
    assert isinstance(LibMgr(), PkgMgr)
    assert isinstance(LibMgr(), object)


# Generated at 2022-06-11 03:57:15.364977
# Unit test for constructor of class LibMgr
def test_LibMgr():
    assert LibMgr()._lib is None


# Generated at 2022-06-11 03:57:24.855513
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    import os
    import sys

    lib_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '../lib/ansible/modules/system'))
    if lib_path not in sys.path:
        sys.path.append(lib_path)
    pm1 = get_all_pkg_managers()['pacman']()
    pm2 = get_all_pkg_managers()['apk']()
    pm3 = get_all_pkg_managers()['apt']()
    pm1.list_installed = lambda: ['vim-minimal']
    pm1.get_package_details = lambda package: {'name': 'vim', 'version': '7.4.309'}
    pm2.list_installed = lambda: ['vim']
    pm2.get

# Generated at 2022-06-11 03:57:27.035251
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    result = CLIMgr.is_available(CLIMgr)
    assert type(result) is bool


# Generated at 2022-06-11 03:57:27.645386
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    assert True

# Generated at 2022-06-11 03:57:31.342626
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    from ansible.module_utils.common.os.pkg_mgr import CLIMgr
    _CLI = 'apt-get'
    climgr = CLIMgr()
    assert climgr.CLI == _CLI
    assert climgr.is_available()


# Generated at 2022-06-11 03:57:38.724333
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():

    def get_package_details(self, package):
        return dict(
            name=package,
            version='1.2.3',
            source='testsource',
            installed=True
        )

    package = 'testpackage'

    PkgMgr.get_package_details = get_package_details

    test = PkgMgr()

    test_details = test.get_package_details(package)

    assert test_details['name'] == package
    assert test_details['version'] == '1.2.3'
    assert test_details['source'] == 'testsource'
    assert test_details['installed']


# Generated at 2022-06-11 03:57:43.249740
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pass

# Generated at 2022-06-11 03:57:45.389908
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    Mgr = type('Mgr', (LibMgr,), {'LIB': 'sqlite3'})

    assert Mgr().is_available() is True



# Generated at 2022-06-11 03:57:48.370683
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class test_CLIMgr(CLIMgr):
        CLI = 'test_cmd'

    test_package_mgr = test_CLIMgr()
    result = test_package_mgr.is_available()
    assert result == False

# Generated at 2022-06-11 03:57:50.849721
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():

    class DummyPkgMgr(PkgMgr):

        def is_available(self):

            return True

    assert DummyPkgMgr().is_available() is True

# Generated at 2022-06-11 03:58:00.555933
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    class TestPkgMgr(PkgMgr):
        def list_installed(self):
            return ['package_1', 'package_2', 'package_3']

        def get_package_details(self, package):
            assert package in ['package_1', 'package_2', 'package_3']
            return {'name': package, 'version': '1.0.0'}

    p = TestPkgMgr()
    assert p.get_packages() == {'package_1': [{'name': 'package_1', 'version': '1.0.0'}], 'package_2': [{'name': 'package_2', 'version': '1.0.0'}], 'package_3': [{'name': 'package_3', 'version': '1.0.0'}]}

# Generated at 2022-06-11 03:58:03.608139
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    pkgs = PkgMgr()
    packages = pkgs.get_packages()
    if packages is not None:
        assert packages.__class__ == dict
    else:
        assert packages is None

# Generated at 2022-06-11 03:58:04.531115
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    assert(CLIMgr().is_available()==False)

# Generated at 2022-06-11 03:58:06.594190
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():

    class Dummy(LibMgr):
        LIB = 'dummy'

    dummy = Dummy()
    dummy.is_available()



# Generated at 2022-06-11 03:58:13.010759
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    from ansible.module_utils.common._collections_compat import Mapping
    import pytest

    # TODO: Write a real testable implementation of PkgMgr
    class PkgMgrStub(PkgMgr):
        # We are not testing for availability for this unit test.
        def is_available(self):
            pass
        # For now we simply expect the list_installed method to return an empty list.
        def list_installed(self):
            return []

    # Tests: check list_installed returns a list of installed packages
    pkg = PkgMgrStub()
    assert isinstance(pkg.list_installed(), list)

# Generated at 2022-06-11 03:58:14.013482
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    mgr = CLIMgr()
    assert(mgr is not None)



# Generated at 2022-06-11 03:58:23.770791
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class Shell(CLIMgr):
        CLI = 'shell'

    pm = Shell()
    assert pm.is_available() == True


# Generated at 2022-06-11 03:58:27.191885
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    apt_package_info = CLIMgr()
    apt_package_info.CLI = 'apt-cache'
    result = apt_package_info.is_available()
    assert result == True



# Generated at 2022-06-11 03:58:29.391733
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    class PkgMgr_list_installed(PkgMgr):
        def __init__(self):
            super(PkgMgr_list_installed, self).__init__()

        def list_installed(self):
            return ['a', 'b', 'c']

    result = PkgMgr_list_installed()
    assert result.list_installed() == ['a', 'b', 'c']


# Generated at 2022-06-11 03:58:33.406872
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    pkgs = [{"name": "python", "version": "2.6.9"}, {"name": "python", "version": "2.6.10"}]
    ret = {"name": ["2.6.9", "2.6.10"]}
    p = PkgMgr()
    p.get_package_details = MagicMock(side_effect=pkgs)
    p.list_installed = MagicMock(return_value=pkgs)
    assert p.get_packages() == ret


if __name__ == '__main__':
    from ansible.module_utils.common._collections_compat import MagicMock
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils._text import to_bytes
    import pytest
    pytest.main

# Generated at 2022-06-11 03:58:35.776977
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class DummyClass(LibMgr):
        LIB = 'os'
    obj = DummyClass()
    assert(obj.is_available())


# Generated at 2022-06-11 03:58:41.338217
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    """Test if method list_installed of class PkgMgr is implemented"""
    pkg_obj = PkgMgr()
    try:
        pkg_obj.list_installed()
    except NotImplementedError:
        msg = f"Method list_installed of class {pkg_obj.__class__} is not implemented"
        raise RuntimeError(msg)


# Generated at 2022-06-11 03:58:51.712417
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    """test the is_available method of class CLIMgr
    """

    import tempfile
    import os

    class DummyCLIMgr(CLIMgr):
        def __init__(self):
            super(DummyCLIMgr, self).__init__()
            self._cli = None
            self.CLI = 'dummy_cli'

    class TestCLIMgr(CLIMgr):
        def __init__(self):
            super(TestCLIMgr, self).__init__()
            self._cli = None
            self.CLI = 'Dummy_cli'

    dummy_cli = '''#!%s
    import sys
    sys.exit(0)
    ''' % (os.environ.get('SHEBANG_ENV'))

    # test cases to check if CLI is available

# Generated at 2022-06-11 03:58:57.701064
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    import sys
    sys.path.append('/home/sk/work/ansible/test/unit/modules/system/pkg_mgr/lib/')
    from pkg_mgr_test_lib import PkgMgrTestLib
    testlib = PkgMgrTestLib()
    assert testlib.get_packages()['test_pkg'] == [
        {u'name': u'test_pkg', u'source': u'pkg_mgr_test_lib', u'version': u'test'}
    ]

# Generated at 2022-06-11 03:58:58.015919
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    assert True

# Generated at 2022-06-11 03:58:58.896591
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():

    assert len(get_all_pkg_managers()) > 0

# Generated at 2022-06-11 03:59:16.016748
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    pm = CLIMgr()
    assert isinstance(pm.is_available(), bool)

# Generated at 2022-06-11 03:59:16.893021
# Unit test for constructor of class LibMgr
def test_LibMgr():
    assert LibMgr()


# Generated at 2022-06-11 03:59:23.620681
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    from ansible.module_utils.common._collections_compat import OrderedDict
    from ansible.module_utils.facts.system.pkg_mgr.pkg_mgr_yum import Yum
    from ansible.module_utils.facts.system.pkg_mgr.pkg_mgr_apt import Apt
    from ansible.module_utils.facts.system.pkg_mgr.pkg_mgr_apk import Apk
    from ansible.module_utils.facts.system.pkg_mgr.pkg_mgr_zypper import Zypper
    from ansible.module_utils.facts.system.pkg_mgr.pkg_mgr_pacman import Pacman
    from ansible.module_utils.facts.system.pkg_mgr.pkg_mgr_slackpkg import Slackpkg

# Generated at 2022-06-11 03:59:25.032117
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    assert CLIMgr().is_available()
    with_metaclass(ABCMeta, CLIMgr).is_available()

# Generated at 2022-06-11 03:59:31.864954
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    try:
        import mock
    except ImportError:
        import unittest.mock as mock

    with mock.patch('ansible.module_utils.common.process.get_bin_path') as mock_get_bin_path:
        mock_get_bin_path.return_value = None
        assert CLIMgr().is_available() is False
    with mock.patch('ansible.module_utils.common.process.get_bin_path') as mock_get_bin_path:
        mock_get_bin_path.return_value = '/path/to/binfile'
        assert CLIMgr().is_available() is True

# Generated at 2022-06-11 03:59:33.769576
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    # test method PkgMgr is_available
    assert PkgMgr.is_available(object)
    return True


# Generated at 2022-06-11 03:59:34.684296
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pass




# Generated at 2022-06-11 03:59:36.886582
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    with pytest.raises(NotImplementedError):
        pm = PkgMgr()
        pm.get_package_details('package')


# Generated at 2022-06-11 03:59:42.031907
# Unit test for constructor of class LibMgr
def test_LibMgr():
    from ansible.module_utils.packages import get_all_pkg_managers
    from ansible.module_utils.six import PY2

    pkg_mgr_dict = get_all_pkg_managers()
    if PY2:
        assert pkg_mgr_dict['aptpkgmgr']() != None
    else:
        assert pkg_mgr_dict['pippkgmgr']() != None


# Generated at 2022-06-11 03:59:45.123133
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():

    class LibMgrTest(LibMgr):

        LIB = 'test_LibMgr_is_available'

    lmt = LibMgrTest()
    assert lmt.is_available() is True


# Generated at 2022-06-11 04:00:20.139878
# Unit test for constructor of class LibMgr
def test_LibMgr():

    pkg_mgr = LibMgr()
    assert not hasattr(pkg_mgr, '_lib')
    assert pkg_mgr.LIB is None
    pkg_mgr.LIB = 'ansible.module_utils.common.dummy'
    pkg_mgr.is_available()
    assert hasattr(pkg_mgr, '_lib')


# Generated at 2022-06-11 04:00:27.678835
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():

    package = {'name': 'name', 'version': 'version', 'release': 'release', 'arch': 'arch', 'source': 'source'}

    pkg_mgr = PkgMgr()
    result = pkg_mgr.get_package_details(package)

    assert result == {'name': 'name', 'version': 'version', 'release': 'release', 'arch': 'arch', 'source': 'source'}
    assert result['name'] == 'name'
    assert result['version'] == 'version'
    assert result['release'] == 'release'
    assert result['arch'] == 'arch'
    assert result['source'] == 'source'


# Generated at 2022-06-11 04:00:30.054923
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    pm = PkgMgr()
    package = {'name': 'one', 'version': '1'}
    assert pm.get_package_details(package) == {'name': 'one', 'version': '1', 'source': 'pkgmgr'}

# Generated at 2022-06-11 04:00:32.105137
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'os'

    assert(TestLibMgr().is_available())


# Generated at 2022-06-11 04:00:35.448898
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    # class has CLI
    class TestCLIMgr(CLIMgr):
        CLI = 'foo'
    # CLI is available
    assert TestCLIMgr().is_available() == True
    # CLI is not available
    assert CLIMgr().is_available() == False


# Generated at 2022-06-11 04:00:43.761240
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class MockPkgMgr(PkgMgr):

        def __init__(self):
            self.packages = None
            super(MockPkgMgr, self).__init__()

        def is_available(self):
            return True

        def list_installed(self):
            if self.packages:
                return list(self.packages.keys())
            else:
                return []

        def get_package_details(self, package):
            return self.packages[package]

    # Test empty package list
    pkg_mgr = MockPkgMgr()
    pkg_mgr.packages = {}
    assert pkg_mgr.get_packages() == {}

    # Test package list with one package

# Generated at 2022-06-11 04:00:44.970288
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    assert CLIMgr().is_available()==False



# Generated at 2022-06-11 04:00:51.044542
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    # Test 1: Confirm that is_available() returns True if the CLI binary exists in PATH
    apt_mgr = CLIMgr()
    apt_mgr.CLI = 'apt-get'
    assert apt_mgr.is_available()

    # Test 2: Confirm that is_available() returns False if the CLI binary does not exist in PATH
    yum_mgr = CLIMgr()
    yum_mgr.CLI = 'yum'
    assert yum_mgr.is_available() == False




# Generated at 2022-06-11 04:00:58.160650
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    def raise_value_error(*args, **kwargs):
        raise ValueError
    def return_false(*args, **kwargs):
        return False
    class TestCase(CLIMgr):
        CLI = 'fake_binary'
    original_get_bin_path = get_bin_path
    try:
        test_obj = TestCase()
        assert test_obj.is_available() == False
        get_bin_path = raise_value_error
        assert test_obj.is_available() == False
        get_bin_path = return_false
        assert test_obj.is_available() == False
    finally:
        get_bin_path = original_get_bin_path

# Generated at 2022-06-11 04:01:00.681967
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    from ansible.module_utils.common._utils import _is_executable
    assert _is_executable(get_bin_path("ls")) == True

# Generated at 2022-06-11 04:02:12.830248
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    climgr = CLIMgr()


# Generated at 2022-06-11 04:02:21.535290
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    """
    Test if the function get_all_pkg_managers() can return all subclasses of PkgMgr.
    """

    # GIVEN
    class PkgMgrOne(PkgMgr):
        pass

    class PkgMgrTwo(CLIMgr):
        pass

    class PkgMgrThree(PkgMgr):
        pass

    # WHEN
    output = get_all_pkg_managers()

    # THEN
    assert len(output) == 3
    assert output['pkgmgrone'].__name__ == 'PkgMgrOne'
    assert output['pkgmgrtwo'].__name__ == 'PkgMgrTwo'
    assert output['pkgmgrthree'].__name__ == 'PkgMgrThree'

# Generated at 2022-06-11 04:02:30.846303
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    import os
    import tempfile
    import copy
    import subprocess
    test_dir = tempfile.mkdtemp(dir='/tmp', prefix='ansible-test-')
    os.chdir(test_dir)
    # Define a test class, which installs a package file in a temp directory.
    class test_PkgMgr(PkgMgr):
        def __init__(self):
            super(test_PkgMgr, self).__init__()

        def is_available(self, package_name):
            return True

        def list_installed(self):
            return [package_name]

        def get_package_details(self, package):
            return {'name': package, 'version': '0.1', 'source': 'test_PkgMgr'}
    
    test_pkg_m

# Generated at 2022-06-11 04:02:32.528057
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    c = CLIMgr()
    c.CLI = 'ls'
    assert c.is_available() == True

# Generated at 2022-06-11 04:02:36.464639
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    class TestCLIMgr(CLIMgr):
        CLI = 'not_installed_cli'

    test_pkg_mgr = TestCLIMgr()
    assert (test_pkg_mgr._cli == None)
    assert (test_pkg_mgr.is_available() == False)
    assert (test_pkg_mgr._cli == None)



# Generated at 2022-06-11 04:02:37.906791
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    test_class = LibMgr()
    assert test_class.is_available() is False


# Generated at 2022-06-11 04:02:40.537746
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.packages.test_libmgr'
    assert TestLibMgr().is_available() is False


# Generated at 2022-06-11 04:02:49.281071
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    manager = PkgMgr()

    def test_list_installed():
        return ['package1', 'package2']

    def get_package_details(package):
        return {'name': package, 'version': '1.2.3'}

    manager.list_installed = test_list_installed
    manager.get_package_details = get_package_details

    assert manager.get_packages() == {'package1': [{'name': 'package1', 'version': '1.2.3', 'source': 'PkgMgr'}],
                                      'package2': [{'name': 'package2', 'version': '1.2.3', 'source': 'PkgMgr'}]}

# Generated at 2022-06-11 04:02:54.921431
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():

    import unittest
    import mock

    class TestCLIMgr(CLIMgr):
        CLI = 'test'

    class MockGetBinPath(object):
        def __call__(self, bin, required=True):
            pass

    mock_obj = MockGetBinPath()
    with mock.patch.object(TestCLIMgr, 'get_bin_path', new=mock_obj):
        t = TestCLIMgr()
        assert t.is_available()

# Generated at 2022-06-11 04:02:59.637292
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():

    pm = get_all_pkg_managers()['dnf']()
    # dnf mod-utils
    assert pm.is_available()
    # packages-arch-specific mod_utils
    pm._lib = None
    pm.LIB = 'dnfplugins.atomic'
    assert pm.is_available()
    # rpm-python mod_utils
    pm._lib = None
    pm.LIB = 'extras'
    assert pm.is_available()


# Generated at 2022-06-11 04:06:00.653584
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    manager = CLIMgr()
    manager.CLI = __file__
    assert manager.is_available() is False
    manager.CLI = "__init__.py"
    assert manager.is_available() is True


# Generated at 2022-06-11 04:06:01.445607
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    pass


# Generated at 2022-06-11 04:06:10.675039
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils.six.moves import mock
    import ansible.module_utils.facts.packages.pip as pip

    # Unavailable command
    pkg = CLIMgr()
    class_name = pkg.__class__.__name__.lower()
    class_name = ansible.module_utils.facts.packages.pip
    class_name.is_available = mock.MagicMock(return_value=False)
    assert pkg.is_available() is False
    assert pkg.list_installed() is None
    assert pkg.get_package_details('dummy-package') == {}
    assert pkg.get_packages() == {}

    # Available command
    pkg = CLIMgr()

# Generated at 2022-06-11 04:06:11.679506
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    test_0 = LibMgr()
    assert test_0.is_available() == False


# Generated at 2022-06-11 04:06:17.789855
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    """Test for method get_packages of class PkgMgr"""
    import platform
    import datetime

    class MockPkgMgr(PkgMgr):

        def is_available(self):
            return True

        def list_installed(self):
            return ['package1', 'package2']

        def get_package_details(self, package):
            return {'name': package, 'version': '1.0.0'}

    pkg_man = MockPkgMgr()
    expected = {'package1': [{'name': 'package1', 'version': '1.0.0', 'source': 'mockpkgmgr'}],
                'package2': [{'name': 'package2', 'version': '1.0.0', 'source': 'mockpkgmgr'}]}
    packages = p

# Generated at 2022-06-11 04:06:19.044792
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    assert CLIMgr.is_available() == False


# Generated at 2022-06-11 04:06:26.762458
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class test_class(LibMgr):
        LIB = 'test_class'
    test = test_class()
    # We'll test the is_available() method using the magic method __mock()
    # so we don't have to import any real modules.
    def __mock(mod_name, mod_file, mod_path, mod_desc):
        assert mod_name == 'test_class'
        raise ImportError("Test ImportError")

    # Check results of calling method is_available() when it can't find the package
    old_imp = __builtins__.__import__
    __builtins__.__import__ = __mock
    result = test.is_available()
    __builtins__.__import__ = old_imp
    assert result is False

    # Check results of calling method is_available() when it can find

# Generated at 2022-06-11 04:06:35.066669
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    try:
        from os import getuid
    except ImportError:
        from getpass import getuser

        get_uid = lambda: getuser()
    else:
        get_uid = getuid
    try:
        import pwd
    except:
        pwd = None
    try:
        import grp
    except:
        grp = None

    lib = LibMgr()
    lib.LIB = 'pwd'
    assert lib.is_available()
    assert lib._lib == pwd
    assert lib.__class__.__name__ in 'PwdMgr'
    lib.LIB = 'pwd'  # trigger ImportError
    assert not lib.is_available()
    lib.LIB = 'pwd'  # trigger ImportError
    assert get_uid() == 0
    assert not lib.is_available()

# Generated at 2022-06-11 04:06:36.944461
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    for _, pkg in get_all_pkg_managers().items():
        assert isinstance(pkg().get_package_details({}), dict)


# Generated at 2022-06-11 04:06:37.809259
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    assert False, "Test not implemented"
