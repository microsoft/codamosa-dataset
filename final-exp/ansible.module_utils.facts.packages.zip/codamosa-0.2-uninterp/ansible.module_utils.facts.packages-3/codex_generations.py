

# Generated at 2022-06-17 01:24:44.056637
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgr

    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True

        def list_installed(self):
            return ['package1', 'package2']

        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}

    pkg_mgr = TestPkgMgr()

# Generated at 2022-06-17 01:24:51.946978
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class PkgMgrTest(PkgMgr):
        def is_available(self):
            return True

        def list_installed(self):
            return ['package1', 'package2']

        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}

    pkg_mgr = PkgMgrTest()
    packages = pkg_mgr.get_packages()
    assert packages == {'package1': [{'name': 'package1', 'version': '1.0', 'source': 'pkgmgrtest'}],
                        'package2': [{'name': 'package2', 'version': '1.0', 'source': 'pkgmgrtest'}]}

# Generated at 2022-06-17 01:24:54.359045
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    assert PkgMgr.list_installed() == NotImplemented


# Generated at 2022-06-17 01:24:56.971429
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    assert PkgMgr.is_available() == False


# Generated at 2022-06-17 01:24:59.577328
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestLibMgr(LibMgr):
        LIB = 'test_lib'

    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr._lib is None


# Generated at 2022-06-17 01:25:04.635031
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'test_lib'
    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr.is_available() == False


# Generated at 2022-06-17 01:25:15.830226
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['package1', 'package2']
        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}
    test_pkg_mgr = TestPkgMgr()
    assert test_pkg_mgr.get_packages() == {'package1': [{'name': 'package1', 'version': '1.0', 'source': 'testpkgmgr'}], 'package2': [{'name': 'package2', 'version': '1.0', 'source': 'testpkgmgr'}]}

# Generated at 2022-06-17 01:25:24.927410
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    from ansible.module_utils.facts.system.pkg_mgr import LibMgr
    from ansible.module_utils.facts.system.pkg_mgr import get_all_pkg_managers
    from ansible.module_utils.facts.system.pkg_mgr import get_all_subclasses
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgr
    from ansible.module_utils.facts.system.pkg_mgr import CLIMgr
    from ansible.module_utils.facts.system.pkg_mgr import LibMgr
    from ansible.module_utils.facts.system.pkg_mgr import get_all_pkg_managers
    from ansible.module_utils.facts.system.pkg_mgr import get_all_subclasses

# Generated at 2022-06-17 01:25:34.316226
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['package1', 'package2']
        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}
    pkg_mgr = TestPkgMgr()
    assert pkg_mgr.get_packages() == {'package1': [{'name': 'package1', 'version': '1.0', 'source': 'testpkgmgr'}],
                                     'package2': [{'name': 'package2', 'version': '1.0', 'source': 'testpkgmgr'}]}

# Generated at 2022-06-17 01:25:35.483716
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr().CLI is None


# Generated at 2022-06-17 01:25:40.891874
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    import sys
    class TestLibMgr(LibMgr):
        LIB = 'sys'
    tlm = TestLibMgr()
    assert tlm.is_available() == True
    assert tlm._lib == sys


# Generated at 2022-06-17 01:25:41.965952
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr()._cli is None


# Generated at 2022-06-17 01:25:43.232859
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    assert PkgMgr.is_available() == False


# Generated at 2022-06-17 01:25:44.885786
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    assert False, "Test not implemented"


# Generated at 2022-06-17 01:25:45.471524
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pass

# Generated at 2022-06-17 01:25:49.531885
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCLIMgr(CLIMgr):
        CLI = 'test_cli'

    test_cli_mgr = TestCLIMgr()
    assert test_cli_mgr.is_available() == False


# Generated at 2022-06-17 01:25:53.134466
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.system.pkg_mgr.test_lib'

    assert TestLibMgr().is_available() is True


# Generated at 2022-06-17 01:25:56.381042
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    class PkgMgrTest(PkgMgr):
        def is_available(self):
            return True
    assert PkgMgrTest().is_available() is True


# Generated at 2022-06-17 01:26:03.927123
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True

        def list_installed(self):
            return ['package1', 'package2']

        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}

    test_pkg_mgr = TestPkgMgr()
    packages = test_pkgMgr.get_packages()
    assert packages == {'package1': [{'name': 'package1', 'version': '1.0', 'source': 'testpkgmgr'}],
                        'package2': [{'name': 'package2', 'version': '1.0', 'source': 'testpkgmgr'}]}

# Generated at 2022-06-17 01:26:05.958151
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    assert PkgMgr.is_available() == False


# Generated at 2022-06-17 01:26:16.918746
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCLIMgr(CLIMgr):
        CLI = 'test_cli'

    test_cli_mgr = TestCLIMgr()
    assert test_cli_mgr.is_available() == False


# Generated at 2022-06-17 01:26:20.768788
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class LibMgrTest(LibMgr):
        LIB = 'ansible.module_utils.facts.system.distribution'
    lm = LibMgrTest()
    assert lm.is_available() == True


# Generated at 2022-06-17 01:26:24.672388
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestLibMgr(LibMgr):
        LIB = 'test_lib'
    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr._lib is None


# Generated at 2022-06-17 01:26:27.561912
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.system.distribution'
    tlm = TestLibMgr()
    assert tlm.is_available()


# Generated at 2022-06-17 01:26:30.061281
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestLibMgr(LibMgr):
        LIB = 'test_lib'
    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr._lib is None


# Generated at 2022-06-17 01:26:38.767326
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['package1', 'package2', 'package3']
        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}
    test_pkg_mgr = TestPkgMgr()
    packages = test_pkg_mgr.get_packages()

# Generated at 2022-06-17 01:26:43.748712
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True

        def list_installed(self):
            return ['test_package']

        def get_package_details(self, package):
            return {'name': 'test_package', 'version': '1.0'}

    pkg_mgr = TestPkgMgr()
    assert pkg_mgr.get_packages() == {'test_package': [{'name': 'test_package', 'version': '1.0', 'source': 'testpkgmgr'}]}

# Generated at 2022-06-17 01:26:47.904641
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.system.pkg_mgr.test_lib'
    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr.is_available()


# Generated at 2022-06-17 01:26:49.932509
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    assert get_all_pkg_managers()

# Generated at 2022-06-17 01:26:52.334668
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.system.distribution'
    assert TestLibMgr().is_available()


# Generated at 2022-06-17 01:27:15.257016
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    import sys
    import os
    import tempfile
    import shutil

    class TestLibMgr(LibMgr):
        LIB = 'test_lib'

    test_lib_dir = tempfile.mkdtemp()
    sys.path.append(test_lib_dir)
    test_lib_file = os.path.join(test_lib_dir, 'test_lib.py')
    with open(test_lib_file, 'w') as f:
        f.write('#!/usr/bin/python\n')
        f.write('# -*- coding: utf-8 -*-\n')
        f.write('\n')
        f.write('class TestLib(object):\n')
        f.write('    pass\n')

# Generated at 2022-06-17 01:27:21.967564
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True

        def list_installed(self):
            return ['test_package']

        def get_package_details(self, package):
            return {'name': 'test_package', 'version': '1.0'}

    pkg_mgr = TestPkgMgr()
    assert pkg_mgr.get_package_details('test_package') == {'name': 'test_package', 'version': '1.0'}


# Generated at 2022-06-17 01:27:28.385484
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True

        def list_installed(self):
            return ['pkg1', 'pkg2']

        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}

    pkg_mgr = TestPkgMgr()
    assert pkg_mgr.get_packages() == {'pkg1': [{'name': 'pkg1', 'version': '1.0', 'source': 'testpkgmgr'}],
                                     'pkg2': [{'name': 'pkg2', 'version': '1.0', 'source': 'testpkgmgr'}]}

# Generated at 2022-06-17 01:27:29.934781
# Unit test for constructor of class LibMgr
def test_LibMgr():
    lm = LibMgr()
    assert lm._lib is None


# Generated at 2022-06-17 01:27:33.239277
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    class TestCLIMgr(CLIMgr):
        CLI = 'test_cli'

    test_cli_mgr = TestCLIMgr()
    assert test_cli_mgr._cli is None


# Generated at 2022-06-17 01:27:38.072274
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCLIMgr(CLIMgr):
        CLI = 'test_cli'
    test_cli_mgr = TestCLIMgr()
    assert test_cli_mgr.is_available() == False
    assert test_cli_mgr._cli == None


# Generated at 2022-06-17 01:27:43.837316
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['package1', 'package2']
        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}
    pkg_mgr = TestPkgMgr()
    assert pkg_mgr.get_packages() == {'package1': [{'name': 'package1', 'version': '1.0', 'source': 'testpkgmgr'}],
                                     'package2': [{'name': 'package2', 'version': '1.0', 'source': 'testpkgmgr'}]}

# Generated at 2022-06-17 01:27:52.807537
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True

        def list_installed(self):
            return ['package1', 'package2']

        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}

    test_pkg_mgr = TestPkgMgr()
    assert test_pkg_mgr.get_packages() == {'package1': [{'name': 'package1', 'version': '1.0', 'source': 'testpkgmgr'}],
                                          'package2': [{'name': 'package2', 'version': '1.0', 'source': 'testpkgmgr'}]}

# Generated at 2022-06-17 01:27:53.776198
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    assert CLIMgr().is_available() == False


# Generated at 2022-06-17 01:28:00.053749
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    from ansible.module_utils.common._utils import get_all_subclasses

    class TestLibMgr(LibMgr):
        LIB = 'test_lib'

    class TestCLIMgr(CLIMgr):
        CLI = 'test_cli'

    class TestPkgMgr(PkgMgr):
        pass

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary virtualenv
    subprocess.check_call(['virtualenv', tmpdir])

    # Add the temporary directory to the module search path
    sys.path.append(tmpdir)

    # Create a temporary module

# Generated at 2022-06-17 01:28:32.890642
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.system.pkg_mgr.test_lib'

    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr.is_available()


# Generated at 2022-06-17 01:28:36.265498
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCLIMgr(CLIMgr):
        CLI = "test_cli"

    test_cli_mgr = TestCLIMgr()
    assert test_cli_mgr.is_available() == False
    assert test_cli_mgr._cli == None


# Generated at 2022-06-17 01:28:38.260740
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCLIMgr(CLIMgr):
        CLI = 'test'
    assert TestCLIMgr().is_available() == False


# Generated at 2022-06-17 01:28:47.871969
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class PkgMgrTest(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['package1', 'package2']
        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}
    pkg_mgr = PkgMgrTest()
    assert pkg_mgr.get_packages() == {'package1': [{'name': 'package1', 'version': '1.0', 'source': 'pkgmgrtest'}], 'package2': [{'name': 'package2', 'version': '1.0', 'source': 'pkgmgrtest'}]}

# Generated at 2022-06-17 01:28:55.517628
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['test_package']
        def get_package_details(self, package):
            return {'name': 'test_package', 'version': '1.0'}
    tpm = TestPkgMgr()
    assert tpm.get_package_details('test_package') == {'name': 'test_package', 'version': '1.0'}


# Generated at 2022-06-17 01:28:59.071428
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestLibMgr(LibMgr):
        LIB = 'testlib'

    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr.is_available() == False


# Generated at 2022-06-17 01:29:01.195521
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    assert isinstance(get_all_pkg_managers(), dict)

# Generated at 2022-06-17 01:29:11.706325
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class PkgMgrTest(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['test1', 'test2']
        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}
    pkg_mgr = PkgMgrTest()
    assert pkg_mgr.get_packages() == {'test1': [{'name': 'test1', 'version': '1.0', 'source': 'pkgmgrtest'}], 'test2': [{'name': 'test2', 'version': '1.0', 'source': 'pkgmgrtest'}]}

# Generated at 2022-06-17 01:29:17.038079
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['package1', 'package2']
        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}
    test_pkg_mgr = TestPkgMgr()
    assert test_pkg_mgr.get_packages() == {'package1': [{'name': 'package1', 'version': '1.0', 'source': 'testpkgmgr'}], 'package2': [{'name': 'package2', 'version': '1.0', 'source': 'testpkgmgr'}]}

# Generated at 2022-06-17 01:29:20.941560
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True

        def list_installed(self):
            return ['package1', 'package2', 'package3']

        def get_package_details(self, package):
            return {'name': package, 'version': '1.0.0'}

    pkg_mgr = TestPkgMgr()
    packages = pkg_mgr.get_packages()

# Generated at 2022-06-17 01:30:33.295561
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestLibMgr(LibMgr):
        LIB = 'test_lib'
    assert TestLibMgr().LIB == 'test_lib'


# Generated at 2022-06-17 01:30:35.569998
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestLibMgr(LibMgr):
        LIB = 'test_lib'

    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr._lib is None


# Generated at 2022-06-17 01:30:45.247558
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class PkgMgrTest(PkgMgr):
        def list_installed(self):
            return ['package1', 'package2']

        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}

    pkg_mgr = PkgMgrTest()
    assert pkg_mgr.get_packages() == {'package1': [{'name': 'package1', 'version': '1.0', 'source': 'pkgmgrtest'}],
                                     'package2': [{'name': 'package2', 'version': '1.0', 'source': 'pkgmgrtest'}]}

# Generated at 2022-06-17 01:30:48.877142
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.system.distribution'

    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr.is_available()


# Generated at 2022-06-17 01:30:51.252699
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class LibMgrTest(LibMgr):
        LIB = 'ansible.module_utils.facts.system.distribution'
    libmgr = LibMgrTest()
    assert libmgr.is_available() == True


# Generated at 2022-06-17 01:31:00.178557
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def __init__(self):
            self.packages = [{'name': 'test_package', 'version': '1.0.0'}]
            super(TestPkgMgr, self).__init__()

        def is_available(self):
            return True

        def list_installed(self):
            return self.packages

        def get_package_details(self, package):
            return package

    test_pkg_mgr = TestPkgMgr()
    assert test_pkg_mgr.get_packages() == {'test_package': [{'name': 'test_package', 'version': '1.0.0', 'source': 'testpkgmgr'}]}

# Generated at 2022-06-17 01:31:12.245822
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['package1', 'package2']
        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}
    pkg_mgr = TestPkgMgr()
    assert pkg_mgr.get_packages() == {'package1': [{'name': 'package1', 'version': '1.0', 'source': 'testpkgmgr'}],
                                     'package2': [{'name': 'package2', 'version': '1.0', 'source': 'testpkgmgr'}]}

# Generated at 2022-06-17 01:31:14.645627
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr().CLI is None


# Generated at 2022-06-17 01:31:19.037506
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    class PkgMgrTest(PkgMgr):
        def list_installed(self):
            return ['test_package']
        def get_package_details(self, package):
            return {'name': 'test_package'}
    pkg_mgr = PkgMgrTest()
    assert pkg_mgr.list_installed() == ['test_package']


# Generated at 2022-06-17 01:31:24.614355
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCLIMgr(CLIMgr):
        CLI = 'test_cli'

    test_cli_mgr = TestCLIMgr()
    assert test_cli_mgr.is_available() == False


# Generated at 2022-06-17 01:34:33.684400
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    pkg_managers = get_all_pkg_managers()
    assert 'apt' in pkg_managers
    assert 'dnf' in pkg_managers
    assert 'yum' in pkg_managers
    assert 'zypper' in pkg_managers
    assert 'pacman' in pkg_managers
    assert 'apk' in pkg_managers
    assert 'pkgng' in pkg_managers
    assert 'portage' in pkg_managers
    assert 'pkg5' in pkg_managers
    assert 'pkg' in pkg_managers
    assert 'pip' in pkg_managers
    assert 'gem' in pkg_managers
    assert 'npm' in pkg_managers
    assert 'pear' in pkg_managers