

# Generated at 2022-06-17 01:24:35.395734
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.system.distribution'

    tlm = TestLibMgr()
    assert tlm.is_available()


# Generated at 2022-06-17 01:24:44.144337
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class PkgMgr_test(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['test_package']
        def get_package_details(self, package):
            return {'name': 'test_package', 'version': '1.0'}
    pkg_mgr = PkgMgr_test()
    assert pkg_mgr.get_package_details('test_package') == {'name': 'test_package', 'version': '1.0'}


# Generated at 2022-06-17 01:24:45.463921
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    assert PkgMgr.list_installed() == NotImplemented


# Generated at 2022-06-17 01:24:46.692740
# Unit test for constructor of class LibMgr
def test_LibMgr():
    lm = LibMgr()
    assert lm._lib is None


# Generated at 2022-06-17 01:24:53.856333
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['package1', 'package2']
        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}

    test_pkg_mgr = TestPkgMgr()
    assert test_pkg_mgr.get_packages() == {'package1': [{'name': 'package1', 'version': '1.0', 'source': 'testpkgmgr'}],
                                          'package2': [{'name': 'package2', 'version': '1.0', 'source': 'testpkgmgr'}]}

# Generated at 2022-06-17 01:25:02.939241
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True

        def list_installed(self):
            return ['package1', 'package2']

        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}

    test_pkg_mgr = TestPkgMgr()
    assert test_pkg_mgr.get_packages() == {'package1': [{'name': 'package1', 'version': '1.0', 'source': 'testpkgmgr'}], 'package2': [{'name': 'package2', 'version': '1.0', 'source': 'testpkgmgr'}]}

# Generated at 2022-06-17 01:25:09.916002
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    """
    Test that get_all_pkg_managers returns a dictionary of all PkgMgr subclasses
    """
    pkg_managers = get_all_pkg_managers()
    assert isinstance(pkg_managers, dict)
    assert len(pkg_managers) > 0
    for pkg_mgr in pkg_managers.values():
        assert issubclass(pkg_mgr, PkgMgr)

# Generated at 2022-06-17 01:25:13.541691
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    class TestCLIMgr(CLIMgr):
        CLI = 'test_cli'
    test_cli_mgr = TestCLIMgr()
    assert test_cli_mgr._cli is None


# Generated at 2022-06-17 01:25:17.983807
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCLIMgr(CLIMgr):
        CLI = 'test_CLIMgr_is_available'
    test_CLIMgr = TestCLIMgr()
    assert test_CLIMgr.is_available() == False
    assert test_CLIMgr._cli == None


# Generated at 2022-06-17 01:25:23.389190
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class PkgMgrTest(PkgMgr):
        def is_available(self):
            pass
        def list_installed(self):
            pass
        def get_package_details(self, package):
            return {'name': 'test', 'version': '1.0'}
    pkg = PkgMgrTest()
    assert pkg.get_package_details('test') == {'name': 'test', 'version': '1.0'}


# Generated at 2022-06-17 01:25:32.005450
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.system.pkg_mgr.test_lib'

    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr.is_available() == True


# Generated at 2022-06-17 01:25:37.545207
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.system.pkg_mgr.test_lib'

    tlm = TestLibMgr()
    assert tlm.is_available()
    assert tlm._lib.__name__ == 'ansible.module_utils.facts.system.pkg_mgr.test_lib'


# Generated at 2022-06-17 01:25:39.593637
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCLIMgr(CLIMgr):
        CLI = 'test_CLIMgr_is_available'

    test_CLIMgr = TestCLIMgr()
    assert test_CLIMgr.is_available() == False


# Generated at 2022-06-17 01:25:45.899315
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    pkg_managers = get_all_pkg_managers()
    assert 'apt' in pkg_managers
    assert 'yum' in pkg_managers
    assert 'dnf' in pkg_managers
    assert 'zypper' in pkg_managers
    assert 'pacman' in pkg_managers
    assert 'apk' in pkg_managers
    assert 'portage' in pkg_managers
    assert 'pkgng' in pkg_managers
    assert 'pip' in pkg_managers
    assert 'gem' in pkg_managers
    assert 'npm' in pkg_managers
    assert 'composer' in pkg_managers
    assert 'pecl' in pkg_managers
    assert 'pip3' in pkg_managers


# Generated at 2022-06-17 01:25:49.904786
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'test_lib'

    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr.is_available() == False


# Generated at 2022-06-17 01:26:00.780087
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.facts.system.pkg_mgr import CLIMgr

    class TestCLIMgr(CLIMgr):
        CLI = 'test_cli'

    test_cli_mgr = TestCLIMgr()
    assert test_cli_mgr.is_available() == False

    get_bin_path_mock = get_bin_path
    def get_bin_path_mock_side_effect(cmd):
        if cmd == 'test_cli':
            return '/usr/bin/test_cli'
        else:
            raise ValueError('Command not found: %s' % cmd)
    get_bin_path.side_effect = get_bin_path_mock_side_effect

    assert test_cli_m

# Generated at 2022-06-17 01:26:06.532628
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class PkgMgrTest(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['a', 'b']
        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}
    pkg_mgr = PkgMgrTest()
    assert pkg_mgr.get_packages() == {'a': [{'name': 'a', 'version': '1.0', 'source': 'pkgmgrtest'}], 'b': [{'name': 'b', 'version': '1.0', 'source': 'pkgmgrtest'}]}

# Generated at 2022-06-17 01:26:10.569026
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.system.distribution'

    assert TestLibMgr().is_available() is True


# Generated at 2022-06-17 01:26:11.935604
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    # Test if the CLI is available
    assert CLIMgr().is_available() == True


# Generated at 2022-06-17 01:26:12.726239
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    assert PkgMgr.is_available() == False


# Generated at 2022-06-17 01:26:27.870162
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.facts.system.pkg_mgr import LibMgr

    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.system.pkg_mgr.test_lib_mgr'

    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr.is_available() is False

    # Mock the import of the library
    class TestLib:
        pass

    test_lib = TestLib()
    test_lib.__file__ = '/path/to/test_lib.py'

# Generated at 2022-06-17 01:26:29.378402
# Unit test for constructor of class LibMgr
def test_LibMgr():
    lib_mgr = LibMgr()
    assert lib_mgr._lib is None


# Generated at 2022-06-17 01:26:37.923301
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.facts.system.pkg_mgr import LibMgr
    from ansible.module_utils.facts.system.pkg_mgr import CLIMgr
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgr

    class TestLibMgr(LibMgr):
        LIB = 'os'

    class TestCLIMgr(CLIMgr):
        CLI = 'ls'

    class TestPkgMgr(PkgMgr):
        pass

    test_lib_mgr = TestLibMgr()
    test_cli_mgr = TestCLIMgr()
    test_pkg_mgr = TestPkgMgr()

    assert test_lib_mgr.is_available()
   

# Generated at 2022-06-17 01:26:38.925776
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    assert CLIMgr().is_available() == False


# Generated at 2022-06-17 01:26:45.756336
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.facts.system.pkg_mgr import CLIMgr
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgr
    from ansible.module_utils.facts.system.pkg_mgr import get_all_pkg_managers

    # Test for a package manager that is not installed
    class TestCLIMgr(CLIMgr):
        CLI = 'not_installed'

    test_mgr = TestCLIMgr()
    assert test_mgr.is_available() == False

    # Test for a package manager that is installed
    class TestCLIMgr(CLIMgr):
        CLI = 'ls'

    test_mgr = TestCLIMgr()

# Generated at 2022-06-17 01:26:48.574482
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.system.pkg_mgr.test_lib'

    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr.is_available()


# Generated at 2022-06-17 01:26:50.805563
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    assert PkgMgr.list_installed() is None


# Generated at 2022-06-17 01:27:01.782291
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True

        def list_installed(self):
            return ['package1', 'package2', 'package3']

        def get_package_details(self, package):
            return {'name': package, 'version': '1.0.0'}

    pkg_mgr = TestPkgMgr()

# Generated at 2022-06-17 01:27:10.403816
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['package1', 'package2']
        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}
    pkg_mgr = TestPkgMgr()
    assert pkg_mgr.list_installed() == ['package1', 'package2']


# Generated at 2022-06-17 01:27:18.021309
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class PkgMgrTest(PkgMgr):
        def is_available(self):
            return True

        def list_installed(self):
            return ['package1', 'package2']

        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}

    pkg_mgr = PkgMgrTest()
    assert pkg_mgr.get_package_details('package1') == {'name': 'package1', 'version': '1.0'}


# Generated at 2022-06-17 01:27:23.401059
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr().CLI is None


# Generated at 2022-06-17 01:27:29.220309
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True

        def list_installed(self):
            return ['pkg1', 'pkg2']

        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}

    pkg_mgr = TestPkgMgr()
    assert pkg_mgr.get_packages() == {'pkg1': [{'name': 'pkg1', 'version': '1.0', 'source': 'testpkgmgr'}],
                                     'pkg2': [{'name': 'pkg2', 'version': '1.0', 'source': 'testpkgmgr'}]}

# Generated at 2022-06-17 01:27:32.360903
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestLibMgr(LibMgr):
        LIB = 'test_lib'
    assert TestLibMgr().LIB == 'test_lib'


# Generated at 2022-06-17 01:27:40.071474
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['test_package']
        def get_package_details(self, package):
            return {'name': 'test_package', 'version': '1.0.0'}
    test_pkg_mgr = TestPkgMgr()
    assert test_pkg_mgr.get_package_details('test_package') == {'name': 'test_package', 'version': '1.0.0'}


# Generated at 2022-06-17 01:27:41.139061
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    assert PkgMgr.is_available() == False


# Generated at 2022-06-17 01:27:42.826970
# Unit test for constructor of class LibMgr
def test_LibMgr():
    lib_mgr = LibMgr()
    assert lib_mgr._lib is None


# Generated at 2022-06-17 01:27:45.718451
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    class TestCLIMgr(CLIMgr):
        CLI = 'test'
    assert TestCLIMgr().is_available() == False


# Generated at 2022-06-17 01:27:54.728344
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class PkgMgrTest(PkgMgr):
        def list_installed(self):
            return ['package1', 'package2', 'package3']

        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}

    pkg_mgr = PkgMgrTest()
    assert pkg_mgr.get_packages() == {'package1': [{'name': 'package1', 'version': '1.0', 'source': 'pkgmgrtest'}],
                                     'package2': [{'name': 'package2', 'version': '1.0', 'source': 'pkgmgrtest'}],
                                     'package3': [{'name': 'package3', 'version': '1.0', 'source': 'pkgmgrtest'}]}

# Generated at 2022-06-17 01:27:57.562597
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.system.pkg_mgr.test_lib'

    lib_mgr = TestLibMgr()
    assert lib_mgr.is_available()


# Generated at 2022-06-17 01:28:04.663063
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    class PkgMgr_test(PkgMgr):
        def list_installed(self):
            return ['package1', 'package2']

        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}

    pkg_mgr = PkgMgr_test()
    assert pkg_mgr.list_installed() == ['package1', 'package2']


# Generated at 2022-06-17 01:28:13.387327
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    class TestCLIMgr(CLIMgr):
        CLI = 'test_cli'
    test_cli_mgr = TestCLIMgr()
    assert test_cli_mgr._cli is None


# Generated at 2022-06-17 01:28:15.653519
# Unit test for constructor of class LibMgr
def test_LibMgr():
    libmgr = LibMgr()
    assert libmgr is not None


# Generated at 2022-06-17 01:28:26.068962
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['package1', 'package2']
        def get_package_details(self, package):
            return {'name': package, 'version': '1.0.0'}
    pkg_mgr = TestPkgMgr()
    packages = pkg_mgr.get_packages()
    assert packages == {'package1': [{'name': 'package1', 'version': '1.0.0', 'source': 'testpkgmgr'}],
                        'package2': [{'name': 'package2', 'version': '1.0.0', 'source': 'testpkgmgr'}]}

# Generated at 2022-06-17 01:28:28.021811
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    assert CLIMgr().is_available() == False


# Generated at 2022-06-17 01:28:30.436921
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.system.distribution'

    assert TestLibMgr().is_available() is True


# Generated at 2022-06-17 01:28:37.372168
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['package1', 'package2']
        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}
    tpm = TestPkgMgr()
    assert tpm.get_packages() == {'package1': [{'name': 'package1', 'version': '1.0', 'source': 'testpkgmgr'}], 'package2': [{'name': 'package2', 'version': '1.0', 'source': 'testpkgmgr'}]}

# Generated at 2022-06-17 01:28:40.155485
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    class PkgMgr_test(PkgMgr):
        def list_installed(self):
            return ['test']
    pkg_mgr = PkgMgr_test()
    assert pkg_mgr.list_installed() == ['test']


# Generated at 2022-06-17 01:28:44.233801
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCLIMgr(CLIMgr):
        CLI = 'test_cli'
    test_mgr = TestCLIMgr()
    assert test_mgr.is_available() == False
    assert test_mgr._cli == None


# Generated at 2022-06-17 01:28:53.858299
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    class TestPkgMgr(PkgMgr):

        def is_available(self):
            return True

        def list_installed(self):
            return ['package1', 'package2']

        def get_package_details(self, package):
            return {'name': package, 'version': '1.0.0'}

    pkg_mgr = TestPkgMgr()
    packages = pkg_mgr.get_packages()
    assert packages == {'package1': [{'name': 'package1', 'version': '1.0.0', 'source': 'testpkgmgr'}],
                        'package2': [{'name': 'package2', 'version': '1.0.0', 'source': 'testpkgmgr'}]}

# Generated at 2022-06-17 01:29:03.211209
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['package1', 'package2']
        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}
    pkg_mgr = TestPkgMgr()
    assert pkg_mgr.get_packages() == {'package1': [{'name': 'package1', 'version': '1.0', 'source': 'testpkgmgr'}], 'package2': [{'name': 'package2', 'version': '1.0', 'source': 'testpkgmgr'}]}

# Generated at 2022-06-17 01:29:12.109034
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestLibMgr(LibMgr):
        LIB = 'test_lib'

    tlm = TestLibMgr()
    assert tlm._lib is None


# Generated at 2022-06-17 01:29:16.786141
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class PkgMgrTest(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['test_package']
        def get_package_details(self, package):
            return {'name': 'test_package', 'version': '1.0.0'}
    pkg_mgr = PkgMgrTest()
    assert pkg_mgr.get_package_details('test_package') == {'name': 'test_package', 'version': '1.0.0'}


# Generated at 2022-06-17 01:29:22.363598
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    import unittest
    import sys
    import os
    import tempfile
    import shutil
    import json

    class TestPkgMgr(PkgMgr):
        def __init__(self):
            super(TestPkgMgr, self).__init__()

        def is_available(self):
            return True

        def list_installed(self):
            return ['test_package']

        def get_package_details(self, package):
            return {'name': 'test_package', 'version': '1.0.0'}

    class TestPkgMgrTestCase(unittest.TestCase):
        def setUp(self):
            self.test_dir = tempfile.mkdtemp()
            self.test_file = os.path.join(self.test_dir, 'test_file')


# Generated at 2022-06-17 01:29:26.655902
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    import os
    import sys
    import tempfile
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary 'bin' directory
    bindir = os.path.join(tmpdir, 'bin')
    os.mkdir(bindir)

    # Create a temporary 'lib' directory
    libdir = os.path.join(tmpdir, 'lib')
    os.mkdir(libdir)

    # Create a temporary 'python' directory
    pythondir = os.path.join(tmpdir, 'python')
    os.mkdir(pythondir)

    # Create a temporary 'python2.7' directory
    python27dir = os.path.join(pythondir, 'python2.7')
    os.mkdir(python27dir)



# Generated at 2022-06-17 01:29:31.444222
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['package1', 'package2']
        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}
    pkg_mgr = TestPkgMgr()
    assert pkg_mgr.get_packages() == {'package1': [{'name': 'package1', 'version': '1.0', 'source': 'testpkgmgr'}], 'package2': [{'name': 'package2', 'version': '1.0', 'source': 'testpkgmgr'}]}

# Generated at 2022-06-17 01:29:35.390967
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestLibMgr(LibMgr):
        LIB = 'test_lib'

    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr._lib is None


# Generated at 2022-06-17 01:29:38.302880
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.system.pkg_mgr.test_lib'
    assert TestLibMgr().is_available()


# Generated at 2022-06-17 01:29:42.904883
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCLIMgr(CLIMgr):
        CLI = 'test_cli'

    test_cli_mgr = TestCLIMgr()
    assert test_cli_mgr.is_available() == False


# Generated at 2022-06-17 01:29:45.467972
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.system.pkg_mgr.test_lib'

    assert TestLibMgr().is_available() is True


# Generated at 2022-06-17 01:29:47.059431
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr().CLI is None


# Generated at 2022-06-17 01:29:56.083330
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    assert PkgMgr.is_available() == False


# Generated at 2022-06-17 01:30:03.344130
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    pkg_mgrs = get_all_pkg_managers()
    assert len(pkg_mgrs) > 0
    assert 'apt' in pkg_mgrs
    assert 'yum' in pkg_mgrs
    assert 'dnf' in pkg_mgrs
    assert 'zypper' in pkg_mgrs
    assert 'pacman' in pkg_mgrs
    assert 'apk' in pkg_mgrs
    assert 'portage' in pkg_mgrs
    assert 'pip' in pkg_mgrs
    assert 'gem' in pkg_mgrs
    assert 'npm' in pkg_mgrs
    assert 'pecl' in pkg_mgrs
    assert 'pear' in pkg_mgrs

# Generated at 2022-06-17 01:30:07.638700
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCLIMgr(CLIMgr):
        CLI = 'test_cli'

    test_cli_mgr = TestCLIMgr()
    assert test_cli_mgr.is_available() is False
    assert test_cli_mgr._cli is None

# Generated at 2022-06-17 01:30:11.944868
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.system.distribution'

    assert TestLibMgr().is_available() == True


# Generated at 2022-06-17 01:30:20.825637
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['package1', 'package2']
        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}
    pkg_mgr = TestPkgMgr()
    assert pkg_mgr.get_packages() == {'package1': [{'name': 'package1', 'version': '1.0', 'source': 'testpkgmgr'}],
                                     'package2': [{'name': 'package2', 'version': '1.0', 'source': 'testpkgmgr'}]}

# Generated at 2022-06-17 01:30:26.842158
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.system.pkg_mgr.test_lib'

    assert TestLibMgr().is_available() is True


# Generated at 2022-06-17 01:30:31.087046
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class PkgMgrTest(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['package1', 'package2']
        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}
    pkg_mgr = PkgMgrTest()
    assert pkg_mgr.get_packages() == {'package1': [{'name': 'package1', 'version': '1.0', 'source': 'pkgmgrtest'}],
                                     'package2': [{'name': 'package2', 'version': '1.0', 'source': 'pkgmgrtest'}]}

# Generated at 2022-06-17 01:30:34.530453
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.system.pkg_mgr.test_lib'

    test_mgr = TestLibMgr()
    assert test_mgr.is_available()
    assert test_mgr._lib.__name__ == 'ansible.module_utils.facts.system.pkg_mgr.test_lib'


# Generated at 2022-06-17 01:30:45.335284
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['a', 'b', 'c']
        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}
    pkg_mgr = TestPkgMgr()
    packages = pkg_mgr.get_packages()

# Generated at 2022-06-17 01:30:46.502558
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr().CLI == None


# Generated at 2022-06-17 01:30:57.599566
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr().CLI is None


# Generated at 2022-06-17 01:31:04.693789
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True

        def list_installed(self):
            return ['package1', 'package2']

        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}

    test_pkg_mgr = TestPkgMgr()
    assert test_pkg_mgr.get_packages() == {'package1': [{'name': 'package1', 'version': '1.0', 'source': 'testpkgmgr'}],
                                          'package2': [{'name': 'package2', 'version': '1.0', 'source': 'testpkgmgr'}]}

# Generated at 2022-06-17 01:31:13.336857
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class PkgMgrTest(PkgMgr):
        def list_installed(self):
            return ['package1', 'package2']
        def get_package_details(self, package):
            return {'name': package, 'version': '1.0.0'}
    pkg_mgr = PkgMgrTest()
    assert pkg_mgr.get_packages() == {'package1': [{'name': 'package1', 'version': '1.0.0', 'source': 'pkgmgrtest'}],
                                     'package2': [{'name': 'package2', 'version': '1.0.0', 'source': 'pkgmgrtest'}]}

# Generated at 2022-06-17 01:31:20.849232
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    import unittest
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgr, LibMgr, CLIMgr
    from ansible.module_utils.facts.system.pkg_mgr.yum import Yum
    from ansible.module_utils.facts.system.pkg_mgr.dnf import Dnf
    from ansible.module_utils.facts.system.pkg_mgr.apt import Apt
    from ansible.module_utils.facts.system.pkg_mgr.apk import Apk
    from ansible.module_utils.facts.system.pkg_mgr.pkgng import Pkgng
    from ansible.module_utils.facts.system.pkg_mgr.pacman import Pac

# Generated at 2022-06-17 01:31:29.211824
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class PkgMgrTest(PkgMgr):
        def list_installed(self):
            return [
                'package1',
                'package2',
                'package3',
            ]

        def get_package_details(self, package):
            return {
                'name': package,
                'version': '1.0.0',
            }

    pkg_mgr = PkgMgrTest()

# Generated at 2022-06-17 01:31:34.525756
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestLibMgr(LibMgr):
        LIB = 'test_lib'
    assert TestLibMgr().LIB == 'test_lib'


# Generated at 2022-06-17 01:31:36.046850
# Unit test for constructor of class LibMgr
def test_LibMgr():
    assert LibMgr()

# Generated at 2022-06-17 01:31:37.095515
# Unit test for constructor of class LibMgr
def test_LibMgr():
    lib_mgr = LibMgr()
    assert lib_mgr._lib is None


# Generated at 2022-06-17 01:31:42.147008
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    # Test case 1:
    #   Input:
    #       package = 'python-2.7.5-48.el7.x86_64'
    #   Expected output:
    #       {'name': 'python', 'version': '2.7.5-48.el7', 'release': '48.el7', 'arch': 'x86_64'}
    package = 'python-2.7.5-48.el7.x86_64'
    expected_output = {'name': 'python', 'version': '2.7.5-48.el7', 'release': '48.el7', 'arch': 'x86_64'}
    assert PkgMgr.get_package_details(package) == expected_output

    # Test case 2:
    #   Input:
    #       package =

# Generated at 2022-06-17 01:31:44.361309
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    assert PkgMgr.list_installed() is None


# Generated at 2022-06-17 01:32:18.320432
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['package1', 'package2']
        def get_package_details(self, package):
            return {'name': package, 'version': '1.0.0'}
    test_pkg_mgr = TestPkgMgr()
    assert test_pkg_mgr.get_packages() == {'package1': [{'name': 'package1', 'version': '1.0.0', 'source': 'testpkgmgr'}], 'package2': [{'name': 'package2', 'version': '1.0.0', 'source': 'testpkgmgr'}]}

# Generated at 2022-06-17 01:32:24.883310
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    pkg_mgrs = get_all_pkg_managers()
    assert 'apt' in pkg_mgrs
    assert 'yum' in pkg_mgrs
    assert 'dnf' in pkg_mgrs
    assert 'zypper' in pkg_mgrs
    assert 'pacman' in pkg_mgrs
    assert 'apk' in pkg_mgrs
    assert 'portage' in pkg_mgrs
    assert 'pkgng' in pkg_mgrs
    assert 'pkg5' in pkg_mgrs
    assert 'pkg' in pkg_mgrs
    assert 'pip' in pkg_mgrs
    assert 'gem' in pkg_mgrs
    assert 'npm' in pkg_mgrs

# Generated at 2022-06-17 01:32:30.043838
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.system.pkg_mgr.test_lib'

    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr.is_available()


# Generated at 2022-06-17 01:32:33.902827
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['package1', 'package2']
        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}

    test_pkg_mgr = TestPkgMgr()
    assert test_pkg_mgr.get_package_details('package1') == {'name': 'package1', 'version': '1.0'}
    assert test_pkg_mgr.get_package_details('package2') == {'name': 'package2', 'version': '1.0'}


# Generated at 2022-06-17 01:32:35.147342
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr().CLI is None


# Generated at 2022-06-17 01:32:39.179141
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCLIMgr(CLIMgr):
        CLI = 'test_CLIMgr_is_available'

    test_CLIMgr = TestCLIMgr()
    assert test_CLIMgr.is_available() == False


# Generated at 2022-06-17 01:32:41.203017
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pkg_mgr = PkgMgr()
    assert pkg_mgr.is_available() == NotImplemented


# Generated at 2022-06-17 01:32:42.471806
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr().CLI is None


# Generated at 2022-06-17 01:32:48.330654
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.system.distribution'

    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr.is_available()


# Generated at 2022-06-17 01:32:53.487842
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class CLIMgr_test(CLIMgr):
        CLI = 'test_CLIMgr_is_available'
    assert not CLIMgr_test().is_available()
    assert CLIMgr_test().is_available() == get_bin_path('test_CLIMgr_is_available')

# Generated at 2022-06-17 01:33:44.713674
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    assert PkgMgr.is_available() == False


# Generated at 2022-06-17 01:33:53.420659
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    pkg_managers = get_all_pkg_managers()
    assert 'apt' in pkg_managers
    assert 'yum' in pkg_managers
    assert 'dnf' in pkg_managers
    assert 'zypper' in pkg_managers
    assert 'pacman' in pkg_managers
    assert 'apk' in pkg_managers
    assert 'portage' in pkg_managers
    assert 'pkgng' in pkg_managers
    assert 'pip' in pkg_managers
    assert 'gem' in pkg_managers
    assert 'npm' in pkg_managers
    assert 'pear' in pkg_managers
    assert 'puppet' in pkg_managers
    assert 'composer' in pkg_managers
   

# Generated at 2022-06-17 01:33:57.852459
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCLIMgr(CLIMgr):
        CLI = 'test_cli'
    test_mgr = TestCLIMgr()
    assert test_mgr.is_available() == False
    assert test_mgr._cli == None


# Generated at 2022-06-17 01:33:59.009877
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    cli = CLIMgr()
    assert cli._cli is None


# Generated at 2022-06-17 01:34:01.168919
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    assert PkgMgr.list_installed() == NotImplemented


# Generated at 2022-06-17 01:34:07.983073
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCLIMgr(CLIMgr):
        CLI = 'test_cli'

    test_cli_mgr = TestCLIMgr()
    assert test_cli_mgr.is_available() == False

    test_cli_mgr._cli = 'test_cli'
    assert test_cli_mgr.is_available() == True

# Generated at 2022-06-17 01:34:14.719073
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.facts.system.pkg_mgr import CLIMgr
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgr
    from ansible.module_utils.facts.system.pkg_mgr import get_all_pkg_managers
    from ansible.module_utils.facts.system.pkg_mgr import get_all_subclasses
    import pytest
    import sys

    # Test if the method is_available of class CLIMgr returns True if the CLI is available
    class TestCLIMgr(CLIMgr):
        CLI = 'python'

    test_cli_mgr = TestCLIMgr()
    assert test_cli_mgr.is_available() == True

    # Test

# Generated at 2022-06-17 01:34:17.857090
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestLibMgr(LibMgr):
        LIB = 'test_lib'

    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr._lib is None


# Generated at 2022-06-17 01:34:20.933844
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.system.pkg_mgr.test_lib'

    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr.is_available()


# Generated at 2022-06-17 01:34:25.213023
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.system.distribution'

    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr.is_available() == True
