

# Generated at 2022-06-17 01:24:29.672298
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr()

# Generated at 2022-06-17 01:24:35.400649
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class FakePkgMgr(PkgMgr):
        def is_available(self):
            return True

        def list_installed(self):
            return ['package1', 'package2']

        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}

    fake_pkg_mgr = FakePkgMgr()
    assert fake_pkg_mgr.get_packages() == {'package1': [{'name': 'package1', 'version': '1.0', 'source': 'fakepkgmgr'}],
                                           'package2': [{'name': 'package2', 'version': '1.0', 'source': 'fakepkgmgr'}]}

# Generated at 2022-06-17 01:24:45.933447
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['package1', 'package2']
        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}
    pkg_mgr = TestPkgMgr()
    packages = pkg_mgr.get_packages()
    assert packages == {'package1': [{'name': 'package1', 'version': '1.0', 'source': 'testpkgmgr'}],
                        'package2': [{'name': 'package2', 'version': '1.0', 'source': 'testpkgmgr'}]}

# Generated at 2022-06-17 01:24:47.158310
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr().CLI is None


# Generated at 2022-06-17 01:24:49.137384
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'os'
    assert TestLibMgr().is_available()


# Generated at 2022-06-17 01:24:58.423889
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class PkgMgrTest(PkgMgr):
        def list_installed(self):
            return ['package1', 'package2']
        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}
    pkgmgr = PkgMgrTest()
    assert pkgmgr.get_packages() == {'package1': [{'name': 'package1', 'version': '1.0', 'source': 'pkgmgrtest'}],
                                    'package2': [{'name': 'package2', 'version': '1.0', 'source': 'pkgmgrtest'}]}

# Generated at 2022-06-17 01:25:00.547069
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr().CLI is None


# Generated at 2022-06-17 01:25:02.643396
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr().is_available() == False


# Generated at 2022-06-17 01:25:07.921234
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCLIMgr(CLIMgr):
        CLI = 'test_cli'
    test_cli_mgr = TestCLIMgr()
    assert test_cli_mgr.is_available() == False


# Generated at 2022-06-17 01:25:10.822475
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestLibMgr(LibMgr):
        LIB = 'test_lib'
    assert TestLibMgr().LIB == 'test_lib'


# Generated at 2022-06-17 01:25:21.662024
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    import sys
    sys.modules['lib'] = None
    lm = LibMgr()
    lm.LIB = 'lib'
    assert lm.is_available() == True
    sys.modules['lib'] = None
    assert lm.is_available() == False


# Generated at 2022-06-17 01:25:28.444099
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.system.pkg_mgr.test_lib'

    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr.is_available()


# Generated at 2022-06-17 01:25:35.348311
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['package1', 'package2']
        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}
    pkg_mgr = TestPkgMgr()
    assert pkg_mgr.get_packages() == {'package1': [{'name': 'package1', 'version': '1.0', 'source': 'testpkgmgr'}], 'package2': [{'name': 'package2', 'version': '1.0', 'source': 'testpkgmgr'}]}

# Generated at 2022-06-17 01:25:38.508087
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr()._cli is None


# Generated at 2022-06-17 01:25:42.142228
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.system.pkg_mgr.test_lib'

    pkg_mgr = TestLibMgr()
    assert pkg_mgr.is_available()
    assert pkg_mgr._lib is not None


# Generated at 2022-06-17 01:25:48.262276
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCLIMgr(CLIMgr):
        CLI = 'test_cli'
    test_cli_mgr = TestCLIMgr()
    assert test_cli_mgr.is_available() == False
    test_cli_mgr._cli = 'test_cli_path'
    assert test_cli_mgr.is_available() == True


# Generated at 2022-06-17 01:25:49.626496
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr().CLI is None


# Generated at 2022-06-17 01:25:53.494961
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    """
    Test the constructor of class CLIMgr
    """
    class TestCLIMgr(CLIMgr):
        CLI = 'test_cli'

    test_mgr = TestCLIMgr()
    assert test_mgr._cli is None


# Generated at 2022-06-17 01:25:55.457136
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    assert PkgMgr.is_available() == False


# Generated at 2022-06-17 01:26:02.214212
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['test_package']
        def get_package_details(self, package):
            return {'name': 'test_package', 'version': '1.0.0'}
    pkg_mgr = TestPkgMgr()
    assert pkg_mgr.get_packages() == {'test_package': [{'name': 'test_package', 'version': '1.0.0', 'source': 'testpkgmgr'}]}

# Generated at 2022-06-17 01:26:10.390696
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.system.distribution'

    assert TestLibMgr().is_available()


# Generated at 2022-06-17 01:26:18.573675
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['package1', 'package2']
        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}
    test_pkg_mgr = TestPkgMgr()
    assert test_pkg_mgr.get_package_details('package1') == {'name': 'package1', 'version': '1.0'}
    assert test_pkg_mgr.get_package_details('package2') == {'name': 'package2', 'version': '1.0'}


# Generated at 2022-06-17 01:26:26.280616
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class PkgMgrTest(PkgMgr):
        def is_available(self):
            pass
        def list_installed(self):
            pass
        def get_package_details(self, package):
            return {'name': 'test', 'version': '1.0'}
    pkg_mgr = PkgMgrTest()
    assert pkg_mgr.get_package_details('test') == {'name': 'test', 'version': '1.0'}


# Generated at 2022-06-17 01:26:34.251051
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['package1', 'package2']
        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}
    test_pkg_mgr = TestPkgMgr()
    assert test_pkg_mgr.get_packages() == {'package1': [{'name': 'package1', 'version': '1.0', 'source': 'testpkgmgr'}], 'package2': [{'name': 'package2', 'version': '1.0', 'source': 'testpkgmgr'}]}

# Generated at 2022-06-17 01:26:43.655328
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class PkgMgrTest(PkgMgr):
        def list_installed(self):
            return ['package1', 'package2']

        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}

    pkg_mgr = PkgMgrTest()
    assert pkg_mgr.get_packages() == {'package1': [{'name': 'package1', 'version': '1.0', 'source': 'pkgmgrtest'}],
                                     'package2': [{'name': 'package2', 'version': '1.0', 'source': 'pkgmgrtest'}]}

# Generated at 2022-06-17 01:26:47.336617
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCLIMgr(CLIMgr):
        CLI = 'test_cli'

    test_mgr = TestCLIMgr()
    assert test_mgr.is_available() == False


# Generated at 2022-06-17 01:26:55.239355
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class PkgMgrTest(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['package1', 'package2']
        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}
    pkg_mgr = PkgMgrTest()
    assert pkg_mgr.get_packages() == {'package1': [{'name': 'package1', 'version': '1.0', 'source': 'pkgmgrtest'}],
                                     'package2': [{'name': 'package2', 'version': '1.0', 'source': 'pkgmgrtest'}]}

# Generated at 2022-06-17 01:26:58.090713
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.system.distribution'

    tlm = TestLibMgr()
    assert tlm.is_available()


# Generated at 2022-06-17 01:26:58.954223
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    assert get_all_pkg_managers()

# Generated at 2022-06-17 01:27:10.006947
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['test_package']
        def get_package_details(self, package):
            return {'name': 'test_package', 'version': '1.0'}
    test_pkg_mgr = TestPkgMgr()
    assert test_pkg_mgr.get_package_details('test_package') == {'name': 'test_package', 'version': '1.0'}


# Generated at 2022-06-17 01:27:17.267676
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'os'

    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr.is_available() == True


# Generated at 2022-06-17 01:27:19.770769
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCLIMgr(CLIMgr):
        CLI = 'test_cli'
    test_mgr = TestCLIMgr()
    assert test_mgr.is_available() == False


# Generated at 2022-06-17 01:27:27.133116
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['package1', 'package2']
        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}
    test_pkg_mgr = TestPkgMgr()
    assert test_pkg_mgr.get_packages() == {'package1': [{'name': 'package1', 'version': '1.0', 'source': 'testpkgmgr'}],
                                          'package2': [{'name': 'package2', 'version': '1.0', 'source': 'testpkgmgr'}]}

# Generated at 2022-06-17 01:27:31.321716
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    class PkgMgr_test(PkgMgr):
        def list_installed(self):
            return ['package1', 'package2']
    test_pkg_mgr = PkgMgr_test()
    assert test_pkg_mgr.list_installed() == ['package1', 'package2']


# Generated at 2022-06-17 01:27:35.911196
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCLIMgr(CLIMgr):
        CLI = 'test'

    test_cli_mgr = TestCLIMgr()
    assert test_cli_mgr.is_available() == False


# Generated at 2022-06-17 01:27:38.383094
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'os'

    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr.is_available() == True


# Generated at 2022-06-17 01:27:40.106518
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    pkg_mgr = PkgMgr()
    assert pkg_mgr.get_package_details('test') == {}


# Generated at 2022-06-17 01:27:50.821915
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    from ansible.module_utils.common.process import get_bin_path

    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True

        def list_installed(self):
            return ['package1', 'package2']

        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}

    test_pkg_mgr = TestPkgMgr()
    packages = test_pkg_mgr.get_packages()
    assert packages == {'package1': [{'name': 'package1', 'version': '1.0', 'source': 'testpkgmgr'}],
                        'package2': [{'name': 'package2', 'version': '1.0', 'source': 'testpkgmgr'}]}

# Generated at 2022-06-17 01:27:54.456008
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    assert PkgMgr.is_available() == False


# Generated at 2022-06-17 01:28:00.589750
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    import os
    import sys
    import tempfile
    import shutil
    import subprocess

    class TestLibMgr(LibMgr):
        LIB = 'testlib'

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create the testlib.py file
    testlib = os.path.join(tmpdir, 'testlib.py')
    with open(testlib, 'w') as f:
        f.write('#!/usr/bin/python\n')
        f.write('# -*- coding: utf-8 -*-\n')
        f.write('\n')
        f.write('class TestLib(object):\n')
        f.write('    pass\n')
    # Make the testlib.py file executable

# Generated at 2022-06-17 01:28:11.587716
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class PkgMgrTest(PkgMgr):
        def is_available(self):
            return True

        def list_installed(self):
            return ['package1', 'package2']

        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}

    pkgmgr = PkgMgrTest()
    packages = pkgmgr.get_packages()
    assert packages == {'package1': [{'name': 'package1', 'version': '1.0', 'source': 'pkgmgrtest'}],
                        'package2': [{'name': 'package2', 'version': '1.0', 'source': 'pkgmgrtest'}]}

# Generated at 2022-06-17 01:28:15.167321
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    assert CLIMgr().is_available() == False


# Generated at 2022-06-17 01:28:17.957784
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCLIMgr(CLIMgr):
        CLI = 'test_CLIMgr_is_available'
    test_CLIMgr = TestCLIMgr()
    assert test_CLIMgr.is_available() == False
    assert test_CLIMgr._cli == None


# Generated at 2022-06-17 01:28:22.180409
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.system.pkg_mgr.test_lib'

    pkg_mgr = TestLibMgr()
    assert pkg_mgr.is_available()


# Generated at 2022-06-17 01:28:24.450632
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.system.pkg_mgr.test_lib'
    assert TestLibMgr().is_available()


# Generated at 2022-06-17 01:28:27.863180
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    assert PkgMgr.list_installed() is None


# Generated at 2022-06-17 01:28:29.971946
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestLibMgr(LibMgr):
        LIB = 'test_lib'
    assert TestLibMgr().LIB == 'test_lib'


# Generated at 2022-06-17 01:28:31.071177
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    assert PkgMgr.is_available() == False


# Generated at 2022-06-17 01:28:39.660528
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.facts.system.pkg_mgr import CLIMgr
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgr
    from ansible.module_utils.facts.system.pkg_mgr import get_all_pkg_managers
    from ansible.module_utils.facts.system.pkg_mgr import get_all_subclasses
    from ansible.module_utils.facts.system.pkg_mgr import get_pkg_mgr
    from ansible.module_utils.facts.system.pkg_mgr import get_pkg_mgr_facts
    from ansible.module_utils.facts.system.pkg_mgr import get_pkg_mgr_facts_from_system


# Generated at 2022-06-17 01:28:44.681127
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.system.pkg_mgr.test_lib'
    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr.is_available() is True


# Generated at 2022-06-17 01:28:53.029248
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    class TestPkgMgr(PkgMgr):
        def list_installed(self):
            return ['package1', 'package2']

        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}

    test_pkg_mgr = TestPkgMgr()
    assert test_pkg_mgr.list_installed() == ['package1', 'package2']


# Generated at 2022-06-17 01:28:55.251142
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestLibMgr(LibMgr):
        LIB = 'test_lib'
    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr._lib is None


# Generated at 2022-06-17 01:28:57.893826
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    assert LibMgr().is_available() == False


# Generated at 2022-06-17 01:28:59.581284
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    assert PkgMgr.list_installed() is None


# Generated at 2022-06-17 01:29:03.481533
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    class PkgMgrTest(PkgMgr):
        def list_installed(self):
            return ['package1', 'package2']

        def get_package_details(self, package):
            return {'name': package}

    pkg_mgr = PkgMgrTest()
    assert pkg_mgr.list_installed() == ['package1', 'package2']


# Generated at 2022-06-17 01:29:12.929505
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True

        def list_installed(self):
            return ['package1', 'package2']

        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}

    pkg_mgr = TestPkgMgr()
    packages = pkg_mgr.get_packages()
    assert packages == {'package1': [{'name': 'package1', 'version': '1.0', 'source': 'testpkgmgr'}],
                        'package2': [{'name': 'package2', 'version': '1.0', 'source': 'testpkgmgr'}]}

# Generated at 2022-06-17 01:29:16.790231
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr().CLI is None


# Generated at 2022-06-17 01:29:17.498163
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    assert PkgMgr.list_installed() == NotImplemented


# Generated at 2022-06-17 01:29:27.844243
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['package1', 'package2']
        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}
    pkgmgr = TestPkgMgr()
    packages = pkgmgr.get_packages()
    assert packages == {'package1': [{'name': 'package1', 'version': '1.0', 'source': 'testpkgmgr'}],
                        'package2': [{'name': 'package2', 'version': '1.0', 'source': 'testpkgmgr'}]}


# Generated at 2022-06-17 01:29:29.746159
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestLibMgr(LibMgr):
        LIB = 'test_lib'
    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr._lib is None


# Generated at 2022-06-17 01:29:42.344281
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestLibMgr(LibMgr):
        LIB = 'testlib'

    tlm = TestLibMgr()
    assert tlm._lib is None


# Generated at 2022-06-17 01:29:47.387557
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['test_package']
        def get_package_details(self, package):
            return {'name': 'test_package', 'version': '1.0.0'}
    test_pkg_mgr = TestPkgMgr()
    assert test_pkg_mgr.get_package_details('test_package') == {'name': 'test_package', 'version': '1.0.0'}


# Generated at 2022-06-17 01:29:49.911608
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCLIMgr(CLIMgr):
        CLI = 'test_cli'
    test_cli_mgr = TestCLIMgr()
    assert test_cli_mgr.is_available() == False
    assert test_cli_mgr._cli == None


# Generated at 2022-06-17 01:29:51.711680
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr().CLI is None
    assert CLIMgr()._cli is None


# Generated at 2022-06-17 01:29:54.379009
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr().CLI is None


# Generated at 2022-06-17 01:29:55.505600
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr()

# Generated at 2022-06-17 01:29:57.673511
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestLibMgr(LibMgr):
        LIB = 'test_lib'
    assert TestLibMgr().LIB == 'test_lib'


# Generated at 2022-06-17 01:30:02.108291
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class TestPkgMgr(PkgMgr):
        def get_package_details(self, package):
            return {'name': 'test', 'version': '1.0'}
    pkg_mgr = TestPkgMgr()
    assert pkg_mgr.get_package_details('test') == {'name': 'test', 'version': '1.0'}


# Generated at 2022-06-17 01:30:09.093431
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class PkgMgrTest(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['package1', 'package2']
        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}
    pkg_mgr = PkgMgrTest()
    assert pkg_mgr.get_packages() == {'package1': [{'name': 'package1', 'version': '1.0', 'source': 'pkgmgrtest'}], 'package2': [{'name': 'package2', 'version': '1.0', 'source': 'pkgmgrtest'}]}

# Generated at 2022-06-17 01:30:15.648236
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class PkgMgrTest(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['package1', 'package2']
        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}
    pkg_mgr = PkgMgrTest()
    assert pkg_mgr.get_package_details('package1') == {'name': 'package1', 'version': '1.0'}
    assert pkg_mgr.get_package_details('package2') == {'name': 'package2', 'version': '1.0'}


# Generated at 2022-06-17 01:30:34.273498
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestLibMgr(LibMgr):
        LIB = 'test_lib'

    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr._lib is None


# Generated at 2022-06-17 01:30:39.521232
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCLIMgr(CLIMgr):
        CLI = 'test_cli'

    test_cli_mgr = TestCLIMgr()
    assert test_cli_mgr.is_available() == False


# Generated at 2022-06-17 01:30:46.327674
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['package1', 'package2']
        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}
    test_pkg_mgr = TestPkgMgr()
    assert test_pkg_mgr.get_packages() == {'package1': [{'name': 'package1', 'version': '1.0', 'source': 'testpkgmgr'}], 'package2': [{'name': 'package2', 'version': '1.0', 'source': 'testpkgmgr'}]}

# Generated at 2022-06-17 01:30:47.722524
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    assert False, "Test not implemented"


# Generated at 2022-06-17 01:30:53.898365
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True

        def list_installed(self):
            return ['package1', 'package2', 'package3']

        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}

    pkg_mgr = TestPkgMgr()
    packages = pkg_mgr.get_packages()

# Generated at 2022-06-17 01:30:59.951460
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.system.distribution'
    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr.is_available()


# Generated at 2022-06-17 01:31:02.908935
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    assert len(get_all_pkg_managers()) > 0

# Generated at 2022-06-17 01:31:13.190532
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True

        def list_installed(self):
            return ['package1', 'package2']

        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}

    pkg_mgr = TestPkgMgr()
    packages = pkg_mgr.get_packages()
    assert packages == {'package1': [{'name': 'package1', 'version': '1.0', 'source': 'testpkgmgr'}],
                        'package2': [{'name': 'package2', 'version': '1.0', 'source': 'testpkgmgr'}]}

# Generated at 2022-06-17 01:31:14.722714
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr()._cli is None


# Generated at 2022-06-17 01:31:18.623890
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCLIMgr(CLIMgr):
        CLI = 'test_cli'
    test_mgr = TestCLIMgr()
    assert test_mgr.is_available() == False
    test_mgr._cli = 'test_cli'
    assert test_mgr.is_available() == True

# Generated at 2022-06-17 01:32:05.242988
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr().is_available() == False
    assert CLIMgr()._cli == None


# Generated at 2022-06-17 01:32:08.219571
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.system.pkg_mgr.test_lib'
    assert TestLibMgr().is_available()


# Generated at 2022-06-17 01:32:09.928526
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    assert PkgMgr.is_available() == False


# Generated at 2022-06-17 01:32:11.688914
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    assert CLIMgr().is_available() == False


# Generated at 2022-06-17 01:32:14.593913
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestLibMgr(LibMgr):
        LIB = 'test_lib'

    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr._lib is None


# Generated at 2022-06-17 01:32:19.938713
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.system.pkg_mgr.test_lib'

    assert TestLibMgr().is_available() == True


# Generated at 2022-06-17 01:32:26.131551
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def list_installed(self):
            return ['test_package']

        def get_package_details(self, package):
            return {'name': 'test_package', 'version': '1.0'}

    pkg_mgr = TestPkgMgr()
    assert pkg_mgr.get_packages() == {'test_package': [{'name': 'test_package', 'version': '1.0', 'source': 'testpkgmgr'}]}

# Generated at 2022-06-17 01:32:33.082281
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    import sys
    import os
    import tempfile
    import shutil
    import importlib

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary python module
    module_name = 'test_module'
    module_path = os.path.join(tmpdir, module_name + '.py')
    with open(module_path, 'w') as f:
        f.write('#!/usr/bin/python\n')
        f.write('# -*- coding: utf-8 -*-\n')
        f.write('\n')
        f.write('def test_function():\n')
        f.write('    pass\n')

    # Add the temporary directory to the python path
    sys.path.append(tmpdir)

    # Import the temporary module


# Generated at 2022-06-17 01:32:34.271277
# Unit test for constructor of class LibMgr
def test_LibMgr():
    assert LibMgr() is not None


# Generated at 2022-06-17 01:32:43.210093
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['package1', 'package2']
        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}
    test_pkg_mgr = TestPkgMgr()
    assert test_pkg_mgr.get_packages() == {'package1': [{'name': 'package1', 'version': '1.0', 'source': 'testpkgmgr'}],
                                          'package2': [{'name': 'package2', 'version': '1.0', 'source': 'testpkgmgr'}]}

# Generated at 2022-06-17 01:34:20.557282
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def list_installed(self):
            return ['package1', 'package2']

        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}

    test_pkg_mgr = TestPkgMgr()
    assert test_pkg_mgr.get_packages() == {'package1': [{'name': 'package1', 'version': '1.0', 'source': 'testpkgmgr'}],
                                          'package2': [{'name': 'package2', 'version': '1.0', 'source': 'testpkgmgr'}]}

# Generated at 2022-06-17 01:34:27.767074
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['test_package']
        def get_package_details(self, package):
            return {'name': 'test_package', 'version': '1.0'}
    test_pkg_mgr = TestPkgMgr()
    assert test_pkg_mgr.get_package_details('test_package') == {'name': 'test_package', 'version': '1.0'}
