

# Generated at 2022-06-17 01:24:35.500671
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCLIMgr(CLIMgr):
        CLI = 'test_CLIMgr_is_available'
    test_CLIMgr = TestCLIMgr()
    assert not test_CLIMgr.is_available()


# Generated at 2022-06-17 01:24:37.197005
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    assert PkgMgr.is_available() == False


# Generated at 2022-06-17 01:24:42.961018
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCLIMgr(CLIMgr):
        CLI = 'test_cli'

    test_mgr = TestCLIMgr()
    assert test_mgr.is_available() == False

    test_mgr._cli = 'test_cli'
    assert test_mgr.is_available() == True


# Generated at 2022-06-17 01:24:47.224947
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['package1', 'package2']
        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}
    test_pkg_mgr = TestPkgMgr()
    assert test_pkg_mgr.get_packages() == {'package1': [{'name': 'package1', 'version': '1.0', 'source': 'testpkgmgr'}],
                                          'package2': [{'name': 'package2', 'version': '1.0', 'source': 'testpkgmgr'}]}

# Generated at 2022-06-17 01:24:48.850936
# Unit test for constructor of class LibMgr
def test_LibMgr():
    libmgr = LibMgr()
    assert libmgr._lib is None


# Generated at 2022-06-17 01:24:49.378531
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr()

# Generated at 2022-06-17 01:24:55.911952
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.facts.system.pkg_mgr import CLIMgr
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgr
    from ansible.module_utils.facts.system.pkg_mgr import get_all_pkg_managers
    from ansible.module_utils.facts.system.pkg_mgr import get_all_subclasses
    from ansible.module_utils.facts.system.pkg_mgr import get_pkg_mgr
    from ansible.module_utils.facts.system.pkg_mgr import get_pkg_mgr_facts
    from ansible.module_utils.facts.system.pkg_mgr import get_pkg_mgr_facts_from_system


# Generated at 2022-06-17 01:25:03.355235
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True

        def list_installed(self):
            return ['package1', 'package2']

        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}

    test_pkg_mgr = TestPkgMgr()
    packages = test_pkg_mgr.get_packages()
    assert packages == {'package1': [{'name': 'package1', 'version': '1.0', 'source': 'testpkgmgr'}],
                        'package2': [{'name': 'package2', 'version': '1.0', 'source': 'testpkgmgr'}]}

# Generated at 2022-06-17 01:25:11.130731
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.system.pkg_mgr.test_lib'

    pkg_mgr = TestLibMgr()
    assert pkg_mgr.is_available()
    assert pkg_mgr._lib.__name__ == 'ansible.module_utils.facts.system.pkg_mgr.test_lib'


# Generated at 2022-06-17 01:25:17.624637
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['package1', 'package2']
        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}
    pkg_mgr = TestPkgMgr()
    assert pkg_mgr.get_packages() == {'package1': [{'name': 'package1', 'version': '1.0', 'source': 'testpkgmgr'}],
                                     'package2': [{'name': 'package2', 'version': '1.0', 'source': 'testpkgmgr'}]}

# Generated at 2022-06-17 01:25:23.882488
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr()

# Generated at 2022-06-17 01:25:34.442734
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    import unittest
    class TestPkgMgr(PkgMgr):
        def list_installed(self):
            return ['test_package']
        def get_package_details(self, package):
            return {'name': 'test_package', 'version': '1.0.0'}
    test_pkg_mgr = TestPkgMgr()
    test_pkg_mgr.is_available = lambda: True
    class TestPkgMgrTestCase(unittest.TestCase):
        def test_get_package_details(self):
            self.assertEqual(test_pkg_mgr.get_package_details('test_package'), {'name': 'test_package', 'version': '1.0.0'})
    unittest.main()


# Generated at 2022-06-17 01:25:41.292392
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['a', 'b', 'c']
        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}
    pkg_mgr = TestPkgMgr()
    packages = pkg_mgr.get_packages()

# Generated at 2022-06-17 01:25:49.235060
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['test_package']
        def get_package_details(self, package):
            return {'name': 'test_package', 'version': '1.0'}
    pkgmgr = TestPkgMgr()
    assert pkgmgr.get_package_details('test_package') == {'name': 'test_package', 'version': '1.0'}


# Generated at 2022-06-17 01:25:51.173655
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    cli = CLIMgr()
    assert cli._cli is None


# Generated at 2022-06-17 01:25:55.175436
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr().is_available() is False


# Generated at 2022-06-17 01:25:56.860837
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    assert PkgMgr.is_available() == False


# Generated at 2022-06-17 01:25:58.237254
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr()._cli is None


# Generated at 2022-06-17 01:26:01.478514
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    cli_mgr = CLIMgr()
    assert cli_mgr._cli is None


# Generated at 2022-06-17 01:26:11.074149
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            pass
        def list_installed(self):
            pass
        def get_package_details(self, package):
            return {'name': 'test_package', 'version': '1.0.0'}
    test_pkg_mgr = TestPkgMgr()
    assert test_pkg_mgr.get_package_details('test_package') == {'name': 'test_package', 'version': '1.0.0'}


# Generated at 2022-06-17 01:26:27.794312
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class PkgMgrTest(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['package1', 'package2']
        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}
    pkg_mgr = PkgMgrTest()
    assert pkg_mgr.get_package_details('package1') == {'name': 'package1', 'version': '1.0'}


# Generated at 2022-06-17 01:26:33.499973
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['package1', 'package2']
        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}
    pkg_mgr = TestPkgMgr()
    assert pkg_mgr.list_installed() == ['package1', 'package2']


# Generated at 2022-06-17 01:26:36.068096
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.system.pkg_mgr.test_lib'

    assert TestLibMgr().is_available() is True


# Generated at 2022-06-17 01:26:37.159727
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    assert PkgMgr.is_available() == False


# Generated at 2022-06-17 01:26:40.235020
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCLIMgr(CLIMgr):
        CLI = 'test_cli'

    test_mgr = TestCLIMgr()
    assert test_mgr.is_available() == False

    test_mgr._cli = 'test_cli'
    assert test_mgr.is_available() == True


# Generated at 2022-06-17 01:26:46.864153
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.system.distribution'

    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr.is_available()


# Generated at 2022-06-17 01:26:48.029180
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    assert PkgMgr.is_available() == False


# Generated at 2022-06-17 01:26:58.292760
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['package1', 'package2', 'package3']
        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}
    test_pkg_mgr = TestPkgMgr()

# Generated at 2022-06-17 01:27:11.086865
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True

        def list_installed(self):
            return ['package1', 'package2']

        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}

    pkg_mgr = TestPkgMgr()
    packages = pkg_mgr.get_packages()
    assert packages == {'package1': [{'name': 'package1', 'version': '1.0', 'source': 'testpkgmgr'}],
                        'package2': [{'name': 'package2', 'version': '1.0', 'source': 'testpkgmgr'}]}

# Generated at 2022-06-17 01:27:19.372542
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def list_installed(self):
            return ['package1', 'package2']

        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}

    pkg_mgr = TestPkgMgr()
    packages = pkg_mgr.get_packages()
    assert packages == {'package1': [{'name': 'package1', 'version': '1.0', 'source': 'testpkgmgr'}],
                        'package2': [{'name': 'package2', 'version': '1.0', 'source': 'testpkgmgr'}]}

# Generated at 2022-06-17 01:27:37.877285
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    assert PkgMgr.list_installed() == NotImplemented


# Generated at 2022-06-17 01:27:38.880581
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    class TestCLIMgr(CLIMgr):
        CLI = 'test'

    assert TestCLIMgr().is_available() == False


# Generated at 2022-06-17 01:27:49.202426
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.facts.system.pkg_mgr import CLIMgr
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgr
    from ansible.module_utils.facts.system.pkg_mgr import get_all_pkg_managers
    from ansible.module_utils.facts.system.pkg_mgr import get_all_subclasses
    from ansible.module_utils.facts.system.pkg_mgr import get_pkg_mgr
    from ansible.module_utils.facts.system.pkg_mgr import get_pkg_mgr_from_system
    from ansible.module_utils.facts.system.pkg_mgr import get_pkg_mgr_from_system_

# Generated at 2022-06-17 01:27:54.826683
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class PkgMgrTest(PkgMgr):
        def is_available(self):
            return True

        def list_installed(self):
            return ['test_package']

        def get_package_details(self, package):
            return {'name': 'test_package', 'version': '1.0.0'}

    pkg_mgr = PkgMgrTest()
    assert pkg_mgr.get_package_details('test_package') == {'name': 'test_package', 'version': '1.0.0'}


# Generated at 2022-06-17 01:27:57.818386
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.system.pkg_mgr.test_lib'

    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr.is_available() is True


# Generated at 2022-06-17 01:28:02.956384
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.system.pkg_mgr.test_lib'

    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr.is_available() == True


# Generated at 2022-06-17 01:28:06.258118
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.system.pkg_mgr.test_lib'

    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr.is_available()


# Generated at 2022-06-17 01:28:09.304872
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestLibMgr(LibMgr):
        LIB = 'test_lib'

    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr._lib is None


# Generated at 2022-06-17 01:28:13.458580
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    class TestCLIMgr(CLIMgr):
        CLI = 'test_cli'
    test_mgr = TestCLIMgr()
    assert test_mgr._cli is None


# Generated at 2022-06-17 01:28:19.516972
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True

        def list_installed(self):
            return ['package1', 'package2']

        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}

    pkg_mgr = TestPkgMgr()
    assert pkg_mgr.get_packages() == {'package1': [{'name': 'package1', 'version': '1.0', 'source': 'testpkgmgr'}],
                                     'package2': [{'name': 'package2', 'version': '1.0', 'source': 'testpkgmgr'}]}

# Generated at 2022-06-17 01:28:59.556936
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.collector.pkg_mgrs.test_lib'
    tlm = TestLibMgr()
    assert tlm.is_available()


# Generated at 2022-06-17 01:29:05.086927
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    class TestPkgMgr(PkgMgr):
        def list_installed(self):
            return ['test']
    pkg_mgr = TestPkgMgr()
    assert pkg_mgr.list_installed() == ['test']


# Generated at 2022-06-17 01:29:11.904576
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class PkgMgrTest(PkgMgr):
        def is_available(self):
            pass
        def list_installed(self):
            pass
        def get_package_details(self, package):
            return {'name': 'test', 'version': '1.0'}
    pkg_mgr = PkgMgrTest()
    assert pkg_mgr.get_package_details('test') == {'name': 'test', 'version': '1.0'}


# Generated at 2022-06-17 01:29:20.491887
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True

        def list_installed(self):
            return ['package1', 'package2']

        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}

    test_pkg_mgr = TestPkgMgr()
    packages = test_pkg_mgr.get_packages()
    assert packages == {'package1': [{'name': 'package1', 'version': '1.0', 'source': 'testpkgmgr'}],
                        'package2': [{'name': 'package2', 'version': '1.0', 'source': 'testpkgmgr'}]}

# Generated at 2022-06-17 01:29:22.465890
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    assert PkgMgr.is_available() == NotImplemented


# Generated at 2022-06-17 01:29:29.395299
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.facts.system.pkg_mgr import CLIMgr
    import os

    class TestCLIMgr(CLIMgr):
        CLI = 'test_cli'

    test_cli = TestCLIMgr()
    assert test_cli.is_available() == False

    os.environ['PATH'] = os.pathsep.join(['/bin', os.environ['PATH']])
    assert test_cli.is_available() == False

    os.environ['PATH'] = os.pathsep.join(['/usr/bin', os.environ['PATH']])
    assert test_cli.is_available() == False


# Generated at 2022-06-17 01:29:31.577684
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    cli_mgr = CLIMgr()
    assert cli_mgr._cli is None


# Generated at 2022-06-17 01:29:39.316188
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['test_package']
        def get_package_details(self, package):
            return {'name': 'test_package', 'version': '1.0.0'}
    pkg_mgr = TestPkgMgr()
    assert pkg_mgr.get_package_details('test_package') == {'name': 'test_package', 'version': '1.0.0'}


# Generated at 2022-06-17 01:29:43.658425
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCLIMgr(CLIMgr):
        CLI = 'test_CLIMgr_is_available'
    test_CLIMgr = TestCLIMgr()
    assert test_CLIMgr.is_available() == False
    assert test_CLIMgr._cli == None


# Generated at 2022-06-17 01:29:44.714520
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    assert PkgMgr.is_available() == False


# Generated at 2022-06-17 01:31:06.865104
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.system.distribution'

    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr.is_available()


# Generated at 2022-06-17 01:31:08.804932
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    assert PkgMgr.is_available() == False


# Generated at 2022-06-17 01:31:11.826982
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestLibMgr(LibMgr):
        LIB = 'test_lib'
    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr._lib is None


# Generated at 2022-06-17 01:31:17.260959
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    import sys
    class TestLibMgr(LibMgr):
        LIB = 'sys'
    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr.is_available() == True
    assert test_lib_mgr._lib == sys


# Generated at 2022-06-17 01:31:21.597881
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class PkgMgrTest(PkgMgr):
        def list_installed(self):
            return ['package1', 'package2']
        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}
    pkg_mgr = PkgMgrTest()
    assert pkg_mgr.get_packages() == {'package1': [{'name': 'package1', 'version': '1.0', 'source': 'pkgmgrtest'}],
                                     'package2': [{'name': 'package2', 'version': '1.0', 'source': 'pkgmgrtest'}]}

# Generated at 2022-06-17 01:31:22.516066
# Unit test for constructor of class LibMgr
def test_LibMgr():
    libmgr = LibMgr()
    assert libmgr._lib is None


# Generated at 2022-06-17 01:31:23.987546
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    assert PkgMgr.is_available() == NotImplemented


# Generated at 2022-06-17 01:31:27.004577
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    mgr = CLIMgr()
    assert mgr._cli is None


# Generated at 2022-06-17 01:31:28.815659
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestLibMgr(LibMgr):
        LIB = 'test_lib'
    assert TestLibMgr().LIB == 'test_lib'


# Generated at 2022-06-17 01:31:34.780255
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    class TestCLIMgr(CLIMgr):
        CLI = 'test'
    assert TestCLIMgr().is_available() == False
    assert TestCLIMgr()._cli == None
