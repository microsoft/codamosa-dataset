

# Generated at 2022-06-17 01:24:38.496166
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCLIMgr(CLIMgr):
        CLI = 'test_cli'
    test_cli_mgr = TestCLIMgr()
    assert test_cli_mgr.is_available() == False
    test_cli_mgr._cli = 'test_cli'
    assert test_cli_mgr.is_available() == True

# Generated at 2022-06-17 01:24:42.274604
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestLibMgr(LibMgr):
        LIB = 'testlib'

    lm = TestLibMgr()
    assert lm._lib is None


# Generated at 2022-06-17 01:24:45.894865
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.packages.test_lib'

    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr.is_available()


# Generated at 2022-06-17 01:24:47.467916
# Unit test for constructor of class LibMgr
def test_LibMgr():
    libmgr = LibMgr()
    assert libmgr._lib is None


# Generated at 2022-06-17 01:24:51.232653
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class PkgMgrTest(PkgMgr):
        def list_installed(self):
            return ['package1', 'package2']

        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}

    pkg_mgr = PkgMgrTest()
    packages = pkg_mgr.get_packages()
    assert packages == {'package1': [{'name': 'package1', 'version': '1.0', 'source': 'pkgmgrtest'}],
                        'package2': [{'name': 'package2', 'version': '1.0', 'source': 'pkgmgrtest'}]}

# Generated at 2022-06-17 01:25:01.685799
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['package1', 'package2']
        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}
    tpm = TestPkgMgr()
    assert tpm.get_packages() == {'package1': [{'name': 'package1', 'version': '1.0', 'source': 'testpkgmgr'}],
                                  'package2': [{'name': 'package2', 'version': '1.0', 'source': 'testpkgmgr'}]}

# Generated at 2022-06-17 01:25:07.598697
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCLIMgr(CLIMgr):
        CLI = 'test_cli'
    test_cli_mgr = TestCLIMgr()
    assert test_cli_mgr.is_available() == False
    assert test_cli_mgr._cli == None


# Generated at 2022-06-17 01:25:13.762530
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.packages.test_lib_mgr'

    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr.is_available()


# Generated at 2022-06-17 01:25:19.719551
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class PkgMgrTest(PkgMgr):
        def __init__(self):
            super(PkgMgrTest, self).__init__()

        def is_available(self):
            return True

        def list_installed(self):
            return ['package1', 'package2']

        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}

    pkg_mgr = PkgMgrTest()
    assert pkg_mgr.get_packages() == {'package1': [{'name': 'package1', 'version': '1.0', 'source': 'pkgmgrtest'}],
                                     'package2': [{'name': 'package2', 'version': '1.0', 'source': 'pkgmgrtest'}]}

# Generated at 2022-06-17 01:25:20.719046
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    assert PkgMgr.is_available() == False


# Generated at 2022-06-17 01:25:28.092577
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    class TestCLIMgr(CLIMgr):
        CLI = 'test'
    assert TestCLIMgr().is_available() == False


# Generated at 2022-06-17 01:25:29.032866
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    assert False, "Test not implemented"

# Generated at 2022-06-17 01:25:31.526476
# Unit test for constructor of class LibMgr
def test_LibMgr():
    lib_mgr = LibMgr()
    assert lib_mgr._lib is None


# Generated at 2022-06-17 01:25:39.204009
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True

        def list_installed(self):
            return ['package1', 'package2']

        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}

    pkg_mgr = TestPkgMgr()
    assert pkg_mgr.get_packages() == {'package1': [{'name': 'package1', 'version': '1.0', 'source': 'testpkgmgr'}],
                                     'package2': [{'name': 'package2', 'version': '1.0', 'source': 'testpkgmgr'}]}

# Generated at 2022-06-17 01:25:45.713647
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['package1', 'package2']
        def get_package_details(self, package):
            if package == 'package1':
                return {'name': 'package1', 'version': '1.0.0', 'source': 'test'}
            elif package == 'package2':
                return {'name': 'package2', 'version': '2.0.0', 'source': 'test'}
    pkg_mgr = TestPkgMgr()
    packages = pkg_mgr.get_packages()
    assert packages['package1'][0]['name'] == 'package1'

# Generated at 2022-06-17 01:25:50.650069
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.system.pkg_mgr.test_lib'

    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr.is_available()


# Generated at 2022-06-17 01:25:55.500391
# Unit test for constructor of class LibMgr
def test_LibMgr():
    libmgr = LibMgr()
    assert libmgr._lib is None


# Generated at 2022-06-17 01:25:57.140661
# Unit test for constructor of class LibMgr
def test_LibMgr():
    assert LibMgr()._lib is None


# Generated at 2022-06-17 01:25:59.297574
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestLibMgr(LibMgr):
        LIB = 'test_lib'
    assert TestLibMgr().LIB == 'test_lib'


# Generated at 2022-06-17 01:26:02.179442
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr()._cli is None


# Generated at 2022-06-17 01:26:12.065256
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCLIMgr(CLIMgr):
        CLI = 'test_CLIMgr_is_available'
    test_CLIMgr = TestCLIMgr()
    assert test_CLIMgr.is_available() == False
    assert test_CLIMgr._cli == None


# Generated at 2022-06-17 01:26:23.484272
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.facts.system.pkg_mgr import get_all_pkg_managers
    from ansible.module_utils.facts.system.pkg_mgr.apt import AptMgr
    from ansible.module_utils.facts.system.pkg_mgr.yum import YumMgr
    from ansible.module_utils.facts.system.pkg_mgr.zypper import ZypperMgr
    from ansible.module_utils.facts.system.pkg_mgr.pacman import PacmanMgr
    from ansible.module_utils.facts.system.pkg_mgr.apk import ApkMgr
    from ansible.module_utils.facts.system.pkg_mgr.pkg5 import Pkg5

# Generated at 2022-06-17 01:26:25.102433
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    libmgr = LibMgr()
    assert libmgr.is_available() == False


# Generated at 2022-06-17 01:26:34.133942
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    import os
    import sys
    import tempfile
    import shutil
    import importlib

    class TestLibMgr(LibMgr):
        LIB = 'testlib'

    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr.is_available() == False

    # Create a temporary directory
    tmp_dir = tempfile.mkdtemp()
    # Create a temporary file in the temporary directory
    tmp_file = tempfile.NamedTemporaryFile(dir=tmp_dir, delete=False)
    # Write some data to the temporary file
    tmp_file.write(b'import sys\n')
    tmp_file.write(b'import os\n')
    tmp_file.write(b'import json\n')
    tmp_file.write(b'import re\n')


# Generated at 2022-06-17 01:26:39.116388
# Unit test for constructor of class LibMgr
def test_LibMgr():
    libmgr = LibMgr()
    assert libmgr._lib is None


# Generated at 2022-06-17 01:26:40.151391
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    assert PkgMgr.is_available() == False


# Generated at 2022-06-17 01:26:50.921207
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['package1', 'package2']
        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}
    test_pkg_mgr = TestPkgMgr()
    assert test_pkg_mgr.get_packages() == {'package1': [{'name': 'package1', 'version': '1.0', 'source': 'testpkgmgr'}],
                                          'package2': [{'name': 'package2', 'version': '1.0', 'source': 'testpkgmgr'}]}

# Generated at 2022-06-17 01:26:56.375734
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.system.pkg_mgr.test_lib'
    assert TestLibMgr().is_available()


# Generated at 2022-06-17 01:26:57.796668
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    libmgr = LibMgr()
    assert libmgr.is_available() == False


# Generated at 2022-06-17 01:27:01.308425
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCLIMgr(CLIMgr):
        CLI = 'test_cli'

    test_mgr = TestCLIMgr()
    assert test_mgr.is_available() == False

    test_mgr._cli = 'test_cli'
    assert test_mgr.is_available() == True


# Generated at 2022-06-17 01:27:12.480888
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    assert PkgMgr.is_available() == False


# Generated at 2022-06-17 01:27:14.591139
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.common.process'

    assert TestLibMgr().is_available() == True


# Generated at 2022-06-17 01:27:19.040770
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.system.pkg_mgr.test_lib'

    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr.is_available() == True


# Generated at 2022-06-17 01:27:26.334515
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['package1', 'package2']
        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}
    pkg_mgr = TestPkgMgr()
    assert pkg_mgr.get_packages() == {'package1': [{'name': 'package1', 'version': '1.0', 'source': 'testpkgmgr'}],
                                     'package2': [{'name': 'package2', 'version': '1.0', 'source': 'testpkgmgr'}]}

# Generated at 2022-06-17 01:27:27.474726
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr()._cli is None


# Generated at 2022-06-17 01:27:28.007988
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pass

# Generated at 2022-06-17 01:27:32.314745
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.system.pkg_mgr.test_lib'

    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr.is_available()


# Generated at 2022-06-17 01:27:36.576589
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.system.distribution'

    assert TestLibMgr().is_available()


# Generated at 2022-06-17 01:27:38.384192
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pkg_mgr = PkgMgr()
    assert pkg_mgr.is_available() == NotImplemented


# Generated at 2022-06-17 01:27:40.323741
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    class PkgMgrTest(PkgMgr):
        def list_installed(self):
            return ['test']
    pkg_mgr = PkgMgrTest()
    assert pkg_mgr.list_installed() == ['test']


# Generated at 2022-06-17 01:27:58.665075
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr().CLI is None


# Generated at 2022-06-17 01:28:03.314064
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    pkg_mgr = PkgMgr()
    assert pkg_mgr.get_package_details("test") == None

# Generated at 2022-06-17 01:28:07.917773
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True

    test_pkg_mgr = TestPkgMgr()
    assert test_pkg_mgr.is_available() == True


# Generated at 2022-06-17 01:28:18.770740
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True

        def list_installed(self):
            return ['a', 'b', 'c']

        def get_package_details(self, package):
            return {'name': package, 'version': '1.0.0'}

    pkg_mgr = TestPkgMgr()

# Generated at 2022-06-17 01:28:24.033647
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.system.pkg_mgr.test_lib'

    pkg_mgr = TestLibMgr()
    assert pkg_mgr.is_available()
    assert pkg_mgr._lib.__name__ == 'ansible.module_utils.facts.system.pkg_mgr.test_lib'


# Generated at 2022-06-17 01:28:27.135212
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr()

# Generated at 2022-06-17 01:28:29.217930
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestLibMgr(LibMgr):
        LIB = 'test_lib'

    tlm = TestLibMgr()
    assert tlm._lib is None


# Generated at 2022-06-17 01:28:30.399799
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr().CLI is None


# Generated at 2022-06-17 01:28:37.893845
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['package1', 'package2']
        def get_package_details(self, package):
            return {'name': package, 'version': '1.0.0'}
    pkg_mgr = TestPkgMgr()
    packages = pkg_mgr.get_packages()
    assert packages == {'package1': [{'name': 'package1', 'version': '1.0.0', 'source': 'testpkgmgr'}],
                        'package2': [{'name': 'package2', 'version': '1.0.0', 'source': 'testpkgmgr'}]}

# Generated at 2022-06-17 01:28:42.232207
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr().CLI == None


# Generated at 2022-06-17 01:29:18.648140
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    class TestPkgMgr(PkgMgr):
        def list_installed(self):
            return ['foo', 'bar']

    test_pkg_mgr = TestPkgMgr()
    assert test_pkg_mgr.list_installed() == ['foo', 'bar']


# Generated at 2022-06-17 01:29:27.951131
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['package1', 'package2']
        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}
    test_pkg_mgr = TestPkgMgr()
    packages = test_pkg_mgr.get_packages()
    assert packages == {'package1': [{'name': 'package1', 'version': '1.0', 'source': 'testpkgmgr'}],
                        'package2': [{'name': 'package2', 'version': '1.0', 'source': 'testpkgmgr'}]}

# Generated at 2022-06-17 01:29:28.849921
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    assert PkgMgr.list_installed() is None


# Generated at 2022-06-17 01:29:39.315778
# Unit test for method is_available of class PkgMgr

# Generated at 2022-06-17 01:29:42.685536
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestLibMgr(LibMgr):
        LIB = 'test_lib'
    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr._lib is None


# Generated at 2022-06-17 01:29:44.959714
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestLibMgr(LibMgr):
        LIB = 'test_lib'

    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr._lib is None


# Generated at 2022-06-17 01:29:48.287691
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class LibMgrTest(LibMgr):
        LIB = 'ansible.module_utils.facts.system.pkg_mgr.LibMgr'

    assert LibMgrTest().is_available() is True


# Generated at 2022-06-17 01:29:51.123238
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCLIMgr(CLIMgr):
        CLI = 'test_cli'

    test_cli_mgr = TestCLIMgr()
    assert test_cli_mgr.is_available() == False


# Generated at 2022-06-17 01:29:53.807577
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    assert LibMgr().is_available() == False


# Generated at 2022-06-17 01:29:56.964400
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'os'

    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr.is_available()


# Generated at 2022-06-17 01:31:08.302902
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    assert PkgMgr.list_installed() == NotImplementedError


# Generated at 2022-06-17 01:31:10.321989
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    assert PkgMgr.is_available() == False


# Generated at 2022-06-17 01:31:20.687271
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    pkg_managers = get_all_pkg_managers()
    assert 'apt' in pkg_managers
    assert 'yum' in pkg_managers
    assert 'dnf' in pkg_managers
    assert 'zypper' in pkg_managers
    assert 'pacman' in pkg_managers
    assert 'apk' in pkg_managers
    assert 'portage' in pkg_managers
    assert 'pkgng' in pkg_managers
    assert 'pkg5' in pkg_managers
    assert 'pkg' in pkg_managers
    assert 'pkgin' in pkg_managers
    assert 'pkgutil' in pkg_managers
    assert 'pkg_info' in pkg_managers
    assert 'pkg_info_installed' in pkg_

# Generated at 2022-06-17 01:31:22.966239
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    assert PkgMgr.list_installed() is None


# Generated at 2022-06-17 01:31:26.953837
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    assert PkgMgr.is_available() is None


# Generated at 2022-06-17 01:31:28.755283
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestLibMgr(LibMgr):
        LIB = 'test_lib'
    assert TestLibMgr().LIB == 'test_lib'


# Generated at 2022-06-17 01:31:40.136810
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    pkg_managers = get_all_pkg_managers()
    assert 'apt' in pkg_managers
    assert 'dnf' in pkg_managers
    assert 'yum' in pkg_managers
    assert 'pacman' in pkg_managers
    assert 'zypper' in pkg_managers
    assert 'portage' in pkg_managers
    assert 'apk' in pkg_managers
    assert 'pkgng' in pkg_managers
    assert 'pkg5' in pkg_managers
    assert 'pkgutil' in pkg_managers
    assert 'pkg' in pkg_managers
    assert 'pkg_info' in pkg_managers
    assert 'pkgin' in pkg_managers
    assert 'pkg_info' in pkg_managers

# Generated at 2022-06-17 01:31:46.690860
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['test_package']
        def get_package_details(self, package):
            return {'name': 'test_package', 'version': '1.0.0'}
    test_pkg_mgr = TestPkgMgr()
    assert test_pkg_mgr.get_package_details('test_package') == {'name': 'test_package', 'version': '1.0.0'}


# Generated at 2022-06-17 01:31:53.984121
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class PkgMgrTest(PkgMgr):
        def is_available(self):
            pass
        def list_installed(self):
            pass
        def get_package_details(self, package):
            return {'name': 'test', 'version': '1.0'}
    pkg_mgr = PkgMgrTest()
    assert pkg_mgr.get_package_details('test') == {'name': 'test', 'version': '1.0'}


# Generated at 2022-06-17 01:31:56.590094
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    assert PkgMgr.is_available() == False
