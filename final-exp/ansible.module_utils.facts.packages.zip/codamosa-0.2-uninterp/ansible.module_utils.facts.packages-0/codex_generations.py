

# Generated at 2022-06-17 01:24:33.812812
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pkg_mgr = PkgMgr()
    assert pkg_mgr.is_available() == NotImplemented

# Generated at 2022-06-17 01:24:36.790957
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCLIMgr(CLIMgr):
        CLI = 'test'
    test_cli_mgr = TestCLIMgr()
    assert test_cli_mgr.is_available() == False


# Generated at 2022-06-17 01:24:39.361149
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestLibMgr(LibMgr):
        LIB = 'test_lib'

    libmgr = TestLibMgr()
    assert libmgr._lib is None


# Generated at 2022-06-17 01:24:48.854387
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['package1', 'package2']
        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}
    pkg_mgr = TestPkgMgr()
    assert pkg_mgr.get_packages() == {'package1': [{'name': 'package1', 'version': '1.0', 'source': 'testpkgmgr'}],
                                     'package2': [{'name': 'package2', 'version': '1.0', 'source': 'testpkgmgr'}]}

# Generated at 2022-06-17 01:24:51.177402
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.packages.test_lib'

    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr.is_available() == True


# Generated at 2022-06-17 01:25:01.920363
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['package1', 'package2']
        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}
    pkg_mgr = TestPkgMgr()
    packages = pkg_mgr.get_packages()
    assert packages == {'package1': [{'name': 'package1', 'version': '1.0', 'source': 'testpkgmgr'}],
                        'package2': [{'name': 'package2', 'version': '1.0', 'source': 'testpkgmgr'}]}

# Generated at 2022-06-17 01:25:04.023232
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr().CLI is None


# Generated at 2022-06-17 01:25:08.611447
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCLIMgr(CLIMgr):
        CLI = 'test_cli'
    test_cli = TestCLIMgr()
    assert test_cli.is_available() == False


# Generated at 2022-06-17 01:25:14.424250
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    class PkgMgrTest(PkgMgr):
        def list_installed(self):
            return ['package1', 'package2']
    pkg_mgr = PkgMgrTest()
    assert pkg_mgr.list_installed() == ['package1', 'package2']


# Generated at 2022-06-17 01:25:15.952473
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr().CLI is None


# Generated at 2022-06-17 01:25:22.652274
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCLIMgr(CLIMgr):
        CLI = 'test_cli'
    test_cli_mgr = TestCLIMgr()
    assert test_cli_mgr.is_available() == False


# Generated at 2022-06-17 01:25:24.474247
# Unit test for constructor of class LibMgr
def test_LibMgr():
    assert LibMgr()


# Generated at 2022-06-17 01:25:27.938083
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    assert PkgMgr.get_package_details(PkgMgr, "package") == NotImplemented


# Generated at 2022-06-17 01:25:31.805347
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCLIMgr(CLIMgr):
        CLI = 'test_cli'

    test_cli_mgr = TestCLIMgr()
    assert test_cli_mgr.is_available() == False


# Generated at 2022-06-17 01:25:32.343722
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr()

# Generated at 2022-06-17 01:25:34.762733
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr()._cli is None


# Generated at 2022-06-17 01:25:39.618492
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCLIMgr(CLIMgr):
        CLI = 'test_CLIMgr_is_available'

    test_CLIMgr = TestCLIMgr()
    assert test_CLIMgr.is_available() == False


# Generated at 2022-06-17 01:25:41.291358
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestLibMgr(LibMgr):
        LIB = 'test_lib'
    assert TestLibMgr().LIB == 'test_lib'


# Generated at 2022-06-17 01:25:49.627769
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['test_package']
        def get_package_details(self, package):
            return {'name': 'test_package', 'version': '1.0.0'}

    test_pkg_mgr = TestPkgMgr()
    assert test_pkg_mgr.get_package_details('test_package') == {'name': 'test_package', 'version': '1.0.0'}


# Generated at 2022-06-17 01:25:53.495740
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.packages.test_lib'

    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr.is_available()


# Generated at 2022-06-17 01:25:58.161910
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr()

# Generated at 2022-06-17 01:26:03.854759
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.system.distribution'

    lm = TestLibMgr()
    assert lm.is_available()


# Generated at 2022-06-17 01:26:05.885281
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr().CLI is None


# Generated at 2022-06-17 01:26:07.586062
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.system.pkg_mgr.test_lib'

    mgr = TestLibMgr()
    assert mgr.is_available()


# Generated at 2022-06-17 01:26:17.547633
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class PkgMgrTest(PkgMgr):
        def __init__(self):
            super(PkgMgrTest, self).__init__()

        def is_available(self):
            return True

        def list_installed(self):
            return ['package1', 'package2']

        def get_package_details(self, package):
            if package == 'package1':
                return {'name': 'package1', 'version': '1.0.0'}
            elif package == 'package2':
                return {'name': 'package2', 'version': '2.0.0'}
            else:
                return {'name': 'package3', 'version': '3.0.0'}

    pkg_mgr_test = PkgMgrTest()
    assert pkg_mgr_test

# Generated at 2022-06-17 01:26:21.436361
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCLIMgr(CLIMgr):
        CLI = 'test_CLIMgr_is_available'

    test_CLIMgr = TestCLIMgr()
    assert test_CLIMgr.is_available() == False


# Generated at 2022-06-17 01:26:25.308653
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCLIMgr(CLIMgr):
        CLI = 'test_cli'
    test_mgr = TestCLIMgr()
    assert test_mgr.is_available() == False


# Generated at 2022-06-17 01:26:29.932422
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class PkgMgrTest(PkgMgr):
        def list_installed(self):
            return ['package1', 'package2']
        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}
    pkg_mgr = PkgMgrTest()
    assert pkg_mgr.get_packages() == {'package1': [{'name': 'package1', 'version': '1.0', 'source': 'pkgmgrtest'}],
                                     'package2': [{'name': 'package2', 'version': '1.0', 'source': 'pkgmgrtest'}]}

# Generated at 2022-06-17 01:26:32.977481
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestLibMgr(LibMgr):
        LIB = 'test_lib'
    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr._lib is None


# Generated at 2022-06-17 01:26:35.343550
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestLibMgr(LibMgr):
        LIB = 'test_lib'
    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr._lib is None


# Generated at 2022-06-17 01:26:43.494375
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr()._cli is None


# Generated at 2022-06-17 01:26:47.510562
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCLIMgr(CLIMgr):
        CLI = 'test_cli'
    test_cli_mgr = TestCLIMgr()
    assert test_cli_mgr.is_available() == False


# Generated at 2022-06-17 01:26:51.389104
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCLIMgr(CLIMgr):
        CLI = 'test_cli'
    test_cli = TestCLIMgr()
    assert test_cli.is_available() == False


# Generated at 2022-06-17 01:26:57.343555
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.system.pkg_mgr.test_lib'

    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr.is_available() == True


# Generated at 2022-06-17 01:27:03.514613
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class PkgMgrTest(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['package1', 'package2']
        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}
    pkgmgr = PkgMgrTest()
    assert pkgmgr.get_packages() == {'package1': [{'name': 'package1', 'version': '1.0', 'source': 'pkgmgrtest'}], 'package2': [{'name': 'package2', 'version': '1.0', 'source': 'pkgmgrtest'}]}

# Generated at 2022-06-17 01:27:07.906367
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestLibMgr(LibMgr):
        LIB = 'test_lib'

    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr._lib is None


# Generated at 2022-06-17 01:27:09.861064
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    assert PkgMgr.is_available() == False


# Generated at 2022-06-17 01:27:14.040935
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCLIMgr(CLIMgr):
        CLI = 'test_cli'
    test_cli_mgr = TestCLIMgr()
    assert test_cli_mgr.is_available() == False


# Generated at 2022-06-17 01:27:15.192866
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    assert PkgMgr.list_installed() == NotImplemented


# Generated at 2022-06-17 01:27:17.940040
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    class TestCLIMgr(CLIMgr):
        CLI = 'test_cli'
    assert TestCLIMgr().is_available() == False

# Generated at 2022-06-17 01:27:28.167408
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class PkgMgrTest(PkgMgr):
        def list_installed(self):
            return ['package1', 'package2']

        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}

    pkg_mgr = PkgMgrTest()
    assert pkg_mgr.get_packages() == {'package1': [{'name': 'package1', 'version': '1.0', 'source': 'pkgmgrtest'}],
                                     'package2': [{'name': 'package2', 'version': '1.0', 'source': 'pkgmgrtest'}]}

# Generated at 2022-06-17 01:27:31.463243
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestLibMgr(LibMgr):
        LIB = 'test_lib'
    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr._lib is None


# Generated at 2022-06-17 01:27:36.371807
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCLIMgr(CLIMgr):
        CLI = 'test_cli'
    test_cli_mgr = TestCLIMgr()
    assert test_cli_mgr.is_available() == False


# Generated at 2022-06-17 01:27:38.398627
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.system.pkg_mgr.test_lib'

    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr.is_available()


# Generated at 2022-06-17 01:27:39.561711
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    assert PkgMgr.is_available() == False


# Generated at 2022-06-17 01:27:41.678680
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestLibMgr(LibMgr):
        LIB = 'test_lib'
    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr._lib is None


# Generated at 2022-06-17 01:27:45.809816
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'test_lib'
    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr.is_available() == False


# Generated at 2022-06-17 01:27:48.837070
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestLibMgr(LibMgr):
        LIB = 'test_lib'

    assert TestLibMgr().is_available() is False


# Generated at 2022-06-17 01:27:52.499933
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCLIMgr(CLIMgr):
        CLI = 'test_cli'
    test_mgr = TestCLIMgr()
    assert test_mgr.is_available() == False
    test_mgr._cli = 'test_cli'
    assert test_mgr.is_available() == True

# Generated at 2022-06-17 01:27:54.016116
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr()

# Generated at 2022-06-17 01:27:58.965008
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    assert PkgMgr.is_available() == False


# Generated at 2022-06-17 01:28:10.148508
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['test_package']
        def get_package_details(self, package):
            return {'name': 'test_package', 'version': '1.0'}
    test_pkg_mgr = TestPkgMgr()
    assert test_pkg_mgr.get_package_details('test_package') == {'name': 'test_package', 'version': '1.0'}


# Generated at 2022-06-17 01:28:14.115605
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestLibMgr(LibMgr):
        LIB = 'test_lib'

    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr._lib is None


# Generated at 2022-06-17 01:28:24.450014
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True

        def list_installed(self):
            return ['package1', 'package2']

        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}

    test_pkg_mgr = TestPkgMgr()
    assert test_pkg_mgr.get_packages() == {'package1': [{'name': 'package1', 'version': '1.0', 'source': 'testpkgmgr'}],
                                          'package2': [{'name': 'package2', 'version': '1.0', 'source': 'testpkgmgr'}]}

# Generated at 2022-06-17 01:28:30.699618
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCLIMgr(CLIMgr):
        CLI = 'test_cli'
    test_cli_mgr = TestCLIMgr()
    assert test_cli_mgr.is_available() == False
    test_cli_mgr._cli = 'test_cli'
    assert test_cli_mgr.is_available() == True


# Generated at 2022-06-17 01:28:31.518855
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr()

# Generated at 2022-06-17 01:28:33.232809
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    class TestCLIMgr(CLIMgr):
        CLI = 'test'
    assert TestCLIMgr().is_available() == False

# Generated at 2022-06-17 01:28:36.077391
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestLibMgr(LibMgr):
        LIB = 'test_lib'

    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr._lib is None


# Generated at 2022-06-17 01:28:38.820131
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.packages.test_libmgr'
    assert TestLibMgr().is_available()


# Generated at 2022-06-17 01:28:48.255420
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True

        def list_installed(self):
            return ['package1', 'package2']

        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}

    pkg_mgr = TestPkgMgr()
    packages = pkg_mgr.get_packages()
    assert packages == {'package1': [{'name': 'package1', 'version': '1.0', 'source': 'testpkgmgr'}],
                        'package2': [{'name': 'package2', 'version': '1.0', 'source': 'testpkgmgr'}]}

# Generated at 2022-06-17 01:28:53.926375
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    # Test for class PkgMgr
    assert PkgMgr.is_available(PkgMgr) == False


# Generated at 2022-06-17 01:28:59.989709
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCLIMgr(CLIMgr):
        CLI = 'test_cli'
    test_mgr = TestCLIMgr()
    assert test_mgr.is_available() == False
    test_mgr._cli = 'test_cli'
    assert test_mgr.is_available() == True


# Generated at 2022-06-17 01:29:07.306465
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.facts.system.pkg_mgr import CLIMgr
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgr
    from ansible.module_utils.facts.system.pkg_mgr import LibMgr
    from ansible.module_utils.facts.system.pkg_mgr import get_all_pkg_managers
    from ansible.module_utils.facts.system.pkg_mgr import get_all_subclasses
    from ansible.module_utils.facts.system.pkg_mgr import get_pkg_mgr
    from ansible.module_utils.facts.system.pkg_mgr import get_pkg_mgr_facts

# Generated at 2022-06-17 01:29:12.108705
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestLibMgr(LibMgr):
        LIB = 'test_lib'

    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr._lib is None


# Generated at 2022-06-17 01:29:21.322695
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['pkg1', 'pkg2']
        def get_package_details(self, package):
            if package == 'pkg1':
                return {'name': 'pkg1', 'version': '1.0'}
            elif package == 'pkg2':
                return {'name': 'pkg2', 'version': '2.0'}
            else:
                return None
    pkg_mgr = TestPkgMgr()
    packages = pkg_mgr.get_packages()

# Generated at 2022-06-17 01:29:28.726364
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.facts.system.pkg_mgr import CLIMgr
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgr
    from ansible.module_utils.facts.system.pkg_mgr import get_all_pkg_managers
    from ansible.module_utils.facts.system.pkg_mgr import get_all_subclasses
    from ansible.module_utils.facts.system.pkg_mgr import get_pkg_mgr
    from ansible.module_utils.facts.system.pkg_mgr import get_pkg_mgr_facts
    from ansible.module_utils.facts.system.pkg_mgr import get_pkg_mgr_facts_from_system


# Generated at 2022-06-17 01:29:31.613066
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestLibMgr(LibMgr):
        LIB = 'test_lib'
    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr._lib is None


# Generated at 2022-06-17 01:29:32.679110
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    assert CLIMgr().is_available() == False


# Generated at 2022-06-17 01:29:36.764266
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestLibMgr(LibMgr):
        LIB = 'test_lib'
    assert TestLibMgr()._lib is None


# Generated at 2022-06-17 01:29:40.919278
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['test_package']
        def get_package_details(self, package):
            return {'name': 'test_package', 'version': '1.0.0'}
    test_pkg_mgr = TestPkgMgr()
    assert test_pkg_mgr.get_package_details('test_package') == {'name': 'test_package', 'version': '1.0.0'}


# Generated at 2022-06-17 01:29:54.343004
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['package1', 'package2']
        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}
    pkg_mgr = TestPkgMgr()
    assert pkg_mgr.get_packages() == {'package1': [{'name': 'package1', 'version': '1.0', 'source': 'testpkgmgr'}], 'package2': [{'name': 'package2', 'version': '1.0', 'source': 'testpkgmgr'}]}

# Generated at 2022-06-17 01:29:57.744019
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCLIMgr(CLIMgr):
        CLI = 'test_cli'

    test_cli_mgr = TestCLIMgr()
    assert test_cli_mgr.is_available() == False


# Generated at 2022-06-17 01:29:59.142028
# Unit test for constructor of class LibMgr
def test_LibMgr():
    libmgr = LibMgr()
    assert libmgr.is_available() == False


# Generated at 2022-06-17 01:30:00.923226
# Unit test for constructor of class LibMgr
def test_LibMgr():
    assert LibMgr()


# Generated at 2022-06-17 01:30:05.937095
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.packages.test_lib'

    assert TestLibMgr().is_available()


# Generated at 2022-06-17 01:30:07.939634
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCLIMgr(CLIMgr):
        CLI = 'test_cli'

    test_cli_mgr = TestCLIMgr()
    assert test_cli_mgr.is_available() == False


# Generated at 2022-06-17 01:30:13.310972
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class PkgMgrTest(PkgMgr):
        def list_installed(self):
            return ['test']

        def get_package_details(self, package):
            return {'name': 'test', 'version': '1.0'}

    pkg_mgr = PkgMgrTest()
    assert pkg_mgr.get_package_details('test') == {'name': 'test', 'version': '1.0'}


# Generated at 2022-06-17 01:30:17.695072
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.system.pkg_mgr.test_lib'

    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr.is_available() == True


# Generated at 2022-06-17 01:30:24.477088
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['package1', 'package2']
        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}
    pkg_mgr = TestPkgMgr()
    assert pkg_mgr.get_packages() == {'package1': [{'name': 'package1', 'version': '1.0', 'source': 'testpkgmgr'}],
                                     'package2': [{'name': 'package2', 'version': '1.0', 'source': 'testpkgmgr'}]}

# Generated at 2022-06-17 01:30:26.566293
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestLibMgr(LibMgr):
        LIB = 'test_lib'

    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr._lib is None


# Generated at 2022-06-17 01:30:40.802723
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCLIMgr(CLIMgr):
        CLI = 'test_cli'

    test_cli_mgr = TestCLIMgr()
    assert test_cli_mgr.is_available() == False


# Generated at 2022-06-17 01:30:52.311879
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    pkg_managers = get_all_pkg_managers()
    assert 'apt' in pkg_managers
    assert 'dnf' in pkg_managers
    assert 'yum' in pkg_managers
    assert 'zypper' in pkg_managers
    assert 'pacman' in pkg_managers
    assert 'portage' in pkg_managers
    assert 'apk' in pkg_managers
    assert 'pkgng' in pkg_managers
    assert 'pkg5' in pkg_managers
    assert 'pkgutil' in pkg_managers
    assert 'pkg' in pkg_managers
    assert 'pkg_info' in pkg_managers
    assert 'pip' in pkg_managers
    assert 'gem' in pkg_managers

# Generated at 2022-06-17 01:31:00.045581
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class PkgMgrTest(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['package1', 'package2']
        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}
    pkg_mgr = PkgMgrTest()
    assert pkg_mgr.get_packages() == {'package1': [{'name': 'package1', 'version': '1.0', 'source': 'pkgmgrtest'}],
                                     'package2': [{'name': 'package2', 'version': '1.0', 'source': 'pkgmgrtest'}]}

# Generated at 2022-06-17 01:31:04.054266
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    class TestCLIMgr(CLIMgr):
        CLI = 'test'
    assert TestCLIMgr().CLI == 'test'


# Generated at 2022-06-17 01:31:13.162943
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class PkgMgrTest(PkgMgr):
        def list_installed(self):
            return ['package1', 'package2']
        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}
    pkg_mgr = PkgMgrTest()
    assert pkg_mgr.get_packages() == {'package1': [{'name': 'package1', 'version': '1.0', 'source': 'pkgmgrtest'}],
                                     'package2': [{'name': 'package2', 'version': '1.0', 'source': 'pkgmgrtest'}]}

# Generated at 2022-06-17 01:31:18.457511
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    class TestPkgMgr(PkgMgr):
        def list_installed(self):
            return ['test_package']

        def get_package_details(self, package):
            return {'name': 'test_package', 'version': '1.0'}

    pkg_mgr = TestPkgMgr()
    assert pkg_mgr.list_installed() == ['test_package']


# Generated at 2022-06-17 01:31:29.043955
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    pkg_managers = get_all_pkg_managers()
    assert 'apt' in pkg_managers
    assert 'yum' in pkg_managers
    assert 'dnf' in pkg_managers
    assert 'zypper' in pkg_managers
    assert 'pacman' in pkg_managers
    assert 'apk' in pkg_managers
    assert 'pkgng' in pkg_managers
    assert 'portage' in pkg_managers
    assert 'pkg5' in pkg_managers
    assert 'pkgutil' in pkg_managers
    assert 'pkg' in pkg_managers
    assert 'pip' in pkg_managers
    assert 'gem' in pkg_managers
    assert 'npm' in pkg_managers

# Generated at 2022-06-17 01:31:35.375695
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCLIMgr(CLIMgr):
        CLI = 'test_cli'

    test_cli_mgr = TestCLIMgr()
    assert test_cli_mgr.is_available() == False
    assert test_cli_mgr._cli == None


# Generated at 2022-06-17 01:31:39.034490
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.system.pkg_mgr.test_lib'

    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr.is_available() is True


# Generated at 2022-06-17 01:31:43.664707
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    assert PkgMgr.is_available() == False


# Generated at 2022-06-17 01:32:12.665062
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestLibMgr(LibMgr):
        LIB = 'test_lib'
    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr._lib is None


# Generated at 2022-06-17 01:32:17.996423
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    assert PkgMgr.is_available() == False


# Generated at 2022-06-17 01:32:19.013128
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    assert PkgMgr.list_installed() == NotImplemented


# Generated at 2022-06-17 01:32:21.545410
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.system.pkg_mgr.test_lib'
    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr.is_available() == True


# Generated at 2022-06-17 01:32:24.904151
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.system.pkg_mgr.test_lib'

    pkg_mgr = TestLibMgr()
    assert pkg_mgr.is_available()


# Generated at 2022-06-17 01:32:27.657801
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    assert PkgMgr.is_available() == False


# Generated at 2022-06-17 01:32:29.872221
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pass


# Generated at 2022-06-17 01:32:32.203045
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    class TestPkgMgr(PkgMgr):
        def list_installed(self):
            return ['test_package']

    test_pkg_mgr = TestPkgMgr()
    assert test_pkg_mgr.list_installed() == ['test_package']


# Generated at 2022-06-17 01:32:39.398459
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.system.pkg_mgr.test_libmgr'
    test_libmgr = TestLibMgr()
    assert test_libmgr.is_available() == True


# Generated at 2022-06-17 01:32:44.418983
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCLIMgr(CLIMgr):
        CLI = 'test_cli'
    test_cli = TestCLIMgr()
    assert test_cli.is_available() == False


# Generated at 2022-06-17 01:33:34.479714
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.system.distribution'

    assert TestLibMgr().is_available() is True


# Generated at 2022-06-17 01:33:40.007117
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestLibMgr(LibMgr):
        LIB = 'test_lib'

    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr._lib is None


# Generated at 2022-06-17 01:33:44.479507
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True

        def list_installed(self):
            return ['package1', 'package2']

        def get_package_details(self, package):
            return {'name': 'package1', 'version': '1.0'}

    pkg_mgr = TestPkgMgr()
    assert pkg_mgr.get_packages() == {'package1': [{'name': 'package1', 'version': '1.0', 'source': 'testpkgmgr'}]}

# Generated at 2022-06-17 01:33:47.437002
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestLibMgr(LibMgr):
        LIB = 'test_lib'

    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr._lib is None


# Generated at 2022-06-17 01:33:50.898798
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True
    assert TestPkgMgr().is_available() == True


# Generated at 2022-06-17 01:33:54.231725
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestLibMgr(LibMgr):
        LIB = 'test_lib'
    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr._lib is None


# Generated at 2022-06-17 01:33:58.177019
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestLibMgr(LibMgr):
        LIB = 'test_lib'

    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr._lib is None


# Generated at 2022-06-17 01:34:03.230405
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['test_package']
        def get_package_details(self, package):
            return {'name': 'test_package', 'version': '1.0.0'}
    test_pkg_mgr = TestPkgMgr()
    assert test_pkg_mgr.get_package_details('test_package') == {'name': 'test_package', 'version': '1.0.0'}


# Generated at 2022-06-17 01:34:07.743469
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    # Create a PkgMgr object
    pkgmgr = PkgMgr()
    # Check that the is_available method returns False
    assert pkgmgr.is_available() == False


# Generated at 2022-06-17 01:34:12.738053
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['foo']
        def get_package_details(self, package):
            return {'name': 'foo', 'version': '1.0'}
    pkg_mgr = TestPkgMgr()
    assert pkg_mgr.get_package_details('foo') == {'name': 'foo', 'version': '1.0'}
