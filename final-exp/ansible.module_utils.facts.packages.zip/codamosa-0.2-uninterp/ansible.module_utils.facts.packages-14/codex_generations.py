

# Generated at 2022-06-17 01:24:32.872209
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    assert PkgMgr.list_installed() is None


# Generated at 2022-06-17 01:24:42.878325
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class PkgMgrTest(PkgMgr):
        def is_available(self):
            return True

        def list_installed(self):
            return ['package1', 'package2']

        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}

    pkg_mgr = PkgMgrTest()
    packages = pkg_mgr.get_packages()
    assert packages == {'package1': [{'name': 'package1', 'version': '1.0', 'source': 'pkgmgrtest'}],
                        'package2': [{'name': 'package2', 'version': '1.0', 'source': 'pkgmgrtest'}]}

# Generated at 2022-06-17 01:24:46.693014
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.system.pkg_mgr.test_lib'
    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr.is_available() is True


# Generated at 2022-06-17 01:24:49.982371
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    class TestCLIMgr(CLIMgr):
        CLI = 'test_cli'
    test_cli_mgr = TestCLIMgr()
    assert test_cli_mgr.CLI == 'test_cli'
    assert test_cli_mgr._cli is None


# Generated at 2022-06-17 01:24:51.936790
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    cli_mgr = CLIMgr()
    assert cli_mgr._cli is None
    assert cli_mgr.CLI is None


# Generated at 2022-06-17 01:25:01.073480
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['test_package']
        def get_package_details(self, package):
            return {'name': 'test_package', 'version': '1.0.0'}
    test_pkg_mgr = TestPkgMgr()
    assert test_pkg_mgr.get_package_details('test_package') == {'name': 'test_package', 'version': '1.0.0'}


# Generated at 2022-06-17 01:25:03.175124
# Unit test for constructor of class LibMgr
def test_LibMgr():
    lm = LibMgr()
    assert lm._lib is None


# Generated at 2022-06-17 01:25:08.795550
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCLIMgr(CLIMgr):
        CLI = 'test_cli'
    test_cli = TestCLIMgr()
    assert test_cli.is_available() == False
    assert test_cli._cli == None


# Generated at 2022-06-17 01:25:11.796297
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCLIMgr(CLIMgr):
        CLI = 'test_cli'

    test_cli_mgr = TestCLIMgr()
    assert test_cli_mgr.is_available() == False


# Generated at 2022-06-17 01:25:17.706380
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def list_installed(self):
            return ['package1', 'package2']

        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}

    test_pkg_mgr = TestPkgMgr()
    packages = test_pkg_mgr.get_packages()
    assert packages == {'package1': [{'name': 'package1', 'version': '1.0', 'source': 'testpkgmgr'}],
                        'package2': [{'name': 'package2', 'version': '1.0', 'source': 'testpkgmgr'}]}

# Generated at 2022-06-17 01:25:24.767928
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    assert PkgMgr.list_installed() == NotImplemented


# Generated at 2022-06-17 01:25:27.076212
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    assert get_all_pkg_managers()

# Generated at 2022-06-17 01:25:34.896055
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['pkg1', 'pkg2']
        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}

    pkg_mgr = TestPkgMgr()
    packages = pkg_mgr.get_packages()
    assert packages == {'pkg1': [{'name': 'pkg1', 'version': '1.0', 'source': 'testpkgmgr'}],
                        'pkg2': [{'name': 'pkg2', 'version': '1.0', 'source': 'testpkgmgr'}]}

# Generated at 2022-06-17 01:25:39.740024
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCLIMgr(CLIMgr):
        CLI = "test_CLIMgr_is_available"
    test_CLIMgr = TestCLIMgr()
    assert test_CLIMgr.is_available() == False


# Generated at 2022-06-17 01:25:45.477532
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['package1', 'package2']
        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}
    pkg_mgr = TestPkgMgr()
    assert pkg_mgr.get_packages() == {'package1': [{'name': 'package1', 'version': '1.0', 'source': 'testpkgmgr'}],
                                     'package2': [{'name': 'package2', 'version': '1.0', 'source': 'testpkgmgr'}]}

# Generated at 2022-06-17 01:25:49.142098
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestLibMgr(LibMgr):
        LIB = 'test_lib'

    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr._lib is None


# Generated at 2022-06-17 01:25:51.083515
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    assert PkgMgr.list_installed() == NotImplemented


# Generated at 2022-06-17 01:25:54.279788
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr()

# Generated at 2022-06-17 01:26:03.084019
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['package1', 'package2', 'package3']
        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}
    test_pkg_mgr = TestPkgMgr()

# Generated at 2022-06-17 01:26:07.588184
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestLibMgr(LibMgr):
        LIB = 'test_lib'

    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr._lib is None


# Generated at 2022-06-17 01:26:15.388828
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.packages.test_libmgr_lib'

    test_libmgr = TestLibMgr()
    assert test_libmgr.is_available() == True


# Generated at 2022-06-17 01:26:18.662725
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'test_lib'
    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr.is_available() == False


# Generated at 2022-06-17 01:26:21.294123
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pkg_mgr = PkgMgr()
    assert pkg_mgr.is_available() == False


# Generated at 2022-06-17 01:26:25.873313
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.system.distribution'
    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr.is_available()


# Generated at 2022-06-17 01:26:28.646630
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCLIMgr(CLIMgr):
        CLI = 'test_CLIMgr_is_available'

    test_CLIMgr = TestCLIMgr()
    assert test_CLIMgr.is_available() == False


# Generated at 2022-06-17 01:26:31.639556
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestLibMgr(LibMgr):
        LIB = 'test_lib'
    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr._lib is None


# Generated at 2022-06-17 01:26:32.925382
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    assert PkgMgr.list_installed() == NotImplemented


# Generated at 2022-06-17 01:26:35.863951
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.packages.test_lib'

    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr.is_available()


# Generated at 2022-06-17 01:26:42.898982
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    # Create a dummy class for testing
    class DummyPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['package1', 'package2']
        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}

    dummy_pkg_mgr = DummyPkgMgr()
    assert dummy_pkg_mgr.list_installed() == ['package1', 'package2']


# Generated at 2022-06-17 01:26:46.125486
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    class TestCLIMgr(CLIMgr):
        CLI = 'test_cli'
    assert TestCLIMgr()._cli is None


# Generated at 2022-06-17 01:26:51.083316
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr()

# Generated at 2022-06-17 01:26:59.819552
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['test_package']
        def get_package_details(self, package):
            return {'name': 'test_package', 'version': '1.0.0'}
    pkg_mgr = TestPkgMgr()
    assert pkg_mgr.get_package_details('test_package') == {'name': 'test_package', 'version': '1.0.0'}


# Generated at 2022-06-17 01:27:01.182706
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    assert get_all_pkg_managers()

# Generated at 2022-06-17 01:27:11.433087
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def list_installed(self):
            return ['package1', 'package2']
        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}
    test_pkg_mgr = TestPkgMgr()
    assert test_pkg_mgr.get_packages() == {'package1': [{'name': 'package1', 'version': '1.0', 'source': 'testpkgmgr'}],
                                          'package2': [{'name': 'package2', 'version': '1.0', 'source': 'testpkgmgr'}]}

# Generated at 2022-06-17 01:27:12.143428
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr()

# Generated at 2022-06-17 01:27:14.552965
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestLibMgr(LibMgr):
        LIB = 'test_lib'
    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr._lib is None


# Generated at 2022-06-17 01:27:18.344458
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCLIMgr(CLIMgr):
        CLI = 'test_CLIMgr_is_available'

    test_CLIMgr = TestCLIMgr()
    assert test_CLIMgr.is_available() == False


# Generated at 2022-06-17 01:27:21.243277
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.system.distribution'

    libmgr = TestLibMgr()
    assert libmgr.is_available() == True


# Generated at 2022-06-17 01:27:24.766583
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.system.pkg_mgr.test_lib'

    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr.is_available() == True


# Generated at 2022-06-17 01:27:25.767828
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr()._cli is None


# Generated at 2022-06-17 01:27:38.192782
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class PkgMgrTest(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['test_package']
        def get_package_details(self, package):
            return {'name': 'test_package', 'version': '1.0'}
    pkg_mgr = PkgMgrTest()
    assert pkg_mgr.get_package_details('test_package') == {'name': 'test_package', 'version': '1.0'}


# Generated at 2022-06-17 01:27:39.299833
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr().CLI is None


# Generated at 2022-06-17 01:27:44.512570
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['package1', 'package2']
        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}
    test_pkg_mgr = TestPkgMgr()
    assert test_pkg_mgr.get_packages() == {'package1': [{'name': 'package1', 'version': '1.0', 'source': 'testpkgmgr'}], 'package2': [{'name': 'package2', 'version': '1.0', 'source': 'testpkgmgr'}]}

# Generated at 2022-06-17 01:27:46.387011
# Unit test for constructor of class LibMgr
def test_LibMgr():
    libmgr = LibMgr()
    assert libmgr._lib is None


# Generated at 2022-06-17 01:27:49.867859
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestLibMgr(LibMgr):
        LIB = 'test_lib'
    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr._lib is None


# Generated at 2022-06-17 01:27:56.334516
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.system.pkg_mgr.test_lib'

    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr.is_available()


# Generated at 2022-06-17 01:28:05.867799
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['package1', 'package2']
        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}

    test_pkg_mgr = TestPkgMgr()
    packages = test_pkg_mgr.get_packages()
    assert packages['package1'][0]['version'] == '1.0'
    assert packages['package2'][0]['version'] == '1.0'

# Generated at 2022-06-17 01:28:08.504757
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.system.pkg_mgr.test_lib'

    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr.is_available()


# Generated at 2022-06-17 01:28:18.148755
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class PkgMgrTest(PkgMgr):
        def list_installed(self):
            return ['package1', 'package2']

        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}

    pkg_mgr = PkgMgrTest()
    assert pkg_mgr.get_packages() == {'package1': [{'name': 'package1', 'version': '1.0', 'source': 'pkgmgrtest'}],
                                     'package2': [{'name': 'package2', 'version': '1.0', 'source': 'pkgmgrtest'}]}

# Generated at 2022-06-17 01:28:21.204277
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestLibMgr(LibMgr):
        LIB = 'test_lib'
    assert TestLibMgr().LIB == 'test_lib'


# Generated at 2022-06-17 01:28:28.250115
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    c = CLIMgr()
    assert c.CLI is None
    assert c._cli is None


# Generated at 2022-06-17 01:28:32.240239
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr()

# Generated at 2022-06-17 01:28:32.746312
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr()

# Generated at 2022-06-17 01:28:33.830702
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    assert PkgMgr.is_available() == NotImplemented


# Generated at 2022-06-17 01:28:38.931669
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCLIMgr(CLIMgr):
        CLI = 'test_cli'
    test_cli_mgr = TestCLIMgr()
    assert test_cli_mgr.is_available() == False


# Generated at 2022-06-17 01:28:47.841906
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class PkgMgrTest(PkgMgr):
        def list_installed(self):
            return ['package1', 'package2']

        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}

    pkg_mgr = PkgMgrTest()
    packages = pkg_mgr.get_packages()
    assert packages == {'package1': [{'name': 'package1', 'version': '1.0', 'source': 'pkgmgrtest'}],
                        'package2': [{'name': 'package2', 'version': '1.0', 'source': 'pkgmgrtest'}]}

# Generated at 2022-06-17 01:28:51.471497
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr().CLI is None


# Generated at 2022-06-17 01:28:56.920059
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True

        def list_installed(self):
            return ['package1', 'package2']

        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}

    test_pkg_mgr = TestPkgMgr()
    assert test_pkg_mgr.get_packages() == {'package1': [{'name': 'package1', 'version': '1.0', 'source': 'testpkgmgr'}],
                                          'package2': [{'name': 'package2', 'version': '1.0', 'source': 'testpkgmgr'}]}

# Generated at 2022-06-17 01:28:58.081848
# Unit test for constructor of class LibMgr
def test_LibMgr():
    lm = LibMgr()
    assert lm._lib is None


# Generated at 2022-06-17 01:29:11.089794
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    import sys
    import os
    import tempfile
    import shutil
    import json
    import subprocess

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary virtualenv
    subprocess.check_call([sys.executable, '-m', 'virtualenv', tmpdir])

    # Install a package
    subprocess.check_call([os.path.join(tmpdir, 'bin', 'pip'), 'install', 'ansible'])

    # Save the output of pip list
    pip_list = subprocess.check_output([os.path.join(tmpdir, 'bin', 'pip'), 'list'])

    # Create a class that inherits from PkgMgr
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return

# Generated at 2022-06-17 01:29:19.719189
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class PkgMgrTest(PkgMgr):
        def list_installed(self):
            return ['test_package']

        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}

    pkg_mgr = PkgMgrTest()
    assert pkg_mgr.get_package_details('test_package') == {'name': 'test_package', 'version': '1.0'}


# Generated at 2022-06-17 01:29:28.550188
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgr
    from ansible.module_utils.facts.system.pkg_mgr import CLIMgr
    from ansible.module_utils.facts.system.pkg_mgr import LibMgr

    class TestCLIMgr(CLIMgr):
        CLI = 'test_cli'

        def list_installed(self):
            return ['test_package']

        def get_package_details(self, package):
            return {'name': 'test_package', 'version': '1.0.0'}

    class TestLibMgr(LibMgr):
        LIB = 'test_lib'

        def list_installed(self):
            return ['test_package']

       

# Generated at 2022-06-17 01:29:38.540030
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True

        def list_installed(self):
            return ['package1', 'package2']

        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}

    test_pkg_mgr = TestPkgMgr()
    assert test_pkg_mgr.get_packages() == {'package1': [{'name': 'package1', 'version': '1.0', 'source': 'testpkgmgr'}],
                                          'package2': [{'name': 'package2', 'version': '1.0', 'source': 'testpkgmgr'}]}

# Generated at 2022-06-17 01:29:41.090429
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    assert False, "Test not implemented"


# Generated at 2022-06-17 01:29:41.984538
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    cli = CLIMgr()
    assert cli._cli is None


# Generated at 2022-06-17 01:29:47.721099
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class PkgMgrTest(PkgMgr):
        def list_installed(self):
            return ['package1', 'package2']

        def get_package_details(self, package):
            return {'name': package, 'version': '1.0.0'}

    pkg_mgr = PkgMgrTest()
    assert pkg_mgr.get_packages() == {'package1': [{'name': 'package1', 'version': '1.0.0', 'source': 'pkgmgrtest'}],
                                     'package2': [{'name': 'package2', 'version': '1.0.0', 'source': 'pkgmgrtest'}]}

# Generated at 2022-06-17 01:29:48.441449
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pass


# Generated at 2022-06-17 01:29:55.424568
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.system.pkg_mgr.test_lib'

    pkg_mgr = TestLibMgr()
    assert pkg_mgr.is_available()
    assert pkg_mgr._lib.__name__ == 'ansible.module_utils.facts.system.pkg_mgr.test_lib'


# Generated at 2022-06-17 01:29:59.555201
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCLIMgr(CLIMgr):
        CLI = 'test_CLIMgr_is_available'
    test_CLIMgr = TestCLIMgr()
    assert test_CLIMgr.is_available() == False
    test_CLIMgr._cli = 'test_CLIMgr_is_available'
    assert test_CLIMgr.is_available() == True


# Generated at 2022-06-17 01:30:05.051523
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.system.distribution'

    assert TestLibMgr().is_available() is True


# Generated at 2022-06-17 01:30:18.227149
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class PkgMgrTest(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['pkg1', 'pkg2']
        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}
    pkg_mgr = PkgMgrTest()
    assert pkg_mgr.get_packages() == {'pkg1': [{'name': 'pkg1', 'version': '1.0', 'source': 'pkgmgrtest'}],
                                     'pkg2': [{'name': 'pkg2', 'version': '1.0', 'source': 'pkgmgrtest'}]}

# Generated at 2022-06-17 01:30:21.576206
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.system.pkg_mgr.test_lib'

    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr.is_available() is True


# Generated at 2022-06-17 01:30:29.494688
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['package1', 'package2']
        def get_package_details(self, package):
            return {'name': package, 'version': '1.0.0'}
    test_pkg_mgr = TestPkgMgr()
    assert test_pkg_mgr.get_packages() == {'package1': [{'name': 'package1', 'version': '1.0.0', 'source': 'testpkgmgr'}], 'package2': [{'name': 'package2', 'version': '1.0.0', 'source': 'testpkgmgr'}]}

# Generated at 2022-06-17 01:30:35.453348
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['package1', 'package2']
        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}
    pkg_mgr = TestPkgMgr()
    packages = pkg_mgr.get_packages()
    assert packages == {'package1': [{'name': 'package1', 'version': '1.0', 'source': 'testpkgmgr'}],
                        'package2': [{'name': 'package2', 'version': '1.0', 'source': 'testpkgmgr'}]}

# Generated at 2022-06-17 01:30:43.653841
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class PkgMgrTest(PkgMgr):
        def list_installed(self):
            return ['test']
        def get_package_details(self, package):
            return {'name': 'test', 'version': '1.0'}
    pkg_mgr = PkgMgrTest()
    assert pkg_mgr.get_package_details('test') == {'name': 'test', 'version': '1.0'}


# Generated at 2022-06-17 01:30:50.969111
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['test_package']
        def get_package_details(self, package):
            return {'name': 'test_package', 'version': '1.0'}
    test_pkg_mgr = TestPkgMgr()
    assert test_pkg_mgr.get_package_details('test_package') == {'name': 'test_package', 'version': '1.0'}


# Generated at 2022-06-17 01:30:56.569137
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.system.pkg_mgr.test_lib'

    pkg_mgr = TestLibMgr()
    assert pkg_mgr.is_available() is True
    assert pkg_mgr._lib is not None


# Generated at 2022-06-17 01:31:00.112040
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.system.pkg_mgr.test_lib'

    pkg_mgr = TestLibMgr()
    assert pkg_mgr.is_available() is True
    assert pkg_mgr._lib is not None


# Generated at 2022-06-17 01:31:04.897177
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestLibMgr(LibMgr):
        LIB = 'test'

    t = TestLibMgr()
    assert t._lib is None


# Generated at 2022-06-17 01:31:13.564181
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['package1', 'package2']
        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}
    test_pkg_mgr = TestPkgMgr()
    assert test_pkg_mgr.get_packages() == {'package1': [{'name': 'package1', 'version': '1.0', 'source': 'testpkgmgr'}], 'package2': [{'name': 'package2', 'version': '1.0', 'source': 'testpkgmgr'}]}

# Generated at 2022-06-17 01:31:30.722372
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.system.distribution'

    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr.is_available()


# Generated at 2022-06-17 01:31:31.945562
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr()._cli is None


# Generated at 2022-06-17 01:31:40.935670
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class PkgMgrTest(PkgMgr):
        def list_installed(self):
            return ['package1', 'package2', 'package3']

        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}

    pkg_mgr = PkgMgrTest()
    packages = pkg_mgr.get_packages()

# Generated at 2022-06-17 01:31:44.391681
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCLIMgr(CLIMgr):
        CLI = 'test'
    assert TestCLIMgr().is_available() == False


# Generated at 2022-06-17 01:31:49.197339
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.system.pkg_mgr.test_lib'

    assert TestLibMgr().is_available() is True


# Generated at 2022-06-17 01:31:51.430039
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestLibMgr(LibMgr):
        LIB = 'test_lib'
    assert TestLibMgr().LIB == 'test_lib'


# Generated at 2022-06-17 01:31:58.721418
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['test1', 'test2']
        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}
    test_pkg_mgr = TestPkgMgr()
    assert test_pkg_mgr.get_packages() == {'test1': [{'name': 'test1', 'version': '1.0', 'source': 'testpkgmgr'}], 'test2': [{'name': 'test2', 'version': '1.0', 'source': 'testpkgmgr'}]}

# Generated at 2022-06-17 01:32:01.892730
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pkg_mgr = PkgMgr()
    assert pkg_mgr.list_installed() == NotImplemented


# Generated at 2022-06-17 01:32:05.240659
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    assert PkgMgr.list_installed() == NotImplemented


# Generated at 2022-06-17 01:32:08.616513
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.system.distribution'

    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr.is_available() == True


# Generated at 2022-06-17 01:32:40.601257
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCLIMgr(CLIMgr):
        CLI = 'test_cli'
    test_cli_mgr = TestCLIMgr()
    assert test_cli_mgr.is_available() == False
    assert test_cli_mgr._cli == None


# Generated at 2022-06-17 01:32:45.682218
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.system.pkg_mgr.test_lib'

    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr.is_available()


# Generated at 2022-06-17 01:32:47.815446
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.facts.system.pkg_mgr.test_lib'

    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr.is_available()


# Generated at 2022-06-17 01:32:53.182248
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.facts.system.pkg_mgr import CLIMgr
    from ansible.module_utils.facts.system.pkg_mgr import get_all_pkg_managers
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgr
    from ansible.module_utils.facts.system.pkg_mgr import LibMgr
    from ansible.module_utils.facts.system.pkg_mgr import get_all_subclasses
    from ansible.module_utils.facts.system.pkg_mgr import get_all_pkg_managers
    from ansible.module_utils.facts.system.pkg_mgr import CLIMgr

# Generated at 2022-06-17 01:33:03.717374
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['package1', 'package2']
        def get_package_details(self, package):
            if package == 'package1':
                return {'name': 'package1', 'version': '1.0.0'}
            elif package == 'package2':
                return {'name': 'package2', 'version': '2.0.0'}
    test_pkg_mgr = TestPkgMgr()

# Generated at 2022-06-17 01:33:08.734566
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCLIMgr(CLIMgr):
        CLI = 'test_cli'

    test_cli_mgr = TestCLIMgr()
    assert test_cli_mgr.is_available() == False


# Generated at 2022-06-17 01:33:12.252762
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestLibMgr(LibMgr):
        LIB = 'test_lib'

    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr._lib is None


# Generated at 2022-06-17 01:33:17.159489
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestLibMgr(LibMgr):
        LIB = 'test_lib'
    assert TestLibMgr().LIB == 'test_lib'


# Generated at 2022-06-17 01:33:26.645146
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class PkgMgrTest(PkgMgr):
        def list_installed(self):
            return ['package1', 'package2']
        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}
    pkg_mgr = PkgMgrTest()
    assert pkg_mgr.get_packages() == {'package1': [{'name': 'package1', 'version': '1.0', 'source': 'pkgmgrtest'}],
                                     'package2': [{'name': 'package2', 'version': '1.0', 'source': 'pkgmgrtest'}]}

# Generated at 2022-06-17 01:33:32.915435
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestLibMgr(LibMgr):
        LIB = 'test_lib'

    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr._lib is None


# Generated at 2022-06-17 01:34:33.747105
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class TestPkgMgr(PkgMgr):
        def __init__(self):
            super(TestPkgMgr, self).__init__()

        def is_available(self):
            return True

        def list_installed(self):
            return ['foo', 'bar']

        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}

    pkg_mgr = TestPkgMgr()
    packages = pkg_mgr.get_packages()
    assert packages == {'foo': [{'name': 'foo', 'version': '1.0', 'source': 'testpkgmgr'}],
                        'bar': [{'name': 'bar', 'version': '1.0', 'source': 'testpkgmgr'}]}