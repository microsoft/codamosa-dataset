

# Generated at 2022-06-23 21:19:43.112318
# Unit test for constructor of class Internet
def test_Internet():
    internet = Internet()
    assert internet.__class__.__name__ == "Internet"
    assert internet.__name__ == "internet"


# Generated at 2022-06-23 21:19:47.608007
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    from mimesis.enums import Layer

    internet = Internet()
    #for layer in Layer:
    for layer in Layer:
        protocol = internet.network_protocol(layer=layer)
        assert isinstance(protocol, str)
        assert protocol.strip() != ""


# Generated at 2022-06-23 21:19:48.680591
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    internet = Internet()


# Generated at 2022-06-23 21:19:50.568869
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    from pprint import pprint
    internet = Internet()
    print()
    pprint(internet.mac_address())

# Generated at 2022-06-23 21:19:54.658566
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    internet = Internet()
    assert isinstance(internet.ip_v4(), str)
    assert len(internet.ip_v4().split('.')) == 4
    assert isinstance(internet.ip_v4(with_port=True), str)


# Generated at 2022-06-23 21:20:04.344989
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    """The provide test for the method hashtags."""
    from mimesis.enums import Hashtag
    from mimesis.providers.internet import Internet

    internet = Internet(seed=12345)
    assert internet.hashtags(quantity=2) == ['#tolerance', '#sky']
    assert internet.hashtags(quantity=3) == ['#nature', '#passport', '#place']
    assert internet.hashtags(quantity=1, category=Hashtag.SPORTS) == '#games'
    assert internet.hashtags(quantity=5, category=Hashtag.BEAUTY) == ['#nail', '#waxing', '#foot', '#makeup', '#face']



# Generated at 2022-06-23 21:20:07.092559
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    provider = Internet('en')
    ip_v4 = provider.ip_v4()
    assert ip_v4
    assert isinstance(ip_v4, str)

# Generated at 2022-06-23 21:20:09.940731
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    internet = Internet()

    result =  internet.emoji()
    print(result)


# Generated at 2022-06-23 21:20:18.406066
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    from mimesis.enums import PortRange
    from mimesis.typing import Seed

    i = Internet()
    for _ in range(100):
        ip = i.ip_v4_object()
        assert isinstance(ip, IPv4Address)
        assert str(ip) == i.ip_v4(False)

        ip_port = i.ip_v4_object()
        assert isinstance(ip_port, IPv4Address)
        assert str(ip_port) == i.ip_v4(True)

        port_random = i.port(PortRange.RANDOM)
        ip_port2 = i.ip_v4_object()
        assert isinstance(ip_port2, IPv4Address)

# Generated at 2022-06-23 21:20:21.496093
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    # Initialize the class
    internet = Internet()
    # Generate a random HTTP method
    print(internet.http_method())


# Generated at 2022-06-23 21:20:25.914578
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    from mimesis.enums import MimeType
    from mimesis.providers.helpers import fake

    content_type = fake.content_type(mime_type=MimeType.IMAGE)
    assert content_type == 'Content-Type: image/jpeg'


# Generated at 2022-06-23 21:20:29.945690
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    from mimesis.enums import PortRange
    from mimesis.providers.network import Network
    result = Internet().ip_v4_object()
    assert result.version == 4
    assert Network().port(port_range=PortRange.PRIVATE) > 1023


# Generated at 2022-06-23 21:20:31.654949
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    assert Internet().emoji() == ":laughing:"

# Generated at 2022-06-23 21:20:33.382055
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    for i in range(100):
        assert len(Internet().ip_v6()) > 0

# Generated at 2022-06-23 21:20:34.497091
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    return Internet().emoji()

# Generated at 2022-06-23 21:20:39.156776
# Unit test for constructor of class Internet
def test_Internet():
    internet1 = Internet()
    internet2 = Internet(seed=123456)
    internet3 = Internet(seed=654321)
    assert id(internet1) != id(internet2)
    assert internet2.seed == internet3.seed

if __name__ == '__main__':
    test_Internet()

# Generated at 2022-06-23 21:20:41.076684
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    for x in range(100):
        assert isinstance(Internet().http_status_code(), int)


# Generated at 2022-06-23 21:20:43.436639
# Unit test for method port of class Internet
def test_Internet_port():
    a = Internet().port(port_range=PortRange.TELNET)
    assert a >= 23 and a <= 23


# Generated at 2022-06-23 21:20:45.952421
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    internet = Internet()
    assert isinstance(internet.mac_address(), str)
    assert len(internet.mac_address()) == 17
    print(internet.mac_address())

# Generated at 2022-06-23 21:20:53.952134
# Unit test for constructor of class Internet
def test_Internet():
    # Test for Linux
    if 'Linux' in Internet().operating_system():
        assert Internet().content_type(mime_type=MimeType.IMAGE) == 'Content-Type: image/gif'
        assert Internet().http_status_message() == 'HTTP/1.1 200 OK'
        assert Internet().http_method() == 'POST'
        assert Internet().ip_v4() == '105.54.186.245'
        assert Internet().ip_v6() == '220b:fb2b:3a3a:bdc:e9b9:c9a6:b5c5:c241'
        assert Internet().mac_address() == '00:16:3e:d4:d1:3e'
        assert Internet().emoji() == '🎅'
        assert Internet().image_placeholder

# Generated at 2022-06-23 21:20:56.409903
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    internet = Internet(seed=4)
    assert internet.home_page() == "https://hong.info"

# Generated at 2022-06-23 21:21:07.273924
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    from mimesis.enums import Layer
    from mimesis.providers.internet import Internet
    internet = Internet()
    assert internet.network_protocol(layer=Layer.APPLICATION) in ['AMQP', 'XMPP', 'Z39.50']
    assert internet.network_protocol(layer=Layer.DATA_LINK) in ['ADCCP', 'ATM', 'AURP', 'AX.25']
    assert internet.network_protocol(layer=Layer.NETWORK) in ['EIGRP', 'ICMP', 'IDRP']
    assert internet.network_protocol(layer=Layer.PRESENTATION) in ['MPEG', 'PPP']
    assert internet.network_protocol(layer=Layer.SESSION) in ['NETBIOS', 'OSPF', 'RSVP']
    assert internet.network_

# Generated at 2022-06-23 21:21:10.351774
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    for i in range(100):
        hashtags = internet.hashtags()
        print(hashtags)
        print(type(hashtags))
        print('\n')

# Generated at 2022-06-23 21:21:12.759897
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    internet = Internet()
    assert isinstance(internet.ip_v6_object(), IPv6Address)

# Generated at 2022-06-23 21:21:14.473478
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    internet = Internet()
    print(internet.ip_v6_object())

# Generated at 2022-06-23 21:21:15.949102
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():

    internet = Internet()
    assert internet.http_status_message() in HTTP_STATUS_MSGS


# Generated at 2022-06-23 21:21:17.269369
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    internet = Internet()
    print(internet.ip_v4())


# Generated at 2022-06-23 21:21:19.420604
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    internet = Internet()
    assert internet.image_placeholder() == 'http://placehold.it/1920x1080'

# Generated at 2022-06-23 21:21:23.346043
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    # Required args
    width = 800
    height = 600
    # Call function
    img_placehold = Internet().image_placeholder(width, height)
    assert "http://placehold.it/800x600" == img_placehold

# Generated at 2022-06-23 21:21:24.958713
# Unit test for method port of class Internet
def test_Internet_port():
    from mimesis.enums import PortRange
    i = Internet()
    assert i.port(port_range=PortRange.ALL) > 0



# Generated at 2022-06-23 21:21:26.516030
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    for type in MimeType:
        print(Internet().content_type(type))


# Generated at 2022-06-23 21:21:27.804419
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    i = Internet()
    print(i.emoji())

# Generated at 2022-06-23 21:21:29.282435
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    assert len(Internet().http_status_message()) > 10
    

# Generated at 2022-06-23 21:21:32.112553
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
	internet = Internet()
	message = internet.http_status_message()
	assert message in HTTP_STATUS_MSGS


# Generated at 2022-06-23 21:21:39.858601
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    """The test case method used to test the top_level_domain method."""
    from mimesis.builtins import Random
    from mimesis.enums import TLDType

    class Inter(Internet):
        """Class for test."""

        def __init__(self):
            """Initialize attributes."""
            self._random = Random(123)

    i = Inter()
    assert i.top_level_domain(tld_type=TLDType.COUNTRY) == '.ac'
    assert i.top_level_domain(tld_type=TLDType.COMMERCIAL) == '.gratis'
    assert i.top_level_domain(tld_type=TLDType.SPAM) == '.fitness'

# Generated at 2022-06-23 21:21:45.778678
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    _internet = Internet()
    _layer = Layer.APPLICATION
    _protocol = _internet.network_protocol(layer=_layer)
    assert _internet._validate_enum(item=_layer, enum=Layer) == _layer.value
    assert _internet._validate_enum(item=_protocol, enum=Layer) == _protocol


# Generated at 2022-06-23 21:21:50.205477
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    internet = Internet()
    http_status_code = internet.http_status_code()
    if not isinstance(http_status_code, int):
        raise AssertionError("internet.http_status_code() should return an integer")

# Generated at 2022-06-23 21:21:56.364157
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    from mimesis.enums import Hashtag

    internet = Internet()
    assert internet.hashtags(quantity=2) == ['#travel', '#day']
    assert internet.hashtags(quantity=1) == '#nice'

    internet = Internet(seed=12345)
    assert internet.hashtags(quantity=3) == ['#cool', '#inspire', '#sunset']
    assert internet.hashtags(quantity=2) == ['#women', '#sun']
    assert internet.hashtags(quantity=1) == '#ship'

    # Test with mime types
    assert internet.hashtags(
        quantity=2,
        category=Hashtag.CULTURE_AND_ARTS
    ) == ['#portrait', '#love']


# Generated at 2022-06-23 21:21:58.981048
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    provider = Internet()
    print(provider.stock_image())
    print(provider.stock_image(width = 600 , height = 400))
    print(provider.stock_image(keywords = ["love" , "friends"]))
    print(provider.stock_image(writable = True))

if __name__ == "__main__":
    test_Internet_stock_image()

# Generated at 2022-06-23 21:22:00.703475
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    """Test result of method ip_v4_object of class Internet, check
    is IPV4Address object"""
    result = Internet().ip_v4_object()
    assert type(result) == IPv4Address


# Generated at 2022-06-23 21:22:02.547807
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    i = Internet(seed=2)
    assert i.user_agent() == 'Mozilla/5.0 (X11; Linux x86_64; rv:7.0; rv:7.1.1) Gecko/20100101 Firefox/3.5.2'


# Generated at 2022-06-23 21:22:04.674052
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    # TODO: test content_type method
    Internet().content_type()
    return True


# Generated at 2022-06-23 21:22:07.033261
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    ip = Internet('en').ip_v4_object()
    assert isinstance(ip, IPv4Address)


# Generated at 2022-06-23 21:22:16.528302
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    import unittest
    from mimesis.enums import TLDType
    from mimesis.exceptions import NonEnumerableError
    internet = Internet()
    count = 10000
    for _ in range(count):
        try:
            top_level_domain = internet.top_level_domain(tld_type=TLDType.ALL)
        except NonEnumerableError:
            top_level_domain = internet.top_level_domain()
        assert top_level_domain.endswith('.com')
    return

if __name__ == '__main__':
    test_Internet_home_page()

# Generated at 2022-06-23 21:22:18.074799
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    # Setup
    internet = Internet()
    # Exercise and Verify
    assert internet.ip_v6() == '2001:c244:cf9d:1fb1:c56d:f52c:8a04:94f3'



# Generated at 2022-06-23 21:22:27.459392
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    from mimesis.enums import TLDType

    internet = Internet()
    tld_types = [TLDType.COM, TLDType.ORG, TLDType.INFO]
    url = internet.home_page(tld_type=TLDType.COM)
    assert url.endswith('.com')
    url = internet.home_page(tld_type=TLDType.ORG)
    assert url.endswith('.org')
    url = internet.home_page(tld_type=TLDType.INFO)
    assert url.endswith('.info')


# Generated at 2022-06-23 21:22:29.032467
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    obj = Internet('ru')
    result = obj.stock_image()
    assert(isinstance(result, str))

# Generated at 2022-06-23 21:22:40.674776
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    instance_hashtags_1 = internet.hashtags()
    instance_hashtags_2 = internet.hashtags()
    instance_hashtags_3 = internet.hashtags(quantity=3)
    instance_hashtags_4 = internet.hashtags(quantity=1)
    assert isinstance(instance_hashtags_1, list)
    assert isinstance(instance_hashtags_2, list)
    assert isinstance(instance_hashtags_3, list)
    assert isinstance(instance_hashtags_4, str)
    assert len(instance_hashtags_1) == 4
    assert len(instance_hashtags_2) == 4
    assert len(instance_hashtags_3) == 3
    assert instance_hashtags_1 != instance_hashtags_2

# Generated at 2022-06-23 21:22:42.284907
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    """Test method ip_v4 of class Internet."""
    assert type(Internet().ip_v4()) is str


# Generated at 2022-06-23 21:22:44.280110
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    internet = Internet('en')
    tld = internet.top_level_domain(tld_type=TLDType.CCTLD)
    assert tld in TLD.CCTLD


# Generated at 2022-06-23 21:22:47.111371
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    user_agent = Internet().user_agent()
    print(user_agent)

if __name__ == "__main__":
    test_Internet_user_agent()


# Generated at 2022-06-23 21:22:52.500652
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    expected = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_0) AppleWebKit/536.3 (KHTML, like Gecko) Chrome/19.0.1063.0 Safari/536.3'
    assert Internet().user_agent() == expected


# Generated at 2022-06-23 21:22:57.345111
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from io import BytesIO

    from PIL import Image

    provider = Internet()
    data = provider.stock_image(width=200, height=100, writable=True)
    image = Image.open(BytesIO(data))
    assert image.width == 200
    assert image.height == 100
    assert image.format == 'JPEG'
    image.close()

# Generated at 2022-06-23 21:22:58.337768
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    pass
    
    

# Generated at 2022-06-23 21:23:03.012496
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    '''
    This function is used to test the method ip_v6 of class Internet
    '''
    my_internet = Internet()
    my_ip = my_internet.ip_v6()
    assert isinstance(my_ip, str)

# Generated at 2022-06-23 21:23:04.940071
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    http_method = Internet.http_method(Internet)
    assert http_method in HTTP_METHODS


# Generated at 2022-06-23 21:23:06.335633
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    net = Internet('ru')
    net.http_status_code() == 200

# Generated at 2022-06-23 21:23:10.102408
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    obj = Internet(seed=42)
    res = obj.hashtags(quantity=3)

    assert isinstance(res, list) and len(res) == 3
    assert res == ['#hello', '#puzzled', '#horror']


# Generated at 2022-06-23 21:23:12.229099
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    """Unit test for method ip_v4 of class Internet."""
    for _ in range(10):
        internet = Internet()
        print(internet.ip_v4())
        print(internet.ip_v4(with_port=True))



# Generated at 2022-06-23 21:23:14.377198
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    internet = Internet('en')
    assert isinstance(internet.ip_v6(), str)
    assert len(internet.ip_v6().split(':')) == 8


# Generated at 2022-06-23 21:23:16.422583
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    generator = Internet()
    response = generator.http_status_code()
    assert(type(response) == int)
    assert(response >= 0 and response <= 699)


# Generated at 2022-06-23 21:23:23.900639
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    """JSON file containing the results of Internet.image_placeholder.

    IMPORTANT:
    Each time this file is modified, we must regenerate the test file.
    This is done by running the test_Internet_image_placeholder()
    function in the mimesis.tests.test_internet module.
    """
    results = """{\n    "1920x1080": "http://placehold.it/1920x1080"\n}"""  # noqa
    with open('mimesis/tests/test_data/internet/image_placeholder.json', 'w') as fp:  # noqa
        fp.write(results)


# Generated at 2022-06-23 21:23:28.770086
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    internet = Internet()
    ip_v6 = internet.ip_v6_object()
    assert ip_v6 is not None
    print(ip_v6, type(ip_v6))


# Generated at 2022-06-23 21:23:30.098831
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    internet = Internet()
    tld = internet.top_level_domain()
    print(tld)

# Generated at 2022-06-23 21:23:32.880394
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    internet = Internet()
    status = internet.http_status_code()
    assert (status >= 100) and (status <= 599)


# Generated at 2022-06-23 21:23:35.331413
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    internet = Internet()
    domain = internet.home_page(tld_type=TLDType.MOST_COMMON)

    assert(domain)

# Generated at 2022-06-23 21:23:36.637615
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    print (Internet.ip_v4(Internet()))


# Generated at 2022-06-23 21:23:40.899112
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()

    # if quantity > 1
    assert internet.hashtags(quantity=5) == internet.hashtags(5)
    assert len(internet.hashtags(quantity=5)) == 5

    # if quantity == 1
    assert internet.hashtags(quantity=1) == internet.hashtags()
    assert len(internet.hashtags(quantity=1)) == 1

# Generated at 2022-06-23 21:23:42.505696
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    internet = Internet()
    method = internet.http_method()
    assert method in HTTP_METHODS


# Generated at 2022-06-23 21:23:49.413933
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    from mimesis.builtins import CyberSecurity
    from mimesis.enums import Layer
    from mimesis.providers.internet import Internet
    import ipaddress
    seeder = CyberSecurity(seed=1)
    internet = Internet(seed=1)
    assert isinstance(internet.ip_v4_object(), ipaddress.IPv4Address)
    assert internet.ip_v4_object() == ipaddress.IPv4Address('0.0.5.15')
    assert isinstance(internet.network_protocol(Layer.NETWORK), str)
    assert internet.network_protocol(Layer.NETWORK) == 'IP'

# Generated at 2022-06-23 21:23:51.350534
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    assert len(internet.hashtags(quantity=4)) == 4

# Generated at 2022-06-23 21:23:53.086247
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    provider = Internet()
    output = provider.home_page()
    assert type(output) == str



# Generated at 2022-06-23 21:23:57.361325
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    generator = Internet('en', 'internet')
    for _ in range(1000):
        result = generator.ip_v4()
        assert isinstance(result, str)
        assert len(result.split('.')) == 4


# Generated at 2022-06-23 21:24:05.609307
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    from mimesis.enums import Layer

    print("\n#####[Internet-Test]#####")
    print("\n#Emoji")
    internet = Internet()
    print("Emoji:", internet.emoji())
    print("\n#Home-Page")
    print("Random home page:", internet.home_page())
    print("\n#Port")
    print("Random port:", internet.port())
    print("\n#Network-Protocol")
    print("Random protocol:", internet.network_protocol(Layer.APPLICATION))
    print("\n#Top-Level-Domain")
    print("Random top level domain:", internet.top_level_domain())
    print("\n#IPv4-Address")
    print("Random IPv4 address:", internet.ip_v4())


# Generated at 2022-06-23 21:24:09.031286
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    internet = Internet()
    ip_v4 = internet.ip_v4_object()
    assert type(ip_v4) == IPv4Address

# Generated at 2022-06-23 21:24:11.074268
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    a = Internet()
    for i in range(1):
        print('ipv4 adress is:',a.ip_v4())

# Generated at 2022-06-23 21:24:12.377186
# Unit test for constructor of class Internet
def test_Internet():
    inte = Internet()
    assert inte != None


# Generated at 2022-06-23 21:24:15.228707
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    """Unit test for Internet.emoji().
    """
    internet = Internet()
    result = internet.emoji()
    assert result in EMOJI

# Generated at 2022-06-23 21:24:17.413429
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
	obj = Internet()
	assert obj.image_placeholder() == 'http://placehold.it/1920x1080'


# Generated at 2022-06-23 21:24:19.329906
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    i = Internet()
    a = i.http_status_message()
    print(a)


# Generated at 2022-06-23 21:24:24.422780
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    # Check that the network protocol with layer 4 is tcp
    assert Internet().network_protocol(layer=Layer.transport)=='tcp'
    
    # Check that the network protocol with layer 3 is ipv4
    assert Internet().network_protocol(layer=Layer.network)=='ipv4'


# Generated at 2022-06-23 21:24:26.407713
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    internet = Internet()

    image = internet.image_placeholder()
    assert image == 'http://placehold.it/1920x1080', image



# Generated at 2022-06-23 21:24:29.078873
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    internet = Internet()
    for _ in range(100):
        assert internet.top_level_domain(TLDType.COUNTRY_CODE) in ['.cn', '.be', '.cm']

# Generated at 2022-06-23 21:24:30.666368
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    http_method = Internet().http_method()
    assert http_method in HTTP_METHODS

# Generated at 2022-06-23 21:24:32.583104
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    internet = Internet()
    ip = internet.ip_v6()
    assert type(ip) is str


# Generated at 2022-06-23 21:24:35.894856
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    it = Internet(seed=42)
    expected = "2001:c244:cf9d:1fb1:c56d:f52c:8a04:94f3"
    assert it.ip_v6() == expected

# Generated at 2022-06-23 21:24:37.143624
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    internet = Internet()
    print(internet.top_level_domain())


# Generated at 2022-06-23 21:24:39.090491
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    try:
        Internet().content_type()
    except Exception as e:
        # print(e)
        return False
    return True


# Generated at 2022-06-23 21:24:43.435462
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    """Unit test for method http_status_code of class Internet."""
    from mimesis.enums import PortRange
    from mimesis.providers.digital.internet import Internet
    # Create object
    internet = Internet()
    # Call method
    internet.top_level_domain()
    # Call method
    internet.port(port_range=PortRange.NUMERICAL)
    # Call method
    internet.port()


# Generated at 2022-06-23 21:24:46.185708
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    internet = Internet()
    status_code = internet.http_method()
    assert status_code in HTTP_METHODS

# Generated at 2022-06-23 21:24:47.662842
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    inet = Internet()
    print(inet.emoji())


# Generated at 2022-06-23 21:24:51.515956
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    hash_tag_list = ['#love', '#sky', '#nice']
    internet = Internet()

    assert internet.hashtags() in hash_tag_list
    assert isinstance(internet.hashtags(), str)
    assert isinstance(internet.hashtags(2), list)

# Generated at 2022-06-23 21:25:01.564176
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    expectations = [
        'http://placehold.it/1920x1080',
        'http://placehold.it/100x100',
        'http://placehold.it/50x500',
        'http://placehold.it/500x500',
        'http://placehold.it/300x250',
        'http://placehold.it/800x600',
        'http://placehold.it/320x150',
        'http://placehold.it/700x500',
        'http://placehold.it/400x300',
        'http://placehold.it/2000x2000',
        'http://placehold.it/3000x3000',
        'http://placehold.it/0x0'
    ]

    internet = Internet()

# Generated at 2022-06-23 21:25:02.770760
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    internet = Internet()
    print(internet.mac_address())

# Generated at 2022-06-23 21:25:04.136774
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    myinternet = Internet()
    assert myinternet.http_method() in HTTP_METHODS

# Generated at 2022-06-23 21:25:08.523488
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    seed = 12345
    prng = random.Random(seed)
    test = Internet(random_instance=prng)
    assert test.user_agent() == 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:15.0) Gecko/20100101 Firefox/15.0.1'


# Generated at 2022-06-23 21:25:13.160464
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    """Test method http_status_message."""
    if __debug__:
        internet = Internet()
        test_http_status_message = internet.http_status_message()
        if not isinstance(test_http_status_message, str):
            raise AssertionError('Returned data is not valid.')


# Generated at 2022-06-23 21:25:15.954806
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    i = Internet()
    print(i.network_protocol(layer = Layer.APPLICATION))
    print(i.network_protocol(layer = Layer.PRESENTATION))


# Generated at 2022-06-23 21:25:19.021866
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    """Test Internet().ip_v6_object()"""
    ip = Internet().ip_v6_object()
    print(ip)


# Generated at 2022-06-23 21:25:20.088475
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    inet = Internet()
    assert inet.user_agent() in USER_AGENTS


# Generated at 2022-06-23 21:25:22.216226
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    stock_image = internet.stock_image()
    print(stock_image)

# Generated at 2022-06-23 21:25:25.954014
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    internet = Internet()
    res = internet.http_status_code()
    if res in HTTP_STATUS_CODES:
        print("HTTP_STATUS_CODES")
        print(res)
    else:
        print("Test failed")


# Generated at 2022-06-23 21:25:28.170879
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    internet = Internet()
    method = internet.http_method()
    assert method in ["GET", "POST", "PUT", "DELETE", "HEAD", "PATCH"]


# Generated at 2022-06-23 21:25:41.099816
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    ip = Internet.ip_v4()

# Generated at 2022-06-23 21:25:46.403455
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    internet = Internet()

    layer = Layer.APP
    protocol_name_from_method = internet.network_protocol(layer)

    print(protocol_name_from_method)
    assert protocol_name_from_method in NETWORK_PROTOCOLS[layer]


"""
from mimesis.enums import Layer

from mimesis.providers.internet import Internet

internet = Internet()

layer = Layer.APP
protocol_name_from_method = internet.network_protocol(layer)
print(protocol_name_from_method)
"""

# Generated at 2022-06-23 21:25:49.910882
# Unit test for constructor of class Internet
def test_Internet():
    """Test Internet constructor."""
    # This apply to all providers
    internet_provider = Internet()
    assert isinstance(internet_provider, Internet)
    assert isinstance(internet_provider.seed, int)

# Generated at 2022-06-23 21:25:52.571361
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    assert len(internet.hashtags()) > 0
    assert len(internet.hashtags(quantity=1)) > 0

# Generated at 2022-06-23 21:26:01.648644
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    import random
    import pytest
    from mimesis.enums import PortRange
    from mimesis.providers.internet import Internet
    from mimesis.providers.file import File
    from mimesis.providers.misc import Misc
    from mimesis.providers.person import Person
    random.seed(0)
    internet = Internet()
    misc = Misc()
    person = Person()
    file = File()

# Generated at 2022-06-23 21:26:04.972843
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    data = Internet().home_page()
    with open("data.txt", "a") as f:
        f.write("\n" + data + "\n")

test_Internet_home_page()

# Generated at 2022-06-23 21:26:07.467296
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    internet = Internet()
    method = internet.http_method()
    assert method in HTTP_METHODS


# Generated at 2022-06-23 21:26:10.268776
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    generator = Internet()
    ip_address = generator.ip_v4()
    assert str(ip_address) == "125.160.160.43"
    print(ip_address)


# Generated at 2022-06-23 21:26:11.864897
# Unit test for constructor of class Internet
def test_Internet():
    internet = Internet()
    assert internet is not None


# Generated at 2022-06-23 21:26:15.026449
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    """
    Unit test for method top_level_domain of class Internet
    """
    internet = Internet()
    domain = internet.top_level_domain()
    assert domain in TLD[TLDType.ALL]

# Generated at 2022-06-23 21:26:17.201259
# Unit test for constructor of class Internet
def test_Internet():
    internet = Internet()
    assert internet is not None
# test_Internet

# Generated at 2022-06-23 21:26:20.968751
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    choice = {}
    for i in range(1000):
        choice[i] = Internet().http_status_code()
    for i in choice:
        assert i in HTTP_STATUS_CODES
test_Internet_http_status_code()


# Generated at 2022-06-23 21:26:24.851830
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    internet = Internet()
    res = internet.user_agent()
    output = 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:15.0) Gecko/20100101 Firefox/15.0.1'
    assert res == output


# Generated at 2022-06-23 21:26:34.136917
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    i = Internet.__new__(Internet)
    i._random = random.Random()
    i.seed_instance(5)

    assert i.top_level_domain(TLDType.COUNTRY) == '.cn'
    assert i.top_level_domain(TLDType.GENERIC) == '.com'
    assert i.top_level_domain(TLDType.COMMUNITY) == '.ar'
    assert i.top_level_domain(TLDType.SPONSOR) == '.alsace'
    assert i.top_level_domain(TLDType.INFRASTRUCTURE) == '.local'


# Generated at 2022-06-23 21:26:36.008995
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    test_data = ["GET", "POST", "PUT", "DELETE", "OPTIONS", "HEAD", "TRACE", "CONNECT", "PATCH"]
    for i in range(100):
        assert Internet("en").http_method() in test_data

# Generated at 2022-06-23 21:26:37.307032
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    assert isinstance(internet.hashtags(), Union[str, list])

# Generated at 2022-06-23 21:26:39.772153
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    internet = Internet()
    # http_status_code()
    assert isinstance(internet.http_status_code(), int)


# Generated at 2022-06-23 21:26:45.278746
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    from mimesis.enums import HTTPStatusCode
    from mimesis.providers.datetime import Datetime
    print("Internet_http_status_code")
    for i in range(10):
        internet = Internet()
        print(internet.http_status_code())
        assert internet.http_status_code() in HTTPStatusCode.__members__

# Generated at 2022-06-23 21:26:47.804560
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    data = Internet()
    print(data.hashtags())
    print(data.hashtags(quantity=3))


# Generated at 2022-06-23 21:26:50.719065
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    t = Internet()
    for _ in range(10):
        mac = t.mac_address()
        assert len(mac) == 17
        assert isinstance(mac, str)

# Generated at 2022-06-23 21:26:52.742332
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    internet = Internet()
    assert isinstance(internet.ip_v4_object(), IPv4Address)

# Generated at 2022-06-23 21:26:58.234364
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    internet = Internet("en")
    test_set = set()
    for i in range(100):
        result = internet.mac_address()
        test_set.add(result)
        assert (isinstance(result, str)
                and len(result) == 17
                and result.count(":") == 5)
    assert len(test_set) > 1

# Generated at 2022-06-23 21:27:02.479903
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    """Unit test for method mac_address of class Internet"""

    from mimesis.enums import PortRange

    # Generate random port
    port = Internet().port(port_range=PortRange.WELL_KNOWN)
    assert  0 <= port <= 1023

# Generated at 2022-06-23 21:27:05.158758
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    """Test method Internet.ip_v6"""
    internet = Internet(seed=123)
    ip = internet.ip_v6()
    assert ip == '2001:c244:cf9d:1fb1:c56d:f52c:8a04:94f3'


# Generated at 2022-06-23 21:27:07.432634
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    provider = Internet()
    url = provider.stock_image(720, 1280, ['water', 'sports'], True)
    assert provider.stock_image(720, 1280) == url

# Generated at 2022-06-23 21:27:10.922269
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    i = Internet()
    ip = i.ip_v6()
    ip == '2001:c244:cf9d:1fb1:c56d:f52c:8a04:94f3'

# Generated at 2022-06-23 21:27:13.289439
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    """Unit test for method ip_v6 of class Internet."""
    ip = Internet().ip_v6()
    assert isinstance(ip, str)

# Generated at 2022-06-23 21:27:22.748828
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    from mimesis.enums import MimeType
    from mimesis.typing import MimeTypeType

    for _ in range(10):
        assert Internet.content_type() == 'Content-Type: image/jpeg'
        assert Internet.content_type(
            MimeType.AUDIO,
        ) == 'Content-Type: audio/wav'
        assert Internet.content_type(
            MimeType.VIDEO,
        ) == 'Content-Type: video/mpeg'
        assert Internet.content_type(
            MimeType.MULTIPART,
        ) == 'Content-Type: multipart/form-data'
        assert Internet.content_type(
            MimeType.TEXT,
        ) == 'Content-Type: text/plain'

# Generated at 2022-06-23 21:27:25.273525
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    provider = Internet()
    assert len(str(provider.image_placeholder())) > 0

# Generated at 2022-06-23 21:27:26.935980
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    internet = Internet()
    ip_v4_object = internet.ip_v4_object()
    assert isinstance(ip_v4_object, IPv4Address)


# Generated at 2022-06-23 21:27:30.020700
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    """Test method Internet.stock_image."""
    internet = Internet('en')
    assert internet.stock_image(
        keywords=['computer', 'people']
    ) == 'https://source.unsplash.com/1920x1080/?computer,people'
    assert internet.stock_image(
        width='800', height='600',
        keywords=['computer', 'people']
    ) == 'https://source.unsplash.com/800x600/?computer,people'



# Generated at 2022-06-23 21:27:41.064311
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    # ある程度固定して値を取得することでテストを書く
    internet1 = Internet(seed=1)
    result = internet1.top_level_domain()
    assert result == '구시가지'

    internet2 = Internet(seed=2)
    result = internet2.top_level_domain()
    assert result == '도메인'

    internet3 = Internet(seed=3)
    result = internet3.top_level_domain()
    assert result == '公司'

    internet4 = Internet(seed=4)
    result = internet4.top_level_domain()
    assert result == '网络'


# Generated at 2022-06-23 21:27:46.507998
# Unit test for method port of class Internet
def test_Internet_port():
    print("Method Internet.port")
    i = Internet()
    port_tcp = i.port(port_range=PortRange.TCP)
    port_udp = i.port(port_range=PortRange.UDP)
    port_all = i.port(port_range=PortRange.ALL)
    assert (port_tcp>=0) and (port_tcp<=65535)
    assert (port_udp>=0) and (port_udp<=65535)
    assert (port_all>=0) and (port_all<=65535)
    print("Done")
        
    return


# Generated at 2022-06-23 21:27:49.353811
# Unit test for constructor of class Internet
def test_Internet():
    internet = Internet('en')
    # print(internet.port())
    print(internet.top_level_domain())

# Generated at 2022-06-23 21:27:50.779085
# Unit test for constructor of class Internet
def test_Internet():
    en = Internet()
    print(en.ip_v4(port_range=2))

# Generated at 2022-06-23 21:27:55.220683
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    ipv6_address = Internet().ip_v6_object()
    print(ipv6_address)  # prints IPv6Address('d5e0:a98c:e06:7e2b:d1ca:1e1c:9b7f:8cac')

test_Internet_ip_v6_object()

# Generated at 2022-06-23 21:27:57.439323
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    # Set up
    provider = Internet()
    obj = provider.ip_v4_object()

    # Test
    assert isinstance(obj, IPv4Address)


# Generated at 2022-06-23 21:27:59.353443
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    internet = Internet()
    protocols = internet.network_protocol(Layer.APPLICATION)
    print(protocols)
    assert protocols

# Generated at 2022-06-23 21:28:00.252663
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    ob = Internet()
    print(ob.emoji())

# Generated at 2022-06-23 21:28:04.372724
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    def a(internet, repeat=100000):
        for _ in range(repeat):
            internet.http_status_message()

    from timeit import timeit
    seed = 0
    internet = Internet(seed=seed)
    print(timeit(lambda: a(internet), number=1000))

    seed = 1
    internet = Internet(seed=seed)
    print(timeit(lambda: a(internet), number=1000))



# Generated at 2022-06-23 21:28:05.628700
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    gen = Internet()
    c = gen.http_status_code()
    print(c)


# Generated at 2022-06-23 21:28:07.770680
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    Inter=Internet()
    agent_list=Inter.user_agent()
    print(agent_list)


# Generated at 2022-06-23 21:28:13.890155
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    assert Internet().network_protocol(
        layer=Layer.LINK,
    ) in NETWORK_PROTOCOLS[Layer.LINK]
    assert Internet().network_protocol(
        layer=Layer.TRANSPORT,
    ) in NETWORK_PROTOCOLS[Layer.TRANSPORT]
    assert Internet().network_protocol(
        layer=Layer.APPLICATION,
    ) in NETWORK_PROTOCOLS[Layer.APPLICATION]

# Generated at 2022-06-23 21:28:14.837672
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from mimesis import Internet
    print(Internet().stock_image())

# Generated at 2022-06-23 21:28:15.757856
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    assert Internet().http_status_code() in HTTP_STATUS_CODES

# Generated at 2022-06-23 21:28:22.714884
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    internet = Internet(seed=0)

    assert internet.ip_v6() == '5c5a:e5a5:7f5b:04ae:1f9b:c4de:4da4:2c85'
    assert internet.ip_v6() == 'd0f9:9a9b:a5b8:0c5e:68b4:b7ba:b5e5:7d38'
    assert internet.ip_v6() == 'b611:b01d:2e2e:8bff:de71:f971:012c:1b6e'
    assert internet.ip_v6() == '4044:eeb6:ec05:9194:30c8:6f0a:6d1e:b7e6'
    assert internet.ip

# Generated at 2022-06-23 21:28:25.940190
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    """Test Internet.content_type()."""
    internet = Internet()
    assert internet.content_type(MimeType.APPLICATION) == 'Content-Type: application/json'


# Generated at 2022-06-23 21:28:28.039666
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    inter = Internet()
    answer = inter.ip_v4_object()
    assert isinstance(answer, IPv4Address) == True


# Generated at 2022-06-23 21:28:31.857977
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    from mimesis.enums import PortRange
    from mimesis.providers.internet import Internet

    internet = Internet()
    r1 = internet.ip_v4_object()
    r2 = internet.ip_v4_object()
    assert (r1 != r2)
    assert ((r1.version == 4) and (r2.version == 4))



# Generated at 2022-06-23 21:28:33.552455
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    o = Internet("fa")
    assert o.content_type().startswith("Content-Type")


# Generated at 2022-06-23 21:28:36.771168
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    internet = Internet(seed=42)
    ipv6_object = internet.ip_v6_object()
    assert str(ipv6_object) == '2001:c244:cf9d:1fb1:c56d:f52c:8a04:94f3'


# Generated at 2022-06-23 21:28:37.934472
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    internet = Internet(seed = 0)
    result = internet.http_status_message()
    assert result == "200 OK"

# Generated at 2022-06-23 21:28:40.144377
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    generator = Internet()
    status = generator.http_status_message()
    assert (status in HTTP_STATUS_MSGS)


# Generated at 2022-06-23 21:28:43.677217
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    internet = Internet()
    status_message = internet.http_status_message()
    print(status_message)
    assert status_message in HTTP_STATUS_MSGS
# test_Internet_http_status_message()


# Generated at 2022-06-23 21:28:52.287901
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    from mimesis.data import USERNAMES
    from mimesis.providers.internet import Internet
    from mimesis.enums import TLDType

    internet = Internet()
    tld_type = TLDType.GOOGLE_APPS
    tlds = internet.top_level_domain(tld_type)
    assert tlds in TLD[tld_type.name]
    for _ in range(100):
        homepage = internet.home_page(tld_type)
        assert homepage != None
        assert tlds in homepage
        assert 'https://' in homepage


# Generated at 2022-06-23 21:28:54.985291
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    internet = Internet()
    http_status_message = internet.http_status_message()
    print(http_status_message)

    assert http_status_message == "401 Unauthorized"


# Generated at 2022-06-23 21:28:55.818320
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    assert Internet().http_method() in HTTP_METHODS

# Generated at 2022-06-23 21:28:58.790580
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    user_agent = 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:15.0) Gecko/20100101 Firefox/15.0.1'
    assert user_agent == Internet().user_agent()

# Generated at 2022-06-23 21:29:00.012001
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    print(
        Internet.image_placeholder()
    )


# Generated at 2022-06-23 21:29:01.517872
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    c = Internet()
    for _ in range(10):
        print(c.home_page())


# Generated at 2022-06-23 21:29:04.333198
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    internet = Internet()
    result_1 = internet.mac_address()
    result_2 = internet.mac_address()
    assert result_1 != result_2

# Generated at 2022-06-23 21:29:07.489597
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    generator = Internet()
    http_status_message = generator.http_status_message()
    assert isinstance(http_status_message, str)


# Generated at 2022-06-23 21:29:14.223000
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    inter = Internet()
    result = set()
    for _ in range(10):
        result.add(inter.http_status_message())
    print(result)
    # {'206 Partial Content', '504 Gateway Time-out', '201 Created', '412 Precondition Failed', '200 OK', '502 Bad Gateway', '404 Not Found', '505 HTTP Version not supported', '403 Forbidden', '401 Unauthorized'}

# Generated at 2022-06-23 21:29:19.626458
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    from mimesis.enums import Browser
    from mimesis.providers.internet import Internet
    internet = Internet()
    user_agent = internet.user_agent()
    try:
        user_agent.index('Mozilla/5.0')
        internet.browser()
    except ValueError:
        return False
    except AttributeError:
        return False
    return True


# Generated at 2022-06-23 21:29:24.602031
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    # TypeError: port must be an integer.
    internet.stock_image(port=8008)
    # TypeError: width must be an integer.
    internet.stock_image(width='800')
    # TypeError: height must be an integer.
    internet.stock_image(height='600')
    # TypeError: keywords must be a list.
    internet.stock_image(keywords='nature')
    # TypeError: keywords must be a list of string.
    internet.stock_image(keywords=[1, 2, 3])

# Generated at 2022-06-23 21:29:25.748955
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    Internet.top_level_domain()

# Generated at 2022-06-23 21:29:27.875442
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    test_Internet = Internet()
    test_hashtags = test_Internet.hashtags(quantity = 5)
    print(test_hashtags)

# Generated at 2022-06-23 21:29:32.366322
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    from mimesis.enums import MimeType
    from .utils import get_data

    data = get_data()
    assert MimeType.AUDIO.value in data

    for i in data:
        assert i.startswith('Content-Type: ')



# Generated at 2022-06-23 21:29:35.030989
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    internet = Internet()
    user_agent = internet.user_agent()
    print("user_agent:",user_agent)

test_Internet_user_agent()

# Generated at 2022-06-23 21:29:37.088348
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    internet = Internet()
    mac = internet.mac_address()
    print(mac)


# Generated at 2022-06-23 21:29:39.074534
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    internet = Internet()
    for _ in range(100):
        assert internet.http_method() in HTTP_METHODS

# Generated at 2022-06-23 21:29:41.026810
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    ip = Internet.ip_v6()
    assert (len(ip.split(':'))) == 8
