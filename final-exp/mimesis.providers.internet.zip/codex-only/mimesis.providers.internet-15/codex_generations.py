

# Generated at 2022-06-23 21:19:43.908839
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    internet = Internet()
    res = internet.home_page()
    assert isinstance(res, str)

# Generated at 2022-06-23 21:19:48.582928
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    """Get a random user agent."""
    internet = Internet()
    assert internet.user_agent() == 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.2.13) Gecko/20101203 Firefox/3.6.13'

# Generated at 2022-06-23 21:19:52.278138
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    """Unit test for method ip_v6_object of class Internet."""
    internet = Internet()
    ip_v6 = internet.ip_v6_object()
    print(ip_v6)


# Generated at 2022-06-23 21:19:54.521935
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    print(Internet.ip_v4())
    print(Internet.ip_v4(with_port=True))
    return "\n"


# Generated at 2022-06-23 21:19:56.093759
# Unit test for method port of class Internet
def test_Internet_port():
    int = Internet()
    port = int.port()
    assert port in range(1024, 65535)

# Generated at 2022-06-23 21:19:57.444799
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    ip_v6 = Internet().ip_v6()
    assert isinstance(ip_v6, str)

# Generated at 2022-06-23 21:20:00.628272
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    internet = Internet()
    image_url = internet.image_placeholder(width=600, height=600)
    assert image_url == 'http://placehold.it/600x600'



# Generated at 2022-06-23 21:20:03.427302
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():

    # Test 1
    provider = Internet()
    status_code = provider.http_status_code()
    assert status_code in HTTP_STATUS_CODES


# Generated at 2022-06-23 21:20:05.081155
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    obj = Internet()
    assert len(obj.content_type()) == 19


# Generated at 2022-06-23 21:20:11.398941
# Unit test for method port of class Internet
def test_Internet_port():
    internet = Internet()

    assert internet.port() >= PortRange.ALL.value[0]
    assert internet.port() <= PortRange.ALL.value[1]

    assert internet.port(PortRange.WELL_KNOWN.value) >= PortRange.WELL_KNOWN.value[0]
    assert internet.port(PortRange.WELL_KNOWN.value) <= PortRange.WELL_KNOWN.value[1]

    assert internet.port(PortRange.REGISTERED.value) >= PortRange.REGISTERED.value[0]
    assert internet.port(PortRange.REGISTERED.value) <= PortRange.REGISTERED.value[1]

    assert internet.port(PortRange.PRIVATE.value) >= PortRange.PRIVATE.value[0]
    assert internet.port(PortRange.PRIVATE.value)

# Generated at 2022-06-23 21:20:13.404554
# Unit test for constructor of class Internet
def test_Internet():
    obj = Internet()
    assert obj


if __name__ == '__main__':
    test_Internet()

# Generated at 2022-06-23 21:20:15.334520
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    internet = Internet()
    assert internet.top_level_domain(TLDType.POPULAR) in TLD.POPULAR


# Generated at 2022-06-23 21:20:18.500407
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    internet = Internet()
    protocol = internet.network_protocol(Layer.TRANSPORT)
    assert protocol in NETWORK_PROTOCOLS[Layer.TRANSPORT]

# Generated at 2022-06-23 21:20:22.996970
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    from mimesis.enums import FileType
    from mimesis.providers.internet import Internet
    internet = Internet()
    assert internet.content_type(FileType.ARCHIVE) == 'Content-Type: application/zip'


# Generated at 2022-06-23 21:20:26.119179
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    internet = Internet()
    result = internet.top_level_domain()

    assert type(result) == str, 'Result is not a string.'
    assert result in TLD['all']

# Generated at 2022-06-23 21:20:27.531665
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    assert Internet().hashtags()

# Generated at 2022-06-23 21:20:33.644095
# Unit test for constructor of class Internet
def test_Internet():
    internet = Internet()
    hash = internet.hashtags()
    print("internet.hashtags():", hash)
    tld = internet.top_level_domain()
    print("internet.top_level_domain():", tld)
    usr = internet.user_agent()
    print("internet.user_agent():", usr)
    net = internet.network_protocol()
    print("internet.network_protocol():", net)
    port = internet.port()
    print("internet.port(): ", port)
    home = internet.home_page()
    print("internet.home_page():", home)
    ip = internet.ip_v6()
    print("internet.ip_v6():", ip)
if __name__ == '__main__':
    test_Internet()


# Generated at 2022-06-23 21:20:35.643435
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    status = Internet().http_status_message()
    assert isinstance(status, str)


# Generated at 2022-06-23 21:20:37.768411
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    seed(1)
    assert Internet().network_protocol(Layer.L7) == 'AMQP'

# Generated at 2022-06-23 21:20:40.315626
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    from mimesis.providers.internet import Internet
    from mimesis.enums import HTTPMessage

    status_message = Internet().http_status_message()
    assert type(status_message) is str

    http_message = HTTPMessage()
    status_message = Internet().http_status_message()
    assert status_message in http_message


# Generated at 2022-06-23 21:20:41.286878
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    assert Internet.image_placeholder(800,600) == 'http://placehold.it/800x600'

# Generated at 2022-06-23 21:20:43.734046
# Unit test for method port of class Internet
def test_Internet_port():
   internet = Internet()
   k = internet.port(PortRange.ALL)
   assert k >= 0 and k <= 65535


# Generated at 2022-06-23 21:20:48.247165
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    internet = Internet()
    print(internet.ip_v6_object())
    print(internet.ip_v6_object())
    print(internet.ip_v6_object())
    # IPv6Address('2a02:20c0:e5d5:5cfb:5367:6d31:9caa:1dea')
    # IPv6Address('3ff3:f6c3:2d8d:cbc9:59ba:6ef2:6e65:1f54')
    # IPv6Address('7b8d:dac0:de1d:22a8:c138:75d2:4a4f:eb1f')


# Generated at 2022-06-23 21:20:52.149706
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    """Create a Internet object and call method top_level_domain."""
    from mimesis import Internet
    internet = Internet('es')
    tld = internet.top_level_domain()
    
    print("method top_level_domain returns: " + tld)
    assert tld == ".es"
    

# Generated at 2022-06-23 21:20:53.856855
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    int_ = Internet()
    assert isinstance(int_.emoji(), str)
    assert len(int_.emoji()) > 0



# Generated at 2022-06-23 21:20:58.362807
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    ip = Internet()
    assert len(ip.ip_v4().split('.')) == 4
    assert len(ip.ip_v4(with_port=True).split('.')) == 4
    print(ip.port())
    print(ip.port(PortRange.WELL_KNOWN))
    print(ip.port(PortRange.PRIVATE))


# Generated at 2022-06-23 21:21:07.745470
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    from mimesis.enums import HttpStatusCode
    from mimesis.enums import HttpStatusMessage
    list1 = []
    for i in HttpStatusCode:
        list1.append(i.value)

    list2 = []
    for i in HttpStatusMessage:
        list2.append(i.value)

    list1.sort()
    list2.sort()

    m = Internet()
    x = m.http_status_message()
    try:
        list1.index(x)  # check x exist in http_status_code
        list2.index(x)  # check x exist in http_status_message
    except ValueError:
        assert False, "x not exist in both http_status_code or http_status_message"

# Generated at 2022-06-23 21:21:10.351839
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    internet = Internet()
    ip = internet.ip_v4_object()
    assert ip.compressed == '19.121.223.58'


# Generated at 2022-06-23 21:21:14.153015
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    for i in range(10):
        hashtags = internet.hashtags()
        assert len(hashtags) == 4
        assert isinstance(hashtags, list)


# Generated at 2022-06-23 21:21:18.449395
# Unit test for method port of class Internet
def test_Internet_port():
    scheme = Internet()
    # scheme.port(PortRange.ALL)
    scheme.port(PortRange.WELL_KNOWN)
    scheme.port(PortRange.REGISTERED)
    scheme.port(PortRange.PRIVATE)
    scheme.port(PortRange.DYNAMIC)


# Generated at 2022-06-23 21:21:19.588759
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    print(Internet().stock_image(writable=True))

# Generated at 2022-06-23 21:21:21.184369
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    assert Internet.http_status_code() in HTTP_STATUS_CODES

# Generated at 2022-06-23 21:21:30.451013
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    assert Internet().top_level_domain() in TLD[TLDType.ALL]
    assert Internet().top_level_domain(TLDType.COMMERCIAL) in TLD[TLDType.COMMERCIAL]
    assert Internet().top_level_domain(TLDType.COUNTRY) in TLD[TLDType.COUNTRY]
    assert Internet().top_level_domain(TLDType.COUNTRY_CODE) in TLD[TLDType.COUNTRY_CODE]
    assert Internet().top_level_domain(TLDType.GENERIC) in TLD[TLDType.GENERIC]
    assert Internet().top_level_domain(TLDType.GENERIC_RESTRICTED) in TLD[TLDType.GENERIC_RESTRICTED]
    assert Internet().top

# Generated at 2022-06-23 21:21:32.832709
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    internet = Internet()
    assert internet.http_method() in HTTP_METHODS


# Generated at 2022-06-23 21:21:34.244498
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    internet = Internet()
    method = internet.http_method()
    assert len(internet.http_method()) == len(method)


# Generated at 2022-06-23 21:21:38.134712
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    internet = Internet()
    mac_address = internet.mac_address()
    assert len(mac_address) == 2 * 5 - 1
    mac_address_list = mac_address.split(':')
    assert len(mac_address_list) == 6
    for value in mac_address_list:
        assert int(value, 16) < 256


# Generated at 2022-06-23 21:21:46.615903
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    """Unit test for method network_protocol of class Internet."""
    from mimesis.enums import Layer
    from mimesis.exceptions import NonEnumerableError

    internet = Internet()
    protocol = internet.network_protocol(layer=Layer.L4)
    assert protocol in [
        'ICPM',
        'SCTP',
        'TCP',
        'UDP',
    ]
    try:
        protocol = internet.network_protocol(layer='L4')
    except NonEnumerableError:
        assert True
    else:
        assert False

# Generated at 2022-06-23 21:21:49.545136
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    ip = Internet().ip_v4()
    assert isinstance(ip, str)
    assert '.' in ip
    assert len(ip.split('.')) == 4
    assert isinstance(Internet().ip_v4_object(), IPv4Address)


# Generated at 2022-06-23 21:21:51.822692
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    provider = Internet()
    assert(provider.http_method() in HTTP_METHODS)


# Generated at 2022-06-23 21:21:53.457201
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    x = Internet()
    x.http_method()
    assert True


# Generated at 2022-06-23 21:21:56.630747
# Unit test for constructor of class Internet
def test_Internet():
    provider = Internet(seed=454545)
    assert isinstance(provider, Internet)
    assert isinstance(provider.random, int)
    assert provider.seed == 454545


# Generated at 2022-06-23 21:22:00.439623
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    dataInternet = Internet()
    assert dataInternet.user_agent() is not None, "Should not be null"
    assert dataInternet.user_agent() is not "", "Should not be empty"
    assert type(dataInternet.user_agent()) is str, "Should be a string"


# Generated at 2022-06-23 21:22:06.056654
# Unit test for method port of class Internet
def test_Internet_port():
    """
    Verify if the method return a random port.

    :return: True if the port is in range and False otherwise
    """
    internet = Internet()

    port_num = internet.port()
    if (port_num >= 0 and port_num <= 65535):
        return True
    return False


# Generated at 2022-06-23 21:22:09.631274
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    internetObj = Internet()
    print(internetObj.network_protocol(layer=Layer.APPLICATION))

if __name__ == '__main__':
    test_Internet_network_protocol()

# Generated at 2022-06-23 21:22:18.628726
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    from mimesis.enums import Field
    from mimesis.providers.datetime import Datetime
    from mimesis.typing import Seed

    internet = Internet(seed=Seed(123456789))
    dt = Datetime(seed=Seed(123456789))

    assert internet.mac_address() == '00:16:3e:3d:3f:3b'

    internet = Internet(seed=Seed(dt.now(Field.MILLISECOND)))
    assert internet.mac_address() == '00:16:3e:9f:0c:7f'



# Generated at 2022-06-23 21:22:19.434101
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    assert Internet().http_method() in HTTP_METHODS

# Generated at 2022-06-23 21:22:21.685718
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    ip_v6 = IPv6Address(240080102805656039834366917577231655624)
    internet = Internet()
    ip = internet.ip_v6_object()
    assert ip == ip_v6

# Generated at 2022-06-23 21:22:28.153220
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    '''
    Testing the expected behavior of the method ip_v6 from class Internet.

    :return: True if the behavior is as expected, False otherwise
    '''
    from mimesis.enums import TLDType

    internet = Internet()

    result = internet.ip_v6()
    assert isinstance(result, str)

    if ':' in result:
        pass
    else:
        return False

    return True


# Generated at 2022-06-23 21:22:31.115108
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    internet = Internet()
    mac_address = internet.mac_address()
    assert len(mac_address) == 17


# Generated at 2022-06-23 21:22:32.825896
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
	internet = Internet()
	print(internet.http_status_message())	#Should print: 200 OK


# Generated at 2022-06-23 21:22:37.368929
# Unit test for method port of class Internet
def test_Internet_port():
    port1 = Internet().port()
    assert 0 <= port1 <= 65536

    port2 = Internet().port(port_range=PortRange.WELL_DEFINED)
    assert 0 <= port2 <= 1024



# Generated at 2022-06-23 21:22:39.696346
# Unit test for constructor of class Internet
def test_Internet():
    """Test constructor of class Internet"""

    obj_internet = Internet(seed=123)
    assert obj_internet.seed == 123


# Generated at 2022-06-23 21:22:43.594013
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    """Unit test for method hashtags."""
    internet = Internet()
    test_data = [1, 2, 3, 4, 5, 6]
    for _ in test_data:
        result = internet.hashtags(quantity=_)
        assert isinstance(result, Union[str, list])
        if isinstance(result, list):
            assert len(result) == _



# Generated at 2022-06-23 21:22:46.338722
# Unit test for method port of class Internet
def test_Internet_port():
    internet = Internet()
    port = internet.port()
    assert isinstance(port, int)
    assert (0 < port) and (port < 65535)

# Generated at 2022-06-23 21:22:56.501256
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    print('Network protocols:')

    internet = Internet('en')
    print('Transport layer: {}'.format(
        internet.network_protocol(layer=Layer.TRANSPORT)),
    )
    print('Network layer: {}'.format(
        internet.network_protocol(layer=Layer.NETWORK)),
    )
    print('Data-link layer: {}'.format(
        internet.network_protocol(layer=Layer.DATA_LINK)),
    )
    print('Physical layer: {}'.format(
        internet.network_protocol(layer=Layer.PHYSICAL)),
    )
    print('All layers: {}'.format(
        internet.network_protocol(layer=Layer.ALL)),
    )


# Generated at 2022-06-23 21:22:58.562188
# Unit test for constructor of class Internet
def test_Internet():
    internet = Internet()
    assert internet is not None
    assert internet.seed is not None
    assert Internet(seed=internet.seed) is not None

# Generated at 2022-06-23 21:23:02.860979
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    print('Testing Internet ip_v4_object')
    data = Internet()
    ip_v4 = data.ip_v4_object()
    print(ip_v4)
    assert type(ip_v4) == IPv4Address



# Generated at 2022-06-23 21:23:04.786893
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    assert(len(str(Internet().ip_v4_object())) == 3)


# Generated at 2022-06-23 21:23:06.645469
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    internet = Internet(random_state=0)
    print('\n\nинтернет.эмодзи() -> ' + internet.emoji())



# Generated at 2022-06-23 21:23:08.524848
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    inter_net = Internet()
    print(inter_net.ip_v4())


# Generated at 2022-06-23 21:23:11.620826
# Unit test for method port of class Internet
def test_Internet_port():
    internet = Internet()
    assert isinstance(internet.port(port_range=PortRange.ALL), int)
    assert isinstance(internet.port(port_range=PortRange.WELL_KNOWN), int)


# Generated at 2022-06-23 21:23:14.074389
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    provider=Internet()
    print(provider.emoji())


# Generated at 2022-06-23 21:23:23.391468
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    from mimesis.enums import PortRange
    from mimesis.providers.internet import Internet
    from random import seed
    from random import randint
    from random import choice

    seed(6)
    ip_range = range(0, 4294967295)
    port_range = PortRange.ALL.value

    i = Internet('ru')

    assert i.ip_v4(False) in ip_range
    assert i.ip_v4(True) in ip_range
    assert i.ip_v4(False) in ip_range
    assert i.ip_v4(True) in ip_range
    assert i.ip_v4(False) in ip_range
    assert i.ip_v4(True) in ip_range
    assert i.ip_v4(False) in ip_range

# Generated at 2022-06-23 21:23:26.477625
# Unit test for constructor of class Internet
def test_Internet():
    obj = Internet()
    Internet(seed=None, locale='en')

# Generated at 2022-06-23 21:23:31.129030
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    internet = Internet()
    ip_v4 = internet.ip_v4()
    assert isinstance(ip_v4, str)
    ip_v4_object = internet.ip_v4_object()
    assert isinstance(ip_v4_object, type(IPv4Address(1)))


# Generated at 2022-06-23 21:23:33.532972
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    # GIVEN
    internet = Internet()
    # WHEN
    method = internet.http_method()
    # THEN
    assert method in HTTP_METHODS

# Generated at 2022-06-23 21:23:35.561348
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    provider = Internet()
    assert isinstance(provider.http_status_message(), str)



# Generated at 2022-06-23 21:23:39.942195
# Unit test for method port of class Internet
def test_Internet_port():
    port_range = PortRange.ALL
    test1 = Internet().port(port_range)
    assert test1 in range(65535)

    port_range = PortRange.FAIR
    test2 = Internet().port(port_range)
    assert test2 in range(1024, 49151)

    port_range = PortRange.PRIVATE
    test3 = Internet().port(port_range)
    assert test3 in range(49152, 65535)

    port_range = PortRange.RESERVED
    test4 = Internet().port(port_range)
    assert test4 in range(0, 1024)


# Generated at 2022-06-23 21:23:43.300407
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    internet = Internet()
    port = internet.http_method()
    test = False
    for i in port in HTTP_METHODS:
        if port == i:
            test = True
        else:
            test = False
    assert test is True

# Generated at 2022-06-23 21:23:44.861623
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    inst = Internet()
    # test method is called
    assert inst.ip_v4_object()



# Generated at 2022-06-23 21:23:48.004973
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    internet = Internet()
    ip_v4_object = internet.ip_v4_object()
    assert isinstance(ip_v4_object, IPv4Address)


# Generated at 2022-06-23 21:23:52.117289
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    ip = Internet().ip_v6()
    assert type(ip) == str
    assert len(ip.split(':')) == 8
    assert len(ip.strip(':')) == 32

# Generated at 2022-06-23 21:23:55.681996
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():      
    assert Internet().ip_v6() == '2001:c244:cf9d:1fb1:c56d:f52c:8a04:94f3'
    

# Generated at 2022-06-23 21:23:56.612312
# Unit test for constructor of class Internet
def test_Internet():
    i = Internet()
    assert i is not None


# Generated at 2022-06-23 21:24:00.159762
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    a = Internet()
    b = a.image_placeholder()
    a.set_random_state(2)
    c = a.image_placeholder()
    assert b != c
    assert b == 'http://placehold.it/1920x1080'


# Generated at 2022-06-23 21:24:07.866626
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from mimesis.builtins import Generic
    import unittest

    gen = Generic('en')
    class UnitTestCase(unittest.TestCase):
        def setUp(self):
            self.file_path = gen.file_path(writable=True)
            self.width = gen.code.random_number(number_type=int, minimum=1, maximum=2048)
            self.height = gen.code.random_number(number_type=int, minimum=1, maximum=2048)
            self.keywords = ['foo', 'bar', 'biz']
        def test_return_value_with_default_arg(self):
            class_ = Internet()
            result = class_.stock_image()

# Generated at 2022-06-23 21:24:09.927870
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    provider = Internet()
    assert 6 == len(provider.mac_address().split(':'))


# Generated at 2022-06-23 21:24:11.574351
# Unit test for constructor of class Internet
def test_Internet():
    provider = Internet('ru')
    assert provider.locale == 'ru'



# Generated at 2022-06-23 21:24:14.500330
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    """
    test_Internet_http_status_message()
    """
    internet = Internet()
    http_status_message = internet.http_status_message()
    assert isinstance(http_status_message, str)


# Generated at 2022-06-23 21:24:24.164506
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    from mimesis.enums import MimeType

    i = Internet('en')
    contentType = i.content_type(MimeType.PDF)
    assert contentType in [
        'Content-Type: application/pdf',
        'Content-Type: application/x-pdf',
        'Content-Type: text/pdf',
        'Content-Type: text/x-pdf',
    ]
    assert i.content_type() in [
        'Content-Type: application/pdf',
        'Content-Type: application/x-pdf',
        'Content-Type: text/pdf',
        'Content-Type: text/x-pdf',
    ]


# Generated at 2022-06-23 21:24:26.620451
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    internet = Internet()
    ipv6 = internet.ip_v6()
    assert(type(ipv6) == str)
    assert(type (IPv6Address(ipv6).exploded) == str)

# Generated at 2022-06-23 21:24:28.231775
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    internet = Internet()
    assert isinstance(internet.ip_v4(), str)


# Generated at 2022-06-23 21:24:31.359285
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    """Unit test for method ip_v4 of class Internet."""
    internet = Internet()
    ipv4 = internet.ip_v4()
    assert len(ipv4.split('.')) == 4

# Generated at 2022-06-23 21:24:36.284792
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    from mimesis import Internet
    r = Internet()
    first_home_page = r.home_page()
    print(f"first_home_page: {first_home_page}")
    second_home_page = r.home_page()
    print(f"second_home_page: {second_home_page}")
test_Internet_home_page()

# Generated at 2022-06-23 21:24:43.883001
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    internetProvider = Internet()
    assert internetProvider.network_protocol() in NETWORK_PROTOCOLS[Layer.APPLICATION]
    assert internetProvider.network_protocol(Layer.APPLICATION) in NETWORK_PROTOCOLS[Layer.APPLICATION]
    assert internetProvider.network_protocol(Layer.PRESENTATION) in NETWORK_PROTOCOLS[Layer.PRESENTATION]
    assert internetProvider.network_protocol(Layer.SESSION) in NETWORK_PROTOCOLS[Layer.SESSION]
    assert internetProvider.network_protocol(Layer.TRANSPORT) in NETWORK_PROTOCOLS[Layer.TRANSPORT]
    assert internetProvider.network_protocol(Layer.NETWORK) in NETWORK_PROTOCOLS[Layer.NETWORK]
    assert internetProvider.network_prot

# Generated at 2022-06-23 21:24:45.213455
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    provider = Internet()
    ip_v6 = provider.ip_v6_object()
    assert isinstance(ip_v6, IPv6Address)

# Generated at 2022-06-23 21:24:49.152997
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    ipv6 = Internet().ip_v6()
    try:
        IPv6Address(ipv6)
    except:
        print("Something wrong with the ip address. The function should return a valid ip address")
        return False
    return True

# Generated at 2022-06-23 21:24:50.584066
# Unit test for constructor of class Internet
def test_Internet():
    internet = Internet()
    assert internet is not None


# Generated at 2022-06-23 21:24:52.692289
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    internet = Internet()
    test = internet.ip_v4_object()
    print(type(test))
    print(test)


# Generated at 2022-06-23 21:25:02.293970
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    n = Internet()
    answer1 = TLD[TLDType.GENERAL]
    answer2 = TLD[TLDType.COUNTRY]
    answer3 = TLD[TLDType.SPONSOR]
    answer4 = TLD[TLDType.INFRASTRUCTURE]
    assert 0 < len(answer1)
    assert 0 < len(answer2)
    assert 0 < len(answer3)
    assert 0 < len(answer4)
    assert n.top_level_domain() in answer1
    assert n.top_level_domain(TLDType.COUNTRY) in answer2
    assert n.top_level_domain(TLDType.SPONSOR) in answer3
    assert n.top_level_domain(TLDType.INFRASTRUCTURE) in answer4

# Generated at 2022-06-23 21:25:10.444879
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    from mimesis.enums import Layer, MimeType
    inet = Internet()
    inet.content_type(MimeType.IMAGE)
    inet.content_type()
    inet.content_type(MimeType.APPLICATION)
    inet.content_type(MimeType.VIDEO)
    inet.content_type(MimeType.AUDIO)
    inet.content_type(MimeType.TEXT)
    inet.content_type(MimeType.MULTIPART)
    inet.content_type(MimeType.MESSAGE)
    inet.content_type(MimeType.MODEL)


# Generated at 2022-06-23 21:25:12.209374
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    obj = Internet()
    hPage = obj.home_page()
    assert hPage != ""

# Generated at 2022-06-23 21:25:13.732026
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    internet = Internet()
    assert isinstance(internet.user_agent(),str)


# Generated at 2022-06-23 21:25:19.483837
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    internet = Internet()
    ip = internet.ip_v4()
    assert(ip in ['69.3.48.17', '67.69.195.125', '124.194.44.17', '242.175.135.90',
                  '123.47.24.59', '20.76.137.235', '76.150.88.29', '156.152.181.92',
                  '49.191.62.68', '140.127.172.56'])
    assert(isinstance(ip, str))


# Generated at 2022-06-23 21:25:23.741753
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    from mimesis.enums import Layer

    internet = Internet()
    network_protocol = internet.network_protocol(layer=Layer.TRANSPORT)
    assert network_protocol in ['AMQP', 'DCCP', 'SCTP', 'TCP', 'UDP']

# Generated at 2022-06-23 21:25:25.822734
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    provider = Internet()
    user_agent = provider.user_agent()
    print(user_agent)

test_Internet_user_agent()

# Generated at 2022-06-23 21:25:28.053113
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    from mimesis.enums import TLDType

    internet = Internet()
    assert internet.home_page(tld_type=TLDType.COMMERCIAL) is not None

# Generated at 2022-06-23 21:25:41.054083
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from mimesis.providers.internet import Internet
    from pathlib import Path
    from PIL import Image
    from typing import Any, Tuple

    internet = Internet()
    stock_image: Path = Path('./stock_image.jpg')
    height: int = 720
    width: int = 1280
    stock_image_link: str = internet.stock_image(int(width), int(height))
    image_from_link: Any = internet.stock_image(int(width), int(height),
                                                writable=True)
    with stock_image.open(mode='wb') as image:
        image.write(image_from_link)
    assert isinstance(image_from_link, bytes)
    assert internet.stock_image(int(width), int(height),
                                writable=False) == stock

# Generated at 2022-06-23 21:25:43.147635
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    """Unit test for method ip_v6_object of class Internet."""
    ip = IPv6Address('2001:c244:cf9d:1fb1:c56d:f52c:8a04:94f3')

    assert Internet().ip_v6_object() == ip

# Generated at 2022-06-23 21:25:54.134085
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    """Unit test for method mac_address of class Internet.
    """
    # Initialize class Internet
    internet = Internet()
    # Get a random MAC address
    mac_address = internet.mac_address()
    # Check that method return a string
    assert type(mac_address) == str
    # Check that the MAC address have a correct format
    check_data_mac_adress = [
        "00-16-3e",
        "01-23-45",
        "22-33-44",
        "a0-a1-a2",
        "ab-ab-ab",
        "ff-ff-ff",
    ]
    assert any(
        [mac_address.startswith(x) for x in check_data_mac_adress])

# Generated at 2022-06-23 21:25:55.603095
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    i = Internet()
    ua = i.user_agent()
    print(ua)

# Generated at 2022-06-23 21:25:57.131397
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    internet = Internet()
    method = internet.http_method()
    assert isinstance(method, str)
    assert method in HTTP_METHODS


# Generated at 2022-06-23 21:25:58.378218
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    for _ in range(100):
        assert Internet().content_type()


# Generated at 2022-06-23 21:26:00.861878
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    # Arrange
    internet = Internet()

    # Act
    result = internet.image_placeholder()

    # Assert
    assert result == 'http://placehold.it/1920x1080'

# Generated at 2022-06-23 21:26:04.650884
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    '''
    Testing method Internet_user_agent(self):
    '''
    internet = Internet()
    user_agent = internet.user_agent()
    print(user_agent)


# Generated at 2022-06-23 21:26:12.093467
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet(seed=12345)
    assert internet.stock_image() == 'https://source.unsplash.com/1920x1080?', 'test_Internet_stock_image_1'
    assert internet.stock_image(keywords=['nature']) == 'https://source.unsplash.com/1920x1080?nature', 'test_Internet_stock_image_2'
    assert internet.stock_image(keywords=['nature', 'trees']) == 'https://source.unsplash.com/1920x1080?nature,trees', 'test_Internet_stock_image_3'


# Generated at 2022-06-23 21:26:22.954435
# Unit test for method ip_v6 of class Internet

# Generated at 2022-06-23 21:26:24.893376
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    myInternet = Internet()
    print(myInternet.user_agent())
if __name__ == "__main__":
    test_Internet_user_agent()

# Generated at 2022-06-23 21:26:26.094982
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    internet = Internet()
    assert True

# Generated at 2022-06-23 21:26:29.057238
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    provider = Internet()
    result = provider.http_status_code()
    assert isinstance(result, int)
    assert result

# Generated at 2022-06-23 21:26:39.102580
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    from mimesis.enums import TLDType
    from mimesis.providers.internet import Internet

    internet = Internet()



# Generated at 2022-06-23 21:26:40.718131
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    internet = Internet()
    user_agent = internet.user_agent()
    assert isinstance(user_agent, str)
    

# Generated at 2022-06-23 21:26:43.973276
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    i = Internet()
    network_protocol = i.network_protocol()
    assert network_protocol in NETWORK_PROTOCOLS[LAYERS.APPLICATION]

# Generated at 2022-06-23 21:26:45.031806
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    print(Internet().top_level_domain())

# Generated at 2022-06-23 21:26:52.736937
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    internet = Internet()

# Generated at 2022-06-23 21:27:03.931723
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from PIL import Image
    from io import BytesIO
    from urllib.request import urlopen
    import requests
    import requests_mock

    width = 150
    height = 150
    keywords = ['cat', 'kitten']

    url = Internet().stock_image(width, height, keywords)
    assert isinstance(url, str)

    img = Image.open(BytesIO(urlopen(url).read()))
    assert isinstance(img, Image.Image)

    try:
        img = Image.open(BytesIO(
            Internet().stock_image(width, height, keywords, writable=True)))
        assert isinstance(img, Image.Image)
    except urllib.error.URLError:
        pass


# Generated at 2022-06-23 21:27:07.346821
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    ip_v6 = Internet().ip_v6()
    print(ip_v6)
    assert type(ip_v6) is str
    

# Generated at 2022-06-23 21:27:10.420225
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    internet = Internet(seed=1)
    result = internet.mac_address()
    assert result == '00:16:3e:4f:eb:f2'

# Generated at 2022-06-23 21:27:13.104977
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    assert Internet.hashtags()
    assert Internet.hashtags(1)
    assert Internet.hashtags(quantity=5)
    assert Internet.hashtags(quantity=5, tld_type=None)


# Generated at 2022-06-23 21:27:21.271285
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    # Default case
    events = 10
    test_Internet = Internet()
    result = []
    for _ in range(events):
        result.append(test_Internet.home_page())

    # Correctness test
    # The event in result should be random and unique
    assert len(set(result)) == events

    # TLD case
    # tld_type = TLDType.GENERIC_COUNTRY_CODE
    # for _ in range(events):
    #     result.append(test_Internet.home_page(tld_type))

    # # Correctness test
    # # The event in result should be random and unique
    # assert len(set(result)) == events

# Generated at 2022-06-23 21:27:23.305798
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    """Unittest method http_status_message"""
    x = Internet()
    assert x.http_status_message() in HTTP_STATUS_MSGS


# Generated at 2022-06-23 21:27:25.997291
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    provider = Internet()
    assert provider.ip_v4() == '28.105.58.59'


# Generated at 2022-06-23 21:27:29.202306
# Unit test for method port of class Internet
def test_Internet_port():
    provider = Internet()
    result = provider.port()
    assert result >= 0 and result <= 65535
    result = provider.port(port_range=PortRange.WELL_KNOWN) 
    assert result >= 0 and result <= 1023

# Generated at 2022-06-23 21:27:31.937940
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    import copy
    import random

    list = [
        random.choice(list(range(300))),
        random.choice(list(range(500)))
        ]

    assert Internet().http_status_code() not in list

# Generated at 2022-06-23 21:27:34.826126
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
  assert Internet().mac_address() == '00:16:3e:01:b7:60'

# Generated at 2022-06-23 21:27:37.720647
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    r = Internet()
    l = []
    for i in range(0, 100):
        l.append(r.network_protocol())
    assert len(l) == 100


# Generated at 2022-06-23 21:27:39.083719
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    internet = Internet()
    print(internet.emoji())


# Generated at 2022-06-23 21:27:45.865490
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    print("Test network_protocol method of Internet class")
    internet = Internet ()
    print("network_protocol: ", internet.network_protocol(Layer.APPLICATION))
    print("network_protocol: ", internet.network_protocol(Layer.SESSION))
    print("network_protocol: ", internet.network_protocol(Layer.TRANSPORT))
    print("network_protocol: ", internet.network_protocol(Layer.NETWORK))
    print("network_protocol: ", internet.network_protocol(Layer.LINK))
    print("network_protocol: ", internet.network_protocol(Layer.PHYSICAL))

# Generated at 2022-06-23 21:27:46.476228
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    pass

# Generated at 2022-06-23 21:27:49.249276
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    """Unit test for method image_placeholder."""
    assert Internet().image_placeholder()


# Generated at 2022-06-23 21:27:51.108601
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    internet = Internet()
    result = internet.user_agent()
    assert type(result) is str

# Generated at 2022-06-23 21:27:54.389375
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    mimesis_internet = Internet()
    ip_address = mimesis_internet.ip_v4()
    print(ip_address)
    assert type(ip_address) == str


# Generated at 2022-06-23 21:28:00.034517
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():

    Internet = Internet(seed = 0)
    assert str(Internet.ip_v6_object()) == '2001:c244:cf9d:1fb1:c56d:f52c:8a04:94f3'
    assert Internet.ip_v6() == '2001:c244:cf9d:1fb1:c56d:f52c:8a04:94f3'


# Generated at 2022-06-23 21:28:01.173726
# Unit test for constructor of class Internet
def test_Internet():
    internet = Internet()
    assert internet.random is not None


# Generated at 2022-06-23 21:28:11.946601
# Unit test for method port of class Internet
def test_Internet_port():
    """
    Tests for the Internet.port method
    """

    from mimesis.exceptions import NonEnumerableError

    internet = Internet()

    # Valid enum test
    port = internet.port(port_range=PortRange.ALL)
    assert 0 <= port <= 65535

    port = internet.port(port_range=PortRange.PRIVILEGED)
    assert 0 <= port <= 1023

    port = internet.port(port_range=PortRange.UNPRIVILEGED)
    assert 1024 <= port <= 49151

    # Invalid enum test
    try:
        internet.port(port_range='INVALID ENUM')
    except NonEnumerableError:
        pass
    else:
        assert False

# Generated at 2022-06-23 21:28:14.136756
# Unit test for method port of class Internet
def test_Internet_port():
    internet_obj = Internet()
    assert internet_obj.port(1) in range(1, 65536)



# Generated at 2022-06-23 21:28:15.297030
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    for i in range(10):
        assert Internet().emoji() in EMOJI


# Generated at 2022-06-23 21:28:16.337360
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    assert Internet().image_placeholder() == 'http://placehold.it/1920x1080'


# Generated at 2022-06-23 21:28:18.776779
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    from mimesis.enums import MimeType

    internet = Internet(seed=42)
    result = internet.content_type(MimeType.APPLICATION)
    assert result == 'Content-Type: application/json'


# Generated at 2022-06-23 21:28:22.145247
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    # unit test for emoji()
    i = Internet()
    assert i.emoji() in EMOJI

    i = Internet()
    assert i.emoji() in EMOJI

    i = Internet(123)
    assert i.emoji() in EMOJI

    i = Internet(11.9)
    assert i.emoji() in EMOJI

# Generated at 2022-06-23 21:28:24.068324
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    obj = Internet()
    print(obj.ip_v4_object())


# Generated at 2022-06-23 21:28:26.129605
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    provider = Internet()
    home_page = provider.home_page()
    print('home_page =', home_page)
    assert home_page is not None


# Generated at 2022-06-23 21:28:28.863060
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    """Unit test for method http_status_message of class Internet"""
    internet = Internet()
    assert internet.http_status_message() in HTTP_STATUS_MSGS

# Generated at 2022-06-23 21:28:30.681324
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    from mimesis import Internet
    in1 = Internet()
    print(in1.http_status_message())


# Generated at 2022-06-23 21:28:33.133018
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    internet = Internet(seed=123456)
    result = internet.ip_v6_object()
    assert result == IPv6Address('f6fa:9d61:a6fa:a4fa:1d16:8f61:2ede:7156')

# Generated at 2022-06-23 21:28:34.917550
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    i_methods = Internet()
    print(i_methods.http_method())


# Generated at 2022-06-23 21:28:38.576199
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    ip = Internet()
    assert isinstance(ip.ip_v4(), str)
    assert isinstance(ip.ip_v4(with_port=True), str)
    assert isinstance(ip.ip_v4_object(), IPv4Address)


# Generated at 2022-06-23 21:28:41.034169
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    plhld = Internet.image_placeholder(width=250, height=140)
    assert plhld == 'http://placehold.it/250x140'

# Generated at 2022-06-23 21:28:46.127354
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    
    a = ['https://fontir.info', 'https://singslobed.info', 'https://sinslobed.info', 'https://sedicions.info', 'https://sedslobed.info']
    for i in range(5):
        assert Internet().home_page() in a


# Generated at 2022-06-23 21:28:48.148854
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    internet = Internet()

    assert isinstance(internet.ip_v4_object(), IPv4Address)



# Generated at 2022-06-23 21:28:51.053069
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    internet = Internet()

    ipv6 = internet.ip_v6_object()
    assert isinstance(ipv6, IPv6Address)


# Generated at 2022-06-23 21:28:52.937801
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    """Test for method home_page of class Internet.
    """
    result = Internet().home_page()
    assert isinstance(result, str)


# Generated at 2022-06-23 21:28:54.389169
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    print("\nTesting http_status_message of class Internet")
    print(Internet().http_status_message())


# Generated at 2022-06-23 21:28:56.065385
# Unit test for constructor of class Internet
def test_Internet():
    provider = Internet()
    assert len(provider.random.choice(HTTP_METHODS)) >= 4

# Generated at 2022-06-23 21:29:03.571227
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    hash_tags_provider = Internet()
    hash_tags1 = hash_tags_provider.hashtags()
    hash_tags2 = hash_tags_provider.hashtags(1)
    hash_tags3 = hash_tags_provider.hashtags(2)
    hash_tags4 = hash_tags_provider.hashtags(3)
    hash_tags5 = hash_tags_provider.hashtags(4)
    assert(isinstance(hash_tags1, str))
    assert(isinstance(hash_tags2, str))
    assert(isinstance(hash_tags3, list))
    assert(isinstance(hash_tags4, list))
    assert(isinstance(hash_tags5, list))


# Generated at 2022-06-23 21:29:09.108447
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    internet = Internet()
    http_status = internet.http_status_code()
    print(http_status)
    print(type(http_status))
    if http_status in [200, 300, 400, 500]:
        print('http status code is correct')
    else:
        print('http status code is incorrect')


# Generated at 2022-06-23 21:29:10.967066
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    internet = Internet('en')
    assert isinstance(internet.ip_v4_object(), IPv4Address)


# Generated at 2022-06-23 21:29:16.863988
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    print()
    print("test_Internet_stock_image()")

    from mimesis.enums import ImageFormat, ImageOrientation

    internet = Internet()

    def test_assertion(format, orientation):
        url = internet.stock_image(width=1920, height=1080,
                                   keywords=["car", "red"],
                                   writable=False)
        f = str(format).lower()
        o = str(orientation).lower()
        assert 'fm={f}&q={o}'.format(f=f, o=o) in url

    for format in ImageFormat:
        for orientation in ImageOrientation:
            test_assertion(format, orientation)



# Generated at 2022-06-23 21:29:18.353348
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    assert Internet.ip_v6() != IPv6Address(0)

# Generated at 2022-06-23 21:29:19.594619
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    assert type(Internet().ip_v6_object()) == IPv6Address
    assert type(Internet().ip_v6_object()) != IPv4Address


# Generated at 2022-06-23 21:29:22.323994
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object(): 
    # Arrange
    internet = Internet() 
    expected = IPv6Address
    
    # Act
    result = type(internet.ip_v6_object())
    
    # Assert
    assert result == expected


# Generated at 2022-06-23 21:29:25.278897
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():

    internet = Internet()
    top_level_domain_str = internet.top_level_domain()
    assert (top_level_domain_str)


# Generated at 2022-06-23 21:29:30.393871
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    from mimesis.enums import MACAddressType

    internet = Internet("en")
    assert internet.mac_address(MACAddressType.IEEE_802) == "02:00:00:00:00:01"
    assert internet.mac_address(MACAddressType.EUI_64) == "02:00:00:ff:fe:00:00:01"
    assert internet.mac_address() == "02:00:00:00:00:01"



# Generated at 2022-06-23 21:29:33.209043
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    internet = Internet(seed=93)
    layer = Layer.NETWORK
    result = internet.network_protocol(layer)
    assert result == 'AMQP'



# Generated at 2022-06-23 21:29:34.689334
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    internet = Internet()

    print(internet.http_method())


# Generated at 2022-06-23 21:29:44.882278
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    from mimesis.enums import Locale
    from mimesis.providers.internet import Internet
    en = Internet(Locale.ENGLISH)
    message = en.http_status_message()
    print(message)
    en = Internet(Locale.ENGLISH)
    message = en.http_status_message()
    print(message)
    en = Internet(Locale.ENGLISH)
    message = en.http_status_message()
    print(message)
    en = Internet(Locale.ENGLISH)
    message = en.http_status_message()
    print(message)
    en = Internet(Locale.ENGLISH)
    message = en.http_status_message()
    print(message)
    en = Internet(Locale.ENGLISH)
    message = en.http