

# Generated at 2022-06-23 21:19:46.449358
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    internet = Internet(seed=0)
    ip_address = internet.ip_v6_object()
    assert ip_address == IPv6Address('3944:7e02:0057:2467:b8e0:37c8:e2ad:1f2c')

# Generated at 2022-06-23 21:19:54.474438
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    # Test with default option
    internet = Internet()
    assert internet.stock_image(writable=True) is not None

    # Test with keywords option
    keywords = ['nature', 'mountain', 'lake']
    assert internet.stock_image(keywords=keywords, writable=True) is not None

    # Test with keywords option and writable option
    assert internet.stock_image(keywords=keywords, writable=True) is not None


if __name__ == "__main__":
    test_Internet_stock_image()

# Generated at 2022-06-23 21:19:55.733710
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    print(Internet().http_status_message())


# Generated at 2022-06-23 21:19:57.206993
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    internet = Internet()
    image = internet.image_placeholder()
    print(image)


# Generated at 2022-06-23 21:20:02.189784
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    """Unit test for Internet().stock_image."""
    from mimesis.enums import PortRange

    net = Internet()
    print(net.port(port_range=PortRange.ALL))
    print(net.port(port_range=PortRange.NETWORK))
    print(net.port(port_range=PortRange.RESERVED))

# Generated at 2022-06-23 21:20:05.400617
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    import sys
    if sys.version_info < (3, 7):
        return print("Skipped for Python 3.6")
    from mimesis.providers.internet import Internet
    from ipaddress import IPv6Address
    internet = Internet()
    ip = internet.ip_v6_object()
    assert isinstance(ip, IPv6Address)

# Generated at 2022-06-23 21:20:10.046878
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    ip = Internet()
    value = ip.ip_v4()
    assert value is not None
    print(value)


if __name__ == '__main__':
    test_Internet_ip_v4()

# Generated at 2022-06-23 21:20:12.566827
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    """Determine if method http_status_message has correct output."""
    assert isinstance(Internet().http_status_message(), str)


# Generated at 2022-06-23 21:20:15.297569
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    top_level_domain = Internet().top_level_domain()
    assert isinstance(top_level_domain, str)
    assert top_level_domain in TLD[TLDType.SUFFIX]


# Generated at 2022-06-23 21:20:17.938617
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    i = Internet()
    img = i.image_placeholder()
    assert 'placehold.it/1920x1080' in img


# Generated at 2022-06-23 21:20:20.826107
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    """Test of method ip_v6 of class Internet."""
    internet = Internet()
    print(internet.ip_v6())


# Generated at 2022-06-23 21:20:23.635296
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    internet = Internet()
    ipv4 = internet.ip_v4_object()
    assert isinstance(ipv4, IPv4Address)

# Generated at 2022-06-23 21:20:31.011049
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    # case 1
    res = Internet().hashtags(quantity=1)
    assert type(res) == str and res[0] == '#'

    # case 2
    res = Internet().hashtags(quantity=3)
    assert type(res) == list and len(res) == 3

    # case 3
    res = Internet().hashtags()
    assert type(res) == list and len(res) == 4

    # case 4
    res = Internet().hashtags(-1)
    assert res == []

    # case 5
    assert Internet().hashtags(0) == []

    # case 6
    assert Internet().hashtags(1000) == []

# Generated at 2022-06-23 21:20:35.072261
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from mimesis.exceptions import NonEnumerableError
    from mimesis.enums import PortRange
    from mimesis.providers.internet import Internet

    internet = Internet()

    port_range = PortRange.WELL_KNOWN
    port_range_str = 'WELL_KNOWN'

    port = internet.port(port_range=port_range_str)
    assert isinstance(port, int)

    try:
        port = internet.port(port_range=port_range_str)
    except NonEnumerableError:
        pass

# Generated at 2022-06-23 21:20:40.556467
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    assert internet.hashtags(1) == '#fond'
    assert internet.hashtags() == ['#learn', '#swing', '#fantasy', '#sound']
    assert internet.hashtags(quantity=5) == ['#blessing', '#snowy', '#sport', '#oscillate', '#mom']

# Generated at 2022-06-23 21:20:41.709502
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    inter = Internet()
    for _ in range(100):
        assert len(inter.mac_address()) == 17


# Generated at 2022-06-23 21:20:43.734029
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    internet = Internet()
    mac = internet.mac_address()
    assert mac


# Generated at 2022-06-23 21:20:45.135014
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    data = Internet()
    print(data.home_page())

# Generated at 2022-06-23 21:20:49.341543
# Unit test for method port of class Internet
def test_Internet_port():
    internet=Internet()
    port=internet.port(port_range=PortRange.ALL)
    assert port>=PortRange.ALL.value[0]
    assert port<=PortRange.ALL.value[1]


    port=internet.port(port_range=PortRange.SYSTEM)
    assert port>=PortRange.SYSTEM.value[0]
    assert port<=PortRange.SYSTEM.value[1]


    port=internet.port(port_range=PortRange.USER)
    assert port>=PortRange.USER.value[0]
    assert port<=PortRange.USER.value[1]

test_Internet_port()

# Generated at 2022-06-23 21:20:50.569376
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    internet = Internet()
    assert len(internet.mac_address()) == 17

# Generated at 2022-06-23 21:20:52.151356
# Unit test for constructor of class Internet
def test_Internet():
    """Test for class Internet."""
    obj = Internet()
    assert obj is not None


# Generated at 2022-06-23 21:20:54.105905
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    """Test cover case for method top_level_domain of class Internet."""
    internet = Internet()
    assert internet.top_level_domain() in TLDType.ALL.value

# Generated at 2022-06-23 21:21:02.226163
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    internet = Internet()
    assert internet.content_type(MimeType.TEXT) == 'Content-Type: text/plain'
    assert internet.content_type(MimeType.APPLICATION) == 'Content-Type: application/json'
    assert internet.content_type(MimeType.AUDIO) == 'Content-Type: audio/basic'
    assert internet.content_type(MimeType.IMAGE) == 'Content-Type: image/png'
    assert internet.content_type(MimeType.VIDEO) == 'Content-Type: video/x-msvideo'
    assert internet.content_type(MimeType.MESSAGE) == 'Content-Type: message/rfc822'
    assert internet.content_type(MimeType.MODEL) == 'Content-Type: model/example'

# Generated at 2022-06-23 21:21:03.571090
# Unit test for constructor of class Internet
def test_Internet():
    internet = Internet()
    assert isinstance(internet, Internet)

# Generated at 2022-06-23 21:21:07.692254
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    internet = Internet()

    assert isinstance(internet.emoji(), str)
    assert internet.emoji() in EMOJI



# Generated at 2022-06-23 21:21:08.698491
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    internet = Internet()

    for i in range(10):
        print(internet.emoji())


# Generated at 2022-06-23 21:21:12.037296
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    internet = Internet()
    ipv6_address = internet.ip_v6_object()
    assert isinstance(ipv6_address, IPv6Address)
    assert len(str(ipv6_address)) == 39

# Generated at 2022-06-23 21:21:20.630270
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from mimesis.enums import Width, Height
    from mimesis.enums import Category
    from io import BytesIO
    from PIL import Image
    import requests

    seed = 50
    internet = Internet(seed=seed)
    width = internet.random.choice(list(Width))
    height = internet.random.choice(list(Height))
    category = internet.random.choice(list(Category))
    image_bytes = internet.stock_image(width=width, height=height,
                                       keywords=[category])

    image_file = BytesIO(image_bytes)
    image = Image.open(image_file)

    assert image.width == width
    assert image.height == height



# Generated at 2022-06-23 21:21:29.798390
# Unit test for method port of class Internet
def test_Internet_port():
    from mimesis.enums import PortRange
    from mimesis.providers.internet import Internet
    portRange = PortRange.ALL
    internet = Internet()
    port = internet.port(portRange=portRange)
    assert port >= portRange.value[0] and port <= portRange.value[1]


    portRange = PortRange.PRIVATE
    internet = Internet()
    port = internet.port(portRange=portRange)
    assert port >= portRange.value[0] and port <= portRange.value[1]


    portRange = PortRange.EPHEMERAL
    internet = Internet()
    port = internet.port(portRange=portRange)
    assert port >= portRange.value[0] and port <= portRange.value[1]



# Generated at 2022-06-23 21:21:32.628175
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    api = Internet()
    # Test with default arguments
    res = api.ip_v4_object()
    assert isinstance(res, IPv4Address)

# Generated at 2022-06-23 21:21:33.811422
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    ua = Internet().user_agent()
    assert isinstance(ua, str)
    assert bool(ua)

# Generated at 2022-06-23 21:21:34.763667
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    Internet().content_type()


# Generated at 2022-06-23 21:21:36.658649
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    provider = Internet()
    ipv6 = provider.ip_v6_object()
    assert isinstance(ipv6, IPv6Address)

# Generated at 2022-06-23 21:21:42.269285
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    internet = Internet()
    image_url = internet.image_placeholder(width=100, height=100)
    assert (image_url == 'http://placehold.it/100x100') or (image_url == '100x100')
    print(image_url)

# Generated at 2022-06-23 21:21:50.375218
# Unit test for method content_type of class Internet

# Generated at 2022-06-23 21:21:53.351036
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    from mimesis.providers.internet import Internet as internet
    obj = internet()
    assert isinstance(obj.http_status_message(), str)


# Generated at 2022-06-23 21:22:02.726198
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    """Unit test for method ip_v6 of class Internet."""
    from mimesis.enums import PortRange
    from mimesis.utils import get_local_ip
    from mimesis.types import Seed
    internet = Internet()
    assert isinstance(internet.ip_v6(), str)
    assert (internet.ip_v4(with_port=True,
           port_range=PortRange.SYSTEM_RESERVED) !=
           internet.ip_v4(with_port=True,
                          port_range=PortRange.SYSTEM_RESERVED))
    assert len(internet.ip_v6()) == 39
    ip = get_local_ip()
    seed = Seed(ip)
    internet = Internet(seed=seed)

# Generated at 2022-06-23 21:22:08.715786
# Unit test for method port of class Internet
def test_Internet_port():
    """Unit test for method port of class Internet."""
    result = Internet('en').port(PortRange.EPHEMERAL)
    assert result >= PortRange.EPHEMERAL.value[0] and result <= PortRange.EPHEMERAL.value[1]

    with pytest.raises(NonEnumerableError):
        Internet('en').port(123)


# Generated at 2022-06-23 21:22:19.470559
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    from mimesis.enums import TLDType


# Generated at 2022-06-23 21:22:23.800316
# Unit test for constructor of class Internet
def test_Internet():
    internet = Internet()
    assert internet.__dict__.keys() == {'random', 'seed', '_MAX_IPV4', '_MAX_IPV6', '_MAX_IPV6', '__file'}

# Generated at 2022-06-23 21:22:28.071008
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    internet = Internet()
    img_url = internet.image_placeholder(
        width=1920, height=1080
    )
    assert isinstance(
        img_url, str
    )
    assert (
        img_url
        == 'http://placehold.it/1920x1080'
    )


# Generated at 2022-06-23 21:22:30.590610
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    internet = Internet()
    ip = internet.ip_v6()
    assert len(ip.split(':')) == 8

# Generated at 2022-06-23 21:22:32.023068
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    internet = Internet()
    assert isinstance(internet.user_agent(), str)

# Generated at 2022-06-23 21:22:36.689902
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    i = Internet()
    port = i.port()
    status = i.http_status_code()
    print(port)
    print(status)


# Generated at 2022-06-23 21:22:41.626639
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    lst = []
    for _ in range(10):
        ip = Internet().ip_v4_object()
        lst.append(ip)
        print(ip)
    
    assert len(lst) == 10
    assert isinstance(lst[1], IPv4Address)
    assert isinstance(lst[3], IPv4Address)
    
    
    
    

# Generated at 2022-06-23 21:22:45.490457
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    obj = Internet()
    res = obj.ip_v4(with_port=True)
    assert res is not None
    assert isinstance(res, str)



# Generated at 2022-06-23 21:22:46.222278
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    print(Internet().stock_image(width=1920, height=1080))

# Generated at 2022-06-23 21:22:50.301684
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    from mimesis.enums import HTTP_METHODS
    from mimesis.providers.internet import Internet
    it = Internet()
    method = it.http_method()
    assert method in HTTP_METHODS

# Generated at 2022-06-23 21:22:57.235747
# Unit test for method port of class Internet
def test_Internet_port():
    port_0 = Internet.PortRange.WELL_KNOWN
    port_1 = Internet.PortRange.REGISTERED
    port_2 = Internet.PortRange.USER
    port_3 = Internet.PortRange.ALL

    for i in range(1, 100):
        assert 0 <= Internet.port(port_3) <= 65535
        assert 0 <= Internet.port(port_0) <= 1023
        assert 1024 <= Internet.port(port_1) <= 49151
        assert 49152 <= Internet.port(port_2) <= 65535


# Generated at 2022-06-23 21:22:58.615246
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    Internet().content_type(MimeType.APPLICATION)


# Generated at 2022-06-23 21:23:09.705314
# Unit test for method port of class Internet
def test_Internet_port():
	result1 = Internet().port(PortRange.PUBLIC)
	result2 = Internet().port(PortRange.ALL)
	result3 = Internet().port(PortRange.PRIVATE)
	result4 = Internet().port()

	# assert isinstance(result1, int)
	# assert isinstance(result2, int)
	# assert isinstance(result3, int)
	# assert isinstance(result4, int)
	#
	# assert ((1024 < result1 < 49151) or (49152 < result1 < 65535))
	# assert ((1024 < result2 < 49151) or (49152 < result2 < 65535))
	# assert (49152 < result3 < 65535)
	# assert ((1024 < result4 < 49151) or (49152 < result4 < 65535))


# Generated at 2022-06-23 21:23:17.845210
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    from mimesis.enums import Layer
    from mimesis.providers.internet import Internet
    from mimesis.typing import NetworkProtocols

    internet = Internet()

    assert isinstance(internet.network_protocol(), str)
    assert isinstance(internet.network_protocol(layer=Layer.APPLICATION), str)
    assert isinstance(internet.network_protocol(layer=Layer.DATA_LINK), str)
    assert isinstance(internet.network_protocol(layer=Layer.NETWORK), str)
    assert internet.network_protocol(layer=Layer.PRESENTATION) in NetworkProtocols[Layer.PRESENTATION]
    assert internet.network_protocol(layer=Layer.SESSION) in NetworkProtocols[Layer.SESSION]

# Generated at 2022-06-23 21:23:21.230505
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    from mimesis.enums import Gender
    from mimesis.providers import Internet

    int = Internet(Gender.MALE)
    result = int.emoji()
    assert result in EMOJI



# Generated at 2022-06-23 21:23:23.786563
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    ip_v6 = Internet()
    # print(ip_v6.ip_v6_object())
    assert isinstance(ip_v6.ip_v6_object(), IPv6Address)


# Generated at 2022-06-23 21:23:25.196331
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    internet = Internet()
    assert internet.http_status_code() in range(100, 600)


# Generated at 2022-06-23 21:23:30.920463
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    from mimesis.enums import TLDType
    from mimesis.providers.internet import Internet

    internet_obj = Internet()
    check_val = internet_obj.home_page(tld_type=TLDType.COMMERCIAL)

    print (check_val)

if __name__ == "__main__":
    test_Internet_home_page()

# Generated at 2022-06-23 21:23:32.929546
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    internet = Internet()
    result = internet.ip_v4_object()
    assert isinstance(result, IPv4Address)

# Generated at 2022-06-23 21:23:34.748427
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    #precondition
    Internet_ = Internet()

    #test
    result_test = Internet_.content_type()

    #postcondition
    assert result_test != ''


# Generated at 2022-06-23 21:23:36.055434
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    internet = Internet(seed=9)
    assert internet.top_level_domain(tld_type=TLDType.CCTLD) == '.tt'

# Generated at 2022-06-23 21:23:38.893909
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    from mimesis.providers import Internet
    from mimesis.enums import HttpStatusCode
    i = Internet()
    status_code = i.http_status_code()
    assert status_code in HttpStatusCode.items()


# Generated at 2022-06-23 21:23:41.370988
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    a = Internet()
    assert isinstance(a.stock_image(writable=False), str)
    assert isinstance(a.stock_image(writable=True), bytes)

# Generated at 2022-06-23 21:23:41.989677
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    pass

# Generated at 2022-06-23 21:23:46.994020
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    # obj = Internet()
    # List of expected results.
    exp = ('GET', 'POST', 'DELETE', 'HEAD', 'PUT', 'OPTIONS',
           'CONNECT', 'TRACE', 'PATCH')
    # List of results using the tested method.
    res = [Internet.http_method() for _ in range(len(exp))]
    # Check that all expected values are in the results.
    assert all([item in res for item in exp])

# Generated at 2022-06-23 21:23:49.728203
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    provider = Internet()
    hash_tags = provider.hashtags(quantity=4)
    assert len(hash_tags) == 4
    

# Generated at 2022-06-23 21:23:53.773685
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    intnet = Internet()
    assert intnet.image_placeholder() == 'http://placehold.it/1920x1080'
    assert intnet.image_placeholder(1500, 1000) == 'http://placehold.it/1500x1000'


# Generated at 2022-06-23 21:23:58.830543
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    """Test method ip_v4_object."""
    internet = Internet()

    for _ in range(10):
        ip_v4 = internet.ip_v4_object()
        print(ip_v4)
        assert isinstance(ip_v4, IPv4Address)



# Generated at 2022-06-23 21:24:01.629326
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    i = Internet('ru')
    assert type(i.stock_image()) == str
    assert type(i.stock_image(writable=True)) == bytes
    assert type(i.stock_image(keywords=['лес','дерево','вертолет'])) == str

# Generated at 2022-06-23 21:24:04.768839
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    internet = Internet()
    ip_v4 = internet.ip_v4()
    print(ip_v4)
    ip_v4_with_port = internet.ip_v4(with_port=True)
    print(ip_v4_with_port)


# Generated at 2022-06-23 21:24:05.634368
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    _obj = Internet()
    _obj.content_type()


# Generated at 2022-06-23 21:24:06.676646
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    test = Internet()
    result = test.http_method()
    assert isinstance(result,str)


# Generated at 2022-06-23 21:24:09.796862
# Unit test for method port of class Internet
def test_Internet_port():
    x = Internet()
    port_ = x.port(port_range = PortRange.SYSTEM)
    assert 0 <= port_ <= 1

# Generated at 2022-06-23 21:24:11.073970
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    obj = Internet()
    res = obj.user_agent()
    assert res

# Generated at 2022-06-23 21:24:14.249871
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    net = Internet()
    # Content-Type: text/html
    net.content_type()
    net.content_type(MimeType.TEXT)
    # Content-Type: application/xml
    net.content_type(MimeType.APP)
    # Content-Type: audio/mp4
    net.content_type(MimeType.AUDIO)
    # Content-Type: video/x-msvideo
    net.content_type(MimeType.VIDEO)
    # Content-Type: image/x-xbitmap
    net.content_type(MimeType.IMAGE)


# Generated at 2022-06-23 21:24:16.217371
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    internet = Internet()
    assert internet.ip_v4() == '81.55.116.91'


# Generated at 2022-06-23 21:24:27.044685
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    from mimesis.enums import Browser, BrowserVersion
    from mimesis.providers.os import OS

    browser = Internet(seed=23)
    _browser = browser.user_agent(
        browser_=Browser.FIREFOX,
        version=BrowserVersion.ANTERIOR_TO_41,
        os_=OS.LINUX,
    )
    assert _browser == 'Mozilla/5.0 (X11; U; Linux x86_64; en-GB; ' \
                       'rv:1.9.1.18) Gecko/20110322 Ubuntu/9.10 ' \
                       '(karmic) Firefox/3.5.8'


# Generated at 2022-06-23 21:24:31.207277
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    internet = Internet()
    placeholder = internet.image_placeholder()
    assert placeholder == 'http://placehold.it/1920x1080'
    placeholder = internet.image_placeholder(width=1024, height=768)
    assert placeholder == 'http://placehold.it/1024x768'


# Generated at 2022-06-23 21:24:32.739574
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    """Unit test for method mac_address of class Internet"""
    internet = Internet()
    i = internet.mac_address()
    assert i is not None


# Generated at 2022-06-23 21:24:35.672612
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    from mimesis.enums import Layer

    i = Internet()
    for _ in range(100):
        result = i.ip_v6_object()
        assert result.version == 6



# Generated at 2022-06-23 21:24:43.459672
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    from mimesis.enums import MimeType
    from mimesis.providers.internet import Internet
    _internet = Internet()
    _mime_type = MimeType.APPLICATION
    _content_type = _internet.content_type(_mime_type)
    assert _content_type == "Content-Type: application/json"

    _mime_type = MimeType.AUDIO
    _content_type = _internet.content_type(_mime_type)
    assert _content_type == "Content-Type: audio/basic"

    _mime_type = MimeType.IMAGE
    _content_type = _internet.content_type(_mime_type)
    assert _content_type == "Content-Type: image/jpeg"

    _mime_type = MimeType.MESSA

# Generated at 2022-06-23 21:24:45.571037
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    internet = Internet()
    print(internet.user_agent())


# Generated at 2022-06-23 21:24:55.190601
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from mimesis.providers.internet import Internet as Internet_internet
    import io
    import os
    import tempfile
    import mimetypes
    import urllib.request

    # Basic test
    internet = Internet_internet()
    size = os.path.getsize(
        internet.stock_image(
            writable=True
        )
    ) > 0

    # Image size test
    image = internet.stock_image(
        writable=True,
        width=600,
        height=400,
    )
    request = urllib.request.Request(
        image,
        headers={'User-Agent': internet.user_agent()})
    file = urllib.request.urlopen(request)
    image_file = io.BytesIO(file.read())

# Generated at 2022-06-23 21:25:04.099985
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    """Test for method ip_v6 of class Internet."""
    # IPv6

# Generated at 2022-06-23 21:25:07.378050
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    # Test option 1
    random_result_1 = '👕'
    result_1 = Internet().emoji()
    assert result_1 == random_result_1
    # Test option 2
    random_result_2 = '👳'
    result_2 = Internet('en').emoji()
    assert result_2 == random_result_2


# Generated at 2022-06-23 21:25:12.244188
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    # Given
    width_expected = "500"
    height_expected = "500"
    expected = 'http://placehold.it/500x500'

    # When
    result = Internet.image_placeholder(width=width_expected,height=height_expected)

    # Then
    assert result == expected


# Generated at 2022-06-23 21:25:13.731816
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    internet = Internet()
    assert isinstance(internet.http_status_code(), int)


# Generated at 2022-06-23 21:25:16.686029
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    """
    Написать юнит-тест для метода emoji класса Internet
    """
    assert len(Internet().emoji()) == len(':kissing:')

# Generated at 2022-06-23 21:25:23.226356
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    d = Internet()
    for layer_type in  ['APPLICATION', 'PRESENTATION', 'SESSION',
                        'TRANSPORT', 'NETWORK', 'DATA_LINK',
                        'PHYSICAL']:
        print(d.network_protocol('d.network_protocol('+layer_type+')'))
        # print(d.network_protocol(layer_type))

# Generated at 2022-06-23 21:25:31.042308
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    from mimesis.enums import Browser

    from selenium import webdriver

    from mimesis.builtins import Browser as Browser_

    internet = Internet('en')
    user_agent = internet.user_agent()
    print(user_agent)

    # By default selenium browser object doesn't have a user agent.
    # So, we should set it manually.
    driver = webdriver.Safari()
    driver.execute_cdp_cmd(
        'Network.setUserAgentOverride',
        {'userAgent': user_agent})

    # Get the actual user agent of the browser.
    user_agent_ = driver.execute_cdp_cmd('Network.getUserAgent')
    print(user_agent_)

    # Get browser capability.
    browser = Browser_.get_instance(Browser.SAFARI)


# Generated at 2022-06-23 21:25:34.033387
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    internet = Internet()
    domain = internet.home_page()
    assert domain.startswith('https://')
    assert domain.endswith(('.com', '.me', '.org', '.info'))

# Generated at 2022-06-23 21:25:40.704028
# Unit test for method port of class Internet
def test_Internet_port():
    internet = Internet()
    port = internet.port(port_range=PortRange.WELL_KNOWN)
    assert 0 < port < 1023
    port = internet.port(port_range=PortRange.REGISTERED)
    assert 1024 < port < 49151
    port = internet.port(port_range=PortRange.DYNAMIC)
    assert 49152 < port < 65535

# Generated at 2022-06-23 21:25:42.715345
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    internet_method_home_page = Internet().home_page()
    assert True == isinstance(internet_method_home_page, str)


# Generated at 2022-06-23 21:25:52.570745
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    """Test of Internet class, method stock_image."""
    internet = Internet()
    assert internet.stock_image(width=200, height=300) == 'https://source.unsplash.com/200x300?'
    assert internet.stock_image(width=200, height=300, keywords=['nature']) == 'https://source.unsplash.com/200x300?nature'
    assert internet.stock_image(width=200, height=300, keywords=['nature', 'sea']) == 'https://source.unsplash.com/200x300?nature,sea'
    assert internet.stock_image(width=200, height=300, keywords=['nature', 'sea'], writable=True) is not None

# Generated at 2022-06-23 21:25:59.604099
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    assert internet.hashtags(quantity=1) == internet.hashtags()

    assert '#nice' in internet.hashtags(quantity=4)
    assert '#ruin' in internet.hashtags(quantity=4)
    assert '#clouds' in internet.hashtags(quantity=4)
    assert '#rainy' in internet.hashtags(quantity=4)
    assert len(internet.hashtags(quantity=4)) == 4
    assert isinstance(internet.hashtags(quantity=4), list)

# Generated at 2022-06-23 21:26:02.205774
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    print("# Get a random HTTP status message")
    rs = Internet()
    print(rs.http_status_message())


# Generated at 2022-06-23 21:26:04.608327
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    print("\nTesting method http_method of class Internet")
    assert Internet().http_method() in HTTP_METHODS


# Generated at 2022-06-23 21:26:07.063709
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    prov = Internet()
    actual = prov.image_placeholder()
    assert actual is not None

# Generated at 2022-06-23 21:26:09.608694
# Unit test for method network_protocol of class Internet

# Generated at 2022-06-23 21:26:20.800774
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    # Arrange
    internet = Internet()

    # Act
    result = internet.emoji()

    # Assert
    # assertTrue('#' == result[0])

    # Unit test for method hashtags of class Internet
    def test_Internet_hashtags():
        # Arrange
        internet = Internet()

        # Act
        result = internet.hashtags()

        # Assert
        # assertTrue('#' == result[0])

    # Unit test for method image_placeholder of class Internet
    def test_Internet_image_placeholder():
        # Arrange
        internet = Internet()

        # Act
        result = internet.image_placeholder()

        # Assert
        assert (result == 'http://placehold.it/1920x1080')

    # Unit test for method stock_image of class Internet

# Generated at 2022-06-23 21:26:23.966445
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    """Unit test for method mac_address of class Internet."""
    int = Internet()
    mac = int.mac_address()
    message = "Method mac_address of class Internet not passed"
    assert isinstance(mac, str), message

# Generated at 2022-06-23 21:26:35.229993
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    meta = Internet.Meta
    assert meta.name == '@@name@@'
    assert meta.provider == '@@provider@@'
    assert meta.package == '@@package@@'
    assert meta.description is None
    assert hasattr(meta, 'url') is True
    assert hasattr(meta, 'version') is True
    assert hasattr(meta, 'license') is True
    assert hasattr(meta, 'author') is True
    assert hasattr(meta, 'email') is True
    assert hasattr(meta, 'copyright') is True

    assert Internet().http_status_message() in HTTP_STATUS_MSGS
    assert Internet().http_status_code() in HTTP_STATUS_CODES
    assert Internet().http_method() in HTTP_METHODS

# Generated at 2022-06-23 21:26:37.819254
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    http_method = Internet().http_method()
    assert isinstance(http_method, str)
    assert http_method in HTTP_METHODS
    

# Generated at 2022-06-23 21:26:40.420167
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
	# Initialization object of class Internet
	internet = Internet()

	# Create object of type IPv4Address
	object = internet.ip_v4_object()

	# Testing method
	assert isinstance(object, IPv4Address)


# Generated at 2022-06-23 21:26:43.081470
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    inet = Internet()
    status = inet.http_status_code()
    assert status in HTTP_STATUS_CODES

# Generated at 2022-06-23 21:26:47.336245
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from mimesis.enums import PortRange
    from mimesis.providers.internet import Internet
    # remove this line to check on your computer
    import pytest
    try:
        Internet().stock_image()
    except urllib.error.URLError:
        pytest.skip("Requires an active HTTP connection to run")
    Internet().stock_image()
    Internet().stock_image(width=1920, height=1080)
    Internet().stock_image(width='1920', height='1080')
    Internet().stock_image(width=1920, height=1080, writable=True)
    Internet().stock_image(width='1920', height='1080', writable=True)
    Internet().stock_image(keywords=['cat', 'dog', 'fish'])

# Generated at 2022-06-23 21:26:49.311551
# Unit test for method emoji of class Internet
def test_Internet_emoji():
	assert Internet().emoji() in EMOJI
	assert Internet('en').emoji() in EMOJI

# Generated at 2022-06-23 21:26:52.037448
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    i = Internet()
    result = i.content_type()
    assert isinstance(result, str)
    assert result.startswith('Content-Type:')


# Generated at 2022-06-23 21:26:54.012840
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    i = Internet()
    hashtags = i.hashtags(5)
    assert isinstance(hashtags, list)

# Generated at 2022-06-23 21:26:54.951321
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    print(Internet.home_page())

# Generated at 2022-06-23 21:27:00.442382
# Unit test for method port of class Internet
def test_Internet_port():
    import unittest
    from mimesis.enums import PortRange

    class TestInternet(unittest.TestCase):

        def setUp(self):
            self.internet = Internet()

        def test_port(self):
            self.assertEqual(self.internet.port(), 80)
            self.assertEqual(self.internet.port(PortRange.ALL), 80)
            self.assertEqual(self.internet.port(PortRange.RESERVED), 443)

    unittest.main()

# Generated at 2022-06-23 21:27:02.649560
# Unit test for constructor of class Internet
def test_Internet():
    internet = Internet()
    assert isinstance(internet, Internet)
    assert internet.locales == ['en']
    assert internet.seed is not None



# Generated at 2022-06-23 21:27:04.911315
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    from mimesis import Internet
    from ipaddress import IPv4Address
    int = Internet()
    assert isinstance(int.ip_v4_object(), IPv4Address)

# Generated at 2022-06-23 21:27:06.565848
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    method = Internet.http_method()
    if method not in HTTP_METHODS:
        raise ValueError



# Generated at 2022-06-23 21:27:10.470936
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    result = internet.stock_image(width=200, height=150, writable=True)
    print(type(result))
    print(internet.stock_image(height=250, width=250))


# Generated at 2022-06-23 21:27:12.419989
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    assert Internet().http_status_message() in HTTP_STATUS_MSGS


# Generated at 2022-06-23 21:27:14.235438
# Unit test for constructor of class Internet
def test_Internet():
    _internet_test = Internet()
    assert _internet_test.seed is not None
    assert _internet_test.random is not None


# Unit tests for ip_v4

# Generated at 2022-06-23 21:27:23.427385
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from mimesis.units import Unit

    """
    If you are not connected to the Internet, to run the tests properly,
    you should modify the method stock_image in class Internet
    as follows:

    def stock_image(self, width: Union[int, str] = 1920,
                    height: Union[int, str] = 1080,
                    keywords: Optional[List[str]] = None,
                    writable: bool = False) -> Union[str, bytes]:
        return 'https://source.unsplash.com/{}x{}?{}'
        """

    internet = Internet()
    # Simple use
    i = internet.stock_image()
    assert i == 'https://source.unsplash.com/1920x1080'

    # Set image size
    i = internet.stock_image(1080, 1080)

# Generated at 2022-06-23 21:27:31.495801
# Unit test for method port of class Internet
def test_Internet_port():
    provider = Internet()
    assert provider.port(port_range=PortRange.TCP_WELL_KNOWN_PORTS) in [1, 1024]
    assert provider.port(port_range=PortRange.TCP_REGISTERED_PORTS) in [1024, 49151]
    assert provider.port(port_range=PortRange.UDP_WELL_KNOWN_PORTS) in [1, 1024]
    assert provider.port(port_range=PortRange.UDP_REGISTERED_PORTS) in [1024, 49151]
    assert provider.port(port_range=PortRange.ALL) in [1, 65535]

# Generated at 2022-06-23 21:27:34.367134
# Unit test for constructor of class Internet
def test_Internet():
    """Test Internet class."""
    internet = Internet()

    assert internet is not None


# Generated at 2022-06-23 21:27:37.633269
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    """Unit test for method ip_v6 of class Internet."""
    internet = Internet()
    ip_v6 = internet.ip_v6()
    assert ip_v6.count('.') == 7

# Generated at 2022-06-23 21:27:40.086333
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    ip = Internet()
    assert isinstance(ip.ip_v4(), str)
    assert len(ip.ip_v4().split('.')) == 4



# Generated at 2022-06-23 21:27:40.733549
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    med = Internet()
    med.user_agent()

# Generated at 2022-06-23 21:27:42.241539
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    from mimesis.enums import Localization
    internet = Internet(Localization.EN)
    print(internet.emoji())


# Generated at 2022-06-23 21:27:45.407566
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    class __(Internet):
        def __init__(self):
            self.random = __Random()
            self.random.randint = lambda *args: 1234567890123456789012345
    obj = __()
    ret = obj.ip_v6_object()
    assert ret == IPv6Address(1234567890123456789012345)

# Generated at 2022-06-23 21:27:46.942820
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    internet = Internet()
    for x in range(1,10):
        print(internet.emoji())



# Generated at 2022-06-23 21:27:59.434594
# Unit test for method port of class Internet
def test_Internet_port():
    """
    Test Internet.port
    """
    tester = Internet()
    assert 0 <= tester.port(PortRange.ALL) <= 65535
    assert 1 <= tester.port(PortRange.REGISTERED) <= 49151
    assert 49152 <= tester.port(PortRange.DYNAMIC) <= 65535
    assert 1 <= tester.port(PortRange.PUBLIC) <= 1024
    assert 1 <= tester.port(PortRange.WELL_KNOWN) <= 49151
    assert 0 <= tester.port(PortRange.USER) <= 1024
    assert 1025 <= tester.port(PortRange.SYSTEM) <= 49151
    assert 49152 <= tester.port(PortRange.EPHEMERAL) <= 65535
    assert 0 <= tester.port(PortRange.RESERVED) <= 1024

# Generated at 2022-06-23 21:28:01.164462
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    obj = Internet()
    
    result = obj.ip_v6_object()
    
    assert type(result) == IPv6Address

# Generated at 2022-06-23 21:28:02.640955
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    internet = Internet()
    assert internet.home_page() != internet.home_page()

# Generated at 2022-06-23 21:28:13.802989
# Unit test for method port of class Internet
def test_Internet_port():
    provider = Internet()
    for _ in range(10):
        result = provider.port(PortRange.WELL_KNOWN)
        assert result in range(1, 1023)

    for _ in range(10):
        result = provider.port(PortRange.REGISTERED)
        assert result in range(1024, 49151)

    for _ in range(10):
        result = provider.port(PortRange.DYNAMIC)
        assert result in range(49152, 65535)

    for _ in range(10):
        result = provider.port(PortRange.ALL)
        assert result in range(1, 65536)

    result = provider.port(port_range=PortRange.ALL)
    assert result in range(1, 65536)

# Generated at 2022-06-23 21:28:16.706579
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    ip = Internet()
    ip_v6_Address_Object = ip.ip_v6_object()
    expected_result = ip_v6_Address_Object.version
    assert expected_result == 6 


# Generated at 2022-06-23 21:28:18.944556
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    internet = Internet()
    content_type = internet.content_type()
    assert(content_type)


# Generated at 2022-06-23 21:28:21.843327
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    provider = Internet('en')
    assert provider.image_placeholder(width=50, height=100) == 'http://placehold.it/50x100'

# Generated at 2022-06-23 21:28:24.216981
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    internet = Internet()
    assert internet.image_placeholder(800, 400) == 'http://placehold.it/800x400'



# Generated at 2022-06-23 21:28:26.582951
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    _ = Internet()
    assert isinstance(_.hashtags(), str)
    assert isinstance(_.hashtags(3), list)

# Generated at 2022-06-23 21:28:29.100298
# Unit test for method emoji of class Internet
def test_Internet_emoji():
  """Test the method emoji of class Internet."""
  seed(1)
  internet = Internet()

  assert internet.emoji() == '🐿'


# Generated at 2022-06-23 21:28:30.890190
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    internet = Internet()
    ip = internet.ip_v4()
    assert ip.count('.') == 3
    assert isinstance(ip, str)

# Generated at 2022-06-23 21:28:38.352088
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    """Unit test for method stock_image of class Internet."""
    from PIL import Image

    from mimesis.enums import PortRange
    from mimesis.typing import Writable

    internet = Internet()
    width = internet.random.randint(1, 1920)
    height = internet.random.randint(1, 1080)
    image: Writable = internet.stock_image(width=width, height=height)

    try:
        img = Image.open(image)
        assert img.size == (width, height)
    except IOError:
        raise IOError('Required an active HTTP connection')

    # Test PortRange
    port = internet.port(port_range=PortRange.ALL)
    assert 0 <= port <= 65535

    # Test TLD

# Generated at 2022-06-23 21:28:39.517526
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    i = Internet('en')
    ip = i.ip_v4_object()
    print(ip)


# Generated at 2022-06-23 21:28:50.951735
# Unit test for constructor of class Internet
def test_Internet():
    internet = Internet()
    assert "" != internet.content_type()
    assert "" != internet.http_status_message()
    assert "" != internet.http_status_code()
    assert "" != internet.http_method()
    assert "" != internet.ip_v4()
    assert "" != internet.ip_v6()
    assert "" != internet.mac_address()
    assert "" != str(internet.ip_v4_object())
    assert "" != str(internet.ip_v6_object())
    assert "" != internet.emoji()
    assert "" != internet.image_placeholder()
    assert "" != internet.stock_image()
    assert "" != internet.hashtags()
    assert "" != internet.home_page()
    assert "" != internet.top_level_domain()
    assert "" != internet.user_agent()


# Generated at 2022-06-23 21:28:54.166157
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    from mimesis.enums import TLDType
    from mimesis.providers.internet import Internet

    i = Internet()
    print(i.top_level_domain(TLDType.TOP_LEVEL_DOMAIN))


# Generated at 2022-06-23 21:29:01.359506
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    internet = Internet()
    ip_v6 = internet.ip_v6()

# Generated at 2022-06-23 21:29:02.558632
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    ip = Internet()
    assert isinstance(ip.ip_v6(), str)

# Generated at 2022-06-23 21:29:04.613133
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    provider = Internet()
    image = provider.stock_image(writable=False)
    assert image == 'https://source.unsplash.com/1920x1080?'

# Generated at 2022-06-23 21:29:10.966878
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    # Arrange
    provider = Internet(random=SystemRandom())
    mac_address = provider.mac_address()

    # Act
    validation = re.compile(r'^([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})$')

    # Assert
    assert validation.match(mac_address) is not None

# Generated at 2022-06-23 21:29:13.656531
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    internet = Internet()
    assert isinstance(internet.ip_v4(), str)


# Generated at 2022-06-23 21:29:17.260770
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    internet = Internet()
    user_agent = internet.user_agent()
    print(user_agent)
    assert isinstance(user_agent, str)

if __name__ == "__main__":
    test_Internet_user_agent()

# Generated at 2022-06-23 21:29:18.690360
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    assert Internet._Internet__http_status_message(Internet()) is not None

# Generated at 2022-06-23 21:29:20.655374
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    assert internet.hashtags(1) == "#mood"

# Generated at 2022-06-23 21:29:28.411334
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    internet = Internet("ru")
    assert isinstance(internet.image_placeholder(), str)
    assert internet.image_placeholder(200, 200) == "http://placehold.it/200x200"
    assert internet.image_placeholder(width=200, height=200) == "http://placehold.it/200x200"
    assert internet.image_placeholder(width="200", height="200") == "http://placehold.it/200x200"    

if __name__ == '__main__':
    test_Internet_image_placeholder()

# Generated at 2022-06-23 21:29:31.992840
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    ifn = Internet()
    if ifn.user_agent() is None:
        print('Test FAILED')
        raise ValueError
    else:
        print('Test SUCCESS')


# Generated at 2022-06-23 21:29:33.496749
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    for _ in range(10):
        print(Internet().emoji())


# Generated at 2022-06-23 21:29:40.954092
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    """Test for method image_placeholder of class Internet."""

    internet = Internet(seed=42)

    assert internet.image_placeholder(100, 200) == 'http://placehold.it/100x200'
    assert internet.image_placeholder(width=300) == 'http://placehold.it/300x1080'
    assert internet.image_placeholder(height=1440) == 'http://placehold.it/1920x1440'
    assert internet.image_placeholder() == 'http://placehold.it/1920x1080'

# Generated at 2022-06-23 21:29:43.538310
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    '''Test if method http_method of class Internet can return the correct value'''
    result = Internet.http_method()
    assert result in ['GET', 'PUT', 'POST', 'DELETE', 'OPTIONS']
