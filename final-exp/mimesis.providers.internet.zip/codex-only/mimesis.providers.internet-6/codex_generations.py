

# Generated at 2022-06-23 21:19:40.787874
# Unit test for method port of class Internet
def test_Internet_port():
    from mimesis.enums import PortRange
    from tests.utils import ensure_enumerable
    ensure_enumerable(PortRange, rng=Internet.port)

# Generated at 2022-06-23 21:19:45.402543
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    from mimesis.enums import Layer

    i = Internet()
    #print(i.network_protocol(layer=Layer.L4))
    for _ in range(50):
        print(i.ip_v6())

# Generated at 2022-06-23 21:19:47.008694
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    internet = Internet()
    assert internet.home_page() is not None

# Generated at 2022-06-23 21:19:50.650953
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    """
    Test ip_v4_object().

    IpV4Address(19.121.223.58)
    """
    print(Internet().ip_v4_object())


# Generated at 2022-06-23 21:19:52.388021
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    internet_object = Internet()
    result = internet_object.image_placeholder()
    assert 'http://placehold.it/' in result



# Generated at 2022-06-23 21:19:55.330918
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    internet = Internet("en")
    result = internet.ip_v6()
    print("[Internet] Result of method ip_v6 is : {}".format(result))
    assert result is not None

# Generated at 2022-06-23 21:19:59.653974
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    internet = Internet()
    url = internet.image_placeholder()
    assert isinstance(url, str)
    assert url == 'http://placehold.it/1920x1080'


# Generated at 2022-06-23 21:20:02.145707
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    ip = Internet().ip_v4()
    assert(isinstance(ip, str) and ip.count('.') == 3)

# Generated at 2022-06-23 21:20:04.118815
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    generator = Internet()
    mac_address = generator.mac_address()
    print(mac_address)
    print(type(mac_address))


# Generated at 2022-06-23 21:20:06.933230
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    internet = Internet()
    test_image = internet.image_placeholder(200, 300)
    assert isinstance(test_image, str)
    assert test_image == 'http://placehold.it/200x300'


# Generated at 2022-06-23 21:20:10.161134
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    internet = Internet()

    for x in range(100):
        assert int(internet.http_status_code()) in range(600)


# Generated at 2022-06-23 21:20:12.333680
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    internet = Internet()
    assert isinstance(internet.ip_v6_object(), IPv6Address)

# Generated at 2022-06-23 21:20:16.287230
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    ip = Internet()
    assert isinstance(ip.image_placeholder(), str)
    assert isinstance(ip.image_placeholder(width=100), str)
    assert isinstance(ip.image_placeholder(height=100), str)
    assert isinstance(ip.image_placeholder(height=100, width=200), str)

# Generated at 2022-06-23 21:20:18.030556
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    internet = Internet()
    print(internet.image_placeholder(width=1080, height=1920))


# Generated at 2022-06-23 21:20:20.826121
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    internet = Internet()
    code = internet.http_status_code()
    print(code)

test_Internet_http_status_code()


# Generated at 2022-06-23 21:20:22.800398
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    a = Internet()
    assert len(a.emoji()) > 0


# Generated at 2022-06-23 21:20:25.964385
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    internet = Internet()
    assert internet.home_page() == 'https://numeros.info'\
        or internet.home_page() == 'https://numeros.info'

# Generated at 2022-06-23 21:20:28.471581
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    internet = Internet()
    t = internet.image_placeholder()
    assert(t == "http://placehold.it/1920x1080")

# Generated at 2022-06-23 21:20:32.437815
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    print ("Testing Internet().emoji(): ", Internet().emoji())
    print ("Testing Internet().emoji(): ", Internet().emoji())
    print ("Testing Internet().emoji(): ", Internet().emoji())


# Generated at 2022-06-23 21:20:35.751024
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    """Test http_method method of class Internet."""
    print('http_method:')
    internet = Internet()
    for _ in range(10):
        print(internet.http_method())


# Generated at 2022-06-23 21:20:39.107218
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    import re
    internet = Internet()
    pattern = re.compile(r'[\w\/\.]')
    user_agent = internet.user_agent()
    assert pattern.match(user_agent) != None

# Generated at 2022-06-23 21:20:42.248727
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    internet = Internet()
    content_type = internet.content_type(mime_type=MimeType.TEXT)
    print('Content-Type: {}'.format(content_type))


# Generated at 2022-06-23 21:20:45.040855
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    """Test method http_status_code of class Internet."""
    internet = Internet()
    assert internet.http_status_code() in HTTP_STATUS_CODES

# Generated at 2022-06-23 21:20:46.683406
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    tester = Internet()
    image_placeholder = tester.image_placeholder()
    print(image_placeholder)

# Generated at 2022-06-23 21:20:50.031682
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    provider = Internet()
    tld_type = TLDType.COUNTRY
    result = provider.top_level_domain(tld_type=tld_type)
    assert isinstance(result, str)
    assert len(result) > 0

# Generated at 2022-06-23 21:20:51.821621
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    internet = Internet()
    emoji = internet.emoji()

    assert isinstance(emoji, str)
    assert emoji



# Generated at 2022-06-23 21:20:54.542764
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    hashtag = internet.hashtags(1)
    assert len(hashtag) > 0

    hashtags = internet.hashtags()
    assert len(hashtags) == 4
    assert isinstance(hashtags, list)



# Generated at 2022-06-23 21:20:57.189980
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    internet = Internet()
    ipv6 = internet.ip_v6()
    assert ipv6 is not None
    assert type(ipv6) is str
    assert ipv6.count(":") == 7


# Generated at 2022-06-23 21:20:59.046846
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    obj = Internet()
    assert(type(obj.ip_v6()) == str)

# Generated at 2022-06-23 21:21:01.025565
# Unit test for constructor of class Internet
def test_Internet():
    obj = Internet()
    assert isinstance(obj, Internet)
assert test_Internet()

# Generated at 2022-06-23 21:21:04.470405
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    provider = Internet()
    result = provider.ip_v4()
    assert isinstance(result, str)
    assert result == '83.60.10.87' or '213.5.119.122'


# Generated at 2022-06-23 21:21:08.525908
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    print(Internet().top_level_domain(TLDType.COUNTRY_CODE))


# Generated at 2022-06-23 21:21:12.231718
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    # Check if the ip_v6_object method of Internet class
    # is returning IPv6Address object
    internet = Internet(seed=1)
    assert isinstance(internet.ip_v6_object(), IPv6Address)


# Generated at 2022-06-23 21:21:15.060340
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    # Setup
    internet = Internet()
    # Exercise and Verify
    assert isinstance(internet.ip_v4_object(), IPv4Address)


# Generated at 2022-06-23 21:21:17.904481
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    internet = Internet()
    ipv4object = internet.ip_v4_object()
    assert isinstance(ipv4object, IPv4Address)


# Generated at 2022-06-23 21:21:26.861616
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    """Test for method top_level_domain of class Internet."""
    i = Internet(seed=123455)

    assert i.top_level_domain() == '.ru'
    assert i.top_level_domain(TLDType.MILITARY) == '.mil'
    assert i.top_level_domain(TLDType.COUNTRY) == '.ru'
    assert i.top_level_domain(TLDType.GENERIC) == '.com'

    try:
        i.top_level_domain(TLDType.TEST)
        assert True
    except NonEnumerableError:
        assert False



# Generated at 2022-06-23 21:21:30.117385
# Unit test for method port of class Internet
def test_Internet_port():
    int = Internet()
    print("test_Internet_port get port:"+str(int.port()))


if __name__ == '__main__':
    test_Internet_port()

# Generated at 2022-06-23 21:21:32.879566
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    for i in range(100):
        assert len(Internet().emoji()) == len(':kissing:')



# Generated at 2022-06-23 21:21:36.209757
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    with open('tests/test_files/internet_test.txt') as ipv6_file:
        ipv6_list = ipv6_file.readlines()
    class_internet = Internet(seed=1234)
    for i in range(0, 10):
        random_ipv6 = class_internet.ip_v6()
        assert random_ipv6 in ipv6_list

# Generated at 2022-06-23 21:21:40.810194
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    """Unit test for method ip_v6_object of class Internet."""
    internet = Internet()
    ipv6_obj = internet.ip_v6_object()
    assert isinstance(ipv6_obj, IPv6Address)



# Generated at 2022-06-23 21:21:42.225499
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    Internet()

# Generated at 2022-06-23 21:21:45.937755
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    """Tests the method home_page of the class Internet."""
    url = Internet().home_page()
    assert len(url) > 0
    assert url.startswith('https://')
    assert url.endswith('.com')


# Generated at 2022-06-23 21:21:48.359253
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    tmp = Internet()
    assert isinstance(tmp.http_status_code(), int)
    assert tmp.http_status_code() in HTTP_STATUS_CODES


# Generated at 2022-06-23 21:21:52.086830
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    internet = Internet()
    result = internet.image_placeholder()
    assert isinstance(result, str)
    assert result == 'http://placehold.it/1920x1080'


# Generated at 2022-06-23 21:21:57.019010
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    internet = Internet()
    http_status_codes = []
    for _ in range(100):
        http_status_codes.append(internet.http_status_code())
    assert len(http_status_codes) == 100
    assert sorted(http_status_codes) == sorted(list(HTTP_STATUS_CODES))

# Generated at 2022-06-23 21:21:59.435458
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    a = Internet()
    for _ in range(10):
        assert int(a.ip_v4_object()) <= a._MAX_IPV4

# Generated at 2022-06-23 21:22:00.021429
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    assert Internet().http_status_message() != None

# Generated at 2022-06-23 21:22:01.022542
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    pr = Internet()
    a = pr.ip_v4()
    print(a)


# Generated at 2022-06-23 21:22:05.220156
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    """Unit test of method home_page of class Internet."""
    i = Internet(seed=42)
    assert i.home_page() == 'https://bum.com'



# Generated at 2022-06-23 21:22:17.157908
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    from mimesis.enums import Layer
    from mimesis.enums import PortRange
    from mimesis.enums import TLDType
    internet = Internet()
    s = internet.http_status_code()
    s2 = internet.http_status_message()
    s3 = internet.http_method()
    s4 = internet.ip_v4()
    s5 = internet.ip_v6()
    s6 = internet.mac_address()
    s7 = internet.emoji()
    s8 = internet.image_placeholder()
    s9 = internet.stock_image()
    s10 = internet.hashtags()
    s11 = internet.top_level_domain()
    s12 = internet.user_agent()
    s13 = internet.network_protocol()
    s14 = internet.port

# Generated at 2022-06-23 21:22:22.187569
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    from mimesis.enums import TLDType
    from mimesis.providers.internet import Internet
    test_Internet = Internet('en')
    test_Internet.top_level_domain(tld_type=TLDType.INFRASTRUCTURE)

# Generated at 2022-06-23 21:22:31.134882
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    # Check correctness of URL if we just ask for simple image
    image_url = Internet().stock_image()
    assert image_url.startswith('https://source.unsplash.com/1920x1080?')
    # Check correctness of URL if we search by specific keyword
    image_url = Internet().stock_image(keywords=['cat'])
    assert image_url.startswith('https://source.unsplash.com/1920x1080?cat')
    # Check correctness of URL if we search by specific keywords
    image_url = Internet().stock_image(keywords=['cat', 'animal'])
    assert image_url.startswith('https://source.unsplash.com/1920x1080?cat,animal')

# Generated at 2022-06-23 21:22:35.947923
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    internet = Internet()
    ip = internet.ip_v4_object()
    assert(isinstance(ip, IPv4Address))

# Generated at 2022-06-23 21:22:40.227249
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    internet = Internet()
    #import pdb; pdb.set_trace()
    http_status_message = internet.http_status_message()
    assert type(http_status_message) is str


# Generated at 2022-06-23 21:22:41.343563
# Unit test for method port of class Internet
def test_Internet_port():
    x = Internet()
    assert x.port() == 0


# Generated at 2022-06-23 21:22:43.208766
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    from utility import Utility
    u = Utility('Internet')
    internet = Internet('Internet')
    x = internet.mac_address()
    u.tprint(x)


# Generated at 2022-06-23 21:22:47.066762
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    assert Internet.image_placeholder() == "http://placehold.it/1920x1080"
    assert Internet.image_placeholder(width=800, height=600) == "http://placehold.it/800x600"

# Generated at 2022-06-23 21:22:51.621025
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    from mimesis import Internet
    from mimesis.enums import MimeType
    mime = Internet().content_type(MimeType.AUDIO)
    assert mime == 'Content-Type: audio/mp4'


# Generated at 2022-06-23 21:22:57.822582
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    print('test_Internet_http_status_message')
    t = Internet()
    status_code = t.http_status_code()
    status_code_str = str(status_code)
    status_code_msg = t.http_status_message()
    assert status_code_msg.startswith(status_code_str)
    print('status_code=' + status_code_str)
    print('status_code_msg=' + status_code_msg)
    print()


# Generated at 2022-06-23 21:22:59.767820
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    a = Internet()
    ip_object = a.ip_v4_object()
    assert True


# Generated at 2022-06-23 21:23:03.117926
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    provider = Internet()
    for i in range(10):
        result = provider.content_type()
        assert result.startswith('Content-Type: ') == True


# Generated at 2022-06-23 21:23:08.662363
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    """Test method network_protocol."""
    internet = Internet()
    transport = Layer.TRANSPORT
    application = Layer.APPLICATION

    assert NETWORK_PROTOCOLS[transport].__contains__(
        internet.network_protocol(transport))
    assert NETWORK_PROTOCOLS[application].__contains__(
        internet.network_protocol(application))



# Generated at 2022-06-23 21:23:10.688251
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    internet = Internet()
    for i in range(10):
        content_type = internet.content_type()
        assert isinstance(content_type, str)

# Generated at 2022-06-23 21:23:12.678298
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    assert (Internet().image_placeholder(100, 100) ==
            'http://placehold.it/100x100')
    assert (Internet().image_placeholder(100, 100) !=
            'http://placehold.it/200x300')



# Generated at 2022-06-23 21:23:14.667429
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    internet = Internet()
    assert isinstance(internet.http_status_code(), int)


# Generated at 2022-06-23 21:23:18.023794
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    internet1 = Internet()
    assert type(internet1.home_page()) == str
    assert internet1.home_page().__contains__('https://')
    assert internet1.home_page().__contains__('io') or internet1.home_page().__contains__('in')

# Generated at 2022-06-23 21:23:20.690965
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    internet = Internet()
    http_status_message = internet.http_status_message()
    assert http_status_message in HTTP_STATUS_MSGS


# Generated at 2022-06-23 21:23:22.977470
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    from mimesis.enums import OS
    provider = Internet()
    user_agent = provider.user_agent(os=OS.LINUX)
    # print(user_agent)

# Generated at 2022-06-23 21:23:34.349782
# Unit test for constructor of class Internet
def test_Internet():
    internet = Internet()
    print(internet.content_type())
    print(internet.http_status_message())
    print(internet.http_status_code())
    print(internet.http_method())
    print(internet.ip_v4_object())
    print(internet.ip_v4())
    print(internet.ip_v4(True))
    print(internet.ip_v4(False))
    print(internet.ip_v6_object())
    print(internet.ip_v6())
    print(internet.mac_address())
    print(internet.emoji())
    print(internet.image_placeholder())
    print(internet.stock_image())
    print(internet.hashtags())
    print(internet.home_page())

# Generated at 2022-06-23 21:23:36.119957
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    """Unit test for method ip_v4 of class Internet."""
    ip = Internet()
    assert isinstance(ip.ip_v4(), str)


# Generated at 2022-06-23 21:23:39.864532
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    """Написать тест на метод emoji класса Internet"""
    internet = Internet()
    print(internet.emoji())
    print(len(EMOJI))
    assert internet.emoji() in EMOJI


# Generated at 2022-06-23 21:23:42.728809
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    intenet = Internet()
    strs = intenet.hashtags()
    assert isinstance(strs, str)
    assert strs.startswith('#')
    strs2 = intenet.hashtags(quantity=3)
    assert isinstance(strs2, list)
    assert len(strs2) == 3

# Generated at 2022-06-23 21:23:47.107956
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    internet = Internet()
    ip = internet.ip_v4_object()
    assert isinstance(ip, IPv4Address)
    assert str(ip) != ''
    assert int(ip) >= 0
    assert int(ip) <= 4294967295
    # Unit test for method ip_v4 of class Internet

# Generated at 2022-06-23 21:23:54.002518
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    from mimesis.enums import PortRange
    from mimesis.providers.internet import Internet
    from mimesis.types import MACAddressGenerator

    i = Internet()
    # print(i.mac_address())
    # print(i.port(port_range = PortRange.STANDARD))
    print(i.ip_v4(with_port = True))


if __name__ == '__main__':
    test_Internet_mac_address()

# Generated at 2022-06-23 21:23:54.959776
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    internet = Internet()

    assert internet.ip_v4() in str(type(internet.ip_v4_object()))

# Generated at 2022-06-23 21:24:00.993100
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    n = Internet(seed=1234567890)
    assert n.hashtags(quantity=0) == ''
    assert n.hashtags(quantity=1) == '#travel'
    assert n.hashtags(quantity=2) == '#fish'
    assert n.hashtags(quantity=3) == '#summer'
    assert n.hashtags(quantity=4) == '#selfie'
    assert n.hashtags(quantity=5) == '#sunset'
    assert n.hashtags(quantity=6) == '#party'
    assert n.hashtags(quantity=7) == '#beautiful'
    assert n.hashtags(quantity=8) == '#drink'
    assert n.hashtags(quantity=9) == '#art'


# Generated at 2022-06-23 21:24:08.389054
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    from mimesis.enums import MimeType
    from mimesis.providers.internet import Internet
    rand = Internet()
    for _ in range(10):
        result = rand.content_type()
        assert result != rand.content_type(MimeType.AUDIO)
        assert result != rand.content_type(MimeType.VIDEO)
        assert result != rand.content_type(MimeType.TEXT)
        assert result != rand.content_type(MimeType.IMAGE)
        assert result != rand.content_type(MimeType.FONT)
        assert result != rand.content_type(MimeType.APPLICATION)
        assert result != rand.content_type(MimeType.MESSAGE)
        assert result != rand.content_type(MimeType.MODEL)
        assert result

# Generated at 2022-06-23 21:24:09.796547
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    internet = Internet()
    print(internet.home_page())


# Generated at 2022-06-23 21:24:10.803705
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    internet = Internet()
    ip = internet.ip_v6_object()
    assert isinstance(ip, IPv6Address)

# Generated at 2022-06-23 21:24:13.157891
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    assert Internet().http_status_message()
    random.seed(0)
    assert Internet().http_status_message() == '200 OK'


# Generated at 2022-06-23 21:24:14.877270
# Unit test for method home_page of class Internet

# Generated at 2022-06-23 21:24:20.770438
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    # test case 1
    a = Internet().mac_address()
    assert a in ['00:16:3e:25:e7:b1', '00:16:3e:f4:11:ce',
                 '00:16:3e:b4:ee:94', '00:16:3e:a2:2a:b7']



# Generated at 2022-06-23 21:24:29.742410
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from mimesis.providers.internet import Internet
    from mimesis.enums import MimeType
    int = Internet('en')
    assert int.stock_image(1920, 1080) == 'https://source.unsplash.com/1920x1080'
    assert int.stock_image(1920, 1080, ['love']) == 'https://source.unsplash.com/1920x1080?love'
    assert int.stock_image(1920, 1080, ['love', 'sky']) == 'https://source.unsplash.com/1920x1080?love,sky'
    assert int.content_type(MimeType.JPEG) == 'Content-Type: image/jpeg'
    assert int.content_type(MimeType.TXT) == 'Content-Type: text/plain'

# Generated at 2022-06-23 21:24:31.160365
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    internet = Internet()
    print(internet.content_type())



# Generated at 2022-06-23 21:24:33.084002
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    response = internet.stock_image(writable = True)
    assert isinstance(response, bytes)

# Generated at 2022-06-23 21:24:34.088248
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    internet = Internet()
    #print(internet.ip_v4_object())

# Generated at 2022-06-23 21:24:39.119712
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    from mimesis.enums import PortRange
    internet = Internet()
    res = internet.ip_v4()
    assert isinstance(res, str)
    assert '.' in res and len(res.split('.')) == 4
    res = internet.ip_v4(with_port=True)
    assert isinstance(res, str)
    res = internet.ip_v4(with_port=True, port_range=PortRange.ALL)
    assert isinstance(res, str)
    assert '.' in res and len(res.split('.')) == 4
    assert ':' in res and len(res.split(':')) == 2


# Generated at 2022-06-23 21:24:44.225485
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    import pytest

    status_code = 0
    while status_code <= 0:
        status_code = int(input("Enter Status Code: "))

    internet = Internet()
    status_message = internet.http_status_message()

    if status_code == int(status_message.split()[0]):
        print("Status Message for Status Code {}: {}"
              .format(status_code, status_message))
    else:
        pytest.fail("Status Message for Status Code {}: {}"
              .format(status_code, status_message))


# Generated at 2022-06-23 21:24:52.046608
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    """Test for class Internet method ip_v4_object"""
    from mimesis.builtins import RussiaSpecProvider
    random_generator = RussiaSpecProvider()
    internet = Internet(random_generator)
    assert isinstance(internet.ip_v4_object(), IPv4Address), "ip_v4_object() did not return a IPv4Address object"
    assert str(internet.ip_v4_object()) == "195.144.183.121", "ip_v4_object() did not return a IPv4Address object"


# Generated at 2022-06-23 21:24:53.864743
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    print()
    print(Internet().user_agent())

if __name__ == '__main__':
    test_Internet_user_agent()

# Generated at 2022-06-23 21:24:59.192983
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    
    from mimesis.enums import DataSource
    from mimesis.providers.internet import Internet
    from mimesis.typing import Seed
    from mimesis.providers.base import BaseDataProvider
    
    seed_: Seed = 1
    internet: Internet = Internet(seed=seed_)
    assert isinstance(internet, (BaseDataProvider, object)) == True
    assert internet.user_agent() == 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.221 Safari/537.36 SE 2.X MetaSr 1.0'
    

# Generated at 2022-06-23 21:25:00.470133
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    assert '200 OK' in Internet().http_status_message()


# Generated at 2022-06-23 21:25:03.229602
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    provider = Internet()
    assert provider.http_status_message() in HTTP_STATUS_MSGS

# Generated at 2022-06-23 21:25:13.075076
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    """We check the method http_status_code for class Internet."""
    test = Internet()
    result = test.http_status_code()

    # We check the type of result
    test.test_data_type(value=result, target_type=int)

    # We check the value of result

# Generated at 2022-06-23 21:25:15.196871
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    provider = Internet()
    agent = provider.user_agent()
    assert isinstance(agent, str)
    print("test_Internet_user_agent ... ok")


# Generated at 2022-06-23 21:25:17.438017
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    from mimesis.enums import Client

    client = Client.FIREFOX

    provider = Internet('en')
    result = provider.user_agent(client=client)

    assert result.startswith('Mozilla')

# Generated at 2022-06-23 21:25:27.973754
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from mimesis.enums import MimeType
    from mimesis.providers.internet import Internet
    i = Internet()

    assert i.stock_image() == 'https://source.unsplash.com/1920x1080'

    assert i.stock_image(width=100, height=100) == \
        'https://source.unsplash.com/100x100'

    assert i.stock_image(keywords=['workspace', 'work']) == \
        'https://source.unsplash.com/1920x1080?workspace,work'

    assert isinstance(i.stock_image(writable=True), bytes)

    assert isinstance(
        i.stock_image(writable=True, mime_type=MimeType.JPG), bytes)


# Generated at 2022-06-23 21:25:41.060069
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    internet = Internet()
    # Change the value of enum constant TLDType.ALL
    assert internet.top_level_domain(tld_type=TLDType.ALL) != ''
    # Change the value of enum constant TLDType.COUNTRIES
    assert internet.top_level_domain(tld_type=TLDType.COUNTRIES) != ''
    # Change the value of enum constant TLDType.GEOGRAPHY
    assert internet.top_level_domain(tld_type=TLDType.GEOGRAPHY) != ''
    # Change the value of enum constant TLDType.GENERAL
    assert internet.top_level_domain(tld_type=TLDType.GENERAL) != ''
    # Change the value of enum constant TLDType.ICANN

# Generated at 2022-06-23 21:25:45.022526
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    ip1 = Internet().ip_v4()
    assert isinstance(ip1, str)
    ip2 = Internet().ip_v4(with_port=True)
    assert isinstance(ip2, str)
    print(ip1)
    print(ip2)

if __name__ == '__main__':
    test_Internet_ip_v4()

# Generated at 2022-06-23 21:25:53.672157
# Unit test for constructor of class Internet
def test_Internet():
    internet = Internet()
    internet.http_method()
    internet.ip_v4()
    internet.port()
    internet.content_type()
    internet.http_status_message()
    internet.http_status_code()
    internet.hashtags()
    internet.user_agent()
    internet.network_protocol()
    internet.home_page()
    internet.top_level_domain()
    internet.port(port_range=PortRange.WELL_KNOWN_PORT)
    internet.port(port_range=PortRange.EPHEMERAL)

# Generated at 2022-06-23 21:25:55.291771
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    internet = Internet()
    print(internet.http_method())


# Generated at 2022-06-23 21:25:56.914252
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    # list comprehension
    assert len([i for i in Internet().http_status_message()]) > 0

# Generated at 2022-06-23 21:25:59.852436
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    from mimesis.enums import HTTP
    from mimesis.providers.web import Web
    my_obj = Web()
    my_obj.internet.http_method()
    assert my_obj.internet.http_method() in HTTP.methods

# Generated at 2022-06-23 21:26:02.069814
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    i = Internet()
    print(i.content_type())

test_Internet_content_type()


# Generated at 2022-06-23 21:26:12.062658
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    print('Test for method ip_v6 of class Internet')
    internet = Internet()
    print('Internet.ip_v6():', internet.ip_v6())
    print('Internet.ip_v6():', internet.ip_v6())
    print('Internet.ip_v6():', internet.ip_v6())
    print('Internet.ip_v6():', internet.ip_v6())
    print('Internet.ip_v6():', internet.ip_v6())
    print('Internet.ip_v6():', internet.ip_v6())
    print('Internet.ip_v6():', internet.ip_v6())
    print('Internet.ip_v6():', internet.ip_v6())
    print('Internet.ip_v6():', internet.ip_v6())

# Generated at 2022-06-23 21:26:22.955741
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    """
    Test if method `network_protocol` works properly

    """
    internet = Internet()

    result = internet.network_protocol(layer=Layer.NETWORK)
    assert result in NETWORK_PROTOCOLS[Layer.NETWORK]

    result = internet.network_protocol(layer=Layer.LINK)
    assert result in NETWORK_PROTOCOLS[Layer.LINK]

    result = internet.network_protocol(layer=Layer.APPLICATION)
    assert result in NETWORK_PROTOCOLS[Layer.APPLICATION]

    result = internet.network_protocol(layer=Layer.TRANSPORT)
    assert result in NETWORK_PROTOCOLS[Layer.TRANSPORT]

    result = internet.network_protocol(layer=Layer.SESSION)
    assert result in NETWORK_

# Generated at 2022-06-23 21:26:24.543883
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    for _ in range(10):
        assert len(Internet.user_agent()) > 20


# Generated at 2022-06-23 21:26:27.090100
# Unit test for method home_page of class Internet
def test_Internet_home_page(): 
    internet = Internet() 
    home_page = internet.home_page() 
    print(home_page)
    

# Generated at 2022-06-23 21:26:30.012530
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    internet = Internet()
    result = internet.user_agent()
    assert result != None and isinstance(result, str)


# Generated at 2022-06-23 21:26:33.516352
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    from lib.mimesisextended import Internet
    from mimesis import Mimesis

    mimesis_internet = Internet(Mimesis('uk'))

    result = mimesis_internet.content_type()

    assert result


# Generated at 2022-06-23 21:26:35.941935
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    internet = Internet()
    random_emoji = internet.emoji()
    assert random_emoji in EMOJI
    assert True


# Generated at 2022-06-23 21:26:41.371079
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    """Unit test for method stock_image of class Internet."""
    import requests
    import tempfile
    from mimesis.providers.internet import Internet

    provider = Internet('en')
    width = 1080
    height = 1920
    keywords = ['nature', 'animal']

    url = provider.stock_image(
        width=width,
        height=height,
        keywords=keywords,
    )
    assert isinstance(url, str)

    try:
        image = provider.stock_image(
            width=width,
            height=height,
            keywords=keywords,
            writable=True
        )
    except urllib.error.URLError:
        image = requests.get(url).content

    assert isinstance(image, bytes)


# Generated at 2022-06-23 21:26:43.510332
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    test = Internet()
    print(test.ip_v4_object())


# Generated at 2022-06-23 21:26:45.493735
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    internet = Internet()
    assert internet.image_placeholder() in 'http://placehold.it/1920x1080'

# Generated at 2022-06-23 21:26:48.564128
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    status_code = Internet().http_status_code()
    assert status_code in HTTP_STATUS_CODES


# Generated at 2022-06-23 21:26:50.520760
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    home_page = Internet().home_page(tld_type=TLDType.DEFAULT)
    return home_page

# Generated at 2022-06-23 21:26:59.947270
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    """Unit test for method top_level_domain of class Internet."""
    internet = Internet("en")
    tld1 = internet.top_level_domain()
    assert tld1 in TLD["ALL"]
    tld2 = internet.top_level_domain(tld_type=TLDType.COUNTRY)
    assert tld2 in TLD["COUNTRY"]
    tld3 = internet.top_level_domain(tld_type=TLDType.GENERIC)
    assert tld3 in TLD["GENERIC"]
    tld4 = internet.top_level_domain(tld_type=TLDType.BRAND)
    assert tld4 in TLD["BRAND"]


# Generated at 2022-06-23 21:27:02.925894
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    user_agent_1 = Internet().user_agent()
    user_agent_2 = Internet().user_agent()

    if user_agent_1 == user_agent_2:
        raise AssertionError("user_agent 不是随机产生的")



# Generated at 2022-06-23 21:27:13.824358
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    from mimesis import Address
    from mimesis.enums import Layer, MimeType, PortRange, TLDType

    # Creating Internet instance
    internet = Internet('en')

    # Checking for user agent
    assert internet.user_agent() in USER_AGENTS

    # Checking for content type
    assert internet.content_type() in MimeType.__members__.values()

    # Checking for random IP
    assert internet.ip_v4() in IPv4Address.__members__.values()

    # Checking for random port
    assert internet.port() in PortRange.__members__.values()

    # Checking for network protocol
    assert internet.network_protocol(layer=Layer.TRANSPORT) in NETWORK_PROTOCOLS[Layer.TRANSPORT.value]

    # Checking for random TLD
    random

# Generated at 2022-06-23 21:27:15.976582
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    x = Internet()
    print(x.ip_v6())
    assert isinstance(x.ip_v6(), str)



# Generated at 2022-06-23 21:27:17.051999
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    assert Internet().image_placeholder()

# Generated at 2022-06-23 21:27:19.154682
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    # Initialize the class
    internet = Internet()
    result = internet.user_agent()
    print(result)




# Generated at 2022-06-23 21:27:26.701788
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    # Testing undefined tld_type parameter
    print(Internet().top_level_domain())
    # Testing defined tld_type parameter i.e. - Generic
    print(Internet().top_level_domain(tld_type=TLDType.GENERIC))
    # Testing defined tld_type parameter i.e. - Country
    print(Internet().top_level_domain(tld_type=TLDType.COUNTRY))
    # Testing defined tld_type parameter i.e. - Sponsored
    print(Internet().top_level_domain(tld_type=TLDType.SPONSORED))
    # Testing defined tld_type parameter i.e. - Infrastructure
    print(Internet().top_level_domain(tld_type=TLDType.INFRASTRUCTURE))
    # Testing defined tld_type parameter i.

# Generated at 2022-06-23 21:27:32.658684
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    from mimesis.enums import HTTP
    from mimesis.providers.other import Other
    from mimesis.providers.internet import Internet
    from mimesis.providers.file import File
    from mimesis.providers.text import Text
    #from mimesis.providers.lorem import Lorem

    other = Other('ru')
    internet = Internet('ru')
    file = File('ru')
    text = Text('ru')
    #lorem = Lorem('ru')

    assert internet.http_method() in HTTP.ALL


# Generated at 2022-06-23 21:27:35.008969
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    import re
    regex = re.compile('Chrome/[0-9][0-9][0-9][0-9].[0-9][0-9].[0-9][0-9]')
    result = Internet()
    assert regex.search(result.user_agent()) is not None

# Generated at 2022-06-23 21:27:36.333212
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    internet = Internet("bg")
    #print(internet.http_status_message())

# Generated at 2022-06-23 21:27:37.847746
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    internet = Internet()
    ip = internet.ip_v6_object()
        
    assert ip.version == 6

# Unit tests for method ip_v6 of class Internet

# Generated at 2022-06-23 21:27:46.281494
# Unit test for method port of class Internet
def test_Internet_port():
    # Test of simple call
    provider = Internet()
    port = provider.port()
    assert isinstance(port, int)

    # Test of PortRange.SYSTEM
    provider = Internet()
    port = provider.port(port_range=PortRange.SYSTEM)
    assert isinstance(port, int)
    assert port in range(*PortRange.SYSTEM.value)

    # Test of PortRange.REGISTERED
    provider = Internet()
    port = provider.port(port_range=PortRange.REGISTERED)
    assert isinstance(port, int)
    assert port in range(*PortRange.REGISTERED.value)

    # Test of PortRange.ALL
    provider = Internet()
    port = provider.port(port_range=PortRange.ALL)
    assert isinstance(port, int)
    assert port in range

# Generated at 2022-06-23 21:27:50.842871
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    from mimesis.enums import Layer
    from mimesis.enums import NetworkProtocols
    import pytest
    from mimesis.exceptions import NonFieldError

    internet = Internet()
    layer = Layer.APPLICATION
    assert isinstance(internet.network_protocol(layer=layer), str)
    assert isinstance(internet.network_protocol(), str)
    assert internet.network_protocol() in NetworkProtocols

    with pytest.raises(NonFieldError):
        internet.network_protocol(layer='test')

# Generated at 2022-06-23 21:27:59.992578
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():

    print("Testing method network_protocol(layer) of class Internet")
    internet = Internet(10)
    # Test with layer as None
    protocol = internet.network_protocol()
    print("network_protocol(None): ", protocol)
    # Test with layer as Layer.APPLICATION
    protocol = internet.network_protocol(layer=Layer.APPLICATION)
    print("network_protocol(Layer.APPLICATION): ", protocol)
    # Test with layer as Layer.TRANSPORT
    protocol = internet.network_protocol(layer=Layer.TRANSPORT)
    print("network_protocol(Layer.TRANSPORT): ", protocol)
    # Test with layer as Layer.INTERNET
    protocol = internet.network_protocol(layer=Layer.INTERNET)

# Generated at 2022-06-23 21:28:02.010919
# Unit test for method home_page of class Internet
def test_Internet_home_page():
	internet = Internet()
	home_page = internet.home_page()
	return home_page

print(test_Internet_home_page())


# Generated at 2022-06-23 21:28:07.618685
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    internet = Internet()
    status = internet.http_status_code()
    assert isinstance(status, int), 'Should return a int'
    assert status in HTTP_STATUS_CODES, 'Should return an HTTP code'


# Generated at 2022-06-23 21:28:10.682027
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    assert internet.hashtags(1) == '#love'
    assert type(internet.hashtags(0)) == list
    assert len(internet.hashtags(0)) == 0

# Generated at 2022-06-23 21:28:14.572894
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    # Set Parameters
    # Seed
    _seed = 5
    # Create object
    from mimesis.builtins import Internet
    _obj = Internet()
    # Set random seed
    _obj.seed(_seed)
    # Do test
    assert (_obj.emoji() == ':bow:')


# Generated at 2022-06-23 21:28:15.826049
# Unit test for constructor of class Internet
def test_Internet():
    internet = Internet()
    assert (not internet.seed is None)



# Generated at 2022-06-23 21:28:16.974924
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    assert Internet().ip_v6_object()


# Generated at 2022-06-23 21:28:19.841812
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    internet = Internet()
    x = internet.emoji()
    assert x in EMOJI

# Generated at 2022-06-23 21:28:30.217467
# Unit test for constructor of class Internet
def test_Internet():
    from mimesis.enums import PortRange

    provider = Internet('en')
    assert provider.content_type() in provider.__file.mime_types()
    assert provider.http_status_message() in HTTP_STATUS_MSGS
    assert provider.http_status_code() in HTTP_STATUS_CODES
    assert provider.http_method() in HTTP_METHODS
    assert isinstance(provider.ip_v4_object(), IPv4Address)
    assert provider.ip_v4() == str(provider.ip_v4_object())
    assert provider.ip_v6() == str(provider.ip_v6_object())
    assert len(provider.mac_address().split(':')) == 6
    assert provider.emoji() in EMOJI
    assert provider.image_placeholder

# Generated at 2022-06-23 21:28:31.478035
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    internet = Internet()
    domain = internet.top_level_domain()
    assert domain in TLD['com']

# Generated at 2022-06-23 21:28:36.085994
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    a = Internet()
    ip = a.ip_v4()
    #localhost 1
    assert ip == "0.0.0.0"
    #localhost 2
    ip = a.ip_v4()
    assert ip == "0.0.0.1"
    #127.0.0.1
    ip = a.ip_v4()
    assert ip == "127.0.0.1"


# Generated at 2022-06-23 21:28:37.952918
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    content_type = Internet().content_type()
    assert type(content_type) == str


# Generated at 2022-06-23 21:28:41.816820
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
	I = Internet()
	number_of_tests = 25
	for _ in range(number_of_tests):
		assert isinstance(I.top_level_domain(), str)

# Generated at 2022-06-23 21:28:52.938619
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    import re

# Generated at 2022-06-23 21:28:57.149336
# Unit test for method port of class Internet
def test_Internet_port():
    in_ = Internet()
    assert isinstance(in_.port(), int)
    assert isinstance(in_.port(port_range=PortRange.WELL_KNOWN), int)
    assert isinstance(in_.port(port_range=PortRange.REGISTERED), int)
    assert isinstance(in_.port(port_range=PortRange.DYNAMIC_AND_PRIVATE), int)
    assert isinstance(in_.port(port_range=PortRange.EPHEMERAL), int)



# Generated at 2022-06-23 21:29:00.332533
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    assert Internet.ip_v6.__doc__ is not None
    net = Internet()
    ip = net.ip_v6()
    assert ip is not None
    assert isinstance(ip, str)


# Generated at 2022-06-23 21:29:01.764867
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():

    internet = Internet()
    image = internet.image_placeholder()

    assert image == 'http://placehold.it/1920x1080'


# Generated at 2022-06-23 21:29:09.978831
# Unit test for method emoji of class Internet
def test_Internet_emoji():

  from mimesis.enums import Locale
  from mimesis.providers.internet import Internet

  Internet('en').emoji()  # => '🍕'
  Internet('ru').emoji()  # => '😂'

  Internet(locale='en').emoji()  # => '🦌'
  Internet(locale=Locale.EN).emoji()  # => '🦌'
  Internet(locale=Locale('en')).emoji()  # => '🦌'


# Generated at 2022-06-23 21:29:16.552936
# Unit test for constructor of class Internet
def test_Internet():
    from mimesis.enums import TLDType
    from mimesis.enums import Gender
    from mimesis.enums import Layer
    from mimesis.enums import PortRange
    from mimesis.providers.internet import Internet

    i = Internet(seed=100)
    # >>> i.seed(100)
    # >>> i.random.getstate()
    # (3, (array('l', [594528336486227919, 6729232683479771333, 4315890686512770952, 5631538028399480790, 5997822193701299820, 6518755715488390977, 3065192852436366460, 8645068613084257220,
    # 635395010876341405, 26892480

# Generated at 2022-06-23 21:29:23.096458
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    obj = Internet()
    print(obj.content_type())
    print(obj.content_type(MimeType.APPLICATION))
    print(obj.content_type(MimeType.IMAGE))
    print(obj.content_type(MimeType.AUDIO))
    print(obj.content_type(MimeType.VIDEO))


# Generated at 2022-06-23 21:29:24.709275
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    i = Internet()
    print(i.content_type())

# Generated at 2022-06-23 21:29:30.529048
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    """
    Unit test for method network_protocol of class Internet
    """
    from mimesis.enums import Layer

    assert Internet.network_protocol(layer=Layer.APPLICATION)
    assert Internet.network_protocol(layer=Layer.DATA)
    assert Internet.network_protocol(layer=Layer.NETWORK)
    assert Internet.network_protocol(layer=Layer.PRESENTATION)
    assert Internet.network_protocol(layer=Layer.SESSION)
    assert Internet.network_protocol(layer=Layer.TRANSPORT)

# Generated at 2022-06-23 21:29:32.951140
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    test_instance = Internet()
    assert isinstance(test_instance.ip_v4_object(), IPv4Address)


# Generated at 2022-06-23 21:29:38.981709
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    obj = Internet()
    value = obj.network_protocol(Layer.APPLICATION)
    assert value in ['AMQP', \
                     'BEEP', \
                     'DICT', \
                     'EDI', \
                     'FTP', \
                     'SIP', \
                     'SMB', \
                     'SNMP', \
                     'SOAP', \
                     'XMPP']
