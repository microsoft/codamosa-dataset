

# Generated at 2022-06-23 21:19:50.242053
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    internet_instance_obj = Internet()

    # Generating random HTTP status code using performance testing
    import timeit
    STATEMENT = 'internet_instance_obj.http_status_code()'
    SETUP_CODE = 'from __main__ import internet_instance_obj'
    number = 100000
    print(timeit.timeit(statement=STATEMENT, setup=SETUP_CODE, number=number))
    print(timeit.timeit(statement=STATEMENT, setup=SETUP_CODE, number=number))

test_Internet_http_status_code()


# Generated at 2022-06-23 21:19:56.619816
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    """
    unit test for method network_protocol of class Internet
    """
    result1 = Internet.network_protocol(Internet, layer="TCP")
    assert result1 in ("TCP", "UDP")
    result2 = Internet.network_protocol(Internet, layer="HTTP")
    assert result2 in ("HTTP", "HTTPS")
    result3 = Internet.network_protocol(Internet, layer="ALL")
    assert result3 in ("TCP", "UDP", "HTTP", "HTTPS")

# Generated at 2022-06-23 21:20:06.273357
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    internet = Internet()

    # Verify the output
    assert any([
        internet.content_type() == 'Content-Type: text/plain',
        internet.content_type(MimeType.AUDIO) == 'Content-Type: audio/mpeg',
        internet.content_type(MimeType.VIDEO) == 'Content-Type: video/x-msvideo',
        internet.content_type(MimeType.IMAGE) == 'Content-Type: image/jpeg',
        internet.content_type(MimeType.TEXT) == 'Content-Type: text/plain',
        internet.content_type(MimeType.APPLICATION) == 'Content-Type: application/json',
        internet.content_type(MimeType.MULTIPART) == 'Content-Type: multipart/form-data'
    ])

# Unit

# Generated at 2022-06-23 21:20:09.204096
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    internet = Internet(language='en', region='en')
    print(internet.http_status_message())

# Generated at 2022-06-23 21:20:12.012129
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    internet = Internet()
    user_agent = internet.user_agent()
    assert isinstance(user_agent, str)
    assert user_agent != ""



# Generated at 2022-06-23 21:20:13.177278
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    pass


# Generated at 2022-06-23 21:20:17.611415
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    i = Internet(None)
    assert i.top_level_domain(None) in TLD['ALL']
    assert i.top_level_domain(TLDType.COUNTRY) in TLD['COUNTRY']
    assert i.top_level_domain(TLDType.GENERIC) in TLD['GENERIC']
    assert i.top_level_domain(TLDType.BRAND) in TLD['BRAND']


# Generated at 2022-06-23 21:20:20.074249
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    internet = Internet()
    ip = internet.ip_v4_object()
    assert ip is not None



# Generated at 2022-06-23 21:20:21.271484
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    internet = Internet()
    result = internet.http_status_message()
    assert result in HTTP_STATUS_MSGS

# Generated at 2022-06-23 21:20:23.740661
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    """Unit test for method emoji of class Internet
    """
    internet = Internet()
    assert internet.emoji() in EMOJI

# Generated at 2022-06-23 21:20:29.618482
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    from mimesis.enums import PortRange
    internet = Internet()
    assert isinstance(internet.mac_address(), str)
    assert isinstance(internet.image_placeholder(), str)
    assert isinstance(internet.stock_image(), str)
    assert isinstance(internet.hashtags(2), str)
    assert isinstance(internet.home_page(TLDType.GENERAL_TLD), str)
    assert isinstance(internet.top_level_domain(), str)
    assert isinstance(internet.user_agent(), str)
    assert isinstance(internet.network_protocol(Layer.APPLICATION), str)
    assert isinstance(internet.port(PortRange.WELL_KNOWN_TCP), int)
    assert isinstance(internet.port(PortRange.ALL), int)

# Generated at 2022-06-23 21:20:35.424273
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    image = internet.stock_image(200,300)
    assert type(image) is str
    # Check integrity of the string
    assert image[:image.rfind('/')].rfind('/') == image.rfind('/') - 8
    assert len(image[:image.rfind('/')]) == 35


# Generated at 2022-06-23 21:20:37.560407
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    ip_v6_object = Internet().ip_v6_object()
    assert ip_v6_object

# Generated at 2022-06-23 21:20:40.296778
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    """Test to print a random top level domain."""
    internet = Internet()
    print(internet.top_level_domain(TLDType.COUNTRY_CODE))



# Generated at 2022-06-23 21:20:42.608903
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    internet = Internet()
    assert len(internet.ip_v4()) == 15 or len(internet.ip_v4()) == 19

# Generated at 2022-06-23 21:20:45.367295
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    internet = Internet()

    status = internet.http_status_code()

    assert isinstance(status, int)
    assert status > 0
    assert status < 600

# Generated at 2022-06-23 21:20:53.238641
# Unit test for method http_method of class Internet
def test_Internet_http_method(): #test1
    from mimesis.enums import HTTPRequestType
    from mimesis.providers.internet import Internet
    from mimesis.enums import HTTPRequestType
    internet = Internet()
    for i in range(100):
        method = internet.http_method()
        assert(method == HTTPRequestType.GET.value or method == HTTPRequestType.HEAD.value or method == \
                HTTPRequestType.POST.value or method == HTTPRequestType.PUT.value or method == \
                HTTPRequestType.DELETE.value or method == HTTPRequestType.CONNECT.value or method == \
                HTTPRequestType.OPTIONS.value or method == HTTPRequestType.TRACE.value or method == \
                HTTPRequestType.PATCH.value)


# Generated at 2022-06-23 21:20:55.057167
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    provider = Internet()
    url = provider.stock_image()
    assert url == 'https://source.unsplash.com/1920x1080?'

# Generated at 2022-06-23 21:20:57.169850
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    myInternet = Internet()
    ip = myInternet.ip_v6()

    assert ip is not None

# Generated at 2022-06-23 21:21:03.413680
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    http_methods = [
        'GET',
        'POST',
        'PUT',
        'DELETE',
        'PATCH',
        'HEAD',
        'OPTIONS',
        'CONNECT',
        'TRACE',
    ]
    for _ in range(100):
        user_agent = Internet().http_method()
        assert user_agent in http_methods

# Generated at 2022-06-23 21:21:07.910078
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    internet = Internet()
    ip_v4 = internet.ip_v4()
    assert ip_v4
    assert isinstance(ip_v4, str)



# Generated at 2022-06-23 21:21:09.810028
# Unit test for constructor of class Internet
def test_Internet():
    internet = Internet()
    assert (internet.internet_homepage().startswith('http'))

# Generated at 2022-06-23 21:21:13.312636
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    from mimesis.enums import HTTP
    from mimesis.providers.internet import Internet
    internet = Internet()
    assert internet.http_status_code() in HTTP.STATUS_CODES


# Generated at 2022-06-23 21:21:17.824818
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    # Initializing the class
    internet = Internet()
    # Getting the results
    result = internet.hashtags(3)
    # Generating the example
    example = ['#love', '#sky', '#nice']
    # Checking the result
    assert all(map(lambda x: x in result, example))

# Generated at 2022-06-23 21:21:26.138523
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    from collections import Counter

    seed = ['ip_v4_object']

    provider = Internet(seed)
    counter = Counter()
    for _ in range(1000):
        ip_v4_object = provider.ip_v4_object()
        counter[ip_v4_object] += 1
    print('#' * 80)
    print('Unit test for method ip_v4_object of class Internet:')
    print('Random IPv4Address object: ',
          counter.most_common()[0][0]
          )
    
test_Internet_ip_v4_object()

# Generated at 2022-06-23 21:21:28.873126
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    i = Internet()
    assert isinstance(i.hashtags(), str)
    assert isinstance(i.hashtags(quantity=10), list)

# Generated at 2022-06-23 21:21:32.112011
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    x = Internet()
    ipv4_object = x.ip_v4_object()
    isinstance(ipv4_object, IPv4Address)


# Generated at 2022-06-23 21:21:33.550355
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    a = Internet()
    b = Internet()
    assert (a.ip_v4() == b.ip_v4())


# Generated at 2022-06-23 21:21:34.891488
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    internet = Internet()
    # print(internet.home_page())
    assert internet.home_page() == "https://vitaly.su"

# Generated at 2022-06-23 21:21:35.816463
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    assert Internet().http_method() in HTTP_METHODS


# Generated at 2022-06-23 21:21:39.829482
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    test_Internet = Internet()
    test_result = test_Internet.http_status_code()
    assert test_result in HTTP_STATUS_CODES


# Generated at 2022-06-23 21:21:45.778698
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    internet = Internet("en")
    for i in range(10):
        print(internet.http_status_message())
    #
    '''
    OK
    Expectation Failed
    Unauthorized
    Unsupported Media Type
    Not Acceptable
    Internal Server Error
    OK
    Forbidden
    Request Timeout
    Request Timeout
    '''


# Generated at 2022-06-23 21:21:50.185206
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    """Unit test for method http_status_message of class Internet."""

    from mimesis.enums import PortRange

    internet = Internet()
    internet.random.seed(400)
    assert internet.http_status_message() == 'OK'

    internet.random.seed(0)
    assert internet.http_status_message() == 'OK'

    internet.random.seed(1000)
    assert internet.http_status_message() == 'OK'


# Generated at 2022-06-23 21:21:54.491858
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    # Setup
    random = Random()
    random.seed(0)  # Seed
    internet = Internet(random)

    # Exercise
    for _ in range(10):
        # Verify
        assert internet.http_status_message() in HTTP_STATUS_MSGS

# Generated at 2022-06-23 21:21:57.543517
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    # The emoji result is the same as expected
    assert Internet().emoji() == ':face_with_monocle:'

if __name__ == '__main__':
    test_Internet_emoji()

# Generated at 2022-06-23 21:21:59.894562
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    """Unit test for method http_status_code of class Internet."""
    internet = Internet()
    assert isinstance(internet.http_status_code(), int)


# Generated at 2022-06-23 21:22:02.028742
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    internet = Internet("ru")
    data = []
    for _ in range(100):
        data.append(internet.ip_v4())
    print(data)


# Generated at 2022-06-23 21:22:03.754451
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    internet = Internet()
    assert any(map(lambda x: x in HTTP_METHODS, [internet.http_method() for _ in range(100)]))

# Generated at 2022-06-23 21:22:08.715213
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    inet = Internet()
    print(inet.home_page())

    # inet_with_tld = Internet()
    # print(inet_with_tld.home_page(tld_type=TLDType.ALL))
    pass



# Generated at 2022-06-23 21:22:18.891535
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    from mimesis.enums import HTTP
    from mimesis.providers.internet import Internet
    from mimesis.providers.person import Person
    from mimesis.providers.cryptographic import Cryptographic
    
    
    mimesis = Internet()
    human = Person(seed=12345)
    password = Cryptographic(seed=12345)
    key = mimesis.random.randint(1, 7)
    value = ""
    
    L = [500, 501, 502, 503, 504, 505]
    value2 =mimesis.http_status_code();
    assert value2 in L
    value2 =mimesis.http_status_message();
    print(value2)
    

# Generated at 2022-06-23 21:22:22.880160
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    hash = Internet()
    print(hash.hashtags())
    print(hash.hashtags(1))
    print(hash.hashtags(2))
    print(hash.hashtags(5))


# Generated at 2022-06-23 21:22:24.582091
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    internet_obj = Internet()
    print(internet_obj.user_agent())

# Generated at 2022-06-23 21:22:25.558814
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    provider = Internet()
    assert provider.user_agent()

# Generated at 2022-06-23 21:22:27.244661
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    """Unit test for method network_protocol of class Internet."""
    internet = Internet()
    service = internet.network_protocol()
    print(service)

# Generated at 2022-06-23 21:22:28.912286
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    t=Internet()
    assert t.network_protocol(Layer.APPLICATION) in t.network_protocols()

# Generated at 2022-06-23 21:22:32.343413
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    internet = Internet()
    assert internet.http_status_message() in HTTP_STATUS_MSGS
    HTTP_STATUS_MSGS[:] = []


# Generated at 2022-06-23 21:22:35.357409
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    assert Internet().http_status_code() in HTTP_STATUS_CODES

# Generated at 2022-06-23 21:22:36.979885
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    obj = Internet()
    assert isinstance(obj.user_agent(), str)


# Generated at 2022-06-23 21:22:40.329798
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    from mimesis.enums import MimeType
    print("\n")
    print("Test Internet_emoji ")
    internet = Internet()
    print(internet.emoji())
    print("\n")


# Generated at 2022-06-23 21:22:41.450443
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    internet.stock_image(writable=True)

# Generated at 2022-06-23 21:22:43.856094
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    internet = Internet()
    user_agent = internet.user_agent()
    print(user_agent)


# Generated at 2022-06-23 21:22:50.257023
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    from mimesis.enums import MimeType
    from mimesis.providers.internet import Internet
    inter = Internet()
    assert (inter.content_type() == "Content-Type: image/gif")
    assert (inter.content_type(mime_type=MimeType.TEXT) == "Content-Type: text/plain")


# Generated at 2022-06-23 21:22:54.839111
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    internet = Internet()
    http_status_code = internet.http_status_code()
    http_status_code_list = [
        200, 301, 302, 304, 307,
        400, 401, 403, 404, 405, 409,
        451, 499,
        500, 501, 502, 503, 504, 507, 511,
    ]
    assert http_status_code in http_status_code_list


# Generated at 2022-06-23 21:23:05.949744
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    from mimesis.enums import PortRange
    from mimesis.providers.internet import Internet, TLDType

    internet = Internet()

    assert isinstance(internet.ip_v4(), str)
    assert isinstance(internet.ip_v4(with_port=True), str)
    assert isinstance(internet.ip_v4(with_port=True,
                                     port_range=PortRange.WELL_KNOWN), str)
    assert isinstance(internet.ip_v6(), str)
    assert isinstance(internet.mac_address(), str)
    assert isinstance(internet.emoji(), str)
    assert isinstance(internet.image_placeholder(), str)
    assert isinstance(internet.stock_image(), str)
    assert isinstance(internet.hashtags(quantity=4), (str, list))


# Generated at 2022-06-23 21:23:11.180603
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    def func():
        ip = Internet.ip_v4_object()
        return len(str(ip)) == 14

    result = utils.run_tests(Internet.ip_v4_object, args=None, kwargs=None,
                             num_tests=100, func=func,
                             test_type=TestType.FUNCTION)
    assert result.failed <= 0, result.err


# Generated at 2022-06-23 21:23:13.470243
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    provider = Internet()
    result = provider.top_level_domain()
    assert isinstance(result, str)
    assert len(result) > 1


# Generated at 2022-06-23 21:23:14.925545
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    Internet().top_level_domain(tld_type=TLDType.SUFFIX)

# Generated at 2022-06-23 21:23:17.216239
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    try:
        for i in range(0, 100):
            print(Internet().home_page())
    except NonEnumerableError:
        print("Error")


# Generated at 2022-06-23 21:23:20.966809
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    try:
        Internet().stock_image()
    except Exception as ex:
        assert ex == urllib.error.URLError('Required an active HTTP connection'), 'fail'

if __name__ == '__main__':
    test_Internet_stock_image()

# Generated at 2022-06-23 21:23:32.237538
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    t = Internet()
    for _ in range(100):
        assert t.network_protocol(Layer.NETWORK) in ['IP', 'IPv4', 'IPv6', 'ICMP']
        assert t.network_protocol(Layer.TRANSPORT) in ['TCP', 'UDP', 'DCCP', 'SCTP', 'RSVP', 'RTP', 'RTCP']
        assert t.network_protocol(Layer.SESSION) in ['SSH', 'ISAKMP', 'L2TP', 'L2F', 'PPTP', 'RTP', 'RTCP']
        assert t.network_protocol(Layer.PRESENTATION) in ['HTTP', 'HTTPS', 'TLS', 'SSL', 'SSLv2', 'SSLv3']

# Generated at 2022-06-23 21:23:35.047241
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    """Unit test for method content_type of class Internet"""
    file = File()
    assert str(file.mime_type()) in Internet().content_type()



# Generated at 2022-06-23 21:23:37.384163
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    label = "emoji"
    obj = Internet(seed=777)
    result = obj.emoji()
    expected = ":worried:"
    assert result == expected

# Generated at 2022-06-23 21:23:39.371337
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    print("\nTest Internet.ip_v6()")
    internet = Internet()
    print(internet.ip_v6())


# Generated at 2022-06-23 21:23:41.623622
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():

     # Create a object of class Internet
     internet = Internet()
     result = internet.http_status_message()
     print(result)

     # Assertion: The variable result must be 'successful return'.
     assert result == 'successful return'


# Generated at 2022-06-23 21:23:43.563588
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    """Test for method hashtags."""
    #  Get a list of hashtags
    assert Internet.hashtags(quantity=2)

    #  Get a list of hashtags
    assert Internet.hashtags(quantity=1)



# Generated at 2022-06-23 21:23:47.410348
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    from utils import assert_enum
    internet = Internet('en')
    for _ in range(100):
        assert_enum(internet, 'http_method', HTTP_METHODS)



# Generated at 2022-06-23 21:23:49.780321
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    from pprint import pprint
    internet = Internet()
    pprint(internet.user_agent())



# Generated at 2022-06-23 21:23:55.144624
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    internet = Internet(seed=1)
    method = internet.http_method()
    # Teste se o método retornou uma string
    assert type(method) == str
    # Teste se o método retornou um uma das opções possíveis
    assert method in HTTP_METHODS


# Generated at 2022-06-23 21:23:59.883630
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    assert Internet().user_agent() == 'Mozilla/5.0 (X11; Linux x86_64) ' \
                                      'AppleWebKit/537.36 (KHTML, like Gecko) ' \
                                      'Chrome/83.0.4103.61 Safari/537.36'

# Generated at 2022-06-23 21:24:06.166115
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    class Internet_test_home_page(Internet):
        def __init__(self):
            super().__init__()

        def seed(self, seed: int):
            return seed

        def top_level_domain(self, tld_type: Optional[TLDType] = None) -> str:
            return 'google.com'

    internet = Internet_test_home_page()
    home_page = internet.home_page(tld_type=TLDType.COUNTRY_CODES)
    print(home_page)
    print(home_page == 'https://google.com')



# Generated at 2022-06-23 21:24:07.432450
# Unit test for constructor of class Internet
def test_Internet():
    obj = Internet()
    assert obj


# Generated at 2022-06-23 21:24:12.377638
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    ipv6 = Internet().ip_v6_object()
    assert ipv6
    assert isinstance(ipv6, IPv6Address)
    assert str(ipv6) == '2001:c244:cf9d:1fb1:c56d:f52c:8a04:94f3'


# Generated at 2022-06-23 21:24:14.413370
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
	internet = Internet()
	internet.ip_v6_object()

# Generated at 2022-06-23 21:24:19.233164
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    i = Internet()
    j = Internet()

    print(f'http_method = {i.http_method()}')
    print(f'http_method = {j.http_method()}')

    assert i.http_method() == 'DELETE' and j.http_method() == 'DELETE'


# Generated at 2022-06-23 21:24:28.834603
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    from mimesis.typing import Seed
    from mimesis.enums import HTTPStatusCode, HTTPStatusMessage

    internet = Internet(seed=Seed(10))
    message = internet.http_status_message()
    assert isinstance(message, str)
    assert message == HTTPStatusMessage.OK

    http_status = HTTPStatusCode.NOT_FOUND
    message = HTTPStatusMessage(http_status)
    assert isinstance(message, str)
    assert message == HTTPStatusMessage.NOT_FOUND

    def test_http_status_message_non_enumerable():
        http_status = 9999
        message = HTTPStatusMessage(http_status)
        assert isinstance(message, str)
        assert message == HTTPStatusMessage.ERROR


# Generated at 2022-06-23 21:24:31.205762
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    internet = Internet()
    result = internet.user_agent()
    assert isinstance(result, str)
    assert result


# Generated at 2022-06-23 21:24:39.538218
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    from mimesis.enums import TLDType
    from mimesis.providers.internet import Internet

    internet = Internet()
    tags = internet.hashtags(quantity=10)
    assert isinstance(tags, list)
    assert len(tags) == 10
    assert tags[0].startswith('#')
    assert internet.top_level_domain(tld_type=TLDType.country) in TLD.country
    assert internet.http_method() in HTTP_METHODS
    assert internet.http_status_code() in HTTP_STATUS_CODES
    assert internet.http_status_message() in HTTP_STATUS_MSGS
    assert internet.user_agent() in USER_AGENTS

# Generated at 2022-06-23 21:24:44.418350
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    from mimesis.enums import TLDType

    internet = Internet()
    tld = internet.top_level_domain(tld_type= TLDType.ALL)

    # assert tld in TLD[TLDType.ALL]
    assert tld in TLD.ALL



# Generated at 2022-06-23 21:24:46.132585
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    assert Internet().ip_v6()


# Generated at 2022-06-23 21:24:52.733074
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    """Test of the method
        stock_image of the class Internet
    """
    from mimesis.builtins import Internet
    # with keywords
    result = Internet().stock_image(keywords=['cats'])
    assert result.startswith(
        'https://source.unsplash.com/1920x1080?cats') is True
    # without keywords
    result = Internet().stock_image()
    assert result.startswith(
        'https://source.unsplash.com/1920x1080?') is True

# Generated at 2022-06-23 21:24:55.605465
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    internet = Internet()
    status_code = internet.http_status_message()
    assert status_code in HTTP_STATUS_MSGS
    assert isinstance(status_code, str)
    print("Test OK method http_status_message")


# Generated at 2022-06-23 21:24:57.027470
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    assert isinstance(internet.hashtags(), str)

# Generated at 2022-06-23 21:24:59.931428
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    """Test Internet.emoji() method."""
    inter = Internet()
    emoji = inter.emoji()
    assert isinstance(emoji, str)
    assert len(emoji) > 0

# Generated at 2022-06-23 21:25:04.180645
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    print("Test method ip_v4_object of class Internet")
    provider_internet = Internet('es')
    res = isinstance(provider_internet.ip_v4_object(), IPv4Address)
    assert res == True


# Generated at 2022-06-23 21:25:08.013303
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from PIL import Image
    from io import BytesIO

    internet = Internet()
    im = Image.open(BytesIO(internet.stock_image(writable=True)))

    assert isinstance(im, Image.Image)
    assert isinstance(internet.stock_image(writable=True), bytes)

# Generated at 2022-06-23 21:25:16.982981
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    from mimesis.enums import Layer, PortRange
    from mimesis.typing import LayerSpecifier
    from tests.utils import TestDataValue
    case = TestDataValue('http_status_message')


# Generated at 2022-06-23 21:25:19.021880
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    internet = Internet()
    result = internet.content_type()
    test_result(result)



# Generated at 2022-06-23 21:25:20.246748
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    int_obj = Internet()
    assert type(int_obj.emoji()) == str


# Generated at 2022-06-23 21:25:26.255256
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    """Unit test for method network_protocol."""
    mock = [
        (None, lambda x: x in NETWORK_PROTOCOLS.values()),
        (Layer.UNKNOWN, lambda x: x in ['HTTP', 'SSH', 'AMPQ']),
    ]

    for item, validator in mock:
        p = Internet()
        result = p.network_protocol(item)
        assert validator(result)

# Generated at 2022-06-23 21:25:27.809841
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    ip = Internet()
    ipv6 = ip.ip_v6()
    print(ipv6)

# Generated at 2022-06-23 21:25:31.101500
# Unit test for method port of class Internet
def test_Internet_port():
    inte = Internet()
    assert isinstance(inte.port(), int)


# Generated at 2022-06-23 21:25:42.673640
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    internet = Internet()
    # Layer.APPLICATION
    assert internet.network_protocol(layer=Layer.APPLICATION) in [
        'MLD',
        'ICMP',
        'DHCP',
        'TCP',
        'BGP',
        'RSVP',
        'HTTP',
        'TLS',
        'OCSP',
        'TACACS',
        'NNTP',
        'RPC',
        'SMB',
        'SIP',
        'SMPP',
        'SSH',
        'IMAP4',
        'MIME',
    ]
    # Layer.PRESENTATION

# Generated at 2022-06-23 21:25:44.837622
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    internet = Internet()
    IP = internet.ip_v4_object()
    assert IP.version == 4, 'Wrong version of generated IP address'


# Generated at 2022-06-23 21:25:53.076740
# Unit test for method port of class Internet
def test_Internet_port():
    from mimesis.enums import PortRange

    s = Internet('en')

    assert s.port() in range(65535)
    assert s.port(PortRange.WELL_KNOWN_SERVICES) in range(1024)
    assert s.port(PortRange.REGISTERED_PORTS) in range(1024, 49151)
    assert s.port(PortRange.DYNAMIC_AND_PRIVATE_PORTS) in range(49152, 65535)
    assert s.port(PortRange.ALL) in range(65535)

# Generated at 2022-06-23 21:25:55.586247
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    i = Internet()
    tld = i.top_level_domain()
    print('top_level_domain: ' + tld)
    assert tld is not None


# Generated at 2022-06-23 21:25:57.562405
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    int = Internet()
    assert int.hashtags(quantity=1) != int.hashtags(quantity=2)


# Generated at 2022-06-23 21:25:58.696478
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    internet = Internet(random_state=10)
    assert internet.http_status_code() == 415

# Generated at 2022-06-23 21:26:03.690088
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    from mimesis.enums import PortRange, TLDType
    from mimesis.providers.internet import Internet

    int = Internet('en')
    for _ in range(5):
        print(int.mac_address())
        print('\n')



# Generated at 2022-06-23 21:26:05.748165
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    internet = Internet()
    ip = internet.ip_v4()

    assert ip, 'Bad ip_v4'


# Generated at 2022-06-23 21:26:07.916100
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    internet = Internet()
    assert internet.emoji() in EMOJI

# Generated at 2022-06-23 21:26:08.846246
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    pass


# Generated at 2022-06-23 21:26:15.146616
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from PIL import Image
    from math import isclose
    from mimesis.typing import Writable
    from os.path import splitext

    initial_width = 1920
    initial_height = 1080
    internet = Internet()
    img = internet.stock_image(
        initial_width,
        initial_height,
        writable=True,
    )

    if isinstance(img, Writable):
        image_name = splitext(__file__)[0] + '.jpg'

        with open(image_name, 'wb') as f:
            f.write(img)

        im = Image.open(image_name)
        w, h = im.size

        assert isclose(initial_width, w)
        assert isclose(initial_height, h)

# Generated at 2022-06-23 21:26:17.248104
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    Internet.http_status_message()
    assert True


# Generated at 2022-06-23 21:26:21.613744
# Unit test for constructor of class Internet
def test_Internet():
    internet = Internet()
    assert internet.__file.__class__.__name__ == 'File'
    assert internet._MAX_IPV4 == 4294967295
    assert internet._MAX_IPV6 == 340282366920938463463374607431768211455


# Generated at 2022-06-23 21:26:25.072511
# Unit test for method port of class Internet
def test_Internet_port():
    TestClass = Internet(random=True)
    TestClass.port(port_range=PortRange.SYSTEM)
    TestClass.port(port_range=PortRange.USER)
    TestClass.port(port_range=PortRange.WELL_KNOWN)



# Generated at 2022-06-23 21:26:36.576202
# Unit test for constructor of class Internet
def test_Internet():
    INTERNET = Internet()

    assert INTERNET.content_type('HTML') in ('Content-Type: text/html',
                                             'Content-Type: text/html; charset=UTF-8')

# Generated at 2022-06-23 21:26:43.665847
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    tld_types = [TLDType.ALL, TLDType.CC, TLDType.GENERIC, TLDType.GEO, TLDType.INTERNATIONAL]
    for tld_type in tld_types:
        for _ in range(10):
            internet = Internet(seed=0, tld_type=tld_type)
            tld = internet.top_level_domain(tld_type=tld_type)
            assert tld not in ['', None]

# Generated at 2022-06-23 21:26:48.550347
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    """Check for correct work of method Internet.network_protocol."""
    from mimesis.enums import Layer

    internet = Internet()
    assert 'UDP' in internet.network_protocol(layer=Layer.TRANSPORT)
    assert 'TLS' in internet.network_protocol(layer=Layer.APPLICATION)

# Generated at 2022-06-23 21:26:58.543667
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    from mimesis.enums import PortRange
    from mimesis.enums import Layer
    from mimesis.enums import TLDType
    from mimesis.enums import MimeType
    from mimesis import Internet
    import re
    import ipaddress

    # Test case 1:
    # Check that the generated ip is a ipv4.
    obj = Internet(seed=None)
    ipv4 = str(obj.ip_v4_object())
    assert isinstance(ipaddress.IPv4Address(ipv4), ipaddress.IPv4Address)

    # Test case 2:
    # Check that content-type is valid.
    obj = Internet(seed=None)
    assert re.search("^Content-Type: .+$", obj.content_type())

    # Test case 3:
    #

# Generated at 2022-06-23 21:27:00.699701
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    internet = Internet()
    assert internet.image_placeholder()



# Generated at 2022-06-23 21:27:02.520086
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    internet = Internet()
    assert internet.emoji() in EMOJI


# Generated at 2022-06-23 21:27:10.420967
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    from mimesis.enums import Layer
    from mimesis.providers.internet import Internet

    my_internet = Internet()

    assert 'AMQP' in set([my_internet.network_protocol() for _ in range(10)])
    assert 'TCP' in set([my_internet.network_protocol(layer=Layer.TRANSPORT) for _ in range(10)])
    assert 'QUIC' in set([my_internet.network_protocol(layer=Layer.APPLICATION) for _ in range(10)])

# Generated at 2022-06-23 21:27:14.089114
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    internet = Internet()
    ip = internet.ip_v6_object()
    assert isinstance(ip, IPv6Address), \
        'Expected a valid IPv6 Address object, but got %s' % type(ip)



# Generated at 2022-06-23 21:27:18.932234
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    ip = Internet()
    ip.seed(1)
    result = ip.home_page()
    assert result == 'https://sophia.info'

    ip.seed(2)
    result = ip.home_page()
    assert result == 'https://lynx.info'
    pass


if __name__ == '__main__':
    test_Internet_home_page()

# Generated at 2022-06-23 21:27:24.622512
# Unit test for constructor of class Internet
def test_Internet():
    internet = Internet()
    ip = internet.ip_v4()
    assert isinstance(ip, str)
    assert (ip[0].isnumeric() and ip[0] != 0) and ip[1] == '.'
    assert (ip[4].isnumeric() and ip[4] != 0) and ip[5] == '.'
    assert (ip[8].isnumeric() and ip[8] != 0) and ip[9] == '.'
    assert (ip[12].isnumeric() and ip[12] != 0)

# Generated at 2022-06-23 21:27:33.134871
# Unit test for method port of class Internet
def test_Internet_port():
    import random as _random

# Generated at 2022-06-23 21:27:35.062009
# Unit test for method port of class Internet
def test_Internet_port():
    """Unit test for method port of class Internet."""
    port_range = PortRange.REGISTRY
    internet = Internet()
    answer = True if 1024 <= internet.port(port_range) <= 49151 else False
    assert answer



# Generated at 2022-06-23 21:27:38.199680
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    internet_1 = Internet()
    internet_2 = Internet(seed=1)
    try:
        assert internet_1.mac_address() == "00:16:3e:25:e7:b1"
        assert internet_2.mac_address() == "00:16:3e:25:e7:b1"
        assert internet_1.mac_address() != internet_2.mac_address()
    except error:
        print(error)


# Generated at 2022-06-23 21:27:40.261837
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    ip = Internet()
    a = ip.image_placeholder()
    assert a == "http://placehold.it/1920x1080"


# Generated at 2022-06-23 21:27:44.892516
# Unit test for method port of class Internet
def test_Internet_port():
    internet = Internet()
    port_test = internet.port(PortRange.WELL_KNOWN)
    assert port_test >= 0
    assert port_test <= 1023
    port_test = internet.port(PortRange.UNREGISTERED)
    assert port_test >= 1024
    assert port_test <= 49151
    port_test = internet.port(PortRange.DYNAMIC)
    assert port_test >= 49152
    assert port_test <= 65535
    port_test = internet.port()
    assert port_test >= 0
    assert port_test <= 65535



# Generated at 2022-06-23 21:27:47.361807
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    """Unit test for method http_status_code of class Internet.

    """
    obj_internet = Internet()
    assert(obj_internet.http_status_code() != None)


# Generated at 2022-06-23 21:27:49.859330
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    provider = Internet()
    result = provider.content_type()
    assert type(result) is str


# Generated at 2022-06-23 21:27:56.635014
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    for _ in range(10):
        foo = Internet(seed=1)
        assert foo.network_protocol() == 'AMQP'
        assert foo.network_protocol(layer=Layer.APPLICATION) == 'AMQP'
        assert foo.network_protocol(layer=Layer.PRESENTATION) == 'SMTP'
        assert foo.network_protocol(layer=Layer.SESSION) == 'SNAP'

# Generated at 2022-06-23 21:27:59.353552
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    for layer in Layer:
        try:
            protocol = Internet().network_protocol(layer=layer)
        except NonEnumerableError:
            continue
        assert isinstance(protocol, str)

# Generated at 2022-06-23 21:28:01.724266
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    internet = Internet()
    http_status_code_1 = internet.http_status_code()
    assert http_status_code_1 in HTTP_STATUS_CODES


# Generated at 2022-06-23 21:28:03.492532
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    """
    Test method home_page of class Internet.
    """
    internet = Internet()
    result = internet.home_page()
    assert result == "https://dpicani.org"

# Generated at 2022-06-23 21:28:06.754845
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    internet = Internet()
    domain_type = internet.top_level_domain()
    assert domain_type in TLD

# Generated at 2022-06-23 21:28:10.276026
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    """
    Unit test for method mac_address of class Internet
    """
    internet = Internet()
    result = internet.mac_address()
    assert result is not None
    assert len(result) == 17
    assert ':' in result


# Generated at 2022-06-23 21:28:11.903552
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    internet = Internet()
    assert isinstance(internet.home_page(), str)


# Generated at 2022-06-23 21:28:14.413523
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    internet = Internet()
    result = internet.ip_v4_object()
    assert str(result) == str(IPv4Address(result))


# Generated at 2022-06-23 21:28:19.573444
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    from mimesis.enums import Layer
    from mimesis.providers.internet import Internet

    class testInternet(Internet):
        def __init__(self):
            Internet.__init__(self, seed=1)

    ti = testInternet()

    assert ti.network_protocol(Layer.LINK) == '802.11'
    assert ti.network_protocol(Layer.TRANSPORT) == 'SCTP'
    assert ti.network_protocol(Layer.SESSION) == 'DDP'

# Generated at 2022-06-23 21:28:21.464846
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    internet = Internet()
    assert internet.emoji() in EMOJI


# Generated at 2022-06-23 21:28:22.714579
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    internet = Internet()
    assert internet.http_status_message() in HTTP_STATUS_MSGS

# Generated at 2022-06-23 21:28:24.549432
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    '''
    Test hashtags
    '''
    seed = 40
    obj = Internet(seed=seed)
    r = obj.hashtags(quantity=3)
    assert r == ['#intelligence', '#follow', '#blackandwhite']


# Generated at 2022-06-23 21:28:25.829123
# Unit test for constructor of class Internet
def test_Internet():
    internet = Internet('en')
    assert internet is not None
    print ("Successful initialization of Internet")


# Generated at 2022-06-23 21:28:31.999227
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    internet = Internet()
    assert internet.home_page() == 'https://musedecay4.info'
    assert internet.home_page() == 'https://unyieldingcobweb.net'
    assert internet.user_agent() != internet.home_page()
    assert internet.ip_v4(with_port=False) != internet.home_page()
    assert internet.top_level_domain() != internet.home_page()
    assert internet.top_level_domain(tld_type='country_code') != internet.top_level_domain()

# Generated at 2022-06-23 21:28:33.084235
# Unit test for constructor of class Internet
def test_Internet():
    internet = Internet()
    assert internet is not None


# Generated at 2022-06-23 21:28:34.917794
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    provider = Internet()
    assert provider.image_placeholder().startswith('http')


# Generated at 2022-06-23 21:28:36.240357
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    assert Internet.http_status_message() == 'OK'


# Generated at 2022-06-23 21:28:38.488805
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    internet = Internet()
    res = internet.user_agent()
    assert type(res) == str
    assert len(res) > 0

# Generated at 2022-06-23 21:28:45.697391
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    obj = Internet()
    assert(str(obj.ip_v4_object()) == '84.0.5.5')
    assert(str(obj.ip_v4_object()) == '0.0.0.0')
    assert(str(obj.ip_v4_object()) == '224.0.0.1')
    assert(str(obj.ip_v4_object()) == '127.0.0.1')
    assert(str(obj.ip_v4_object()) == '192.0.2.2')
    assert(str(obj.ip_v4_object()) == '192.168.23.1')
    assert(str(obj.ip_v4_object()) == '169.254.1.1')

# Generated at 2022-06-23 21:28:48.148648
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    a = Internet()
    for i in range(10):
        c = a.http_method()
        print(c)


# Generated at 2022-06-23 21:28:51.469217
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    mime_type = 'application/json'
    res = Internet().content_type()

    assert isinstance(res, str)
    assert res.startswith('Content-Type')


# Generated at 2022-06-23 21:28:54.251621
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    from mimesis.enums import Layer
    internet = Internet()
    assert internet.network_protocol(layer=Layer.ONE) in list(NETWORK_PROTOCOLS[Layer.ONE])

# Generated at 2022-06-23 21:29:01.420170
# Unit test for constructor of class Internet
def test_Internet():
    print("***************************************************")
    print("Initializing attributes for Internet class")
    print("***************************************************")
    print("Initializing seed for Internet class")
    print("Seed: ", end="")
    seed = input()
    internet = Internet(seed=seed)
    print("***************************************************")
    print("Testing getter for class attributes")
    print("***************************************************")
    print("Content type: ", internet.content_type())
    print("HTTP status message: ", internet.http_status_message())
    print("HTTP status code: ", internet.http_status_code())
    print("HTTP method: ", internet.http_method())
    print("IP v4: ", internet.ip_v4())
    print("IP v6: ", internet.ip_v6())
    print("MAC address: ", internet.mac_address())

# Generated at 2022-06-23 21:29:02.329722
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    print(Internet().http_status_message())

# Generated at 2022-06-23 21:29:12.382214
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    import re
    from mimesis.enums import MimeType
    from mimesis.typing import Enum

    internet = Internet()
    re_type = re.compile(
        r'\bContent-Type:\sapplication|audio|font|example|image|message|model|'
        r'multipart|text|video')
    assert bool(re_type.match(internet.content_type()))

    internet = Internet(mime_type=MimeType.IMAGE)
    assert bool(re_type.match(internet.content_type()))

    internet = Internet(mime_type=Enum)
    assert bool(re_type.match(internet.content_type()))



# Generated at 2022-06-23 21:29:16.459740
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    assert str(Internet().ip_v6_object())=="bbcN:b6A8:6f:d6a:9e:b42a:66:e5d5"


# Generated at 2022-06-23 21:29:18.692037
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    myInternet = Internet()
    assert myInternet.ip_v4_object() == IPv4Address('123.124.124.124')


# Generated at 2022-06-23 21:29:21.356222
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    http_status_message = Internet().http_status_message()
    print(http_status_message)
    assert http_status_message != ""

if __name__ == '__main__':

    test_Internet_http_status_message()

# Generated at 2022-06-23 21:29:23.715412
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    """Unit test for method ip_v4 of class Internet."""
    internet = Internet()
    ip = internet.ip_v4(with_port=True)
    assert len(ip.split(':')) == 2

# Generated at 2022-06-23 21:29:29.729171
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    internet_generator = Internet()
    print("\n")
    print("Internet IPv4: ")
    print("Generating random IPv4 address")
    print("Generated: " + internet_generator.ip_v4())
    print("\n")
    print("Generating random IPv4 address with port")
    print("Generated: " + internet_generator.ip_v4(with_port=True, port_range=PortRange.COMMON))
    print("\n")


# Generated at 2022-06-23 21:29:32.202968
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    internet = Internet()
    print(internet.home_page())

if __name__ == '__main__':
    test_Internet_home_page()

# Generated at 2022-06-23 21:29:35.220259
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    # Create a instance
    instance = Internet("ru")
    # Run method
    result = instance.ip_v6()

    # Check result
    assert isinstance(result,str)
    assert len(result) == 39

# Generated at 2022-06-23 21:29:41.744448
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    # test_content_type.txt is a content_type_txt file
    f = open("test_content_type.txt", "r")
    # test_case is a list
    test_case = f.read().split("\n")
    # create an object of Internet class
    ii = Internet()
    # Assert the content_type method whether the result is in test_case
    assert ii.content_type() in test_case
