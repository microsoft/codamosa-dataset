

# Generated at 2022-06-23 21:19:53.957147
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    from mimesis.enums import PortRange
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.file import File
    from mimesis.providers.generic import Generic
    from mimesis.providers.misc import Misc

    internet = Internet(Datetime, File, Generic, Misc, seed=42)
    internet.get_random = lambda: 0

    assert internet.http_status_message() == 'Continue'
    assert internet.http_status_message() == 'Switching Protocols'

    internet.get_random = lambda: 1
    assert internet.http_status_message() == 'OK'
    assert internet.http_status_message() == 'Accepted'

    internet.get_random = lambda: 2
    assert internet.http_status_message() == 'Created'

# Generated at 2022-06-23 21:19:57.036005
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    print('test_Internet_ip_v4')
    internet = Internet()
    ip = internet.ip_v4()
    domain = internet.top_level_domain()
    url = internet.home_page()
    assert ip in url
    assert domain in url



# Generated at 2022-06-23 21:20:02.380955
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():

    from mimesis.enums import PortRange

    print("start test_Internet_ip_v6")

    # 测试ipv6地址
    for i in range(100):
        ipv6_address = Internet().ip_v6()
        assert len(ipv6_address)==39;

    print("end test_Internet_ip_v6")

# Generated at 2022-06-23 21:20:06.701249
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    from mimesis.enums import TLDType
    from tests.utils import check_iterable_type
    tld_type = TLDType.COUNTRY
    internet = Internet('ru')
    result = internet.home_page(tld_type)
    assert result == check_iterable_type(result, str)
    assert isinstance(result, str)


# Generated at 2022-06-23 21:20:13.084356
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    """ Example of the Internet method user_agent """
    from mimesis.enums import DataField
    from mimesis.builtins import datetime

    data = Internet(localization=DataField.RUSSIAN, seed=42)
    print("Date: ", datetime.DateTime(seed=42).date())
    print("User Agent: ", data.user_agent())

# Generated at 2022-06-23 21:20:16.250549
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    print(f"[+] Start test 'Internet.http_method()'")
    for i in range(1, 100):
        assert Internet().http_method() in HTTP_METHODS
    print(f"[+] Test 'Internet.http_method()' finished!")


# Generated at 2022-06-23 21:20:18.957405
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    provider = Internet()
    tld = provider.top_level_domain(tld_type=TLDType.HOSTING)
    assert tld == "cyou"



# Generated at 2022-06-23 21:20:19.751268
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    internet = Internet()

    print(internet.user_agent())


# Generated at 2022-06-23 21:20:23.530330
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    """Test for Image placeholder."""
    assert Internet.image_placeholder(
        width=100, height=100
    ) == (
        'http://placehold.it/100x100'
    )


# Generated at 2022-06-23 21:20:25.634126
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    obj = Internet(seed=0)
    assert obj.emoji() == ':rainbow:'


# Generated at 2022-06-23 21:20:27.430198
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    obj = Internet()
    print(obj.stock_image())


# Generated at 2022-06-23 21:20:29.910887
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    for _ in range(1000):
        assert isinstance(internet.hashtags(), str)
        assert isinstance(internet.hashtags(quantity=2), list)


# Generated at 2022-06-23 21:20:34.874870
# Unit test for method port of class Internet
def test_Internet_port():
    # test with enum PortRange
    internet = Internet()
    print(internet.port(port_range=PortRange.ALL))
    print(internet.port(port_range=PortRange.PRIVATE))
    print(internet.port(port_range=PortRange.PUBLIC))

# Generated at 2022-06-23 21:20:36.578326
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    internet = Internet()
    assert type(internet.image_placeholder()) is str

# Generated at 2022-06-23 21:20:38.896123
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    provider = Internet()
    name = provider.ip_v6_object()

    assert(isinstance(name, IPv6Address))

# Generated at 2022-06-23 21:20:40.099601
# Unit test for constructor of class Internet
def test_Internet():
    internet = Internet()
    assert isinstance(internet, Internet)
    assert internet.seed is None
    assert internet.random is not None

# Generated at 2022-06-23 21:20:43.255854
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    internet = Internet()
    link = internet.image_placeholder(35, 56)
    assert link is not None
    assert link == 'http://placehold.it/35x56'


# Generated at 2022-06-23 21:20:45.082823
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    import re
    i = Internet('en')
    agent = i.user_agent()
    result = re.findall("\(([^)]+)", agent)
    print(result)
    print("Successfully test_Internet_user_agent()")


# Generated at 2022-06-23 21:20:46.304862
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    internet = Internet()
    mac = internet.mac_address()
    print('MAC Address : ', mac)





# Generated at 2022-06-23 21:20:48.310269
# Unit test for constructor of class Internet
def test_Internet():
    t = Internet()
    assert t is not None



# Generated at 2022-06-23 21:20:56.724181
# Unit test for method home_page of class Internet

# Generated at 2022-06-23 21:21:00.398478
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    obj = Internet()
    result = obj.ip_v4_object()
    assert isinstance(result, IPv4Address)


# Generated at 2022-06-23 21:21:08.401764
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    from mimesis.enums import Emoji
    from mimesis.exceptions import NonEnumerableError

    i = Internet('en')

    assert isinstance(i.emoji(), str) == True
    assert i.emoji() in Emoji

    #Make sure that the next tests will fail

    try:
        i.emoji() in Emoji.FLAGS
    except NonEnumerableError as e:
        assert isinstance(e, NonEnumerableError) == True

    try:
        i.emoji() in Emoji.NATURE
    except NonEnumerableError as e:
        assert isinstance(e, NonEnumerableError) == True

    try:
        i.emoji() in Emoji.OBJECTS
    except NonEnumerableError as e:
        assert isinstance(e, NonEnumerableError) == True


# Generated at 2022-06-23 21:21:09.453149
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    print(Internet().image_placeholder())

# Generated at 2022-06-23 21:21:12.012046
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    internet = Internet()
    for _ in range(20):
        assert internet.http_status_message() in HTTP_STATUS_MSGS


# Generated at 2022-06-23 21:21:14.002608
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    tester=Internet()
    assert tester.ip_v4() != '127.0.0.1'

# Generated at 2022-06-23 21:21:22.884423
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    from mimesis.enums import TLDType
    from mimesis.utils import get_localizer
    from mimesis.builtins import RussiaSpecProvider
    eng = get_localizer('en')
    rus = get_localizer('ru')
    kaz = get_localizer('kk')
    provider = Internet('ru')
    res1 = provider.home_page()
    assert len(res1) > 0
    assert res1.startswith('https://')
    assert res1.endswith('.ru') or res1.endswith('.su')
    res2 = provider.home_page(TLDType.COUNTRY_CODE)
    assert res2.endswith('.ru')
    assert res2.startswith('https://')

# Generated at 2022-06-23 21:21:25.332957
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    internet_provider = Internet()
    assert isinstance(internet_provider.ip_v4_object(), IPv4Address)


# Generated at 2022-06-23 21:21:28.821380
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    print()
    provider = Internet()
    for _ in range(10):
        r = provider.content_type()
        print(r)
    print()


# Generated at 2022-06-23 21:21:38.534044
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    obj = Internet()
    assert obj.http_status_message() in HTTP_STATUS_MSGS
    assert obj.http_status_message() in HTTP_STATUS_MSGS
    assert obj.http_status_message() in HTTP_STATUS_MSGS
    assert obj.http_status_message() in HTTP_STATUS_MSGS
    assert obj.http_status_message() in HTTP_STATUS_MSGS
    assert obj.http_status_message() in HTTP_STATUS_MSGS
    assert obj.http_status_message() in HTTP_STATUS_MSGS
    assert obj.http_status_message() in HTTP_STATUS_MSGS
    assert obj.http_status_message() in HTTP_STATUS_MSGS
    assert obj.http_status_message() in HTTP_STATUS_MSGS
    assert obj

# Generated at 2022-06-23 21:21:41.738104
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    obj = Internet(seed=1)
    assert str(obj.ip_v4_object()) == "8.99.65.58"


# Generated at 2022-06-23 21:21:45.653269
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    """Unit test for method emoji of class Internet."""
    internet = Internet()
    emoji = internet.emoji()

    assert isinstance(emoji, str)
    assert emoji[0] == ':'
    assert emoji[-1] == ':'


# Generated at 2022-06-23 21:21:49.591749
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    internet_1 = Internet()
    ip_1 = internet_1.ip_v4(with_port=False)
    print(ip_1)
    print(type(ip_1))


# Generated at 2022-06-23 21:21:51.179523
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    internet = Internet()
    result = internet.http_status_code()
    assert isinstance(result, int)
    assert result in HTTP_STATUS_CODES


# Generated at 2022-06-23 21:21:54.105145
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    internet = Internet('it')
    ip_v6 = internet.ip_v6_object()
    assert ip_v6
    assert isinstance(ip_v6, IPv6Address)

# Generated at 2022-06-23 21:22:03.246787
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    print("Testing http_status_code")
    HTTP_STATUS_CODES_TEST = [100, 101, 200, 201, 202, 204, 206, 207, 208, 226,
                              300, 301, 302, 303, 304, 305, 307, 308, 400, 401,
                              402, 403, 404, 405, 406, 407, 408, 409, 410, 411,
                              412, 413, 414, 415, 416, 417, 418, 421, 422, 423,
                              424, 426, 428, 429, 431, 444, 450, 451, 499, 500,
                              501, 502, 503, 504, 505, 506, 507, 508, 510, 511]
    sut = Internet()

# Generated at 2022-06-23 21:22:07.053015
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    from mimesis.enums import Gender
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.misc import Misc
    from mimesis.providers.person import Person
    inter = Internet(Datetime(), Person(Misc('en'), Gender), Misc('en'))
    http_status_message = inter.http_status_message()
    assert http_status_message in HTTP_STATUS_MSGS

# Generated at 2022-06-23 21:22:14.824208
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    test_data = [
        (1920, 1080),
        (1080, 1920),
        ("1920", "1080"),
        ("100", "200"),
    ]

    for width, height in test_data:
        placeholder = Internet.image_placeholder(
            width=width, height=height)

        expected_placeholder = "http://placehold.it/{}x{}".format(
            width, height
        )

        assert placeholder == expected_placeholder

# Generated at 2022-06-23 21:22:17.455418
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    ip = Internet()
    ip_num = ip.ip_v6_object()
    assert isinstance(ip_num, IPv6Address)



# Generated at 2022-06-23 21:22:20.199532
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    d = Internet()
    res = d.image_placeholder()
    assert 'http://placehold.it/' in res
    print('Test image_placeholder OK')


# Generated at 2022-06-23 21:22:21.148454
# Unit test for constructor of class Internet
def test_Internet():
    internet = Internet()
    assert internet.random.randint(0, 1) == internet.random.randint(0, 1)

# Generated at 2022-06-23 21:22:23.957648
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    a = Internet()
    b = a.content_type()
    assert bool(b)


# Generated at 2022-06-23 21:22:26.860802
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    g = Internet()
    # print(g.ip_v4_object())
    assert type(g.ip_v4_object()) == IPv4Address


# Generated at 2022-06-23 21:22:28.533416
# Unit test for constructor of class Internet
def test_Internet():
    provider = Internet()
    assert provider is not None



# Generated at 2022-06-23 21:22:31.558057
# Unit test for method port of class Internet
def test_Internet_port():
    INTERNET = Internet()
    port = INTERNET.port(PortRange.REGISTERED)
    assert 1024 <= port <= 49151


# Generated at 2022-06-23 21:22:38.728117
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    print("\nTest http_method() method of class Internet:\n")
    a = set()
    for i in range(1000):
        a.add(Internet().http_method())
    tab = ["HEAD", "POST", "DELETE", "PUT", "GET", "PATCH"]
    print("Set of methods: ")
    print(a)
    print()
    print("Are all elements of set in tab: ")
    print(a.issubset(tab))



# Generated at 2022-06-23 21:22:43.168625
# Unit test for method port of class Internet
def test_Internet_port():
    internet = Internet()
    port = internet.port(port_range=internet.PortRange.WELL_KNOWN)
    assert 0 <= port <= 1023
    port = internet.port(port_range=internet.PortRange.PRIVATE)
    assert 49152 <= port <= 65535
    port = internet.port(port_range=internet.PortRange.ALL)
    assert 0 <= port <= 65535

# Generated at 2022-06-23 21:22:52.979904
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    from mimesis.typing import Seed
    from mimesis.enums import SeedSource

    seed = Seed(SeedSource.DATE.value)
    internet = Internet(seed=seed)

    assert internet.ip_v6() == 'aaaa:bbbb:cccc:dddd:eeee:ffff:0000:0001'

    seed = Seed(SeedSource.TIME.value)
    internet = Internet(seed=seed)

    assert internet.ip_v6() == 'aaaa:0bbb:0ccc:0ddd:0eee:0fff:0fff:f000'


# Generated at 2022-06-23 21:22:57.415483
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    from mimesis.local import ru
    from mimesis.enums import TLDType

    internet_ru = ru.Internet()
    home_page = internet_ru.home_page(tld_type=TLDType.CC)

    assert isinstance(home_page, str)
    assert home_page.endswith('.cc')

# Generated at 2022-06-23 21:23:02.454309
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    internet = Internet()
    result = internet.user_agent()
    answer = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36'
    assert result == answer

# Generated at 2022-06-23 21:23:04.371707
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    internet = Internet()
    print('\nIPv4:', internet.ip_v4())

# Generated at 2022-06-23 21:23:06.179677
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    st = Internet()
    assert st.http_status_message() in HTTP_STATUS_MSGS

# Generated at 2022-06-23 21:23:07.260769
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    image = Internet().stock_image()
    assert image

# Generated at 2022-06-23 21:23:09.434764
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    obj = Internet()
    result = obj.http_method()
    assert result != result


assert test_Internet_http_method()


# Generated at 2022-06-23 21:23:11.843685
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    internet = Internet()
    emoji = internet.emoji()
    assert type(emoji) is str
    assert len(emoji) > 0
        


# Generated at 2022-06-23 21:23:15.253891
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    from mimesis.providers.internet import Internet
    from mimesis.enums import HTTPStatusCode

    internet = Internet()
    status = internet.http_status_code()
    assert status in HTTPStatusCode.__members__

    assert internet.http_status_message() == "OK"


# Generated at 2022-06-23 21:23:24.394713
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    """Test for method ip_v4 of class Internet"""
    import re
    from mimesis.enums import PortRange
    random_data = Internet()

    ip_v4 = random_data.ip_v4()
    regex = re.compile(
        r"^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)(\."
        r"(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)){3}$")
    assert ip_v4 == '9.10.97.54'
    assert isinstance(ip_v4, str)
    assert regex.match(ip_v4) is not None

    ip_v4 = random_

# Generated at 2022-06-23 21:23:27.861684
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    internet = Internet()
    assert internet.network_protocol(Layer.APPLICATION) in NETWORK_PROTOCOLS[Layer.APPLICATION]

# Generated at 2022-06-23 21:23:30.311168
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    internet_obj = Internet()
    for i in range(0,10):
        print(internet_obj.mac_address())


# Generated at 2022-06-23 21:23:39.874905
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    import random
    from mimesis.enums import BuildVersion
    from mimesis.enums import OperatingSystem
    from mimesis.exceptions import NonEnumerableError
    from mimesis.providers.internet import Internet

    _internet = Internet(seed=777)
    assert _internet.user_agent() == 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.9; rv:11.0) Gecko/20100101 Firefox/11.0'
    ua = _internet.user_agent(os=OperatingSystem.UBUNTU)
    assert ua == 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:10.0) Gecko/20100101 Firefox/10.0'

# Generated at 2022-06-23 21:23:45.250818
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    """Unit test for method content_type of class Internet.

    Yields:
        bool: The result of test.
    """
    n = Internet()
    result = n.content_type()
    assert result in [
        'Content-Type: application/pdf',
        'Content-Type: application/x-javascript',
        'Content-Type: image/jpeg',
        'Content-Type: application/msword',
    ]
    return True


# Generated at 2022-06-23 21:23:53.042815
# Unit test for method port of class Internet
def test_Internet_port():
    internet = Internet()
    res = internet.port(port_range=PortRange.ALL)
    assert type(res) == int
    assert res >= 1 and res <= 65535

    res = internet.port(port_range=PortRange.WELL_KNOWN)
    assert type(res) == int
    assert res >= 0 and res <= 49151

    res = internet.port(port_range=PortRange.PRIVILEGED)
    assert type(res) == int
    assert res >= 49152 and res <= 65535

# Generated at 2022-06-23 21:23:54.432281
# Unit test for constructor of class Internet
def test_Internet():
    internet = Internet()
    assert internet is not None


# Generated at 2022-06-23 21:23:59.537495
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    """Unit test for method top_level_domain of class Internet."""
    tld_type = TLDType.ICANN_GTLD
    internet = Internet(seed=12345)
    result = internet.top_level_domain(tld_type=tld_type)
    assert isinstance(result, str)

# Generated at 2022-06-23 21:24:00.902055
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    internet = Internet()
    print(internet.content_type())

test_Internet_content_type()

# Generated at 2022-06-23 21:24:07.538720
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    from mimesis.enums import MimeType
    internet = Internet()
    content_type1 = internet.content_type()

# Generated at 2022-06-23 21:24:09.247048
# Unit test for method port of class Internet
def test_Internet_port():
    random = Random()
    seed(1)
    provider = Internet(random=random)
    assert provider.port() == 63733
    seed(1)
    assert provider.port(port_range=PortRange.WELL_KNOWN) == 16

# Generated at 2022-06-23 21:24:10.539446
# Unit test for constructor of class Internet
def test_Internet():
    internet = Internet()
    assert isinstance(internet, Internet)


# Generated at 2022-06-23 21:24:12.199956
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    ip = IPv4Address(2345)
    assert type(ip) is IPv4Address


# Generated at 2022-06-23 21:24:20.382180
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    """Test method ip_v4."""
    internet = Internet(seed=0)

    assert (
        internet.ip_v4()
        == '250.93.142.134'
    )
    assert (
        internet.ip_v4(with_port=True)
        == '250.93.142.134:8080'
    )
    assert (
        internet.ip_v4(with_port=True,
                       port_range=PortRange.PRIVATE) ==
        '250.93.142.134:49152'
    )
    assert (
        internet.ip_v4(with_port=True,
                       port_range=PortRange.REGISTERED) ==
        '250.93.142.134:18080'
    )

# Generated at 2022-06-23 21:24:22.941470
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    test_Internet = Internet()
    test_result = test_Internet.http_status_code
    assert test_result in [200, 404, 418, 500]

# Generated at 2022-06-23 21:24:31.131302
# Unit test for constructor of class Internet
def test_Internet():
    internet = Internet()
    content_type = internet.content_type()
    assert content_type.startswith('Content-Type')

    http_status_message = internet.http_status_message()
    assert http_status_message.startswith('Multiple') or http_status_message == 'No Content'

    http_status_code = internet.http_status_code()
    assert (http_status_code >= 100) and (http_status_code <= 599)

    http_method = internet.http_method()
    assert http_method in ['GET', 'PUT']

    ip_v4 = internet.ip_v4()
    assert ip_v4.count('.') == 3

    ip_v4_object = internet.ip_v4_object()
    assert ip_v4_object.compressed == ip_

# Generated at 2022-06-23 21:24:32.634899
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    print(Internet.ip_v4_object())



# Generated at 2022-06-23 21:24:41.434399
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    inter = Internet()
    assert inter.top_level_domain(tld_type=TLDType.TOP_COUNTRY)
    assert inter.top_level_domain(tld_type=TLDType.ALL)
    assert inter.top_level_domain()
    assert inter.top_level_domain(tld_type=TLDType.TOP_COUNTRY_GOV)
    assert inter.top_level_domain(tld_type=TLDType.TOP_COUNTRY_BANK)
    assert inter.top_level_domain(tld_type=TLDType.TOP_COUNTRY_MIL)
    assert inter.top_level_domain(tld_type=TLDType.TOP_COUNTRY_EDU)

# Generated at 2022-06-23 21:24:46.453598
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    http_status_code = Internet().http_status_code()
    assert http_status_code in HTTP_STATUS_CODES and isinstance(http_status_code, int)
    assert len(str(http_status_code)) == 3


# Generated at 2022-06-23 21:24:51.214174
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    provider = Internet()
    random_ip = provider.ip_v4_object()
    assert isinstance(random_ip, IPv4Address)
    assert type(random_ip.compressed) is str
    assert type(random_ip.exploded) is str
    assert type(random_ip.packed) is bytes


# Generated at 2022-06-23 21:24:53.215978
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    for i in range(20):
        print(Internet('en').http_method())


# Generated at 2022-06-23 21:24:55.757894
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    internet = Internet()
    result = internet.emoji()
    assert isinstance(result, str)
    assert result[0] == ':' and result[-1] == ':'
    assert ' ' not in result


# Generated at 2022-06-23 21:24:59.685451
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    """Test image_placeholder of class Internet"""
    width = 200
    height = 200
    strInstance = Internet.image_placeholder(width, height)
    assert isinstance(strInstance, str)
    assert 'http://placehold.it/200x200' == strInstance


# Generated at 2022-06-23 21:25:07.200588
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    # Test saved image
    s = Internet(seed=0)
    url = s.stock_image(width=1300, height=600, writable=False)
    print(url)
    # Test sequence bytes of image
    # WARNING: need internet connection!
    s = Internet(seed=0)
    image = s.stock_image(width=1300, height=600, writable=True)
    # Test saved image
    with open('unsplash.jpg', 'wb') as f:
        f.write(image)

# Generated at 2022-06-23 21:25:09.871072
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    internet = Internet()
    result = internet.http_status_code()
    assert (type(result) == int)


# Generated at 2022-06-23 21:25:12.285089
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    ts = Internet()
    ip = ts.ip_v4_object()
    print(ip)
    ip2 = ts.ip_v4()
    print(ip2)

# Generated at 2022-06-23 21:25:14.453063
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    h = Internet()
    assert h.http_status_message() in HTTP_STATUS_MSGS


# Generated at 2022-06-23 21:25:17.217998
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    provider = Internet()
    f = provider.ip_v4_object()
    assert f in range(4,4)

# Generated at 2022-06-23 21:25:21.379278
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    """Unit test for method ip_v6_object of class Internet."""
    ip = Internet().ip_v6_object()
    ip_string: str = str(ip)
    assert isinstance(ip_string, str) and ":" in ip_string

# Generated at 2022-06-23 21:25:23.375986
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    inter = Internet()
    assert inter.http_status_message() in HTTP_STATUS_MSGS


# Generated at 2022-06-23 21:25:27.184220
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    from mimesis.enums import Size
    from mimesis.providers.internet import Internet
    internet_provider = Internet('en')
    result = internet_provider.image_placeholder(width=Size.MEDIUM, height=Size.MEDIUM)
    assert result is not None


# Generated at 2022-06-23 21:25:31.811504
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    i = Internet()
    result = i.ip_v4()
    assert isinstance(result, str)
    assert len(result.split('.')) == 4


# Generated at 2022-06-23 21:25:37.805674
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    from mimesis.providers.internet import Internet
    ip = Internet()

    v4 = ip.ip_v4_object()
    assert isinstance(v4, IPv4Address)

    v6 = ip.ip_v6_object()
    assert isinstance(v6, IPv6Address)


# Generated at 2022-06-23 21:25:45.113733
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()

    url = internet.stock_image()
    assert 'https://source.unsplash.com' in url

    url = internet.stock_image(
        width=1024, height=768,
    )
    assert 'https://source.unsplash.com' in url

    url = internet.stock_image(
        keywords=['cat', 'meow'],
    )
    assert 'https://source.unsplash.com' in url

    image = internet.stock_image(
        keywords=['cat', 'meow'],
        writable=True,
    )
    assert isinstance(image, bytes)

# Generated at 2022-06-23 21:25:50.579585
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    print("Method http_method of Internet")
    # Prepare test context
    internet = Internet()
    # Run method
    result = internet.http_method()
    # Check result
    assert result in ["GET", "OPTIONS", "HEAD", "POST", "PUT", "PATCH", "DELETE", "TRACE", "CONNECT"]

# Generated at 2022-06-23 21:26:00.491179
# Unit test for method port of class Internet
def test_Internet_port():
    """ Test that method port returns a valid port number.
    """
    import mimesis
    i = mimesis.Internet()

    # Test random port
    assert i.port() < 65536 and i.port() >= 0

    # Test port in well-known range
    assert i.port(mimesis.PortRange.WELL_KNOWN) < 1024
    assert i.port(port_range=mimesis.PortRange.WELL_KNOWN) < 1024

    # Test port in registered range
    assert i.port(mimesis.PortRange.REGISTERED) >= 1024
    assert i.port(port_range=mimesis.PortRange.REGISTERED) >= 1024

    # Test port in dynamic range
    assert i.port(mimesis.PortRange.DYNAMIC) >= 49152

# Generated at 2022-06-23 21:26:02.855614
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    provider = Internet('ru')
    layer = provider.Layer
    protocol = provider.network_protocol(layer.APPLICATION)
    assert protocol in ['HTTP', 'HTTPS', 'FTP', 'Telnet', 'SMTP']

# Generated at 2022-06-23 21:26:04.562405
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
	internet = Internet()
	print('User agent: ', internet.user_agent())


# Generated at 2022-06-23 21:26:09.349417
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    # Arrange
    mime_type = MimeType.AUDIO
    internet = Internet(seed=1337)

    # Act
    result = internet.content_type(mime_type)

    # Assert
    assert result == 'Content-Type: audio/basic'


# Generated at 2022-06-23 21:26:10.036085
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    net = Internet()
    assert 1 == 1

# Generated at 2022-06-23 21:26:12.625229
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    internet = Internet()
    status = internet.http_status_code()
    assert status in HTTP_STATUS_CODES and isinstance(status, int)

# Generated at 2022-06-23 21:26:16.571612
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    from mimesis.enums import HTTPStatusCode
    from mimesis.providers.internet import Internet
    inter = Internet()
    x = inter.http_status_code()
    assert x in HTTPStatusCode.ALL.value


# Generated at 2022-06-23 21:26:21.096093
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    internet = Internet("en")
    # generate mac_address from provider
    mac_addr = internet.mac_address()
    print("Generated mac address: {}\n".format(mac_addr))

    # check generated mac address from provider
    check_mac_address(mac_addr)


# Generated at 2022-06-23 21:26:22.639281
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    test = Internet()
    assert isinstance(test.network_protocol(), str)

# Generated at 2022-06-23 21:26:24.543327
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    internet = Internet()
    ret = internet.http_status_code()
    assert ret in HTTP_STATUS_CODES


# Generated at 2022-06-23 21:26:27.451863
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    try:
        print(Internet().ip_v6())
    except Exception as e:
        print(e)

# Dummy test for method ip_v4 of class Internet

# Generated at 2022-06-23 21:26:32.883885
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    gen = Internet()
    x = gen.ip_v4_object()
    x.version == 4
    x.is_global
    x.is_reserved
    x.is_private
    num = gen.random.randint(0, gen._MAX_IPV4)
    assert str(x) == str(IPv4Address(num))

# Generated at 2022-06-23 21:26:36.116445
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    print("\n\n" + str(Internet.image_placeholder()))
    print("\n\n" + str(Internet.image_placeholder(400, 300)))


# Generated at 2022-06-23 21:26:38.043973
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    from mimesis.builtins import Internet # this example use builtins class for easy testing
    internet = Internet()
    method = internet.http_method()
    assert method in ['GET', 'POST', 'PUT', 'DELETE']

# Generated at 2022-06-23 21:26:48.388612
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from unittest.mock import patch

    with patch('urllib.request.urlopen') as mocked_urlopen:
        mocked_urlopen.return_value.read.return_value = b'foo'
        res = Internet().stock_image(
            width=300,
            height=200,
            keywords=['animal', 'flower', 'mountain']
        )
        assert res == b'foo'

        res = Internet().stock_image(
            width=300,
            height=200,
            keywords=['animal', 'flower', 'mountain'],
            writable=False
        )
        assert res == 'https://source.unsplash.com/300x200?animal,flower,mountain'

# Generated at 2022-06-23 21:26:51.118291
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    '''
    Test top_level_domain function
    '''
    # obj = Internet()
    # print (obj.top_level_domain(TLDType.SLOVAK))

# Generated at 2022-06-23 21:26:53.940403
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    internet = Internet()
    http_status_message_ = internet.http_status_message()
    assert http_status_message_ in HTTP_STATUS_MSGS


# Generated at 2022-06-23 21:26:56.938840
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    from mimesis.enums import HTTPStatusCode

    assert HTTPStatusCode.OK.value == '200'


# Generated at 2022-06-23 21:27:01.429471
# Unit test for method port of class Internet
def test_Internet_port():
    """Unit test for method port of class Internet."""
    port = PortRange.PORT_80.value
    port_example = Internet().port(PortRange.PORT_80)
    assert port_example >= port[0]
    assert port_example <= port[1]



# Generated at 2022-06-23 21:27:04.696248
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    """Tests for method stock_image of class Internet."""
    internet = Internet()
    image = internet.stock_image()
    assert type(image) == str
    assert image.startswith('https://source.unsplash.com/')
    assert len(image.split('/')) > 4
    assert len(image.split('/')[-1]) > 0

# Generated at 2022-06-23 21:27:07.560572
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    internet = Internet()
    home_page = internet.home_page()
    print(home_page)

if __name__ == '__main__':
    test_Internet_home_page()

# Generated at 2022-06-23 21:27:11.959733
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    internet = Internet()
    ip = internet.ip_v6()

# # Unit test for method ip_v4 of class Internet
# def test_Internet_ip_v4():
#     internet = Internet()
#     ip = internet.ip_v4()
#     print(ip)

# Generated at 2022-06-23 21:27:13.434914
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    x = Internet()
    print(x.http_status_message())

# Generated at 2022-06-23 21:27:15.730601
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    provider = Internet()
    result = provider.content_type(MimeType.IMAGE)
    assert len(result) > 0


# Generated at 2022-06-23 21:27:19.775917
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    print("Internet_ip_v4_test start")
    internet = Internet(seed=0)
    IP = internet.ip_v4(with_port=True)
    assert IP == '177.232.57.84:49159'
    print("Internet_ip_v4_test end")


# Generated at 2022-06-23 21:27:27.144129
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    useForTest = Internet()

# Generated at 2022-06-23 21:27:29.015804
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    for layer in Layer:
        for index in range(len(NETWORK_PROTOCOLS[layer])):
            n = Internet()
            assert n.network_protocol(layer=layer) == NETWORK_PROTOCOLS[layer][index]

# Generated at 2022-06-23 21:27:30.190893
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    temp = Internet(seed=12345)
    assert temp.http_status_message() == "Switch Proxy"


# Generated at 2022-06-23 21:27:32.618545
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    http_status_code_test_obj = Internet()
    assert (('http_status_code' in dir(http_status_code_test_obj))==True)


# Generated at 2022-06-23 21:27:36.247857
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    """
    These are the unit testing for method stock_image of class Internet.
    Here, I will inspect the length of data returned.
    """
    assert Internet()

# Generated at 2022-06-23 21:27:39.129466
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    test_object = Internet()
    test_var = test_object.http_method()
    assert (test_var in HTTP_METHODS)


# Generated at 2022-06-23 21:27:42.199999
# Unit test for method port of class Internet
def test_Internet_port():
    from mimesis.enums import PortRange
    from mimesis.providers.internet import Internet

    internet = Internet()
    print(internet.port(port_range=PortRange.RESERVED))



# Generated at 2022-06-23 21:27:44.648764
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    provider = Internet()
    for i in range(0, 10):
        # acts
        ip_v6 = provider.ip_v6()

        # asserts
        assert isinstance(ip_v6, str)

# Generated at 2022-06-23 21:27:46.221572
# Unit test for method port of class Internet
def test_Internet_port():
    internet = Internet()
    port = internet.port()
    assert port in range(0, 65535)

# Generated at 2022-06-23 21:27:54.033610
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    #  Initialization of class object
    internet = Internet()
    #  Generation of MAC-address
    macro = internet.mac_address()
    # Verification of MAC-address consists of numbers and letters
    for i in range(len(macro)):
        if macro[i] == ":":
            continue
        if (macro[i]>='0') and (macro[i] <='9'):
            continue
        if (macro[i]>='a') and (macro[i] <='z'):
            continue
        if (macro[i]>='A') and (macro[i] <='Z'):
            continue
        assert False
    # Verification of the length of the MAC-address
    assert len(macro) == 17
    print ('MAC-address - ', macro)


# Generated at 2022-06-23 21:27:55.462510
# Unit test for method port of class Internet
def test_Internet_port():
    provider = Internet()
    assert provider.port() in range(0, 65536)


# Generated at 2022-06-23 21:27:57.053100
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    internet = Internet("en")
    assert internet.http_status_code() in range(100, 600)

# Generated at 2022-06-23 21:27:58.867045
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    obj = Internet()
    result = obj.ip_v4()
    assert isinstance(result, str)



# Generated at 2022-06-23 21:28:03.054588
# Unit test for method port of class Internet
def test_Internet_port():
    from random import seed
    from mimesis.enums import PortRange

    ext = Internet('ru')
    for _ in range(10):
        print(ext.port(PortRange.PRIVATE))
    print('-' * 30)
    seed(32)
    for _ in range(10):
        print(ext.port(PortRange.PRIVATE))
    print('-' * 30)
    seed(32)
    for _ in range(10):
        print(ext.port(PortRange.ALL))
    print('-' * 30)
    seed(32)
    for _ in range(10):
        print(ext.port(PortRange.PRIVATE))


if __name__ == "__main__":
    test_Internet_port()

# Generated at 2022-06-23 21:28:06.649952
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    internet = Internet()
    assert internet.content_type() == "Content-Type: application/zip"

# Generated at 2022-06-23 21:28:08.832702
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    ip = Internet.ip_v6_object()
    ip_v6 = IPv6Address(ip)
    assert ip_v6.exploded == ip

# Generated at 2022-06-23 21:28:10.768907
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    # print(Internet.http_method(Internet()))
    assert Internet.http_method(Internet()) in HTTP_METHODS

# Generated at 2022-06-23 21:28:13.334151
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    expected_string = 'AMQP'
    actual_string = Internet.network_protocol(layer=Layer.APPLICATION)
    assert expected_string == actual_string

# Generated at 2022-06-23 21:28:15.621069
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    # Initialize mimesis
    i = Internet()

    # Get an IPv4 address object
    ip = i.ip_v4_object()

    print(ip)



# Generated at 2022-06-23 21:28:18.219972
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    n = Internet()
    n.user_agent()
    # Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:15.0) Gecko/20100101 Firefox/15.0.1


# Generated at 2022-06-23 21:28:21.463773
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    internet = Internet()
    assert internet.http_method() in ("GET", "POST", "HEAD", "PUT", "DELETE")


# Generated at 2022-06-23 21:28:24.358699
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    image = Internet().image_placeholder(width = 100, height = 100)
    assert image == ("http://placehold.it/100x100")


# Generated at 2022-06-23 21:28:30.328452
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    ip = Internet().ip_v4_object()
    assert str(ip) == (
             "Internet().ip_v4_object()"
    )

    # Ip address object has method packed that returns integer value
    assert isinstance(ip.packed, int)
    assert str(int) == (
             "Ip address object has method packed that returns integer value"
    )

    assert ip.exploded == (
             "Ip address object has method exploded that returns human readable string "
    )

# Generated at 2022-06-23 21:28:31.578015
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    test_Internet = Internet()
    test_Internet.user_agent()

# Generated at 2022-06-23 21:28:33.553117
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    internet = Internet()
    http_method = internet.http_method()
    assert http_method in HTTP_METHODS

# Generated at 2022-06-23 21:28:34.806659
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    internet = Internet()
    assert isinstance(internet.ip_v6(), IPv6Address)

# Generated at 2022-06-23 21:28:40.777792
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    """Unit test for method ip_v6 of class Internet"""
    ip_v4_object = Internet.ip_v4_object()
    ip_v4 = Internet.ip_v4()
    ip_v6_object = Internet.ip_v6_object()
    ip_v6 = Internet.ip_v6()
    print(ip_v4_object)
    print(ip_v4)
    print(ip_v6_object)
    print(ip_v6)

# Generated at 2022-06-23 21:28:43.501460
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    assert internet.stock_image(300, 300, keywords=['food']) == "https://source.unsplash.com/300x300?food"

# Generated at 2022-06-23 21:28:52.475166
# Unit test for constructor of class Internet
def test_Internet():
    '''
    def __init__(self, *args, **kwargs):
        """Initialize attributes.
        :param args: Arguments.
        :param kwargs: Keyword arguments.
        """
        super().__init__(*args, **kwargs)
        self.__file = File(seed=self.seed)
        self._MAX_IPV4 = (2 ** 32) - 1
        self._MAX_IPV6 = (2 ** 128) - 1
    '''
    test = Internet()
    print(test._MAX_IPV4)
    print(test._MAX_IPV6)


# Generated at 2022-06-23 21:28:54.121907
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    assert Internet().http_status_code() in HTTP_STATUS_CODES


# Generated at 2022-06-23 21:29:02.522141
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    # Définir le seed pour contrôler le résultat
    seed=100
    # Initialisation du générateur en précisant le seed
    gen = Internet(seed=seed)
    # Génération avec le seed précisé
    ip_v6 = gen.ip_v6()
    # Exécution
    usercode = f"""
    seed={seed}
    gen = Internet(seed=seed)
    ip_v6 = gen.ip_v6()
    print(ip_v6)
    """
    exec(usercode)
    # Vérification du résultat
    assert ip_v6 == 'd1b0:f6b8:36b0:ee33:c6de:28ba:f1c3:1da0'

# Generated at 2022-06-23 21:29:05.430473
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    # Get a fake home page as a string
    home_page = Internet.home_page()
    # Run a test
    assert isinstance(home_page, str)


# Generated at 2022-06-23 21:29:09.978910
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    """Test method ip_v6"""

    # Arrange
    internet = Internet()
    ip_v6=""

    # Act
    ip_v6=internet.ip_v6()

    # Assert
    assert ip_v6 is not None


# Generated at 2022-06-23 21:29:11.407506
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    internet = Internet(seed=0)
    assert internet.home_page() == 'https://Schimmel_Upton.info'


# Generated at 2022-06-23 21:29:13.752213
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    res = Internet().user_agent()
    str(res)


# Generated at 2022-06-23 21:29:19.255773
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    from ipaddress import IPv6Address
    from mimesis.enums import PortRange
    from mimesis.providers.internet import Internet
    from mimesis.providers.base import BaseProvider

    i = Internet('en')
    assert isinstance(i, BaseProvider)
    ip = i.ip_v6()
    assert isinstance(ip, str)
    IPv6Address(ip)



# Generated at 2022-06-23 21:29:21.879431
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    internet = Internet(random_state=0)
    assert internet.home_page(TLDType.GOV) == 'https://entrance.gov'

# Generated at 2022-06-23 21:29:25.801634
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    assert Internet().home_page() == 'https://morten.info'
    assert Internet().home_page() == 'https://allan.info'
    assert Internet().home_page() == 'https://karen.org'

# Generated at 2022-06-23 21:29:28.234734
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    """Unit testing for method http_method of class Internet."""
    internet = Internet()
    assert internet.http_method() in HTTP_METHODS


# Generated at 2022-06-23 21:29:30.497382
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    """Test for method emoji of class Internet."""
    assert Internet().emoji() in EMOJI


# Generated at 2022-06-23 21:29:39.079312
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    internet = Internet()
    print(internet.network_protocol(layer=Layer.APPLICATION))
    print(internet.network_protocol(layer=Layer.PRESENTATION))
    print(internet.network_protocol(layer=Layer.SESSION))
    print(internet.network_protocol(layer=Layer.TRANSPORT))
    print(internet.network_protocol(layer=Layer.NETWORK))
    print(internet.network_protocol(layer=Layer.DATA_LINK))
    print(internet.network_protocol(layer=Layer.PHYSICAL))


# Generated at 2022-06-23 21:29:40.885940
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    a = internet.hashtags(quantity = 3)
    assert a == None


# Generated at 2022-06-23 21:29:43.496460
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    http_status_code = Internet().http_status_code()
    assert(isinstance(http_status_code,int))
    assert(http_status_code >= 0 and http_status_code <= 599)
 
