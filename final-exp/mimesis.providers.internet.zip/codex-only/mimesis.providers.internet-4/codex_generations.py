

# Generated at 2022-06-23 21:19:44.119996
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    i = Internet()
    print(i.mac_address())
    print(i.mac_address())
    print(i.mac_address())
    print(i.mac_address())
    print(i.mac_address())


# Generated at 2022-06-23 21:19:46.105603
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    internet = Internet('en')
    assert isinstance(internet.http_status_code(), int)


# Generated at 2022-06-23 21:19:48.641371
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    for _ in range(10):
        print((Internet().hashtags()))
    for _ in range(10):
        print((Internet().hashtags(1)))

# Generated at 2022-06-23 21:19:51.318642
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    int = Internet()
    print(int.content_type())

    # Expected result: 'Content-Type: application/vnd.ms-excel'



# Generated at 2022-06-23 21:19:59.268349
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    x = Internet()
    x.random.seed(42)
    #assert '200 OK' == x.http_status_message()
    assert '505 HTTP Version Not Supported' == x.http_status_message()
    assert '206 Partial Content' == x.http_status_message()
    assert '201 Created' == x.http_status_message()
    assert '404 Not Found' == x.http_status_message()
    assert '503 Service Unavailable' == x.http_status_message()
    assert '403 Forbidden' == x.http_status_message()
    assert '406 Not Acceptable' == x.http_status_message()
    assert '401 Unauthorized' == x.http_status_message()
    assert '412 Precondition Failed' == x.http_status_message()

# Generated at 2022-06-23 21:20:04.292139
# Unit test for method hashtags of class Internet
def test_Internet_hashtags(): # 1
    """Unit test for method hashtags of class Internet"""
    _internet = Internet()
    assert _internet.hashtags(quantity=1) == "#writing"
    assert _internet.hashtags(quantity=2) == ["#writing", "#laughing"]
    assert _internet.hashtags(quantity=3) == ["#writing", "#laughing", "#movies"]


# Generated at 2022-06-23 21:20:08.202976
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    """unit test for method user_agent of class Internet."""
    internet = Internet(seed=42)
    result = internet.user_agent()
    assert result == 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.130 Safari/537.36'

# Generated at 2022-06-23 21:20:13.672748
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    """Test that the resulting value is in the list HTTP_METHODS."""
    from mimesis.enums import Layer
    from mimesis.providers.internet import Internet
    provider = Internet(seed=1)
    result = provider.http_method()

    assert provider.random.choice(HTTP_METHODS) == result


# Generated at 2022-06-23 21:20:15.254808
# Unit test for constructor of class Internet
def test_Internet():
    # Test for method __init__()
    internet = Internet()
    assert isinstance(internet, Internet)


# Generated at 2022-06-23 21:20:17.544407
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    i = Internet()
    # TODO Add pytesseract to PyPi and then add test of this method
    pass

# Generated at 2022-06-23 21:20:22.123128
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    from random import Random
    from ipaddress import IPv6Address

    provider = Internet(random=Random(4))
    result = provider.ip_v6_object()
    assert isinstance(result, IPv6Address)


# Generated at 2022-06-23 21:20:27.233849
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    """Test for method ip_v4 of class Internet."""
    ip = Internet()
    for _ in range(10):
        r = ip.ip_v4()
        assert r
        assert type(r) is str
    r2 = ip.ip_v4(with_port=True)
    assert r2


# Generated at 2022-06-23 21:20:30.320600
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    n = Internet()
    result = n.network_protocol()
    logg = 'Result of method network_protocol() of class Internet is %s' % result
    print(logg)
    assert result in NETWORK_PROTOCOLS[Layer.APPLICATION]


# Generated at 2022-06-23 21:20:33.072108
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    internet = Internet()
    result = internet.network_protocol()
    assert result is not None

# Generated at 2022-06-23 21:20:35.036589
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    internet = Internet()
    assert isinstance(internet.ip_v6_object(), IPv6Address)

# Generated at 2022-06-23 21:20:45.817985
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    # Initialize instances of class Internet.
    internet_1 = Internet()
    internet_2 = Internet()
    internet_3 = Internet()
    internet_4 = Internet()

    # Get random hashtags.
    rnd_hashtags_1_1 = internet_1.hashtags(1)
    rnd_hashtags_1_2 = internet_1.hashtags(2)
    rnd_hashtags_1_3 = internet_1.hashtags(4)
    rnd_hashtags_1_4 = internet_1.hashtags(6)
    rnd_hashtags_2_1 = internet_2.hashtags(1)
    rnd_hashtags_2_2 = internet_2.hashtags(2)
    rnd_hashtags_2_3 = internet_2.hashtags(4)
    r

# Generated at 2022-06-23 21:20:49.171574
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    #Test case 1
    ipv6_object = Internet().ip_v6_object()
    assert isinstance(ipv6_object, IPv6Address)



# Generated at 2022-06-23 21:20:51.021592
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    internet = Internet()
    mac = internet.mac_address()
    print(mac)
    assert len(mac) == 17



# Generated at 2022-06-23 21:20:52.742951
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    internet = Internet()
    src = internet.image_placeholder()
    assert src == 'http://placehold.it/1920x1080'


# Generated at 2022-06-23 21:20:58.474659
# Unit test for method top_level_domain of class Internet

# Generated at 2022-06-23 21:21:06.295468
# Unit test for constructor of class Internet
def test_Internet():
    internet = Internet()
    print(internet.ip_v4(with_port=True))
    print(internet.port())
    print(internet.mac_address())
    print(internet.http_status_code())
    print(internet.http_status_message())
    print(internet.content_type())
    print(internet.network_protocol())
    print(internet.ip_v4())
    print(internet.ip_v6())
    print(internet.top_level_domain())
    # print(internet.user_agent())

if __name__ == '__main__':
    test_Internet()

# Generated at 2022-06-23 21:21:09.861807
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    internet = Internet()
    assert isinstance(internet.http_status_code(), int)
    assert internet.http_status_code() in HTTP_STATUS_CODES

# Generated at 2022-06-23 21:21:12.055043
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    tmp = Internet()
    assert len(tmp.ip_v4().split('.')) == 4


# Generated at 2022-06-23 21:21:14.745777
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    """Unit test for method ip_v6 of class Internet."""
    internet = Internet()
    ip = internet.ip_v6()
    assert isinstance(ip, str)
    assert ip
    print(ip)


# Generated at 2022-06-23 21:21:16.950811
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    home_page = Internet().home_page()
    assert home_page and isinstance(home_page, str)

# Generated at 2022-06-23 21:21:20.098360
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    user_list = internet.hashtags()
    print(user_list)
    print(len(user_list))
        

# Generated at 2022-06-23 21:21:22.165150
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    """Test method ip_v6_object of class Internet."""
    result = Internet().ip_v6_object()
    assert isinstance(result, IPv6Address)

# Generated at 2022-06-23 21:21:24.143100
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    internet = Internet()
    ip = internet.ip_v4_object()
    assert ip == IPv4Address(internet.random.randint(0, internet._MAX_IPV4))


# Generated at 2022-06-23 21:21:26.189688
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    internet = Internet()
    assert internet.top_level_domain()


# Generated at 2022-06-23 21:21:31.956562
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    from mimesis.enums import HTTPStatusCode
    from mimesis.providers.internet import Internet
    internet = Internet()
    result = internet.http_status_code()
    assert isinstance(result, (int, HTTPStatusCode))

    status_code = result
    assert status_code >= 100
    assert status_code <= 599

# Generated at 2022-06-23 21:21:35.726629
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    """Test Internet.image_placeholder()"""
    from mimesis.enums import ImageSize

    internet = Internet()

    # Test with default values
    image = internet.image_placeholder()

    # Test with custom values
    image = internet.image_placeholder(width=ImageSize.QUADRUPLE.value, height=800)

    # Test with custom string
    image = internet.image_placeholder(width='500', height='800')


# Generated at 2022-06-23 21:21:37.523962
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    assert isinstance(internet.hashtags(5), list)
    assert isinstance(internet.hashtags(1), str)
    assert isinstance(internet.hashtags(0), str)

# Generated at 2022-06-23 21:21:42.377476
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    """Test method mac_address of class Internet."""
    obj = Internet(seed=123)
    mac_address = obj.mac_address()
    assert mac_address == '00:16:3e:4f:ff:ff'

# Generated at 2022-06-23 21:21:43.976917
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    internet = Internet()
    image = internet.image_placeholder()
    assert image is not None

# Generated at 2022-06-23 21:21:46.614719
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    """Unit test for method user_agent of class Internet."""
    internet = Internet()
    print('\nInternet.user_agent():')
    print(internet.user_agent())



# Generated at 2022-06-23 21:21:48.372817
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    assert Internet().content_type() == 'Content-Type: application/json'


# Generated at 2022-06-23 21:21:51.270369
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    internet = Internet()
    host = internet.ip_v4()
    assert isinstance(host, str)


# Generated at 2022-06-23 21:21:55.855532
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    internet = Internet()

    for method in [internet.home_page, internet.home_page_object]:
        assert isinstance(method(), str)
        assert method().startswith('http://')
        assert method().startswith('https://')
        assert method()[-1] is not '/'


# Generated at 2022-06-23 21:21:58.059425
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    print(Internet().http_status_code())
    return True
# print(test_Internet_http_status_code())


# Generated at 2022-06-23 21:21:59.790920
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    """Test for method user_agent of class Internet.

    Checks the length of generated string.
    """
    internet = Internet()
    user_agent = internet.user_agent()
    assert user_agent is not None
    assert len(user_agent) == 78

# Generated at 2022-06-23 21:22:00.515699
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    assert Internet().http_method() in set(HTTP_METHODS)


# Generated at 2022-06-23 21:22:05.165856
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    from mimesis.providers.internet import Internet
    objInternet = Internet()
    assert isinstance(objInternet.ip_v6(), str)




# Generated at 2022-06-23 21:22:13.784812
# Unit test for method port of class Internet
def test_Internet_port():
    i = Internet()
    for idx in range(10):
        port = i.port(PortRange.ALL)
        port_min = i.port(PortRange.MIN_PORT)
        port_max = i.port(PortRange.MAX_PORT)
        try:
            assert port >= 0 and port <= 65535
            assert port_max >= 0 and port_max <= 65535
            assert port_min >= 0 and port_min <= 65535
        except AssertionError:
            print('Failed test: Internet.port')

# Generated at 2022-06-23 21:22:15.281477
# Unit test for constructor of class Internet
def test_Internet():
    internet = Internet()
    assert internet is not None
    assert internet is not None

# Generated at 2022-06-23 21:22:17.538384
# Unit test for method home_page of class Internet
def test_Internet_home_page():
   internet = Internet()
   result = internet.home_page()
   assert result is not None
   assert isinstance(result, str)


# Generated at 2022-06-23 21:22:19.171438
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    provider = Internet()
    result = provider.home_page()
    print(result)

# Generated at 2022-06-23 21:22:24.684050
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    assert type(internet.stock_image(width=1920,height=1080)) == type("string")
    assert type(internet.stock_image(width=1920,height=1080,
                                     keywords=["cat"],writable=True)) == type(b'bytes')


# Generated at 2022-06-23 21:22:25.756535
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    internet = Internet()
    assert internet.emoji() in EMOJI


# Generated at 2022-06-23 21:22:30.647531
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    # Testing when quantity less than 1
    result = internet.hashtags(quantity=-1)
    assert len(result) == 4
    # Testing when quantity greater than 1000
    result = internet.hashtags(quantity=1001)
    assert len(result) == 4
    # Testing when quantity is 1
    result = internet.hashtags(quantity=1)
    assert isinstance(result, str)
    # Testing when quantity is equal to 4
    result = internet.hashtags(quantity=4)
    assert isinstance(result, list)
    assert len(result) == 4
    # Testing when quantity is not given
    result = internet.hashtags()
    assert len(result) == 4

# Generated at 2022-06-23 21:22:41.359248
# Unit test for method stock_image of class Internet

# Generated at 2022-06-23 21:22:44.871545
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    from mimesis.enums import Language
    from mimesis.providers.internet import Internet

    internet_en = Internet(language=Language.EN)
    internet_ru = Internet(language=Language.RU)

    assert internet_en.http_status_message() in HTTP_STATUS_MSGS
    assert internet_ru.http_status_message() in HTTP_STATUS_MSGS


# Generated at 2022-06-23 21:22:46.639775
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    ev = Internet()
    assert isinstance(ev.ip_v6_object(), IPv6Address)

# Generated at 2022-06-23 21:22:51.938576
# Unit test for method port of class Internet
def test_Internet_port():
    internet = Internet()
    assert isinstance(internet.port(port_range=PortRange.PRIVATE), int)
    try:
        internet.port(port_range='not a PortRange enum object')
    except NonEnumerableError as e:
        assert str(e) == 'Invalid value.'

# Generated at 2022-06-23 21:22:55.615749
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    from ipaddress import IPv6Address
    ip_v6 = IPv6Address("2001:0db8:85a3:08d3:1319:8a2e:0370:7344")

    assert(Internet().ip_v6_object()._ip == ip_v6._ip)

# Generated at 2022-06-23 21:23:00.011227
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    from mimesis.enums import TLDType
    from mimesis.providers.internet import Internet
    internet = Internet()
    country = internet.top_level_domain(tld_type=TLDType.COUNTRY)
    assert isinstance(country, str)
    assert len(country) > 0



# Generated at 2022-06-23 21:23:05.040406
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    from mimesis.enums import HTTPStatusCode

    status_codes = set()
    for _ in range(1000):
        status_code = Internet().http_status_code()
        status_codes.add(status_code)

    assert len(status_codes) == len(HTTPStatusCode)

# Generated at 2022-06-23 21:23:14.415177
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    internet = Internet('en')
    result = internet.mac_address()

# Generated at 2022-06-23 21:23:16.345751
# Unit test for constructor of class Internet
def test_Internet():
    """
    Unit test to check the constructor of class Internet.
    """
    myInternet = Internet()
    assert myInternet is not None

# Generated at 2022-06-23 21:23:17.909803
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    assert Internet().emoji() in Internet.Meta.providers[Internet.Meta.name][Internet.emoji.__name__]['data']


# Generated at 2022-06-23 21:23:20.558809
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    internet_ = Internet()
    assert internet_.content_type(MimeType.IMAGE_JPEG) == 'Content-Type: image/jpeg'



# Generated at 2022-06-23 21:23:24.842602
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    """Test for method mac_address of class Internet."""
    internet = Internet()

# Generated at 2022-06-23 21:23:25.670464
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    assert len(Internet().mac_address()) == 17

# Generated at 2022-06-23 21:23:29.373070
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    """Test for method network_protocol of class Internet."""
    internet = Internet()

    result = internet.network_protocol()
    assert result in NETWORK_PROTOCOLS[Layer.APPLICATION]

# Generated at 2022-06-23 21:23:39.441853
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    from mimesis.enums import PortRange
    import ipaddress
    ip = Internet()
    ip_adrs = ip.ip_v4(with_port=True, port_range=PortRange.SYS_ADMIN)
    ip_adrs_test = "127.0.0.1:80"
    assert ip_adrs == ip_adrs_test

    ip_adrs1 = ip.ip_v4(with_port=True, port_range=PortRange.ALL)
    ip_adrs1_test = "19.121.223.58:8000"
    assert ip_adrs1 == ip_adrs1_test

    ip_adrs2 = ip.ip_v4(with_port=False)
    ip_adrs2_test = "19.121.223.58"

# Generated at 2022-06-23 21:23:41.024111
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    i = Internet(10)
    print(i.stock_image(writable=True))


# Generated at 2022-06-23 21:23:42.686102
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    print(Internet('ru').ip_v4())  # For example: 107.220.118.77


# Generated at 2022-06-23 21:23:47.006076
# Unit test for method port of class Internet
def test_Internet_port():
    """Test that each port from PortRange enum is in range of
    PortRange enum.
    """
    internet = Internet(seed=0)

    for pr in PortRange:
        port = internet.port(port_range=pr)
        assert pr.value[0] <= port <= pr.value[1]


# Generated at 2022-06-23 21:23:49.780399
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    """Test for method emoji of class Internet."""
    for result in Internet().emoji():
        assert result in EMOJI and result[0] == ':'

# Generated at 2022-06-23 21:23:52.070407
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    internet = Internet()
    actual = internet.emoji()
    assert actual in EMOJI


# Generated at 2022-06-23 21:23:55.388691
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    internet = Internet()
    assert internet.ip_v4() != internet.ip_v4()
    assert internet.ip_v4(with_port=True) != internet.ip_v4(with_port=True)

# Generated at 2022-06-23 21:23:57.839903
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    assert Internet().http_status_code() in HTTP_STATUS_CODES


# Generated at 2022-06-23 21:24:00.684827
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
  int_obj = Internet(seed=1213)
  ip_v4 = int_obj.ip_v4()
  assert ip_v4 == '11.173.136.13'
  

# Generated at 2022-06-23 21:24:07.390588
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from mimesis.enums import PortRange
    from mimesis.providers.internet import Internet
    from mimesis.providers.network import Network
    Internet = Internet(seed = 10)
    Network = Network(seed = 10)

# Generated at 2022-06-23 21:24:09.130373
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
  print(Internet().user_agent())

# Generated at 2022-06-23 21:24:11.165774
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    """Test method http_method of class Internet."""
    obj = Internet()
    assert obj.http_method() in HTTP_METHODS

# Generated at 2022-06-23 21:24:12.469451
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    internet = Internet()
    print(internet.ip_v6())

# Generated at 2022-06-23 21:24:24.370299
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    r = Internet(seed=SEED)

    # Check for fixed string length
    for _ in range(1000):
        assert len(r.ip_v6()) == 39

    # Check for fixed division by colons
    for _ in range(1000):
        ip = r.ip_v6()
        assert len(ip.split(':')) == 8

    # Check for fixed division by hex digits
    assert len(r.ip_v6().split(':')) == 8
    assert all([len(x) == 4 for x in r.ip_v6().split(':')])

    # Check seed
    assert r.ip_v6() == '2001:c244:cf9d:1fb1:c56d:f52c:8a04:94f3'

    # Check randomness
    r = Internet()



# Generated at 2022-06-23 21:24:26.030239
# Unit test for constructor of class Internet
def test_Internet():
    inet1 = Internet()
    inet2 = Internet()
    assert inet1 != inet2

# Generated at 2022-06-23 21:24:28.599394
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    from mimesis.enums import MimeType

    content_type = Internet().content_type(MimeType.DOCUMENT)
    assert content_type == 'Content-Type: text/html'



# Generated at 2022-06-23 21:24:30.565573
# Unit test for constructor of class Internet
def test_Internet():
    class TestInternet():
        def test_init_object(self):
            obj = Internet()
            assert obj is not None

# Generated at 2022-06-23 21:24:34.516711
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    random.seed(0)
    ip_v6 = "2001:c244:cf9d:1fb1:c56d:f52c:8a04:94f3"
    assert Internet().ip_v6() == ip_v6


# Generated at 2022-06-23 21:24:41.964884
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    from mimesis.providers.internet import Internet
    from ipaddress import ip_address
    from mimesis.data import NETWORK_PROTOCOLS
    from mimesis.enums import Layer

    internet = Internet('en')
    ipv6 = internet.ip_v6()
    ip_object = ip_address(ipv6)

    assert isinstance(ipv6, str)
    assert isinstance(ip_object, IPv6Address)

    assert internet.network_protocol() in NETWORK_PROTOCOLS[Layer.APPLICATION]
    assert internet.network_protocol(Layer.APPLICATION) in NETWORK_PROTOCOLS[Layer.APPLICATION]
    assert internet.network_protocol(Layer.TRANSPORT) in NETWORK_PROTOCOLS[Layer.TRANSPORT]


# Generated at 2022-06-23 21:24:44.472546
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    provider = Internet("en")
    print(provider.emoji())
    #Output:
    #❤


# Generated at 2022-06-23 21:24:46.965271
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    i = Internet.stock_image(width=1920, height=1080)
    assert i is not None

# Generated at 2022-06-23 21:24:50.584116
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    pattern = r'([1-5]\d{2})|(\d{3})'
    internet = Internet()
    text = internet.http_status_code()
    assert search(pattern, str(text))



# Generated at 2022-06-23 21:24:52.005009
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    internet = Internet()
    mac = internet.mac_address()
    assert isinstance(mac, str)

# Generated at 2022-06-23 21:25:01.477303
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    """Unit test for stock_image method of class Internet.
    """
    import os
    import tempfile
    import PIL.Image

    i = Internet()
    image = i.stock_image(writable=True)
    img_name = 'test_image.jpg'
    img_path = os.path.join(tempfile.gettempdir(), img_name)

    try:
        with open(img_path, 'wb') as f:
            f.write(image)
        im = PIL.Image.open(img_path)
        assert im.size == (1920, 1080)
    except (OSError, IOError):
        pass
    finally:
        if os.path.exists(img_path):
            os.remove(img_path)

# Generated at 2022-06-23 21:25:04.483600
# Unit test for constructor of class Internet
def test_Internet():
    """test for constructor of class Internet"""
    from mimesis.builtins import datetime

    custom_datetime = datetime.Datetime()
    internet = Internet(seed=custom_datetime.timestamp())
    assert internet.seed == custom_datetime.timestamp()


# Generated at 2022-06-23 21:25:05.938623
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    assert Internet().user_agent() in USER_AGENTS


# Generated at 2022-06-23 21:25:09.284759
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    print("Testing Internet class, method home_page...")
    internet = Internet()
    assert internet.home_page() == "https://divert.info"

test_Internet_home_page()

# Generated at 2022-06-23 21:25:11.907338
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    internet = Internet()
    net_protocol = internet.network_protocol(layer=Layer.TRANSPORT)
    assert net_protocol == 'AMQP'



# Generated at 2022-06-23 21:25:13.736486
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    # Act
    internet = Internet()
    # Assert
    assert internet.top_level_domain() in TLD[TLDType.ALL]

# Generated at 2022-06-23 21:25:23.431095
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    from mimesis.enums import DomainType
    import requests
    from mimesis.builtins import USERS
    internet = Internet()
    for i in range(10):
        home_page = internet.home_page(tld_type=DomainType.WIKI)
        print(home_page)
        response = requests.get(home_page)
        if (response.status_code == 200):
            print("Found a valid homepage: " + home_page)
            break
        else:
            print("Not Found a valid homepage: " + home_page + " , Generating a new one")


# Generated at 2022-06-23 21:25:31.144018
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    from mimesis.enums import TLDType
    from mimesis.providers.internet import Internet
    from mimesis.data import TLD
    from mimesis.providers.file import File
    from mimesis.data import EMOJI
    from mimesis.enums import Layer, PortRange
    from mimesis.enums import MimeType
    from mimesis.data import (
        HTTP_METHODS,
        HTTP_STATUS_CODES,
        HTTP_STATUS_MSGS,
        NETWORK_PROTOCOLS,
        USER_AGENTS,
    )
    from mimesis.providers.utils import is_int

    Internet = Internet()

# Generated at 2022-06-23 21:25:33.751187
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    """Unit test for method home_page of class Internet."""
    internet = Internet()
    result = internet.home_page()
    assert result == "https://invis.info"

# Generated at 2022-06-23 21:25:38.690903
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    test = Internet()
    http_methods = list(HTTP_METHODS)
    count = 0
    while count < 100:
        assert test.http_method() in http_methods
        count += 1


# Generated at 2022-06-23 21:25:43.776125
# Unit test for method port of class Internet
def test_Internet_port():
    print("\nUnit test for method port of class Internet")
    portRange = PortRange.RESERVED
    print(portRange)
    port = Internet().port(port_range=portRange)
    print(port)
    assert port >= PortRange.RESERVED.value[0]
    assert port <= PortRange.RESERVED.value[1]
    print("------")


# Generated at 2022-06-23 21:25:46.030167
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    internet = Internet()
    ip = internet.ip_v4()

    assert isinstance(ip, str)


# Generated at 2022-06-23 21:25:50.579154
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    """Test http_method method of class Internet"""
    # GIVEN
    internet = Internet()

    # WHEN
    method = internet.http_method()

    # THEN
    assert isinstance(method, str)
    assert method in HTTP_METHODS


# Generated at 2022-06-23 21:26:00.490048
# Unit test for constructor of class Internet
def test_Internet():
    internet_fn = Internet(seed=1)
    assert isinstance(internet_fn.content_type(), str)
    assert isinstance(internet_fn.http_status_message(), str)
    assert isinstance(internet_fn.http_status_code(), int)
    assert isinstance(internet_fn.http_method(), str)
    assert isinstance(internet_fn.ip_v4_object(), IPv4Address)
    assert isinstance(internet_fn.ip_v4(), str)
    assert isinstance(internet_fn.ip_v6_object(), IPv6Address)
    assert isinstance(internet_fn.ip_v6(), str)
    assert isinstance(internet_fn.mac_address(), str)
    assert isinstance(internet_fn.emoji(), str)

# Generated at 2022-06-23 21:26:07.717729
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    from mimesis.enums import DataLayer

    internet = Internet(seed=777)
    ip = internet.ip_v6()
    assert isinstance(ip, str) == True
    assert ip == '2001:c244:cf9d:1fb1:c56d:f52c:8a04:94f3'
    may_ip = internet.ip_v6()
    assert may_ip != ip


# Generated at 2022-06-23 21:26:09.822140
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    internet = Internet(seed=10)
    mac = internet.mac_address()
    print("mac = {}".format(mac))

# Generated at 2022-06-23 21:26:11.407140
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    internet = Internet()
    ip = internet.ip_v6_object()
    assert isinstance(ip, IPv6Address)

# Generated at 2022-06-23 21:26:14.648758
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    a = Internet()
    mac = a.mac_address()
    print(mac)
    print(type(mac))
    print(len(mac))
    print(mac.count(':'))


# Generated at 2022-06-23 21:26:20.390680
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    """Check Internet class"""
    from mimesis.enums import MimeType

    internet = Internet()
    print(internet.content_type())
    print(internet.content_type(mime_type=MimeType.IMAGE))
    print(internet.content_type(mime_type=MimeType.TEXT))


# Generated at 2022-06-23 21:26:23.844864
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    """Mac address unit test."""
    internet = Internet()
    result = set()

    for _ in range(100):
        mac_address = internet.mac_address()
        result.add(mac_address)

    assert len(result) == 100

# Generated at 2022-06-23 21:26:35.006036
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    # wrong argument for method network_protocol for class Internet
    I1 = Internet()
    try:
        I1.network_protocol('layer')
    except Exception as e:
        assert isinstance(e, NonEnumerableError)
    # wrong argument for method network_protocol for class Internet
    try:
        I1.network_protocol(12)
    except Exception as e:
        assert isinstance(e, NonEnumerableError)
    # wrong argument for method network_protocol for class Internet
    try:
        I1.network_protocol('wrong argument')
    except Exception as e:
        assert isinstance(e, NonEnumerableError)
    # correct argument for method network_protocol for class Internet
    assert isinstance(I1.network_protocol(Layer.APPLICATION), str)

# Generated at 2022-06-23 21:26:37.307602
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    internet = Internet()
    ipv4 = internet.ip_v4()
    assert ipv4 == '160.220.48.231'

# Generated at 2022-06-23 21:26:39.331133
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    internet = Internet()
    result = internet.emoji()
    assert result == ":kissing:"


# Generated at 2022-06-23 21:26:40.175170
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    for _ in range(10):
        assert Internet().http_status_code() < 600

# Generated at 2022-06-23 21:26:42.374805
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    generator = Internet()
    mac_address = generator.mac_address()
    assert len(mac_address) == 17

# Generated at 2022-06-23 21:26:46.764672
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    # Given
    internet = Internet()
    mime_type = MimeType.APPLICATION
    # When
    result = internet.content_type(mime_type)
    # Then
    assert result.startswith('Content-Type: application')



# Generated at 2022-06-23 21:26:49.645945
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    internet = Internet()
    assert internet.http_status_message() in HTTP_STATUS_MSGS


# Generated at 2022-06-23 21:26:52.591216
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    s = Internet()
    status_code = s.http_status_code()
    print(status_code)
    assert status_code in HTTP_STATUS_CODES


# Generated at 2022-06-23 21:26:54.068867
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    """Test method emoji"""
    assert ':' in Internet().emoji()

# Generated at 2022-06-23 21:26:54.997755
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    Internet().network_protocol(Layer.LINK)

# Generated at 2022-06-23 21:27:01.418413
# Unit test for method port of class Internet
def test_Internet_port():
    from mimesis.builtins import PortRange
    from mimesis.enums import Layer
    from mimesis.providers.internet import Internet

    internet = Internet()

    assert internet.port() == 80
    assert internet.port(port_range=PortRange.PRIVATE) == 49152
    assert internet.port(port_range=PortRange.PRIVATE) == 49160
    assert internet.port(port_range=PortRange.WELL_KNOWN) == 7
    assert internet.port(port_range=PortRange.WELL_KNOWN) == 19


# Generated at 2022-06-23 21:27:02.779012
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    internet = Internet()
    print(internet.content_type())


# Generated at 2022-06-23 21:27:06.021458
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    """Unit test for method http_status_code of class Internet.
    """
    my_class = Internet()
    my_status_code = my_class.http_status_code()
    assert (my_status_code in HTTP_STATUS_CODES)

# Generated at 2022-06-23 21:27:10.621201
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    from mimesis.enums import TLDType
    i = Internet()
    # Test for TLDType.GENERIC
    tld = i.top_level_domain(tld_type=TLDType.GENERIC)
    assert tld in TLD[TLDType.GENERIC]

# Generated at 2022-06-23 21:27:12.584925
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    internet = Internet()
    method = internet.http_method()
    assert method in HTTP_METHODS

# Generated at 2022-06-23 21:27:15.303380
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    from mimesis.enums import Layer
    from mimesis.providers.internet import Internet

    internet = Internet()
    assert type(internet.mac_address()) == str

    p = internet.network_protocol(layer=Layer.LAYER_3)
    assert type(p) == str

# Generated at 2022-06-23 21:27:17.961823
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    """Test the Internet.home_page method."""
    home_p = Internet().home_page()
    assert home_p == 'https://murphy.info'


# Generated at 2022-06-23 21:27:20.337131
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    for i in range(1000):
        ip = Internet().ip_v6()
        assert isinstance(ip, str)
        assert len(ip) > 0


# Generated at 2022-06-23 21:27:21.229489
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    print(Internet.image_placeholder())

# Generated at 2022-06-23 21:27:22.435515
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    internet = Internet()
    internet.http_status_code() == 200

# Generated at 2022-06-23 21:27:24.460713
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    random = Internet()
    targ = '00:16:3e:3b:63:6b'
    assert(random.mac_address() == targ)


# Generated at 2022-06-23 21:27:33.043679
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    internet = Internet()

# Generated at 2022-06-23 21:27:39.039572
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    """
    Test method top_level_domains of class Internet.
    """
    obj = Internet()
    print(obj.top_level_domain(TLDType.COUNTRY))
    print(obj.top_level_domain(TLDType.GENERIC))
    print(obj.top_level_domain(TLDType.INFRASTRUCTURE))

# Generated at 2022-06-23 21:27:40.706204
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    internet = Internet()
    assert internet.http_status_message() in HTTP_STATUS_MSGS


# Generated at 2022-06-23 21:27:43.660978
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    print("\n\nTest Internet_ip_v6")
    print("Retrieving 100 random IPv6 addresses:")
    for _ in range(100):
        print("\t" + Internet().ip_v6())


# Generated at 2022-06-23 21:27:50.842997
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    seed = 0
    intnet = Internet(seed=seed)

    assert intnet.stock_image(width=5, height=5) == \
        "https://source.unsplash.com/5x5?exact"

    assert intnet.stock_image(width=5, height=5, keywords=[""]) == \
        "https://source.unsplash.com/5x5?"

    assert intnet.stock_image(width=5, height=5, keywords=["exact"]) == \
        "https://source.unsplash.com/5x5?exact"

    assert intnet.stock_image(width=5, height=5, keywords=["5x5"]) == \
        "https://source.unsplash.com/5x5?5x5"


# Generated at 2022-06-23 21:27:52.404749
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    assert internet.content_type() is not None


# Generated at 2022-06-23 21:28:01.095522
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    internet = Internet()
    # test with domaintype 'GENERAL'
    top_level_domain = internet.top_level_domain(tld_type=TLDType.GENERAL)
    assert isinstance(top_level_domain, str)
    assert len(top_level_domain) > 1

    # test with domaintype 'RANDOM'
    top_level_domain = internet.top_level_domain(tld_type=TLDType.RANDOM)
    assert isinstance(top_level_domain, str)
    assert len(top_level_domain) > 1

    # test with domaintype 'RESTRICTED'
    top_level_domain = internet.top_level_domain(tld_type=TLDType.RESTRICTED)
    assert isinstance(top_level_domain, str)

# Generated at 2022-06-23 21:28:02.219146
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    internet = Internet()
    print(internet.network_protocol())


# Generated at 2022-06-23 21:28:13.632803
# Unit test for constructor of class Internet
def test_Internet():
    internet = Internet()
    # print(internet.ip_v4_object())
    print(internet.ip_v4(True))
    # print(internet.ip_v6_object())
    print(internet.ip_v6())
    print(internet.mac_address())
    print(internet.emoji())
    print(internet.image_placeholder())
    print(internet.stock_image())
    print(internet.hashtags(3))
    print(internet.home_page())
    print(internet.top_level_domain())
    print(internet.user_agent())
    print(internet.network_protocol())
    print(internet.port())

if __name__ == '__main__':
    test_Internet()

# Generated at 2022-06-23 21:28:15.905325
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    e = Internet()
    print(e.user_agent())
    print(e.user_agent())
    print(e.user_agent())


# Generated at 2022-06-23 21:28:17.573380
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    """Test method mac_address"""
    internet = Internet()
    mac = internet.mac_address()
    print('mac_address:', mac)


# Generated at 2022-06-23 21:28:21.053224
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    int_ = Internet(seed=123456789)
    emoji = int_.emoji()
    assert emoji == ':kissing:'

# Generated at 2022-06-23 21:28:22.339140
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    Internet().http_method()



# Generated at 2022-06-23 21:28:25.082431
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    internet = Internet()
    placeholder = internet.image_placeholder(1920, 1080)
    assert placeholder == 'http://placehold.it/1920x1080'



# Generated at 2022-06-23 21:28:28.201475
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    """Test method image_placeholder of class Internet."""
    url = Internet.image_placeholder(width=1920, height=1080)
    assert url == 'http://placehold.it/1920x1080'

# Generated at 2022-06-23 21:28:30.220155
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    internet = Internet()
    assert internet.top_level_domain(tld_type=TLDType.COUNTRY_CODE)


# Generated at 2022-06-23 21:28:37.906520
# Unit test for constructor of class Internet

# Generated at 2022-06-23 21:28:40.455981
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    """Unit test for method ip_v6_object of class Internet."""
    assert isinstance(Internet().ip_v6_object(), IPv6Address)



# Generated at 2022-06-23 21:28:51.521170
# Unit test for constructor of class Internet
def test_Internet():
    """Test for Internet class of mimesis.
    """
    internet = Internet()
    # Test for content type.
    assert internet.content_type() == 'Content-Type: text/plain'
    # Test for emoji.
    assert internet.emoji() in EMOJI
    # Test for hashtag.
    assert internet.hashtags(quantity=10) != []
    # Test for http status code.
    assert internet.http_status_code() in HTTP_STATUS_CODES
    # Test for http method.
    assert internet.http_method() in HTTP_METHODS
    # Test for ip v4.
    assert internet.ip_v4() in internet.ip_v4()
    # Test for ip v6.
    assert internet.ip_v6() in internet.ip_v6()
    # Test for

# Generated at 2022-06-23 21:28:56.388304
# Unit test for method port of class Internet
def test_Internet_port():
    from  mimesis.enums import PortRange
    from mimesis.providers.internet import Internet
    inter = Internet(seed=0)
    port1 = inter.port()
    assert port1 == 0
    port2 = inter.port(port_range=PortRange.ALL)
    assert port2 == 49152
    port3 = inter.port(port_range=PortRange.PRIVILEGED)
    assert port3 == 1
    port4 = inter.port(port_range=PortRange.UNPRIVILEGED)
    assert port4 == 49152

# Generated at 2022-06-23 21:28:58.631594
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    it = Internet()
    res = it.content_type()
    assert 'Content-Type' in res
    assert 'application/json' == res.split(':')[-1].strip()

# Generated at 2022-06-23 21:29:00.810882
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    """Test for the function mac_address of class Internet."""
    cls = Internet()
    mac = cls.mac_address()
    assert len(mac) == 17 and ':' in mac

# Generated at 2022-06-23 21:29:06.621255
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    from mimesis.enums import TLDType
    internet = Internet()
    home_page = 'https://alexandersk.info'
    assert internet.home_page(tld_type=TLDType.FREE) == home_page, \
        "https://alexandersk.info != {}".format(internet.home_page(tld_type=TLDType.FREE))

# Generated at 2022-06-23 21:29:18.343616
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    provider = Internet()
    assert isinstance(provider.ip_v4(), str)
    assert len(provider.ip_v4().split('.')) == 4
    assert isinstance(provider.ip_v4(with_port=True), str)
    assert isinstance(provider.port(), int)
    assert provider.port() >= 0
    assert provider.port() <= 65535
    assert provider.port(port_range=PortRange.ALL) >= 0
    assert provider.port(port_range=PortRange.ALL) <= 65535
    assert provider.port(port_range=PortRange.SPECIAL) <= 1024
    assert provider.port(port_range=PortRange.SPECIAL) > 0
    assert provider.port(port_range=PortRange.GLOBAL) <= 49151

# Generated at 2022-06-23 21:29:19.984381
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    from mimesis.providers.internet import Internet
    obj=Internet()
    obj.mac_address()
    assert True

# Generated at 2022-06-23 21:29:26.540391
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    # Create a Fake
    fake = Internet()

    # Create a set as a good container of unique items
    address_set = set()

    # Generate 10000 MAC Addresses
    for _ in range(10000):
        current_address = fake.mac_address()
        address_set.add(current_address)
    
    # Size of set equals to 10000?
    assert len(address_set) == 10000, 'MAC Address generation not working'

# Generated at 2022-06-23 21:29:28.432693
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    result = Internet().ip_v4_object()
    assert isinstance(result, IPv4Address)

# Generated at 2022-06-23 21:29:40.028479
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    from mimesis.builtins import Internet
    from mimesis.enums import MimeType
    i = Internet('en')
    print('i.http_status_code(): ' + str(i.http_status_code()))
    print('i.http_status_message(): ' + str(i.http_status_message()))
    print('i.http_method(): ' + str(i.http_method()))
    print('i.ip_v4(): ' + str(i.ip_v4()))
    print('i.ip_v4(with_port=True): ' + str(i.ip_v4(with_port=True)))
    print('i.ip_v6(): ' + str(i.ip_v6()))