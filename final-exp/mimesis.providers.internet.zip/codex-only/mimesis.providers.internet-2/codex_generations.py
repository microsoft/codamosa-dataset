

# Generated at 2022-06-23 21:19:44.487127
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    """
    >>> internet = Internet()
    >>> internet.stock_image()
    'https://source.unsplash.com/1920x1080?'
    """

# Generated at 2022-06-23 21:19:55.616069
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    """Test that it returns the correct result."""
    from mimesis.enums import Hashtag

    internet = Internet('en')

    assert isinstance(internet.hashtags(), str)
    assert isinstance(internet.hashtags(quantity=1), str)
    assert isinstance(internet.hashtags(quantity=3), list)
    assert isinstance(internet.hashtags(quantity=3,
                                        category=Hashtag.FOOD), list)
    assert isinstance(internet.hashtags(quantity=3,
                                        category=Hashtag.ANIMALS), list)
    assert isinstance(internet.hashtags(quantity=3,
                                        category=Hashtag.NATURE), list)
    assert isinstance(internet.hashtags(quantity=3,
                                        category=Hashtag.OBJECTS), list)

# Generated at 2022-06-23 21:19:59.127780
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    internet = Internet()
    assert internet.image_placeholder(width=400, height=300) == 'http://placehold.it/400x300'


# Generated at 2022-06-23 21:20:08.203552
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    import ipaddress
    rndm = Internet(seed=23)
    # 1rst time
    assert(rndm.ip_v6_object() == ipaddress.IPv6Address('23:bb:cb:da:dc:eb:ff:0f'))
    # 2nd time
    assert(rndm.ip_v6_object() == ipaddress.IPv6Address('1b:5e:ee:74:d8:7e:58:0f'))
    # 3rd time
    assert(rndm.ip_v6_object() == ipaddress.IPv6Address('1b:5e:ee:74:d8:7e:58:0f'))
    # 4th time

# Generated at 2022-06-23 21:20:13.323881
# Unit test for method port of class Internet
def test_Internet_port():
    from mimesis.enums import PortRange
    from mimesis.providers.internet import Internet
    i = Internet()
    port = i.port(port_range=PortRange.UNPRIVILEGED)
    assert isinstance(port, int)
    assert port > 1024 and port < 65535

# Generated at 2022-06-23 21:20:15.569194
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    from mimesis.enums import DataField

    i = Internet(DataField())
    address = i.mac_address()
    assert address is not None


# Generated at 2022-06-23 21:20:17.573515
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    internet = Internet()
    assert type(internet.ip_v4_object()) == IPv4Address


# Generated at 2022-06-23 21:20:19.836810
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    internet = Internet()
    assert internet.http_method() in HTTP_METHODS



# Generated at 2022-06-23 21:20:20.593476
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    assert Internet().emoji() in EMOJI

# Generated at 2022-06-23 21:20:23.846496
# Unit test for method port of class Internet
def test_Internet_port():
    from mimesis.enums import PortRange
    port_range = PortRange.COMMERCIAL
    assert int < type(Internet().port()) < int



# Generated at 2022-06-23 21:20:27.337043
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    internet = Internet()
    expected = random.choice(internet._data['http_status_msgs'])
    result = internet.http_status_message()
    assert expected == result



# Generated at 2022-06-23 21:20:33.561975
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    """Test method 'stock_image'."""
    import urllib.error

    provider = Internet(seed=42)
    img_url = provider.stock_image(
        width=1080,
        height=1920,
        keywords=['nature', 'food', 'travel'])
    img_file = provider.stock_image(
        width=1080,
        height=1920,
        keywords=['nature', 'food', 'travel'],
        writable=True)
    assert img_url == 'https://source.unsplash.com/1080x1920?nature,food,travel'
    assert isinstance(img_file, bytes)
    assert isinstance(img_file, bytes)

# Generated at 2022-06-23 21:20:46.258230
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    from mimesis.enums import SpecialChar
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.system import System
    from mimesis.providers.web import Web

    from datetime import datetime
    from mimesis import Mimesis

    seed = datetime.now()
    c = Mimesis(seed=seed)
    c = Mimesis()
    c = Internet(seed=seed)
    c = Internet()
    print(Internet.Meta.name)
    print(c.content_type())
    print(c.emoji())
    print(c.hashtags())
    print(c.hashtags(1))
    print(c.home_page())
    print(c.http_method())
    print(c.http_status_code())
    print

# Generated at 2022-06-23 21:20:49.255759
# Unit test for method port of class Internet
def test_Internet_port():
    """
    Test_Internet_port
    """
    internet = Internet()
    port = internet.port(PortRange.WELL_KNOWN)
    print(port)


# Generated at 2022-06-23 21:20:53.489407
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    p = Internet()
    protocols = ['Ethernet', 'MPLS', 'PIM', 'IP', 'ICMP',
                 'DHCP', 'HTTPS', 'DNS', 'SSH', 'Telnet',
                 'HTTP', 'FTP', 'SMTP', 'POP3', 'IMAP']
    assert p.network_protocol(layer=Layer.APPLICATION) in protocols

# Generated at 2022-06-23 21:21:00.693953
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    from mimesis.enums import HTTPMethod
    from mimesis.random import Random
    from mimesis.providers.internet import Internet
    
    r = Random()
    r.seed(42)
    i = Internet(random=r)
    
    for _ in range(100):
        i.http_method()

    r.seed(42)
    assert i.http_method() == HTTPMethod.GET
    assert i.http_method() == HTTPMethod.DELETE
    assert i.http_method() == HTTPMethod.PATCH
    assert i.http_method() == HTTPMethod.POST
    assert i.http_method() == HTTPMethod.PUT


# Generated at 2022-06-23 21:21:02.452368
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    MacAddress = Internet()
    print(MacAddress.mac_address())

# Generated at 2022-06-23 21:21:05.159093
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    provider = Internet()

    for _ in range(10):
        url = provider.home_page()
        assert url.startswith('https://')
        assert url.endswith('.info')

# Generated at 2022-06-23 21:21:09.246063
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    assert Internet.content_type(MimeType.IMAGE).startswith('Content-Type: image/')


# Generated at 2022-06-23 21:21:10.292087
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    i = Internet()
    print(i.home_page())


# Generated at 2022-06-23 21:21:13.122341
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    internet = Internet()
    for _ in range(100):
        emoji = internet.emoji()
        print(emoji)


# Generated at 2022-06-23 21:21:19.352563
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    print("Testing Internet.ip_v4")
    data = []
    for i in range(10):
        addr = Internet.ip_v4()
        assert type(addr) is str
        assert len(addr) > 0
        if addr not in data:
            data.append(addr)
        else:
            print("Duplicate value: " + addr)
            assert False
    assert len(data) == 10
    print("Success")


# Generated at 2022-06-23 21:21:21.019296
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    internet = Internet()
    #print(internet.emoji())


# Generated at 2022-06-23 21:21:23.345171
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    # Using the same seed will generate the same results
    provider = Internet(seed=47)
    http_status_message = provider.http_status_message()
    assert http_status_message == 'OK'


# Generated at 2022-06-23 21:21:29.433653
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    from mimesis.enums import HttpMethod
    from mimesis.typing import HTTP_METHODS
    from mimesis.providers.internet import Internet
    inter = Internet()
    http_method_result = inter.http_method()
    assert http_method_result in HTTP_METHODS, "http_method_result should be in the list"
    assert isinstance(HttpMethod(http_method_result), HttpMethod), "http_method_result should be an HttpMethod object"


# Generated at 2022-06-23 21:21:31.841586
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    internet = Internet()
    assert internet.content_type() == "Content-Type: application/json"


# Generated at 2022-06-23 21:21:36.466317
# Unit test for constructor of class Internet
def test_Internet():
    from mimesis.enums import TLDType
    prov = Internet()
    print("\n--------test_Internet--------")
    print("\nprov.content_type()1: ",prov.content_type())
    print("\nprov.content_type()2: ",prov.content_type(MimeType.AUDIO))
    print("\nprov.http_status_message(): ",prov.http_status_message())
    print("\nprov.http_status_code(): ",prov.http_status_code())
    print("\nprov.http_method(): ",prov.http_method())
    print("\nprov.ip_v4_object(): ",prov.ip_v4_object())
    print("\nprov.ip_v4(): ",prov.ip_v4())

# Generated at 2022-06-23 21:21:44.276975
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    internet = Internet()
    height = 300
    width = 500
    url = internet.image_placeholder(height=height, width=width)
    assert url == f'http://placehold.it/{width}x{height}'
    url = internet.image_placeholder(height, width) # Without keyword parameters
    assert url == f'http://placehold.it/{width}x{height}'

test_Internet_image_placeholder()

# Generated at 2022-06-23 21:21:47.175990
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    """Test method http_method of class Internet."""
    internet = Internet()
    actual = internet.http_method()
    assert actual in HTTP_METHODS


# Generated at 2022-06-23 21:21:48.184194
# Unit test for constructor of class Internet
def test_Internet():
    assert Internet(seed=42)

# Generated at 2022-06-23 21:21:49.484247
# Unit test for constructor of class Internet
def test_Internet():
    Internet()


# Generated at 2022-06-23 21:21:58.012669
# Unit test for method port of class Internet
def test_Internet_port():
    from mimesis.enums import PortRange
    from mimesis.exceptions import NonEnumerableError

    obj = Internet()
    args = {}

    for _ in range(10):
        for k, v in PortRange.__members__.items():
            args[k] = v
    for k, v in args.items():
        port = obj.port(port_range=v)
        print(port)
        assert v[0] <= port <= v[1]

    try:
        obj.port(port_range=5)
    except NonEnumerableError:
        pass
    else:
        assert False

# Generated at 2022-06-23 21:22:03.718316
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    """Test for method ip_v4 of class Internet."""
    # Define seed for random of generator
    seed = 'my_seed'
    # Create an object from class Internet
    internet = Internet(seed=seed)
    # Generate ip v4 with port
    ip = internet.ip_v4(with_port=True)
    # Expected result
    result = '132.198.248.59:80'
    # Print result
    print(ip)
    # Check method ip_v4
    assert ip == result


# Generated at 2022-06-23 21:22:06.644522
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    internet = Internet()
    result = internet.image_placeholder()
    assert(result == "http://placehold.it/1920x1080")

# Generated at 2022-06-23 21:22:18.287176
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    """Unit test for method network_protocol."""
    internet = Internet()

    result = internet.network_protocol(layer=Layer.APPLICATION)
    assert isinstance(result, str)
    assert len(result) > 0

    result = internet.network_protocol(layer=Layer.TRANSPORT)
    assert isinstance(result, str)
    assert len(result) > 0

    result = internet.network_protocol(layer=Layer.NETWORK)
    assert isinstance(result, str)
    assert len(result) > 0

    result = internet.network_protocol(layer=Layer.DATA_LINK)
    assert isinstance(result, str)
    assert len(result) > 0

    result = internet.network_protocol(layer=Layer.PHYSICAL)

# Generated at 2022-06-23 21:22:27.712686
# Unit test for method port of class Internet
def test_Internet_port():
    internet = Internet()
    # assert internet.port(PortRange.ALL) in range(0, 65535)
    assert internet.port(PortRange.WELL_KNOWN) in range(0, 1023)
    assert internet.port(PortRange.REGISTERED) in range(1024, 49151)
    assert internet.port(PortRange.DYNAMIC_AND_PRIVATE) in range(49152, 65535)
    assert internet.port(PortRange(1024, 49151)) in range(1024, 49151)
    assert internet.port(PortRange(0, 0)) == 0

test_Internet_port()

# Generated at 2022-06-23 21:22:30.590644
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    for i in range(100):
        assert isinstance(Internet().ip_v4_object(), IPv4Address)



# Generated at 2022-06-23 21:22:37.679772
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    print("Testing Internet_mac_address")
    from mimesis.enums import DataType
    from mimesis.providers.internet import Internet
    internet = Internet()
    # Testing generated value
    assert re.match(r'^([a-fA-F0-9]{2}[:|\-]?){6}$', internet.mac_address())
    # Testing is type equal to str
    assert type(internet.mac_address(data_type=DataType.STRING)) is str

# Generated at 2022-06-23 21:22:39.805707
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    internet = Internet()
    status = internet.http_status_message()
    assert isinstance(status, str)


# Generated at 2022-06-23 21:22:41.188882
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    internet = Internet()
    internet.network_protocol(layer=Layer.ESTABLISHMENT)

# Generated at 2022-06-23 21:22:42.581936
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    internet = Internet()
    assert internet.http_method() in HTTP_METHODS


# Generated at 2022-06-23 21:22:48.112152
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    internet = Internet()
    print(internet.top_level_domain(internet.tld_type.Usual))
    print(internet.top_level_domain(internet.tld_type.Country))
    print(internet.top_level_domain(internet.tld_type.Infrequent))


# Generated at 2022-06-23 21:22:51.466819
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    obj = Internet()
    # make sure the method returns str
    assert isinstance(obj.emoji(), str)


# Generated at 2022-06-23 21:22:57.195521
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    inter = Internet()
    ipv6_addr_mock = IPv6Address('2001:0db8:85a3:08d3:1319:8a2e:0370:7344')
    ipv6_addr = inter.ip_v6_object()
    assert isinstance(ipv6_addr, IPv6Address)
    assert ipv6_addr == ipv6_addr_mock


# Generated at 2022-06-23 21:22:59.520391
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    for i in range(100):
        result = Internet().http_status_message()
        assert result in HTTP_STATUS_MSGS

# Generated at 2022-06-23 21:23:02.452298
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    internet = Internet()
    mac_address = internet.mac_address()
    print("mac address is: ", mac_address)


# Generated at 2022-06-23 21:23:09.289082
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    """Method for Unit test of Internet.network_protocol()."""
    from enum import Enum
    from mimesis.enums import Layer

    class LayerTest(Enum):
        """Class for testing."""

        TEST = Layer.APPLICATION.value + ['TEST']

    class Test:
        """Class with unit test."""

        def test_with_key(self):
            """Test with key."""
            internet = Internet()
            assert internet.network_protocol(layer=Layer.APPLICATION) in \
                Layer.APPLICATION.value

        def test_with_enum(self):
            """Test with enum."""
            internet = Internet()
            assert internet.network_protocol(layer=LayerTest.TEST) in LayerTest.TEST.value


# Generated at 2022-06-23 21:23:11.313997
# Unit test for constructor of class Internet
def test_Internet():
    i = Internet()
    assert i is not None
    assert i.seed is not None
    assert i.random is not None


# Generated at 2022-06-23 21:23:14.624375
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    image = internet.stock_image()


if __name__ == "main":
    test_Internet_stock_image()

# Generated at 2022-06-23 21:23:17.454201
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from mimesis.providers.internet import Internet
    i = Internet()
    link = i.stock_image(width=1920, height=1080, keywords=["nature"])
    assert link == "https://source.unsplash.com/1920x1080?nature"

# Generated at 2022-06-23 21:23:18.993234
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    mimesis = Internet()
    assert len(mimesis.emoji()) >= 2

# Generated at 2022-06-23 21:23:24.658288
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    """Unit test for method home_page of class Internet.

    :return: None.
    """
    inter = Internet()
    top_level_domain = inter.top_level_domain(tld_type=TLDType.GOV)
    resource = inter.random.choice(USERNAMES)
    url = 'https://{resourse}{domain}'.format(resourse=resource, domain=top_level_domain)
    assert inter.home_page(tld_type=TLDType.GOV) == url

# Generated at 2022-06-23 21:23:29.043019
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    internet = Internet()
    ip_v6 = internet.ip_v6_object()
    assert isinstance(ip_v6, IPv6Address)
    assert ip_v6 is not None


# Generated at 2022-06-23 21:23:31.674398
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    """Unit test for method ip_v6_object in class Internet."""
    teststring = '[::]:636'

    ip = IPv6Address(teststring)

    assert isinstance(ip, IPv6Address)

# Generated at 2022-06-23 21:23:33.675107
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    internet = Internet()
    assert internet.http_method() in HTTP_METHODS


# Generated at 2022-06-23 21:23:35.699382
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    cls = Internet()
    assert len(cls.http_status_message())


# Generated at 2022-06-23 21:23:42.865275
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():

    import unittest

    from mimesis.enums import TLDType

    class InternetTestCase(unittest.TestCase):

        def setUp(self):
            self.internet = Internet('ru')

        def test_top_level_domain(self):
            result = self.internet.top_level_domain()
            self.assertIsInstance(result, str)
            self.assertIn(result, self.internet.tld)

        def test_top_level_domain_with_tld_type(self):
            result = self.internet.top_level_domain(tld_type=TLDType.RU)
            self.assertIn(result, self.internet.tld[TLDType.RU])

        def test_top_level_domain_with_wrong_tld_type(self):
            result

# Generated at 2022-06-23 21:23:51.974392
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    provider = Internet(['en-US'], 'en')
    image = provider.image_placeholder()
    assert image == 'http://placehold.it/1920x1080'

    image = provider.image_placeholder(
        width=100,
        height=100,
    )
    assert image == 'http://placehold.it/100x100'

    image = provider.image_placeholder(
        width='100',
        height='100',
    )
    assert image == 'http://placehold.it/100x100'


# Unit tests for methods has_tld of class Internet

# Generated at 2022-06-23 21:23:57.409851
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    count = 0
    internet = Internet()
    while count < 100:
        layer_name = internet.random.choice(list(Layer))
        protocol = internet.network_protocol(layer=layer_name)
        if protocol in NETWORK_PROTOCOLS[layer_name]:
            count += 1
        else:
            assert False

# Generated at 2022-06-23 21:24:06.065341
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    from collections import Counter

    from mimesis.enums import Layer
    from mimesis.providers.internet import Internet
    from mimesis.types import LayerPortRange
    from mimesis.types import LayerProtocol

    counter = Counter()

    i = Internet()

    # Test for correct type
    assert isinstance(i.ip_v6(), str)

    for x in range(10):
        ip = i.ip_v6()
        assert ':' in ip
        assert len(ip) == 39

        # Test for probability of ports
        port = i.port()
        assert 0 <= port <= 65535

        counter[port] += 1

    assert counter[443] > 0
    assert counter[80] > 0

    # Test for probability of protocols

# Generated at 2022-06-23 21:24:15.924710
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    provider = Internet()
    tld = provider.top_level_domain(tld_type=TLDType.GENERIC_TLD)
    assert tld in TLD[TLDType.GENERIC_TLD], \
        'Should return Top level domain from generic list'

    tld = provider.top_level_domain(tld_type=TLDType.COUNTRY_CODE_TLD)
    assert tld in TLD[TLDType.COUNTRY_CODE_TLD], \
        'Should return Top level domain from country code list'

    tld = provider.top_level_domain(tld_type=TLDType.GENERIC_RESTRICTED)

# Generated at 2022-06-23 21:24:26.759107
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    """Return random stock image (JPG/JPEG) hosted on Unsplash.

    See «Random search term» on https://source.unsplash.com/
    for more details.

    .. note:: This method required an active HTTP connection
        if you want to get writable object

    :param width: Width of the image.
    :param height: Height of the image.
    :param keywords: List of search keywords.
    :param writable: Return image as sequence ob bytes.
    :return: Link to the image.
    """
    # Initialize an instance of the class Internet
    internet = Internet()
    # Get a random stock image
    # Get a random stock image (JPG/JPEG) hosted on Unsplash
    # Parameters: width, height, keywords, writable
    internet.stock_image()
    # Call the method stock

# Generated at 2022-06-23 21:24:28.618093
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    # Initialize Internet Class
    internet = Internet()
#     print("The IPv4 Address is " + internet.ip_v4())
    


# Generated at 2022-06-23 21:24:31.009563
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    internet = Internet()
    print(internet.http_status_message())
    assert internet.http_status_message() == 'OK'

# Generated at 2022-06-23 21:24:40.298553
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from mimesis.enums import PortRange, MimeType
    internet = Internet(seed=101)
    result = internet.stock_image()
    assert isinstance(result, str) == True
    result = internet.image_placeholder(width=1920, height=1080)
    assert isinstance(result, str) == True
    result = internet.home_page()
    assert isinstance(result, str) == True
    result = internet.http_status_code()
    assert isinstance(result, int) == True
    result = internet.port(port_range=PortRange.PRIVATE)
    assert isinstance(result, int) == True
    result = internet.port(port_range=PortRange.RESERVED)
    assert isinstance(result, int) == True

# Generated at 2022-06-23 21:24:47.065294
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    """Test for method top_level_domain of class Internet."""
    assert Internet.top_level_domain(Internet(), TLDType.CCTLD)
    assert Internet.top_level_domain(Internet(), TLDType.GENERIC)
    assert Internet.top_level_domain(Internet(), TLDType.PRIVATE)
    assert Internet.top_level_domain(Internet(), TLDType.RESERVED)

# Generated at 2022-06-23 21:24:50.305219
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    test_internet = Internet()
    test_http_status_message = test_internet.http_status_message()
    assert type(test_http_status_message) == str


# Generated at 2022-06-23 21:24:52.101205
# Unit test for constructor of class Internet
def test_Internet():
    """Test constructor of class Internet."""
    pass

# Generated at 2022-06-23 21:24:54.242980
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    ip_v4 = Internet().ip_v4_object()
    assert str(ip_v4) == '19.121.223.58'


# Generated at 2022-06-23 21:24:55.884553
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    internet = Internet()
    assert len(internet.ip_v4().split('.')) == 4
    

# Generated at 2022-06-23 21:24:58.746077
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    internet = Internet()
    status_code = internet.http_status_code()
    assert status_code in HTTP_STATUS_CODES
    assert isinstance(status_code, int)


# Generated at 2022-06-23 21:25:04.820036
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    it = Internet()
    category = "hashtags"
    ht = it.hashtags()
    hts = it.hashtags(quantity=3)
    assert ht in HASHTAGS
    assert type(hts) == list
    assert len(hts) == 3
    assert ht in HASHTAGS
    assert hts[0] in HASHTAGS
    assert hts[1] in HASHTAGS
    assert hts[2] in HASHTAGS
    print("Test for method \"hashtags\" of class \"Internet\" is OK")

# Generated at 2022-06-23 21:25:08.401248
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    """Unit test for method Internet.ip_v4_object
    """
    assert type(Internet().ip_v4_object()) == ipaddress.IPv4Address

# Generated at 2022-06-23 21:25:10.772280
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    provider = Internet()
    emojis = provider.emoji()
    assert isinstance(emojis, str)


# Generated at 2022-06-23 21:25:13.021451
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    internet = Internet()
    answer = internet.content_type(MimeType.IMAGE)
    print(answer)
    assert answer is not None


# Generated at 2022-06-23 21:25:18.887014
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    from ipaddress import IPv4Address
    from mimesis.providers.internet import Internet
    from mimesis.enums import PortRange

    internet_ip_v4_object = Internet().ip_v4_object()
    assert isinstance(internet_ip_v4_object, IPv4Address)
    internet_ip_v4_with_port = Internet().ip_v4(with_port=True, port_range=PortRange.MIN)
    assert isinstance(internet_ip_v4_with_port, str)
    assert internet_ip_v4_with_port.split(":")[1]


# Generated at 2022-06-23 21:25:24.167153
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    internet_provider = Internet()
    ipv6 = internet_provider.ip_v6()
    pattern = "^(?:[A-F0-9]{1,4}:){7}[A-F0-9]{1,4}$"
    assert re.match(pattern, ipv6)


# Generated at 2022-06-23 21:25:25.867780
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    from mimesis.enums import PortRange

    print(Internet().ip_v4_object())


# Generated at 2022-06-23 21:25:27.437500
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    status = Internet.http_status_code()
    print (status)
    assert status in HTTP_STATUS_CODES

# Generated at 2022-06-23 21:25:32.601810
# Unit test for method content_type of class Internet
def test_Internet_content_type():
	from mimesis.enums import MimeType
	from mimesis import Internet
	i = Internet()
	print(i.content_type())
	print(i.content_type(MimeType.MISC))


# Generated at 2022-06-23 21:25:33.614802
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    Internet().stock_image(writable=True)

# Generated at 2022-06-23 21:25:38.485212
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    internet = Internet()
    ipv6_object = internet.ip_v6_object()
    assert isinstance(ipv6_object, IPv6Address)
    assert ipv6_object in list(IPv6Address)



# Generated at 2022-06-23 21:25:42.672433
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    from mimesis.enums import MimeType
    from mimesis.providers.internet import Internet

    internet = Internet()
    # Content-Type: text/plain
    assert(internet.content_type(MimeType.TEXT_PLAIN) == 'Content-Type: text/plain')


# Generated at 2022-06-23 21:25:53.721116
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    import re
    ipv4_re = re.compile(r'(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.\
            (25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.\
            (25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.\
            (25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)')
    ipv4_address = Internet().ip_v4()

    assert ipv4_re.match(ipv4_address) is not None


# Generated at 2022-06-23 21:25:56.743076
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    internet = Internet()

    # Simple test without arguments
    assert 'Content-Type:' in internet.content_type()

    # Test with enum MimeType as argument
    assert ('Content-Type: application/json' ==
            internet.content_type(MimeType.JSON))



# Generated at 2022-06-23 21:25:57.356218
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    pass

# Generated at 2022-06-23 21:25:58.248156
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    internet = Internet()
    internet.user_agent()

# Generated at 2022-06-23 21:26:00.138246
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    assert Internet.content_type() != None
    assert Internet.content_type().startswith('Content-Type:')


# Generated at 2022-06-23 21:26:06.198883
# Unit test for constructor of class Internet
def test_Internet():
    # Create a Internet object
    from mimesis.builtins import Internet
    internet = Internet()

    # Assert that content_type() is not None
    internet.content_type()

    # Assert that http_status_message() is not None
    internet.http_status_message()

    # Assert that http_status_code() is not None
    internet.http_status_code()

    # Assert that http_method() is not None
    internet.http_method()

    # Assert that ip_v4() is not None
    internet.ip_v4()

    # Assert that ip_v6() is not None
    internet.ip_v6()

    # Assert that mac_address() is not None
    internet.mac_address()

    # Assert that emoji() is not None
    internet.emoji

# Generated at 2022-06-23 21:26:09.081922
# Unit test for method port of class Internet
def test_Internet_port():
    port_range = PortRange.ALL
    from mimesis.enums import PortRange
    assert isinstance(port_range, PortRange)
    assert 1 <= port_range <= 65535

# Generated at 2022-06-23 21:26:11.368048
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    result = Internet().emoji()
    assert len(result) > 2
    assert result[0] == ':'
    assert result[-1] == ':'


# Generated at 2022-06-23 21:26:18.687869
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    # Initialization class
    internet = Internet()

    # Call of method stock_image()
    stock_image_url = internet.stock_image()

    # Assertion
    assert stock_image_url == 'https://source.unsplash.com/1920x1080'

    # Call of method stock_image()
    stock_image_bytes = internet.stock_image(writable=True)

    # Assertion
    assert isinstance(stock_image_bytes, bytes)

# Generated at 2022-06-23 21:26:21.731384
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    internet = Internet()
    assert internet.network_protocol() in NETWORK_PROTOCOLS.values()

if __name__ == '__main__':
    test_Internet_network_protocol()

# Generated at 2022-06-23 21:26:23.172642
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    obj = Internet()

    status = obj.http_status_message()
    assert isinstance(status, str)

# Generated at 2022-06-23 21:26:24.758182
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    internet = Internet()
    home_page = internet.home_page()
    assert(home_page)

# Generated at 2022-06-23 21:26:25.952799
# Unit test for constructor of class Internet
def test_Internet():
    internet = Internet()
    assert internet != None

# Generated at 2022-06-23 21:26:29.306555
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    internet = Internet('en')
    ipv4 = internet.ip_v4()
    assert ipv4 != ''
    assert ipv4 != ' '


# Generated at 2022-06-23 21:26:33.752425
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    http_methods = ["GET", "POST", "PUT", "DELETE", "OPTIONS", "CONNECT", "TRACE"]
    for _ in range(10):
        print(Internet().http_method())
    assert Internet().http_method() in http_methods


# Generated at 2022-06-23 21:26:39.174102
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    # My test string
    # 2001:c244:cf9d:1fb1:c56d:f52c:8a04:94f3
    i = Internet(seed=4321)
    s = i.ip_v6()
    assert s == "2001:c244:cf9d:1fb1:c56d:f52c:8a04:94f3"
    print(s)



# Generated at 2022-06-23 21:26:40.245117
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
        tmp = Internet()
        tmp.stock_image(writable=True)

# Generated at 2022-06-23 21:26:42.862925
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    """Test function for method home_page of class Internet."""
    internet = Internet()
    assert 'http://' in internet.home_page()

# Generated at 2022-06-23 21:26:46.809089
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    # Given
    internet = Internet()

    # When
    result = internet.http_status_message()

    # Then
    assert isinstance(result, str)
    assert result in HTTP_STATUS_MSGS



# Generated at 2022-06-23 21:26:51.371604
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()

    # Only one tag
    assert '#' in internet.hashtags()

    # Multiple tags
    tags = internet.hashtags(3)
    if not isinstance(tags, str):
        assert len(tags) == 3

# Generated at 2022-06-23 21:26:54.906233
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    assert internet.hashtags(quantity=3) == ['#love', '#sky', '#nice']

    # If quantity equal to 1, return string
    assert type(internet.hashtags(quantity=1)) is not list

# Generated at 2022-06-23 21:26:56.684713
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    internet = Internet()
    assert internet.http_method() in HTTP_METHODS


# Generated at 2022-06-23 21:26:58.197232
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    internet = Internet()
    status = internet.http_status_message()
    print(status)

# Generated at 2022-06-23 21:27:06.139546
# Unit test for method port of class Internet
def test_Internet_port():
    from hypothesis import given, strategies as st
    from enum import Enum
    port_range = st.sampled_from([x for x in PortRange])
    @given(port_range)
    def test_port(port_range):
        print("Portrange value is " + str(port_range))
        internet = Internet()
        port = internet.port(port_range = port_range)
        print("Port number is :" + str(port))
        assert port>=port_range.value[0] and port<=port_range.value[1]
    test_port()


# Generated at 2022-06-23 21:27:10.015461
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    from mimesis.providers.internet import Internet
    import ipaddress
    i = Internet()
    ip = i.ip_v6_object()
    assert isinstance(ip, ipaddress.IPv6Address)



# Generated at 2022-06-23 21:27:11.571214
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    internet = Internet(
        seed=0,
    )
    print(f'ip = {internet.ip_v4()}')



# Generated at 2022-06-23 21:27:14.319457
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    internet = Internet(seed=3)
    result = internet.ip_v4_object()
    assert result == IPv4Address('5.26.111.18')


# Generated at 2022-06-23 21:27:18.057201
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    import pytest
    from mimesis.enums import PortRange 
    from mimesis.providers.internet import Internet
    i = Internet()
    res = i.ip_v6_object()
    assert isinstance(res, IPv6Address)

# Generated at 2022-06-23 21:27:20.768786
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    obj = Internet()
    assert isinstance(obj.ip_v4_object(), IPv4Address)


# Generated at 2022-06-23 21:27:26.324024
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    temp_class = Internet()
    assert temp_class.top_level_domain(tld_type=TLDType.CC)
    assert temp_class.top_level_domain(tld_type=TLDType.COUNTRY)
    assert temp_class.top_level_domain(tld_type=TLDType.GENERIC)
    assert temp_class.top_level_domain(tld_type=TLDType.INFRASTRUCTURE)
    assert temp_class.top_level_domain(tld_type=TLDType.GOV)
    assert temp_class.top_level_domain(tld_type=TLDType.INTL)
    assert temp_class.top_level_domain(tld_type=TLDType.MIL)
    assert temp_class.top_level_domain

# Generated at 2022-06-23 21:27:28.052833
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    for _ in range(5):
        print(Internet().user_agent())



# Generated at 2022-06-23 21:27:29.022774
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    assert 200 == Internet().http_status_code()

# Generated at 2022-06-23 21:27:32.424505
# Unit test for method port of class Internet
def test_Internet_port():
    from mimesis.enums import PortRange
    from mimesis.providers.internet import Internet

    port = Internet().port(port_range=PortRange.PRIVILEGED)
    assert 1 <= port <= 1024
    assert isinstance(port, int)



# Generated at 2022-06-23 21:27:40.619578
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from mimesis import Internet
    import io
    import base64

    internet = Internet('ru')
    data = internet.stock_image(writable=True)

    # Generate dictionary with image, base64 format
    image = {
        "id": 1,
        "image": str(base64.b64encode(data))[1:]
    }

    # Use context manager to create and close file automatically
    with open("dataImage.json", "w") as write_file:
        json.dump(image, write_file)



# Generated at 2022-06-23 21:27:47.801827
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    """Test method user_agent of class Internet."""
    internet = Internet(seed=99999)
    uas = [internet.user_agent() for _ in range(5)]

    assert uas[0] == "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:47.0) Gecko/20100101 Firefox/47.0"
    assert uas[1] == "Mozilla/5.0 (Macintosh; Intel Mac OS X x.y; rv:42.0) Gecko/20100101 Firefox/42.0"
    assert uas[2] == "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36"
    assert uas

# Generated at 2022-06-23 21:27:50.631933
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    assert Internet.http_status_message()
    assert Internet.http_status_message()
    assert Internet.http_status_message()

# Generated at 2022-06-23 21:27:53.652826
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    obj = Internet()
    for layer in [Layer.APPLICATION, Layer.SESSION, Layer.PRESENTATION]:
        assert obj.network_protocol(layer=layer) in NETWORK_PROTOCOLS[layer]

# Generated at 2022-06-23 21:27:55.253553
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    assert Internet().image_placeholder(640, 480) == \
        'http://placehold.it/640x480'

# Generated at 2022-06-23 21:27:56.340922
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    internet = Internet()
    print(internet.http_status_code())


# Generated at 2022-06-23 21:28:01.019608
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    from mimesis.enums import PortRange
    from mimesis.providers.internet import Internet
    for i in range(10):
        ip = Internet('en').ip_v4()
        assert isinstance(ip, str)
        assert len(ip.split('.')) == 4
        assert Internet('en').ip_v4(with_port=True, port_range=PortRange.ALL)



# Generated at 2022-06-23 21:28:05.033218
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    try:
        i = Internet()
        IPv6Address(i.ip_v6_object())
        return True
    except:
        return False


# Generated at 2022-06-23 21:28:06.213827
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    internet = Internet()
    print(internet.top_level_domain(tld_type="gov"))


# Generated at 2022-06-23 21:28:07.993127
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    import random
    internet_provider = Internet()
    http_method = internet_provider.http_method()
    assert http_method in HTTP_METHODS



# Generated at 2022-06-23 21:28:09.686508
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    for _ in range(100):
        obj = Internet()
        obj.emoji()


# Generated at 2022-06-23 21:28:18.571092
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    """ Test method Internet.hashtags. """
    import pytest
    from mimesis.enums import Hashtag

    data_provider = Internet()

    quantity = ['1', '2', '3', 'hello', 4, None]

    for q in quantity:
        # Test 1: Try to get 1 tag
        if isinstance(q, str) or q is None:
            with pytest.raises(NonEnumerableError):
                data_provider.hashtags(quantity=q)
        else:
            hashtags = data_provider.hashtags(quantity=q)

            assert isinstance(hashtags, list)
            assert len(hashtags) == int(q)

            for hashtag in hashtags:
                assert hashtag.startswith('#')
                assert hashtag[1:] in Hashtag.values()

# Generated at 2022-06-23 21:28:19.656802
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    print(internet.hashtags(quantity=3))


# Generated at 2022-06-23 21:28:23.829498
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    '''
    Test the Internet class method ip_v4_object.

    Expected:
    IPv4Address object

    '''
    internet = Internet(seed=0)

    # Test the results
    assert isinstance(internet.ip_v4_object(), IPv4Address)

# Generated at 2022-06-23 21:28:32.681805
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():

    internet = Internet()

    assert internet.network_protocol(layer=None) != internet.network_protocol(layer=Layer.APPLICATION)
    assert internet.network_protocol(layer=Layer.APPLICATION) != internet.network_protocol(layer=Layer.TRANSPORT)
    assert internet.network_protocol(layer=Layer.TRANSPORT) != internet.network_protocol(layer=Layer.NETWORK)
    assert internet.network_protocol(layer=Layer.NETWORK) != internet.network_protocol(layer=Layer.DATALINK)
    assert internet.network_protocol(layer=Layer.DATALINK) != internet.network_protocol(layer=Layer.PHYSICAL)

    network_protocol_application = internet.network_protocol(layer=Layer.APPLICATION)
   

# Generated at 2022-06-23 21:28:34.165280
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    instance = Internet()
    result = instance.content_type()
    assert isinstance(result, str)


# Generated at 2022-06-23 21:28:37.499739
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    from pprint import pprint
    internet = Internet()

    user_agent = internet.user_agent()
    print(user_agent)

    # User Agent Dictionary
    pprint(internet.json_dict['user']['aget'])


if __name__ == '__main__':
    test_Internet_user_agent()

# Generated at 2022-06-23 21:28:38.858434
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    internet = Internet()
    assert internet.user_agent() != ''


# Generated at 2022-06-23 21:28:41.509054
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    d = Internet()
    result = d.ip_v4_object()
    assert result is not None

# Generated at 2022-06-23 21:28:43.501317
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    ip = Internet()
    result = ip.ip_v4()
    assert(result is not None)

# Generated at 2022-06-23 21:28:46.075089
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    result = Internet().mac_address()
    assert isinstance(result, str)
    assert len(result) >= 17


# Generated at 2022-06-23 21:28:48.962778
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    internet = Internet()
    ip_v4_object = internet.ip_v4_object()

    assert isinstance(ip_v4_object, IPv4Address)


# Generated at 2022-06-23 21:28:50.548988
# Unit test for method http_method of class Internet
def test_Internet_http_method():
   internet = Internet("en")
   print(internet.http_method())


# Generated at 2022-06-23 21:28:54.858632
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    from collections import Counter

    # Testing probability of finding "00:16:3e" prefix in 60000 iterations.
    # This probability should be high (around 99% or more)
    counter = Counter([Internet().mac_address()[:8] for _ in range(60000)])
    assert counter["00:16:3e"] > 58000

# Generated at 2022-06-23 21:28:56.522269
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    provider = Internet()
    assert provider.network_protocol() in NETWORK_PROTOCOLS

# Generated at 2022-06-23 21:28:58.425193
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    expected = 200
    internet = Internet()
    result = internet.http_status_code()
    assert expected == result

# Generated at 2022-06-23 21:29:00.756091
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    assert Internet().top_level_domain(tld_type=TLDType.GOV) == '.gov'
    assert type(Internet().top_level_domain()) == str

# Generated at 2022-06-23 21:29:01.912811
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    assert 'http://www.google.com' == Internet().top_level_domain()

# Generated at 2022-06-23 21:29:06.832661
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    internet = Internet()
    # Define the width and height of an image
    width = 1920
    height = 1080
    # Generate a link to a placeholder
    placeholder = internet.image_placeholder(width=width, height=height)
    # Asserting an error
    assert placeholder is not None


# Generated at 2022-06-23 21:29:11.501383
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    # Arrange
    internet = Internet()
    
    # Act
    ip = internet.ip_v6()
    ipv6 = IPv6Address(ip)

    # Assert
    assert isinstance(ip, str)
    assert isinstance(ipv6, IPv6Address)


# Generated at 2022-06-23 21:29:16.409136
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    """Unit test for method ip_v6 of class Internet"""
    # prepare
    ip_length = 4 * 8
    internet = Internet()

    # test
    ip = internet.ip_v6()

    # assert
    assert len(ip) == ip_length

# Generated at 2022-06-23 21:29:18.253023
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    internet = Internet()
    response = internet.http_status_code()
    print(response)


# Generated at 2022-06-23 21:29:22.362140
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    internet = Internet()
    width = internet.random.randint(1, 1920)
    height = internet.random.randint(1, 1080)
    url = internet.image_placeholder(width, height)
    assert 'http://placehold.it/' in url
    assert 'x'.join([str(width), str(height)]) in url


# Generated at 2022-06-23 21:29:24.868795
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    inter = Internet()
    result = inter.user_agent()
    assert result != None
    assert len(result) > 0


# Generated at 2022-06-23 21:29:34.555004
# Unit test for method port of class Internet

# Generated at 2022-06-23 21:29:36.625023
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    assert (Internet().image_placeholder(100, 100) == 'http://placehold.it/100x100')

# Generated at 2022-06-23 21:29:41.019178
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    """Unit test for method ip_v6_object of class Internet."""
    internet = Internet(seed=12345)
    ip = internet.ip_v6_object()
    assert str(ip) == '2001:c244:cf9d:1fb1:c56d:f52c:8a04:94f3'

# Generated at 2022-06-23 21:29:42.674016
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    internet = Internet()
    assert internet.ip_v6() == '2a02:1811:5c5:8640:a5d5:5b74:5b13:8b5f'
