

# Generated at 2022-06-23 21:19:45.718215
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    internet = Internet()
    image_placeholder = internet.image_placeholder()

    assert isinstance(image_placeholder, str)
    assert image_placeholder.startswith('http://placehold.it/')


# Generated at 2022-06-23 21:19:49.884677
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    """Unit test for method home_page of class Internet."""
    home_page = Internet().home_page()
    assert isinstance(home_page, str)
    assert home_page.startswith('https://')


# Generated at 2022-06-23 21:19:53.198867
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    Internet_test = Internet()
    emoji_test = Internet_test.emoji()
    assert any(char in emoji_test for char in ['0', '1', 'a', 'b']) == False

# Generated at 2022-06-23 21:19:55.407706
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    status_code = Internet().http_status_code()
    assert isinstance(status_code, int)
    assert status_code > 0


# Generated at 2022-06-23 21:19:56.437582
# Unit test for constructor of class Internet
def test_Internet():
    it = Internet()
    assert it



# Generated at 2022-06-23 21:19:56.943515
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    pass

# Generated at 2022-06-23 21:19:58.513766
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    result = Internet().top_level_domain()
    assert len(result) > 1
    assert "." in result

# Generated at 2022-06-23 21:20:01.509076
# Unit test for method port of class Internet
def test_Internet_port():
    net=Internet()
    ports=[net.port() for x in range(10)]
    assert all([port > 0 and port < 65536 for port in ports])


# Generated at 2022-06-23 21:20:02.910791
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    assert Internet().http_method() in ['GET', 'POST', 'PUT']


# Generated at 2022-06-23 21:20:04.858131
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    prv = Internet()
    assert prv.home_page() == prv.home_page(None)


# Generated at 2022-06-23 21:20:07.102782
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet() #initialize class
    internet.hashtags() #return hashtags


# Generated at 2022-06-23 21:20:13.448250
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    """
    Test method ip_v4_object
    """
    # Case 1:
    internet = Internet()
    ip = internet.ip_v4_object()
    assert isinstance(ip, IPv4Address)
    # Case 2:
    internet = Internet()
    ip = internet.ip_v4_object()
    assert isinstance(ip, IPv4Address)

# Generated at 2022-06-23 21:20:20.035950
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
  from mimesis.exceptions import NonEnumerableError
  from mimesis.enums import HTTPStatus
  from mimesis.providers.internet import Internet
  from mimesis.providers.base import BaseProvider
  from mimesis.enums import DataField
  from mimesis.enums import Gender
  from mimesis.exceptions import NonExistentLocaleConfig
  from mimesis.exceptions import NonExistentLocale
  from mimesis.exceptions import NonEnumerableError
  from mimesis.enums import Layer
  from mimesis.enums import TLDType
  from mimesis.providers.file import File
  from enum import Enum
  from mimesis.enums import PortRange
  from mimesis.providers.internet import Internet
  from typing import Union

# Generated at 2022-06-23 21:20:26.931788
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    """Generate IPv4 address."""
    from pprint import pprint

    internet = Internet('en')
    ip = internet.ip_v4()
    print(ip)
    assert isinstance(ip, str)
    print()

    pprint(internet.ip_v4_object().compressed)
    print()

    pprint(internet.ip_v4_object().exploded)
    print()



# Generated at 2022-06-23 21:20:28.959369
# Unit test for constructor of class Internet
def test_Internet():
    internet = Internet()
    result = internet.top_level_domain()
    assert result in TLD[TLDType.ALL]

# Generated at 2022-06-23 21:20:32.335593
# Unit test for constructor of class Internet
def test_Internet():
    internet = Internet()
    assert internet.__file
    assert internet._MAX_IPV6
    assert internet._MAX_IPV4


# Generated at 2022-06-23 21:20:33.455296
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    print(Internet().ip_v6_object())

# Generated at 2022-06-23 21:20:44.524135
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    from mimesis.enums import TLDType
    from mimesis.providers.internet import Internet
    from mimesis.providers.internet import TLD
    for tld_type in TLDType:
        assert set(TLD[tld_type]).isdisjoint(set(TLD[TLDType.DEFAULT]))
    assert Internet().home_page() != Internet().home_page()
    assert Internet().home_page(tld_type=TLDType.DEFAULT).split('.')[-1] \
        in TLD[TLDType.DEFAULT]
    assert Internet().home_page(tld_type=TLDType.DEFAULT) \
        not in Internet().home_page(tld_type=TLDType.GENERIC)

# Generated at 2022-06-23 21:20:48.212184
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet_object = Internet()
    print(internet_object.hashtags())
    print(internet_object.hashtags(quantity=2))
    print(internet_object.hashtags(quantity=8))
    print(internet_object.hashtags(quantity=1))


# Generated at 2022-06-23 21:20:53.655859
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    print("\n**************** Unit test for method hashtags of class Internet")
    assert Internet().hashtags(1) == "#fall"
    assert len(Internet().hashtags(3)) is 3
    assert Internet().hashtags() == [
        "#night", "#nice", "#girl", "#love", "#autumn", "#boy", "#hot",
        "#clouds", "#beach", "#day", "#dog", "#sky", "#sunset", "#mountains", "#food",
        "#party", "#spring", "#summer", "#love", "#winter"
    ]

# Generated at 2022-06-23 21:20:57.014102
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    ip = Internet()
    ipv6 = ip.ip_v6()
    assert isinstance(ipv6, str)
    assert len(ipv6) < 40
    assert ipv6.startswith('2001:')

# Generated at 2022-06-23 21:21:01.593791
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    provider = Internet(seed=1)
    assert provider.network_protocol() == "AMQP"
    assert provider.network_protocol(layer=Layer.APPLICATION) == "HTTP"


# Generated at 2022-06-23 21:21:05.231559
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    seed = 2182253338
    ipv6_address = '2001:7fa:2:1:580:e8f:e07a:a083'
    internet = Internet(seed=seed)
    assert str(internet.ip_v6_object()) == ipv6_address


# Generated at 2022-06-23 21:21:08.882185
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    obj = Internet()
    data = obj.content_type()
    assert len(data) > 1


# Generated at 2022-06-23 21:21:10.983831
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    """Unit test for method emoji of class Internet"""
    internet = Internet()
    assert internet.emoji() in EMOJI


# Generated at 2022-06-23 21:21:13.642598
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    internet = Internet()
    ip = internet.ip_v6()
    #print(ip)
    assert isinstance(ip, str)



# Generated at 2022-06-23 21:21:19.427007
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.enums import Language
    internet = Internet()

    message = internet.http_status_message()
    spec = RussiaSpecProvider(Language.RU)
    http_status_code = internet.http_status_code()
    http_status_message = spec.get_http_status_message(http_status_code)
    assert message == http_status_message

# Generated at 2022-06-23 21:21:22.135246
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    ip = IPv4Address(Internet().ip_v4_object())
    assert ip.compressed == Internet().ip_v4()

# Generated at 2022-06-23 21:21:23.983770
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    i = Internet()
    assert type(i.ip_v6_object()) == IPv6Address

# Generated at 2022-06-23 21:21:27.239356
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    from mimesis.enums import MACAddressType

    test = Internet()

    assert MACAddressType.STANDART in test.mac_address()


# Generated at 2022-06-23 21:21:37.818924
# Unit test for method http_status_message of class Internet

# Generated at 2022-06-23 21:21:40.464889
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    __internet = Internet()
    __emoji_code = __internet.emoji()
    assert len(__emoji_code) > 0



# Generated at 2022-06-23 21:21:43.745486
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    image_link = internet.stock_image(width=640, height=480)
    print(image_link)


# Generated at 2022-06-23 21:21:45.602098
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    internet = Internet()
    data = internet.mac_address()
    assert isinstance(data, str)
    assert (len(data.split(':'))) == 6


# Generated at 2022-06-23 21:21:48.090994
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    assert Internet.network_protocol() in ['TCP', 'UDP']


# Generated at 2022-06-23 21:21:53.619307
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    """Test method hashtags of class Internet."""
    internet = Internet()
    result = internet.hashtags()
    assert len(result) == 4
    result_one = internet.hashtags(1)
    assert result_one.startswith('#')
    result_two = internet.hashtags(2)
    assert len(result_two) == 2

# Generated at 2022-06-23 21:22:02.915717
# Unit test for method port of class Internet
def test_Internet_port():
    internet = Internet()
    assert internet.port() >= 0, "Port not in range"
    assert internet.port() <= 65535, "Port not in range"
    assert internet.port(port_range=PortRange.SYSTEM) >= 0, "Port not in range"
    assert internet.port(port_range=PortRange.SYSTEM) <= 1023, "Port not in range"
    assert internet.port(port_range=PortRange.REGISTERED) >= 1024, "Port not in range"
    assert internet.port(port_range=PortRange.REGISTERED) <= 49151, "Port not in range"
    assert internet.port(port_range=PortRange.DYNAMIC) >= 49152, "Port not in range"

# Generated at 2022-06-23 21:22:05.808192
# Unit test for method home_page of class Internet
def test_Internet_home_page():

    # test case 1
    # expectation: ¿?
    # print(Internet().home_page())
    pass


# Generated at 2022-06-23 21:22:07.291768
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    assert Internet().top_level_domain() in TLD['ALL']

# Generated at 2022-06-23 21:22:18.744406
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    layer = Layer.APPLICATION

# Generated at 2022-06-23 21:22:21.123982
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    print("\nUnit test for method 'hashtags' of class Internet:")
    internet = Internet()
    print(internet.hashtags(quantity=1))
    print(internet.hashtags(quantity=10))


# Generated at 2022-06-23 21:22:27.671234
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    provider = Internet(seed=12345)
    assert provider.emoji() == ':kissing:'
    provider = Internet(seed=12345)
    assert provider.emoji() == ':kissing:'
    provider = Internet(seed=54321)
    assert provider.emoji() == ':-1:'
    provider = Internet(seed=54321)
    assert provider.emoji() == ':-1:'

# Generated at 2022-06-23 21:22:39.496793
# Unit test for method port of class Internet
def test_Internet_port():
    """Testing method port of class Internet."""
    from mimesis.enums import PortRange
    from test_enums import TestEnums
    ports = [PortRange.IP_SERVICE_DISCOVERY.value,
            PortRange.WELL_KNOWN_SERVICES.value,
            PortRange.REGISTERED_PORTS.value,
            PortRange.DYNAMIC_AND_PRIVATE_PORTS.value,
            PortRange.GLOBAL_DYNAMIC_AND_PRIVATE_PORTS.value,
            PortRange.ALL.value]
    for k, v in enumerate(ports):
        t = Internet()
        m = TestEnums()
        p = t.port(m.range(k))
        assert p >= v[0] and p <= v[1]

# Generated at 2022-06-23 21:22:40.247124
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    internet = Internet()
    assert isinstance(internet.home_page(), str)

# Generated at 2022-06-23 21:22:42.558765
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    import random
    seed = random.randint(0, 100000)
    a = 0
    b = (2 ** 128) - 1
    ip_v6_object = IPv6Address(seed)
    assert ip_v6_object >= a and ip_v6_object <= b

# Generated at 2022-06-23 21:22:55.230620
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    internet = Internet()
    assert internet.network_protocol(layer=Layer.TP) != None
    assert internet.network_protocol(layer=Layer.TP) in ['AMQP', 'MQTT', 'SMTP', 'POP3', 'IMAP', 'NNTP', 'SSH', 'NTP',
                                                          'SNMP', 'IMAPS', 'SMTPS', 'POP3S', 'SSH', 'SFTP', 'DHCP',
                                                          'TFTP', 'FTP']

    assert internet.network_protocol(layer=Layer.IP) != None
    assert internet.network_protocol(layer=Layer.IP) in ['IPv4', 'IPv6']

    assert internet.network_protocol(layer=Layer.APP) != None

# Generated at 2022-06-23 21:22:59.289154
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    ip_v4 = Internet()
    test_ip = ip_v4.ip_v4()
    ip = test_ip.split('.')
    assert len(ip) == 4
    for x in ip:
        assert int(x) >= 0 and int(x) <= 255


# Generated at 2022-06-23 21:23:02.187464
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    for quantity in range(4):
        hashtags = internet.hashtags(quantity)
        assert len(hashtags) == quantity

# Generated at 2022-06-23 21:23:12.190136
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    from mimesis.data import HTTP_STATUS_MSGS
    from mimesis.providers.internet import Internet
    from mimesis.enums import Field

    seed = '3dd1d585-c321-4f4b-a0cf-4d8d4b4b9658'
    internet = Internet()
    pattern = r'^\d{3} .*$'
    result = internet.http_status_message()
    assert bool(re.match(pattern, result)) == True
    assert result in HTTP_STATUS_MSGS
    internet = Internet(localization=Field.RU)
    result = internet.http_status_message()
    assert bool(re.match(pattern, result)) == True
    assert result in HTTP_STATUS_MSGS
    internet = Internet(seed=seed)
   

# Generated at 2022-06-23 21:23:14.623941
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    internet = Internet(random=True)
    assert internet.content_type() is not None



# Generated at 2022-06-23 21:23:17.265166
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    """Method that test behavior of method hashtags of class Internet."""
    internet = Internet()
    tags = internet.hashtags()
    assert len(tags) == 4
    assert '#' in tags[0]

# Generated at 2022-06-23 21:23:20.284448
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    from mimesis.enums import TLDType
    from mimesis.providers.internet import Internet

    internet = Internet('en')
    print(internet.top_level_domain(TLDType.GOV))

# Generated at 2022-06-23 21:23:22.935662
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    http_method = Internet.http_method()
    print('http_method = ' + http_method)
    assert http_method in Internet.Meta.providers, 'Error: Internet.http_method()'


# Generated at 2022-06-23 21:23:25.261109
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    internet = Internet()
    result1 = internet.ip_v4_object()
    result2 = internet.ip_v4_object()
    assert result1 is not result2


# Generated at 2022-06-23 21:23:29.526987
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    print("--Start Unit Test : ip_v6_object() of Internet--")
    internet = Internet()
    ip_v6 = internet.ip_v6_object()
    print(ip_v6)


# Generated at 2022-06-23 21:23:31.628877
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    internet = Internet()
    result = internet.http_status_code()
    assert result in HTTP_STATUS_CODES

# Generated at 2022-06-23 21:23:34.063909
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    test_obj = Internet()
    output = test_obj.http_status_message()
    assert output in HTTP_STATUS_MSGS

# Generated at 2022-06-23 21:23:36.059661
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    # Check for the generated value is not empty
    assert Internet().hashtags(quantity=1) != ''


# Generated at 2022-06-23 21:23:37.985934
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    internet = Internet('en')
    for i in range(1000):
        s = internet.image_placeholder()
        assert len(s) > 10


# Generated at 2022-06-23 21:23:40.426013
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    # GIVEN
    internet = Internet()
    # WHEN
    mac = internet.mac_address()
    # THEN
    assert mac is not None


# Generated at 2022-06-23 21:23:47.623981
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from mimesis.types import DataPath

    path = DataPath('/data/imgs')
    internet = Internet()
    url = internet.stock_image(width=250, height=250)
    image = internet.stock_image(width=250, height=250, writable=True)

    assert url.endswith('250x250')
    assert len(image) > 0
    assert path.exists('img') is False

    path.create()

    assert path.exists('img') is True

    with path.get_open_resource('img', 'wb') as f:
        f.write(image)

    assert path.exists('img') is True

    path.delete()

# Generated at 2022-06-23 21:23:50.471628
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    ti = Internet(random_state=None)
    a = ti.http_status_code()
    assert a in HTTP_STATUS_CODES

# Generated at 2022-06-23 21:23:53.254600
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    count = 0
    for i in range(1, 100):
        count += 1 if Internet().http_method() in HTTP_METHODS else 0
    assert count == 99


# Generated at 2022-06-23 21:23:59.491947
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    provider = Internet()
    assert provider.stock_image(writable=False) == 'https://source.unsplash.com/1920x1080' \
                                         '?{}'.format('')
    assert provider.stock_image(keywords=['flower', 'nice'], writable=False) == 'https://source.unsplash.com/1920x1080' \
                                                                               '?flower,nice'

# Generated at 2022-06-23 21:24:01.158765
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    ip = Internet()
    result = ip.ip_v4_object()
    print(result)


# Generated at 2022-06-23 21:24:03.695519
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    internet = Internet()
    result = internet.content_type()
    assert type(result) is str
    assert len(result) > 1
    assert result.startswith("Content-Type")


# Generated at 2022-06-23 21:24:06.268018
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    from mimesis.enums import MimeType

    inet = Internet()
    for _ in range(10):
        assert inet.content_type(MimeType.TEXT) == 'Content-Type: text/plain'


# Generated at 2022-06-23 21:24:16.045209
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    from mimesis.enums import TLDType
    internet = Internet(seed=8)
    assert internet.hashtags() == '#love'
    assert internet.hashtags(quantity=2) == ['#love', '#sky']
    assert internet.hashtags(quantity=3) == ['#love', '#sky', '#nice']
    assert internet.hashtags(quantity=4) == ['#love', '#sky', '#nice', '#landscape']
    assert internet.top_level_domain() == '.hn'
    assert internet.top_level_domain(tld_type=TLDType.COUNTRY_CODE_TLD) == '.hn'
    assert internet.top_level_domain(tld_type=TLDType.GENERIC_TLD) == '.biz'

# Generated at 2022-06-23 21:24:18.695030
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    import ipaddress
    internet = Internet()
    res = internet.ip_v4_object()
    assert(isinstance(res, ipaddress.IPv4Address))


# Generated at 2022-06-23 21:24:21.534466
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    i = Internet()
    hash_tags = i.hashtags(quantity=1)
    assert isinstance(hash_tags, str)

# Generated at 2022-06-23 21:24:25.521274
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    internet = Internet()
    mac_address = internet.mac_address()
    assert mac_address == "00:16:3e:25:e7:b1" or mac_address == "00:16:3e:25:e7:b1"


# Generated at 2022-06-23 21:24:26.655297
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    assert Internet().http_method() in HTTP_METHODS


# Generated at 2022-06-23 21:24:27.861106
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    print(internet.stock_image())


# Generated at 2022-06-23 21:24:37.785278
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    @classmethod
    def test_function(cls):
        ip = cls._internet.ip_v6_object()
        assert isinstance(ip, IPv6Address)

    return test_function

if __name__ == "__main__":
    import os
    import sys
    import unittest

    sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

    from base import BaseTest

    class InternetTestCase(BaseTest):

        def setUp(self):
            super().setUp()
            self._internet = Internet(seed=self.SEED)


# Generated at 2022-06-23 21:24:44.820790
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    from mimesis.enums import Constants
    from mimesis.enums import Platform
    import ast
    import re
    pattern = re.compile('(.+)/(.+) (.+) (.+) (.+) (.+) (.+)')
    internet = Internet(Constants.DEFAULT_LOCALE)
    assert ast.literal_eval(internet.user_agent(Platform.ANDROID)) == pattern.match(internet.user_agent(Platform.ANDROID)).groups()
    assert ast.literal_eval(internet.user_agent(Platform.CHROME)) == pattern.match(internet.user_agent(Platform.CHROME)).groups()
    assert ast.literal_eval(internet.user_agent(Platform.EDGE)) == pattern.match(internet.user_agent(Platform.EDGE)).groups()
    assert ast.literal_

# Generated at 2022-06-23 21:24:48.890183
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    """Test for method network_protocol of class Internet"""
    internet = Internet()
    for i in Layer:
        result = internet.network_protocol(layer=i)
        assert result in NETWORK_PROTOCOLS[i]

# Generated at 2022-06-23 21:24:51.771050
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    internet = Internet()

    data = [internet.home_page() for item in range(10)]
    assert 'https://' in data[0]
    assert data[0].endswith('.info')

# Generated at 2022-06-23 21:24:53.785649
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    a = Internet()
    b = a.ip_v4_object()
    print(b)


# Generated at 2022-06-23 21:24:55.950068
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    test_image_placeholder = Internet.image_placeholder()
    print(test_image_placeholder)
    assert test_image_placeholder == 'http://placehold.it/1920x1080'

# Generated at 2022-06-23 21:24:57.148368
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    """Unit test for method hashtags of class Internet."""
    pass

# Generated at 2022-06-23 21:24:59.010387
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    image = internet.stock_image()
    print(image)

# Generated at 2022-06-23 21:25:00.643241
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    internet = Internet()
    assert isinstance(internet.http_status_message(), str)


# Generated at 2022-06-23 21:25:03.163664
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    """Test method ip_v6 of class Internet"""
    internet = Internet()
    ipv6 = internet.ip_v6()
    assert IPv6Address(ipv6)


# Generated at 2022-06-23 21:25:04.687574
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    internet = Internet()
    assert type(internet.mac_address()) == str
# Test set the seed of class Internet

# Generated at 2022-06-23 21:25:08.677047
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    internet = Internet()
    a1 = internet.mac_address()
    a2 = internet.mac_address()
    assert a1 == '00:16:3e:a5:58:2c'
    assert a2 == '00:16:3e:a5:58:2c'


# Generated at 2022-06-23 21:25:13.990938
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    from mimesis import Internet
    from mimesis.enums import TLDType

    # Test for default Top level domain
    home_page = Internet().home_page()
    print(home_page)

    # Test for Top level domain = TLDType.GOV
    home_page = Internet().home_page(tld_type=TLDType.GOV)
    print(home_page)

    # Test for Top level domain = TLDType.COOP
    home_page = Internet().home_page(tld_type=TLDType.COOP)
    print(home_page)

    # Test for Top level domain = TLDType.EDU
    home_page = Internet().home_page(tld_type=TLDType.EDU)
    print(home_page)

    # Test for Top level domain =

# Generated at 2022-06-23 21:25:15.702917
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    assert Internet().content_type() == 'Content-Type: image/png'


# Generated at 2022-06-23 21:25:22.006792
# Unit test for constructor of class Internet
def test_Internet():
    from mimesis.enums import PortRange
    provider = Internet()
    assert provider.port(port_range=PortRange.HTTP) in range(0, 1024)
    assert provider.port(port_range=PortRange.HTTPS) in range(443, 5000)
    assert provider.port(port_range=PortRange.ALL) in range(0, 65535)


# Generated at 2022-06-23 21:25:23.171189
# Unit test for constructor of class Internet
def test_Internet():
    """Test class Internet"""
    pass

# Generated at 2022-06-23 21:25:26.041388
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    """Test method Internet.top_level_domain on class Internet."""
    internet = Internet()
    tld = internet.top_level_domain()
    assert tld in TLD[TLDType.GENERAL]

# Generated at 2022-06-23 21:25:28.129033
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    random.seed(0) # Fix random seed value
    internet = Internet()
    # Test that http_status_code return an integer value in range from 100 to 600
    assert internet.http_status_code() in range(100, 600)


# Generated at 2022-06-23 21:25:37.192367
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    import random, string
    random_internet = Internet(random)
    random_elements = list(random_internet.top_level_domain() for i in range(100))
    random_elements = list(filter(None, random_elements))
    assert len(random_elements) > 0
    assert all(isinstance(item, str) for item in random_elements)
    assert all(item in string.ascii_uppercase for item in random_elements)


# Generated at 2022-06-23 21:25:38.797052
# Unit test for constructor of class Internet
def test_Internet():
    internet = Internet()
    assert internet is not None


# Generated at 2022-06-23 21:25:46.744736
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():                                               # noqa: E501
    from mimesis.enums import PortRange                                          # noqa: E501
                                                                                 # noqa: E501
    data = Internet('en')                                                        # noqa: E501
                                                                                 # noqa: E501
    print(data.port(PortRange.ALL))                                              # noqa: E501
    print(data.ip_v4_object())                                                   # noqa: E501
    print(data.ip_v4(with_port=False))                                           # noqa: E501
    print(data.ip_v4(with_port=True))                                            # noqa: E501
                                                                                 # noqa: E501
    print(data.ip_v6_object())                                                   # noqa: E

# Generated at 2022-06-23 21:25:48.722174
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    placeHolder = Internet.image_placeholder()
    print(placeHolder)


# Generated at 2022-06-23 21:25:50.868967
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    provider = Internet()
    response = provider.stock_image()
    assert response
    assert not isinstance(response, str)

# Generated at 2022-06-23 21:25:55.153221
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    internet = Internet(seed=123)
    assert internet.user_agent() == 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:15.0) Gecko/20100101 Firefox/15.0.1'


# Generated at 2022-06-23 21:25:57.825117
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    provider = Internet(seed=555555)
    ip = provider.ip_v6_object()
    assert ip == IPv6Address('1111:3333:5555:7777:9999:bbbb:dddd:ffff')

# Generated at 2022-06-23 21:25:58.867123
# Unit test for constructor of class Internet
def test_Internet():
    obj = Internet()
    print(obj.hashtags(quantity=5))


# Generated at 2022-06-23 21:26:02.378229
# Unit test for constructor of class Internet
def test_Internet():
    internet = Internet()
    assert internet.seed is None
    assert internet.random is not None
    assert isinstance(internet.random, type)


# Generated at 2022-06-23 21:26:05.156238
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    temp = 0
    for i in range(10):
        data = Internet(seed=i+1)
        assert data.hashtags() != data.hashtags()

# Generated at 2022-06-23 21:26:09.565457
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
	Internet_obj = Internet()
	result_1 = Internet_obj.http_status_message()
	result_2 = Internet_obj.http_status_message()

	assert result_1 in HTTP_STATUS_MSGS
	assert result_2 != result_1


# Generated at 2022-06-23 21:26:20.756986
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    provider = Internet()
    user_agent = provider.user_agent()
    assert user_agent == "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.100 Safari/537.36"
    provider = Internet(seed=3)
    user_agent = provider.user_agent()
    assert user_agent == "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36"
    provider = Internet(seed=5)
    user_agent = provider.user_agent()

# Generated at 2022-06-23 21:26:31.675853
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
     from mimesis.enums import Browser
     from mimesis.enums import OperatingSystem
     from mimesis.enums import Device
     from mimesis.enums import Robot
     from mimesis.enums import Engine
     from mimesis.enums import TLDType
     from mimesis.enums import Language
     from mimesis.enums import Script
     from mimesis.enums import Currency
     from mimesis.enums import Country
     from mimesis.enums import Region
     from mimesis.enums import City
     from mimesis.enums import MimeType
     from mimesis.enums import Layer
     from mimesis.enums import PortRange
     from mimesis.providers.file import FileProvider
     from mimesis.providers.address import Address
    

# Generated at 2022-06-23 21:26:36.116495
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    emoji = Internet().emoji()
    assert isinstance(emoji, str)
    assert ':' in emoji
    test_count = 100

    for i in range(test_count):
        emoji = Internet().emoji()
        assert isinstance(emoji, str)
        assert ':' in emoji

# Generated at 2022-06-23 21:26:37.458132
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    if Internet.http_method() == 'GET':
        print('Test Pass')
    else:
        print('Test Fail')


# Generated at 2022-06-23 21:26:39.810415
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    internet = Internet()
    for _ in range(10):
        assert len(internet.content_type()) >= 12


# Generated at 2022-06-23 21:26:41.072287
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    Internet().stock_image()

# Generated at 2022-06-23 21:26:42.809398
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    provider = Internet()
    assert provider.ip_v6()

# Generated at 2022-06-23 21:26:47.930752
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    from ipaddress import IPv4Address
    internet = Internet()
    ip = internet.ip_v4_object()
    if isinstance(ip, IPv4Address):
        assert True, "test_Internet_ip_v4_object: Correct"
    else:
        assert False, "test_Internet_ip_v4_object: Wrong"



# Generated at 2022-06-23 21:26:54.506800
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    import random

    seed = random.randrange(pow(2, 32))
    random.seed(seed)
    internet = Internet(seed=seed)
    assert internet.http_method() in ["GET", "HEAD", "POST", "PUT", "DELETE", "CONNECT", "OPTIONS", "TRACE", "PATCH"]
    random.seed(seed)
    internet = Internet(seed=seed)
    assert internet.http_method() == "GET"


# Generated at 2022-06-23 21:26:57.361965
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
  internet = Internet()
  test_IPv6Address = IPv6Address(internet.random.randint(0, 2**128 - 1,))
  assert isinstance(test_IPv6Address, IPv6Address)

# Generated at 2022-06-23 21:26:59.948676
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    """Unit test for method emoji of class Internet."""
    assert (Internet().emoji() != '')


# Generated at 2022-06-23 21:27:01.791436
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    internet = Internet()
    emoji = internet.emoji()
    assert emoji in EMOJI


# Generated at 2022-06-23 21:27:04.107838
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    obj = Internet(seed=123456789)
    ip = obj.ip_v4_object()
    assert ip == IPv4Address('1119059738')


# Generated at 2022-06-23 21:27:06.584471
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    """Unit test for http_status_code"""
    internet = Internet()
    result = internet.http_status_code()
    assert isinstance(result, int)
    assert result >= 100
    assert result <= 599

# Generated at 2022-06-23 21:27:13.389301
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    from mimesis.enums import PortRange
    from mimesis.providers.internet import Internet
    from mimesis.typing import PortRanges

    # Example 1
    int_ = Internet()
    status = int_.http_status_code()
    assert type(status) is int  # Example 1

    # Example 2
    int_ = Internet(seed=42)
    status = int_.http_status_code()
    assert status == 204  # Example 2


# Generated at 2022-06-23 21:27:15.193651
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    internet = Internet()
    assert internet.emoji() in EMOJI


# Generated at 2022-06-23 21:27:16.500876
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    address = Internet().ip_v6()

    assert(address is not None)
    assert(isinstance(address, str))


# Generated at 2022-06-23 21:27:19.735518
# Unit test for method port of class Internet
def test_Internet_port():
    # Arrange
    n = 10000
    mi, ma = 1, 65535

    # Act
    for _ in range(n):
        port = Internet().port()
        # Assert
        assert mi <= port <= ma


# Generated at 2022-06-23 21:27:21.460713
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    """Test get random top level domain."""
    assert Internet().top_level_domain() in TLD[TLDType.ALL]

# Generated at 2022-06-23 21:27:23.773216
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    print('Internet.http_status_code()')
    internet = Internet()
    assert internet.http_status_code() in HTTP_STATUS_CODES



# Generated at 2022-06-23 21:27:25.514043
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    internet = Internet(seed = 1)
    print(internet.mac_address())

# Generated at 2022-06-23 21:27:27.165119
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    print('Internet_http_status_message')
    for i in range(10):
        print(i+1, ': ', Internet().http_status_message())


# Generated at 2022-06-23 21:27:31.151452
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    """Test http_method() method."""
    # Setup
    internet = Internet()
    # Exercise
    result = internet.http_method()
    # Verify
    assert result is not None
    assert len(result) > 0
    assert result in HTTP_METHODS


# Generated at 2022-06-23 21:27:34.916711
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    internet = Internet()
    http_status_code = internet.http_status_code()
    assert http_status_code >= 100 and http_status_code < 600

# Generated at 2022-06-23 21:27:40.406361
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    ipv6str_list = []
    for i in range(10):
        internet = Internet()
        ipv6str_list.append(internet.ip_v6())
    for i in range(9):
        for j in range(i+1, 10):
            assert ipv6str_list[i] != ipv6str_list[j]

test_Internet_ip_v6()

# Generated at 2022-06-23 21:27:47.111921
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    internet = Internet()
    domain = internet.top_level_domain(TLDType.ALL)
    print(domain)
    domain = internet.top_level_domain(TLDType.COMMON)
    print(domain)
    domain = internet.top_level_domain(TLDType.COUNTRY_CODE)
    print(domain)
    domain = internet.top_level_domain(TLDType.GENERIC)
    print(domain)
    domain = internet.top_level_domain(TLDType.INFRASTRUCTURE)
    print(domain)
    domain = internet.top_level_domain(TLDType.SPONSORED)
    print(domain)


# Generated at 2022-06-23 21:27:54.346922
# Unit test for method port of class Internet
def test_Internet_port():
    from mimesis.enums import PortRange
    from mimesis.providers.internet import Internet
    test = Internet()
    assert test.port(port_range=PortRange.DEFAULT) in PortRange.DEFAULT.value
    assert test.port(port_range=PortRange.ALL) in PortRange.ALL.value


if __name__ == '__main__':
    test_Internet_port()

# Generated at 2022-06-23 21:27:57.135771
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    internet = Internet()
    domain = internet.top_level_domain(TLDType.ICANN)
    print('Testing internet.py Test_Internet_top_level_domain...')
    print('Extracted domain: '+domain)


# Generated at 2022-06-23 21:28:02.184485
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    """Test method hashtags of class Internet."""
    internet = Internet(seed=0)
    # Expected result is
    # ['#love', '#sky', '#nice', '#cloud']
    test_result = internet.hashtags()
    assert test_result == ['#love', '#sky', '#nice', '#cloud']
    # Expected result is '#love'
    test_result = internet.hashtags(1)
    assert test_result == '#love'

# Generated at 2022-06-23 21:28:08.515426
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    x = Internet(seed=42)
    y = x.network_protocol(layer=Layer.APPLICATION)
    assert y == 'AMQP'
    z = x.network_protocol(layer=Layer.TRANSPORT)
    assert z in ['TCP', 'UDP']

# Generated at 2022-06-23 21:28:14.897659
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    from mimesis.enums import TLDType
    from mimesis.providers.internet import Internet
    from mimesis.providers.roles import Roles
    from mimesis.providers.person import Person

    internet = Internet()
    person = Person('en')
    roles = Roles('en')
    assert internet.hashtags() == '#believe'
    assert internet.hashtags(quantity=3) == ['#positive', '#loyal', '#extra']
    assert internet.home_page() == 'https://jacobgray.com.org'
    assert internet.home_page(tld_type=TLDType.GENERIC) == 'https://kevin.biz'
    assert internet.top_level_domain() == '.info'

# Generated at 2022-06-23 21:28:16.783925
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    ip = Internet()
    res = ip.ip_v4_object()
    assert isinstance(res, IPv4Address)


# Generated at 2022-06-23 21:28:21.242044
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    gen = Internet(seed=0)
    assert gen.image_placeholder() == 'http://placehold.it/1920x1080'
    assert gen.image_placeholder(width=800) == 'http://placehold.it/800x1080'

# Generated at 2022-06-23 21:28:28.302265
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    from mimesis.enums import PortRange
    from mimesis.typing import Port

    internet = Internet()
    ipv4 = internet.ip_v4()
    ipv4_with_port: Port = internet.ip_v4(with_port=True, port_range=PortRange.UNPRIVILEGED)
    ipv6 = internet.ip_v6()

    assert '.' in ipv4
    assert ':' in ipv4_with_port
    assert '.' not in ipv6

# Generated at 2022-06-23 21:28:32.090821
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    from mimesis.enums import DataField
    from mimesis.providers.internet import Internet
    inet = Internet('en')
    e = inet.emoji()
    assert type(e) is str
    # print(e)
    assert e in DataField.EMOJI.value or e in DataField.EMOJI_UNICODE.value


# Generated at 2022-06-23 21:28:33.156891
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    internet = Internet()
    assert(type(internet.image_placeholder()) == str)

# Generated at 2022-06-23 21:28:35.211098
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    internet = Internet('en')
    assert isinstance(internet.ip_v4_object(), IPv4Address)


# Generated at 2022-06-23 21:28:43.020379
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    internet = Internet()
    v6 = internet.ip_v6_object()
    assert v6.is_loopback is False and \
           v6.is_multicast is False and \
           v6.is_reserved is False and \
           v6.is_unspecified is False and \
           v6.is_link_local is False and \
           v6.is_site_local is False and \
           v6.is_private is False and \
           v6.is_public is False and \
           v6.is_global is False and \
           v6.is_unique_local is False and \
           v6.is_interface_local is False

# Generated at 2022-06-23 21:28:46.818517
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    internet = Internet()
    assert internet.content_type() == "Content-Type: image/jpeg"
    assert internet.content_type(MimeType.TEXT_HTML) == "Content-Type: text/html"


# Generated at 2022-06-23 21:28:48.798247
# Unit test for constructor of class Internet
def test_Internet():
    internet = Internet()
    res = internet.http_status_message()
    print(res)

# Generated at 2022-06-23 21:28:53.514574
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    obj = Internet()
    assert isinstance(obj.network_protocol(), str)
    assert obj.network_protocol() in NETWORK_PROTOCOLS[Layer.TRANSPORT]
    assert obj.network_protocol(layer=Layer.SESSION) in NETWORK_PROTOCOLS[Layer.SESSION]


# Generated at 2022-06-23 21:28:57.833792
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    from mimesis.enums import TLDType
    from mimesis.providers.internet import Internet
    ip = Internet()
    ip4 = ip.ip_v4_object()
    assert ip4.version == 4
    ip4 = ip.ip_v4_object()
    assert ip4.version == 4
    ip6 = ip.ip_v6_object()
    assert ip6.version == 6

# Generated at 2022-06-23 21:29:05.616199
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.providers.internet import Internet
    person = Person("ru")
    gender = person.gender()
    person_name = person.full_name(gender=gender)
    person_email = person.email()
    gender_emoji = person.gender(as_emoji=True)
    ip_address = person.ipv6()
    internet = Internet("ru")
    internet__emoji = internet.emoji()
    print("\nFull name: ", person_name)
    print("Email: ", person_email)
    print("IP: ", ip_address)
    print("Gender emoji: ", gender_emoji)
    print("Internet emoji: ", internet__emoji)


# Generated at 2022-06-23 21:29:07.593766
# Unit test for method port of class Internet
def test_Internet_port():
    internet = Internet()
    assert internet.port() == internet.port(port_range=PortRange.ALL)

# Generated at 2022-06-23 21:29:10.315605
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    int_object = Internet()
    assert isinstance(int_object.ip_v6_object(), IPv6Address)


# Generated at 2022-06-23 21:29:15.334209
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    provider = Internet()
    protocol = provider.network_protocol()
    assert protocol in NETWORK_PROTOCOLS[Layer.ALL]
    assert protocol in NETWORK_PROTOCOLS[Layer.TRANSPORT]
    assert protocol in NETWORK_PROTOCOLS[Layer.APPLICATION]


# Generated at 2022-06-23 21:29:16.813985
# Unit test for constructor of class Internet
def test_Internet():
    internet = Internet()
    assert internet.__file is not None

# Generated at 2022-06-23 21:29:19.666067
# Unit test for method port of class Internet
def test_Internet_port():
    from mimesis.enums import PortRange
    from mimesis.providers.internet import Internet
    internet = Internet()
    assert internet.port(port_range=PortRange.ALL) >= 0


# Generated at 2022-06-23 21:29:21.074977
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    quantity = int(input())
    print(internet.hashtags(quantity))



# Generated at 2022-06-23 21:29:23.238811
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    obj = Internet()
    result = obj.http_status_code()
    assert result == 200

# Generated at 2022-06-23 21:29:26.984297
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    """Unit test for method ip_v6_object of class Internet."""

    from mimesis.providers.address import Address

    addr = Address()
    ip_v6 = addr.ip_v6()
    # print(ip_v6)

# Generated at 2022-06-23 21:29:29.096188
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    internet = Internet()
    assert internet.content_type() == 'Content-Type: image/tiff'



# Generated at 2022-06-23 21:29:34.869072
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    from mimesis.enums import DataField
    # Read mimesis.json file
    internet = DataField.INTERNET.value
    for unit in sorted(internet.keys()):
        print(internet[unit]())
    # call ip_v6 method
    print(internet['ip_v6']())

if __name__ == '__main__':
    test_Internet_ip_v6()

# Generated at 2022-06-23 21:29:39.372969
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    from mimesis.enums import ResultType
    from mimesis.providers.network import Network

    network = Network(seed=0, result_type=ResultType.PYTHON)
    address = network.mac_address()
    assert address == '00:16:3e:1f:42:aa'

# Generated at 2022-06-23 21:29:41.936043
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    internet = Internet()
    assert len(internet.mac_address()) == 17
    assert internet.mac_address().count(':') == 5