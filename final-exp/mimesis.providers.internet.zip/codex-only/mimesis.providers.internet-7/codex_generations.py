

# Generated at 2022-06-23 21:19:43.908911
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    assert Internet().http_status_message() in HTTP_STATUS_MSGS

if __name__ == '__main__':
    for x in range(1000):
        test_Internet_http_status_message()

# Generated at 2022-06-23 21:19:50.604639
# Unit test for constructor of class Internet
def test_Internet():
    i = Internet()
    s = i.http_status_message()
    assert s in HTTP_STATUS_MSGS
    assert i.ip_v4()
    assert i.ip_v6()
    assert i.top_level_domain()
    assert i.user_agent()
    assert i.network_protocol(layer=Layer.TRANSPORT)
    assert i.port()
    assert i.hashtags()

# Generated at 2022-06-23 21:19:52.718287
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    import pytest
    seed = pytest.fixture

    obj = Internet(seed=seed)
    x = obj.home_page()
    assert True == isinstance(x, str)

test_Internet_home_page()

# Generated at 2022-06-23 21:19:58.462358
# Unit test for method port of class Internet
def test_Internet_port():
    i = Internet('en')
    assert isinstance(i.port(), int) is True

    w = i.port(PortRange.WELL_KNOWN)
    assert (0 < w and w < 1024) is True

    r = i.port(PortRange.REGISTERED)
    assert (1024 < r and r < 49152) is True

    s = i.port(PortRange.SECURE)
    assert (49152 < s and s < 65536) is True

    all = i.port(PortRange.ALL)
    assert (0 < all and all < 65536) is True

# Generated at 2022-06-23 21:20:03.074426
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    print("\n--- Testing method 'ip_v6_object' of class 'Internet' ---")
    internet = Internet()
    ip_v6 = internet.ip_v6_object()
    assert(ip_v6)
    print("ip_v6: " + str(ip_v6))



# Generated at 2022-06-23 21:20:04.795339
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    """
    Internet.home_page() should return a string.
    """
    internet = Internet()
    assert isinstance(internet.home_page(), str)

# Generated at 2022-06-23 21:20:13.907312
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    provider = Internet()
    assert provider.stock_image() == "https://source.unsplash.com/1920x1080"
    assert provider.stock_image(width=400, height=400) == "https://source.unsplash.com/400x400"
    assert provider.stock_image(keywords=['city']) == "https://source.unsplash.com/1920x1080?city"
    assert provider.stock_image(keywords=['city', 'car']) == "https://source.unsplash.com/1920x1080?city,car"

# Generated at 2022-06-23 21:20:16.651165
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    assert len(str(Internet().ip_v6_object())) == 39
    assert all(c in '0123456789abcdef' for c in str(Internet().ip_v6_object()))


# Generated at 2022-06-23 21:20:28.428309
# Unit test for constructor of class Internet
def test_Internet():
    i = Internet()
    assert i.seed == '5df732e1c632'
   # Internet(language='ru')
    #i = Internet(language='ru')
    #print(i.ip_v4())
    #print(i.ip_v6_object())
    #print(i.port())
    #print(i.mac_address())

    #print(i.image_placeholder())
    #print(i.stock_image())
    #print(i.stock_image(keywords=["sunset"]))
    #print(i.network_protocol())
    #print(Internet.network_protocol(Layer.TWO))
    #print(i.hashtags(quantity=2))

    #print(i.user_agent())

    #print(i.content_type())
   

# Generated at 2022-06-23 21:20:34.550291
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    """ Unit test for method hashtags of class Internet.
    
    Testing that the method returs:
    - the right data type
    - the right data
    """
    
    assert isinstance(Internet().hashtags(), str)
    assert isinstance(Internet().hashtags(1), str)
    assert isinstance(Internet().hashtags(2), list)


# Generated at 2022-06-23 21:20:45.460250
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    internet_obj = Internet()
    print(internet_obj.http_status_message()) # 200 OK
    print(internet_obj.http_status_message()) # 200 OK
    print(internet_obj.http_status_message()) # 200 OK
    print(internet_obj.http_status_message()) # 200 OK
    print(internet_obj.http_status_message()) # 200 OK
    print(internet_obj.http_status_message()) # 200 OK
    print(internet_obj.http_status_message()) # 200 OK
    print(internet_obj.http_status_message()) # 200 OK
    print(internet_obj.http_status_message()) # 200 OK
    print(internet_obj.http_status_message()) # 200 OK
    print(internet_obj.http_status_message()) # 200 OK

# Generated at 2022-06-23 21:20:46.305003
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    x = Internet()
    print(x.http_status_message())

# Generated at 2022-06-23 21:20:54.203492
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    from mimesis.enums import TLDType
    from mimesis.exceptions import NonEnumerableError
    from mimesis.typing import Enum
    assert Internet().top_level_domain(tld_type=TLDType.COUNTRY) is not None
    assert Internet().top_level_domain(tld_type=TLDType.ALL) is not None
    assert Internet().top_level_domain(tld_type=TLDType.GENERIC) is not None
    try:
        assert Internet().top_level_domain(tld_type=TLDType.GENERIC) is not None
    except NonEnumerableError:
        pass
    try:
        assert Internet().top_level_domain(tld_type=TLDType.ALL) is not None
    except NonEnumerableError:
        pass

# Generated at 2022-06-23 21:20:55.718681
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    obj = Internet()
    assert isinstance(obj.ip_v4_object(), IPv4Address)


# Generated at 2022-06-23 21:20:59.755369
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    from mimesis.enums import Hashtag
    from mimesis.localization import Localization
    d = []
    for _ in range(1000):
        d.append(Internet('en', localization=Localization())
                 .hashtags(Hashtag.PLACES))

    assert(len(d) == 1000)
    assert(d.count('#Paris') == 1000)

# Generated at 2022-06-23 21:21:04.389380
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    hashtags = Internet()
    hashtag = hashtags.hashtags(quantity=1)
    hashtags_list = hashtags.hashtags(quantity=4)
    assert isinstance(hashtag, str)
    assert isinstance(hashtags_list, list)
    assert len(hashtags_list) == 4

# Generated at 2022-06-23 21:21:09.245186
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    internet = Internet()
    assert('https://' in internet.home_page())
    assert(internet.home_page() == 'https://experiment.com')


# Generated at 2022-06-23 21:21:11.264778
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    i = Internet(seed=9079079)
    i.image_placeholder(width=1920,height=1080)


# Generated at 2022-06-23 21:21:13.470996
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    internet = Internet()
    assert isinstance(internet.ip_v4_object(), IPv4Address)


# Generated at 2022-06-23 21:21:14.930208
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    ip = Internet()
    assert(isinstance(ip.ip_v4, str))

# Generated at 2022-06-23 21:21:19.463251
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():

    from mimesis.enums import Locale
    from mimesis.providers.internet import Internet

    internet = Internet(locale=Locale.EN)
    status = internet.http_status_message()
    assert isinstance(status, str)
    assert status in internet.__class__.Meta.http_status_msgs


# Generated at 2022-06-23 21:21:29.571186
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    # Given
    internet = Internet()

    # When
    result_1 = internet.network_protocol(Layer.ONE)
    result_2 = internet.network_protocol(Layer.TWO)
    result_3 = internet.network_protocol(Layer.THREE)
    result_4 = internet.network_protocol(Layer.FOUR)
    result_5 = internet.network_protocol(Layer.FIVE)
    result_6 = internet.network_protocol(Layer.SIX)
    result_7 = internet.network_protocol(Layer.SEVEN)

    # Then
    assert len(result_1) > 0
    assert len(result_2) > 0
    assert len(result_3) > 0
    assert len(result_4) > 0
    assert len(result_5) > 0
   

# Generated at 2022-06-23 21:21:31.955085
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    from Tests import test_Internet_ip_v6
    test_Internet_ip_v6.test()

# Generated at 2022-06-23 21:21:36.226551
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    print('\n************** start **************\n')
    i = Internet()
    print(i.hashtags())
    print(i.hashtags(2))
    print('\n**************  end  **************')


if __name__ == '__main__':
    test_Internet_hashtags()

# Generated at 2022-06-23 21:21:48.189475
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    import unittest.mock as mock

    from mimesis.enums import PortRange
    from mimesis.exceptions import NonEnumerableError

    internet = Internet()

    width = 1920
    height = 1080

    assert internet._MAX_IPV4 == (2 ** 32) - 1
    assert internet._MAX_IPV6 == (2 ** 128) - 1
    assert internet.port() in range(0, 65536)
    assert internet.port(PortRange.ALL) in range(0, 65536)
    assert internet.port(PortRange.DEFAULT) in range(1, 1001)
    assert internet.port(PortRange.DYNAMIC) in range(49152, 65536)
    assert internet.port(PortRange.PRIVILEGED) in range(1, 1001)

# Generated at 2022-06-23 21:21:51.495086
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    internets = Internet('en')
    result = internets.user_agent()
    assert isinstance(result, str) \
        and len(result.split()) > 1



# Generated at 2022-06-23 21:21:55.288310
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    internet = Internet()
    http_status_message = internet.http_status_message()
    assert isinstance(http_status_message, str)
    assert http_status_message in HTTP_STATUS_MSGS



# Generated at 2022-06-23 21:21:56.289207
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    internet = Internet()
    link_to_image = internet.image_placeholder()
    assert link_to_image != None

# Generated at 2022-06-23 21:21:58.886658
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    assert Internet().image_placeholder() == 'http://placehold.it/1920x1080', 'ERROR image_placeholder'
    assert Internet().image_placeholder(100, 100) == 'http://placehold.it/100x100', 'ERROR image_placeholder'
    assert Internet().image_placeholder(100, 100) != 'http://placehold.it/1920x1080', 'ERROR image_placeholder'


# Generated at 2022-06-23 21:21:59.794353
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    int_net = Internet('en')
    assert isinstance(int_net.image_placeholder(), str)

# Generated at 2022-06-23 21:22:01.191440
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    res = internet.hashtags()
    assert len(res) == 4
    for tag in res:
        assert tag[0] == '#'

# Generated at 2022-06-23 21:22:05.242897
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    from mimesis.enums import MimeType
    from mimesis.providers.internet import Internet
    inet = Internet()
    assert inet.content_type(MimeType.AUDIO) == 'Content-Type: audio/vnd.digital-winds'
    assert inet.content_type(MimeType.VIDEO) == 'Content-Type: video/vnd.fvt'


# Generated at 2022-06-23 21:22:07.189501
# Unit test for constructor of class Internet
def test_Internet():
    """Test for constructor of class Internet."""
    internet = Internet()
    assert internet is not None



# Generated at 2022-06-23 21:22:09.526921
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    x = Internet()
    y = x.http_status_message()
    print(y)

# Generated at 2022-06-23 21:22:14.421551
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    '''Test top_level_domain method of Internet class'''
    seed = 1
    internet = Internet(seed)
    assert internet.top_level_domain() == '.org'


if __name__ == "__main__":
    test_Internet_top_level_domain()

# Generated at 2022-06-23 21:22:16.804786
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    for _ in range(10):
        ip = Internet(seed=_).ip_v4_object()
        print(ip)


# Generated at 2022-06-23 21:22:24.733797
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    image = internet.stock_image(640, 480)
    assert isinstance(image, str)
    image = internet.stock_image(640, 480, writable=True)
    assert isinstance(image, bytes)
    try:
        internet.stock_image(640, 480, writable=True)
    except urllib.error.URLError:
        raise RuntimeError('Should not throw URLError')

# Generated at 2022-06-23 21:22:30.896939
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    from mimesis.enums import Layer
    _internet = Internet(seed=42)
    assert _internet.network_protocol(layer=Layer.TRANSPORT) == 'SCTP'
    assert _internet.network_protocol(layer=Layer.NETWORK) == 'IP'
    assert _internet.network_protocol(layer=Layer.DATA_LINK) == 'PPP'
    assert _internet.network_protocol(layer=Layer.APPLICATION) == 'HTTP'


# Generated at 2022-06-23 21:22:32.608405
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    assert Internet.image_placeholder() == "http://placehold.it/1920x1080"


# Generated at 2022-06-23 21:22:40.859902
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    from mimesis.enums import Language
    from mimesis.providers.internet import Internet
    from random import randint
    en = Internet(Language.ENGLISH)
    ru = Internet(Language.RUSSIAN)
    assert isinstance(en.http_status_code(), int)
    assert isinstance(ru.http_status_code(), int)
    assert en.http_status_code() <= 599 or en.http_status_code() >= 100
    assert ru.http_status_code() <= 599 or ru.http_status_code() >= 100

# Generated at 2022-06-23 21:22:45.809609
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    ip_v4 = Internet()
    ip = ip_v4.ip_v4_object()
    if ip.is_multicast or ip.ipv4_mapped:
        return False
    if ip.packed == b'\x7f\x00\x00\x01':
        return False
    if ip.is_private:
        return False
    if ip.is_reserved:
        return False
    if not ip.is_global:
        return False
    if str(ip) == '0.0.0.0':
        return False
    return True


# Generated at 2022-06-23 21:22:50.661700
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    # test_hashtags_quantity
    quantity = internet.random.randint(1, 9)
    assert len(internet.hashtags(quantity)) == quantity
    # test_hashtags_without_quantity
    assert isinstance(internet.hashtags(), str)

# Generated at 2022-06-23 21:22:52.551327
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    obj = Internet()
    assert isinstance(obj.ip_v4_object(), IPv4Address)


# Generated at 2022-06-23 21:22:56.108607
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    """A test of method ip_v6 of class Internet
        """
    global int_obj
    int_obj = Internet()
    ip = int_obj.ip_v6()
    assert isinstance(ip, str), f"{ip} is not a valid string type"


# Generated at 2022-06-23 21:22:57.701090
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    internet = Internet()
    assert internet.http_method() in HTTP_METHODS



# Generated at 2022-06-23 21:23:00.011110
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    internet = Internet()
    result = internet.http_status_code()
    assert result in list(range(100, 600))


# Generated at 2022-06-23 21:23:03.364400
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    gen = Internet()
    ip = gen.ip_v6_object()
    assert ip.is_global, "IPv6 Address is not global"


# Generated at 2022-06-23 21:23:07.722841
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    """Unit test for method top_level_domain of class Internet."""
    tld = Internet.top_level_domain(
        tld_type=TLDType.GENERIC,
    )

    assert isinstance(tld, str)
    assert tld in TLD[TLDType.GENERIC]

# Generated at 2022-06-23 21:23:12.019913
# Unit test for method port of class Internet
def test_Internet_port():
  for i in range(100):
    port_range = PortRange.UNPRIVILEGED
    upper_bound = port_range.value[1]
    lower_bound = port_range.value[0]
    port = Internet.port(port_range)
    assert(lower_bound <= port <= upper_bound)



# Generated at 2022-06-23 21:23:16.646084
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    image = internet.stock_image(writable=False)
    assert image == 'https://source.unsplash.com/1920x1080'
    assert isinstance(image, str)

    image = internet.stock_image(writable=True)
    assert isinstance(image, bytes)

# Generated at 2022-06-23 21:23:20.375439
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    from mimesis.enums import Category
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.internet import Internet
    import copy
    import mimesis.enums as enums
    import pytest
    internet = Internet('ru')

# Generated at 2022-06-23 21:23:31.178582
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    internet = Internet()
    http_status_message = internet.http_status_message()

# Generated at 2022-06-23 21:23:38.083365
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    result_dict = {
        Layer.APPLICATION: 'AMQP',
        Layer.PRESENTATION: 'SSL',
        Layer.SESSION: 'SMB',
        Layer.TRANSPORT: 'UDP',
        Layer.NETWORK: 'BGP',
        Layer.DATA_LINK: 'PPP',
        Layer.PHYSICAL: 'IEEE-802.11',
    }
    internet = Internet()

    for layer, protocol in result_dict.items():
        assert internet.network_protocol(layer) == protocol

# Generated at 2022-06-23 21:23:40.169774
# Unit test for constructor of class Internet
def test_Internet():
    provider = Internet(seed=456)
    result = provider.port(PortRange.ALL)

    assert result == 12648



# Generated at 2022-06-23 21:23:46.923621
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    internet = Internet()
    internet_protocol_1 = internet.network_protocol()
    assert internet_protocol_1 == 'TCP/IP'
    internet_protocol_2 = internet.network_protocol(Layer.APPLICATION)
    assert internet_protocol_2 == 'HTTP'
    internet_protocol_3 = internet.network_protocol(Layer.TRANSPORT)
    assert internet_protocol_3 == 'TCP/IP'
    internet_protocol_4 = internet.network_protocol(Layer.NETWORK)
    assert internet_protocol_4 == 'IPv4'


# Generated at 2022-06-23 21:23:49.676317
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from mimesis.providers.internet import Internet
    internet = Internet()
    result = internet.stock_image()
    assert result is not None

# Generated at 2022-06-23 21:23:51.974989
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    obj = Internet()
    result = obj.http_status_message()
    print(result)


# Generated at 2022-06-23 21:23:53.719908
# Unit test for constructor of class Internet
def test_Internet():
    internet = Internet()
    assert internet.__class__.__name__ == 'Internet'



# Generated at 2022-06-23 21:23:54.791374
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    print(Internet().user_agent())

# Generated at 2022-06-23 21:24:04.809597
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    i = Internet()
    print("IPv6 : "+i.ip_v6())
    print("IPv6 : "+i.ip_v6())
    print("IPv6 : "+i.ip_v6())
    print("IPv6 : "+i.ip_v6())
    print("IPv6 : "+i.ip_v6())
    print("IPv6 : "+i.ip_v6())
    print("IPv6 : "+i.ip_v6())
    print("IPv6 : "+i.ip_v6())
    print("IPv6 : "+i.ip_v6())
    print("IPv6 : "+i.ip_v6())
    print("IPv6 : "+i.ip_v6())
    print("IPv6 : "+i.ip_v6())



# Generated at 2022-06-23 21:24:08.986647
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    internet = Internet()
    ip = internet.ip_v4_object()
    assert isinstance(ip, IPv4Address)


# Generated at 2022-06-23 21:24:12.111731
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    """Unit test for method stock_image of class Internet."""
    internet = Internet(seed=123)
    result = internet.stock_image()
    expected = 'https://source.unsplash.com/1920x1080?'
    assert result == expected

# Generated at 2022-06-23 21:24:20.322929
# Unit test for constructor of class Internet
def test_Internet():
    internet = Internet()
    print(internet.hashtags())
    print(internet.content_type())
    print(internet.http_status_message())
    print(internet.http_status_code())
    print(internet.http_method())
    print(internet.ip_v4())
    print(internet.ip_v6())
    print(internet.mac_address())
    print(internet.emoji())
    print(internet.image_placeholder())
    print(internet.stock_image())
    print(internet.hashtags())
    print(internet.home_page())
    print(internet.top_level_domain())
    print(internet.user_agent())
    print(internet.network_protocol())
    print(internet.port())

if __name__ == "__main__":
    test_Internet()

# Generated at 2022-06-23 21:24:21.286031
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    internet = Internet()
    assert internet.content_type() == "Content-Type: application/json"


# Generated at 2022-06-23 21:24:24.560943
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    Internet_instance = Internet(seed=1)
    result = Internet_instance.ip_v4_object()
    assert result == IPv4Address('166.185.149.144')


# Generated at 2022-06-23 21:24:30.315569
# Unit test for method port of class Internet
def test_Internet_port():
    i = Internet()
    assert isinstance(i.port(port_range=PortRange.ALL), int)
    assert isinstance(i.port(port_range=PortRange.COMMON), int)
    assert isinstance(i.port(port_range=PortRange.PRIVATE), int)
    assert isinstance(i.port(port_range=PortRange.RESTRICTED), int)
    assert isinstance(i.port(port_range=PortRange.SYSTEM), int)

# Generated at 2022-06-23 21:24:36.416029
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    method = Internet().home_page()
    assert (method == 'https://black.org') or  (method == 'https://black.com') or  (method == 'https://black.net') or  (method == 'https://black.net') or  (method == 'https://black.biz') or  (method == 'https://black.info') or  (method == 'https://black.me') or  (method == 'https://black.mobi')


# Generated at 2022-06-23 21:24:37.121351
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    Internet().content_type()


# Generated at 2022-06-23 21:24:43.763101
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    internet = Internet()
    assert(internet.network_protocol(Layer.L1)) in "AAL5"
    assert(internet.network_protocol(Layer.L2)) in "802.3"
    assert(internet.network_protocol(Layer.L3)) in "IPv6"
    assert(internet.network_protocol(Layer.L4)) in "SCTP"
    assert(internet.network_protocol(Layer.L5)) in "TACACS"
    assert(internet.network_protocol(Layer.L6)) in "X.400"
    assert(internet.network_protocol(Layer.L7)) in "HypertextTransferProtocol"


# Generated at 2022-06-23 21:24:45.411090
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    print(Internet().http_method())


# Generated at 2022-06-23 21:24:48.469383
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    internet = Internet()
    assert internet.network_protocol(Layer.APPLICATION) in NETWORK_PROTOCOLS[Layer.APPLICATION]

# Generated at 2022-06-23 21:24:50.352890
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    internet = Internet()
    image_placeholder = internet.image_placeholder()
    print(image_placeholder)

# Generated at 2022-06-23 21:24:52.773969
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    image = internet.stock_image(writable=True)
    assert len(image) > 0
    # assert isinstance(image, bytes)

# Generated at 2022-06-23 21:24:54.830124
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    internet = Internet()
    status = internet.http_status_code()
    assert isinstance(status, int)
    assert 100 <= status <= 599


# Generated at 2022-06-23 21:24:56.103322
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    assert Internet().hashtags() == "#you", "'hashtags of class Internet can not work'"

# Generated at 2022-06-23 21:25:06.727438
# Unit test for method port of class Internet
def test_Internet_port():
    from mimesis.enums import PortRange
    from mimesis.providers.internet import Internet
    from mimesis.providers.media import Media
    from mimesis.providers.file import File

    media = Media(seed=0)
    internet = Internet(seed=0)
    file = File(seed=0)
    assert internet.port(port_range=PortRange.DYNAMIC) == 49152
    assert internet.port(port_range=PortRange.STATIC) == 8080
    assert internet.port() == 826
    assert internet.content_type(mime_type=file.mime_type(type_=media.audio())) == 'Content-Type: audio/midi'

# Generated at 2022-06-23 21:25:09.283112
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    provider = Internet()
    result = provider.content_type()
    assert result == 'Content-Type: application/json'


# Generated at 2022-06-23 21:25:11.351098
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    """Unit test for method home_page of class Internet."""
    obj = Internet()
    result = obj.home_page()
    assert result is not None

# Generated at 2022-06-23 21:25:13.957661
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    for _ in range(30):
        assert Internet().network_protocol() in list(NETWORK_PROTOCOLS.values())

# Generated at 2022-06-23 21:25:19.968811
# Unit test for method port of class Internet
def test_Internet_port():
    Internet_object = Internet(seed=1)
    assert Internet_object.port() == 3540
    assert Internet_object.port() == 7293
    assert Internet_object.port() == 3186
    assert Internet_object.port() == 7105
    assert Internet_object.port() == 7620


# Generated at 2022-06-23 21:25:29.486049
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    ip = Internet()

# Generated at 2022-06-23 21:25:34.276209
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    internet = Internet('en')

    # Test for generate a random MAC address
    test_mac = internet.mac_address()
    # assert isinstance(test_mac, str), 'Should return MAC address'
    assert isinstance(test_mac, str)
    print('Test Internet.mac_address()')



# Generated at 2022-06-23 21:25:37.458411
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    i = Internet()
    assert i.home_page() == 'https://kaydenmiller.org'


# Generated at 2022-06-23 21:25:42.555915
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    """Get a random user agent.

    :return: User agent.

    :Example:
        Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:15.0)
        Gecko/20100101 Firefox/15.0.1
    """
    user_agent = Internet.user_agent()
    assert user_agent in USER_AGENTS

# Generated at 2022-06-23 21:25:53.536967
# Unit test for method port of class Internet
def test_Internet_port():
    """Test a method that returns a random port."""
    import pytest
    from mimesis.enums import PortRange

    provider = Internet()
    result = provider.port()

    assert isinstance(result, int)

    # Default port range
    assert 0 <= result <= 65535
    assert provider.port() in range(0, 65535)

    # System port range
    assert 0 <= provider.port(port_range=PortRange.SYSTEM) <= 1023
    assert 0 <= provider.port(port_range=PortRange.SYSTEM) <= 1023

    # User port range
    assert 1024 <= provider.port(port_range=PortRange.USER) <= 49151
    assert 1024 <= provider.port(port_range=PortRange.USER) <= 49151

    # Dynamic port range

# Generated at 2022-06-23 21:25:55.514353
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    internet = Internet()
    assert internet.network_protocol(layer=Layer.Network) == 'IPV4'

# Generated at 2022-06-23 21:25:58.168463
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    """Test Internet.user_agent()."""
    internet = Internet()
    # Repeat 100 times
    for _ in range(100):
        result = internet.user_agent()
        assert result in USER_AGENTS

# Generated at 2022-06-23 21:26:02.327175
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet(seed=42)
    tags = internet.hashtags(quantity=1)
    assert isinstance(tags, str)
    assert tags == '#voluptas'

    tags = internet.hashtags(quantity=3)
    assert isinstance(tags, list)
    assert tags == ['#neque', '#laboriosam', '#eum']


# Generated at 2022-06-23 21:26:04.385230
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    internet = Internet()
    result = internet.http_method()
    assert isinstance(result, str)



# Generated at 2022-06-23 21:26:08.372505
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    print("Testing Internet.ip_v4_object()")
    _internet = Internet()
    _ip = _internet.ip_v4_object()
    print(type(_ip))
    print(_ip)


# Generated at 2022-06-23 21:26:10.697312
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    sample_provider = Internet()
    ip_v4_object = sample_provider.ip_v4_object()
    assert str(ip_v4_object)


# Generated at 2022-06-23 21:26:13.146834
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    internet = Internet('ru')

    assert isinstance(internet.ip_v4(), str)


# Generated at 2022-06-23 21:26:14.836104
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    internet = Internet()
    assert internet.top_level_domain(tld_type=TLDType.COUNTRY)

# Generated at 2022-06-23 21:26:18.738783
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    """Testing method image_placeholder of class Internet."""
    internet = Internet()
    assert internet.image_placeholder() == \
        'http://placehold.it/1920x1080'


# Generated at 2022-06-23 21:26:20.798740
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    for i in range(10):
        print(Internet().http_status_message())


# Generated at 2022-06-23 21:26:24.293845
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():

    internet = Internet()

    tags = internet.hashtags(quantity=3)

    assert type(tags) == list

    assert len(tags) == 3

    tags = internet.hashtags(quantity=1)

    assert type(tags) == str

    assert len(tags) > 1

# Generated at 2022-06-23 21:26:27.225803
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    """Unit test for method http_status_message of class Internet."""
    i = Internet()
    assert len(i.http_status_message()) >= 0


# Generated at 2022-06-23 21:26:31.832469
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    internet_class_1 = Internet(seed=10)
    internet_class_2 = Internet(seed=10)
    assert internet_class_1.ip_v6_object()  == internet_class_2.ip_v6_object()


# Generated at 2022-06-23 21:26:32.915637
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    code = Internet().http_status_code()
    print("HTTP status code:", code)



# Generated at 2022-06-23 21:26:41.511230
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    from mimesis.enums import TLDType
    from mimesis.providers.internet import Internet
    from mimesis.providers.internet import TLD
    from mimesis.providers.internet import USERNAMES
    from mimesis.typing import Enum

    i = Internet('en')
    assert i.home_page() == f'https://{i.random.choice(USERNAMES)}.{i.random.choice(TLD["default"])}'
    assert i.home_page(tld_type=TLDType.COUNTRY_SPECIFIC) == \
        f'https://{i.random.choice(USERNAMES)}.{i.random.choice(TLD["country_specific"])}'

# Generated at 2022-06-23 21:26:43.079208
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    assert Internet().user_agent() in USER_AGENTS

# Generated at 2022-06-23 21:26:46.295437
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    newInternet = Internet()
    IPv6Address = newInternet.ip_v6_object()
    assert type(IPv6Address) == ipaddress.IPv6Address


# Generated at 2022-06-23 21:26:48.814797
# Unit test for constructor of class Internet
def test_Internet():
    internet = Internet()
    assert internet is not None


# Generated at 2022-06-23 21:26:54.153496
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    test_Int = Internet(seed=3)
    assert test_Int.home_page() == "https://arrivingsystem.info"
    assert test_Int.home_page(tld_type="en") == "https://sales.org"
    assert test_Int.home_page(tld_type="ru") == "https://dualcovered.ru"


# Generated at 2022-06-23 21:26:55.982302
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    test_obj = Internet()
    print(test_obj.home_page())


# Generated at 2022-06-23 21:26:57.648809
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    internet = Internet()
    m = internet.http_method()
    assert m in HTTP_METHODS

# Generated at 2022-06-23 21:27:01.480585
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    internet = Internet()
    import ipaddress
    ipv6 = internet.ip_v6_object()
    assert isinstance(ipv6, ipaddress.IPv6Address)


# Generated at 2022-06-23 21:27:04.532543
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    from mimesis.enums import PortRange
    from mimesis.providers.internet import Internet

    http_status_message = Internet().http_status_message()
    assert type(http_status_message) is str


# Generated at 2022-06-23 21:27:11.344463
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    internet1 = Internet() 
    internet2 = Internet() 
    internet3 = Internet() 
    internet4 = Internet() 
    internet5 = Internet() 
    internet6 = Internet() 
    internet7 = Internet() 
    internet8 = Internet() 
    internet9 = Internet() 
    internet10 = Internet() 
    print(internet1.home_page(),internet1.home_page()) 
    print(internet2.home_page(),internet2.home_page()) 
    print(internet3.home_page(),internet3.home_page()) 
    print(internet4.home_page(),internet4.home_page()) 
    print(internet5.home_page(),internet5.home_page()) 
    print(internet6.home_page(),internet6.home_page()) 

# Generated at 2022-06-23 21:27:13.549402
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    my_internet = Internet()
    user_agent = my_internet.user_agent()
    assert isinstance(user_agent, str) and user_agent != ''


# Generated at 2022-06-23 21:27:22.889189
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    obj = Internet()
    assert isinstance(obj.mac_address(), str)
    assert len(obj.mac_address()) == 17
    assert obj.mac_address()[2] == ":"
    assert int(obj.mac_address()[0:2], 16) == 0
    assert int(obj.mac_address()[3:5], 16) == 22
    assert int(obj.mac_address()[6:8], 16) == 62
    assert int(obj.mac_address()[9:11], 16) >= 0
    assert int(obj.mac_address()[9:11], 16) < 128
    assert int(obj.mac_address()[12:14], 16) >= 0
    assert int(obj.mac_address()[12:14], 16) < 256

# Generated at 2022-06-23 21:27:30.344708
# Unit test for method port of class Internet
def test_Internet_port():
    internet = Internet()
    test_cases = [
        [PortRange.ALL, 1, 65535],
        [PortRange.PRIVILEGED, 1, 1024],
        [PortRange.UNPRIVILEGED, 1025, 65535],
        [PortRange.EPHEMERAL, 49152, 65535],
    ]

    for port_range, min_port, max_port in test_cases:
        for i in range(100):
            assert min_port <= internet.port(port_range) <= max_port

# Generated at 2022-06-23 21:27:32.426356
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    test = Internet()
    assert isinstance(test.ip_v6(), str)
    assert len(test.ip_v6()) == 39

# Generated at 2022-06-23 21:27:34.655037
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    print(Internet('en').mac_address())

# Generated at 2022-06-23 21:27:36.334195
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    i = Internet()
    assert i.http_status_code() in HTTP_STATUS_CODES



# Generated at 2022-06-23 21:27:37.847218
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    internet = Internet()
    assert isinstance(internet.ip_v4(), str)
    assert isinstance(internet.ip_v4(with_port=True), str)


# Generated at 2022-06-23 21:27:43.520504
# Unit test for method port of class Internet
def test_Internet_port():
    provider = Internet(random_state=42)

    # Default value from the method
    assert provider.port() == provider.port(PortRange.ALL)

    # Regular
    assert provider.port(PortRange.REGULAR) == provider.port(49152, 65535)

    # Registered
    assert provider.port(PortRange.REGISTERED) == \
           provider.port(1024, 49151)

    # Dynamic
    assert provider.port(PortRange.DYNAMIC) == provider.port(49152, 65535)

    # Well-known
    assert provider.port(PortRange.WELL_KNOWN) == \
           provider.port(1, 1023)

    # Ephemeral
    assert provider.port(PortRange.EPHEMERAL) == provider.port(49152, 65535)

# Generated at 2022-06-23 21:27:46.416623
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    internet = Internet()
    result = internet.image_placeholder(width=1920, height=1080)
    link = 'http://placehold.it/1920x1080'
    assert result == link, "Test method Internet.image_placeholder"



# Generated at 2022-06-23 21:27:47.547071
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    internet = Internet()
    assert internet.user_agent().find(' ') != -1

# Generated at 2022-06-23 21:27:54.387543
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    internet = Internet()
    contents = ['😀😃😄😁😆😅', '😂🤣😋😎🤗', '😍😚😘🤩😗', '😙🤪😛🤑😏', '🤥😶😇🙂🤠']

    assert internet.emoji() in contents

# Generated at 2022-06-23 21:28:02.020406
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from pprint import pprint
    from mimesis.enums import ImageSize

    internet = Internet()
    link = internet.stock_image(width=1920, height=1080,
                                keywords=['fashion', 'beauty'])
    pprint(link)

    link = internet.stock_image(
        width=ImageSize.S_1024x512.value,
        height=ImageSize.S_1024x512.value,
    )
    pprint(link)

    img = internet.stock_image(
        width=ImageSize.L_2048x1024.value,
        height=ImageSize.L_2048x1024.value,
        writable=True,
    )
    pprint(img)



# Generated at 2022-06-23 21:28:05.272361
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    internet = Internet()
    assert '200 OK' == internet.http_status_message()

# Generated at 2022-06-23 21:28:07.048773
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    result = Internet().ip_v4()
    assert result



# Generated at 2022-06-23 21:28:10.179808
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    """Test if the HTTP method is not fixed."""
    provider = Internet('en')
    for _ in range(100):
        assert provider.http_method() in HTTP_METHODS



# Generated at 2022-06-23 21:28:13.465168
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    i = Internet()
    print("i.emoji()=", i.emoji())
    print("i.emoji()=", i.emoji())
    print("i.emoji()=", i.emoji())


# Generated at 2022-06-23 21:28:14.155954
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    pass


# Generated at 2022-06-23 21:28:18.661050
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    """Test method top_level_domain.

    :return: Nothing.
    """
    internet = Internet()

    expected_keys = ['common', 'country', 'ngos', 'special']
    actual_keys = list(TLD.keys())
    assert expected_keys == actual_keys

    domain = internet.top_level_domain()
    assert domain.startswith('.')
    assert domain not in expected_keys



# Generated at 2022-06-23 21:28:24.516658
# Unit test for constructor of class Internet
def test_Internet():
    internet = Internet()
    print(internet.content_type(mime_type=MimeType.PDF))
    print(internet.http_status_message())
    print(internet.http_status_code())
    print(internet.http_method())
    print(internet.ip_v4_object())
    print(internet.ip_v4(with_port=True, port_range=PortRange.RESTRICTED))
    print(internet.ip_v6_object())
    print(internet.ip_v6())
    print(internet.mac_address())
    print(internet.emoji())
    print(internet.image_placeholder(width=1920, height=1080))
    print(internet.stock_image(width=1920, height=1080))
    print(internet.hashtags(quantity=4))
    print

# Generated at 2022-06-23 21:28:26.843200
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    internet = Internet('en')
    assert internet.home_page() == 'https://mvf.com'


# Generated at 2022-06-23 21:28:29.295050
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    # given
    internet = Internet()
    # when
    result = internet.ip_v6_object()
    # then
    assert isinstance(result, IPv6Address)

# Generated at 2022-06-23 21:28:31.760521
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    try:
        ip = IPv6Address(Internet().ip_v6_object())
        assert isinstance(ip, IPv6Address)
    except Exception as e:
        print(e)
        return False
    return True


# Generated at 2022-06-23 21:28:33.271060
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    res = Internet().image_placeholder()
    assert type(res)==str


# Generated at 2022-06-23 21:28:34.621699
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    Internet.http_status_message() == ' '


# Generated at 2022-06-23 21:28:38.222755
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    from mimesis.hypermedia.internet import Internet
    internet = Internet()
    for i in range(100000):
        ip_v6_object = internet.ip_v6_object()
        assert ip_v6_object.version == 6

# Generated at 2022-06-23 21:28:45.618832
# Unit test for method port of class Internet
def test_Internet_port():

    from random import Random
    from enum import Enum
    from mimesis.enums import PortRange
    from mimesis.providers.internet import Internet
    from mimesis.providers.base import BaseProvider
    """
    Test the method port of class Internet.

    """

    """
    Test raising NonEnumerableError if port_range is not in PortRange.

    """
    provider = Internet('en')
    provider.port_range = None
    with pytest.raises(NonEnumerableError) as excinfo:
        provider.port()
    assert  excinfo.type == NonEnumerableError
    
    """
    Test that port_range is in PortRange.

    """
    provider = Internet('en')
    provider.port_range = PortRange.ALL

# Generated at 2022-06-23 21:28:55.739565
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    """ Generate ipv6 address from ipv6_object method of class Internet """
    from mimesis.enums import Layer, PortRange
    from mimesis.providers.internet import Internet
    from mimesis.providers.file import File
    from mimesis.providers.utils import get_provider

    # Initialize the internet provider
    internet = Internet('en')
    assert internet
    # Initialize the utils provider
    utils = get_provider('utils', 'en')
    assert utils
    # Initialize the file provider
    file = File('en')
    assert file
    # Initialize the port range enum
    port_range = PortRange
    assert port_range
    # Initialize the layer enum
    layer = Layer
    assert layer
    # Initialize the maximum value of ipv4
    max

# Generated at 2022-06-23 21:28:59.837140
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    internet = Internet()
    #valid
    internet.network_protocol(layer=Layer.LINK)
    internet.network_protocol(layer=Layer.NETWORK)
    internet.network_protocol(layer=Layer.TRANSPORT)
    internet.network_protocol(layer=Layer.SESSION)
    internet.network_protocol(layer=Layer.PRESENTATION)
    internet.network_protocol(layer=Layer.APPLICATION)

# Generated at 2022-06-23 21:29:03.318573
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():

    net = Internet(seed=1234567890)
    assert net.ip_v6() == "2001:c244:cf9d:1fb1:c56d:f52c:8a04:94f3"

# Generated at 2022-06-23 21:29:06.408121
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    internet = Internet()
    home_page = internet.home_page()
    assert len(home_page) > 1
    print(home_page)


# Generated at 2022-06-23 21:29:18.162490
# Unit test for constructor of class Internet
def test_Internet():
    import random
    test_port_range = random.choice((PortRange.ALL, PortRange.SYS, PortRange.REG))
    print("port_range : ", test_port_range)
    print("ip_v4 : ", Internet().ip_v4(with_port=True, port_range=test_port_range))
    print("ip_v6 : ", Internet().ip_v6())
    print("mac_address : ", Internet().mac_address())
    print("emoji : ", Internet().emoji())
    print("image_placeholder : ", Internet().image_placeholder())
    print("stock_image : ", Internet().stock_image())
    print("hashtags : ", Internet().hashtags())
    print("home_page : ", Internet().home_page())

# Generated at 2022-06-23 21:29:22.518926
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    # TODO: This test should cover all the logic
    #       of ip_v4 method in class Internet
    internet = Internet()
    ip = internet.ip_v4()
    assert ip is not None

# Generated at 2022-06-23 21:29:24.978911
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    IP = Internet()
    
    ip = IP.ip_v4()
    assert IPv4Address(ip)


# Generated at 2022-06-23 21:29:37.621978
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    internet = Internet()
    assert internet.network_protocol(layer=Layer.APPLICATION) in (
        "FTP", "HTTP", "HTTPS", "IMAP", "IRC", "LDAP", "NNTP", "POP3", "RDP", "RTMP", "SMTP", "SSH", "TELNET", "UPNP",
        "XMPP", "XML-RPC")
    assert internet.network_protocol(layer=Layer.TRANSPORT) in (
        "TCP", "UDP")
    assert internet.network_protocol(layer=Layer.INTERNET) in (
        "ICMP", "IGMP", "IPv4", "IPv6")

# Generated at 2022-06-23 21:29:38.809823
# Unit test for method port of class Internet
def test_Internet_port():
    port = Internet().port()
    assert port == 1

# Generated at 2022-06-23 21:29:47.364484
# Unit test for method port of class Internet
def test_Internet_port():
    internet = Internet(seed=123456)

    assert internet.port() == 9921
    assert internet.port() == 63674
    assert internet.port(PortRange.DYNAMIC) == 6731
    assert internet.port(PortRange.DYNAMIC_OR_PRIVATE) == 8127
    assert internet.port(PortRange.EPHEMERAL) == 19990
    assert internet.port(PortRange.PRIVATE) == 799
    assert internet.port(PortRange.REGISTERED) == 9167
    assert internet.port(PortRange.RESERVED) == 1878
    assert internet.port(PortRange.SYSTEM) == 3675
    assert internet.port(PortRange.WELL_KNOWN) == 4385

