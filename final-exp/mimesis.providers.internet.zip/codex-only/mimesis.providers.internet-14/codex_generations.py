

# Generated at 2022-06-23 21:19:47.059765
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    # create a object for class Internet
    mac = Internet(seed=101)
    # create a string named mac_addr and assign it a random mac address
    mac_addr = mac.mac_address()
    # assert the mac address returned is value "00:16:3e:25:e7:b1"
    assert mac_addr == '00:16:3e:25:e7:b1'

# Generated at 2022-06-23 21:19:51.061669
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    i = Internet(seed=0)
    s = i.ip_v6()
    expected = '2001:c244:cf9d:1fb1:c56d:f52c:8a04:94f3'
    assert s == expected

# Generated at 2022-06-23 21:19:54.706181
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    """ Test for method stock_image of class Internet"""
    obj = Internet()
    res = obj.stock_image(1920, 1080)
    print(res)
    assert isinstance(res, str)
    assert res.startswith('https://')

# Generated at 2022-06-23 21:20:00.164358
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    """Unit test for method stock_image()."""
    from mimesis.providers.internet import Internet
    internet = Internet()
    url_or_image = internet.stock_image(writable=True)
    assert isinstance(url_or_image, bytes)

# Generated at 2022-06-23 21:20:02.634421
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    quantity = 3
    hashtags = internet.hashtags(quantity)
    assert len(hashtags) == quantity

# Generated at 2022-06-23 21:20:06.274414
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    from mimesis.providers.internet import Internet
    from mimesis.enums import Layer, PortRange, TLDType
    # Create object internet
    internet = Internet()
    # Print data
    print("Method http_status_code:", internet.http_status_code())


# Generated at 2022-06-23 21:20:16.975156
# Unit test for method port of class Internet
def test_Internet_port():
    internet = Internet()
    for _ in range(10):
        port = internet.port()
        assert port >= PortRange.ALL.value[0]
        assert port <= PortRange.ALL.value[1]
    for _ in range(10):
        port = internet.port(port_range=PortRange.RESERVED)
        assert port >= PortRange.RESERVED.value[0]
        assert port <= PortRange.RESERVED.value[1]
    for _ in range(10):
        port = internet.port(port_range=PortRange.SYSTEM)
        assert port >= PortRange.SYSTEM.value[0]
        assert port <= PortRange.SYSTEM.value[1]
    for _ in range(10):
        port = internet.port(port_range=PortRange.USER)

# Generated at 2022-06-23 21:20:19.624927
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    x = Internet()
    result = x.ip_v4_object()
    assert result.is_global
    

# Generated at 2022-06-23 21:20:22.596409
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    ip = Internet(seed=0)
    for _ in range(100):
        assert type(ip.ip_v6_object()) == IPv6Address

# Generated at 2022-06-23 21:20:31.561980
# Unit test for constructor of class Internet
def test_Internet():
    internet = Internet()
    tld_type = internet.random.choice(list(TLDType))
    layer = internet.random.choice(list(Layer))
    port_range = internet.random.choice(list(PortRange))

    assert isinstance(internet.content_type(), str)
    assert isinstance(internet.content_type(MimeType.JSON), str)
    assert isinstance(internet.http_status_message(), str)
    assert isinstance(internet.http_status_code(), int)
    assert isinstance(internet.http_method(), str)
    assert isinstance(internet.ip_v4_object(), IPv4Address)
    assert isinstance(internet.ip_v4(), str)
    assert isinstance(internet.ip_v4(with_port=True), str)

# Generated at 2022-06-23 21:20:33.281769
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    print(internet.stock_image())

# Generated at 2022-06-23 21:20:43.937492
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    i = Internet()
    # print(i.top_level_domain())
    assert i.top_level_domain() in TLD[TLDType.ALL]
    assert i.top_level_domain(TLDType.ALL) in TLD[TLDType.ALL]
    assert i.top_level_domain(TLDType.GEOGRAPHIC) \
        in TLD[TLDType.GEOGRAPHIC]
    assert i.top_level_domain(TLDType.COUNTRY_CODE) \
        in TLD[TLDType.COUNTRY_CODE]
    assert i.top_level_domain(TLDType.GENERIC) \
        in TLD[TLDType.GENERIC]


# Generated at 2022-06-23 21:20:46.383721
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    internet = Internet(seed = 1)
    assert internet.mac_address() == "00:16:3e:7f:b8:f8"


# Generated at 2022-06-23 21:20:48.662252
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    http_method = Internet().http_method()
    assert http_method in HTTP_METHODS


# Generated at 2022-06-23 21:20:50.242296
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    internet = Internet()
    assert internet.http_method() in HTTP_METHODS


# Generated at 2022-06-23 21:20:52.148498
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    for _ in range(10):
        result = Internet().emoji();
        assert isinstance(result, str)
        assert result


# Generated at 2022-06-23 21:20:55.634204
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    """Test for Internet.top_level_domain."""
    t = Internet()
    t.seed(1)
    assert t.top_level_domain() == 'ol'
    t.seed(2)
    assert t.top_level_domain() == 'habo'


# Generated at 2022-06-23 21:21:02.149954
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    try:
        # Test 1
        obj_1 = Internet()
        ipv4_1 = obj_1.ip_v4_object()
        assert(type(ipv4_1) == IPv4Address)
        # Test 2
        obj_2 = Internet(seed=4545454545)
        ipv4_2 = obj_2.ip_v4_object()
        assert(type(ipv4_2) == IPv4Address)
        print("Test for Internet.ip_v4_object() completed")
        return True
    except:
        print("Test for Internet.ip_v4_object() failed")
        return False


# Generated at 2022-06-23 21:21:03.782650
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    obj = Internet()
    assert isinstance(obj.ip_v6_object(), IPv6Address)

# Generated at 2022-06-23 21:21:09.660444
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():   
    """
    stock_image = Internet().stock_image(keywords=['poop'])
    assert (stock_image)
    """
    stock_image = Internet().stock_image(keywords=['poop'])
    assert (stock_image)



# Generated at 2022-06-23 21:21:11.241347
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    internet = Internet()
    print(internet.mac_address())


# Generated at 2022-06-23 21:21:13.368092
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    internet =Internet()
    assert internet.http_status_message() in HTTP_STATUS_MSGS


# Generated at 2022-06-23 21:21:17.178329
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    """Test method stock_image of class Internet."""
    internet = Internet()
    image = internet.stock_image()
    assert image.startswith('https://')
    # Check if exception was raised
    internet.stock_image(writable=True)

# Generated at 2022-06-23 21:21:27.080710
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    """Unit test for method network_protocol of class Internet
    
    This test works correct if the next results are equal:
    
    >>> i = Internet()
    >>> i.network_protocol(layer=Layer.TRANSPORT)
    'UDP'
    >>> i.network_protocol()
    'HTTP'
    >>> i.network_protocol(layer=Layer.APPLICATION)
    'SSH'
    
    """
    i = Internet()
    assert i.network_protocol(layer=Layer.TRANSPORT) == 'UDP'
    assert i.network_protocol() == 'HTTP'
    assert i.network_protocol(layer=Layer.APPLICATION) == 'SSH'


# Generated at 2022-06-23 21:21:29.350258
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    assert(Internet().http_status_code() in HTTP_STATUS_CODES)


# Generated at 2022-06-23 21:21:32.162147
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    from mimesis.providers.internet import Internet
    internet = Internet()
    useragent = internet.user_agent()
    assert useragent != ''

# Generated at 2022-06-23 21:21:33.840888
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    int_n = Internet()
    http_status_code = int_n.http_status_code()
    print("HTTP Status Code:", http_status_code)



# Generated at 2022-06-23 21:21:36.184015
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    internet1 = Internet()
    ip_v4 = internet1.ip_v4(True, PortRange.TRUSTED)
    assert ip_v4.count(':') == 1

# Generated at 2022-06-23 21:21:42.540794
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    print('Тестируем метод http_method')
    inter = Internet()
    i = 1
    while i < 3:
        test_http_method = inter.http_method()
        print(test_http_method)
        i += 1


# Generated at 2022-06-23 21:21:45.191145
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    internet = Internet('en')
    mac = internet.mac_address()
    assert mac.__len__() >= 17
    print(mac)



# Generated at 2022-06-23 21:21:51.495451
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    patterns = [
        'GET',
        'POST',
        'HEAD',
        'PUT',
        'DELETE',
        'TRACE',
        'OPTIONS',
        'CONNECT',
        'PATCH'
    ]
    method = Internet().http_method()
    assert method in patterns
    assert isinstance(method, str)


# Generated at 2022-06-23 21:21:52.850481
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    provider = Internet()
    status = provider.http_status_code()

    assert status in HTTP_STATUS_CODES

# Generated at 2022-06-23 21:21:55.235363
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    ip_address = Internet().ip_v4_object()
    assert isinstance(ip_address, IPv4Address)


# Generated at 2022-06-23 21:21:56.727717
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    assert Internet().home_page()=="https://sharenietzsche.com"

# Generated at 2022-06-23 21:21:57.691882
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    internet = Internet()
    ip = internet.ip_v6()
    print(ip)
    assert isinstance(ip, str)


# Generated at 2022-06-23 21:22:00.349855
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    # create an instance
    ip_obj = Internet()

    # create an ip address
    ip = ip_obj.ip_v4()

    # check ip
    assert isinstance(ip, str) == True

# Generated at 2022-06-23 21:22:01.831283
# Unit test for method port of class Internet
def test_Internet_port():
    """Test for Internet port."""
    item = Internet()
    assert isinstance(item.port(), int)

# Generated at 2022-06-23 21:22:05.460039
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    """Test method image_placeholder of class Internet."""
    url = 'http://placehold.it/500x500'
    assert Internet.image_placeholder(width=500, height=500) == url

# Generated at 2022-06-23 21:22:17.372939
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    from mimesis import Random
    internet = Internet(seed=1)
    ipv6_object = internet.ip_v6_object()
    assert ipv6_object.exploded == '0:0:0:0:0:ffff:e597:ab1a'
    assert ipv6_object.is_global == True
    assert ipv6_object.is_link_local == False
    assert ipv6_object.is_multicast == False
    assert ipv6_object.is_site_local == False
    assert ipv6_object.is_unspecified == False
    assert ipv6_object.version == 6
    assert ipv6_object.with_netmask == '0:0:0:0:0:ffff:e597:ab1a/128'
    assert ipv6_object

# Generated at 2022-06-23 21:22:21.815363
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    from mimesis.enums import Layer
    from mimesis.providers.internet import Internet
    from mimesis.providers.utils import re_test_pattern


# Generated at 2022-06-23 21:22:24.632603
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    internet = Internet()
    s = internet.http_status_message()
    assert len(s) > 0


# Generated at 2022-06-23 21:22:32.635914
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    """Unit test for method emoji of class Internet."""
    from mimesis.enums import MimeType
    from mimesis.enums import PortRange
    from mimesis.enums import TLDType
    from mimesis.enums import Layer
    from mimesis.enums import Locale

    ru = Internet(locale=Locale.RU)

    assert ru.ip_v4()
    assert ru.ip_v4(with_port=True)
    assert ru.ip_v4(with_port=True, port_range=PortRange.ALL)
    assert ru.ip_v6()
    assert ru.mac_address()
    assert ru.emoji()
    assert ru.content_type()
    assert ru.content_type(mime_type=MimeType.VIDEO)
    assert ru

# Generated at 2022-06-23 21:22:42.886539
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    """Test for the method user_agent of class Internet."""
    a = Internet()
    ua = a.user_agent()
    assert len(ua) > 0
    assert isinstance(ua, str)
    # Test user agents, which are most often used

# Generated at 2022-06-23 21:22:46.467224
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    """This function tests stock_image method of class Internet."""
    from mimesis.enums import ImageOrientation

    internet = Internet('en')
    assert isinstance(internet.stock_image(), str)
    assert isinstance(internet.stock_image(writable=True), bytes)
    assert isinstance(internet.stock_image(
        width=1280, height=720,
        keywords=[ImageOrientation.PORTRAIT],
    ), str)

# Generated at 2022-06-23 21:22:48.157638
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    internet = Internet()
    assert isinstance(internet.ip_v4_object(), IPv4Address)


# Generated at 2022-06-23 21:22:58.534623
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    internet = Internet()
    content_type = internet.content_type()

# Generated at 2022-06-23 21:23:09.610581
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    from mimesis.enums import DatetimeUnit, Layer, MimeType
    from mimesis.exceptions import NonEnumerableError
    from mimesis.typing import CustomList, CustomStr

    generator = Internet()
    timestamp = generator.datetime(timezone=False,
                                   minimum=1466424147,
                                   maximum=1466527077,
                                   datetime_unit=DatetimeUnit.SECONDS)
    assert timestamp == 1466504120
    assert generator.seed == 1466504120

    generator = Internet(timestamp=1466504120)
    assert generator.seed == 1466504120

    generator = Internet(seed=1)
    assert generator.seed == 1466504120

    assert hasattr(generator, 'file')
    assert hasattr(generator, 'net')
    assert hasattr

# Generated at 2022-06-23 21:23:11.270771
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    ip = Internet.ip_v6_object()
    assert isinstance(ip, IPv6Address)


# Generated at 2022-06-23 21:23:13.022279
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    x = Internet()
    assert type(x.content_type()) is str
    assert x.content_type(MimeType.AUDIO) == "Content-Type: audio/basic"


# Generated at 2022-06-23 21:23:14.884747
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    internet = Internet()
    assert internet.content_type() == 'Content-Type: application/json'


# Generated at 2022-06-23 21:23:17.528276
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    """Unit test for method http_status_message of class Internet."""
    internet = Internet()
    http = internet.http_status_message()
    assert http in HTTP_STATUS_MSGS


# Generated at 2022-06-23 21:23:21.275005
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    print('*** Start test_Internet_network_protocol() ***')

    p = Internet('en')
    res = p.network_protocol()
    print('Test #1 pass')

    print('*** Finish test_Internet_network_protocol() ***')


# Generated at 2022-06-23 21:23:24.131639
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    """Test method ip_v6 of class Internet"""
    internet = Internet()
    ip = internet.ip_v6()
    assert isinstance(ip, str)
    assert isinstance(IPv6Address(ip), IPv6Address)


# Generated at 2022-06-23 21:23:27.861026
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    obj = Internet(seed=False)
    response = obj.http_status_code()
    assert isinstance(response, int)


# Generated at 2022-06-23 21:23:35.940899
# Unit test for method port of class Internet
def test_Internet_port():
    random_generator = random.Random()
    random_generator.seed(1)
    internet = Internet(random_generator)
    assert internet.port() == 58846
    assert internet.port(PortRange.TIME) == 59250
    assert internet.port(PortRange.TACACS) == 64886
    assert internet.port(PortRange.ORACLE) == 71650
    assert internet.port(PortRange.DOMAIN) == 59917
    assert internet.port(PortRange.UNPRIVILEGED) == 61649
    assert internet.port() == 59060
    assert internet.port(PortRange.EVERYTHING) == 59633
    assert internet.port(PortRange.WELLKNOWN) == 59707
    assert internet.port(PortRange.ALL) == 58562

# Generated at 2022-06-23 21:23:44.488937
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    from mimesis.enums import TLDType
    from mimesis.providers.internet import Internet
    from mimesis.exceptions import NonEnumerableError

    internet = Internet()
    get_emoji = internet.emoji()
    print(get_emoji)
    print(type(get_emoji))

    get_ipv4 = internet.ip_v4()
    print(get_ipv4)
    print(type(get_ipv4))

    get_port = internet.port()
    print(get_port)
    print(type(get_port))
    get_port = internet.port(port_range=internet.PortRange.BLOCKED)
    print(get_port)

    get_http_status = internet.http_status_code()
    print(get_http_status)

# Generated at 2022-06-23 21:23:55.517177
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    """Unit test for method ip_v4 of class Internet."""
    from mimesis.enums import PortRange

    internet = Internet()
    ip = internet.ip_v4()
    ip_with_port = internet.ip_v4(with_port=True, port_range=PortRange.ALL)

    assert isinstance(ip, str)
    assert '.' in ip
    assert len(ip.split('.')) == 4

    assert isinstance(ip_with_port, str)
    assert ':' in ip_with_port
    assert len(ip_with_port.split('.')) == 4
    assert len(ip_with_port.split(':')) == 2


# Generated at 2022-06-23 21:23:57.977037
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    ip = Internet()
    ip.image_placeholder()
    print(ip.image_placeholder(300, 400))

# Generated at 2022-06-23 21:24:05.885142
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    #Let's create a list of the elements that we obtain by this method
    list=[]
    quantity=100000
    test=Internet()
    #we create a list that contains "quantity" elements
    for i in range(0,quantity):
        list.append(test.home_page())
    #Now we compare the number of different elements with the quantity of elements
    #If the two numbers are the same, we will have a false positive rate of zero
    if len(set(list))!=quantity:
        print("test_Internet_home_page test failed")
        return
    #If the two numbers are different, there is a false positive rate greater than zero
    else:
        print("test_Internet_home_page test passed")
        return

# Generated at 2022-06-23 21:24:06.934844
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    internet = Internet()
    assert True == isinstance(internet.home_page(), str)


# Generated at 2022-06-23 21:24:09.839833
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    internet = Internet()
    print(internet.user_agent())


if __name__ == '__main__':
    test_Internet_user_agent()

# Generated at 2022-06-23 21:24:12.558081
# Unit test for method content_type of class Internet
def test_Internet_content_type():

    internet = Internet()
    ct = internet.content_type()
    # print(ct)
    assert isinstance(ct, str)
    # assert ct == 'application/json'


# Generated at 2022-06-23 21:24:17.208450
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    provider = Internet()
    result = provider.content_type()
    assert result is not None
    assert isinstance(result, str)

    result = provider.content_type(MimeType.PDF)
    assert result is not None
    assert isinstance(result, str)



# Generated at 2022-06-23 21:24:18.741652
# Unit test for constructor of class Internet
def test_Internet():
    t = Internet()
    print(t.mac_address())


# Generated at 2022-06-23 21:24:20.771251
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    assert type(Internet().ip_v4_object()) == IPv4Address


# Generated at 2022-06-23 21:24:22.379125
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    # Preparation
    internet = Internet(seed=12)

    # Execution
    result = internet.emoji()

    # Verification
    assert result == ':confused:'



# Generated at 2022-06-23 21:24:25.038277
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    internet = Internet()
    tld_type = TLDType.COUNTRY_SPECIFIC

    domain = internet.top_level_domain(tld_type=tld_type)
    assert isinstance(domain,str)
    assert 1 <= len(domain) <= 6


# Generated at 2022-06-23 21:24:27.204202
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    internet = Internet()
    tld = internet.top_level_domain()
    assert tld in internet.data.tld
    assert len(tld) > 1

# Generated at 2022-06-23 21:24:28.905650
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    internet = Internet()
    assert isinstance(internet.http_status_message(), str)


# Generated at 2022-06-23 21:24:30.860669
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    internet = Internet()
    assert internet.ip_v4() == '66.244.36.11'


# Generated at 2022-06-23 21:24:32.796363
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    internet = Internet()
    assert internet.http_status_message() in HTTP_STATUS_MSGS


# Generated at 2022-06-23 21:24:41.539547
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    from mimesis.enums import TLDType
    i = Internet()
    assert i.top_level_domain(tld_type=TLDType.GENERIC) in TLD[TLDType.GENERIC]
    assert i.top_level_domain(tld_type=TLDType.COUNTRY) in TLD[TLDType.COUNTRY]
    assert i.top_level_domain(tld_type=TLDType.REGION) in TLD[TLDType.REGION]
    assert i.top_level_domain(tld_type=TLDType.SPECIAL) in TLD[TLDType.SPECIAL]

# Generated at 2022-06-23 21:24:43.084828
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    assert isinstance(Internet().top_level_domain(), str)


# Generated at 2022-06-23 21:24:46.295144
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    internet = Internet()
    for layer in Layer:
        print(internet.network_protocol(layer=layer))


# Generated at 2022-06-23 21:24:48.732064
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    internet = Internet()
    assert internet.http_method() in ['GET', 'POST', 'PUT', 'DELETE', 'PATCH']


# Generated at 2022-06-23 21:24:52.090892
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    internet = Internet()
    assert internet.top_level_domain() in TLD[TLDType.ALL]
    assert internet.top_level_domain(tld_type=TLDType.GENERIC) in TLD[TLDType.GENERIC]

# Generated at 2022-06-23 21:24:53.896835
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    """Test method http_method of class Internet"""
    provider = Internet()
    assert provider.http_method() in HTTP_METHODS


# Generated at 2022-06-23 21:24:56.254892
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    network = Internet(seed=123)
    ip = network.ip_v6_object()
    assert ip == IPv6Address('1914:95c1:7b57:41e9:7ed6:6595:5718:34f4')

# Generated at 2022-06-23 21:24:59.239487
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    from mimesis.enums import HTTP_METHODS
    from mimesis.providers.internet import Internet
    internet = Internet()
    method = internet.http_method()
    assert method in HTTP_METHODS



# Generated at 2022-06-23 21:25:01.606065
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    user_agent = Internet().user_agent()
    assert isinstance(user_agent, str)
    assert len(user_agent) > 0


# Generated at 2022-06-23 21:25:05.944626
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    """
    Test of method ip_v4 of class Internet
    """
    internet = Internet()
    assert(internet.ip_v4().split(".")[0] in ['0', '10', '127', '172', '192', '224', '240', '255'])


# Generated at 2022-06-23 21:25:07.378354
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    internet = Internet()
    msg = internet.http_status_message()
    assert msg in HTTP_STATUS_MSGS


# Generated at 2022-06-23 21:25:09.111317
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    assert Internet().content_type() is not None


# Generated at 2022-06-23 21:25:13.622498
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from pprint import pprint
    internet = Internet()
    pprint(internet.stock_image())
    pprint(internet.stock_image('500', '800'))
    print(internet.stock_image(writable=True))
    pprint(internet.stock_image(keywords=['nature', 'city']))

# Generated at 2022-06-23 21:25:15.419493
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():

    ip_v6 = Internet().ip_v6()
    print("IPV6: {}".format(ip_v6))


# Generated at 2022-06-23 21:25:18.130888
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    _internet = Internet()

    # """
    #    1. Check if the result of method ip_v4_object is instance of
    #    class IPv4Address.
    # """

    assert isinstance(_internet.ip_v4_object(), IPv4Address)

# Generated at 2022-06-23 21:25:21.279808
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    """Unit test for method emoji of class Internet."""
    obj = Internet()

    result = obj.emoji()
    assert isinstance(result, str)



# Generated at 2022-06-23 21:25:23.690863
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    provider = Internet('en')
    meth = provider.http_method()
    assert meth in HTTP_METHODS


# Generated at 2022-06-23 21:25:27.480111
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    msg = ('Method http_status_code of class Internet must return '
           'HTTP status code in HTTP Status Codes.')
    internet = Internet()
    for _ in range(100):
        status = internet.http_status_code()
        assert status in HTTP_STATUS_CODES, msg


# Generated at 2022-06-23 21:25:32.200367
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    internet = Internet()
    url = internet.image_placeholder()
    assert isinstance(url, str)
    assert url == 'http://placehold.it/1920x1080'

# Generated at 2022-06-23 21:25:36.872885
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    # We are testing for IPv4Address object
    ip_v4_object = IPv4Address(3232235521)
    actual_result = Internet().ip_v4_object()
    assert actual_result == ip_v4_object


# Generated at 2022-06-23 21:25:44.591336
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    from mimesis.enums import MACAddressFormat
    mac_format = MACAddressFormat.COLON_HEX
    internet = Internet()
    # Test common case
    mac_address = internet.mac_address(mac_format=mac_format)
    assert len(mac_address.split(mac_format.value)) == 6, \
        "Number of bytes in MAC address is not 6"
    # Test all bytes are in HEX
    assert all(c in '0123456789ABCDEF'
               for c in mac_address.replace(mac_format.value, "")), \
        "MAC address is not in HEX format"

# Generated at 2022-06-23 21:25:46.442788
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    provider = Internet()
    print(provider.hashtags())

# Generated at 2022-06-23 21:25:57.433985
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    from mimesis.enums import OS

# Generated at 2022-06-23 21:26:04.595498
# Unit test for constructor of class Internet
def test_Internet():
    from mimesis.enums import Gender
    from mimesis.providers.address import Address
    from mimesis.providers.name import Name
    from mimesis.providers.person import Person
    from mimesis.providers.profile import Profile
    from mimesis.providers.user import User

    r = Internet('en', seed=42)

    a = Address('en', seed=42)
    n = Name('en', seed=42)
    p = Person('en', seed=42)
    pr = Profile('en', seed=42)
    u = User('en', seed=42)

    assert r.country_code() == 'GB'

# Generated at 2022-06-23 21:26:09.736842
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    internet = Internet()
    for i in range(10):
        print(internet.http_method())
# Expected output:
#    PUT
#    PUT
#    GET
#    PUT
#    PUT
#    PUT
#    DELETE
#    DELETE
#    PUT
#    POST


# Generated at 2022-06-23 21:26:13.327048
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    from mimesis.enums import MimeType

    from . import INTERNET

    assert INTERNET.http_status_message() in HTTP_STATUS_MSGS
    assert INTERNET.http_status_message() in HTTP_STATUS_MSGS

# Generated at 2022-06-23 21:26:20.885494
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    """Unit test for method network_protocol of class Internet."""
    provider = Internet()
    assert provider.network_protocol(layer=Layer.LINK) in NETWORK_PROTOCOLS[Layer.LINK]
    assert provider.network_protocol(layer=Layer.TRANSPORT) in NETWORK_PROTOCOLS[Layer.TRANSPORT]
    assert provider.network_protocol(layer=Layer.APPLICATION) in NETWORK_PROTOCOLS[Layer.APPLICATION]

# Generated at 2022-06-23 21:26:25.484685
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    inter = Internet()
    output = str(inter.user_agent())
    assert "Mozilla/5.0" in output
    assert "Gecko" in output
    assert "Chrome" in output
    assert "Firefox" in output
    assert "Macintosh" in output
    assert "Windows" in output
    assert "Android" in output


# Generated at 2022-06-23 21:26:26.255480
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    assert Internet().emoji() in EMOJI

# Generated at 2022-06-23 21:26:27.825702
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    r = Internet()
    print(r.http_status_code())

# Generated at 2022-06-23 21:26:31.675091
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    """Unit test for http_status_code()."""
    from mimesis.providers.internet import Internet
    intn = Internet()
    assert 400 <= intn.http_status_code() <= 499



# Generated at 2022-06-23 21:26:34.106896
# Unit test for method port of class Internet
def test_Internet_port():
    internet = Internet()
    ports = []
    for _ in range(10):
        ports.append(internet.port(internet.PortRange.STANDARD))
    assert ports == [53974, 47679, 34381, 4560, 3550, 7933, 3341, 3372, 4147, 4988]



# Generated at 2022-06-23 21:26:36.535520
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    internet = Internet()
    content_type = internet.content_type()
    assert content_type == 'Content-Type: application/json'


# Generated at 2022-06-23 21:26:38.095678
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    content_type = Internet.content_type()
    assert isinstance(content_type, str) == True


# Generated at 2022-06-23 21:26:43.772588
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    # Test 1: All
    print(Internet('en').top_level_domain())

    # Test 2: Countries
    print(Internet('en').top_level_domain(TLDType.COUNTRY_CODE))

    # Test 3: Generic
    print(Internet('en').top_level_domain(TLDType.GENERIC))

# Generated at 2022-06-23 21:26:44.437789
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    pass

# Generated at 2022-06-23 21:26:48.183191
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    from mimesis.enums import TLDType
    from mimesis.providers.internet import Internet

    internet = Internet()
    home_page = internet.home_page(TLDType.COUNTRY)

    print(home_page)

# Generated at 2022-06-23 21:26:49.598696
# Unit test for constructor of class Internet
def test_Internet():
    t = Internet()
    assert t.seed is not None


# Generated at 2022-06-23 21:26:59.385150
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    import unittest

    class Test_Layer(unittest.TestCase):

        def testNetworkProtocol(self):
            from mimesis.enums import Layer
            from mimesis.enums import PortRange

            internet = Internet()
            self.assertEqual(len(internet.network_protocol(Layer.TRANSPORT)), 4)
            self.assertEqual(len(internet.network_protocol(Layer.PRESENTATION)), 6)
            self.assertEqual(len(internet.network_protocol(Layer.APPLICATION)), 16)
            self.assertEqual(len(internet.network_protocol(Layer.SESSION)), 6)
            self.assertEqual(len(internet.network_protocol(Layer.DATA_LINK)), 11)

# Generated at 2022-06-23 21:27:00.527156
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    assert Internet.ip_v4()

# Generated at 2022-06-23 21:27:06.061529
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    """Unit test for method home_page of class Internet."""
    from mimesis.enums import TLDType
    from mimesis.providers.internet import Internet
    internet = Internet('en')
    tld_type = TLDType.INTERNATIONAL
    for _ in range(10):
        result = internet.home_page()
        assert internet.top_level_domain() == result
        assert internet.top_level_domain(tld_type=tld_type) == result

# Generated at 2022-06-23 21:27:08.816500
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    int = Internet()
    bool = False
    for _ in range(100):
        if int.http_status_code() == 200:
            bool = True
    assert bool

# Generated at 2022-06-23 21:27:11.377663
# Unit test for constructor of class Internet
def test_Internet():
    internet = Internet()
    assert internet.port() in range(*PortRange.ALL.value)
    assert internet.http_method() in HTTP_METHODS
    assert internet.http_status_code() in HTTP_STATUS_CODES
    assert internet.http_status_message() in HTTP_STATUS_MSGS
    assert internet.mac_address()


if __name__ == '__main__':
    test_Internet()

# Generated at 2022-06-23 21:27:14.499550
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    s = Internet()
    assert s.http_status_message() not in (None, "", " ")
    assert isinstance(s.http_status_message(), str)


# Generated at 2022-06-23 21:27:16.698902
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    internet = Internet()
    a = internet.mac_address()
    print(a)
    print('wjy')


# Generated at 2022-06-23 21:27:23.836551
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    from mimesis.enums import Hashtag

    internet = Internet('en')
    hashtags = internet.hashtags()
    assert isinstance(hashtags, list)
    assert all([str(tag).startswith('#') for tag in hashtags])
    assert len(hashtags) == 4

    hashtag1 = internet.hashtags(Hashtag.INTEGER)
    assert isinstance(hashtag1, str)
    assert hashtag1.startswith('#')

    hashtag2 = internet.hashtags(Hashtag.NONE)
    assert isinstance(hashtag2, str)
    assert hashtag2.startswith('#')


# Generated at 2022-06-23 21:27:26.101701
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    internet = Internet()
    assert isinstance(internet.ip_v6_object(), IPv6Address)

# Generated at 2022-06-23 21:27:30.297182
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    internet = Internet()
    addressing_format = internet.ip_v6()
    address_parts = addressing_format.split(":")
    address_parts_range = 255
    assert len(address_parts) == 8
    for x in range(8):
        assert int(address_parts[x], 16) < address_parts_range


# Generated at 2022-06-23 21:27:38.489944
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    """Unit test for method top_level_domain of class Internet."""

    provider = Internet()

    tld = provider.top_level_domain()

    assert isinstance(tld, str)
    assert tld.startswith('.')
    assert len(tld) > 1

    tld = provider.top_level_domain(tld_type=TLDType.TLD)
    assert isinstance(tld, str)
    assert tld.startswith('.')
    assert len(tld) > 1


# Generated at 2022-06-23 21:27:42.985180
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    assert internet.stock_image(keywords=['black-and-white'])
    assert internet.stock_image(writable=True)
    assert internet.stock_image(keywords=[
        'black-and-white'], writable=True)


if __name__ == '__main__':
    test_Internet_stock_image()

# Generated at 2022-06-23 21:27:44.512454
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    assert_method_returns_something(Internet.http_status_message)

# Generated at 2022-06-23 21:27:47.362627
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    from mimesis.enums import MimeType

    inter = Internet()
    assert inter.content_type(
        mime_type=MimeType.IMAGE,
    ) == 'Content-Type: image/jpeg'



# Generated at 2022-06-23 21:27:55.422516
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    from mimesis.numbers import Number
    from mimesis.internet import Internet
    from sys import maxsize
    from ipaddress import IPv4Address
    seed = maxsize
    i = Internet(seed=seed)
    number = Number(seed=seed)
    r_1 = i.ip_v4_object()
    r_2 = IPv4Address(number.between(0, 4294967295))
    assert r_1 == r_2


# Generated at 2022-06-23 21:28:03.434094
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    # 1. Arrange
    import random
    import string
    import unittest

    random.seed(1337)

# Generated at 2022-06-23 21:28:07.099094
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    _internet = Internet()
    results = _internet.hashtags(2)
    assert len(results) == 2


# Generated at 2022-06-23 21:28:14.949761
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    # Unit test for method user_agent of class Internet
    from mimesis.enums import OS, Platform

    user_agent = Internet().user_agent()
    assert user_agent
    assert isinstance(user_agent, str)

    user_agent = Internet(platform=Platform.ANDROID).user_agent()
    assert user_agent.startswith('Dalvik')

    user_agent = Internet(os=OS.WINDOWS).user_agent()
    assert user_agent.startswith('Windows')

    user_agent = Internet(platform=Platform.LINUX).user_agent()
    assert user_agent.startswith('Linux')

# Generated at 2022-06-23 21:28:18.041606
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    from mimesis.enums import USER_AGENT

    from . import Internet

    internet = Internet(UserAgents=USER_AGENT.Firefox)

    assert internet.user_agent() == 'Mozilla/5.0 (Windows NT 6.2; Win64; x64; rv:16.0) Gecko/16.0 Firefox/16.0'

# Generated at 2022-06-23 21:28:24.594598
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    """Test method hashtags.

    :return: None
    """
    from mimesis.enums import Hashtag

    i = Internet()
    assert i.hashtags()
    assert i.hashtags(quantity=4)
    assert i.hashtags(Hashtag.TECHNOLOGY)
    assert i.hashtags(quantity=4, category=Hashtag.TECHNOLOGY)

# Generated at 2022-06-23 21:28:26.535028
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    obj = Internet()
    content = obj.content_type()

    assert(content == "Content-Type: application/json")

# Generated at 2022-06-23 21:28:28.166824
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    test = Internet()
    assert isinstance(test.ip_v6_object(), IPv6Address)


# Generated at 2022-06-23 21:28:30.680225
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    code = Internet().http_status_code()
    status_code_collection = [
        200, 302, 401, 404
    ]
    assert code in status_code_collection


# Generated at 2022-06-23 21:28:32.241818
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    status_message = "200 OK"
    assert Internet().http_status_message() == status_message


# Generated at 2022-06-23 21:28:33.387973
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    internet = Internet()
    print(internet.top_level_domain())

# Generated at 2022-06-23 21:28:38.301073
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    temp = Internet(seed=12345)
    print(temp.ip_v6_object())
    print(temp.ip_v6_object())
    print(temp.ip_v6_object())
    print(temp.ip_v6_object())
    print(temp.ip_v6_object())
    print(temp.ip_v6_object())
    print(temp.ip_v6_object())
    print(temp.ip_v6_object())
    print(temp.ip_v6_object())

# Generated at 2022-06-23 21:28:40.831002
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    print('Entering test_Internet_http_status_message')
    provider = Internet()
    results = provider.http_status_message()
    print(results)


# Generated at 2022-06-23 21:28:43.189044
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    for _ in range(10):
        internet = Internet()
        result = internet.hashtags()
        assert result != ''


# Generated at 2022-06-23 21:28:45.290017
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    print(Internet().http_status_message())
# Output: "200 OK"


# Generated at 2022-06-23 21:28:47.712144
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    internet = Internet()
    assert isinstance(internet.image_placeholder(width=100, height=100), str)


# Generated at 2022-06-23 21:28:54.336765
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    assert (Internet.emoji() in EMOJI)
    assert (Internet.hashtags() in HASHTAGS)
    assert (Internet.http_method() in HTTP_METHODS)
    assert (Internet.http_status_code() in HTTP_STATUS_CODES)
    assert (Internet.http_status_message() in HTTP_STATUS_MSGS)
    assert (Internet.top_level_domain() in TLD)
    assert (Internet.user_agent() in USER_AGENTS)

# Generated at 2022-06-23 21:29:00.612082
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    num = internet.random.randint(10)
    temp_file_name = "test_file_{}.jpg".format(num)
    image = internet.stock_image(writable=True)
    with open(temp_file_name, 'wb') as f:
        f.write(image)
    try:
        assert os.path.isfile(temp_file_name)
        os.remove(temp_file_name)
    except AssertionError as e:
        raise e
    except Exception as e:
        raise e
    else:
        pass

# Generated at 2022-06-23 21:29:02.188876
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    internet = Internet()
    assert isinstance(internet.emoji(), str)

# Generated at 2022-06-23 21:29:05.480231
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    for _ in range(10):
        ip = Internet().ip_v6_object()
        if not isinstance (ip, IPv6Address):
            break
    else:
        raise AssertionError('Ожидали, что вернётся IPv6Address.')

# Generated at 2022-06-23 21:29:09.573478
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    from mimesis.enums import Layer
    from mimesis.providers.internet import Internet

    i = Internet(seed=42)
    for _ in range(10):
        assert i.emoji() in i.EMOJI

# Generated at 2022-06-23 21:29:11.377904
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    internet = Internet()
    emoji = internet.emoji()
    assert isinstance(emoji, str)
    assert bool(emoji)

# Generated at 2022-06-23 21:29:14.120800
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    internet = Internet()
    result = internet.user_agent()
    assert len(result) > 0


# Generated at 2022-06-23 21:29:17.686173
# Unit test for method http_method of class Internet
def test_Internet_http_method():
	from mimesis.enums import HTTP_METHODS
	from mimesis.providers.internet import Internet
	it = Internet()
	method = it.http_method()
	print (method)
	assert method in HTTP_METHODS


# Generated at 2022-06-23 21:29:19.042886
# Unit test for constructor of class Internet
def test_Internet():
    internet = Internet()
    assert internet.seed is not None


# Generated at 2022-06-23 21:29:20.727457
# Unit test for constructor of class Internet
def test_Internet():
    """Unit test for constructor of class Internet."""
    Internet()


# Generated at 2022-06-23 21:29:26.435074
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    data = [
        Layer.APPLICATION,
        Layer.PRESENTATION,
        Layer.SESSION,
        Layer.TRANSPORT,
        Layer.NETWORK,
        Layer.DATA_LINK,
        Layer.PHYSICAL,
    ]
    i = Internet()
    for item in data:
        assert i.network_protocol(item) != ''

# Generated at 2022-06-23 21:29:30.434185
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    from mimesis.providers.internet import Internet
    from ipaddress import IPv6Address

    ip_v6_object = IPv6Address(Internet().ip_v6())
    assert isinstance(ip_v6_object, IPv6Address)

# Generated at 2022-06-23 21:29:34.509054
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    provider = Internet()
    result = provider.mac_address()
    assert re.match(r'^([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})$', result)


# Generated at 2022-06-23 21:29:37.246284
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    """Test for method top_level_domain of class Internet."""
    internet = Internet()
    assert internet.top_level_domain() == ".net"


# Generated at 2022-06-23 21:29:39.222484
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    internetprovider = Internet()
    assert len(internetprovider.user_agent())> 0


# Generated at 2022-06-23 21:29:43.344199
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    # Test 1: proxy = None
    # Test 2: proxy = 'localhost'

    internet = Internet(proxy=None)
    assert isinstance(internet.http_status_message(), str)

    internet = Internet(proxy='localhost')
    assert isinstance(internet.http_status_message(), str)
