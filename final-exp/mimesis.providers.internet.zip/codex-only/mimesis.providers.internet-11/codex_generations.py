

# Generated at 2022-06-23 21:19:44.702571
# Unit test for constructor of class Internet
def test_Internet():
    """Create Internet object."""
    assert Internet()



# Generated at 2022-06-23 21:19:46.650685
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    internet = Internet()
    assert internet.http_status_message() in HTTP_STATUS_MSGS


# Generated at 2022-06-23 21:19:49.935451
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    from mimesis.enums import TLDType
    _internet = Internet('en')
    _internet.top_level_domain(TLDType.GENERIC)


# Generated at 2022-06-23 21:19:51.863586
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    internet = Internet()
    assert isinstance(internet.ip_v4_object(), IPv4Address)


# Generated at 2022-06-23 21:19:54.658307
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    provider = Internet()
    ipv6 = provider.ip_v6_object()
    assert ipv6 is not None
    assert isinstance(ipv6, IPv6Address)

# Generated at 2022-06-23 21:20:00.162473
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    print(Internet().content_type())
    print(Internet().content_type(MimeType.TEXT))
    print(Internet().content_type(MimeType.AUDIO))
    print(Internet().content_type(MimeType.IMAGE))


# Generated at 2022-06-23 21:20:02.161992
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    print(Internet().ip_v4_object())
    assert IPv4Address(Internet().ip_v4_object()
                       ).is_global == True


# Generated at 2022-06-23 21:20:04.162328
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    """Test for method ip_v4 of class Internet"""
    assert Internet().ip_v4() == '223.216.221.183'


# Generated at 2022-06-23 21:20:05.955935
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    internet = Internet()
    ip = internet.ip_v4_object()
    assert type(ip) is IPv4Address


# Generated at 2022-06-23 21:20:15.172359
# Unit test for constructor of class Internet
def test_Internet():
    from mimesis.enums import TLDType
    from mimesis.meta import generator_meta
    from mimesis.providers.internet import Internet
    
    generated_meta = generator_meta(Internet)
    assert generated_meta == Internet.Meta

    internet = Internet(seed=1)
    assert internet
    assert internet._MAX_IPV4 == 4294967295
    assert internet._MAX_IPV6 == 340282366920938463463374607431768211455
    assert internet._seed == 1

    internet = Internet(seed=42)
    assert internet._seed == 42



# Generated at 2022-06-23 21:20:17.938891
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    print("Test method content_type of class Internet")
    internet = Internet()
    print(internet.content_type())


# Generated at 2022-06-23 21:20:29.450032
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    from mimesis.enums import OperatingSystem
    
    internet = Internet()
    
    user_agent = internet.user_agent()
    
    assert isinstance(user_agent, str)
    assert "Mozilla" not in user_agent
    assert "AppleWebKit" not in user_agent
    assert "Opera" not in user_agent
    assert "Windows" not in user_agent
    assert "Macintosh" not in user_agent
    assert "Linux" not in user_agent
    
    user_agent = internet.user_agent(
        os=OperatingSystem.WINDOWS,
    )
    
    assert "Windows" in user_agent
    assert "MSIE" in user_agent
    
    user_agent = internet.user_agent(
        os=OperatingSystem.MACOS,
    )
    

# Generated at 2022-06-23 21:20:41.433040
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    from mimesis.enums import TLDType
    from mimesis.providers.internet import Internet
    intern = Internet()
    # tld_type is TLDType.ILLEGAL
    tld_type = TLDType.ILLEGAL
    answer = intern.top_level_domain(tld_type)
    expected = 'com'
    assert answer == expected
    # tld_type is TLDType.COUNTRY_CODE
    tld_type = TLDType.COUNTRY_CODE
    answer = intern.top_level_domain(tld_type)
    expected = 'cn'
    assert answer == expected
    # tld_type is TLDType.GENERIC
    tld_type = TLDType.GENERIC

# Generated at 2022-06-23 21:20:43.886290
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    i = Internet()
    ip = i.ip_v6_object()
    print("Address: " + str(ip))


# Generated at 2022-06-23 21:20:48.912021
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    from mimesis.enums import Specification
    from mimesis.enums import OS
    from mimesis.enums import Browser

    # random user agents
    print(Internet('en').user_agent())
    print(Internet('ru').user_agent())
    print(Internet('uk').user_agent())
    print(Internet('en').user_agent(os=OS.WINDOWS))
    print(Internet('en').user_agent(os=OS.ANDROID))
    print(Internet('en').user_agent(os=OS.MAC_OS))
    print(Internet('en').user_agent(os=OS.IOS))
    print(Internet('en').user_agent(os=OS.LINUX))
    print(Internet('en').user_agent(os=OS.FIREFOX_OS))

# Generated at 2022-06-23 21:20:50.487449
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    """Test for method ip_v4 of class Internet."""
    internet = Internet()
    assert internet.ip_v4()

# Generated at 2022-06-23 21:20:52.062730
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    internet = Internet()
    result = internet.top_level_domain()

    assert result in TLD['ALL']

# Generated at 2022-06-23 21:20:53.614859
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    internet = Internet()
    assert isinstance(internet.http_status_message(), str)



# Generated at 2022-06-23 21:20:59.738681
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    # Test without list of keywords
    url = Internet().stock_image()
    assert isinstance(url, str)
    assert url.startswith('https://source.unsplash.com')
    assert '.' in url
    assert '1920x1080' in url

    # Test with list of keywords
    url = Internet().stock_image(keywords=('dog', 'pet'))
    assert isinstance(url, str)
    assert url.startswith('https://source.unsplash.com')
    assert '.' in url
    assert '1920x1080' in url
    assert 'dog,pet' in url
    assert 'https://source.unsplash.com/1920x1080?dog,pet' == url

# Generated at 2022-06-23 21:21:01.897181
# Unit test for constructor of class Internet
def test_Internet():
    internet = Internet()
    assert internet.port() in range(0, 65535)

# Generated at 2022-06-23 21:21:05.749310
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    ip_v6 = Internet.ip_v6()
    ip_v6_object = Internet.ip_v6_object()
    assert type(ip_v6) == str
    assert type(ip_v6_object) == IPv6Address
    assert str(ip_v6_object) == ip_v6


# Generated at 2022-06-23 21:21:10.484043
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    provider = Internet()
    image_link = provider.stock_image(1920, 1080, ['nature'])
    assert image_link == "https://source.unsplash.com/1920x1080?nature", "Incorrect image link"

# Generated at 2022-06-23 21:21:16.007232
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    internet_provider = Internet()
    test_ip = internet_provider.ip_v6()
    test_ip_address = IPv6Address(test_ip)
    assert test_ip_address.compressed == test_ip
    assert isinstance(test_ip_address, IPv6Address)

# Generated at 2022-06-23 21:21:18.650849
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    from mimesis.enums import Locale
    from mimesis.typing import Seed

    mime = Internet(seed=Seed(13))

    assert mime.emoji() == ":heart:"


# Generated at 2022-06-23 21:21:21.183793
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    internet = Internet()
    ip = internet.ip_v4_object()
    assert isinstance(ip, IPv4Address) and ip.is_private

# Generated at 2022-06-23 21:21:24.715440
# Unit test for method port of class Internet
def test_Internet_port():
    port_range = PortRange.OFFICIAL
    port = Internet().port(port_range=port_range)
    assert port in range(port_range.value[0], port_range.value[1])

# Generated at 2022-06-23 21:21:26.307862
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():

    internet = Internet(seed = 1)
    assert (internet.ip_v4() == '112.255.92.230')

# Generated at 2022-06-23 21:21:28.236656
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    result = Internet.http_method()
    assert (result in HTTP_METHODS)

# Generated at 2022-06-23 21:21:32.731758
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    print("Executing unit test for method ip_v4 of class Internet")
    for _ in range(10):
        ipv4 = Internet().ip_v4()
        print(ipv4)
        assert isinstance(ipv4, str)


# Generated at 2022-06-23 21:21:35.857305
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    internet = Internet()
    print(internet.content_type())
    print(internet.content_type(MimeType.TEXT))
    print(internet.content_type(MimeType.APPLICATION))


# Generated at 2022-06-23 21:21:45.234787
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    internet = Internet()
    assert internet.network_protocol()
    assert internet.network_protocol(layer=Layer.TRANSPORT)
    assert internet.network_protocol(layer=Layer.APPLICATION)
    assert internet.network_protocol(layer=Layer.PRESENTATION)
    assert internet.network_protocol(layer=Layer.SESSION)
    assert internet.network_protocol(layer=Layer.DATA_LINK)
    assert internet.network_protocol(layer=Layer.PHYSICAL)


# Generated at 2022-06-23 21:21:46.733573
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    internet = Internet()
    print (internet.ip_v4_object())


# Generated at 2022-06-23 21:21:49.537538
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    internet = Internet()
    img = internet.image_placeholder(width=300, height=100)
    assert img == "http://placehold.it/300x100"


# Generated at 2022-06-23 21:21:52.716123
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    i = Internet()
    ip = i.ip_v4()
    assert isinstance(ip, str)
    assert ip == "19.121.223.58"


# Generated at 2022-06-23 21:21:54.203401
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    internet = Internet()
    print(internet.http_status_code())

# Generated at 2022-06-23 21:21:56.528426
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    internet = Internet('en')
    result = internet.mac_address()
    assert len(result) == 17


# Generated at 2022-06-23 21:22:02.571227
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    from mimesis.enums import TLDType
    from mimesis.exceptions import NonEnumerableError

    internet = Internet("en")
    tld_type = TLDType.CC
    tld = internet.top_level_domain(tld_type)
    print(tld)
    print(".")
    try:
        tld = internet.top_level_domain("TLD")
    except NonEnumerableError as e:
        print("Nope")

    # Unit test for method image_placeholder of class Internet

# Generated at 2022-06-23 21:22:05.037285
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    provider = Internet()
    for _ in range(1000):
        assert 200 <= provider.http_status_code() <= 599



# Generated at 2022-06-23 21:22:09.031107
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    internet = Internet()
    ip = internet.ip_v4_object()
    assert isinstance(ip, IPv4Address)
    ip_valid = '127.0.0.1'
    assert ip.compressed == ip_valid


# Generated at 2022-06-23 21:22:13.465629
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    '''
    Parameters
    ----------
    self : object
        Internet object
    '''
    internet = Internet()
    assert isinstance(internet.ip_v6(), str)
    assert len(internet.ip_v6()) == 39

# Generated at 2022-06-23 21:22:16.331611
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    from mimesis.generators.internet import Internet

    internet = Internet()
    assert int(internet.http_status_code()) in range(100, 599)



# Generated at 2022-06-23 21:22:28.856128
# Unit test for method port of class Internet
def test_Internet_port():
    from mimesis.enums import PortRange
    from mimesis.providers.internet import Internet
    internet = Internet()
    LOW = PortRange.LOW.value
    HIGH = PortRange.HIGH.value
    LOW_ALL = PortRange.LOW_ALL.value
    HIGH_ALL = PortRange.HIGH_ALL.value
    ALL = PortRange.ALL.value
    LOW_REGISTERED = PortRange.LOW_REGISTERED.value
    HIGH_REGISTERED = PortRange.HIGH_REGISTERED.value
    REGISTERED = PortRange.REGISTERED.value
    LOW_DYNAMIC = PortRange.LOW_DYNAMIC.value
    HIGH_DYNAMIC = PortRange.HIGH_DYNAMIC.value
    DYNAMIC = PortRange.DYNAM

# Generated at 2022-06-23 21:22:35.458030
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    print('Internet.user_agent')
    inter = Internet(seed=100)
    assert inter.user_agent() == 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-Us; rv:1.9.2.14) Gecko/20110218 Firefox/3.6.14'


# Generated at 2022-06-23 21:22:40.176611
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    internet = Internet()
    assert isinstance(internet.mac_address(), str)

if __name__ == "__main__":
    Internet.top_level_domain(tld_type=TLDType.COUNTRY)

# Generated at 2022-06-23 21:22:41.863925
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    internet = Internet()
    method_result = internet.http_status_code()
    expected_result = random.choice(HTTP_STATUS_CODES)
    assert method_result == expected_result


# Generated at 2022-06-23 21:22:44.920523
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    ip = Internet().ip_v4_object()
    print(ip)


# Generated at 2022-06-23 21:22:49.979302
# Unit test for method port of class Internet
def test_Internet_port():
    """Test for method port of class Internet.

    Test enum object PortRange.
    """
    from mimesis.enums import PortRange

    i = Internet()

    port_sys = i.port(PortRange.SYSTEM)
    assert 0 < port_sys < 1024

    port_well = i.port(PortRange.WELL_KNOWN)
    assert 1024 <= port_well < 49152

    port_reg = i.port(PortRange.REGISTERED)
    assert 49152 <= port_reg < 65536

    port_priv = i.port(PortRange.PRIVATE)
    assert 49152 <= port_priv < 65536

    port_dyn = i.port(PortRange.DYNAMIC_PRIVATE)
    assert 49152 <= port_dyn < 65536


# Generated at 2022-06-23 21:22:51.819773
# Unit test for constructor of class Internet
def test_Internet():
    I = Internet(seed=12345)
    assert I
    assert I.__class__.__name__ == 'Internet'
    assert I._seed == 12345


# Generated at 2022-06-23 21:22:59.992726
# Unit test for method port of class Internet
def test_Internet_port():
    from mimesis.enums import PortRange
    from mimesis.exceptions import NonEnumerableError
    from mimesis.providers.internet import Internet

    internet = Internet()

    # PortRange.ALL, min 1 max 65535
    value = internet.port(PortRange.ALL)
    assert 1 <= value <= 65535

    # PortRange.REGISTERED, min 1 max 49151
    value = internet.port(PortRange.REGISTERED)
    assert 1 <= value <= 49151

    # PortRange.WELL_KNOWN, min 1 max 1023
    value = internet.port(PortRange.WELL_KNOWN)
    assert 1 <= value <= 1023

    # PortRange.LIMITED, min 49152 max 65535
    value = internet.port(PortRange.LIMITED)
    assert 49152 <= value <= 655

# Generated at 2022-06-23 21:23:02.080979
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    tst = Internet()
    while True:
        tst.stock_image()

# Generated at 2022-06-23 21:23:05.186612
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    ip = Internet(seed=42).ip_v6_object()
    assert ip == IPv6Address('2001:db8:85a3:8d3:1319:8a2e:370:7348')

# Generated at 2022-06-23 21:23:06.786633
# Unit test for method port of class Internet
def test_Internet_port():
    i = Internet(seed=123)

    assert i.port() == 2159
    assert i.port(PortRange.PORT_21) == 21



# Generated at 2022-06-23 21:23:11.757419
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():

    from copy import copy

    tester = Internet('en')
    ip_v4_object_result = tester.ip_v4_object()
    assert not isinstance(ip_v4_object_result, (str, dict)), \
        "The method 'ip_v4_object' does not return an int"
    assert len(str(ip_v4_object_result)) != 0, \
        "The method 'ip_v4_object' returns an int of the wrong length"
    assert copy(ip_v4_object_result) == ip_v4_object_result, \
        "The method 'ip_v4_object' does not return a valid int"

# Generated at 2022-06-23 21:23:15.175115
# Unit test for method port of class Internet
def test_Internet_port():
    """Test for method port of class Internet."""
    print("Inside test_Internet_port()")
    provider = Internet()
    test_port = provider.port()
    print("test_port is", test_port)
    assert type(test_port) is int

# Test for method content_type of class Internet

# Generated at 2022-06-23 21:23:17.485715
# Unit test for method port of class Internet
def test_Internet_port():
    myobj = Internet()
    assert myobj.port(PortRange.PRIVILEGED) in range(*PortRange.PRIVILEGED.value)


# Generated at 2022-06-23 21:23:19.402236
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    internet = Internet()
    result = internet.ip_v6()
    print(result)


# Generated at 2022-06-23 21:23:21.450635
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    internet = Internet()
    result = internet.ip_v4_object()
    assert isinstance(result, IPv4Address)


# Generated at 2022-06-23 21:23:26.714622
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    internet = Internet()
    assert internet.http_status_message() in HTTP_STATUS_MSGS
    assert internet.http_status_message() in HTTP_STATUS_MSGS
    assert internet.http_status_message() in HTTP_STATUS_MSGS


# Generated at 2022-06-23 21:23:29.608499
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    inet = Internet()
    ipv4 = inet.ip_v4_object()
    assert isinstance(ipv4, IPv4Address)

# Generated at 2022-06-23 21:23:32.303990
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    internet = Internet(seed=100)
    assert isinstance(internet.ip_v4_object(), IPv4Address)


# Generated at 2022-06-23 21:23:35.835779
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    """Test ip_v6 method of class Internet."""
    obj = Internet('en')
    result = obj.ip_v6()
    assert ('::' not in result) and ('.' not in result) and ('-' not in result)


# Generated at 2022-06-23 21:23:41.593570
# Unit test for method port of class Internet
def test_Internet_port():
    obj = Internet()
    assert obj.port() in range(65535)

    assert obj.port(port_range=PortRange.COMMON) in range(1, 1024)
    assert obj.port(port_range=PortRange.REGISTERED) in range(1024, 49151)
    assert obj.port(port_range=PortRange.DYNAMIC) in range(49152, 65535)

    assert obj.port(port_range=PortRange.WELL_KNOWN) in range(1, 1023)
    assert obj.port(port_range=PortRange.PRIVATE) in range(49152, 65535)

# Generated at 2022-06-23 21:23:44.614508
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    a = Internet(seed=1)
    emoji = a.emoji()
    assert emoji not in ['', ' '], "Internet emoji is empty!"

if __name__ == '__main__':
    test_Internet_emoji()

# Generated at 2022-06-23 21:23:52.208885
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    from mimesis.enums import Layer
    from mimesis.providers.internet import Internet
    internet = Internet('en')

    ip = internet.ip_v6()

    assert len(ip.split(':')) == 8

    ip = internet.ip_v6()

    assert len(ip.split(':')) == 8

    ip = internet.ip_v6()

    assert len(ip.split(':')) == 8

# Generated at 2022-06-23 21:24:01.158796
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    # test_Internet_content_type_default
    data = Internet().content_type()
    check_data_type(data, type(str()))
    # test_Internet_content_type_param_mime_type_exist_MimeType_TEXT
    data = Internet().content_type(mime_type=MimeType.TEXT)
    check_data_type(data, type(str()))
    # test_Internet_content_type_param_mime_type_exist
    data = Internet().content_type(mime_type=MimeType.AUDIO)
    check_data_type(data, type(str()))



# Generated at 2022-06-23 21:24:02.621413
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    obj = Internet()
    result = obj.ip_v4_object()
    assert isinstance(result, IPv4Address)


# Generated at 2022-06-23 21:24:04.521391
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    for i in range(50):
        print(Internet('es').http_method())


# Generated at 2022-06-23 21:24:08.895781
# Unit test for method port of class Internet
def test_Internet_port():
    provider = Internet()
    assert provider.port(port_range=PortRange.EPHEMERAL) in range(49152, 65535)

# Generated at 2022-06-23 21:24:11.294848
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    url = Internet.image_placeholder()
    print(url)

if __name__ == '__main__':
    test_Internet_image_placeholder()

# Generated at 2022-06-23 21:24:13.950958
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    """Test for method http_status_code"""
    internet_instance = Internet()
    rv = internet_instance.http_status_code()
    assert rv in [200, 403, 500]


# Generated at 2022-06-23 21:24:17.004721
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    internet = Internet()
    # The method has only one variant of calling, because it does not include
    # any arguments
    assert internet.http_status_code() in HTTP_STATUS_CODES


# Generated at 2022-06-23 21:24:18.151083
# Unit test for constructor of class Internet
def test_Internet():
    Internet(seed=1)

# Generated at 2022-06-23 21:24:20.096580
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    result = Internet().ip_v6()
    print("IPv6:", result)
    assert type(result) == str

# Generated at 2022-06-23 21:24:22.278560
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    internet = Internet()
    value = internet.user_agent()
    assert isinstance(value, str)



# Generated at 2022-06-23 21:24:24.421717
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    provider = Internet()
    out = provider.hashtags()
    assert isinstance(out, list)

# Generated at 2022-06-23 21:24:28.507011
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    '''case 1: expected 200'''
    res = Internet().http_status_code()
    assert res == 200
    '''case 2: expected http_status_code from [200, 300)'''
    res = Internet().http_status_code()
    assert res >= 200 and res < 300
    
    

# Generated at 2022-06-23 21:24:32.929057
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    """Test home_page method of class Internet."""
    from mimesis.providers.internet import Internet

    internet = Internet()
    links = [internet.home_page() for _ in range(100)]
    assert 'https://' in links[0]
    assert 'https://' in links[-1]

# Generated at 2022-06-23 21:24:34.428812
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    assert isinstance(internet.hashtags(), str)
    assert isinstance(internet.hashtags(quantity=3), list)


# Generated at 2022-06-23 21:24:42.585577
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    random.seed(1912)
    ht1 = Internet().hashtags(quantity=1)
    assert ht1 == '#cupiditate'
    ht2 = Internet().hashtags(quantity=2)
    assert ht2 == ['#officiis', '#quod']
    ht3 = Internet().hashtags(quantity=3)
    assert ht3 == ['#sit', '#sunt', '#rerum']
    ht4 = Internet().hashtags(quantity=4)
    assert ht4 == ['#inventore', '#sunt', '#in', '#quia']
    # Test non-enumerable error
    with pytest.raises(NonEnumerableError):
        assert Internet().hashtags(quantity='discore') == '#ipsa'

# Unit test

# Generated at 2022-06-23 21:24:46.187514
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    internet = Internet()
    status1 = internet.http_status_message()
    status2 = internet.http_status_message()
    assert status1 != status2


# Generated at 2022-06-23 21:24:47.175752
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    internet = Internet()
    result = internet.ip_v6_object()
    assert isinstance(result, IPv6Address)


# Generated at 2022-06-23 21:24:50.398848
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    """Unit test for method mac_address of class Internet."""
    mac = Internet().mac_address()
    first_tag = mac.split(':')[0]
    assert int(first_tag, 16) == 0

# Generated at 2022-06-23 21:24:52.480437
# Unit test for method content_type of class Internet
def test_Internet_content_type():

    internet = Internet(seed=42)
    assert "Content-Type: application/pdf" == internet.content_type()



# Generated at 2022-06-23 21:24:53.821232
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    i = Internet()
    assert i.content_type() is not None

# Generated at 2022-06-23 21:24:55.130551
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    assert len(Internet().ip_v6()) == 39

# Generated at 2022-06-23 21:24:56.415219
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    i = Internet()
    print(i.network_protocol())

# Generated at 2022-06-23 21:24:59.622495
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    """Unit test for method top_level_domain of class Internet."""
    internet = Internet(seed=1234567890)
    expected = 'top_level_domain'
    actual = internet.top_level_domain()
    assert expected == actual

# Generated at 2022-06-23 21:25:03.519315
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    """Unit test for method network_protocol."""
    from mimesis.enums import Layer
    from mimesis.exceptions import NonEnumerableError

    internet = Internet()

    try:
        internet.network_protocol(layer=Layer.APPLICATION)
    except NonEnumerableError as e:
        print(e)


# Generated at 2022-06-23 21:25:04.450822
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    return Internet().stock_image()

# Generated at 2022-06-23 21:25:10.540086
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    print("Testing class Internet method ip_v6_object")
    ip_v6 = Internet(seed=42).ip_v6_object()
    assert ip_v6.compressed == "2001:3c48:cd9d:1fb1:c56d:f52c:8a04:94f3"
    assert ip_v6.exploded == (
        "2001:03c8:0cd9:1fb1:0c56:0f52:08a0:94f3")
    assert ip_v6.exploded == "2001:3c8:cd9:1fb1:c56:f52:8a0:94f3"
    assert ip_v6.is_multicast is False
    assert ip_v6.is_reserved is False
    assert ip_v6.is_

# Generated at 2022-06-23 21:25:19.615583
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    """Unit test for method ip_v6_object of class Internet."""
    from mimesis.providers.internet import Internet
    internet = Internet()

# Generated at 2022-06-23 21:25:28.691338
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    from mimesis.enums import MimeType
    from textx.metamodel import metamodel_from_file
    from textx.model import children_of_type

    meta = metamodel_from_file("./data/mime.tx")
    content = meta.model_from_file("./data/mime/content_type.txt")
    inter = Internet(seed=123)

    for i in range(100):
        mime_type = MimeType(1)
        mime = inter.content_type(mime_type)

        if mime not in children_of_type("ContentType", content):
            raise Exception("Content-Type mismatch!", mime)



# Generated at 2022-06-23 21:25:32.451981
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    internet = Internet()
    data = internet.http_method()
    assert data in ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS', 'HEAD']


# Generated at 2022-06-23 21:25:41.053776
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    """Unit test for method http_method of class Internet."""

    from mimesis.enums import HttpMethod
    from mimesis.typing import Enum

    data = []
    for method in HttpMethod:
        for _ in range(10):
            data.append(Internet().http_method())

    unique_data = list(set(data))

    assert len(unique_data) == len(HttpMethod)
    for method in HttpMethod:
        assert Enum.get_name(method) in unique_data



# Generated at 2022-06-23 21:25:45.213679
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    ip = Internet().ip_v6()
    assert isinstance(ip, str)
    assert ip.count(':') == 7
    assert int(ip.replace(':', ''), 16) <= 340282366920938463463374607431768211455
    assert int(ip.replace(':', ''), 16) >= 0


# Generated at 2022-06-23 21:25:51.330161
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    provider = Internet()

    for _ in range(100):
        result = provider.ip_v6_object()
        assert isinstance(result, IPv6Address)
        assert isinstance(str(result), str)

    provider.seed(0)
    assert str(provider.ip_v6_object()) == 'ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff'

# Generated at 2022-06-23 21:25:52.878133
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    assert Internet.stock_image(width=10) is not None

# Generated at 2022-06-23 21:25:54.413192
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    assert type(Internet().ip_v4_object()) == IPv4Address


# Generated at 2022-06-23 21:26:03.734168
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    internet_provider = Internet()

    assert (internet_provider.network_protocol(Layer.PROCESS)
            in NETWORK_PROTOCOLS[Layer.PROCESS]), \
        'Should be {} type'.format(Layer.PROCESS)

    assert (internet_protocol.network_protocol(Layer.NETWORK)
            in NETWORK_PROTOCOLS[Layer.NETWORK]), \
        'Should be {} type'.format(Layer.NETWORK)

    assert (internet_protocol.network_protocol(Layer.DATA_LINK)
            in NETWORK_PROTOCOLS[Layer.DATA_LINK]), \
        'Should be {} type'.format(Layer.DATA_LINK)


# Generated at 2022-06-23 21:26:07.718010
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    print("Unit test for method content_type of class Internet")
    print('A random HTTP content type: ', Internet().content_type())
    print('A random HTTP content type: ', Internet().content_type(MimeType.IMAGE))
    

# Generated at 2022-06-23 21:26:11.950538
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    from mimesis.providers.internet import Internet
    from mimesis.enums import PortRange
    from mimesis.enums import Protocol
    from ipaddress import ip_address
    i=Internet()
    ip=i.ip_v4_object()
    assert isinstance(ip,ip_address)
    assert ip.__str__() == i.ip_v4()
    assert ip.version == 4


# Generated at 2022-06-23 21:26:14.403168
# Unit test for method port of class Internet
def test_Internet_port():
    ports = [Internet().port(port_range=p) for _ in range(100)]
    assert all([0 <= p <= 65535 for p in ports])

# Generated at 2022-06-23 21:26:24.315880
# Unit test for method network_protocol of class Internet

# Generated at 2022-06-23 21:26:26.829859
# Unit test for method port of class Internet
def test_Internet_port():
    provider = Internet()
    port = provider.port()
    assert type(port) == int
    assert 0 <= port <= 65535

# Generated at 2022-06-23 21:26:29.697733
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    """Unit test for method network_protocol of class Internet."""
    obj = Internet()
    assert obj.network_protocol() != ''

# Generated at 2022-06-23 21:26:39.459735
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from mimesis.data import SHUTTER_STOCK_KEYWORDS
    from mimesis.providers.internet import Internet
    from mimesis.enums import PortRange
    from mimesis.builtins import hash_code
    from mimesis.builtins import FileSystem
    import os
    import datetime
    import json
    # get random IP
    ip = Internet().ip_v4(with_port=True, port_range=PortRange.BUFFERED_WELL_KNOWN_PORTS)

    # generate test records

# Generated at 2022-06-23 21:26:42.701414
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    internet = Internet()
    print(test_Internet_ip_v4_object.__name__ + ":", internet.ip_v4())


# Generated at 2022-06-23 21:26:44.725361
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    i = Internet()
    assert i.http_status_code() in HTTP_STATUS_CODES

# Generated at 2022-06-23 21:26:52.616332
# Unit test for method port of class Internet
def test_Internet_port():
    internet = Internet()
    port_range = PortRange.ALL
    port = internet.port(port_range)
    assert port_range.value[0] <= port <= port_range.value[1]
    port_range = PortRange.SYSTEM
    port = internet.port(port_range)
    assert port_range.value[0] <= port <= port_range.value[1]
    port_range = PortRange.REGISTERED
    port = internet.port(port_range)
    assert port_range.value[0] <= port <= port_range.value[1]
    port_range = PortRange.DYNAMIC_OR_PRIVATE
    port = internet.port(port_range)
    assert port_range.value[0] <= port <= port_range.value[1]



# Generated at 2022-06-23 21:26:57.419008
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    internet = Internet()
    result = internet.ip_v6()
    ip_v6_object = internet.ip_v6_object()
    assert result == str(ip_v6_object)
    assert result != internet.ip_v6()
    assert ip_v6_object.version == 6

# Generated at 2022-06-23 21:27:02.382012
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    """ Unit test for Internet class. """
    obj = Internet()

    assert(obj.hashtags() == '#cry')

    assert(len(obj.hashtags(10)) == 10)
    assert(len(obj.hashtags(3)) == 3)
    assert(len(obj.hashtags(1)) == 1)

# Generated at 2022-06-23 21:27:04.873317
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    internet = Internet("ro_RO")
    print(internet.user_agent())
    internet = Internet("ru_RU")
    print(internet.user_agent())
    internet = Internet("en_GB")
    print(internet.user_agent())


# Generated at 2022-06-23 21:27:06.399931
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    t = Internet()
    print(t.ip_v6_object())


# Generated at 2022-06-23 21:27:08.217122
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    obj = Internet()
    assert isinstance(obj.emoji(), str)


# Generated at 2022-06-23 21:27:10.016231
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    internet = Internet()
    assert internet.ip_v6() != None

# Generated at 2022-06-23 21:27:12.356324
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    internet = Internet()
    content_type = internet.content_type()
    assert content_type == 'Content-Type: application/json'


# Generated at 2022-06-23 21:27:14.272556
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    internet = Internet()
    result = internet.home_page()
    print(result)


# Generated at 2022-06-23 21:27:16.442160
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    obj = Internet()
    assert(str(obj.ip_v6_object()) == obj.ip_v6())

# Generated at 2022-06-23 21:27:18.621556
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    """Test method http_method of class Internet."""
    internet = Internet()
    assert internet.http_method() in HTTP_METHODS


# Generated at 2022-06-23 21:27:19.904736
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    internet = Internet()
    i = internet.mac_address()


# Generated at 2022-06-23 21:27:27.407757
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    """Test method Internet.stock_image
    
    :return: True if success, False otherwise
    """
    print('Testing method Internet.stock_image...', end='\r')
    from PIL import Image
    import tempfile

    internet = Internet('en', seed=0)
    img = internet.stock_image()
    with tempfile.NamedTemporaryFile(suffix='.jpg', delete=False) as temp:
        temp.write(img)
    
    try:
        image = Image.open(temp.name)
    except OSError:
        return False
    else:
        return True

# Generated at 2022-06-23 21:27:36.247513
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    """Test for image method of class Internet."""
    from mimesis.enums import ImageSize
    from mimesis.typing import Arbitrary

    internet = Internet()
    placeholder = internet.image_placeholder()
    assert placeholder == 'http://placehold.it/1920x1080'

    width: Arbitrary[int] = ImageSize.HD.value[0]
    height: Arbitrary[int] = ImageSize.HD.value[1]
    assert internet.image_placeholder(width, height) == \
        'http://placehold.it/1920x1080'

# Generated at 2022-06-23 21:27:38.391368
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    provider = Internet()
    ip = provider.ip_v4()
    assert len(ip.split('.')) == 4

# Generated at 2022-06-23 21:27:40.240308
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    internet = Internet()
    internet.image_placeholder()
    internet.image_placeholder(width=100, height=100)

# Generated at 2022-06-23 21:27:47.623938
# Unit test for method port of class Internet
def test_Internet_port():
    internet = Internet()
    for _ in range(100000):
        port = internet.port(PortRange.ALL)
        assert port <= 65535
        assert port >= 0
    for _ in range(100000):
        port = internet.port(PortRange.SYS_RESERVED)
        assert port < 1024
        assert port >= 0
    for _ in range(100000):
        port = internet.port(PortRange.DYN_RESERVED)
        assert port < 49151
        assert port >= 49152
    for _ in range(100000):
        port = internet.port(PortRange.UNREGISTERED)
        assert port >= 1024
        assert port < 49152
    for _ in range(100000):
        port = internet.port()
        assert port <= 65535
        assert port >= 0

# Generated at 2022-06-23 21:27:49.759634
# Unit test for constructor of class Internet
def test_Internet():
    """Test constructor of class Internet."""
    assert Internet()



# Generated at 2022-06-23 21:28:00.760845
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    assert internet.stock_image() == 'https://source.unsplash.com/1920x1080?'
    assert internet.stock_image(keywords=['cat']) == 'https://source.unsplash.com/1920x1080?cat'
    assert internet.stock_image(keywords=['cat', 'dog']) == 'https://source.unsplash.com/1920x1080?cat,dog'
    assert internet.stock_image(keywords=['cat', 'dog', 'sky']) == 'https://source.unsplash.com/1920x1080?cat,dog,sky'
    assert internet.stock_image(keywords=['cat', 'dog', 'sky', 'python']) == 'https://source.unsplash.com/1920x1080?cat,dog,sky,python'

# Generated at 2022-06-23 21:28:07.055108
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    provider = Internet()
    assert isinstance(provider.stock_image(), str)
    assert isinstance(provider.stock_image(), str)
    assert isinstance(provider.stock_image(width=300, height=200), str)
    assert isinstance(provider.stock_image(width=300, height=200), str)

# Generated at 2022-06-23 21:28:08.497369
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    internet = Internet()

    res = internet.ip_v4_object()
    assert isinstance(res, IPv4Address)

# Generated at 2022-06-23 21:28:10.458705
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    a = Internet()
    assert a.http_status_message() == '200 OK'


# Generated at 2022-06-23 21:28:13.717741
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    # Test a random IP address
    for _ in range(100):
        ip = IPv4Address(Internet().random.randint(0, Internet._MAX_IPV4))
        assert Internet().ip_v4_object() == ip


# Generated at 2022-06-23 21:28:14.926947
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    from mimesis.providers.internet import Internet
    assert type(Internet().http_method()) == str

# Generated at 2022-06-23 21:28:17.267944
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    """Test method hashtags of class Internet."""
    rand = Internet()
    assert rand.hashtags(quantity=-65536) == []
    assert rand.hashtags(quantity=0) == []
    for _ in range(10):
        assert isinstance(rand.hashtags(quantity=5), list)

# Generated at 2022-06-23 21:28:18.539160
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    pass


# Generated at 2022-06-23 21:28:29.791511
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    from mimesis.enums import Layer
    internet = Internet()

# Generated at 2022-06-23 21:28:35.752207
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    import sys
    import os
    import inspect
    import ipaddress

    current_dir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
    parent_dir = os.path.dirname(current_dir)
    sys.path.insert(0, parent_dir)
    from mimesis.providers.internet import _Internet as Internet

    s = Internet(seed=42)

    assert isinstance(s.ip_v4_object(), ipaddress.IPv4Address)



# Generated at 2022-06-23 21:28:37.733771
# Unit test for constructor of class Internet
def test_Internet():
    internet = Internet(seed=0)
    assert internet.__class__.__name__ == 'Internet'


# Generated at 2022-06-23 21:28:38.727516
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    Internet().image_placeholder()

# Generated at 2022-06-23 21:28:41.508891
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    for i in range(100):
        print(Internet().home_page())


# Generated at 2022-06-23 21:28:49.278742
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol(): # Test if each range of layer of OSI model is valid
    case = [[Internet('it-IT').network_protocol(layer=l) for _ in range(0, 10000)] for l in list(Layer)]
    for i in range(0, 7): 
        for protocol in case[i]:
            assert len(protocol) >= 2 or len(protocol) <= 4
    for i in range(7, len(case)):
        for protocol in case[i]:
            assert len(protocol) >= 2 or len(protocol) <= 4


# Generated at 2022-06-23 21:28:52.098207
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    # Arrange
    internet = Internet()

    # Act
    result = internet.emoji()

    # Assert
    assert result in EMOJI


# Generated at 2022-06-23 21:28:53.701811
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    internet = Internet()
    msg = internet.http_status_message()
    assert msg in HTTP_STATUS_MSGS


# Generated at 2022-06-23 21:28:56.607972
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    """Unit test for method ip_v6 of class Internet."""
    internet = Internet()
    ipv6_address = internet.ip_v6()
    assert isinstance(ipv6_address, str)
    assert ipv6_address.count(':') == 7


# Generated at 2022-06-23 21:29:02.982952
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    internet = Internet()
    content_type = internet.content_type()
    print(content_type)
    assert content_type == 'Content-Type: text/html' or content_type == 'Content-Type: text/plain' or content_type == 'Content-Type: application/json' or content_type == 'Content-Type: application/xml' or content_type == 'Content-Type: application/pdf' or content_type == 'Content-Type: image/gif' or content_type == 'Content-Type: image/jpeg' or content_type == 'Content-Type: image/png'


# Generated at 2022-06-23 21:29:04.960459
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    ip_v4_object = Internet()
    assert isinstance(ip_v4_object, Internet)


# Generated at 2022-06-23 21:29:07.200182
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    x = Internet()
    c = x.emoji()
    print(c)


# Generated at 2022-06-23 21:29:09.522713
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    assert Internet().image_placeholder() == 'http://placehold.it/1920x1080'


# Generated at 2022-06-23 21:29:20.348617
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    # test number 1
    internet1 = Internet(seed=1)
    mac_address = internet1.mac_address()

    assert mac_address == '00:16:3e:25:e1:2e'

    # test number 2
    internet2 = Internet(seed=1)
    mac_address = internet2.mac_address()

    assert mac_address == '00:16:3e:25:e1:2e'

    # test number 3
    internet3 = Internet(seed=1000)
    mac_address = internet3.mac_address()

    assert mac_address == '00:16:3e:4d:a0:6f'

    # test number 4
    internet4 = Internet(seed=1000)
    mac_address = internet4.mac_address()


# Generated at 2022-06-23 21:29:29.480092
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    """Unit test for method image_placeholder of class Internet."""
    internet = Internet(random_state=2)
    # Tested function
    assert internet.image_placeholder(width=1920, height=1080) == 'http://placehold.it/1920x1080'
    # Test for fix width and random height
    assert internet.image_placeholder(width=1920) == 'http://placehold.it/1920x567'
    # Test for fix height and random width
    assert internet.image_placeholder(height=1080) == 'http://placehold.it/2188x1080'
    # Test for random width and height
    assert internet.image_placeholder() == 'http://placehold.it/1724x746'

# Generated at 2022-06-23 21:29:33.217703
# Unit test for constructor of class Internet
def test_Internet():
    try:
        # Test for constructor of class Internet
        internet = Internet()
        print("Internet() -> ", internet)
    except:
        print("Error while creating instance of class Internet")
        print("-" * 20)


# Generated at 2022-06-23 21:29:35.120440
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    content_type = Internet().content_type()
    assert 'Content-Type' in content_type

# Generated at 2022-06-23 21:29:37.506351
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    a = Internet()
    result = a.emoji()
    print(result)
    assert result != ''


# Generated at 2022-06-23 21:29:42.456903
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():

    url1 = Internet.image_placeholder(width=200, height=200)
    assert url1 == 'http://placehold.it/200x200'

    url2 = Internet.image_placeholder(width='100%', height='100%')
    assert url2 == 'http://placehold.it/100%x100%'

# Generated at 2022-06-23 21:29:44.579700
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    assert Internet.image_placeholder(
        width=1920, height=1080) == \
        'http://placehold.it/1920x1080'
