

# Generated at 2022-06-23 21:19:50.509111
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    # создаём объект класса Internet
    internet = Internet('ru')
    # генерируем хэштеги
    hashtags = internet.hashtags(quantity=3)
    # выводим их значения на экран
    print(hashtags)

test_Internet_hashtags()

# Generated at 2022-06-23 21:19:52.958025
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    provider = Internet()
    status = provider.http_status_code()
    assert isinstance(status, int) and 200 <= status <= 599

# Generated at 2022-06-23 21:19:54.798323
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    x = Internet()

    obj = x.ip_v6_object()

    assert isinstance(obj, IPv6Address)

# Generated at 2022-06-23 21:20:00.495998
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    t1 = Internet.image_placeholder()
    t2 = Internet.image_placeholder(width=800, height=600)
    assert t1 != t2, "Error in Internet.image_placeholder()"
    print(t1)
    print(t2)
test_Internet_image_placeholder()

# Generated at 2022-06-23 21:20:02.951392
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    obj = Internet()
    result = obj.ip_v6_object()
    assert isinstance(result, IPv6Address)


# Generated at 2022-06-23 21:20:03.859619
# Unit test for method port of class Internet
def test_Internet_port():
    assert Internet().port(PortRange.ALL) < 65535

# Generated at 2022-06-23 21:20:07.258931
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    data = Internet()
    assert data.ip_v4() in ['19.121.223.58', '19.121.223.58:8000']
    assert data.ip_v4(with_port=True) in ['19.121.223.58', '19.121.223.58:8000']


# Generated at 2022-06-23 21:20:09.941112
# Unit test for method port of class Internet
def test_Internet_port():
    item = Internet()
    assert isinstance(item.port(PortRange.USER), int) is True

# Generated at 2022-06-23 21:20:13.630902
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    # Create a instance of the Internet class
    internet = Internet()
    # Create a valid domain
    domain = internet.home_page()
    # print out the verified value
    print(domain)
    assert isinstance(domain, str)


# Generated at 2022-06-23 21:20:19.352586
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    from mimesis.enums import DomainType
    from mimesis.providers.networks import Network

    i = Internet()
    for _ in range(100):
        domain = i.top_level_domain(DomainType.FREE)
        assert domain in Network.DOMAINS_FREE

    i = Internet()
    for _ in range(100):
        domain = i.top_level_domain(DomainType.OPEN)
        assert domain in Network.DOMAINS_OPEN

    i = Internet()
    for _ in range(100):
        domain = i.top_level_domain(DomainType.RESTRICTED)
        assert domain in Network.DOMAINS_RESTRICTED

# Generated at 2022-06-23 21:20:23.585838
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    import android
    droid = android.Android()
    droid.makeToast("Hello, bambino.")
    internet = Internet('ru')
    a = internet.user_agent()
    droid.makeToast(a)



# Generated at 2022-06-23 21:20:28.513844
# Unit test for method port of class Internet
def test_Internet_port():
    from mimesis.enums import PortRange
    from mimesis.providers.internet import Internet
    from mimesis.exceptions import NonEnumerableError

    internet = Internet()

    for port_range in PortRange:
        res = internet.port(port_range=port_range)
        assert isinstance(res, int), 'Result is not integer'

# Generated at 2022-06-23 21:20:32.961461
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    """
    This was used to test the image_placeholder method of Internet class
    """
    internet = Internet()
    print(internet.image_placeholder())
    print(internet.image_placeholder(200, 300))


# Generated at 2022-06-23 21:20:37.726002
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    hashtags = internet.hashtags()
    assert len(hashtags) == 4

    hashtags = internet.hashtags(3)
    assert len(hashtags) == 3
    for item in hashtags:
        assert item.startswith('#')
        assert len(item) > 1

# Generated at 2022-06-23 21:20:39.211212
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    provider = Internet()
    assert provider.stock_image(writable=True) is not None

# Generated at 2022-06-23 21:20:40.402308
# Unit test for method content_type of class Internet
def test_Internet_content_type():

    i = Internet()

    result = i.content_type()
    assert result in i.content_type(MimeType.IMAGE)



# Generated at 2022-06-23 21:20:41.907004
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    assert isinstance(internet.hashtags(), str)
    assert type(internet.hashtags(quantity=2)) == list
    assert type(internet.hashtags(quantity=5)) == list

# Generated at 2022-06-23 21:20:43.436664
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    internet = Internet()
    ip = internet.ip_v4()

# Generated at 2022-06-23 21:20:44.167382
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    assert Internet().emoji() in EMOJI


# Generated at 2022-06-23 21:20:46.215573
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    l = []
    for _ in range(100):
        a = Internet().home_page()
        l.append(a)
        assert a not in l

# Generated at 2022-06-23 21:20:49.723323
# Unit test for method port of class Internet
def test_Internet_port():
  assert Internet('en').port(PortRange.ALL) > 0
  assert Internet('en').port(PortRange.UNPRIVILEGED) < 1024
  assert Internet('en').port(PortRange.WELL_KNOWN) < 1024
  assert Internet('en').port(PortRange.SYSTEM) < 512

# Generated at 2022-06-23 21:20:52.644258
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    # Instantiate provider
    internet = Internet()
    # Get a random network protocol
    data = internet.network_protocol(Layer.APPLICATION)
    # Check data type
    assert isinstance(data, str) is True


# Generated at 2022-06-23 21:20:58.429227
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    from mimesis.data import HTTP_USER_AGENTS, NETWORK_PROTOCOLS
    from mimesis.enums import Layer, PortRange, TLDType
    from mimesis.providers.internet import Internet
    from mimesis.providers.file import File

    provider = Internet()
    assert isinstance(provider, Internet)
    assert isinstance(provider.seed, int)
    assert isinstance(provider.__file, File)
    assert isinstance(provider._MAX_IPV4, int)
    assert isinstance(provider._MAX_IPV6, int)
    assert HTTP_USER_AGENTS
    assert isinstance(provider.content_type(), str)
    assert isinstance(provider.http_status_message(), str)

# Generated at 2022-06-23 21:21:02.760671
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    # http_method()
    a = Internet()
    assert a.http_method() in [
        'GET', 'POST', 'PUT', 'DELETE',
        'HEAD', 'PATCH', 'OPTIONS',
    ]



# Generated at 2022-06-23 21:21:04.407181
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    """Unit test for method content_type of class Internet."""
    internet = Internet()
#    print(internet.content_type())


# Generated at 2022-06-23 21:21:15.269088
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    internet = Internet()
    res1 = internet.top_level_domain()
    res2 = internet.top_level_domain(tld_type=TLDType.COUNTRY)
    res3 = internet.top_level_domain(tld_type=TLDType.GENERIC)
    res4 = internet.top_level_domain(tld_type=TLDType.ALL)
    assert isinstance(res1, str)
    assert isinstance(res2, str)
    assert isinstance(res3, str)
    assert isinstance(res4, str)
    assert len(res1) > 1
    assert len(res2) > 1
    assert len(res3) > 1
    assert len(res4) > 1

# Generated at 2022-06-23 21:21:17.269414
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    ip = Internet().ip_v4(False)
    assert isinstance(ip, str)


# Generated at 2022-06-23 21:21:20.095135
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    internet = Internet(locale='en')
    data = internet.home_page()
    print(data)


# Generated at 2022-06-23 21:21:23.659219
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    def test():
        placehold_string = mimesis.Internet().image_placeholder()
        return placehold_string

    # sample result: 'http://placehold.it/1920x1080'
    print(test())


# Generated at 2022-06-23 21:21:26.528570
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    seed = 42
    internet = Internet(seed=seed)
    expected = 408
    actual = internet.http_status_code()
    assert expected == actual
    return True


# Generated at 2022-06-23 21:21:32.787621
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    from mimesis.providers.internet import Internet
    from mimesis.enums import HTTPStatus
    import random
    print("\nTesting Internet.http_status_message():")
    internet = Internet()
    random.seed(5)
    assert internet.status_code() in HTTPStatus.CODES
test_Internet_http_status_message()


# Generated at 2022-06-23 21:21:33.250345
# Unit test for constructor of class Internet
def test_Internet():
    Internet()

# Generated at 2022-06-23 21:21:36.565782
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    _validate_data_provider_method(
        data_provider_class=Internet,
        method_name='http_status_message',
        enum_class=HTTP_STATUS_MSGS,
    )



# Generated at 2022-06-23 21:21:45.404187
# Unit test for constructor of class Internet
def test_Internet():
    inet = Internet()
    print(inet.hashtags())
    print(inet.image_placeholder())
    # print(inet.stock_image())
    print(inet.mac_address())
    print(inet.user_agent())
    print(inet.ip_v4())
    print(inet.ip_v4(with_port=True))
    print(inet.ip_v6())
    print(inet.top_level_domain())

# Main function
if __name__ == '__main__':
    test_Internet()

# Generated at 2022-06-23 21:21:51.766311
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    # Create a generator of the Internet class
    internet = Internet()
    # Get HTTP method number 1
    result = internet.http_method()
    # Check that the HTTP method is not empty
    assert result != ''
    # Check that the HTTP method is not None
    assert result is not None
    # Check that the HTTP method is a string
    assert type(result) is str


# Generated at 2022-06-23 21:21:53.344713
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    internet = Internet()
    http_method = internet.http_method()
    assert http_method in HTTP_METHODS


# Generated at 2022-06-23 21:21:56.528867
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    from mimesis.enums import HTTPStatus
    from mimesis.providers.internet import Internet
    result = Internet().http_status_code
    assert result in HTTPStatus.all_values


# Generated at 2022-06-23 21:22:00.369519
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    from mimesis.enums import ImageFormat
    from mimesis.providers.internet import Internet

    internet = Internet()

    for _ in range(100):
        url = internet.image_placeholder()
        assert url.startswith('http://placehold.it/')

        url = internet.image_placeholder(width='140', height='140')
        assert url.startswith('http://placehold.it/')

        url = internet.image_placeholder(
            width=140, height=140, imageformat=ImageFormat.PNG,
        )
        assert url.startswith('http://placehold.it/')



# Generated at 2022-06-23 21:22:04.598207
# Unit test for method port of class Internet
def test_Internet_port():
    internet = Internet()
    port_num = internet.port()
    assert 0 <= port_num <= 65535

# Generated at 2022-06-23 21:22:16.621307
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet(seed=12345)
    res = internet.stock_image(width=400, height=300)
    assert res == 'https://source.unsplash.com/400x300?'
    res = internet.stock_image(400, 300, ['random'])
    assert res == 'https://source.unsplash.com/400x300?random'
    res = internet.stock_image(400, 300, ['random', 'nature'])
    assert res == 'https://source.unsplash.com/400x300?random,nature'
    res = internet.stock_image(400, 300, ['random', 'nature'], writable=True)
    assert isinstance(res, bytes)
    res = internet.stock_image(400, 300, ['random', 'nature'], writable=False)

# Generated at 2022-06-23 21:22:24.733644
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    # Initialize a instance of Internet class
    f = Internet()

    ip = f.ip_v4()

    assert type(ip) == str

    # Test case: IP should be in range between 0.0.0.0 and 255.255.255.255
    assert f.ip_v4_object() >= IPv4Address(0)
    assert f.ip_v4_object() <= IPv4Address(4294967295)

# Generated at 2022-06-23 21:22:25.814622
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    internet = Internet()
    for _ in range(100):
        assert internet.emoji() in EMOJI

# Generated at 2022-06-23 21:22:31.203906
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from unittest import TestCase
    from mimesis import Internet

    class TestInternet(TestCase):
        def setUp(self):
            self.web = Internet(seed=4242)

        def test_stock_image_width_height(self):
            result = self.web.stock_image(width='800', height='800')
            self.assertEqual(
                result,
                'https://source.unsplash.com/800x800?',
            )

        def test_stock_image_keywords(self):
            result = self.web.stock_image(width='800', height='800', keywords=['test', 'example'])
            self.assertEqual(
                result,
                'https://source.unsplash.com/800x800?test,example',
            )


# Generated at 2022-06-23 21:22:41.732086
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():

    from mimesis.internet import Internet
    i = Internet()
    try:
        # Get image on default parameters
        image_link = i.stock_image()
        print(image_link)
        print('[ OK ] Stock image: {}'.format(image_link))

        # Get image with custom keywords and size
        image_bytes = i.stock_image(width=500,
                                    height=500,
                                    keywords=['nature', 'green', 'tree'],
                                    writable=True)
        print(image_bytes)
        print('[ OK ] Stock image: {}'.format(image_bytes))
    except urllib.error.URLError as e:
        print(e)
        print('[FAIL] Test for Internet.stock_image()')


# Generated at 2022-06-23 21:22:45.986340
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    internet = Internet()
    ip = internet.ip_v6()
    assert ip[0] == '2'

# Generated at 2022-06-23 21:22:46.972999
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    Internet.hashtags()


# Generated at 2022-06-23 21:22:57.853553
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    _internet = Internet(seed=12345)


# Generated at 2022-06-23 21:22:59.458660
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    internet = Internet("en")

    mac_address = internet.mac_address()

    print("MAC address", mac_address)

    assert mac_address is not None


# Generated at 2022-06-23 21:23:02.761457
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    internet = Internet()
    content_type = internet.content_type()
    assert(content_type != None)
    assert(content_type != "")


# Generated at 2022-06-23 21:23:06.685773
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    """Unit test for method ip_v4_object of class Internet."""
    seed = 123
    internet = Internet(seed=seed)

    ip = internet.ip_v4_object()

    assert str(ip) == '19.121.223.58'


# Generated at 2022-06-23 21:23:07.906862
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    assert Internet().hashtags(4) == ['#love', '#sky', '#nice', '#pretty']

# Generated at 2022-06-23 21:23:09.516257
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    internet = Internet()
    url = internet.image_placeholder(width=1920, height=1080)
    assert url == 'http://placehold.it/1920x1080'

# Generated at 2022-06-23 21:23:11.533576
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    ip_v4_object = Internet().ip_v4_object()
    assert ip_v4_object is not None


# Generated at 2022-06-23 21:23:19.080269
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    mimesis_i = Internet(seed=42)
    # Test URL
    url = mimesis_i.stock_image(width=1920, height=1080)
    assert url == 'https://source.unsplash.com/1920x1080'
    # Test with keywords
    url_keywords = mimesis_i.stock_image(
        width=1920,
        height=1080,
        keywords=['picture', 'gallery'],
    )
    assert (url_keywords ==
            'https://source.unsplash.com/1920x1080?picture,gallery')
    # Test image as bytes
    image_bytes = mimesis_i.stock_image(
        width=1920,
        height=1080,
        writable=True,
    )
    assert isinstance(image_bytes, bytes)

# Generated at 2022-06-23 21:23:24.731792
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    from mimesis.enums import TLDType
    from mimesis.localization import EN

    # Default params
    i = Internet(EN)
    home_page = i.home_page()
    assert isinstance(home_page, str)
    assert len(home_page) > 1

    # With params
    home_page = i.home_page(tld_type=TLDType.GENERIC)
    assert isinstance(home_page, str)
    assert len(home_page) > 1

# Generated at 2022-06-23 21:23:25.670311
# Unit test for method emoji of class Internet
def test_Internet_emoji():
  assert Internet().emoji() != None


# Generated at 2022-06-23 21:23:26.714644
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    Internet.home_page()

# Generated at 2022-06-23 21:23:28.541379
# Unit test for method port of class Internet
def test_Internet_port():
    obj = Internet()
    assert isinstance(obj.port(),int)


# Generated at 2022-06-23 21:23:34.537046
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    import re
    import random
    iteration_amount = random.randint(1, 100)
    internet = Internet(seed=123)
    home_page_template = re.compile(r'^(http://|https://)(\w+)(.info|.com|.org)$')
    for i in range(iteration_amount):
        home_page = internet.home_page()
        assert home_page_template.fullmatch(home_page) != None, "home_page must consist of http:// or https://, \
                                                                 a sequence of letters, digits, underscores, and \
                                                                 hyphens, and .info, .com or .org at the end"

# Generated at 2022-06-23 21:23:35.788631
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    internet = Internet()
    assert internet.content_type() == 'Content-Type: image/gif'


# Generated at 2022-06-23 21:23:42.915363
# Unit test for method port of class Internet
def test_Internet_port():
    """Unit test for method port of class Internet."""
    internet = Internet()
    port = internet.port()
    print(port)
    assert port in range(0, 65536)

    port = internet.port(port_range=PortRange.ALL)
    print(port)
    assert port in range(0, 65536)

    port = internet.port(port_range=PortRange.REGISTERED)
    print(port)
    assert port in range(1024, 49151)

    port = internet.port(port_range=PortRange.DYNAMIC_OR_PRIVATE)
    print(port)
    assert port in range(49152, 65536)



# Generated at 2022-06-23 21:23:44.372795
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    provider = Internet()
    ip = provider.ip_v6_object()

    assert isinstance(ip, IPv6Address)


# Generated at 2022-06-23 21:23:47.217792
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    assert isinstance(Internet().ip_v4_object(), IPv4Address)


# Generated at 2022-06-23 21:23:57.409933
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
	import os
	from mimesis.enums import Gender
	from mimesis.builtins import RussiaSpecProvider
	from pathlib import Path
	import shutil
	import tempfile
	
	temp_dir = tempfile.mkdtemp()
	data_dir = os.path.join(temp_dir, "data")
	os.mkdir(data_dir)
	tmp = RussiaSpecProvider(localization='ru')
	print(tmp.full_name(gender=Gender.FEMALE))
	foto_path = os.path.join(data_dir, "foto.jpg")
	url = tmp.internet.stock_image(writable=True)
	with open(foto_path, "wb") as f:
	    f.write(url)
	print(os.listdir(data_dir))


# Generated at 2022-06-23 21:24:00.646030
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    from mimesis.enums import TLDType

    internet_provider = Internet('en')

    home_page = internet_provider.home_page()
    assert isinstance(home_page, str)

    home_page = internet_provider.home_page(TLDType.ALL)
    assert isinstance(home_page, str)


# Generated at 2022-06-23 21:24:07.921872
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    from datetime import datetime
    from mimesis import Person
    from mimesis.enums import Gender
    from mimesis.providers.internet import Internet

    p = Person('en', seed=datetime(year=2019, month=1, day=1))
    print(p.full_name(gender=Gender.FEMALE))
    print(p.full_name(gender=Gender.MALE))
    print(p.username())

    instance = Internet()
    print(instance.ip_v4_object())
    print(instance.ip_v4_object())
    print(instance.ip_v4_object())
    print(instance.ip_v4_object())
    print(instance.ip_v4_object())


# Generated at 2022-06-23 21:24:09.570867
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    intm = Internet()
    assert 'portable_water' in intm.emoji()

# Generated at 2022-06-23 21:24:17.995494
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    holder = Internet()
    assert holder.top_level_domain(tld_type=TLDType.ALL) in TLD['ALL']
    assert holder.top_level_domain(tld_type=TLDType.COUNTRY) in TLD['COUNTRY']
    assert holder.top_level_domain(tld_type=TLDType.GENERIC) in TLD['GENERIC']
    assert holder.top_level_domain(tld_type=TLDType.COUNTRY_CODE) in TLD['COUNTRY_CODE']
    assert holder.top_level_domain(tld_type=TLDType.SPONSOR) in TLD['SPONSOR']
    # Test if the method raises NonEnumerableError if the param is not in TLD
    tld = 'test_tld'


# Generated at 2022-06-23 21:24:19.428469
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    for _ in range(100):
        print(Internet().http_status_code())

# Generated at 2022-06-23 21:24:21.838586
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    internet = Internet(seed=99863)
    assert internet.http_status_code() == 501



# Generated at 2022-06-23 21:24:24.324970
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    provider = Internet('en')
    result = provider.http_method()
    assert provider.http_method() in HTTP_METHODS

# Generated at 2022-06-23 21:24:30.985825
# Unit test for constructor of class Internet
def test_Internet():
    """Test for constructor of Internet."""
    try:
        seed = 'test'
        prov = Internet(seed=seed)
        # print(prov)
        assert isinstance(prov, Internet)
    except Exception as error:
        if isinstance(error, NonEnumerableError):
            print('Got expected error: ', error)
        else:
            raise error

    try:
        prov = Internet(seed='test')
        # print(prov)
        assert isinstance(prov, Internet)
    except Exception as err:
        if isinstance(error, NonEnumerableError):
            print('Got expected error: ', err)
        else:
            raise err



# Generated at 2022-06-23 21:24:32.880470
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    provider = Internet('en')
    res = provider.http_status_code()
    return res


# Generated at 2022-06-23 21:24:37.368802
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    internet = Internet('en')
    # check that all IPs start with "http:"
    assert(internet.ip_v4(with_port=True,
                          port_range=PortRange.HIGH.value)[:5] == 'http:')
    assert(internet.ip_v4(with_port=True,
                          port_range=PortRange.MEDIUM.value)[:5] == 'http:')
    assert(internet.ip_v4(with_port=True,
                          port_range=PortRange.LOW.value)[:5] == 'http:')


# Generated at 2022-06-23 21:24:40.495960
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    inter = Internet()
    ipv4_object = IPv4Address(inter.random.randint(0, inter._MAX_IPV4))
    assert isinstance(ipv4_object, IPv4Address)


# Generated at 2022-06-23 21:24:43.758067
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    # Create a new instance of Internet
    internet = Internet()
    # Generate random HTTP status message
    message = internet.http_status_message()
    # Check the result
    assert message in HTTP_STATUS_MSGS

# Generated at 2022-06-23 21:24:47.324987
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    internet = Internet()
    http_status_code = internet.http_status_code()
    assert http_status_code >= 100 and http_status_code <= 599

# Generated at 2022-06-23 21:24:49.360644
# Unit test for constructor of class Internet
def test_Internet():
    a = Internet()
    assert a.port() in range(0, 65535)

# Generated at 2022-06-23 21:24:51.129507
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    internet = Internet()
    result = internet.mac_address()
    print(result)

# Generated at 2022-06-23 21:24:55.665052
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    obj = Internet()
    top_level_domain = obj.top_level_domain(obj.TLDType.ASCII)
    assert top_level_domain
    #assert isinstance(top_level_domain, str)
    #assert (len(top_level_domain) > 0)



# Generated at 2022-06-23 21:24:59.684614
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    class Internet(BaseProvider):
        class Meta:
            name = 'internet'
    http_status_message_ret = test_internet.http_status_message()
    assert http_status_message_ret in HTTP_STATUS_MSGS
    print(http_status_message_ret)

# Generated at 2022-06-23 21:25:01.689626
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    G = Internet()
    s = G.ip_v6()
    assert s[0] == '2'
    assert len(s) == 39

# Generated at 2022-06-23 21:25:04.276478
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    from ipaddress import IPv6Address
    from mimesis.enums import Layer, PortRange, TLDType
    from mimesis.providers.internet import Internet
    from mimesis.typing import LayerEnum, PortRangeEnum, TLDTypeEnum
    x = Internet('en')
    ipv6 = x.ip_v6_object()
    assert isinstance(ipv6, IPv6Address)



# Generated at 2022-06-23 21:25:06.422595
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    internet = Internet()
    ipv4 = internet.ip_v4()
    assert IPv4Address(ipv4)


# Generated at 2022-06-23 21:25:09.870421
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    assert Internet().http_method() in ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'HEAD', 'OPTIONS', 'CONNECT', 'TRACE']


# Generated at 2022-06-23 21:25:15.915488
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    assert Internet.http_method() == 'GET'
    assert Internet.http_method() == 'PUT'
    assert Internet.http_method() == 'HEAD'
    assert Internet.http_method() == 'POST'
    assert Internet.http_method() == 'PATCH'
    assert Internet.http_method() == 'TRACE'
    assert Internet.http_method() == 'OPTIONS'
    assert Internet.http_method() == 'DELETE'


# Generated at 2022-06-23 21:25:20.428430
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    assert(internet.hashtags() == '#nice')
    assert(len(internet.hashtags(quantity=1)) == 1)
    assert(internet.hashtags(quantity=1)[0] == '#nice')

# Generated at 2022-06-23 21:25:22.596986
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    """Unit test for method user_agent."""
    assert Internet().user_agent() is not ""


# Generated at 2022-06-23 21:25:25.166820
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    internet = Internet()
    http_status_code = internet.http_status_code()

    assert http_status_code in HTTP_STATUS_CODES


# Generated at 2022-06-23 21:25:29.007961
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    internet = Internet()
    width = "1024"
    height = "768"
    url_1 = internet.image_placeholder()
    url_2 = internet.image_placeholder(width, height)
    assert url_1 is not None
    assert url_2 is not None
    assert url_1 != url_2


# Generated at 2022-06-23 21:25:31.961142
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    results = [Internet().ip_v4() for x in range(0, 1000)]
    assert len(set(results)) == 1000


# Generated at 2022-06-23 21:25:36.310682
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    from mimesis.enums import Layer, PortRange, TLDType
    from mimesis.providers.internet import Internet

    internet = Internet('en')
    assert internet.http_status_message() in HTTP_STATUS_MSGS


# Generated at 2022-06-23 21:25:39.869239
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    tld_type = TLDType.COUNTRY_CODE
    tld = Internet().top_level_domain(tld_type=tld_type)
    assert type(tld) == str


# Generated at 2022-06-23 21:25:41.989926
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    stock_img = Internet().stock_image()
    assert 'https://source.unsplash.com' in stock_img


# Generated at 2022-06-23 21:25:45.470839
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    # Create Provider
    provider = Internet(seed=1)

    # Get mac_address
    mac_address = provider.mac_address()

    # Compare mac_address
    assert mac_address == '00:16:3e:25:e7:b1'

# Generated at 2022-06-23 21:25:49.021772
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    internet = Internet('en')
    result = internet.ip_v4(True)
    if isinstance(result,str):
        assert result
    else:
        assert False


# Generated at 2022-06-23 21:25:52.705679
# Unit test for method port of class Internet
def test_Internet_port():
    """Unit test for method port of class Internet."""
    from mimesis.enums import PortRange
    from mimesis.providers.internet import Internet
    from mimesis.exceptions import NonEnumerableError

    internet = Internet('en')
    this = internet.port()
    that = internet.port(PortRange.ALL)
    assert this == that

    this = internet.port(port_range=PortRange.LOW)
    that = internet.port(port_range=PortRange.SYS)
    assert this < 1024 and that < 1024


# Generated at 2022-06-23 21:25:54.236468
# Unit test for method emoji of class Internet
def test_Internet_emoji():
  internet = Internet()
  assert internet.emoji() in EMOJI

# Generated at 2022-06-23 21:25:58.288593
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    import pytest
    print("\n\tTest Internet: ip_v6")
    internet = Internet()
    ip_v6 = internet.ip_v6()
    assert ip_v6 is not None
    assert isinstance(ip_v6, str)
    assert len(ip_v6) == 39
    
if __name__ == '__main__':
   test_Internet_ip_v6()

# Generated at 2022-06-23 21:26:00.177271
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    """Unit test for method content_type of class Internet."""
    assert Internet().content_type() == 'Content-Type: image/png'


# Generated at 2022-06-23 21:26:03.926619
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    internet = Internet()
    for _ in range(1000):
        ipv6 = internet.ip_v6()
        assert isinstance(ipv6, str)
        assert ':' in ipv6

# Generated at 2022-06-23 21:26:08.974434
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():

    t6 = '124.124.124.124'
    t9 = '124.124.124.124:80'

    internet = Internet()

    # Assertion
    assert t6 == internet.ip_v4(with_port=False)
    assert t9 == internet.ip_v4(with_port=True)


# Generated at 2022-06-23 21:26:11.197048
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    """Unit test for method image_placeholder of class Internet."""
    internet = Internet()
    assert internet.image_placeholder().startswith('http://placehold.it/')

# Generated at 2022-06-23 21:26:14.218937
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    """Unit test for method http_status_message of class Internet."""
    net = Internet()
    assert net.http_status_message() in HTTP_STATUS_MSGS


# Generated at 2022-06-23 21:26:17.943763
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    obj = Internet()
    ip = obj.ip_v4_object()
    assert ip is not None
    assert ip.max_prefixlen is 32
    assert ip.version is 4


# Generated at 2022-06-23 21:26:18.695501
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    pass

# Generated at 2022-06-23 21:26:21.730961
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    x = Internet()
    # Count the number of IPv4 Address objects with the same data.
    assert x.ip_v4_object() == x.ip_v4_object()


# Generated at 2022-06-23 21:26:27.389662
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    from mimesis.enums import Hashtag
    from mimesis.exceptions import NonEnumerableError


# Generated at 2022-06-23 21:26:38.260217
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    from mimesis import Internet
    from re import compile
    ia = Internet()
    ua = ia.user_agent()
    print (ua)

# Generated at 2022-06-23 21:26:40.784712
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    """Unit test for method mac_address of class Internet
    """
    internet = Internet()
    mac_address = internet.mac_address()
    assert(mac_address == '00:16:3e:25:e7:b1')



# Generated at 2022-06-23 21:26:44.830127
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    test_obj = Internet()
    test_ip = test_obj.ip_v4_object()
    if isinstance(test_ip, IPv4Address):
        assert True
    else:
        assert False


# Generated at 2022-06-23 21:26:49.702267
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from mimesis.enums import MimeType
    from PIL import Image
    i=Internet()
    picture=i.stock_image()
    print(picture)
    picture=i.stock_image(writable=True)
    print(i.content_type(MimeType.IMAGE) )
    i = Image.open(picture)
    i.show()

# Generated at 2022-06-23 21:26:59.493255
# Unit test for method network_protocol of class Internet

# Generated at 2022-06-23 21:27:02.218558
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    provider = Internet()
    for i in range(0, 3):
        provider.network_protocol()

    provider = Internet(random_state=1)
    for i in range(0, 3):
        provider.network_protocol()

# Generated at 2022-06-23 21:27:03.805130
# Unit test for method emoji of class Internet
def test_Internet_emoji():
   """Method for testing Internet.emoji()"""
   print(Internet().emoji())


# Generated at 2022-06-23 21:27:10.056815
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    i = Internet()
    assert i.hashtags(quantity=10) == '#sad' or i.hashtags(quantity=10) == '#happy' or i.hashtags(quantity=10) == '#sky' or i.hashtags(quantity=10) == '#nice' or i.hashtags(quantity=10) == '#red' or i.hashtags(quantity=10) == '#green' or i.hashtags(quantity=10) == '#love' or i.hashtags(quantity=10) == '#beautiful' or i.hashtags(quantity=10) == '#fun' or i.hashtags(quantity=10) == '#fashion'

# Generated at 2022-06-23 21:27:13.240315
# Unit test for method emoji of class Internet
def test_Internet_emoji():

    # Arrange
    internet = Internet(seed=123456)

    # Act
    emoji = internet.emoji()

    # Assert
    assert emoji == '🧚\u200d♀️'

# Generated at 2022-06-23 21:27:15.104260
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    i = Internet()
    assert len(i.mac_address()) == 17


# Generated at 2022-06-23 21:27:16.947307
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    ip = Internet().ip_v6_object()
    assert isinstance(ip, IPv6Address)


# Generated at 2022-06-23 21:27:22.803570
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    from mimesis.enums import Layer
    internet = Internet()
    protocol = internet.network_protocol(layer=Layer.APPLICATION)
    assert protocol in ('DHCP', 'DNS', 'FTP', 'HTTP', 'IMAP',
                        'MDNS', 'NFS', 'POP3', 'RPC', 'RTP', 'RTSP',
                        'SFTP', 'SIP', 'SNMP', 'SSH', 'TELNET',
                        'TLS', 'XMPP')

# Generated at 2022-06-23 21:27:32.512566
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    from mimesis.enums import Layer, PortRange
    a = Internet()
    b = Internet()
    # assert a.hashtags() != b.hashtags()
    # assert a.http_status_code() != b.http_status_code()
    # assert a.http_status_message() != b.http_status_message()
    assert a.network_protocol(layer=Layer.APPLICATION) != b.network_protocol(layer=Layer.APPLICATION)
    # assert a.port() != b.port()
    # assert a.user_agent() != b.user_agent()
    # assert a.user_agent() != b.user_agent()
    # assert a.ip_v4() != b.ip_v4()
    # assert a.ip_v4() != b.ip_v

# Generated at 2022-06-23 21:27:38.165844
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    """Проверка корректности генерации http-статуса."""
    internet = Internet()
    assert isinstance(internet.http_status_code(), int)



# Generated at 2022-06-23 21:27:40.263912
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    """Test method of Internet class stock image."""
    print("test_Internet_stock_image()")
    i = Internet()
    print("\t" + i.stock_image())

# Generated at 2022-06-23 21:27:43.652955
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    from mimesis.enums import HttpStatusCode as status_code
    message = status_code.OK.value.split(None, 1)[1]
    assert Internet().http_status_message() == message



# Generated at 2022-06-23 21:27:49.895110
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    """Test method http_status_message of class Internet."""
    from mimesis.enums import HTTPStatus
    internet = Internet()
    for _ in range(10):
        print("HTTP status code: %s" %internet.http_status_code())
    for _ in range(10):
        print("HTTP status message: %s" %internet.http_status_message())
    print("HTTP status message 404: %s" %internet.http_status_message(status_code=HTTPStatus.CODE_404))
    print("HTTP status message with code 404: %s" %internet.http_status_message(HTTPStatus.CODE_404))



# Generated at 2022-06-23 21:27:52.018836
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    t = Internet()
    print(t.mac_address())

if __name__ == '__main__':
    test_Internet_mac_address()

# Generated at 2022-06-23 21:27:54.544186
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    """Unit test for method stock_image of class Internet."""
    i = Internet()
    result = i.stock_image(width=12, height=12)
    assert result is not None

# Generated at 2022-06-23 21:28:02.695824
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    seed = str(123456789)
    tlds1 = ['.com', '.biz', '.info', '.name', '.net', '.org']
    tlds2 = ['.aero', '.cat', '.coop', '.edu', '.gov', '.int', '.jobs', '.mil',
             '.museum', '.pro', '.tel', '.travel', '.xxx', '.arpa', '.asia',
             '.buzz', '.dev', '.diamonds', '.eus', '.gal', '.guru', '.juegos',
             '.ninja', '.social', '.tienda', '.uno']

# Generated at 2022-06-23 21:28:06.369352
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    Provider = Internet()
    c = Provider.content_type()
    assert isinstance(c, str)


# Generated at 2022-06-23 21:28:13.023575
# Unit test for constructor of class Internet
def test_Internet():
    from mimesis.enums import Layer
    from mimesis.enums import PortRange
    from mimesis.enums import TLDType
    from mimesis.internet import Internet
    from mimesis.seed import Seed
    from mimesis.types import SeedFlags
    from mimesis.types import SeedFlags as SF
    seed = Seed(SF.INTERNET, SF.FILE)
    internet = Internet(seed=seed)
    # Проверка строковых полей
    assert not internet.content_type() == ""
    assert not internet.http_status_message() == ""
    assert not internet.http_method() == ""
    assert not internet.ip_v4() == ""
    assert not internet.ip_v6() == ""


# Generated at 2022-06-23 21:28:14.686036
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    for i in range(0, 10):
        print('{} => {}'.format(i,Internet(seed=i).http_status_message()))


# Generated at 2022-06-23 21:28:18.051948
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    internet = Internet()
    layer = internet._validate_enum(item = Layer.L4, enum = Layer)
    element = internet.network_protocol(layer)
    element_in_set = element in NETWORK_PROTOCOLS[layer]
    assert element_in_set


# Generated at 2022-06-23 21:28:20.688727
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    print(internet.hashtags(5))

# Generated at 2022-06-23 21:28:26.139847
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    ip = Internet()
    ip_v4 = ip.ip_v4()
    ip_v4_1 = ip.ip_v4(True)
    assert ip_v4 is not None and ip_v4 not in ['', [], (), {}]
    assert ip_v4_1 is not None and ip_v4_1 not in ['', [], (), {}]


# Generated at 2022-06-23 21:28:26.881247
# Unit test for method http_status_message of class Internet

# Generated at 2022-06-23 21:28:35.211561
# Unit test for constructor of class Internet
def test_Internet():
    internet = Internet(seed=12345)
    # print(internet.content_type())
    # print(internet.http_status_message())
    # print(internet.http_status_code())
    # print(internet.http_method())
    # print(internet.ip_v4())
    # print(internet.ip_v4(with_port=True))
    # print(internet.ip_v4(with_port=True, port_range=PortRange.PRIVATE))
    # print(internet.ip_v6())
    # print(internet.mac_address())
    # print(internet.emoji())
    # print(internet.image_placeholder(200))
    # print(internet.stock_image(width=150, height=150))
    # print(internet.hashtags(2))
    # print

# Generated at 2022-06-23 21:28:37.864923
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    i = Internet()
    result = i.hashtags(quantity=4)
    result = i.hashtags(quantity=1)
    print(result)


# Generated at 2022-06-23 21:28:42.910011
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    logger = logging.getLogger()
    logger.name = 'mimesis.Internet.http_status_message'
    logger.setLevel(logging.DEBUG)

    c = logging.StreamHandler()
    c.setLevel(logging.DEBUG)
    logger.addHandler(c)

    internet = Internet()
    logger.debug(internet.http_status_message())
    logger.debug(internet.http_status_message())

# Generated at 2022-06-23 21:28:48.851961
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    from mimesis.enums import Specialization
    from mimesis.providers.internet import Internet
    i = Internet(Specialization.ES)
    ag = i.user_agent()
    assert ag == 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36'

# Generated at 2022-06-23 21:28:50.449673
# Unit test for method port of class Internet
def test_Internet_port():
    generator = Internet()
    port = generator.port()
    assert 0 <= port <= 65535

# Generated at 2022-06-23 21:28:52.709229
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    i = Internet()
    print(i.mac_address()) # 00:16:3e:25:e7:b1



# Generated at 2022-06-23 21:28:54.178973
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    internet = Internet()
    result = internet.ip_v4()
    assert result == internet.ip_v4_object().exploded


# Generated at 2022-06-23 21:29:02.593860
# Unit test for method port of class Internet
def test_Internet_port():
    """Test for method port of class Internet."""
    seed(0)
    internet = Internet()
    port = internet.port(port_range=PortRange.EXP_WELLKNOWN)
    assert port == 80

    internet = Internet()
    port = internet.port(port_range=PortRange.EXP_REGISTRED)
    assert port == 49153

    internet = Internet()
    port = internet.port(port_range=PortRange.DYN_PRIVATE_EPHEMERAL)
    assert port == 49154

    internet = Internet()
    port = internet.port(port_range=PortRange.DYN_PUBLIC_EPHEMERAL)
    assert port == 50000

    internet = Internet()
    port = internet.port(port_range=PortRange.DYN_PUBLIC_EPHEMERAL)

# Generated at 2022-06-23 21:29:07.910225
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    o = Internet()
    assert o.ip_v6() == str(o.ip_v6_object())

    o = Internet(seed=25)
    assert o.ip_v6() == '7701:3ff3:bc69:8bcc:65d0:a2cd:a49:b6cf'



# Generated at 2022-06-23 21:29:10.547085
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    """Unit test for method home_page of class Internet."""
    internet = Internet()
    assert internet.home_page() != None


# Generated at 2022-06-23 21:29:12.765713
# Unit test for method port of class Internet
def test_Internet_port():
    internet = Internet()
    for i in range(0, 10):
        port_range = internet.random.choice(list(PortRange))
        port = internet.port(port_range)
        assert port >= port_range.value[0]
        assert port <= port_range.value[1]



# Generated at 2022-06-23 21:29:13.561502
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    internet = Internet()
    assert internet.emoji() != None


# Generated at 2022-06-23 21:29:17.161894
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    """Unit tests for method ip_v4_object of class Internet."""
    import ipaddress
    assert isinstance(Internet().ip_v4_object(), ipaddress.IPv4Address)

# Unit tests for method ip_v4 of class Internet

# Generated at 2022-06-23 21:29:18.596430
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    print (Internet().ip_v4_object())


# Generated at 2022-06-23 21:29:21.520370
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    """Unit test for method hashtags of class Internet."""
    result = Internet().hashtags(1)
    assert result == '#5w5OGBO'

# Generated at 2022-06-23 21:29:24.095453
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    """Unit test for method stock_image of class Internet"""
    provider = Internet()
    for _ in range(10):
        assert provider.stock_image()

# Generated at 2022-06-23 21:29:24.767820
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    assert Internet().home_page() == 'https://fontir.info'


# Generated at 2022-06-23 21:29:29.859259
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    assert Internet(seed=1).hashtags(quantity=1) == '#all'
    assert Internet(seed=2).hashtags(quantity=1) == '#nice'
    assert Internet(seed=1).hashtags(quantity=3) == ['#all', '#sky', '#nice']
    assert Internet(seed=2).hashtags(quantity=3) == ['#love', '#sky', '#nice']


# Generated at 2022-06-23 21:29:32.312676
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    from mimesis.providers.internet import Internet
    p = Internet()
    assert p.home_page() == 'https://poe/com'

# Generated at 2022-06-23 21:29:33.884950
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    assert Internet().stock_image().startswith('https://source.unsplash.com')

# Generated at 2022-06-23 21:29:36.709370
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    internet = Internet()
    result = internet.image_placeholder()
    assert result == 'http://placehold.it/1920x1080', "Internet.image_placeholder return wrong result"

# Generated at 2022-06-23 21:29:44.821591
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    internet = Internet()
    assert isinstance(internet.content_type(), str)