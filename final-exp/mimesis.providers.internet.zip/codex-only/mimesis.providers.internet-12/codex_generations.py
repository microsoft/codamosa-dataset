

# Generated at 2022-06-23 21:19:44.066526
# Unit test for constructor of class Internet
def test_Internet():
    """Test for constructor of class Internet."""
    provider = Internet()
    assert provider
    assert provider.seed



# Generated at 2022-06-23 21:19:47.458776
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    internet = Internet()
    width = 100
    height = 100
    assert internet.image_placeholder(width=width, height=height) == f'http://placehold.it/{width}x{height}'

# Generated at 2022-06-23 21:19:50.603555
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    internet = Internet()
    status_msg = internet.http_status_message()
    assert (status_msg in HTTP_STATUS_MSGS)


# Generated at 2022-06-23 21:19:52.387458
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    from mimesis.builtins import RussiaSpecProvider
    i = Internet(RussiaSpecProvider)
    print(i.ip_v4())

test_Internet_ip_v4()

# Generated at 2022-06-23 21:19:57.606702
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    from pathlib import Path
    import pytest

    random_dir = Path('tests') / 'random'
    random_dir.mkdir(parents=True, exist_ok=True)

    internet = Internet(random_dir=random_dir)
    p = 'mimesis.IPv6Address'
    with pytest.raises(TypeError) as e:
        internet.ip_v6()
    assert str(e.value) == '{} is not callable'.format(p)

# Generated at 2022-06-23 21:19:59.859995
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
  internet_provider = Internet()
  print(internet_provider.http_status_message())


# Generated at 2022-06-23 21:20:05.160729
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    """Test for method ip_v4_object."""
    from mimesis.enums import TLD
    from mimesis.providers.internet import Internet

    data = [
        TLD.RU,
        TLD.COM,
        TLD.ORG,
        TLD.NET,
    ]
    for i in data:
        Internet().ip_v4_object().version

# Generated at 2022-06-23 21:20:10.112875
# Unit test for method port of class Internet
def test_Internet_port():
    internet = Internet()
    port_communication = internet.port(port_range=PortRange.COMMUNICATION)
    port_client = internet.port(port_range=PortRange.CLIENT)
    port_registry = internet.port(port_range=PortRange.REGISTRY)
    port_system = internet.port(port_range=PortRange.SYSTEM)
    port_all = internet.port()
    return port_communication, port_client, port_registry, port_system, port_all
# print(test_Internet_port())
# print(Internet.port())

# Generated at 2022-06-23 21:20:12.066968
# Unit test for constructor of class Internet
def test_Internet():
    """Unit test for constructor of class Internet."""
    internet = Internet()
    assert internet is not None

# Generated at 2022-06-23 21:20:13.285056
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    provider = Internet()
    for i in range(0, 100):
        assert type(provider.content_type()) == str


# Generated at 2022-06-23 21:20:19.943339
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    """To check if Internet.mac_address() generates a valid mac address."""
    from mimesis.enums import Provider
    from mimesis.utils import Counter
    from mimesis.exceptions import NonEnumerableError

    counter = Counter()
    internet = Internet()

    for _ in range(10000):
        result = internet.mac_address()

        counter[result] += 1
        assert isinstance(result, str)
        assert len(result) == 17

    # Test exceptions

# Generated at 2022-06-23 21:20:30.410398
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    """Test method ip_v4 of class Internet."""
    internet = Internet()
    assert isinstance(internet.ip_v4(), str)
    assert isinstance(internet.ip_v4(with_port=True), str)
    assert isinstance(internet.ip_v4(with_port=True, port_range=PortRange.TRUSTED), str)
    assert isinstance(internet.ip_v4(with_port=True, port_range=PortRange.WELL_KNOWN), str)
    assert isinstance(internet.ip_v4(with_port=True, port_range=PortRange.UNTRUSTED), str)
    assert isinstance(internet.ip_v4(with_port=True, port_range=PortRange.EPHEMERAL), str)

# Generated at 2022-06-23 21:20:32.015013
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    test_user_agent = Internet()
    assert type(test_user_agent.user_agent()) == str


# Generated at 2022-06-23 21:20:34.550542
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    internet = Internet()
    method = internet.http_method()
    assert isinstance(method, str)
    assert method.isupper()


# Generated at 2022-06-23 21:20:45.415074
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    # Test case 1
    obj = Internet(seed=99999)
    assert obj.ip_v6_object() == IPv6Address('9e0e:8f36:61d7:d4c4:4ba3:d6cf:5cb0:5f49')

    # Test case 2
    obj = Internet(seed=0)
    assert obj.ip_v6_object() == IPv6Address('e814:5b1d:8755:c2b7:8f6e:d742:e6c9:6f8a')

    # Test case 3
    obj = Internet()
    assert obj.ip_v6_object() == IPv6Address('3b81:2c72:368b:a1ea:5637:805f:cd38:04b9')

    return


#

# Generated at 2022-06-23 21:20:46.251197
# Unit test for constructor of class Internet
def test_Internet():
    globals()['Internet']().seed


# Generated at 2022-06-23 21:20:49.910538
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    data = list()
    for i in range(1000):
        internet = Internet(i)
        data.append(internet.content_type())
    assert len(data)
    assert len(set(data)) < len(data)


# Generated at 2022-06-23 21:20:50.770341
# Unit test for constructor of class Internet
def test_Internet():
    internet = Internet()
    assert internet is not None

# Generated at 2022-06-23 21:20:54.026971
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    flags = []
    for i in range(100):
        provider = Internet()
        address = provider.ip_v6_object()
        if address.version == 6:
            flags.append(True)
        else:
            flags.append(False)
    assert all(flags) == True

# Generated at 2022-06-23 21:20:57.723052
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    class MockRandom:
        def randint(self, start, end):
            return 0x3e
    internet = Internet(MockRandom())
    assert internet.mac_address() == "00:16:3e:00:00:00"


# Generated at 2022-06-23 21:21:01.026553
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    provider = Internet()
    item = provider.content_type()
    assert type(item).__name__ == 'str'
    assert len(item) > 0


# Generated at 2022-06-23 21:21:04.779762
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    # Show that none values are acceptable
    assert Internet().ip_v6() is not None
    assert Internet(seed=2).ip_v6() == '2001:c244:cf9d:1fb1:c56d:f52c:8a04:94f3'

# Generated at 2022-06-23 21:21:14.932403
# Unit test for method port of class Internet
def test_Internet_port():
    i = Internet()
    for _ in range (1, 100):
        assert i.port() in range(65_536)
        assert i.port(port_range=PortRange.SYSTEM) in range(1, 1024)
        assert i.port(port_range=PortRange.USER) in range(1025, 49_151)
    for _ in range (1, 100):
        assert i.port(port_range=PortRange.ALL) in range(65_536)
        assert i.port(port_range=PortRange.SYSTEM) in range(1, 1024)
        assert i.port(port_range=PortRange.USER) in range(1025, 49_151)

# Generated at 2022-06-23 21:21:16.407166
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    Internet().stock_image


# Generated at 2022-06-23 21:21:17.701405
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    ipv6 = Internet().ip_v6_object()
    assert ipv6

# Generated at 2022-06-23 21:21:20.196455
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    for i in range(10):
        emoji = Internet().emoji()
        assert emoji



# Generated at 2022-06-23 21:21:29.749354
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    """Test for method content_type of class Internet.

    :return: None
    """
    from mimesis.enums import MimeType
    from mimesis.exceptions import NonEnumerableError

    internet = Internet()

    # test for simple call
    ctype = internet.content_type()
    assert ctype.startswith('Content-Type: ')

    # test for valid argument
    ctype = internet.content_type(mime_type=MimeType.ARG)
    assert ctype.startswith('Content-Type: ')
    assert ctype.endswith('arg')

    # test for invalid argument
    try:
        _ = internet.content_type(mime_type=MimeType.DIFF)
    except NonEnumerableError:
        pass
    else:
        raise Assert

# Generated at 2022-06-23 21:21:36.210271
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    code = ['100', '101', '200', '201', '202', '203', '204', '205', '206',
            '207', '300', '301', '302', '303', '304', '305', '306', '307',
            '400', '401', '402', '403', '404', '405', '406', '407', '408',
            '409', '410', '411', '412', '413', '414', '415', '416', '417',
            '418', '421', '422', '423', '424', '425', '426', '428', '429',
            '431', '451', '500', '501', '502', '503', '504', '505', '506',
            '507', '508', '510', '511']
    internet = Internet()

# Generated at 2022-06-23 21:21:39.017872
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    t = Internet()
    assert isinstance(t.emoji(), str)


# Generated at 2022-06-23 21:21:45.818902
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    from ipaddress import IPv4Address
    from mimesis.enums import Layer

    t = Internet(seed=1)
    ip = t.ip_v4_object()
    assert ip == IPv4Address(3243943186)
    assert isinstance(t.ip_v4_object(), IPv4Address)
    assert t.network_protocol(layer=Layer.APPLICATION) == "H.323"


# Generated at 2022-06-23 21:21:46.994239
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    internet = Internet()

    assert internet.content_type() is not None


# Generated at 2022-06-23 21:21:48.377506
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    tmp = Internet()
    tmp.emoji()


# Generated at 2022-06-23 21:21:59.436002
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    """Unit test for method emoji of class Internet."""
    internet = Internet()
    for t in range(100):
        internet.emoji()
        internet.emoji()
        internet.emoji()
        internet.emoji()
        internet.emoji()
        internet.emoji()
        internet.emoji()
        internet.emoji()
        internet.emoji()
        internet.emoji()
        internet.emoji()
        internet.emoji()
        internet.emoji()
        internet.emoji()
        internet.emoji()
        internet.emoji()
        internet.emoji()
        internet.emoji()
        internet.emoji()
        internet.emoji()
        internet.emoji()
        internet.emoji()
        internet.emoji()
        internet.emoji()

# Generated at 2022-06-23 21:22:01.426791
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    internet = Internet()
    protocol_name = internet.network_protocol(layer=Layer.NETWORK)
    assert protocol_name in ['IP', 'IPv6', 'ICMP', 'IGMP', 'IPX', 'PPP', 'ARPA', 'XNET']



# Generated at 2022-06-23 21:22:02.551061
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    from mimesis.providers.internet import Internet
    assert '.' in str(Internet().ip_v4())


# Generated at 2022-06-23 21:22:04.962344
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    """Test for method http_status_message of class Internet"""
    # Arrange
    internet = Internet()
    # Act
    result = internet.http_status_message()
    # Assert
    assert isinstance(result, str)


# Generated at 2022-06-23 21:22:16.936774
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    from mimesis.enums import LengthUnit
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.enums import DatetimeFormat

    dt = Datetime(seed=42)

    # Default parameters
    assert Internet.image_placeholder() == 'http://placehold.it/1920x1080'

    # Custom
    assert Internet.image_placeholder(width=800, height=600) == \
           'http://placehold.it/800x600'

    # Custom with length unit
    assert Internet.image_placeholder(width=dt.length(unit=LengthUnit.KILOMETER),
                                      height=dt.length(unit=LengthUnit.CENTIMETER)) == \
           'http://placehold.it/100kmx100cm'

    # Custom with datetime


# Generated at 2022-06-23 21:22:18.448936
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    import pprint
    internet = Internet()
    pprint.pprint(internet.user_agent())


# Generated at 2022-06-23 21:22:23.611981
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    from mimesis.enums import PortRange
    test_object = Internet()
    test_result = test_object.ip_v4()
    assert test_result
    assert test_result == str(IPv4Address(int(test_result.split('.')[0])))
    test_result_with_port = test_object.ip_v4(with_port=True)
    assert test_result_with_port
    assert test_result_with_port == str(IPv4Address(int(test_result_with_port.split('.')[0]))) + ":" + str(test_object.port(port_range=PortRange.ALL))


# Generated at 2022-06-23 21:22:27.447549
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    ob = Internet()
    assert ob.mac_address() in [
        '00:16:3e:25:e7:b1',
        '00:16:3e:25:e7:b2',
        '00:16:3e:25:e7:b3',
        '00:16:3e:25:e7:b4',
        '00:16:3e:25:e7:b5',
        '00:16:3e:25:e7:b6'
    ]

# Generated at 2022-06-23 21:22:38.769530
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    # Test by using the enum Layer.
    ip = Internet()
    assert ip.network_protocol(layer = Layer.APPLICATION) == 'AMQP'
    assert ip.network_protocol(layer = Layer.TRANSPORT) == 'TCP'
    assert ip.network_protocol(layer = Layer.INTERNET) == 'IP'
    assert ip.network_protocol(layer = Layer.LINK) == 'IP'
    assert ip.network_protocol(layer = Layer.PHYSICAL) == 'Ethernet'

    # Test by using the number of the layers.
    ip = Internet()
    assert ip.network_protocol(layer = 7) == 'AMQP'
    assert ip.network_protocol(layer = 4) == 'TCP'

# Generated at 2022-06-23 21:22:46.103433
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    internet = Internet(seed=0, locale='en')
    assert internet.http_method() == 'POST'

    internet.random.seed(0)
    assert internet.http_method() == 'GET'

    internet.random.seed(1)
    assert internet.http_method() == 'POST'

    internet.random.seed(2)
    assert internet.http_method() == 'OPTIONS'

    internet.random.seed(3)
    assert internet.http_method() == 'GET'

    internet.random.seed(4)
    assert internet.http_method() == 'PUT'

    internet.random.seed(5)
    assert internet.http_method() == 'POST'

    internet.random.seed(6)
    assert internet.http_method() == 'GET'

    internet.random.seed(7)

# Generated at 2022-06-23 21:22:48.580545
# Unit test for method port of class Internet
def test_Internet_port():
    t = Internet()
    for i in range(0, 100):
        p = t.port()
        assert p in range(1024, 49151)

# Generated at 2022-06-23 21:22:51.114591
# Unit test for method port of class Internet
def test_Internet_port():
    internet = Internet()
    port = internet.port()
    assert isinstance(port, int)



# Generated at 2022-06-23 21:22:53.443690
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    from pprint import pprint

    tmp_ = Internet()

    pprint(tmp_.http_status_message())


# Generated at 2022-06-23 21:22:56.148746
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    # Arrange
    internet = Internet()
    # Act
    result = internet.emoji()
    # Assert
    assert isinstance(result, str)
    assert result in EMOJI


# Generated at 2022-06-23 21:22:57.747998
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    # Call function http_method of class Internet
    assert Internet().http_method() in HTTP_METHODS

# Generated at 2022-06-23 21:23:01.492659
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    t = Internet(random_state=False)
    for i in range(100):
        t.user_agent()
        assert t.user_agent() in USER_AGENTS



# Generated at 2022-06-23 21:23:05.426302
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    
    # test.1
    expected = '#drama'
    actual = internet.hashtags(quantity=1)

    # test.2
    assert type(expected) == type(actual)
    assert expected == actual

# Generated at 2022-06-23 21:23:07.721697
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    internet = Internet()
    ip = internet.ip_v4_object()
    assert isinstance(ip, IPv4Address)


# Generated at 2022-06-23 21:23:08.646348
# Unit test for constructor of class Internet
def test_Internet():
    provider = Internet()
    assert provider.user_agent() is not None

# Generated at 2022-06-23 21:23:10.639746
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    net = Internet(seed=1)
    assert net.network_protocol(layer=Layer.L1) == "CSMA/CD"



# Generated at 2022-06-23 21:23:12.317069
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    hash_tag = internet.hashtags()
    assert hash_tag



# Generated at 2022-06-23 21:23:14.020000
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    from mimesis.enums import HTTPStatusCodes

    internet = Internet('en')
    status_message = internet.http_status_message()
    assert status_message in HTTPStatusCodes.get_codes()

test_Internet_http_status_message()

# Generated at 2022-06-23 21:23:16.729666
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    assert Internet().image_placeholder() == "http://placehold.it/1920x1080"
    assert Internet().image_placeholder(640, 480) == "http://placehold.it/640x480"


# Generated at 2022-06-23 21:23:18.023912
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    assert Internet().ip_v4_object()


# Generated at 2022-06-23 21:23:19.201022
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    test = Internet()
    assert isinstance(test.http_status_code(), int)


# Generated at 2022-06-23 21:23:26.960838
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    """Test method network_protocol of class Internet
    """
    # Test Network protocol on layer 3
    internet = Internet()
    assert internet.network_protocol(Layer.TRANSPORT) in [
        'SCTP', 'TCP', 'UDP'
    ]
    # Test Network protocol on layer 4
    internet = Internet()
    assert internet.network_protocol(Layer.NETWORK) in [
        'GGP', 'ICMP', 'IP', 'IPv6', 'OSPF', 'PPP'
    ]
    # Test Network protocol on layer 5
    internet = Internet()
    assert internet.network_protocol(Layer.DATA_LINK) in [
        'ATM', 'Ethernet', 'FDDI', 'LAPB', 'PPP', 'SLIP'
    ]
    # Test Network protocol

# Generated at 2022-06-23 21:23:35.602773
# Unit test for method port of class Internet
def test_Internet_port():
    import pytest

    from mimesis.enums import PortRange

    # Ranged port = {port}
    ranged_port = {
            'PORT-PRIV': [49152, 65535],
            'PORT-REG': [1024, 49151],
            'PORT-WELL': [1, 1023],
            'PORT-EXT': [0, 65535],
            'PORT-NET': [0, 49151],
    }

    internet = Internet('en')
    port_range_list = [key for key in ranged_port.keys()]

    # with pytest.raises(NonEnumerableError):
    #     internet.port(port_range=port_range_list[-1])

    for port_name in port_range_list:
        port_value = PortRange(port_name).value


# Generated at 2022-06-23 21:23:40.950650
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    """Unit test for method user_agent of class Internet."""
    from mimesis.exceptions import NonEnumerableError

    internet = Internet('en')
    user_agent = internet.user_agent()
    # Check if user agent is valid
    assert isinstance(user_agent, str)
    assert len(user_agent) > 1

    # Check if NonEnumerableError is raised
    try:
        internet.user_agent(None)
    except NonEnumerableError:
        assert True
    else:
        assert False



# Generated at 2022-06-23 21:23:42.597398
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    obj = Internet()
    method = obj.http_method()
    assert(method in HTTP_METHODS)

# Generated at 2022-06-23 21:23:43.851757
# Unit test for constructor of class Internet
def test_Internet():
    internet = Internet()
    assert internet is not None


# Generated at 2022-06-23 21:23:45.365149
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    provider = Internet()
    result = provider.image_placeholder()
    print(result)


# Generated at 2022-06-23 21:23:54.077876
# Unit test for method port of class Internet
def test_Internet_port():
    Internet._PortRange = type('_PortRange', (object,), {
        'HTTP': (80, 80),
        'HTTPS': (443, 443),
        'ALL': (0, 65535)})

    internet = Internet()
    http_port = internet.port(port_range=Internet._PortRange.HTTP)
    https_port = internet.port(port_range=Internet._PortRange.HTTPS)
    all_port = internet.port(port_range=Internet._PortRange.ALL)

    assert http_port == 80
    assert https_port == 443
    assert all_port in range(65536)

# Generated at 2022-06-23 21:23:56.137663
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    # Any returns a random value from an non-empty sequence.
    print(Internet().http_method())



# Generated at 2022-06-23 21:23:58.211177
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    internet = Internet()
    domain = internet.top_level_domain()
    print(domain)


# Generated at 2022-06-23 21:24:00.683175
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    internet = Internet()
    content_type = internet.content_type(MimeType.IMAGE)
    assert content_type == "Content-Type: image/jpeg"


# Generated at 2022-06-23 21:24:01.206430
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    pass

# Generated at 2022-06-23 21:24:02.412082
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    internet = Internet()
    assert internet.emoji() in EMOJI


# Generated at 2022-06-23 21:24:04.251468
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    """Unit test for method http_method of class Internet."""
    a = Internet()
    b = a.http_method()
    print(b)
    assert type(b) == str
    assert b in HTTP_METHODS


# Generated at 2022-06-23 21:24:11.799994
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    assert internet.hashtags(quantity = 1) is not None
    assert internet.hashtags(quantity = 2) is not None
    assert internet.hashtags(quantity = 4) is not None
    assert internet.hashtags(quantity = 8) is not None
    assert internet.hashtags(quantity = 16) is not None
    assert internet.hashtags(quantity = 32) is not None

# Generated at 2022-06-23 21:24:14.983459
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    print("Testing method ip_v4 of class Internet")
    ip_v4 = Internet().ip_v4()
    assert(type(ip_v4) is str)
    assert(len(ip_v4.split(".")) == 4)


# Generated at 2022-06-23 21:24:18.249370
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    internet = Internet(seed=42)
    actual = internet.ip_v6_object()
    assert actual == IPv6Address('42:42:42:42:42:42:42:42')


# Generated at 2022-06-23 21:24:23.298579
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    internet = Internet()
    protocols = [internet.network_protocol(layer=key)
        for key in Layer.ENUM.value]

    assert isinstance(protocols, list)
    assert set(protocols).issubset(set(NETWORK_PROTOCOLS))

# Generated at 2022-06-23 21:24:24.609462
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from mimesis.providers.internet import Internet

    x = Internet()

    assert x.stock_image() is not None



# Generated at 2022-06-23 21:24:28.235104
# Unit test for constructor of class Internet
def test_Internet():
    """Unit test for constructor of class Internet."""
    provider = Internet()
    assert isinstance(provider, BaseProvider)
    assert isinstance(provider.seed, int)
    assert isinstance(provider.random, type(provider.random))
    assert isinstance(provider.file, File)



# Generated at 2022-06-23 21:24:31.773311
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    img = internet.stock_image()
    assert isinstance(img, str)
    assert img.startswith('https://')
    img = internet.stock_image(writable=True)
    assert isinstance(img, bytes)

# Generated at 2022-06-23 21:24:36.123920
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    assert Internet().http_method() == "GET"
    assert Internet().http_method() == "POST"
    assert Internet().http_method() == "DELETE"
    assert Internet().http_method() == "PUT"
    assert Internet().http_method() == "OPTIONS"
    assert Internet().http_method() == "HEAD"
    assert Internet().http_method() == "TRACE"
    assert Internet().http_method() == "CONNECT"
    assert Internet().http_method() == "PATCH"
    print("########## Internet_http_method passed ##########")


# Generated at 2022-06-23 21:24:38.786025
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    """
    Test method emoji of class Internet
    """
    print("\nIn method Internet.emoji")
    internet = Internet()
    for i in range(20):
        emoji = internet.emoji()
        print(emoji)


# Generated at 2022-06-23 21:24:41.116151
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    """Method http_method of class Internet"""
    i = Internet()
    assert isinstance(i.http_method(), str)
    assert len(i.http_method()) > 0

# Generated at 2022-06-23 21:24:43.133372
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    ri = Internet('en')
    assert(ri.hashtags() == '#nice')


# Generated at 2022-06-23 21:24:44.471767
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    print(Internet.http_method())

# Generated at 2022-06-23 21:24:45.762173
# Unit test for method port of class Internet
def test_Internet_port():
    internet = Internet()
    assert isinstance(internet.port(), int) and internet.port() >= 0



# Generated at 2022-06-23 21:24:47.713553
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    internet = Internet()
    ip = internet.ip_v6()
    assert type(ip) == str


# Generated at 2022-06-23 21:24:50.773610
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    internet = Internet()
    assert isinstance(internet.http_status_code, int)


# Generated at 2022-06-23 21:24:58.917925
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    rng = random.Random(0)  # Create random generator with seed = 0
    int_gen = rng.randint(0, (2 ** 32) - 1)  # Create function that returns 0
    valid_ip = '0.0.0.0'

    # Patch random generator and randint to generate value = 0
    with patch('tests.providers.test_internet.random', rng), \
            patch('mimesis.providers.internet.random.randint', int_gen):
        ip = Internet().ip_v4()

        assert ip == valid_ip


# Generated at 2022-06-23 21:25:02.027951
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    internet = Internet()
    ipv6 = internet.ip_v6_object()
    print(ipv6)


# Generated at 2022-06-23 21:25:05.213140
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    """Unit tests for method http_status_code of class Internet."""
    generator = Internet()
    output = generator.http_status_code()
    assert output in HTTP_STATUS_CODES


# Generated at 2022-06-23 21:25:08.489785
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internal_object = Internet(seed=12345)
    i = internal_object.stock_image()
    assert i == 'https://source.unsplash.com/1920x1080?', i

# Generated at 2022-06-23 21:25:17.997305
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    ints = Internet()
    print(ints.http_status_message())
    print(ints.http_status_code())
    print(ints.http_method())
    print(ints.ip_v4_object())
    print(ints.ip_v4(with_port=True))
    print(ints.ip_v6_object())
    print(ints.ip_v6())
    print(ints.mac_address())
    print(ints.emoji())
    print(ints.image_placeholder(width=200, height=200))
    print(ints.stock_image(width=200, height=200))
    print(ints.hashtags(quantity=5))
    print(ints.home_page())
    print(ints.top_level_domain())
    print(ints.user_agent())
    print

# Generated at 2022-06-23 21:25:22.467025
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.enums import PortRange
    ru = RussiaSpecProvider('internet')
    print(ru.ip_v4(with_port=True, port_range=PortRange.SECURE))


# Generated at 2022-06-23 21:25:23.527190
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    o = Internet()
    assert isinstance(o.ip_v6_object(), IPv6Address)


# Generated at 2022-06-23 21:25:26.637741
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    from mimesis.enums import Language
    i = Internet(Language.ENGLISH)
    assert len(i.http_status_message()) >= 0
    assert type(i.http_status_message()) is str

# Generated at 2022-06-23 21:25:28.170489
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    test_internet = Internet()
    assert test_internet.http_status_message() in HTTP_STATUS_MSGS

# Generated at 2022-06-23 21:25:33.894796
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    for i in range(10):
        internet = Internet()
        length = internet.random.randint(1, 100)
        length2 = internet.random.randint(1, 100)
        assert len(internet.hashtags(quantity=length)) == length
        assert len(internet.hashtags(quantity=length2)) == length2


# Generated at 2022-06-23 21:25:38.383374
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    obj = Internet()
    assert len(obj.mac_address().split(':')) == 6
    assert obj.mac_address() == "00:16:3e:25:e7:b1"


# Generated at 2022-06-23 21:25:41.196367
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    provider = Internet()
    ip_string = provider.ip_v6_object()
    assert isinstance(ip_string, IPv6Address)


# Generated at 2022-06-23 21:25:47.788713
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from mimesis.enums import PortRange
    from mimesis.providers.internet import Internet

    i = Internet()

    # This method required an active HTTP connection
    print(i.stock_image(width=1280, height=960) + '\n')
    print('Image size: 1280x960\n'
          'Keywords: None')

    # Add keywords
    print(i.stock_image(keywords=['space', 'fantasy']) + '\n')
    print('Image size: 1920x1080\n'
          'Keywords: space, fantasy')

    # Return image as writable object
    print(i.stock_image(width=400, height=200, writable=True))
    print('Image size: 400x200\n'
          'Keywords: None')

# Generated at 2022-06-23 21:25:51.530089
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    """Unit test for method content_type of class Internet."""
    result = Internet().content_type(MimeType.TEXT)
    assert 'Content-Type: text/plain' in result


# Generated at 2022-06-23 21:25:56.316257
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    random = random.Random()
    random.seed(0)
    internet = Internet(random = random)
    assert internet.http_status_code( ) == 200
    assert internet.http_status_code( ) == 200
    assert internet.http_status_code( ) == 200
    assert internet.http_status_code( ) == 200

# Generated at 2022-06-23 21:25:59.603543
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    provider = Internet()
    assert len(provider.emoji()) == 2
    assert provider.emoji()[0] == ':'
    assert provider.emoji()[1] != ':'
    assert provider.emoji()[1].isalpha() is True


# Generated at 2022-06-23 21:26:00.750273
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    assert Internet().http_status_code() in HTTP_STATUS_CODES

# Generated at 2022-06-23 21:26:04.209303
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    result = internet.stock_image(width=200, height=200, keywords=['nature'])
    print(result) # It will display the link to image

# Generated at 2022-06-23 21:26:08.196247
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    """
    Test ip_v4_object method
    :return:
    """
    ip = Internet().ip_v4_object()
    assert str(ip)
    print("Test ip_v4_object() - " + str(ip))



# Generated at 2022-06-23 21:26:13.795121
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    internet = Internet()
    # Test 1:
    # Test with TLD_Type = Domain
    homepage = internet.home_page(TLDType.DOMAIN)
    assert homepage.__contains__(':')
    assert homepage.__contains__('https')
    # Test 2:
    # Test with TLD_Type = Suffix
    homepage = internet.home_page(TLDType.SUFFIX)
    assert homepage.__contains__(':')
    assert homepage.__contains__('https')


if __name__ == '__main__':
    test_Internet_home_page()

# Generated at 2022-06-23 21:26:23.172860
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    from hypothesis import given, settings, Verbosity
    from hypothesis.strategies import integers

    from mimesis import Internet
    
    intnet = Internet()

    @given(integers(min_value=0, max_value=999))
    @settings(verbosity=Verbosity.verbose, deadline=None)
    def test_http_status_code(val):
        assert val == intnet.http_status_code()
        if (val > 99) and (val < 600):
            assert isinstance(val, int)
        else:
            assert intnet.http_status_code() in range(100, 600)
        
    test_http_status_code()



# Generated at 2022-06-23 21:26:24.557110
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    gen = Internet()
    result = gen.user_agent()
    print(result)
    assert result is not None


# Generated at 2022-06-23 21:26:27.135400
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    """Unit test for method network_protocol of class Internet."""
    assert Internet().network_protocol(Layer.PHYSICAL) == 'Ethernet'

# Generated at 2022-06-23 21:26:35.890532
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    provider = Internet()
    
    result = provider.top_level_domain()
    assert result

    result = provider.top_level_domain(tld_type=TLDType.CCTLD)
    assert result

    result = provider.top_level_domain(tld_type=TLDType.GSLD)
    assert result

    result = provider.top_level_domain(tld_type=TLDType.IDN)
    assert result
    
    result = provider.top_level_domain(tld_type=TLDType.SCCLD)
    assert result


# Generated at 2022-06-23 21:26:37.899416
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    obj = Internet(seed=123456789)
    assert isinstance(obj.ip_v6_object(), IPv6Address)

# Generated at 2022-06-23 21:26:40.488514
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    for i in range(100):
        # internet = Internet()
        x = Internet().ip_v6()
        assert isinstance(x, str)
        assert len(x) == 39
        # print(x)


# Generated at 2022-06-23 21:26:44.530886
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    from mimesis.builtins import RussiaSpecProvider
    from ipaddress import IPv4Address
    internet = Internet(RussiaSpecProvider())
    ip = internet.ip_v4_object()
    assert isinstance(ip, IPv4Address)


# Generated at 2022-06-23 21:26:51.656932
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    from mimesis.enums import Browser
    assert Internet().user_agent() in USER_AGENTS
    assert Internet(browser=Browser.FIREFOX).user_agent() in USER_AGENTS
    assert Internet(browser=Browser.OPERA).user_agent() in USER_AGENTS
    assert Internet(browser=Browser.SAFARI).user_agent() in USER_AGENTS
    assert Internet(browser=Browser.CHROME).user_agent() in USER_AGENTS
    assert Internet(browser=Browser.INTERNET_EXPLORER).user_agent() in USER_AGENTS
    assert Internet(browser=Browser.EDGE).user_agent() in USER_AGENTS

# Generated at 2022-06-23 21:26:53.748491
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    assert internet.hashtags() == '#graphic' or '#love' or '#winter'

# Generated at 2022-06-23 21:27:05.037514
# Unit test for method port of class Internet
def test_Internet_port():
    """Unit test for method port of class Internet."""
    ip = Internet()
    assert (ip.port(port_range=None) == ip.port(port_range=PortRange.ALL))
    assert (ip.port(port_range=PortRange.ALL) >= 0)
    assert (ip.port(port_range=PortRange.ALL) <= 65535)
    assert (ip.port(port_range=PortRange.PRIVATE) >= 49152)
    assert (ip.port(port_range=PortRange.PRIVATE) <= 65535)
    assert (ip.port(port_range=PortRange.RESERVED) >= 0)
    assert (ip.port(port_range=PortRange.RESERVED) <= 1024)

# Generated at 2022-06-23 21:27:07.345847
# Unit test for constructor of class Internet
def test_Internet():
    data = Internet()
    data.mac_address()
    data.ip_v4()
    data.port()
    data.port(port_range = PortRange.RESERVED)

# Generated at 2022-06-23 21:27:10.020049
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    internet_obj = Internet()
    ipv6 = internet_obj.ip_v6()
    assert ipv6


# Generated at 2022-06-23 21:27:15.184739
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    provider = Internet()

    assert provider.stock_image(1920, 1080, ['love', 'sky']) == 'https://source.unsplash.com/1920x1080?love,sky'
    assert provider.stock_image(width=1920, height=1080, keywords=['love', 'sky']) == 'https://source.unsplash.com/1920x1080?love,sky'

    assert provider.stock_image(width='1920', height='1080', keywords=['love', 'sky']) == 'https://source.unsplash.com/1920x1080?love,sky'

# Generated at 2022-06-23 21:27:17.051780
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    internet = Internet()
    assert isinstance(internet.ip_v6_object(), IPv6Address)

# Generated at 2022-06-23 21:27:20.074464
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    provider = Internet()
    print(provider.emoji())


# Generated at 2022-06-23 21:27:22.845432
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    # for random_seed in range(10 ** 5, 10 ** 6):
    for random_seed in range(10):
        data_provider = Internet(random_seed=random_seed)
        print(data_provider.home_page())


# Generated at 2022-06-23 21:27:26.386650
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    from mimesis.enums import Layer

    np = Internet().network_protocol(Layer.TRANSPORT)
    print(np)



# Generated at 2022-06-23 21:27:33.733638
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    # Creation of object Internet
    internet = Internet()

    # Creation of list for check
    code_check = [200, 201, 202, 203, 204, 205, 206, 207, 208, 226, 300, 301,
                  302, 303, 304, 305, 306, 307, 308, 400, 401, 402, 403, 404,
                  405, 406, 407, 408, 409, 410, 411, 412, 413, 414, 415, 416,
                  417, 418, 421, 422, 423, 424, 426, 428, 429, 431, 444, 451,
                  500, 501, 502, 503, 504, 505, 506, 507, 508, 510, 511, 599]

    # Creation of a list of HTTP status codes

# Generated at 2022-06-23 21:27:35.035417
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    """Unit test for method home_page of class Internet"""
    internet = Internet()
    assert type(internet.home_page()) == str

# Generated at 2022-06-23 21:27:44.500589
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    from mimesis.enums import DataLayer
    from mimesis.exceptions import NonEnumerableError
    from mimesis.providers.internet import Internet
    from mimesis.typing import NetworkProtocol

    internet = Internet()
    assert internet.ip_v6() != ''

    try:
        internet.ip_v6() == 127
    except Exception:
        assert True
    else:
        assert False

    try:
        internet.ip_v6() == ''
    except Exception:
        assert True
    else:
        assert False

    assert internet.network_protocol() in NetworkProtocol

    try:
        internet.network_protocol(layer=DataLayer.SEVEN)
    except NonEnumerableError:
        assert True
    else:
        assert False

    assert internet.port() > 0
   

# Generated at 2022-06-23 21:27:46.082751
# Unit test for method home_page of class Internet
def test_Internet_home_page():

    i = Internet()
    a = i.home_page()
    assert a == 'https://b.erkol.info'

# Generated at 2022-06-23 21:27:47.825070
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    data = []
    for i in range(0, 10000):
        data.append(Internet().http_status_code())
    assert len(data) == 10000

# Generated at 2022-06-23 21:27:49.859072
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    internet = Internet()
    print(internet.emoji())


# Generated at 2022-06-23 21:27:53.023521
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    internet = Internet('ru')
    import random
    assert internet.http_status_code() in random.choices(HTTP_STATUS_CODES)


# Generated at 2022-06-23 21:27:54.847161
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    i = Internet()

    for n in range(1, 5):
        assert len(i.hashtags(n)) == n

# Generated at 2022-06-23 21:27:58.637297
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    for _ in range(100):
        top_level_domain = Internet().top_level_domain(TLDType.COUNTRY_CODE)
        assert top_level_domain in Internet.Meta.tld.COUNTRY_CODE
        assert isinstance(top_level_domain, str)
        assert top_level_domain

# Generated at 2022-06-23 21:28:00.295027
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    ip = Internet().ip_v4()
    assert isinstance(ip, str)
    assert '.' in ip

# Generated at 2022-06-23 21:28:02.012066
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    provider = Internet()
    for _ in range(25):
        assert isinstance(provider.home_page(), str)


# Generated at 2022-06-23 21:28:04.640401
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    internet_provider = Internet()
    random_http_status_message = internet_provider.http_status_message()
    assert random_http_status_message in HTTP_STATUS_MSGS
    assert isinstance(random_http_status_message, str)


# Generated at 2022-06-23 21:28:06.780195
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    ia = Internet(seed=1234)
    assert ia.ip_v6() == 'caef:f0f9:615e:a6d0:e72e:6f1c:3500:3d39'

# Generated at 2022-06-23 21:28:08.930403
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    # GIVEN
    engine = Internet()
    # WHEN
    result = engine.image_placeholder()
    # THEN
    assert isinstance(result, str)

# Generated at 2022-06-23 21:28:11.559082
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    for i in range(10):
        ip = Internet.image_placeholder()
        assert ip.startswith('http://placehold.it')


# Generated at 2022-06-23 21:28:13.192297
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    a = Internet()
    for i in range(0, 10):
        print(a.ip_v4_object())
        

# Generated at 2022-06-23 21:28:14.384705
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    test = Internet()
    result = test.emoji()
    assert result in EMOJI

# Generated at 2022-06-23 21:28:20.255083
# Unit test for method port of class Internet
def test_Internet_port():
    internet = Internet()
    # Check PortRange.WELL_KNOWN
    assert internet.port(port_range=PortRange.WELL_KNOWN) >= 0
    # Check PortRange.REGISTERED
    assert internet.port(port_range=PortRange.REGISTERED) >= 1024
    # Check PortRange.DYNAMIC_AND_PRIVATE
    assert internet.port(port_range=PortRange.DYNAMIC_AND_PRIVATE) >= 49152
    # Check PortRange.ALL
    assert internet.port(port_range=PortRange.ALL) >= 0

test_Internet_port()

# Generated at 2022-06-23 21:28:21.941537
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    internet = Internet()
    print(internet.http_status_message())



# Generated at 2022-06-23 21:28:25.641465
# Unit test for method emoji of class Internet
def test_Internet_emoji():
        # Arrange
        internet = Internet()
        # Act
        result = internet.emoji()

        # Assert
        assert isinstance(result, str)

        assert result in EMOJI

        assert len(result) == 2



# Generated at 2022-06-23 21:28:28.902880
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    print('\n---------- TEST http_method() of Internet class----------')
    intnet = Internet()
    # The length of the returned string is always more than 3
    for i in range(3):
        print(intnet.http_method())


# Generated at 2022-06-23 21:28:32.362580
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    import inspect

    assert inspect.isclass(Internet)
    assert callable(Internet)

    internet = Internet()
    assert isinstance(internet, Internet)
    assert isinstance(internet.content_type(), str)
    assert internet.content_type() == "Content-Type: text/plain"


# Generated at 2022-06-23 21:28:36.200234
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    provider = Internet()
    result = provider.home_page()
    assert type(result).__name__ == 'str', 'provider.home_page() returned wrong type!'
    assert provider.link_has_protocol(result) is True, 'provider.home_page() returned incorrect value'



# Generated at 2022-06-23 21:28:40.412049
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    internet = Internet(seed=1)
    result = internet.ip_v6_object()
    expected = IPv6Address('2b4c:3aea:4b0e:5a1a:6882:77f8:8566:9487')
    assert str(result) == str(expected)



# Generated at 2022-06-23 21:28:42.402074
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    print("http_status_message")
    i = Internet()
    print(i.http_status_message())


# Generated at 2022-06-23 21:28:44.773981
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    internet = Internet()
    internet.http_method().lower() in HTTP_METHODS


# Generated at 2022-06-23 21:28:47.989548
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    internet = Internet()
    data = internet.home_page()
    assert isinstance(data, str)
    assert 'http' in data
    assert data.endswith('.com')



# Generated at 2022-06-23 21:28:48.915989
# Unit test for constructor of class Internet
def test_Internet():
    """Unit test for constructor of class Internet."""
    internet = Internet()
    assert isinstance(internet, Internet)

# Generated at 2022-06-23 21:28:54.985223
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    from mimesis.enums import UserAgentType
    from mimesis.providers.internet import Internet
    from mimesis.typing import String

    inter = Internet()
    ua = inter.user_agent()
    print(ua)
    print(type(ua), type(String), type(inter.user_agent), type(inter.user_agent()))
    print(type(ua), type(String), type(inter.user_agent), type(inter.user_agent()))

# Generated at 2022-06-23 21:28:57.936245
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    r = Internet()
    s = r.http_status_code()
    if status.isnumeric() and int(status) in HTTP_STATUS_CODES:
        pass
    else:
        assert 0, 'Method Internet().http_status_code() failed'


# Generated at 2022-06-23 21:29:00.773626
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    pattern = re.compile(r"^([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})$")
    assert pattern.match(Internet().mac_address())

# Generated at 2022-06-23 21:29:02.802326
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    internet = Internet()
    assert isinstance(internet.content_type(), str)


# Generated at 2022-06-23 21:29:06.832904
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from mimesis.providers.internet import Internet
    
    b = Internet().stock_image()
    print(b)
    print(Internet().stock_image())


if __name__ == '__main__':
    test_Internet_stock_image()

# Generated at 2022-06-23 21:29:07.976669
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    i = Internet()
    er = ':kissing:'
    e = i.emoji()

    assert e in er


# Generated at 2022-06-23 21:29:10.554305
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    """Test for method http_status_message."""
    from mimesis.enums import Locale

    internet = Internet(Locale.EN)
    test_method = internet.http_status_message()
    assert isinstance(test_method, str)


# Generated at 2022-06-23 21:29:15.722542
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    """Test for method user_agent of class Internet.

    :return: `None`
    """
    from mimesis.providers.internet import Internet

    inet = Internet()
    assert len(Internet.Meta.name) > 0
    assert len(inet.user_agent()) > 0


# Generated at 2022-06-23 21:29:20.089449
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    """Unit test for method hashtags of class Internet."""
    internet = Internet()
    result = internet.hashtags(quantity=4)
    assert isinstance(result, list)
    assert isinstance(result[0], str)
    result = internet.hashtags(quantity=1)
    assert isinstance(result, str)

# Generated at 2022-06-23 21:29:22.689648
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    provider = Internet()
    result = provider.stock_image(1920, 1080)
    print('result = {}'.format(result))


# Generated at 2022-06-23 21:29:27.207080
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    from mimesis.builtins import internet
    res = internet.Internet().http_status_message()
    if 0 < res.__len__()< 25:
        print("method http_status_message: passed")
    else:
        print("method http_status_message: failed")



# Generated at 2022-06-23 21:29:29.361301
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    provider = Internet()
    assert isinstance(provider.network_protocol(), str) is True

# Generated at 2022-06-23 21:29:33.990237
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    """
    Testing for method image_placeholder
    """
    internet = Internet()
    test_url = internet.image_placeholder(width=1920, height=1080)
    assert test_url == 'http://placehold.it/1920x1080', "failed test_Internet_image_placeholder"



# Generated at 2022-06-23 21:29:35.343551
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    prov = Internet()
    assert prov.top_level_domain() in TLD['all']

# Generated at 2022-06-23 21:29:42.629081
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    """Test method ip_v4_object."""
    from mimesis.data import INTERNET

    INTERNET._MAX_IPV4 = 2 ** 32
    ip = INTERNET.ip_v4_object()
    assert ip._string_from_ip_int(ip._ip) == '255.255.255.255'

    INTERNET._MAX_IPV4 = 0
    ip = INTERNET.ip_v4_object()
    assert ip._string_from_ip_int(ip._ip) == '0.0.0.0'
