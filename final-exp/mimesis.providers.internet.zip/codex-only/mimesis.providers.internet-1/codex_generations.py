

# Generated at 2022-06-23 21:19:50.081277
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    """Unit test for method network_protocol of class Internet."""
    internet = Internet()
    assert internet.network_protocol(
        layer=Layer.APPLICATION) in NETWORK_PROTOCOLS[Layer.APPLICATION]
    assert internet.network_protocol(
        layer=Layer.PRESENTATION) in \
        NETWORK_PROTOCOLS[Layer.PRESENTATION]
    assert internet.network_protocol(
        layer=Layer.SESSION) in NETWORK_PROTOCOLS[Layer.SESSION]
    assert internet.network_protocol(layer=Layer.TRANSPORT) in \
        NETWORK_PROTOCOLS[Layer.TRANSPORT]
    assert internet.network_protocol(layer=Layer.NETWORK) in \
        NETWORK_PROTOCOLS[Layer.NETWORK]

# Generated at 2022-06-23 21:19:51.576215
# Unit test for constructor of class Internet
def test_Internet():
    internet = Internet()
    assert isinstance(internet, Internet)

# Generated at 2022-06-23 21:19:54.049437
# Unit test for method port of class Internet
def test_Internet_port():
        internet = Internet()
        port = internet.port(port_range=PortRange.WELL_KNOWN)
        assert port in [1, 1023]

# Generated at 2022-06-23 21:20:00.355887
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    network_protocols = [
        'AMQP', 'ARP', 'BitTorrent', 'DHCP', 'DNS', 'FTP',
        'Gnutella', 'HTTP', 'HTTPS', 'ICMP', 'IMAP', 'IRC',
        'LDAP', 'NFS', 'NNTP', 'PostgreSQL', 'PPTP', 'RADIUS',
        'RIP', 'RPC', 'RTP', 'RSTP', 'RTSP', 'SCP', 'SFTP', 'SMTP',
        'SNMP', 'SSH', 'Telnet', 'TFTP', 'XMPP',
        ]
    internet = Internet()
    networks = [internet.network_protocol() for i in range(20)]
    for n in networks:
        assert n in network_protocols

# Generated at 2022-06-23 21:20:02.455594
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    internet = Internet()
    assert internet.content_type()[:14] == 'Content-Type:'

# Generated at 2022-06-23 21:20:09.960204
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    """Test method Internet.mac_address."""
    from mimesis.enums import PortRange

# Generated at 2022-06-23 21:20:12.947865
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    t = Internet(seed=123)
    func = t.ip_v6_object
    res = func()

    assert isinstance(res, IPv6Address)


# Generated at 2022-06-23 21:20:17.223835
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    response = internet.stock_image(200, 100, ['car'], writable=True)

    import os
    from pathlib import Path
    file_name = 'stock_image.jpg'
    full_path = str(Path(os.getcwd(), file_name))
    with open(full_path, 'wb') as f:
        f.write(response)

    return full_path

# Generated at 2022-06-23 21:20:23.478992
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    """Test method ip_v4 of class Internet"""
    internet = Internet()
    ipv4 = internet.ip_v4()
    ipv4_w_port = internet.ip_v4(with_port=True)

    print("ipv4 =", ipv4)
    print("ipv4_w_port =", ipv4_w_port)



# Generated at 2022-06-23 21:20:26.985889
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    """Unit test for method http_method of class Internet."""
    internet = Internet()
    result = internet.http_method()
    assert type(result) == str
    assert result in HTTP_METHODS

# Generated at 2022-06-23 21:20:30.154437
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    obj = Internet()
    assert isinstance(obj.ip_v4(), str)
    assert isinstance(obj.ip_v4(with_port=True), str)
    assert isinstance(obj.ip_v4_object(), IPv4Address)


# Generated at 2022-06-23 21:20:36.703990
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    from mimesis.enums import Layer
    from mimesis.providers.internet import Internet

    field = Internet()

    for _ in range(10):
        print(field.ip_v6())
    print(field.network_protocol(layer=Layer.APPLICATION))

if __name__ == '__main__':
    test_Internet_ip_v6()

# Generated at 2022-06-23 21:20:46.976951
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    a = Internet(seed=12345)
    assert a.home_page() == 'https://hongchi.info'
    assert a.home_page(tld_type='uk') == 'https://acall.uk'
    assert a.home_page(tld_type='com') == 'https://studio.com'
    assert a.home_page(tld_type='edu') == 'https://garrison.edu'
    assert a.home_page(tld_type='gov') == 'https://bennett.gov'
    assert a.home_page(tld_type='net') == 'https://wood.net'
    assert a.home_page(tld_type='int') == 'https://davis.int'

# Generated at 2022-06-23 21:20:48.503866
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    assert IPv4Address('75.48.62.81') == Internet().ip_v4_object()


# Generated at 2022-06-23 21:20:50.031297
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    internet = Internet(seed=123)

    assert ip_v4 == '16.153.142.222'

# Generated at 2022-06-23 21:20:51.232198
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    provider = Internet()
    assert provider.http_method() in HTTP_METHODS

# Generated at 2022-06-23 21:20:58.912327
# Unit test for method port of class Internet
def test_Internet_port():
    i = Internet()
    port_min, port_max = PortRange.ALL.value
    assert i.port(PortRange.ALL) in range(port_min, port_max)
    port_min, port_max = PortRange.SYSTEM.value
    assert i.port(PortRange.SYSTEM) in range(port_min, port_max)
    port_min, port_max = PortRange.WELL_KNOWN.value
    assert i.port(PortRange.WELL_KNOWN) in range(port_min, port_max)
    port_min, port_max = PortRange.REGISTERED.value
    assert i.port(PortRange.REGISTERED) in range(port_min, port_max)
    port_min, port_max = PortRange.DYNAMIC.value

# Generated at 2022-06-23 21:21:02.451837
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    width = 1920
    height = 1080
    url = Internet.image_placeholder(width, height)
    assert url == 'http://placehold.it/1920x1080'


# Generated at 2022-06-23 21:21:03.889331
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    n = Internet()

    assert isinstance(n.user_agent(),str)


# Generated at 2022-06-23 21:21:08.168158
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    # Given
    internet = Internet()
    # When
    result = internet.emoji()
    # Then
    assert result


# Generated at 2022-06-23 21:21:13.393891
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    """Unit test for method user_agent of class Internet."""
    # user agent example for popular sites
    assert Internet.user_agent() == 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36'



# Generated at 2022-06-23 21:21:16.138433
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
        stock_image = Internet().stock_image()
        print(f'stock_image: {stock_image}')


# Generated at 2022-06-23 21:21:17.297442
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    # 1 represents success
    assert(1)

# Generated at 2022-06-23 21:21:27.717491
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    from mimesis.enums import Layer, PortRange
    from mimesis.providers.internet import Internet


    internet = Internet()
    # IPv6
    ipv6_inr = internet.ip_v6()
    assert ipv6_inr
    assert isinstance(ipv6_inr, str)
    # IPv4
    ipv4_inr = internet.ip_v4()
    assert ipv4_inr
    assert isinstance(ipv4_inr, str)
    # IPv4 with port
    ipv4_port = internet.ip_v4(with_port=True)
    assert ipv4_port
    assert isinstance(ipv4_port, str)

# Generated at 2022-06-23 21:21:29.033015
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    assert len(Internet().mac_address()) == 17

# Generated at 2022-06-23 21:21:30.574990
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    obj = Internet()
    print(obj.http_status_message())


# Generated at 2022-06-23 21:21:36.772151
# Unit test for method port of class Internet
def test_Internet_port():
    assert Internet().port(PortRange.ALL) in range(0, 65535 + 1)
    assert Internet().port(PortRange.WELL_KNOWN) in range(0, 1023 + 1)
    assert Internet().port(PortRange.REGISTERED) in range(1024, 49151 + 1)
    assert Internet().port(PortRange.DYNAMIC_AND_PRIVATE) in range(
        49152, 65535 + 1)

# Generated at 2022-06-23 21:21:48.294438
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    from mimesis.enums import DataField
    from mimesis.providers.network import Network
    from mimesis.providers.internet import Internet
    from mimesis.typing import Seed
    from mimesis.utils import random_seed

    net_1 = Network(seed=random_seed())
    net_2 = Network(seed=random_seed())
    assert net_1.mac_address() == net_2.mac_address()

    net_1 = Network(seed=random_seed())
    net_2 = Network(seed=random_seed())
    assert (net_1.mac_address(DataField.PRIVATE) ==
            net_2.mac_address(DataField.PRIVATE))

    net_1 = Network(seed=random_seed())

# Generated at 2022-06-23 21:21:57.915041
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    """Unit test for method http_status_code of class Internet."""
    # Preconditions
    expected_return_type = int
    expected_return_values = HTTP_STATUS_CODES

    # Run the test
    internet = Internet()
    result = internet.http_status_code()

    # Verify the results
    assert isinstance(result, expected_return_type)
    assert result in expected_return_values

    # Run the test
    internet = Internet()
    result = internet.http_status_code()

    # Verify the results
    assert isinstance(result, expected_return_type)
    assert result in expected_return_values


# Generated at 2022-06-23 21:21:58.912096
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    internet = Internet()
    assert isinstance(internet.emoji(), str)


# Generated at 2022-06-23 21:22:03.028305
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():

    internet = Internet()

    # Unit test for method ip_v4
    assert isinstance(internet.ip_v4(), str)
    assert internet.ip_v4() == '0.0.0.0'
    assert isinstance(internet.ip_v4(with_port=True), str)
    assert internet.ip_v4(with_port=True) == '0.0.0.0:0'

    # Unit test for method ip_v4_object
    assert isinstance(internet.ip_v4_object(), IPv4Address)
    assert str(internet.ip_v4_object()) == '0.0.0.0'



# Generated at 2022-06-23 21:22:04.784689
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    i = Internet()
    result = i.http_method()

    assert result in HTTP_METHODS


# Generated at 2022-06-23 21:22:06.695882
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    obj = Internet()
    assert isinstance(obj.ip_v6(), str)


# Generated at 2022-06-23 21:22:15.283799
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    from mimesis.enums import TLDType
    from mimesis import Internet
    i = Internet()
    tld_type1 = i.top_level_domain(tld_type=TLDType.GOV)
    tld_type2 = i.top_level_domain(tld_type=TLDType.COM)
    str1 = isinstance(tld_type1, str)
    assert str1 == True
    str2 = isinstance(tld_type2, str)
    assert str2 == True

# Generated at 2022-06-23 21:22:19.685672
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    """Test for method image_placeholder of class Internet"""
    internet = Internet()
    assert internet.image_placeholder(width=500, height=500) == "http://placehold.it/500x500"
    

# Generated at 2022-06-23 21:22:24.475676
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    """Unit test for method mac_address of class Internet."""
    internet = Internet()
    mac_address = internet.mac_address()

    assert mac_address.startswith('00:')
    assert len(mac_address) == 17

# Generated at 2022-06-23 21:22:26.947214
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    obj = Internet()
    ip = obj.ip_v4_object()  
    assert isinstance(ip, IPv4Address)

# Generated at 2022-06-23 21:22:35.236796
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    from mimesis.enums import Hashtag
    from mimesis.exceptions import NonEnumerableError
    from mimesis.providers.internet import Internet
    for i in range(100):
        try:
            Internet().hashtags(Hashtag.SPORT)
        except NonEnumerableError:
            print('fail')
        try:
            Internet().hashtags(Hashtag.NON_EXISTENT)
        except NonEnumerableError:
            print('fail')

# Generated at 2022-06-23 21:22:38.563310
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    internet = Internet()
    mac_address = internet.mac_address()
    mac_address_1 = internet.mac_address()
    print("mac_address: ", mac_address)
    print("mac_address: ", mac_address_1)


# Generated at 2022-06-23 21:22:40.868225
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    provider = Internet()
    data = provider.top_level_domain(TLDType.GENERIC)
    assert data in TLD['generic']

# Generated at 2022-06-23 21:22:44.500811
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    internet = Internet()
    assert isinstance(internet.ip_v4(), str)
    assert isinstance(internet.ip_v4(with_port=True, port_range=PortRange.PRIVATE), str)

# Generated at 2022-06-23 21:22:49.995048
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    """Test http_status_code"""
    from mimesis import DataSpec
    from mimesis.providers.internet import Internet

    internet = Internet(DataSpec(seed=11))
    for _ in range(10):
        value = internet.http_status_code()
        assert isinstance(value, int)

# Generated at 2022-06-23 21:22:51.477158
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    print("Testing http_status_code:")
    i = Internet()
    print(i.http_status_code())


# Generated at 2022-06-23 21:22:53.236182
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    assert Internet('en').network_protocol() in NETWORK_PROTOCOLS


# Generated at 2022-06-23 21:22:54.689764
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    status = Internet().http_status_code()
    assert isinstance(status, int)

# Generated at 2022-06-23 21:22:59.624839
# Unit test for method port of class Internet
def test_Internet_port():
    gen = Internet()
    assert gen.port() not in [PortRange.SYSTEM.value, PortRange.USER.value]
    assert gen.port(PortRange.SYSTEM) not in [PortRange.USER.value]
    assert gen.port(PortRange.USER) not in [PortRange.SYSTEM.value]


# Generated at 2022-06-23 21:23:08.662014
# Unit test for method port of class Internet
def test_Internet_port():
    from mimesis.enums import PortRange
    from mimesis.exceptions import NonEnumerableError

    internet = Internet()

    # Test range of ports
    port_wellknown = internet.port(PortRange.WELL_KNOWN)
    port_registered = internet.port(PortRange.REGISTERED)
    port_dynamic = internet.port(PortRange.DYNAMIC)
    port_all = internet.port(PortRange.ALL)

    assert 0 <= port_wellknown <= 1023
    assert 1024 <= port_registered <= 49151
    assert 49152 <= port_dynamic <= 65535
    assert 0 <= port_all <= 65535

# Generated at 2022-06-23 21:23:10.439591
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    from mimesis.enums import Specification

    internet = Internet(Specification.EN)
    message = internet.http_status_message()
    assert message in HTTP_STATUS_MSGS



# Generated at 2022-06-23 21:23:12.490177
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    bs = Internet()
    for i in range(10):
        print(bs.ip_v4_object())


# Generated at 2022-06-23 21:23:13.168881
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    assert len(Internet().ip_v6()) == 39


# Generated at 2022-06-23 21:23:22.689125
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    from mimesis.enums import TLDType
    from mimesis.providers.internet import Internet
    from mimesis.providers.file import File
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address

    internet = Internet()
    assert isinstance(internet.home_page(), str)
    assert internet.home_page(TLDType.CCTLD) in [
        'https://brunom.tv',
        'https://jenniferh.tv',
        'https://giannantonio.tv',
        'https://ceciliad.tv',
        'https://joseph.tv',
        'https://donna.tv',
        'https://ronbrooks.tv'
    ]

    # Create provider with seed

# Generated at 2022-06-23 21:23:28.493549
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    import ipaddress
    provider = Internet()
    assert isinstance(provider.ip_v4_object(), ipaddress.IPv4Address)
    assert isinstance(provider.ip_v4_object(), str)


# Generated at 2022-06-23 21:23:30.438201
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    provider = Internet()

    assert isinstance(provider.ip_v4_object(), IPv4Address)

# Generated at 2022-06-23 21:23:33.409138
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    test = Internet(seed=SEED)
    for _ in range(10):
        assert (test.hashtags(quantity=1) == '#love')
    for _ in range(10):
        assert (test.hashtags(quantity=2) == '#life')



# Generated at 2022-06-23 21:23:35.789806
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    internet = Internet()
    assert internet.image_placeholder() == 'http://placehold.it/1920x1080'


# Generated at 2022-06-23 21:23:37.383754
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    assert Internet().content_type() == 'Content-Type: image/jpeg'


# Generated at 2022-06-23 21:23:39.371044
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    internet = Internet()
    result = internet.http_status_code()
    assert type(result) == int


# Generated at 2022-06-23 21:23:40.935214
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    internet = Internet()
    assert 'http' in internet.home_page()


# Generated at 2022-06-23 21:23:43.255348
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    internet = Internet()
    assert internet.ip_v4() == '7.110.103.241' or '100.178.205.113'


# Generated at 2022-06-23 21:23:45.738564
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    tester = Internet()
    mac_address = tester.mac_address()
    assert len(mac_address) == 17
    assert mac_address.replace(':','').isalnum() == True

# Generated at 2022-06-23 21:23:49.568337
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    print(internet.hashtags(quantity=2))
    print(internet.hashtags(quantity=1))
    print(internet.hashtags())



# Generated at 2022-06-23 21:23:53.000543
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    """Test that the content type is provided."""
    i = Internet('ru')
    assert i.content_type(MimeType.IMAGE) == 'Content-Type: image/png'

# Generated at 2022-06-23 21:23:56.212555
# Unit test for method port of class Internet
def test_Internet_port():
    """Unit test for method port of class Internet."""
    internet = Internet(seed=1)
    internet.port(PortRange.SYSTEM)
    internet.port(PortRange.USER)

# Generated at 2022-06-23 21:23:58.654508
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    internet = Internet()
    print(
        internet.home_page(
            tld_type=TLDType.ALL),
    )

# Generated at 2022-06-23 21:24:00.057246
# Unit test for method port of class Internet
def test_Internet_port():
    i = Internet()
    test = i.port()
    assert 0 <= test <= 65535

# Generated at 2022-06-23 21:24:02.682142
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    statuses_set = set()
    for _ in range(10):
        statuses_set.add(Internet().http_status_code())
    assert statuses_set == set(HTTP_STATUS_CODES)

# Generated at 2022-06-23 21:24:04.583282
# Unit test for constructor of class Internet
def test_Internet():
    check=Internet()
    assert check.http_method() in HTTP_METHODS


# Generated at 2022-06-23 21:24:15.762139
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    """Test method ip_v4_object of class Internet."""
    import itertools
    import random

    class FakeRandom:
        """Fake random module to use in unit tests."""

        def __init__(self, seed):
            self.seed = seed
            self.counter = 0

        def randint(self, begin, end):
            self.counter += 1
            return begin + self.counter

    seed = random.randint(0, 1000)
    random = FakeRandom(seed)
    provider = Internet(random)

    ip_v4_object_list = list(itertools.islice(provider.ip_v4_object, 10))

# Generated at 2022-06-23 21:24:18.405172
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    try:
        internet = Internet()
        print(internet.mac_address())
    except TypeError:
        print("=!= Invalid type of argument.")


# Generated at 2022-06-23 21:24:20.819487
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    internet = Internet()
    ua = internet.user_agent()
    assert len(ua) > 42

# Generated at 2022-06-23 21:24:26.716380
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    instance = Internet(seed=42)

    print(instance.network_protocol(layer=Layer.APPLICATION))
    print(instance.network_protocol(layer=Layer.TRANSPORT))
    print(instance.network_protocol(layer=Layer.NETWORK))
    print(instance.network_protocol(layer=Layer.DATA_LINK))
    print(instance.network_protocol(layer=Layer.PHYSICAL))



# Generated at 2022-06-23 21:24:36.675117
# Unit test for method port of class Internet
def test_Internet_port():
    assert Internet().port(port_range=PortRange.WELL_KNOWN) in range (*PortRange.WELL_KNOWN.value)
    assert (Internet().port(port_range=PortRange.USER_REGISTERED) >= PortRange.USER_REGISTERED.value[0]) and (
            Internet().port(port_range=PortRange.USER_REGISTERED) <= PortRange.USER_REGISTERED.value[1])
    assert (Internet().port(port_range=PortRange.DYNAMIC_PRIVATE) >= PortRange.DYNAMIC_PRIVATE.value[0]) and (
            Internet().port(port_range=PortRange.DYNAMIC_PRIVATE) <= PortRange.DYNAMIC_PRIVATE.value[1])

# Generated at 2022-06-23 21:24:41.275895
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    """Test function for http_status_message.
    """
    internet = Internet(seed=0)
    assert internet.http_status_message() == 'HTTP/1.1 200 OK'
    assert internet.http_status_message() == 'HTTP/1.1 429 Too Many Requests'
    assert internet.http_status_message() == 'HTTP/1.1 404 Not Found'


# Generated at 2022-06-23 21:24:52.650905
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    from mimesis.enums import PortRange
    from mimesis.providers.network import Network

    n = Network()
    n.mac_address()

    n.ip_v4()
    n.ip_v4(with_port=True, port_range=PortRange.ALL)
    n.ip_v4()
    n.ip_v4()
    n.ip_v6()

    i = Internet()
    i.ip_v4()
    i.ip_v6()
    i.port(port_range=PortRange.ALL)
    i.port(port_range=PortRange.ALL)
    i.top_level_domain()

    i.http_method()

    i.hashtags()
    i.hashtags(quantity=1)

    i.user_agent()
   

# Generated at 2022-06-23 21:24:55.444042
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    internet = Internet(locale='ru')
    mac = internet.mac_address()
    assert internet.validate_mac_address(mac)


# Generated at 2022-06-23 21:25:06.335187
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    internet = Internet()
    result = internet.network_protocol(Layer.TRANSPORT)

# Generated at 2022-06-23 21:25:09.825427
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    internet = Internet(seed=42)
    assert str(internet.ip_v6_object()) == '2001:c244:cf9d:1fb1:c56d:f52c:8a04:94f3'

# Generated at 2022-06-23 21:25:11.216266
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    internet = Internet()
    print(internet.mac_address())

# Generated at 2022-06-23 21:25:15.700650
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    """Test for method top_level_domain of class Internet."""
    instance = Internet()
    # tld = instance.top_level_domain(tld_type=TLDType.INFRASTRUCTURE)
    tld = instance.top_level_domain()
    assert bool(tld)

# Generated at 2022-06-23 21:25:18.661972
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    internet = Internet()
    assert internet.emoji() in EMOJI
    assert not internet.emoji() in EMOJI

# Generated at 2022-06-23 21:25:23.171100
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    obj = Internet()
    mac = obj.mac_address()
    # Check if mac string is not empty
    assert len(mac) > 0
    # Check if mac string is equal to expected
    assert mac == '00:16:3e:62:7d:55'

# Generated at 2022-06-23 21:25:26.341183
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    from mimesis.enums import HTTPMethod
    from mimesis.providers.internet import Internet

    provider = Internet('en')
    assert provider.http_method().lower() in [item.value.lower() for item in HTTPMethod]



# Generated at 2022-06-23 21:25:27.843959
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    internet = Internet(seed=123)
    image = internet.image_placeholder(1920, 1080)
    assert image == 'http://placehold.it/1920x1080'

# Generated at 2022-06-23 21:25:29.673159
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    print(Internet().mac_address())

# Generated at 2022-06-23 21:25:41.279536
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    internet = Internet()
    ip = internet.ip_v4_object()
    assert type(ip.version) == int
    assert ip.__str__()
    assert ip.compressed
    assert ip.exploded
    assert ip.packed
    assert ip.is_link_local
    assert ip.is_loopback
    assert ip.is_multicast
    assert not ip.is_reserved
    assert not ip.is_unspecified
    assert not ip.is_site_local
    assert not ip.is_private
    assert not ip.is_global
    assert not ip.is_reserved
    assert ip.max_prefixlen
    assert ip.version
    assert ip.max_prefixlen


# Generated at 2022-06-23 21:25:46.410473
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from mimesis.enums import Category, Layer

    ip = Internet()
    ip.random.seed(42)
    assert ip.stock_image(100, 100, ['dog', 'cat']) == 'https://source.unsplash.com/100x100?dog,cat'

# Generated at 2022-06-23 21:25:48.353558
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    assert isinstance(Internet().ip_v4_object(), IPv4Address)


# Generated at 2022-06-23 21:25:53.381102
# Unit test for constructor of class Internet
def test_Internet():
    internet = Internet()
    print(internet.hashtags())
    print(internet.image_placeholder())
    print(internet.http_method())
    print(internet.mac_address())
    print(internet.home_page())


if __name__ == '__main__':
    test_Internet()

# Generated at 2022-06-23 21:25:56.096261
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    test = Internet()
    http_status_code = test.http_status_code()
    assert isinstance(http_status_code, int)


# Generated at 2022-06-23 21:26:00.058326
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    """Create object of Internet, call method ip_v4_object and check
    if result is instance of IPv4Address class from module
    ipaddress.
    """
    from ipaddress import IPv4Address
    internet = Internet()
    result = internet.ip_v4_object()
    assert isinstance(result, IPv4Address)


# Generated at 2022-06-23 21:26:06.175127
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    # Create instance of class Internet with seed
    user_agent = Internet(seed=12345).user_agent()
    # Check type of user_agent
    assert isinstance(user_agent, str)
    assert user_agent == 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:15.0) Gecko/20100101 Firefox/15.0.1'
    # Create instance of class Internet with seed
    user_agent = Internet(seed=54321).user_agent()
    # Check type of user_agent
    assert isinstance(user_agent, str)
    assert user_agent == 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:15.0) Gecko/20100101 Firefox/15.0.1'

# Generated at 2022-06-23 21:26:09.823563
# Unit test for constructor of class Internet
def test_Internet():
    it = Internet()
    assert it.__file.seed == it.seed
    assert it._MAX_IPV4 == (2 ** 32) - 1
    assert it._MAX_IPV6 == (2 ** 128) - 1


# Generated at 2022-06-23 21:26:13.459666
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    x = Internet()
    assert x.image_placeholder() == "http://placehold.it/1920x1080"
    assert x.image_placeholder(height=300) == "http://placehold.it/1920x300"


# Generated at 2022-06-23 21:26:16.305607
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    """Test method 'top_level_domain' of class 'Internet'."""
    assert 'ru' in Internet().top_level_domain()


# Generated at 2022-06-23 21:26:19.092042
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    from mimesis.enums import Layer

    internet = Internet()
    ip = internet.ip_v6_object()

    assert isinstance(ip, IPv6Address)



# Generated at 2022-06-23 21:26:23.507461
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    # Arrange
    @dataclass
    class MockRandom(Random):
        def choice(self, seq):
            return ':panda_face:'

    internet = Internet()
    internet.random = MockRandom()

    # Act
    actual = internet.emoji()

    # Assert
    expected = ':panda_face:'
    assert actual == expected


# Generated at 2022-06-23 21:26:25.483796
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    internet = Internet(random_state=42)
    for i in range(50):
        print(internet.ip_v6())


# Generated at 2022-06-23 21:26:30.848441
# Unit test for method port of class Internet
def test_Internet_port():
    # Test random port number without parameter
    int_obj = Internet(seed=0)
    port = int_obj.port()
    assert port == 43

    # Test random port number with parameter
    port = int_obj.port(port_range=PortRange.SYSTEM)
    assert port == 495



# Generated at 2022-06-23 21:26:31.525694
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    internet = Internet()
    print(internet.image_placeholder())


# Generated at 2022-06-23 21:26:34.132243
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    internet = Internet()
    http_status_code = internet.http_status_code()
    assert isinstance(http_status_code, int)


# Generated at 2022-06-23 21:26:36.923688
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    internet = Internet()
    http_status_code = internet.http_status_code()
    assert isinstance(http_status_code, int)


# Generated at 2022-06-23 21:26:39.065980
# Unit test for method port of class Internet
def test_Internet_port():
    test = Internet()
    ports = test.port(PortRange.ALL)
    assert (ports < 65535)
    assert (ports >= 0)


# Generated at 2022-06-23 21:26:40.419216
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    internet = Internet()
    assert internet.image_placeholder(width=1024, height=768).startswith('http')

# Generated at 2022-06-23 21:26:42.210190
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    lu = Internet()
    lu.hashtags(1)



# Generated at 2022-06-23 21:26:44.628467
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    """Unit test for emoji of Internet."""
    i = Internet()
    result = i.emoji()
    assert result in EMOJI

# Generated at 2022-06-23 21:26:48.015222
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    internet = Internet()
    a = internet.http_method()
    assert a in ['GET', 'POST', 'PUT', 'DELETE', 'HEAD', 'OPTIONS', 'PATCH']


# Generated at 2022-06-23 21:26:49.502709
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    t = Internet()
    print(t.emoji())


# Generated at 2022-06-23 21:26:52.843442
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    assert isinstance(Internet.hashtags(), str)
    assert isinstance(Internet.hashtags(quantity=5), list)
    assert isinstance(Internet.hashtags(quantity=5)[0], str)

# Generated at 2022-06-23 21:26:55.363972
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    internet = Internet()
    mac_addr = internet.mac_address()
    assert mac_addr == '00:16:3e:25:e7:b1'

# Generated at 2022-06-23 21:26:58.745438
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    intranet = Internet()
    assert intranet.network_protocol(layer=Layer.APP) in ['AMQP', 'IMAP4',
                                                          'HTTP', 'MQTT',
                                                          'LDAP', 'SMB']


# Generated at 2022-06-23 21:27:01.684402
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    test_field = Internet()
    result = test_field.http_status_code()
    assert isinstance(result, int)

# Generated at 2022-06-23 21:27:05.701022
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    from mimesis.types import IPAddressType
    i = Internet('en')
    a = i.ip_v6_object()
    b = i.ip_v6_object()
    assert isinstance(a, IPAddressType)
    assert isinstance(b, IPAddressType)
    assert a != b

# Generated at 2022-06-23 21:27:08.057778
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    internet = Internet()
    ip_v6_object = internet.ip_v6_object()
    assert isinstance(ip_v6_object.packed, bytes)


# Generated at 2022-06-23 21:27:10.368218
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    internet = Internet()
    emoji = internet.emoji()
    print(emoji)


# Generated at 2022-06-23 21:27:13.578624
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    i = Internet()
    flag = 0
    for _ in range(100):
        if i.top_level_domain() in TLD['all']:
            flag += 1

    return flag == 100

# Generated at 2022-06-23 21:27:17.721336
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    assert internet.hashtags() == '#love'
    assert isinstance(internet.hashtags(), str)
    assert internet.hashtags(quantity=2) == ['#love', '#nice']
    assert isinstance(internet.hashtags(quantity=2), list)

# Generated at 2022-06-23 21:27:19.424820
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    internet = Internet()
    assert internet.mac_address() != internet.mac_address()


# Generated at 2022-06-23 21:27:22.075964
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    from mimesis.enums import TLDType
    provider = Internet()
    assert provider.home_page(tld_type=TLDType.GOV) == 'https://lqy.gov'

# Generated at 2022-06-23 21:27:24.393849
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    internet = Internet()
    protocols = internet.network_protocol()
    print(protocols)



# Generated at 2022-06-23 21:27:25.556197
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    internet = Internet('en')
    result = internet.http_status_code()
    assert result



# Generated at 2022-06-23 21:27:28.976690
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    internet = Internet()
    mac = internet.mac_address()
    i = 0
    for _ in range(len(mac)):
        if mac[_] == ':':
            i = i + 1
    assert i == 5

# Generated at 2022-06-23 21:27:30.508488
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    internet = Internet()
    assert_match(IPv4Address, internet.ip_v4())


# Generated at 2022-06-23 21:27:32.265763
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    internet = Internet("en")
    ip = internet.ip_v4()
    assert(ip)


# Generated at 2022-06-23 21:27:37.816455
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    from mimesis.enums import Layer, PortRange, TLDType
    from mimesis.providers.internet import Internet
    internet = Internet()
    http_method = internet.http_method()
    assert http_method in ['GET', 'POST', 'PUT', 'DELETE', 'HEAD']


# Generated at 2022-06-23 21:27:38.414359
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    assert Internet().emoji() != ""

# Generated at 2022-06-23 21:27:39.827925
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    obj = Internet()
    obj.ip_v4_object()


# Generated at 2022-06-23 21:27:41.821172
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    provider = Internet()
    result = provider.http_status_code()
    assert(result in HTTP_STATUS_CODES)

# Generated at 2022-06-23 21:27:48.187596
# Unit test for method port of class Internet
def test_Internet_port():
  import pandas as pd
  #df = pd.DataFrame(columns = ['port_range', 'port'])
  df = []
  from mimesis.enums import PortRange
  from mimesis.providers.internet import Internet
  provider = Internet()
  for i in range(1000):
    for port_range in PortRange:
      df.append([port_range, provider.port(port_range = port_range)])
  df = pd.DataFrame(df, columns = ['port_range', 'port'])

  df['is_port_in_range'] = df['port'].apply(lambda x: x >= df['port_range'].min() and x <= df['port_range'].max())
  assert df['is_port_in_range'].all()
# Unit test

# Generated at 2022-06-23 21:28:00.035263
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    internet = Internet()
    ip = internet.ip_v6_object()
    print(ip)
    ip = internet.ip_v6_object()
    print(ip)
    ip = internet.ip_v6_object()
    print(ip)
    ip = internet.ip_v6_object()
    print(ip)
    ip = internet.ip_v6_object()
    print(ip)
    ip = internet.ip_v6_object()
    print(ip)
    ip = internet.ip_v6_object()
    print(ip)
    ip = internet.ip_v6_object()
    print(ip)
    ip = internet.ip_v6_object()
    print(ip)
    ip = internet.ip_v6_object()
    print(ip)

# Generated at 2022-06-23 21:28:01.165751
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    ip_v6 = Internet().ip_v6()
    return ip_v6

# Generated at 2022-06-23 21:28:05.331448
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    internet = Internet()
    mac = internet.mac_address()
    assert type(mac) == str
    assert len(mac.split(':')) == 6



# Generated at 2022-06-23 21:28:08.328755
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    internet = Internet()
    ip = internet.ip_v4()

    assert type(ip) == str
    assert len(ip.split('.')) == 4


# Generated at 2022-06-23 21:28:17.554490
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    """Unit test for method http_method of class Internet"""
    from mimesis.enums import HTTPStatusCode, Layer, MimeType, PortRange
    from mimesis.providers.network import Internet

    internet = Internet()

    print(internet.http_method())

    print(internet.content_type(MimeType.PDF))
    print(internet.http_status_message())
    print(internet.http_status_code())
    print(internet.ip_v4_object())
    print(internet.ip_v4())
    print(internet.ip_v4(with_port=True, port_range=PortRange.ALL))
    print(internet.ip_v6_object())
    print(internet.ip_v6())
    print(internet.mac_address())
    print(internet.emoji())
   

# Generated at 2022-06-23 21:28:22.900060
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    internet = Internet()
    assert internet.image_placeholder() == 'http://placehold.it/1920x1080'
    assert internet.image_placeholder(960, 480) == 'http://placehold.it/960x480'
    
    

# Generated at 2022-06-23 21:28:29.869736
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    import unittest
    from mimesis.enums import Layer

    class TestInternetNetworkProtocol(unittest.TestCase):

        def setUp(self):
            self.internet = Internet()
            self.data = ['AMQP', 'EDP', 'GDP', 'HTTP']
            self.layer = Layer.APPLICATION

        def test_return_value(self):
            result = self.internet.network_protocol(layer=self.layer)
            self.assertIn(result, self.data)

    unittest.main()

# Generated at 2022-06-23 21:28:32.402357
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    test_value = IPv6Address('::1')
    test_instance = Internet()
    test_instance.seed(1)
    result = test_instance.ip_v6_object()
    assert result == test_value

# Generated at 2022-06-23 21:28:35.134800
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    """Check Internet.network_protocol() function work fine."""
    from mimesis.enums import Layer
    internet = Internet()
    assert internet.network_protocol(Layer.APPLICATION)

# Generated at 2022-06-23 21:28:42.947389
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    from mimesis import Person
    from mimesis.enums import Gender
    from mimesis.exceptions import NonEnumerableError

    im = Internet(seed=23)
    image_placeholder = im.image_placeholder()
    assert image_placeholder == "http://placehold.it/1920x1080"
    place = im.image_placeholder(width=50, height=50)
    assert place == "http://placehold.it/50x50"
    place = im.image_placeholder(width="100vh", height="100vh")
    assert place == "http://placehold.it/100vhx100vh"



# Generated at 2022-06-23 21:28:43.920649
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    print(Internet().emoji())

# Generated at 2022-06-23 21:28:47.712232
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    internet = Internet()
    ip_v4 = internet.ip_v4_object()
    print(ip_v4)

if __name__ == '__main__':
    test_Internet_ip_v4_object()

# Generated at 2022-06-23 21:28:57.225865
# Unit test for constructor of class Internet
def test_Internet():
    assert Internet().content_type() == 'Content-Type: application/x-gzip'
    assert Internet().http_status_message() == '200 OK'
    assert Internet().http_status_code() == 500
    assert Internet().http_method() == 'GET'
    assert isinstance(Internet().ip_v4_object(), IPv4Address)
    assert Internet().ip_v4() == '119.20.42.216'
    assert Internet().ip_v4(with_port=True) == '12.60.59.145:9090'
    assert isinstance(Internet().ip_v6_object(), IPv6Address)
    assert Internet().ip_v6() == 'a55c:cfb8:7830:6a1b:8c1c:efb7:fa2f:d9b7'

# Generated at 2022-06-23 21:29:08.847328
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    internet = Internet()

# Generated at 2022-06-23 21:29:12.291440
# Unit test for method port of class Internet
def test_Internet_port():
    for port_range in PortRange:
        _internet = Internet(port_range = port_range)
        _port = _internet.port()
        assert  port_range.value[0] <= _port <= port_range.value[1]

# Generated at 2022-06-23 21:29:15.035973
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    provider = Internet()
    assert isinstance(provider.top_level_domain(None), str)


# Generated at 2022-06-23 21:29:23.842259
# Unit test for constructor of class Internet
def test_Internet():
    # Create instance of Internet
    internet = Internet()
    # Generate random Http status code
    code = internet.http_status_code()
    print(code)

    code_msg = internet.http_status_message()
    print(code_msg)

    http_method = internet.http_method()
    print(http_method)

    ipv4 = internet.ip_v4()
    print(ipv4)

    ipv6 = internet.ip_v6()
    print(ipv6)

    mac = internet.mac_address()
    print(mac)

    emo = internet.emoji()
    print(emo)

    # Generate image placeholder
    image = internet.image_placeholder()
    print(image)

    # Generate random stock image
    # with some search keywords (e.g

# Generated at 2022-06-23 21:29:26.697521
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    i = Internet(seed = 100  )
    ip = i.ip_v4()
    assert ip == '82.104.17.16'


# Generated at 2022-06-23 21:29:30.974865
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    """Unit test for method network_protocol() of class Internet."""
    providers = Internet()
    result = providers.network_protocol(layer=Layer.SECOND)
    layer = result.split(" ")[0].lower()

    assert layer == "link" or layer == "physical"

# Generated at 2022-06-23 21:29:37.533227
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    # Create a seed
    seed = 6
    # Create a instance of class Internet
    internet = Internet(seed)
    # Generate a hashtags
    tag = internet.hashtags()
    # Verify the result
    assert tag == '#love'
    # Generate a hashtags
    tags = internet.hashtags(quantity=2)
    # Verify the result
    assert tags == ['#love', '#sky']


# Generated at 2022-06-23 21:29:39.568940
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    agent = Internet().user_agent()
    assert "Mozilla/5.0" in agent
