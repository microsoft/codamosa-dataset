

# Generated at 2022-06-23 21:19:45.566622
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
        """Test method hashtags of class Internet"""
        # Initialize object Internet
        internet = Internet()
        # Result list random
        result = internet.hashtags(quantity=2)
        # Concatenation result
        result = ''.join(result)
        # Check result
        assert hasattr(result, '__iter__')
        assert len(result) < 4

# Generated at 2022-06-23 21:19:50.139961
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    internet = Internet()
    r1 = internet.content_type()
    r2 = internet.content_type(MimeType.IMAGE)
    print("random internet content_type:", r1)
    print("random image internet content_type:", r2)


# Generated at 2022-06-23 21:19:55.969909
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    # Test top level domain
    from mimesis.enums import TLDType
    from mimesis.providers.internet import Internet
    tld_list = ['com', 'net', 'org', 'eu', 'nl']
    result = Internet().top_level_domain(tld_type=TLDType.GENERIC)
    for tld in tld_list:
        assert tld in result 



# Generated at 2022-06-23 21:19:56.768299
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
  assert Internet().hashtags(1) == '#nice'

# Generated at 2022-06-23 21:19:59.648374
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    """test_Internet_network_protocol"""
    internet = Internet()
    assert internet.network_protocol(layer=Layer.APPLICATION)
    print("Test test_Internet_network_protocol()")

# Generated at 2022-06-23 21:20:00.989863
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    internet = Internet()
    print(internet.ip_v4())



# Generated at 2022-06-23 21:20:03.074080
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    internet = Internet(random=0)

    assert internet.network_protocol(Layer.NETWORK) == 'IP'

# Generated at 2022-06-23 21:20:04.345787
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    internet = Internet()
    assert isinstance(internet.ip_v6(), str)

# Generated at 2022-06-23 21:20:05.657618
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    provider = Internet()
    result = provider.http_method()
    assert isinstance(result, str)
    assert result

# Generated at 2022-06-23 21:20:09.417506
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    internet = Internet()

    ip_v6 = internet.ip_v6_object()
    assert isinstance(ip_v6, IPv6Address)

# Generated at 2022-06-23 21:20:13.587454
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    i = Internet()
    assert isinstance(i.hashtags(), str)
    assert isinstance(i.hashtags(1), str)
    assert isinstance(i.hashtags(2), list)
    assert isinstance(i.hashtags(quantity=5), list)

# Generated at 2022-06-23 21:20:18.921745
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    from mimesis.enums import Hashtag
    from mimesis.exceptions import NonEnumerableError

    internet = Internet()

    # Without category
    res_1 = (set(internet.hashtags())
             == set(internet.hashtags()))
    assert res_1

    # With category
    res_2 = (set(internet.hashtags(Hashtag.ANIMALS))
             == set(internet.hashtags(Hashtag.ANIMALS)))
    assert res_2
    
    # Exception
    with pytest.raises(NonEnumerableError):
        internet.hashtags(quantity=0)

# Generated at 2022-06-23 21:20:27.383511
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    from mimesis.enums import DataType

    class TestInternet(Internet):
        def __init__(self):
            super(TestInternet, self).__init__(seed=492827604)
            self._data_type = DataType.EXTERNAL

    internet = TestInternet()
    assert internet.user_agent() == \
        'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:2.2) Gecko/20100101 Firefox/4.0.1'



# Generated at 2022-06-23 21:20:29.303746
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    quantity = 5

    hashtags = internet.hashtags(quantity)
    assert len(hashtags) == 5

# Generated at 2022-06-23 21:20:33.175092
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    INTERNET = Internet()
    image = INTERNET.stock_image()
    assert isinstance(image, str)
    assert image.startswith('https://source.unsplash.com')

# Generated at 2022-06-23 21:20:36.201864
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    x = Internet()
    ip = x.ip_v6_object()
    if (ip):
        assert True
    else:
        assert False


# Generated at 2022-06-23 21:20:37.740702
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    from mimesis.enums import MimeType

    internet = Internet()
    assert internet.content_type(MimeType.TEXT) == 'Content-Type: text/plain'
    

# Generated at 2022-06-23 21:20:38.713397
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    internet = Internet()
    value = internet.emoji()
    assert value in internet.emoji()


# Generated at 2022-06-23 21:20:40.315127
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    "Test function to test_Internet_ip_v4_object method."
    ip = Internet()
    ip_addr = ip.ip_v4_object()
    assert ip_addr._version == 4



# Generated at 2022-06-23 21:20:41.842180
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    """Test method ip_v4_object of class Internet.
    """
    result = Internet(seed=1).ip_v4_object()
    assert result == IPv4Address(4294967295)


# Generated at 2022-06-23 21:20:43.887214
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    provider = Internet()
    result = provider.image_placeholder()
    print(result)


# Generated at 2022-06-23 21:20:47.017271
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    """Test method `mac_address` of class `Internet`."""
    net = Internet()
    mac = net.mac_address()
    assert isinstance(mac, str)
    assert len(mac) == 17


# Generated at 2022-06-23 21:20:48.035189
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    ipv6=Internet.ip_v6()
    print(ipv6)



# Generated at 2022-06-23 21:20:50.243248
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    internet = Internet()
    ipv4_object = internet.ip_v4_object()

    assert len(str(ipv4_object)) == 15


# Generated at 2022-06-23 21:20:52.599138
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    from mimesis.enums import Dimension

    internet = Internet()

    assert internet.image_placeholder(Dimension.WIDTH, Dimension.HEIGHT) == 'http://placehold.it/1920x1080'

# Generated at 2022-06-23 21:20:55.439522
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    it = Internet()
    res = it.image_placeholder(100, 100)
    assert res == 'http://placehold.it/100x100'

if __name__ == '__main__':
    test_Internet_image_placeholder()

# Generated at 2022-06-23 21:21:00.036643
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    from mimesis.enums import TLDType
    from mimesis.providers.internet import Internet
    inter = Internet()
    result = inter.home_page(TLDType.CCTLD)
    assert result.startswith('https://')
    tld = result.split('.')[-1]
    assert tld in TLD[TLDType.CCTLD]


# Generated at 2022-06-23 21:21:04.082852
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    # Test with enum Layer.Transport
    item = Layer.Transport
    i = Internet()
    result = i.network_protocol(layer=item)
    print("Network protocol of layer " + item.value + " is " + result)

    # Test with enum Layer.Application
    item = Layer.Application
    result = i.network_protocol(layer=item)
    print("Network protocol of layer " + item.value + " is " + result)

    # Test without parameter layer (default Layer.ALL)
    result = i.network_protocol()
    print("Network protocol of ALL layer is " + result)

# Generated at 2022-06-23 21:21:10.087449
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    import random
    from mimesis.enums import Layer
    from mimesis.providers.internet import Internet
    provider = Internet(random)
    protocol = provider.network_protocol(Layer.L3)
    assert protocol in ['IP', 'IPv6']


# Generated at 2022-06-23 21:21:14.154021
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    print("Test for method http_status_code of class Internet")
    internet = Internet()
    x = internet.http_status_code()
    print(x)
    assert (x in HTTP_STATUS_CODES)

# Generated at 2022-06-23 21:21:18.012469
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    # Initialize class
    internet = Internet()

    # Generate HTTP content type
    content_type = internet.content_type()

    # Verification
    assert content_type == 'Content-Type: image/jpg'
    assert internet.content_type() != internet.content_type()



# Generated at 2022-06-23 21:21:20.844977
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    i = Internet()
    for _ in range(100):
        assert len(i.top_level_domain()) == 4


# Generated at 2022-06-23 21:21:24.444738
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    """Test for method network_protocol of class Internet."""
    inter = Internet(seed=123)
    protocol = inter.network_protocol(layer=Layer.APPLICATION)
    assert protocol == 'AMQP'

# Generated at 2022-06-23 21:21:26.706699
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    hashtags = internet.hashtags()
    print(hashtags)
    assert isinstance(hashtags, list) == True, "Internet.hashtags has some errors"

# Generated at 2022-06-23 21:21:34.399275
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    from mimesis.enums import Hashtag
    internet_provider = Internet()
    assert len(internet_provider.hashtags(quantity=1)) == 1
    assert len(internet_provider.hashtags(quantity=4)) == 4
    hashtags = internet_provider.hashtags(quantity=3,
                                          hashtag=Hashtag.ART)
    assert len(hashtags) == 3
    assert hashtags[0] in HASHTAGS['art']

# Generated at 2022-06-23 21:21:36.957145
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    i = Internet()
    print(i.content_type())
    print(i.content_type())
    print(i.content_type())
    print(i.content_type())


# Generated at 2022-06-23 21:21:42.381276
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    """Test method ip_v6_object."""
    internet = Internet('en')
    print(internet.ip_v6_object())
    # 2001:b004:213:6313:1d7b:f37b:ffd1:eba


# Generated at 2022-06-23 21:21:43.486381
# Unit test for constructor of class Internet
def test_Internet():
    assert Internet().seed != None

# Generated at 2022-06-23 21:21:45.234273
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    for i in range(0, 100):
        print(Internet('en').ip_v6())

# Generated at 2022-06-23 21:21:47.030529
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    """Test http_status_message"""
    i = Internet()

    assert i.http_status_message() in HTTP_STATUS_MSGS

# Generated at 2022-06-23 21:21:56.270935
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    from mimesis.enums import Hashtag, TLDType
    from mimesis.providers.internet import Internet

    internet = Internet(seed=0)
    assert internet.hashtags(quantity=2,
                             category=Hashtag.SPORTS) == ['#skate', '#parkour']
    assert internet.hashtags(quantity=1,
                             category=Hashtag.SPORTS) == '#skate'

    assert internet.hashtags(quantity=1) == '#love'

    assert internet.top_level_domain(tld_type=TLDType.COUNTRY) == '.us'



# Generated at 2022-06-23 21:21:57.051996
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    print(Internet().image_placeholder())



# Generated at 2022-06-23 21:21:58.023775
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    internet = Internet()
    res = internet.emoji()
    assert isinstance(res, str)


# Generated at 2022-06-23 21:22:02.639301
# Unit test for constructor of class Internet
def test_Internet():
	# Create instance of class Internet and call method port
	t = Internet()
	assert isinstance(t.port(), int)
	# Create instance of class Internet and call method http_status_message
	t2 = Internet()
	assert isinstance(t2.http_status_message(), str)
	# Create instance of class Internet and call method ip_v4_object
	t3 = Internet()
	assert isinstance(t3.ip_v4_object(), IPv4Address)
	# Create instance of class Internet and call method ip_v6_object
	t4 = Internet()
	assert isinstance(t4.ip_v6_object(), IPv6Address)
	# Create instance of class Internet and call method mac_address
	t5 = Internet()
	assert isinstance(t5.mac_address(), str)
	# Create instance of

# Generated at 2022-06-23 21:22:04.398758
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    Internet().ip_v4_object()


# Generated at 2022-06-23 21:22:14.724739
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    """Unit test for method hashtags of class Internet."""
    from mimesis.enums import TLDType

    tld = TLDType

    print("Hash tags: \n")

    internet = Internet(seed=45454545)
    print("Random quantity: ")
    print(internet.hashtags())

    print("Quantity = 4: ")
    print(internet.hashtags(4))

    print("Quantity = 1: ")
    print(internet.hashtags(1))

    print("Quantity = 0: ")
    print(internet.hashtags(0))


if __name__ == '__main__':
    test_Internet_hashtags()

# Generated at 2022-06-23 21:22:17.070855
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    internet = Internet()
    status = internet.http_status_code()
    assert type(status) == int
    assert len(str(status)) == 3

# Generated at 2022-06-23 21:22:19.711805
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    from mimesis.providers.internet import Internet
    internet = Internet()
    assert len(internet.ip_v6().split(':')) == 8
    assert internet.ip_v6() != internet.ip_v6()


# Generated at 2022-06-23 21:22:26.394974
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    """ Test Internet.home_page() """

    # the random seed needed to initialize the RNG might change anytime
    # so I'm using a constant one just to improve the code readability
    seed = 42
    expected = 'https://Panny_Schiller92.org'

    i = Internet(seed=seed)
    result = i.home_page()

    assert result == expected

# Generated at 2022-06-23 21:22:38.604986
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    from mimesis.enums import MimeType
    from mimesis.exceptions import NonEnumerableError
    from mimesis.utils import ChoiceEnumMeta
    provider = Internet(seed=101)

# Generated at 2022-06-23 21:22:40.594368
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    instance = Internet()
    assert isinstance(instance.ip_v6_object(), IPv6Address)

# Generated at 2022-06-23 21:22:41.426108
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    print(Internet().mac_address())


# Generated at 2022-06-23 21:22:42.784003
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    assert IPv4Address('42.168.204.193') == Internet().ip_v4_object()



# Generated at 2022-06-23 21:22:48.158347
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    try:
        a = Internet()
        b = Internet()
        assert a.ip_v4() != b.ip_v4(), 'Method Internet.ip_v4 must return different values'
    except AssertionError as e:
        print(e)
        assert False


# Generated at 2022-06-23 21:22:49.734251
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    internet = Internet()
    res = internet.emoji()
    assert res in EMOJI
    assert isinstance(res, str)


# Generated at 2022-06-23 21:22:55.098074
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    import ipaddress
    from mimesis.enums import PortRange
    from mimesis.providers.internet import Internet
    from pprint import pprint

    internet = Internet()

    pprint(internet.ip_v4(with_port=True, port_range=PortRange.HIGH))
    assert isinstance(internet.ip_v4_object(), ipaddress.IPv4Address)
    assert isinstance(internet.ip_v4(with_port=True, port_range=PortRange.HIGH), str)

# Generated at 2022-06-23 21:22:56.539034
# Unit test for constructor of class Internet
def test_Internet():
    # get MyClass instance
    internet = Internet()


# Generated at 2022-06-23 21:23:04.679191
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    """test_Internet_ip_v6"""
    from mimesis.enums import Layer
    
    ip_v6 = Internet().ip_v6()
    assert len(ip_v6.split(":")) == 8
    protocol = Internet().network_protocol(Layer.TRANSPORT)
    assert protocol in ['TP4', 'TCP', 'UDP', 'SCTP', 'DCCP', 'RDP', 'SCTP', 'RUDP']
    assert isinstance(Internet().port(), int) and Internet().port() in range(65536)

# Generated at 2022-06-23 21:23:10.014169
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    """Unit test for the method home_page of class Internet."""
    from mimesis.enums import TLDType
    from mimesis.providers.internet import Internet

    inter = Internet()
    for _ in range(10):
        homepage = inter.home_page(tld_type=TLDType.GENERIC_TLD)
        assert isinstance(homepage, str)


# Generated at 2022-06-23 21:23:18.063514
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    from ipaddress import IPv4Address
    from mimesis.enums import PortRange
    from mimesis.providers.internet import Internet

    internet_provider = Internet()
    ip = internet_provider.ip_v4_object()
    assert isinstance(ip, IPv4Address)
    assert isinstance(ip.packed, bytes)

    ip = internet_provider.ip_v4_object()
    assert internet_provider.ip_v4(with_port=True, port_range=PortRange.ALL)
    assert internet_provider.ip_v4(with_port=True, port_range=PortRange.SYSTEM)
    assert internet_provider.ip_v4(with_port=True, port_range=PortRange.HIGH)

# Generated at 2022-06-23 21:23:19.676191
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    """Test to check the method Internet.image_placeholder."""
    internet = Internet()
    i = internet.image_placeholder()
    print(i)


# Generated at 2022-06-23 21:23:20.511240
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    """test_Internet_top_level_domain()"""
    internet = Internet()
    internet.top_level_domain()

# Generated at 2022-06-23 21:23:21.806015
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    obj = Internet()
    assert hasattr(obj, 'emoji')


# Generated at 2022-06-23 21:23:23.671305
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    internet = Internet()
    result = internet.image_placeholder()
    assert result == 'http://placehold.it/1920x1080', 'Not equal'

# Generated at 2022-06-23 21:23:26.075887
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    """Unit test for method emoji of class Internet."""
    internet = Internet()
    for i in range(10):
        assert internet.emoji() in internet.__file.text(max_chars=15)



# Generated at 2022-06-23 21:23:30.438960
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    x = Internet().hashtags(3)
    x = ("#"+Internet().hashtags(1))
    assert isinstance(x, str)
    assert isinstance(Internet().hashtags(4), list)
    assert isinstance(Internet().hashtags(4), tuple)



# Generated at 2022-06-23 21:23:32.299794
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    # GIVEN
    internet_generator = Internet()

    # WHEN
    ip_v4 = internet_generator.ip_v4()

    # THEN
    assert ip_v4 is not None



# Generated at 2022-06-23 21:23:39.701247
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    # Status code must be in range 100 - 599
    # If it is not in this range, then function should raise an error
    class TestData:
        def test_type_error(self):
            from mimesis.exceptions import FieldValueNotFound

            internet = Internet()
            try:
                internet.http_status_code("a")
            except FieldValueNotFound:
                return True

    assert TestData().test_type_error() == True

    # Status code must be in range 100 - 599
    # If it is not in this range, then function should raise an error
    class TestData:
        def test_range_error(self):
            from mimesis.exceptions import FieldValueNotFound

            internet = Internet()

# Generated at 2022-06-23 21:23:41.980631
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    internet = Internet()
    ip_v4_string = internet.ip_v4()
    assert isinstance(ip_v4_string, str)


# Generated at 2022-06-23 21:23:45.263808
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    """Test function home_page of class Internet."""
    ua = Internet()
    #home_page_1 = ua.home_page()
    home_page_2 = ua.home_page(TLDType.CC)
    home_page_3 = ua.home_page(TLDType.ACADEMY)

    assert type(home_page_2) is str
    assert type(home_page_3) is str

test_Internet_home_page()

# Generated at 2022-06-23 21:23:48.516822
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    """Test method home_page of class Internet."""
    inter = Internet()
    assert 'https://' in inter.home_page()
    assert '.' in inter.home_page()



# Generated at 2022-06-23 21:23:51.663371
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    internet = Internet()
    res = internet.image_placeholder(100, 100)

    assert res is not None


# Generated at 2022-06-23 21:23:55.486621
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    internet = Internet()
    protocol = internet.network_protocol(layer=Layer.TCP_IP)
    print(protocol)
    # 'BGP'
    # 'IGMP'
    # 'ICMP'

# Generated at 2022-06-23 21:24:02.597096
# Unit test for method port of class Internet
def test_Internet_port():
    """Test method port of class Internet."""
    internet = Internet()
    port = internet.port(port_range=PortRange.ALL)
    assert isinstance(port, int)
    assert 0 <= port <= 65535

    port = internet.port(port_range=PortRange.PRIVATE)
    assert isinstance(port, int)
    assert 49152 <= port <= 65535

    port = internet.port(port_range=PortRange.PUBLIC)
    assert isinstance(port, int)
    assert 0 <= port <= 49151


# Generated at 2022-06-23 21:24:04.692077
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    a = Internet()
    assert len(a.hashtags(quantity=1)) > 0
    assert len(a.hashtags(quantity=3)) > 0

# Generated at 2022-06-23 21:24:15.761153
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    from mimesis.data import HASHTAGS_POPULAR
    from mimesis.enums import Hashtag
    from mimesis.providers.internet import Internet

    internet = Internet()
    for _ in range(10):
        tags = internet.hashtags(quantity=4)
        assert all(tag.startswith('#') for tag in tags)
        assert all(tag[1:].lower() in HASHTAGS for tag in tags)

    tags = internet.hashtags(5)
    assert isinstance(tags, list)

    tags = internet.hashtags(quantity=1, category=Hashtag.POPULAR)
    assert isinstance(tags, str)
    assert all(tag[1:].lower() in HASHTAGS_POPULAR for tag in tags)



# Generated at 2022-06-23 21:24:22.675443
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    """Test for ``Internet.ip_v6_object()`` method."""
    from ipaddress import IPv6Address
    from mimesis.enums import Protocol
    from mimesis.providers.generic import Provider

    provider = Internet('ru')
    provider._seed(5)

    for _ in range(100):
        result = provider.ip_v6_object()
        assert isinstance(result, IPv6Address)
        assert result.version == Protocol.IPV6



# Generated at 2022-06-23 21:24:26.757621
# Unit test for method port of class Internet
def test_Internet_port():
    """
    Unit test for method port of class Internet
    """
    # Get a random port number within the range.
    start = 1000
    end = 2000
    port_number = Internet(seed=1000).port(PortRange(start, end))
    assert start <= port_number <= end


# Generated at 2022-06-23 21:24:28.418332
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    internet = Internet()
    mac_address = internet.mac_address()
    assert len(mac_address) == 17

# Generated at 2022-06-23 21:24:30.366732
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
   internet = Internet()
   result = internet.mac_address()
   print(result)
   assert True


# Generated at 2022-06-23 21:24:32.686069
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    internet = Internet()
    ip_v6_string = internet.ip_v6()
    assert len(ip_v6_string) == 39

# Generated at 2022-06-23 21:24:37.014569
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    """Unit test for method network_protocol of class Internet"""
    
    internet = Internet()

    network_protocol_7layers = internet.network_protocol(layer=Layer.SEVENTH)
    print(f'Network protocol of the 7th layer - {network_protocol_7layers}')


# Generated at 2022-06-23 21:24:39.249851
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    """Test for method ip_v6 of class Internet.
    """
    internet = Internet()
    ip = internet.ip_v6()

    assert isinstance(ip, str)

# Generated at 2022-06-23 21:24:45.838672
# Unit test for constructor of class Internet
def test_Internet():
    from mimesis.enums import PortRange, TLDType
    from mimesis.providers.internet import Internet

    internet = Internet('en')
    assert isinstance(internet, Internet) == True
    assert internet._MAX_IPV4 == 4294967295
    assert internet._MAX_IPV6 == 340282366920938463463374607431768211455
    assert internet.random == internet._random
    assert internet.seed == internet._seed
    assert internet.provider == 'en-internet'
    assert isinstance(internet.port(port_range=PortRange.ALL), int) == True
    assert isinstance(internet.top_level_domain(tld_type=TLDType.NATIONAL), str) == True
    assert isinstance(internet.user_agent(), str) == True

# Generated at 2022-06-23 21:24:47.766414
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    net = Internet()
    assert net.emoji() in EMOJI


# Generated at 2022-06-23 21:24:50.910025
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    from mimesis.enums import HTTPStatusCode
    gen = Internet('en')
    res = gen.http_status_message()
    assert res in HTTPStatusCode.messages
    assert len(res) > 0

# Generated at 2022-06-23 21:24:57.981713
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    provider = Internet()
    assert IPv4Address(provider.ip_v4())
    provider.seed(1)
    assert provider.ip_v4() == '180.44.3.84'
    assert provider.ip_v4(with_port=True) == '180.44.3.84:8000'
    provider.seed(2)
    assert provider.ip_v4() == '177.198.67.149'
    assert provider.ip_v4(with_port=True) == '177.198.67.149:49153'
    provider.seed(3)
    assert provider.ip_v4() == '60.136.173.26'
    assert provider.ip_v4(with_port=True) == '60.136.173.26:49153'
    provider.seed(4)


# Generated at 2022-06-23 21:24:59.843596
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    internet = Internet()
    print(internet.ip_v6_object())


# Generated at 2022-06-23 21:25:01.814887
# Unit test for method port of class Internet
def test_Internet_port():
    internet = Internet()
    port = internet.port()
    assert port in range(1, 65535)
    assert isinstance(port, int)

# Generated at 2022-06-23 21:25:04.135545
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    internet = Internet()
    http_method = internet.http_method()
    assert http_method in HTTP_METHODS


# Generated at 2022-06-23 21:25:05.850973
# Unit test for method port of class Internet
def test_Internet_port():
    internet = Internet()
    assert 1 <= internet.port() <= 65535



# Generated at 2022-06-23 21:25:08.401436
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    import random
    internet = Internet()
    mac_address = internet.mac_address()
    print(mac_address)
    assert mac_address is not None

# Generated at 2022-06-23 21:25:16.951556
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    from mimesis.enums import Hashtag

    hash_tag_test = Internet(seed=100)

    list_of_hashtags = hash_tag_test.hashtags(5, Hashtag.ANIMALS)
    assert isinstance(list_of_hashtags, list)
    assert len(list_of_hashtags) == 5
    assert all(isinstance(hashtag, str) for hashtag in list_of_hashtags)
    assert all(hashtag[0] == '#' for hashtag in list_of_hashtags)

    single_hashtag = hash_tag_test.hashtags(1, Hashtag.ANIMALS)
    assert single_hashtag[0] == '#frog'


# Generated at 2022-06-23 21:25:21.540622
# Unit test for method port of class Internet
def test_Internet_port():
    from mimesis.enums import PortRange

    internet = Internet()
    port = internet.port(port_range = PortRange.WELL_KNOWN)
    print(port)
    assert isinstance(port, int)
    assert (0 <= port <= 1023)


# Generated at 2022-06-23 21:25:23.933757
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    # given
    internet = Internet()

    # when
    result = internet.ip_v6()
    print(result)

    # then
    pass

# Generated at 2022-06-23 21:25:25.645498
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    """docstring for test_Internet_stock_image."""
    client = Internet()
    print(client.stock_image())

# Generated at 2022-06-23 21:25:29.849713
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    """
        Unit test for method top_level_domain of class Internet
    """
    # as a
    internet = Internet()
    # arrange
    tld_type = TLDType.GENERIC

    # act
    result = internet.top_level_domain(tld_type=tld_type)

    # assert
    assert result in internet.list_items(tld_type=tld_type)

# Generated at 2022-06-23 21:25:31.967151
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    internet = Internet()
    print(internet.ip_v6())


# Generated at 2022-06-23 21:25:33.876221
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    seed = 5
    internet = Internet(seed=seed)
    result = internet.user_agent()
    assert result == "Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:15.0) Gecko/20100101 Firefox/15.0.1"

# Generated at 2022-06-23 21:25:37.962817
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    """Randomly testing method home_page of class Internet."""
    home_page = Internet().home_page()
    print("Random home page: " + home_page)


# Generated at 2022-06-23 21:25:41.855974
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    internet = Internet()

    assert internet.user_agent() == ('Mozilla/5.0 (X11; Ubuntu; Linux x86_64; \
                                      rv:15.0) Gecko/20100101 Firefox/15.0.1')



# Generated at 2022-06-23 21:25:43.793429
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    n1=Internet()
    assert n1.http_status_code() in HTTP_STATUS_CODES


# Generated at 2022-06-23 21:25:48.458289
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    from mimesis.enums import OperatingSystem

    i = Internet()
    assert isinstance(i.user_agent(), str)
    assert i.user_agent(OperatingSystem.LINUX)
    assert i.user_agent(OperatingSystem.WINDOWS)
    assert i.user_agent(OperatingSystem.MACOS)

# Generated at 2022-06-23 21:25:59.059294
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    """Test for method top_level_domain"""
    from mimesis.enums import TLDType

    tld = ["com", "net", "org", "info", "co.uk"]
    for i in range(100):
        tldi = Internet().top_level_domain(tld_type=TLDType.COMMON)
        assert tldi in tld


# Generated at 2022-06-23 21:26:02.379125
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    # When I call method Internet.ip_v6()
    result = Internet.ip_v6()
    # then result is string
    assert isinstance(result, str)


# Generated at 2022-06-23 21:26:05.157355
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    assert  isinstance(Internet().ip_v4_object(), str)
    assert  len(Internet().ip_v4_object()) > 1


# Generated at 2022-06-23 21:26:08.056305
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    """Unit test for method home_page of class Internet."""
    assert Internet().home_page() == 'https://gesser.info'

# Generated at 2022-06-23 21:26:13.932369
# Unit test for method port of class Internet
def test_Internet_port():
    internet = Internet(seed=42)
    assert internet.port(port_range=PortRange.ALL) == 12082
    assert internet.port(port_range=PortRange.LOW) == 8
    assert internet.port(port_range=PortRange.HIGH) == 60674
    assert internet.port(port_range=PortRange.REGISTERED) == 53
    assert internet.port(port_range=PortRange.PRIVATE) == 49152
    assert internet.port(port_range=PortRange.DYNAMIC) == 49153
    assert internet.port(port_range=PortRange.EPHEMERAL) == 49154



# Generated at 2022-06-23 21:26:17.667475
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    ip_ = Internet().ip_v4_object()
    assert isinstance(ip_, IPv4Address)
    assert (str(ip_).count('.') == 3)


# Generated at 2022-06-23 21:26:21.653106
# Unit test for method port of class Internet
def test_Internet_port():
    """Generate random port."""
    from mimesis.enums import PortRange
    port = Internet('en').port(port_range=PortRange.SYSTEM)
    assert isinstance(port, int)
    assert port >= 0 and port <= 1024



# Generated at 2022-06-23 21:26:24.114340
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    """test_Internet_network_protocol"""
    provider = Internet(lang='en')
    result = provider.network_protocol(Layer.TRANSPORT)
    assert result in ['CET', 'TCP']


# Generated at 2022-06-23 21:26:25.438459
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    assert '404 Not Found' in Internet.http_status_message()

# Generated at 2022-06-23 21:26:28.033967
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    internet = Internet()

    for i in range(10):
        assert type(internet.top_level_domain()) == str


# Generated at 2022-06-23 21:26:31.880166
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    assert isinstance(internet.hashtags(), str)
    assert isinstance(internet.hashtags(5), list)
    assert isinstance(internet.hashtags(1), str)

# Generated at 2022-06-23 21:26:32.972679
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet('ru')
    result = internet.hashtags(3)
    assert isinstance(result, list)

# Generated at 2022-06-23 21:26:35.230515
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    internet = Internet()
    status_code = internet.http_status_code()
    assert isinstance(status_code, int)

# Generated at 2022-06-23 21:26:40.119243
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    from mimesis.enums import UserAgentType
    from mimesis.providers.internet import Internet
    from mimesis.providers.user_agent import UserAgent
    from mimesis.typ import Enum
    internet = Internet()
    user_agent = UserAgent(internet._seed)
    internet_user_agent = internet.user_agent()
    user_agent_user_agent = user_agent.user_agent()
    user_agent_user_agent_enum = user_agent.user_agent(
        type_=Enum(UserAgentType))
    assert internet_user_agent == user_agent_user_agent
    assert user_agent_user_agent != user_agent_user_agent_enum

# Generated at 2022-06-23 21:26:49.632117
# Unit test for method port of class Internet
def test_Internet_port():
    from mimesis.enums import PortRange
    internet=Internet()
    assert internet.port()>1023 and internet.port()<65535
    assert internet.port(port_range=PortRange.WELL_KNOWN)>1023 and internet.port(port_range=PortRange.WELL_KNOWN)<49152
    assert internet.port(port_range=PortRange.REGISTERED)>49152 and internet.port(port_range=PortRange.REGISTERED)<65535
    assert internet.port(port_range=PortRange.DYNAMIC_PRIVATE)>49152 and internet.port(port_range=PortRange.DYNAMIC_PRIVATE)<65535

    

# Generated at 2022-06-23 21:26:51.613494
# Unit test for method port of class Internet
def test_Internet_port():
    internet = Internet('en')
    port = internet.port()
    assert port >= 1 and port <= 65535

# Generated at 2022-06-23 21:26:54.417184
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    """Test for Internet class http_status_message."""
    provider = Internet()
    assert provider.http_status_message() in HTTP_STATUS_MSGS


# Generated at 2022-06-23 21:27:02.797006
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    from mimesis.enums import DataClass
    from random import sample
    # import random
    # random.seed(0)
    user_agent = Internet(DataClass.MEDIA_PLAYER).user_agent()
    assert user_agent == 'VLC media player (LIVE555 Streaming Media v2011.12.23) libVLC/2.0.1'
    user_agent = Internet(DataClass.WEB_BROWSER).user_agent()
    assert user_agent == 'Opera/9.80 (Windows NT 6.0) Presto/2.12.388 Version/12.14'
    user_agent = Internet(DataClass.MOBILE_BROWSER).user_agent()

# Generated at 2022-06-23 21:27:06.431838
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    internet = Internet()
    for _ in range(1000):
        assert isinstance(internet.ip_v4(), str)
        assert isinstance(internet.ip_v4(with_port=True), str)


# Generated at 2022-06-23 21:27:09.459024
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    """Unit test for method http_method of class Internet."""
    internet = Internet()
    assert internet.http_method() in HTTP_METHODS


# Generated at 2022-06-23 21:27:13.232718
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    random_mac_address = Internet.mac_address()
    assert isinstance(random_mac_address, str)
    assert re.findall(r'([A-F0-9a-f][A-F0-9a-f]:){5}([A-F0-9a-f][A-F0-9a-f])', random_mac_address)


# Generated at 2022-06-23 21:27:15.636675
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    internet = Internet()
    print(internet.http_status_code())
    print(internet.http_status_code())
    print(internet.http_status_code())

if __name__ == '__main__':
    test_Internet_http_status_code()

# Generated at 2022-06-23 21:27:24.493129
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    internet = Internet()

# Generated at 2022-06-23 21:27:26.576539
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    internet = Internet(seed=42)
    assert IPv4Address(3009) == internet.ip_v4_object()

# Generated at 2022-06-23 21:27:29.723198
# Unit test for constructor of class Internet
def test_Internet():
    try:
        internet = Internet()
        assert internet
        assert internet.seed
        internet = Internet(seed='123')
        assert internet
        assert internet.seed == '123'
    except ImportError:
        return


# Generated at 2022-06-23 21:27:35.890903
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    from mimesis.enums import TLDType
    from mimesis.providers.internet import Internet
    from mimesis.seed import Seed
    import re 

    aa = Seed.create()
    print(aa)
    internet = Internet(aa)
    print(internet.home_page())


if __name__ == '__main__':
    test_Internet_home_page()

# Generated at 2022-06-23 21:27:38.037665
# Unit test for constructor of class Internet
def test_Internet():
    internet = Internet(seed = 10)
    assert internet.__class__.__name__ == 'Internet'

# Generated at 2022-06-23 21:27:40.084084
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    """Check mac_address method of class Internet"""
    e = Internet()
    mac = e.mac_address()
    assert len(mac) == 17

# Generated at 2022-06-23 21:27:42.419117
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    # Given
    generator = Internet()

    # When
    result = generator.stock_image()

    # Then
    assert result.startswith('http://')

# Generated at 2022-06-23 21:27:44.076478
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    pass


# Generated at 2022-06-23 21:27:45.602208
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    _internet = Internet()
    print(
        _internet.content_type()
    )


# Generated at 2022-06-23 21:27:47.437103
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    print('internet.hashtags(quantity=3) -> ', internet.hashtags(quantity=3))


# Generated at 2022-06-23 21:27:49.552625
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    print(Internet().http_status_code())

# Generated at 2022-06-23 21:27:59.325883
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    obj = Internet()
    result = obj.image_placeholder()
    assert result == "http://placehold.it/1920x1080"
    result = obj.image_placeholder(width=600, height=400)
    assert result == "http://placehold.it/600x400"
    result = obj.image_placeholder(width="1x", height="1x")
    assert result == "http://placehold.it/1x1x"
    result = obj.image_placeholder(width="100x100", height="100x100")
    assert result == "http://placehold.it/100x100x100x100"



# Generated at 2022-06-23 21:28:06.188767
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from PIL import Image
    from mimesis import Internet
    
    internet = Internet("en")
    
    # get URL of image
    image_url = internet.stock_image()
    assert type(image_url) is str
    assert "https" in image_url
    
    # get the byte code of the image
    image_bytes= internet.stock_image(writable=True)
    assert type(image_bytes) is bytes
    
    # use the byte code to create an image object
    image_open = Image.open(io.BytesIO(image_bytes))
    image = ImageTk.PhotoImage(image_open)
    
    label = tk.Label(root, image=image)
    label.pack()
    
    root.mainloop()

# Generated at 2022-06-23 21:28:15.945352
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    def test_one_parameter(tld_type=None):
        internet = Internet(seed=123)
        assert internet.top_level_domain(tld_type=tld_type) == '.info'
        assert internet.top_level_domain(tld_type=tld_type) == '.store'
        assert internet.top_level_domain(tld_type=tld_type) == '.info'

    yield test_one_parameter
    def test_two_parameters(tld_type=None):
        internet = Internet(seed=123)
        assert internet.top_level_domain(tld_type=tld_type) == '.com'
        assert internet.top_level_domain(tld_type=tld_type) == '.net'

# Generated at 2022-06-23 21:28:17.037992
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    assert Internet.http_method() in Internet.Meta.fields['http_method']


# Generated at 2022-06-23 21:28:20.804615
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    internet = Internet(seed=0)
    assert (internet.ip_v4_object()).__str__() == "255.255.255.255"



# Generated at 2022-06-23 21:28:27.155072
# Unit test for constructor of class Internet
def test_Internet():
    # When the constructor is called with no parameters
    internet_provider = Internet()
    assert internet_provider is not None
    assert isinstance(internet_provider, Internet)

    # When the constructor is called with parameters
    seed = 10
    internet_provider = Internet(seed=seed)
    assert internet_provider is not None
    assert isinstance(internet_provider, Internet)
    assert internet_provider._seed == seed


# Generated at 2022-06-23 21:28:29.257709
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    print(Internet().network_protocol())
    print(Internet().network_protocol(layer=Layer.TRANSPORT))


# Generated at 2022-06-23 21:28:30.724957
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    internet = Internet()
    print('User-Agent: {}'.format(internet.user_agent()))

# Generated at 2022-06-23 21:28:32.264320
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    ip_int = Internet()
    result = ip_int.home_page()
    assert isinstance(result, str)
    assert "https://" in result

# Generated at 2022-06-23 21:28:34.975483
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    for _ in range(100):
        ct = Internet().content_type()
        assert ct.startswith('Content-Type:')
        assert ct.split(':')[1] in MimeType.__members__


# Generated at 2022-06-23 21:28:38.727396
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():

    internet = Internet()
    result = internet.image_placeholder()
    assert result == 'http://placehold.it/1920x1080'

    result = internet.image_placeholder(100, 100)
    assert result == 'http://placehold.it/100x100'


# Generated at 2022-06-23 21:28:45.548287
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    test_data = [
        (None, 'Content-Type: application/json'),
        ('application/json', 'Content-Type: application/json'),
        ('image/jpeg', 'Content-Type: image/jpeg'),
    ]

    for mime_type, expected in test_data:
        assert expected == Internet().content_type(mime_type=mime_type)



# Generated at 2022-06-23 21:28:47.985528
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    internet = Internet()
    result = internet.ip_v6()
    assert result.count('.') == 7 and result.count(':') == 7

# Generated at 2022-06-23 21:28:49.546164
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    g = Internet()
    print(g.home_page())


# Generated at 2022-06-23 21:28:53.082478
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    # print (type(internet.stock_image(writable=True)))
    assert (internet.stock_image(writable=True))

if __name__ == '__main__':
    test_Internet_stock_image()

# Generated at 2022-06-23 21:29:00.585762
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    internet = object.__new__(Internet)
    internet.random = object.__new__(MockRandom)
    internet.random.choice.return_value = 'com'
    assert internet.top_level_domain() == 'com'

    internet.random.choice.return_value = 'arg'
    assert internet.top_level_domain(TLDType.COUNTRY) == 'arg'

    internet.random.choice.return_value = 'edu'
    assert internet.top_level_domain(TLDType.EDU) == 'edu'

    internet.random.choice.return_value = 'arpa'
    assert internet.top_level_domain(TLDType.ARPA) == 'arpa'

    internet.random.choice.return_value = 'gov'

# Generated at 2022-06-23 21:29:02.553369
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    internet = Internet()
    assert internet.http_status_message() in HTTP_STATUS_MSGS


# Generated at 2022-06-23 21:29:14.709584
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    test_obj1 = Internet()
    ip_v4_value1 = test_obj1.ip_v4(with_port=False,
                                   port_range=PortRange.ALL)
    print('\nip_v4_value1: ', ip_v4_value1)

    test_obj2 = Internet()
    ip_v4_value2 = test_obj2.ip_v4(with_port=False,
                                   port_range=PortRange.ALL)
    print('\nip_v4_value2: ', ip_v4_value2)

    test_obj3 = Internet()
    ip_v4_value3 = test_obj3.ip_v4(with_port=True,
                                   port_range=PortRange.ALL)

# Generated at 2022-06-23 21:29:16.710829
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    internet = Internet()
    data = internet.http_method()
    assert isinstance(data,str)

# Generated at 2022-06-23 21:29:19.584554
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    internet = Internet()
    image_placeholder = internet.image_placeholder(width=1920, height=1080)
    assert(image_placeholder == 'http://placehold.it/1920x1080')

# Generated at 2022-06-23 21:29:26.697490
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    #test code with fixed seed
    gen = Internet(seed = 0)
    print(f"home_page = {gen.home_page()}")
    print(f"home_page = {gen.home_page()}")
    print(f"home_page = {gen.home_page()}")
    print(f"home_page = {gen.home_page()}")

if __name__ == "__main__":
    test_Internet_home_page()

# Generated at 2022-06-23 21:29:29.201604
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    internet = Internet()
    assert internet.ip_v4()
    assert internet.ip_v4() == internet.ip_v4()


# Generated at 2022-06-23 21:29:32.101452
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    internet = Internet()
    s = internet.http_method()
    assert s
    assert isinstance(s, str)
    assert s in HTTP_METHODS


# Generated at 2022-06-23 21:29:34.461973
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    internet = Internet()
    data = internet.home_page()
    assert len(data.split('.')) == 3


# Generated at 2022-06-23 21:29:36.539476
# Unit test for constructor of class Internet
def test_Internet():
    # Internet object is created
    internet = Internet()

    assert internet
    assert internet.seed



# Generated at 2022-06-23 21:29:40.704703
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    # Example result: "c0:c1:c0:0d:00:3e"
    print(Internet('en').mac_address())
    # Example result: "52:54:00:d0:6f:c6"
    print(Internet('ru').mac_address())