

# Generated at 2022-06-21 16:09:48.842155
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    int_prov = Internet()
    assert int_prov.stock_image(1000, 1000) == 'https://source.unsplash.com/1000x1000?'

# Generated at 2022-06-21 16:09:50.300811
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    ip = Internet()
    assert '.' in ip.ip_v4()



# Generated at 2022-06-21 16:09:51.837454
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    i=Internet()
    print(i.ip_v6_object())
    

# Generated at 2022-06-21 16:09:59.164650
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    import random
    import mimesis.enums
    random.seed(0)
    assert Internet().network_protocol(mimesis.enums.Layer.APPLICATION) == 'HTTP'
    random.seed(0)
    assert Internet().network_protocol(mimesis.enums.Layer.NETWORK) == 'IGMP'
    random.seed(0)
    assert Internet().network_protocol(mimesis.enums.Layer.PRESENTATION) == 'ASN.1'


# Generated at 2022-06-21 16:10:01.225876
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    assert Internet().http_status_code() == 404, "Result should be 404"


# Generated at 2022-06-21 16:10:01.913005
# Unit test for constructor of class Internet
def test_Internet():
    pass

# Generated at 2022-06-21 16:10:06.932747
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    from mimesis.enums import PortRange
    from mimesis.providers.network import Internet
    i=Internet()
    ip=i.ip_v4()
    ip1=i.ip_v4(True,PortRange.DEVELOPMENT)
    print(ip)
    print(ip1)
    print(type(ip1))


# Generated at 2022-06-21 16:10:09.619259
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    internet = Internet()
    user_agent = internet.user_agent()
    assert(user_agent is not None)


# Generated at 2022-06-21 16:10:13.542077
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    """
    Purpose: Tests if the user_agent method of Internet class
    returns an item from the user_agents list
    :return:
    """
    from mimesis.enums import DataSource
    from mimesis.providers.internet import Internet
    test_internet = Internet(seed=12345, data_source=DataSource.INTERNAL)

    assert test_internet.user_agent() in USER_AGENTS

# Generated at 2022-06-21 16:10:19.159795
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    """Unit test for method mac_address of class Internet."""
    internet = Internet()
    for _ in range(10):
        mac = internet.mac_address()
        assert (':' in mac), 'Address should have ":"'
        assert (len(mac) == 17), 'Address should have length of 17'


# Generated at 2022-06-21 16:10:43.808342
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    print(internet.stock_image(keywords=['people', 'wood']))
    print(internet.stock_image(keywords=['people', 'wood'], writable=True))


if __name__ == '__main__':
    test_Internet_stock_image()

# Generated at 2022-06-21 16:10:49.128166
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    """Unit test for hashtags of Internet class."""
    internet = Internet()
    data_list = [
        '#instagood',
        '#love',
        '#beautiful',
        '#sun',
    ]
    assert internet.hashtags() in data_list
    assert internet.hashtags(1) in data_list
    assert len(internet.hashtags(0)) == 0
    assert isinstance(internet.hashtags(2), list)

# Generated at 2022-06-21 16:10:51.340814
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    tmp_instance = Internet()
    tmp_instance.content_type(MimeType.APP)


# Generated at 2022-06-21 16:10:55.256052
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    _internet = Internet()
    _ip = _internet.ip_v4()
    print(_ip)

if __name__ == '__main__':
    test_Internet_ip_v4()

# Generated at 2022-06-21 16:10:58.726268
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    internet = Internet()
    macs = [internet.mac_address() for _ in range(10)]
    assert len(macs) == 10
    assert are_unique(macs)


# Generated at 2022-06-21 16:11:03.372649
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    x = Internet()
    assert x.top_level_domain(tld_type=TLDType.COUNTRY) == '.ru'
    assert x.top_level_domain(tld_type=TLDType.GENERIC) == '.com'

# Generated at 2022-06-21 16:11:12.899160
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    from mimesis.enums import Browser
    from mimesis.providers.internet import Internet
    from .tools import random_mim
    mim = random_mim(Internet())

    assert mim.user_agent() in USER_AGENTS

    assert isinstance(mim.user_agent(), str)
    assert len(mim.user_agent()) > 0

    mim = Internet(browser=Browser.SAFARI)
    assert 'safari' in mim.user_agent().lower()

    mim = Internet(browser=Browser.EDGE)
    assert 'edge' in mim.user_agent().lower()

    mim = Internet(browser=Browser.INTERNET_EXPLORER)
    assert 'msie' in mim.user_agent().lower()

    mim = Internet(browser=Browser.OPERA)

# Generated at 2022-06-21 16:11:15.203234
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    intenet_obj = Internet()
    #test_home_page = intenet_obj.home_page()
    #assert(test_home_page == 'https://fontir.info')


# Generated at 2022-06-21 16:11:16.244034
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    assert Internet().http_status_code() in range(100, 600)

# Generated at 2022-06-21 16:11:17.848693
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    a = Internet()
    result = a.stock_image()
    assert result is not None, "Internet().stock_image() should not be None"