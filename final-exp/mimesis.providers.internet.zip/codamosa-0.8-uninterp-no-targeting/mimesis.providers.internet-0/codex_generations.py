

# Generated at 2022-06-21 16:09:42.228907
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    a = Internet()
    assert a.ip_v4()



# Generated at 2022-06-21 16:09:43.716003
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    internet = Internet()
    http_method = internet.http_method()
    assert http_method in HTTP_METHODS


# Generated at 2022-06-21 16:09:51.725694
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    # arrange
    from mimesis.enums import HTTPStatusCode
    provider = Internet()
    # act
    ok_results = [HTTPStatusCode.OK.value for _ in range(0, 4)]
    fail_results = [HTTPStatusCode.BAD_REQUEST.value for _ in range(0, 4)]
    results = []
    for _ in range(0, 8):
        results.append(provider.http_status_code())

    # assert
    assert ok_results[0] in results
    assert ok_results[1] in results
    assert ok_results[2] in results
    assert ok_results[3] in results
    assert fail_results[0] in results
    assert fail_results[1] in results
    assert fail_results[2] in results
    assert fail_results[3] in results

# Generated at 2022-06-21 16:09:54.239069
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    """Testing method Internet::network_protocol."""
    net = Internet()
    assert net.network_protocol(Layer.NETWORK) == "IP"
    print("Ok")


# Generated at 2022-06-21 16:10:00.966629
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    test_cases = [
        (None, '#garden'),
        (1, '#garden'),
        (2, ['#garden', '#sweet']),
        (3, ['#garden', '#sweet', '#baby']),
    ]
    provider = Internet(seed=0)
    for t in test_cases:
        assert provider.hashtags(quantity=t[0]) == t[1]

# Generated at 2022-06-21 16:10:03.618884
# Unit test for constructor of class Internet
def test_Internet():
    internet = Internet()
    internet._Internet__file
    internet._MAX_IPV4
    internet._MAX_IPV6


# Generated at 2022-06-21 16:10:06.735670
# Unit test for method port of class Internet
def test_Internet_port():
    from mimesis.enums import PortRange

    internet = Internet()
    port_range = PortRange.ALL
    port = internet.port(port_range)
    assert port_range.value[0] <= port <= port_range.value[1]

# Generated at 2022-06-21 16:10:09.416938
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    internet = Internet(123)
    result = internet.http_status_code()
    assert result in HTTP_STATUS_CODES

# Generated at 2022-06-21 16:10:10.666346
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    for i in range(1, 10):
        print(Internet().stock_image(1520, 980))
        i += 1

# Generated at 2022-06-21 16:10:13.146312
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    """
    test http_status_message method of Internet class
    """
    in_instance = Internet()
    a = in_instance.http_status_message()
    assert (a in HTTP_STATUS_MSGS)



# Generated at 2022-06-21 16:10:21.511782
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    internet = Internet(seed=9)
    s = set()
    for _ in range(1000):
        s.add(internet.http_status_code())
    print(s)
    assert s >= set(HTTP_STATUS_CODES)

# Generated at 2022-06-21 16:10:32.705272
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    class LayerEnum:
        AP = 0
        CTP = 1
        NLP = 2
        TP = 3
        DL = 4
        LL = 5
        IP = 6
        TP = 7
        TP = 8

    internet = Internet()
    assert internet.network_protocol(LayerEnum.AP) == 'AMQP'
    assert internet.network_protocol(LayerEnum.CTP) == 'DNS'
    assert internet.network_protocol(LayerEnum.NLP) == 'HTTP'
    assert internet.network_protocol(LayerEnum.TP) == 'HTTPS'
    assert internet.network_protocol(LayerEnum.DL) == 'NDP'
    assert internet.network_protocol(LayerEnum.LL) == 'TCP'

# Generated at 2022-06-21 16:10:34.632776
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
  internet = Internet()
  ip = internet.ip_v4_object()
  assert type(ip) == IPv4Address


# Generated at 2022-06-21 16:10:36.122073
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    print(internet.hashtags())
    print(internet.hashtags(1))


# Generated at 2022-06-21 16:10:36.900774
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    Internet.network_protocol()


# Generated at 2022-06-21 16:10:41.575533
# Unit test for constructor of class Internet
def test_Internet():
    # Initialize object
    internet = Internet()

    # Test method
    result = internet.ip_v4()

    print("IP v4:", result)
    # Result:
    # IP v4: 75.58.206.123

# Generated at 2022-06-21 16:10:43.808257
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    assert Internet().emoji()

# Generated at 2022-06-21 16:10:46.953043
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    from mimesis import Internet
    from mimesis.enums import TLDType

    us = Internet()
    print(us.home_page(tld_type=TLDType.GENERIC))


# Generated at 2022-06-21 16:10:53.979924
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    # Test for return value
    expected = ['.com']
    actual = Internet().top_level_domain(tld_type = TLDType.COMMERCIAL)
    assert actual in expected
    
    # Test for error
    try:
        Internet().top_level_domain(tld_type = TLDType.ARBITRARY)
    except NonEnumerableError as e:
        assert "ARBITRARY" in str(e)


# Generated at 2022-06-21 16:10:55.809961
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    obj = Internet()
    result = obj.ip_v4()
    assert isinstance(result, str)


# Generated at 2022-06-21 16:11:12.555704
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    from mimesis.enums import Hashtag
    from mimesis.providers.internet import Internet
    a = Internet()
    if a.hashtags(category=Hashtag.NATURE) is None:
        assert True
    else:
        assert False


# Generated at 2022-06-21 16:11:14.479437
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    p = Internet()
    ip_v6_object = p.ip_v6_object()
    assert isinstance(ip_v6_object, IPv6Address)


# Generated at 2022-06-21 16:11:16.210892
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    for _ in range(10):
        tld = Internet().top_level_domain()
        assert tld in TLD[TLDType.FULL]

# Generated at 2022-06-21 16:11:16.949826
# Unit test for constructor of class Internet
def test_Internet():
    assert Internet().seed == 0


# Generated at 2022-06-21 16:11:18.826274
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    """Unit test for method ip_v4_object of class Internet"""
    assert(str(Internet.ip_v4_object(Internet()))) != ''


# Generated at 2022-06-21 16:11:21.154450
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    internet = Internet()
    assert internet.image_placeholder() == 'http://placehold.it/1920x1080'
    assert internet.image_placeholder(250, 250) == 'http://placehold.it/250x250'


# Generated at 2022-06-21 16:11:23.078927
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    internet = Internet()
    content_type = internet.content_type()
    assert isinstance(content_type, str)
    assert content_type.startswith("Content-Type: ")


# Generated at 2022-06-21 16:11:25.252744
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    '''Test ip_v4_object generated from class Internet'''
    provider = Internet(locale='en')
    result = provider.ip_v4_object()
    assert type(result) == IPv4Address


# Generated at 2022-06-21 16:11:27.468520
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    # Arrange
    internet = Internet()

    # Act
    result = internet.http_method()

    # Assert
    assert result in HTTP_METHODS


# Generated at 2022-06-21 16:11:29.182415
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    inter = Internet('en')
    url = inter.image_placeholder(200, 200)
    print(url)
    assert url == 'http://placehold.it/200x200'


# Generated at 2022-06-21 16:11:42.596991
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    i = Internet()
    status = i.http_status_message()
    assert isinstance(status, str)
    print(status)


# Generated at 2022-06-21 16:11:46.680642
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    from mimesis.enums import TLDType
    from mimesis.providers.internet import Internet

    i = Internet()

    res = i.home_page(tld_type=TLDType.COUNTRY)


# Generated at 2022-06-21 16:11:48.390393
# Unit test for constructor of class Internet
def test_Internet():
    """Test for class Internet."""
    internet = Internet()
    assert internet.seed is not None

# Generated at 2022-06-21 16:11:49.556963
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    internet = Internet()
    assert len(internet.mac_address()) == 17


# Generated at 2022-06-21 16:11:52.961595
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    assert 'http://placehold.it/1920x1080' == \
           Internet.image_placeholder()
    assert 'http://placehold.it/800x400' == \
           Internet.image_placeholder(width=800, height=400)

# Generated at 2022-06-21 16:11:55.422256
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
  print('Internet_stock_image()')
  with open('/tmp/unsplash.jpg', 'wb') as f:
    f.write(Internet.stock_image(width=1920, height=1080, writable=True))

# Generated at 2022-06-21 16:11:57.517036
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    internet = Internet()
    ip = internet.ip_v6()
    assert  isinstance(ip,str) == True


# Generated at 2022-06-21 16:11:59.350510
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    internet_obj = Internet()
    mac_address1 = internet_obj.mac_address()
    mac_address2 = internet_obj.mac_address()
    assert mac_address1 != mac_address2


# Generated at 2022-06-21 16:12:02.660472
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet(locale='vi')
    assert isinstance(internet.hashtags(), str)
    assert isinstance(internet.hashtags(5), list)

# Generated at 2022-06-21 16:12:05.032822
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    internet = Internet()
    for _ in range(50):
        assert int(internet.http_status_code()) < 599


# Generated at 2022-06-21 16:13:09.457756
# Unit test for constructor of class Internet
def test_Internet():
    import datetime
    import mimesis
    internet = mimesis.Internet()
    demo = internet.content_type()
    content = internet.http_method()
    status = internet.http_status_message()
    code = internet.http_status_code()
    ipv4 = internet.ip_v4()
    ipv6 = internet.ip_v6()
    mac = internet.mac_address()
    emoji = internet.emoji()
    hash = internet.hashtags(5)
    home = internet.home_page()
    tld = internet.top_level_domain()
    user = internet.user_agent()
    port = internet.port()
    p = internet.image_placeholder()
    img = internet.stock_image()
    file = internet.file()
    now = datetime.datetime

# Generated at 2022-06-21 16:13:11.273098
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    internet = Internet()

    str1 = internet.ip_v6()
    str2 = internet.ip_v6()

    assert str1 != str2

# Generated at 2022-06-21 16:13:19.829078
# Unit test for constructor of class Internet
def test_Internet():
    a = Internet()
    print(a.image_placeholder())
    print(a.stock_image())
    print(a.stock_image(keywords=['Love', 'Man']))
    print(a.stock_image(keywords=['Love', 'Man']))
    print(a.stock_image(keywords=['Love', 'Man']))
    print(a.stock_image(keywords=['Love', 'Man']))
    print(a.home_page())
    print(a.top_level_domain())
    print(a.user_agent())
    print(a.network_protocol())
    print(a.port())
    print(a.hashtags())
    print(a.emoji())
    print(a.mac_address())
    print(a.ip_v6())
    print

# Generated at 2022-06-21 16:13:21.030082
# Unit test for constructor of class Internet
def test_Internet():
    internet = Internet()

    assert isinstance(internet, Internet)

# Generated at 2022-06-21 16:13:26.497108
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    internet = Internet()    
    mac_address = internet.mac_address()
    if (mac_address != ''):
        print("test_Internet_mac_address test is successfull")
    else:
        print("test_Internet_mac_address test failed")

test_Internet_mac_address()

# Generated at 2022-06-21 16:13:29.818021
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    international = Internet()
    # print(international.http_status_message())
    assert isinstance(international.http_status_message(), str)
    # print(international.http_status_message())


# Generated at 2022-06-21 16:13:35.386855
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    data_provider = Internet()

    # Without params (random)
    protocol = data_provider.network_protocol()
    assert protocol in [
        'IP', 'IPv6', 'IPX', 'IPsec', 'IPv4', 'AppleTalk',
        'ARP', 'RARP', 'SCTP', 'OSPF',
        'IS-IS', 'PPP', 'PPTP', 'ICMP', 'ICMPv6', 'ICMPv4',
        'IGMP', 'IGRP', 'L2TP', 'GRE', 'BGP', 'AODV', 'OSPFv3',
        'IPv4/IPv6', 'IPv4/IPv6/IP', 'IPv4/IPv6/IPsec'
    ]

    # With Layer enum object
    protocol = data_provider.network

# Generated at 2022-06-21 16:13:36.658460
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    a=Internet()
    print(a.content_type())


# Generated at 2022-06-21 16:13:37.696889
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    # ipv4 address generation
    print(Internet().ip_v4_object())

# Generated at 2022-06-21 16:13:43.348752
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    assert internet.stock_image() == 'https://source.unsplash.com/1920x1080?'
    assert internet.stock_image(width=300, height=300) == 'https://source.unsplash.com/300x300?'
    assert internet.stock_image(keywords='nature,flowers') == 'https://source.unsplash.com/1920x1080?nature,flowers'