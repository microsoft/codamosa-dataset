

# Generated at 2022-06-21 16:10:01.638651
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    """Test method ip_v6_object of class Internet."""
    print("Test method ip_v6_object of class Internet")
    # Create object of class Internet
    obj = Internet()
    # Call method of the object
    ip = obj.ip_v6_object()
    # Test result -- if IPv6
    assert isinstance(ip, IPv6Address)


# Generated at 2022-06-21 16:10:03.847365
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    internet = Internet()
    mac = internet.mac_address()
    assert 17 == len(mac)



# Generated at 2022-06-21 16:10:06.910495
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    """Test image_placeholder method of Internet class."""
    internet = Internet()

    assert internet.image_placeholder(width=500, height=500) \
        == 'http://placehold.it/500x500'



# Generated at 2022-06-21 16:10:09.917755
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    internet = Internet()
    home_page = internet.home_page()
    print(home_page)
    assert home_page == 'https://spa.com'


# Generated at 2022-06-21 16:10:11.056847
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    provider = Internet()
    print(provider.user_agent())


# Generated at 2022-06-21 16:10:12.050060
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    internet = Internet()
    print(internet.user_agent())


# Generated at 2022-06-21 16:10:12.749329
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    pass


# Generated at 2022-06-21 16:10:14.156917
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    internet = Internet()
    ip_v6 = internet.ip_v6()
    assert type(ip_v6), "<class 'str'>"

# Generated at 2022-06-21 16:10:17.164168
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    assert random.choice(HTTP_METHODS) in [
        'GET','POST','DELETE','PUT','OPTIONS','HEAD','CONNECT','PATCH','TRACE']

# Generated at 2022-06-21 16:10:19.132396
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    test_obj = Internet()
    test_obj.http_status_code()


# Generated at 2022-06-21 16:10:30.945248
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    """Test hashtags method."""
    internet = Internet()
    hashtags = internet.hashtags(quantity=1)
    assert isinstance(hashtags, str)
    assert type(hashtags) is not list

# Generated at 2022-06-21 16:10:35.598011
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    from mimesis.providers.internet import Internet
    from ipaddress import IPv6Network
    for i in range(20):
        result = Internet('zh-CN').ip_v6()
        print(result)
        try:
            IPv6Network(result, strict=False)
        except ValueError as e:
            assert False, "IPv6Network ValuError: %s" % e


# Generated at 2022-06-21 16:10:47.914920
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    # Unit test for method ip_v6 of class Internet
    from mimesis.enums import Format

    ip = Internet(seed=0)

    # assert isinstance(ip.ip_v6(), str)
    assert ip.ip_v6() == "2001:c244:cf9d:1fb1:c56d:f52c:8a04:94f3"

    assert isinstance(ip.ip_v6_object(), IPv6Address)
    assert ip.ip_v6_object() == IPv6Address(
        42540766411282592847984510677643796866799573523951808766181710)


# Generated at 2022-06-21 16:10:50.041879
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    """Testing method emoji."""
    internet = Internet()
    result = internet.emoji()
    assert isinstance(result, str)
    assert result in EMOJI


# Generated at 2022-06-21 16:10:51.693735
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    internet = Internet()
    statusMsg = internet.http_status_message()
    print(statusMsg)


# Generated at 2022-06-21 16:10:59.153879
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from mimesis.enums import PortRange, TLDType
    from mimesis.providers.internet import Internet
    from mimesis.providers.datetime import Datetime
    from requests import get

    try:
        from PIL import Image
    except ImportError:
        raise ImportError('Module PIL is missing')

    seed = 'MHDgEkza'
    provider = Internet(seed=seed)
    dt = Datetime(seed=seed)
    keywords = ['summer', 'sunny', dt.date()]

    width = provider.port(port_range=PortRange.SYSTEM)
    height = provider.port(port_range=PortRange.MULTIPLEXER)
    url = provider.stock_image(width=width, height=height, keywords=keywords)

# Generated at 2022-06-21 16:11:01.824046
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    _ = Internet()
    assert (_.ip_v6() != _.ip_v6())

# Generated at 2022-06-21 16:11:03.316962
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    assert len(Internet().hashtags()) > 0

# Generated at 2022-06-21 16:11:05.112279
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    ipv4 = Internet()
    assert '.' in ipv4.ip_v4()



# Generated at 2022-06-21 16:11:08.723899
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    # Test with value param mime_type
    mime_type = MimeType.AUDIO
    obj = Internet()
    result = obj.content_type(mime_type)
    assert result == 'Content-Type: audio/x-midi', result


# Generated at 2022-06-21 16:11:20.823428
# Unit test for constructor of class Internet
def test_Internet():
    internet = Internet(seed=1)
    assert isinstance(internet, Internet), 'Cant create instance of Internet'

# Generated at 2022-06-21 16:11:22.263992
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    internet=Internet()
    assert internet.user_agent()=='Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:15.0) Gecko/20100101 Firefox/15.0.1'


# Generated at 2022-06-21 16:11:23.829925
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    """The test method for the method Internet.top_level_domain."""
    assert isinstance(Internet().top_level_domain(), str)

# Generated at 2022-06-21 16:11:25.445619
# Unit test for constructor of class Internet
def test_Internet():
    """Unit test for the constructor of class Internet."""
    inter = Internet()
    assert isinstance(inter, Internet)
    assert inter.__file.seed == inter.seed



# Generated at 2022-06-21 16:11:28.367359
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    prov = Internet()
    results = []

    for i in range(0, 1000):
        results.append(prov.http_status_message())
        assert(isinstance(results[i], str))
        assert(len(results[i]) > 0)


# Generated at 2022-06-21 16:11:32.492769
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    internet = Internet(seed=110)
    first_agent = internet.user_agent()
    assert first_agent == 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.87 Safari/537.36'
    assert internet.user_agent() == 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.87 Safari/537.36'

# Generated at 2022-06-21 16:11:39.739811
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    ''' 
    Search random hashtags with quantity 1
    '''
    t = Internet()
    assert isinstance(t.hashtags(), str)
    assert t.hashtags()[0] == "#"
    assert len(t.hashtags()) > 0
    assert isinstance(t.hashtags(quantity=1), str)
    assert t.hashtags(quantity=1)[0] == "#"
    assert len(t.hashtags(quantity=1)) > 0
    assert isinstance(t.hashtags(quantity=11), list)
    assert len(t.hashtags(quantity=11)) == 11
    assert t.hashtags(quantity=11)[0][0] == "#"

# Generated at 2022-06-21 16:11:41.828985
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    inter=Internet()
    assert type(inter.image_placeholder())==str
    

# Generated at 2022-06-21 16:11:47.486500
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    provider = Internet()
    result = provider.ip_v4()
    assert isinstance(result, str)
    assert len(result.split('.')) == 4
    result = provider.ip_v4(with_port=True)
    assert isinstance(result, str)
    assert len(result.split('.')) == 4
    assert len(result.split(':')) == 2


# Generated at 2022-06-21 16:11:55.140963
# Unit test for method port of class Internet
def test_Internet_port():
    """Unit test for method port of class Internet."""
    port = Internet().port(port_range=PortRange.ALL)
    assert port >= 1 and port <= 65535
    assert isinstance(port, int)

    port = Internet().port(port_range=PortRange.SYSTEM)
    assert port >= 1 and port <= 1023
    assert isinstance(port, int)

    port = Internet().port(port_range=PortRange.USER)
    assert port >= 1024 and port <= 49151
    assert isinstance(port, int)

    port = Internet().port(port_range=PortRange.DYNAMIC)
    assert port >= 49152 and port <= 65535
    assert isinstance(port, int)

# Generated at 2022-06-21 16:12:19.826359
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    """Test Internet.user_agent"""
    check = Internet().user_agent()
    assert isinstance(check, str)

# Generated at 2022-06-21 16:12:24.317581
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    test_Internet = Internet()
    test_Internet.ip_v4()
    test_Internet.ip_v4(port_range=PortRange.WELL_KNOWN)
    test_Internet.ip_v4(with_port=True, port_range=PortRange.TRANSIENT)


# Generated at 2022-06-21 16:12:27.978834
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    # Arrange
    http_status_message = 'OK'
    # Assert
    assert Internet().http_status_message() == http_status_message


# Generated at 2022-06-21 16:12:28.814562
# Unit test for method http_method of class Internet
def test_Internet_http_method():
  inter=Internet()
  http_method=inter.http_method()
  print(http_method)


# Generated at 2022-06-21 16:12:31.071417
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    """Unit test for method image_placeholder of class Internet."""
    assert(Internet.image_placeholder().
           startswith('http://placehold.it/'))

# Generated at 2022-06-21 16:12:36.174169
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    from ipaddress import IPv6Address
    from mimesis.builtins import get_builtin
    from mimesis.enums import Datatype
    
    # Initialize the class
    ip = get_builtin(Datatype.INTERNET)
    
    # Test IPv6 address as object
    ipv6_object = ip.ip_v6_object()
    assert isinstance(ipv6_object, IPv6Address)
    
    
    

# Generated at 2022-06-21 16:12:38.855735
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    internet = Internet()

    print('IPv4 with port')
    print(internet.ip_v4(with_port=True))

    print('IPv4 without port')
    print(internet.ip_v4(with_port=False))


# Generated at 2022-06-21 16:12:40.399014
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    if not (Internet().hashtags(quantity=1)) == '#random':
        print('Error in Internet.hashtags method')


# Generated at 2022-06-21 16:12:41.935851
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    s = Internet()
    assert s.content_type() == 'Content-Type: application/vnd.ms-fontobject'


# Generated at 2022-06-21 16:12:47.655901
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    """Test top_level_domain."""
    random = Internet(seed=0)
    assert random.top_level_domain(TLDType.COUNTRY) == '.ru'
    assert random.top_level_domain(TLDType.GENERIC) == '.com'
    assert random.top_level_domain(TLDType.GENERIC) == '.net'
    assert random.top_level_domain(TLDType.GENERIC) == '.biz'
    assert random.top_level_domain(TLDType.GENERIC) == '.com'
    assert random.top_level_domain(TLDType.GENERIC) == '.info'
    assert random.top_level_domain(TLDType.GENERIC) == '.net'