

# Generated at 2022-06-21 16:10:03.094003
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    x = Internet()
    mac_addr = x.mac_address()
    count_colon = mac_addr.count(":")
    assert count_colon == 5
    mac_addr_split = mac_addr.split(":")
    assert len(mac_addr_split) == 6
    assert mac_addr_split[0] == "00"
    assert mac_addr_split[1] == "16"
    assert mac_addr_split[2] == "3e"
    assert int(mac_addr_split[3], 16) >= 0
    assert int(mac_addr_split[3], 16) <= 127
    assert int(mac_addr_split[4], 16) >= 0
    assert int(mac_addr_split[4], 16) <= 255
    assert int(mac_addr_split[5], 16)

# Generated at 2022-06-21 16:10:10.784041
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    from mimesis.enums import Layer
    from mimesis.enums import NetworkProtocols
    from mimesis.enums import PortRange
    from mimesis.enums import TLDType
    from mimesis.internet import Internet

    internet = Internet('en')
    port_range = PortRange.ALL
    min_port = PortRange.MIN
    max_port = PortRange.MAX
    tld_type = TLDType.CC
    layer_all = Layer.ALL
    layer_link = Layer.LINK
    layer_network = Layer.NETWORK
    layer_transport = Layer.TRANSPORT
    layer_session = Layer.SESSION
    layer_application = Layer.APPLICATION
    layer_presentation = Layer.PRESENTATION
    layer_data_link_mac = Layer.DATA_L

# Generated at 2022-06-21 16:10:12.010464
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    internet = Internet()
    result = internet.emoji()
    assert len(result) > 0


# Generated at 2022-06-21 16:10:13.613616
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    internet = Internet()
    assert isinstance(internet.ip_v4(), str)
    assert isinstance(internet.ip_v4(True), str)


# Generated at 2022-06-21 16:10:24.899047
# Unit test for method port of class Internet
def test_Internet_port():
    from mimesis.enums import PortRange

    gen_port = Internet().port(port_range=PortRange.WELL_KNOWN)
    assert gen_port > 1 and gen_port <= 1023
    gen_port = Internet().port(port_range=PortRange.REGISTERED)
    assert gen_port > 1023 and gen_port <= 49151
    gen_port = Internet().port(port_range=PortRange.DYNAMIC)
    assert gen_port > 49151 and gen_port <= 65535
    gen_port = Internet().port(port_range=PortRange.EPHEMERAL)
    assert gen_port > 32768 and gen_port <= 61000
    gen_port = Internet().port(port_range=PortRange.UNPRIVILEGED)

# Generated at 2022-06-21 16:10:26.993149
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    result = Internet().hashtags()
    print(result)
    assert type(result) is list

# Generated at 2022-06-21 16:10:30.083909
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    b = Internet(seed=0)
    assert b.http_status_message() == '404 Not Found'


# Generated at 2022-06-21 16:10:33.952713
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    data = ['🇩🇰', '🍧', '🇨🇲', '🇩🇪', '🇲🇰', '🇹🇷', '🤡']
    assert Internet().emoji() in data



# Generated at 2022-06-21 16:10:34.709538
# Unit test for constructor of class Internet
def test_Internet():
    instance = Internet()
    assert isinstance(instance, Internet)


# Generated at 2022-06-21 16:10:38.978563
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    from mimesis.enums import Layer
    from mimesis.exceptions import NonEnumerableError
    # network_protocol(self, layer: Optional[Layer] = None)
    i = Internet()
    layer = Layer.APPLICATION
    name = i.network_protocol(layer)
    assert isinstance(name, str)
    assert layer in name
    with pytest.raises(NonEnumerableError):
        i.network_protocol(layer='test')


# Generated at 2022-06-21 16:10:56.047959
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    objInternet = Internet()
    assert objInternet.user_agent() == 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.122 YaBrowser/20.4.1.147 Yowser/2.5 Safari/537.36'


# Generated at 2022-06-21 16:10:58.986613
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    obj = Internet()
    status_message = obj.http_status_message()
    print(status_message)
    print(type(status_message))

# Generated at 2022-06-21 16:11:01.822742
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    assert Internet().emoji() == ":smile:"


# Generated at 2022-06-21 16:11:03.213987
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    """Test method mac_address."""
    internet = Internet()
    mac = internet.mac_address()
    assert isinstance(mac, str)
    assert mac.count(':') == 5



# Generated at 2022-06-21 16:11:07.937736
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    internet = Internet()
    ipv4 = internet.ip_v4(with_port=True, port_range=PortRange.PRIVATE)
    assert isinstance(ipv4, str)
    assert ipv4.count('.')  == 3
    assert ipv4.split(':')[1].isdigit()

# Generated at 2022-06-21 16:11:09.902564
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    for i in range(3):
        assert isinstance(Internet().ip_v4_object(), IPv4Address)



# Generated at 2022-06-21 16:11:11.218182
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    print(Internet().user_agent())


# Generated at 2022-06-21 16:11:14.382437
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    class_name = "Internet"
    method_name = "http_method"
    class_obj = eval(class_name)
    obj = class_obj()
    result = obj.http_method()
    assert method_name in dir(class_obj)
    

# Generated at 2022-06-21 16:11:15.585367
# Unit test for constructor of class Internet
def test_Internet():
    """
    Unit test for constructor of class Internet
    """
    assert Internet() is not None

# Generated at 2022-06-21 16:11:20.823423
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    from mimesis.enums import TLDType
    from mimesis.providers.internet import Internet
    from mimesis.typing import Enum

    _internet = Internet()
    _tld_type = TLDType.GENERAL

    assert isinstance(
        _internet.top_level_domain(tld_type=_tld_type), str
    )
    assert isinstance(
        _internet.top_level_domain(tld_type=_tld_type), str,
    )

# Generated at 2022-06-21 16:11:52.638094
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    from mimesis.enums import TLDType
    print("\nStart testing method home_page of class Internet")

    internet = Internet()
    internet.set_language('en')
    # Test with parameter tld_type
    home_page_1 = internet.home_page(tld_type=TLDType.COMMERCIAL)
    # Test with default value of parameter tld_type
    home_page_2 = internet.home_page()

    print("Test with parameter tld_type: ")
    print(home_page_1)
    print("Test with default value of parameter tld_type: ")
    print(home_page_2)

    print("\nEnd testing method home_page of class Internet")



# Generated at 2022-06-21 16:11:56.885567
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet("en")
    print("--- testing method hashtags of class Internet")
    print("--- print out the result is a string")
    print("--- print out result:")
    print(internet.hashtags(1))
    print("--- print out the result is a list")
    print("--- print out result:")
    print(internet.hashtags(4))

# Generated at 2022-06-21 16:12:01.594603
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    from mimesis.enums import OS
    from mimesis.providers.os import OS
    from mimesis.providers.internet import Internet
    from mimesis.types import Seed
    import re

    os_ = OS(Seed.random())
    os_.choose_os([OS.WINDOWS, OS.LINUX, OS.MAC_OS])

    internet = Internet(Seed.random())
    regex_pattern = re.compile(r'^([0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}$')
    assert regex_pattern.match(internet.mac_address()) is not None


# Generated at 2022-06-21 16:12:08.690837
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    from mimesis.enums import PortRange
    from mimesis.providers.internet import Internet

    INTERNET = Internet()

    ip = INTERNET.ip_v4()

    assert '.' in ip

    ipv4_with_port = INTERNET.ip_v4(with_port=True)
    assert ':' in ipv4_with_port
    assert ip in ipv4_with_port

    ipv4_friendly_port = INTERNET.ip_v4(with_port=True, port_range=PortRange.FRIENDLY)
    assert ':' in ipv4_friendly_port
    assert ip in ipv4_friendly_port

# Generated at 2022-06-21 16:12:10.256911
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    value = Internet().ip_v6_object()
    assert isinstance(value, IPv6Address)

# Generated at 2022-06-21 16:12:14.134915
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    internet = Internet()
    expected_http_methods = 'GET', 'POST', 'PUT', 'DELETE', 'HEAD', 'PATCH', 'OPTIONS'
    assert internet.http_method() in expected_http_methods

# Generated at 2022-06-21 16:12:15.580535
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    internet = Internet()
    a = internet.http_status_message()
    print(a)


# Generated at 2022-06-21 16:12:23.283812
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    from mimesis.enums import Emoji
    emoji_generator = Internet()
    assert emoji_generator.emoji() in Emoji.EMOJI
    assert emoji_generator.emoji() in Emoji.EMOJI
    assert emoji_generator.emoji() in Emoji.EMOJI
    assert emoji_generator.emoji() in Emoji.EMOJI

# Generated at 2022-06-21 16:12:27.099987
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    internet = Internet()
    print(internet.content_type())
    # print(internet.content_type('image'))
    # print(internet.content_type(MimeType.IMAGE))


# Generated at 2022-06-21 16:12:28.890809
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    f = Internet()
    assert 0 < int(f.http_status_code()) < 600


# Generated at 2022-06-21 16:12:58.440783
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    from mimesis.enums import HTTPVerb
    from mimesis.providers.internet import Internet
    from mimesis.typing import Verb
    
    i = Internet()

    v = i.http_method()
    assert isinstance(v, str)
    assert isinstance(v, Verb)
    assert v in HTTPVerb.__members__.values()


# Generated at 2022-06-21 16:12:59.016107
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    pass

# Generated at 2022-06-21 16:13:01.856026
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    from mimesis.enums import Hashtag
    from mimesis.enums import Hashtag
    for item in Hashtag:
        print(item.value)
        print(Internet.hashtags(item.value))



# Generated at 2022-06-21 16:13:03.715182
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    """Unit test for method user_agent of class Internet."""
    internet = Internet()
    result = internet.user_agent()
    assert isinstance(result, str)

# Generated at 2022-06-21 16:13:05.381847
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    """Unit test for method emoji of class Internet."""
    obj = Internet()
    emoji = obj.emoji()
    assert isinstance(emoji, str)
    assert len(emoji) > 0


# Generated at 2022-06-21 16:13:06.775809
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    internet = Internet()
    content_type = internet.content_type()
    assert(len(content_type) > 0)


# Generated at 2022-06-21 16:13:07.913670
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    inter = Internet()
    # Validate the type of the return value
    assert isinstance(inter.content_type(), str)


# Generated at 2022-06-21 16:13:10.293444
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    ip = Internet().ip_v4_object()
    assert isinstance(ip, IPv4Address)


# Generated at 2022-06-21 16:13:12.288724
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    i = Internet()

    for item in range(3):
        i.network_protocol()
        i.network_protocol(Layer.TRANSPORT)

# Generated at 2022-06-21 16:13:13.340498
# Unit test for constructor of class Internet
def test_Internet():
    obj = Internet()
    assert isinstance(obj, Internet)

# Generated at 2022-06-21 16:13:40.660005
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    data = Internet().ip_v4_object()
    assert data is not None
    assert isinstance(data, IPv4Address)


# Generated at 2022-06-21 16:13:42.285318
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    provider = Internet('en')
    result = provider.mac_address()
    assert result[2] == ':'

# Generated at 2022-06-21 16:13:43.912424
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    for _ in range(10):
        assert type(Internet().http_status_message()) == str

# Generated at 2022-06-21 16:13:49.250849
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    print("Method: stock_image of class Internet")
    from mimesis.enums import PortRange
    internet = Internet()
    print("Methods:")
    print("\tinternet.ip_v4()")
    print(internet.ip_v4())
    print("\tinternet.ip_v4(with_port=True)")
    print(internet.ip_v4(with_port=True))
    print("\tinternet.ip_v4(port_range=PortRange.PRIVATE)")
    print(internet.ip_v4(port_range=PortRange.PRIVATE))
    print("\tinternet.ip_v6()")
    print(internet.ip_v6())
    print("\tinternet.mac_address()")
    print(internet.mac_address())

# Generated at 2022-06-21 16:13:53.001185
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    internet = Internet()
    ip = internet.ip_v6()
    assert isinstance(ip, str)
    assert (ip.count('.') == 0) and (ip.count(':') == 7)

# Generated at 2022-06-21 16:13:57.319729
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    print('\n\n=====\ntest_Internet_home_page')
    d = Internet()
    print(d.home_page())
    print(d.home_page(TLDType.FR))


# Generated at 2022-06-21 16:14:00.049625
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    from mimesis.providers.internet import Internet
    from mimesis.enums import HTTPStatusCodes, HTTPStatusCodes

    internet = Internet()
    print(internet.http_status_message())

# Generated at 2022-06-21 16:14:02.330135
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    internet = Internet()
    # Тестируем работу функции Internet.top_level_domain
    assert internet.top_level_domain(TLDType.GOV) == 'mil.id'


# Generated at 2022-06-21 16:14:05.103873
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    """Test for method image_placeholder."""
    data = Internet().image_placeholder()
    assert data == 'http://placehold.it/1920x1080'



# Generated at 2022-06-21 16:14:12.847056
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    internet = Internet()