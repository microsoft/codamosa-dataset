

# Generated at 2022-06-21 16:10:40.288338
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    assert Internet().image_placeholder() == 'http://placehold.it/1920x1080'
    assert Internet().image_placeholder(800, 600) == 'http://placehold.it/800x600'

# Generated at 2022-06-21 16:10:47.954024
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    print(Internet.http_status_code())
    print(Internet.http_status_code())
    print(Internet.http_status_code())
    print(Internet.http_status_code())
    print(Internet.http_status_code())
    print(Internet.http_status_code())
    print(Internet.http_status_code())
    print(Internet.http_status_code())
    print(Internet.http_status_code())
    print(Internet.http_status_code())



# Generated at 2022-06-21 16:10:53.979923
# Unit test for method http_method of class Internet
def test_Internet_http_method():

    # Test 1: method http_method of class Internet should return POST
    internet_provider_1 = Internet(seed=1234)
    assert internet_provider_1.http_method() == "POST"

    # Test 2: method http_method of class Internet should return GET
    internet_provider_2 = Internet(seed=4321)
    assert internet_provider_2.http_method() == "GET"


# Generated at 2022-06-21 16:10:56.553534
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    assert Internet.image_placeholder() == "http://placehold.it/1920x1080"
    assert Internet.image_placeholder(width=50, height=50) == "http://placehold.it/50x50"
    

# Generated at 2022-06-21 16:10:59.449318
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    seed = 1234567
    internet = Internet(seed=seed)
    print(internet.network_protocol(layer=Layer.NETWORK))

# Generated at 2022-06-21 16:11:01.824419
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    it=Internet()
    print(it.mac_address())


# Generated at 2022-06-21 16:11:02.752792
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    internet = Internet()
    print(internet.ip_v4_object())


# Generated at 2022-06-21 16:11:12.402034
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from mimesis.enums import ImageSizeMode
    from mimesis.providers.internet import Internet
    import numpy as np
    from PIL import Image
    import io
    import requests

    keywords = ['sky', 'clouds', 'sun']
    _width = 1920
    _height = 1080
    image_mode = ImageSizeMode.LANDSCAPE

    provider = Internet()
    r_url = provider.stock_image(
        width=_width,
        height=_height,
        keywords=keywords,
        writable=False
    )
    print(r_url)

    r_data = provider.stock_image(
        width=_width,
        height=_height,
        keywords=keywords,
        writable=True
    )

    # get width and height of image
    img = Image

# Generated at 2022-06-21 16:11:19.692847
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    from datetime import datetime
    from random import randint
    from re import compile
    from IPython.display import Image

    seed = randint(0, 100)
    start = datetime.now()
    i = Internet(seed=seed)

    # Test with default args
    img = i.image_placeholder()
    test_img = Image(url=img)
    end = datetime.now()
    time_diff = end - start
    diff_in_seconds = divmod(time_diff.days * 86400 + time_diff.seconds, 60)
    print('Execution time to create an image url: {} seconds {} microseconds'.format(diff_in_seconds[0], diff_in_seconds[1]))
    test_img

    # Test with our custom args
    width = randint(1, 100)


# Generated at 2022-06-21 16:11:26.032494
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    from mimesis.enums import TLDType

    internet = Internet('en')
    assert internet.top_level_domain() in TLD[TLDType.COMMERCIAL]
    assert internet.top_level_domain(TLDType.COMMERCIAL) in TLD[TLDType.COMMERCIAL]
    assert internet.top_level_domain(TLDType.MILITARY) in TLD[TLDType.MILITARY]
    assert internet.top_level_domain(TLDType.INFRASTRUCTURE) in TLD[TLDType.INFRASTRUCTURE]
    assert internet.top_level_domain(TLDType.EXTERNAL) in TLD[TLDType.EXTERNAL]
    assert internet.top_level_domain(TLDType.SPONSOR) in T

# Generated at 2022-06-21 16:12:23.047775
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    """Test that the function returns a random mac address"""
    internet = Internet()
    mac = internet.mac_address()  # noqa: S111
    assert len(mac.split(":")) == 6

# Generated at 2022-06-21 16:12:25.764407
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    """Test method Internet.emoji"""
    result = Internet.emoji()
    print("Emoji:", result)
    assert isinstance(result, str)


# Generated at 2022-06-21 16:12:31.628456
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from mimesis.providers.internet import Internet
    from argparse import Namespace
    # Required arguments
    width = 600
    height = 400
    ns = Namespace(**locals())
    # Optional arguments
    keywords = ['forest']
    writable = True
    internet = Internet('en', seed=0)
    internet.stock_image(width=ns.width, height=ns.height, keywords=keywords, writable=writable)

# Generated at 2022-06-21 16:12:33.356617
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    assert Internet('en').ip_v4() == '182.189.246.149'

# Generated at 2022-06-21 16:12:36.224065
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    internet = Internet()
    home_page = internet.home_page()
    assert home_page is not None and isinstance(home_page, str), home_page

# Generated at 2022-06-21 16:12:43.176837
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    r = list()
    r.append("https://7904.com")
    r.append("https://www.clamity.info")
    r.append("https://www.okaid.com")
    r.append("https://www.runner.com")
    r.append("https://volite.com")
    r.append("https://www.mijam.info")
    r.append("https://www.seo.biz")
    r.append("https://66619.com")
    r.append("https://www.emotional.info")
    r.append("https://www.blah.info")
    r.append("https://www.upc.info")
    r.append("https://www.x.biz")
    r.append("https://www.zany.org")
    r.append

# Generated at 2022-06-21 16:12:50.440991
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    comp = Internet("en")
    assert comp.network_protocol() in NETWORK_PROTOCOLS[0]
    assert comp.network_protocol(layer=Layer.TRANSPORT) in NETWORK_PROTOCOLS[4]
    assert comp.network_protocol(layer=Layer.SESSION) in NETWORK_PROTOCOLS[3]
    assert comp.network_protocol(layer=Layer.PRESENTATION) in NETWORK_PROTOCOLS[2]
    assert comp.network_protocol(layer=Layer.APPLICATION) in NETWORK_PROTOCOLS[5]



# Generated at 2022-06-21 16:12:56.937463
# Unit test for constructor of class Internet
def test_Internet():
    # What we're testing ...
    internet = Internet()

    # ... Internet is an instance of BaseProvider
    assert isinstance(internet, BaseProvider)

    # ... internet has 'internet' as _meta.name
    assert internet._meta.name == 'internet'

    # ... internet has the expected methods...
    assert hasattr(internet, 'ip_v4')

    # ... internet has no unexpected methods...
    assert not hasattr(internet, 'is_this_method_unexpected?')

# Generated at 2022-06-21 16:13:02.597385
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    """Unit test for method ip_v6 of class Internet."""
    internet = Internet(seed=145436635)
    result = internet.ip_v6()
    assert result == '717d:e2c2:23e3:cec3:13a1:d39c:f3e3:a41f'

    internet = Internet(seed=145436635)
    result = internet.ip_v6()
    assert result == '717d:e2c2:23e3:cec3:13a1:d39c:f3e3:a41f'



# Generated at 2022-06-21 16:13:05.076268
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    _internet = Internet("en")
    _home_page = _internet.home_page()
    assert _home_page



# Generated at 2022-06-21 16:14:40.550003
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    from mimesis.providers.internet import Internet
    internet = Internet()
    assert 200 <= internet.http_status_code() <= 600


# Generated at 2022-06-21 16:14:42.587681
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    s = "GET"
    internet = Internet()
    assert internet.http_method().upper() == s.upper()



# Generated at 2022-06-21 16:14:44.105538
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    address = Internet().ip_v4_object()
    assert isinstance(address, IPv4Address) and address.__len__() == 4


# Generated at 2022-06-21 16:14:45.566669
# Unit test for constructor of class Internet
def test_Internet():
    provider = Internet()
    assert provider.__class__.__name__ == 'Internet'
    assert provider._seed is not None


# Generated at 2022-06-21 16:14:55.606960
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    assert Internet().network_protocol(
        layer=Layer.PHYSICAL) == "Ethernet"
    assert Internet().network_protocol(
        layer=Layer.DATALINK) == "Frame Relay"
    assert Internet().network_protocol(
        layer=Layer.NETWORK) == "BGP"
    assert Internet().network_protocol(
        layer=Layer.TRANSPORT) == "TCP"
    assert Internet().network_protocol(
        layer=Layer.SESSION) == "Session Announcement Protocol"
    assert Internet().network_protocol(
        layer=Layer.PRESENTATION) == "Text Encoding for Internet Messages"
    assert Internet().network_protocol(
        layer=Layer.APPLICATION) == "Remote Desktop Protocol"


# Generated at 2022-06-21 16:14:58.123541
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    ip_v6 = Internet().ip_v6()
    assert isinstance(ip_v6, str)
    assert len(ip_v6) == 39


# Generated at 2022-06-21 16:15:01.511335
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    internet = Internet()
    assert internet.content_type()


# Generated at 2022-06-21 16:15:06.269366
# Unit test for method content_type of class Internet
def test_Internet_content_type():
  internet_object = Internet()
  assert isinstance(internet_object.content_type(), str)
  assert internet_object.content_type(MimeType.AUDIO) == 'Content-Type: audio/aac'
  assert internet_object.content_type(MimeType.VIDEO) == 'Content-Type: video/x-msvideo'


# Generated at 2022-06-21 16:15:07.796641
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    """Test ip_v6."""
    ip = Internet().ip_v6()
    assert isinstance(ip, str)
    assert len(ip) > 0

# Generated at 2022-06-21 16:15:13.965549
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    n = Internet()
    assert n.content_type() in [
        'Content-Type: application/xhtml+xml',
        'Content-Type: text/html',
        'Content-Type: application/json',
        'Content-Type: application/javascript',
        'Content-Type: application/ecmascript',
        'Content-Type: text/css',
        'Content-Type: text/csv',
        'Content-Type: text/markdown',
        'Content-Type: text/plain',
        'Content-Type: application/xml',
    ]



# Generated at 2022-06-21 16:17:48.338038
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    internet = Internet()
    assert isinstance(internet.mac_address(),str)


# Generated at 2022-06-21 16:17:49.730926
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    internet = Internet()
    ip = internet.ip_v4_object()
    assert(isinstance(ip, IPv4Address))

# Generated at 2022-06-21 16:17:52.850571
# Unit test for method port of class Internet
def test_Internet_port():
    a = Internet()
    PortRange.ALL.value

    assert a.port() == a.port(PortRange.ALL)
    assert a.port(PortRange.WELL_KNOWN) in range(1024)
    assert a.port(PortRange.REGISTERED) in range(1024, 49151)
    assert a.port(PortRange.DYNAMIC) in range(49152, 65535)


# Generated at 2022-06-21 16:17:54.475715
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    obj_internet = Internet()
    assert IPv6Address(obj_internet.ip_v6())
    print("Method ip_v6 of class Internet works correctly")

# Generated at 2022-06-21 16:17:55.877888
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    provider = Internet()
    print(provider.stock_image(keywords=['girl', 'plane']))

# Generated at 2022-06-21 16:17:56.967312
# Unit test for method port of class Internet
def test_Internet_port():
    internet = Internet(seed=1)
    assert internet.port() == 46471


# Generated at 2022-06-21 16:17:57.924376
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    for i in range(10):
        print(Internet().ip_v6())

# Generated at 2022-06-21 16:17:59.736561
# Unit test for method port of class Internet
def test_Internet_port():
    for _ in range(10):
        port = Internet().port(port_range=PortRange.DEFAULT)

        assert isinstance(port, int)
        assert 0 < port < 1024


# Generated at 2022-06-21 16:18:00.986089
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    internet = Internet()
    img = internet.image_placeholder()
    assert img == "http://placehold.it/1920x1080"


# Generated at 2022-06-21 16:18:02.996443
# Unit test for method emoji of class Internet
def test_Internet_emoji():
#    print('----------test_Internet_emoji----------')
    internet = Internet()
    emj = internet.emoji()
    assert emj in EMOJI
