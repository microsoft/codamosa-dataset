

# Generated at 2022-06-21 16:10:10.447696
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    Internet = Internet()
    assert len(Internet.http_status_message()) > 0


# Generated at 2022-06-21 16:10:11.913321
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    internet = Internet()
    print("\n\nUser-Agent:")
    print("\t", internet.user_agent())



# Generated at 2022-06-21 16:10:16.995367
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    import unittest
    class test_Internet_ip_v6(unittest.TestCase):
        def test_regular(self):
            provider = Internet()
            ip_v6 = provider.ip_v6()
            self.assertRegex(ip_v6, r'^[a-fA-F0-9:]+$')
            # Check if ip_v6 is global unicast address
            if ip_v6[0:4] == '2001':
                self.assertEqual('0', ip_v6[4:5])
            elif ip_v6[0:2] == 'fd':
                self.assertEqual('0', ip_v6[2:3])
            else:
                self.assertEqual('2', ip_v6[0:1])

# Generated at 2022-06-21 16:10:19.365168
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    internet = Internet()
    domain = internet.top_level_domain(TLDType.GENERIC)
    print(domain)


# Generated at 2022-06-21 16:10:24.015730
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    internet = Internet()
    ip = internet.ip_v4()
    assert (len(ip.split('.')) == 4)
    ip = internet.ip_v4(with_port=True)
    assert (len(ip.split(':')) == 2)


# Generated at 2022-06-21 16:10:25.394266
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    a = Internet()
    print(a.top_level_domain())

# Generated at 2022-06-21 16:10:30.979831
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    internet = Internet()
    assert internet.content_type() == 'application/x-7z-compressed'
    assert internet.content_type(MimeType.AUDIO) == 'audio/mp4'
    assert internet.content_type(MimeType.VIDEO) == 'video/x-ms-wmv'


# Generated at 2022-06-21 16:10:37.815465
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    internet = Internet()
    result = internet.http_status_code(seed=5)
    assert result == 207
    result_2 = internet.http_status_code(seed=5)
    assert result_2 == 207
    result_3 = internet.http_status_code(seed=5)
    assert result_3 == 207
    result_4 = internet.http_status_code(seed=6)
    assert result_4 == 207
    result_5 = internet.http_status_code(seed=6)
    assert result_5 == 207
    result_6 = internet.http_status_code(seed=6)
    assert result_6 == 207


# Generated at 2022-06-21 16:10:41.463882
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    """
    Test for method user_agent of class Internet
    """
    internet = Internet()
    user_agent = internet.user_agent()
    print(user_agent)


# Generated at 2022-06-21 16:10:49.897871
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    random_Internet = Internet()
    mac_address = random_Internet.mac_address()
    assert isinstance(mac_address, str)
    assert len(mac_address.split(':')[0]) == 2
    assert len(mac_address.split(':')[1]) == 2
    assert len(mac_address.split(':')[2]) == 2
    assert len(mac_address.split(':')[3]) == 2
    assert len(mac_address.split(':')[4]) == 2
    assert len(mac_address.split(':')[5]) == 2
    assert len(mac_address) == 17