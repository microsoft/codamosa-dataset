

# Generated at 2022-06-21 16:09:49.250841
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    assert Internet().ip_v6_object().__repr__() == "IPv6Address('ace4:a665:4842:8c08:e5a2:5b3a:a5c5:3079')"

# Generated at 2022-06-21 16:09:51.271420
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    internet = Internet()
    ip = internet.ip_v4_object()
    if ip == "" or None:
        raise AssertionError()


# Generated at 2022-06-21 16:09:53.354644
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    test_obj = Internet('en')
    result = test_obj.http_status_code()
    print(result)


# Generated at 2022-06-21 16:09:54.814484
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    internet = Internet(seed=12)
    assert internet.http_status_message() == 'Unknown Error'



# Generated at 2022-06-21 16:09:59.334208
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    """Unit test of network_protocol method of class Internet."""
    internet = Internet()
    protocol = internet.network_protocol(layer=Layer.APPLICATION)
    assert type(protocol) is str

# Generated at 2022-06-21 16:10:00.862677
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    meta = Internet.Meta()
    assert meta.name == 'internet'

# Generated at 2022-06-21 16:10:05.527319
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    """Test result of method content_type.

    Test should return a string similar to this:
    Content-Type: application/json
    """
    internet = Internet()
    result = internet.content_type()
    assert isinstance(result, str)
    assert 'Content-Type: ' in result


# Generated at 2022-06-21 16:10:11.235386
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    # NOTE:  The current unit test is based upon randomness,
    #        and MAY NOT be appropriate for this implementation.
    import re
    hash_tag_regexp = re.compile(r'^#(\w+)\b')
    tags_list = ['#love', '#sky', '#nice']
    assert hash_tag_regexp.findall(' '.join(Internet().hashtags(3))) == tags_list

# Generated at 2022-06-21 16:10:15.710337
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    from mimesis.enums import Hashtag
    internet_generator = Internet()
    assert isinstance(internet_generator.hashtags(quantity=3), list)
    assert isinstance(internet_generator.hashtags(quantity=1), str)
    assert isinstance(internet_generator.hashtags(quantity=4, category=Hashtag.ART,), list)
    try:
        internet_generator.hashtags(category=Hashtag.SPORT,)
    except NonEnumerableError:
        assert True
    else:
        assert False


# Generated at 2022-06-21 16:10:18.640093
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    print('\nTest Internet::user_agent()')
    for i in range(5):
        internet = Internet()
        print(internet.user_agent())


# Generated at 2022-06-21 16:10:35.598179
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    res = internet.hashtags(1)
    assert len(res) == 1, "Failed Internet.hashtags() with param 'quantity=1'"
    res = internet.hashtags(2)
    assert len(res) == 2, "Failed Internet.hashtags() with param 'quantity=2'"
    assert isinstance(res, list), \
        "Failed Internet.hashtags() with param 'quantity=2'"



# Generated at 2022-06-21 16:10:36.972471
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    assert Internet(seed=1).content_type() == "Content-Type: application/rtf"

# Generated at 2022-06-21 16:10:47.916488
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    from mimesis.enums import Width, Height
    from mimesis.providers.internet import Internet
    inst = Internet()
    width = 480
    height = 480
    res = inst.image_placeholder(width=width, height=height)
    assert res == 'http://placehold.it/{width}x{height}'.format(width=width, height=height)
    width = Width.XGA
    height = Height.WUXGA
    res = inst.image_placeholder(width=width.value, height=height.value)
    assert res == 'http://placehold.it/{width}x{height}'.format(width=width.value, height=height.value)


# Generated at 2022-06-21 16:10:50.334372
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    internet = Internet()
    status_code = internet.http_status_code()
    assert status_code in HTTP_STATUS_CODES

test_Internet_http_status_code()


# Generated at 2022-06-21 16:10:55.777162
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    internet = Internet()
    result = internet.network_protocol(layer=Layer.APPLICATION)
    assert (result in [
        'XMPP',
        'SMTP',
        'HTTP',
        'IPMI',
        'POP3',
        'DHCP',
        'BGP',
        'SNMP',
        'AMQP',
    ])

# Generated at 2022-06-21 16:11:02.585494
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    from mimesis.providers.internet import Internet
    from mimesis.enums import MACAddressType
    
    internet = Internet('zh')
    
    mac_address = internet.mac_address()
    print(mac_address)

    mac_address = internet.mac_address(MACAddressType.EUI_64)
    print(mac_address)
    
    

# Generated at 2022-06-21 16:11:07.385081
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    test_data = [
        {
            "input": None,
            "expected_output": '00:16:3e:25:e7:b1'
        },
    ]

    obj = Internet()

    for item in test_data:
        result = obj.mac_address()
        assert result == item.get("expected_output")

# Generated at 2022-06-21 16:11:11.123337
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    """Unit test for method home_page of class Internet."""
    lst = []
    val = 1000
    i = Internet()
    while val > 0:
        data = i.home_page()
        print(data)
        lst.append(data)
        val -= 1
    assert len(lst) == 1000

# Generated at 2022-06-21 16:11:12.973423
# Unit test for method content_type of class Internet
def test_Internet_content_type():
        testElement = Internet()
        # test
        assert "Content-Type: image/jpeg"==testElement.content_type()
        

# Generated at 2022-06-21 16:11:14.857090
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    ipv6_random_address = Internet().ip_v6()
    assert IPv6Address(ipv6_random_address)
    print(ipv6_random_address)