

# Generated at 2022-06-21 16:10:07.039167
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    provider = Internet()

    # Test 1: Generate MAC address with BaseProvider
    test_mac = provider.mac_address()
    assert len(test_mac) == 17
    assert test_mac != provider.mac_address()
    assert test_mac.find(":") != -1

    # Test 2: Generate MAC address with string seed
    provider = Internet(seed="mimesis")
    test_mac2 = provider.mac_address()
    assert test_mac == test_mac2
    assert test_mac.find(":") != -1

    # Test 3: Generate MAC address with integer seed
    provider = Internet(seed=123456789)
    test_mac3 = provider.mac_address()
    assert test_mac == test_mac3
    assert test_mac.find(":") != -1

    # Test

# Generated at 2022-06-21 16:10:11.564629
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    internet = Internet()
    ipv4 = internet.ip_v4()
    assert str(type(ipv4)) == "<class 'str'>"
    ipv4_with_port = internet.ip_v4(with_port=True)
    assert str(type(ipv4_with_port)) == "<class 'str'>"


# Generated at 2022-06-21 16:10:13.248303
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    """Test Internet.http_status_message()."""
    result = Internet().http_status_message()
    assert isinstance(result, str)



# Generated at 2022-06-21 16:10:15.632383
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    assert Internet.top_level_domain(TLDType.CCTLD)

# Generated at 2022-06-21 16:10:18.956861
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    mac_address = Internet.mac_address()
    assert mac_address is not None
    assert len(mac_address) == 17
    assert mac_address == '00:16:3e:25:e7:b1'

# Generated at 2022-06-21 16:10:30.451435
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    from mimesis.enums import Provider
    from mimesis.providers.date import DateTime
    from mimesis.providers.internet import Internet

    data = list()
    for _ in range(100):
        internet = Internet(seed=123)
        emoji = internet.emoji()
        data.append(emoji)


# Generated at 2022-06-21 16:10:33.952500
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    from mimesis.enums import MimeType
    from mimesis.providers.file import File
    from mimesis.providers.internet import Internet

    class Meta:
        name = 'internet'

    class Internet(Internet, metaclass=Meta):
        pass

    uut = Internet(seed=42)

    result = uut.image_placeholder()
    assert result == 'http://placehold.it/1920x1080'

    result = uut.image_placeholder('100%', '100%')
    assert result == 'http://placehold.it/100%25x100%25'

# Generated at 2022-06-21 16:10:34.821043
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    internet = Internet()
    emoji = internet.emoji()
    assert isinstance(emoji, str)

# Generated at 2022-06-21 16:10:40.137142
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    from mimesis.enums import HTTPStatusType
    from mimesis.providers.internet import Internet
    mimesis_internet = Internet('en')
    if mimesis_internet.http_status_code() not in HTTPStatusType:
        print("Error on http_status_code")
        return False
    return True


# Generated at 2022-06-21 16:10:43.083245
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    i = Internet()
    assert i.image_placeholder() == 'http://placehold.it/1920x1080'

# Generated at 2022-06-21 16:11:07.163512
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    from mimesis.enums import Hashtag

    internet = Internet()
    assert internet.hashtags() == '#sky'
    assert internet.hashtags(Hashtag.NATURE) == '#pretty'
    assert internet.hashtags(Hashtag.ANIMALS) == '#lion'
    assert internet.hashtags(Hashtag.INTERESTING) == '#love'
    assert internet.hashtags(Hashtag.CITIES) == '#city'
    assert internet.hashtags(quantity=2) == '#sun'



# Generated at 2022-06-21 16:11:11.992841
# Unit test for method port of class Internet
def test_Internet_port():
    internet = Internet()
    assert internet.port(port_range=PortRange.PRIVILEGED) == '80'
    assert internet.port(port_range=PortRange.UNPRIVILEGED) == '1024'
    assert internet.port(port_range=PortRange.ALL) == '0'
    assert internet.port(port_range=PortRange.SYSTEM_ONLY) == '0'

# Generated at 2022-06-21 16:11:14.381851
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    internet = Internet()
    result = internet.http_status_message()
    print(result)
    assert isinstance(result, str) is True


# Generated at 2022-06-21 16:11:15.825026
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    internet = Internet()
    print(internet.ip_v4_object())


# Generated at 2022-06-21 16:11:17.646837
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    """Unit test for method http_method in class Internet."""
    inter = Internet()
    assert inter.http_method() in HTTP_METHODS


# Generated at 2022-06-21 16:11:18.957915
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    """Test method ip_v6."""
    assert isinstance(Internet().ip_v6(), str)

# Generated at 2022-06-21 16:11:22.973676
# Unit test for method port of class Internet
def test_Internet_port():
    internet = Internet()
    assert internet.port(PortRange.ALL) in [_ for _ in range(1, 65535)]
    assert internet.port(PortRange.WELL_KNOWN) in [_ for _ in range(1, 1024)]
    assert internet.port(PortRange.USER) in [_ for _ in range(1024, 49151)]
    assert internet.port(PortRange.PRIVILEGED) in [_ for _ in range(49152, 65535)]

# Generated at 2022-06-21 16:11:24.235306
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    data = Internet()
    result = data.emoji()
    assert (result in EMOJI)

# Generated at 2022-06-21 16:11:29.115672
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    i = Internet()
    ip = i.ip_v6()
    assert len(ip) > 0
    assert len(ip) < 42
    assert ip.count('.') == 3
    assert not ip.startswith('127.')
    assert not ip.startswith('192.168.')
    assert not ip.startswith('169.254.')
    assert not ip.startswith('10.')
    assert not ip.startswith('172.16.')
    assert not ip.startswith('172.31.')



# Generated at 2022-06-21 16:11:31.563491
# Unit test for constructor of class Internet
def test_Internet():
    """Unit test for constructor of class Internet."""
    internet = Internet()
    assert internet is not None

# Generated at 2022-06-21 16:11:40.797267
# Unit test for constructor of class Internet
def test_Internet():
    Internet()


# Generated at 2022-06-21 16:11:43.140184
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    # Arrange
    item = Internet()

    # Act
    result = item.ip_v6()

    # Assert
    assert result is not None


# Generated at 2022-06-21 16:11:46.974633
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    internet = Internet()
    assert internet.ip_v6() == '2601:53:c640:9f00:693e:5c5f:ecfc:8e2e'


# Generated at 2022-06-21 16:11:48.466564
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    internet = Internet()
    home_page = internet.home_page()
    print(home_page)


# Generated at 2022-06-21 16:11:49.631177
# Unit test for constructor of class Internet
def test_Internet():
    generator = Internet()
    assert generator is not None


# Generated at 2022-06-21 16:11:52.745306
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    test_provider = Internet()

    image = test_provider.image_placeholder()

    assert isinstance(image, str)
    assert 'http://placehold.it' in image


# Generated at 2022-06-21 16:11:55.861765
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    """Unit test for method top_level_domain of class Internet."""
    internet = Internet()
    tld_list = internet.top_level_domain()
    print(tld_list)


if __name__ == '__main__':
    test_Internet_top_level_domain()

# Generated at 2022-06-21 16:11:59.163215
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    import unittest

    class InternetTestCase(unittest.TestCase):
        def setUp(self) -> None:
            self.internet = Internet()

        def test_http_method(self) -> None:
            self.assertIn(
                self.internet.http_method(),
                HTTP_METHODS,
            )

    unittest.main()


# Generated at 2022-06-21 16:12:01.372970
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    """Unit test for method ip_v4_object of class Internet."""
    from ipaddress import IPv4Address
    import pytest
    from mimesis.providers.internet import Internet

    ip = Internet().ip_v4_object()
    assert(type(ip) == IPv4Address)


# Generated at 2022-06-21 16:12:04.143896
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    for _ in range(1000):
        method = Internet().http_method()
        assert method in HTTP_METHODS
