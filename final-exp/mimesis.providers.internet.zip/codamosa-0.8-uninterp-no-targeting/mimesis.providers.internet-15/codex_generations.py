

# Generated at 2022-06-21 16:10:28.695795
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    provider = Internet()
    result = provider.image_placeholder(1024, 1024)
    assert isinstance(result, str)
    assert str.startswith(result, 'http://placehold.it')


# Generated at 2022-06-21 16:10:30.451572
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    import mimesis
    result = mimesis.Internet().mac_address()
    assert result is not None

# Generated at 2022-06-21 16:10:32.093240
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    internet = Internet()
    assert internet.emoji() == internet.emoji()


# Generated at 2022-06-21 16:10:33.004617
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    Internet().ip_v6_object()
    assert True

# Generated at 2022-06-21 16:10:35.875893
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    i = Internet(iid=True, seed=True)
    website = i.top_level_domain(tld_type=TLDType.GEOGRAPHY)
    assert website in TLD[TLDType.GEOGRAPHY]

# Generated at 2022-06-21 16:10:38.181345
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    assert isinstance(Internet().user_agent(), str)



# Generated at 2022-06-21 16:10:40.394384
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    internet = Internet()
    result = internet.emoji()
    assert len(result) >= 1


# Generated at 2022-06-21 16:10:44.597399
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    """Unit test for method network_protocol of class Internet."""
    internet = Internet(seed=1)
    assert internet.network_protocol(layer=Layer.APPLICATION) == 'AMQP'



# Generated at 2022-06-21 16:10:51.891176
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    from mimesis.enums import DomainType
    from mimesis.enums import Layer
    from mimesis.enums import MimeType
    from mimesis.enums import PortRange
    from mimesis.enums import TLDType
    from mimesis.providers.internet import Internet
    from mimesis.providers.network import Network
    from mimesis.providers.security import Security
    from mimesis.types import CustomDataType
    from mimesis.providers.file import File
    from mimesis.providers.utils import Utilities
    from mimesis.enums import Language
    from mimesis.providers.localization import Localization
    from mimesis.builtins import LocalisationMixin
    from mimesis.builtins import Basic
    from datetime import datetime

# Generated at 2022-06-21 16:10:54.387267
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    ip = Internet()
    assert ip.http_status_message() in HTTP_STATUS_MSGS


# Generated at 2022-06-21 16:11:20.940127
# Unit test for constructor of class Internet
def test_Internet():
    """Test class Internet."""
    internet = Internet()
    assert internet.seed is not None

    internet = Internet('1234')
    assert internet.seed == 1234



# Generated at 2022-06-21 16:11:22.535985
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    from mimesis.enums import MimeType

    i = Internet()
    assert isinstance(i.content_type(MimeType.APPLICATION), str)


# Generated at 2022-06-21 16:11:23.862104
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    from mimesis import Internet
    internet = Internet()
    print(internet.http_status_message())


# Generated at 2022-06-21 16:11:30.053589
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    import random
    import string
    import unittest

    from mimesis.enums import Layer, PortRange
    from mimesis.exceptions import MimesisError

    from . import Internet

    class InternetTestCase(unittest.TestCase):

        def setUp(self):
            self.seed = 12345
            self.internet = Internet(self.seed)

        def test_image_placeholder(self):
            result = self.internet.image_placeholder(width=100, height=100)
            self.assertEqual('http://placehold.it/100x100', result)

        def test_stock_image(self):
            result = self.internet.stock_image(
                width=100, height=100,
            )

# Generated at 2022-06-21 16:11:32.879799
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    """Unit test for method ip_v6 of class Internet"""
    ip_v6_object = Internet().ip_v6_object()
    assert isinstance(ip_v6_object, IPv6Address)


# Generated at 2022-06-21 16:11:36.279343
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    internet = Internet()
    for i in TLD:
        for j in range(5):
            tld = internet.top_level_domain(tld_type=i)
            print(i, tld)


# Generated at 2022-06-21 16:11:37.627281
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    for content in Internet().stock_image():
        print(content)

# Generated at 2022-06-21 16:11:39.045680
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    internet = Internet()
    status = internet.http_status_message()
    assert status in HTTP_STATUS_MSGS


# Generated at 2022-06-21 16:11:41.168415
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    i = Internet()
    print(i.stock_image(width = 100, height = 100, writable = False))
    result = i.stock_image(writable = True)
    with open(i.file_name(), "wb") as f:
        f.write(result)


# Generated at 2022-06-21 16:11:50.736822
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    from mimesis.enums import Browser
    from mimesis.enums import OperatingSystem
    from mimesis.enums import Platform
    from mimesis.enums import RenderingEngine
    assert Internet().user_agent() == 'User-Agent: Mozilla/5.0 (X11; Linux x86_64; rv:10.0) Gecko/20100101 Firefox/10.0.1'
    assert Internet().user_agent(browser=Browser.CHROME) == 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36'

# Generated at 2022-06-21 16:12:48.236519
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    """Unit test for method ip_v4_object of class Internet."""
    e = Internet()
    assert isinstance(e.ip_v4_object(), IPv4Address)


# Generated at 2022-06-21 16:12:58.440843
# Unit test for method port of class Internet
def test_Internet_port():
    from mimesis.enums import PortRange
    from mimesis.exceptions import NonEnumerableError

    internet = Internet(random_state=False)
    port = None
    try:
        port = internet.port(port_range='unknown')
    except NonEnumerableError:
        assert port is None
    assert internet.port(port_range=PortRange.WELL_KNOWN) in \
        range(0, 1023)
    assert internet.port(port_range=PortRange.REGISTERED) in \
        range(1024, 49151)
    assert internet.port(port_range=PortRange.DYNAMIC) in \
        range(49152, 65535)
    assert internet.port(port_range=PortRange.ALL) in \
        range(0, 65535)


# Generated at 2022-06-21 16:13:00.287998
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    result = Internet().mac_address()
    assert len(result) == 17, result

# Generated at 2022-06-21 16:13:07.286209
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    from mimesis.enums import Layer

    assert Internet().ip_v6_object().is_global
    assert Internet().ip_v6_object().is_link_local
    assert Internet().ip_v6_object().is_loopback
    assert Internet().ip_v6_object().is_multicast
    assert Internet().ip_v6_object().is_reserved
    assert Internet().ip_v6_object().is_site_local
    assert Internet().ip_v6_object().is_unspecified

    assert Internet().ip_v6_object().version == 6
    assert Internet().network_protocol(Layer.APPLICATION)
    assert Internet().network_protocol(Layer.PRESENTATION)
    assert Internet().network_protocol(Layer.SESSION)

# Generated at 2022-06-21 16:13:12.074807
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    from mimesis.enums import Layer, MimeType, PortRange, TLDType
    #global Layer, MimeType, PortRange, TLDType
    global Internet
    internet = Internet()
    ip_v6 = internet.ip_v6()
    assert ip_v6 != '0'
    assert isinstance(ip_v6, str) == True
    print (ip_v6)


# Generated at 2022-06-21 16:13:20.899967
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    instance = Internet()

# Generated at 2022-06-21 16:13:21.919085
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    ip = Internet().ip_v4_object()

# Generated at 2022-06-21 16:13:27.403493
# Unit test for constructor of class Internet
def test_Internet():
    # Parameterized constructor
    internet = Internet(seed=1)
    assert internet.__class__.__name__ == 'Internet'

    # No-parameter constructor
    internet = Internet()
    assert internet.__class__.__name__ == 'Internet'


# Generated at 2022-06-21 16:13:34.178714
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    i = Internet('en')
    assert i.network_protocol(layer=Layer.APPLICATION) in ['DDP', 'RPC', 'FCP', 'SCP', 'BEEP']
    assert i.network_protocol(layer=Layer.BUSINESS) in ['X.25', 'Frame Relay', 'ATM', 'SONET/SDH', 'ISDN', 'PPP']
    assert i.network_protocol(layer=Layer.DATA_LINK) in ['ATM', 'L2TP', 'ISDN', 'PPP', 'HDLC', 'Ethernet', 'LAPS', 'FDDI', 'Token ring', 'ARCNET', 'WiFi', 'Bluetooth', 'IrDA', 'Fiber', 'Frame Relay', 'ADSL', 'GPRS', 'DVB-H']
    assert i.network_prot

# Generated at 2022-06-21 16:13:36.621674
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    internet = Internet()
    http_method = internet.http_method()
    assert http_method in HTTP_METHODS

# Generated at 2022-06-21 16:14:54.812845
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    assert Internet().http_status_code() in HTTP_STATUS_CODES, 'Generating http status code is wrong'


# Generated at 2022-06-21 16:14:57.293602
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    internet = Internet()
    assert isinstance(internet.ip_v4(), str)


# Generated at 2022-06-21 16:15:07.552769
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    # Example for layer 1 of the OSI model
    assert Internet().network_protocol(layer=Layer.LAYER_1) == 'Ethernet'
    # Example for layer 2 of the OSI model
    assert Internet().network_protocol(layer=Layer.LAYER_2) == 'SNMP'
    # Example for layer 3 of the OSI model
    assert Internet().network_protocol(layer=Layer.LAYER_3) == 'DCCP'
    # Example for layer 4 of the OSI model
    assert Internet().network_protocol(layer=Layer.LAYER_4) == 'TCP'
    # Example for layer 5 of the OSI model
    assert Internet().network_protocol(layer=Layer.LAYER_5) == 'RTP'
    # Example for layer 6 of the OSI model


# Generated at 2022-06-21 16:15:15.537594
# Unit test for method port of class Internet
def test_Internet_port():
    class PortRange_value:
        SYSTEM = (1, 1023)
        USER = (1024, 49151)
        DYNAMIC = (49152, 65535)
        ALL = (1, 65535)

    class PortRange(Enum):
        SYSTEM = PortRange_value.SYSTEM
        USER = PortRange_value.USER
        DYNAMIC = PortRange_value.DYNAMIC
        ALL = PortRange_value.ALL

        def __str__(self):
            return self.name

    t = Internet()
    result = []
    for i in range(10000):
        result.append(t.port(PortRange.SYSTEM))
    for i in range(10000):
        result.append(t.port(PortRange.USER))

# Generated at 2022-06-21 16:15:17.305954
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    internet = Internet()
    url = internet.image_placeholder(250, 250)
    assert url == 'http://placehold.it/250x250'

# Generated at 2022-06-21 16:15:23.022897
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    from mimesis.enums import HTTPStatusMessage
    from mimesis.providers.internet import Internet
    generator_1 = Internet()
    for i in range(100):
        random_value = generator_1.http_status_message()
        assert random_value in HTTPStatusMessage.__members__.values()


# Generated at 2022-06-21 16:15:27.275834
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    internet = Internet(seed=5)
    assert internet.user_agent() == 'Mozilla/5.0 (Windows; U; Windows NT 5.1; ' \
                                    'en-US) AppleWebKit/525.13 (KHTML, like Gecko) ' \
                                    'Chrome/0.A.B.C Safari/525.13'




# Generated at 2022-06-21 16:15:31.827309
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    from mimesis.enums import Layer
    from mimesis.providers.internet import Internet
    internet = Internet('en')
    for i in range(2):
        print(internet.network_protocol(layer=Layer.APPLICATION))


# Generated at 2022-06-21 16:15:38.650383
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from mimesis.enums import Dimension
    from PIL import Image


    provider = Internet('en')

    print('Generate random stock image with default settings')
    print(provider.stock_image())


    print('Generate random stock image with specific dimension')
    print(provider.stock_image(Dimension.PX_320_240))


    print('Generate random stock image with custom dimension')
    print(provider.stock_image(640, 480))


    print('Generate random stock image with search keywords')
    print(provider.stock_image(keywords=['cat', 'dog']))


    print('Generate random stock image as writable object')

# Generated at 2022-06-21 16:15:40.995804
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    ipv4 = Internet()
    print(ipv4.ip_v4())
