

# Generated at 2022-06-21 16:09:48.213941
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    a = Internet()
    res = []
    for b in range(10):
        method = a.http_method()
        res.append(method)
    res_set = set(res)
    assert len(res_set) == 10



# Generated at 2022-06-21 16:09:50.035841
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    internet = Internet()
    http_status_message = internet.http_status_message()
    print(http_status_message)
    

# Generated at 2022-06-21 16:09:52.865939
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    from mimesis.enums import HTTPStatusCode
    obj = Internet()
    func = obj.http_status_code
    assert func() in obj.random.choice(HTTPStatusCode.ALL_CODES.value)


# Generated at 2022-06-21 16:09:54.093304
# Unit test for constructor of class Internet
def test_Internet():
    i = Internet()
    assert isinstance(i, Internet)



# Generated at 2022-06-21 16:10:04.933910
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    assert Internet().network_protocol(layer=Layer.TRANSPORT) == 'TCP'
    assert Internet().network_protocol(layer=Layer.PRESENTATION) == 'NFS'
    assert Internet().network_protocol(layer=Layer.SESSION) == 'SSDP'
    assert Internet().network_protocol(layer=Layer.APPLICATION) == 'SIP'
    assert Internet().network_protocol(layer=Layer.DATA_LINK) == '802.2'
    assert Internet().network_protocol(layer=Layer.NETWORK) == 'TCP/IP'
    assert Internet().network_protocol(layer=Layer.PHYSICAL) == '802.11'



# Generated at 2022-06-21 16:10:09.132344
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    import ipaddress

    internet = Internet()
    ipv6 = internet.ip_v6()
    assert ipaddress.IPv6Address(ipv6) == ipaddress.ip_address(ipv6)
    assert ipaddress.ip_address(ipv6).version is 6

# Generated at 2022-06-21 16:10:10.400992
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    dt = Internet()
    result = dt.home_page()
    print(result)


# Generated at 2022-06-21 16:10:11.330466
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    test_Internet = Internet()
    test_Internet.user_agent()


# Generated at 2022-06-21 16:10:13.014892
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    tld = Internet().top_level_domain(tld_type = TLDType.GOV)
    assert isinstance(tld, str)


# Generated at 2022-06-21 16:10:19.590593
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    internet = Internet()
    assert internet.network_protocol(Layer.APP) == 'RTP'
    assert internet.network_protocol(Layer.TRANSPORT) == 'GRE'
    assert internet.network_protocol(Layer.LINK) == 'L2TP'
    assert internet.network_protocol(Layer.NET) == 'ICMP'


# Generated at 2022-06-21 16:11:11.763312
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    from mimesis.enums import MimeType
    from test_cases import *

    n = 1  # How many times we test json content type
    assert create_random_instance(Internet, n).content_type(MimeType.JSON) == 'Content-Type: application/json'

    # HOW IT WORKS IN REALITY
    # n = 1  # How many times we test json content type
    # assert Internet(n).content_type(MimeType.JSON) == 'Content-Type: application/json'


# Generated at 2022-06-21 16:11:13.222239
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    internet = Internet()
    result = internet.mac_address()
    assert len(result) > 0



# Generated at 2022-06-21 16:11:14.856555
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    inter=Internet()
    print(inter.top_level_domain(tld_type=TLDType.GOV))



# Generated at 2022-06-21 16:11:19.140744
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    """Test for method stock_image of class Internet."""
    internet = Internet()
    image = internet.stock_image(550, 500, ['nature'])
    assert isinstance(image, str)
    assert not isinstance(image, bytes)

    image_bytes = internet.stock_image(550, 500, ['nature'], True)
    assert isinstance(image_bytes, bytes)
    assert not isinstance(image_bytes, str)

    import sys
    if sys.version_info[1] < 8:
        if sys.version_info[0] < 3:
            try:
                internet.stock_image(550, 500, ['nature'], True)
            except Exception:
                assert True
            else:
                assert False
        else:
            assert True
    else:
        assert True

# Generated at 2022-06-21 16:11:19.644553
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    assert Internet().content_type()


# Generated at 2022-06-21 16:11:20.823949
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    __test_Internet_content_type()


# Generated at 2022-06-21 16:11:21.482460
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    assert isinstance(Internet().emoji(), str)


# Generated at 2022-06-21 16:11:23.451916
# Unit test for method port of class Internet
def test_Internet_port():
    internet = Internet()
    port_range = PortRange.PRIVATE
    port = internet.port(port_range)
    assert port_range.value[0] <= port <= port_range.value[1]

# Generated at 2022-06-21 16:11:24.174196
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    pass


# Generated at 2022-06-21 16:11:25.955666
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    resource = 'fontir'
    domain = '.info'
    result = 'https://{}{}'.format(resource, domain)
    assert Internet().home_page() == result


# Generated at 2022-06-21 16:12:05.560139
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from mimesis.enums import Category
    from mimesis.providers.internet import Internet

    i = Internet()
    assert i.stock_image(
        width=100, height=100, keywords=['jungle', 'forest'],
    ) == (
        'https://source.unsplash.com/100x100?jungle,forest'
    )

# Generated at 2022-06-21 16:12:08.624678
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    """Tests for method mac_address."""
    internet = Internet(seed=123)
    assert isinstance(internet.mac_address(), str)
    assert internet.mac_address() == '00:16:3e:7f:ff:ff'


# Generated at 2022-06-21 16:12:10.109629
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    """Testing method emoji of class Internet."""
    internet = Internet()
    assert internet.emoji() in EMOJI


# Generated at 2022-06-21 16:12:11.128042
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    ip = Internet()
    assert len(ip.ip_v6()) == 39

# Generated at 2022-06-21 16:12:14.578829
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from mimesis.providers.internet import Internet

    internet = Internet()

    image = internet.stock_image(keywords=['nature', 'summer'])
    assert image and isinstance(image, str)

    image = internet.stock_image(keywords=['nature', 'summer'], writable=True)
    assert image and isinstance(image, bytes)

# Generated at 2022-06-21 16:12:17.385707
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    internet = Internet()
    assert internet.user_agent() == 'Mozilla/5.0(iPad;U;CPUOS4_3_3;zh-cn)AppleWebKit/533.17.9(KHTML,likeGecko)Version/5.0.2Mobile/8J2Safari/6533.18.5'


# Generated at 2022-06-21 16:12:20.766388
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    inter = Internet()
    ip = inter.ip_v6_object()
    assert isinstance(ip, IPv6Address)
    assert str(ip) == inter.ip_v6()

# Generated at 2022-06-21 16:12:27.993122
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    from mimesis import internet

    internet_instance = internet.Internet()
    mac_address = internet_instance.mac_address()

    print('Mac address =', mac_address)

    try:
        print('Is mac address valid =', internet.Internet.is_valid_mac_address(mac_address))
    except AttributeError:
        print('Method is_valid_mac_address is not defined.')



# Generated at 2022-06-21 16:12:30.740683
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    for _ in range(1000):
        assert isinstance(Internet.ip_v4(), str)
        assert isinstance(Internet.ip_v4(with_port=True), str)


# Generated at 2022-06-21 16:12:33.796663
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    """Test a random IPv4 address as string."""
    ip_v4 = Internet().ip_v4()
    assert type(ip_v4) == str
    assert type(ip_v4) is not int


# Generated at 2022-06-21 16:13:51.881830
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    """
    This function tests user_agent() method of class Internet.
    """
    assert Internet().user_agent() == 'Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.9.0.1) Gecko/2008071615 Fedora/3.0.1-1.fc9 Firefox/3.0.1'


# Generated at 2022-06-21 16:13:54.072211
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    m = Internet()
    mac_address = m.mac_address()
    print(mac_address)
    assert mac_address != ''


# Generated at 2022-06-21 16:13:58.862169
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    data = ['😀', '😁', '😂', '🤣', '😃', '😄',
            '😅', '😆', '😉', '😊', '😋', '😎']

    generator = Internet()
    value = generator.emoji()
    assert value in data

# Generated at 2022-06-21 16:13:59.878233
# Unit test for constructor of class Internet
def test_Internet():
    internet = Internet()
    assert internet.seed is not None


# Generated at 2022-06-21 16:14:04.573087
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    from mimesis.exceptions import NonEnumerableError
    from mimesis.enums import PortRange

    internet = Internet(seed=42)
    assert internet.ip_v6_object() == IPv6Address('2b51:6da8:6a92:e951:7d0b:c846:9c3:3d0')

    internet = Internet(seed=41)
    assert internet.ip_v6_object() == IPv6Address('75c7:2fab:f662:55f8:a1a1:1d54:c42b:9b9')

    internet = Internet(seed=40)

# Generated at 2022-06-21 16:14:08.276298
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    internet = Internet(seed=0)
    assert internet.network_protocol() == "SSDP"
    assert internet.network_protocol(layer=Layer.NETWORK) == "RIP"
    assert internet.network_protocol(layer=Layer.TRANSPORT) == "RPC"

# Generated at 2022-06-21 16:14:09.041714
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    assert Internet.content_type() == 'Content-Type: text/csv'



# Generated at 2022-06-21 16:14:14.519133
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    from mimesis.enums import Layer, PortRange
    from mimesis.enums import TLDType
    from mimesis.providers.internet import Internet
    internet = Internet()
    # Unit test for method content_type of class Internet
    assert internet.content_type() == 'Content-Type: application/json'
    # Unit test for method http_status_message of class Internet
    assert internet.http_status_message() in HTTP_STATUS_MSGS
    # Unit test for method http_status_code of class Internet
    assert internet.http_status_code() in HTTP_STATUS_CODES
    # Unit test for method http_method of class Internet
    assert internet.http_method() in HTTP_METHODS
    # Unit test for method ip_v4_object of class Internet

# Generated at 2022-06-21 16:14:16.968215
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
	
    internet = Internet()
    assert internet.http_status_code() in HTTP_STATUS_CODES

# Generated at 2022-06-21 16:14:18.143804
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    internet = Internet()
    print (internet.home_page())