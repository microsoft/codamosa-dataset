

# Generated at 2022-06-21 16:10:02.761126
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    for i in range(100):
        assert Internet().http_status_code() in HTTP_STATUS_CODES


# Generated at 2022-06-21 16:10:06.478696
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    """Test home_page() method of the class Internet."""
    internet = Internet()
    assert isinstance(internet.home_page(), str)
    assert internet.home_page(TLDType.SUFFIX)
    assert internet.home_page(TLDType.RESTRICTED)

# Generated at 2022-06-21 16:10:09.091527
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    """Test user_agent."""
    provider = Internet()
    result = provider.user_agent()
    assert int(len(result)) > 0

# Generated at 2022-06-21 16:10:10.213324
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    _internet = Internet()
    assert _internet.http_method() in HTTP_METHODS

# Generated at 2022-06-21 16:10:13.310805
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    instance = Internet()
    result1 = instance.stock_image()
    result2 = instance.stock_image(width=640, height=480)
    result3 = instance.stock_image(
        width=640, height=480, keywords=['nature', 'snow'])
    assert True

# Generated at 2022-06-21 16:10:16.082228
# Unit test for constructor of class Internet
def test_Internet():
    l = list(Internet.__dict__.keys())
    assert '__init__' in l


# Generated at 2022-06-21 16:10:26.953935
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    from mimesis.providers.internet import Internet
    from mimesis.enums import Layer
    internet = Internet()

# Generated at 2022-06-21 16:10:32.915051
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    internet = Internet()
    pattern = IPv6Address('::')
    ip_v6 = internet.ip_v6()
    assert isinstance(pattern, IPv6Address)
    assert isinstance(ip_v6, str)
    assert len(ip_v6.split(':')) == 8
    assert len(str(internet.ip_v6_object()).split(':')) == 8


# Generated at 2022-06-21 16:10:35.789196
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    internet = Internet()

    for _ in range(10):
        ip_v6 = internet.ip_v6()
        ipv6 = IPv6Address(ip_v6)

        assert ipv6.exploded == ip_v6

# Generated at 2022-06-21 16:10:37.137600
# Unit test for method port of class Internet
def test_Internet_port():
    internet = Internet()
    internet.port(port_range = PortRange.HTTP)


# Generated at 2022-06-21 16:11:16.141241
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    from mimesis.enums import Hashtag

    hashtag_tags = ['#love', '#sky', '#nice']
    # when
    try:
        internet = Internet(seed=12345)
        tags = internet.hashtags(Hashtag.NATURE, 3)
        assert tags == hashtag_tags
    except NonEnumerableError:
        assert False

# Generated at 2022-06-21 16:11:18.019452
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    myint = Internet()
    res = myint.ip_v4()

    assert res != None
    assert res != ""
    assert isinstance(res, str)


# Generated at 2022-06-21 16:11:19.282793
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    assert Internet() is not None
    assert isinstance(Internet().home_page(), str)


# Generated at 2022-06-21 16:11:20.823413
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    from mimesis.enums import Layer

    user_agent = Internet().user_agent()
    assert user_agent is not None



# Generated at 2022-06-21 16:11:21.985766
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    internet = Internet()
    u_agent = internet.user_agent()
    assert u_agent in USER_AGENTS

# Generated at 2022-06-21 16:11:23.485695
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    Internet_class_test = Internet()
    assert isinstance(Internet_class_test.emoji(), str)


# Generated at 2022-06-21 16:11:25.141317
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    it = Internet('en')
    assert it.content_type() != it.content_type()

#Unit test for method http_status_message of class Internet

# Generated at 2022-06-21 16:11:25.981463
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    assert Internet().http_status_code() == 200


# Generated at 2022-06-21 16:11:29.761722
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    """Function for testing Internet.emoji method."""
    from mimesis.enums import Emoji
    from mimesis.providers.internet import Internet

    int_ = Internet()
    bool_ = True

    for _ in range(100):
        emoji_ = int_.emoji()
        if emoji_ not in Emoji:
            print(emoji_)
            bool_ = False
            break

    assert bool_ is True

# Generated at 2022-06-21 16:11:31.683943
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    b = Internet(lang='en')

    assert b.home_page()
test_Internet_home_page()