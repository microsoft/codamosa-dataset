

# Generated at 2022-06-21 16:10:10.971957
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    ip = Internet()
    assert re.match(r'^([0-9a-f]{1,4}:){1,7}[0-9a-f]{1,4}$', ip.ip_v6())

# Generated at 2022-06-21 16:10:15.911143
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    internet = Internet()
    p1 = internet.network_protocol()
    p2 = internet.network_protocol(Layer.APPLICATION)
    p3 = internet.network_protocol(Layer.SESSION)
    p4 = internet.network_protocol(Layer.TRANSPORT)
    p5 = internet.network_protocol(Layer.NETWORK)
    p6 = internet.network_protocol(Layer.LINK)
    p7 = internet.network_protocol(Layer.PHYSICAL)
    print(p1,p2,p3,p4,p5,p6,p7)


# Generated at 2022-06-21 16:10:19.211260
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    internet = Internet()
    status_code = internet.http_status_code()
    assert isinstance(status_code, int)
    assert status_code in [status_code for status_code in range(200, 524)]

# Generated at 2022-06-21 16:10:28.181526
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    """Unit test for method user_agent of class Internet.

    This test will provide 10 random user agents based on the
    preset list of user agents from the USER_AGENTS
    list and compare them to the user_agent method of class Internet.
    """
    user_agent_list = USER_AGENTS
    for _ in range(10):
        random_user_agent = random.choice(user_agent_list)
        internet = Internet()
        assert random_user_agent == internet.user_agent()

if __name__ == "__main__":
    Internet.test_Internet_user_agent()

# Generated at 2022-06-21 16:10:37.007810
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    internet = Internet(seed=0)
    print("internet.home_page(tld_type=TLDType.LANGUAGE): " + internet.home_page(tld_type=TLDType.LANGUAGE))
    print("internet.home_page(tld_type=TLDType.COUNTRY_CODE): " + internet.home_page(tld_type=TLDType.COUNTRY_CODE))
    print("internet.home_page(tld_type=TLDType.GENERIC): " + internet.home_page(tld_type=TLDType.GENERIC))

# Generated at 2022-06-21 16:10:40.096660
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    internet = Internet()
    result = internet.content_type()
    assert isinstance(result, str) == True


# Generated at 2022-06-21 16:10:44.692211
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    '''Test case for method top_level_domain of class Internet.
    '''
    c1 = Internet()
    print(c1.top_level_domain(TLDType.SPONSORING_ORG))



# Generated at 2022-06-21 16:10:47.672081
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    internet1 = Internet()
    mac_address1 = internet1.mac_address()
    mac_address2 = internet1.mac_address()
    assert mac_address1 != mac_address2


# Generated at 2022-06-21 16:10:50.559909
# Unit test for method content_type of class Internet
def test_Internet_content_type():
	internet = Internet()
	content_type = internet.content_type()
	assert content_type is not None
	assert isinstance(content_type, str)
	assert content_type != ''
	assert len(content_type) > 1

# Generated at 2022-06-21 16:10:54.509895
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    """Test that the method returns a random content type."""
    internet = Internet()
    result = internet.content_type()
    assert isinstance(result, str)
    assert len(result) > 1


# Generated at 2022-06-21 16:12:04.548097
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    result = Internet.content_type()
    assert result == "Content-Type: image/png"


# Generated at 2022-06-21 16:12:06.057395
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    internet = Internet()
    mac = internet.mac_address()
    assert isinstance(mac, str)



# Generated at 2022-06-21 16:12:07.895371
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    obj = Internet()
    user_agent = obj.user_agent()
    assert isinstance(user_agent, str)
    assert user_agent
    assert len(user_agent) > 0


# Generated at 2022-06-21 16:12:14.695741
# Unit test for method port of class Internet
def test_Internet_port():
    """Unit tests for method port of class Internet."""
    def check_port_value(port_range, expected_value):
        """Internal helper function."""
        internet = Internet()
        assert isinstance(internet.port(port_range=port_range), int)
        assert expected_value < internet.port(
            port_range=port_range) < expected_value + 10

    port_test_data = [
        (PortRange.SYSTEM, 1024),
        (PortRange.USER, 49152),
        (PortRange.ALL, 1),
        (PortRange.WELL_KNOWN, 1),
        (PortRange.REGISTERED, 1024),
    ]

    for port_range, expected_value in port_test_data:
        yield check_port_value, port_range, expected_value

# Generated at 2022-06-21 16:12:19.677249
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    assert isinstance(Internet().ip_v6_object(), IPv6Address)
    # IPv6Address('6ff3:3eb:8a7f:e9d6:b10a:9f9e:69c0:1eac')

# Generated at 2022-06-21 16:12:24.964062
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    t = Internet()
    print(t.network_protocol())
    print(t.network_protocol(Layer.TRANSPORT))
    print(t.network_protocol(Layer.NETWORK))
    print(t.network_protocol(Layer.DATA_LINK))
    print(t.network_protocol(Layer.PHYSICAL))


# Generated at 2022-06-21 16:12:27.268715
# Unit test for method port of class Internet
def test_Internet_port():
    internet = Internet()
    result = internet.port()
    assert isinstance(result, int)

# Generated at 2022-06-21 16:12:30.077078
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    assert Internet.hashtags(4) == ["#fashiobloggers", "#blog", "#blogger", "#business"]


# Generated at 2022-06-21 16:12:34.340512
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    import urllib.request
    from PIL import Image
    from io import BytesIO

    internet = Internet()
    sample_url = internet.image_placeholder()
    sample_data = BytesIO(urllib.request.urlopen(sample_url).read())
    image = Image.open(sample_data)
    assert image is not None


# Generated at 2022-06-21 16:12:35.851378
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    internet = Internet()
    assert isinstance(internet.ip_v4_object(), IPv4Address)


# Generated at 2022-06-21 16:12:57.708982
# Unit test for method ip_v6_object of class Internet
def test_Internet_ip_v6_object():
    internet = Internet("en")
    ip = internet.ip_v6_object()
    if isinstance(ip, IPv6Address):
        return True
    else:
        return False


# Generated at 2022-06-21 16:13:04.400199
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    """Test for method stock_image"""
    internet = Internet()

# Generated at 2022-06-21 16:13:06.008224
# Unit test for method port of class Internet
def test_Internet_port():
    internet = Internet()
    assert internet.port() in range(65536)
    assert all(isinstance(port, int) for port in [internet.port(port_range=port_range) for port_range in PortRange])

# Generated at 2022-06-21 16:13:07.773131
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    from mimesis.enums import HttpMethod
    from mimesis.providers.internet import Internet

    internet = Internet()
    assert isinstance(internet.http_method(), HttpMethod)


# Generated at 2022-06-21 16:13:09.707346
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    for i in range(10):
        assert "." in Internet().home_page()

# Generated at 2022-06-21 16:13:11.180647
# Unit test for method port of class Internet
def test_Internet_port():
    internet = Internet()
    for port in range(1000):
        assert port == internet.port()

# Generated at 2022-06-21 16:13:12.544685
# Unit test for method mac_address of class Internet
def test_Internet_mac_address():
    internet = Internet()
    result = internet.mac_address()
    print(result)


# Generated at 2022-06-21 16:13:17.389989
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    from mimesis.providers.internet import Internet
    from mimesis.enums import PortRange

    internet = Internet(seed=0)
    assert '255.255.255.255' == internet.ip_v4()
    assert '10.234.1.253' == internet.ip_v4(with_port=True,
                                            port_range=PortRange.PRIVATE)



# Generated at 2022-06-21 16:13:19.256794
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    provider = Internet('en')
    result = provider.http_status_code()
    assert isinstance(result, int)


# Generated at 2022-06-21 16:13:24.163166
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    """Test of the method http_status_message() of the class Internet."""
    internet = Internet("ru")
    http_status_message = internet.http_status_message()
    assert isinstance(http_status_message, str)
    assert len(http_status_message) > 0
    assert len(http_status_message) < 20


# Generated at 2022-06-21 16:13:48.165706
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    from mimesis.enums import TLDType
    from mimesis.exceptions import NonEnumerableError
    from mimesis.providers.internet import Internet
    from mimesis.typing import Seed

    a = Internet(Seed(5))
    list1 = [None, 'a a', TLDType.CORPORATION, TLDType.COUNTRY]
    list2 = [TLDType.COM, TLDType.ORG, TLDType.NET]
    for i in list1:
        try:
            a.top_level_domain(i)
        except NonEnumerableError:
            continue
    b = a.top_level_domain()
    c = a.top_level_domain(TLDType.COUNTRY)

# Generated at 2022-06-21 16:13:53.897927
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    from mimesis.enums import TLDType
    internet = Internet()
    home_page = internet.home_page(tld_type=TLDType.COUNTRY)
    assert '.' in home_page
    assert 'https://' in home_page

if __name__ == '__main__':
    internet = Internet()
    print(internet.home_page())

# Generated at 2022-06-21 16:13:57.436314
# Unit test for method http_method of class Internet
def test_Internet_http_method():
    a = Internet().http_method()
    assert a in ['OPTIONS', 'GET', 'HEAD', 'POST', 'PUT', 'DELETE', 'TRACE', 'CONNECT']

# Generated at 2022-06-21 16:13:59.384312
# Unit test for method emoji of class Internet
def test_Internet_emoji():
    internet = Internet()
    assert isinstance(internet.emoji(), str)


# Generated at 2022-06-21 16:14:01.302796
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    internet = Internet(seed=1234)
    ip = internet.ip_v4_object()
    assert isinstance(ip, IPv4Address)

# Generated at 2022-06-21 16:14:06.703831
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    x = Internet()
    a = x.hashtags()
    print(a)

    # Expected output
    # ['#love', '#sky', '#nice']

# Generated at 2022-06-21 16:14:08.941119
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    from mimesis.providers import Internet
    obj = Internet()
    assert type(obj.user_agent()) == str
    assert len(obj.user_agent()) > 0

# Generated at 2022-06-21 16:14:10.641295
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    internet = Internet()
    url = internet.home_page()
    assert isinstance(url, str)
    assert 'https://' in url

# Generated at 2022-06-21 16:14:13.485404
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    from mimesis.enums import TLDType
    internet = Internet()
    print('TLD = ' + str(internet.top_level_domain(TLDType.GENERIC)))


# Generated at 2022-06-21 16:14:17.174707
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    """Unit test for method content_type of class Internet."""
    _internet = Internet()
    assert _internet.content_type(MimeType.XML) == \
        'Content-Type: application/xml'

# Generated at 2022-06-21 16:14:55.103301
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    assert Internet().image_placeholder() == 'http://placehold.it/1920x1080'


# Generated at 2022-06-21 16:14:57.296997
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    """Test method content_type of class Internet"""
    assert Internet().content_type() == 'Content-Type: image/png'


# Generated at 2022-06-21 16:15:03.233174
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    pr = Internet(seed=10)
    assert pr.ip_v6() == 'fce8:21f3:ab87:d066:76c3:3081:3f9:fe80'
    assert pr.ip_v6() == 'baa4:43d4:c2f5:5ee9:c404:56:d5b8:5cca'
    assert pr.ip_v6() == 'e8c6:d9f1:f6e0:4318:a8a5:6a67:f87:2585'
    assert pr.ip_v6() == '21a3:f983:f66e:ab74:d71e:1c0f:b9f:922'

# Generated at 2022-06-21 16:15:06.384534
# Unit test for method http_status_message of class Internet
def test_Internet_http_status_message():
    class InternetMock(Internet):
        def __init__(self):
            self.random = GenericRandom()

    internet = InternetMock()
    value = HTTP_STATUS_MSGS[0]
    assert internet.http_status_message() == value


# Generated at 2022-06-21 16:15:09.524205
# Unit test for method http_status_code of class Internet
def test_Internet_http_status_code():
    """Test for http_status_code of class Internet"""
    inter = Internet(random_state=0)
    assert inter.http_status_code() == 200
    assert inter.http_status_code() == 301
    assert inter.http_status_code() == 401
    assert inter.http_status_code() == 403


# Generated at 2022-06-21 16:15:12.040289
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    internet = Internet()
    assert len(internet.user_agent()) > 0
    assert internet.user_agent() in USER_AGENTS
    # TODO: add more tests
test_Internet_user_agent()


# Generated at 2022-06-21 16:15:14.234563
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    internet = Internet()
    results = []
    for i in range(10):
        results.append(internet.network_protocol())


# Generated at 2022-06-21 16:15:15.232930
# Unit test for method home_page of class Internet
def test_Internet_home_page():
    i_t = Internet()
    print(i_t.home_page())

# Generated at 2022-06-21 16:15:19.927676
# Unit test for constructor of class Internet
def test_Internet():
    assert Internet(seed=0).seed == 0
    assert Internet(seed=0).random.seed == 0
    assert Internet(seed=0).random.random == 0.8444218515250481
    assert Internet(seed=1).seed == 1
    assert Internet(seed=1).random.seed == 1
    assert Internet(seed=1).random.random == 0.7579544029403025
    assert Internet(seed=0) != Internet(seed=1)


# Unit tests for method content_type()

# Generated at 2022-06-21 16:15:21.406557
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    mime_website = Internet()
    assert mime_website.network_protocol(Layer.TRANSPORT) == "AMQP"

# Generated at 2022-06-21 16:16:13.577490
# Unit test for method content_type of class Internet
def test_Internet_content_type():
    internet = Internet()
    count = 0
    while count < 2:
        res = internet.content_type(MimeType.IMAGE)
        assert res == 'Content-Type: image/{}'.format(
            internet.__file.mime_type(type_=MimeType.IMAGE))
        count += 1


# Generated at 2022-06-21 16:16:15.353051
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    stock_image = internet.stock_image()
    assert 'https://source.unsplash.com/' in stock_image

# Generated at 2022-06-21 16:16:19.401933
# Unit test for method image_placeholder of class Internet
def test_Internet_image_placeholder():
    """Unit test for method image_placeholder."""
    internet = Internet()
    result = internet.image_placeholder()
    actual = 'http://placehold.it/1920x1080'
    assert result == actual, f'Method image_placeholder does not work as expected!\nResult   : {result}\nExpected : {actual}'


# Generated at 2022-06-21 16:16:28.272499
# Unit test for constructor of class Internet
def test_Internet():
    internet = Internet()
    print(internet.port())

    print(internet.ip_v4())
    print(internet.ip_v4_object())
    print(internet.ip_v6())
    print(internet.ip_v6_object())

    print(internet.mac_address())
    print(internet.hashtags(3))
    print(internet.home_page())
    print(internet.top_level_domain())
    print(internet.user_agent())
    print(internet.network_protocol())
    print(internet.image_placeholder())
    print(internet.stock_image())
    print(internet.content_type())
    print(internet.http_status_code())
    print(internet.http_status_message())
    print(internet.http_method())
    print(internet.emoji())

# Generated at 2022-06-21 16:16:37.332939
# Unit test for method port of class Internet
def test_Internet_port():
    from mimesis.enums import PortRange
    assert Internet().port(port_range=PortRange.RESERVED) in range(0, 1023)
    assert Internet().port(port_range=PortRange.UNPRIVILEGED) \
        in range(1024, 49151)
    assert Internet().port(port_range=PortRange.PRIVILEGED) \
        in range(49152, 65535)
    assert Internet().port(port_range=PortRange.FREE) \
        in range(49152, 65535)
    assert Internet().port(port_range=PortRange.ALL) \
        in range(0, 65535)

# Generated at 2022-06-21 16:16:40.050908
# Unit test for method top_level_domain of class Internet
def test_Internet_top_level_domain():
    """Test method Internet.top_level_domain()."""
    internet = Internet()
    assert internet.top_level_domain() in TLD[internet.ALL]
    assert internet.top_level_domain(TLDType.COUNTRY) in TLD[TLDType.COUNTRY]
    assert internet.top_level_domain(TLDType.GENERIC) in TLD[TLDType.GENERIC]



# Generated at 2022-06-21 16:16:42.256131
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    """
    Test Internet.ip_v4
    """
    ip = Internet().ip_v4()
    assert len(ip.split('.')) == 4, "ip v4 should has 4 digits"


# Generated at 2022-06-21 16:16:44.229939
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    internet = Internet()
    ip_v4_object = internet.ip_v4_object()
    assert isinstance(ip_v4_object, IPv4Address)


# Generated at 2022-06-21 16:16:47.686865
# Unit test for method user_agent of class Internet
def test_Internet_user_agent():
    from Internet.user_agent import Internet
    internet = Internet()
    assert internet.user_agent() == "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:15.0) Gecko/20100101 Firefox/15.0.1"

# Generated at 2022-06-21 16:16:49.842885
# Unit test for method network_protocol of class Internet
def test_Internet_network_protocol():
    from mimesis.enums import Layer
    from mimesis.providers.internet import Internet
    from random import random

    layer = Layer(int(random() * 7))
    print(Internet().network_protocol(layer))


# Generated at 2022-06-21 16:19:21.360468
# Unit test for method ip_v6 of class Internet
def test_Internet_ip_v6():
    internet = Internet(seed=101)
    ipv6 = internet.ip_v6()
    assert ipv6 == '2001:c244:cf9d:1fb1:c56d:f52c:8a04:94f3'

# Generated at 2022-06-21 16:19:23.114896
# Unit test for method ip_v4_object of class Internet
def test_Internet_ip_v4_object():
    obj = Internet()
    ip = obj.ip_v4_object()
    print(type(ip))


# Generated at 2022-06-21 16:19:27.680480
# Unit test for method ip_v4 of class Internet
def test_Internet_ip_v4():
    """Test function ip_v4 of class Internet."""
    provider = Internet(seed=42)
    assert provider.ip_v4() == '95.244.173.202'
    assert provider.ip_v4(with_port=True) == '19.121.223.58:8000'

# Generated at 2022-06-21 16:19:29.216521
# Unit test for method port of class Internet
def test_Internet_port():
    internet = Internet()
    data = internet.port(PortRange.WELL_KNOWN)
    assert data >= 0 and data < 1024

# Generated at 2022-06-21 16:19:39.103586
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    assert Internet().stock_image() == 'https://source.unsplash.com/1920x1080?'
    assert Internet().stock_image(width=800, height=600) == 'https://source.unsplash.com/800x600?'
    assert Internet().stock_image(keywords=['animal']) == 'https://source.unsplash.com/1920x1080?animal'
    assert Internet().stock_image(keywords=['nature', 'animal', 'birds']) == 'https://source.unsplash.com/1920x1080?nature,animal,birds'
    assert Internet().stock_image(keywords=['nature', 'bird', 'bird', 'animals']) == 'https://source.unsplash.com/1920x1080?nature,bird,bird,animals'