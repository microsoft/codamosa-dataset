

# Generated at 2022-06-12 02:06:46.451193
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    """Unit test for method hashtags of class Internet."""
    internet = Internet()
    assert isinstance(internet.hashtags(), str)
    assert isinstance(internet.hashtags(quantity=1), str)
    assert isinstance(internet.hashtags(quantity=2), list)
    assert isinstance(internet.hashtags(quantity=2)[0], str)
    assert isinstance(internet.hashtags(quantity=2)[1], str)
    assert internet.hashtags(quantity=2)[0] != internet.hashtags(quantity=2)[1]
    assert len(internet.hashtags(quantity=2)) == 2
    assert internet.hashtags(quantity=2)[0][0] == internet.hashtags(quantity=2)[1][0]


# Generated at 2022-06-12 02:06:54.443993
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from mimesis.enums import PortRange
    from mimesis.providers.internet import Internet
    assert Internet().stock_image() == \
        'https://source.unsplash.com/1920x1080?'
    assert Internet().stock_image(keywords=["aaa", "bbb"]) == \
        'https://source.unsplash.com/1920x1080?aaa,bbb'
    assert Internet().stock_image(keywords=["aaa", "bbb"], width=400,height=300) == \
        'https://source.unsplash.com/400x300?aaa,bbb'
# test_Internet_stock_image()

# Generated at 2022-06-12 02:06:57.421405
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    # internet.stock_image(writable=True)
    internet.stock_image()


if __name__ == '__main__':
    test_Internet_stock_image()

# Generated at 2022-06-12 02:06:59.400075
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    t = Internet()
    assert '#' in t.hashtags()

# Generated at 2022-06-12 02:07:06.669438
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from mimesis.builtins import USER_AGENT
    from mimesis.providers.internet import Internet
    from mimesis.enums import MimeType

    size = (1920, 1080)

    print(Internet().stock_image(*size))

    print(Internet().stock_image(*size, writable=True))

    print(Internet().stock_image(*size, ['office']))

    # version 1 of the API
    print(Internet(USER_AGENT).stock_image(*size, writable=True))

    # version 2 of the API
    print(Internet().stock_image(*size, writable=True,
                                 mime_type=MimeType.JPEG))

# Generated at 2022-06-12 02:07:09.314354
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    hashtag = internet.hashtags()

    assert isinstance(hashtag, str)

# Generated at 2022-06-12 02:07:10.675385
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
        internet = Internet(seed=10)
        print(internet.stock_image())



# Generated at 2022-06-12 02:07:13.731768
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    """
    Unit test for method stock_image of class Internet
    """
    inst = Internet()
    assert inst.stock_image() == "https://source.unsplash.com/1920x1080?"

# Generated at 2022-06-12 02:07:17.886011
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from mimesis.providers.internet import Internet
    from mimesis.enums import Layer

    provider = Internet()

    # Test of method stock_image
    url = provider.stock_image()
    assert url.startswith('https://source.unsplash.com')

# Generated at 2022-06-12 02:07:20.812345
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    inter = Internet()
    assert isinstance(inter.hashtags(), str)
    assert '#' in inter.hashtags()
    assert len(inter.hashtags().split(sep='#')) == 2
