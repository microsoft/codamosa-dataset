

# Generated at 2022-06-12 02:06:42.456783
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    provider = Internet()
#    print(provider.stock_image(writable=True))
    assert provider.stock_image(writable=True) is not None

# Generated at 2022-06-12 02:06:43.683153
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    assert internet.stock_image() is not None


# Generated at 2022-06-12 02:06:49.360661
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from PIL import Image
    import tempfile

    internet_obj = Internet()
    try:
        image = internet_obj.stock_image(writable=True)
    except urllib.error.URLError:
        raise Exception(
            "Internet class can't to generate a list of stock images without active internet connection")
    im = Image.open(tempfile.NamedTemporaryFile(prefix='mimesis_', suffix='.jpg'))
    im.show()

# Generated at 2022-06-12 02:06:51.310079
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    res = internet.stock_image()

    assert isinstance(res, str)
    assert 'https://' in res

# Generated at 2022-06-12 02:06:53.426661
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    """
    Test class Internet method stock_image.
    """

    result = Internet().stock_image()
    assert isinstance(result, str)

# Generated at 2022-06-12 02:06:55.225121
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    print(internet.stock_image())

# Generated at 2022-06-12 02:07:00.065674
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    i = Internet()
    data = i.stock_image(width = 1920,height = 1080,writable = True)
    with open('./test.jpg', 'wb') as f:
        f.write(data)
        print('写入成功！')

# Generated at 2022-06-12 02:07:00.953057
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    Internet().stock_image()

# Generated at 2022-06-12 02:07:09.073301
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    """Test method stock_image of class Internet."""
    from mimesis.exceptions import NonEnumerableError
    from mimesis.enums import PortRange, TLDType, Layer
    from mimesis.providers.internet import Internet
    from mimesis.providers.network import Network
    internet = Internet()
    network = Network()
    assert internet.top_level_domain() in internet.top_level_domains
    assert internet.top_level_domain(TLDType.COUNTRY_CODE) in internet.cc_tlds
    assert internet.top_level_domain(TLDType.GENERIC) in internet.generic_tlds
    assert internet.top_level_domain(TLDType.INFRASTRUCTURE) in internet.infra_tlds
    assert internet.home_page()

# Generated at 2022-06-12 02:07:12.997293
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    provider = Internet()
    image = provider.stock_image()
    print("image",image)

    image_b = provider.stock_image(writable=True)
    print("image_b",image_b)

if __name__ == '__main__':
    test_Internet_stock_image()