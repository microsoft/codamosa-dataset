

# Generated at 2022-06-12 02:06:51.809926
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from mimesis.enums import ImageFormat, ImageSize
    from mimesis.internet import Internet

    internet = Internet()
    obj = internet.stock_image()
    obj = internet.stock_image(1920, 1080)
    obj = internet.stock_image(1920, 1080, ['nature'])
    obj = internet.stock_image(ImageSize.HD)
    obj = internet.stock_image(ImageSize.HD, ['nature'])
    obj = internet.stock_image(1920, 1080, ['nature'], True)

# Generated at 2022-06-12 02:06:55.589860
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    i = Internet()
    h= i.hashtags(quantity=4)
    assert h.__len__() == 4
    assert h[0][0] == '#'
    assert h[3][0] == '#'

# Generated at 2022-06-12 02:06:59.924703
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    from mimesis.enums import Category
    from mimesis.providers.internet import Internet

    internet = Internet()
    for i in Category:
        result = internet.hashtags(i, 4)
        assert isinstance(result, list)



# Generated at 2022-06-12 02:07:02.162849
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    image = internet.stock_image(1920, 1080)
    assert image == 'https://source.unsplash.com/1920x1080'


# Generated at 2022-06-12 02:07:04.107443
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    hashtags = internet.hashtags(quantity=2)
    assert len(hashtags) == 2


# Generated at 2022-06-12 02:07:06.017180
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    # Define the list of keywords
    keywords = ['cat', 'dog', 'kitten', 'puppy']

    # Define the instance for Stock image
    stock_image = Internet.stock_image(keywords=keywords)
    print(stock_image)

# Generated at 2022-06-12 02:07:15.570789
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    """Testing method hashtags of class Internet."""
    from mimesis.enums import Hashtag

    internet = Internet()
    assert isinstance(internet.hashtags(quantity=4), list)
    assert isinstance(internet.hashtags(quantity=1), str)
    assert internet.hashtags(Hashtag.JOBS) == '#jobs'
    assert internet.hashtags(Hashtag.LOVE) == '#love'
    assert internet.hashtags(Hashtag.MUSIC) == '#music'
    assert internet.hashtags(Hashtag.BEAUTIFUL) == '#beautiful'
    assert internet.hashtags(Hashtag.CRAZY) == '#crazy'
    assert internet.hashtags(Hashtag.FOOD) == '#food'
    assert internet.hashtags(Hashtag.LIFE)

# Generated at 2022-06-12 02:07:18.156445
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    image = Internet.stock_image()
    assert len(image) > 0
    print(image)



# Generated at 2022-06-12 02:07:24.535513
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    from mimesis.enums import Hashtag
    from mimesis.providers.internet import Internet
    from mimesis.typing import Quantifier

    i = Internet()
    Q = Quantifier

    assert i.hashtags(quantity=Q.FULL) == '#transportation'
    assert i.hashtags(quantity=Q.DEFAULT) == ['#love', '#sky', '#nice']
    assert i.hashtags(quantity=Q.SHORT) == '#love'
    assert i.hashtags(quantity=Q.MINIMAL) == ['#love']
    assert i.hashtags(quantity=Q.LARGE) == '#amazing'
    i.add_provider('hashtag', Hashtag)
    assert i.hashtags() == ['#introvert']

# Generated at 2022-06-12 02:07:28.306873
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from mimesis.enums import TLDType
    from mimesis.providers.tools import iterate
    from mimesis.providers.internet import Internet
    from PIL import Image

    internet = Internet()
    image = internet.stock_image(
        width=640,
        height=480,
        keywords=['food', 'water', 'air', 'nature'],
        writable=True,
    )
    img = Image.open(image)
    print(img)

