

# Generated at 2022-06-12 02:07:09.134417
# Unit test for method port of class Internet
def test_Internet_port():
    print("Test Internet port")
    print("'80' <= Internet(seed=12344).port(port_range=PortRange.WELL_KNOWN) <= '1023'")
    assert '80' <= Internet(seed=12344).port(port_range=PortRange.WELL_KNOWN) <= '1023'
    print("True")

    print("'80' <= Internet(seed=12344).port(port_range=PortRange.REGISTERED) <= '49151'")
    assert '80' <= Internet(seed=12344).port(port_range=PortRange.REGISTERED) <= '49151'
    print("True")

    print("'1024' <= Internet(seed=12344).port(port_range=PortRange.DYNAMIC) <= '65535'")

# Generated at 2022-06-12 02:07:13.659351
# Unit test for method port of class Internet
def test_Internet_port():
    for port_range in PortRange:
        port = Internet.port(port_range)
        assert isinstance(port, int)
        assert -1 < port < 65536

    # Invalid argument
    try:
        Internet.port('invalid value')
    except Exception as e:
        assert e.args[0] == 'invalid value is not in PortRange'

# Generated at 2022-06-12 02:07:22.484542
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    from mimesis.enums import Hashtag
    internet = Internet()
    assert internet.hashtags(1) == '#love'
    assert internet.hashtags(2) == ['#love', '#sky']
    assert internet.hashtags(3) == ['#love', '#sky', '#nice']
    assert internet.hashtags(4) == ['#love', '#sky', '#nice', '#summer']
    assert internet.hashtags(5) == ['#love', '#sky', '#nice', '#summer', '#blue']

    assert internet.hashtags(1, category=Hashtag.ANIMALS) == '#cute'
    assert internet.hashtags(2, category=Hashtag.ANIMALS) == ['#cute', '#pet']

# Generated at 2022-06-12 02:07:25.243548
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from mimesis.enums import Width

    provider = Internet(seed=0)
    link = provider.stock_image(
        width=Width.WIDTH_1080P, writable=True)

    assert len(link) == 232481

# Generated at 2022-06-12 02:07:27.728698
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    """Test method stock_image of class Internet."""
    internet = Internet()

    assert internet.stock_image() == 'https://source.unsplash.com/1920x1080'

# Generated at 2022-06-12 02:07:31.210777
# Unit test for method port of class Internet
def test_Internet_port():
    port_range =  PortRange.DYNAMIC
    start = port_range.value[0]
    end = port_range.value[1]
    int_prov = Internet()
    assert start <= int_prov.port(port_range=port_range) <= end

# Generated at 2022-06-12 02:07:33.701822
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    test = Internet()
    result = test.hashtags(quantity=1)
    assert result == '#love' or result == '#sky' or result == '#nice'


# Generated at 2022-06-12 02:07:37.064417
# Unit test for method port of class Internet
def test_Internet_port():
    internet = Internet()
    port = internet.port(port_range = PortRange.WELL_KNOWN)
    assert 0 <= port <= 1023

# Generated at 2022-06-12 02:07:39.976748
# Unit test for method port of class Internet
def test_Internet_port():
    """Check output data of method port."""
    port_range = PortRange.ALL
    internet = Internet()
    port = internet.port()

    assert isinstance(port, int)
    assert 0 <= port <= 65535

# Generated at 2022-06-12 02:07:44.266312
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    # initialization of class Internet
    internet = Internet()
    # get the ’Internet.hashtags’ result
    hashtags = internet.hashtags(quantity=1)
    # assertion for hashtag
    assert isinstance(hashtags, str) or isinstance(hashtags, list)

# Generated at 2022-06-12 02:08:20.218842
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    print(internet.stock_image(1024, 768, keywords=['cat', 'dog']))

# Generated at 2022-06-12 02:08:27.870974
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    """Test for Internet class.

    Test method stock_image().
    """
    from os import path
    from PIL import Image
    from tempfile import NamedTemporaryFile
    download_image = True
    if download_image:
        url = Internet().stock_image(writable=True)
        with NamedTemporaryFile(suffix='.jpg') as image:
            image.write(url)
            image.seek(0)
            im = Image.open(image.name)
            im.show()
    else:
        url = Internet().stock_image()
        assert path.exists(url)

# Generated at 2022-06-12 02:08:29.187855
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    res = internet.stock_image(width=640, height=480)
    assert res is not None

# Generated at 2022-06-12 02:08:30.663769
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    response = internet.stock_image(writable=True)
    assert isinstance(response, bytes)

# Generated at 2022-06-12 02:08:33.133767
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    inc = Internet()
    assert inc.stock_image() == 'https://source.unsplash.com/1920x1080'

# Generated at 2022-06-12 02:08:42.109999
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from mimesis.enums import PortRange, TLDType
    from mimesis.providers.network import Internet

    internet = Internet('en')
    
    # Task 1
    print('Task 1\n')
    print(internet.ip_v4())
    print(internet.ip_v4(with_port=True))
    print(internet.ip_v4(with_port=True, port_range=PortRange.HIGH))
    print(internet.ip_v6())
    
    # Task 2
    print('\nTask 2\n')
    print(internet.mac_address())
    
    # Task 3
    print('\nTask 3\n')
    print(internet.emoji())
    
    # Task 4
    print('\nTask 4\n')

# Generated at 2022-06-12 02:08:47.343176
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    stock_image = Internet().stock_image(
        width=1920,
        height=1080,
        keywords=['wallpaper', 'desktop'],
        writable=True,
    )

    image_name = 'wallpaper.jpg'
    with open(image_name, 'wb') as f:
        f.write(stock_image)

    assert f.tell() == 338905
    assert f.closed

# Generated at 2022-06-12 02:08:48.999877
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    assert Internet().stock_image(keywords=['python'], writable=True) is not None

# Generated at 2022-06-12 02:08:50.293759
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    print(internet.stock_image())

# Generated at 2022-06-12 02:08:51.630991
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    internet.stock_image()