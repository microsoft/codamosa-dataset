

# Generated at 2022-06-12 02:06:40.473752
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    inter = Internet()
    print(inter.hashtags())

# Generated at 2022-06-12 02:06:43.800069
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    f = open('image.jpeg', 'wb')
    picture = Internet.stock_image(
        width = 50,
        height = 50,
        writable = True)
    f.write(picture)
    f.close()

test_Internet_stock_image()

# Generated at 2022-06-12 02:06:46.318667
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    z = Internet()
    z.hashtags(quantity=1) # return a string
    z.hashtags(quantity=3) # return a list of length 3

# Generated at 2022-06-12 02:06:47.934623
# Unit test for method port of class Internet
def test_Internet_port():
    internet = Internet()
    port = internet.port()
    assert port >= 0 and port <= 65535


# Generated at 2022-06-12 02:06:49.227895
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    """Test if return stock image."""
    assert Internet.stock_image()

# Generated at 2022-06-12 02:06:51.516183
# Unit test for method port of class Internet
def test_Internet_port():
    internet = Internet()
    random.seed(0)
    port_range = PortRange.REGISTERED_PORTS
    assert internet.port(port_range=port_range) == 3572

# Generated at 2022-06-12 02:07:00.916232
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    from mimesis.enums import Hashtag

    it = Internet('en')
    assert it.hashtags(5) == '#travel'
    assert it.hashtags(0) == '#travel'
    assert it.hashtags(quantity=20) == '#travel'
    assert it.hashtags(1) == '#travel'
    assert it.hashtags(3) == ['#travel', '#photography', '#tag']

    it = Internet('en', hashtags_categories=Hashtag.SPORT)
    assert it.hashtags(quantity=5) == ['#sport', '#fitness', '#sports', '#soccer', '#football']

# Generated at 2022-06-12 02:07:03.487223
# Unit test for method port of class Internet
def test_Internet_port():
    # Arrange
    internet = Internet()

    # Act
    result = internet.port()

    # Assert
    assert isinstance(result, int)
    assert result >= 0
    assert result <= 65535

# Generated at 2022-06-12 02:07:04.168707
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    provider = Internet('en')
    provider.stock_image()

# Generated at 2022-06-12 02:07:06.934584
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from PIL import Image
    from io import BytesIO

    internet = Internet()
    img = internet.stock_image(
        writable=True,)
    image = Image.open(BytesIO(img))
    assert image.size == (1920, 1080)

# Generated at 2022-06-12 02:07:30.411495
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    import unittest

    class TestInternet(unittest.TestCase):
        """Tests for class Internet of module internet."""

        def test_stock_image(self):
            """Test method Internet.stock_image.

            Require connection to Internet.
            """
            image = Internet().stock_image()
            self.assertIn('https://', image)

    unittest.main()

# Generated at 2022-06-12 02:07:32.140228
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    assert internet.stock_image(writable=True)

# Generated at 2022-06-12 02:07:35.422078
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    """Test method stock_image of class Internet."""
    internet = Internet()
    assert internet.stock_image().startswith('https://source.unsplash.com')
    assert isinstance(internet.stock_image(writable=True), bytes)

# Generated at 2022-06-12 02:07:42.636180
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    # Init seed
    internet = Internet(seed=42)
    # Old logic
    link = internet.stock_image()
    assert link == 'https://source.unsplash.com/1920x1080?', "Expect string " + link
    # New writeable logic
    image = internet.stock_image(writable=True)
    assert image is not None, "Expect not None"


# Generated at 2022-06-12 02:07:47.658526
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    # this test guaranteed work without an active internet connection
    import unittest
    import urllib.error

    # create custom class TestStockImage which extend class TestCase
    class TestStockImage(unittest.TestCase):

        def test_error(self):
            # create object of class Internet
            internet = Internet()
            # call method stock_image of class Internet
            with self.assertRaises(urllib.error.URLError):
                internet.stock_image(writable=True)

    # launch unit test
    unittest.main()




# Generated at 2022-06-12 02:07:49.649916
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet(seed=1468703)
    image = internet.stock_image(width=800, height=600)
    assert image == 'https://source.unsplash.com/800x600?building'

# Generated at 2022-06-12 02:07:52.233904
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    print("Testing Internet.stock_image()")
    headers = {'User-Agent': Internet().user_agent()}
    print(Internet().stock_image(headers=headers))
    print("PASSED\n")

if __name__ == "__main__":
    test_Internet_stock_image()

# Generated at 2022-06-12 02:07:53.696683
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    result = internet.stock_image()
    assert result == 'https://source.unsplash.com/1920x1080/'


# Generated at 2022-06-12 02:07:56.483229
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    provider = Internet(random_state=1)
    print(provider.stock_image(250, 250, writable=True))

# Generated at 2022-06-12 02:08:00.097594
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    url = internet.stock_image()
    assert url.startswith('https://source.unsplash.com/')
    assert url.count('/') == 3
    assert url.count('?') == 1



# Generated at 2022-06-12 02:08:40.216985
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    flags = [
        '1920x1080',
        '200x300',
        '300x200',
        '200x200',
        '300x300',
    ]
    assert internet.stock_image(width=flags[0], height=flags[0]) == \
        'https://source.unsplash.com/1920x1080', \
        'Incorrect size of placeholder image'

    assert internet.stock_image(width=flags[1], height=flags[1]) == \
        'https://source.unsplash.com/200x300', \
        'Incorrect size of placeholder image'


# Generated at 2022-06-12 02:08:41.772036
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    test = Internet()
    print(test.stock_image())

# Generated at 2022-06-12 02:08:43.458697
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    x = Internet()
    print(x.stock_image())

# Generated at 2022-06-12 02:08:48.120986
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    """Unit test for method stock_image of class Internet"""
    internet = Internet()
    image = internet.stock_image(140, 140, ['cat'], True)
    if isinstance(image, bytes):
        print('Image has been downloaded.')
    else:
        print('Image has not been downloaded.')

if __name__ == '__main__':
    test_Internet_stock_image()

# Generated at 2022-06-12 02:08:59.015015
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from mimesis.providers.internet import Internet
    from io import BytesIO
    internet = Internet(seed=123)
    image = internet.stock_image(writable=True)
    image_local = BytesIO()
    image_local.write(image)
    image_local.seek(0)

# Generated at 2022-06-12 02:09:05.007517
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    # Case: necessary active HTTP connection
    try:
        # Case: necessary active HTTP connection
        Internet().stock_image()
    except urllib.error.URLError:
        pass
    else:
        raise AssertionError('There is an active HTTP connection')

    # Case: no necessary active HTTP connection
    try:
        image = Internet().stock_image(writable=True)
    except urllib.error.URLError:
        raise AssertionError('There is not an active HTTP connection')
    else:
        # Check the size of receiving data
        assert len(image) > 0

# Generated at 2022-06-12 02:09:07.439994
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    assert isinstance(Internet.stock_image(), str)
    assert isinstance(Internet.stock_image(writable=True), bytes)



# Generated at 2022-06-12 02:09:09.775977
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    pic_base64_bytes = internet.stock_image(writable=True)
    print(pic_base64_bytes)

# Generated at 2022-06-12 02:09:19.144039
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from mimesis.enums import PortRange, TLDType
    from mimesis.providers.internet import Internet
    print('Internet tests')
    inet = Internet()
    print('IPv4:', inet.ip_v4())
    print('IPv4 with port:', inet.ip_v4(with_port=True))
    print('IPv4 with port in range:', inet.ip_v4(port_range=PortRange.PRIVATE))
    print('IPv6:', inet.ip_v6())
    print('MIME type:', inet.content_type(MimeType.APPLICATION))
    print('Home page:', inet.home_page())

# Generated at 2022-06-12 02:09:20.674764
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    p = Internet()
    assert p.stock_image() != None

# Generated at 2022-06-12 02:09:42.648574
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from mimesis.builtins import data
    from PIL import Image
    from io import BytesIO

    # Сгенерировать изображение, если какое-либо из изображений не удалось
    # получить, функция ругается
    try:
        image = Internet().stock_image(writable=True)
    except Exception:
        image = data.get_file(path='../data/image/stock/stock-image.jpg')

    # Получи

# Generated at 2022-06-12 02:09:45.684621
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from mimesis.enums import Width, Height

    internet = Internet()
    image = internet.stock_image(width=Width.W1080, height=Height.H1920, writable=True)
    assert image is not None

# Generated at 2022-06-12 02:09:51.264854
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    # Create object Internet
    internet = Internet()

    # Get link to the image
    url = internet.stock_image()

    # Check if returned value is a string
    assert isinstance(url, str), 'URL: {} is not a string'.format(url)

    # Check if returned value is a link to the image
    assert url.startswith('https://source.unsplash.com/'), \
        'URL: {} is not a link to the image'.format(url)

# Generated at 2022-06-12 02:09:54.923811
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    ''' Unit test for method stock_image of class Internet
    '''

    # Expected response.
    expected_response = 'https://source.unsplash.com/1920x1080?cat'

    internet = Internet('en')
    response = internet.stock_image(1920, 1080, 'cat')

    assert response == expected_response

# Generated at 2022-06-12 02:09:58.637667
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    print("Testing for method stock_image of class Internet")
    internet = Internet()
    stock_image = internet.stock_image()
    print("Testing for method stock_image of class Internet: ", stock_image)


# Generated at 2022-06-12 02:10:06.514416
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    """Test for method Internet.stock_image."""
    internet = Internet()
    # Test for the placeholder of method stock_image
    placeholder = internet.stock_image()
    assert 'http://placehold.it/1920x1080' == placeholder
    # Test for writable object
    img = internet.stock_image(width=300, height=300, writable=True)
    assert isinstance(img, bytes)
    # Test for keywords
    keywords = [
        'nature',
        'people',
        'sky'
    ]
    url = internet.stock_image(keywords=keywords)
    assert '?nature,people,sky' in url

# Generated at 2022-06-12 02:10:07.639357
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    assert 'jpeg' in internet.stock_image()

# Generated at 2022-06-12 02:10:08.875119
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    for i in range(5):
        url = Internet().stock_image()
        assert url != None
        print(url)

# Generated at 2022-06-12 02:10:20.908048
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    """
    Check that the method Internet.stock_image() return an image.
    """
    from PIL import Image
    from io import BytesIO
    from mimesis.providers.internet import Internet
    from mimesis.enums import Layer
    internet = Internet()
    image = internet.stock_image(writable=True)
    assert Image.open(BytesIO(image)).size
    assert image is not None
    assert internet.network_protocol(layer=Layer.APPLICATION) is not None
    assert internet.network_protocol(layer=Layer.DATA) is not None
    assert internet.network_protocol(layer=Layer.NETWORK) is not None
    assert internet.network_protocol(layer=Layer.PRESENTATION) is not None
    assert internet.network_protocol(layer=Layer.SESSION)

# Generated at 2022-06-12 02:10:22.227320
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    provider = Internet()
    stock_image = provider.stock_image()
    assert isinstance(stock_image, str)

# Generated at 2022-06-12 02:10:53.032637
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    stock_image_bytes = internet.stock_image(width=800, height=600, writable=True)
    stock_image_url = internet.stock_image(width=800, height=600)
    print(stock_image_bytes)
    print(stock_image_url)

test_Internet_stock_image()

# Generated at 2022-06-12 02:10:56.486725
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    import matplotlib.pyplot as plt
    from PIL import Image
    import io

    internet = Internet()
    img = internet.stock_image(writable = True)
    img = Image.open(io.BytesIO(img))
    plt.imshow(img)
    plt.show()



if __name__ == '__main__':
    test_Internet_stock_image()

# Generated at 2022-06-12 02:10:57.894629
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()

    response_img = internet.stock_image(writable=True)
    assert isinstance(response_img, bytes)

# Generated at 2022-06-12 02:11:01.192755
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from PIL import Image

    random = Internet()
    img = random.stock_image(writable=True)
    im = Image.open(img)

    assert im.size == (1920, 1080)

# Generated at 2022-06-12 02:11:03.223485
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
#     print(Internet.stock_image(writable=True))
    pass

if __name__ == '__main__':
    test_Internet_stock_image();

# Generated at 2022-06-12 02:11:07.563386
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    import requests
    import os.path

    image = Internet().stock_image(width=500, height=500, writable=True)

    assert len(image) > 0
    assert os.path.exists('image.jpg')
    assert os.path.getsize('image.jpg') == len(image)
    # Remove image created for test
    os.remove('image.jpg')

# Generated at 2022-06-12 02:11:09.781855
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    """Unit test for method stock_image of class Internet."""
    internet = Internet()
    url = internet.stock_image()
    assert url is not None

# Generated at 2022-06-12 02:11:20.579754
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    """Test method stock_image of class Internet."""
    import os
    import tempfile
    internet = Internet()
    # Not set PATH_TO_IMAGES
    PATH_TO_IMAGES = 'PATH_TO_IMAGES'
    assert not os.getenv(PATH_TO_IMAGES)
    # Get image as URL
    url = internet.stock_image()
    assert url.startswith('https://source.unsplash.com/')
    # Get image as writable object
    img = internet.stock_image(writable=True)
    assert isinstance(img, bytes)

    # Set PATH_TO_IMAGES
    os.environ[PATH_TO_IMAGES] = tempfile.gettempdir()

# Generated at 2022-06-12 02:11:22.546531
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    try:
        internet = Internet()
        url = internet.stock_image()
        assert isinstance(url, str)
    except urllib.error.URLError:
        pass

# Generated at 2022-06-12 02:11:25.759320
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    provider = Internet()
    result = provider.stock_image(width=400, height=300, writable=True)
    assert type(result) == bytes
    assert len(result) > 0

# Generated at 2022-06-12 02:11:56.279360
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    url = internet.stock_image(1024, 768)
    assert "https://source.unsplash.com/1024x768?" in url

# Generated at 2022-06-12 02:11:59.362514
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    """Test case for method stock_image of class Internet."""
    provider_internet = Internet()
    result = provider_internet.stock_image()
    assert result is not None
    assert isinstance(result, str)

# Generated at 2022-06-12 02:12:05.286192
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()

    assert internet.stock_image() == 'https://source.unsplash.com/1920x1080?service'
    assert internet.stock_image(1920, 1080, None) == 'https://source.unsplash.com/1920x1080?service'
    assert internet.stock_image(1920, 1080, ['service']) == 'https://source.unsplash.com/1920x1080?service'
    assert internet.stock_image(1920, 1080, ['service', 'tools']) == 'https://source.unsplash.com/1920x1080?service,tools'
    assert internet.stock_image(width=1920, height=1080, keywords=['service', 'tools']) == 'https://source.unsplash.com/1920x1080?service,tools'

# Generated at 2022-06-12 02:12:13.320871
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    # min_width = 1
    # max_width = 1920
    # min_height = 1
    # max_height = 1080
    # url_pattern = 'https://source.unsplash.com/\d{2,4}x\d{2,4}?\w{1,6},\w{1,6},\w{1,6},\w{1,6},\w{1,6},\w{1,6}'
    # assert re.match(url_pattern, Internet.stock_image())
    internet = Internet(seed=0)
    width, height = internet.stock_image().split('?')[0].split('/')[-1].split('x')
    width, height = int(width), int(height)
    assert (width != 1920) and (height != 1080)

# Generated at 2022-06-12 02:12:14.733318
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    """Test method stock_image of class Internet."""
    internet = Internet()
    internet.stock_image()

# Generated at 2022-06-12 02:12:22.197613
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():

    internet = Internet()
    assert internet.stock_image() == \
        'https://source.unsplash.com/1920x1080?'

    assert internet.stock_image(width=800, height=600) == \
        'https://source.unsplash.com/800x600?'

    assert internet.stock_image(keywords=['italy']) == \
        'https://source.unsplash.com/1920x1080?italy'

    assert internet.stock_image(
        keywords=['italy', 'mountains']) == \
        'https://source.unsplash.com/1920x1080?italy,mountains'

    assert isinstance(
        internet.stock_image(writable=True), bytes)

# Generated at 2022-06-12 02:12:25.030551
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    i = Internet()
    assert isinstance(i.stock_image(), str)
    assert isinstance(i.stock_image(writable=True), bytes)

if __name__ == '__main__':
    print(Internet().stock_image(writable=True))

# Generated at 2022-06-12 02:12:29.560295
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from mimesis.enums import TLDType

    # initialize class Internet
    Internet = Internet()
    # get the random internet top level domain
    url = Internet.top_level_domain(tld_type=TLDType.COMMON)
    # check if the url will return a valid image
    assert Internet.stock_image(tld_type=TLDType.COMMON) == 'https://source.unsplash.com/1920x1080?{}'.format(url)

# Generated at 2022-06-12 02:12:33.405170
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    assert internet.stock_image() == 'https://source.unsplash.com/1920x1080'
    assert internet.stock_image(width=200, height=200, keywords=['cat']) == 'https://source.unsplash.com/200x200?cat'

# Generated at 2022-06-12 02:12:40.540962
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    # If a keyword is passed, the image will be associated with it. 
    # For example, https://source.unsplash.com/1600x900/?nature,water 
    # will generate a random image of size 1600x900 with the keyword nature,
    # and water.
    assert Internet().stock_image(writable=True) is not None  # Default
    assert Internet().stock_image(keywords=['nature'], writable=True) is not None
    assert Internet().stock_image(keywords=['nature', 'water'], writable=True) is not None
    # Dimension defaults to the size of your browser window.
    assert Internet().stock_image(keywords=['nature', 'water'], writable=True, width=400) is not None

# Generated at 2022-06-12 02:13:41.108468
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    # Arrange
    internet = Internet()
    height = 42
    width = 42

    # Act
    link = internet.stock_image(height, width)

    # Assert
    assert isinstance(link, str)
    assert "https://source.unsplash.com/42x42" in link

# Generated at 2022-06-12 02:13:48.823695
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet(seed=12345)
    image = internet.stock_image(width=500, height=500, writable=True)
    assert isinstance(image, bytes)

# Generated at 2022-06-12 02:13:55.278261
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from mimesis.providers.internet import Internet
    from mimesis.enums import TLDType
    from mimesis.data import COUNTRIES
    if __name__ == '__main__':
        provider = Internet()
        # Return an image of size 1920x1080 with the tag `cat`
        print(provider.stock_image(width=1920, height=1080, keywords=['cat']))
        # Return an image of size 1024x768 with the tag `house`
        print(provider.stock_image(width=1024, height=768, keywords=['house']))
        # Return an image of size 640x480 with tags `bird`, `flower` and `tree`
        print(provider.stock_image(width=640, height=480, keywords=['bird', 'flower', 'tree']))
        # Return an image

# Generated at 2022-06-12 02:14:00.834080
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    """Unit test for method image placeholder of class Internet"""
    import os
    import shutil
    from mimesis.enums import ImageMode
    from mimesis.providers.internet import Internet
    from PIL import Image

    path = "/tmp/image.jpg"
    path_resized = "/tmp/image_resized.jpg"
    internet = Internet()

    assert isinstance(internet.stock_image(), str)
    internet.stock_image(writable=True)
    assert internet.stock_image(keywords=['dog', 'cat'])
    assert internet.stock_image(width=1920, height=1080)
    assert internet.stock_image(keywords=['dog', 'cat'], width=1920, height=1080)

# Generated at 2022-06-12 02:14:05.043903
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    """Test Internet.stock_image() method."""
    from mimesis.providers.utils import is_valid_image
    width = 1080
    height = 1920
    keywords = ['nature', 'random']
    image = Internet().stock_image(width, height, keywords)
    sample_image = Internet().stock_image(width, height, keywords,
                                          writable=True)
    assert len(image) > 100
    assert is_valid_image(sample_image)
    assert isinstance(image, str)
    assert isinstance(sample_image, bytes)

# Generated at 2022-06-12 02:14:06.338843
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    assert internet.stock_image() == 'https://source.unsplash.com/1920x1080?'

# Generated at 2022-06-12 02:14:10.437720
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    # Arrange
    from mimesis.enums import ImageSize

    # Act
    result = Internet().stock_image(ImageSize.LARGE)

    # Assert
    assert result is not None
    assert isinstance(result, str)

# Generated at 2022-06-12 02:14:14.761196
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    i = Internet()
    # Should return a link to a random image
    assert i.stock_image() == 'https://source.unsplash.com/1920x1080'
    # Should return a list of bytes
    assert isinstance(i.stock_image(writable=True), bytes)
    # Should raise an exception
    import requests
    try:
        requests.get(i.stock_image())
    except requests.exceptions.ConnectionError:
        assert i.stock_image(writable=True) == b''

# Generated at 2022-06-12 02:14:15.876496
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    Internet.stock_image()
    Internet.stock_image(writable=True)



# Generated at 2022-06-12 02:14:24.406199
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    """Unit test for Internet.stock_image.

    Collect data by calling "stock_image" method of Internet.
    There are 2 ways how you can get data:
    1. get link to image
    2. get bytes of image

    How to read bytes:
    from mimesis import Internet
    internet = Internet('en')

    # collect data
    data = internet.stock_image(writable=True)

    # write it to file
    with open('image.jpg', 'wb') as img:
        img.write(data)

    """
    internet = Internet()

    # image size
    width = 1920
    height = 1080

    # get url of image
    url = internet.stock_image(width, height)
    print('Link to image: "{}"'.format(url))

    # get bytes object of image