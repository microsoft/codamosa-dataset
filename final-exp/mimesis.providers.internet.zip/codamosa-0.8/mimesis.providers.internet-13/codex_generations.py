

# Generated at 2022-06-12 02:06:40.307158
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    from mimesis.builtins import Internet
    obj = Internet('en')
    print(obj.hashtags(4))
    print(obj.hashtags(1))


# Generated at 2022-06-12 02:06:49.580607
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    from mimesis.enums import Hashtag
    assert '#nice' in Internet.hashtags(1)
    assert '#food' in Internet.hashtags(1)
    assert '#love' in Internet.hashtags(1)
    assert '#sky' in Internet.hashtags(1)
    assert '#best' in Internet.hashtags(1)
    assert '#motivational' in Internet.hashtags(1)
    assert '#food' in Internet.hashtags(1, category=Hashtag.FOOD)
    assert '#love' in Internet.hashtags(1, category=Hashtag.LOVE)
    assert '#sky' in Internet.hashtags(1, category=Hashtag.SKY)
    assert '#best' in Internet.hashtags(1, category=Hashtag.BEST)

# Generated at 2022-06-12 02:06:50.504578
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet_data_provider = Internet()
    assert internet_data_provider.stock_image() != None

# Generated at 2022-06-12 02:06:54.580497
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    """Unit test for method hashtags of class Internet."""
    tester = Internet()
    assert isinstance(tester.hashtags(), str)
    assert isinstance(tester.hashtags(1), str)
    assert isinstance(tester.hashtags(10), list)

# Generated at 2022-06-12 02:06:56.825127
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    result = internet.stock_image()
    assert 'https://source.unsplash.com/' in result

# Generated at 2022-06-12 02:07:01.335400
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    provider = Internet()
    Quantity = 2
    assert len(provider.hashtags(quantity=Quantity)) == Quantity
    assert provider.hashtags(quantity=Quantity)[0].startswith('#')
    assert provider.hashtags(quantity=Quantity)[-1].startswith('#')


# Generated at 2022-06-12 02:07:04.928862
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    """Unit test for method stock_image of class Internet."""
    _ = Internet()
    result = _.stock_image()
    assert isinstance(result, str)
    assert 'https://' in result

    result = _.stock_image(writable=True)
    assert isinstance(result, bytes)

# Generated at 2022-06-12 02:07:10.155482
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    hashtags = internet.hashtags(quantity=6)
    assert len(hashtags) == 6, len(hashtags)
    assert len(hashtags[0]) >= 2
    assert isinstance(hashtags[0], str)

    hashtags = internet.hashtags(quantity=1)
    assert len(hashtags) == 1
    assert len(hashtags[0]) >= 2
    assert isinstance(hashtags[0], str)



# Generated at 2022-06-12 02:07:13.512980
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    provider = Internet()
    result = provider.hashtags(quantity=1)
    assert isinstance(result, str)

    result = provider.hashtags(quantity=4)
    assert isinstance(result, list)


# Generated at 2022-06-12 02:07:17.994259
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    """Internet.stock_image() should return a stock image.
    """
    internet = Internet()
    assert internet.stock_image()
    assert internet.stock_image(width=800)
    assert internet.stock_image(height=600)
    assert internet.stock_image(keywords=['nature'])

# Generated at 2022-06-12 02:09:03.803251
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from mimesis.enums import WidthRange, HeightRange
    from mimesis.utils import is_image
    from PIL import Image

    img = Internet.stock_image(
        width=WidthRange.RANDOM, height=HeightRange.RANDOM, writable=True)
    assert is_image(img)

    img = Image.open(img)
    assert img.width >= WidthRange.ICON.value[0]
    assert img.height >= HeightRange.ICON.value[0]

# Generated at 2022-06-12 02:09:06.622406
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    i = Internet()
    r = i.stock_image(writable=True)
    print(r)
    with open('e:\\tmp\\aaa.jpg', 'wb') as fp:
        fp.write(r)


# Generated at 2022-06-12 02:09:08.257339
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    Internet().stock_image(keywords=['sun', 'ocean'])

# Generated at 2022-06-12 02:09:12.554909
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    # Arrange
    provider = Internet('en')

    # Act
    url = provider.stock_image()

    # Assert
    assert url == 'https://source.unsplash.com/1920x1080?', f'{url}'


# Generated at 2022-06-12 02:09:21.807116
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    """Unit test for the method stock_image of class Internet."""
    from mimesis.schemas import Field
    from mimesis.typing import Schema

    class ImagePlaceholderSchema(Schema):
        """Class for generate data using the field 'stock_image'."""

        stock_image = Field('internet.stock_image')

    image = ImagePlaceholderSchema().create(suppress_warnings=True)
    assert isinstance(image, dict) and 'stock_image' in image
    assert (len(image['stock_image'])
            == len('https://source.unsplash.com/1920x1080/?'))

    class ImagePlaceholderWritableSchema(Schema):
        """Class for generate data using the field 'stock_image'."""


# Generated at 2022-06-12 02:09:28.430550
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    i = Internet()
    for _ in range(1000):
        i.stock_image()
        i.stock_image(width=600, height=400)
        i.stock_image(
            width=600,
            height=400,
            keywords=['nature', 'people'],
        )
    try:
        i.stock_image(
            width=600,
            height=400,
            keywords=['nature', 'people'],
            writable=True
        )
    except urllib.error.URLError:
        pass

# Generated at 2022-06-12 02:09:30.727090
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet(seed=42) 
    assert internet.stock_image(keywords=["cat", "dog"]) == "https://source.unsplash.com/1920x1080?cat,dog"

# Generated at 2022-06-12 02:09:33.897123
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    """
    Check method stock_image
    """
    try:
        assert Internet().stock_image() == "https://source.unsplash.com/1920x1080"
    except Exception as error:
        print(error)

# Generated at 2022-06-12 02:09:43.405596
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from mimesis.enums import PortRange
    from mimesis.providers.internet import Internet
    internet = Internet('en')
    assert internet.stock_image(800, 600, ['nature', 'animal']) == 'https://source.unsplash.com/800x600?nature,animal'
    assert isinstance(internet.port(PortRange.WELL_KNOWN), int)
    assert internet.port() in range(65536)
    assert internet.ip_v4(with_port=False)
    assert internet.ip_v4(with_port=True)
    assert internet.ip_v6()
    assert internet.mac_address()
    assert internet.emoji()
    assert internet.content_type()
    assert internet.http_status_message()
    assert internet.http_status_code()
    assert internet

# Generated at 2022-06-12 02:09:46.019664
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    i = Internet()
    assert isinstance(i.stock_image(1920, 1080), str)
    assert isinstance(i.stock_image(1920, 1080, writable=True), bytes)