

# Generated at 2022-06-12 02:07:00.617393
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    # Given
    provider = Internet()

    # When
    result = provider.stock_image(1400, 1400, ['cat', 'dog'])

    # Then
    assert isinstance(result, str)
    assert 'unsplash.com' in result

# Generated at 2022-06-12 02:07:01.830473
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    int_obj = Internet()
    assert int_obj.stock_image() is not None

# Generated at 2022-06-12 02:07:04.106838
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    country = internet.hashtags(quantity=1)
    #assert isinstance(country, str)
    #print(country)



# Generated at 2022-06-12 02:07:04.656370
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    stock_image()

# Generated at 2022-06-12 02:07:07.043463
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    assert len(internet.hashtags(3)) == 3
    assert internet.hashtags(1)[0].startswith("#")
    assert len(internet.hashtags(0)) == 4

# Generated at 2022-06-12 02:07:08.979083
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    """Tests Internet.stock_image"""
    internet = Internet()
    assert internet.stock_image() == 'https://source.unsplash.com/1920x1080?'

# Generated at 2022-06-12 02:07:12.115503
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet() # class Internet is imported from mimesis.providers.internet
    hashtags1 = internet.hashtags(quantity=4) # quantity is used to limit the quantity of the returned list of hashtags
    hashtags2 = internet.hashtags(quantity=1) # also, quantity=1 can be used for getting a single random hashtag
    print(hashtags1)
    print(hashtags2)



# Generated at 2022-06-12 02:07:12.948357
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    i = Internet()
    print(i.stock_image())

# Generated at 2022-06-12 02:07:14.812837
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    print('Running test for method stock_image of class Internet')

    from mimesis.enums import Category

    for _ in range(5):
        t = Internet(Category.TECH)
        print(t.stock_image())


# Generated at 2022-06-12 02:07:15.906829
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    intern = Internet()
    assert intern.stock_image() is not None

# Generated at 2022-06-12 02:07:47.085535
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    i = Internet()
    assert isinstance(i.stock_image(), str)
    assert isinstance(i.stock_image(writable=True), bytes)
    assert len(i.stock_image(writable=True)) > 100
    assert isinstance(i.stock_image(writable=False), str)
    assert len(i.stock_image(writable=False)) > 100

# Generated at 2022-06-12 02:07:48.185382
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    image = internet.stock_image()
    print(image)


# Generated at 2022-06-12 02:07:51.737764
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    # Initialization of class Internet.
    internet = Internet(seed=11)
    # Generate random stock image as string.
    test_image_link = internet.stock_image(
        width=740, height=570, writable=False
    )
    # Check
    assert (test_image_link ==
            'https://source.unsplash.com/740x570?family,colored,technology')



# Generated at 2022-06-12 02:07:54.154179
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from mimesis.enums import Size
    internet = Internet()
    url = internet.stock_image()
    url2 = internet.stock_image(Size.SMALL)
    assert isinstance(url, str)
    assert isinstance(url2, str)

# Generated at 2022-06-12 02:08:00.096724
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    seed = 3
    internet = Internet(seed)
    image = internet.stock_image(writable=True)
    assert len(image) == 31495
    assert image[:6] == b'\xFF\xD8\xFF\xE0\x00\x10'
    assert internet.stock_image() == 'https://source.unsplash.com/1920x1080?'

# Generated at 2022-06-12 02:08:02.792102
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    image = Internet.stock_image(600, 400, ['python', 'programming'])
    assert isinstance(image, str)
    assert image.startswith('https://images.unsplash.com/photo')

# Generated at 2022-06-12 02:08:04.913587
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    stock_image = internet.stock_image(writable=True)
    assert stock_image

# Generated at 2022-06-12 02:08:12.954112
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    """Unit test for method stock_image of class Internet."""
    internet = Internet()
    image = internet.stock_image()
    image_link = 'https://source.unsplash.com/1920x1080?'
    assert image == image_link

    keywords = ['cat', 'dog', 'bird']
    image = internet.stock_image(keywords=keywords)
    image_link = 'https://source.unsplash.com/1920x1080?cat,dog,bird'
    assert image == image_link

    image = internet.stock_image(width='200', height='200')
    image_link = 'https://source.unsplash.com/200x200?'
    assert image == image_link

# Generated at 2022-06-12 02:08:23.961873
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from mimesis.enums import PortRange
    from mimesis.providers.file import File
    from mimesis.providers.internet import Internet
    # PortRange.__repr__()
    assert repr(PortRange()) == '<Internet.PortRange: ALL>'
    # Internet.port()
    assert (0 < Internet().port() < 65535)
    # Internet.port()
    assert (0 < Internet().port(port_range=PortRange.MINIMUM) < 1024)
    # Internet.port()
    assert (1023 < Internet().port(port_range=PortRange.WELL_KNOWN) < 49152)
    # Internet.port()
    assert (49151 < Internet().port(port_range=PortRange.REGISTERED) < 65536)
    # Internet.port()

# Generated at 2022-06-12 02:08:33.485671
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    """Test stock_image method of class Internet."""
    from mimesis.enums import PortRange
    from mimesis.providers.internet import Internet
    from mimesis.providers.network import Network
    from mimesis.providers.os import OS

    internet = Internet(seed=100)
    network = Network(seed=100)
    os = OS(seed=100)

    assert internet.ip_v4(with_port=True, port_range=PortRange.ALL) == '0.0.0.0:13363'
    assert internet.ip_v4_object().compressed == '0.0.0.0'
    assert internet.ip_v6_object().exploded == '0000:0000:0000:0000:0000:0000:0000:0000'