

# Generated at 2022-06-17 22:42:31.083234
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    """Test for method stock_image of class Internet."""
    internet = Internet()
    url = internet.stock_image()
    assert url.startswith('https://source.unsplash.com/')

# Generated at 2022-06-17 22:42:32.548109
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    print(internet.stock_image())


# Generated at 2022-06-17 22:42:35.057282
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    assert internet.stock_image() == 'https://source.unsplash.com/1920x1080'

# Generated at 2022-06-17 22:42:43.780845
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from mimesis.enums import ImageSize
    from mimesis.providers.internet import Internet
    from mimesis.providers.file import File
    from mimesis.providers.generic import Generic
    from mimesis.providers.text import Text
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.business import Business
    from mimesis.providers.code import Code
    from mimesis.providers.misc import Misc
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.unit import Unit
   

# Generated at 2022-06-17 22:42:48.860508
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    assert internet.hashtags(quantity=1) == '#love'
    assert internet.hashtags(quantity=2) == ['#love', '#sky']
    assert internet.hashtags(quantity=3) == ['#love', '#sky', '#nice']
    assert internet.hashtags(quantity=4) == ['#love', '#sky', '#nice', '#sun']


# Generated at 2022-06-17 22:42:51.802837
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from mimesis.enums import ImageFormat

    internet = Internet()
    image = internet.stock_image(writable=True)
    assert isinstance(image, bytes)

    image_format = internet.file.mime_type(type_=ImageFormat.JPEG)
    assert image_format in str(image)

# Generated at 2022-06-17 22:42:53.883366
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    print(internet.stock_image())


# Generated at 2022-06-17 22:43:04.580054
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    assert internet.hashtags(quantity=1) == '#love'
    assert internet.hashtags(quantity=2) == ['#love', '#sky']
    assert internet.hashtags(quantity=3) == ['#love', '#sky', '#nice']
    assert internet.hashtags(quantity=4) == ['#love', '#sky', '#nice', '#sky']
    assert internet.hashtags(quantity=5) == ['#love', '#sky', '#nice', '#sky', '#nice']


# Generated at 2022-06-17 22:43:14.476782
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from mimesis.enums import ImageSize
    from mimesis.providers.internet import Internet
    from mimesis.providers.file import File
    from mimesis.providers.file import Image
    from mimesis.providers.file import ImageFormat
    from mimesis.providers.file import ImageSize as ImageSizeEnum
    from mimesis.providers.file import ImageType
    from mimesis.providers.file import ImageType as ImageTypeEnum
    from mimesis.providers.file import ImageType as ImageTypeEnum
    from mimesis.providers.file import ImageType as ImageTypeEnum
    from mimesis.providers.file import ImageType as ImageTypeEnum
    from mimesis.providers.file import ImageType as ImageTypeEnum

# Generated at 2022-06-17 22:43:15.713788
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    image = internet.stock_image()
    assert isinstance(image, str)

# Generated at 2022-06-17 22:43:27.851195
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    image = internet.stock_image(width=1920, height=1080, keywords=['nature'])
    assert isinstance(image, str)
    assert image.startswith('https://')
    assert image.endswith('.jpg')

# Generated at 2022-06-17 22:43:29.347316
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    image = internet.stock_image(writable=True)
    assert isinstance(image, bytes)

# Generated at 2022-06-17 22:43:36.507062
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from mimesis.enums import ImageSize
    from mimesis.providers.internet import Internet
    internet = Internet()
    assert internet.stock_image(width=ImageSize.SMALL.value,
                                height=ImageSize.SMALL.value) == 'https://source.unsplash.com/400x400'
    assert internet.stock_image(width=ImageSize.MEDIUM.value,
                                height=ImageSize.MEDIUM.value) == 'https://source.unsplash.com/800x800'
    assert internet.stock_image(width=ImageSize.LARGE.value,
                                height=ImageSize.LARGE.value) == 'https://source.unsplash.com/1600x1600'

# Generated at 2022-06-17 22:43:39.379859
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    assert internet.stock_image() == 'https://source.unsplash.com/1920x1080'

# Generated at 2022-06-17 22:43:41.820966
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    image = internet.stock_image(width=1920, height=1080)
    assert image.startswith('https://images.unsplash.com/')

# Generated at 2022-06-17 22:43:43.618259
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    print(internet.stock_image())


# Generated at 2022-06-17 22:43:50.836183
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from mimesis.enums import Layer
    from mimesis.providers.internet import Internet
    internet = Internet()
    print(internet.stock_image())
    print(internet.stock_image(keywords=['cat', 'dog']))
    print(internet.stock_image(width=400, height=200))
    print(internet.stock_image(keywords=['cat', 'dog'], width=400, height=200))
    print(internet.network_protocol(layer=Layer.APPLICATION))

# Generated at 2022-06-17 22:43:54.601912
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    assert internet.stock_image() == 'https://source.unsplash.com/1920x1080'

# Generated at 2022-06-17 22:43:57.978639
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    image = internet.stock_image()
    assert image == 'https://source.unsplash.com/1920x1080'

# Generated at 2022-06-17 22:44:08.228590
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    assert internet.stock_image() == 'https://source.unsplash.com/1920x1080'
    assert internet.stock_image(width=100, height=100) == 'https://source.unsplash.com/100x100'
    assert internet.stock_image(keywords=['nature', 'mountain']) == 'https://source.unsplash.com/1920x1080?nature,mountain'
    assert internet.stock_image(keywords=['nature', 'mountain'], width=100, height=100) == 'https://source.unsplash.com/100x100?nature,mountain'

# Generated at 2022-06-17 22:45:05.152783
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    assert internet.stock_image() == 'https://source.unsplash.com/1920x1080'

# Generated at 2022-06-17 22:45:13.445387
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from mimesis.enums import ImageSize
    from mimesis.providers.internet import Internet
    internet = Internet()
    image = internet.stock_image(ImageSize.SMALL)
    assert isinstance(image, str)
    assert image.startswith('https://source.unsplash.com/')
    image = internet.stock_image(ImageSize.SMALL, writable=True)
    assert isinstance(image, bytes)
    assert image.startswith(b'\xff\xd8\xff\xe0\x00\x10JFIF')

# Generated at 2022-06-17 22:45:23.270835
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    assert internet.stock_image() == 'https://source.unsplash.com/1920x1080'
    assert internet.stock_image(keywords=['cat']) == 'https://source.unsplash.com/1920x1080?cat'
    assert internet.stock_image(keywords=['cat', 'dog']) == 'https://source.unsplash.com/1920x1080?cat,dog'
    assert internet.stock_image(keywords=['cat', 'dog', 'bird']) == 'https://source.unsplash.com/1920x1080?cat,dog,bird'
    assert internet.stock_image(keywords=['cat', 'dog', 'bird', 'fish']) == 'https://source.unsplash.com/1920x1080?cat,dog,bird,fish'

# Generated at 2022-06-17 22:45:25.313858
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    image = internet.stock_image()
    assert image.startswith('https://')

# Generated at 2022-06-17 22:45:26.929222
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    assert internet.stock_image() == 'https://source.unsplash.com/1920x1080'

# Generated at 2022-06-17 22:45:33.572888
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from mimesis.enums import ImageSize
    from mimesis.providers.internet import Internet
    from mimesis.providers.file import File
    from mimesis.providers.image import Image
    from mimesis.providers.misc import Misc
    from mimesis.providers.person import Person
    from mimesis.providers.text import Text
    from mimesis.providers.time import Time
    from mimesis.providers.unit import Unit
    from mimesis.providers.web import Web
    from mimesis.providers.address import Address
    from mimesis.providers.business import Business
    from mimesis.providers.code import Code
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.geo import Geo

# Generated at 2022-06-17 22:45:44.961537
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from mimesis.enums import ImageSize
    from mimesis.providers.internet import Internet
    from mimesis.providers.file import File
    from mimesis.providers.image import Image
    from mimesis.providers.misc import Misc

    internet = Internet()
    file = File()
    image = Image()
    misc = Misc()

    # Generate random image
    image_url = internet.stock_image()
    assert image_url.startswith('https://source.unsplash.com/')

    # Generate random image with keywords
    keywords = misc.keywords()
    image_url = internet.stock_image(keywords=keywords)
    assert image_url.startswith('https://source.unsplash.com/')

    # Generate random image with keywords and size
   

# Generated at 2022-06-17 22:45:46.947351
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    result = internet.stock_image()
    assert isinstance(result, str)
    assert result.startswith('https://source.unsplash.com/')

# Generated at 2022-06-17 22:45:54.974061
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    """Unit test for method stock_image of class Internet."""
    internet = Internet()
    url = internet.stock_image()
    assert isinstance(url, str)
    assert url.startswith('https://source.unsplash.com/')
    assert url.endswith('.jpg')

    url = internet.stock_image(keywords=['cat'])
    assert isinstance(url, str)
    assert url.startswith('https://source.unsplash.com/')
    assert url.endswith('.jpg')
    assert 'cat' in url

    url = internet.stock_image(keywords=['cat', 'dog'])
    assert isinstance(url, str)
    assert url.startswith('https://source.unsplash.com/')

# Generated at 2022-06-17 22:45:57.913373
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    assert internet.stock_image() == 'https://source.unsplash.com/1920x1080'