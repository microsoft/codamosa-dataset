

# Generated at 2022-06-17 22:42:36.504403
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    """Test for method stock_image of class Internet."""
    internet = Internet()
    assert internet.stock_image() == 'https://source.unsplash.com/1920x1080?'
    assert internet.stock_image(keywords=['nature']) == 'https://source.unsplash.com/1920x1080?nature'
    assert internet.stock_image(keywords=['nature', 'water']) == 'https://source.unsplash.com/1920x1080?nature,water'
    assert internet.stock_image(keywords=['nature', 'water'], width=800) == 'https://source.unsplash.com/800x1080?nature,water'

# Generated at 2022-06-17 22:42:37.774333
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    internet.stock_image()

# Generated at 2022-06-17 22:42:39.308550
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    image = internet.stock_image(writable=True)
    assert isinstance(image, bytes)

# Generated at 2022-06-17 22:42:45.821278
# Unit test for method port of class Internet
def test_Internet_port():
    internet = Internet()
    port = internet.port(port_range=PortRange.ALL)
    assert port >= 0 and port <= 65535
    port = internet.port(port_range=PortRange.WELL_KNOWN)
    assert port >= 0 and port <= 1023
    port = internet.port(port_range=PortRange.REGISTERED)
    assert port >= 1024 and port <= 49151
    port = internet.port(port_range=PortRange.DYNAMIC)
    assert port >= 49152 and port <= 65535

# Generated at 2022-06-17 22:42:52.194419
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    assert internet.stock_image() == 'https://source.unsplash.com/1920x1080'
    assert internet.stock_image(width=100, height=100) == 'https://source.unsplash.com/100x100'
    assert internet.stock_image(keywords=['nature']) == 'https://source.unsplash.com/1920x1080?nature'
    assert internet.stock_image(keywords=['nature', 'water']) == 'https://source.unsplash.com/1920x1080?nature,water'
    assert internet.stock_image(keywords=['nature', 'water'], writable=True) is not None

# Generated at 2022-06-17 22:42:55.650202
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    assert internet.stock_image() == 'https://source.unsplash.com/1920x1080'


# Generated at 2022-06-17 22:43:03.131709
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    print(internet.stock_image())
    print(internet.stock_image(keywords=['cat', 'dog']))
    print(internet.stock_image(width=500, height=500))
    print(internet.stock_image(width=500, height=500, keywords=['cat', 'dog']))

# Generated at 2022-06-17 22:43:09.910844
# Unit test for method port of class Internet
def test_Internet_port():
    internet = Internet()
    port = internet.port(port_range=PortRange.ALL)
    assert port >= 0 and port <= 65535
    port = internet.port(port_range=PortRange.WELL_KNOWN)
    assert port >= 0 and port <= 1023
    port = internet.port(port_range=PortRange.REGISTERED)
    assert port >= 1024 and port <= 49151
    port = internet.port(port_range=PortRange.DYNAMIC)
    assert port >= 49152 and port <= 65535

# Generated at 2022-06-17 22:43:11.676416
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    image = internet.stock_image(writable=True)
    assert isinstance(image, bytes)

# Generated at 2022-06-17 22:43:19.838972
# Unit test for method port of class Internet
def test_Internet_port():
    internet = Internet()
    port = internet.port(port_range=PortRange.ALL)
    assert port >= 0 and port <= 65535
    port = internet.port(port_range=PortRange.WELL_KNOWN)
    assert port >= 0 and port <= 1023
    port = internet.port(port_range=PortRange.REGISTERED)
    assert port >= 1024 and port <= 49151
    port = internet.port(port_range=PortRange.DYNAMIC_AND_PRIVATE)
    assert port >= 49152 and port <= 65535


# Generated at 2022-06-17 22:43:28.956395
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    assert internet.stock_image() == 'https://source.unsplash.com/1920x1080'

# Generated at 2022-06-17 22:43:32.364055
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    assert isinstance(internet.hashtags(), str)
    assert isinstance(internet.hashtags(quantity=3), list)
    assert len(internet.hashtags(quantity=3)) == 3
    assert internet.hashtags(quantity=1) == '#love'


# Generated at 2022-06-17 22:43:38.172365
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    from mimesis.enums import Hashtag
    from mimesis.providers.internet import Internet
    internet = Internet()
    assert internet.hashtags(quantity=1) in Hashtag.ALL.value
    assert internet.hashtags(quantity=2) in Hashtag.ALL.value
    assert internet.hashtags(quantity=3) in Hashtag.ALL.value
    assert internet.hashtags(quantity=4) in Hashtag.ALL.value
    assert internet.hashtags(quantity=5) in Hashtag.ALL.value
    assert internet.hashtags(quantity=6) in Hashtag.ALL.value
    assert internet.hashtags(quantity=7) in Hashtag.ALL.value
    assert internet.hashtags(quantity=8) in Hashtag.ALL.value

# Generated at 2022-06-17 22:43:49.945003
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    assert isinstance(internet.hashtags(), str)
    assert isinstance(internet.hashtags(quantity=1), str)
    assert isinstance(internet.hashtags(quantity=2), list)
    assert isinstance(internet.hashtags(quantity=3), list)
    assert isinstance(internet.hashtags(quantity=4), list)
    assert isinstance(internet.hashtags(quantity=5), list)
    assert isinstance(internet.hashtags(quantity=6), list)
    assert isinstance(internet.hashtags(quantity=7), list)
    assert isinstance(internet.hashtags(quantity=8), list)
    assert isinstance(internet.hashtags(quantity=9), list)
    assert isinstance(internet.hashtags(quantity=10), list)


# Generated at 2022-06-17 22:43:56.582525
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    assert internet.hashtags(quantity=1) == '#love'
    assert internet.hashtags(quantity=2) == ['#love', '#sky']
    assert internet.hashtags(quantity=3) == ['#love', '#sky', '#nice']
    assert internet.hashtags(quantity=4) == ['#love', '#sky', '#nice', '#sky']
    assert internet.hashtags(quantity=5) == ['#love', '#sky', '#nice', '#sky', '#nice']

# Generated at 2022-06-17 22:44:00.795231
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    """Test method stock_image of class Internet."""
    internet = Internet()
    assert internet.stock_image() == 'https://source.unsplash.com/1920x1080'

# Generated at 2022-06-17 22:44:07.559761
# Unit test for method port of class Internet
def test_Internet_port():
    from mimesis.enums import PortRange
    from mimesis.providers.internet import Internet
    internet = Internet()
    assert internet.port(port_range=PortRange.ALL) in range(0, 65535)
    assert internet.port(port_range=PortRange.WELL_KNOWN) in range(0, 1023)
    assert internet.port(port_range=PortRange.REGISTERED) in range(1024, 49151)
    assert internet.port(port_range=PortRange.DYNAMIC) in range(49152, 65535)


# Generated at 2022-06-17 22:44:09.373195
# Unit test for method port of class Internet
def test_Internet_port():
    internet = Internet()
    port = internet.port(port_range=PortRange.WELL_KNOWN)
    assert port in range(0, 1024)

# Generated at 2022-06-17 22:44:16.305896
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from mimesis.enums import ImageSize
    from mimesis.providers.internet import Internet
    from mimesis.providers.file import File
    from mimesis.providers.datetime import Datetime
    import os
    import shutil
    import tempfile

    internet = Internet()
    file = File()
    datetime = Datetime()
    image_size = ImageSize.LARGE
    keywords = ['nature', 'landscape']
    image_name = '{}.jpg'.format(datetime.timestamp())
    image_path = os.path.join(tempfile.gettempdir(), image_name)
    image_url = internet.stock_image(
        width=image_size.value[0],
        height=image_size.value[1],
        keywords=keywords,
    )

   

# Generated at 2022-06-17 22:44:18.861193
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    image = internet.stock_image(width=1920, height=1080, writable=True)
    assert isinstance(image, bytes)

# Generated at 2022-06-17 22:44:34.467213
# Unit test for method port of class Internet
def test_Internet_port():
    from mimesis.enums import PortRange
    from mimesis.exceptions import NonEnumerableError
    from mimesis.providers.internet import Internet

    internet = Internet()
    assert internet.port(PortRange.ALL) in range(0, 65535)
    assert internet.port(PortRange.SYSTEM) in range(0, 1024)
    assert internet.port(PortRange.USER) in range(1024, 49151)
    assert internet.port(PortRange.DYNAMIC) in range(49152, 65535)
    assert internet.port(PortRange.EPHEMERAL) in range(32768, 61000)
    assert internet.port(PortRange.WELL_KNOWN) in range(1, 1023)
    assert internet.port(PortRange.REGISTERED) in range(1024, 49151)
   

# Generated at 2022-06-17 22:44:36.474394
# Unit test for method port of class Internet
def test_Internet_port():
    """Unit test for method port of class Internet."""
    internet = Internet()
    port = internet.port()
    assert port >= 0 and port <= 65535

# Generated at 2022-06-17 22:44:40.429002
# Unit test for method port of class Internet
def test_Internet_port():
    internet = Internet()
    port = internet.port(port_range=PortRange.ALL)
    assert isinstance(port, int)
    assert port >= 0
    assert port <= 65535


# Generated at 2022-06-17 22:44:47.791920
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    """Unit test for method stock_image of class Internet."""
    internet = Internet()
    assert internet.stock_image() == 'https://source.unsplash.com/1920x1080'
    assert internet.stock_image(keywords=['nature']) == 'https://source.unsplash.com/1920x1080?nature'
    assert internet.stock_image(keywords=['nature', 'water']) == 'https://source.unsplash.com/1920x1080?nature,water'
    assert internet.stock_image(keywords=['nature', 'water'], width=800, height=600) == 'https://source.unsplash.com/800x600?nature,water'

# Generated at 2022-06-17 22:44:50.122676
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    """Test for method stock_image of class Internet."""
    internet = Internet()
    url = internet.stock_image()
    assert url.startswith('https://source.unsplash.com/')

# Generated at 2022-06-17 22:44:52.128451
# Unit test for method port of class Internet
def test_Internet_port():
    internet = Internet()
    port = internet.port()
    assert isinstance(port, int)
    assert port >= 0
    assert port <= 65535


# Generated at 2022-06-17 22:44:54.857512
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    assert internet.stock_image() == 'https://source.unsplash.com/1920x1080'

# Generated at 2022-06-17 22:44:56.115342
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    image = internet.stock_image()
    assert image.startswith('https://source.unsplash.com/')

# Generated at 2022-06-17 22:45:00.624510
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    image = internet.stock_image()
    assert isinstance(image, str)
    assert image.startswith('https://')
    assert image.endswith('.jpg')

# Generated at 2022-06-17 22:45:07.037592
# Unit test for method port of class Internet
def test_Internet_port():
    internet = Internet()
    assert internet.port(port_range=PortRange.WELL_KNOWN) in range(0, 1024)
    assert internet.port(port_range=PortRange.REGISTERED) in range(1024, 49152)
    assert internet.port(port_range=PortRange.DYNAMIC) in range(49152, 65535)
    assert internet.port(port_range=PortRange.ALL) in range(0, 65535)