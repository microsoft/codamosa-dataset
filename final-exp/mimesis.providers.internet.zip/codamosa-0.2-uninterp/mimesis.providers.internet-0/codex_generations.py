

# Generated at 2022-06-17 22:42:45.684696
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    image = internet.stock_image()
    assert image is not None

# Generated at 2022-06-17 22:42:50.013384
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from mimesis.enums import MimeType
    from mimesis.providers.internet import Internet
    from mimesis.providers.file import File
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.utils import ProviderType
    from mimesis.providers.utils import get_provider_by_type
    from mimesis.providers.utils import get_provider_by_name
    from mimesis.providers.utils import get_provider_by_class
    from mimesis.providers.utils import get_provider_by_instance
    from mimesis.providers.utils import get_provider_by_module
    from mimesis.providers.utils import get_provider_by_object
    from mimesis.providers.utils import get

# Generated at 2022-06-17 22:42:57.610772
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from mimesis.enums import ImageSize
    from mimesis.providers.internet import Internet
    from mimesis.providers.file import File
    from mimesis.providers.misc import Misc

    internet = Internet()
    file = File()
    misc = Misc()

    # Test for method stock_image
    # Test for default parameters
    url = internet.stock_image()
    assert url.startswith('https://source.unsplash.com/')

    # Test for custom parameters
    url = internet.stock_image(
        width=ImageSize.WIDTH_1080,
        height=ImageSize.HEIGHT_720,
        keywords=['nature', 'mountains'],
    )
    assert url.startswith('https://source.unsplash.com/')

    # Test for writable parameter

# Generated at 2022-06-17 22:43:10.084750
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    assert internet.stock_image(width=1920, height=1080) == 'https://source.unsplash.com/1920x1080'
    assert internet.stock_image(width=1920, height=1080, keywords=['dog', 'cat']) == 'https://source.unsplash.com/1920x1080?dog,cat'

# Generated at 2022-06-17 22:43:12.546203
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    assert internet.hashtags() == '#love'
    assert internet.hashtags(quantity=3) == ['#love', '#sky', '#nice']

# Generated at 2022-06-17 22:43:24.237921
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    assert internet.hashtags(quantity=1) == '#love'
    assert internet.hashtags(quantity=2) == ['#love', '#sky']
    assert internet.hashtags(quantity=3) == ['#love', '#sky', '#nice']
    assert internet.hashtags(quantity=4) == ['#love', '#sky', '#nice', '#sun']
    assert internet.hashtags(quantity=5) == ['#love', '#sky', '#nice', '#sun', '#sea']
    assert internet.hashtags(quantity=6) == ['#love', '#sky', '#nice', '#sun', '#sea', '#girl']

# Generated at 2022-06-17 22:43:26.879446
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    image = internet.stock_image()
    assert isinstance(image, str)
    assert image.startswith('https://source.unsplash.com/')

# Generated at 2022-06-17 22:43:34.804388
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    assert internet.stock_image() == 'https://source.unsplash.com/1920x1080'
    assert internet.stock_image(width=800, height=600) == 'https://source.unsplash.com/800x600'
    assert internet.stock_image(keywords=['nature']) == 'https://source.unsplash.com/1920x1080?nature'
    assert internet.stock_image(keywords=['nature', 'mountain']) == 'https://source.unsplash.com/1920x1080?nature,mountain'

# Generated at 2022-06-17 22:43:39.591305
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    from mimesis.enums import Hashtag
    from mimesis.providers.internet import Internet
    internet = Internet()
    assert internet.hashtags(Hashtag.ANIMALS)


# Generated at 2022-06-17 22:43:45.407687
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    assert internet.hashtags(quantity=1) == '#love'
    assert internet.hashtags(quantity=2) == ['#love', '#sky']
    assert internet.hashtags(quantity=3) == ['#love', '#sky', '#nice']
    assert internet.hashtags(quantity=4) == ['#love', '#sky', '#nice', '#girl']