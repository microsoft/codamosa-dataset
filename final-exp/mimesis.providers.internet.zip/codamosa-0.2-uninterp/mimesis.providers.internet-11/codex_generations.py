

# Generated at 2022-06-17 22:44:03.000417
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    assert internet.hashtags() == '#love'
    assert internet.hashtags(quantity=3) == ['#love', '#sky', '#nice']

# Generated at 2022-06-17 22:44:11.536509
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    from mimesis.enums import Hashtag
    from mimesis.providers.internet import Internet
    internet = Internet()
    assert internet.hashtags(quantity=1) in Hashtag.ALL
    assert internet.hashtags(quantity=2) in Hashtag.ALL
    assert internet.hashtags(quantity=3) in Hashtag.ALL
    assert internet.hashtags(quantity=4) in Hashtag.ALL
    assert internet.hashtags(quantity=5) in Hashtag.ALL
    assert internet.hashtags(quantity=6) in Hashtag.ALL
    assert internet.hashtags(quantity=7) in Hashtag.ALL
    assert internet.hashtags(quantity=8) in Hashtag.ALL
    assert internet.hashtags(quantity=9) in Hashtag.ALL
    assert internet.hashtags

# Generated at 2022-06-17 22:44:17.148876
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    assert internet.hashtags(quantity=1) == '#love'
    assert internet.hashtags(quantity=2) == ['#love', '#sky']
    assert internet.hashtags(quantity=3) == ['#love', '#sky', '#nice']
    assert internet.hashtags(quantity=4) == ['#love', '#sky', '#nice', '#sun']

# Generated at 2022-06-17 22:44:23.502515
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    assert isinstance(internet.hashtags(), str)
    assert isinstance(internet.hashtags(quantity=1), str)
    assert isinstance(internet.hashtags(quantity=2), list)
    assert isinstance(internet.hashtags(quantity=3), list)
    assert isinstance(internet.hashtags(quantity=4), list)
    assert isinstance(internet.hashtags(quantity=5), list)
    assert isinstance(internet.hashtags(quantity=6), list)
    assert isinstance(internet.hashtags(quantity=7), list)
    assert isinstance(internet.hashtags(quantity=8), list)
    assert isinstance(internet.hashtags(quantity=9), list)
    assert isinstance(internet.hashtags(quantity=10), list)


# Generated at 2022-06-17 22:44:29.243698
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    assert internet.hashtags(quantity=1) == '#love'
    assert internet.hashtags(quantity=2) == ['#love', '#sky']
    assert internet.hashtags(quantity=3) == ['#love', '#sky', '#nice']
    assert internet.hashtags(quantity=4) == ['#love', '#sky', '#nice', '#sun']

# Generated at 2022-06-17 22:44:34.937432
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    from mimesis.enums import Hashtag
    from mimesis.providers.internet import Internet
    internet = Internet()
    assert internet.hashtags(quantity=1) in Hashtag.ALL.value
    assert internet.hashtags(quantity=2) in Hashtag.ALL.value
    assert internet.hashtags(quantity=3) in Hashtag.ALL.value
    assert internet.hashtags(quantity=4) in Hashtag.ALL.value
    assert internet.hashtags(quantity=5) in Hashtag.ALL.value
    assert internet.hashtags(quantity=6) in Hashtag.ALL.value
    assert internet.hashtags(quantity=7) in Hashtag.ALL.value
    assert internet.hashtags(quantity=8) in Hashtag.ALL.value

# Generated at 2022-06-17 22:44:45.319446
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    from mimesis.enums import Hashtag
    from mimesis.providers.internet import Internet
    internet = Internet()
    assert internet.hashtags(quantity=1) in Hashtag.ALL
    assert internet.hashtags(quantity=2) in Hashtag.ALL
    assert internet.hashtags(quantity=3) in Hashtag.ALL
    assert internet.hashtags(quantity=4) in Hashtag.ALL
    assert internet.hashtags(quantity=5) in Hashtag.ALL
    assert internet.hashtags(quantity=6) in Hashtag.ALL
    assert internet.hashtags(quantity=7) in Hashtag.ALL
    assert internet.hashtags(quantity=8) in Hashtag.ALL
    assert internet.hashtags(quantity=9) in Hashtag.ALL
    assert internet.hashtags

# Generated at 2022-06-17 22:44:52.961579
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    assert internet.hashtags(quantity=1) == '#love'
    assert internet.hashtags(quantity=2) == ['#love', '#sky']
    assert internet.hashtags(quantity=3) == ['#love', '#sky', '#nice']
    assert internet.hashtags(quantity=4) == ['#love', '#sky', '#nice', '#sun']
    assert internet.hashtags(quantity=5) == ['#love', '#sky', '#nice', '#sun', '#summer']
    assert internet.hashtags(quantity=6) == ['#love', '#sky', '#nice', '#sun', '#summer', '#beach']

# Generated at 2022-06-17 22:44:58.169921
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    from mimesis.enums import Hashtag
    from mimesis.providers.internet import Internet
    internet = Internet()
    assert internet.hashtags(quantity=1) in Hashtag.__members__
    assert internet.hashtags(quantity=2) in Hashtag.__members__
    assert internet.hashtags(quantity=3) in Hashtag.__members__
    assert internet.hashtags(quantity=4) in Hashtag.__members__
    assert internet.hashtags(quantity=5) in Hashtag.__members__
    assert internet.hashtags(quantity=6) in Hashtag.__members__
    assert internet.hashtags(quantity=7) in Hashtag.__members__
    assert internet.hashtags(quantity=8) in Hashtag.__members__

# Generated at 2022-06-17 22:45:02.234386
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    assert internet.hashtags(quantity=1) == '#love'
    assert internet.hashtags(quantity=2) == ['#love', '#sky']
    assert internet.hashtags(quantity=3) == ['#love', '#sky', '#nice']
    assert internet.hashtags(quantity=4) == ['#love', '#sky', '#nice', '#sun']