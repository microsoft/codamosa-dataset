

# Generated at 2022-06-17 22:42:38.889329
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from mimesis.enums import Layer
    from mimesis.providers.internet import Internet
    from mimesis.providers.network import Network
    from mimesis.providers.text import Text
    from mimesis.providers.utils import Provider

    provider = Provider(Internet, Network, Text)

    assert provider.internet.stock_image(
        width=1920,
        height=1080,
        keywords=['nature', 'water', 'mountain'],
    ) == 'https://source.unsplash.com/1920x1080?nature,water,mountain'


# Generated at 2022-06-17 22:42:48.777842
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    assert internet.stock_image() == 'https://source.unsplash.com/1920x1080'
    assert internet.stock_image(width=800, height=600) == 'https://source.unsplash.com/800x600'
    assert internet.stock_image(keywords=['nature']) == 'https://source.unsplash.com/1920x1080?nature'
    assert internet.stock_image(keywords=['nature', 'mountain']) == 'https://source.unsplash.com/1920x1080?nature,mountain'

# Generated at 2022-06-17 22:42:55.430598
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    assert internet.stock_image() == 'https://source.unsplash.com/1920x1080'
    assert internet.stock_image(width=800, height=600) == 'https://source.unsplash.com/800x600'
    assert internet.stock_image(keywords=['nature']) == 'https://source.unsplash.com/1920x1080?nature'
    assert internet.stock_image(keywords=['nature', 'water']) == 'https://source.unsplash.com/1920x1080?nature,water'

# Generated at 2022-06-17 22:43:04.066143
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    assert internet.stock_image() == 'https://source.unsplash.com/1920x1080'
    assert internet.stock_image(width=800, height=600) == 'https://source.unsplash.com/800x600'
    assert internet.stock_image(keywords=['nature', 'mountain']) == 'https://source.unsplash.com/1920x1080?nature,mountain'

# Generated at 2022-06-17 22:43:10.127742
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    assert internet.stock_image() == 'https://source.unsplash.com/1920x1080'
    assert internet.stock_image(width=400, height=300) == 'https://source.unsplash.com/400x300'
    assert internet.stock_image(keywords=['nature', 'mountain']) == 'https://source.unsplash.com/1920x1080?nature,mountain'

# Generated at 2022-06-17 22:43:21.014530
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    assert isinstance(internet.hashtags(), str)
    assert isinstance(internet.hashtags(quantity=2), list)
    assert isinstance(internet.hashtags(quantity=3), list)
    assert isinstance(internet.hashtags(quantity=4), list)
    assert isinstance(internet.hashtags(quantity=5), list)
    assert isinstance(internet.hashtags(quantity=6), list)
    assert isinstance(internet.hashtags(quantity=7), list)
    assert isinstance(internet.hashtags(quantity=8), list)
    assert isinstance(internet.hashtags(quantity=9), list)
    assert isinstance(internet.hashtags(quantity=10), list)
    assert isinstance(internet.hashtags(quantity=11), list)


# Generated at 2022-06-17 22:43:23.125148
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    internet.stock_image(width=1920, height=1080)

# Generated at 2022-06-17 22:43:26.038691
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    """Test for method stock_image of class Internet."""
    internet = Internet()
    url = internet.stock_image()
    assert isinstance(url, str)
    assert url.startswith('https://source.unsplash.com/')

# Generated at 2022-06-17 22:43:26.916268
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    internet.stock_image()

# Generated at 2022-06-17 22:43:34.836368
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    assert isinstance(internet.hashtags(quantity=1), str)
    assert isinstance(internet.hashtags(quantity=2), list)
    assert isinstance(internet.hashtags(quantity=3), list)
    assert isinstance(internet.hashtags(quantity=4), list)
    assert isinstance(internet.hashtags(quantity=5), list)
    assert isinstance(internet.hashtags(quantity=6), list)
    assert isinstance(internet.hashtags(quantity=7), list)
    assert isinstance(internet.hashtags(quantity=8), list)
    assert isinstance(internet.hashtags(quantity=9), list)
    assert isinstance(internet.hashtags(quantity=10), list)