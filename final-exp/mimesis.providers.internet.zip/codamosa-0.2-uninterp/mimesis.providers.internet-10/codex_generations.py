

# Generated at 2022-06-17 22:43:18.885558
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    assert isinstance(internet.hashtags(), str)
    assert isinstance(internet.hashtags(quantity=1), str)
    assert isinstance(internet.hashtags(quantity=3), list)
    assert isinstance(internet.hashtags(quantity=3)[0], str)
    assert isinstance(internet.hashtags(quantity=3)[1], str)
    assert isinstance(internet.hashtags(quantity=3)[2], str)
    assert internet.hashtags(quantity=3)[0].startswith('#')
    assert internet.hashtags(quantity=3)[1].startswith('#')
    assert internet.hashtags(quantity=3)[2].startswith('#')


# Generated at 2022-06-17 22:43:20.680040
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    assert internet.stock_image() == 'https://source.unsplash.com/1920x1080'

# Generated at 2022-06-17 22:43:26.651279
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    """Test for method stock_image of class Internet."""
    internet = Internet()
    assert internet.stock_image() == 'https://source.unsplash.com/1920x1080'
    assert internet.stock_image(width=800, height=600) == 'https://source.unsplash.com/800x600'
    assert internet.stock_image(keywords=['nature', 'water']) == 'https://source.unsplash.com/1920x1080?nature,water'

# Generated at 2022-06-17 22:43:34.603545
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    assert internet.hashtags(quantity=1) == '#love'
    assert internet.hashtags(quantity=2) == ['#love', '#sky']
    assert internet.hashtags(quantity=3) == ['#love', '#sky', '#nice']
    assert internet.hashtags(quantity=4) == ['#love', '#sky', '#nice', '#sun']
    assert internet.hashtags(quantity=5) == ['#love', '#sky', '#nice', '#sun', '#summer']
    assert internet.hashtags(quantity=6) == ['#love', '#sky', '#nice', '#sun', '#summer', '#beach']

# Generated at 2022-06-17 22:43:36.159943
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    """Test for method stock_image of class Internet."""
    internet = Internet()
    assert internet.stock_image() == 'https://source.unsplash.com/1920x1080?'

# Generated at 2022-06-17 22:43:39.118542
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    image = internet.stock_image()
    assert isinstance(image, str)

# Generated at 2022-06-17 22:43:50.231419
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from mimesis.enums import ImageSize
    from mimesis.providers.internet import Internet
    from mimesis.providers.file import File
    from mimesis.providers.image import Image
    import os
    import tempfile
    import unittest

    class TestInternet(unittest.TestCase):

        def setUp(self):
            self.internet = Internet()
            self.file = File()
            self.image = Image()

        def test_stock_image(self):
            url = self.internet.stock_image()
            self.assertIsInstance(url, str)
            self.assertIn('https://source.unsplash.com/', url)


# Generated at 2022-06-17 22:43:58.040172
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    url = internet.stock_image()
    assert url == 'https://source.unsplash.com/1920x1080'
    url = internet.stock_image(width=800, height=600)
    assert url == 'https://source.unsplash.com/800x600'
    url = internet.stock_image(keywords=['nature', 'mountain'])
    assert url == 'https://source.unsplash.com/1920x1080?nature,mountain'
    url = internet.stock_image(width=800, height=600, keywords=['nature', 'mountain'])
    assert url == 'https://source.unsplash.com/800x600?nature,mountain'
    url = internet.stock_image(writable=True)
    assert isinstance(url, bytes)

# Generated at 2022-06-17 22:44:08.310944
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    assert isinstance(internet.hashtags(), str)
    assert isinstance(internet.hashtags(quantity=2), list)
    assert isinstance(internet.hashtags(quantity=1), str)
    assert isinstance(internet.hashtags(quantity=0), list)
    assert isinstance(internet.hashtags(quantity=-1), list)
    assert isinstance(internet.hashtags(quantity=1.5), str)
    assert isinstance(internet.hashtags(quantity=1.0), str)
    assert isinstance(internet.hashtags(quantity=1.9), str)
    assert isinstance(internet.hashtags(quantity=1.1), str)
    assert isinstance(internet.hashtags(quantity=1.99), str)

# Generated at 2022-06-17 22:44:10.255187
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    image = internet.stock_image()
    assert image.startswith('https://source.unsplash.com/')

# Generated at 2022-06-17 22:45:11.677898
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    """Test stock_image method of class Internet."""
    internet = Internet()
    assert internet.stock_image() == 'https://source.unsplash.com/1920x1080'

# Generated at 2022-06-17 22:45:13.155403
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    assert internet.stock_image() == 'https://source.unsplash.com/1920x1080'

# Generated at 2022-06-17 22:45:14.982342
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    image = internet.stock_image()
    assert isinstance(image, str)
    assert image.startswith('https://')

# Generated at 2022-06-17 22:45:22.335304
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    assert internet.stock_image() == 'https://source.unsplash.com/1920x1080'
    assert internet.stock_image(width=800, height=600) == 'https://source.unsplash.com/800x600'
    assert internet.stock_image(keywords=['nature', 'mountain']) == 'https://source.unsplash.com/1920x1080?nature,mountain'
    assert internet.stock_image(keywords=['nature', 'mountain'], width=800, height=600) == 'https://source.unsplash.com/800x600?nature,mountain'

# Generated at 2022-06-17 22:45:30.398837
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from mimesis.enums import ImageSize
    from mimesis.providers.internet import Internet
    from mimesis.providers.file import File
    from mimesis.providers.utils import get_mime_type

    internet = Internet()
    file = File()

    image = internet.stock_image(
        width=ImageSize.WIDTH_1920,
        height=ImageSize.HEIGHT_1080,
        keywords=['nature', 'mountains', 'snow'],
        writable=True,
    )

    assert isinstance(image, bytes)
    assert get_mime_type(image) == 'image/jpeg'


# Generated at 2022-06-17 22:45:32.568776
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    image = internet.stock_image()
    assert isinstance(image, str)
    assert image.startswith('https://source.unsplash.com/')

# Generated at 2022-06-17 22:45:36.684815
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    assert internet.stock_image() == 'https://source.unsplash.com/1920x1080'
    assert internet.stock_image(width=800, height=600) == 'https://source.unsplash.com/800x600'
    assert internet.stock_image(keywords=['nature', 'mountains']) == 'https://source.unsplash.com/1920x1080?nature,mountains'
    assert internet.stock_image(keywords=['nature', 'mountains'], width=800, height=600) == 'https://source.unsplash.com/800x600?nature,mountains'

# Generated at 2022-06-17 22:45:38.247497
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    assert internet.stock_image() == 'https://source.unsplash.com/1920x1080'

# Generated at 2022-06-17 22:45:45.083163
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    assert internet.stock_image() == 'https://source.unsplash.com/1920x1080'
    assert internet.stock_image(width=400, height=300) == 'https://source.unsplash.com/400x300'
    assert internet.stock_image(keywords=['nature', 'mountains']) == 'https://source.unsplash.com/1920x1080?nature,mountains'

# Generated at 2022-06-17 22:45:45.954643
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    internet.stock_image()