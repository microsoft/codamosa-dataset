

# Generated at 2022-06-17 22:42:27.268404
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    assert internet.hashtags(quantity=1) == '#love'
    assert internet.hashtags(quantity=2) == ['#love', '#sky']
    assert internet.hashtags(quantity=3) == ['#love', '#sky', '#nice']
    assert internet.hashtags(quantity=4) == ['#love', '#sky', '#nice', '#sun']

# Generated at 2022-06-17 22:42:38.603537
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    assert internet.stock_image() == 'https://source.unsplash.com/1920x1080'
    assert internet.stock_image(width=800, height=600) == 'https://source.unsplash.com/800x600'
    assert internet.stock_image(keywords=['nature', 'mountain']) == 'https://source.unsplash.com/1920x1080?nature,mountain'
    assert internet.stock_image(keywords=['nature', 'mountain'], width=800, height=600) == 'https://source.unsplash.com/800x600?nature,mountain'
    assert internet.stock_image(writable=True) != 'https://source.unsplash.com/1920x1080'

# Generated at 2022-06-17 22:42:40.590528
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    internet.stock_image()

# Generated at 2022-06-17 22:42:42.254695
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    image = internet.stock_image()
    assert image.startswith('https://')

# Generated at 2022-06-17 22:42:47.249369
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    assert internet.hashtags() == '#love'
    assert internet.hashtags(quantity=2) == ['#love', '#sky']
    assert internet.hashtags(quantity=3) == ['#love', '#sky', '#nice']
    assert internet.hashtags(quantity=4) == ['#love', '#sky', '#nice', '#girl']


# Generated at 2022-06-17 22:42:51.388566
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    assert internet.hashtags(quantity=1) == '#love'
    assert internet.hashtags(quantity=2) == ['#love', '#sky']
    assert internet.hashtags(quantity=3) == ['#love', '#sky', '#nice']
    assert internet.hashtags(quantity=4) == ['#love', '#sky', '#nice', '#girl']

# Generated at 2022-06-17 22:42:58.191800
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    """Test for method stock_image of class Internet."""
    internet = Internet()
    url = internet.stock_image()
    assert isinstance(url, str)
    assert url.startswith('https://source.unsplash.com/')
    assert url.endswith('.jpg')

# Generated at 2022-06-17 22:43:03.847673
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from mimesis.enums import ImageSize
    from mimesis.providers.internet import Internet
    internet = Internet()
    image = internet.stock_image(ImageSize.LARGE)
    assert image.startswith('https://source.unsplash.com/')

# Generated at 2022-06-17 22:43:10.253511
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    assert internet.hashtags() == '#love'
    assert internet.hashtags(quantity=1) == '#love'
    assert internet.hashtags(quantity=2) == ['#love', '#sky']
    assert internet.hashtags(quantity=3) == ['#love', '#sky', '#nice']
    assert internet.hashtags(quantity=4) == ['#love', '#sky', '#nice', '#sun']

# Generated at 2022-06-17 22:43:15.724311
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    assert internet.stock_image() == 'https://source.unsplash.com/1920x1080'
    assert internet.stock_image(keywords=['nature']) == 'https://source.unsplash.com/1920x1080?nature'
    assert internet.stock_image(keywords=['nature', 'sky']) == 'https://source.unsplash.com/1920x1080?nature,sky'