

# Generated at 2022-06-17 22:42:45.775733
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    assert isinstance(internet.hashtags(), str)
    assert isinstance(internet.hashtags(quantity=2), list)
    assert len(internet.hashtags(quantity=2)) == 2
    assert len(internet.hashtags(quantity=1)) == 1


# Generated at 2022-06-17 22:42:49.275979
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    assert internet.stock_image() == 'https://source.unsplash.com/1920x1080'
    assert internet.stock_image(width=800, height=600) == 'https://source.unsplash.com/800x600'
    assert internet.stock_image(keywords=['nature', 'animals']) == 'https://source.unsplash.com/1920x1080?nature,animals'
    assert internet.stock_image(keywords=['nature', 'animals'], width=800, height=600) == 'https://source.unsplash.com/800x600?nature,animals'

# Generated at 2022-06-17 22:42:51.904408
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    assert internet.hashtags() == '#love'
    assert internet.hashtags(quantity=3) == ['#love', '#sky', '#nice']

# Generated at 2022-06-17 22:43:05.949106
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    assert internet.hashtags(quantity=1) == '#love'
    assert internet.hashtags(quantity=2) == ['#love', '#sky']
    assert internet.hashtags(quantity=3) == ['#love', '#sky', '#nice']
    assert internet.hashtags(quantity=4) == ['#love', '#sky', '#nice', '#sun']
    assert internet.hashtags(quantity=5) == ['#love', '#sky', '#nice', '#sun', '#sea']
    assert internet.hashtags(quantity=6) == ['#love', '#sky', '#nice', '#sun', '#sea', '#girl']

# Generated at 2022-06-17 22:43:12.161934
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    assert isinstance(internet.hashtags(), str)
    assert isinstance(internet.hashtags(quantity=1), str)
    assert isinstance(internet.hashtags(quantity=2), list)
    assert isinstance(internet.hashtags(quantity=3), list)
    assert isinstance(internet.hashtags(quantity=4), list)
    assert isinstance(internet.hashtags(quantity=5), list)

# Generated at 2022-06-17 22:43:18.460479
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    assert internet.hashtags(quantity=1) == '#love'
    assert internet.hashtags(quantity=2) == ['#love', '#sky']
    assert internet.hashtags(quantity=3) == ['#love', '#sky', '#nice']
    assert internet.hashtags(quantity=4) == ['#love', '#sky', '#nice', '#girl']

# Generated at 2022-06-17 22:43:28.984624
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    assert internet.hashtags() == '#love'
    assert internet.hashtags(quantity=2) == ['#love', '#sky']
    assert internet.hashtags(quantity=3) == ['#love', '#sky', '#nice']
    assert internet.hashtags(quantity=4) == ['#love', '#sky', '#nice', '#sun']
    assert internet.hashtags(quantity=5) == ['#love', '#sky', '#nice', '#sun', '#summer']
    assert internet.hashtags(quantity=6) == ['#love', '#sky', '#nice', '#sun', '#summer', '#beach']

# Generated at 2022-06-17 22:43:36.264092
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    assert internet.hashtags(quantity=1) == '#love'
    assert internet.hashtags(quantity=2) == ['#love', '#sky']
    assert internet.hashtags(quantity=3) == ['#love', '#sky', '#nice']
    assert internet.hashtags(quantity=4) == ['#love', '#sky', '#nice', '#sun']
    assert internet.hashtags(quantity=5) == ['#love', '#sky', '#nice', '#sun', '#sea']
    assert internet.hashtags(quantity=6) == ['#love', '#sky', '#nice', '#sun', '#sea', '#beach']

# Generated at 2022-06-17 22:43:47.666631
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from mimesis.enums import ImageSize
    from mimesis.providers.internet import Internet
    from mimesis.providers.file import File
    from mimesis.providers.image import Image
    from mimesis.providers.misc import Misc
    import os
    import tempfile

    internet = Internet()
    image = Image()
    misc = Misc()
    file = File()

    # Generate random image
    image_size = image.image_size()
    width = image_size.get('width')
    height = image_size.get('height')
    keywords = misc.keywords()
    image_bytes = internet.stock_image(
        width=width, height=height, keywords=keywords, writable=True)

    # Save image to temp file
    temp_dir = tempfile.gettemp

# Generated at 2022-06-17 22:43:50.192127
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    assert internet.stock_image() == 'https://source.unsplash.com/1920x1080'

# Generated at 2022-06-17 22:44:08.800620
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from mimesis.enums import ImageSize
    from mimesis.providers.internet import Internet
    from mimesis.providers.file import File
    from mimesis.providers.image import Image
    from mimesis.providers.misc import Misc
    from mimesis.providers.person import Person
    from mimesis.providers.text import Text
    from mimesis.providers.time import Time
    from mimesis.providers.unit import Unit
    from mimesis.providers.web import Web
    from mimesis.providers.address import Address
    from mimesis.providers.business import Business
    from mimesis.providers.code import Code
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.geo import Geo

# Generated at 2022-06-17 22:44:16.032441
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    assert internet.stock_image() == 'https://source.unsplash.com/1920x1080'
    assert internet.stock_image(width=100, height=100) == 'https://source.unsplash.com/100x100'
    assert internet.stock_image(keywords=['cat', 'dog']) == 'https://source.unsplash.com/1920x1080?cat,dog'
    assert internet.stock_image(keywords=['cat', 'dog'], width=100, height=100) == 'https://source.unsplash.com/100x100?cat,dog'

# Generated at 2022-06-17 22:44:17.402454
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    assert internet.stock_image() == 'https://source.unsplash.com/1920x1080'

# Generated at 2022-06-17 22:44:19.989975
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    url = internet.stock_image()
    assert url == 'https://source.unsplash.com/1920x1080'

# Generated at 2022-06-17 22:44:29.814977
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    assert internet.stock_image() == 'https://source.unsplash.com/1920x1080'
    assert internet.stock_image(width=800, height=600) == 'https://source.unsplash.com/800x600'
    assert internet.stock_image(keywords=['nature', 'water']) == 'https://source.unsplash.com/1920x1080?nature,water'
    assert internet.stock_image(width=800, height=600, keywords=['nature', 'water']) == 'https://source.unsplash.com/800x600?nature,water'

# Generated at 2022-06-17 22:44:31.476207
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    image = internet.stock_image()
    assert isinstance(image, str)
    assert image.startswith('https://')

# Generated at 2022-06-17 22:44:42.255605
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from mimesis.enums import ImageSize
    from mimesis.providers.internet import Internet
    from mimesis.providers.file import File
    from mimesis.exceptions import NonEnumerableError
    import urllib.error
    import urllib.request

    internet = Internet()
    file = File()

    # Test for method stock_image of class Internet
    # Test for correct type of return value
    assert isinstance(internet.stock_image(), str)

    # Test for correct type of return value
    assert isinstance(internet.stock_image(writable=True), bytes)

    # Test for correct type of return value
    assert isinstance(internet.stock_image(keywords=['nature']), str)

    # Test for correct type of return value

# Generated at 2022-06-17 22:44:44.649632
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    stock_image = internet.stock_image()
    assert stock_image == 'https://source.unsplash.com/1920x1080?', stock_image

# Generated at 2022-06-17 22:44:52.421357
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    assert internet.stock_image() == 'https://source.unsplash.com/1920x1080'
    assert internet.stock_image(width=800, height=600) == 'https://source.unsplash.com/800x600'
    assert internet.stock_image(keywords=['nature', 'mountains']) == 'https://source.unsplash.com/1920x1080?nature,mountains'
    assert internet.stock_image(keywords=['nature', 'mountains'], width=800, height=600) == 'https://source.unsplash.com/800x600?nature,mountains'
    assert internet.stock_image(writable=True) != 'https://source.unsplash.com/1920x1080'

# Generated at 2022-06-17 22:44:53.522231
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    assert internet.stock_image() == 'https://source.unsplash.com/1920x1080'

# Generated at 2022-06-17 22:45:05.521430
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    image = internet.stock_image()
    assert image == 'https://source.unsplash.com/1920x1080'

# Generated at 2022-06-17 22:45:16.159877
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from mimesis.enums import ImageSize
    from mimesis.providers.internet import Internet
    from mimesis.providers.file import File
    from mimesis.providers.datetime import Datetime
    import os
    import shutil
    import tempfile

    internet = Internet()
    file = File()
    datetime = Datetime()

    # Create temporary directory
    temp_dir = tempfile.mkdtemp()
    temp_dir_path = os.path.join(temp_dir, 'test')
    os.mkdir(temp_dir_path)

    # Get image
    image = internet.stock_image(width=ImageSize.WIDTH_1920,
                                 height=ImageSize.HEIGHT_1080,
                                 writable=True)

    # Save image

# Generated at 2022-06-17 22:45:21.990189
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    """
    Test for method stock_image of class Internet
    """
    internet = Internet()
    assert internet.stock_image() == 'https://source.unsplash.com/1920x1080'
    assert internet.stock_image(width=800, height=600) == 'https://source.unsplash.com/800x600'
    assert internet.stock_image(keywords=['nature', 'mountain']) == 'https://source.unsplash.com/1920x1080?nature,mountain'

# Generated at 2022-06-17 22:45:29.780067
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    assert internet.stock_image() == 'https://source.unsplash.com/1920x1080'
    assert internet.stock_image(width=800, height=600) == 'https://source.unsplash.com/800x600'
    assert internet.stock_image(keywords=['nature', 'mountains']) == 'https://source.unsplash.com/1920x1080?nature,mountains'
    assert internet.stock_image(width=800, height=600, keywords=['nature', 'mountains']) == 'https://source.unsplash.com/800x600?nature,mountains'

# Generated at 2022-06-17 22:45:40.007313
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from mimesis.enums import ImageSize
    from mimesis.providers.internet import Internet
    from mimesis.providers.file import File
    from mimesis.enums import ImageFormat
    from mimesis.enums import ImageSize
    from mimesis.enums import ImageColor
    from mimesis.enums import ImageCategory
    from mimesis.enums import ImageType
    from mimesis.enums import ImageEffect
    from mimesis.enums import ImageOrientation
    from mimesis.enums import ImageResolution
    from mimesis.enums import ImageRatio
    from mimesis.enums import ImageFilter
    from mimesis.enums import ImageBackground
    from mimesis.enums import ImageText
    from mimesis.enums import ImageTextStyle


# Generated at 2022-06-17 22:45:40.666807
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    print(internet.stock_image())


# Generated at 2022-06-17 22:45:43.459070
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from mimesis.enums import ImageFormat
    from mimesis.providers.internet import Internet
    internet = Internet()
    image = internet.stock_image(
        width=1920,
        height=1080,
        keywords=['nature', 'mountains'],
        writable=True,
    )
    assert isinstance(image, bytes)
    assert internet.__file.mime_type(
        type_=MimeType.IMAGE,
        format_=ImageFormat.JPEG,
    ) in str(image)

# Generated at 2022-06-17 22:45:48.235456
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    assert internet.stock_image() == 'https://source.unsplash.com/1920x1080'
    assert internet.stock_image(width=800, height=600) == 'https://source.unsplash.com/800x600'
    assert internet.stock_image(keywords=['nature', 'mountain']) == 'https://source.unsplash.com/1920x1080?nature,mountain'

# Generated at 2022-06-17 22:45:55.752331
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    assert internet.stock_image(width=1920, height=1080) == 'https://source.unsplash.com/1920x1080?'
    assert internet.stock_image(width=1920, height=1080, keywords=['nature', 'mountain']) == 'https://source.unsplash.com/1920x1080?nature,mountain'

# Generated at 2022-06-17 22:46:08.844168
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from mimesis.enums import PortRange
    from mimesis.providers.internet import Internet
    from mimesis.providers.file import File
    from mimesis.providers.network import Network
    from mimesis.providers.web import Web
    from mimesis.providers.text import Text
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.business import Business
    from mimesis.providers.payment import Payment
    from mimesis.providers.science import Science
    from mimesis.providers.misc import Misc
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.structures import Structures
