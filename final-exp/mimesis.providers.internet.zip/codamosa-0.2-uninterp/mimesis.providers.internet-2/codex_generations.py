

# Generated at 2022-06-17 22:42:33.867110
# Unit test for method port of class Internet
def test_Internet_port():
    """Unit test for method port of class Internet."""
    internet = Internet()
    port = internet.port(port_range=PortRange.WELL_KNOWN)
    assert port in range(0, 1024)

    port = internet.port(port_range=PortRange.REGISTERED)
    assert port in range(1024, 49151)

    port = internet.port(port_range=PortRange.DYNAMIC)
    assert port in range(49152, 65535)

# Generated at 2022-06-17 22:42:42.835383
# Unit test for method port of class Internet
def test_Internet_port():
    from mimesis.enums import PortRange
    from mimesis.providers.internet import Internet
    from mimesis.exceptions import NonEnumerableError

    internet = Internet()
    port = internet.port(port_range=PortRange.ALL)
    assert port >= 0 and port <= 65535

    port = internet.port(port_range=PortRange.WELL_KNOWN)
    assert port >= 0 and port <= 1023

    port = internet.port(port_range=PortRange.REGISTERED)
    assert port >= 1024 and port <= 49151

    port = internet.port(port_range=PortRange.DYNAMIC)
    assert port >= 49152 and port <= 65535

    try:
        internet.port(port_range=PortRange.ALL.value)
    except NonEnumerableError:
        pass
   

# Generated at 2022-06-17 22:42:51.327000
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    assert internet.hashtags(quantity=1) == '#love'
    assert internet.hashtags(quantity=2) == ['#love', '#sky']
    assert internet.hashtags(quantity=3) == ['#love', '#sky', '#nice']
    assert internet.hashtags(quantity=4) == ['#love', '#sky', '#nice', '#sun']
    assert internet.hashtags(quantity=5) == ['#love', '#sky', '#nice', '#sun', '#summer']
    assert internet.hashtags(quantity=6) == ['#love', '#sky', '#nice', '#sun', '#summer', '#sea']

# Generated at 2022-06-17 22:42:56.871266
# Unit test for method port of class Internet
def test_Internet_port():
    from mimesis.enums import PortRange
    from mimesis.providers.internet import Internet
    internet = Internet()
    port = internet.port(port_range=PortRange.ALL)
    assert port >= 0 and port <= 65535

# Generated at 2022-06-17 22:43:00.300853
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    image = internet.stock_image()
    assert image == 'https://source.unsplash.com/1920x1080?'

# Generated at 2022-06-17 22:43:08.737173
# Unit test for method port of class Internet
def test_Internet_port():
    internet = Internet()
    port = internet.port(port_range=PortRange.ALL)
    assert isinstance(port, int)
    assert port >= 0
    assert port <= 65535

    port = internet.port(port_range=PortRange.WELL_KNOWN)
    assert isinstance(port, int)
    assert port >= 0
    assert port <= 1023

    port = internet.port(port_range=PortRange.REGISTERED)
    assert isinstance(port, int)
    assert port >= 1024
    assert port <= 49151

    port = internet.port(port_range=PortRange.DYNAMIC)
    assert isinstance(port, int)
    assert port >= 49152
    assert port <= 65535

    port = internet.port(port_range=PortRange.PRIVATE)

# Generated at 2022-06-17 22:43:14.831155
# Unit test for method port of class Internet
def test_Internet_port():
    internet = Internet()
    port = internet.port(port_range=PortRange.ALL)
    assert port >= 0 and port <= 65535
    port = internet.port(port_range=PortRange.WELL_KNOWN)
    assert port >= 0 and port <= 1023
    port = internet.port(port_range=PortRange.REGISTERED)
    assert port >= 1024 and port <= 49151
    port = internet.port(port_range=PortRange.DYNAMIC)
    assert port >= 49152 and port <= 65535

# Generated at 2022-06-17 22:43:18.073693
# Unit test for method port of class Internet
def test_Internet_port():
    internet = Internet()
    port = internet.port(port_range=PortRange.ALL)
    assert port >= 0 and port <= 65535

# Generated at 2022-06-17 22:43:28.729597
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from mimesis.enums import ImageSize
    from mimesis.providers.internet import Internet
    from mimesis.providers.file import File
    from mimesis.providers.image import Image
    from mimesis.providers.misc import Misc
    from mimesis.providers.text import Text
    from mimesis.providers.web import Web
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.business import Business
    from mimesis.providers.code import Code
    from mimesis.providers.date import DateTime
    from mimesis.providers.payment import Payment
    from mimesis.providers.science import Science
    from mimesis.providers.numbers import Numbers

# Generated at 2022-06-17 22:43:35.239200
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from mimesis.enums import ImageSize
    from mimesis.providers.internet import Internet
    from mimesis.providers.file import File
    from mimesis.providers.utils import get_mime_type
    from mimesis.exceptions import NonEnumerableError

    internet = Internet()
    file = File()
    mime_type = get_mime_type(file.mime_type())

    # Test for correct work
    assert isinstance(internet.stock_image(), str)
    assert isinstance(internet.stock_image(writable=True), bytes)
    assert isinstance(internet.stock_image(keywords=['nature', 'mountain']), str)
    assert isinstance(internet.stock_image(keywords=['nature', 'mountain'], writable=True), bytes)
   

# Generated at 2022-06-17 22:45:42.318536
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from mimesis.enums import ImageSize
    from mimesis.providers.internet import Internet
    from mimesis.providers.file import File
    from mimesis.providers.image import Image
    from mimesis.providers.misc import Misc
    from mimesis.providers.person import Person
    from mimesis.providers.text import Text
    from mimesis.providers.web import Web
    from mimesis.providers.business import Business
    from mimesis.providers.code import Code
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.geo import Geo
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.science import Science
    from mimesis.providers.structures import Structures

# Generated at 2022-06-17 22:45:46.063165
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    """Test method stock_image of class Internet."""
    internet = Internet()
    image = internet.stock_image(width=1920, height=1080)
    assert image.startswith('https://source.unsplash.com/')

# Generated at 2022-06-17 22:45:48.093299
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    """Test method stock_image of class Internet."""
    internet = Internet()
    assert internet.stock_image() == 'https://source.unsplash.com/1920x1080'

# Generated at 2022-06-17 22:45:53.549105
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    assert internet.stock_image() == 'https://source.unsplash.com/1920x1080'
    assert internet.stock_image(width=800, height=600) == 'https://source.unsplash.com/800x600'
    assert internet.stock_image(keywords=['nature', 'mountain']) == 'https://source.unsplash.com/1920x1080?nature,mountain'

# Generated at 2022-06-17 22:45:58.432061
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    """Unit test for method stock_image of class Internet."""
    internet = Internet()
    image = internet.stock_image()
    assert image == 'https://source.unsplash.com/1920x1080'

# Generated at 2022-06-17 22:46:05.907120
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    print(internet.stock_image())
    print(internet.stock_image(keywords=['cat', 'dog']))
    print(internet.stock_image(keywords=['cat', 'dog'], writable=True))

if __name__ == '__main__':
    test_Internet_stock_image()

# Generated at 2022-06-17 22:46:14.914799
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    assert internet.stock_image() == 'https://source.unsplash.com/1920x1080'
    assert internet.stock_image(keywords=['nature']) == 'https://source.unsplash.com/1920x1080?nature'
    assert internet.stock_image(keywords=['nature', 'sky']) == 'https://source.unsplash.com/1920x1080?nature,sky'
    assert internet.stock_image(width=800, height=600) == 'https://source.unsplash.com/800x600'
    assert internet.stock_image(width=800, height=600, keywords=['nature']) == 'https://source.unsplash.com/800x600?nature'

# Generated at 2022-06-17 22:46:24.708759
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from mimesis.enums import PortRange
    from mimesis.providers.internet import Internet
    from mimesis.providers.file import File
    from mimesis.providers.network import Network
    from mimesis.providers.system import System
    from mimesis.providers.text import Text
    from mimesis.providers.unit import Unit
    from mimesis.providers.utils import Utils
    from mimesis.providers.web import Web
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.geo import Geo
    from mimesis.providers.person import Person
    from mimesis.providers.payment import Payment
    from mimesis.providers.science import Science
    from mimesis.providers.business import Business
   

# Generated at 2022-06-17 22:46:30.379026
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    assert internet.stock_image() == 'https://source.unsplash.com/1920x1080'
    assert internet.stock_image(width=200, height=200) == 'https://source.unsplash.com/200x200'
    assert internet.stock_image(keywords=['cat', 'dog']) == 'https://source.unsplash.com/1920x1080?cat,dog'
    assert internet.stock_image(keywords=['cat', 'dog'], width=200, height=200) == 'https://source.unsplash.com/200x200?cat,dog'

# Generated at 2022-06-17 22:46:39.996983
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    assert internet.stock_image() == 'https://source.unsplash.com/1920x1080'
    assert internet.stock_image(width=400, height=300) == 'https://source.unsplash.com/400x300'
    assert internet.stock_image(keywords=['nature', 'mountain']) == 'https://source.unsplash.com/1920x1080?nature,mountain'
    assert internet.stock_image(keywords=['nature', 'mountain'], width=400, height=300) == 'https://source.unsplash.com/400x300?nature,mountain'
