

# Generated at 2022-06-17 22:42:32.186391
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    """Unit test for method stock_image of class Internet."""
    from mimesis.enums import TLDType
    from mimesis.providers.internet import Internet
    from mimesis.providers.file import File
    from mimesis.providers.network import Network
    from mimesis.providers.person import Person
    from mimesis.providers.text import Text
    from mimesis.providers.misc import Misc
    from mimesis.providers.address import Address
    from mimesis.providers.code import Code
    from mimesis.providers.business import Business
    from mimesis.providers.date import DateTime
    from mimesis.providers.payment import Payment
    from mimesis.providers.science import Science
    from mimesis.providers.unit import Unit
   

# Generated at 2022-06-17 22:42:35.601635
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    """Test for method stock_image of class Internet."""
    internet = Internet()
    image = internet.stock_image()
    assert isinstance(image, str)

# Generated at 2022-06-17 22:42:44.128678
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from mimesis.enums import ImageSize
    from mimesis.providers.internet import Internet
    from mimesis.providers.file import File
    from mimesis.providers.utils import get_mime_type
    from mimesis.exceptions import NonEnumerableError

    internet = Internet()
    file = File()

    # Test for default values
    url = internet.stock_image()
    assert url.startswith('https://source.unsplash.com/1920x1080')

    # Test for custom values
    url = internet.stock_image(width=ImageSize.SMALL.value,
                               height=ImageSize.SMALL.value)
    assert url.startswith('https://source.unsplash.com/400x300')

    # Test for keywords
    url = internet.stock_image

# Generated at 2022-06-17 22:42:46.178628
# Unit test for method port of class Internet
def test_Internet_port():
    internet = Internet()
    port = internet.port(port_range=PortRange.WELL_KNOWN)
    assert port in range(0, 1024)

# Generated at 2022-06-17 22:42:48.038354
# Unit test for method port of class Internet
def test_Internet_port():
    internet = Internet()
    port = internet.port(port_range=PortRange.WELL_KNOWN)
    assert port >= 0 and port <= 1023

# Generated at 2022-06-17 22:42:49.525727
# Unit test for method port of class Internet
def test_Internet_port():
    internet = Internet()
    port = internet.port()
    assert port >= 0 and port <= 65535

# Generated at 2022-06-17 22:42:50.538598
# Unit test for method port of class Internet
def test_Internet_port():
    internet = Internet()
    port = internet.port(port_range=PortRange.PRIVATE)
    assert port in range(49152, 65535)

# Generated at 2022-06-17 22:42:53.086051
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    assert isinstance(internet.hashtags(), str)
    assert isinstance(internet.hashtags(quantity=2), list)
    assert len(internet.hashtags(quantity=2)) == 2


# Generated at 2022-06-17 22:42:57.775138
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    assert isinstance(internet.hashtags(), str)
    assert isinstance(internet.hashtags(quantity=2), list)
    assert isinstance(internet.hashtags(quantity=1), str)

# Generated at 2022-06-17 22:43:00.887010
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    assert isinstance(internet.hashtags(), str)
    assert isinstance(internet.hashtags(quantity=2), list)
    assert isinstance(internet.hashtags(quantity=1), str)
    assert isinstance(internet.hashtags(quantity=0), list)
    assert isinstance(internet.hashtags(quantity=4), list)
