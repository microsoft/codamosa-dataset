

# Generated at 2022-06-17 22:42:47.883094
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from mimesis.enums import ImageSize
    from mimesis.providers.internet import Internet
    from mimesis.providers.file import File
    from mimesis.providers.utils import get_mime_type
    from mimesis.exceptions import NonEnumerableError

    internet = Internet()
    file = File()

    # Test for correct work
    image_url = internet.stock_image(
        width=ImageSize.SMALL.value,
        height=ImageSize.SMALL.value,
        keywords=['nature', 'mountains'],
    )
    assert image_url.startswith('https://source.unsplash.com/')

    # Test for correct work

# Generated at 2022-06-17 22:42:49.407351
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    image = internet.stock_image()
    assert isinstance(image, str)

# Generated at 2022-06-17 22:42:51.363364
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    assert internet.stock_image() == 'https://source.unsplash.com/1920x1080'

# Generated at 2022-06-17 22:42:58.559926
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from mimesis.enums import ImageSize
    from mimesis.providers.internet import Internet
    from mimesis.providers.file import File
    from mimesis.providers.image import Image
    from mimesis.providers.misc import Misc
    import os
    import tempfile

    # Create temporary directory
    temp_dir = tempfile.TemporaryDirectory()
    # Create temporary file
    temp_file = tempfile.NamedTemporaryFile(dir=temp_dir.name)
    # Create providers
    internet = Internet()
    file = File()
    image = Image()
    misc = Misc()

    # Generate random image
    image_bytes = internet.stock_image(writable=True)
    # Generate random image size

# Generated at 2022-06-17 22:43:10.748737
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    from mimesis.enums import Hashtag
    from mimesis.providers.internet import Internet
    internet = Internet()
    assert internet.hashtags(quantity=1) == '#love'
    assert internet.hashtags(quantity=2) == ['#love', '#sky']
    assert internet.hashtags(quantity=3) == ['#love', '#sky', '#nice']
    assert internet.hashtags(quantity=4) == ['#love', '#sky', '#nice', '#sun']
    assert internet.hashtags(quantity=5) == ['#love', '#sky', '#nice', '#sun', '#summer']

# Generated at 2022-06-17 22:43:13.382008
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    assert internet.hashtags(quantity=1) == '#love'
    assert internet.hashtags() == ['#love', '#sky', '#nice', '#beautiful']


# Generated at 2022-06-17 22:43:25.100957
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    assert internet.hashtags(quantity=1) == '#love'
    assert internet.hashtags(quantity=2) == ['#love', '#sky']
    assert internet.hashtags(quantity=3) == ['#love', '#sky', '#nice']
    assert internet.hashtags(quantity=4) == ['#love', '#sky', '#nice', '#sun']
    assert internet.hashtags(quantity=5) == ['#love', '#sky', '#nice', '#sun', '#sea']
    assert internet.hashtags(quantity=6) == ['#love', '#sky', '#nice', '#sun', '#sea', '#mountain']

# Generated at 2022-06-17 22:43:27.202920
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    image = internet.stock_image()
    assert isinstance(image, str)
    assert image.startswith('https://')

# Generated at 2022-06-17 22:43:35.059124
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    assert internet.hashtags(quantity=1) == '#love'
    assert internet.hashtags(quantity=2) == ['#love', '#sky']
    assert internet.hashtags(quantity=3) == ['#love', '#sky', '#nice']
    assert internet.hashtags(quantity=4) == ['#love', '#sky', '#nice', '#girl']
    assert internet.hashtags(quantity=5) == ['#love', '#sky', '#nice', '#girl', '#boy']
    assert internet.hashtags(quantity=6) == ['#love', '#sky', '#nice', '#girl', '#boy', '#summer']

# Generated at 2022-06-17 22:43:47.104135
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    assert internet.stock_image() == 'https://source.unsplash.com/1920x1080'
    assert internet.stock_image(width=800, height=600) == 'https://source.unsplash.com/800x600'
    assert internet.stock_image(keywords=['nature', 'mountain']) == 'https://source.unsplash.com/1920x1080?nature,mountain'
    assert internet.stock_image(keywords=['nature', 'mountain'], width=800, height=600) == 'https://source.unsplash.com/800x600?nature,mountain'

# Generated at 2022-06-17 22:44:10.867413
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    assert internet.stock_image() == 'https://source.unsplash.com/1920x1080'
    assert internet.stock_image(keywords=['nature']) == 'https://source.unsplash.com/1920x1080?nature'
    assert internet.stock_image(keywords=['nature', 'water']) == 'https://source.unsplash.com/1920x1080?nature,water'
    assert internet.stock_image(keywords=['nature', 'water'], width=800, height=600) == 'https://source.unsplash.com/800x600?nature,water'
    assert internet.stock_image(keywords=['nature', 'water'], width=800, height=600, writable=True)

# Generated at 2022-06-17 22:44:13.726346
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    """Test for method stock_image of class Internet."""
    internet = Internet()
    assert internet.stock_image() == 'https://source.unsplash.com/1920x1080'

# Generated at 2022-06-17 22:44:21.858368
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from mimesis.enums import ImageSize
    from mimesis.providers.internet import Internet
    internet = Internet()
    assert internet.stock_image(ImageSize.SMALL) == 'https://source.unsplash.com/400x300?'
    assert internet.stock_image(ImageSize.MEDIUM) == 'https://source.unsplash.com/640x480?'
    assert internet.stock_image(ImageSize.LARGE) == 'https://source.unsplash.com/1024x768?'
    assert internet.stock_image(ImageSize.XLARGE) == 'https://source.unsplash.com/1600x1200?'
    assert internet.stock_image(ImageSize.XXLARGE) == 'https://source.unsplash.com/2048x1536?'
    assert internet.stock_image

# Generated at 2022-06-17 22:44:26.758960
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    """Unit test for method stock_image of class Internet."""
    internet = Internet()
    image = internet.stock_image()
    assert isinstance(image, str)
    assert image.startswith('https://source.unsplash.com/')

# Generated at 2022-06-17 22:44:30.908827
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    print(internet.stock_image())
    print(internet.stock_image(keywords=['cat', 'dog']))
    print(internet.stock_image(writable=True))
    print(internet.stock_image(keywords=['cat', 'dog'], writable=True))

# Generated at 2022-06-17 22:44:34.462798
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    """Unit test for method stock_image of class Internet."""
    from mimesis.providers.internet import Internet
    internet = Internet()
    assert internet.stock_image() == 'https://source.unsplash.com/1920x1080'

# Generated at 2022-06-17 22:44:36.897990
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    """Test for method stock_image of class Internet."""
    internet = Internet()
    assert internet.stock_image() == 'https://source.unsplash.com/1920x1080'

# Generated at 2022-06-17 22:44:39.606715
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    image = internet.stock_image(writable=True)
    assert isinstance(image, bytes)

# Generated at 2022-06-17 22:44:41.430409
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    img = internet.stock_image()
    assert img.startswith('https://source.unsplash.com/')

# Generated at 2022-06-17 22:44:43.477090
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    image = internet.stock_image()
    assert image.startswith('https://source.unsplash.com/')

# Generated at 2022-06-17 22:45:17.320287
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    image = internet.stock_image()
    assert isinstance(image, str)
    assert image.startswith('https://source.unsplash.com/')

# Generated at 2022-06-17 22:45:18.383696
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    image = internet.stock_image()
    assert image is not None

# Generated at 2022-06-17 22:45:25.441741
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from mimesis.enums import ImageSize
    from mimesis.providers.internet import Internet
    internet = Internet()
    assert internet.stock_image(ImageSize.SMALL) == 'https://source.unsplash.com/400x300'
    assert internet.stock_image(ImageSize.MEDIUM) == 'https://source.unsplash.com/800x600'
    assert internet.stock_image(ImageSize.LARGE) == 'https://source.unsplash.com/1600x1200'
    assert internet.stock_image(ImageSize.XLARGE) == 'https://source.unsplash.com/2400x1800'
    assert internet.stock_image(ImageSize.FULL) == 'https://source.unsplash.com/3200x2400'

# Generated at 2022-06-17 22:45:32.597475
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    assert internet.stock_image() == 'https://source.unsplash.com/1920x1080'

# Generated at 2022-06-17 22:45:35.366354
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    image = internet.stock_image()
    assert isinstance(image, str)
    assert image.startswith('https://')

# Generated at 2022-06-17 22:45:45.668387
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    """Unit test for method stock_image of class Internet."""
    from mimesis.enums import Layer
    from mimesis.providers.internet import Internet
    from mimesis.providers.file import File
    from mimesis.providers.network import Network
    from mimesis.providers.text import Text
    from mimesis.providers.utils import Provider

    class TestInternet(Internet):
        """Class for testing Internet."""

        def __init__(self, *args, **kwargs):
            """Initialize attributes."""
            super().__init__(*args, **kwargs)
            self.__file = File(seed=self.seed)
            self.__network = Network(seed=self.seed)
            self.__text = Text(seed=self.seed)


# Generated at 2022-06-17 22:45:54.010774
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    assert internet.stock_image() == 'https://source.unsplash.com/1920x1080'
    assert internet.stock_image(keywords=['nature']) == 'https://source.unsplash.com/1920x1080?nature'
    assert internet.stock_image(keywords=['nature', 'water']) == 'https://source.unsplash.com/1920x1080?nature,water'
    assert internet.stock_image(keywords=['nature', 'water'], width=800, height=600) == 'https://source.unsplash.com/800x600?nature,water'

# Generated at 2022-06-17 22:45:58.610861
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    image = internet.stock_image()
    assert isinstance(image, str)
    assert image.startswith('https://')
    assert image.endswith('.jpg')

# Generated at 2022-06-17 22:46:09.841304
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    """Test method stock_image of class Internet."""
    internet = Internet()
    assert internet.stock_image() == 'https://source.unsplash.com/1920x1080'
    assert internet.stock_image(keywords=['nature']) == 'https://source.unsplash.com/1920x1080?nature'
    assert internet.stock_image(keywords=['nature', 'water']) == 'https://source.unsplash.com/1920x1080?nature,water'
    assert internet.stock_image(keywords=['nature', 'water'], width=800, height=600) == 'https://source.unsplash.com/800x600?nature,water'

# Generated at 2022-06-17 22:46:10.914831
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    assert internet.stock_image() == 'https://source.unsplash.com/1920x1080'