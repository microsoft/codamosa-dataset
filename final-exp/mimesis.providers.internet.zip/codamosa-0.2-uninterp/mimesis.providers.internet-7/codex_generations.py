

# Generated at 2022-06-17 22:42:33.811906
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    image = internet.stock_image()
    assert isinstance(image, str)
    assert image.startswith('https://')

# Generated at 2022-06-17 22:42:41.072547
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    assert internet.stock_image() == 'https://source.unsplash.com/1920x1080'
    assert internet.stock_image(width=800, height=600) == 'https://source.unsplash.com/800x600'
    assert internet.stock_image(keywords=['nature', 'water']) == 'https://source.unsplash.com/1920x1080?nature,water'
    assert internet.stock_image(keywords=['nature', 'water'], width=800, height=600) == 'https://source.unsplash.com/800x600?nature,water'

# Generated at 2022-06-17 22:42:42.388447
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    print(internet.stock_image())


# Generated at 2022-06-17 22:42:51.041210
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    assert internet.stock_image() == 'https://source.unsplash.com/1920x1080'
    assert internet.stock_image(keywords=['nature', 'mountain']) == 'https://source.unsplash.com/1920x1080?nature,mountain'
    assert internet.stock_image(width=500, height=500) == 'https://source.unsplash.com/500x500'
    assert internet.stock_image(width=500, height=500, keywords=['nature', 'mountain']) == 'https://source.unsplash.com/500x500?nature,mountain'
    assert internet.stock_image(writable=True) != 'https://source.unsplash.com/1920x1080'

# Generated at 2022-06-17 22:43:00.300205
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    assert internet.stock_image() == 'https://source.unsplash.com/1920x1080'
    assert internet.stock_image(width=800, height=600) == 'https://source.unsplash.com/800x600'
    assert internet.stock_image(keywords=['nature', 'mountains']) == 'https://source.unsplash.com/1920x1080?nature,mountains'

# Generated at 2022-06-17 22:43:03.215280
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    assert internet.stock_image() == 'https://source.unsplash.com/1920x1080'

# Generated at 2022-06-17 22:43:07.762915
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from mimesis.enums import ImageSize
    from mimesis.providers.internet import Internet
    from PIL import Image

    internet = Internet()
    image = internet.stock_image(ImageSize.LARGE.value)
    assert isinstance(image, bytes)
    assert Image.open(image)

# Generated at 2022-06-17 22:43:18.513725
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    assert internet.stock_image() == 'https://source.unsplash.com/1920x1080'
    assert internet.stock_image(keywords=['nature']) == 'https://source.unsplash.com/1920x1080?nature'
    assert internet.stock_image(keywords=['nature', 'mountains']) == 'https://source.unsplash.com/1920x1080?nature,mountains'
    assert internet.stock_image(width=500, height=500) == 'https://source.unsplash.com/500x500'
    assert internet.stock_image(width=500, height=500, keywords=['nature']) == 'https://source.unsplash.com/500x500?nature'

# Generated at 2022-06-17 22:43:26.508195
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    assert internet.stock_image() == 'https://source.unsplash.com/1920x1080'
    assert internet.stock_image(width=800, height=600) == 'https://source.unsplash.com/800x600'
    assert internet.stock_image(keywords=['nature', 'mountain']) == 'https://source.unsplash.com/1920x1080?nature,mountain'
    assert internet.stock_image(keywords=['nature', 'mountain'], width=800, height=600) == 'https://source.unsplash.com/800x600?nature,mountain'

# Generated at 2022-06-17 22:43:34.534354
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from mimesis.enums import PortRange
    from mimesis.providers.internet import Internet
    from mimesis.providers.file import File
    from mimesis.providers.network import Network
    from mimesis.providers.text import Text
    from mimesis.providers.utils import Provider
    from mimesis.providers.web import Web
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.code import Code
    from mimesis.providers.business import Business
    from mimesis.providers.payment import Payment
    from mimesis.providers.science import Science
    from mimesis.providers.numbers import Numbers

# Generated at 2022-06-17 22:44:04.736862
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    from mimesis.enums import Hashtag
    from mimesis.providers.internet import Internet
    internet = Internet()
    assert internet.hashtags(quantity=1) in Hashtag.ALL.value
    assert internet.hashtags(quantity=2) in Hashtag.ALL.value
    assert internet.hashtags(quantity=3) in Hashtag.ALL.value
    assert internet.hashtags(quantity=4) in Hashtag.ALL.value
    assert internet.hashtags(quantity=5) in Hashtag.ALL.value
    assert internet.hashtags(quantity=6) in Hashtag.ALL.value
    assert internet.hashtags(quantity=7) in Hashtag.ALL.value
    assert internet.hashtags(quantity=8) in Hashtag.ALL.value

# Generated at 2022-06-17 22:44:08.511075
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    assert internet.hashtags() == '#love'
    assert internet.hashtags(1) == '#love'
    assert internet.hashtags(2) == ['#love', '#sky']
    assert internet.hashtags(3) == ['#love', '#sky', '#nice']

# Generated at 2022-06-17 22:44:15.618633
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    assert internet.hashtags(quantity=1) == '#love'
    assert internet.hashtags(quantity=2) == ['#love', '#sky']
    assert internet.hashtags(quantity=3) == ['#love', '#sky', '#nice']
    assert internet.hashtags(quantity=4) == ['#love', '#sky', '#nice', '#happy']
    assert internet.hashtags(quantity=5) == ['#love', '#sky', '#nice', '#happy', '#beautiful']
    assert internet.hashtags(quantity=6) == ['#love', '#sky', '#nice', '#happy', '#beautiful', '#cute']

# Generated at 2022-06-17 22:44:21.016972
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from mimesis.enums import ImageSize
    from mimesis.providers.internet import Internet
    from mimesis.providers.file import File
    from mimesis.providers.file import ImageSize as ImageSize_
    from mimesis.providers.file import ImageFormat as ImageFormat_
    from mimesis.providers.file import ImageColor as ImageColor_
    from mimesis.providers.file import ImageCategory as ImageCategory_
    from mimesis.providers.file import ImageText as ImageText_
    from mimesis.providers.file import ImageFont as ImageFont_
    from mimesis.providers.file import ImageTextStyle as ImageTextStyle_
    from mimesis.providers.file import ImageTextAlignment as ImageTextAlignment_

# Generated at 2022-06-17 22:44:31.944061
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    assert internet.hashtags(quantity=1) == '#love'
    assert internet.hashtags(quantity=2) == ['#love', '#sky']
    assert internet.hashtags(quantity=3) == ['#love', '#sky', '#nice']
    assert internet.hashtags(quantity=4) == ['#love', '#sky', '#nice', '#sun']
    assert internet.hashtags(quantity=5) == ['#love', '#sky', '#nice', '#sun', '#day']
    assert internet.hashtags(quantity=6) == ['#love', '#sky', '#nice', '#sun', '#day', '#summer']

# Generated at 2022-06-17 22:44:42.796589
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    assert isinstance(internet.hashtags(), str)
    assert isinstance(internet.hashtags(quantity=1), str)
    assert isinstance(internet.hashtags(quantity=2), list)
    assert isinstance(internet.hashtags(quantity=3), list)
    assert isinstance(internet.hashtags(quantity=4), list)
    assert isinstance(internet.hashtags(quantity=5), list)
    assert isinstance(internet.hashtags(quantity=6), list)
    assert isinstance(internet.hashtags(quantity=7), list)
    assert isinstance(internet.hashtags(quantity=8), list)
    assert isinstance(internet.hashtags(quantity=9), list)
    assert isinstance(internet.hashtags(quantity=10), list)


# Generated at 2022-06-17 22:44:47.642315
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    assert internet.hashtags(quantity=1) == '#love'
    assert internet.hashtags(quantity=2) == ['#love', '#sky']
    assert internet.hashtags(quantity=3) == ['#love', '#sky', '#nice']
    assert internet.hashtags(quantity=4) == ['#love', '#sky', '#nice', '#sun']

# Generated at 2022-06-17 22:44:54.662381
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    from mimesis.enums import Hashtag
    from mimesis.providers.internet import Internet
    from mimesis.typing import HashtagCategory

    internet = Internet()
    assert isinstance(internet.hashtags(), str)
    assert isinstance(internet.hashtags(quantity=1), str)
    assert isinstance(internet.hashtags(quantity=2), list)
    assert isinstance(internet.hashtags(quantity=2)[0], str)
    assert isinstance(internet.hashtags(quantity=2)[1], str)
    assert isinstance(internet.hashtags(quantity=2, category=HashtagCategory.ANIMALS), list)
    assert isinstance(internet.hashtags(quantity=2, category=HashtagCategory.ANIMALS)[0], str)

# Generated at 2022-06-17 22:44:58.398649
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    """Test for method stock_image of class Internet."""
    internet = Internet()
    assert internet.stock_image() == 'https://source.unsplash.com/1920x1080'

# Generated at 2022-06-17 22:45:02.537990
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    image = internet.stock_image()
    assert isinstance(image, str)
    assert image.startswith('https://source.unsplash.com/')