

# Generated at 2022-06-17 22:42:35.793019
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    assert isinstance(internet.hashtags(), str)
    assert isinstance(internet.hashtags(quantity=1), str)
    assert isinstance(internet.hashtags(quantity=2), list)
    assert isinstance(internet.hashtags(quantity=3), list)
    assert isinstance(internet.hashtags(quantity=4), list)
    assert isinstance(internet.hashtags(quantity=5), list)
    assert isinstance(internet.hashtags(quantity=6), list)
    assert isinstance(internet.hashtags(quantity=7), list)
    assert isinstance(internet.hashtags(quantity=8), list)
    assert isinstance(internet.hashtags(quantity=9), list)
    assert isinstance(internet.hashtags(quantity=10), list)


# Generated at 2022-06-17 22:42:42.969797
# Unit test for method port of class Internet
def test_Internet_port():
    internet = Internet()
    port = internet.port(port_range=PortRange.ALL)
    assert port >= 0 and port <= 65535
    port = internet.port(port_range=PortRange.WELL_KNOWN)
    assert port >= 0 and port <= 1023
    port = internet.port(port_range=PortRange.REGISTERED)
    assert port >= 1024 and port <= 49151
    port = internet.port(port_range=PortRange.DYNAMIC)
    assert port >= 49152 and port <= 65535
    port = internet.port(port_range=PortRange.EPHEMERAL)
    assert port >= 49152 and port <= 65535


# Generated at 2022-06-17 22:42:51.418619
# Unit test for method port of class Internet
def test_Internet_port():
    internet = Internet()
    port = internet.port(port_range=PortRange.ALL)
    assert port >= 0 and port <= 65535
    port = internet.port(port_range=PortRange.PRIVATE)
    assert port >= 49152 and port <= 65535
    port = internet.port(port_range=PortRange.PRIVATE_DYNAMIC)
    assert port >= 49152 and port <= 65535
    port = internet.port(port_range=PortRange.PRIVATE_STATIC)
    assert port >= 49152 and port <= 65535
    port = internet.port(port_range=PortRange.PUBLIC)
    assert port >= 0 and port <= 49151
    port = internet.port(port_range=PortRange.PUBLIC_DYNAMIC)
    assert port >= 0 and port <= 49151
   

# Generated at 2022-06-17 22:42:56.946464
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from mimesis.providers.internet import Internet
    from mimesis.enums import ImageSize

    internet = Internet()
    image = internet.stock_image(ImageSize.SMALL)
    assert isinstance(image, str)

# Generated at 2022-06-17 22:43:03.173564
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    assert internet.hashtags() == '#love'
    assert internet.hashtags(quantity=2) == ['#love', '#sky']
    assert internet.hashtags(quantity=3) == ['#love', '#sky', '#nice']

# Generated at 2022-06-17 22:43:11.487970
# Unit test for method port of class Internet
def test_Internet_port():
    from mimesis.enums import PortRange
    from mimesis.providers.internet import Internet
    internet = Internet()
    port = internet.port(port_range=PortRange.ALL)
    assert port >= 0 and port <= 65535
    port = internet.port(port_range=PortRange.WELL_KNOWN)
    assert port >= 0 and port <= 1023
    port = internet.port(port_range=PortRange.REGISTERED)
    assert port >= 1024 and port <= 49151
    port = internet.port(port_range=PortRange.DYNAMIC)
    assert port >= 49152 and port <= 65535

# Generated at 2022-06-17 22:43:23.093769
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    assert internet.hashtags(quantity=1) == '#love'
    assert internet.hashtags(quantity=2) == ['#love', '#sky']
    assert internet.hashtags(quantity=3) == ['#love', '#sky', '#nice']
    assert internet.hashtags(quantity=4) == ['#love', '#sky', '#nice', '#sky']
    assert internet.hashtags(quantity=5) == ['#love', '#sky', '#nice', '#sky', '#nice']
    assert internet.hashtags(quantity=6) == ['#love', '#sky', '#nice', '#sky', '#nice', '#love']

# Generated at 2022-06-17 22:43:29.543155
# Unit test for method port of class Internet
def test_Internet_port():
    internet = Internet()
    port = internet.port(port_range=PortRange.ALL)
    assert port >= 0 and port <= 65535
    port = internet.port(port_range=PortRange.WELL_KNOWN)
    assert port >= 0 and port <= 1023
    port = internet.port(port_range=PortRange.REGISTERED)
    assert port >= 1024 and port <= 49151
    port = internet.port(port_range=PortRange.DYNAMIC)
    assert port >= 49152 and port <= 65535

# Generated at 2022-06-17 22:43:35.145065
# Unit test for method port of class Internet
def test_Internet_port():
    from mimesis.enums import PortRange
    from mimesis.providers.internet import Internet
    internet = Internet()
    assert internet.port(port_range=PortRange.ALL) in range(0, 65535)
    assert internet.port(port_range=PortRange.WELL_KNOWN) in range(0, 1023)
    assert internet.port(port_range=PortRange.REGISTERED) in range(1024, 49151)
    assert internet.port(port_range=PortRange.DYNAMIC) in range(49152, 65535)

# Generated at 2022-06-17 22:43:39.340192
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    assert internet.hashtags() == '#love'
    assert internet.hashtags(quantity=3) == ['#love', '#sky', '#nice']