

# Generated at 2022-06-25 20:43:00.313820
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet_0 = Internet()
    internet_0.stock_image()


# Generated at 2022-06-25 20:43:03.770131
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    data = Internet()
    assert isinstance(data.hashtags(), str)
    assert isinstance(data.hashtags(quantity=2), list)
    assert data.hashtags(quantity=1) == '#information'


# Generated at 2022-06-25 20:43:06.197840
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    inte = Internet()
    assert isinstance(inte.stock_image(), str)
    assert isinstance(inte.stock_image(writable=True), bytes)


# Generated at 2022-06-25 20:43:07.288251
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    tags = ['#love', '#sky', '#nice']
    internet_1 = Internet()
    assert internet_1.hashtags() in tags



# Generated at 2022-06-25 20:43:15.846509
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet_0 = Internet()
    width_0 = 1
    height_0 = 0
    keywords_0 = []
    result_0 = internet_0.stock_image(
        width_0,
        height_0,
        keywords_0,
    )
    assert isinstance(result_0, str)
    width_1 = 1
    height_1 = 0
    keywords_1 = []
    writable_1 = True
    result_1 = internet_0.stock_image(
        width_1,
        height_1,
        keywords_1,
        writable_1,
    )
    assert isinstance(result_1, bytes)


# Generated at 2022-06-25 20:43:20.228406
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    internet.stock_image()
    internet.stock_image(writable=True)
    internet.stock_image(keywords=["car", "beautiful"])
    internet.stock_image(keywords=["car", "beautiful"], writable=True)
    internet.stock_image(width="300", height="300", writable=True)

# Generated at 2022-06-25 20:43:21.613981
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet_0 = Internet()
    assert internet_0.hashtags() != '#love'



# Generated at 2022-06-25 20:43:28.195191
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    """
    Check if Internet.stock_image is working properly
    :return:
    """
    width = 1920
    height = 1080
    keywords = ['dog', 'cat']
    internet = Internet()

    # test the return type
    response = internet.stock_image(width=width, height=height, keywords=keywords, writable=True)
    assert(isinstance(response, bytes))

    # check if the size of the image is correct
    assert(len(response) == 476978)



# Generated at 2022-06-25 20:43:29.933364
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet_0 = Internet()
    assert internet_0.stock_image() == 'https://source.unsplash.com/1920x1080?', 'Test for method Internet.stock_image() failed.'


# Generated at 2022-06-25 20:43:31.019356
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet_1 = Internet()
    internet_1.stock_image()

