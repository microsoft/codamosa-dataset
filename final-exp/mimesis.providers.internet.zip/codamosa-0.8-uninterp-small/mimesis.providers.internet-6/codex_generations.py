

# Generated at 2022-06-25 20:43:05.065153
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    image = internet.stock_image()


# Generated at 2022-06-25 20:43:08.511074
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    """
    This method is used to test 'Internet.stock_image' method.
    """
    internet = Internet()
    result = internet.stock_image()
    assert 'https://source.unsplash.com/1920x1080' in str(result)



# Generated at 2022-06-25 20:43:10.316157
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    i = Internet()
    assert i.stock_image() == 'https://source.unsplash.com/1920x1080'
