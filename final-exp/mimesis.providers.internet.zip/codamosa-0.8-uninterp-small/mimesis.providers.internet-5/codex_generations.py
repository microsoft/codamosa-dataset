

# Generated at 2022-06-25 20:42:53.499742
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    hashtags = internet.hashtags()
    assert isinstance(hashtags, str)
    assert hashtags.startswith('#')


# Generated at 2022-06-25 20:42:55.230343
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet_1 = Internet()
    assert len(internet_1.hashtags()) == 4
    return True



# Generated at 2022-06-25 20:42:57.818153
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet_0 = Internet()
    assert internet_0.hashtags(1) == '#wedding'
    assert isinstance(internet_0.hashtags(), list)


# Generated at 2022-06-25 20:43:00.126557
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    for i in range(0,10):
        print(Internet().hashtags(quantity=Internet().random.randint(1, 10)))



# Generated at 2022-06-25 20:43:02.313853
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet_1 = Internet()
    result_1 = internet_1.hashtags(1)
    assert result_1.startswith("#")

# Generated at 2022-06-25 20:43:04.177887
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet_1 = Internet
    internet_1.hashtags(quantity=4)


# Generated at 2022-06-25 20:43:06.966609
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    # Создание объекта
    Internet_0 = Internet()
    assert type(Internet_0.hashtags()) == str


# Generated at 2022-06-25 20:43:08.251615
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet_0 = Internet()
    internet_0.hashtags()


# Generated at 2022-06-25 20:43:15.845320
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    # No args, returns "str"
    internet_0 = Internet()
    assert isinstance(internet_0.hashtags(), str)

    # Positive int arg, returns "list"
    internet_1 = Internet(seed=4537)
    assert isinstance(internet_1.hashtags(quantity=5), list)

    # Negative int arg, returns "ValueError"
    internet_2 = Internet(seed=5875)
    assert internet_2.hashtags(quantity=-5) is None


# Generated at 2022-06-25 20:43:17.249959
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet_1 = Internet()
    internet_1.hashtags(quantity=3)
