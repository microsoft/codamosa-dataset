

# Generated at 2022-06-25 20:44:32.898490
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet_1 = Internet()
    int_43 = internet_1.random.randint(1, (1 + 2) * 2)
    str_46 = internet_1.hashtags(int_43)


# Generated at 2022-06-25 20:44:35.479726
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet_0 = Internet()
    str_0 = internet_0.hashtags(quantity=3)


# Generated at 2022-06-25 20:44:36.919925
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet_0 = Internet()
    result_0 = internet_0.hashtags(1)


# Generated at 2022-06-25 20:44:39.942381
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet_0 = Internet()
    str_0 = internet_0.hashtags(4)


# Generated at 2022-06-25 20:44:42.842634
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    assert isinstance(internet.hashtags(), str)
    assert isinstance(internet.hashtags(4), list)


# Generated at 2022-06-25 20:44:46.347358
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    expected = list()
    for _ in range(4):
        tag = '#' + internet.random.choice(HASHTAGS)
        expected.append(tag)

    actual = internet.hashtags()

    assert actual == expected

# Generated at 2022-06-25 20:44:58.098908
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    # 1
    internet_1 = Internet()
    str_1 = internet_1.hashtags(quantity=1)
    str_2 = internet_1.hashtags(quantity=2)
    str_3 = internet_1.hashtags(quantity=3)
    str_4 = internet_1.hashtags(quantity=4)

    assert(str_1.startswith('#'))
    assert(str_2.startswith('#'))
    assert(str_3.startswith('#'))
    assert(str_4.startswith('#'))
    assert(str_1[1:] in HASHTAGS)
    assert(str_2[1:] in HASHTAGS)
    assert(str_3[1:] in HASHTAGS)

# Generated at 2022-06-25 20:45:00.232206
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    assert type(Internet().hashtags()) == str


# Generated at 2022-06-25 20:45:04.838524
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    print('[Test] method hashtags of class Internet')
    internet_0 = Internet()
    str_0 = internet_0.hashtags()
    print(str_0)



# Generated at 2022-06-25 20:45:10.518841
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet_0 = Internet()
    ret_0_0 = internet_0.hashtags()