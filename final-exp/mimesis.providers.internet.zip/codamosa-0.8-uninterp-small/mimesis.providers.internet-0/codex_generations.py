

# Generated at 2022-06-25 20:42:41.088271
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    Internet_0 = Internet()
    Internet_res_0 = Internet_0.stock_image()
    assert Internet_res_0 == 'https://source.unsplash.com/1920x1080'
    Internet_res_1 = Internet_0.stock_image(width='400')
    assert Internet_res_1 == 'https://source.unsplash.com/400x1080'
    Internet_res_2 = Internet_0.stock_image(height='300')
    assert Internet_res_2 == 'https://source.unsplash.com/1920x300'
    Internet_res_3 = Internet_0.stock_image(width='400', height='300')
    assert Internet_res_3 == 'https://source.unsplash.com/400x300'

# Generated at 2022-06-25 20:42:45.299330
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    int_0 = Internet()

    assert isinstance(int_0.hashtags(), list)
    assert len(int_0.hashtags()) == 4
    assert isinstance(int_0.hashtags()[0], str)

    assert isinstance(int_0.hashtags(quantity=1), str)
    assert int_0.hashtags(quantity=1).startswith('#')


# Generated at 2022-06-25 20:42:46.866264
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    image = internet.stock_image()
    assert str(type(image)) == "<class 'str'>"


# Generated at 2022-06-25 20:42:48.447753
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet_0 = Internet()
    tag_0 = internet_0.hashtags()


# Generated at 2022-06-25 20:42:51.474062
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet_0 = Internet()
    stock_image_0 = internet_0.stock_image(1920, 1080, None)
    assert_equal(stock_image_0, None)


# Generated at 2022-06-25 20:42:58.474847
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet_0 = Internet()
    output_0 = internet_0.stock_image()
    assert type(output_0) is str
    assert output_0.startswith('http://')
    assert output_0.endswith('.jpg')
    output_1 = internet_0.stock_image(keywords=['computer'])
    assert output_1.startswith('https://')
    output_2 = internet_0.stock_image(writable=True)
    assert type(output_2) is bytes


# Generated at 2022-06-25 20:43:01.981364
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    int_1 = Internet()
    hastags_0 = int_1.hashtags(4)
    hastags_1 = int_1.hashtags(1)
    print(hastags_0)
    print(hastags_1)

# Generated at 2022-06-25 20:43:08.554029
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet_0 = Internet()
    hashtags_0 = internet_0.hashtags()
    hashtags_1 = internet_0.hashtags()
    hashtags_2 = internet_0.hashtags()
    hashtags_3 = internet_0.hashtags()
    hashtags_4 = internet_0.hashtags()
    assert hashtags_0 != hashtags_1
    assert hashtags_1 != hashtags_2
    assert hashtags_2 != hashtags_3
    assert hashtags_3 != hashtags_4


# Generated at 2022-06-25 20:43:15.846164
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet_0 = Internet()
    int_0 = internet_0.hashtags(4)

# Generated at 2022-06-25 20:43:23.978956
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    # Check if an error is raised
    from mimesis.exceptions import NonEnumerableError
    Internet().stock_image()

    # Define width and height for image
    width = 1920
    height = 1080

    # Define keywords
    keywords = ['awesome', 'mimesis', 'random_data']

    # First variant: Return link to image
    link = Internet().stock_image(width=width,
                                  height=height,
                                  keywords=keywords)
    assert isinstance(link, str)

    # Second variant: Return writable object
    writable = Internet().stock_image(width=width,
                                      height=height,
                                      keywords=keywords,
                                      writable=True)
    assert isinstance(writable, bytes)