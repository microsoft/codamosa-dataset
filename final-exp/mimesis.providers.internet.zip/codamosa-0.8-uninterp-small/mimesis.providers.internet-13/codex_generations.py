

# Generated at 2022-06-25 20:42:54.966217
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet_1 = Internet()
    assert isinstance(internet_1.stock_image(), str)

    # Test for required internet connection
    assert internet_1.stock_image(writable=True)

# Generated at 2022-06-25 20:42:57.132796
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet_1 = Internet()
    internet_1.stock_image(width=1920, height=1080, keywords=["cat", "sky"])


# Generated at 2022-06-25 20:42:58.833441
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet_1 = Internet()
    assert isinstance(internet_1.hashtags(), str)


# Generated at 2022-06-25 20:43:00.361003
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet_stock_image_0 = Internet().stock_image()


# Generated at 2022-06-25 20:43:05.654997
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    # Set up data
    internet_0 = Internet()
    expected_result = 'https://source.unsplash.com/1920x1080?kitten,puppy'
    # Execute code under test
    actual_result = internet_0.stock_image(keywords=['kitten', 'puppy'])
    # Verify expectations
    assert actual_result == expected_result


# Generated at 2022-06-25 20:43:09.064046
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet_1 = Internet()
    link = internet_1.stock_image(writable=False)
    assert isinstance(link, str)
    image = internet_1.stock_image(writable=True)
    assert isinstance(image, bytes)


# Generated at 2022-06-25 20:43:11.158481
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet_0 = Internet()
    internet_0._Internet__file = File()
    print( internet_0.hashtags(quantity = 4) )


# Generated at 2022-06-25 20:43:15.846167
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet_1 = Internet()
    internet_1.stock_image('test_width', 'test_height', ['test_keywords'])
    internet_1.stock_image('test_width', 'test_height', ['test_keywords'], True)


# Generated at 2022-06-25 20:43:16.954998
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet_0 = Internet()
    internet_0.stock_image()


# Generated at 2022-06-25 20:43:21.039388
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet_1 = Internet()
    assert internet_1.stock_image(width=1, height=1, keywords=['test']) == 'https://source.unsplash.com/1x1?test'
    assert internet_1.stock_image() == 'https://source.unsplash.com/1920x1080?'
