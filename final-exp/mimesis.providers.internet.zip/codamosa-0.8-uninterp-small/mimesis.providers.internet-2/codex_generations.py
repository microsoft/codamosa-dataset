

# Generated at 2022-06-25 20:42:33.560122
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet_0 = Internet()
    assert internet_0.hashtags(quantity=1) == '#dsmn'



# Generated at 2022-06-25 20:42:34.939905
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet_1 = Internet()
    internet_1.stock_image(writable=True)

# Generated at 2022-06-25 20:42:41.128060
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    from base64 import b64decode
    from io import BytesIO
    from mimesis.builtins import Image
    image_0 = Internet().stock_image()
    image_1 = Internet().stock_image(writable=True)
    image_2 = Image(BytesIO(image_1))
    assert isinstance(image_0, str)
    assert isinstance(image_1, bytes)
    assert isinstance(image_2, Image)

# Generated at 2022-06-25 20:42:45.015817
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet_1 = Internet()
    assert isinstance(internet_1.stock_image(), str)
    try:
        assert isinstance(internet_1.stock_image(writable=True), bytes)
    except urllib.error.URLError:
        assert True



# Generated at 2022-06-25 20:42:47.079308
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet(seed=123)
    result = internet.hashtags()
    assert result == '#cupiditate'



# Generated at 2022-06-25 20:42:50.516961
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    image = Internet.stock_image('600', '600')
    assert image.find('https') != -1
    assert image.find('source.unsplash.com') != -1


# Generated at 2022-06-25 20:42:52.846733
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    image = internet.stock_image()
    assert image is not None
    assert isinstance(image, str)

# Generated at 2022-06-25 20:42:55.780727
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    image = Internet().stock_image(width=200, height=400, writable=True)
    print(image)
    # assert isinstance(image, bytes)
    # assert image

# Generated at 2022-06-25 20:43:05.836472
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    data = [
        {
            'width': 1920,
            'height': 1080
        },
        {
            'keywords': 'buildings, office, modern',
            'writable': True
        },
        {
            'width': 500,
            'height': 850
        },
        {
            'width': 500,
            'height': 850,
            'keywords': 'buildings, office, modern',
            'writable': True
        }
    ]

    for d in data:
        stock_image = Internet().stock_image(
            width=d.get('width', 1920),
            height=d.get('height', 1080),
            keywords=d.get('keywords', None),
            writable=d.get('writable', False)
        )
        print(stock_image)

# Generated at 2022-06-25 20:43:07.852184
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet_0 = Internet()
    assert internet_0.stock_image().startswith("https://source.unsplash.com/")


# Generated at 2022-06-25 20:43:23.124037
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    i = Internet()
    print(i.user_agent())

# Generated at 2022-06-25 20:43:29.891468
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    width = 1920
    height = 1080
    keywords = ['nature', 'technology']
    writable = True

    try:
        internet_0 = Internet()
        stock_image_0 = internet_0.stock_image(
            width=width, height=height, keywords=keywords, writable=writable)
        assert len(stock_image_0) == height * width

    except urllib.error.URLError:
        raise urllib.error.URLError('Required an active HTTP connection')



# Generated at 2022-06-25 20:43:32.062532
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet_0 = Internet()
    print(internet_0.stock_image(keywords=['love','sky','nice']));

# Generated at 2022-06-25 20:43:34.004778
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet_1 = Internet(seed=0)
    assert internet_1.stock_image() == 'https://source.unsplash.com/1920x1080?nature'

# Generated at 2022-06-25 20:43:35.612805
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()

    assert isinstance(internet.stock_image(), str)
    assert isinstance(internet.stock_image(writable=True), bytes)

# Generated at 2022-06-25 20:43:37.956293
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet_0 = Internet()
    image_0 = internet_0.stock_image(width=1440, height=900, keywords=['lion'], writable=False)
    assert isinstance(image_0, str)


# Generated at 2022-06-25 20:43:39.408620
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet_1 = Internet()
    assert type(internet_1.stock_image(1920, 1080)) is str

# Generated at 2022-06-25 20:43:44.829338
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet_0 = Internet()
    result_0 = internet_0.stock_image()
    assert_0 = 'https://source.unsplash.com/1920x1080'
    assert_1 = result_0 == assert_0
    assert assert_1


# Generated at 2022-06-25 20:43:49.350444
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet_0 = Internet()
    internet_0.stock_image(1920, 1080, ['cat', 'dog'])


# Generated at 2022-06-25 20:43:51.573967
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet_0 = Internet()
    internet_0.stock_image(width=1920, height=1080)


# Generated at 2022-06-25 20:44:15.779317
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet_1 = Internet()
    assert isinstance(internet_1.stock_image(), str)

# Generated at 2022-06-25 20:44:18.063029
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet_0 = Internet()
    ret_0 = internet_0.stock_image(width=None, height=None)
    # Test is not available
    assert_true(ret_0)


# Generated at 2022-06-25 20:44:20.744500
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    internet.stock_image(width=500, height=500)



# Generated at 2022-06-25 20:44:25.612007
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet_1 = Internet()
    image_url = internet_1.stock_image()
    assert isinstance(image_url, str)
    assert (image_url.startswith("https://images.unsplash.com/photo"))

# Generated at 2022-06-25 20:44:28.823458
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    internet.stock_image()



# Generated at 2022-06-25 20:44:32.497561
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet_1 = Internet()

    assert type(internet_1.stock_image()) == str
    assert type(internet_1.stock_image(writable=True)) == bytes

# Generated at 2022-06-25 20:44:38.663668
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet_0 = Internet()

    # Test with default values
    internet_0.stock_image()
    internet_0.stock_image(width=640, height=480)
    internet_0.stock_image(width=640, height=480, keywords=[
                           "mountain", "sea", "water"])
    internet_0.stock_image(width=640, height=480, keywords=["water"])
    internet_0.stock_image(width=640, height=480, keywords=["water"], writable=True)



# Generated at 2022-06-25 20:44:50.441373
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    # stock image
    try:
        internet = Internet()
        print(internet.stock_image())
        # https://source.unsplash.com/1920x1080?
    except Exception as e:
        print(e)
        return False

    # stock image 4:3 (default)
    try:
        internet = Internet()
        print(internet.stock_image())
        # https://source.unsplash.com/1920x1080?
    except Exception as e:
        print(e)
        return False

    # stock image with keywords
    try:
        internet = Internet()
        print(internet.stock_image(keywords=["books", "open"]))
        # https://source.unsplash.com/1920x1080?books,open
    except Exception as e:
        print(e)
        return False

   

# Generated at 2022-06-25 20:44:53.447573
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    # The method is supposed to return str
    assert(isinstance(
        internet.stock_image(),
        str,
    ))

# Generated at 2022-06-25 20:44:56.503036
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet_0 = Internet()
    internet_0_result = internet_0.stock_image(1920, 1080, ['search', 'for'], True)
    assert internet_0_result

