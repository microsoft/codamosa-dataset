

# Generated at 2022-06-25 20:42:36.699406
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet_1 = Internet()
    list_0 = internet_1.hashtags(quantity=1)
    assert len(list_0) == 1
    assert list_0[0] == '#love'


# Generated at 2022-06-25 20:42:45.758944
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    # Test with default quantity = 4
    res = internet.hashtags()
    assert len(res) == 4
    # Test with quantity = 3
    res = internet.hashtags(quantity=3)
    assert len(res) == 3
    # Test with quantity = 1
    res = internet.hashtags(quantity=1)
    assert type(res) == str
    # Test with quantity = 0
    res = internet.hashtags(quantity=0)
    assert res == []
    # Test with quantity = -1
    res = internet.hashtags(quantity=-1)
    assert res == []
    res = internet.hashtags(quantity=None)
    assert res == []
    from pytest import raises
    with raises(TypeError):
        internet.hashtags(quantity='')


# Generated at 2022-06-25 20:42:46.961411
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet = Internet()
    assert internet.hashtags() != None


# Generated at 2022-06-25 20:42:49.314936
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet_0 = Internet()
    str_0 = internet_0.stock_image()


# Generated at 2022-06-25 20:42:50.982502
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet_0 = Internet()
    str_0 = internet_0.hashtags()


# Generated at 2022-06-25 20:42:55.646001
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    assert Internet().hashtags(quantity=3) == '#love,#news,#sky'
    assert Internet().hashtags(quantity=1) == '#music'
    assert Internet().hashtags(quantity=2) == ['#music', '#nice']
    assert isinstance(Internet().hashtags(quantity=3), list)


# Generated at 2022-06-25 20:42:58.564820
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet_1 = Internet()
    str_0 = internet_1.stock_image()
    assert str_0.startswith("https://source.unsplash.com/")


# Generated at 2022-06-25 20:43:07.001169
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet_0 = Internet()
    stock_image_0 = internet_0.stock_image()
    stock_image_1 = internet_0.stock_image(2332, 1753)
    stock_image_2 = internet_0.stock_image(1949, 1475, ['bike'])
    stock_image_2 = internet_0.stock_image(1949, 1475, ['bike'], True)
    stock_image_3 = internet_0.stock_image(1219, 887, ['dog', 'mountain'])
    stock_image_4 = internet_0.stock_image(1219, 887, ['dog', 'mountain'], True)

# Generated at 2022-06-25 20:43:08.638196
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet_0 = Internet()
    assert isinstance(internet_0.stock_image(), str)


# Generated at 2022-06-25 20:43:11.975030
# Unit test for method hashtags of class Internet
def test_Internet_hashtags():
    internet_0 = Internet()
    str_0 = internet_0.hashtags(0)
    str_1 = internet_0.hashtags(1)
    str_2 = internet_0.hashtags(2)
    str_3 = internet_0.hashtags(3)
    str_4 = internet_0.hashtags(4)


# Generated at 2022-06-25 20:43:33.126051
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet_0 = Internet()
    result = internet_0.stock_image()
    assert(result == "https://source.unsplash.com/1920x1080?")

    result = internet_0.stock_image(1920, 1080)
    assert(result == "https://source.unsplash.com/1920x1080?")

    result = internet_0.stock_image(1920, 1080, ["test"], False)
    assert(result == "https://source.unsplash.com/1920x1080?test")

    # Test with size of zero
    result = internet_0.stock_image(0, 0)
    assert(result == "https://source.unsplash.com/0x0?")


# Generated at 2022-06-25 20:43:37.994505
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet_0 = Internet() 
    internet_1 = Internet()
    image_0 = internet_0.stock_image(width = '1024', height = '768')
    image_1 = internet_1.stock_image(width = '1024', height = '768', keywords = ['love'])
    assert image_0 != image_1
    assert 'https://source.unsplash.com/1024x768?' in image_0 
    assert 'https://source.unsplash.com/1024x768?love' in image_1


# Generated at 2022-06-25 20:43:39.408344
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    INTERNET = Internet()
    print(INTERNET.stock_image(width = 960, height = 960))


# Generated at 2022-06-25 20:43:51.212614
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    # Generate stock image with default params,
    # returning url to image
    url_0 = Internet().stock_image()

    assert isinstance(url_0, str)
    # Test for if_else structure
    assert "https://source.unsplash.com/1920x1080?" in url_0

    # Generate stock image with params,
    # returning bytes object
    bytes_0 = Internet().stock_image(writable=True)

    assert isinstance(bytes_0, bytes)
    # Test for if_else structure
    assert b'\xff\xd8' in bytes_0
    
    # Generate stock image with params,
    # returning url to image with keywords
    url_1 = Internet().stock_image(keywords=['man','woman','red','blue','green'])


# Generated at 2022-06-25 20:43:53.149054
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet_1 = Internet()
    print(internet_1.stock_image())

##############################

test_case_0()
test_Internet_stock_image()

# Generated at 2022-06-25 20:43:56.137976
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet_1 = Internet()
    assert isinstance(internet_1.stock_image(writable=True), bytes)
    assert len(internet_1.stock_image(writable=True)) > 0


# Generated at 2022-06-25 20:43:57.259072
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    result = internet.stock_image()


# Generated at 2022-06-25 20:44:03.386444
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    class InternetTest(Internet):
        class Meta:
            name = 'internet'

    internet = InternetTest()
    assert type(internet.stock_image(writable=True)) == bytes
    assert type(internet.stock_image()) == str

# Generated at 2022-06-25 20:44:06.607593
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet = Internet()
    stock_image_0: str = internet.stock_image()
    assert isinstance(stock_image_0, str)

# Generated at 2022-06-25 20:44:10.653100
# Unit test for method stock_image of class Internet
def test_Internet_stock_image():
    internet_0 = Internet()
    output_0 = internet_0.stock_image(keywords=['python-mimesis'])
    assert isinstance(output_0, str)
