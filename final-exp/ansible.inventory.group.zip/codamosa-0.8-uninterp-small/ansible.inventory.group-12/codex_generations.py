

# Generated at 2022-06-24 19:38:46.953879
# Unit test for method remove_host of class Group
def test_Group_remove_host():
    group = Group('test_group')
    host = Host('test_host')

    group.add_host(host)
    assert group.hosts[0] == host
    group.remove_host(host)
    assert group.hosts == []


# Generated at 2022-06-24 19:38:49.980927
# Unit test for method remove_host of class Group
def test_Group_remove_host():
    group_0 = Group()
    group_0.set_variable('ansible_group_priority', 1)
    group_0.remove_host('host_0')



# Generated at 2022-06-24 19:38:52.772981
# Unit test for method add_host of class Group
def test_Group_add_host():
    foo = Group(name='foo')
    new_host = "new_host"    # placeholder for whatever code creates a new Host object
    foo.add_host(new_host)


# Generated at 2022-06-24 19:38:57.782097
# Unit test for method set_variable of class Group
def test_Group_set_variable():
    # Create a new Group
    group_0 = Group()
    # Use the set_variable method of class Group
    group_0.set_variable("vars", "value")
    # Check the result
    vars = group_0.vars
    assert vars == {"vars": "value"}, "group_0.set_variable() failed"


# Generated at 2022-06-24 19:39:08.109099
# Unit test for function to_safe_group_name
def test_to_safe_group_name():
    # Bad characters and replacement characters
    bad_chars = C.INVALID_VARIABLE_NAMES.findall('test!group@name')
    good_char = '_'

    # Test for replacement of invalid characters
    group_name = to_safe_group_name('test!group@name')
    assert group_name == 'test{}{}group{}name'.format(good_char, good_char, good_char)

    # Test that setting force to true replaces all characters
    group_name = to_safe_group_name('test!group@name')
    assert group_name == 'test{}{}group{}name'.format(good_char, good_char, good_char)

    # Test that setting force to true with a replacement character works

# Generated at 2022-06-24 19:39:10.081283
# Unit test for method deserialize of class Group
def test_Group_deserialize():
    group_0 = Group()
    group_0.deserialize({'group_vars': [], 'hosts': [], 'parent_groups': [], 'name': 'foo', 'host_vars': []})

# Generated at 2022-06-24 19:39:12.427105
# Unit test for method set_variable of class Group
def test_Group_set_variable():
    group = Group()
    group.set_variable('ansible_group_priority', 3)
    assert(group.priority == 3)
    group.clear_hosts_cache()


# Generated at 2022-06-24 19:39:21.764089
# Unit test for method remove_host of class Group
def test_Group_remove_host():
    # create Group
    group_0 = Group()
    # create Host
    host_0 = Host("host_0")
    # add host_0 as host to group
    group_0.add_host(host_0)
    # Check that group_0 has host_0
    assert host_0 in group_0.hosts
    # Check that host_0 has group_0
    assert group_0 in host_0.groups
    # remove host_0 from group_0
    group_0.remove_host(host_0)
    # Check that group_0 doesn't have host_0
    assert host_0 not in group_0.hosts
    # Check that host_0 doesn't have group_0
    assert group_0 not in host_0.groups



# Generated at 2022-06-24 19:39:25.596814
# Unit test for method add_host of class Group
def test_Group_add_host():
    group_0 = Group()
    host_0 = Host()
    group_0.add_host(host_0)
    assert group_0.hosts == [host_0]

if __name__ == "__main__":
    test_Group_add_host()

# Generated at 2022-06-24 19:39:33.308355
# Unit test for method set_variable of class Group
def test_Group_set_variable():
    # Create a group
    group = Group()

    # Create a key
    key = 'mykey'

    # Create a string value
    string_value = 'mystringvalue'
    # Create a dict value
    dict_value = {'mydictkey':'mydictvalue'}

    # Set the variable
    group.set_variable(key, string_value)

    # Test set_variable
    assert group.vars[key] == string_value
    assert group.vars['mykey'] == string_value

    group.set_variable(key, string_value)

    # Test set_variable no overwrite
    assert group.vars[key] == string_value
    assert group.vars['mykey'] == string_value

    # Test set_variable overwrite
    group.set_variable(key, dict_value)


# Generated at 2022-06-24 19:39:40.888181
# Unit test for method remove_host of class Group
def test_Group_remove_host():
    host_0 = Host()
    group_0 = Group()
    group_0.remove_host(host_0)


# Generated at 2022-06-24 19:39:50.292632
# Unit test for method remove_host of class Group
def test_Group_remove_host():
    group_0 = Group()
    group_0.hosts = ['host_0', 'host_1', 'host_2', 'host_3']
    group_0._hosts = {'host_0': 'host_0', 'host_1': 'host_1', 'host_2': 'host_2'}
    group_0.name = 'group_0'
    host_2 = 'host_2'
    host_2.groups = [group_0]

    # testing - removing an existing host from the list of groups.
    assert_result = group_0.remove_host(host_2)
    assert assert_result == True
    assert group_0.hosts == ['host_0', 'host_1', 'host_3']

# Generated at 2022-06-24 19:39:59.512131
# Unit test for method add_child_group of class Group
def test_Group_add_child_group():

    # Given a parents and children set of groups
    parent_1 = Group("parent_1")
    parent_1.add_host("host_0")
    parent_2 = Group("parent_2")
    parent_2.add_host("host_1")
    child_1 = Group("child_1")
    child_1.add_host("host_2")
    child_2 = Group("child_2")
    child_2.add_host("host_3")
    grandchildren_1 = Group("grandchildren_1")
    grandchildren_1.add_host("host_4")
    grandchildren_2 = Group("grandchildren_2")
    grandchildren_2.add_host("host_5")

    # When we add and remove child relationships
    parent_1.add_child_group(child_1)
    child_1

# Generated at 2022-06-24 19:40:04.771009
# Unit test for method deserialize of class Group
def test_Group_deserialize():
    new_group = Group()
    data = {'name': 'test', 'vars': {'test_var': 'test_value'}, 'hosts': ['host_1', 'host_2'],
            'parent_groups': [{'name': 'group_2', 'vars': {'test_var_2': 'test_value_2'}, 'parent_groups': [], 'hosts': ['host_1']}]}
    return new_group.deserialize(data)


# Generated at 2022-06-24 19:40:10.545682
# Unit test for method remove_host of class Group
def test_Group_remove_host():
    test_host = {'name' : 'foo.bar'}
    group1 = Group('group1')
    group1.add_host(test_host)
    group1.remove_host(test_host)


# Generated at 2022-06-24 19:40:20.335170
# Unit test for method remove_host of class Group
def test_Group_remove_host():
    group0 = Group("Group0")
    group1 = Group("Group1")
    assert len(group0.hosts) == 0
    assert len(group1.hosts) == 0
    host_0 = Host(name="Host0")
    host_1 = Host(name="Host1")
    host_2 = Host(name="Host2")
    group0.add_host(host_0)
    group0.add_host(host_1)
    group1.add_host(host_2)
    assert len(group0.hosts) == 2
    assert len(group1.hosts) == 1
    assert host_0 in group0.hosts
    assert host_1 in group0.hosts
    assert host_0 not in group1.hosts
    assert host_1 not in group1.hosts

# Generated at 2022-06-24 19:40:24.227245
# Unit test for method set_variable of class Group
def test_Group_set_variable():
    test_group = Group()
    # Setting variable with key ansible_group_priority and testing if it is set correctly
    test_group.set_variable('ansible_group_priority', 500)
    assert (test_group.priority == 500)
    # Setting variable with key name and testing if it is set correctly
    test_group.set_variable('name', 'test-group')
    assert (test_group.name == 'test-group')

# Generated at 2022-06-24 19:40:33.099528
# Unit test for method deserialize of class Group
def test_Group_deserialize():
    group_0 = Group()
    group_0.deserialize({'vars': {},
                         'child_groups': [],
                         'parent_groups': [],
                         'depth': 0,
                         'hosts': [],
                         'name': 'test'})
    assert group_0.depth == 0
    assert group_0.name == 'test'
    assert group_0.hosts == []
    assert group_0.vars == {}
    assert group_0.child_groups == []
    assert group_0.parent_groups == []


# Generated at 2022-06-24 19:40:40.437310
# Unit test for function to_safe_group_name
def test_to_safe_group_name():
    assert('_A_A' == to_safe_group_name('A-A', force=True))
    assert('_A_A' == to_safe_group_name('A_A', force=True))
    assert('_A_A' == to_safe_group_name('A.A', force=True))
    assert('_A_A' == to_safe_group_name('A:A', force=True))
    assert('_A_A' == to_safe_group_name('A@A', force=True))
    assert('_A_A' == to_safe_group_name('A/A', force=True))
    assert('_A_A' == to_safe_group_name('A\\A', force=True))

# Generated at 2022-06-24 19:40:44.095557
# Unit test for method add_host of class Group
def test_Group_add_host():
    group_0 = Group()
    group_0.add_host("host_0")
    group_0.add_host("host_1")
    group_0.add_host("host_2")
    group_0.add_host("host_0")


# Generated at 2022-06-24 19:41:09.884322
# Unit test for method remove_host of class Group
def test_Group_remove_host():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory

    inventory = Inventory()
    inventory.parse_inventory("./test/units/inventory/test_inventory_remove_host/")
    inventory.reconcile_inventory()

    # selected_groups will be used to validate the result
    selected_groups = ['group_0', 'group_1', 'all']
    # selected_hosts will be used to validate the result
    selected_hosts = ['host_1', 'host_2', 'host_3', 'host_4', 'host_5']

    all_group = inventory.groups_dict['all']
    group_0 = inventory.groups_dict['group_0']
    group_1 = inventory.groups_dict['group_1']


# Generated at 2022-06-24 19:41:19.066296
# Unit test for method remove_host of class Group
def test_Group_remove_host():
    test_group = Group('G1')
    test_group.add_host(Host('H1'))
    test_group.add_host(Host('H2'))
    test_group.add_host(Host('H3'))
    test_group.add_host(Host('H4'))
    assert len(test_group.hosts) == 4
    test_group.remove_host(Host('H3'))
    assert len(test_group.hosts) == 3
    test_group.remove_host(Host('H1'))
    assert len(test_group.hosts) == 2
    return True

test_case_0()

test_Group_remove_host()

# Generated at 2022-06-24 19:41:25.042480
# Unit test for method remove_host of class Group
def test_Group_remove_host():

    group_0 = Group()
    group_0.name = "group_0"

    host_0 = Host()
    host_0.name = "host_0"

    group_0.add_host(host_0)
    removed = group_0.remove_host(host_0)

    assert not removed


# Generated at 2022-06-24 19:41:29.249497
# Unit test for method remove_host of class Group
def test_Group_remove_host():
    group = Group()
    group.set_variable = Mock()
    group._check_children_depth = Mock()
    group.clear_hosts_cache = Mock()
    group.hosts = [host1,host2]
    host3 = Host()
    assert not group.remove_host(host3)


# Generated at 2022-06-24 19:41:36.264884
# Unit test for function to_safe_group_name
def test_to_safe_group_name():

    print("\nTest to_safe_group_name")

    # Test to_safe_group_name with an invalid group name
    bad_name = 'system-name?'

    # First, test bytes input
    print("Group: %s" % bad_name.encode('utf-8'))
    good_name = to_safe_group_name(bad_name.encode('utf-8'))
    print("Safe group: %s" % good_name)
    assert isinstance(good_name, str)

    # Next, test text input
    print("Group: %s" % bad_name)
    good_name = to_safe_group_name(bad_name)
    print("Safe group: %s" % good_name)
    assert isinstance(good_name, str)

    # Test to_safe_

# Generated at 2022-06-24 19:41:47.294380
# Unit test for method remove_host of class Group
def test_Group_remove_host():
    group_1 = Group('Group_1')
    group_2 = Group('Group_2')
    group_3 = Group('Group_3')
    group_4 = Group('Group_4')
    group_5 = Group('Group_5')
    group_6 = Group('Group_6')
    group_7 = Group('Group_7')
    group_8 = Group('Group_8')
    group_9 = Group('Group_9')

    group_1.add_child_group(group_2)
    group_2.add_child_group(group_3)
    group_3.add_child_group(group_4)
    group_4.add_child_group(group_5)
    group_5.add_child_group(group_6)

# Generated at 2022-06-24 19:41:56.130909
# Unit test for method add_host of class Group
def test_Group_add_host():
    """
        Create some hosts, groups, and ensure that the right
        number of hosts and groups are present in various
        group relationships.
    """
    group_0 = Group()
    group_1 = Group()
    group_2 = Group()
    group_3 = Group()

    host_0 = Host()
    host_1 = Host()
    host_2 = Host()
    host_3 = Host()

    group_0.add_child_group(group_1)
    group_0.add_child_group(group_2)
    group_0.set_variable('foo', {'bar': 'baz'})
    group_1.set_variable('foo1', 'bar1')
    group_2.set_variable('foo2', 'bar2')


# Generated at 2022-06-24 19:42:04.268099
# Unit test for method set_variable of class Group
def test_Group_set_variable():
    group = Group()
    group.set_variable('key', 'value')
    assert group.vars['key'] == 'value'
    group.set_variable('key2', 'value2')
    assert group.vars['key2'] == 'value2'
    group.set_variable('key', {'key3': 'value3'})
    assert group.vars['key'] == {'key3': 'value3'}
    group.set_variable('key', {'key4': 'value4'})
    assert group.vars['key'] == {'key4': 'value4'}


# Generated at 2022-06-24 19:42:13.658143
# Unit test for method remove_host of class Group
def test_Group_remove_host():
    group_0 = Group()
    group_0.name = 'all'
    group_0.vars = {'foo': 'bar1'}

    host_0 = Host()
    host_0.name = 'www.example.com'
    host_0.port = 22
    host_0.vars = {'foo': 'baz1'}

    group_0.add_host(host_0)

    group_0.remove_host(host_0)

    assert host_0.vars['foo'] == 'baz1'
    assert group_0.vars['foo'] == 'bar1'
    assert host_0 in group_0.hosts


# Generated at 2022-06-24 19:42:18.190843
# Unit test for method add_host of class Group
def test_Group_add_host():
    group_0 = Group()
    host_0 = Host(name='host_0')
    group_0.add_host(host_0)


# Generated at 2022-06-24 19:42:33.007956
# Unit test for method remove_host of class Group
def test_Group_remove_host():
    g_0 = Group("test_Group_remove_host_0")
    g_1 = Group("test_Group_remove_host_1")
    g_2 = Group("test_Group_remove_host_2")
    g_2.add_child_group(g_0)
    g_2.add_child_group(g_1)
    h_0 = Host("test_Group_remove_host_0")
    h_1 = Host("test_Group_remove_host_1")
    h_2 = Host("test_Group_remove_host_2")
    h_3 = Host("test_Group_remove_host_3")
    h_0.add_group(g_0)
    h_1.add_group(g_1)
    h_2.add_group(g_2)

# Generated at 2022-06-24 19:42:35.943118
# Unit test for method remove_host of class Group
def test_Group_remove_host():
    group_0 = Group()
    hosts = set()
    group_0.hosts = hosts
    host = Host()
    group_0.remove_host(host)



# Generated at 2022-06-24 19:42:41.099472
# Unit test for method remove_host of class Group
def test_Group_remove_host():
    group_0 = Group()
    host_0 = Host()
    group_0.add_host(host_0)
    group_0.remove_host(host_0)
    assert len(group_0.hosts) == 0
    assert host_0.name not in group_0.host_names
    assert group_0 not in host_0.groups


# Generated at 2022-06-24 19:42:48.107184
# Unit test for method add_host of class Group
def test_Group_add_host():

    grp = Group()

    # begin test case 0
    # goal: add host (h0) to group (grp)
    # assert: host (h0) is not in group (grp) before adding
    # assert: host (h0) is in group (grp) after adding
    h0 = 'test_host_0'
    if h0 in grp.hosts:
        raise Exception()
    grp.add_host(h0)
    if h0 not in grp.hosts:
        raise Exception()
    # end test case 0


# Generated at 2022-06-24 19:42:56.163115
# Unit test for method add_host of class Group
def test_Group_add_host():
    # Create empty group
    h0 = Group()
    h1 = Group()
    # Create host template
    h2 = Host()
    # Add a host group and a host to group
    h0.add_child_group(h1)
    h0.add_host(h2)

    # Assert group has host
    assert h0.get_hosts()[0] == h2
    # Assert host has group
    assert h2.get_groups()[0] == h0
    # Assert there are no children
    assert len(h0.get_children()) == 0

    # Add host to child
    h1.add_host(h2)
    # Assert child has host
    assert h1.get_hosts()[0] == h2
    # Assert host has group
    assert h2

# Generated at 2022-06-24 19:43:04.857367
# Unit test for method remove_host of class Group
def test_Group_remove_host():
    group_0 = Group('test_group')
    group_0.add_host('test_host')
    group_0.add_host('test_host_1')
    group_0.add_host('test_host_2')
    group_0.add_host('test_host_3')
    assert group_0.hosts == ['test_host','test_host_1','test_host_2','test_host_3']
    assert group_0.remove_host('test_host') == True
    assert group_0.remove_host('test_host') == False
    assert group_0.remove_host('test_host_1') == True
    assert group_0.remove_host('test_host_2') == True
    assert group_0.remove_host('test_host_3') == True



# Generated at 2022-06-24 19:43:12.928862
# Unit test for method remove_host of class Group
def test_Group_remove_host():
    group_0 = Group()
    host_0 = Host()
    host_0.name = 'host0'
    rem_0 = group_0.remove_host(host_0)
    group_0.hosts.append(host_0)
    rem_1 = group_0.remove_host(host_0)

    # Test case where host is removed from group.
    assert rem_1 == True

    # Test case where host is not removed from group.
    assert rem_0 == False



# Generated at 2022-06-24 19:43:17.115385
# Unit test for method add_host of class Group
def test_Group_add_host():
    # create the object containing the test case
    case = Group()
    # initialize the test case
    case.name = "test_name"
    case.hosts = []
    case._hosts = ["test_host"]
    # run the method
    result = case.add_host("test_host")
    # verify the result
    assert not result


# Generated at 2022-06-24 19:43:23.811518
# Unit test for method remove_host of class Group
def test_Group_remove_host():
    group_0 = Group()
    group_0.name = "dummy_name"
    group_0.hosts = ["dummy_host"]
    group_0._hosts = set(["dummy_host"])
    group_0.vars = {}
    group_0.child_groups = []
    group_0.parent_groups = []
    group_0._hosts_cache = None
    group_0.priority = 1
    host_0 = ["dummy_host"]
    host_0[0] = Host()
    host_0[0].name = "dummy_host"
    host_0[0].port = 0
    host_0[0].vars = {}
    host_0[0].groups = ["dummy_group"]
    host_0[0].has_active_failing

# Generated at 2022-06-24 19:43:30.675762
# Unit test for method remove_host of class Group
def test_Group_remove_host():
    group_0 = Group()
    group_1 = Group()
    group_0.add_child_group(group_1)
    host_0 = Host('192.168.1.1')
    host_1 = Host('192.168.1.2')
    host_2 = Host('192.168.1.3')
    host_3 = Host('192.168.1.4')
    host_0.add_group(group_0)
    host_0.add_group(group_1)
    host_1.add_group(group_0)
    host_1.add_group(group_1)
    host_2.add_group(group_0)
    host_2.add_group(group_1)
    host_3.add_group(group_0)

# Generated at 2022-06-24 19:43:39.968347
# Unit test for function to_safe_group_name
def test_to_safe_group_name():
    assert to_safe_group_name('goodname') == 'goodname'
    assert to_safe_group_name('very$bad name') == 'very_bad_name'
    assert to_safe_group_name('!m@c0s!') == '__m_c0s_'
    assert to_safe_group_name('[u]') == '_u_'

# Generated at 2022-06-24 19:43:45.710111
# Unit test for method add_host of class Group
def test_Group_add_host():
    group = Group()
    host = Host('test_host')
    assert False == group.add_host(host)
    assert 0 == len(host._groups)
    host.add_group(group)
    assert True == group.add_host(host)
    assert 2 == len(host._groups)


# Generated at 2022-06-24 19:43:49.221516
# Unit test for method remove_host of class Group
def test_Group_remove_host():
    group_0 = Group()
    group_0.remove_host(group_0.host)


# Generated at 2022-06-24 19:43:59.131731
# Unit test for method remove_host of class Group
def test_Group_remove_host():
    group_1 = Group()
    group_2 = Group()

    host_1 = group_1.add_host('host_1')
    host_2 = group_1.add_host('host_2')

    group_3 = Group()
    group_3.add_host('host_3')
    group_3.add_host('host_4')

    group_2.add_host(host_1)
    group_2.add_host(host_2)

    assert len(group_2.hosts) == 2
    assert len(group_1.hosts) == 2

    group_1.remove_host(host_1)

    assert len(group_2.hosts) == 1
    assert len(group_1.hosts) == 1

    group_1.remove_host(host_2)

# Generated at 2022-06-24 19:44:02.360785
# Unit test for method add_host of class Group
def test_Group_add_host():
    g = Group('group')
    h = Host('host')
    assert g.add_host(h)
    assert h in g.hosts
    assert g in h.groups


# Generated at 2022-06-24 19:44:11.621207
# Unit test for method set_variable of class Group
def test_Group_set_variable():
    group = Group()

    # Create a 'group' var
    group.set_variable('group_var', 'initial_value')
    assert group.vars['group_var'] == 'initial_value'

    # Change the value of the 'group_var' with a simple value
    group.set_variable('group_var', 'changed')
    assert group.vars['group_var'] == 'changed'

    # Change the value of the 'group_var' with a dict
    group.set_variable('group_var', {'sub_key': 'sub_value'})
    assert group.vars['group_var'] == {'sub_key': 'sub_value'}

    # Update the value of the 'group_var' with a simple value
    group.set_variable('group_var', 'updated')

# Generated at 2022-06-24 19:44:14.381754
# Unit test for method add_host of class Group
def test_Group_add_host():
    group_0 = Group()
    group_0.add_host(host=Host(name='dans-MacBook-Pro.local'))


# Generated at 2022-06-24 19:44:18.673970
# Unit test for method remove_host of class Group
def test_Group_remove_host():
    class Host:
        def __init__(self,name):
            self.name = name
            self.groups = []
        def remove_group(self,group):
            self.groups.remove(group)
    group = Group()
    # NOTE: host.groups can not be empty in this situation,
    # otherwise group.remove_host() will not try to remove the host
    host = Host("host")
    group.hosts.append(host)
    group._hosts = set([host.name])
    host.groups.append(group)
    assert len(host.groups) == 1
    group.remove_host(host)
    assert len(host.groups) == 0
    assert len(group.hosts) == 0
    assert len(group._hosts) == 0
    

# Generated at 2022-06-24 19:44:25.104598
# Unit test for method remove_host of class Group
def test_Group_remove_host():

    group = Group()
    group.add_host('machine1')
    group.add_host('machine2')
    assert list(group._hosts) == ['machine1', 'machine2']
    group.remove_host('machine3')
    assert list(group._hosts) == ['machine1', 'machine2']
    group.remove_host('machine2')
    assert list(group._hosts) == ['machine1']
    group.remove_host('machine1')
    assert list(group._hosts) == []


# Generated at 2022-06-24 19:44:31.925083
# Unit test for method add_host of class Group
def test_Group_add_host():
    group_0 = Group()
    host_0 = Host()
    host_1 = Host()
    if group_0.add_host(host_0):
        print("PASS")
    if group_0.add_host(host_0):
        print("FAIL")
    if group_0.add_host(host_1):
        print("PASS")
    if not group_0.add_host(host_1):
        print("FAIL")


# Generated at 2022-06-24 19:44:46.946284
# Unit test for method remove_host of class Group
def test_Group_remove_host():
    # Create a new group and add a new host
    test_Group_remove_host_group = Group("test")
    test_Group_remove_host_host = Host("test_host")
    test_Group_remove_host_group.add_host(test_Group_remove_host_host)
    # Check that the new host is in the group
    if test_Group_remove_host_host not in test_Group_remove_host_group.hosts:
        print("Error: test_host not in test_Group_remove_host_group")
        return 1
    # Call remove_host
    removed = test_Group_remove_host_group.remove_host(test_Group_remove_host_host)
    # Check that the host was removed

# Generated at 2022-06-24 19:44:51.231239
# Unit test for method add_host of class Group
def test_Group_add_host():
    g = Group()
    assert len(g.hosts) == 0
    h = MockHost()
    g.add_host(h)
    assert len(g.hosts) == 1
    assert h in g.hosts


# Generated at 2022-06-24 19:44:55.964592
# Unit test for method remove_host of class Group
def test_Group_remove_host():
    g = Group()
    h = Host('host1')
    g.add_host(h)
    assert(g.remove_host(h))
    assert(h.get_group() != g)


# Generated at 2022-06-24 19:45:02.516793
# Unit test for method add_child_group of class Group
def test_Group_add_child_group():
    group_1 = Group()
    group_2 = Group()
    group_3 = Group()
    group_4 = Group()
    group_5 = Group()
    group_6 = Group()

    group_1.add_child_group(group_2)
    group_2.add_child_group(group_3)
    group_3.add_child_group(group_4)
    group_4.add_child_group(group_5)

    assert group_1.child_groups == [group_2]
    assert group_2.child_groups == [group_3]
    assert group_3.child_groups == [group_4]
    assert group_4.child_groups == [group_5]

    assert group_2.parent_groups == [group_1]
    assert group_3.parent

# Generated at 2022-06-24 19:45:09.513457
# Unit test for function to_safe_group_name
def test_to_safe_group_name():
    test_name = 'ansible-group-name'
    result = to_safe_group_name(test_name)
    assert result == test_name, "Expecting %s, got %s" % (test_name, result)

    test_name = 'ansible-group-name-with-illegal-chars-%'
    result = to_safe_group_name(test_name)
    assert result == 'ansible-group-name-with-illegal-chars-_', "Expecting %s, got %s" % ('ansible-group-name-with-illegal-chars-_', result)


# Generated at 2022-06-24 19:45:11.982305
# Unit test for method add_host of class Group
def test_Group_add_host():
    group = Group()
    group.add_host(Host())



# Generated at 2022-06-24 19:45:20.993061
# Unit test for method remove_host of class Group
def test_Group_remove_host():
    group_0 = Group()
    group_1 = Group()
    group_2 = Group()
    group_3 = Group()
    group_4 = Group()
    group_5 = Group()
    group_6 = Group()
    group_7 = Group()
    group_8 = Group()
    group_9 = Group()
    group_10 = Group()
    group_11 = Group()
    group_12 = Group()
    group_13 = Group()
    group_14 = Group()
    group_15 = Group()
    group_16 = Group()
    group_17 = Group()
    group_18 = Group()
    group_19 = Group()
    group_20 = Group()
    group_21 = Group()
    group_22 = Group()
    group_23 = Group()
    group_24 = Group()

# Generated at 2022-06-24 19:45:24.636209
# Unit test for method add_host of class Group
def test_Group_add_host():
    test = Group()
    test.add_host('hello')
    assert test.hosts == ['hello']
    test.add_host('world')
    assert test.hosts == ['hello','world']

# Generated at 2022-06-24 19:45:34.518293
# Unit test for method add_child_group of class Group
def test_Group_add_child_group():
    test_group = Group()
    test_group2 = Group()
    test_group3 = Group()

    assert test_group.add_child_group(test_group2)
    assert test_group.add_child_group(test_group2) == False
    assert test_group2 in test_group.child_groups
    assert test_group2.parent_groups == [test_group]
    assert test_group.depth == 0
    assert test_group2.depth == 1

    assert test_group2.add_child_group(test_group3)
    assert test_group2.add_child_group(test_group3) == False
    assert test_group3 in test_group2.child_groups
    assert test_group3.parent_groups == [test_group2]

# Generated at 2022-06-24 19:45:42.368568
# Unit test for function to_safe_group_name
def test_to_safe_group_name():
    assert "a_b" == to_safe_group_name("a@b")
    assert "_" == to_safe_group_name("@")
    assert "abc" == to_safe_group_name("abc")
    assert "abc" == to_safe_group_name("abc", replacer="")
    assert "abc" == to_safe_group_name("abc", replacer="", force=True)
    assert "a@bc" == to_safe_group_name("a@bc", replacer="", force=True, silent=True)
    assert "a_bc" == to_safe_group_name("a@bc", replacer="_", force=True, silent=True)

if __name__ == "__main__":
    test_case_0()
    test_to_safe_group_name()

# Generated at 2022-06-24 19:45:56.872235
# Unit test for method remove_host of class Group
def test_Group_remove_host():
    group_0 = Group()
    group_1 = Group()
    group_0.add_child_group(group_1)
    group_2 = Group()
    group_1.add_child_group(group_2)
    group_3 = Group()
    group_2.add_child_group(group_3)
    group_4 = Group()
    group_2.add_child_group(group_4)
    group_5 = Group()
    group_2.add_child_group(group_5)
    group_6 = Group()
    group_1.add_child_group(group_6)
    group_7 = Group()
    group_0.add_child_group(group_7)
    group_8 = Group()
    group_7.add_child_group(group_8)

# Generated at 2022-06-24 19:45:58.121344
# Unit test for method add_host of class Group
def test_Group_add_host():
    group_0 = Group()
    group_0.add_host(host)


# Generated at 2022-06-24 19:46:01.178019
# Unit test for method remove_host of class Group
def test_Group_remove_host():
    group_0 = Group()
    host_0 = Host()
    group_0.add_host(host_0)
    group_0.remove_host(host_0)


# Generated at 2022-06-24 19:46:05.272417
# Unit test for method remove_host of class Group
def test_Group_remove_host():
    group_host = Group()
    group_host.add_host("host1")
    group_host.remove_host("host1")
    assert group_host.hosts == []


# Generated at 2022-06-24 19:46:07.836865
# Unit test for method add_host of class Group
def test_Group_add_host():
    group = Group()
    host = Host()
    assert group.add_host(host)
    assert not group.add_host(host)



# Generated at 2022-06-24 19:46:11.865880
# Unit test for method remove_host of class Group
def test_Group_remove_host():
    # Setup
    group_0 = Group()
    group_0.hosts = [None, None, None]
    group_0.hosts[0] = Host()
    group_0.hosts[1] = Host()
    group_0.hosts[2] = Host()
    group_0.hosts[2].name = 'host03'

    # Testing: Remove an host
    group_0.remove_host(group_0.hosts[2])
    assert group_0.hosts == [None, None], 'Created host list is not equal to [None, None]'


# Generated at 2022-06-24 19:46:17.689984
# Unit test for method remove_host of class Group
def test_Group_remove_host():
    test_group = Group()
    test_group.name = 'test_group'
    test_host = Host()
    test_host.name = 'test_host'
    added = test_group.add_host(test_host)
    test_group.remove_host(test_host)
    assert added == True and test_group.host_names == set()



# Generated at 2022-06-24 19:46:21.475945
# Unit test for method add_host of class Group
def test_Group_add_host():
    # create host and group
    host_0 = Host(name="host-0")
    group_0 = Group(name="group-0")

    # add host to group
    result = group_0.add_host(host_0)
    assert result == True
    assert host_0 in group_0.hosts



# Generated at 2022-06-24 19:46:30.598600
# Unit test for method add_host of class Group
def test_Group_add_host():

    group_0 = Group(name='name_0')
    host_0 = Host(name='name_0')
    host_1 = Host(name='name_1')
    host_2 = Host(name='name_2')
    assert group_0.host_names == set()
    assert group_0.hosts == []
    # assert group_0.hosts_by_name == {}
    group_0.add_host(host=host_0)
    assert group_0.host_names == {'name_0'}
    assert host_0 in group_0.hosts
    assert host_1 not in group_0.hosts
    assert host_2 not in group_0.hosts



# Generated at 2022-06-24 19:46:32.138839
# Unit test for method add_host of class Group
def test_Group_add_host():
    group_0 = Group()
    group_0.add_host(None)


# Generated at 2022-06-24 19:46:46.704532
# Unit test for method remove_host of class Group
def test_Group_remove_host():
    group0 = Group()
    group1 = Group()
    group0.add_child_group(group1)

    host0 = Host('ho0')
    host1 = Host('ho1')
    host2 = Host('ho2')
    host3 = Host('ho3')
    host4 = Host('ho4')
    host5 = Host('ho5')

    group0.add_host(host0)
    group0.add_host(host1)
    group0.add_host(host2)

    group1.add_host(host3)
    group1.add_host(host4)
    group1.add_host(host5)

    group0.remove_host(host0)
    group0.remove_host(host1)
    group0.remove_host(host2)

    group1

# Generated at 2022-06-24 19:46:55.634554
# Unit test for method remove_host of class Group
def test_Group_remove_host():
    group_1 = Group()
    group_2 = Group()
    host_0 = Host()
    host_1 = Host()
    host_2 = Host()
    host_3 = Host()
    host_4 = Host()
    host_5 = Host()
    host_6 = Host()
    group_1.add_child_group(group_2)
    group_2.add_host(host_0)
    group_2.add_host(host_1)
    group_2.add_host(host_2)
    group_2.add_host(host_3)
    group_2.add_host(host_4)
    group_2.add_host(host_5)
    group_2.add_host(host_6)

# Generated at 2022-06-24 19:47:05.106550
# Unit test for method add_host of class Group
def test_Group_add_host():

    host_01 = Host(name='host_01')
    host_02 = Host(name='host_02')
    host_03 = Host(name='host_03')

    group_01 = Group(name='group_01')
    group_02 = Group(name='group_02')

    group_01.add_host(host_01)
    group_01.add_host(host_02)
    group_01.add_host(host_03)

    assert host_01 in group_01.hosts
    assert host_02 in group_01.hosts
    assert host_03 in group_01.hosts

    group_02.add_host(host_01)

    assert host_01 in group_02.hosts



# Generated at 2022-06-24 19:47:07.831161
# Unit test for method remove_host of class Group
def test_Group_remove_host():
    group_1 = Group()
    group_2 = Group()
    group_3 = Group()
    host_1 = Host()
    host_2 = Host()
    host_3 = Host()

    pass


# Generated at 2022-06-24 19:47:10.314517
# Unit test for method remove_host of class Group
def test_Group_remove_host():
    group_0 = Group()
    group_0.hosts = []
    group_0.hosts.append("test")
    group_0.remove_host("test")
    assert len(group_0.hosts) == 0


# Generated at 2022-06-24 19:47:12.893754
# Unit test for method remove_host of class Group
def test_Group_remove_host():
    group_0 = Group()
    host_0 = group_0.Host(name="host_0")
    group_0.add_host(host=host_0)
    group_0.remove_host(host=host_0)
    return 1

# Generated at 2022-06-24 19:47:14.417595
# Unit test for method remove_host of class Group
def test_Group_remove_host():
    group_0 = Group()
    group_0.remove_host("fake_host_0")


# Generated at 2022-06-24 19:47:16.705619
# Unit test for function to_safe_group_name
def test_to_safe_group_name():
    assert to_safe_group_name('ansible') == 'ansible'
    assert to_safe_group_name('ansible.has(bugs)') == 'ansible_has_bugs_'

# Generated at 2022-06-24 19:47:24.380248
# Unit test for method add_host of class Group
def test_Group_add_host():
    """Validate behavior of Group.add_host method"""
    test_host_0 = Host('host_0')
    test_host_1 = Host('host_1')
    test_host_2 = Host('host_2')
    test_host_3 = Host('host_3')

    test_group_0 = Group()
    test_group_1 = Group()
    test_group_2 = Group()
    test_group_3 = Group()

    # test_group_0 has no hosts
    assert test_group_0.add_host(test_host_0)
    assert test_group_0.add_host(test_host_1)
    assert not test_group_0.add_host(test_host_1)

    # test_group_1 has no hosts
    assert test_group_1.add

# Generated at 2022-06-24 19:47:28.229375
# Unit test for method add_host of class Group
def test_Group_add_host():
    # test Group.add_host
    test_group = Group()
    test_host = Host('testhost')
    test_group.add_host(test_host)
    assert test_group == test_host.groups[0]
    assert test_host == test_group.hosts[0]


# Generated at 2022-06-24 19:47:45.876617
# Unit test for method remove_host of class Group
def test_Group_remove_host():
    group1 = Group()
    group2 = Group()
    host1 = Host()
    host2 = Host()

    assert group1.remove_host(host1) == False,     "remove_host should return False on first run"

    group1.add_host(host1)
    assert group1.remove_host(host1) == True,      "remove_host should return True on second run"

    group1.add_host(host1)
    group1.add_host(host2)
    group2.add_host(host2)
    group2.add_host(host1)
    group2.add_child_group(group1)
    group1.remove_host(host2)
    assert host2 in group2.get_hosts()
    assert host1 in group2.get_hosts()
   

# Generated at 2022-06-24 19:47:47.989494
# Unit test for method add_host of class Group
def test_Group_add_host():
    group_A = Group()
    host_0 = Host()
    added = group_A.add_host(host_0)
    assert(added == True)
    assert(len(group_A.hosts) == 1)


# Generated at 2022-06-24 19:47:57.401471
# Unit test for function to_safe_group_name
def test_to_safe_group_name():
    assert to_safe_group_name(C.DEFAULT_HOST_VARNAME) == 'ansible_host'
    assert to_safe_group_name(C.DEFAULT_GROUP_VARNAME) == 'ansible_group'
    assert to_safe_group_name('0') is not None
    assert to_safe_group_name(C.DEFAULT_HOST_INTERNAL_VARNAME) == 'ansible_host_internal'
    assert to_safe_group_name('ansible_host_internal') == 'ansible_host_internal'
    assert to_safe_group_name(C.DEFAULT_HOSTVARS_VARNAME) == 'ansible_group_hostvars'

# Generated at 2022-06-24 19:48:03.255571
# Unit test for method add_host of class Group
def test_Group_add_host():
    # create a group, then a couple hosts and add them to the group
    group_0 = Group()
    host_0 = Host(name='test_host_0')
    host_1 = Host(name='test_host_1')
    group_0.add_host(host_0)
    group_0.add_host(host_1)
    # ensure they were properly added
    assert(host_0 in group_0.hosts)
    assert(host_1 in group_0.hosts)
    assert(group_0 in host_0.groups)
    assert(group_0 in host_1.groups)


# Generated at 2022-06-24 19:48:04.110838
# Unit test for method remove_host of class Group
def test_Group_remove_host():
    test_case_0()


# Generated at 2022-06-24 19:48:11.336556
# Unit test for method remove_host of class Group
def test_Group_remove_host():
    # Assuming the create_group adds the host to the group
    # The host_to_add is the host object
    # The group_to_add is the group object
    # The host_to_add is not in the list of host in the group_to_add
    # The remove_host will remove the host_to_add from the group_to_add
    # The remove_host modifying the group_to_add.hosts list

    # Setup
    host_to_add = Host('external-node')
    group_to_add = Group('group-x')
    group_to_add.add_host(host_to_add)

    # Check Initialization
    assert len(group_to_add.hosts) == 1
    assert len(host_to_add.get_groups()) == 1

    # Invoke the method to

# Generated at 2022-06-24 19:48:17.138192
# Unit test for method remove_host of class Group
def test_Group_remove_host():
    group_0 = Group("group_0")
    group_0.add_host("host_1")
    result = group_0.remove_hos("host_2")
    assert False == result


# Generated at 2022-06-24 19:48:19.468675
# Unit test for method remove_host of class Group
def test_Group_remove_host():
    group_0 = Group()
    group_0.remove_host()
    assert group_0.hosts == []
