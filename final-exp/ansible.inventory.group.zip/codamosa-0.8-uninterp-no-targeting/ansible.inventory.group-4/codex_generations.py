

# Generated at 2022-06-20 14:57:49.983014
# Unit test for function to_safe_group_name
def test_to_safe_group_name():
    ''' Tests function to_safe_group_name, checking the following:
        - Behavior with bad characters in the name
        - Behavior with a "when" condition (should never replace)
        - Behavior with a "force" argument
        - Behavior with a "silent" argument
    '''
    name = "bad_name_|"
    transformed = to_safe_group_name(name, force=True)
    assert name != transformed
    assert transformed == 'bad_name__'

    name = "good_name"
    transformed = to_safe_group_name(name, force=True)
    assert name == transformed

    name = "bad_name_|"
    transformed = to_safe_group_name(name, force=False, silent=True)
    assert name != transformed
    assert transformed == 'bad_name__'

    name

# Generated at 2022-06-20 14:57:57.307303
# Unit test for method set_variable of class Group
def test_Group_set_variable():
    g = Group('test')
    g.set_variable('test', 'value')
    assert g.vars['test'] == 'value'
    g.set_variable('test', 'new_value')
    assert g.vars['test'] == 'new_value'
    g.set_variable('test', {'a': 'b'})
    assert g.vars['test'] == {'a': 'b'}
    g.set_variable('test', {'d': 'e'})
    assert g.vars['test'] == {'a': 'b', 'd': 'e'}
    g.set_variable('test', 'f')
    assert g.vars['test'] == 'f'


# Generated at 2022-06-20 14:58:09.176718
# Unit test for method add_host of class Group
def test_Group_add_host():
    from ansible.inventory.host import Host

    myhost = Host('host01')
    assert myhost.name == 'host01'
    assert myhost.groups == []

    mygroup = Group('group01')
    assert mygroup.name == 'group01'
    assert mygroup.hosts == []

    # test that host is added to group and group to host
    mygroup.add_host(myhost)
    assert mygroup.hosts == [myhost]
    assert myhost.groups == [mygroup]

    # make sure host is not added to group again
    assert mygroup.add_host(myhost) is False
    assert len(mygroup.hosts) == 1

    # make sure group is not added to host again
    assert myhost.add_group(mygroup) is False

# Generated at 2022-06-20 14:58:18.693554
# Unit test for function to_safe_group_name
def test_to_safe_group_name():
    # Get the function to test
    func = to_safe_group_name

    # Good values
    good_values = [u'valid-characters_123',
                   u'VALID-CHARACTERS_123',
                   ]
    for value in good_values:
        new_value = func(value)
        assert value == new_value

    # Bad values
    bad_values = [u'invalid-characters-!@#$%^&*()_+',
                  u'invalid-chars-in-start-!a',
                  u'invalid-chars-in-end_a!',
                  u'invalid-chars-in-middle-a!b',
                  ]

# Generated at 2022-06-20 14:58:22.992045
# Unit test for constructor of class Group
def test_Group():
    g = Group('testGroup')
    assert g is not None
    assert g.__class__.__name__ == 'Group'
    assert g.name == 'testGroup'
    assert g.hosts == []
    assert g.depth == 0
    assert g.vars == {}
    assert g.child_groups == []
    assert g.parent_groups == []
    assert repr(g) == "testGroup"
    assert str(g) == "testGroup"


# Generated at 2022-06-20 14:58:24.841817
# Unit test for method add_host of class Group
def test_Group_add_host():
    pass
#Unit test for method add_child_group of class Group

# Generated at 2022-06-20 14:58:35.048161
# Unit test for constructor of class Group

# Generated at 2022-06-20 14:58:36.721035
# Unit test for method __repr__ of class Group
def test_Group___repr__():
    group = Group(name='server')
    assert repr(group) == group.get_name()


# Generated at 2022-06-20 14:58:40.523460
# Unit test for method get_name of class Group
def test_Group_get_name():
    host1 = Group(name='host1')
    assert host1.name == 'host1'
    assert host1.get_name() == 'host1'

    host2 = Group(name=None)
    assert host2.name == None
    assert host2.get_name() == None


# Generated at 2022-06-20 14:58:48.618559
# Unit test for method get_ancestors of class Group
def test_Group_get_ancestors():
    a = Group('A')
    b = Group('B')
    c = Group('C')
    d = Group('D')
    e = Group('E')
    f = Group('F')

    a.add_child_group(d)
    b.add_child_group(d)
    c.add_child_group(d)
    c.add_child_group(e)
    d.add_child_group(f)
    e.add_child_group(f)

    assert f.get_ancestors() == {a, b, c, d, e}

# Generated at 2022-06-20 14:59:08.967343
# Unit test for method add_child_group of class Group
def test_Group_add_child_group():
    import pytest
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    # test_data is the format of a test case consisting of four elements:
    # 1: The Group to add children to (parent_group)
    # 2: The children to add to parent_group, a list of tuples:
    #    (Group to add, expected to succeed)
    # 3: The expected children of parent_group after all additions performed
    # 4: The expected parents of each Group in List 3

# Generated at 2022-06-20 14:59:18.765451
# Unit test for method get_descendants of class Group
def test_Group_get_descendants():
    a = Group('A')
    b = Group('B')
    c = Group('C')
    d = Group('D')
    e = Group('E')
    f = Group('F')
    g = Group('G')

    a.add_child_group(d)
    b.add_child_group(d)
    c.add_child_group(e)
    d.add_child_group(e)
    d.add_child_group(f)
    d.add_child_group(g)

    assert d.get_descendants(include_self=False) == set([e,f,g])
    assert d.get_descendants(include_self=True) == set([d,e,f,g])

    assert e.get_descendants(include_self=False) == set([])

# Generated at 2022-06-20 14:59:19.689202
# Unit test for method __repr__ of class Group
def test_Group___repr__():
    pass


# Generated at 2022-06-20 14:59:30.721138
# Unit test for function to_safe_group_name

# Generated at 2022-06-20 14:59:38.232765
# Unit test for method deserialize of class Group
def test_Group_deserialize():

    data = dict(vars=dict(a='b', c='d'))

    group_one = Group('group_one')
    group_two = Group('group_two')
    group_one.deserialize(data)
    group_two.deserialize(data)
    assert group_one.get_name() == 'group_one'
    assert group_two.get_name() == 'group_two'

    for k in group_one.get_vars():
        assert group_one.get_vars()[k] == group_two.get_vars()[k]

# Generated at 2022-06-20 14:59:47.657320
# Unit test for function to_safe_group_name
def test_to_safe_group_name():
    assert to_safe_group_name('group name') == 'group_name'
    assert to_safe_group_name('group-name') == 'group_name'
    assert to_safe_group_name('group; name') == 'group__name'
    assert to_safe_group_name('group, name') == 'group__name'
    assert to_safe_group_name('group/name') == 'group_name'
    assert to_safe_group_name('group@name') == 'group@name'
    assert to_safe_group_name('group$name') == 'group$name'

# Generated at 2022-06-20 14:59:58.904535
# Unit test for method get_hosts of class Group
def test_Group_get_hosts():
    # Create two hosts, one that is a member of all the groups, the other which is not
    test_hosts = {
        'host0': Host('host0'),
        'host1': Host('host1'),
    }
    # Create five groups, with the following relationships:
    # A: (A1, A2)
    # B: (A, B1, B2)
    # C: (A, C1)
    # D: (A, D1, D2)
    # E: (A, C, B, E1)

# Generated at 2022-06-20 15:00:02.025438
# Unit test for method serialize of class Group
def test_Group_serialize():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.vars import combine_vars

# Generated at 2022-06-20 15:00:07.483317
# Unit test for method set_priority of class Group
def test_Group_set_priority():
    print("Testing set_priority method on class Group")
    g=Group()
    g.set_priority(10)
    assert g.priority == 10
    print("set_priority works perfectly")
    print("")


# Generated at 2022-06-20 15:00:09.549657
# Unit test for method set_priority of class Group
def test_Group_set_priority():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    g = Group()
    g.set_priority(4)
    assert g.priority == 4



# Generated at 2022-06-20 15:00:17.012472
# Unit test for method serialize of class Group
def test_Group_serialize():
    group = Group(name='test_group_serialize')
    result = group.serialize()
    assert result['name'] == 'test_group_serialize'
    assert result['parent_groups'] == []
    assert result['depth'] == 0
    assert result['vars'] == {}
    assert result['hosts'] == []

# Generated at 2022-06-20 15:00:18.739872
# Unit test for method __repr__ of class Group
def test_Group___repr__():
    group = Group()
    group.name = 'test'
    assert group.__repr__() == group.get_name()

# Generated at 2022-06-20 15:00:27.268860
# Unit test for method get_ancestors of class Group
def test_Group_get_ancestors():
    g = Group(name='F')
    g.add_child_group(Group(name='D'))
    g.add_child_group(Group(name='E'))
    g.parent_groups.append(Group(name='B'))
    g.parent_groups.append(Group(name='C'))
    g.parent_groups[0].add_child_group(Group(name='A'))
    ancestors = g.get_ancestors()
    assert set(['A', 'B', 'C']) == set(map(Group.get_name, ancestors))



# Generated at 2022-06-20 15:00:36.612009
# Unit test for method set_priority of class Group
def test_Group_set_priority():
    class MockHost:
        def __init__(self, name):
            self.name = name
        def add_group(self, group):
            return
        def remove_group(self, group):
            return

    g = Group(name='mygroup')
    h = MockHost(name='myhost')
    g.add_host(h)

    # test different types of priorities
    # Expected resut:
    #   set_priority() should not raise exception
    #   priority should be casted to int
    test_cases = [
        ('3', 3),
        (3.0, 3),
        (u'4', 4)
    ]

    for priority, exp_priority_int in test_cases:
        g.set_priority(priority)
        assert g.priority == exp_priority_int

# Generated at 2022-06-20 15:00:39.556758
# Unit test for method get_name of class Group
def test_Group_get_name():
    g = Group()
    name = 'name'
    g.name = name
    assert name == g.get_name()


# Generated at 2022-06-20 15:00:50.699402
# Unit test for method clear_hosts_cache of class Group
def test_Group_clear_hosts_cache():

    from ansible.inventory.host import Host

    # Create groups and populate hosts
    all_group   = Group('all')
    alpha_group = Group('alpha')
    beta_group  = Group('beta')
    gamma_group = Group('gamma')
    for group in (alpha_group, beta_group, gamma_group):
        all_group.add_child_group(group)

    host_alpha_1 = Host('alpha_1')
    host_alpha_2 = Host('alpha_2')
    host_beta_1  = Host('beta_1')
    host_beta_2  = Host('beta_2')
    host_gamma_1 = Host('gamma_1')
    host_gamma_2 = Host('gamma_2')

# Generated at 2022-06-20 15:00:59.418390
# Unit test for method __setstate__ of class Group
def test_Group___setstate__():
    result = False
    try:
        # test with no name
        group_ = Group()
        group_.deserialize({})
        if (group_.name) and (group_.name == ''):
            # test with bad name
            group_.deserialize({
                'name': '1',
            })
            # test with good name
            if (group_.name) and (group_.name == '1'):
                # test with depth
                if (group_.depth) and (group_.depth == 0):
                    # test with hosts
                    if (group_.hosts):
                        result = True
    except Exception:
        pass
    # return the result
    return result


# Generated at 2022-06-20 15:01:10.909972
# Unit test for method set_variable of class Group
def test_Group_set_variable():
    class Host():

        def __init__(self, name):
            self.name = name
            self.vars = {}

        def add_group(self, group):
            pass

        def remove_group(self, group):
            pass

    host = Host("localhost")
    group = Group("test")
    group.add_host(host)
    group.set_variable("test_1", "1")
    group.set_variable("test_2", "2")
    group.set_variable("test_1", "3")
    group.set_variable("test_3", "4")
    assert(group.get_vars() == {'test_1': '3', 'test_2': '2', 'test_3': '4'})

# Generated at 2022-06-20 15:01:11.616783
# Unit test for method add_host of class Group
def test_Group_add_host():
    pass



# Generated at 2022-06-20 15:01:21.735009
# Unit test for method deserialize of class Group
def test_Group_deserialize():
    data = dict(
        name="test_group",
        vars=dict(
            test_var_1="test_var_1_val",
            test_var_2="test_var_2_val",
        ),
        parent_groups=[],
        depth=0,
        hosts=['1.1.1.1', '1.1.1.2', '1.1.1.3'],
    )

    g = Group()
    g.deserialize(data)

    assert g.name == "test_group"
    assert g.vars['test_var_1'] == "test_var_1_val"
    assert g.vars['test_var_2'] == "test_var_2_val"
    assert g.child_groups == []
    assert g.parent_groups == []

# Generated at 2022-06-20 15:01:37.514243
# Unit test for method get_vars of class Group
def test_Group_get_vars():

    class MockHost(object):
        def __init__(self, name, vars={}):
            self.name = name
            self.vars = vars

    # G1 has a variable that is a dictionary, we want to make sure we are doing a merge and not
    # replacing the dictionary with another dictionary.

    G1 = Group('g1')
    G2 = Group('g2')
    G3 = Group('g3')
    G4 = Group('g4')
    H1 = MockHost('h1', {'var1': 'foo'})
    H2 = MockHost('h2', {'var1': {'a': 1, 'b': 2}})
    H3 = MockHost('h3', {'var1': {'c': 3}})

    G1.add_child_group(G2)

# Generated at 2022-06-20 15:01:42.808210
# Unit test for method __getstate__ of class Group
def test_Group___getstate__():
    group = Group(name='fake_group')
    group.vars = dict()
    group.hosts = ['host1', 'host2', 'host3']
    assert group.__getstate__() == {'name': 'fake_group', 'vars': {}, 'parent_groups': [], 'depth': 0,
                                    'hosts': ['host1', 'host2', 'host3']}


# Generated at 2022-06-20 15:01:48.726811
# Unit test for function to_safe_group_name
def test_to_safe_group_name():
    assert to_safe_group_name('loan.local') == 'loan_local'
    assert to_safe_group_name(u'loan.local') == 'loan_local'
    assert to_safe_group_name('loan.local', replacer='-') == 'loan-local'
    assert to_safe_group_name(u'loan.local', replacer='-') == 'loan-local'

# Generated at 2022-06-20 15:01:51.424932
# Unit test for method set_variable of class Group
def test_Group_set_variable():
    g = Group('foo')
    g.set_variable('ansible_group_priority', '5')
    assert g.priority == 5

# Generated at 2022-06-20 15:02:01.024737
# Unit test for method add_host of class Group
def test_Group_add_host():
    group = Group()
    group.name = "test_Group"
    group.hosts = ["host1", "host2"]
    #hosts = group.hosts
    hosts = set(["host1","host2"])
    assert set(group.hosts) == hosts
    host = Host('host3')
    assert group.add_host(host)
    assert "host3" in group._hosts
    assert not group.add_host(host)
    assert set(group.hosts) == hosts.union({'host3'})
    assert group.remove_host(host)
    assert host.name not in group._hosts
    assert not group.remove_host(host)
    assert set(group.hosts) == hosts


# Generated at 2022-06-20 15:02:03.179790
# Unit test for method get_name of class Group
def test_Group_get_name():
    """
    Test get method of Group.get_name()
    """
    group = Group()
    return group.get_name()


# Generated at 2022-06-20 15:02:15.697847
# Unit test for method get_ancestors of class Group
def test_Group_get_ancestors():

    g_a = Group('A')
    g_b = Group('B')
    g_c = Group('C')
    g_d = Group('D')
    g_e = Group('E')
    g_f = Group('F')
    g_g = Group('G')
    g_h = Group('H')
    g_i = Group('I')

    g_a.add_child_group(g_b)
    g_a.add_child_group(g_c)
    g_a.add_child_group(g_f)
    g_b.add_child_group(g_d)
    g_c.add_child_group(g_d)
    g_d.add_child_group(g_e)

# Generated at 2022-06-20 15:02:23.751740
# Unit test for method get_ancestors of class Group
def test_Group_get_ancestors():

    # Construct a basic graph
    g1 = Group('g1')
    g2 = Group('g2')
    g3 = Group('g3')
    g4 = Group('g4')
    g5 = Group('g5')
    g6 = Group('g6')

    g1.add_child_group(g2)
    g1.add_child_group(g3)
    g2.add_child_group(g4)
    g3.add_child_group(g5)
    g4.add_child_group(g6)

    results = g6.get_ancestors()
    assert len(results) == 4
    assert 'g1' in results
    assert 'g2' in results
    assert 'g3' in results
    assert 'g4' in results

# Unit test

# Generated at 2022-06-20 15:02:31.564444
# Unit test for method deserialize of class Group
def test_Group_deserialize():
    deserialize_data = dict()
    deserialize_data['name'] = 'group'
    deserialize_data['vars'] = dict(a=1, b=2)
    deserialize_data['depth'] = 1
    deserialize_data['hosts'] = ['test']
    deserialize_data['parent_groups'] = list()

    group = Group()
    group.deserialize(deserialize_data)

    assert group.name == deserialize_data['name']
    assert group.vars == deserialize_data['vars']
    assert group.depth == deserialize_data['depth']
    assert group.hosts == deserialize_data['hosts']
    assert group.parent_groups == deserialize_data['parent_groups']

# Generated at 2022-06-20 15:02:33.300463
# Unit test for method __str__ of class Group
def test_Group___str__():
    test_name='test'
    test_group = Group(test_name)
    assert test_group.__str__() == 'test'


# Generated at 2022-06-20 15:02:45.303441
# Unit test for method get_ancestors of class Group
def test_Group_get_ancestors():

    g = Group()
    g2 = Group()
    g3 = Group()
    g4 = Group()

    g.add_child_group(g2)
    g2.add_child_group(g3)
    g2.add_child_group(g4)

    assert g.get_ancestors() == set([])
    assert g2.get_ancestors() == set([g])
    assert g3.get_ancestors() == set([g])
    assert g4.get_ancestors() == set([g])


# Generated at 2022-06-20 15:02:51.976733
# Unit test for constructor of class Group
def test_Group():
    g = Group('mygroup')
    assert isinstance(g, Group)
    assert g.get_name() == 'mygroup'
    assert g.get_hosts() == []
    assert g.get_vars() == {}
    assert g.parent_groups == []



# Generated at 2022-06-20 15:02:59.035169
# Unit test for method add_child_group of class Group
def test_Group_add_child_group():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    h1 = Host("h1")
    h2 = Host("h2")
    h3 = Host("h3")
    h4 = Host("h4")
    h5 = Host("h5")
    h6 = Host("h6")
    h7 = Host("h7")

    g1 = Group("g1")
    g2 = Group("g2")
    g3 = Group("g3")
    g4 = Group("g4")
    g5 = Group("g5")
    g6 = Group("g6")
    g7 = Group("g7")


# Generated at 2022-06-20 15:03:05.821859
# Unit test for method get_ancestors of class Group
def test_Group_get_ancestors():
    test_group = Group()

    test_parent1 = Group()
    test_parent2 = Group()
    test_child1 = Group()
    test_child2 = Group()

    test_group.add_child_group(test_child1)
    test_group.add_child_group(test_child2)
    test_child1.add_child_group(test_parent1)
    test_child2.add_child_group(test_parent2)

    assert test_parent1 in test_group.get_ancestors()
    assert test_parent2 in test_group.get_ancestors()
    assert len(test_group.get_ancestors()) == 2


# Generated at 2022-06-20 15:03:16.340747
# Unit test for method get_hosts of class Group
def test_Group_get_hosts():
    A = Group('A')
    B = Group('B')
    C = Group('C')

    h1 = MockHost('h1')
    h2 = MockHost('h2')
    h3 = MockHost('h3')
    h4 = MockHost('h4')
    h5 = MockHost('h5')
    h6 = MockHost('h6')
    h7 = MockHost('h7')

    A.add_host(h1)
    A.add_host(h2)

    B.add_host(h1)
    B.add_host(h3)
    B.add_host(h4)

    C.add_host(h2)
    C.add_host(h3)
    C.add_host(h5)
    C.add_host(h6)

# Generated at 2022-06-20 15:03:26.386323
# Unit test for method get_hosts of class Group
def test_Group_get_hosts():
    g1 = Group(name='g1')
    g2 = Group(name='g2')
    g3 = Group(name='g3')
    g4 = Group(name='g4')
    h1 = Group(name='h1')
    h2 = Group(name='h2')
    h3 = Group(name='h3')
    h4 = Group(name='h4')
    g1.add_child_group(g2)
    g2.add_child_group(g3)
    g3.add_child_group(g4)
    g1.add_host(h1)
    g2.add_host(h2)
    g3.add_host(h3)
    g4.add_host(h4)

# Generated at 2022-06-20 15:03:34.630741
# Unit test for method __setstate__ of class Group
def test_Group___setstate__():
    a = Group('a')
    b = Group('b')
    a.add_child_group(b)
    serialized = a.serialize()
    a.vars = {}
    a.depth = -1
    a.child_groups = []
    a.parent_groups = []
    a.hosts = []
    a.deserialize(serialized)
    if a.name != 'a':
        raise Exception('Failed test: expected `a`, got %s' % a.name)
    if a.depth != 1:
        raise Exception('Failed test: expected `1`, got %s' % a.depth)
    if a.child_groups[0].name != 'b':
        raise Exception('Failed test: expected `b`, got %s' % a.child_groups[0].name)
   

# Generated at 2022-06-20 15:03:40.968251
# Unit test for method get_ancestors of class Group
def test_Group_get_ancestors():
    '''
    Verify that all ancestors of a group are returned.
    '''
    a = Group(name='a')
    b = Group(name='b')
    c = Group(name='c')

    a.add_child_group(b)
    b.add_child_group(c)

    d = Group(name='d')
    e = Group(name='e')

    d.add_child_group(e)

    expected = set()
    expected.add(a)
    expected.add(b)
    assert expected == c.get_ancestors()

    f = Group(name='f')
    a.add_child_group(f)
    f.add_child_group(d)

    expected = set()
    expected.add(a)
    expected.add(b)
    expected

# Generated at 2022-06-20 15:03:50.351713
# Unit test for method get_ancestors of class Group
def test_Group_get_ancestors():
    A = Group(name="A")
    B = Group(name="B")
    C = Group(name="C")
    D = Group(name="D")
    E = Group(name="E")
    F = Group(name="F")

    # A   B    C
    # |  / |  /
    # | /  | /
    # D -> E
    # |  /    vertical connections
    # | /     are directed upward
    # F
    A.add_child_group(D)
    B.add_child_group(D)
    B.add_child_group(E)
    C.add_child_group(E)
    D.add_child_group(F)
    E.add_child_group(F)

    ancestors = F.get_ancestors()

# Generated at 2022-06-20 15:04:03.447947
# Unit test for function to_safe_group_name
def test_to_safe_group_name():

    assert to_safe_group_name("foo") == 'foo'
    assert to_safe_group_name("foo bar", replacer='_', force=False, silent=False) == 'foo_bar'
    assert to_safe_group_name("foo.bar", replacer='_', force=False, silent=False) == "foo_bar"
    assert to_safe_group_name("foo-bar", replacer='_', force=False, silent=False) == "foo_bar"
    assert to_safe_group_name("foo_bar:baz", replacer='_', force=False, silent=False) == "foo_bar_baz"
    assert to_safe_group_name("foo [bar]", replacer='_', force=False, silent=False) == "foo__bar_"
    assert to_safe

# Generated at 2022-06-20 15:04:23.145762
# Unit test for method set_variable of class Group
def test_Group_set_variable():
    group = Group('some_group')
    group.set_variable('some_var', 'some_value')
    assert(group.vars.get('some_var') == 'some_value')

    group.set_variable('some_var', 'updated_value')
    assert(group.vars.get('some_var') == 'updated_value')

    group.set_variable('some_var_with_dict_value', {'some_dict_key': 'some_dict_value'})
    assert(group.vars.get('some_var_with_dict_value') == {'some_dict_key': 'some_dict_value'})

    group.set_variable('some_var_with_dict_value', {'some_dict_key': 'updated_dict_value'})

# Generated at 2022-06-20 15:04:26.576638
# Unit test for method set_priority of class Group
def test_Group_set_priority():
    group = Group(name='test')
    assert group.priority == 1
    group.set_priority(4)
    assert group.priority == 4

# Generated at 2022-06-20 15:04:34.077350
# Unit test for constructor of class Group
def test_Group():

    assert Group().depth == 0
    assert Group().vars == {}
    assert Group().hosts == []
    assert Group().child_groups == []
    assert Group().parent_groups == []

    assert Group(name="foo").name == "foo"
    assert Group(name="foo").depth == 0
    assert Group(name="foo").vars == {}
    assert Group(name="foo").hosts == []
    assert Group(name="foo").child_groups == []
    assert Group(name="foo").parent_groups == []


# Generated at 2022-06-20 15:04:43.718783
# Unit test for method get_hosts of class Group
def test_Group_get_hosts():

    from ansible.inventory.host import Host

    g1 = Group('g1')
    g2 = Group('g2')
    g3 = Group('g3')
    g4 = Group('g4')
    g5 = Group('g5')

    h1 = Host('h1')
    h2 = Host('h2')
    h3 = Host('h3')
    h4 = Host('h4')
    h5 = Host('h5')
    h6 = Host('h6')
    h7 = Host('h7')

    g1.add_child_group(g2)
    g1.add_child_group(g3)
    g1.add_child_group(g4)

    g2.add_child_group(g5)

# Generated at 2022-06-20 15:04:50.444388
# Unit test for method get_vars of class Group
def test_Group_get_vars():
    g = Group('test')
    assert {} == g.get_vars()

    g.set_variable('foo', 'bar')
    assert {'foo': 'bar'} == g.get_vars()

    g.set_variable('foo', 'baz')
    assert {'foo': 'baz'} == g.get_vars()

    g.set_variable('foo', ['bar', 'baz'])
    assert {'foo': ['bar', 'baz']} == g.get_vars()


# Generated at 2022-06-20 15:04:59.606681
# Unit test for method deserialize of class Group
def test_Group_deserialize():

    data = {
        "name": "test",
        "vars": {
            "foo": "bar",
            "baz": "qux"
        },
        "depth": 0,
        "hosts": [
            "foo"
        ]
    }

    g = Group()
    g.deserialize(data)

    assert g.name == "test"
    assert g.vars == {'foo': 'bar', 'baz': 'qux'}
    assert g.depth == 0
    assert g.hosts == ['foo']
    assert g._hosts_cache == None

# Generated at 2022-06-20 15:05:04.889627
# Unit test for constructor of class Group
def test_Group():
    g = Group('foo')
    assert g.name == 'foo'
    assert g.vars == {}
    assert g.child_groups == []
    assert g.parent_groups == []



# Generated at 2022-06-20 15:05:12.878284
# Unit test for method serialize of class Group
def test_Group_serialize():
    grp1 = Group(name='test_group')
    grp1.add_host(Host('test_host1'))
    grp1.add_host(Host('test_host2'))
    grp1.set_variable('test_var', True)

    grp2 = Group(name='test_group2')
    grp2.add_host(Host('test_host1'))
    grp2.add_host(Host('test_host2'))
    grp2.set_variable('test_var2', 'test_val')

    grp3 = Group(name='test_group3')
    grp3.add_host(Host('test_host1'))
    grp3.add_host(Host('test_host2'))

# Generated at 2022-06-20 15:05:26.617566
# Unit test for method add_child_group of class Group
def test_Group_add_child_group():
    g1 = Group(name='g1')
    g2 = Group(name='g1')
    g3 = Group(name='g3')
    g4 = Group(name='g4')
    g5 = Group(name='g5')
    g6 = Group(name='g6')
    g1.add_child_group(g2)
    g1.add_child_group(g3)
    g3.add_child_group(g4)
    g3.add_child_group(g5)
    assert g1 not in g2.child_groups
    assert g1 in g3.child_groups
    assert g3 in g4.child_groups
    assert g3 in g5.child_groups
    assert g1 not in g4.child_groups

# Generated at 2022-06-20 15:05:35.276149
# Unit test for method add_host of class Group
def test_Group_add_host():
    test_group = Group()
    test_host1 = Host()
    test_host2 = Host()

    test_group.add_host(test_host1)
    test_group.add_host(test_host2)

    # test
    assert_equal(len(test_group.hosts), 2)
    assert_equal(test_group.host_names, set(['localhost', 'test_play.test_host']))
    assert_equal(test_group.hosts, [test_host1, test_host2])
    assert_equal(test_host1.get_groups()[0], test_group)
    assert_equal(test_host2.get_groups()[0], test_group)



# Generated at 2022-06-20 15:06:09.688998
# Unit test for method deserialize of class Group
def test_Group_deserialize():
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager

    my_group = Group(name="test_group")
    child_group = Group(name="test_child_group")
    # group_id is used to prevent duplicates when serialization
    my_group.group_id = 3
    my_host = Host(name="test_host")
    my_host.host_id = 4
    vars_manager = VariableManager()

    my_host.set_variable('ansible-var1', 'var1')
    my_host.set_variable('ansible-var2', 'var2')

    my_group.vars = {'group-var1': 'gvar1'}

# Generated at 2022-06-20 15:06:21.610486
# Unit test for method remove_host of class Group
def test_Group_remove_host():
    import unittest

    class TestGroup(Group):
        def __init__(self, name=None):
            super(TestGroup, self).__init__(name)

        def remove_host(self, host):
            super(TestGroup, self).remove_host(host)

    class TestHost:
        def __init__(self):
            self.groups = []

        def add_group(self, group):
            self.groups.append(group)

        def remove_group(self, group):
            self.groups.remove(group)

    class TestCase(unittest.TestCase):
        def test_remove_host(self):
            group = TestGroup('group')
            host = TestHost()
            group.add_host(host)
            self.assertEqual(group.hosts, [host])
           

# Generated at 2022-06-20 15:06:29.195266
# Unit test for method __setstate__ of class Group
def test_Group___setstate__():
    g = Group()
    name = 'GroupTest'
    vars = {}
    g.name = name
    g.vars = vars
    state = g.__getstate__()

    g.__setstate__(state)

    assert(g.vars == vars)
    assert(g.name == name)


# Generated at 2022-06-20 15:06:39.534703
# Unit test for method get_descendants of class Group
def test_Group_get_descendants():
    """
    Test for method get_descendants
    """
    # Build the following tree
    # A   B    C
    # |  / |  /
    # | /  | /
    # D -> E
    # |  /    vertical connections
    # | /     are directed upward
    # F
    # Called on F, returns set of (A, B, C, D, E)
    A = Group('A')
    B = Group('B')
    C = Group('C')
    D = Group('D')
    E = Group('E')
    F = Group('F')
    A.add_child_group(D)
    B.add_child_group(E)
    C.add_child_group(E)
    D.add_child_group(F)
    E.add_child_

# Generated at 2022-06-20 15:06:44.269463
# Unit test for method remove_host of class Group
def test_Group_remove_host():
    g = Group('foo')
    h1 = Host('h1')
    h2 = Host('h2')
    h3 = Host('h3')
    g.add_host(h1)
    g.add_host(h2)
    g1 = Group('g1')
    g2 = Group('g2')
    g1.add_child_group(g2)
    g1.add_host(h3)
    g.add_child_group(g1)

    g.remove_host(h1)

    assert h1 not in g.hosts
    assert h2 in g.hosts
    assert h3 in g.hosts
    assert h1 not in g1.hosts
    assert h2 not in g1.hosts
    assert h3 in g1.hosts


# Unit

# Generated at 2022-06-20 15:06:54.144902
# Unit test for constructor of class Group
def test_Group():

    # Test when name is None
    g1 = Group()
    assert g1.name == ''
    assert g1.hosts == []
    assert g1.child_groups == []
    assert g1.parent_groups == []
    assert g1._hosts_cache is None
    
    # Test when name is not None
    g2_name = 'x'
    g2 = Group(g2_name)
    assert g2.name == g2_name
    assert g2.hosts == []
    assert g2.child_groups == []
    assert g2.parent_groups == []
    assert g2._hosts_cache is None

    # Test for the serialize() function
    g1_serialized = g1.serialize()
    assert g1_serialized['name'] == ''
    assert g1_

# Generated at 2022-06-20 15:07:02.436530
# Unit test for method get_ancestors of class Group
def test_Group_get_ancestors():
    a = Group('A')
    b = Group('B')
    c = Group('C')
    d = Group('D')
    e = Group('E')
    f = Group('F')

    for a_b in [
        (a, b),
        (b, c),
        (c, e),
        (d, e),
        (d, f)]:
        a_b[0].add_child_group(a_b[1])

    test = d.get_ancestors()
    assert(len(test) == 2)
    for item in [a, e]:
        assert(item in test)
