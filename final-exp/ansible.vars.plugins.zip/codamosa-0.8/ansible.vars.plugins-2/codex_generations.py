

# Generated at 2022-06-11 19:13:49.724026
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    import glob
    import inspect
    import os

    import ansible.plugins
    from ansible.plugins import vars
    from ansible.plugins.loader import vars_loader

    from ansible.errors import AnsibleError

    class MockHost(object):
        def __init__(self, name):
            self.name = name

    class MockPlugin(object):
        REQUIRES_WHITELIST = False

        def get_vars(self, loader, path, entities):
            pass
        get_host_vars = get_vars
        get_group_vars = get_vars

    vars_plugins_dir = os.path.join(os.path.dirname(inspect.getabsfile(ansible.plugins)), 'vars')

# Generated at 2022-06-11 19:13:51.976782
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    assert get_vars_from_inventory_sources("my_loader", ["my_source"], "my_entities", "my_stage") == {}



# Generated at 2022-06-11 19:13:56.667436
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager
    loader = InventoryManager('localhost')
    path = '/'
    entities = []
    stage = 'inventory'

    data = get_vars_from_path(loader, path, entities, stage)
    assert type(data) is dict

# Generated at 2022-06-11 19:14:02.694598
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import test_vars_plugin
    t = AnsibleCollectionRef.from_string('ansible.builtin.test_vars_plugin')
    plugin = vars_loader.get(t)
    path = os.path.dirname(test_vars_plugin.__file__)
    s = 'test_get_plugin_vars'
    assert plugin.get_vars(None, path, s) == {'test_get_plugin_vars': {'result': 'test_get_plugin_vars'}}


# Generated at 2022-06-11 19:14:12.966618
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.vars import vars_cache as vars_cache_module
    from ansible.plugins.vars.host_group_vars import HostGroupVars

    plugin_list = list(vars_loader.all())
    # Add host_group_vars plugin to plugin list
    plugin_list.append(HostGroupVars())
    # Add vars_cache plugin to plugin list
    plugin_list.append(vars_cache_module)

    import ansible_collections

    try:
        cwd = os.getcwd()
    except:
        cwd = None

    # Force os.getcwd() to temp directory
    with mock.patch('os.getcwd', return_value='/tmp'):
        for plugin in plugin_list:
            plugin.set_options()

    #

# Generated at 2022-06-11 19:14:20.498925
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.cli.galaxy import GalaxyCLI
    path = GalaxyCLI.display_paths('/etc/ansible/hosts')
    sources = [path]

    # test host vars
    loader, entities, all_vars = get_vars_from_inventory_sources(sources, ['host1'], 'host_group_vars')

    # test group vars
    loader, entities, all_vars = get_vars_from_inventory_sources(sources, ['host_group1'], 'group_vars/all')

# Generated at 2022-06-11 19:14:31.757560
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory import Inventory, Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host_pattern import HostPattern
    from ansible.utils.vars import combine_vars
    from ansible.plugins.inventory.ini import InventoryModule

    def load_inventory(loader, sources):
        '''
        Load inventory from one or more inventory files
        '''
        filenames = []
        for source in sources:
            if os.path.isfile(source):
                filenames.append(source)
            elif os.path.isdir(source):
                filenames.extend(InventoryModule()._load_from_directory(source))

# Generated at 2022-06-11 19:14:38.361119
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    assert get_vars_from_path(None, '/path', ['host1', 'host2'], 'inventory') == {'host1': {'vars1': 'var1'}, 'host2': {'vars2': 'var2'}}
    assert get_vars_from_path(None, '/path', ['group1', 'group2'], 'inventory') == {'group1': {'vars1': 'var1'}, 'group2': {'vars2': 'var2'}}
    assert get_vars_from_path(None, '/path', 'host1', 'inventory') == {'vars1': 'var1'}
    assert get_vars_from_path(None, '/path', 'host2', 'inventory') == {'vars2': 'var2'}


# Generated at 2022-06-11 19:14:42.001430
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    loader = None
    path = '.'
    entities = []
    stage = None
    vars = get_vars_from_path(loader, path, entities, stage)
    assert vars



# Generated at 2022-06-11 19:14:51.685715
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    plugin_list = list(vars_loader.all())
    for plugin_name in C.VARIABLE_PLUGINS_ENABLED:
        if AnsibleCollectionRef.is_valid_fqcr(plugin_name):
            plugin = vars_loader.get(plugin_name)
            if plugin is None:
                # Error if there's no play directory or the name is wrong?
                continue
            if plugin not in plugin_list:
                plugin_list.append(plugin)

# Generated at 2022-06-11 19:15:03.858510
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    # Test case 1: Wrappers
    data = get_vars_from_path('/tmp/', 'group_var', 'host_var')
    assert isinstance(data, dict)

    # Test case 2: Valid plugin
    data = get_vars_from_path('/tmp/', 'my_group', 'my_host')
    assert isinstance(data, dict)

# Generated at 2022-06-11 19:15:09.492114
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    # Create fake plugin
    class FakePlugin():

        _load_name = 'test_plugin'

        def get_vars(self, loader, path, entities):
            return {'fake_result': 'test_result'}

    plugin = FakePlugin()

    ret_val = get_plugin_vars(None, plugin, None, None)
    assert ret_val == {'fake_result': 'test_result'}


# Generated at 2022-06-11 19:15:16.568263
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    def assertion(self, objs):
        assert objs == {'test_var': 1}
    from ansible.plugins.vars.vars import VarsModule as VarsPlugin
    from ansible.plugins.loader import vars_loader
    vars_plugin = VarsPlugin()
    vars_plugin._load_name = "vars_plugin"
    vars_plugin.get_vars = assertion
    vars_loader.add(vars_plugin, "vars_plugin")
    loader = None
    path = "test_path"
    entities = ["test_entity"]
    assert get_plugin_vars(loader, vars_plugin, path, entities) == {'test_var': 1}

# Generated at 2022-06-11 19:15:26.587598
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars.facts import VarsModule as vars_facts_module
    from ansible.plugins.vars.vault import VarsModule as vars_vault_module
    from ansible.plugins.vars.k8s import VarsModule as vars_k8s_module
    from ansible.vars.manager import VariableManager

    mock_loader = {'paths': [os.path.join(os.getcwd(), 'vars_plugins/')]}
    mock_entities = []

    # test vars_facts plugin
    data = get_plugin_vars(mock_loader, vars_facts_module, 'vars_plugins/', mock_entities)

# Generated at 2022-06-11 19:15:38.156915
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    variable_manager.extra_vars = {'foobar': 'asdf'}

    data = get_vars_from_path(loader, '', [inventory.hosts['localhost'], inventory.groups['all']], 'task')

    assert data['inventory_dir'] == '.'
    assert data['inventory_file'] == 'localhost,'
    assert data['inventory_file_relpath'] == 'localhost,'
    assert 'foo' not in data

# Generated at 2022-06-11 19:15:47.444671
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = vars_loader
    groups = [Group('all'), Group('group1'), Group('group2')]
    hosts = [Host('host1'), Host('host2'), Host('host3')]
    path = ''


    def get_plugin_vars(loader, plugin, path, entities):
        if plugin._load_name == 'vars/group_vars.yml':
            data = {'vars': {'test_key': 'test_group_vars'}}
        else:
            data = {}

        return data
    plugin_get_vars = get_plugin_vars


# Generated at 2022-06-11 19:15:59.243531
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['test/inventory/dynamic/'])
    inventory.parse_sources()
    group = inventory.groups['group1']
    host = inventory.get_host('localhost')

    expected = {'group1_plugin_group_var': 'group1', 'group1_plugin_host_var': 'host1'}
    assert get_plugin_vars(loader, inventory.variable_manager._vars_plugins['test_plugins.group_vars_plugin'], 'test/inventory/dynamic/', [group]) == expected

# Generated at 2022-06-11 19:16:05.795191
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugins
    plugin = vars_plugins.get(C.DEFAULT_VARS_PLUGIN)
    if plugin and hasattr(plugin, 'get_vars'):
        # Requires a path to be passed
        assert get_plugin_vars(None, plugin, "./test_get_plugin_vars", []) == {}

# Generated at 2022-06-11 19:16:07.262207
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert isinstance(get_vars_from_path(), dict)

# Generated at 2022-06-11 19:16:14.083812
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.data import InventoryData

    loader = DataLoader()
    sources = './test/integration/vars_plugins'
    inv_data = InventoryData(loader=loader, sources=sources)
    inventory = InventoryManager(loader=loader, sources=sources)
    variables = VariableManager(loader=loader, inventory=inventory)

    stage = 'inventory'
    data = get_vars_from_path(loader, sources, inv_data.get_hosts(), stage)
    assert data['plugin_vars_inventory.yml']['key'] == 'value'

# Generated at 2022-06-11 19:16:27.383854
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    from ansible.inventory.manager import InventoryManager
    from ansible_collections.community.general.plugins.inventory.ini import InventoryModule as IniInventoryModule

    display.verbosity = 3

    inventory_source = 'tests/unit/inventory_test/test_group_vars_plugins/inventory'
    plugin_vars_source = 'tests/unit/inventory_test/test_group_vars_plugins/group_vars'

    loader = IniInventoryModule.loader_class()
    loader.set_inventory(InventoryManager(loader=loader, sources=inventory_source))

    group_list = ['group3', 'group1', 'group2']
    inventory_entities = []

    for group in group_list:
        inventory_entities.append(loader.inventory.groups[group])

    vars_from_

# Generated at 2022-06-11 19:16:37.910105
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars.test_vars import VarsModule as TestPlugin1
    from ansible.plugins.vars.test_vars import VarsModule2 as TestPlugin2
    from ansible.plugins.loader import vars_loader
    from ansible.utils.collection_loader import AnsibleCollectionRef

    vars_loader.add(AnsibleCollectionRef('/dummy_path/vars.collection/ansible_collections/test_ns/test_coll/plugins/vars'))
    vars_loader.add(TestPlugin1)
    vars_loader.add(TestPlugin2)

    from ansible.inventory.manager import InventoryManager

    inventory_file = os.path.join(os.path.dirname(__file__), '../data/inventory.yml')
    inv_manager = Inventory

# Generated at 2022-06-11 19:16:41.268732
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    assert get_vars_from_path(None, '/home/testuser/ansible/ansible', ['testhost'], 'task') == {}

    # This is default setting for RUN_VARS_PLUGINS, so it should return the plugins
    assert get_vars_from_path(None, '/home/testuser/ansible/ansible', ['testhost'], 'inventory')['inventory_file'] == '/home/testuser/ansible/ansible/hosts'

# Generated at 2022-06-11 19:16:44.884572
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    loader, entities, path = None, None, './ansible/playbooks'

    data = get_vars_from_path(loader, path, entities, 'task')

    assert data

# Generated at 2022-06-11 19:16:49.235914
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    path1 = "/my/fake/path/file"
    vars_plugin_list = [get_vars_from_path(path1, 'update')]
    vars_plugin_list[0] = 'a'

    assert (vars_plugin_list[0] == 'a')


# Generated at 2022-06-11 19:16:58.352546
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # test valid data
    plugin_data = [
        {
            '_load_name': 'fake',
            'get_vars': lambda a, b, c: {'fake': 'data'}
        },
        {
            '_load_name': 'fake1',
            'get_vars': lambda a, b, c: {'fake1': 'data'}
        },
        {
            '_load_name': 'fake2',
            'get_host_vars': lambda a: {'fake2': 'host_data'},
            'get_group_vars': lambda a: {'fake2': 'group_data'}
        }
    ]


# Generated at 2022-06-11 19:17:09.162261
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    import json
    import os
    from ansible.plugins.loader import vars_loader
    from ansible.utils.collection_loader import AnsibleCollectionRef
    from ansible.utils.vars import combine_vars

    name = 'test_vars_plugin'

    if AnsibleCollectionRef.is_valid_fqcr(name):
        plugin = vars_loader.get(name)
    else:
        plugin = vars_loader.get(name)

    path = os.path.join(os.path.dirname(__file__), "../../../test/test_plugin_vars/")
    data = {}
    entities = {'host':['a', 'b']}
    data = get_plugin_vars(vars_loader, plugin, path, entities)

# Generated at 2022-06-11 19:17:20.686566
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=None, host_list='/path/to/host_list')

    # Test the 'host' stage
    with open('tests/data/host_stage.yml', 'r') as test_file:
        host_stage_vars = yaml.safe_load(test_file)

    # Test the 'task' stage
    with open('tests/data/task_stage.yml', 'r') as test_file:
        task_stage_vars = yaml.safe_load(test_file)

    assert get_vars_from_path(loader, '/path/to/vars_plugin', [inventory], 'host') == host

# Generated at 2022-06-11 19:17:31.252504
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    display = Display()

    test_plugin_path = os.path.join(os.path.dirname(__file__), 'vars_plugins')

    def get_plugin_list():
        return [x._load_name for x in vars_loader.all()]

    # test vars_loader functionality
    plugin_names = get_plugin_list()
    assert 'test_vars_plugin' in plugin_names
    plugin = vars_loader.get('test_vars_plugin')
    assert plugin is not None

# Generated at 2022-06-11 19:17:36.169975
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    ''' plugin_utils.get_plugin_vars() returns data for group_vars for passed entity.

    :return:
    '''
    loader, plugin, path, entities = False, False, False, False
    assert get_plugin_vars(loader, plugin, path, entities) == {}


# Generated at 2022-06-11 19:17:55.246819
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    import os
    test_dir = os.path.dirname(os.path.realpath(__file__))
    test_dir = os.path.join(test_dir, 'test_get_vars_from_path')
    if not os.path.isdir(test_dir):
        # if this test isn't run from the default ansible repo location then
        # we need to go back in the directory tree until we find test/units
        # and then cd into the test_vars directory from there
        find_test_dir = os.path.dirname(test_dir)
        while not os.path.isdir(os.path.join(find_test_dir, 'test', 'units', '__init__.py')):
            find_test_dir = os.path.dirname(find_test_dir)
       

# Generated at 2022-06-11 19:17:57.243209
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert get_vars_from_path('loader', 'path', ['entities'], 'stage') == {}

# Generated at 2022-06-11 19:18:05.405057
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    TESTS = {
        'group_vars': True,
        'host_vars': True,
        'global': False,
    }

    for test_name, groups in TESTS.items():
        assert test_name

        class Plugin(object):
            def __init__(self, test_name, groups):
                self.test_name = test_name
                self.groups = groups

            def get_group_vars(self, group):
                assert not self.groups
                return {'test_name': self.test_name}

            def get_host_vars(self, host):
                assert self.groups
                return {'test_name': self.test_name}


# Generated at 2022-06-11 19:18:14.760555
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    # Mock some variables
    inventory_file = '/Users/testuser/inventory.yml'
    group_name = 'test_group'
    host_name = 'test_host'

    # Create test Host/Group
    test_group = Group(group_name)
    test_host = Host(host_name)

    # Create a test plugin
    class TestVarsPlugin:
        def get_vars(self, loader, path, entities):
            return {
                'test_key': 'test_value',
            }

    # Mock the loader to return our test plugin
    loader.vars_loader = {
        'test_plugin': TestVarsPlugin()
    }

    # Call get_vars_from_path, and assert

# Generated at 2022-06-11 19:18:22.650315
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    loader = None
    # sources = [b"localhost"]
    # sources = [b"localhost:1234"]
    # sources = [b"localhost,apps1"]
    sources = [b"/etc/ansible/hosts"]
    # sources = [b"/etc/ansible/hosts:1234"]
    # sources = [b"/etc/ansible/hosts,apps1"]

    # TODO: load entities
    entities = []
    stage = "inventory"
    get_vars_from_inventory_sources(loader, sources, entities, stage)

# Generated at 2022-06-11 19:18:29.828867
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Import needed modules.
    import os
    import sys
    from ansible.parsing.utils.addresses import parse_address
    from ansible.plugins import vars_loader, config_loader

    # Set up the environment for testing.
    test_fqpn = os.path.join(os.path.dirname(__file__), 'vars_from_path/')
    fake_config_file = os.path.join(os.path.dirname(__file__), 'fakedata/fake_config.yml')
    fake_vars_file = os.path.join(os.path.dirname(__file__), 'fakedata/fake_vars.yml')

    # Set up the loader and Set the sys.path so we only collect the 'testing' plugins.
    loader = vars_loader

# Generated at 2022-06-11 19:18:38.260752
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    class MockVarsPlugin(object):
        def __init__(self):
            self._load_name = 'Test'
            self._original_path = 'Test'
        def get_vars(self, *args, **kwargs):
            return {'foo': 'bar'}

    class MockLoader(object):
        def all(self):
            return [MockVarsPlugin()]

    class MockEntity(object):
        def __init__(self, name):
            self.name = name

    loader = MockLoader()

    assert get_plugin_vars(loader, MockVarsPlugin(), None, [MockEntity('host')]) == {'foo': 'bar'}



# Generated at 2022-06-11 19:18:49.097062
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    inventory_sources = '/home/ansible/playbooks/inventory/hosts,127.0.0.1'
    test_host = Host('test')
    test_host.name = 'test_host'
    test_host.vars = {'test_item':'test_value'}
    test_host.groups = ['test_group']
    dummy_loader = vars_loader.__all__.copy()
    test_loader = vars_loader.copy()
    test_loader._module_cache.update(dummy_loader)
    test_loader.get_plugin_by_name('test_plugin')
    test_loader.plugins._module_cache['test_plugin'] = {}
    test_loader.plugins._module_cache['test_plugin']['plugin'] = 'plugin'
    test_loader.plugins

# Generated at 2022-06-11 19:18:58.551201
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    #
    # Test #1: Check basic path exists
    #

    loader_mock = mock.Mock()
    plugin_mock = mock.Mock()
    mock_vars = {'var1': 'val1'}
    plugin_mock.get_vars.return_value = mock_vars
    loader_mock.all.return_value = [plugin_mock]
    entities_mock = []
    path_mock = '/plugins/path'

    vars = get_vars_from_path(loader_mock, path_mock, entities_mock, 'start')

    assert vars == mock_vars



# Generated at 2022-06-11 19:19:08.823347
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    import ansible.plugins.loader as plugin_loader
    loader = plugin_loader.PluginLoader(
        'vars',
        'ansible.plugins.vars',
        C.config.get_config_value('DEFAULT_VARS_PLUGIN_PATH'))

    yaml_content = """
all:
    ntp_server:
        - ntp1.example.com
        - ntp2.example.com

p1:
    ntp_server:
        - ntp1.p1.example.com
        - ntp2.p1.example.com
    p1_only: test

p2:
    ntp_server:
        - ntp1.p2.example.com
        - ntp2.p2.example.com
    p2_only: test
"""

   

# Generated at 2022-06-11 19:19:37.523367
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    import os
    import shutil
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.vars.plugins.group_vars import GroupVars

    test_dir = os.path.join(os.path.curdir, 'test_path')
    test_group = os.path.join(test_dir, 'group_vars')
    test_file = os.path.join(test_group, 'all')

    if not os.path.exists(test_dir):
        os.makedirs(test_dir)

    if not os.path.exists(test_group):
        os.makedirs(test_group)


# Generated at 2022-06-11 19:19:42.970183
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    loader = None
    path = '/home/ansible_user/ansible_project/playbooks/roles/vars_plugin/vars'
    group = None
    host = None
    stage = 'task'

    assert type(get_vars_from_path(loader, path, [group, host], stage)) == dict
    assert get_vars_from_path(loader, path, [group, host], stage) == {}

# Generated at 2022-06-11 19:19:54.624862
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    import ansible.plugins.loader as ploader
    loader = ploader.get_all_plugin_loaders()

    from ansible.inventory import Inventory
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    inv_path = '/var/lib/awx/projects/test_dir/test_inv'

    group1 = 'group1'
    group2 = 'group2'
    group3 = 'group3'
    group4 = 'group4'

    host1 = 'host1'
    host2 = 'host2'
    host3 = 'host3'

    # create inventory groups
    inv = Inventory(loader=DataLoader())
    # create

# Generated at 2022-06-11 19:19:55.153435
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    pass

# Generated at 2022-06-11 19:20:02.186838
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.path import unfrackpath
    from ansible.utils.display import Display
    from ansible.playbook.play_context import PlayContext

    from units.mock.loader import DictDataLoader


# Generated at 2022-06-11 19:20:09.260972
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    from ansible.utils.path import unfrackpath
    from ansible.vars.plugins.facts import FactsPlugin

    from units.mock.loader import DictDataLoader


# Generated at 2022-06-11 19:20:14.506331
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    plugin = vars_loader.get("from_group_vars")
    loader = None
    path = None
    entities = ['test']
    stage = 'inventory'
    result = get_vars_from_path(loader, path, entities, stage)
    assert result == get_plugin_vars(loader, plugin, path, entities)


# Generated at 2022-06-11 19:20:21.191527
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    def get_vars_from_path_run(loader, path, entities, stage):
        return to_bytes(get_vars_from_path(loader, path, entities, stage))

    # test: no plugin
    assert {} == get_vars_from_path_run(None, '/tmp', [], 'inventory')

    # test: no vars
    class fakeplugin:
        @staticmethod
        def get_vars(loader, path, entities):
            return {}
    assert {} == get_vars_from_path_run(None, '/tmp', [], 'inventory', fakeplugin)

    # test: no attribute error
    class fakeplugin:
        @staticmethod
        def get_vars(loader, path, entities):
            raise AttributeError

# Generated at 2022-06-11 19:20:29.707007
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    # Setup vars plugins and loader
    loader = None
    from ansible.plugins.vars import vars_plugins
    plugin_list = vars_plugins.all(loader)
    for plugin in plugin_list:
        plugin._load_name = plugin._load_name.split('.')[-1]

    path = 'resources/test_inventory_vars_plugins'
    entities = []


# Generated at 2022-06-11 19:20:33.033327
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    '''
    This function is used to test the get_vars_from_path() function
    '''
    assert get_vars_from_path(None, "/path/to/dir", Host('hostname.example.com'), 'inventory') == {}

# Generated at 2022-06-11 19:21:16.421963
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    pass

# Generated at 2022-06-11 19:21:25.708193
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    loader = {}

    # Create an object of the class Host()
    host_obj = Host(name='localhost')

    # Create an object of the class Group()
    group_obj = Group(name='group1')

    # Create an object of the class Group()
    group_obj_1 = Group(name='group2')

    # Create a list that contains the object of Host and Group
    entities = [host_obj, group_obj, group_obj_1]

    # Test case 1:
    # Plugin with functions get_vars and run
    class Test_get_vars():
        def get_vars(self, loader, path, entities):
            return {'vars': 'value'}

        def run(self):
            return {'test': 'value'}

    plugin = Test_get_vars()


# Generated at 2022-06-11 19:21:36.118961
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.plugins.loader import plugin_loader

    # test vars_loader.py
    display.verbosity = 3
    my_var_manager = VariableManager()
    my_inventory = InventoryManager(loader=None, sources='localhost,')

    my_play = Play().load({
        'hosts': 'localhost',
        'connection': 'local',
        'gather_facts': 'no',
        'tasks': [
            {'debug': {'msg': '{{foo}}'}}
        ]
    }, variable_manager=my_var_manager, loader=plugin_loader)

    # call function get_vars_from_path
    data = get_v

# Generated at 2022-06-11 19:21:37.511580
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert get_vars_from_path(None, None, None, None) == {}

# Generated at 2022-06-11 19:21:47.512173
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    plugin_file = os.path.join(os.path.dirname(__file__),
                               'test_vars_plugins/test_vars_plugin.py')
    loader = vars_loader.get('{0} {1}'.format(
                             C.DEFAULT_VARS_PLUGIN_PATH, plugin_file))
    assert loader is not None

    path = os.path.join(os.path.dirname(__file__), 'test_vars_plugins')

    entities = []
    host = Host('host')
    host.vars = {}
    entities.append(host)

    stage = 'task'

    data = get_vars_from_path(loader, path, entities, stage)
    assert data == {'var1': 'value1'}

# Generated at 2022-06-11 19:21:57.974421
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    """
    Unit test for function get_vars_from_path
    """
    from ansible import context
    from ansible_collections.ansible.builtin.plugins.vars import host_group_vars
    from ansible.plugins.loader import vars_loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext

    context.CLIARGS = {}
    vars_loader.add(host_group_vars.HostGroupVarsModule())
    loader = DataLoader()
    play_context_obj = PlayContext()
    inventory_sources_list = ['/Users/ansible/mycode/ansible-testing/internal-testing/mock_inventory.yml']
    entities = ['group_name']

    result = get_

# Generated at 2022-06-11 19:22:00.730051
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    assert get_vars_from_path(None, '/home/user/hosts', [], 'inventory') == {}

    # Unit test for function get_vars_from_inventory_sources

# Generated at 2022-06-11 19:22:10.678261
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    import ansible.inventory.loader

    loader = ansible.inventory.loader.AnsibleInventoryLoader()
    entities = [Host(name='test')]

    # Test when C.RUN_VARS_PLUGINS == 'all'
    C.RUN_VARS_PLUGINS = 'all'
    C.VARIABLE_PLUGINS_ENABLED = []

    ret = get_vars_from_path(loader, '/etc', entities, 'task')
    assert(ret is not None)

    # Test when C.RUN_VARS_PLUGINS == 'start'
    C.RUN_VARS_PLUGINS = 'start'
    C.VARIABLE_PLUGINS_ENABLED = []


# Generated at 2022-06-11 19:22:21.466945
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.parsing.dataloader import DataLoader

    inventory_src_dir = os.path.dirname(__file__) + "/../../../plugins/inventory"
    inventory_src = os.path.normpath(inventory_src_dir) + os.sep + "test_hosts_list"
    sources = [inventory_src]
    loader = DataLoader()
    loader.set_basedir('/tmp')
    entity = 'test'
    entities = [entity]
    stage = 'inventory'

    plugin_vars = get_vars_from_path(loader, inventory_src, entities, stage)
    assert "list_var" in plugin_vars
    assert "host_var" in plugin_vars
    assert plugin_vars["list_var"] == "list_var_value"


# Generated at 2022-06-11 19:22:31.493840
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import vars_loader

    vars_loader.add('sample_vars_plugin', lambda *a,**kw: dict(sample='vars'))

    inventory = InventoryManager(loader=None)
    inventory._sources = [None, '/nonexistent', 'ansible.cfg', 'tests/test_inventory/sample_hosts.ini']
    assert get_vars_from_inventory_sources(None, inventory._sources, ['example'], 'task') == {'sample': 'vars'}

    del vars_loader._vars_plugins['sample_vars_plugin']

# Generated at 2022-06-11 19:23:22.984767
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.utils.collection_loader import AnsibleCollectionRef

    plugins = vars_loader.all()
    assert AnsibleCollectionRef.is_valid_fqcr('test_namespace.test_collection.test_vars_plugin')
    ansible_plugin = next(plugin for plugin in plugins if plugin._load_name == 'test_namespace.test_collection.test_vars_plugin')
    assert ansible_plugin.get_vars('loader', 'path', []) == {'foo': 1}

# Generated at 2022-06-11 19:23:29.567939
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from unittest import TestCase

    class TestVars(object):

        def __init__(self, name):
            self.name = name

        def get_vars(self, loader, path, entities):
            data = {}
            for entity in entities:
                data.update({'%s_data' % entity.name: 42})
            return data

        def get_host_vars(self, host):
            return {'host_vars_%s' % host: 43}

        def get_group_vars(self, group):
            return {'group_vars_%s' % group: 44}

    class TestVars2(object):

        def __init__(self, name):
            self.name = name

        def get_vars(self, loader, path, entities):
            data = {}