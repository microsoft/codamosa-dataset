

# Generated at 2022-06-11 19:13:56.079776
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    class MockSourceData:
        def __init__(self, name, extension, content):
            self.name = name
            self.path = "%s.%s" % (name, extension)
            self.size = len(content)
            self.content = content
            self.mode = 0o444

    class MockSourceDir:
        def __init__(self, name, contents):
            self.name = name
            self.path = name
            self.size = len(contents)
            self.mode = 0o555
            self.isdir = True
            self.contents = content

        def iterdir(self):
            for v in self.contents:
                yield v

    class MockSourceFileSystem:
        def __init__(self, contents):
            self.contents = contents


# Generated at 2022-06-11 19:14:03.905484
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager
    inv = InventoryManager(loader=None, sources=['localhost,', 'other,', 'group,'])
    loader = None

    path = './test/units/plugins/vars'

    group_vars = get_vars_from_path(loader, path, inv.get_groups(), 'inventory')
    expected_group_vars = {
        'all': {'test_var': 5},
        'group': {'test_var': 4},
        'group:child': {'test_var': 3},
        'group:child:grandchild': {'test_var': 2},
        'group:child:grandchild:greatgrandchild': {'test_var': 1}
    }
    assert group_vars == expected_group_vars

    host_vars

# Generated at 2022-06-11 19:14:10.584488
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    import ansible.parsing.dataloader
    from units.mock.loader import DictDataLoader
    # Loader needs to contain a variable_manager for this to work
    mock_loader = DictDataLoader({}, variable_manager=ansible.parsing.dataloader.DataLoader({}))
    assert get_vars_from_inventory_sources(mock_loader, [], [], '') == {}
    # TODO: Add tests for vars plugins

# Generated at 2022-06-11 19:14:21.967627
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    import pytest

    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    vault = VaultLib(None)

    sources = ['tests/vars/test1', 'tests/vars/test2']
    entities = [Host(name='host1'), Host(name='host2'), Group(name='host2')]

    # test with no plugins in the path
    data = get_vars_from_inventory_sources(loader, sources, entities, stage='inventory')
    assert data == {}

    # test with plugins in the path

# Generated at 2022-06-11 19:14:33.126364
# Unit test for function get_vars_from_inventory_sources

# Generated at 2022-06-11 19:14:34.144208
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # TODO
    pass


# Generated at 2022-06-11 19:14:35.764259
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert get_vars_from_path(None, '.', None, 'start') == {}

# Generated at 2022-06-11 19:14:46.108026
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    import ansible.plugins.loader as plugin_loader
    import ansible.plugins.vars.test as test_plugin

    # Mock the loader to return our test plugin by name
    plugin_loader.vars_loader = plugin_loader.PluginLoader('Ansible.plugins.vars',
                                                           'VarsModule',
                                                           C.DEFAULT_INVENTORY_SOURCES,
                                                           'ansible.plugins.vars',
                                                           'vars_plugins',
                                                           'VarsModule',
                                                           ['.py'])
    plugin_loader.vars_loader._modules = {'vars_plugins': {'test': test_plugin}}

    # Set the plugin up to only run for the inventory stage
    test_plugin.stage = 'inventory'

    #

# Generated at 2022-06-11 19:14:57.109813
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    # which variables are available before and after are handled by the mock and not by the function
    src = 'path/to/inventory/src'

    data = {
        'first': 'foo',
        'second': 'bar',
        'third': 'baz',
        'fourth': 'qux',
        'fifth': 'quux'
    }

    sources = [src]
    entities = ['host1', 'host2', 'host3', 'host4', 'host5']
    stage = 'inventory'

    result = get_vars_from_inventory_sources(None, sources, entities, stage)

    # always return a dict
    assert isinstance(result, dict)
    assert result == data, "Got %s Expected %s" % (result, data)

# Generated at 2022-06-11 19:15:04.726756
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert 'example_one' in get_vars_from_path(None, './test/units/vars/group_vars', ('all',), 'inventory')
    assert 'example_two' in get_vars_from_path(None, './test/units/vars/group_vars', ('all',), 'inventory')
    assert 'example_three' in get_vars_from_path(None, './test/units/vars/group_vars', ('all',), 'inventory')

# Generated at 2022-06-11 19:15:25.263015
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    loader, entities, path = None, None, 'path'
    vars_plugin_list = []
    collected_data = {}

    # Testing when plugin is not in C.VARIABLE_PLUGINS_ENABLED
    vars_plugin_list.append(vars_loader.get('copy'))
    collected_data = get_vars_from_path(loader, path, entities, 'task')
    assert collected_data == {}

    # Testing when plugin is in C.VARIABLE_PLUGINS_ENABLED
    C.VARIABLE_PLUGINS_ENABLED.append('copy')
    collected_data = get_vars_from_path(loader, path, entities, 'task')
    assert isinstance(collected_data, dict)
    C.VARIABLE_PLUGINS

# Generated at 2022-06-11 19:15:37.193916
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    plugin_name = 'vars_test'
    plugin_path = '/path/to/plugin'
    host_name = 'testhost'
    group_name = 'testgroup'

    # Test v2 API
    plugin_v2 = FakeVarsPluginV2(plugin_name, plugin_path)
    host = Host(host_name)
    group = FakeGroup(group_name)

    try:
        result = get_plugin_vars(None, plugin_v2, None, [host, group])
    except AnsibleError:
        raise AssertionError("Invalid use of vars plugin v2 API")

    assert isinstance(result, dict)
    assert result == {'v2_host': host.name, 'v2_group': group.name}

    # Test v1 API
    plugin_v1 = Fake

# Generated at 2022-06-11 19:15:46.624642
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Set up test fixtures
    display.verbosity = 0  # quiet down ansible logging
    plugin_list = list(vars_loader.all())
    for plugin in plugin_list:
        try:
            os.unlink(plugin._original_path)
        except OSError:
            pass

    C.VARIABLE_PLUGINS_ENABLED = ['test_plugin']
    vars_plugin = vars_loader.get('test_plugin')
    assert(vars_plugin)

    # Run the code being tested
    data = get_vars_from_path(None, None, None, None)

    # Verify the results
    assert(data == {'test_plugin': 'Test Plugin'})

    # Clean up test fixtures

# Generated at 2022-06-11 19:15:56.275025
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    '''Does get vars from path work?'''

    import ansible.plugins.vars.bones
    test_plugin = ansible.plugins.vars.bones.VariablesModule()

    from ansible.plugins.loader import vars_loader
    vars_loader.add(test_plugin, 'test_plugin')

    import ansible.inventory.host
    test_hosts = ansible.inventory.host.Host("localhost")

    test_data = get_vars_from_path("/", [test_hosts], 'task')
    assert "test_plugin" in test_data.keys()

# Generated at 2022-06-11 19:16:07.408015
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    from ansible_collections.ansible.community.tests.unit.mock import MagicMock

    def mock_get_vars(loader, path, entities):
        return {"mocked_key": "mocked_value"}
    def mock_get_vars_error(loader, path, entities):
        raise AttributeError()

    # Test for success
    mocked_plugin = MagicMock()
    mocked_plugin.get_vars = mock_get_vars
    mocked_plugin._load_name = "test_vars_plugin_success"
    mocked_plugin._original_path = "test/path"
    result = get_vars_from_path(None, None, None, None, [mocked_plugin])
    assert result == {"mocked_key": "mocked_value"}

    # Test for AttributeError

# Generated at 2022-06-11 19:16:13.864345
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    from ansible.vars.unsafe_proxy import wrap_var

    v = wrap_var(get_vars_from_path)
    # Test for plugin vars with VarsPluginV2 instance function get_vars.
    assert v.get_vars.__name__ == 'get_vars'

    # Test for plugin vars with get_host_vars and get_group_vars.
    assert v.get_host_vars.__name__ == 'get_host_vars'
    assert v.get_group_vars.__name__ == 'get_group_vars'

    # Test for plugin vars with VarsModule instance function run.
    assert v.run.__name__ == 'run'

# Generated at 2022-06-11 19:16:23.989754
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    import types
    import ansible.plugins.vars
    import itertools

    # The most simple vars plugin
    class VarsPlugin(object):
        def get_vars(self, loader, path, entities):
            return {'a': 1}

    # The deprecated vars plugin
    class OldVarsPlugin(object):
        def get_host_vars(self, hostname):
            return {'b': 2}

    class HybridVarsPlugin(VarsPlugin, OldVarsPlugin):
        pass

    class HybridVarsPlugin2(OldVarsPlugin, VarsPlugin):
        pass

    class OldBadVarsPlugin(object):
        def get_host_vars(self, hostname):
            return {'a': 1}


# Generated at 2022-06-11 19:16:32.797092
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    vars_plugin = object()
    for plugin in vars_loader.all():
        if plugin._load_name == 'yaml':
            vars_plugin = plugin
    loader = object()
    assert_result = {'test_key': 'test_value'}
    path = '../test/test_vars_dir/dir_inventory.yml'
    host_vars = [Host('test_host1'), Host('test_host2'), Host('test_host3')]
    group_vars = [object(), object()]

    # Test get host vars
    assert get_plugin_vars(loader, vars_plugin, path, host_vars) == assert_result

    # Test get group vars

# Generated at 2022-06-11 19:16:33.302451
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    pass

# Generated at 2022-06-11 19:16:40.900288
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    loader = vars_loader
    test_path = "/home/user1/ansible/plugins/vars/file.yml"
    test_vars = {'test_var': 'test_var_value'}
    test_dummy_plugin = DummyVarsPlugin(loader, "testplugin", test_vars, test_path)
    loader._vars_plugins[test_dummy_plugin.file_name] = test_dummy_plugin
    test_entities = []
    test_entities.append(Host(name='test_host1'))
    test_entities.append(Host(name='test_host2'))
    test_stage = 'start'

# Generated at 2022-06-11 19:16:54.038018
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    '''
    :return:
    '''
    _result = dict()
    _loader = dict()
    _path = dict()
    _entities = dict()
    _stage = dict()

    # get_plugin_vars
    from ansible.plugins.vars import vars_plugins
    from ansible.plugins.vars import HostVars
    from ansible.plugins.vars import GroupVars

    _plugin = vars_plugins.get('hostname')
    _mock_get_vars = dict()
    _result = _mock_get_vars
    _result = get_plugin_vars(_loader, _plugin, _path, _entities)


    _result = dict()
    _plugin = vars_plugins.get('host')
    _mock_get_host_vars

# Generated at 2022-06-11 19:16:58.187675
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # the key for plugin '@fake_collection/fake_plugin' is missing in C.VARIABLE_PLUGINS_ENABLED, so the plugin is not loaded.
    assert get_vars_from_path(None, 'mock_path', [], 'mock_stage') == {}

# Generated at 2022-06-11 19:17:00.675323
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # TODO: unit test
    pass


# Generated at 2022-06-11 19:17:10.240814
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import module_utils_loader
    from ansible.plugins.loader import test_utils
    from ansible.plugins.loader import modules_loader

    loader = module_utils_loader.ModuleUtilsLoader()
    test_utils.set_loader(loader)
    loader.set_module_utils_caching(False)

    modules_loader.add_directory(os.path.join(os.path.dirname(__file__), 'test_vars_plugin'))

    plugin = vars_loader.get('test_vars_plugin.test_plugin')
    plugin.get_vars = ('get_plugin_vars', None, False)
    plugin.get_host_vars = ('get_host_vars', None, False)

# Generated at 2022-06-11 19:17:21.538749
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    def get_vars(loader, path, entities):
        return {'a': 1, 'b': 2}

    class VarsPlugin():
        def get_vars(self, loader, path, entities):
            return {'a': 1, 'b': 2}

    loader = [VarsPlugin()]
    assert get_plugin_vars(loader, get_vars, '/etc', ['/etc']) == {'a': 1, 'b': 2}

    class VarsPlugin1():
        def get_host_vars(self, hostname):
            return {'a': 1, 'b': 2}

    assert get_plugin_vars(loader, VarsPlugin1(), '/etc', ['host1']) == {'a': 1, 'b': 2}


# Generated at 2022-06-11 19:17:31.741087
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    try:
        from ansible.plugins.vars.test_vars_plugin import TestVarsPlugin
    except ImportError as e:
        import pytest
        pytest.skip("test_vars_plugin is not available: %s" % to_bytes(e))

    try:
        from ansible.plugins.vars.lookup_plugins.test_lookup import TestLookupPlugin
    except ImportError as e:
        import pytest
        pytest.skip("test_lookup is not available: %s" % to_bytes(e))

    p = TestVarsPlugin()
    p._load_name = 'test_vars'
    p._original_path = 'test_vars'
    p.init()
    data = get_plugin_vars({}, p, '/tmp/', ['foo'])
   

# Generated at 2022-06-11 19:17:42.969716
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars.facts import VarsModule as RealVarsModule
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    class FakeVarsModule(RealVarsModule):
        """Replacement for FactsModule that doesn't require an Inventory to run"""
        def get_vars(self, loader, path, entities):
            return {'test-var': 'test-val'}

    vars_loader._vars_collection.get.return_value = FakeVarsModule()

    host = Host('some-host')
    group = Group('some-group')
    loader = Host('some-loader')

    # Test with get_vars

# Generated at 2022-06-11 19:17:53.321340
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.errors import AnsibleError

    class VarsPlugin(object):
        def get_plugin_vars(self, loader, path, entities):
            return {'a': 1}

    get_plugin_vars(None, VarsPlugin(), None, None)

    class VarsPlugin(object):
        def get_host_vars(self, host):
            return {'b': 2}

    get_plugin_vars(None, VarsPlugin(), None, [object()])

    class VarsPlugin(object):
        def get_group_vars(self, host):
            return {'c': 3}

    get_plugin_vars(None, VarsPlugin(), None, [object()])

    class VarsPlugin(object):
        def run(self):
            pass


# Generated at 2022-06-11 19:18:03.572781
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.utils.display import Display
    from ansible import context
    from ansible.plugins.vars import BaseVarsPlugin

    class TestPlugin(BaseVarsPlugin):
        """This is a dummy plugin used for tests"""

        def process_tasks(self, tasks):
            # returning unused var, just to make this look more realistic
            return {'hello': 'world'}

    class TestLoader:
        class _TestFileParser:
            """This is a dummy parser used for tests"""
            def get_basedir(self):
                return '.'

        def __init__(self):
            self.parser = self._TestFileParser()

    class TestHost:
        def __init__(self, name):
            self.name = name


# Generated at 2022-06-11 19:18:12.415070
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources(): # pylint: disable=protected-access
    # pylint: disable=unused-argument
    class MockPlugin:
        REQUIRES_WHITELIST = False
        def get_vars(self, loader, path, entities):
            return {'vars': {'test': '1'}}

    plugin = MockPlugin()
    vars_loader._all.append(plugin) # pylint: disable=protected-access
    sources = ['/path/to/inventory']
    entities = ['localhost']
    stage = 'start'
    expected_data = {'test': '1'}
    data = get_vars_from_inventory_sources(None, sources, entities, stage)
    vars_loader._all.remove(plugin) # pylint: disable=protected-access

# Generated at 2022-06-11 19:18:29.413726
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    test_data = {
        '__ansible_facts__': {},
        'JINJA2_CONSTANTS': {},
        'JINJA2_GLOBALS': {},
        'hostvars': {}
    }
    plugin_results = {
        'test': {'test_key': 'test_value'}
    }
    expected_result = {
        '__ansible_facts__': {},
        'JINJA2_CONSTANTS': {},
        'JINJA2_GLOBALS': {},
        'hostvars': {},
        'test': {'test_key': 'test_value'}
    }

    test_plugin = lambda plugin, loader, path, entities: plugin_results[plugin._load_name]

    data = get_vars_from_path

# Generated at 2022-06-11 19:18:36.497146
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    import ansible.plugins.vars.vault
    import ansible.plugins.vars.yaml

    ansible.plugins.vars.vault.REQUIRES_WHITELIST = False
    ansible.plugins.vars.yaml.REQUIRES_WHITELIST = False

    loader = "loader"
    path = "/path"
    hosts = [Host("host1"), Host("host2")]
    stage = "inventory"
    data = get_vars_from_path(loader, path, hosts, stage)

    assert len(data) == 0

# Generated at 2022-06-11 19:18:38.340761
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    data = get_vars_from_path({}, '/path/to/dir', [], 'all')
    assert data == {}

# Generated at 2022-06-11 19:18:45.257007
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader

    # Role is not a vars plugin. Make sure we don't get vars from it
    vars_plugin_list = list(vars_loader.all())
    for plugin in vars_plugin_list:
        if plugin._load_name == 'role':
            vars_plugin_list.remove(plugin)

    assert len(get_vars_from_path(None, './test/units/vars_plugins/vars_plugins_dir', [], None)) == 0

# Generated at 2022-06-11 19:18:47.723970
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert get_vars_from_path(None, 'inv', None, None) == {}

# Generated at 2022-06-11 19:18:58.395398
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    loader = None
    inventory_manager = InventoryManager(loader=loader)

# Generated at 2022-06-11 19:19:08.748133
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=DataLoader(), sources=['tests/units/vars_plugins/inventory_01'])

    # Test with a single host and a single group
    host_01 = inventory.get_host(hostname="host_01")
    group_all = inventory.get_group(groupname="all")
    group_linux = inventory.get_group(groupname="linux")
    group_bsd = inventory.get_group(groupname="bsd")

    # Mock a global vars_plugin

# Generated at 2022-06-11 19:19:15.099610
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    path = 'host_vars'
    loader = None
    entities = []
    stage = ''
    display.verbosity = 1
    plugin_name = 'win_domain_membership'
    vars_plugin_list = list(vars_loader.all())
    for i in vars_plugin_list:
        if i._load_name == plugin_name:
            data = get_plugin_vars(loader, i, path, entities)
            assert "{'ansible_domain': 'ansible.local'} "\
                   == str(data), 'when there is a variable'
    return data



# Generated at 2022-06-11 19:19:24.770984
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Create a mock vars plugin
    class MockVarsPlugin():
        def get_vars(self, loader, path, entities):
            return {'var_py': 'value_py', 'var_yml': 'value_yml'}
        def get_host_vars(self, host):
            return {'var_host': 'value_host'}
        def get_group_vars(self, group):
            return {'var_group': 'value_group'}

    # Create a loader and add the mock plugin.
    loader = vars_loader.PluginLoader()
    loader.add(MockVarsPlugin, 'mock_vars_plugin')

    # Get the mock plugin, and test it.
    for plugin_name in loader.all():
        plugin = loader.get(plugin_name)
       

# Generated at 2022-06-11 19:19:36.263440
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    '''
    Makes sure get_vars_from_path combined vars properly
    '''
    data = {}
    vars_plugin_list = list(vars_loader.all())
    for plugin_name in C.VARIABLE_PLUGINS_ENABLED:
        if AnsibleCollectionRef.is_valid_fqcr(plugin_name):
            vars_plugin = vars_loader.get(plugin_name)
            if vars_plugin is None:
                continue
            if vars_plugin not in vars_plugin_list:
                vars_plugin_list.append(vars_plugin)


# Generated at 2022-06-11 19:19:56.212972
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    loader = vars_loader

    class MockEntity:
        def __init__(self, name):
            self.name = name
        def __repr__(self):
            return self.name

    # Mock entity list
    entities = [MockEntity('group1'), MockEntity('group2'), MockEntity('host1')]

    # Mock arguments
    sources = [None, ',']
    stage = 'start'

    # Mock function
    def mock_get_vars_from_path(loader, path, entities, stage):
        '''
        Returns a dict containing the name of file from which the args
        are called.
        '''
        return {'path': path}

    data = get_vars_from_inventory_sources(loader, sources, entities, stage, mock_get_vars_from_path)


# Generated at 2022-06-11 19:20:02.790447
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    def mock_plugin_constructor(plugin_name, original_path, class_name=None, config=C.config, subdir=None):
        class MockVarsPlugin():
            _load_name = plugin_name
            _original_path = original_path
            REQUIRES_WHITELIST = True

            @staticmethod
            def get_vars(loader, path, entities):
                return {'vars%s' % plugin_name: True, plugin_name: plugin_name}

        return MockVarsPlugin()

    def mock_plugin_module(plugin_name, original_path, class_name=None, config=C.config, subdir=None):
        class MockVarsPlugin():
            _load_name = plugin_name
            _original_path = original_path
            REQUIRES_WHITEL

# Generated at 2022-06-11 19:20:04.837559
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    plugin_list = list(vars_loader.all())
    for plugin in plugin_list:
        get_vars_from_path(None, None, None, None)

# Generated at 2022-06-11 19:20:10.656992
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # variables defined in the global inventory
    global_vars_content = """
[athens:children]
greeks
trojans
"""
    # variables defined in group_vars/greeks.yml
    group_vars_greeks_content = """
[greeks:vars]
achilles_status=alive
"""
    # variables defined in group_vars/trojans.yml
    group_vars_trojans_content = """
[trojans:vars]
hector_status=dead
"""
    # passing entities that are members of the groups greeks and trojans
    global_vars_path = "/dev/null/inventory/global_vars"

# Generated at 2022-06-11 19:20:19.213923
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    import os
    import sys
    import shutil
    import tempfile
    import json
    import ansible.plugins.vars.test_vars_plugin as test_vars_plugin
    TESTS_DIR = os.path.dirname(os.path.realpath(__file__))
    FIXTURES_DIR = os.path.join(TESTS_DIR, 'fixtures', 'test_variable_plugins')
    sys.path.insert(0, FIXTURES_DIR)
    plugins = [os.path.basename(path) for path in os.listdir(FIXTURES_DIR)]


# Generated at 2022-06-11 19:20:28.346523
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    """This test is only validating the logic of the function and its
    usage in the code. It does not actually validate the run of the
    plugins."""

    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    hosts = inventory.groups['all']
    path = '/some/sources/path'
    stages = ['inventory', 'task']

    for stage in stages:
        # Global setting 'all'
        C.RUN_VARS_PLUGINS = 'all'
        get_vars_from_path(loader, path, hosts, stage)

        # Global setting 'demand'
        C.RUN_VARS_PLUGINS = 'demand'
       

# Generated at 2022-06-11 19:20:31.597570
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    loader = None
    path = None
    entities = []
    stage = None
    result = get_vars_from_path(loader, path, entities, stage)
    assert result == {}

# Generated at 2022-06-11 19:20:36.051256
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    sources = [
        'tests/units/plugins/inventory/test_inventory_vars/inventory.yml',
        'tests/units/plugins/inventory/test_inventory_vars/inventory.ini',
        'tests/units/plugins/inventory/test_inventory_vars/inventory.ini',
        'localhost,192.168.0.1,ec2-1-1-1-1.compute-1.amazonaws.com',
    ]
    inventory = InventoryManager(loader, sources)

    # host1 has both vars in host var and inventory var
    host1 = inventory.get_host('host1')

# Generated at 2022-06-11 19:20:45.144377
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager

    sources = ['../../test/integration/inventory/inventory_file']
    inventory = InventoryManager(loader=None, sources=sources)
    host_1 = inventory.get_host('192.168.1.2')
    host_2 = inventory.get_host('192.168.1.3')
    group_1 = inventory.get_group('group1')
    group_2 = inventory.get_group('group2')
    group_3 = inventory.get_group('group3')


# Generated at 2022-06-11 19:20:54.491961
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.vars import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader

    options = {'inventory': './test/units/vars/hosts',
               'subset': 'host_with_vars',
               'ask_vault_pass': False}
    loader = DataLoader()
    inventory = InventoryManager(loader, options, sources=options['inventory'])

    entities = [Host(name='test', port=22),
                inventory.get_group('test_group')]

    # inventory.get_group('test_group') should return a group object. Its vars should be {}.
    # Host(name='test', port=22) should return a Host object with vars {

# Generated at 2022-06-11 19:21:15.069101
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # TODO: Fix vars_plugins_unit_test to not assume a specific vars plugin
    #       configuration.  It should not be hardcoded to no plugins or assume
    #       the existence of vars_plugins/subdir/{ansible_distribution}.py

    # TODO: Fix vars_plugins_unit_test to not assume a specific vars plugin
    #       configuration.  It should not be hardcoded to no plugins or assume
    #       the existence of vars_plugins/subdir/{ansible_distribution}.py

    # Mock out a loader object
    loader_mock = type('LoaderMock', (object,), {})()

    # Test using a None for a path
    assert get_vars_from_path(loader_mock, None, [], 'inventory') == {}


# Generated at 2022-06-11 19:21:25.427337
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import collect_plugin_vars
    sys_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'lib')
    assert sys_path in C.DEFAULT_MODULE_PATH
    vars_loader.add_directory(sys_path, with_subdir=True)
    loader = collect_plugin_vars()
    path = os.path.dirname(os.path.dirname(__file__))
    entities = [1, 2]
    stage = 'inventory'
    data = get_vars_from_path(loader, path, entities, stage)

    assert data.get('test_get_vars_from_path') == 'success'
    assert data.get('test_get_vars_from_inventory_sources')

# Generated at 2022-06-11 19:21:32.426706
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import testvars
    host = Host('host')
    data = get_plugin_vars(None, testvars, None, [host])
    assert data == {'testvars_plugin_host': 'host'}

    group = Host('group')
    data = get_plugin_vars(None, testvars, None, [group])
    assert data == {'testvars_plugin_group': 'group'}


# Generated at 2022-06-11 19:21:43.857567
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.playbook.play_context import PlayContext

    class MockConfig(object):
        run_vars_plugins = 'all'

    class MockPlugin(object):
        def __init__(self, name):
            self._load_name = name

        def get_vars(self, loader, path, entities):
            return {self._load_name: path}

    class MockInventory(object):
        def __init__(self, sources):
            self._sources = sources

        @property
        def sources(self):
            return [MockInventorySource(path) for path in self._sources]

    class MockInventorySource(object):
        def __init__(self, path):
            self.path = path

    class MockLoader(object):
        def __init__(self, plugins):
            self

# Generated at 2022-06-11 19:21:50.280747
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    m_loader = object()
    m_path = object()
    m_entities = object()
    m_plugin = object()

    m_vars_loader = object()
    m_vars_loader.all = lambda: (m_plugin,)

    m_data = object()
    m_data2 = object()

    m_plugin.get_vars = lambda l, p, e: m_data

    assert get_vars_from_path(m_loader, m_path, m_entities, 'inventory') == m_data

    m_plugin.get_vars = lambda l, p, e: m_data2

    assert get_vars_from_path(m_loader, m_path, m_entities, 'task') == m_data2

    m_plugin.get_vars = Attribute

# Generated at 2022-06-11 19:21:59.315080
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    plugin_name = 'vars'
    plugin_type = 'file'
    data = {
        '_hosts': {},
        '_groups': {},
        '_hostvars': {},
        '_inventory': {}
    }
    data['_hostvars']['simple_host'] = {}
    data['_hostvars']['simple_host']['file_name'] = 'simple_plugin.yml'
    data['_hostvars']['simple_host']['plugin_name'] = plugin_name
    data['_hostvars']['simple_host']['plugin_type'] = plugin_type
    data['_hostvars']['simple_host']['plugin_args'] = None

    loader = None
    entities = set(['simple_host'])
   

# Generated at 2022-06-11 19:22:09.551213
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.path import unfrackpath
    from ansible.inventory.manager import InventoryManager

    paths = [unfrackpath(PlayContext.get_init_path() + "/../../test/units/vars_plugins/")]
    loader = vars_loader._create_loader(paths, None)
    plugin = vars_loader.get("test_plugin_1")
    path = unfrackpath(plugin._original_path)
    # Test passing a hostname
    host = Host(name="test_host")

# Generated at 2022-06-11 19:22:20.646721
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import wrap_var

    host = Host(name='host')

    loader = vars_loader

    manager = VariableManager()
    manager.hostvars = HostVars(host, vars_loader, manager)
    manager.hostvars.update({'foo': 'bar', 'deep': {'a': 1, 'b': 2}})

    # vars should return dict
    assert isinstance(get_vars_from_path(loader, '.', [host], 'inventory'), dict)

    # vars should be able to see variables in hostvars

# Generated at 2022-06-11 19:22:32.278012
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader

    loader = vars_loader

    assert len(loader.all()) > 0

    plugin = loader.get("environments")
    assert plugin is not None

    group = type("FooGroup", (object,), {
        "name": "group", "vars": {}, "groups": [], "hosts": [],
    })()

    host = type("FooHost", (object,), {
        "name": "group", "vars": {},
    })()

    path = "."

    entities = [group, host]

    stage = "task"

    data = get_vars_from_path(loader, path, entities, stage)
    assert data is not None
    assert "" in data

# Generated at 2022-06-11 19:22:43.062478
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins import vars_loader

    vars_loader.load_plugins()

    data = get_vars_from_path(None, '.', [], 'inventory')
    assert data == {}

    # Testing a dummy plugin
    class DummyPlugin:
        def __init__(self):
            self._load_name = 'host_vars'
            self._original_path = 'host_vars'
            self.has_option = lambda x:'stage'

        def get_host_vars(self, hostname):
            return {'host': hostname, 'vars': 'host'}

        def get_option(self, option):
            return 'all'

    data = get_vars_from_path(None, '.', ['host123'], 'inventory')

# Generated at 2022-06-11 19:23:03.320601
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    pass

# Generated at 2022-06-11 19:23:09.053627
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    # Import statement is required to register the plugin
    import ansible.plugins.vars.namespace
    plugin = vars_loader.get('namespace')
    entities = []

    assert {} == get_plugin_vars(None, plugin, '/path/does/not/matter', entities)



# Generated at 2022-06-11 19:23:14.871466
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    tmp_path = os.path.join(os.path.dirname(__file__), 'vars_from_inventory_sources.yml')
    loader = InventoryManager()
    sources = [tmp_path]
    entities = [loader.get_host('example_host')]
    data = get_vars_from_inventory_sources(loader, sources, entities, 'inventory')
    assert 'example_host' in data
    assert data['example_host']['baz'] == 'hello world'

# Generated at 2022-06-11 19:23:23.835226
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from importlib import import_module

    test_path = os.path.dirname(os.path.realpath(__file__))
    test_plugins_path = os.path.join(test_path, 'fixtures', 'vars_plugins')

    loader = import_module('ansible.plugins.loader')
    loader.add_directory(test_plugins_path)

    vars_plugin_list = list(loader._modules['vars']._loaders['vars'])

    assert len(vars_plugin_list) == 1

    data = get_vars_from_path(loader, test_path, [], 'inventory')
    assert data['path'] == test_path

# Generated at 2022-06-11 19:23:35.110770
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars.test_vars import AnsibleVarsBaseTest

    class VarsPlugin(AnsibleVarsBaseTest):

        run_method_name = 'get_vars'

        def __init__(self, *args, **kwargs):
            super(VarsPlugin, self).__init__(*args, **kwargs)

            # The name of the vars plugin plugin is the filename without extension
            self._load_name = 'test_vars'

    vars_plugin = VarsPlugin('/my/path')

    loader = None
    path = '/my/path'
    entities = None

    expected_data = {'test_vars': 'test_value'}
    returned_data = get_plugin_vars(loader, vars_plugin, path, entities)
    assert returned_