

# Generated at 2022-06-11 19:13:49.230946
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    loader = None
    path = "/home/ansible/test_env"
    host = Host('test_host')
    group = Host('test_group')
    stage = "task"

    plugin_data = get_vars_from_path(loader, path, [host, group], stage)
    assert len(plugin_data) == 0, "Plugin data should be 0"

# Generated at 2022-06-11 19:13:56.360550
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    from ansible.inventory.manager import InventoryManager

    sources = ["../tests/inventory/host_vars", "../tests/inventory/hosts"]

    # create InventoryManager with the sources
    loader, inventory, host_list = InventoryManager.load(sources)
    assert inventory

    vars_data = get_vars_from_inventory_sources(loader, sources, host_list, stage='task')

    assert vars_data

    # test that variables in host_vars are added to the host
    assert vars_data['host_all']['host_var'] == "host_var1"
    assert vars_data['host_all']['group_var'] == "group_var1"
    assert vars_data['host_one']['group_var'] == "group_var1"
    assert v

# Generated at 2022-06-11 19:14:03.975972
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    import os
    import tempfile
    import textwrap

    from ansible.module_utils.six import PY2
    from ansible.module_utils.six.moves import configparser
    from ansible.module_utils.six.moves import StringIO
    from ansible.vars.vars_loader import VarsModule

    orginal_vars_loader_all = vars_loader.all

    # create temporary directory and file
    tmp_dir = tempfile.mkdtemp()

    plugin_name = 'test'
    plugin_path = os.path.join(tmp_dir, '{}.py'.format(plugin_name))

# Generated at 2022-06-11 19:14:04.629039
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert 1 == 1

# Generated at 2022-06-11 19:14:08.678752
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    assert get_vars_from_inventory_sources(None, ['hosts'], [], None) == {}
    assert get_vars_from_inventory_sources(None, ['hosts', 'hosts_test'], [], None) == {}

# Generated at 2022-06-11 19:14:13.460700
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    data = get_vars_from_path('/etc/ansible/hosts', '', '', 1)
    assert data == {}

# Generated at 2022-06-11 19:14:22.628439
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.utils.plugin_docs import get_docstring

    # Load the data loader first
    loader = DataLoader()

    # Create the inventory (to read the host/group vars)
    inv_manager = InventoryManager(loader=loader, sources='test/test_vars_plugins/hosts')

    # Set up the variable manager
    variable_manager = VariableManager(loader=loader)
    variable_manager.set_inventory(inv_manager)

    # Include group vars
    group = inv_manager.groups['all']

# Generated at 2022-06-11 19:14:28.952802
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # TODO: reimplement test

    # vars_plugin = VarsModule({})
    # vars_plugin.get_vars = (lambda x: {'test': 'foo'})
    # vars_loader.add(vars_plugin, 'test')
    # print(get_vars_from_path('test', 'test'))
    pass



# Generated at 2022-06-11 19:14:35.069002
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible import context
    from ansible.inventory.manager import InventoryManager

    param=dict(
              sources='hosts/hosts',
              plugin='first',
              path='/home/ansible/playbooks',
              entities='host1'

         )

    context.CLIARGS = {}
    context.CLIARGS['inventory'] = [param['sources']]
    inventory=InventoryManager(loader=None, sources=context.CLIARGS['inventory'])
    loader = inventory.loader
    vars_plugin = vars_loader.get(param['plugin'])
    host=inventory.get_host(param['entities'])
    data=get_plugin_vars(loader, vars_plugin, param['path'], host)

# Generated at 2022-06-11 19:14:45.535554
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    # Provide a vars plugin which generates some fake vars data
    def vars_plugin_get_vars(loader, path, entities):
        return {'var1': '1', 'var2': '2'}

    # To keep code simple, we just use the variables already defined on vars_loader.PluginName
    # rather than creating a test plugin class
    class TestPlugin:
        REQUIRES_WHITELIST = True
        get_vars = vars_plugin_get_vars

    loader = 'some_loader'
    path = 'some_path'
    entities = ['entity1', 'entity2']
    stage = 'inventory'

    # Test without VARIABLE_PLUGINS_ENABLED set
    vars_loader.all().clear()

# Generated at 2022-06-11 19:15:00.179674
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    loader = None
    sources = ['tests/fixtures/vars_plugins/inventory_sources']
    entities = ['host', 'group', 'all']

    data = get_vars_from_inventory_sources(loader, sources, entities, None)


# Generated at 2022-06-11 19:15:03.399442
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    loader = None
    entites = ["192.168.0.40"]
    path = "/home/test/"
    stage = "inventory"
    assert get_vars_from_path(loader, path, entites, stage) is not None

# Generated at 2022-06-11 19:15:10.340518
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    loader = None
    entities = ['1.1.1.1','1.1.1.2','1.1.1.3','1.1.1.4','1.1.1.5','1.1.1.6','1.1.1.7','1.1.1.8','1.1.1.9']
    data = get_vars_from_path(loader, '/opt/vars_sdk/ansible_test/test_dir', entities, 'inventory')
    assert data
    assert data['test_var'] == 'test'

# Generated at 2022-06-11 19:15:10.866097
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    assert False

# Generated at 2022-06-11 19:15:11.439406
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    pass

# Generated at 2022-06-11 19:15:20.839947
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    '''
    all plugins enabled, both global and plugin-specific stages, and use_global
    '''
    loader, inventory, sources, entities, stage = (
        None, None, [b'one', b'two'], None, 'inventory')


# Generated at 2022-06-11 19:15:27.284625
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inv = InventoryManager(loader=loader, sources='localhost,')
    group = inv.groups[inv.groups.keys()[0]]
    varmgr = VariableManager(loader=loader, inventory=inv)

    assert get_vars_from_inventory_sources(loader, ['/dev/null'], [group], 'inventory') == {}


# ---- END VARS PLUGINS ----


# Generated at 2022-06-11 19:15:37.339097
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    import unittest.mock as mock
    mock_vars_plugin = mock.Mock()
    mock_vars_plugin.get_vars = mock.Mock(return_value={'a': 1})
    mock_vars_plugin.get_host_vars = mock.Mock(return_value={'b': 2})
    mock_vars_plugin.get_group_vars = mock.Mock(return_value={'c': 3})
    data = get_vars_from_path(None, './test_path', [Host('test1')], 'task')
    assert data == {'a': 1, 'b': 2}



# Generated at 2022-06-11 19:15:46.765305
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    import sys
    import os
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader
    from ansible.errors import AnsibleError
    from ansible.plugins.loader import vars_loader

    def get_vars(self, loader, path, entities, cache=True):
        return {'var':path}

    # Create directory for dummy test
    test_dir = os.path.join(C.DEFAULT_LOCAL_TMP, 'test_dir')
    if not os.path.exists(test_dir):
        os.makedirs(test_dir, 0o755)

    # Make sure to test with a relative path instead of absolute path
    relpath = os.path.relpath(test_dir)



# Generated at 2022-06-11 19:15:58.492688
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager

    dummy_plugin = {
        'get_vars': lambda *args, **kwargs: {'test': 'dummy'}
    }
    dummy_plugin_name = 'dummy_plugin'

    vars_loader.add(dummy_plugin_name, dummy_plugin)

    inventory_host_vars_data = {'host_vars': {'host1': {'test': 'host1'}, 'host2': {'test': 'host2'}}}
    inventory_group_vars_data = {'group_vars': {'group1': {'test': 'group1'}}}
    sources = ['/tmp/inventory_host_vars', '/tmp/inventory_group_vars', '/tmp/inventory_vars']


# Generated at 2022-06-11 19:16:20.040226
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    loader = InventoryManager(C.DEFAULT_HOST_LIST)
    path = 'tests/data/inventory'

    current_data = loader.get_vars(['all'], refresh=True, stage='inventory')
    assert(current_data['test_var'] == 'test_value')

    new_data = get_vars_from_path(loader, path, ['all'], 'inventory')
    assert(new_data['test_var'] == 'test_value')

    current_data = loader.get_vars(['webservers'], refresh=True, stage='inventory')
    assert(current_data['test_var'] == 'test_value')


# Generated at 2022-06-11 19:16:20.974635
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    # TODO: test with v1 plugins?
    pass

# Generated at 2022-06-11 19:16:29.233267
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    from ansible.plugins.loader import inventory_loader
    from ansible.utils.collection_loader import AnsibleCollectionRef

    loader = inventory_loader

    plugin_list = list(loader.all())
    plugin_list.append(loader.get(AnsibleCollectionRef.from_string(u'test_namespace.test_collection.test_inventory')))
    loader.set_inventory_sources("test1\ntest2")

    plugins = loader.inventory_sources

    vars_from_path = get_vars_from_inventory_sources(loader, plugins, [], "inventory")

    # Test that vars plugin for namespace test_namespace.test_collection
    # is called for each plugin in the loader.

# Generated at 2022-06-11 19:16:36.904545
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    loader = None
    entities = [ Host('10.1.1.1') ]

    path = 'test/unit/plugins/vars_plugin/host_vars'

    plugin = vars_loader.get('host_vars')
    plugin_vars = get_plugin_vars(loader, plugin, path, entities)
    assert plugin_vars == { 'answer_to_the_ultimate_question_of_life_the_universe_and_everything': 42 }

    plugin = vars_loader.get('group_vars')
    plugin_vars = get_plugin_vars(loader, plugin, path, entities)
    assert plugin_vars == { 'secret': 'sshhhh' }

    path = 'test/unit/plugins/vars_plugin/group_vars'
    plugin_vars = get_

# Generated at 2022-06-11 19:16:44.102368
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    # get_vars_from_path requires a path, an entities list, and a stage.
    # The path can be a file path or a directory path, there is not much difference
    # The entities list can be [all]
    # The stage is either 'inventory' or 'task'

    # example call:
    # get_vars_from_path(loader, os.path.join(os.path.dirname(__file__), "../"), ['all'], 'inventory')

    pass

# Generated at 2022-06-11 19:16:45.897209
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert type(get_vars_from_path) == type(get_vars_from_path)

# Generated at 2022-06-11 19:16:52.508504
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    loader = 'dummy_loader'
    path = 'dummy_path'
    entities = ['entity1', 'entity2']
    stage = 'task'
    plugin = 'dummy_plugin'
    plugin.get_vars = get_vars_from_path
    plugin.get_host_vars = get_vars_from_path
    plugin.get_group_vars = get_vars_from_path

    assert get_vars_from_path(loader, path, entities, stage) ==  get_plugin_vars(loader, plugin, path, entities)

# Generated at 2022-06-11 19:16:57.310193
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # test passing in a valid and invalid plugin to get_plugin_vars
    assert get_plugin_vars('loader', 'plugin', 'path', 'entities') == dict()

    # test passing in a valid and invalid plugin to get_vars_from_path
    assert get_vars_from_path('loader', 'path', 'entities', 'stage') == dict()

# Generated at 2022-06-11 19:17:01.409650
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    loader = None
    path = "../../../../ansible/plugins/vars"
    entities = []
    stage = "inventory"
    print(get_vars_from_path(loader, path, entities, stage))

# Generated at 2022-06-11 19:17:08.901123
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager

    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=VariableManager(), host_list='./test/lib/ansible/inventory/test_inventory.yaml')
    vars = get_vars_from_path(loader, './test/lib/ansible/inventory/', [inventory.groups.get('all')], 'inventory')
    assert vars.get('all_group_var') == 'all_group_var_value'

# Generated at 2022-06-11 19:17:24.536366
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    loader = object()
    path = object()
    entities = object()
    stage = object()

    class _Plugin():
        def get_vars(self, loader, path, entities):
            assert self == _Plugin._instance
            assert loader == loader
            assert path == path
            assert entities == entities
            assert stage == stage
            return 'foo'

    _Plugin._instance = _Plugin()

    assert get_vars_from_path(loader, path, entities, stage) == 'foo'

# Generated at 2022-06-11 19:17:29.269247
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=VariableManager(loader=loader), host_list='localhost')
    sources = [__file__]
    entities = [inventory.get_host('localhost')]
    stage = 'inventory'
    data = get_vars_from_path(loader, '.', entities, stage)
    assert len(data) > 0
    assert 'ansible_version' in data
    assert data['ansible_version']['full'] == '2.6.16'

# Generated at 2022-06-11 19:17:35.728859
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.constants import VARIABLE_PLUGINS_ENABLED
    from ansible.plugins.loader import vars_loader

    VARIABLE_PLUGINS_ENABLED.append('my_test_vars_plugin')

    test_loader = vars_loader.all(class_only=True)['my_test_vars_plugin']()
    test_loader._load_name = 'my_test_vars_plugin'
    test_loader.get_vars = lambda x, y, z: {'foo': 'bar'}

    result = get_vars_from_path(test_loader, '/tmp', ['dummy_entity'], 'start')

    assert 'foo' in result
    assert result['foo'] == 'bar'

# Generated at 2022-06-11 19:17:46.194668
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    test_path = '/etc/ansible'
    test_entities = ['foo']
    test_stage = 'task'

    fake_loader = lambda : None
    fake_loader.all = lambda : []
    fake_loader.path_exists = lambda p: True if p == test_path else False

    assert get_vars_from_path(fake_loader, test_path, test_entities, test_stage) == {}

    test_plugin = lambda : None
    test_plugin._load_name = 'test_plugin'
    fake_loader.all = lambda : [test_plugin]
    test_plugin.get_vars = lambda l, p, e: {'key': 'value'}


# Generated at 2022-06-11 19:17:48.576448
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    ''' This is a unit test for function get_plugin_vars '''
    pass



# Generated at 2022-06-11 19:17:57.304469
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.module_utils._text import to_bytes
    import ansible.plugins.loader as ploader
    from ansible.plugins.vars import aws_ec2
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    # Set up test
    # Create test vars plugin
    class TestPlugin(aws_ec2.VarsModule):
        _instance = None
        _load_name = 'test_vars'

        def __init__(self, *args, **kwargs):
            super(TestPlugin, self).__init__(*args, **kwargs)

        @staticmethod
        def get_vars(loader, path, entities, cache=True):
            return {'vars': {'test_key': 'test_val'}}


# Generated at 2022-06-11 19:18:01.073049
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    class DummyVarPlugin:
        def get_vars(self, loader, path, entities):
            return "Result"
    dummy = DummyVarPlugin()
    assert get_plugin_vars(None, dummy, None, None) == "Result"

# Generated at 2022-06-11 19:18:10.188305
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins import vars_loader
    loader = vars_loader.VarsModule()
    path = '/test/path'
    entities = ['test_var1', 'test_var2']
    stage = 'inventory'
    output = get_vars_from_path(loader, path, entities, stage)
    #print(output)
    assert output['test_var1'] == '/test/path'
    assert output['test_var2'] == '/test/path'
    assert output == get_plugin_vars(loader, output['plugin'], path, entities)



# Generated at 2022-06-11 19:18:15.458008
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    fake_plugin_module = {'run': True, 'get_host_vars': lambda x: {x: 'host'}, 'get_group_vars': lambda x: {x: 'group'}}
    fake_host = Host('host')
    fake_group = 'group'
    actual_vars = get_plugin_vars(None, fake_plugin_module, None, [fake_host, fake_group])
    assert actual_vars == {'host': 'host', 'group': 'group'}


# Generated at 2022-06-11 19:18:26.112744
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    # mock a loader object
    class MockLoader(object):
        pass

    loader = MockLoader()

    # mock a vars plugin object
    class MockVarsPlugin(object):
        @staticmethod
        def get_vars(loader, path):
            return {'some_var': 'foo'}

    plugin = MockVarsPlugin()

    entities = [1, 2, 3]

    # mock a path
    path = 'test_path'

    # Test with function argument stage == 'inventory'
    result = get_vars_from_path(loader, path, entities, 'inventory')
    assert result == {'some_var': 'foo'}

    # Test with function argument stage == 'task'
    result = get_vars_from_path(loader, path, entities, 'task')

# Generated at 2022-06-11 19:18:48.673042
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    # TODO: We'll need to mock out the relevant parts of the
    #   Ansible plugin framework here to make this test work.

    assert False

# Generated at 2022-06-11 19:18:59.357264
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.plugins.vars import BaseVarsPlugin

    class TestVarsPlugin(BaseVarsPlugin):
        def get_vars(self, loader, path, entities=None):
            return {'test_var': 'test_value'}

    # Create a new vars_loader and add a test plugin
    loader = vars_loader.VarsModuleLoader()
    test_plugin = TestVarsPlugin('test_plugin', {}, None)

    test_path = '/'
    test_entities = []
    test_stage = 'inventory'
    actual_vars = get_vars_from_path(loader, test_path, test_entities, test_stage)

    assert actual_vars == {'test_var': 'test_value'}

# Generated at 2022-06-11 19:19:09.547264
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    class FakePlugin:
        _load_name = 'fake'
        _original_path = 'fake_path'
    class FakeVarsPlugin(FakePlugin):
        pass
    class FakeHostPlugin(FakePlugin):
        def get_host_vars(self, host):
            return {'host_var': 1}
    class FakeGroupPlugin(FakePlugin):
        def get_group_vars(self, group):
            return {'group_var': 1}
    class FakeRunPlugin(FakePlugin):
        def run(self):
            return {'run_var': 1}

    loader = FakePlugin
    path = 'fake_path'

    # Test old-style vars plugin, should raise an exception
    plugin = FakeRunPlugin()

# Generated at 2022-06-11 19:19:12.118495
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    display.warning('Skipping test_get_vars_from_path() since it is not supported for Python 3')
    pass


# Generated at 2022-06-11 19:19:23.163492
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # test the function with different input
    loader = vars_loader
    path1 = "./test/test_dir"
    entities1 = [Host("test_host")]
    stage1 = "task"


    plugin1 = vars_loader.get("test_vars")
    plugin2 = vars_loader.get("test_vars_2")
    data1 = get_plugin_vars(loader, plugin1, path1, entities1)
    data2 = get_plugin_vars(loader, plugin2, path1, entities1)
    data = {key: value for key, value in data1.items()}
    data.update({key: value for key, value in data2.items()})
    # Get the data expect to get

# Generated at 2022-06-11 19:19:33.921118
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    # vars plugins are disabled globally but enabled for a specific plugin
    result = get_vars_from_path(None, '/some/path', None, 'task')
    assert result is not None
    assert len(result) == 0

    # vars plugins are enabled globally and enabled for a specific plugin
    result = get_vars_from_path(None, '/some/path', None, 'inventory')
    assert result is not None
    assert len(result) == 0

    # vars plugins are enabled globally but disabled for a specific plugin
    result = get_vars_from_path(None, '/some/path', None, 'task')
    assert result is not None
    assert len(result) == 0

# Generated at 2022-06-11 19:19:43.735860
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    loader = {'_ansible_vars_plugins': [{'_load_name': 'v2', 'get_vars': 'get_vars_method', 'get_group_vars': 'get_group_vars_method', 'get_host_vars': 'get_host_vars_method'},
                                       {'_load_name': 'v1', 'get_vars': 'get_vars_method', 'get_group_vars': 'get_group_vars_method', 'get_host_vars': 'get_host_vars_method'}]}
    # no plugin found
    plugin, path, entities = {}, {}, {}
    assert get_plugin_vars({}, plugin, path, entities) == {}

    # ansible v2 type plugin

# Generated at 2022-06-11 19:19:54.825935
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    # Mock loader
    loader = type('MockLoader', (object,), dict(to_file=lambda x: x))()

    path_entities = [('/path1', [Host('host1')])]

    # Mock vars plugin
    class MockVarsPlugin(object):

        # Mock properties
        _load_name = 'MockVarsPlugin'
        _original_path = 'MockVarsPlugin'

        @staticmethod
        def get_vars(loader, path, entities):
            assert loader is mock_loader
            assert path == '/path1'
            assert entities == [Host('host1')]
            return dict(x=1)

    # Mock vars loader
    class MockVarsLoader(object):
        plugins = [MockVarsPlugin(), ]


# Generated at 2022-06-11 19:20:03.896679
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    # This test will require an environment that has a valid Ansible installation.
    # It will not run in Docker.
    from ansible.cli.playbook import PlaybookCLI

# Generated at 2022-06-11 19:20:13.913200
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader, module_utils_loader, filter_loader
    from ansible.utils.collection_loader import AnsibleCollectionRef

    # The vars_loader loads all the plugin names in C.VARIABLE_PLUGINS_ENABLED by default,
    # which is not what we want for unit testing.  So we set it up to just load the plugins we
    # want, and also add an empty vars plugin for testing.

    # Start with an empty list, then add each plugin in the order it's supposed to be tested.
    vars_loader._plugins = []
    vars_loader._plugins = vars_loader._plugins + [vars_loader.get('{}:host'.format('host_group_vars'))]

# Generated at 2022-06-11 19:21:04.965085
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    plugin_name = 'test_plugin'
    path = './test_plugin/test_plugin'
    entity = Host('127.0.0.1')
    entities = [entity]
    stage = 'inventory'

    vars_plugin = vars_loader.get(plugin_name)
    assert(vars_plugin._load_name == plugin_name)

    plugin_data = get_plugin_vars(vars_loader, vars_plugin, path, entities)
    assert(plugin_data.get('test', '') == 'test')

# Generated at 2022-06-11 19:21:13.067801
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    # TODO: This test is not complete yet

    # Expect value on apply
    expect = {'asdf': 'asdf'}
    # Set up a host and a group to test on
    host = Host('test')
    group = Group('test')

    # Call function to test
    result = get_vars_from_path(None, '/tmp/test', host, 'inventory')
    assert result == expect

    # Call function to test
    result = get_vars_from_path(None, '/tmp/test', group, 'inventory')
    assert result == expect

# Generated at 2022-06-11 19:21:19.737231
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.vars import ansible_facts, inventory_hostname, ip_addresses, localhost
    # assert that the function can load the vars plugins
    # the function will raise an error if the plugin is not found or not able to load it
    vars_loader.all()

    # here, we provide a mock loader and assert if the values returned by the plugin matches
    # with the expected values for the plugin
    fake_loader = {'_basedir': '',
                   '_inventory_sources': ['/mock_path/hosts.yaml']}
    # ansible_facts
    vars_data = get_vars_from_path(fake_loader, '/mock_path/hosts.yaml', ['localhost', 'host1', 'host2'], 'inventory')

# Generated at 2022-06-11 19:21:23.635157
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    """This is a unit test for ansible.plugins.vars.host_group_vars.get_vars_from_inventory_sources"""
    # Create a Host and a Group
    host = Host(u'localhost')
    group = FakeGroup(name=u'group_vars_test')
    group.inventory = 'test/units/vars_plugins/inventory'
    group.vars = {'group_var': u'bar'}
    host.add_group(group)
    # Call the tested function
    vars = get_vars_from_inventory_sources(None, ['test/units/vars_plugins/inventory'], [group], 'task')
    # Asserts
    assert(vars == {'group_var': u'bar'})

# Generated at 2022-06-11 19:21:34.167104
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    def get_plugin(plugin_name, enabled=True):
        class FakePlugin():
            var_data = {}
            def get_vars(self, loader, path, entities):
                return self.var_data
            def __contains__(self, key):
                return key in self.var_data
            def get_host_vars(self, host):
                return self.var_data
            def get_group_vars(self, group):
                return self.var_data
        C.VARIABLE_PLUGINS_ENABLED.append(plugin_name)
        plugin = FakePlugin()
        return plugin
    class FakeLoader():
        vars_plugin_list = []
        def __contains__(self, key):
            return key in self.vars_plugin_list

# Generated at 2022-06-11 19:21:45.698612
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    from ansible.plugins.loader import vars_loader
    from ansible.vars.manager import VariableManager

    class SamplePlugin:

        def __init__(self, plugin_name, plugin_path):
            self._load_name = plugin_name
            self._original_path = plugin_path

        def get_vars(self, loader, path, entities):
            return {'test_data': path + ':' + ':'.join([e.name for e in entities])}

        def get_host_vars(self, host):
            return {'host_test_data': 'host:' + host}

        def get_group_vars(self, group):
            return {'group_test_data': 'group:' + group}


# Generated at 2022-06-11 19:21:46.728808
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # TODO
    pass

# Generated at 2022-06-11 19:21:57.547136
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.utils.vars import TaskVars
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    groups = [
        # name, vars, host, port
        ["group1", {"group1": "value"}, "foo", "22"],
        ["group2", {"group2": "value"}, "bar", "22"],
    ]
    hosts = [
        # name, vars, port
        ["foo", {"foo": "value"}, "22"],
        ["bar", {"bar": "value"}, "22"],
    ]
    inventory = InventoryManager(loader=loader)
    for group in groups:
        inventory.add_group(group[0])

# Generated at 2022-06-11 19:22:08.090794
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # vars_loader is a global variable
    vars_loader.add('vars_test_test', 'ansible.plugins.test.vars_loader.vars_test_test')
    vars_loader.enable('vars_test_test')

    result = get_vars_from_path(object, 'fake/path', [], 'fake/stage')
    assert result == {'test_key': 'test_value'}

    result = get_vars_from_path(object, 'fake/path', [object], 'fake/stage')
    assert result == {'test_key': 'test_value'}

    result = get_vars_from_path(object, 'fake/path', [object, object], 'fake/stage')
    assert result == {'test_key': 'test_value'}



# Generated at 2022-06-11 19:22:19.728111
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible import context
    from ansible.inventory.manager import InventoryManager

    context.CLIARGS = {}
    plugin = vars_loader.all()[0]
    path = '/ansible/test/data/plugins/vars'
    path2 = '/ansible/test/data/playbooks/playbook/host_vars'
    loader = vars_loader

    entities = [Host('test_host')]
    stage = 'inventory'
    data = get_vars_from_path(loader, path, entities, stage)

    assert 'test_plugin_var' in data
    assert data['test_plugin_var'] == 'foo'

    data = get_vars_from_path(loader, path2, entities, stage)