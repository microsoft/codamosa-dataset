

# Generated at 2022-06-11 19:13:52.943094
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Replace this with the new testinfra api when it supports ansible 2.8
    # https://github.com/philpep/testinfra/issues/492
    from testinfra.modules.base import AnsibleModule
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.collection_loader import AnsibleCollectionRef

    source = """
all:
  hosts:
    testhost:
      ansible_host: localhost
"""
    loader = InventoryManager(sources=source)

    # Create fake variable plugin
    class MyFakePlugin:
        def __init__(self, name, fqcr):
            self._load_name = name
            self._original_path = fqcr


# Generated at 2022-06-11 19:14:02.555879
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    vars_loader.add_directory(os.path.join(os.path.dirname(__file__), '../test_vars_plugins'))
    vars_loader.add_directory(os.path.join(os.path.dirname(__file__), '../test_vars_plugins_copy'))

    # vars_plugins unit-test
    # for sample plugin see: lib/ansible/plugins/vars/__init__.py
    # for sample plugin see: lib/ansible/plugins/vars_plugins/__init__.py
    # for sample plugin see: lib/ansible/plugins/vars_plugins/test.py
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
   

# Generated at 2022-06-11 19:14:03.828872
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert False, "Unit test not implemented"

# Generated at 2022-06-11 19:14:13.025841
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    loader = 'loader'
    entity = 'entity'
    stage = 3
    source1 = None
    source2 = 'source2'
    sources = [source1, source2]
    entities = [entity, 'entity2']

    os.path.isdir = lambda x: True
    os.path.dirname = lambda x: 'dirname'
    os.path.exists = lambda x: True
    get_vars_from_path = lambda x, y, z, w: {'path' + str(z) + str(w): x}
    data = get_vars_from_inventory_sources(loader, sources, entities, stage)
    assert data == {'pathentity3': 'dirname', 'pathentity23': 'dirname'}

# Generated at 2022-06-11 19:14:17.738787
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.vars.vault import VariablesModule as VarsVault

    results = {}
    path = '/path/to/files'
    entities = []
    loader = None

    # Test that a plugin that implements `get_vars` works
    data = get_plugin_vars(loader, VarsVault(), path, entities)
    assert(data == {'vault_password_file': None})

    # Test that a plugin that implements `get_host_vars` and `get_group_vars` works
    data = get_vars_from_path(loader, path, entities, 'inventory')
    assert(data == {'vault_password_file': None})

# Generated at 2022-06-11 19:14:24.047130
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    class fake_plugin:
        ''' Implements same interfaces (except get_vars) as required '''
        def get_host_vars(self, host):
            return {'hostvars': host}

        def get_group_vars(self, group):
            return {'groupvars': group}

    loader = None
    path = 'path'
    data = {}
    plugin = fake_plugin()

    data = combine_vars(data, get_plugin_vars(loader, plugin, path, [Host('test1'), Host('test2')]))
    assert data['hostvars'] == 'test1'
    data = combine_vars(data, get_plugin_vars(loader, plugin, path, [Host('test1'), Host('test2')]))

# Generated at 2022-06-11 19:14:24.630744
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    pass

# Generated at 2022-06-11 19:14:26.885360
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    assert get_vars_from_path(None, to_bytes('/path/to/ansible/library'), None, None) is not None

# Generated at 2022-06-11 19:14:29.784105
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert (
        "vars_plugin" in get_vars_from_path({}, "/dev/null", [], 'task')
    )

# Generated at 2022-06-11 19:14:37.422418
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    test_plugin = type('TestPlugin', (object,),
                       {
                           '_load_name': 'test_plugin',
                           '__file__': 'test_plugin',
                           'get_vars': lambda self, loader, path, entities: {'test_var': 'test_value'},
                           'get_host_vars': lambda self, host: {'test_host_var': 'test_host_value'},
                           'get_group_vars': lambda self, group: {'test_group_var': 'test_group_value'},
                       })

    test_loader = type('TestLoader', (object,),
                       {
                           'all': lambda self: [test_plugin()],
                       })


# Generated at 2022-06-11 19:14:42.951843
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    pass

# Generated at 2022-06-11 19:14:53.002273
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins import vars_loader

    def _get_path(p):
        return os.path.join(os.path.dirname(__file__), 'vars_plugins', p + '.py')


# Generated at 2022-06-11 19:15:02.468258
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    class TestVarsPlugin:
        def get_vars(self, loader, path, entities):
            return {'plugin_var': 'plugin_var_value'}

        def get_group_vars(self, group_name):
            return {group_name: {'group_var': 'group_var_value'}}

        def get_host_vars(self, host_name):
            return {host_name: {'host_var': 'host_var_value'}}

    class TestVarsPlugin2:
        def get_vars(self, loader, path, entities):
            return {'plugin_var2': 'plugin_var_value2'}


# Generated at 2022-06-11 19:15:08.476411
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import auto

    vars_plugin_list = list(vars_loader.all())
    for plugin_name in C.VARIABLE_PLUGINS_ENABLED:
        if AnsibleCollectionRef.is_valid_fqcr(plugin_name):
            vars_plugin = vars_loader.get(plugin_name)
            if vars_plugin is None:
                # Error if there's no play directory or the name is wrong?
                continue
            if vars_plugin not in vars_plugin_list:
                vars_plugin_list.append(vars_plugin)

    sample_host_name = 'test'
    sample_group_name = 'test'

# Generated at 2022-06-11 19:15:13.686915
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    import os
    import sys
    import tempfile

    thisdir = os.path.dirname(os.path.realpath(__file__))
    ansible_path = os.path.realpath(os.path.join(thisdir, '..', '..'))
    test_plugins_path = os.path.join(ansible_path, 'test', 'units', 'module_utils', 'vars_plugins')

    sys.path.insert(0, test_plugins_path)
    from test_vars_plugin_legacy import fakevars1
    from test_vars_plugin_v2 import fakevars2

    t = tempfile.mkdtemp()

    loader = FakeVarsPluginLoader()

# Generated at 2022-06-11 19:15:25.262817
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    d = get_vars_from_path(None, './test/data/plugins/vars_plugins', ['all'], 'inventory')
    assert d == {
        'group_var': 'group',
        'host_var': 'host',
        'plugin_var': 'plugin',
        'plugin_var_with_stage': 'plugin',
        'plugin_var_with_stage_and_default': 'plugin',
        'plugin_var_with_stage_and_wrong_default': 'plugin',
        'plugin_var_with_wrong_stage': 'plugin'}

    d = get_vars_from_path(None, './test/data/plugins/vars_plugins', ['all'], 'task')

# Generated at 2022-06-11 19:15:26.345541
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    # TODO:
    assert False

# Generated at 2022-06-11 19:15:38.006974
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    import os
    import sys

    # get the dir of this file, dataloader expects this to be ran from the dir of the file that is being tested
    mydir = os.path.dirname(os.path.realpath(__file__))
    test_dir = mydir + '/test_get_vars_from_path'

    # add the vars plugin dirs
    sys.path.append(os.path.join(test_dir, 'group_vars_plugins'))
    sys.path.append(os.path.join(test_dir, 'host_vars_plugins'))

    loader = DataLoader()

    # load and parse inventory

# Generated at 2022-06-11 19:15:47.360777
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.cli import CLI
    from ansible.context import AnsibleContext
    from ansible.plugins.loader import vars_loader
    import os
    import pytest
    from tempfile import NamedTemporaryFile
    from tempfile import mkdtemp
    from ansible.errors import AnsibleError

    @pytest.fixture
    def fake_module():
        fake_module = NamedTemporaryFile(delete=False)
        fake_module.write(b"#!/usr/bin/python\nfrom __future__ import (absolute_import, division, print_function)\n__metaclass__ = type\n")
        fake_module.close()
        return fake_module

    @pytest.fixture
    def fake_plugin():
        fake_plugin = NamedTemporaryFile(delete=False)
        fake_plugin.write

# Generated at 2022-06-11 19:15:54.325695
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader

    vars_loader._all = vars_loader._find_plugins(C.DEFAULT_VARS_PLUGIN_PATH, 'vars')

    path = os.path.dirname(__file__)
    data = get_vars_from_path(None, path, [], None)
    assert data == {}

# Generated at 2022-06-11 19:16:10.328696
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    from sys import version_info
    from ansible.plugins.loader import vars_loader

    if version_info[0] == 2:
        from mock import MagicMock
    else:
        from unittest.mock import MagicMock

    groupvars_path = os.path.join(os.path.dirname(__file__), '..','..','..','..','..','test','integration','inventory','host_vars_plugins')
    loader = MagicMock()
    loader.list_directory.return_value = [groupvars_path]

    vars_plugins = list(vars_loader.all())
    vars_plugins.remove(vars_loader.get('host_vars_plugins.yaml'))

# Generated at 2022-06-11 19:16:17.760498
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    display.verbosity = 4
    path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'test/units/module_utils/test_vars_plugins')
    loader = vars_loader.get('v1')

    vars_plugin_list = list(vars_loader.all())
    for plugin in vars_plugin_list:
        data = get_plugin_vars(loader, plugin, path, ['host1', 'host2', 'group1', 'group2'])
        print('%s' % (data,))

# Generated at 2022-06-11 19:16:23.356242
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Change to test directory and run tests
    path = os.path.join(os.path.dirname(__file__), 'test_vars_plugin')
    assert get_vars_from_path(None, path, None, 'inventory') == {'value': 'this is inventory value'}
    assert get_vars_from_path(None, path, None, 'task') == {'value': 'this is task value'}

# Generated at 2022-06-11 19:16:33.475201
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    class DummyPlugin:
        pass

    class DummyLoader:
        pass

    loader = DummyLoader()
    vars_path = '/path/to/vars/files'
    hostname = 'testhostname'
    host = Host(hostname)
    vars_test_data = {'testkey': 'testvalue'}
    vars_file_name = 'testvarsfile'
    vars_file_path = vars_path + '/' + vars_file_name + '.yml'
    plugin1 = DummyPlugin()
    plugin1._load_name = 'plugin1'
    plugin1._original_path = '/path/to/plugin1'
    plugin1.get_vars = lambda loader, path, entities: {'testkey': 'testvalue'}


# Generated at 2022-06-11 19:16:40.972914
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    import sys
    sys.modules['ansible'] = type('ansible_mock', (), {})()
    sys.modules['ansible.errors'] = type('ansible_errors', (), {})()
    sys.modules['ansible.plugins'] = type('ansible_plugins', (), {})()
    sys.modules['ansible.plugins.loader'] = type('ansible_plugins_loader', (), {})()

    import ansible.errors
    setattr(ansible.errors, 'AnsibleError', Exception)
    import ansible.plugins.loader
    setattr(ansible.plugins.loader, 'vars_loader', type('posix', (), {})())

    setattr(ansible.plugins.loader.vars_loader, 'all', lambda: [])

    import ansible.plugins.vars

# Generated at 2022-06-11 19:16:48.818537
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader

    class MyClass:
        pass

    result = {}
    loader = MyClass()
    loader.path_exists = lambda x: True
    for name in vars_loader.all():
        plugin = vars_loader.get(name)
        result = combine_vars(result, get_plugin_vars(loader, plugin, 'foo', ['foo.bar.com', 'bar.bar.com']))
        assert 'foo' in result



# Generated at 2022-06-11 19:16:58.033937
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    from ansible.vars.manager import InventoryVarsManager
    from ansible.vars.manager import VariableManager

    # disable deprecation warning for get_vars_from_path
    import warnings
    warnings.filterwarnings('ignore', '.*', DeprecationWarning, r'ansible\.vars\.manager', 0)

    class NewPlugin(object):
        REQUIRES_WHITELIST = False
        def get_vars(self, _loader, _path, _entities):
            return {'key1': 'value1'}
        def get_host_vars(self, _host):
            return {'key1': 'value1'}
        def get_group_vars(self, _group):
            return {'key1': 'value1'}

# Generated at 2022-06-11 19:17:08.987995
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    import sys
    sys.path.insert(0, os.getcwd())

    from ansible.plugins.vars import dir_vars
    from ansible.plugins.vars import file_vars
    from ansible.plugins.vars import group_vars
    from ansible.plugins.vars import host_vars

    loader = False

    # dir_vars ATTRS:
    # _load_name
    # REQUIRES_WHITELIST
    # get_vars
    # get option
    # has option

    dir_path = "/etc/ansible/hosts"
    host = "127.0.0.1"
    group = "test"

    plugin = dir_vars()
    plugin._load_name = "dir_vars"
    plugin.REQUIRES_WH

# Generated at 2022-06-11 19:17:20.577952
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from units.mock import patch
    from units.plugins.loader import vars_loader_mod
    from units.plugins.loader.vars_loader import VarsModule

    inv_vars = VarsModule('inv_vars')
    vars_loader_mod.add(inv_vars, 'inv_vars')

    host_vars = VarsModule('host_vars')
    setattr(host_vars, 'get_host_vars', lambda x: {'host_key': 'host_value'})
    vars_loader_mod.add(host_vars, 'host_vars')

    group_vars = VarsModule('group_vars')
    setattr(group_vars, 'get_group_vars', lambda x: {'group_key': 'group_value'})


# Generated at 2022-06-11 19:17:31.137250
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader

    class vars_plugin1:
        def get_vars(self, loader, path, entities):
            return {'key1': 'value1'}

    class vars_plugin2:
        def get_group_vars(self, group):
            return {'key2': 'value2'}

    class vars_plugin3:
        def get_host_vars(self, host):
            return {'key3': 'value3'}

    class vars_plugin4:
        def run(self):
            pass

    vars_loader.add(vars_plugin1(), "_")
    vars_loader.add(vars_plugin2(), "_")
    vars_loader.add(vars_plugin3(), "_")
    vars_loader

# Generated at 2022-06-11 19:17:51.178613
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    import os
    from ansible.config.manager import ConfigManager
    from ansible.plugins.loader import vars_loader
    test_dir = os.path.join(os.path.dirname(__file__), 'vars_plugin')
    config_manager = ConfigManager(conf_base_path=test_dir)
    vars_loader.add_directory(os.path.join(test_dir, 'vars_plugins'))
    data = get_vars_from_path(config_manager, '', [], 'task')
    assert data["from_all"]
    assert not data["from_task"]
    assert not data["from_start"]
    data = get_vars_from_path(config_manager, '', [], 'inventory')
    assert data["from_all"]

# Generated at 2022-06-11 19:17:54.496520
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    path = './lib/ansible/plugins/vars'

    entities = [Host('localhost')]

    stage='inventory'

    try:
        data = get_vars_from_path(path,entities,stage)
        print(data)
    except AnsibleError as e:
        print(e.message)

# Generated at 2022-06-11 19:18:03.372292
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    path = u'examples/inventory'
    inventory = InventoryManager(loader=DataLoader(), sources=path)
    loader = DataLoader()

    host = inventory.get_host('jumper')
    group = inventory.get_group('ungrouped')
    path = path + u'/'

    plugin = next(iter(vars_loader.all()))
    plugin.get_option = lambda x: None

    data = get_plugin_vars(loader, plugin, path, [host])
    assert data == {'hostvars': {u'jumper': {}}}

# Generated at 2022-06-11 19:18:09.714147
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert(get_vars_from_path(None, './tests/unit/vars/vars_dir', None, 'inventory') ==
           {
               'group_file_var': 'group_file_var_value',
               'group_yaml_var': 'group_yaml_var_value',
               'host_file_var': 'host_file_var_value',
               'host_yaml_var': 'host_yaml_var_value'
           })

# Generated at 2022-06-11 19:18:10.624709
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    pass

# Generated at 2022-06-11 19:18:11.803362
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    assert(get_plugin_vars(None, None, None) is None)

# Generated at 2022-06-11 19:18:12.416427
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    pass

# Generated at 2022-06-11 19:18:12.862163
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert True

# Generated at 2022-06-11 19:18:21.843614
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugins
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    host = Host('localhost')
    group = Group('group', has_inventory=True)
    loader = object()
    some_dir = 'tests/test_vars_plugin/some_dir'
    path = os.path.join(os.getcwd(), some_dir)
    plugin = vars_plugins.addition(loader, 'addition', some_dir)
    assert get_plugin_vars(loader, plugin, path, [host]) == {'add_two': 4}
    assert get_plugin_vars(loader, plugin, path, [group]) == {}

# Generated at 2022-06-11 19:18:29.510469
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    '''Unit test for ansible.inventory.vars_plugins.get_vars_from_path'''
    from ansible.plugins.loader import vars_loader
    vars_loader.add_directory(os.path.join(os.path.dirname(__file__), u'../test_vars_plugin'))
    vars_loader.add_directory(os.path.join(os.path.dirname(__file__), u'../test_vars_plugin_use_dirname'))
    plugin_2 = next(iter(x for x in vars_loader if x.file_name == 'test_vars_plugin_2'))
    loaded_plugins = vars_loader.all()


# Generated at 2022-06-11 19:18:38.459497
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars.core import VarModule
    import ansible.parsing.plugin_docs as plugin_docs

    plugin_docs.readme = lambda x: ""
    plugin = VarModule()

    loader, path, entities = None, None, None
    assert get_plugin_vars(loader, plugin, path, entities) == {}

# Generated at 2022-06-11 19:18:49.245615
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    from ansible.parsing.dataloader import DataLoader
    from unittest import TestCase

    class FakeGlobalPlugin:

        def get_vars(self, loader, path, entities):
            return {'fake': 'global'}

    class FakeTaskPlugin:

        def get_vars(self, loader, path, entities):
            return {'fake': 'task'}

    class FakeBothPlugin:

        def get_vars(self, loader, path, entities):
            return {'fake': 'both'}

    class FakeLegacyPlugin:

        def get_host_vars(self, host):
            return {'fake': 'host'}

    class FakeHostPlugin:

        def get_vars(self, loader, path, hosts):
            return {'fake': 'host'}


# Generated at 2022-06-11 19:18:51.918157
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert get_vars_from_path(None, '', [], 'inventory')

# Generated at 2022-06-11 19:18:55.817773
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    vars_plugin_test = vars_loader.get("vars_test_plugin")
    data = get_plugin_vars("loader_test", vars_plugin_test, "path_test", ["entity"])
    assert data["test"] == ("test vars plugin")



# Generated at 2022-06-11 19:19:03.156626
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    from ansible.plugins.vars import vars_cache
    from ansible.plugins.vars import vars_cache_plugins

    # Load all the plugins
    vars_cache.clear()
    vars_cache_plugins.clear()
    vars_loader.clear_all()

    # Create a fake loader
    class FakeLoader():

        def path_dwim(self, path):
            return path

    my_loader = FakeLoader()

    # Create a simple plugin

    class MyVarsPlugin():
        def get_vars(self, loader, path, entities, cache=True):
            return {'foo': 'bar'}

    # Add the plugin to the cache
    plugin = MyVarsPlugin()
    plugin._load_name = 'my_vars_plugin'

# Generated at 2022-06-11 19:19:13.823596
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    # Reset the paths for vars plugins to a single directory
    C.VARS_PLUGINS_PATH = os.path.join(os.path.dirname(__file__), 'vars_plugins')
    vars_loader.add_directory(C.VARS_PLUGINS_PATH)

    InventoryManager.SET_CACHE = False
    variable_manager = VariableManager()
    loader = DataLoader()

    host = Host("testhost")
    host.set_variable("User", "Guest")
    host.set_variable("Password", "Pass")
    group = Host("testgroup")
    group.set_variable("User", "Admin")


# Generated at 2022-06-11 19:19:24.094811
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    VARIABLE_PLUGINS_ENABLED = ['vars_foo', 'vars_bar']

    loader = None
    path = "test_path"
    entities = ["entity1", "entity2"]
    stage = "inventory"
    data = {}

    vars_plugin_list = list(vars_loader.all())
    for plugin_name in VARIABLE_PLUGINS_ENABLED:
        if AnsibleCollectionRef.is_valid_fqcr(plugin_name):
            vars_plugin = vars_loader.get(plugin_name)
            if vars_plugin is None:
                # Error if there's no play directory or the name is wrong?
                continue

# Generated at 2022-06-11 19:19:31.650603
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    import sys
    import os

    sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))
    from ansible.plugins.loader import vars_loader

    loader = vars_loader.get('/etc/ansible/roles/role/defaults/main.yml')
    data = get_plugin_vars(loader, path, entities)

    print(data)

# Generated at 2022-06-11 19:19:39.438976
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    # test plugin with get_vars method
    class PluginV2:

        def _init_(self, loader, name):
            self.get_vars = lambda x: {'test': 'value'}

    # test plugin with get_host_vars and get_group_vars methods
    class PluginV1:

        def _init_(self, loader, name):
            self.get_host_vars = lambda x: {'host_test': 'host_value'}
            self.get_group_vars = lambda x: {'group_test': 'group_value'}

    # test plugin with get_option and run methods (v1 style plugin)
    class PluginV1_2:

        def _init_(self, loader, name):
            self.get_option = lambda x: x

# Generated at 2022-06-11 19:19:43.590699
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    class MockVarsLoader():
        def get(self, name):
            return None

    class MockPlugin():
        pass

    mock_vars_loader = MockVarsLoader()
    mock_plugin = MockPlugin()
    assert get_plugin_vars(mock_vars_loader, mock_plugin, '', '') == {}

# Generated at 2022-06-11 19:19:52.252767
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugins
    plugin = vars_plugins.get('yaml')
    data = get_plugin_vars('', plugin, '', [])
    assert plugin._load_name == 'yaml'
    assert data == {}

# Generated at 2022-06-11 19:19:55.578351
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    loader = None
    path = '/etc/ansible/vars/'
    entities = ['localhost']
    stage = 'inventory'
    data = get_vars_from_path(loader, path, entities, stage)
    assert data == {}

# Generated at 2022-06-11 19:19:57.418837
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    result = get_vars_from_path("","",[Host("")],"inventory")
    assert result != ""

# Generated at 2022-06-11 19:20:05.879329
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    import os
    import shutil
    import tempfile

    # Make a temp dir to work in
    tmp_dir = tempfile.mkdtemp()

# Generated at 2022-06-11 19:20:15.351875
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    class FakeLoader:
        pass

    class Plugin:
        _load_name = "_load_name"
        _original_path = "original_path"

        def get_vars(self, loader, path, entities):
            return {'plugin_test_key': 'plugin_test_value'}

    class Plugin2:
        _load_name = "_load_name"
        _original_path = "original_path"

        def get_host_vars(self, host_name):
            return {'host_plugin_test_key': 'host_plugin_test_value'}

        def get_group_vars(self, group_name):
            return {'group_plugin_test_key': 'group_plugin_test_value'}

    class Plugin3:
        _load_name = "_load_name"


# Generated at 2022-06-11 19:20:21.927573
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.constants import load_config_file
    from ansible.plugins.loader import collection_loader
    from ansible.plugins.vars import PluginLoader

    # Test with ansible.cfg existing
    config_data = load_config_file()
    if config_data:
        display.display('Using config file: ' + config_data['config_file'])
    else:
        display.display('Using default config')

    # Test with a valid path
    current_path = os.path.realpath(os.path.dirname(__file__))
    # By setting VARIABLE_PLUGINS_ENABLED it will exclude all other plugin if they are not listed
    loader = PluginLoader(variable_plugins_enabled=['m_vars'], config_data=config_data)
    vars_plugin_list

# Generated at 2022-06-11 19:20:30.999893
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    class fakevar(object):
        def get_vars(self, loader, path, entities):
            return {"a": 1}
        def get_host_vars(self, host):
            return {"a": 1}
        def get_group_vars(self, group):
            return {"a": 1}

    class fakevar_run(object):
        def run(self, host):
            return {"a": 1}
        def run_host(self, host):
            return {"a": 1}
        def run_group(self, group):
            return {"a": 1}

    class fakevar_run_fail(object):
        def run(self, host):
            return {"a": 1}


# Generated at 2022-06-11 19:20:38.723602
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    '''
    This function allows us to run unit-tests against internal functions like
    get_vars_from_path
    '''
    from ansible.plugins import vars
    loader = vars.VarsModule()
    inventory_file = 'file'
    inventory_directory = 'directory'
    inventory_group = 'group'
    inventory_host = 'host'
    data = get_vars_from_path(loader, inventory_directory, [inventory_group, inventory_host], 'inventory')
    assert data == {}
    data = get_vars_from_path(loader, inventory_file, [inventory_group, inventory_host], 'inventory')
    assert data == {}

# Generated at 2022-06-11 19:20:46.640922
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    import unittest
    import ansible.plugins.vars.test

    class TestGetVarsFromPath(unittest.TestCase):

        # Tests that a v2 plugin raises an AnsibleError
        @unittest.skipIf(ansible.plugins.vars.test.USE_V1, "Test requires v2 vars plugin.")
        def test_get_vars_from_path_v2(self):
            plugin = vars_loader.get("test_vars_plugin")
            from ansible.inventory.manager import InventoryManager
            from ansible.parsing.dataloader import DataLoader
            loader = DataLoader()
            inventory = InventoryManager(loader=loader, sources=[])
            path = u"/"
            entities = [inventory.get_host("localhost")]

# Generated at 2022-06-11 19:20:57.049581
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    class A:
        _load_name = 'a'
        plugin_type = 'a'
        get_vars = lambda self, loader, path, entities: {'a': 1}

    class B:
        _load_name = 'b'
        plugin_type = 'b'
        get_vars = lambda self, loader, path, entities: {'a': 1}
        get_option = lambda self, name: None

    class C:
        _load_name = 'c'
        plugin_type = 'c'
        get_vars = lambda self, loader, path, entities: {'a': 1}
        has_option = lambda self, name: True

    class D:
        _load_name = 'd'
        plugin_type = 'd'

# Generated at 2022-06-11 19:21:07.871904
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    pass

# Generated at 2022-06-11 19:21:17.489413
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    loader = None
    path = 'path'
    entities = []
    stage = 'start'

    vars_loader.add_directory(os.path.join(os.path.dirname(__file__), 'plugins/vars_plugins'))

# Generated at 2022-06-11 19:21:26.260455
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    loader = None
    entities = [{}, {}]
    stage = 'task'

    # empty path
    vars_path = "/"
    try:
        assert not get_vars_from_path(loader, vars_path, entities, stage)
    except Exception:
        raise AssertionError("Cannot load vars from path %s" % vars_path)

    # wrong path
    vars_path = "/test/test"
    try:
        get_vars_from_path(loader, vars_path, entities, stage)
    except Exception:
        pass
    else:
        raise AssertionError("vars.yml path %s is not exist" % vars_path)

    # normal path

# Generated at 2022-06-11 19:21:36.275417
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    vars_plugin_list = list(vars_loader.all())
    # Check if all plugins in the list are vars plugins
    for plugin in vars_plugin_list:
        assert plugin.is_vars_plugin()
        if hasattr(plugin, 'get_vars'):
            assert plugin.get_vars("loader", "path", "entities") is not None
    # Check if plugins marked as requires whitelist are passed whitelisting
    plugin_name = ["ansible.netcommon.network_group"]
    path = "/path/"
    entities = ['entities']
    stage = 'inventory'

# Generated at 2022-06-11 19:21:37.242673
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # TODO: implement
    assert False

# Generated at 2022-06-11 19:21:47.313917
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    vars_plugins_list = C.VARIABLE_PLUGINS_ENABLED.split(os.path.pathsep)
    for plugin_name in vars_plugins_list:
        plugin = vars_loader.get(plugin_name)
        if plugin is None:
            continue

        if isinstance(plugin, str):
            raise AnsibleError("Invalid vars plugin %s from %s" % (plugin._load_name, plugin._original_path))

        if not hasattr(plugin, 'run') and not hasattr(plugin, 'get_group_vars') and not hasattr(plugin, 'get_host_vars'):
            continue


# Generated at 2022-06-11 19:21:57.830578
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    vars_plugins_enabled = C.VARIABLE_PLUGINS_ENABLED
    run_vars_plugins = C.RUN_VARS_PLUGINS
    C.VARIABLE_PLUGINS_ENABLED = ['hosts', 'groups']
    C.RUN_VARS_PLUGINS = 'demand'
    host1 = Host("host1")
    host2 = Host("host2")
    host3 = Host("host3")
    host1.vars = {'host1': 1}
    host2.vars = {'host2': 2}
    host3.vars = {'host3': 3}

    class FakePlugin:
        def __init__(self, name, options=None):
            self._name = name
            self._options = options


# Generated at 2022-06-11 19:22:08.140000
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    # mock a plugin
    class MockVarsPlugin:
        # called for each inventory source
        def get_vars(self, loader, path, entities):
            if path == 'path1':
                return {'test_var': 'value1'}
            return {'test_var': 'value2'}

    # mock a loader
    mock_loader = DataLoader()

    # mock plugins
    class VarsLoaderMock:
        def get(self, name):
            return None

        def all(self):
            mock_vars_plugin = MockVarsPlugin()
            return [mock_vars_plugin]

    # mock an InventoryManager

# Generated at 2022-06-11 19:22:13.278961
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # create class loader
    loader = 'yaml'
    # create class path
    path = ''
    # create class entities
    entities = ''
    # create class stage
    stage = 'inventory'
    vars_data = get_vars_from_path(loader, path, entities, stage)
    # print(vars_data)

# Generated at 2022-06-11 19:22:19.903664
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # assert_equal is imported as part of pytest.
    # pylint: disable=no-name-in-module
    from pytest import assert_equal
    loader = None
    path = 'path'
    entities = []
    stage = 'inventory'
    data = {'vars_file': None, 'vars_dir': None}
    assert_equal(get_vars_from_path(loader, path, entities, stage), data)

# Generated at 2022-06-11 19:22:47.782997
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    import ansible.plugins.loader as plugin_loader

    # construct fake vars plugins
    from ansible.plugins.vars import VarsModule as VarsBase

    class VarsPlugin1(VarsBase):

        def get_vars(self, loader, path, entities):
            return {'fake_key': 'fake_value'}

    class VarsPlugin2(VarsBase):

        def get_group_vars(self, group):
            return {'fake_key': 'fake_value'}

    class VarsPlugin3(VarsBase):

        def get_host_vars(self, host):
            return {'fake_key': 'fake_value'}


# Generated at 2022-06-11 19:22:57.786533
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    def plugin_get_vars(loader, path, entities):
        return {'test': 1}

    def plugin_get_host_vars(host):
        return {'test': 2}

    def plugin_get_group_vars(group):
        return {'test': 3}

    vars_loader.subdir_list._list.clear()
    vars_loader._module_cache.clear()

# Generated at 2022-06-11 19:23:02.223730
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import TestVarsPlugin
    test_plugin = TestVarsPlugin()
    assert dict(vars=1, path='/tmp/test_path') == get_plugin_vars(None, test_plugin, '/tmp/test_path', ['test_host'])


# Generated at 2022-06-11 19:23:13.804309
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.playbook.play_context import PlayContext

    class TestHost(Host):
        pass

    class TestGroup(object):
        pass

    class TestInventory(object):
        @staticmethod
        def host(hostname):
            h = TestHost(hostname)
            h.vars = {}
            return h

        @staticmethod
        def get_group(groupname):
            g = TestGroup()
            g.name = groupname
            g.vars = {}
            return g

    class TestVarsPlugin(object):
        _load_name = 'TestVarsPlugin'

        def __init__(self):
            self._host = None
            self._group = None
            self._path = None
            self._entities = None


# Generated at 2022-06-11 19:23:23.369486
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    loader = None
    path = 'sample/path'
    display.verbosity = 4

    entities = []
    entities.append(Host("127.0.0.1"))
    entities.append("test_group")

    print("\nTesting get_vars_from_path() ....")
    print("\nInput :: path = %s, entities = %s" % (path, entities))

    data = get_vars_from_path(loader, path, entities, stage='inventory')
    print("\nOutput :: data = %s" % data)
    print("\nEnd of unit test for get_vars_from_path() ....\n")



# Generated at 2022-06-11 19:23:29.771378
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.plugins.vars import IniVarProvider
    from ansible.plugins.vars.host_group import GroupVars
    from ansible.plugins.vars.host_group import HostVars

    vars_loader.set_directory('./vars_plugins')
    vars_loader.all()

    data = {}
    entities = [Host('host1')]

    plugin = IniVarProvider()
    plugin_vars = get_plugin_vars(None, plugin, '/dev/null', entities)
    data = combine_vars(data, plugin_vars)

    plugin = GroupVars()
    plugin_vars = get_plugin_vars(None, plugin, '/dev/null', entities)