

# Generated at 2022-06-11 19:13:55.956309
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    loader = '/path/to/loader.py'
    path = '/path/to/test/data'
    entities = ('host1', 'host2', 'group1', 'group2')
    # test v2 plugin
    plugin = 'test_plugin'
    assert get_plugin_vars(loader, plugin, path, entities) == '/path/to/test/data'
    # test v1 plugin
    def get_host_vars(host):
        return host
    plugin.get_host_vars = get_host_vars
    assert get_plugin_vars(loader, plugin, path, entities) == ('host1', 'host2')
    def get_group_vars(group):
        return group
    plugin.get_group_vars = get_group_vars

# Generated at 2022-06-11 19:13:56.718046
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert False

# Generated at 2022-06-11 19:14:03.568408
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    from ansible_collections.nsbl.test.plugins.vars.vars import TestVarsPluginNSBLCollection

    plugin = TestVarsPluginNSBLCollection.get_plugin().get_plugin_class()
    path = os.path.join(os.environ["COLLECTIONS_PATHS"].split(':')[0], "nsbl/test/plugins/vars/")
    entities = []

    data = get_plugin_vars(None, plugin, path, entities)
    assert data == {"nsbl__toto": "toto"}

    data = get_vars_from_path(None, path, entities, None)
    assert data == {"nsbl__toto": "toto"}

# Generated at 2022-06-11 19:14:04.277314
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    pass

# Generated at 2022-06-11 19:14:13.724720
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    dummy_loader = None
    dummy_entities = {}
    dummy_path = None

    class DummyVarsPlugin():

        def get_vars(self, loader, path, entities):
            return {'a': 'b'}

        def get_group_vars(self, group):
            return {'c': 'd'}

        def get_host_vars(self, host):
            return {'e': 'f'}

        def run(self):
            pass

    class DummyVarsPluginNotV2():

        def get_host_vars(self, host):
            pass

    dummy_vars_plugin = DummyVarsPlugin()
    dummy_vars_plugin_not_v2 = DummyVarsPluginNotV2()


# Generated at 2022-06-11 19:14:22.710100
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.cli import CLI
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    # Prevent optional dependencies from breaking this test
    current_shells = C.DEFAULT_SHELL_PLUGINS_ENABLED
    current_vars = C.VARIABLE_PLUGINS_ENABLED
    current_action = C.DEFAULT_ACTION_PLUGINS_ENABLED
    C.DEFAULT_SHELL_PLUGINS_ENABLED = []
    C.VARIABLE_PLUGINS_ENABLED = ['test_vars_plugin']
    C.DEFAULT_ACTION_PLUGINS_ENABLED = []


# Generated at 2022-06-11 19:14:33.781246
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    # Tests one file with two plugins and a combination of two files with one plugin each
    # and two files with a single plugin but only one of those files supporting a stage
    # option.  All the plugins will try to run but only the ones which are enabled and
    # support the stage will return data.
    sources = [
        'source1.yaml',
        'source2.yaml',
        'source3.yaml',
        'source4.yaml',
    ]

    # list of tuples - plugin, name, return value

# Generated at 2022-06-11 19:14:44.521093
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.config.manager import ConfigManager

    # We don't have a config, so we have to initialize the ConfigManager
    # by hand here
    config_manager = ConfigManager()

    # Assume a default config
    config_manager._parser = config_manager.load_source()

    # Test vars plugin
    class TestVarsPlugin:

        def __init__(self):
            self._load_name = 'test'
            self._original_path = '/path/to/plugins/test'

        def get_vars(self, loader, path, entities):
            return {'test_vars_plugin_get_vars': True}

    # Test vars plugin (legacy)
    class TestVarsPluginLegacy:

        def __init__(self):
            self._load_name = 'test'
            self

# Generated at 2022-06-11 19:14:45.939068
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    vars_plugin_list = list(vars_loader.all())
    assert vars_plugin_list

# Generated at 2022-06-11 19:14:46.794933
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    pass



# Generated at 2022-06-11 19:15:00.973987
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins import vars_loader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play_context import PlayContext

    class Mock_Task:
        def __init__(self, name, action='normal'):
            self.name = name
            self.action = action

    class Mock_Play:
        def __init__(self, tasks):
            self.tasks = tasks

    class Mock_Loader:
        def __init__(self, path):
            self.path = path

        def path_exists(self, path):
            return self.path == path

    class Mock_Vars_Plugin:
        def __init__(self, name):
            self._load_name = name


# Generated at 2022-06-11 19:15:07.579307
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    entities = [Host(name="host1")]
    inventory = """
[group1]
host1
host2

[group2]
host1
host3

[all:vars]
g_var1=g_val1

[group1:vars]
h_var1=h_val1
h_var2=h_val2

[group2:vars]
h_var1=h_val1
s_var1=s_val1
"""
    loader = DataLoader()
    vars_manager = VariableManager()
    vars_manager._vars_plugins = vars_loader.all()

# Generated at 2022-06-11 19:15:15.948556
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    inventory = '''[groupA]
server1
server2'''
    loader = MockLoader()
    plugin_list = [MockPlugin1, MockPlugin2, MockPlugin3]
    loader.set_plugin_list(plugin_list)
    path = os.path.join(C.DEFAULT_LOCAL_TMP, 'inventory_data')
    if not os.path.isdir(path):
        os.makedirs(path)
    inventory_file = os.path.join(path, 'inventory')
    with open(inventory_file, 'w') as f:
        f.write(inventory)
    result = get_vars_from_path(loader, path, ['server1', 'server2'], 'task')

# Generated at 2022-06-11 19:15:26.349863
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.vars.clean import annotation_processor

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[
        os.path.join(os.path.dirname(__file__), '../../ansible/test/inventory/test_inventory.ini'),
    ])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    variable_manager._options = {'_ansible_vault_password': 'testpasswd'}
    variable_manager.set_inventory(inventory)
    plugin = vars_loader.get(
        'group_by',
        class_only=True,
    )
    inventory

# Generated at 2022-06-11 19:15:31.758599
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.loader import vars_loader
    data = {}
    plugin = vars_loader.get('yaml_file')
    path = '/etc/ansible/roles/test/vars'

    data = get_plugin_vars(path, [])
    print(data)


# Generated at 2022-06-11 19:15:38.488250
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Build test path
    path = 'some/path'
    # Build test entities, empty list
    entities = []
    # Build test stage, set to 'inventory'
    stage = 'inventory'
    # Build test loader, set to None
    loader = None
    # Run the get_vars_from_path function
    vars = get_vars_from_path(loader, path, entities, stage)
    # Make sure the returned data is a dictionary
    assert isinstance(vars, dict)


# Generated at 2022-06-11 19:15:47.600224
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import var_prompt

    # Load plugins
    var_prompt.VarsModule()

    loader = None
    path = './tests/unit/vars_plugins/'
    entities = [Host("hostname")]
    stage = 'task'
    result = get_vars_from_path(loader, path, entities, stage)
    assert result == {'vars_prompt': 'prompt_value', 'vars_vault': 'vault_value'}

    loader = None
    path = './tests/unit/vars_plugins/'
    entities = [Host("hostname")]
    stage = 'inventory'
    result = get_vars_from_path(loader, path, entities, stage)

# Generated at 2022-06-11 19:15:58.139457
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.cli.arguments import option_helpers as opt_help
    from ansible.plugins.loader import vars_cache

    loader, inventory, variable_manager = opt_help.setup_inventory(opt_help.parse_cli_args(['-i', 'localhost,']))

    plugin_manager = vars_cache.VarsCache(inventory)
    plugin_manager.set_host_list(["localhost"])

    data = get_vars_from_path(loader, os.path.dirname(os.getcwd()), plugin_manager.get_hosts("localhost"), 'task')

    assert(data['ansible_user_id'] == 'rdegges')

# Generated at 2022-06-11 19:16:09.778823
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # This is a trivial case that doesn't test the functionality, but we test it to show that it works
    # The purpose of this function is that it's not a one line operation, it has a lot of logic
    # so it would be much harder to test if we didn't have this utility function
    from ansible.inventory.script import ScriptInventory
    from ansible.parsing.dataloader import DataLoader

    script_path = 'tests/test_utils/test_vars_plugin/index.yml'

    i = ScriptInventory(loader=DataLoader(), script=script_path)
    entities = i.get_hosts()

    # We need to do this to initialize the plugins, otherwise they won't get loaded
    i.hosts.add('dummy_host')

# Generated at 2022-06-11 19:16:14.410272
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    _plugin = vars_loader.get('yaml')
    _loader = '_'
    _path = 'path'
    _entities = ['host1', 'host2']
    assert get_plugin_vars(_loader, _plugin, _path, _entities) is not None


# Generated at 2022-06-11 19:16:27.659456
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.loader import vars_loader
    from ansible.plugins.vars import auto_legacy, auto

    loader = vars_loader
    plugin = auto_legacy
    path = None
    entity = {'name': 'test.com',
              'group_names': [],
              'groups': [],
              '_parent_groups': [],
              '_ancestor_groups': [],
              'profile': ['test_group'],
              'inventory_dir': '',
              'config_dir': '',
              'vars': {'foo': 'bar'}}

    entities = [entity]
    expected = {'foo': 'bar'}
    actual = get_plugin_vars(loader, plugin, path, entities)
    assert expected == actual

    plugin = auto

# Generated at 2022-06-11 19:16:37.908390
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.cli.arguments import option_helpers

    option_helpers.set_defaults()

    loader = DictDataLoader({
        'group_vars': {
            'group1': {},
            'group2': {},
        },
        'group_vars/group1': {},
        'group_vars/group2': {},
    })

    sources = [
        './playbook',
        './hosts',
    ]
    entities = [
        Host('host1'),
        Host('host2'),
        Host('host3'),
    ]
    stage = 'start'
    data = get_vars_from_inventory_sources(loader, sources, entities, stage)

    assert len(data) == 2



# Generated at 2022-06-11 19:16:49.318129
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    from ansible.config.manager import ConfigManager
    from ansible.plugins.loader import vars_loader
    from ansible.utils.display import Display
    from ansible.inventory.manager import InventoryManager

    plugin = None
    loader = '_test_'
    path = os.path.dirname(__file__)
    display = Display()

    # load config manager
    config_data = {}
    config_manager = ConfigManager(config_data)

    ent_list = []

    # generate sample host
    host = Host(name='test_host')
    ent_list.append("test_host")

    # Testing the plugin with get_vars function

# Generated at 2022-06-11 19:16:59.100557
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    loader, entities, injector = setup_plugin_loader([
        {
            "foo": "1",
            "bar": "2",
            "baz": "3"
        },
        {
            "foo": "2",
            "bar": "3",
            "baz": "4"
        },
        {
            "bar": "3",
            "baz": "5"
        },
        {
            "bar": "5",
            "baz": "4"
        }
    ])

    assert get_vars_from_path(loader, ".", entities, "inventory") == {
            "foo": "2",
            "bar": "5",
            "baz": "4"
    }

    # Test for a BUG: Plugin lowered the priority of the file based inventory variables
    #


# Generated at 2022-06-11 19:17:09.318723
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.lookup.vars import LookupModule
    from ansible.plugins.loader import vars_loader

    TEST_TEXT = 'test'

    class DummyPlugin(object):
        def get_vars(self):
            return {'foo': TEST_TEXT}

    dummy_obj = DummyPlugin()
    vars_loader.add(DummyPlugin, 'dummy')
    assert get_vars_from_path(vars_loader, '/tmp', [], 'inventory') == {'foo': TEST_TEXT}

    class DummyPlugin(object):
        def get_host_vars(self, host):
            return {'foo': TEST_TEXT}

    dummy_obj = DummyPlugin()
    vars_loader.add(DummyPlugin, 'dummy')
    assert get_vars_

# Generated at 2022-06-11 19:17:20.676642
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader, 'localhost,')
    display.verbosity = 3

    inventory.extra_vars = {
        'foo': 'bar'
    }

    entities = inventory._inventory.get_hosts()
    data = get_vars_from_path(loader, os.path.dirname(__file__), entities, 'inventory')
    assert isinstance(data, dict)
    assert data['inventory_dir'] == os.path.dirname(__file__)
    assert data['inventory_file'] is None
    assert data['inventory_file_no_suffix'] is None
    assert data['inventory_hostname'] == 'localhost'

# Generated at 2022-06-11 19:17:25.836795
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert {
        'test1': {
            'user1': 'value1',
            'user2': 'value2'
        },
        'test2': {
            'user3': 'value3',
            'user4': 'value4'
        }
    } == get_vars_from_path(None, None, ['test1', 'test2'], 'host')


# Generated at 2022-06-11 19:17:34.642842
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    from ansible.plugins.loader import vars_loader, module_loader

    results = []
    plugin_paths = []

    for plugin_path in module_loader._get_paths('vars'):
        if plugin_path not in plugin_paths:
            plugin_paths.append(plugin_path)

    for path in plugin_paths:
        results.extend(module_loader._module_finder(path, 'vars_plugins'))

    loader = module_loader.ModuleLoader(None, 'test', 'vars', 'vars_plugins')
    loader.meta_overrides = loader._get_metadata(results)
    plugin_list = list(vars_loader.all())
    plugin = vars_loader.get('test')
    entities = []

    data = get_vars_from_path

# Generated at 2022-06-11 19:17:42.357676
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    loader = vars_loader
    from ansible.module_utils._text import to_bytes
    from ansible.inventory import Inventory
    loader._package_paths = ['ansible/plugins/vars']
    data = {}
    path = os.path.dirname(to_bytes(__file__))
    entities = Inventory().get_hosts()
    data = combine_vars(data, get_vars_from_path(loader, path, entities, 'task'))
    print(data)

# Generated at 2022-06-11 19:17:42.889347
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    pass

# Generated at 2022-06-11 19:18:00.487896
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    pass

# Generated at 2022-06-11 19:18:11.472323
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader

    class VarsRunner:
        VARS = {'a': 1}

        def run(self, *args, **kwargs):
            return self.VARS

    class VarsRunner2:
        VARS = {'a': 2}

        def run(self, *args, **kwargs):
            return self.VARS

    def run_plugin(plugin):
        C.VARIABLE_PLUGINS_ENABLED.append(plugin.__class__.__name__)
        plugin.get_vars = lambda *args, **kwargs: plugin.run(*args, **kwargs)
        ret = get_vars_from_path(None, None, [], 'task')
        assert plugin.__class__.__name__ in ret

# Generated at 2022-06-11 19:18:17.739224
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.utils.path import unfrackpath

    plugin_vars_path = unfrackpath('lib/ansible/plugins/vars')

    old_collection = None
    for vars_plugin in vars_loader.all(class_only=True):
        if AnsibleCollectionRef.is_valid_fqcr(vars_plugin):
            vars_plugin_name = vars_plugin.pop('_name')
            vars_plugin_path = vars_plugin.pop('_path')
            vars_plugin_namespace = vars_plugin.pop('_namespace')
            vars_plugin_collection = vars_plugin.pop('_collection')
            vars_plugin_file_name = vars_plugin.pop('_original_path')

# Generated at 2022-06-11 19:18:25.828941
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager

    inventory_path = './test/units/plugins/inventory/vars/hosts'
    sources = [inventory_path]
    loader = InventoryManager(sources=sources, sources_list=sources)
    inventory = loader.get_inventory()

    host = inventory.get_host("test_001")
    group = inventory.get_group('all')

    assert host.vars['var1'] == 'a'
    assert group.vars['var2'] == 'b'

# Generated at 2022-06-11 19:18:35.440795
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    import ansible
    import unittest

    print(ansible.__version__)

    class TestVarsPlugin(object):
        def __init__(self, name, path, data):
            self._name = name
            self._path = path
            self._data = data

        def get_vars(self, loader, path, entities):
            return self._data

    class TestVarsPlugin2(object):
        def __init__(self, name, path, data):
            self._name = name
            self._path = path
            self._data = data

        def get_vars(self, loader, path, entities):
            return self._data

        def get_host_vars(self, host):
            return self._data

        def get_group_vars(self, group):
            return self._data



# Generated at 2022-06-11 19:18:42.998733
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    import pytest
    from ansible.inventory.loader import InventoryLoader
    from ansible.plugins.loader import vars_loader

    vars_plugin_list = list(vars_loader.all())

    for plugin_name in C.VARIABLE_PLUGINS_ENABLED:
        if AnsibleCollectionRef.is_valid_fqcr(plugin_name):
            vars_plugin = vars_loader.get(plugin_name)
            if vars_plugin is None:
                # Error if there's no play directory or the name is wrong?
                continue
            if vars_plugin not in vars_plugin_list:
                vars_plugin_list.append(vars_plugin)

    for plugin in vars_plugin_list:
        assert(plugin.namespace is not None)

# Generated at 2022-06-11 19:18:50.587119
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    class TestPlugin:
        @staticmethod
        def get_vars(loader, path, entities):
            return {'test_var': 'test_value'}
        @staticmethod
        def get_option(name):
            return None
    loader = object()
    mock_plugin_obj = TestPlugin()
    vars_plugin_list = [mock_plugin_obj]
    data = get_vars_from_path(loader, 'inventory_path', [], 'start')
    assert data == {'test_var': 'test_value'}



# Generated at 2022-06-11 19:19:00.209153
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    for varname in vars_loader.all():
        print(varname)

    print("get_vars_from_path for /home/lx/ansible_playbooks/playbooks/roles/repo/tasks/main.yml")
    data = get_vars_from_path("/home/lx/ansible_playbooks/playbooks/roles/repo/tasks/main.yml")
    print("vars.repo.upstream.repos: %s" % data["vars.repo.upstream.repos"])
    data = {'ansible': {'foo': 42}}

# Generated at 2022-06-11 19:19:07.141430
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader, sources='localhost,')
    all_hosts = inventory.hosts
    host = all_hosts['localhost']

    def check_vars_from_path(global_setting, plugin_setting, expected):
        """
        Mock function to wrap get_vars_from_path
        """
        global C
        C.VARIABLE_PLUGINS_ENABLED = {'test_vars': 'test_vars'}
        C.RUN_VARS_PLUGINS = global_setting
        plugin = DummyVarsPlugin(plugin_setting)

# Generated at 2022-06-11 19:19:08.275363
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert get_vars_from_path(None, None, None, None) == {}

# Generated at 2022-06-11 19:19:25.938700
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.vars import yaml

    test_dir = os.path.dirname(os.path.realpath(__file__))

    test_file = os.path.join(test_dir, '../data/test_vars_plugin.yml')
    plugin = yaml.VarsModule()

    data = get_plugin_vars(None, plugin, test_file, [])
    assert data == {"key1": "value1"}

# Generated at 2022-06-11 19:19:37.011172
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    import ansible.plugins.loader
    from ansible.parsing.dataloader import DataLoader

    def _get_vars_from_path(path, entities, stage, config=None):
        config = config or {}
        config.setdefault('vars_plugins', ['host_vars', 'group_vars'])
        config.setdefault('run_vars_plugins', 'demand')
        config.setdefault('inventory', '/dev/null')
        loader = DataLoader()
        vars_plugins = ansible.plugins.loader.vars_loader
        vars_plugins.set_options(config)
        return get_vars_from_path(loader, path, entities, stage)


# Generated at 2022-06-11 19:19:42.518570
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.vars import keys

    loader = DummyVarsLoader()

    # Create a vars plugin object
    vars_plugin = keys.Keys()
    vars_plugin.get_vars = lambda loader, path, entities: {'a_plugin': path}

    assert get_vars_from_path(loader, '/tmp/path', [], 'inventory') == {'a_plugin': '/tmp/path'}


# Generated at 2022-06-11 19:19:45.157096
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    result = list(get_vars_from_path({}, '', '', ''))
    assert isinstance(result, list)

# Generated at 2022-06-11 19:19:56.026186
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    # Let's create the inventory file containing hosts
    # and create a temp folder to create and test vars plugins
    # Then test the function and return the result
    import os
    import tempfile
    import shutil

    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager

    temp_folder = tempfile.mkdtemp()
    inventory_file = tempfile.NamedTemporaryFile(prefix="ansible_test_inventory_", delete=False)

    # Create and write the content of the inventory file
    inventory_file.write(b"[local]\n")
    inventory_file.write(b"localhost ansible_connection=local\n")

    # Create the vars plugins for test

# Generated at 2022-06-11 19:19:58.504909
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars.host_group_vars import HostVars
    assert isinstance(get_plugin_vars(None, HostVars(), None, None), dict)

# Generated at 2022-06-11 19:20:04.727434
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    import ansible.plugins.loader as ploader
    class TestVarsPlugin:
        def get_vars(self, *args, **kwargs):
            return {'a': 1}
    plugin = TestVarsPlugin()
    loader = ploader.ArgvVarsLoader('/path/to/file.yml', plugin)
    path = '/path/to/dir'
    entities = []
    stage = 'inventory'
    result = get_vars_from_path(loader, path, entities, stage)
    assert result == {'a': 1}


# Generated at 2022-06-11 19:20:14.547494
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.cli.playbook.play_helpers import load_list_of_tasks
    from ansible.cli.playbook.play_context import PlayContext

    play_context = PlayContext()
    play_context._tqm = load_list_of_tasks([])

    loader = play_context.variable_manager.vars_loader
    path = './tests/test_utils/vars_plugins/vars_plugins_path'

    entities = [Host('localhost')]
    stage = 'inventory'

    data = get_vars_from_path(loader, path, entities, stage)


# Generated at 2022-06-11 19:20:21.011810
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    target_plugin = None
    class MockPlugin:
        def get_vars(self, *args):
            return {'test': 'value'}
    class MockLoader:
        def all(self):
            return [MockPlugin(), target_plugin]

    path = '/path/to/dir'
    entities = [None]
    stage = 'inventory'
    loader = MockLoader()
    data = get_vars_from_path(loader, path, entities, stage)
    assert data == {'test': 'value'}

    target_plugin = MockPlugin()
    data = get_vars_from_path(loader, path, entities, stage)
    assert data == {'test': 'value', 'test': 'value'}
    assert len(data) == 1

# Generated at 2022-06-11 19:20:27.546404
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    import ansible.plugins.vars.host_group_vars
    import ansible.plugins.vars.host_vars

    host = Host("fakehost")
    loader = {}
    path = "tests/vars_plugins"
    host_name = host.name
    entities = [host, host_name]
    data = get_vars_from_path(loader, path, entities, None)

    assert data["test_host_vars"] == "host vars"
    assert data["test_group_vars"] == "group vars"



# Generated at 2022-06-11 19:20:57.737375
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    assert(0)



# Generated at 2022-06-11 19:21:06.393616
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import vars_loader

    inv = InventoryManager(loader=None, sources=['/etc/ansible', 'playbooks/inventory'])
    inv.add_group('test_group')
    inv.add_host(Host(name='test_host', groups=['test_group'], port=1234))

    var_manager = VariableManager(loader=None, inventory=inv)
    vars_loader.add('ansible_variables', vars_loader.all().pop())
    vars_loader.add('ansible_variables2', vars_loader.all().pop())

# Generated at 2022-06-11 19:21:15.768216
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    class StubPlugin:
        def get_vars(self, loader, path, entities):
            return {'var3': 'var3_value'}

    loader = None
    path = '/path/to/dir'
    entities = ['e1', 'e2', 'e3']

    display.verbosity = 4
    vars_plugin_list = [vars_loader.get('yaml')]
    vars_plugin_list.append(StubPlugin())
    for plugin in vars_plugin_list:
        if plugin._load_name == 'yaml':
            assert get_plugin_vars(loader, plugin, path, entities) == {'var1': 'var1_value', 'var2': 'var2_value'}

# Generated at 2022-06-11 19:21:21.456261
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    class TestPlugin(object):
        def __init__(self, plugin_name):
            self._load_name = plugin_name

    class TestLoader(object):

        def __init__(self, plugins):
            self.plugins = plugins

        def all(self):
            return self.plugins().values()

        def get(self, plugin_name):
            if plugin_name not in self.plugins():
                return None
            return self.plugins()[plugin_name]

    class TestHost:
        def __init__(self, hostname):
            self.name = hostname

    class TestGroup:
        def __init__(self, groupname):
            self.name = groupname


# Generated at 2022-06-11 19:21:33.035209
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.errors import AnsibleError
    from ansible.plugins.loader import vars_loader

    # There are no vars in this plugin!
    plugin = vars_loader.get('group_by')
    assert plugin.get_vars(None, None, []) == {}

    # We should get some vars from this one
    plugin = vars_loader.get('hostname')
    assert plugin.get_vars(None, None, []) != {}

    # Older style plugins should raise an error
    class OldPlugin:
        def get_host_vars(self, name):
            return {}
    plugin = OldPlugin()
    try:
        get_plugin_vars(None, plugin, None, [])
        assert False, "Should have gotten an AnsibleError"
    except AnsibleError:
        pass

# Generated at 2022-06-11 19:21:44.756037
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    from ansible.plugins.loader import vars_loader

    class FakeVarsPlugin():
        def __init__(self, plugin_name):
            self._load_name = plugin_name
            self._original_path = os.path.join(os.path.expanduser('~'), 'ansible', 'test', 'vars_plugins', plugin_name + '.py')

        def get_vars(self, loader, path, entities):
            return {'foo': 'bar'}

    class FakeVarsV2Plugin():
        def __init__(self, plugin_name):
            self._load_name = plugin_name
            self._original_path = None
            self.vars = {'foo': 'bar'}


# Generated at 2022-06-11 19:21:45.583488
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # TODO: implement
    return

# Generated at 2022-06-11 19:21:56.798359
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    """
    Test if get_vars_from_path is getting the list of vars plugins
    and calls get_vars from each one of them.
    """
    entities = []
    path = "/path/to/inventory"
    loader = "loader"
    mock_vars_plugin_list = [MagicMock(), MagicMock()]
    loader.all.return_value = mock_vars_plugin_list

    with patch('ansible.vars.vars_plugins.get_plugin_vars'):
        get_vars_from_path(loader, path, entities, 'inventory')
        for plugin in mock_vars_plugin_list:
            plugin.get_vars.assert_called_once_with(loader, path, entities)

    # mock get_plugin_vars so that we can test the data

# Generated at 2022-06-11 19:22:07.966690
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.plugins.vars.host_group import VarsModule as alias

    loader = vars_loader
    path = os.path.dirname(os.path.abspath(__file__))
    aliases = loader.get('host_group')

    entities = {'hosts': {'localhost': {'alias': 'desk1'}}}
    data = get_vars_from_path(loader, path, entities['hosts'], 'task')
    assert 'desk1' in data

    entities = {'groups': {'local': {'alias': 'server'}}}
    data = get_vars_from_path(loader, path, entities['groups'], 'task')
    assert 'server' in data


# Generated at 2022-06-11 19:22:18.355223
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    plugins = ('test_plugin',)
    for plugin in plugins:
        vars_loader.add(vars_loader.find_plugin(plugin))

    loader = vars_loader.get("test_plugin")
    path = '/home/dev/ansible/collection/ansible'
    entities = ['localhost']
    stage = 'inventory'
    data = get_vars_from_path(loader, path, entities, stage)
    print("data is %s " % data)
    assert data['ansible_python_interpreter'] == '/usr/bin/python'

if __name__ == '__main__':
    test_get_vars_from_path()

# Generated at 2022-06-11 19:23:17.864093
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    # TODO: write test
    pass


# Generated at 2022-06-11 19:23:21.424911
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    plugin_vars = get_plugin_vars(None, vars_loader.get('systemd'), None, None)
    assert isinstance(plugin_vars, dict)
    assert 'timezone' in plugin_vars


# Generated at 2022-06-11 19:23:28.477229
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    import ansible.plugins.loader as plugins
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    vars_plugin_instance_list = [
        plugins.vars_loader.get("bogus_vars_plugin_1"),
        plugins.vars_loader.get("bogus_vars_plugin_2")
    ]

# Generated at 2022-06-11 19:23:34.756382
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    inventory = InventoryManager(loader=DataLoader(), sources='localhost,')
    plugin_vars = get_vars_from_path(inventory, "~/fake/path", ['localhost'], 'inventory')
    assert plugin_vars['inventory_file'] == 'localhost,'
    assert plugin_vars['inventory_dir'] == '~/fake/path'