

# Generated at 2022-06-11 19:13:51.122802
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.utils.collection_loader import AnsibleCollectionRef
    from ansible.inventory.manager import InventoryManager

    my_host = Host("127.0.0.1")
    my_host.name = "127.0.0.1"
    my_host.groups = ["all"]
    my_host.vars["ansible_connection"] = "local"
    my_host.vars["example_var"] = "example"
    my_host.vars["ansible_python_interpreter"] = "/usr/bin/env python"
    my_host.vars["ansible_python_interpreter_short"] = "/usr/bin/python"

# Generated at 2022-06-11 19:13:52.606139
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    get_vars_from_path()

# Generated at 2022-06-11 19:14:02.296879
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    loader = None

    test_vars_plugin = MockVarsPlugin()
    vars_loader._plugins[test_vars_plugin._load_name] = test_vars_plugin
    C.VARIABLE_PLUGINS_ENABLED = ['MockVarsPlugin']

    # Test that MockVarsPlugin behaves sensibly
    assert test_vars_plugin.get_vars(loader, 'any_path', []) == {'mock_vars_plugin': 'test'}
    assert test_vars_plugin.get_vars(loader, 'any_path', ['test_entity']) == {'mock_vars_plugin': 'test_entity'}

# Generated at 2022-06-11 19:14:12.766654
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    # Get the current working directory
    pwd = os.getcwd()

    vars_plugin_list = list(vars_loader.all())
    assert vars_plugin_list

    # Create a mock plugin that returns a fixed vars value
    class FakePlugin:
        def __init__(self):
            self._load_name = 'fake_plugin'
            self._original_path = os.path.join(pwd, 'fake_plugin.py')

        @staticmethod
        def get_host_vars(host):
            return {'test_var': True}

    # Create an inventory source with a directory that does not exist
    # This is for testing if the function can deal with that
    test_source = [os.path.join('does_not_exist', 'host_vars')]

    # Create an inventory

# Generated at 2022-06-11 19:14:22.425622
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager

    vars_plugin_list = vars_loader.all()

    for plugin in vars_plugin_list:
        # dict of inventory sources
        i_sources = {
            '../../test/integration/inventory_with_vars': {
                'plugins': ['yaml', 'ini', 'vault']
            }
        }
        # dict of inventory entities

# Generated at 2022-06-11 19:14:33.563990
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins import vars_plugins
    from ansible.plugins.loader import vars_loader

    plugin = vars_plugins.host_local.HostLocalVars()
    vars_loader.add(plugin, 'host_local')

    class TestLoader(object):
        def __init__(self, hostvars=dict()):
            self.hostvars = hostvars

        def get_basedir(self, path):
            return '/test/'

        def get_vars(self, path):
            return dict(testvar='testval')

    class TestEntity(object):
        def __init__(self, name):
            self.name = name

    class TestHost(TestEntity):
        pass

    class TestGroup(TestEntity):
        pass


# Generated at 2022-06-11 19:14:44.342827
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.dir import InventoryDirectory
    from ansible.parsing.dataloader import DataLoader

    basedir = os.path.dirname(os.path.dirname(__file__))
    dataloader = DataLoader()
    inventory = InventoryDirectory(loader=dataloader, basedir=basedir, sources=['hosts_test'])


    def test(name, path, entities, stage, data):
        assert get_vars_from_path(dataloader, path, entities, stage) == data


# Generated at 2022-06-11 19:14:53.276907
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    sources = ['/etc/ansible/hosts', '/etc/ansible/host_vars/host1', '/etc/ansible/group_vars/group1']
    entities = ['host1', 'group1']
    stage = 'inventory'
    loader = vars_loader
    print('Testing get_vars_from_inventory_sources:\n')
    print('Sources: ', sources)
    print('Entities: ', entities)
    print('Stage: ', stage)
    print('Loader: ', loader)

    result = get_vars_from_inventory_sources(loader, sources, entities, stage)
    print('\nResult: ', result)


# Generated at 2022-06-11 19:14:54.203572
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert False

# Generated at 2022-06-11 19:15:03.441621
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.var import BaseVarsPlugin, var_manager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play

    class TestVarsPlugin(BaseVarsPlugin):
        def __init__(self, *args, **kwargs):
            super(TestVarsPlugin, self).__init__(*args, **kwargs)
            self._group_list = {}
            self._host_list = {}

        def get_vars(self, loader, path, entities):
            return {'result': 'get_vars'}

        def get_group_vars(self, group):
            return {'result': 'get_group_vars'}

# Generated at 2022-06-11 19:15:15.149341
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    class FakeLoader:
        class FakePlugin:
            @staticmethod
            def get_vars(loader, path, entities):
                return {
                    "test_key_1": "test_value_1",
                    "test_key_2": "test_value_2",
                }

        _paths = []
        _plugins = {
            "fakeplugin": FakePlugin
        }

        def all(self):
            return self._plugins.values()

    loader = FakeLoader()

    assert get_vars_from_path(loader, "/", [], "inventory") == {
        "test_key_1": "test_value_1",
        "test_key_2": "test_value_2",
    }

test_get_vars_from_path()

# Generated at 2022-06-11 19:15:16.292446
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    pass

# Generated at 2022-06-11 19:15:26.485886
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.vars.host_group_vars import VarsModule as host_group_vars

    loader = None
    path = "some/path"

    test_host = Host()
    test_host.name = "test"
    test_group = Host()
    test_group.name = "testgroup"

    invalid_plugin = host_group_vars()
    invalid_plugin._load_name = "invalid_plugin"
    invalid_plugin._original_path = "/invalid/path"

    bad_v1_plugin = host_group_vars()
    bad_v1_plugin._load_name = "bad_v1_plugin"
    bad_v1_plugin._original_path = "/invalid/path"


# Generated at 2022-06-11 19:15:38.084634
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    from ansible.plugins.loader import vars_loader

    try:
        from __main__ import display
    except ImportError:
        from ansible.utils.display import Display
        display = Display()

    vars_plugin_list = list(vars_loader.all())
    for plugin_name in C.VARIABLE_PLUGINS_ENABLED:
        if AnsibleCollectionRef.is_valid_fqcr(plugin_name):
            vars_plugin = vars_loader.get(plugin_name)
            if vars_plugin is None:
                # Error if there's no play directory or the name is wrong?
                continue
            if vars_plugin not in vars_plugin_list:
                vars_plugin_list.append(vars_plugin)


# Generated at 2022-06-11 19:15:45.097899
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.parsing.dataloader import DataLoader

    s = b"""
    [localhost]
    local
    """

    l = DataLoader()

    h = Host(name='local')

    data = get_vars_from_inventory_sources(l, [l.load_from_file(path='hosts', data=s)], [h], 'inventory')

    assert isinstance(data, dict)
    assert data == {'inventory_hostname': 'local'}



# Generated at 2022-06-11 19:15:56.419025
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.groupvars import GroupVars

    data = get_vars_from_path(None, 'host', ['host'], None)
    assert data['host'] == 'host'

    data = get_vars_from_path(None, 'host', [Host('host')], None)
    assert 'host' in data
    assert data['host'] == 'host'

    data = get_vars_from_path(None, 'group', ['group'], None)
    assert 'group' in data
    assert data['group'] == 'group'

    data = get_vars_from_path(None, 'group', [HostVars('host')], None)
    assert not data

    data = get_vars_from_path

# Generated at 2022-06-11 19:16:06.968092
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    from ansible.plugins.vars.foo import VarsModule as foo
    from ansible.plugins.vars.bar import VarsModule as bar

    plugin_name = 'foo'
    plugin = foo()
    plugin._load_name = 'foo'
    plugin._original_path = '/fake/foo/path'
    data = get_plugin_vars(None, plugin, None, [])
    assert data == {'a': 1}

    plugin_name = 'bar'
    plugin = bar()
    plugin._load_name = 'bar'
    plugin._original_path = '/fake/bar/path'
    data = get_plugin_vars(None, plugin, None, [])
    assert data == {'a': 2}

# Generated at 2022-06-11 19:16:13.642625
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    import pytest
    from ansible.plugins.loader import vars_loader
    from ansible.utils.collection_loader import AnsibleCollectionRef

    results = []
    entities = []
    path = None
    stage = 'inventory'

    def test_route(self, loader, path, entities):
        results.append(self)

    class VarsPlugin:
        pass

    vars_loader.add('test', VarsPlugin())
    VarsPlugin.run = test_route

    with pytest.raises(AnsibleError):
        results.clear()
        get_vars_from_path(None, path, entities, stage)

    del VarsPlugin.run
    vars_loader.remove(AnsibleCollectionRef.parse('test'))

# Generated at 2022-06-11 19:16:23.767191
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.utils import context_objects as co

    loader = C.get_config_loader()

    for plugin in vars_loader.all():
        # do we have any inventory files to check?
        if not plugin.BYPASS_HOST_LOOP and plugin._search_paths:
            # yes, populate the inventory objects
            if plugin.INVENTORY_FILTERS:
                # yes, we need a real inventory in order to test
                inv = Inventory(loader=loader, host_list=[])
                inv.populate_inventory()
                entities = inv.get_hosts() + inv.get_groups()
            else:
                entities = []

            # set up env jinja lookups

# Generated at 2022-06-11 19:16:32.615257
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible_collections.testns.testcoll import plugins
    from ansible.plugins.loader import vars_loader

    fake_plugin = vars_loader.add_plugin(plugins.VarsModule)

    class FakeLoader(object):
        def load_from_file(self, filename):
            return fake_plugin

    class FakeHost(object):
        def __init__(self, name):
            self.name = name

    loader = FakeLoader()
    input = [FakeHost('foo')]

    # test get_host_vars
    assert get_plugin_vars(loader, fake_plugin, None, input) == {'a': 'b'}

    # test get_group_vars
    fake_plugin.get_host_vars = None

# Generated at 2022-06-11 19:16:55.385813
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    """
    unit testing for get_vars_from_path

    """
    from ansible.loader.collection_loader import AnsibleCollectionLoader
    from ansible_collections.testns.testcoll.plugins.vars import test

    # Creating test plugin
    ModuleUtilsPath = os.path.join(os.path.dirname(__file__), 'module_utils')
    loader = AnsibleCollectionLoader(ModuleUtilsPath)
    manager = loader.get('vars')
    manager.add(test.VarsModule())
    test_plugin = manager.get('test_vars_plugin')

    # Creating test inventory
    test_inventory = Host('test')

    # Creating test data
    test_data = {'test_data_var': 'test_var'}

    # Test plugin

# Generated at 2022-06-11 19:17:00.675040
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader

    vars_loader.all()

    loader = None
    path = '/tmp'
    entities = None
    stage = None

    data = get_vars_from_path(loader, path, entities, stage)

    assert data is not None



# Generated at 2022-06-11 19:17:04.441165
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    loader = 'TMP'
    path = 'TMP'
    entities = 'TMP'
    stage = 'inventory'
    vars_from_path = get_vars_from_path(loader, path, entities, stage)
    assert vars_from_path == {}



# Generated at 2022-06-11 19:17:12.927511
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    # Init
    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=None, host_list=[])
    inventory.parse_inventory(host_list='tests/unit/test_loader/test_inventory_vars_negative')
    sources = [inventory.host_list]

    # Assert
    host = inventory.get_host('h1')
    assert get_vars_from_inventory_sources(loader, sources, [host, ], stage="task") == {}

    host = inventory.get_host('h2')
    assert get_vars_from_inventory_sources(loader, sources, [host, ], stage="task") == {}

    host = inventory.get_host('h3')

# Generated at 2022-06-11 19:17:23.496111
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.loader import vars_loader, module_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.path import unfrackpath
    from ansible_collections.ansible.community.plugins.loader import vars_loader as community_vars_loader
    from ansible.config.manager import ConfigManager
    from ansible.plugins import fake_vars_plugin

    if community_vars_loader.__name__ not in sys.modules:
        sys.modules[community_vars_loader.__name__] = community_vars_loader

# Generated at 2022-06-11 19:17:33.202531
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.plugins.vars import test_vars_plugin
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    plugin_loader = AnsibleCollectionLoader()
    plugin_loader.add_directory(os.path.join(os.path.dirname(test_vars_plugin.__file__), 'vars_plugins'))
    vars_plugin = plugin_loader.get(plugin_name='test_vars_plugin')
    host = Host('test_host')
    group = Group('test_group')
    entities = [host, group]
    stage = 'task'
    data = get_vars_from_path(plugin_loader, '/home/vagrant', entities, stage)

    assert(data)

# Generated at 2022-06-11 19:17:43.748349
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    loader_mock = MagicMock()
    test_vars_path = 'test/vars'
    test_entities = ['test_entity']
    test_stage = 'inventory'

    plugin_2_0 = MagicMock()
    plugin_2_0.get_vars.return_value = {'plugin_2_0': 'test'}
    plugin_1_0 = MagicMock()
    plugin_1_0.get_host_vars.return_value = {'plugin_1_0': 'test'}
    plugin_1_0.get_group_vars.return_value = {'plugin_1_0': 'test'}
    plugin_1_0_func = MagicMock()

# Generated at 2022-06-11 19:17:50.228920
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import test_vars_plugin

    loader = vars_loader
    plugin = test_vars_plugin.ResultCallback()
    path = '/path/to/inventory/file'
    entities = [Host('testhost'), 'testgroup']

    assert get_plugin_vars(loader, plugin, path, entities) == plugin.get_vars(loader, path, entities)

# Generated at 2022-06-11 19:17:57.872128
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # test default behavior
    loader = None
    path = "/fake_path"
    entities = ["host1", "host2"]
    stage = "inventory"
    assert get_vars_from_path(loader, path, entities, stage) == {}

    # test with v1 plugin
    loader = None
    path = "/fake_path"
    entities = ["host1", "host2"]
    stage = "inventory"
    display.verbosity = 0
    assert get_vars_from_path(loader, path, entities, stage) == {}



# Generated at 2022-06-11 19:18:05.594847
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    class FakeInventoryPlugin:
        def __init__(self, _load_name, _original_path):
            self._load_name = _load_name
            self._original_path = _original_path

    class FakeInventoryPlugin2(FakeInventoryPlugin):
        REQUIRES_WHITELIST = True

        def get_vars(self, loader, path, entities):
            return {'x': 'y'}

        def get_host_vars(self, host):
            return {'a': 'b'}

        def get_group_vars(self, host):
            return {'c': 'd'}

    class FakeInventoryPlugin3(FakeInventoryPlugin2):
        REQUIRES_WHITELIST = False


# Generated at 2022-06-11 19:18:26.387037
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    class TestVarsPlugin:
        def get_option(self, opt):
            if opt == 'stage':
                return 'inventory'
        def run(self):
            return {'test_var': 'testing'}
    class TestVarsPlugin2:
        def get_option(self, opt):
            if opt == 'stage':
                return 'task'
        def run(self):
            return {'test_var2': 'testing2'}
    class TestVarsPlugin3:
        def get_option(self, opt):
            if opt == 'stage':
                return 'task'
        def run(self):
            return {'test_var3': 'testing3'}
        @property
        def REQUIRES_WHITELIST(self):
            return True
    vars_loader._all = {}
   

# Generated at 2022-06-11 19:18:29.777644
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    loader = None
    path = '~/.ansible/plugins/vars'
    entities = 'localhost'
    stage = 'task'

    # assert(get_vars_from_path(loader, path, entities, stage) == '~/.ansible/plugins/vars')


# Generated at 2022-06-11 19:18:39.102864
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    from ansible.plugins.loader import vars_loader

    data = {}
    assert data == get_vars_from_path(None, "/", None, None)

    class MockPlugin:
        get_vars = None
        get_host_vars = None
        get_group_vars = None
        run = None
        _load_name = "MockPlugin"
        _original_path = "/fake/path"

    class MockPlugin2:
        get_vars = lambda self, loader, path, entities: {loader.path: loader.path, path: path, entities: entities}
        get_host_vars = None
        get_group_vars = None
        run = None
        _load_name = "MockPlugin2"
        _original_path = "/fake/path"


# Generated at 2022-06-11 19:18:49.815541
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    ## test_file1.yml
    # a: 1
    ## test_file2.yml
    # b: 2
    ## test_dir/test_file1.yml
    # c: 3
    ## test_dir/test_file2.yml
    # d: 4

    from ansible.inventory.manager import InventoryManager
    loader = InventoryManager()
    plugin = vars_loader.get('collection_vars')
    # the test plugin will always return something
    test_plugin = vars_loader.get('test_plugin')
    entities = (loader.inventory.get_host("test_host"), loader.inventory.get_group("test_group"))

    ## test_file1.yml

# Generated at 2022-06-11 19:19:00.011254
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    # Fake the loader
    class MyLoader:
        pass

    loader = MyLoader()

    # Fake the source
    class MySource:
        pass

    source = MySource()

    # Fake the entity
    class MyEntity:
        pass

    entity = MyEntity()

    # Fake the plugin
    class MyPlugin:
        def __init__(self):
            self._load_name = "fake"

        def get_vars(self, loader, path, entities):
            return {
                'fake-loader': loader,
                'fake-path': path,
                'fake-entity': entities[0],
            }

    loader.vars_plugins = {
        'my_plugin': [MyPlugin()]
    }

    source._loader = loader
    source.path = "fake-path"

# Generated at 2022-06-11 19:19:07.017847
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.vars.mapping import Mapping
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()

    plugin_vars_file = os.getcwd() + '/tests/vars_plugins/test.yml'
    inventory = InventoryManager(loader=loader, sources=plugin_vars_file)
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    task_queue_manager = TaskQueueManager(inventory=inventory, variable_manager=variable_manager, loader=loader)

    # get the path from the inventory file

# Generated at 2022-06-11 19:19:15.047468
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import vars_loader
    from ansible.plugins.vars.host_list import VarsModule as HostListVars
    loader = vars_loader._create_loader(paths=['./lib/ansible/plugins/vars'], class_only=False)
    inv = InventoryManager(loader=loader, sources=None)
    host_list_vars = HostListVars()
    inv.add_plugin(plugin=host_list_vars)
    assert get_vars_from_inventory_sources(loader, ['./test/units/lib/ansible/inventory/sources'], [inv.hosts.get('localhost')], 'inventory') == {'test': 'var'}

# Generated at 2022-06-11 19:19:24.736760
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.cli.doc import DocCLI
    from ansible.plugins.loader import inventory_loader, vars_loader

    result = get_vars_from_inventory_sources(inventory_loader, ['../../../../../lib/ansible/plugins/inventory/sample'], ["dbservers"], 'inventory')
    assert isinstance(result, dict)
    assert result != {}
    assert result.keys() == {'color', 'foo', 'group_by_color', 'group_by_dbservers', 'hostvars'}

    result = get_vars_from_inventory_sources(inventory_loader, ['../../../../../lib/ansible/plugins/inventory/sample'], ["webservers"], 'inventory')
    assert isinstance(result, dict)
    assert result != {}

# Generated at 2022-06-11 19:19:33.251784
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    loader = None
    entities = [Host('localhost')]
    stage = 'inventory'

    # passing null sources should not error
    get_vars_from_inventory_sources(loader, None, entities, stage)

    # passing an empty list should not error
    get_vars_from_inventory_sources(loader, [], entities, stage)

    # passing a list with an empty string should not error
    get_vars_from_inventory_sources(loader, [''], entities, stage)

# Generated at 2022-06-11 19:19:38.135856
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    from ansible.plugins.vars import base_vars

    test_plugin = base_vars.BaseVars()

    loader = None

    path = '/tmp'

    host = Host('foo')

    entities = [host]

    test_plugin.get_vars = lambda x, y, z: {'a': 'b'}

    result = get_plugin_vars(loader, test_plugin, path, entities)

    assert result == {'a': 'b'}



# Generated at 2022-06-11 19:20:06.827749
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    from ansible.plugins.loader import vars_loader

    vars_plugin_list = list(vars_loader.all())
    for plugin in vars_plugin_list:
        if plugin._load_name in C.VARIABLE_PLUGINS_ENABLED and getattr(plugin, 'REQUIRES_WHITELIST', False):
            get_plugin_vars(vars_loader, plugin, '', [])

# Generated at 2022-06-11 19:20:08.236235
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert isinstance(get_vars_from_path(None, None, None, None), dict)

# Generated at 2022-06-11 19:20:08.784008
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    pass

# Generated at 2022-06-11 19:20:10.667588
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert get_vars_from_path('a', 'b', 'c', 'd') == {}

# Generated at 2022-06-11 19:20:18.442206
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.vars.vars_plugins.main import VarsModule

    class VarsModuleChild(VarsModule):
        def __init__(self, *args, **kwargs):
            self._original_path = '/path/to/file/vars_plugin.py'
            self._load_name = 'vars_plugin'

        def get_vars(self, loader, path, entities):
            return {'foo': 'bar', 'baz': 'qux'}

    plugin = VarsModuleChild()
    data = get_plugin_vars(None, plugin, '', None)
    assert data['foo'] == 'bar'
    assert data['baz'] == 'qux'

# Generated at 2022-06-11 19:20:21.382367
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    loader = None
    path = './'
    entities = []
    stage = 'inventory'

    data = get_vars_from_path(loader, path, entities, stage)
    assert data == {}

# Generated at 2022-06-11 19:20:30.066707
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    class MyHost:
        def __init__(self, name):
            self.name = name

    class MyGroup:
        def __init__(self, name):
            self.name = name


    class FakeLoader:
        def __init__(self):
            self.calls = 0

        def list_collection_paths(self, collections_paths=C.DEFAULT_COLLECTIONS_PATHS):
            self.calls += 1
            return collections_paths

    class FakeVarsPlugin:
        def __init__(self):
            self.calls = 0

        def get_vars(self, loader, path, entities):
            self.calls += 1
            if self.calls == 1:
                return {'name': 'get_vars'}
            return {}


# Generated at 2022-06-11 19:20:40.563363
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.loader import vars_loader
    from ansible.utils.collection_loader import AnsibleCollectionRef
    from ansible.utils.vars import combine_vars

    class ansible_facts():
        class _dummy():
            bsd = False
            linux = False
            selinux = False
            distrib_id = 'CentOS'
            distrib_major_version = '7'

    # check that the hostvars plugin loads when whitelisted
    C.VARIABLE_PLUGINS_ENABLED.append(AnsibleCollectionRef('ansible.builtin.hostvars'))
    host = Host(name='test')
    host.vars['ansible_facts'] = ansible_facts()
    host.vars['ansible_os_family'] = 'RedHat'
   

# Generated at 2022-06-11 19:20:46.965578
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    from ansible.inventory.host import Host

    from ansible.inventory.manager import InventoryManager

    from ansible.module_utils.plugins.loader import vars_loader

    from ansible.parsing.dataloader import DataLoader

    from ansible.playbook.play_context import PlayContext

    from ansible_collections.ansible.foo.plugins.module_utils.vars.bar import DummyVarsPlugin

    from ansible_collections.ansible.foo.plugins.module_utils.vars.baz import DummyGroupVarsPlugin, DummyHostVarsPlugin

    inventory = InventoryManager(loader=DataLoader(), sources=['localhost,'])
    dummy_vars_plugin = vars_loader.add(DummyVarsPlugin())

# Generated at 2022-06-11 19:20:57.424027
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    class MockVarsPlugin:
        def get_vars(self, loader, path, entities):
            return dict(a=1)

    class MockVarsPlugin2:
        def get_host_vars(self, host):
            return dict(b=1)

        def get_group_vars(self, group):
            return dict(c=1)

    class MockVarsPlugin3:
        def run(self):
            pass

    plugin = MockVarsPlugin()
    plugin2 = MockVarsPlugin2()
    plugin3 = MockVarsPlugin3()

    plugin._load_name = 'myname'
    plugin._original_path = 'mypath'
    plugin2._load_name = 'myname2'
    plugin2._original_path = 'mypath2'

# Generated at 2022-06-11 19:21:25.606959
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    assert get_plugin_vars(None, {"get_vars": lambda x: {"test": True}}, "/tmp/test", ["foo"]) == {"test": True}
    assert get_plugin_vars(None, {"get_host_vars": lambda x: {"test": True}}, "/tmp/test", ["foo"]) == {"test": True}
    assert get_plugin_vars(None, {"get_group_vars": lambda x: {"test": True}}, "/tmp/test", ["foo"]) == {"test": True}
    assert get_plugin_vars(None, {"get_vars": lambda x: {"test": True}}, "/tmp/test", [{"name":"foo"}]) == {"test": True}

# Generated at 2022-06-11 19:21:33.997031
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    def dummy_plugin(dummy1, dummy2, dummy3):
        return {'key': 'value'}

    loader = 'dummy'
    path = 'dummy'
    vars_plugin_list = list()
    entities = list()

    data = get_vars_from_path(loader, path, entities, vars_plugin_list)
    assert data == {}

    plugin = dummy_plugin
    vars_plugin_list.append(plugin)
    data = get_vars_from_path(loader, path, entities, vars_plugin_list)
    assert data == {'key': 'value'}

# Generated at 2022-06-11 19:21:45.698403
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # TODO: add general inventory tests
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None)
    inventory.add_host('localhost')
    inventory.add_group('ungrouped')
    inventory.add_group('all')
    inventory.add_host(host='host1', group='group1')
    inventory.add_host(host='host2', group='group2')

    vars = VariableManager(loader=None)

    assert set(get_vars_from_path(vars, './test/units/lib/ansible/plugins/vars', inventory.get_groups(), 'inventory').keys()) == set()

# Generated at 2022-06-11 19:21:56.903110
# Unit test for function get_vars_from_path
def test_get_vars_from_path():


    class FakePlugin:
        def __init__(self, path, name):
            self._original_path = path
            self._load_name = name

    class FakePlugin1(FakePlugin):
        def get_vars(self, loader, path, entities):
            return {'p1': '1'}

    class FakePlugin2(FakePlugin):
        def get_vars(self, loader, path, entities):
            return {'p2': '2'}

    class FakePlugin3(FakePlugin):
        def get_vars(self, loader, path, entities):
            return {'p3': '3'}

    class FakeHost:
        def __init__(self, name):
            self.name = name

    loader = FakePluginLoader()

# Generated at 2022-06-11 19:21:58.536172
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    assert True

# Generated at 2022-06-11 19:22:07.607510
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    vars_loader._all_vars_plugins = None

    class MockVarsPlugin:
        def __init__(self, name):
            self._load_name = name
            self._original_path = 'path'

        def get_vars(self, loader, path, entities):
            return {self._load_name: 'new'}

    vars_loader._all_vars_plugins = None

    vars_loader.add(MockVarsPlugin('name1'))
    vars_loader.add(MockVarsPlugin('name2'))

    assert get_vars_from_path(None, 'path', None, '') == {'name1': 'new', 'name2': 'new'}

# Generated at 2022-06-11 19:22:11.801617
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    loader = None
    path = "C:\Python27\Scripts"
    entities = ["webservers", "dbservers"]
    stage = "inventory"
    data = get_vars_from_path(loader, path, entities, stage)

# Generated at 2022-06-11 19:22:22.141253
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    class Host:
        name = "host"

    class Group:
        name = "group"

    class VarsPlugin:
        _load_name = "my_plugin"
        def get_vars(self, loader, path, entities):
            vars = {}
            vars[self._load_name] = "v2.0 plugin"
            return vars

    class VarsPlugin_host_vars_getter:
        _load_name = "my_plugin_host_vars_getter"
        def get_host_vars(self, hostname):
            vars = {}
            vars[self._load_name] = "v1.0 plugin (host vars getter)"
            return vars


# Generated at 2022-06-11 19:22:24.255572
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    # TODO: implement
    pass



# Generated at 2022-06-11 19:22:33.677552
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    vars_dirs = ['/tmp/vars_dirs']
    plugin_vars = {'run': {'first': 'first_run'},
                   'host': {'second': 'second_host'},
                   'group': {'third': 'third_group'}}

    class VarsModule:
        def __init__(self, vars):
            self._vars = vars
            self._load_name = 'vars_test'
            self._original_path = '/tmp/vars_test.py'

        def get_vars(self, loader, path, entities):
            return self._vars['run']

        def get_host_vars(self, host):
            return self._vars['host']

        def get_group_vars(self, group):
            return self._vars

# Generated at 2022-06-11 19:23:24.149239
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import var_plugins

    loader = DataLoader()
    sources = ['tests/inventory_sources_vars_plugin_test']
    path = os.path.join(sources[0], 'group_vars/group1')
    inventory = Inventory(loader, sources=sources)
    plugin = var_plugins.resolve_name_to_obj('VARS_PLUGIN_TEST', 'variable')
    data = get_vars_from_path(loader, path, inventory.groups.values(), 'inventory')
    assert 'group1_var' in data
    assert data['group1_var'] == 'group1'

# Generated at 2022-06-11 19:23:25.618417
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    raise NotImplementedError

# Generated at 2022-06-11 19:23:28.475260
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    assert get_vars_from_inventory_sources("loader", "sources", "entities", "task") == {'data': None}