

# Generated at 2022-06-11 19:13:51.393033
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # initialize loader
    loader = vars_loader
    # initialize plugin list
    vars_plugin_list = list(vars_loader.all())
    assert(len(vars_plugin_list) >= 1)

    # initialize vars entities
    hostvars = Host("testhost")
    groupvars = Host("testgroup")
    entities = [hostvars, groupvars]

    # initialize path
    path = "/"

    # initialize stage
    stage = "inventory"

    # unit test for case of all plugins are enabled
    C.VARIABLE_PLUGINS_ENABLED = ["yaml", "ini", "json", "hashing"]


# Generated at 2022-06-11 19:13:58.217913
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.loader import vars_loader
    loader = vars_loader
    plugin = loader.get("test_vars_plugin_legacy")
    path = "this/path/does/not/exist"
    for entity in [Host("example.com"), Host("example.org"), Host("example.net")]:
        assert entity.name in get_plugin_vars(loader, plugin, path, [entity])



# Generated at 2022-06-11 19:13:59.187915
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    pass

# Generated at 2022-06-11 19:14:08.819798
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    host = Host('localhost')
    group = Group('group1')
    entities = [host, group]

    data = get_vars_from_inventory_sources('loader', ['path1', 'path2'], entities, 'task')
    assert data == {'group_names': ['group1'], 'groups': {u'group1': ['localhost']}, 'inventory_dir': u'.', 'inventory_file': None, 'inventory_hostname': 'localhost', 'inventory_hostname_short': 'localhost'}



# Generated at 2022-06-11 19:14:21.204336
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader.vars import VarsModule
    from ansible.plugins.loader import vars_loader
    from ansible.parsing.dataloader import DataLoader

    real_get_vars = VarsModule.get_vars

    class TestVars(VarsModule):

        def __init__(self, name):
            super(TestVars, self).__init__()
            self._name = name

        @property
        def _load_name(self):
            return self._name

        def get_vars(self, loader, path, entities):
            return {'test': 'ok'}

    def test_vars_1(loader, path, entities):
        return {'vars_1': 'true'}


# Generated at 2022-06-11 19:14:27.526071
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.vars import include_vars

    class TestVarLoader:
        def __init__(self):
            self.vars_plugin_list = [
                include_vars.IncludeVars()
            ]

    entities = [
        Host('test1')
    ]

    result = get_vars_from_path(TestVarLoader(), '/path/to/include', entities, '')
    assert len(result) == 0

# Generated at 2022-06-11 19:14:36.430840
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.cli import CLI
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.plugins.loader import vars_loader

    path = './lib/ansible/plugins/vars'
    entities = ['localhost']
    stage = 'task'
    # Some plugins have dependencies, they can't be tested alone and
    # need inventory to be set up...
    # So we copy plugins to be tested (no-op if they already exist)
    # and create an InventoryManager with dummy variables

# Generated at 2022-06-11 19:14:46.309034
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    import ansible.plugins.vars.vars_plugin as vars_plugin
    vars_plugin.VarModule._basedir = './lib/ansible/plugins/vars'

    test_loader = lambda : None
    setattr(test_loader, '_basedir', './lib/ansible/plugins/vars')
    setattr(test_loader, '_vars_plugins', {'test_vars_plugin': vars_plugin.VarModule})

    test_sources = ['test/plugins_vars_inventory.yml', 'test/plugins_vars_inventory.ini', 'plugins_vars_directory']
    test_entities = ['test/plugins_vars_inventory.yml']

    # test the get_vars_from_inventory_sources

# Generated at 2022-06-11 19:14:57.614445
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    # Dummy vars plugin
    class DummyVars(object):

        _load_name = 'DummyVars'

        def get_vars(self, loader, path, entities):
            d = {
                'group_vars': [
                    {'groupname': 'Green'},
                    {'groupname': 'Blue'}
                ],
                'host_vars': [
                    {'hostname': 'Blue'},
                    {'hostname': 'Red'}
                ]
            }
            return d

    # Dummy vars plugin
    class DummyVars2(object):

        _load_name = 'DummyVars2'

        def get_host_vars(self, hostname):
            d = {
                'hostname': hostname
            }
            return d


# Generated at 2022-06-11 19:15:06.819179
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    # fake file path
    fake_path = "/path/to/fake/file"

    # fake AnsibleMap object
    class FakeAnsibleMap(object):
        def __init__(self, name):
            self.name = name

    # fake AnsibleLoader object
    class FakeLoader(object):
        path_exists = lambda self, path: True

    # fake vars plugin
    class FakeVarsPlugin(object):
        def get_vars(self, loader, path, entities):
            return {'fake_data': 'fake_data'}

    # fake vars plugin list object
    fake_vars_plugin_list = [FakeVarsPlugin()]

    # fake loader object
    fake_loader = FakeLoader()

    # create a fake inventory

# Generated at 2022-06-11 19:15:21.140208
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    class MockedVarsPlugin:

        def __init__(self, load_name, original_path, get_vars_func):
            self._load_name = load_name
            self._original_path = original_path
            self.get_vars = get_vars_func
            self.has_option = lambda option_name: True
            self.get_option = lambda option_name: 'all' if option_name == 'stage' else None

        def get_group_vars(self, group):
            group_data = {'group': group}
            group_data[self._load_name] = 'group'
            return group_data

        def get_host_vars(self, host):
            host_data = {'host': host}
            host_data[self._load_name] = 'host'

# Generated at 2022-06-11 19:15:21.772054
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    pass

# Generated at 2022-06-11 19:15:23.794455
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    # TODO: remove this function once function get_plugin_vars can be
    # tested by unit tests.
    raise NotImplementedError

# Generated at 2022-06-11 19:15:36.401241
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    #
    # unit test for function get_vars_from_path
    #

    #
    # tests of function get_vars_from_path
    #

    # test get_vars_from_path when the plugin implements get_vars method
    #
    # plugin class that implements get_vars
    class test_get_vars():
        def get_vars(self, loader, path, entities):
            return {'getvars': True}

    # test when plugin has get_vars
    plugin_mock = test_get_vars()
    returned_data = get_vars_from_path(None, None, [], 'inventory')
    assert returned_data == {'getvars': True}

    # test get_vars_from_path when the plugin implements get_host_vars method

# Generated at 2022-06-11 19:15:46.006530
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    from ansible.plugins.loader import vars_loader

    class TestVarsPlugin():
        def __init__(self):
            # attributes required by Ansible plugin specifications
            self._load_name = 'test_plugin'
            self._original_path = '/path/to/test_plugin'

        def get_vars(self, loader, path, entities):
            data = dict()
            data['test_plugin'] = entities[0].name
            return data

    test_plugin_only = [TestVarsPlugin()]
    # test the plugin-specific setting
    test_sources = ['/path/to/inventory', '/path/to/other/inventory']
    test_host = [Host(name='host1')]


# Generated at 2022-06-11 19:15:52.980025
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host

    plugin = vars_loader.get('yaml_file')
    path = '/etc/ansible'
    host = Host('localhost')
    entities = [host]
    stage = 'inventory'
    data = get_vars_from_path(None, path, entities, stage)
    assert data

# Generated at 2022-06-11 19:16:01.373188
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    class VarsLoaderTest:
        def get(self, name):
            class VarsPluginTest:
                def get_vars(self, loader, path, entities):
                    return {'a': '1'}

                def get_host_vars(self, host):
                    return {'b': '2'}

                def get_group_vars(self, group):
                    return {'c': '3'}

                def get_option(self, option):
                    if option == 'stage':
                        return 'all'

            return VarsPluginTest()

        def all(self):
            return [self.get(None)]

    class DisplayTest:
        @classmethod
        def warning(self, message):
            pass

    entities = [{'name': 'a'}]

# Generated at 2022-06-11 19:16:11.720249
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    # A dummy plugin that returns a dict
    class VarsModule:
        _load_name = 'test_get_plugin_vars'
        def get_vars(self, loader, path, entities):
            return {'a': 'b'}
    loader = None
    path = 'path does not matter'
    entities = ['an entity does not matter']

    plugin_result = get_plugin_vars(loader, VarsModule(), path, entities)
    assert plugin_result == {'a': 'b'}

    # A dummy plugin that has old interface
    class VarsModule:
        _load_name = 'test_get_plugin_vars'
        def get_host_vars(self, host):
            return {'c': 'd'}

# Generated at 2022-06-11 19:16:18.886464
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import InventoryVariableManager
    inventory = InventoryManager(loader=None, sources=["test/ansible_hosts"])
    host = inventory.get_host("bsm_test_01")
    var_manager = InventoryVariableManager(loader=None, inventory=inventory)
    vars = get_vars_from_path(var_manager, "test/ansible_hosts", [host], "")
    assert (vars['hostvar'] == 'hostvar_value')
    assert (vars['groupvar'] == 'groupvar_value')

# Generated at 2022-06-11 19:16:20.130502
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # TODO

    return

# Generated at 2022-06-11 19:16:46.840095
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Get vars from path
    data = {}
    entities = []

    loader = None
    path = "path"
    entities = []
    stage = "inventory"
    data = combine_vars(data, get_vars_from_path(loader, path, entities, stage))

# Generated at 2022-06-11 19:16:50.986579
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    data = {}
    loader = vars_loader
    path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'plugins', 'vars', 'test.yml')
    entities = ['foo']
    stage = 'inventory'
    data = get_vars_from_path(loader, path, entities, stage)
    assert data['test_var'] == 'test_value'

# Generated at 2022-06-11 19:16:59.532269
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    test_path = os.path.join(os.path.dirname(__file__), '..', '..', '..', 'test', 'units', 'vars_plugins')
    loader = None
    entities = [
        Host('host1'),
        Host('host2'),
        Host('host3'),
    ]

    # test without any plugins
    data = get_vars_from_path(loader, test_path, entities, 'inventory')
    assert data == {}

    # test with plugins
    data = get_vars_from_path(loader, test_path, entities, 'inventory')
    assert data == {}

# Generated at 2022-06-11 19:17:07.157384
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager
    loader = InventoryManager(loader=None, sources=['localhost,'])

    # test with source directory and empty entities list
    source_dir = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
    vars_from_path = get_vars_from_path(loader, path=source_dir, entities=[], stage='task')

    # test the returned values
    assert isinstance(vars_from_path, dict)
    assert vars_from_path  # should not be empty



# Generated at 2022-06-11 19:17:07.673218
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    pass

# Generated at 2022-06-11 19:17:15.648639
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager

    inventory_manager = InventoryManager()
    inventory_manager.load_inventory_sources()
    loader = inventory_manager.loader

    assert get_vars_from_path(loader, '', '', 'task') == {}
    assert get_vars_from_path(loader, '/etc/ansible/hosts', '', 'task') == {}
    assert get_vars_from_path(loader, '/etc/ansible/hosts', [], 'task') == {}
    assert get_vars_from_path(loader, '/etc/ansible/hosts', ['test'], 'task') == {}
    assert get_vars_from_path(loader, '/etc/ansible/hosts', [inventory_manager.get_host('test')], 'task') == {}

# Generated at 2022-06-11 19:17:18.257131
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    """
    Tests the get_vars_from_path() function.
    """
    assert get_vars_from_path('loader', 'path', [], 'inventory') == {}

# Generated at 2022-06-11 19:17:29.314904
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    # stub vars loader to override methods
    class StubVarsLoader(object):
        def __init__(self):
            self.plugins = []

        def list(self):
            return self.plugins

        def get(self, item):
            return self.plugins[item]

        def add(self, plugin):
            plugin._load_name = 'test'
            self.plugins.append(plugin)

    # stub vars plugin
    class StubVarsPlugin(object):
        def get_vars(self, loader, path, entities):
            return {'test': True}

    loader = StubVarsLoader()
    vars_loader.add(loader)
    plugin = StubVarsPlugin()
    loader.add(plugin)

    data = get_vars_from_path(loader, '/foo', [], 'start')


# Generated at 2022-06-11 19:17:38.110204
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import vars_loader
    from ansible.utils.collection_loader import AnsibleCollectionRef

    class MockPlugin:
        def __init__(self, values):
            self.values = values

        def get_vars(self, loader, path, entities):
            return self.values

    plugin1 = MockPlugin({'key1': 'value1'})
    plugin2 = MockPlugin({'key2': 'value2'})
    plugin3 = MockPlugin({'key3': 'value3'})
    plugin4 = MockPlugin({'key4': 'value4'})
    plugin5 = MockPlugin({'key5': 'value5'})

    play_context = PlayContext()
    play_context.vars_plugins_enabled = []



# Generated at 2022-06-11 19:17:50.071460
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    import unittest
    import tempfile
    from ansible.utils.collection_loader import AnsibleCollectionLoader, get_collections_from_directory

    class TestVarsPlugin:
        def get_vars(self, loader, path, entities):
            return {'test': 1}

    class TestVarsPlugin2:
        def get_vars(self, loader, path, entities):
            return {'test2': 2}

    class TestVarsPlugin3:
        def get_vars(self, loader, path, entities):
            return {'test': 1}

    class TestVarsPlugin4:
        def get_vars(self, loader, path, entities):
            return {'test2': 2}


# Generated at 2022-06-11 19:18:05.809018
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    assert get_vars_from_path(None, None, [], None) == {}
    assert get_vars_from_path(None, None, [], 'inventory') == {}
    assert get_vars_from_path(None, None, [], 'task') == {}

# Generated at 2022-06-11 19:18:13.380377
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.playbook.play_context import PlayContext
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inv_data = '''
    [group0]
    host0
    '''

    display.verbosity = 0
    inv_file = 'inventory'
    inv_path = os.path.join(os.path.join(os.path.join(os.getcwd(), 'test'), 'integration'), inv_file)
    with open(inv_path, 'w') as f:
        f.write(inv_data)

# Generated at 2022-06-11 19:18:15.594150
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    loader = None
    path = C.get_config_value('DEFAULT', 'vars_plugins')
    entities = (None,None)
    assert get_vars_from_path(loader,path,entities)

# Generated at 2022-06-11 19:18:16.363033
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    raise NotImplementedError

# Generated at 2022-06-11 19:18:27.019506
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    class _Loader(object):
        pass

    loader = _Loader()

    assert get_vars_from_path(loader, "./", [], "inventory") == {}

    assert get_vars_from_path(loader, "/tmp/doesNotExist", [], "inventory") == {}

    from ansible.plugins.vars import vars_from_vault

    class _Vault_Plugin(object):
        pass

    vault_plugin = _Vault_Plugin()
    vault_plugin.get_vars = vars_from_vault.get_vars

    host1 = Host("host1")
    group1 = Group("group1")


# Generated at 2022-06-11 19:18:36.454240
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    loader, result = {}, {}

    # Should return empty data without error
    collection_path = os.path.join(C.DEFAULT_MODULE_PATH[0], '..', '..')
    vars_plugin_list = list(vars_loader.all())
    for plugin in vars_plugin_list:
        if plugin._load_name not in C.VARIABLE_PLUGINS_ENABLED and getattr(plugin, 'REQUIRES_WHITELIST', False):
            # 2.x plugins shipped with ansible should require whitelisting, older or non shipped should load automatically
            continue

        has_stage = hasattr(plugin, 'get_option') and plugin.has_option('stage')

        # if a plugin-specific setting has not been provided, use the global setting
        # older/non shipped plugins that

# Generated at 2022-06-11 19:18:43.611966
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader, get_plugin_by_name
    d = {}
    d['test1'] = dict(a=1, b=2)
    d['test2'] = dict(a=3, b=4)
    fake_loader = dict((k, get_plugin_by_name(vars_loader, 'yaml')(k, k, d[k])) for k in d.keys())
    fake_loader['test1']._original_path = "test1"
    fake_loader['test2']._original_path = "test2"
    fake_loader['test1']._load_name = "test1"
    fake_loader['test2']._load_name = "test2"
    fake_loader['test1'].get_vars = None


# Generated at 2022-06-11 19:18:52.666886
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    import ansible.plugins.loader as vars_loader
    import ansible.inventory.manager
    import os

    loader = vars_loader.get('yaml')
    from ansible.playbook.play_context import PlayContext
    context = PlayContext('test')
    context.basedir = os.path.join(os.path.dirname(__file__), '..', 'vars_plugin')
    host_1 = ansible.inventory.manager.InventoryManager(loader=loader, sources=['tests/vars_plugin/inventory_test_1']).get_hosts('test_group')[0]
    host_2 = ansible.inventory.manager.InventoryManager(loader=loader, sources=['tests/vars_plugin/inventory_test_2']).get_hosts('test_group')[0]

   

# Generated at 2022-06-11 19:18:59.663976
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.plugins.vars import v2

    plugin_name = 'test_var_plugin'
    plugin = v2.VarsModule()
    plugin._load_name = plugin_name
    plugin._original_path = "/tmp"
    plugin.get_vars = lambda x, y, z: {"test_var": "test_value"}

    loader = AnsibleCollectionLoader()
    entities = []

    data = get_plugin_vars(loader, plugin, '/tmp', entities)
    assert data == {"test_var": "test_value"}

# Generated at 2022-06-11 19:19:01.390847
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # TODO
    # test variables from vars_plugins
    # test 'stage' option
    # test collection vars plugins
    pass

# Generated at 2022-06-11 19:19:27.362383
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    # test data structures
    test_sources = ['/home/ansible/test/ansible/roles/test_role/inventory/test_inventory']
    test_entities = ['test_entity']

    # test get_vars_from_inventory_sources function
    assert get_vars_from_inventory_sources(None, test_sources, test_entities, None) == {}

# Generated at 2022-06-11 19:19:35.408235
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    vars_plugin_list = ['/etc/ansible/test_vars1.py', '/etc/ansible/test_vars2.py']
    for plugin_name in vars_plugin_list:
        C.VARIABLE_PLUGINS_ENABLED.append(plugin_name)

    result = get_vars_from_path(vars_loader, '.', '.', 'inventory')
    assert (result == {u'var1': u'value1', u'var2': u'value2'})

# Generated at 2022-06-11 19:19:44.456010
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    loader = DataLoader()
    inv = InventoryManager(loader=loader, sources=['test/integration/inventory/dynamic'])
    vars_manager = VariableManager(loader=loader, inventory=inv)

    def test(entities, stage):
        vars_manager.clear_vars()
        vars_manager.add_host_vars(entities, get_vars_from_inventory_sources(loader, ['test/integration/inventory/dynamic'], entities, stage))

    test([inv.get_host('local_vars1')], 'task')
    assert 'local_vars1' in vars_manager._host_v

# Generated at 2022-06-11 19:19:55.188935
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    loader, path, entities, stage = None, None, None, 'task'

    # Test global setting VARIABLE_PLUGINS_ENABLED
    C.VARIABLE_PLUGINS_ENABLED = [
        'vars_file',
        'source',
        'yaml',
        'json',
        'to_yaml',
        'to_json',
        'ini',
    ]
    data1 = get_vars_from_path(loader, path, entities, stage)
    assert 'source' in data1.keys()

    # Test plugin-specific setting stage

# Generated at 2022-06-11 19:20:02.908996
# Unit test for function get_plugin_vars
def test_get_plugin_vars():


    class MockModuleLoader():
        def get(self, modname, classname=None, valid_subclasses=None):
            return MockInventoryModule()


    class MockInventoryModule():
        _load_name = 'plugin'
        _original_path = 'path'
        def get_vars(self, loader, path, entities):
            return dict(vars='vars')

    loader = MockModuleLoader()

    plugin = MockInventoryModule()

    path = 'some path'
    entities = ['some entities']

    data = get_plugin_vars(loader, plugin, path, entities)

    assert data == dict(vars='vars')


# Generated at 2022-06-11 19:20:05.526545
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    loader = None
    plugin = None
    path = '/path/to/existing/dir'
    entities = ['']

    # Should not raise exception
    get_plugin_vars(loader, plugin, path, entities)



# Generated at 2022-06-11 19:20:14.629631
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.module_utils.basic import AnsibleModule, missing_required_lib

    if missing_required_lib('yaml'):
        module = None
    else:
        module = AnsibleModule(
            argument_spec=dict(),
        )

    inventory_sources_paths = ['/Users/vkhomenko/Documents/ansible/test/test_vars_loader/host_vars',
                               '/Users/vkhomenko/Documents/ansible/test/test_vars_loader/group_vars']
    entities = [Host(), Host()]
    output = get_vars_from_path('loader', inventory_sources_paths, entities, 'inventory')

    module.exit_json(changed=False,
                     vars_from_path=output)

# Generated at 2022-06-11 19:20:21.263930
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    import ansible.module_utils.network.dmos.config.ospf.ospf_global

    fake_loader = object()
    fake_path = object()
    fake_entities = [object()]
    fake_stage = object()

    assert get_vars_from_path(fake_loader, fake_path, fake_entities, fake_stage) is not None

    ansible.module_utils.network.dmos.config.ospf.ospf_global.get_vars = lambda loader, path, entities, stage: \
        [fake_loader, fake_path, fake_entities, fake_stage]

    assert get_vars_from_path(fake_loader, fake_path, fake_entities, fake_stage) == [fake_loader, fake_path, fake_entities, fake_stage]

# Generated at 2022-06-11 19:20:29.829655
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    from ansible.plugins.loader import vars_loader
    from ansible.inventory.data import InventoryData

    class MockPlugin:
        def __init__(self, name, path):
            self._load_name = name
            self._original_path = path
            self.has_option = lambda x: True
        def get_option(self, k):
            return None

    # add three vars plugins
    vars_plugin1 = MockPlugin('plugin1', 'plugin1_path')
    vars_plugin1.get_vars = lambda l, p, e: {'1.1': 'foo', '1.2': 'bar'}
    vars_loader.add(vars_plugin1)

    vars_plugin2 = MockPlugin('plugin2', 'plugin2_path')
    vars_plugin2.get

# Generated at 2022-06-11 19:20:39.596690
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import var_plugins
    from ansible.plugins.vars import base

    class v1_plugin(base):
        def __init__(self):
            self._load_name = 'v1_plugin'

        def get_vars(self, loader, path, entities=None):
            return {'v1_plugin': 'success'}

    class v2_plugin(base):
        def __init__(self):
            self._load_name = 'v2_plugin'

        def get_vars(self, loader, path, entities, **kwargs):
            return {'v2_plugin': 'success'}

    class v3_plugin(base):
        def __init__(self):
            self._load_name = 'v3_plugin'


# Generated at 2022-06-11 19:21:37.024885
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars.host_group_vars import VarsModule
    from ansible.utils.collection_loader import AnsibleCollectionRef
    loader = vars_loader

    plugin_name = 'ansible.builtin.host_group_vars'
    plugin_obj = loader.get(plugin_name)
    if plugin_obj is None:
        plugin_name = 'ansible-base.host_group_vars'
        plugin_obj = loader.get(plugin_name)
    assert isinstance(plugin_obj, VarsModule)
    assert plugin_obj._load_name == AnsibleCollectionRef.parse_fqcr(plugin_name).to_display()

    vars = get_plugin_vars(loader, plugin_obj, '/tmp/', ['node1', 'node2'])

# Generated at 2022-06-11 19:21:45.200269
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    result = []
    from ansible.plugins import vars_loader
    loader = vars_loader.all()
    path = "/opt/ansible/ansible/test/units/modules/test_vars_plugin/vars"
    entities = ['all']
    data = get_vars_from_path(loader, path, entities, "inventory")
    for plugin in loader:
        data = get_plugin_vars(loader, plugin, path, entities)
    result.append(data)
    assert result == [{'a': 1, 'b': 2}]

# Generated at 2022-06-11 19:21:50.799959
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    class MockHost(object):
        def __init__(self, is_localhost):
            self.is_localhost = is_localhost
            self.vars = {}

    class MockPlugin(object):
        def __init__(self, path, data):  # data by hostname
            self._original_path = path
            self.data = data

        def get_host_vars(self, hostname):
            return self.data.get(hostname, {})

    class MockLoader(object):
        def __init__(self, path, plugin):
            self._inventory = [path]
            self._vars_plugins = plugin

    # Set up the fixtures we need
    inventory = "foo"
    host_list = "localhost"
    host = MockHost(True)
    host2 = MockHost(False)
    plugin_

# Generated at 2022-06-11 19:21:58.818157
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play_context import PlayContext
    loader = DataLoader()
    inv = VariableManager()
    pc = PlayContext()
    inv.set_inventory(loader.inventory)
    vars_plugin_list = list(vars_loader.all())
    entities = []
    path = '.'
    stage = 'inventory'
    vars = get_vars_from_path(loader, path, entities, stage)
    assert(type(vars) == dict)

# Generated at 2022-06-11 19:22:09.145385
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars
    from ansible.vars import vars_loader
    from ansible.plugins.vars.foo_yaml_v1 import VarsModule as VarsModule_foo_yaml_v1

    # Create a vars plugin
    class VarsModule_foo_py_v2(object):
        def __init__(self):
            pass

        def get_vars(self, loader, path, entities):
            output = {}
            output['plugin_name'] = self.__module__
            output['entities'] = entities
            return output

    test_vars_plugin = VarsModule_foo_py_v2()
    v

# Generated at 2022-06-11 19:22:20.353431
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    display.verbosity = 2
    loader = '--'
    host_name = 'localhost'
    path_inventory_dir = '/etc/ansible/hosts'
    path_inventory_file = '/etc/ansible/hosts'
    path_playbook_dir = '/etc/ansible/playbook'
    path_playbook_file = '/etc/ansible/playbook/test.yml'
    path_task_dir = '/etc/ansible/playbook/roles/lamp/tasks'

    # Test:
    # - Use inventory files
    # - Path exists
    # - Call to get_vars_from_path returns a list
    retrieved_data = get_vars_from_path(loader, path_inventory_dir, host_name, 'inventory')

# Generated at 2022-06-11 19:22:32.041078
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    plugin_vars = {u'foo': {u'bar': u'baz'}, u'frob': {u'qux': u'quux'}}
    plugin_list = [FakePlugin(plugin_vars)]

    loader = FakeLoader(plugin_list)
    path = '/path/to/foo'
    entities = [FakeGroup('group1'), FakeGroup('group2'), FakeHost('host1'), FakeHost('host2')]

    vars = get_vars_from_path(loader, path, entities, 'inventory')
    assert vars == plugin_vars

    vars = get_vars_from_path(loader, path, entities, 'task')
    assert vars == plugin_vars

    vars = get_vars_from_path(loader, path, entities, 'something-else')
   

# Generated at 2022-06-11 19:22:43.022586
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    entities = [Host('host1')]
    inventory_path = os.path.join(os.path.dirname(__file__), '../../../lib/ansible/inventory')
    loader_path = os.path.join(inventory_path, 'loader.py')
    loader = vars_loader.get('loader', loader_path)
    plugin_path = os.path.join(inventory_path, 'host_list.py')
    plugin = vars_loader.get('host_list', plugin_path)
    stage = 'task'
    path = "something"
    path2 = "something_else"
    assert type(get_vars_from_path(loader, path, entities, stage)) is dict
    assert stage in get_vars_from_path(loader, path, entities, stage)

# Generated at 2022-06-11 19:22:49.479845
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.config.manager import ConfigManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    config = ConfigManager(
        os.path.join(os.path.dirname(__file__), 'data/configs/vars_plugin.yaml')
    )

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources="localhost,")
    inventory.parse_inventory(inventory.sources, cache=True)

    vars_from_path = get_vars_from_path(loader, config.get_config_value('library'), inventory.hosts.keys(), 'task')
    assert vars_from_path['var_from_task_vars_plugin'] == 'ok'

    vars_from_path = get_

# Generated at 2022-06-11 19:22:53.707074
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    loader = None
    path = '/home/user/.ansible/plugins/vars'
    entities = []
    stage = 'inventory'
    test_data = get_vars_from_path(loader, path, entities, stage)
    assert test_data == {}