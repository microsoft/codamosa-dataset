

# Generated at 2022-06-11 19:13:52.177221
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # not testing all since there are many permutations
    # first remove all plugins and add only one to ensure it will be used
    all_plugins = vars_loader.all()
    for p in all_plugins:
        vars_loader.remove(p)
    vars_loader.add(VarsPluginCheck(name="test"))
    results = get_vars_from_path(None, None, None, 'inventory')
    assert results == {'test': True}

    # same test encrypted
    all_plugins = vars_loader.all()
    for p in all_plugins:
        vars_loader.remove(p)
    vars_loader.add(VarsPluginCheck(name="test"))
    results = get_vars_from_path(None, None, None, 'inventory')

# Generated at 2022-06-11 19:14:02.129028
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.script import Script
    from ansible.inventory.vars_plugins import from_yaml

    from ansible.utils.vars import combine_vars

    loader = from_yaml.PluginLoader()
    path = 'test/integration/inventory/vars_dir/'
    vars_from_file = script_vars = ''

    sources = path.split(':')
    inventory = InventoryManager(loader=loader, sources=sources)
    var_data = get_vars_from_path(loader, path, inventory._hosts, 'inventory')

    with open(path + 'vars_file', 'r') as f:
        vars_from_file = ''.join(f.readlines())

# Generated at 2022-06-11 19:14:12.664656
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.plugins.vars import vars_plugins

    entities = []
    loader = 'fake_loader'
    path = 'fake_path'
    stage = 'inventory'
    data = {}
    vars_plugin_list = []
    plugin_name = 'fake_plugin'
    plugin_plugin = vars_loader.get(plugin_name)
    vars_plugin_list.append(plugin_plugin)
    plugin = plugin_plugin
    data = combine_vars(data, get_plugin_vars(loader, plugin, path, entities))
    plugin = vars_loader.get('yaml')
    data = combine_vars(data, get_plugin_vars(loader, plugin, path, entities))
    assert isinstance(data, dict)

# Generated at 2022-06-11 19:14:22.397377
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    plugin_list = list(vars_loader.all())
    plugin = plugin_list[0]

    assert(get_vars_from_path(None, None, None, None) == {})

    # testing with a test plugin
    class TestPlugin:
        def get_vars(self, loader, path, entities):
            return {'test': 'yes'}

        def run(self, loader, inventory, cache):
            raise AnsibleError("Cannot use v1 type vars plugin")

    assert(get_vars_from_path(None, None, None, None) == {})

    plugin_list.append(TestPlugin())
    assert(get_vars_from_path(None, None, None, None) == {'test': 'yes'})


# Generated at 2022-06-11 19:14:33.525869
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    # List of sources for the inventory
    inventory_base_dir = '/test/test_inventory'
    sources = [
        os.path.join(inventory_base_dir, 'hosts'),
        os.path.join(inventory_base_dir, 'group_vars/all'),
        os.path.join(inventory_base_dir, 'group_vars/test_group'),
        os.path.join(inventory_base_dir, 'host_vars/test_host_1'),
        os.path.join(inventory_base_dir, 'host_vars/test_host_2'),
    ]

    # Set constants to enable all vars plugins
    C.VARIABLE_PLUGINS_ENABLED = ['yaml', 'ini']
    C.RUN_VARS_PLUGINS = 'task'

# Generated at 2022-06-11 19:14:44.342517
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    loader = None
    path = "/tmp/inventory"
    entities = {}
    stage = 'inventory'

    # Create a vars plugin class
    class TestVarsPlugin(object):
        _load_name = 'vars_plugin_test'
        _original_path = ''

        def get_vars(self, loader, path, entities):
            return {'var1':'value1'}

    vars_loader.add(TestVarsPlugin, 'vars_plugin_test')
    C.VARIABLE_PLUGINS_ENABLED.append('vars_plugin_test')

    # Check if the vars plugin returns the added vars
    data = get_vars_from_path(loader, path, entities, stage)
    assert(data['var1'] == 'value1')

# Generated at 2022-06-11 19:14:49.443495
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    class FakeVars:
        def get_vars(self, loader, path, entities):
            return {'test_plugin': 'win'}
    vars_plugin = FakeVars()
    vars_plugin.REQUIRES_WHITELIST = False
    assert get_plugin_vars(None, vars_plugin, None, None) == {'test_plugin': 'win'}



# Generated at 2022-06-11 19:14:59.869168
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.parsing.dataloader import DataLoader

    entities = [Host('testhost')]
    dl = DataLoader()

    # This path should not be real, it is only used to test that the function doesn't try to open the directory
    path = "/this/is/not/a/real/path"

    # In run vars plugin mode 'start', data should be a blank dictionary
    data = get_vars_from_path(dl, path, entities, 'inventory')
    assert isinstance(data, dict)
    assert len(data) == 0

    # In run vars plugin mode 'all', data should be a blank dictionary
    data = get_vars_from_path(dl, path, entities, 'task')
    assert isinstance(data, dict)
    assert len(data) == 0

# Generated at 2022-06-11 19:15:09.606260
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    test_plugin = type("test_plugin", (object,), dict(get_vars=lambda x,y,z: dict(test_plugin='test_plugin')))
    test_plugin2 = type("test_plugin2", (object,), dict(get_vars=lambda x,y,z: dict(test_plugin2='test_plugin2')))

    from ansible.plugins.loader import vars_loader
    vars_loader._reload()
    vars_loader.set_directory(os.path.join(os.getcwd(), "test", "vars_plugins"), with_subdir=True)
    assert(get_vars_from_path(None, 'abcd', [], 'inventory') == dict(a='b'))

# Generated at 2022-06-11 19:15:12.834551
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    plugin = vars_loader.get('hashivault')

    entities = Host('test_host')

    loader = None

    path = "/path"

    plugin_data = get_plugin_vars(loader, plugin, path, entities)

    assert len(plugin_data.keys()) > 0

# Generated at 2022-06-11 19:15:28.674912
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    from ansible_collections.community.general.tests.unit.plugins.test_vars_plugins import test_vars_path
    from ansible.plugins.vars import vars_cache_name

    # note this requires test_vars_path to be in the same directory
    # as this file.
    vars_cache_file = os.path.join(test_vars_path, vars_cache_name)

    def always_new_plugin(host):
        plugin = ImplicitVarsPlugin()
        plugin.HOSTCACHE_FILE = vars_cache_file
        plugin.WHITELIST_CACHE = ['always_new']
        return plugin

    vars_loader.add(always_new_plugin, 'always_new')


# Generated at 2022-06-11 19:15:39.391557
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    import ansible.plugins.loader as plugin_loader
    import ansible.vars.plugins.legacy_yaml as legacy_yaml

    # mock a dynamic class so we get back a class that can be used for instance comparison
    mock_class = plugin_loader._create_dynamic_class('module_utils.ansible.vars.plugins.legacy_yaml.YamlVars')
    assert isinstance(legacy_yaml.__class__, mock_class)

    assert legacy_yaml._load_name == 'legacy_yaml'
    assert legacy_yaml.has_option('stage') is False
    my_path = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
    assert legacy_yaml._original_path == os

# Generated at 2022-06-11 19:15:46.403352
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    dummy_loader = 'dummy_loader'
    dummy_plugin = 'dummy_plugin'
    dummy_path = 'dummy_path'
    dummy_entities = 'dummy_entities'

    data = get_plugin_vars(dummy_loader, dummy_plugin, dummy_path, dummy_entities)
    if data == {}:
        print('Unit test passed!')
    else:
        print('Unit test failed!')

if __name__ == '__main__':
    test_get_plugin_vars()

# Generated at 2022-06-11 19:15:48.220256
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    vars = get_vars_from_path(None, '.', [], 'inventory')
    assert 'ansible_user' in vars

# Generated at 2022-06-11 19:15:59.824693
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    class TestVarsDictPlugin:
        def get_vars(self, loader, path, entities):
            return {'test_var_dict': 'dict_value'}

    class TestVarsHostPlugin:
        def get_host_vars(self, host):
            return {'test_var_host': 'host_value'}

    class TestVarsGroupPlugin:
        def get_group_vars(self, group):
            return {'test_var_group': 'group_value'}

    class InvalidPlugin:
        def run(self):
            pass

    entity = Host('test_host')
    entities = [entity]
    path = '/tmp'
    vars_plugin = TestVarsDictPlugin()
    vars_plugin._load_name = 'test_vars_dict'
    vars

# Generated at 2022-06-11 19:16:11.064591
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # create ansible.cfg file
    f = open('ansible.cfg', 'w')
    f.write('[defaults]\n')
    f.close()

    # create a playbook with a variable data
    f = open('playbook.yml', 'w')
    f.write('---\n')
    f.write('- hosts: localhost\n')
    f.write('\n')
    f.write('  vars: var_inventory\n')
    f.write('\n')
    f.write('  tasks:\n')
    f.write('    - debug: msg="{{ var_inventory }}\n"\n')
    f.write('    - debug: msg="{{ var_playbook }}\n"\n')

# Generated at 2022-06-11 19:16:20.364661
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.utils.collection_loader import AnsibleCollectionRef

    AnsibleCollectionRef.add_collection_to_cache(
        'test_vars_plugins.file_vars', 'plugins',
        ['test/test_vars_plugins/collections/test_vars_plugins/plugins/file_vars'],
    )
    AnsibleCollectionRef.add_collection_to_cache(
        'test_vars_plugins.host_vars', 'plugins',
        ['test/test_vars_plugins/collections/test_vars_plugins/plugins/host_vars'],
    )

# Generated at 2022-06-11 19:16:21.641422
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert {} == get_vars_from_path(None, None, None, None)

# Generated at 2022-06-11 19:16:30.019904
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import test_vars_plugin
    loader = None
    plugin = test_vars_plugin.TestVarsModule(loader=loader, name='test')
    assert get_plugin_vars(None, plugin, None, ['host1', 'group1']) == {'group1': {'var_group1': 'group1'},
                                                                         'host1': {'var_host1': 'host1'}}

# Generated at 2022-06-11 19:16:37.167572
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    print('test_get_vars_from_path')
    from ansible.cli import CLI
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.display import Display
    from ansible.vars.manager import VariableManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase
    import hypothesis
    import hypothesis.strategies as st
    import json, pprint

# Generated at 2022-06-11 19:16:52.616470
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    my_plugin = 'test_plugin_name'
    my_plugin_data = {'test1': 'data1', 'test2': 'data2'}
    my_data = {}

    class MockPlugin(object):
        def __init__(self, load_name):
            self._load_name = load_name

        def get_vars(self, loader, path, entities):
            return my_plugin_data

    # Add our mock plugin to the vars_loader
    vars_loader.add(my_plugin, MockPlugin(my_plugin))

    # Test getting the vars data
    my_data = get_vars_from_path(None, '/path/to/file', [], 'inventory')
    assert my_plugin in my_data
    assert my_data[my_plugin] == my_plugin_data

# Generated at 2022-06-11 19:17:03.721698
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    def fake_get_vars(loader, path, entities):
        return {'fake_plugin': 'fake_plugin'}

    def fake_get_vars_with_run_method(loader, path, entities):
        return {'fake_plugin_with_run_method': 'fake_plugin_with_run_method'}

    def fake_get_host_vars(host_name):
        return {'fake_host': host_name}

    def fake_get_group_vars(group_name):
        return {'fake_group': group_name}

    def fake_run(host):
        return {'fake_run': 'fake_run'}

    plugin = type('FakePlugin', (object,), {})
    plugin.get_vars = fake_get_vars
    vars_from_get

# Generated at 2022-06-11 19:17:11.030830
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    from ansible.plugins import vars as vars_plugins

    loader = "fake_loader_instance"
    path = "/path/to/somewhere/"
    entities = ["fake_host_1", "fake_host_2", "fake_host_3"]
    plugin = vars_plugins.Facts()
    get_plugin_vars(loader, plugin, path, entities)

    plugin = vars_plugins.GroupVars()
    get_plugin_vars(loader, plugin, path, entities)

    plugin = vars_plugins.HostVars()
    get_plugin_vars(loader, plugin, path, entities)

# Generated at 2022-06-11 19:17:22.087174
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader.vars_plugins.yaml_groups import VarsModule as YamlGroups
    from ansible.plugins.loader.vars_plugins.group_vars_files import VarsModule as FileSystemVars
    from ansible.plugins.loader.vars_plugins.host_vars_files import VarsModule as FileSystemHostVars
    plugin_loader = vars_loader

    def _load_plugin(plugin_class):
        plugin_loader.add(plugin_class)
        plugin = plugin_loader.get(plugin_class._load_name)
        return plugin

    class TestPlugin(object):
        def __init__(self, data):
            self.data = data

        def get_vars(self, loader, path, entities):
            return self.data

    plugin_loader.clear

# Generated at 2022-06-11 19:17:28.954081
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.vars.hostvars import HostVars
    from ansible.parsing.yaml.objects import AnsibleMapping

    hostvars = HostVars(dict(a=1))
    entities = [hostvars]
    ansible_vars = AnsibleMapping(dict(b="test"))
    loader = get_plugin_vars(None, hostvars, None, entities)

    assert(loader == {'a': 1})



# Generated at 2022-06-11 19:17:35.728766
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    # vars_plugins.yml is a vars plugin that returns a static dict
    plugin_data = get_plugin_vars(None, vars_loader.get('vars_plugins.yml'), '', [])
    assert plugin_data == {"BAR": "BAR", "FOO": "FOO"}

    # get_vars_from_path should return the same data
    vars_data = get_vars_from_path(None, '', [], '')
    assert vars_data == {"BAR": "BAR", "FOO": "FOO"}

    # vars_plugins.yml is a deprecated vars plugin that returns a static dict
    plugin_data = get_plugin_vars(None, vars_loader.get('vars_plugins.yml'), '', [])
    assert plugin

# Generated at 2022-06-11 19:17:38.111023
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    assert combine_vars({"a": ["b", "c"]}, {"a": ["c", "d"]}) == {"a": ["b", "c", "d"]}

# Generated at 2022-06-11 19:17:50.071894
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.plugins.loader import collection_loader
    from ansible.plugins.vars import my_vars
    from ansible.inventory.manager import InventoryManager
    vars_loader.add(my_vars.VarsModule())
    loader = AnsibleCollectionLoader()
    path = 'tests/data/inventory/'
    host_list = ['localhost']

    inv_manager = InventoryManager()
    inv_manager.add_book(loader, path, host_list)
    display.display("INV MANAGER: %s" % inv_manager)
    host = inv_manager.get_groups_dict()['all'].get_hosts()[0]

    display.display(host.name)
    data = get_vars_from_inventory_

# Generated at 2022-06-11 19:17:50.610341
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    pass

# Generated at 2022-06-11 19:17:59.053502
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    # Run some tests

    # Create loader object
    loader = DataLoader()

    # test data
    vars_path = "tests/test_vars"
    groups = ["group1", "group2", "group3", "group4"]
    hosts = ["test1", "test2", "test3", "test4"]
    stage = "inventory"

    # get vars from inventory sources
    entities = []
    for g in groups:
        entities.append(Group(g))
    for h in hosts:
        entities.append(Host(h))
    get_vars_inventory_sources(loader, [vars_path], entities, stage)

# Generated at 2022-06-11 19:18:13.085767
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    output = get_vars_from_inventory_sources(
        loader,
        ['vars_plugins/inventory_dir/inventory_file', 'vars_plugins/playbook_dir/playbook.yml', 'vars_plugins/playbook_dir/playbook_file'],
        ['host1', 'host2'],
        'inventory'
    )

    assert output['var_inv_file'] == 'inventory_file'
    assert output['var_inv_dir'] == 'inventory_dir'
    assert output['var_pl_file'] == 'playbook_file'
    assert output['var_pl_dir'] == 'playbook_dir'
    assert output['var_inv_hosts'] == ['host1', 'host2']

# Generated at 2022-06-11 19:18:15.849257
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    inventory_path = '/home/a/inventory.yaml'
    entities = ['webservers', 'foo']
    stage = 'inventory'
    data = get_vars_from_path(None, inventory_path, entities, stage)

    assert len(data) == 0

# Generated at 2022-06-11 19:18:16.632862
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # TODO
    return True


# Generated at 2022-06-11 19:18:17.860410
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert get_vars_from_path(None, '', [], '') == {}

# Generated at 2022-06-11 19:18:28.181924
# Unit test for function get_vars_from_path

# Generated at 2022-06-11 19:18:28.755476
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert True

# Generated at 2022-06-11 19:18:38.140633
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    # Data type test
    # Empty plugin
    loader = DummyPluginLoader()
    path = 'path/'
    entities = []
    stage = 'task'
    result = get_vars_from_path(loader, path, entities, stage)
    assert(type(result) == dict)
    assert(result == {})

    # Normal case
    entities = [DummyPlugin()]
    stage = 'task'
    result = get_vars_from_path(loader, path, entities, stage)
    assert(type(result) == dict)
    assert(result == {'path': True})

    # Data evaluation test
    # Empty plugin
    loader = DummyPluginLoader()
    path = 'path/'
    entities = []
    stage = 'task'

# Generated at 2022-06-11 19:18:49.059006
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # setup
    fake_plugin_1 = type('Plugin1', (object,), {'_load_name': 'foo', 'get_vars': lambda self, loader, path, entities: {'foo': 'bar'}})
    fake_plugin_2 = type('Plugin2', (object,), {'_load_name': 'bar', 'get_vars': lambda self, loader, path, entities: {'bar': 'baz'}})
    fake_collection = type('Collection', (object,), {'_load_name': 'test.collection', '_original_path': 'path/foo.tar.gz'})


# Generated at 2022-06-11 19:18:51.096689
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    pass


# Generated at 2022-06-11 19:19:00.532296
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Test global setting
    C.RUN_VARS_PLUGINS = 'start'
    plugin_list = list(vars_loader.all())
    assert len(plugin_list) == 8
    assert len(get_vars_from_path(None, './test/test_vars_plugins', None, 'task')) == 0
    assert len(get_vars_from_path(None, './test/test_vars_plugins', None, 'inventory')) == 8
    C.RUN_VARS_PLUGINS = 'demand'
    assert len(get_vars_from_path(None, './test/test_vars_plugins', None, 'inventory')) == 0

# Generated at 2022-06-11 19:19:12.375161
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    test_plugin_name = 'test_plugin'
    test_plugin_path = '/tmp/test_plugin.py'
    test_inventory_source = '/tmp/inventory_source'

    display.vvv("Running unit test for function get_vars_from_path")
    test_plugin_file = open(test_plugin_path, "wb")

# Generated at 2022-06-11 19:19:23.161432
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager

    class TestVarsPlugin:
        def get_vars(self, loader, path, entities, cache=True):
            return {'test_vars': path}

    test_var_plugin = TestVarsPlugin()
    test_var_plugin._load_name = 'test_vars_plugin'
    vars_loader.add(test_var_plugin, 'test_vars_plugin')

    inventory = InventoryManager(loader=None, sources="localhost")
    inventory.add_host(Host("localhost", groups=["group1"]))
    inventory.add_group(Group("group1"))

    path = '/tmp'
   

# Generated at 2022-06-11 19:19:25.863336
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    '''
    Runs the function without loading any plugins
    '''
    assert get_vars_from_path(None, 'foo', 'bar', 'baz') == {}

# Generated at 2022-06-11 19:19:36.948731
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # create an inventory source dirs
    loader = vars_loader
    path = '/tmp/test_var_path'
    os.mkdir(path)
    inventory_source_data = [
        '---\n',
        'test_var_path: test_var_path',
    ]
    with open(path + '/.var_test', 'w') as source:
        source.writelines(inventory_source_data)

    # create an inventory source file for ansible.builtin vars
    # this file does not exist in plugins/vars as it's only used for unit testing
    # instead, we use a mock plugin to return some variables

# Generated at 2022-06-11 19:19:39.723576
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    results = get_vars_from_path("loader", "path", ["entities1", "entities2"], "stage")
    if not results:
        raise AssertionError("Failed to get var from path")

# Generated at 2022-06-11 19:19:42.034093
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    data = get_vars_from_path(None, 'HOME', [], 'inventory')

    assert data is not None


# Generated at 2022-06-11 19:19:45.912724
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    import os
    path = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
    result = get_vars_from_path(None, path, None, 'inventory')
    assert result['_group_names'] == 'example_group'

# Generated at 2022-06-11 19:19:54.246647
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    loader = 'myLoader'
    path = 'myPath'
    entities = 'myEntities'
    stage = 'myStage'
    vars_plugin_list = ['vars_plugin_list']
    plugin = {'_load_name': 'myPlugin', '_original_path': 'myPath', 'has_option': 'myOption'}

    import ansible.plugins.vars.test_vars_plugins as vars_test
    data = get_vars_from_path(loader, path, entities, stage)
    assert vars_test.plugin_vars == data

# Generated at 2022-06-11 19:20:03.347919
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # mocks
    loader = 'loader'
    path = 'path'
    entities = 'entities'
    stage = 'stage'
    plugin = 'plugin'
    plugin._load_name = 'dummy.py'
    C.VARIABLE_PLUGINS_ENABLED = 'dummy'
    # set up
    get_plugin_vars_old = get_plugin_vars
    vars_loader_all_old = vars_loader.all
    vars_loader_get_old = vars_loader.get

# Generated at 2022-06-11 19:20:09.824909
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Create a fake host and group and set it to the same plugin path
    host1 = Host('host1')
    group1 = dict(name='group1', hosts=['host1'])
    host1.vars = group1['vars'] = {'plugin_path': 'bar'}
    host_entities = [host1]
    group_entities = [group1]
    # Create a new plugin and set it to the same path 'bar' as the entities

# Generated at 2022-06-11 19:20:30.431575
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    '''
    Test get_vars_from_path function
    '''

    import ansible.plugins.vars.test as testplugin

    global display

    # Create a test plugin
    vars_loader.add('testplugin', testplugin.VarsModule())

    # Create a mock loader
    class MockLoader(object):
        def __init__(self, paths):
            self._paths = paths

    # Create an entity
    class Entity(object):
        def __init__(self, entity_name):
            self._name = entity_name

        @property
        def name(self):
            return self._name

    # Test a simple plugin with method get_vars
    entities = []
    entities.append(Entity('test_entity'))

    loader = MockLoader(['/foo/bar'])

    vars

# Generated at 2022-06-11 19:20:40.762970
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    # Stub out the vars loader
    class VarsLoaderStub(object):
        class StubVarsPlugin(object):
            def __init__(self, name, path, run_stage):
                self._load_name = name
                self._original_path = path
                self._run_stage = run_stage

            def get_vars(self, loader, path, entities):
                if self._load_name == 'vars_plugin_good_v2':
                    return {'plugin_vars': True}
                return {}


# Generated at 2022-06-11 19:20:48.605915
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    sources = [
        'test/units/lib/ansible/vars/vars_plugins/inventory_hostname.yaml',
        'test/units/lib/ansible/vars/vars_plugins/group_names.yaml',
        'test/units/lib/ansible/vars/vars_plugins/inventory_port.yaml',
    ]

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=sources)
    plugin_host, plugin_group = set(), set()

    # check ansible.cfg, group_names.yaml, inventory_hostname.yaml, inventory_port.yaml

# Generated at 2022-06-11 19:20:59.156931
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    loader = None
    inline_data = [
        "[local]\nhost1\nhost2\nhost3\n",
        "[group_withspace]\nhost4\nhost5\nhost6\n",
        "[group_with_colon:]\nhost7\nhost8\nhost9\n"
    ]

    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from collections import namedtuple
    from ansible.plugins.loader import vars_loader
    sources = ['/tmp/inventory_file']
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=sources)
    inventory.parse_sources(inline_data)

    # Assume the inventory file is correct, so the next key should be MAX

# Generated at 2022-06-11 19:21:07.241042
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    from ansible.plugins.loader import vars_loader

    vars_loader.add_directory(os.path.join(os.path.dirname(os.path.realpath(__file__)), "unit/framework/shared"))

    loader = FakeLoader()
    path = os.path.join(os.path.dirname(os.path.realpath(__file__)), "unit/plugins/vars")
    data = get_vars_from_path(loader, path, [], 'all')
    assert 'my_var' in data
    assert data['my_var'] == 'my_value'

    data = get_vars_from_path(loader, path, [], 'task')
    assert 'my_var' in data
    assert data['my_var'] == 'my_value_task'

    data = get

# Generated at 2022-06-11 19:21:14.709744
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    # Get a vars loader
    loader = vars_loader.get('file')

    # File should exist
    path = "tests/vars/test_vars_exists"
    assert(os.path.isfile(path))

    # Entity should be a host
    entity1 = Host("my_host")

    # Get the data
    data = get_vars_from_path(loader, path, [entity1], 'inventory')

    # Ensure we have the expected data
    assert(data['test_var_exists'] == "I exist!")



# Generated at 2022-06-11 19:21:25.396127
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    def mock_get_vars(loader, path, entities):
        return dict(path=path, entities=[entity.name for entity in entities])

    loader = object()
    path = '/path/to/somewhere'

    # Hosts get their name
    host = Host(name='hostname')
    plugin = type('Plugin', (object,), dict(get_vars=mock_get_vars))()
    assert get_vars_from_path(loader, path, [host], 'inventory') == dict(path=path, entities=['hostname'])

    # Groups get their name
    group = Host(name='groupname')
    plugin = type('Plugin', (object,), dict(get_vars=mock_get_vars))()

# Generated at 2022-06-11 19:21:27.495305
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    assert isinstance(get_plugin_vars('loader', 'plugin', 'path', 'entities'), dict)

# Generated at 2022-06-11 19:21:32.998165
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    class TestPlugin():
        REQUIRES_WHITELIST = False
        def get_vars(self):
            return {'test_key': 'test_value'}

    data = get_plugin_vars(loader, TestPlugin(), '/', entities=[])

    assert len(data) == 1
    assert data['test_key'] == 'test_value'

# Generated at 2022-06-11 19:21:38.994777
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    import ansible.plugins.vars.system
    assert isinstance(get_plugin_vars(None, ansible.plugins.vars.system.VarsModule(), ".", ""), dict)

    import ansible.plugins.vars.host_list
    assert isinstance(get_plugin_vars(None, ansible.plugins.vars.host_list.VarsModule(), ".", ""), dict)

# Generated at 2022-06-11 19:22:05.398882
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    loader = None
    sources = ['/etc/ansible/hosts', 'hosts', None]
    entities = ['localhost']
    stage = 'inventory'
    data = get_vars_from_inventory_sources(loader, sources, entities, stage)
    assert data == {'test1': 'test2'}

# Generated at 2022-06-11 19:22:07.142475
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    assert get_vars_from_path(None, '.', [], 'all') == {}



# Generated at 2022-06-11 19:22:10.674832
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # TODO: Write a unit test for this function
    # Note: hard to write a test for this function,
    # as it depends on the return value of a get_vars function which can be anything
    pass

# Generated at 2022-06-11 19:22:21.436313
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    class TestVarPlugin():

        def __init__(self):
            self.host_vars = {}

        def get_vars(self, loader, path, entities):
            return {'test': 'test_host_vars'}

        def get_host_vars(self, host):
            return {'test': host}

    class TestHost(Host):

        def __init__(self, name):
            super(TestHost, self).__init__(name)

    loader = None
    entities = []

    _plugin = TestVarPlugin()
    _plugin._load_name = 'test_plugin'
    assert _plugin.get_vars(loader, None, entities) == {'test': 'test_host_vars'}

# Generated at 2022-06-11 19:22:32.678046
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.plugins.loader import vars_loader, inventory_loader
    from ansible.inventory.manager import InventoryManager  # noqa: F401
    import ansible.constants as C  # noqa: F401

    inv_path = './test/integration/inventory'
    INV_SRC = ['%s/test_inventory_plugs_dbs' % inv_path,
               '%s/test_inventory_plugs_gro' % inv_path]

    loader = inventory_loader.get('%s/test_inventory_plugs_no' % inv_path)
    entities = loader.get_hosts()

    stage = 'inventory'

    # test that get_vars_from_path works
    vars_plugin = vars_loader.get('group_vars_all')
    data = get

# Generated at 2022-06-11 19:22:38.143051
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    import os
    import sys
    display = Display()
    fake_plugin_path = os.path.join(os.path.dirname(__file__), 'fakes/plugins')
    sys.path.insert(0, fake_plugin_path)

    vars_loader.add_directory(fake_plugin_path)

    fake_hosts = ['localhost']
    fake_hosts_path = os.path.join(os.path.dirname(__file__), 'fakes/inventory/hosts')
    fake_host = Host(name='localhost')

    fake_groups = [{'name': 'fake_group'}]
    fake_groups_path = os.path.join(os.path.dirname(__file__), 'fakes/inventory/groups')


# Generated at 2022-06-11 19:22:47.026586
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    ##############################
    # Setup Class and Mock Plugin
    ##############################
    class MockPlugin():
        def __init__(self, plugin_name):
            self._load_name = plugin_name
            self._original_path = "path/to/plugin"

        def get_vars(self, loader, path, entities):
            return {plugin_name: "get_vars_called"}

    class MockLoader():
        pass

    class MockEntity():
        # TODO: Derive from object for naming consistency?
        def __init__(self, entity_name):
            self.name = entity_name

        def __str__(self):
            return self.name

    plugin_name = "my_plugin"

    entity_name = "my_entity"

    mock_plugin = MockPlugin(plugin_name)

# Generated at 2022-06-11 19:22:57.330920
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import vars_loader

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources=['localhost,'])
    var_manager = VariableManager(loader=loader, inventory=inv_manager)

    path = None
    entities = var_manager.inventory.hosts
    stage = 'task'

    # Load all vars_plugins in the vars_loader
    vars_loader.all()
    data =  get_vars_from_path(loader, path, entities, stage)
    assert len(data) == 0


# Generated at 2022-06-11 19:23:05.066256
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager

    loader = 'awx.main.plugins.inventory.vars_plugins._file_based_loader'

    fake_inventory_path = os.path.join(
        os.path.dirname(__file__), '../../../examples/files/inventory_vars_plugin/'
    )
    inventory_manager = InventoryManager(loader, [fake_inventory_path])

    host_1 = Host(name='host_1')
    group_1 = inventory_manager.groups.get('group_1')
    group_2 = inventory_manager.groups.get('group_2')

    result = get_vars_from_path(loader, fake_inventory_path, [host_1], 'inventory')

# Generated at 2022-06-11 19:23:09.678695
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    path = "."
    entities = []
    stage = "inventory"
    loader = vars_loader
    result = get_vars_from_path(loader, path, entities, stage)
    assert isinstance(result, dict) == True
