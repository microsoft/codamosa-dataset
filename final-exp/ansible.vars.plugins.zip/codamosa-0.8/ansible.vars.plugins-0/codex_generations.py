

# Generated at 2022-06-11 19:13:43.657150
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    # TODO:
    # - test path is None
    # - test path ',' in path and not os.path.exists(path)  # skip host lists
    # - test path not os.path.isdir(to_bytes(path))

    pass

# Generated at 2022-06-11 19:13:46.323655
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    assert get_vars_from_inventory_sources("loader", "sources", "entities", "stage")

# Generated at 2022-06-11 19:13:55.915498
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory import Inventory
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars

    display = Display()

    loader = AnsibleCollectionLoader()
    loader.all()

    vars_plugin_list = list(vars_loader.all())

    all_plugin_dict = {plugin._load_name: plugin for plugin in vars_plugin_list}
    all_plugin_dict.update({'b_plugin': type('b_plugin', (object,), {'get_vars': lambda *args: {'b': 2}})})

# Generated at 2022-06-11 19:14:00.576524
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    import glob
    loader = vars_loader
    sources = glob.glob('test/sanity/inventory/*.yml')
    sources = sources + ['test/sanity/inventory/group_vars/dbservers.yml']
    if sources:
        print(get_vars_from_inventory_sources(loader, sources, None, None))

# Generated at 2022-06-11 19:14:07.999969
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    os.chdir(os.path.join(os.path.dirname(__file__), '../../'))
    loader = './lib/ansible/plugins/vars'
    sources = [os.getcwd() + '/lib/ansible/plugins/inventory']
    entities = ['hosts']
    stage = 'inventory'

    vars = get_vars_from_inventory_sources(loader, sources, entities, stage)
    assert isinstance(vars, dict)

# Generated at 2022-06-11 19:14:20.736961
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    import ansible.plugins.loader as ans_pl

    test_plugin_list = ['plugin_dir', 'plugin_dir_2']
    test_plugin_list_2 = ['plugin_dir', 'plugin_dir_2', 'plugin_dir_3']
    path = '/ansible/collection/namespace/collection_name/plugins/vars/plugins_enabled_1.yml'
    invalid_path = '/ansible/collection/namespace/collection_name/plugins/vars/plugins_enabled_2.yml'
    entities = ['host1']

    # Test plugin_dir
    plugin_dir = ans_pl.VarsModule()
    plugin_dir.name = 'plugin_dir'
    plugin_dir.get_vars = lambda *args, **kwargs: {'plugin_dir': 1}
    plugin_dir

# Generated at 2022-06-11 19:14:25.678878
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    entity_list = ['host1', 'group1']
    result = get_vars_from_path(None, '.', entity_list, 'inventory')
    assert result == {}
    result = get_vars_from_path(None, None, entity_list, 'inventory')
    assert result == {}


# Generated at 2022-06-11 19:14:27.078003
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # TODO: add a test for py3
    pass



# Generated at 2022-06-11 19:14:36.342462
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    # Test 1.
    # No vars plugins
    from ansible.plugins.loader import vars_loader
    vars_loader.cached_plugins = [ ]
    vars_loader.package_paths = []
    vars_loader.plugins = []

    loader = "loader"
    path = "path"
    entities = [ "entities" ]
    stage = "stage"

    data = get_vars_from_path(loader, path, entities, stage)
    assert data == {}

    # Test 2.
    # No inventory
    # Simple yaml file

# Generated at 2022-06-11 19:14:39.923761
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    from unittest import TestCase
    from ansible.plugins.loader import vars_loader
    from ansible.module_utils._text import to_bytes


# Generated at 2022-06-11 19:14:50.834555
# Unit test for function get_plugin_vars
def test_get_plugin_vars():  # pylint: disable=no-self-use
    display.verbosity = 0
    path = os.path.expanduser('~')

    data = get_plugin_vars(None, None, path, [])
    assert data == {}

    for plugin in vars_loader.all():
        # get_vars function is not defined
        if not hasattr(plugin, 'get_vars'):
            data = get_plugin_vars(None, plugin, path, ['host1'])
            assert data == {}

# Generated at 2022-06-11 19:15:00.900390
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    import sys
    import tempfile

    # Python 2 and 3 compat
    if sys.version[0] == "3":
        from unittest.mock import patch
    else:
        from mock import patch

    class FakePlugin(object):
        _original_path = None
        _load_name = None

        def get_vars(self, loader, path, entities):
            return {'foo': 'bar'}

    with patch.object(vars_loader, '_get_all_plugin_loaders', return_value=[FakePlugin()]):
        assert get_vars_from_path(None, '/', [], None) == {'foo': 'bar'}

    with patch.object(vars_loader, '_get_all_plugin_loaders', return_value=[FakePlugin()]):
        assert get_

# Generated at 2022-06-11 19:15:04.116831
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    loader = None
    stage = 'test'
    path = 'path'
    entities = 'entities'
    result = get_vars_from_path(loader, path, entities, stage)
    assert result == {}, 'Should return empty dictionary'

# Generated at 2022-06-11 19:15:13.362247
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.vars.reserved import Reserved
    from ansible.vars.unsafe_proxy import wrap_var

    reserved_words = Reserved()
    paths = ['/usr/share/ansible/plugins/vars',
             '/usr/share/ansible/plugins/vars/host_vars',
             '/usr/share/ansible/plugins/vars/group_vars'
             ]
    mock_loader = MockVarsLoader(reserved_words, paths)

    host_vars = dict(test_var='test_value')

    vars_plugin = MockVarsPlugin(host_vars)
    data = get_plugin_vars(mock_loader, vars_plugin, 'path', 'entity')
    assert data.get('test_var') == 'test_value'

    data = get

# Generated at 2022-06-11 19:15:24.604069
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.inventory.manager import InventoryManager
    from ansible_collections.cisco.asa.plugins.module_utils.network.asa.asa import Connection

    path = r"C:\Users\praveen\Desktop\asa_ansible\hosts"
    objects = [host for host in InventoryManager(path).hosts]
    plugin = Connection('hosts', 'asa_hosts')
    loader = vars_loader.get(plugin._load_name)
    assert loader == plugin
    entities = ['asa_hosts']
    data = get_plugin_vars(loader, plugin, path, entities)
    assert isinstance(data, dict)
    assert len(data) != 0
    assert isinstance(data.get('asa_interface_obj'), list)

# Generated at 2022-06-11 19:15:26.344294
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    result = get_plugin_vars(None, None, None, None)
    assert result == {}

# Generated at 2022-06-11 19:15:31.389270
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    loader, _, path, entities = _get_basic_loader()
    assert get_vars_from_path(loader, path, entities, "some_stage") == {'a': {'a_vars': {u'a': u'I am a'}}}



# Generated at 2022-06-11 19:15:40.455494
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.cli import CLI
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader, sources=['@test_inventory'], vault_password='ansible')
    assert loader.set_vault_password('ansible')

    assert get_vars_from_inventory_sources(loader, sources=['@test_inventory'], entities=[Host(name='localhost')], stage='inventory') == {}
    assert get_vars_from_inventory_sources(loader, sources=['@test_inventory'], entities=[Host(name='localhost')], stage='task') == {'var_name1': 'var_value1'}

# Generated at 2022-06-11 19:15:45.138469
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    fake_var = {'result':'success'}
    class loader:
        pass
    class plugin:
        def get_vars(self, loader, path, entities):
            return fake_var
    result = get_plugin_vars(loader, plugin, '/path/', 'host')
    assert result == fake_var

# Generated at 2022-06-11 19:15:56.514819
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars.testvars import VarsModule as TestVars

    test_plugin = TestVars()
    test_plugin.set_options({'foo': 'bar'})
    test_plugin.set_group_vars("all", {'group_var': 'group_value'})
    test_plugin.set_host_vars("www.example.com", {'host_var': 'host_value'})

    class MockData:
        pass

    loader = MockData()
    path = "."
    host = Host("www.example.com")
    group = MockData()
    group.name = "all"

    entities = [host, group]


# Generated at 2022-06-11 19:16:12.146521
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    path = 'function_test/vars/group_vars'
    entities = []
    entities.append(Host(name='host1.example.com'))
    entities.append(Host(name='host2.example.com'))
    loader = {}
    expect = {}
    expect['g1_var'] = 'g1_value'
    expect['g2_var'] = 'g2_value'
    expect['h1_var'] = 'h1_value'
    expect['h2_var'] = 'h2_value'

    result = get_vars_from_path(loader, path, entities, 'all')

    assert(result == expect)


# Generated at 2022-06-11 19:16:20.489127
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    import os
    import tempfile
    import shutil
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars

    # set ansible.cfg to point to our test directory
    test_dir = os.path.join(os.path.dirname(__file__), 'test_data')
    os.environ[str('ANSIBLE_CONFIG')] = os.path.join(test_dir, 'ansible.cfg')

    # create a fake directory structure to pass to our module
    temp_dir = tempfile.mkdtemp()
    root = os.path.join(temp_dir, 'root')


# Generated at 2022-06-11 19:16:28.805003
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    """Return global variables as a dict object."""
    inventory_vars = {}

    vars_plugin_list = list(vars_loader.all())
    for plugin_name in C.VARIABLE_PLUGINS_ENABLED:
        vars_plugin = vars_loader.get(plugin_name)
        if vars_plugin is None:
            # Error if there's no play directory or the name is wrong?
            continue
        if vars_plugin not in vars_plugin_list:
            vars_plugin_list.append(vars_plugin)


# Generated at 2022-06-11 19:16:38.809461
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    global get_plugin_vars

    class FakeVarsPlugin:
        def get_vars(self, loader, path, entities):
            return FakeVarsPluginReturnDict.get(self.__class__)

    class FakeVarsPlugin2(FakeVarsPlugin):
        pass

    # FakeVarsPlugin returns this dict
    FakeVarsPluginReturnDict = {FakeVarsPlugin: {'fake_var': 'fake_value'},
                                FakeVarsPlugin2: {'fake_var2': 'fake_value2'}}

    # Original get_plugin_vars
    original_get_plugin_vars = get_plugin_vars

    # Monkey patch an alternative version of get_plugin_vars

# Generated at 2022-06-11 19:16:49.855557
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.parsing.vault import VaultSecret

    loader = 'test'
    sources = ['test/path1', 'test/path2', 'test/path2/test.yml,test/path2/test1.yml']
    entities = ['entity1', 'entity2', 'entity3']
    stage = 'test_stage'

    def test_get_vars(path, entities):
        data = {}
        data['vars_from_path'] = path + '/'
        data['vars_from_entities'] = entities
        return data

    class TestModel(object):
        def __init__(self):
            self.name = 'test'
            self._original_path = 'test'
            self.options = None
            self.args = None


# Generated at 2022-06-11 19:16:52.201638
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    host_vars = get_vars_from_path('inventory/test_inventory_file.yml', [], 'inventory')
    assert 'test_variable' in host_vars


# Generated at 2022-06-11 19:17:03.302819
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # TODO: Fix this to work on Windows too
    if os.name == 'nt':
        raise SkipTest

    from ansible.inventory.manager import InventoryManager

    C.VARIABLE_PLUGINS_ENABLED = ['vault']

    test_dir = os.path.join(os.path.dirname(__file__), 'test_data/vars_plugin')
    test_inventory_path = os.path.join(test_dir, 'inventory')

    loader = DataLoader()
    sources = ['host_vars', 'group_vars']
    inventory = InventoryManager(loader=loader, sources=sources)
    inventory.set_host_variable(host='all', varname='test_var', value='test_value')


# Generated at 2022-06-11 19:17:10.389012
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    class Mock_loader():
        class all():
            @staticmethod
            def get_vars():
                return {'hello': 'world'}

    class Mock_plugin():
        class _load_name():
            pass

        class _original_path():
            pass

    class Mock_entity():
        class name():
            pass

    class Mock_host():
        class name():
            pass

    class Mock_path():
        pass

    assert get_vars_from_path(Mock_loader, Mock_path, [Mock_entity(), Mock_host()], 'inventory') == {'hello': 'world'}

# Generated at 2022-06-11 19:17:21.675902
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    import sys
    import json

    from ansible.module_utils._text import to_text
    from ansible.plugins.loader import vars_loader, action_loader

    # Find a vars plugin and test it.
    # Which plugin is tested depends on which plugins are installed.
    # Iterate over the plugins until one is found.
    # This can be expanded with more tests to test additional plugins.
    expected_vars_plugin_name = 'setup'
    expected_plugin_vars = {'ansible_facts': {'distribution': 'Fedora',
                                              'distribution_major_version': '27',
                                              'distribution_release': 'Rawhide',
                                              'distribution_version': '27 (Rawhide)'}}


# Generated at 2022-06-11 19:17:27.269410
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugins
    from ansible.plugins.loader import vars_loader
    all_vars = list(vars_loader.all())
    assert all_vars
    plugin = vars_plugins.get('EnvVarVars')
    assert plugin.get_vars(vars_loader, '/some/path', 'some_entity') == {}



# Generated at 2022-06-11 19:18:05.126010
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    class MockVarPlugin:

        DEFAULT_FILE = 'defaults.yml'

        def __init__(self, name):
            self._name = name
            self._data = {}

        def get_vars(self, loader, path, entities):
            return self._data

        def get_group_vars(self, group):
            return self._data

        def get_host_vars(self, host):
            return self._data

        def set_vars(self, loader, path, entities, data):
            self._data.update(data)

        def set_group_vars(self, group, data):
            self._data.update(data)

        def set_host_vars(self, host, data):
            self._data.update(data)


# Generated at 2022-06-11 19:18:06.038517
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    # TODO: more unit test for get_vars_from_path()
    assert True

# Generated at 2022-06-11 19:18:13.487314
# Unit test for function get_vars_from_inventory_sources

# Generated at 2022-06-11 19:18:16.634042
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    data = get_vars_from_path(loader=None,
                              path="data/vars_plugins/demo_plugin",
                              entities="demo",
                              stage="demo")
    display.display("data: %s" % data)
    assert 'demo' in data


# Generated at 2022-06-11 19:18:27.299268
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Unit test requires that vars plugin directory is in the ansible modules path
    this_dir, this_filename = os.path.split(__file__)
    plugin_dir = os.path.join(this_dir, '..', '..', '..', 'plugins', 'vars')
    assert(os.path.isdir(plugin_dir))

    # Include plugin
    from ansible.plugins.vars import include_plugin
    C.VARIABLE_PLUGINS_ENABLED.append('include_plugin')

    # Mock loader
    tests_path = os.path.dirname(__file__)
    loader = None
    path = os.path.join(tests_path, 'data', 'vars_plugins', 'path1')

    # Mock entities

# Generated at 2022-06-11 19:18:35.145765
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    basedir = os.path.join(os.path.dirname(__file__), 'vars_plugins')
    vars_loader.add_directory(basedir)
    path = os.path.join(basedir, 'test')
    entities = [Host("test1")]
    vars = get_vars_from_path(vars_loader, path, entities, 'inventory')
    assert vars == {
        'test': 'test',
        'test1': 'test1',
        'test2': 'test2',
        'test3': 'test3'
    }

# Generated at 2022-06-11 19:18:42.787449
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins import vars_loader
    from ansible.vars.reserved import _get_reserved_vars
    from ansible.inventory.manager import InventoryManager

    path = '/mypath'
    loader = vars_loader
    inventory = InventoryManager(loader=loader, sources=path)
    #hosts = [host['hostname'] for host in inventory.hosts]
    entities = inventory.hosts  # + inventory.groups

    reserved_vars = _get_reserved_vars(loader, inventory)
    data1 = get_vars_from_path(loader, path, entities, 'task')

    data2 = combine_vars(reserved_vars, data1)

    assert data2.get('ansible_version').get('string') == C.__version__

# Generated at 2022-06-11 19:18:52.255683
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    '''test for get_vars_from_path, a feature that allows plugins to inject
    variables into hosts, groups and inventory.
    '''
    from ansible.plugins.loader import find_plugin_files
    from ansible.utils import plugin_docs
    # mock a plugin
    plugin_docs.INVENTORY_PLUGINS = {}
    base_dir = os.path.dirname(os.path.dirname(__file__))
    plugins = [os.path.join(base_dir, 'test_plugins', 'vars_plugins')]
    find_plugin_files(plugins, 'vars_plugins')

    import ansible.plugins.vars.generate_vars as gen_vars_plugin
    import ansible.plugins.vars.host_group_vars as hg_vars_plugin


# Generated at 2022-06-11 19:18:52.829482
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    pass

# Generated at 2022-06-11 19:19:01.612434
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    class TestPlugin(object):
        pass

    plugin = TestPlugin()
    plugin.get_vars = lambda loader, path, entities: dict(var='var_from_plugin')
    entity_manager = InventoryManager(loader=DataLoader(), sources=None)
    var_manager = VariableManager(loader=DataLoader(), inventory=entity_manager)
    assert len(var_manager.get_vars_from_path(loader=DataLoader(), path='/etc', entities=[], stage='inventory', plugin_list=[plugin])) == 1