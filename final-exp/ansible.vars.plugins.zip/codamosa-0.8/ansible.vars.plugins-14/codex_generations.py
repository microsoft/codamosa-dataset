

# Generated at 2022-06-11 19:13:51.752971
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.vars.manager import VariableManager

    fake_loader = object()
    fake_sources = 'path'

    vars_plugin_list = list(vars_loader.all())
    for plugin_name in C.VARIABLE_PLUGINS_ENABLED:
        if AnsibleCollectionRef.is_valid_fqcr(plugin_name):
            vars_plugin = vars_loader.get(plugin_name)
            if vars_plugin is None:
                # Error if there's no play directory or the name is wrong?
                continue
            if vars_plugin not in vars_plugin_list:
                vars_plugin_list.append(vars_plugin)


# Generated at 2022-06-11 19:14:01.919288
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    tmp = os.path.realpath(os.path.join(os.path.dirname(__file__), '../lib/ansible/plugins/vars'))
    if tmp not in C.VARS_PLUGINS_Dirs:
        C.VARS_PLUGINS_Dirs.append(tmp)
    # case 1: RUN_VARS_PLUGINS = 'all' (default)
    C.RUN_VARS_PLUGINS = 'all'
    data = get_vars_from_inventory_sources(None, ['/tmp'], [], 'inventory')
    assert 'ansible_facts' in data.keys()
    assert 'ansible_playbook_python' in data.keys()
    assert 'ansible_local' in data.keys()
    # case 2: RUN_VARS_PL

# Generated at 2022-06-11 19:14:05.927250
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    p = vars_loader.get('plugins/vars/v0')
    assert p.get_vars(None, '/my/path', ['my/entity']) == {'a': 'b'}

# Generated at 2022-06-11 19:14:14.503897
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    """
    TODO
    """
    import ansible.inventory
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.system.pkg_mgr
    import ansible.module_utils.facts.virtual.virtualbox
    import ansible.module_utils.facts.virtual.xen
    from ansible.plugins.loader import collection_loader
    from ansible.plugins.vars import ansible_defaults
    from ansible.plugins.vars import ansible_managed
    from ansible.plugins.vars import configuration
    from ansible.plugins.vars import dependencies
    from ansible.plugins.vars import group_by
    from ansible.plugins.vars import yaml_inventory

    config_loader

# Generated at 2022-06-11 19:14:20.096529
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    loader = 'ansible.parsing.dataloader.DataLoader'
    sources = ['/etc/ansible/hosts']
    entities = []
    stage = 'task'
    data = get_vars_from_inventory_sources(loader, sources, entities, stage)
    print(data)


if __name__ == '__main__':
    test_get_vars_from_inventory_sources()

# Generated at 2022-06-11 19:14:31.349919
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # test for plugins that implement get_vars
    loader = None
    path = './test/unit/plugins/vars_plugins'
    entities = ['test/unit/plugins/vars_plugins/hosts2']
    stage = 'inventory'
    expected = {u'bar': u'foo', u'foo': u'bar'}
    result = get_vars_from_path(loader, path, entities, stage)
    assert result == expected

    # test for plugins that implement get_host_vars and get_group_vars
    loader = None
    path = './test/unit/plugins/vars_plugins'
    entities = ['test/unit/plugins/vars_plugins/hosts2']
    stage = 'inventory'

# Generated at 2022-06-11 19:14:36.095569
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    plugin_name = 'examplevars'
    examplevars_path = os.path.join(os.path.dirname(os.path.realpath(__file__)),'examplevars')
    examplevars_path = os.path.join(examplevars_path,'__init__.py')
    examplevars = vars_loader.get(plugin_name)
    assert examplevars.get_vars(vars_loader, examplevars_path, []) == {}

# Generated at 2022-06-11 19:14:46.239978
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager

    def test_get_vars_from_path_stage_inventory(host_vars, group_vars, vars_from_path):
        inv = InventoryManager(host_vars=host_vars, group_vars=group_vars)
        # Mock so we can control the plugin instances
        vars_loader._all_plugins = {}
        vars_loader.package_paths = [os.path.join(os.path.dirname(__file__), 'vars_plugins')]
        for path in vars_loader.find_vars_plugins('.'):
            plugin = vars_loader.get(path)
            if plugin:
                vars_loader._all_plugins[plugin._load_name] = plugin

# Generated at 2022-06-11 19:14:53.232705
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    plugin_list = []
    vars_plugin_list = list(vars_loader.all())

    for plugin in vars_plugin_list:
        if plugin._load_name == 'host_list':
            plugin_list.append(plugin)

    for plugin in plugin_list:
        assert(vars_loader.all())
        data = plugin.get_vars(plugin, plugin._original_path, None)
        assert data == {}, "error with ansible collection"

# Generated at 2022-06-11 19:15:02.718594
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.module_utils.six import PY3
    from ansible.inventory.manager import InventoryManager
    if PY3:
        from importlib import reload # pylint: disable=import-error

    # setup vars_loader
    vars_loader._module_utils_path = ['lib/ansible/module_utils']

    # setup inventory manager
    inventory_source = "./test/units/plugins/inventory/resources/complex_hostname.ini"
    inventory_manager = InventoryManager(loader=None, sources=[inventory_source])

    # setup plugin
    vars_plugin = vars_loader.get('refresh_vars_plugin')
    vars_plugin_list = [vars_plugin]
    vars_loader._get_all_plugin

# Generated at 2022-06-11 19:15:20.951995
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.utils.collection_loader import AnsibleCollectionRef
    test_path = './tests/units/module_utils/vars_plugins'
    vars_loader.add_directory(test_path)
    loader = AnsibleCollectionLoader(None)
    sources = [test_path]
    host = Host('localhost')
    entities = [host]
    stage = 'inventory'
    data = get_vars_from_path(loader, sources[0], entities, stage)
    assert data['version_info']['minor'] <= 0

# Generated at 2022-06-11 19:15:22.084892
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    # TODO:

    pass

# Generated at 2022-06-11 19:15:24.682466
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    loader = None
    path = None
    entities = [None]
    stage = None
    data = get_vars_from_path(loader, path, entities, stage)
    assert data == {}


# Generated at 2022-06-11 19:15:34.339147
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    import ansible.plugins.vars
    import ansible.plugins.vars.system

    loader = ansible.plugins.vars.VarsModule()

    plugin = ansible.plugins.vars.system.VarsModule()
    plugin.get_vars = lambda x, y, z: {'path': y, 'entities': z}

    my_path = '/path/to/my/file'
    my_entities = [1, 2]
    assert get_vars_from_path(loader, my_path, my_entities, 'task') == {'path': my_path, 'entities': my_entities}

# Generated at 2022-06-11 19:15:43.106422
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    host = Host("test")
    host.vars = {'ansible_distribution': 'CentOS',
                 'ansible_distribution_version': '7.1',
                 'ansible_distribution_release': 'Final',
                 'ansible_os_family': 'RedHat',
                 'ansible_pkg_mgr': 'yum',
                 'ansible_user_id': 'ansible',
                 'ansible_env': {'HOME': '.'},
                 }
    a = {'a': 'x'}
    vars_plugin_list = [a, host]
    assert get_vars_from_path(None, None, vars_plugin_list, None) == a



# Generated at 2022-06-11 19:15:44.859365
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert get_vars_from_path({}, "./", entities, stage) is None

# Generated at 2022-06-11 19:15:56.080373
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    import unittest

    class TestContainer:
        def __init__(self):
            self.VARS_PLUGINS = []
            self.VARS_PLUGINS.append(get_vars_from_path())

    class TestPlugin:
        def __init__(self):
            self._load_name = 'test'

    class TestHost:
        def __init__(self):
            self.name = 'localhost'

    class TestGroup:
        def __init__(self):
            self.name = 'group1'

    class TestCase(unittest.TestCase):

        def setUp(self):
            self.container = TestContainer()
            self.plugin = TestPlugin()

        def test_get_vars_from_path(self):
            self.container.VARS_PLUGINS = []


# Generated at 2022-06-11 19:16:06.968618
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.constants import plugin_vars_loader

    sources = ['/etc/ansible/hosts']
    entities = ['local', 'web']
    path = '/etc/ansible/hosts'
    data_from_path = {}


# Generated at 2022-06-11 19:16:13.985729
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader

    def make_plugin(name, vars):
        class Plugin(object):
            _load_name = name
            _original_path = name

            def get_vars(self, loader, path, entities, cache=True):
                return vars

        return Plugin()

    test1_vars = make_plugin('test1', {'test1_var': 'test1_val'})
    test2_vars = make_plugin('test2', {'test2_var': 'test2_val'})
    test3_vars = make_plugin('test3', {'test3_var': 'test3_val'})
    test4_vars = make_plugin('test4', {'test4_var': 'test4_val'})
    test5_

# Generated at 2022-06-11 19:16:24.112329
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    # Non-existent plugin
    plugin = vars_loader.get('fake')
    path = '/tmp'
    entities = []
    data = get_plugin_vars(None, plugin, path, entities)
    assert data == {}

    # Rollback plugin (pre 1.4)
    plugin = vars_loader.get('rollback')
    path = '/tmp'
    entities = []
    data = get_plugin_vars(None, plugin, path, entities)
    assert data == {}

    # Run now plugin (1.4 plugin)
    plugin = vars_loader.get('runnow')
    path = '/tmp'
    entities = []
    data = get_plugin_vars(None, plugin, path, entities)
    assert data is not None

    # Some plugins depend on being supplied a valid loader.
    #

# Generated at 2022-06-11 19:16:36.774489
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert get_vars_from_path(
        loader='loader',
        path='path',
        entities=['entities'],
        stage='stage') is None

# Generated at 2022-06-11 19:16:47.632220
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    good_vars_plugin_data = '{"foo": {"bar": "baz"}}'
    bad_vars_plugin_data = '{"foo": {"bar"}'
    path = os.path.abspath(os.path.dirname(__file__)) + "/test_data/good_vars_plugin"
    test_host = Host("localhost")
    test_group = Group("test")

    # test loading single vars plugin
    test_plugin = VarsModule(path)
    assert test_plugin.get_vars(None, path, [test_host]) == json.loads(good_vars_plugin_data)

    # test bad vars plugin
    os.rename(path + "/vars_plugin.py", path + "/bad_vars_plugin.py")
    test_plugin = Vars

# Generated at 2022-06-11 19:16:56.018312
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    test_file_contents = '{"a": "b"}'

    vars_plugin_list = list(vars_loader.all())
    plugin = vars_loader.get("json_file")

    entities = [Host("test")]
    path = "/tmp"

    assert get_plugin_vars(vars_plugin_list, plugin, path, entities) == {}

    vars_plugin_list.append(plugin)

    assert get_vars_from_path(vars_plugin_list, path, entities, "test") == {}

    with open(os.path.join(path, "test.json"), "w") as file:
        file.write(test_file_contents)


# Generated at 2022-06-11 19:17:04.534359
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    class Plugin():
        pass

    class Loader():
        pass

    loader = Loader()
    plugin = Plugin()

    plugin.get_vars = lambda loader, path, entities: {'generated': 'test value'}
    C.RUN_VARS_PLUGINS = 'all'
    C.VARIABLE_PLUGINS_ENABLED = ['test_plugin']

    result = get_vars_from_path(loader, 'path', 'entities', 'all')
    assert result['generated'] == 'test value'


# Generated at 2022-06-11 19:17:07.724444
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    loader = None
    path = "/"
    entities = None
    stage = "task"
    vars_data = get_vars_from_path(loader=loader, path=path, entities=entities, stage=stage)
    assert vars_data

# Generated at 2022-06-11 19:17:13.517707
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    import sys
    import imp
    import tempfile
    tempdirname = tempfile.mkdtemp()
    sys.path.append(tempdirname)
    test_file_name = tempdirname + "/vars_test.py"

# Generated at 2022-06-11 19:17:24.048493
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # requires testing for v2 vars plugins with and without stage support

    # stub object for testing purposes
    class stub_vars_loader():
        pass

    class stub_plugin():
        def get_vars(loader, path, entities):
            return {'foo': 'bar'}

    class stub_plugin1():
        def get_vars(loader, path, entities):
            return {'foo': 'bar', 'baz': 'buzz'}

    class stub_plugin2():
        def get_vars(loader, path, entities):
            return {'baz': 'buzz', 'fuz': 'fiz'}

    loader = stub_vars_loader()
    plugin = stub_plugin()
    plugin1 = stub_plugin1()
    plugin2 = stub_plugin2()


# Generated at 2022-06-11 19:17:27.717204
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from units.mock.loader import DictDataLoader
    sources = ['foo/bar', 'localhost, ', 'localhost', 'bar/foo', '/dev/null']
    inventory = DictDataLoader(dict(foo={'hosts': {'localhost': None}}))
    result = get_vars_from_inventory_sources(inventory, sources, None, None)
    assert result == {}


# Generated at 2022-06-11 19:17:31.020009
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    result = get_vars_from_path(loader, '/ansible', ['testhost'],  'inventory')
    assert result == {}



# Generated at 2022-06-11 19:17:42.599401
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    class Plugin:
        def __init__(self, name, vars):
            self.name = name
            self.vars = vars

        def get_vars(self, loader, path, entities):
            return self.vars

    class MockLoader:
        pass

    pl1 = Plugin('p1', {'p1k1': 'p1v1', 'p1k2': 'p1v2'})
    pl2 = Plugin('p2', {'p2k1': 'p2v1'})

    pls = [pl1, pl2]
    data = {}

    # v2 plugin(s)
    data = combine_vars(data, get_plugin_vars(MockLoader, pl1, 'path', 'entities'))

# Generated at 2022-06-11 19:17:56.020236
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    entities = [
        Host('inventory_hostname_1'),
        Host('inventory_hostname_2'),
    ]

    module_utils = 'lib/ansible/module_utils/'
    collection_paths = [
        'lib/ansible/collections/',
        'lib/ansible/plugins/',
        module_utils,
    ]

    data = get_vars_from_path(None, module_utils, entities, 'all')

    assert data
    assert len(data) == 3
    assert data['ansible_version']
    assert data['ansible_facts']
    assert data['ansible_config']

# Generated at 2022-06-11 19:18:04.828474
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    class TestPlugin:
        def get_vars(self, loader, path, entities):
            return {'var1': 'var1'}

    loader = {}
    path = "/path/"
    entities = []
    stage = "inventory"
    vars_plugin_list = [TestPlugin(), TestPlugin()]
    data = {}


# Generated at 2022-06-11 19:18:06.251982
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    loader = None
    path = None
    entities = None
    stage = None
    get_vars_from_path(loader, path, entities, stage)

# Generated at 2022-06-11 19:18:12.024857
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    import ansible.plugins.vars.host_list
    loader = ansible.parsing.dataloader.DataLoader()
    plugin = ansible.plugins.vars.host_list.VarsModule()
    entities = ['127.0.0.1', 'localhost']
    path = '~/py3'
    data = {}
    data = combine_vars(data, get_plugin_vars(loader, plugin, path, entities))
    print(data)

if __name__ == '__main__':
    test_get_vars_from_path()

# Generated at 2022-06-11 19:18:17.959858
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    data = get_vars_from_path(None, '/', ['k8s_host'], 'start')

    assert isinstance(data, dict)
    assert 'k8s_host' in data and isinstance(data['k8s_host'], dict)
    assert 'k8s_host' in data['k8s_host'] and isinstance(data['k8s_host']['k8s_host'], dict)
    assert 'k8s_host' in data['k8s_host']['k8s_host'] and isinstance(data['k8s_host']['k8s_host']['k8s_host'], dict)
    assert 'k8s_host' in data['k8s_host']['k8s_host']['k8s_host']

# Generated at 2022-06-11 19:18:28.208217
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    class FakePlugin():
        def __init__(self, name):
            self.name = name

        def get_vars(self, loader, path, entities):
            return {self.name: path}

    data = get_vars_from_path(None, '/some/path', [], 'task')
    assert data == {}, 'Did not expect any vars'

    data = get_vars_from_path(None, '/some/path', [FakePlugin('some_name')], 'task')
    assert data == {'some_name': '/some/path'}, 'Did not get expected vars for single plugin'

    data = get_vars_from_path(None, '/some/path', [FakePlugin('some_name1'), FakePlugin('some_name2')], 'task')

# Generated at 2022-06-11 19:18:31.774308
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    # make loader and call function
    loader = 'dummy_loader'
    path = 'dummy_path'
    entities = ['dummy_entities']
    stage = 'dummy_stage'
    assert get_vars_from_path(loader, path, entities, stage) == {}

# Generated at 2022-06-11 19:18:39.064608
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    class MockPlugin:
        def get_vars(self, loader, path, entities):
            return {'a': 1}

    class MockVarsPlugins:
        @staticmethod
        def all():
            return [MockPlugin()]
        @staticmethod
        def get(name):
            return MockPlugin()

    from ansible.constants import Constant

    Constant.DEFAULT_RUN_VARS_PLUGINS = 'start'
    Constant.DEFAULT_VARIABLE_PLUGINS_ENABLED = ['MockPlugin']
    assert get_vars_from_path(None, '/a', [], 'task')['a'] == 1

# Generated at 2022-06-11 19:18:49.744275
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    # Create a fake plugin with a fake get_vars function
    class FakePlugin:
        def get_vars(self, loader, path, entities):
            return {'var1': 'value1',
                    'var2': 'value2'}

    # Create a fake loader object
    class FakeLoader:
        def __init__(self):
            self.collection_loader = None

    # Create a fake entity
    class FakeEntity:
        def __init__(self, name):
            self.name = name

    # Create fake entities
    fake_entity1 = FakeEntity('fake_entity1')
    fake_entity2 = FakeEntity('fake_entity2')
    entities = [fake_entity1, fake_entity2]

    # Check fake plugin is working
    fake_plugin = FakePlugin()
    assert get_plugin_vars

# Generated at 2022-06-11 19:19:00.011300
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    fake_loader = 'Fake Loader'
    fake_path = 'Fake Path'
    fake_entities = ['Fake Entity']
    fake_stage = 'Fake Stage'
    fake_plugin_a = FakePluginA('Fake Plugin A')
    fake_plugin_b = FakePluginB('Fake Plugin B')
    fake_plugin_list = [fake_plugin_a, fake_plugin_b]
    fake_plugin_name = 'fake_plugin_name'
    fake_plugin = FakePluginA('Fake Plugin A')
    fake_plugins_enabled = [fake_plugin_name]

    assert get_vars_from_path(fake_loader, fake_path, fake_entities, fake_stage) == {}

    fake_plugin_list.append(fake_plugin)
    C.VARIABLE_PLUGINS_ENABLED

# Generated at 2022-06-11 19:19:18.680940
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    data = {}
    for plugin_name in C.VARIABLE_PLUGINS_ENABLED:
        if plugin_name == 'top':
            data = get_plugin_vars(None, vars_loader.get(plugin_name), None, None)
    assert 'ansible_top_var' in data



# Generated at 2022-06-11 19:19:20.604674
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    assert get_vars_from_path(None, '.', '', 'task') == {}

# Generated at 2022-06-11 19:19:21.140393
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    pass

# Generated at 2022-06-11 19:19:30.673358
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.utils.vars import combine_vars
    from ansible.utils.collection_loader import AnsibleCollectionRef
    from ansible.plugins.loader import vars_loader

    # load plugin
    plugin_name = "Ansible.collections.ansible.builtin.vars_group_vars_v2"
    plugin = vars_loader.get(plugin_name)
    entities = {}

    path = '/usr/share/ansible/'
    loader = None
    stage = 'inventory'
    assert get_vars_from_path(loader, path, entities, stage) == {}

    path = '/usr/share/ansible/'
    entities = {'test': 'test'}
    stage = 'inventory'
    assert get_vars_from_path(loader, path, entities, stage)

# Generated at 2022-06-11 19:19:38.992847
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    '''
    tests the functionality of get_vars_from_path
    '''
    # create a fake vars plugin
    class FakePlugin:
        def get_vars(self, loader, path, entities):
            return {'test_vars': True}

    # create a fake vars plugin
    class FakePlugin2:
        def get_host_vars(self, name):
            return {'test_host_vars': True}

        def get_group_vars(self, name):
            return {'test_group_vars': True}

    global display

    # create a Mock Display to avoid the actual output
    class FakeDisplay:
        def display(self, msg, color=None):
            pass
    display = FakeDisplay()

    # create a fake loader
    class FakeDataLoader:
        pass


# Generated at 2022-06-11 19:19:46.679615
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    print('test_get_vars_from_path')

    class TestVarsPlugin:

        def get_vars(self, loader, path, entities):
            print('plugin get_vars')
            return {'a': 2}

        def get_group_vars(self, name):
            print('plugin get_group_vars')
            return {'b': 3}

        def get_host_vars(self, name):
            print('plugin get_host_vars')
            return {'c': 4}

    vars_loader.add('test', TestVarsPlugin())

    assert get_vars_from_path({}, '', None, 'inventory') == {'a': 2}

# Generated at 2022-06-11 19:19:52.506780
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    '''
    unit test for function get_vars_from_path
    '''
    plugin = VarsPlugin(None, None)
    plugin._load_name = 'testname'
    loader = None
    path = None
    entities = [1, 2]
    stage = None
    assert get_vars_from_path(loader, path, entities, stage) == {}


# Generated at 2022-06-11 19:20:01.708122
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    from ansible.vars.vars_plugins import VarsModule
    from ansible.vars.hostvars import HostVars

    from ansible.vars.task_vars import TaskVars
    from ansible.vars.group_vars import GroupVars
    from ansible.vars.file_vars import FileVars
    from ansible.vars.filesystem_vars import FileSystemVars

    class Plugin1(VarsModule):
        def get_vars(self, loader, path, entities):
            return {'plugin1': path}

    class Plugin2(VarsModule):
        def get_host_vars(self, host):
            return {host: host}


# Generated at 2022-06-11 19:20:08.057093
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    import ansible.plugins.loader as plugin_loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    path = ''
    entities = []
    stage = 'inventory'
    data = {}

    vars_plugin_list = list(vars_loader.all())

    data = get_vars_from_path(loader, path, entities, stage)

    vars_plugin_list = list(vars_loader.all())
    for plugin in vars_plugin_list:
        data = combine_vars(data, get_plugin_vars(loader, plugin, path, entities))

# Generated at 2022-06-11 19:20:14.044329
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    loader = None
    path = '/path/to/dir'
    entities = []
    stage = 'task'
    vars_plugin_list=list()

    vars_plugin_list.append('dummy plugin')
    vars_plugin_list.append('dummy plugin2')

    data = get_vars_from_path(loader, path, entities, stage)
    assert vars_plugin_list == list(vars_loader.all())

# Generated at 2022-06-11 19:20:38.444941
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import find_plugin_filepaths
    loader = vars_loader

    plugin_rnames = list(vars_loader.all(ignore_errors=True))  # Test needs it in this format

    # Test with path matching plugin
    plugin = vars_loader._get(plugin_rnames[0], class_only=True)
    path = plugin._original_path[:plugin._original_path.find('/library')]

    # Test with path not matching plugin
    plugin = vars_loader._get(plugin_rnames[0], class_only=True)
    path = find_plugin_filepaths('library', subdirs=True)[0]

    # Test with two plugins
    plugin_rnames = plugin_rnames[0:2]  # get_vars_from_path only looks

# Generated at 2022-06-11 19:20:43.379880
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # get_vars_from_path returns a dictionary of data populated from the vars plugins
    # in the plugin path.  This tests the path traversal for the vars plugins.
    path = '/tmp'
    entities = [{}, {}]

    assert isinstance(get_vars_from_path(None, path, entities, 'inventory'), dict)

# Generated at 2022-06-11 19:20:47.567602
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader

    loader = []

    vars_from_path = get_vars_from_path(loader, '.', [], 'task')
    ret = loader.get_all_plugin_loaders('vars')

    assert isinstance(vars_from_path, dict)
    assert isinstance(ret, list)

# Generated at 2022-06-11 19:20:57.935550
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.parsing.dataloader import DataLoader

    sources = [
        '/path/to/playbooks/group_vars',
        '/path/to/playbooks/inventory_source',
        '/path/to/playbooks/inventory_source',
    ]

    loader = DataLoader()
    path = '/path/to/playbooks/inventory_source'

    # test the path=... case
    data1 = get_vars_from_path(loader, path, [], None)
    assert data1 == {}

    # test one "real" case to catch regressions early
    dummy_entity = 'Dummy'
    data2 = get_vars_from_path(loader, path, [dummy_entity], None)
    assert dummy_entity in data2

# Generated at 2022-06-11 19:20:59.900435
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    print (get_vars_from_path('/usr/share/ansible/plugins/inventory/hosts.yml', 'hosts.yml'))

# Generated at 2022-06-11 19:21:02.500962
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert to_bytes(get_vars_from_path('loader', '/etc/ansible/hosts', 'entities', 'stage')) == {}

# Generated at 2022-06-11 19:21:03.296934
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    pass


# Generated at 2022-06-11 19:21:03.623796
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    pass

# Generated at 2022-06-11 19:21:13.425527
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.plugins.vars import blah

    def test_loader(path, *args, **kwargs):
        return blah.BlahVarsModule()

    # Test to make sure the get_vars method is called in v2 plugins
    test_data_v2 = ImmutableDict({'foo': 'bar'})
    result_v2 = get_vars_from_path(test_loader, '/', None, 'inventory')
    assert result_v2 == test_data_v2

    # Test to make sure the get_host_vars and get_group_vars methods are called in v1 plugins

# Generated at 2022-06-11 19:21:16.524021
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert isinstance(get_vars_from_path(object, "", [], ""), dict)

# Generated at 2022-06-11 19:21:50.762612
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    import sys
    import os
    import tempfile
    import shutil
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..', '..', 'plugins'))

    # Create a test directory to play in
    test_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(test_dir, 'plugins', 'vars'))

    # Place a toy plugin in the directory
    # This plugin returns a value for all hosts
    plugin_dir = os.path.join(test_dir, 'plugins', 'vars', 'vars_test.py')

# Generated at 2022-06-11 19:21:52.030407
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    pass

# Generated at 2022-06-11 19:21:54.302243
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # This function is not unit tested because it does not produce deterministic results
    pass

# Generated at 2022-06-11 19:21:54.865396
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    pass

# Generated at 2022-06-11 19:22:00.678968
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    import ansible.plugins.loader as plugins_loader

    def _get_collection_loader():
        # load collections and return the loader object
        import ansible.config
        import ansible.collections
        ansible.config.load_collections = True
        bl = ansible.collections.collections_loader.CollectionsLoader()
        bl._load_collections()
        bl._load_list_of_collections([])
        return bl

    # setup a test plugin
    class MyPlugin(object):
        def get_vars(self, loader, path, entities):
            return dict(foo='bar')

    # setup a test collection plugin
    class MyCollectionPlugin(object):
        def get_vars(self, loader, path, entities):
            return dict(baz='bam')

    real_get_plugins = plugins

# Generated at 2022-06-11 19:22:02.729605
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Test that one plugin returns the expected value
    #   Create an inventory with one plugin returning a value
    #   Assert that the function returns that value
    pass

# Generated at 2022-06-11 19:22:04.378209
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    # TODO: Write this
    pass

# Generated at 2022-06-11 19:22:06.130321
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert len(get_vars_from_path("x", "y", "z")) == 0

# Generated at 2022-06-11 19:22:13.443742
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    from ansible.inventory.hosts import Hosts
    from ansible.vars.manager import VariableManager

    loader = 'fixture/test_vars_plugins/'
    path = 'fixture/test_vars_plugins/group_vars/all/'
    group = Hosts(loader=loader)
    group.add_group('all')
    host1 = Host('host1')
    host2 = Host('host2')
    group.add_host(host1)
    group.add_host(host2)

    data = get_vars_from_path(loader, path, group.get_group('all'), 'inventory')
    var_manager = VariableManager(loader=loader, inventory=group)
    assert var_manager.get_vars(host=host1) == data

    data = get_vars

# Generated at 2022-06-11 19:22:22.732879
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    import pytest
    from ansible.inventory.manager import InventoryManager
    loader = InventoryManager(loader='yaml')
    sources = [
        'test/data/inventory_vars/inventory_vars_1',
        'test/data/inventory_vars/inventory_vars_2',
    ]
    fake_hosts = [
        Host('host1'),
        Host('host2'),
        Host('host3'),
    ]
    fake_groups = [
        loader.groups['group_1'],
        loader.groups['group_2'],
        loader.groups['group_3'],
    ]
    # host_vars and group_vars defined in inventory_vars_1 and inventory_vars_2 should be merged in alphabetical order

# Generated at 2022-06-11 19:23:36.937419
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import find_plugin_files
    from ansible.plugins.loader import vars_loader
    from ansible.plugins.loader import vars_loader as plugin_loader
    from ansible.plugins.loader import vars_loader, get_plugin_class, get_plugin_class, get_plugin_class, get_plugin_class

    print(vars_loader)
    print(plugin_loader)
    print(get_plugin_class)

    """
    This function is a unit test for function get_vars_from_path().

    It shows how a inventory plugin gets called and its output as it would be
    called when run by the inventory script.
    """
    # Get a list of paths where we are looking for plugins.