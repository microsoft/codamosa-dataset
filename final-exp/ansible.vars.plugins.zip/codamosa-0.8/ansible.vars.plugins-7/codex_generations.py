

# Generated at 2022-06-11 19:13:54.893450
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    # If successful, nothing would be raised
    assert get_plugin_vars

# Generated at 2022-06-11 19:14:03.037825
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    plugin = type('Plugin', (object, ), {})
    loader = type('Loader', (object, ), {})
    path = 'path'
    display.verbosity = 5

    # get_vars not implemented
    entities = ['foo']
    result = get_plugin_vars(loader, plugin, path, entities)
    assert isinstance(result, dict)
    assert result == {}

    # get_vars implemented
    entities = ['foo']
    get_vars_return = 'get_vars'
    plugin.get_vars = lambda x, y, z: get_vars_return
    result = get_plugin_vars(loader, plugin, path, entities)
    assert result == get_vars_return



# Generated at 2022-06-11 19:14:05.980341
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert get_vars_from_path('test_loader', 'test_path', 'test_entities', 'test_stage') == {}

# Generated at 2022-06-11 19:14:08.955673
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader

    assert get_vars_from_path(vars_loader, os.path.dirname(__file__), None, 'inventory') == {}

# Generated at 2022-06-11 19:14:21.203866
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.loader import vars_loader

    plugin = vars_loader.get('test_var_plugin_test')
    assert plugin is not None

    data = get_plugin_vars(None, plugin, None, [])
    assert 'ANSIBLE_VAR_PLUGIN_TEST_VAR_1' in data
    assert 'ANSIBLE_VAR_PLUGIN_TEST_VAR_2' in data
    assert 'ANSIBLE_VAR_PLUGIN_TEST_VAR_3' in data
    assert data['ANSIBLE_VAR_PLUGIN_TEST_VAR_1'] == 'Z'
    assert data['ANSIBLE_VAR_PLUGIN_TEST_VAR_2'] == 'Y'

# Generated at 2022-06-11 19:14:32.342411
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.executor.play_iterator import PlayIterator
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext

    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop
    from units.mock.plugins.loader import make_vars_plugin

    dl = DictDataLoader({})
    inventory = InventoryManager(loader=dl, sources=['localhost,', 'otherhost,'])
    myhost = inventory.get_host('myhost')

    play_context = PlayContext()


# Generated at 2022-06-11 19:14:43.476756
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    """
    Test that get_vars_from_path loads the vars plugin as expected
    """

    import ansible.plugins
    import ansible.plugins.vars.test_vars_plugin

    def get_object(module_name, object_path, *args, **kwargs):
        if module_name == 'ansible.plugins.vars.test_vars_plugin':
            obj = ansible.plugins.vars.test_vars_plugin
        else:
            obj = loader.get(module_name, object_path, *args, **kwargs)
        return obj

    loader = ansible.plugins.loader.vars_loader
    loader._get_all_plugin_loaders = lambda *args, **kwargs: [ansible.plugins.vars.test_vars_plugin]
    loader._get

# Generated at 2022-06-11 19:14:52.088074
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    loader = None
    path = './'
    entities = [1, 2, 3]
    stage = ['all', 'start', 'task', 'inventory']
    try:
        for step in stage:
            get_vars_from_path(loader, path, entities, step)
    except Exception as e:
        display.error(u'Get_vars_from_path failed with error: %s\n' % to_text(e, errors='surrogate_or_strict'))
        assert False
    else:
        display.error(u'Get_vars_from_path failed\n')
        assert True

# Generated at 2022-06-11 19:15:01.734554
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    import ansible.vars.hostvars_vars_plugin

    loader = ansible.vars.hostvars_vars_plugin.VarsModule()
    vars_plugin_list = list(vars_loader.all())
    vars_plugin_list.append(loader)
    res = get_vars_from_path(loader, 'inventory/plugins/vars', 'ansible', 'inventory')
    assert res
    res = get_vars_from_path(loader, 'inventory/plugins/vars', 'ansible', 'task')
    assert not res
    ansible.constants.RUN_VARS_PLUGINS = 'demand'

# Generated at 2022-06-11 19:15:06.045418
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    '''
    This function should return a dictionary of variables
    '''
    loader = None
    entities = []
    stage = 'task'
    # set fixture
    path = os.path.join(os.path.dirname(__file__), '../fixtures/')
    # function to test
    data = get_vars_from_path(loader, path, entities, stage)
    # assert
    assert data['a'] == 1
    assert data['b'] == 2
    assert data['c'] is True

# Generated at 2022-06-11 19:15:25.298508
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    '''
    Test case is to create a file in the test/units/lib/ansible/vars/vars_test_dir.yml.
    It contains a variable group_vars_test_variable = 'TEST'
    It will load a group_vars_paths plugin and execute get_vars_from_path(loader, path, entities, stage)
    function.
    :return:
    '''

    # Create a test directory
    os.makedirs(os.path.join('test/units/lib/ansible/vars/', 'vars_test_dir'), exist_ok=True)
    # Create a test file

# Generated at 2022-06-11 19:15:27.332856
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    assert get_plugin_vars([], {}, '', []) == {}, 'output: {}'



# Generated at 2022-06-11 19:15:29.322038
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    assert get_plugin_vars(None, None, None, None) == {}

# Generated at 2022-06-11 19:15:39.631983
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.vars import combine_vars
    from ansible.module_utils._text import to_bytes

    from ansible.plugins.loader import vars_loader

    from ansible.utils.collection_loader import AnsibleCollectionRef

    from ansible.utils.display import Display
    display = Display()

    from ansible.plugins.loader import vars_loader
    vars_plugin_list = list(vars_loader.all())
    for plugin_name in C.VARIABLE_PLUGINS_ENABLED:
        if AnsibleCollectionRef.is_valid_fqcr(plugin_name):
            vars_plugin = vars_loader.get(plugin_name)
            if vars_plugin is None:
                continue
            if vars_plugin not in vars_plugin_list:
                vars

# Generated at 2022-06-11 19:15:47.723789
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Test to make sure plugin whitelisting works.
    # This should load the vars_plugins/test_vars_plugin.py (which exists) but not the vars_plugins/test_no_vars_plugin.py
    # (which does not)
    entities = []
    test_loader = 'test_loader'
    test_path = 'test_path'
    data = get_vars_from_path(test_loader, test_path, entities, 'test_stage')
    assert 'test_variable' in data and data['test_variable'] == 1
    assert 'no_test_variable' not in data

test_get_vars_from_path()

# Generated at 2022-06-11 19:15:59.389825
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager
    test_hosts = [Host(name='host1'), Host(name='host2')]
    test_sources = ['.']
    test_stages = ['inventory', 'task']
    test_results = {}

    # Run through the test cases
    for test_stage in test_stages:
        test_results[test_stage] = get_vars_from_inventory_sources(InventoryManager(loader=None), test_sources, test_hosts, test_stage)

    # Assert that we can find specific vars in each of the test results
    assert (set(['service', 'package']) <= set(test_results['inventory']))
    assert (set(['port', 'config_file']) <= set(test_results['task']))

# Generated at 2022-06-11 19:15:59.949581
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    pass

# Generated at 2022-06-11 19:16:05.440266
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    '''Test get_vars_from_path function'''
    loader = None
    path = '/tmp'
    entities = 'defaults'
    stage = 'inventory'
    get_vars_from_path(loader, path, entities, stage)



# Generated at 2022-06-11 19:16:13.343595
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins import vars_manager
    loader = vars_manager.VarsModule()
    class MyVars:
        def __init__(self):
            pass
    myvars = MyVars()

    class MyPlugin:
        def __init__(self):
            pass
        def get_vars(self, loader, path, entities):
            return {'name1': 'value1'}
    plugin = MyPlugin()
    vars = get_plugin_vars(loader, plugin, 'path', entities)
    assert vars == {'name1': 'value1'}
    vars = get_plugin_vars(loader, myvars, 'path', entities)
    assert vars == {}

    class MyPlugin2:
        def __init__(self):
            pass

# Generated at 2022-06-11 19:16:23.441680
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import testvars_plugin
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader

    class DummyPlugin:
        def __init__(self, name):
            self._load_name = name
            self._original_path = 'dummy/path'

    class DummyVaultLib(VaultLib):
        def __init__(self, *args, **kwargs):
            pass

    class DummyLoader(DataLoader):
        def __init__(self, *args, **kwargs):
            self.vault = DummyVaultLib()
            self.vault_password = None

    loader = DummyLoader()

    # test v2 interface
    var_plugin = testvars_plugin.TestVars

# Generated at 2022-06-11 19:16:35.436303
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    loader = vars_loader
    entities = ["test_entity"]
    stage = 'inventory'
    sources = []
    sources.append(None)
    sources.append('.')
    sources.append('../ansible/test/units/plugins/vars/data')
    data = get_vars_from_inventory_sources(loader, sources, entities, stage)
    assert data == {"data_dir_var": "dir_var"}

# Generated at 2022-06-11 19:16:37.303953
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert get_vars_from_path('get_vars_from_path','path','entities','stage')

# Generated at 2022-06-11 19:16:40.076701
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    entity = Host()
    data = get_vars_from_path(None, '', entity, None)
    assert isinstance(data, dict)

# Generated at 2022-06-11 19:16:40.640602
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert True

# Generated at 2022-06-11 19:16:51.508838
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    import ansible.plugins.vars.aws_ec2 as aws_ec2
    import ansible.plugins.vars.file as file_vars
    import ansible.plugins.vars.yaml as yaml_vars
    class mock_loader(object):
        class MockVarsPlugin():
            _load_name = 'aws_ec2'
            _original_path = 'original_path'

            def get_vars(self, loader, path, entities):
                return {'aws_ec2_key': 'aws_ec2_value'}

# Generated at 2022-06-11 19:16:53.324338
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert get_vars_from_path('loader', 'path', 'entities', 'stage') is not None

# Generated at 2022-06-11 19:17:04.489975
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    import ansible.plugins.vars.my_vars as my_vars
    data1 = get_vars_from_path(None, os.path.join(os.path.dirname(__file__), 'fixtures'), ['fake_host'], 'task')
    assert data1 == dict(test_var='test value', test_var2='test')
    data2 = get_vars_from_path(None, os.path.join(os.path.dirname(__file__), 'fixtures'), ['fake_host'], 'inventory')
    assert data2 == dict(test_var='test value', test_var2='test')

# Generated at 2022-06-11 19:17:12.959170
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    print("TEST: get_vars_from_path")
    class test_source(object):
        def __init__(self, path):
            self.path = path
    class test_entity(object):
        def __init__(self, name):
            self.name = name
    class test_loader(object):
        def __init__(self):
            pass
    class test_plugin(object):
        def __init__(self, name):
            self._load_name = name
            self._original_path = path
        def get_vars(self, loader, path, entities):
            return {self._load_name: {'entity1': self._load_name, 'entity2': self._load_name, 'entity3': self._load_name}}

# Generated at 2022-06-11 19:17:23.666216
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from unittest import mock

    vars_plugin_list = []
    plugin_mock = mock.Mock()
    plugin_mock.run = False
    plugin_mock.get_vars.side_effect = [{'a': 1, 'b': 2}, {'b': 3, 'c': 4}]
    vars_plugin_list.append(plugin_mock)
    plugin_mock.run = True
    plugin_mock.get_vars.side_effect = [{'a': 1, 'b': 2}, {'b': 3, 'c': 4}]
    vars_plugin_list.append(plugin_mock)
    plugin_mock.run = False
    data = get_vars_from_path(None, None, None, None, vars_plugin_list)

# Generated at 2022-06-11 19:17:33.289167
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['@test/integration/inventory_vars_plugin/hosts.yml'])
    all_hosts = inventory.get_hosts()
    group = inventory.get_group('example_group')

    data = get_vars_from_path(loader, os.path.dirname(os.path.dirname(__file__)), all_hosts, 'task')
    assert data == {'var_all': 'var_all', 'var_hosts': 'var_hosts'}


# Generated at 2022-06-11 19:17:57.163236
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # VarsLoader returns a dictionary of name:object pairs
    vars_plugins = vars_loader.all()
    first_var_plugin = vars_plugins.popitem()[1]
    # path is a string, entities is a list of strings
    path = 'some/directory'
    entities = ['some/filename', 'some/other/filename']
    stage = 'task'
    expected_plugin_vars = {}

    # Get plugin vars from first plugin in vars_loader
    expected_plugin_vars.update(get_plugin_vars(vars_loader, first_var_plugin, path, entities))

    # Get plugin vars from all plugins in vars_loader
    expected_plugin_vars.update(get_vars_from_path(vars_loader, path, entities, stage))

# Generated at 2022-06-11 19:18:00.352855
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    loader = None
    path = '/'
    entities = []
    stage = 'inventory'
    get_vars_from_path(loader, path, entities, stage)

# Generated at 2022-06-11 19:18:06.703093
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    playbook_dir = os.path.join(os.path.dirname(__file__), 'test_get_vars_from_path_playbook')
    data = get_vars_from_path(playbook_dir, 'host_vars', ['localhost'])
    assert data['foo'] == 'bar'

# Generated at 2022-06-11 19:18:13.786027
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    test_plugins_path = '../../test/units/vars/plugins/vars'
    plugins_path = os.path.join(os.path.dirname(__file__), test_plugins_path)
    fake_plugin_loader = PluginLoader(vars_loader,
                                      'ansible.plugins.vars',
                                      C.DEFAULT_INTERNAL_PLUGIN_PATH,
                                      'vars_plugins',
                                      'vars_plugins')
    fake_plugin_loader.add_directory(plugins_path)
    loader = DataLoader()
    # test get_vars_from_path with 3.x plugin
    test_plugin = next(iter(fake_plugin_loader.all()))
    path = '/'
    entities = []
    stage = 'task'
    data = get_v

# Generated at 2022-06-11 19:18:14.803564
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    assert get_plugin_vars(None, 'none', None, None) == {}

# Generated at 2022-06-11 19:18:25.492136
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    from ansible.inventory.host import Host

    class MockLoader:
        class MockVarsPlugin:
            def get_vars(self, loader, path, entities):
                return {'1': '1'}

        class MockVarsPlugin2:
            def get_host_vars(self, host):
                return {'2': '2'}

            def get_group_vars(self, group):
                return {'3': '3'}

        class MockVarsPlugin3:
            def get_vars(self, loader, path, entities):
                return {'4': '4', '5': '5'}

        class MockVarsPlugin4:
            def get_vars(self, loader, path, entities):
                return {'6': '6'}


# Generated at 2022-06-11 19:18:27.647624
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    assert get_plugin_vars(loader=None, plugin=None, path=None, entities=None) == {}

# Generated at 2022-06-11 19:18:28.102114
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert False

# Generated at 2022-06-11 19:18:35.817875
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    for plugin in vars_loader.all():
        if plugin._load_name == 'sample_vars_plugin':
            assert plugin.get_vars(None, None, None) == {}
        if plugin._load_name == 'oneline_vars_plugin':
            assert plugin.get_vars(None, None, None) == {}
        if plugin._load_name == 'multiline_vars_plugin':
            assert plugin.get_vars(None, None, None) == {}
        if plugin._load_name == 'vault_vars_plugin':
            assert plugin.get_vars(None, None, None) == {}

# Generated at 2022-06-11 19:18:43.268990
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.loader.vars_loader import VarsModule
    from ansible.module_utils._text import to_native
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    plugin = VarsModule('test_vars', '', '', 'vars_test')
    module_data_dir = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'module_data')
    collection_path = os.path.join(module_data_dir, 'test_collection')
    collection_dirs = loader.find_plugin_dirs(collection_path, False)

# Generated at 2022-06-11 19:19:24.094038
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Create vars loader
    vars_loader = vars_loader._create_loader(os.path.join(C.DEFAULT_MODULE_PATH, 'vars_plugins'))
    # Create path to vars
    path = b"/path/to/vars/dir/"
    # Create some fake entities
    fake_host = Host('fake_host')
    fake_group = Host('fake_group')
    entities = [fake_host, fake_group]
    # Test vars plugin list
    vars_plugin_list = [vars_loader.get('vars_file.py'), vars_loader.get('vars_dir.py')]

    # Function get_plugin_vars()
    # Test if plugin is exact plugin
    plugin = vars_plugin_list[0]
    vars = get

# Generated at 2022-06-11 19:19:36.158189
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # fake argv
    argv = ['ansible-playbook']

    # fake config
    config = {
        'DEFAULT_CALLABLE_WHITELIST': ['my_func_1', 'my_func_2'],
        'RUN_VARS_PLUGINS': 'all',
        'VARIABLE_PLUGINS_ENABLED': ['my_var_1', 'my_var_2', 'my_var_3'],
        'DEFAULT_HASH_BEHAVIOUR': 'replace'
    }
    C.initialize(config, argv)

    # mock_loader
    class my_loader:
        class my_plugin:
            def __init__(self, name):
                self._load_name = name
                self._original_path = 'fake path'

# Generated at 2022-06-11 19:19:43.120584
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    import ansible
    ansible_root = ansible.__path__[0]
    loader = None
    path = os.path.join(ansible_root, 'plugins/vars')
    entities = {'all': {'name': 'all'},
                'plugins': {'name': 'plugins'},
                'groups': {'name': 'groups'}}

    assert get_vars_from_path(loader, path, entities, 'inventory') == get_plugin_vars(loader, vars_loader.get('plugins'), path, entities)


# Generated at 2022-06-11 19:19:44.431812
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    pass

# Generated at 2022-06-11 19:19:55.189833
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.vars import vars_cache
    from ansible.inventory.data import InventoryData
    from ansible.playbook.play_context import PlayContext

    # Test basic chaining
    vars_plugin_list = vars_loader.all()
    assert len(vars_plugin_list) == 0

    vars_plugin_list.append(vars_cache.VarsCache())
    vars_plugin_list.append(vars_cache.VarsCache())

    loader = MockLoader()
    path = '.'
    test_data = {'a': 8}
    for plugin in vars_plugin_list:
        plugin.get_vars = lambda loader, path, entities: test_data

    data = get_vars_from_path(loader, path, [], 'inventory')

# Generated at 2022-06-11 19:19:56.651472
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # TODO: Replace pass with test.
    pass



# Generated at 2022-06-11 19:20:05.237812
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader

    class VarsPlugin1:
        def get_vars(self, loader, path, entities):
            return {'path': path, 'entities': entities}
        def get_group_vars(self, group):
            return {'group_vars': True}
        def get_host_vars(self, host):
            return {'host_vars': True}

    class VarsPlugin2:
        def get_vars(self, loader, path, entities):
            return {'path': path, 'entities': entities}
        def run(self, host):
            return {'a': 'b'}

    vars_no_get_vars = VarsPlugin1()
    vars_with_get_vars = VarsPlugin2()
   

# Generated at 2022-06-11 19:20:06.166519
# Unit test for function get_vars_from_path

# Generated at 2022-06-11 19:20:15.581258
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars

    path = os.path.dirname(__file__)
    inv_data = '''[test]
    localhost
    '''
    inv = InventoryManager(loader=None, sources=inv_data)
    loader = None
    # unit test for get_vars_from_path
    entities = list(inv.hosts.values())
    entities.extend(list(inv.groups.values()))
    # make a list of original vars
    original_vars = []
    for data in entities:
        original_vars.append(data.vars)

    # host vars
    os.environ['TEST_VARS_PLUGIN_HOST'] = 'foobar'
    host_

# Generated at 2022-06-11 19:20:22.174842
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader

    loader = vars_loader

    plugin = vars_loader.get('file')
    if plugin is None:
        return False

    path = "./data"
    host1 = Host()
    host1.name = 'test'
    host2 = Host()
    host2.name = 'test1'
    entities = [host1, host2]
    stage = 'test'

    plugin.get_vars = lambda *args: {'a': 1234}
    data = get_vars_from_path(loader, path, entities, stage)
    assert ('a' in data and data['a'] == 1234)

    plugin._original_path = './data'
    plugin.get_group_vars = lambda *args: {'b': 1234}


# Generated at 2022-06-11 19:22:25.904063
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.errors import AnsibleError
    actual = get_vars_from_path(vars_loader, "/etc/ansible/hosts", [], "inventory")
    expected = {'all': {},
                'ungrouped': {}}
    try:
        assert actual == expected
    except AssertionError:
        raise AssertionError()



# Generated at 2022-06-11 19:22:34.018540
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.config.manager import ConfigManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    config_mgr = ConfigManager(loader=loader)
    inv_mgr = InventoryManager(loader=loader, sources='localhost,')
    all_hosts = inv_mgr.get_hosts()
    host = next(all_hosts)
    assert host.vars == get_vars_from_inventory_sources(loader, inv_mgr.sources, [host], 'inventory')
    assert host.vars == get_vars_from_inventory_sources(loader, inv_mgr.sources, [host], 'task')

# Generated at 2022-06-11 19:22:43.339086
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    class TestPlugin:

        def get_vars(self, loader, path, entities):
            return {"data": path}

    plugin = TestPlugin()

    assert get_vars_from_path("loader", "path", "entities", "stage") == {}

    global vars_loader
    vars_loader = {
        plugin._load_name: plugin
    }

    assert get_vars_from_path("loader", "path", "entities", "stage") == {"data": "path"}

    global C
    C = type("C", (), {"VARIABLE_PLUGINS_ENABLED": []})

    assert get_vars_from_path("loader", "path", "entities", "stage") == {}


# Generated at 2022-06-11 19:22:45.737407
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert get_vars_from_path('loader', 'path', ['entities'], 'stage') == {'test': 'test'}, \
        'get_vars_from_path failed'

# Generated at 2022-06-11 19:22:50.771010
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    """The test is used to ensure that the get_vars_from_path function
    returns a dict of combined variables when vars plugins are passed
    correctly, or returns an empty dict when the vars plugins are not
    passed.

    The vars_plugin variable is set to None so that the function does
    not try to execute any of the vars plugins.
    """
    from ansible.plugins.loader import vars_loader
    from ansible.utils.collection_loader import AnsibleCollectionRef
    from ansible.utils.vars import combine_vars

    vars_plugin = None
    data = {}
    vars_plugin_list = list(vars_loader.all())


# Generated at 2022-06-11 19:22:56.616112
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager

    loader = None
    path = 'tests/vars/inventory_dir/'
    inventory_manager = InventoryManager(loader, sources=path)
    entities = [inventory_manager.get_group('group1')]
    stage = 'inventory'
    data = get_vars_from_path(loader, path, entities, stage)
    assert data['var_group1'] == 'group1'
    assert data['var_all'] == 'all'

# Generated at 2022-06-11 19:22:57.093987
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    pass

# Generated at 2022-06-11 19:23:03.387961
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    try:
        # use first element of ansible.cfg search path as basedir
        basedir = C.CONFIG.searchpath[0]
    except IndexError:
        # use current directory
        basedir = os.getcwd()
    # data to use as inventory sources
    sources = [os.path.join(basedir, 'inventory')]
    # this test is for the case when a 'hosts' file is absent
    assert get_vars_from_inventory_sources(None, sources, [], 'inventory') == dict()

# Generated at 2022-06-11 19:23:14.427767
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    vars_plugin_list = list(vars_loader.all())
    for plugin_name in C.VARIABLE_PLUGINS_ENABLED:
        if AnsibleCollectionRef.is_valid_fqcr(plugin_name):
            vars_plugin = vars_loader.get(plugin_name)
            if vars_plugin is None:
                # Error if there's no play directory or the name is wrong?
                continue
            if vars_plugin not in vars_plugin_list:
                vars_plugin_list.append(vars_plugin)

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='./test/hosts')


# Generated at 2022-06-11 19:23:17.076887
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    # unit test to test get_plugin_vars function
    pass