

# Generated at 2022-06-11 19:13:45.752996
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    pass

# Generated at 2022-06-11 19:13:53.037803
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch
    inventory = InventoryManager(loader=DataLoader(), sources=['localhost,'])
    # Mock import of plugin which is being tested
    with patch.dict('sys.modules', {'ansible_collections.notstdlib.moveitallout.plugins.module_utils.foo_utils': None}):
        from ansible_collections.notstdlib.moveitallout.plugins.module_utils.foo_utils import FooUtilsModule

        # Simulate plugin object
        plugin = FooUtilsModule()
        plugin.get_vars = lambda loader, path, entities: {'result': 'success'}

# Generated at 2022-06-11 19:14:02.403058
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    class _Loader(object):
        pass

    loader = _Loader()
    loader.get_basedir = None
    plugin = None

    path = '.'
    entities = ['a', 'b']
    stage = 'start'
    data = get_vars_from_path(loader, path, entities, stage)

    assert len(data) == 0

    # test get_vars
    plugin = None

    class _Plugin(object):
        def get_vars(self, loader, path, entities):
            return {'foo': 'bar'}

    plugin = _Plugin()
    data = get_plugin_vars(loader, plugin, path, entities)

    assert len(data) == 1
    assert data == {'foo': 'bar'}

# Generated at 2022-06-11 19:14:12.231245
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    plugin_list_before = list(vars_loader.all())
    plugin_name = "test_vars"
    plugin_class = type(plugin_name, (object,), {"get_vars": lambda *args, **kwargs: {"my": "test"}})
    vars_loader.add(plugin_name, plugin_class)
    try:
        assert get_vars_from_inventory_sources(None, [], [], None) == {}
        assert get_vars_from_inventory_sources(None, ["test_dir"], [], None) == {"my": "test"}
    finally:
        vars_loader.remove(plugin_name)
        vars_loader.all().extend(plugin_list_before)

# Generated at 2022-06-11 19:14:16.151914
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert get_vars_from_path({}, None, [], '') == {}

    assert get_vars_from_path({}, '/some/path', [], '') == {}



# Generated at 2022-06-11 19:14:19.344703
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    assert get_plugin_vars(object, object, object, object) is not None
    assert get_plugin_vars(object, object, None, None) is not None
    assert get_plugin_vars(None, None, None, None) is not None

# Generated at 2022-06-11 19:14:23.090522
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    assert get_vars_from_path(None, 'test/test_vars_plugin', None, 'inventory') == \
           {'key_0': 'value_0', 'key_1': 'value_1'}


# Generated at 2022-06-11 19:14:31.344563
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    from ansible.plugins.vars import TestVarsPlugin as test_plugin

    entity_list = [
        Host('localhost', port=22),
        Host('localhost2', port=22),
    ]

    plugin_list = [test_plugin()]
    data = get_vars_from_path(None, ".", entity_list, "task")
    assert data.get("test_key", "default_val") == "test_val"
    assert data.get("test_key2", "default_val") == "test_val"



# Generated at 2022-06-11 19:14:38.181805
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    # pylint: disable=too-many-branches
    class Plugin1:
        def __init__(self, name, path):
            self._load_name = name
            self._original_path = path

        def get_vars(self, loader, path, entities):
            return {'plugin': 'plugin1'}

        def get_host_vars(self, name):
            return {'host': 'host'}

        def get_group_vars(self, name):
            return {'group': 'group'}

    class Plugin2:
        def __init__(self, name, path):
            self._load_name = name
            self._original_path = path

        def get_vars(self, loader, path, entities):
            return {'plugin': 'plugin2'}


# Generated at 2022-06-11 19:14:47.242015
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Initialize loader with a directory to test with file based vars
    test_loader = vars_loader.get('file')
    test_loader.set_inventory_basedir('test/units/plugins/vars/vars_loader_test_dir')

    # Initialize some test entities
    host_test_1 = Host(name='test_1')
    host_test_2 = Host(name='test_2')
    group_test_1 = Host(name='test_1')
    group_test_2 = Host(name='test_2')

    # Test file based variables
    data = get_vars_from_path(test_loader, 'test/units/plugins/vars/vars_loader_test_dir', [host_test_1], 'inventory')

# Generated at 2022-06-11 19:15:02.459284
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.constants import ANSIBLE_TEST_DATA_ROOT

    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import vars_loader

    inventory = InventoryManager(loader=None, sources=['{0}/test_vars_loader_basic_inventory'.format(ANSIBLE_TEST_DATA_ROOT)])
    plugin = vars_loader.get('test_vars_plugin')
    assert plugin is not None

    # Test that get_plugin_vars runs without exceptions
    get_plugin_vars(inventory.loader, plugin, None, [])

# Generated at 2022-06-11 19:15:06.823522
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    class FakePlugin(object):
        def __init__(self, filename):
            self._filename = filename
            self._load_name = filename


# Generated at 2022-06-11 19:15:15.300330
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    class TestVarsModule:
        def __init__(self):
            self.host_vars = {}
            self.group_vars = {}

        def get_host_vars(self, host):
            return self.host_vars.get(host, {})

        def get_group_vars(self, group):
            return self.group_vars.get(group, {})

    class TestVarsDynamicInventory:
        def __init__(self):
            self.host_vars = {}
            self.group_vars = {}

        def run(self, host):
            return self.host_vars.get(host, {})


# Generated at 2022-06-11 19:15:21.420419
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    loader = None
    path = '/var/temp'
    entities = [{'name': 'group1'}, {'name': 'group2'}]
    stage = 'inventory'

    data_output = get_vars_from_path(loader, path, entities, stage)
    assert isinstance(data_output, dict)

# Generated at 2022-06-11 19:15:28.633808
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    # test class to fake a plugin
    class fake_vars_plugin(object):
        def __init__(self, plugin_name):
            self._load_name = plugin_name
        # returns different vars based on the inventory path
        def get_vars(self, loader, path, entities):
            if path == 'path1':
                return {self._load_name: 'vars from path1'}
            else:
                return {self._load_name: 'vars from other path'}
    # test class to fake a plugin
    class fake_host_vars_plugin(object):
        def __init__(self, plugin_name):
            self._load_name = plugin_name
        # returns different vars based on the name of the host

# Generated at 2022-06-11 19:15:37.855007
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    from ansible.plugins.loader import vars_loader

    class MockPlugin():
        def run(self, entities, data):
            return {'a': 1, 'b': 2, 'c': 3 }

    class MockLoader():
        def get(self, plugin_name):
            return MockPlugin()

    loader = MockLoader()
    plugin = vars_loader.get('mock_plugin')
    path = b'path'
    entities = []
    result = get_plugin_vars(loader, plugin, path, entities)
    assert result == {'a': 1, 'b': 2, 'c': 3, 'c_plugin': None }

# Generated at 2022-06-11 19:15:43.714241
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory import Inventory
    from ansible.inventory.manager import InventoryManager

    inventory = Inventory()
    inventory.add_host(Host(name="localhost", hostname="127.0.0.1"))
    inventory_manager = InventoryManager(loader=None, sources=[])
    inventory_manager.add_inventory(inventory)
    data = get_vars_from_path(inventory_manager, './', [inventory], stage='inventory')
    assert isinstance(data, dict)

# Generated at 2022-06-11 19:15:50.436583
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    class DummyPlugin():
        def get_vars(self, loader, path, entities):
            return {'hello': 'world'}

    dummy_plugin = DummyPlugin()
    assert({'hello': 'world'} == get_plugin_vars(None, dummy_plugin, None, None))

    class DummyPlugin2():
        def get_host_vars(self, name):
            return {'host_var': 'host_var_value'}

        def get_group_vars(self, name):
            return {'group_var': 'group_var_value'}

    entities = ['host_1', 'group_1', 'host_2', 'group_2']


# Generated at 2022-06-11 19:16:00.671769
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    display.verbosity = 0

# Generated at 2022-06-11 19:16:02.015008
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    pass


# Generated at 2022-06-11 19:16:23.989642
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader

    data = {}
    path = os.path.dirname(__file__)
    class Entity:
        name = "localhost"
    entities = [Entity()]
    data = combine_vars(data, get_vars_from_path(vars_loader, path, entities, 'task'))
    assert(data['hostvars']['localhost']['inventory_dir'] == path)
    assert(data['hostvars']['localhost']['inventory_file'] == os.path.basename(__file__))


# Generated at 2022-06-11 19:16:32.795578
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.module_utils.six import PY3

    # Init
    sources = [
        "hosts=hosts",
        "hosts=hosts_with_vars",
        "hosts=hosts_with_vars_dir",
        "hosts=hosts_with_vars_dir2",
        "hosts=hosts_with_vars_dir_2",
        "hosts=hosts_with_vars_dir_3",
    ]

    loader = DataLoader()

# Generated at 2022-06-11 19:16:39.235806
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import auto

    loader = 'loader'
    path = '/path/to/inventory'
    plugin = auto.VarsModule()
    plugin.get_vars = lambda loader, path, entities: {'vars': 'vars'}
    plugin.get_host_vars = lambda hostname: {}
    plugin.get_group_vars = lambda groupname: {}
    entities = ['something']

    assert get_plugin_vars(loader, plugin, path, entities) == {'vars': 'vars'}



# Generated at 2022-06-11 19:16:40.832481
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    assert(get_vars_from_path(None, None, [], 'task') is not None)



# Generated at 2022-06-11 19:16:51.603484
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.vars.vars import AnsibleVars
    from ansible.vars.vars import PreProcessingVars
    from ansible.vars.vars import CombineVars

    vars_manager = VariableManager()
    loader = vars_manager._loader

    assert get_plugin_vars(loader, HostVars, True, ['a', 'b']) == {'a': {}, 'b': {}}
    assert get_plugin_vars(loader, PreProcessingVars, True, ['a', 'b']) == {'a': {}, 'b': {}}

# Generated at 2022-06-11 19:16:57.980566
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    path = os.path.dirname(os.path.abspath(__file__))
    path = os.path.join(path, '..', '..', 'test_utils', 'vars_plugins', 'group_vars')
    host = Host('test_get_vars_from_path')
    data = get_vars_from_path(None, path, [host,], 'inventory')
    assert data['test_value'] == 'test_get_vars_from_path'

# Generated at 2022-06-11 19:17:08.946678
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    loader = {}
    path = '/test/test'
    host = Host("test")

    class TestPlugin:
        def get_vars(self, loader, path, entities):
            return {'get_vars': True, 'path': path}

        def get_group_vars(self, group):
            return {'get_group_vars': True, 'group': group}

        def get_host_vars(self, host):
            return {'get_host_vars': True, 'host': host}

    class TestPlugin2:
        def get_vars(self, loader, path, entities):
            return {'get_vars2': True, 'path': path}

        def run(self, *args, **kwargs):
            return


# Generated at 2022-06-11 19:17:12.489901
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    source = [ 'fake_inventory' ]
    entities = [ "test_host" ]

    data = get_vars_from_inventory_sources(None, source, entities, 'inventory')

# Generated at 2022-06-11 19:17:23.168242
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # One vars plugin is loaded, it returns a value and no errors are raised
    class MockLoader:
        pass

    class MockPlugin:
        def get_vars(self, loader, path, entities):
            assert loader == mock_loader
            assert path == 'test_path'
            assert entities == ['entity']
            return 'test_value'

    mock_loader = MockLoader()
    plugin = MockPlugin()
    vars_loader._all = {'MockPlugin': plugin}
    vars_loader.update_all_candidates()
    vars_loader.update_cache()

    result = get_vars_from_path(mock_loader, 'test_path', ['entity'], stage='test_stage')

    assert result == 'test_value'

    # No vars plugins are loaded, an empty dictionary is returned

# Generated at 2022-06-11 19:17:25.547970
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    loader = None
    plugin = {}
    path = None
    entities = []
    data = get_plugin_vars(loader, plugin, path, entities)
    assert data == {}

# Generated at 2022-06-11 19:17:57.163622
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader

# Generated at 2022-06-11 19:18:05.383576
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Mock vars loader and return a fake plugin
    class VarsLoaderMock:
        def get(self, name):
            class PluginWrapper:
                def get_vars(self, loader, path, entities):
                    return {
                        'test_get_vars_from_path': 'test_get_vars_from_path',
                    }
                def get_host_vars(self, entity_name):
                    return {
                        'test_get_vars_from_path': 'test_get_vars_from_path',
                    }
                def get_group_vars(self, entity_name):
                    return {
                        'test_get_vars_from_path': 'test_get_vars_from_path',
                    }
            return PluginWrapper()


# Generated at 2022-06-11 19:18:13.042164
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    loader = 'x'
    path = '/y'
    stage = 'z'
    entities = [1, 2]

    plugin_mock = 'test_plugin'

    def get_vars(plugin_mock, loader, path, entities):
        return {plugin_mock: {'test_key': 'test_value'}}

    plugin_mock.get_vars = get_vars

    vars = get_vars_from_path(loader, path, entities, stage)

    assert vars == {plugin_mock: {'test_key': 'test_value'}}

# Generated at 2022-06-11 19:18:14.019539
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    # TODO: Implement some tests
    assert 1 == 1


# Generated at 2022-06-11 19:18:16.035427
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    data = get_vars_from_path(None,'/home/ansible/ansible/inventory', 'test', 'start')
    assert data == {}

# Generated at 2022-06-11 19:18:26.692849
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    import tempfile
    fd, f = tempfile.mkstemp(prefix='ansible_test')
    os.close(fd)

# Generated at 2022-06-11 19:18:36.029580
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    '''
    Test get_vars_from_path with default sample plugins
    '''

    # run_vars_plugins default setting 'demand'
    C.VARIABLE_PLUGINS_ENABLED = ['include_vars']
    C.RUN_VARS_PLUGINS = 'demand'

    os.environ['ANSIBLE_INVENTORY_ENABLED'] = 'script'
    inventory = {}
    inventory['script'] = {}
    inventory['script']['plugin'] = "ansible.inventory.script"
    inventory['script']['direct'] = False
    inventory['script']['vars'] = {}
    inventory['script']['vars']['foo'] = [1, 2, 3]

# Generated at 2022-06-11 19:18:43.375695
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    class Mock_Loader(object):
        def __init__(self, result):
            self.result = result

    class Mock_Plugin(object):
        def __init__(self, name):
            self._load_name = name

        def get_vars(self, loader, path, entities):
            return loader.result

    fake_loader = Mock_Loader({"foo": "bar"})
    assert get_plugin_vars(fake_loader, Mock_Plugin("name"), "path", ["entities"]) == {"foo": "bar"}
    fake_loader.result = {"foo": "baz"}
    assert get_plugin_vars(fake_loader, Mock_Plugin("name"), "path", ["entities"]) == {"foo": "baz"}
    fake_loader.result = "result"
    assert get_plugin_v

# Generated at 2022-06-11 19:18:52.526260
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    from ansible.inventory.loader import InventoryLoader

    loader = InventoryLoader()
    plugin_path = './lib/ansible/plugins/vars/'

    # test for python vars plugins
    python_plugin_name_list = ['foo.py', 'bar.py']
    plugin_list = []
    for plugin_name in python_plugin_name_list:
        plugin_list.append(vars_loader.get(plugin_name))
    result = get_vars_from_path(loader, plugin_path, plugin_list, stage='inventory')
    assert len(result) == 2
    assert result['foo_key'] == 'foo_value'
    assert result['bar_key'] == 'bar_value'

    # test for module vars plugins
    module_plugin_name_list = ['test/test.py']

# Generated at 2022-06-11 19:19:01.390708
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.host import Host
    from ansible.utils.collection_loader import _get_collection_base_path
    from ansible.utils.collection_loader import _get_collection_name_from_path

    inventory_path = "/tmp/collections/ansible_namespace/custom_collection/tests/inventory/hosts"

    # Initialize plugin paths and the loader
    _get_collection_base_path()
    _get_collection_name_from_path(inventory_path)

    host_obj = Host('localhost')
    entities = [host_obj]

    path = "/tmp/collections/ansible_namespace/custom_collection/tests/inventory"
    stage = 'inventory'

    data = get_vars_from_path(None, path, entities, stage)

    assert data['custom_var']

# Generated at 2022-06-11 19:19:36.625764
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from collections import namedtuple

    Plugin = namedtuple('Plugin', ['_load_name', '_original_path', 'get_vars'])
    Host = namedtuple('Host', ['name'])
    Group = namedtuple('Group', ['name'])

    # Simple plugin
    plugin = Plugin(
        "_load_name",
        "path",
        lambda loader, path, entities: {
            "host": {
                "host1": {
                    "hostvar1": "host1-value"
                }
            },
            "group": {
                "group1": {
                    "groupvar1": "group1-value"
                }
            },
            "all": {
                "allvar1": "all-value"
            }
        })


# Generated at 2022-06-11 19:19:45.307141
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    import os
    import tempfile
    import shutil
    import textwrap
    import ansible
    from ansible.plugins import vars_loader

    # Create a fake vars plugin
    fake_vars_plugin_content = '''
    # This is a fake vars plugin
    from ansible.plugins.vars import BaseVarsPlugin

    class VarsModule(BaseVarsPlugin):

        def get_vars(self, loader, path, entities, cache=True):
            return { 'FAKE_KEY': 'FAKE_VALUE' }

    v = VarsModule()
    '''

    # Fake collection with fake vars plugin
    fake_collection = tempfile.mkdtemp()
    fake_collection_vars_dir = os.path.join(fake_collection, 'my_collection', 'vars')
    os

# Generated at 2022-06-11 19:19:50.109266
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.host import Host
    dummy_host = Host(name='dummy_host')
    data = get_vars_from_path(None, '/etc/ansible', [dummy_host], "inventory")
    assert(data == {})

# Generated at 2022-06-11 19:19:59.750430
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    module_utils_path = os.path.join(os.path.dirname(__file__), 'module_utils')
    path = 'a/b/c'
    this_host = Host(name="somehost")
    that_host = Host(name="someotherhost")
    my_group = Host(name='mygroup')
    plugin_name = "test_vars_plugin"
    test_plugin = vars_loader.get(plugin_name, class_only=True)
    test_plugin.get_vars = lambda x,y,z: {'test_value': 1}
    test_plugin.get_host_vars = lambda x: {'test_value': 10}
    test_plugin.get_group_vars = lambda x: {'test_value': 100}

# Generated at 2022-06-11 19:20:07.560340
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin
    host = Host('testhost')
    group = host.get_group('testgroup')
    loader = []
    path = ['/dir1', '/dir2', '/dir3']
    plugin = vars_plugin.VarsModule()
    plugin.get_vars = lambda x, y, z: {'vars': 1}
    entities = [host, group]
    assert get_plugin_vars(loader, plugin, path, entities) == {'vars': 1}
    plugin.get_host_vars = lambda x: {'host_vars': 1}
    plugin.get_group_vars = lambda x: {'group_vars': 1}

# Generated at 2022-06-11 19:20:16.972061
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.plugins.vars import base

    class DummyPlugin1(base.BaseVarsPlugin):
        def get_vars(self, *args, **kwargs):
            return "dummy1"

        def get_group_vars(self, *args, **kwargs):
            return "group_vars_dummy1"

        def get_host_vars(self, *args, **kwargs):
            return "host_vars_dummy1"

    class DummyPlugin2(base.BaseVarsPlugin):
        def get_vars(self, *args, **kwargs):
            return "dummy2"


# Generated at 2022-06-11 19:20:23.445784
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    def test_plugin(loader, path, entities):
        return {'test': 'ok'}

    vars_loader.add("test_plugin", test_plugin)
    data = get_vars_from_path(None, None, None, None)
    assert data == {'test': 'ok'}

    vars_loader.remove("test_plugin")
    data = get_vars_from_path(None, None, None, None)
    assert data == {}

# Generated at 2022-06-11 19:20:25.873810
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    data = get_vars_from_path(vars_loader, path="./", entities=[], stage="inventory")
    assert isinstance(data, dict)

# Generated at 2022-06-11 19:20:35.430453
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=["test/resources/inventory"])

    plugin_data = get_vars_from_path(loader, "./test/resources/inventory", [inventory.hosts["host1"]], C.RUN_VARS_PLUGINS)
    assert plugin_data == {"test_plugin_var": "plugin_var0"}

    meta_data = get_vars_from_path(loader, "./test/resources/inventory", [inventory.hosts["host1"]], "meta")
    assert meta_data == {"test_meta_var": "meta_var0"}


# Generated at 2022-06-11 19:20:44.353732
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.playbook.play import Play

    loader = None
    path = 'tmp/test/tt'
    entities = [Play.load(dict(), loader=loader, variable_manager=None, loader_node='localhost')]
    stage = 'inventory'
    data = get_vars_from_path(loader, path, entities, stage)
    assert data == {}
    path = 'tmp'
    entities = [Play.load(dict(), loader=loader, variable_manager=None, loader_node='localhost')]
    stage = 'inventory'
    data = get_vars_from_path(loader, path, entities, stage)
    assert 'test' in data
    assert data['test']['tt'] == {}


# Generated at 2022-06-11 19:21:42.016304
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    # make fake plugin
    class FakePlugin(object):
        def get_vars(self, *args, **kwargs):
            return {
                'var1': 'value1',
                'var2': 'value2'
            }

    fake_plugin = FakePlugin()
    data = get_plugin_vars(None, fake_plugin, None, [])

    assert 'var1' in data
    assert 'var2' in data
    assert data['var1'] == 'value1'
    assert data['var2'] == 'value2'

# Generated at 2022-06-11 19:21:48.144473
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    test_path = "/path/to/inventory"
    entities = [Host("host1"), Host("host2")]

    # vars plugin
    class Plugin:
        def get_vars(self, loader, path, entities):
            return {"test_path": path}
    loader = [Plugin()]

    # get_vars_from_path() should return vars plugin's vars
    data = get_vars_from_path(loader, test_path, entities, None)
    assert data["test_path"] == test_path

# Generated at 2022-06-11 19:21:58.403842
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    def assert_vars_from_path(path, expected):
        from ansible.plugins.loader import vars_loader
        from ansible.parsing.splitter import parse_kv

        vars_plugin_list = list(vars_loader.all())
        for plugin_name in C.VARIABLE_PLUGINS_ENABLED:
            if AnsibleCollectionRef.is_valid_fqcr(plugin_name):
                vars_plugin = vars_loader.get(plugin_name)
                if vars_plugin is None:
                    # Error if there's no play directory or the name is wrong?
                    continue
                if vars_plugin not in vars_plugin_list:
                    vars_plugin_list.append(vars_plugin)
        expected = parse_kv(expected)
        result

# Generated at 2022-06-11 19:22:08.140384
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.playbook.play_context import PlayContext
    pc = PlayContext()
    pc.variable_manager._extra_vars = {"test": "x"}
    vars_plugin_list = []
    for plugin_name in C.VARIABLE_PLUGINS_ENABLED:
        vars_plugin = vars_loader.get(plugin_name)
        if vars_plugin is None:
            # Error if there's no play directory or the name is wrong?
            continue
        vars_plugin_list.append(vars_plugin)

    for plugin in vars_plugin_list:
        result = get_vars_from_path(None, plugin, "test_path", [])
        assert isinstance(result, dict)



# Generated at 2022-06-11 19:22:19.763431
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.cli.inventory import InventoryCLI
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    data = {
        'plugin': 'test_vars'
    }

    inv = InventoryCLI(['localhost'])
    inv.parse_sources(('localhost,'), loader=DataLoader())
    var_manager = VariableManager(loader=DataLoader(), inventory=inv)

    assert ('test_vars' in get_vars_from_inventory_sources(loader=DataLoader(),
                                                           sources=('/usr/share/ansible/inventory'),
                                                           entities=inv.hosts,
                                                           stage='inventory'))


# Generated at 2022-06-11 19:22:21.343113
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    #TODO: Write unit test for new functionality
    pass

# Generated at 2022-06-11 19:22:29.824341
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.vars import vars_plugins
    from ansible.plugins import base

    loader = base.BaseVarsPlugin()
    entities = []
    plugin = vars_plugins.JsonFileVars()
    vars_from_path = get_vars_from_path(loader, ".", entities, "inventory")
    assert isinstance(vars_from_path, dict)
    assert plugin.get_vars(loader, ".", entities) == vars_from_path



# Generated at 2022-06-11 19:22:36.278238
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Mock the all() method of the vars_loader
    vars_loader_old_all = vars_loader.all
    vars_loader.all = lambda: vars_plugin_list
    loader = _get_loader()

    # run the get_vars_from_path function
    result = get_vars_from_path(loader, os.path.dirname(__file__), [], 'inventory')

    # set the old all() method back
    vars_loader.all = vars_loader_old_all

    # Check the result
    # There are two vars plugins in this directory. We return the combine vars of both plugins
    assert result == {"a": 1, "c": 9, "b": 2}



# Generated at 2022-06-11 19:22:46.278505
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Set mock plugins
    _b_vars_loader_plugins = ['a', 'b']
    _b_vars_loader_plugins_dict = {
        'a': {
            '_load_name': 'a',
            '_original_path': '/tmp/a.py',
            'get_vars': {
                'dirname': 'dirname',
                'entities': ['a', 'b'],
            },
        },
        'b': {
            '_load_name': 'b',
            '_original_path': '/tmp/b.py',
            'has_option': True,
            'get_option': 'start',
        },
    }

    vars_loader.clear_all_vars()
    vars_loader.add_directory(path='/tmp')
    vars

# Generated at 2022-06-11 19:22:56.886666
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Test package loading
    test_plugin = dict(
        _load_name="vars_test",
        run=lambda x, y, z: dict()
    )
    display.verbosity = 3
    assert get_plugin_vars(None, test_plugin, None, None) == dict()
    display.verbosity = 0

    # Test v2 plugin
    test_plugin = dict(
        _load_name="vars_test",
        get_vars=lambda x, y, z: dict(foo="bar")
    )
    assert get_plugin_vars(None, test_plugin, None, None) == dict(foo="bar")

    # Test old plugin