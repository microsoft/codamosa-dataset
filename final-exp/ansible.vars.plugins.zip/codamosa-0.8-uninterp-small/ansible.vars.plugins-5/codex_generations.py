

# Generated at 2022-06-25 14:16:13.653568
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    entities = []
    stage = 'inventory'
    path = ''
    loader = None

    try:
        get_vars_from_path(loader, path, entities, stage)
    except:
        pass

    try:
        get_vars_from_path(loader=loader, path=path, entities=entities, stage=stage)
    except:
        pass


# Generated at 2022-06-25 14:16:19.902625
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    loader = None
    path = "/etc/ansible/hosts"
    entities = Host(name="localhost")
    stage = "inventory"
    expected = {
        "ansible_connection": "local",
        "ansible_host": "127.0.0.1",
        "ansible_python_interpreter": "/usr/bin/python"
    }
    actual = get_vars_from_path(loader, path, entities, stage)
    assert expected == actual



# Generated at 2022-06-25 14:16:22.900956
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    arg_0 = Host()
    arg_0.name = "localhost"
    arg_1 = "inventory_dir"
    arg_2 = ["localhost", "test_host"]
    arg_3 = "task"
    test_case_0(arg_0, arg_1, arg_2, arg_3)

# Generated at 2022-06-25 14:16:29.125954
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    list0 = []

# Generated at 2022-06-25 14:16:37.696931
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    list_0 = []

# Generated at 2022-06-25 14:16:48.963033
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    list_0 = []

# Generated at 2022-06-25 14:16:52.473793
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    entities = []
    loader = ''
    path = ''
    stage = ''
    new = get_vars_from_path(loader, path, entities, stage)
    assert new == {}


# Generated at 2022-06-25 14:16:56.206425
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    loader = None
    path = ""
    entities = ["entities"]
    stage = ""
    var_0 = get_vars_from_path(loader, path, entities, stage)
    assert var_0 == {}



# Generated at 2022-06-25 14:16:59.894070
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    loader = None
    plugin = None
    path = "elapsed:"
    entities = [Host]

    result = get_plugin_vars(loader, plugin, path, entities)
    assert "description" in result
    assert "always" in result


# Generated at 2022-06-25 14:17:07.625969
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    file_0 = './pangaea/tasks/ansible/test/inventory/molecule/default/molecule.yml'
    path_0 = './pangaea/tasks/ansible/test/inventory/molecule/default/molecule.yml'
    list_0 = []
    str_0 = 'task'
    #path_1 = path_0
    path_1 = './pangaea/tasks/ansible/test/inventory/molecule/default/'
    #path_2 = path_1
    path_2 = './pangaea/tasks/ansible/test/inventory/molecule/default/'
    #path_3 = path_2

# Generated at 2022-06-25 14:17:14.720972
# Unit test for function get_plugin_vars

# Generated at 2022-06-25 14:17:15.603444
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    var_0 = []



# Generated at 2022-06-25 14:17:26.698444
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    # Test when sources is None
    sources = None
    entities = None
    stage = None
    assert get_vars_from_inventory_sources(sources, entities, stage) is None

    # Test when sources as a non list, not a directory, and os.path.exists is False
    sources = "hello"
    entities = "world"
    stage = "vars"
    assert get_vars_from_inventory_sources(sources, entities, stage) == {}

    # Test when sources as an None, not a directory, and os.path.exists is False
    sources = None
    entities = None
    stage = None
    assert get_vars_from_inventory_sources(sources, entities, stage) is None

    # Test when sources as a list, not a directory, and os.path.exists

# Generated at 2022-06-25 14:17:28.315938
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    try:
        var_0 = get_plugin_vars(loader, plugin, path, entities)
    except Exception as e:
        traceback.print_exc()
        print(e)


# Generated at 2022-06-25 14:17:28.889821
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    var_0 = []


# Generated at 2022-06-25 14:17:31.699313
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    vars_loader.add_directory(os.path.join(C.DEFAULT_MODULE_PATH, 'vars_plugin'))
    vars_loader.all()
    loader = None
    path = ["/home/kirito/myansible/bk/.test/test_plugins/vars_plugin/vars/demo.yml"]
    entities = []
    stage = 'inventory'
    get_vars_from_path(loader, path, entities, stage)


# Generated at 2022-06-25 14:17:40.809721
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    var_a = []
    var_b = []
    var_c = []

    src_path = "./config.json"
    dst_path = "./config.json.bak"
    data = {
        "test": "hello world"
    }
    data_from_path = {}
    data_from_path = combine_vars(data_from_path, get_vars_from_path(None, src_path, var_a, var_b))    # Get data from path
    assert data_from_path == data


# Generated at 2022-06-25 14:17:42.150836
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert get_vars_from_path(var_0) == var_0

# Generated at 2022-06-25 14:17:43.408490
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Test cases for sub routine get_plugin_vars
    pass


# Generated at 2022-06-25 14:17:51.918114
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    var_9 = None
    var_10 = None
    var_11 = None
    var_12 = None
    var_13 = None
    var_14 = None
    var_15 = None
    var_16 = None
    var_17 = None
    var_18 = None
    var_19 = None
    var_20 = None
    var_21 = None
    var_22 = None
    var_23 = None
    var_24 = None
    var_25 = None
    var_26 = None
    var_27 = None
    var_

# Generated at 2022-06-25 14:18:07.706718
# Unit test for function get_vars_from_path

# Generated at 2022-06-25 14:18:14.934474
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    list_0 = []
    str_0 = "GRAz.K|>Q.1=fh5C5DHt"
    str_0 = "\n{0}\n{1}\n\n{2}\n{3}\n\n{4}\n\n{5}\n{6}\n\n{7}\n\n{8}\n{9}\n\n{10}\n\n{11}\n{12}\n\n{13}\n".format(str_0, str_0, str_0, str_0, str_0, str_0, str_0, str_0, str_0, str_0, str_0, str_0, str_0, str_0)
    str_1 = "z2\t>5J-=fDhBC5GtK|>Q."

# Generated at 2022-06-25 14:18:25.622697
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    list_0 = []

# Generated at 2022-06-25 14:18:34.700153
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    list_0 = []

# Generated at 2022-06-25 14:18:42.741704
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    list_0 = []

# Generated at 2022-06-25 14:18:47.504140
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    loader = MockModule()
    path = "ansible/test/data/vars_files/test_multi_group_vars/test.yml"
    entities = ['test_group']
    stage = 'inventory'
    var_2 = get_vars_from_path(loader, path, entities, stage)



# Generated at 2022-06-25 14:18:56.341248
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    obj = [{'value': 1}, {'value': 2}, {'value': 3}, {'value': 4}]
    field = 'value'
    glob = False
    regexp = '.*'
    match_all = False
    match_only = False
    all_matching = False
    no_matching = False
    extract = False
    replace = False
    value = 0
    result = get_plugin_vars(obj, field, glob, regexp, match_all, match_only, all_matching, no_matching, extract, replace, value)
    assert -1 != 1


# Generated at 2022-06-25 14:19:01.929416
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible_collections.ansible.netcommon.plugins.action.net_command import ActionModule

    loader = ActionModule.set_loader(None)
    vars = get_vars_from_path(loader, './test/unit/vars_plugins/vars', [], 'inventory')
    assert vars == {'a': 'b', 'c': 'd'}


# Generated at 2022-06-25 14:19:08.154052
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    list_0 = []

# Generated at 2022-06-25 14:19:17.694121
# Unit test for function get_vars_from_path

# Generated at 2022-06-25 14:19:34.215689
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    print("[+] Test get_plugin_vars")
    test_case_0()


# Generated at 2022-06-25 14:19:34.847044
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert True

# Generated at 2022-06-25 14:19:36.750753
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    try:
        test_case_0()
    except AnsibleError as exc:
        display.display(exc)

# Generated at 2022-06-25 14:19:46.682749
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    class A:
        def __init__(self):
            self._load_name = None
            self._original_path = None

        def get_vars(self, *args):
            return {'1':2}

    class B:
        def __init__(self):
            self._load_name = None
            self._original_path = None

        def get_vars(self, *args):
            raise Exception('Test case for exception handling')

    class C:
        def __init__(self):
            self._load_name = None
            self._original_path = None

        def run(self, *args):
            raise Exception('Test case for exception handling')

    # Test case 1
    get_plugin_vars(None, A(), None, None)

    # Test case 2

# Generated at 2022-06-25 14:19:50.615409
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    str_0 = 'inventory'
    str_1 = 'task'
    str_2 = 'invenIory'

    # Passed
    var_0 = get_vars_from_inventory_sources(str_0, str_1, str_2, str_2)
    assert var_0 == {}

    # Passed
    var_1 = get_vars_from_inventory_sources(str_0, str_0, str_2, str_2)
    assert var_1 == {}

    # Passed
    var_2 = get_vars_from_inventory_sources(str_0, str_2, str_2, str_2)
    assert var_2 == {}

    # Passed

# Generated at 2022-06-25 14:19:57.299625
# Unit test for function get_vars_from_path

# Generated at 2022-06-25 14:20:00.798601
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    str_0 = 'invenIory'
    vars_plugin_list = list(vars_loader.all())
    var_0 = get_plugin_vars(str_0, vars_plugin_list, str_0, str_0)
    assert (var_0 == ())



# Generated at 2022-06-25 14:20:02.312011
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
	assert get_plugin_vars(str, str, str, str) == None # check function return value


# Generated at 2022-06-25 14:20:03.556971
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert get_vars_from_path(str(), str(), str(), str()) == dict()

# Generated at 2022-06-25 14:20:06.532089
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    loader = None
    path = 'foo'
    entities = 'bar'
    stage = 'all'
    var_0 = get_vars_from_path(loader, path, entities, stage)
    assert var_0 == {}


# Generated at 2022-06-25 14:20:55.077686
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Define variables for get_vars_from_path
    loader = 'invenIory'
    path = 'invenIory'
    entities = 'invenIory'
    stage = 'invenIory'

    # Call the function
    result = get_vars_from_path(loader, path, entities, stage)

    # Check the result
    # assert result is False, "Function get_vars_from_path did not return the correct result"


# Generated at 2022-06-25 14:20:58.870646
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    try:
        test_case_0()
    except Exception as e:
        display.display("Test case 0: failed")
        display.display("Exception info: %s" % e)

if __name__ == '__main__':
    test_get_vars_from_path()

# Generated at 2022-06-25 14:21:04.269053
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    mock_loader = 'mock_loader'
    mock_path = 'mock_path'
    mock_entities = 'mock_entities'
    mock_stage = 'mock_stage'
    var_0 = get_vars_from_path(mock_loader, mock_path, mock_entities, mock_stage)
    assert var_0 == {}


# Generated at 2022-06-25 14:21:08.230060
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    loader_0 = 'invenIory'
    path_0 = 'invenIory'
    path_1 = 'invenIory'
    inventory_1 = 'invenIory'
    assert get_vars_from_path(loader_0, path_0, path_1, inventory_1) is None


# Generated at 2022-06-25 14:21:10.809987
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    try:
        assert 'data' in get_vars_from_path('loader', 'path', 'entities', 'stage')
        assert test_case_0() == None
    except Exception:
        assert False


# Generated at 2022-06-25 14:21:14.964895
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Local variables
    var_0 = 'invenIory'
    var_1 = get_vars_from_path(var_0, var_0, var_0, var_0)
    return var_1



# Generated at 2022-06-25 14:21:17.849897
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    var_1 = get_vars_from_path(str, str, str, str)
    assert isinstance(var_1, dict)


# Generated at 2022-06-25 14:21:21.118493
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    str_0 = 'invenIory'
    var_0 = get_vars_from_path(str_0, str_0, str_0, str_0)


# Generated at 2022-06-25 14:21:24.560881
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    print("Start test_get_vars_from_path")

    test_case_0()

    print("End test_get_vars_from_path")
    print("")



# Generated at 2022-06-25 14:21:29.458970
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    str_0 = 'invenIory'
    str_1 = 'invenIory'
    str_2 = 'invenIory'
    str_3 = 'invenIory'
    get_plugin_vars(str_0, str_1, str_2, str_3)


# Generated at 2022-06-25 14:22:02.731967
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    str_0 = 'invenIory'
    var_0 = get_vars_from_inventory_sources(str_0, str_0, str_0, str_0)
    str_1 = 'invenIory'
    var_1 = get_vars_from_inventory_sources(str_0, str_1, str_1, str_0)
    str_2 = 'invenIory'
    var_2 = get_vars_from_inventory_sources(str_0, str_2, str_2, str_0)
    str_3 = 'invenIory'
    var_3 = get_vars_from_inventory_sources(str_0, str_3, str_3, str_0)

# Generated at 2022-06-25 14:22:07.834799
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'invenIory'
    var_0 = get_vars_from_path(str_0, str_0, str_0, str_0)
    assert str_0 == 'invenIory'
    assert str_0 == 'invenIory'
    assert str_0 == 'invenIory'
    assert str_0 == 'invenIory'
    assert var_0 == {}


# Generated at 2022-06-25 14:22:11.164682
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    print("# Unit test for function get_vars_from_path.")
    test_case_0()

# Generated at 2022-06-25 14:22:11.755459
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert True



# Generated at 2022-06-25 14:22:20.574844
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'invenIory'
    str_1 = 'iamnotadirectory'
    var_0 = get_vars_from_path(str_0, str_0, str_0, str_0)
    var_1 = get_vars_from_path(str_0, str_0, str_1, str_0)
    var_2 = get_vars_from_path(str_0, str_1, str_0, str_0)
    var_3 = get_vars_from_path(str_0, str_1, str_1, str_0)
    var_4 = get_vars_from_path(str_0, str_0, str_0, str_1)

# Generated at 2022-06-25 14:22:23.384114
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'invenIory'
    var_0 = get_vars_from_path(str_0, str_0, str_0, str_0)
    assert var_0 == {}



# Generated at 2022-06-25 14:22:29.434704
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    print('FUNCTION: get_plugin_vars')
    try:
        str_0 = 'invenIory'
        str_1 = 'entities'
        var_0 = get_plugin_vars(str_0, str_0, str_0, str_1)
    except Exception as error:
        print('Exception caught in function ' + 'test_get_plugin_vars' + ': ' + str(error))


# Generated at 2022-06-25 14:22:31.707035
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert get_vars_from_path(str, str, str, str) == {}


# Generated at 2022-06-25 14:22:34.197925
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert get_vars_from_path('loader', 'path', 'entities', 'stage') == {}

# Generated at 2022-06-25 14:22:36.575175
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    my_var = get_vars_from_path("", "", "", "")
    assert isinstance(my_var, (set, dict, list))



# Generated at 2022-06-25 14:23:13.512911
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'invenIory'
    var_0 = get_vars_from_path(str_0, str_0, str_0, str_0)
    assert var_0 == {}, "assertions failed"


# Generated at 2022-06-25 14:23:15.958120
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'invenIory'
    var_0 = get_vars_from_path(str_0, str_0, str_0, str_0)
    # assert that var_0 contains no entities

# Generated at 2022-06-25 14:23:16.787116
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert False


# Generated at 2022-06-25 14:23:24.653766
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    host_0_0 = Host('host_0.0')
    host_0_1 = Host('host_0.1')
    host_0_2 = Host('host_0.2')
    host_0_3 = Host('host_0.3')
    host_0_4 = Host('host_0.4')
    group_0_1 = Host('group_0.1')
    group_0_2 = Host('group_0.2')
    group_0_3 = Host('group_0.3')
    group_0_4 = Host('group_0.4')
    entities_0_0 = [host_0_0, host_0_1, host_0_2, host_0_3, host_0_4]

# Generated at 2022-06-25 14:23:28.771341
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    str_0 = 'invenIory'
    var_0 = get_vars_from_inventory_sources((str_0), (str_0), (str_0), (str_0))


# Generated at 2022-06-25 14:23:34.188890
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'invenIory'
    var_0 = get_vars_from_path(str_0, str_0, str_0, str_0)
    assert var_0 == {}, 'Assertion failed for call get_vars_from_path(str_0, str_0, str_0, str_0)'



# Generated at 2022-06-25 14:23:37.617051
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Make sure that exceptions raised in the tested code block are re-raised
    with pytest.raises(Exception):
        # Use a known good path and a known good plugin
        good_path = str(Path(__file__).absolute().parent.parent.parent)
        test_case_0()

# Generated at 2022-06-25 14:23:40.828359
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    try:
        assert isinstance(get_plugin_vars(str, str, str, str), dict)
        print("test get_plugin_vars Success")
    except AssertionError as e:
        print("test get_plugin_vars Failed")


# Generated at 2022-06-25 14:23:48.451993
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    # For now test only one plugin by calling get_vars method
    vars_plugin = vars_loader.get('host_group_vars')
    var_0 = get_vars_from_path(vars_plugin, 'src/ansible/plugins/vars/host_group_vars', 'src/ansible/plugins/vars/host_group_vars', 'src/ansible/plugins/vars/host_group_vars')

# Generated at 2022-06-25 14:23:49.642661
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    print("Testcase 1")
    test_case_0()



# Generated at 2022-06-25 14:24:19.897095
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Path can be a directory or a file
    parent_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
    var_0 = get_vars_from_path(None, parent_dir, None, 'task')
    var_1 = get_vars_from_path(None, __file__, None, 'task')
    assert var_0 is not None and var_1 is not None

# Generated at 2022-06-25 14:24:23.755751
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    try:
        data_0 = get_vars_from_path([], '', [], '')
        print(data_0)

    except AnsibleError as e:
        print(e)
        raise e


# Generated at 2022-06-25 14:24:24.633278
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    test_case_0()


# Generated at 2022-06-25 14:24:27.952580
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    src_from_path = 'path'
    var_from_path = get_vars_from_path(src_from_path, src_from_path, src_from_path, src_from_path)
    assert len(var_from_path) > 0


# Generated at 2022-06-25 14:24:29.353181
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    ex = Exception('')
    try:
        test_case_0()
    except:
        print(ex)
        pass


# Generated at 2022-06-25 14:24:38.324298
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    str_1 = 'inventory'
    str_2 = 'task'
    str_3 = 'inventory'
    str_4 = 'task'
    str_5 = 'inventory'
    str_6 = 'task'
    str_7 = 'inventory'
    str_8 = 'task'
    str_9 = 'inventory'
    str_10 = 'inventory'

    var_1 = get_vars_from_inventory_sources(str_1, str_2, str_3, str_4)
    var_2 = get_vars_from_inventory_sources(str_1, str_3, str_3, str_4)
    var_3 = get_vars_from_inventory_sources(str_1, str_3, str_3, str_5)
    var_4 = get_

# Generated at 2022-06-25 14:24:48.254881
# Unit test for function get_vars_from_path

# Generated at 2022-06-25 14:24:51.926057
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    
    data = {}
    path = 'some\path'
    entities = ['inventory', 'vars']
    stage = 'inventory'
    res = get_vars_from_path(data, path, entities, stage)

    assert res is not None, 'Expected value: not None'


# Generated at 2022-06-25 14:24:54.675446
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # test with bad path
    str_0 = 'invenIory'
    var_0 = get_vars_from_path(str_0, str_0, str_0, str_0)
    assert isinstance(var_0, dict)
    assert var_0 == {}

# Generated at 2022-06-25 14:24:57.937907
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    loader = 'loader'
    path = 'path'
    entities = 'entities'
    stage = 'stage'
    var_0 = get_vars_from_path(loader, path, entities, stage)
    assert type(var_0) == dict


# Generated at 2022-06-25 14:25:31.614667
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    str_0 = 'invenIory'
    from ansible.plugins.vars import include_vars
    plugin = include_vars.IncludeVars()
    vars_loader.add(plugin, 'include_vars')
    var_1 = get_plugin_vars(str_0, plugin, str_0, str_0)
    var_2 = get_vars_from_path(str_0, str_0, str_0, str_0)

# Generated at 2022-06-25 14:25:38.116407
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    loader1 = vars_loader.__name__
    try:
        plugin_file = os.path.basename(vars_loader.__file__)
        plugin = vars_loader.get(plugin_file)
        path1 = './'
        entities1 = vars_loader.__name__
        var_1 = get_plugin_vars(loader1, plugin, path1, entities1)
    except Exception as err:
        print('Error: test_get_plugin_vars() failed: ' + str(err))
        return False
    else:
        return True


if __name__ == '__main__':
    print('Test vars_loader()')
    test_vars_loader()
    print('Test get_vars_from_inventory_sources()')
    test_get_vars_