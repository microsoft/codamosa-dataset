

# Generated at 2022-06-25 14:16:00.531053
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    set_0 = None
    list_0 = [None, True, 'H_', 1, 0, 0, None, True, 'H_', {'Rbglm': 0}, True, 'H_', 1, 1, 0, 0]
    str_0 = 'Ck-RSu{=SEMw@V.j<x'
    dict_0 = {'D5k7&}J': {'Md#o': -45}, '1Ql}Nbx': -34, 'Jn0a': {'Jn0a': {'jy1(v': 81, 'x1F(': list_0, 'jy1(v': 'H_'}}}
    list_1 = [True, True, 'H_', 1, 0, 0, None, True, 'H_']
    dict_1

# Generated at 2022-06-25 14:16:04.417151
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    file_0 = '>#-L<_y6]W~"U(R6h"T/T7P)'
    tuple_0 = (file_0, file_0, file_0)
    var_0 = get_vars_from_path(tuple_0, file_0, tuple_0, file_0)



# Generated at 2022-06-25 14:16:05.216395
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    pass


# Generated at 2022-06-25 14:16:11.801147
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    var_0 = None
    var_1 = None
    set_0 = None
    str_0 = 'b8'
    str_1 = 't3'
    int_0 = 2
    int_1 = -12
    boolean_1 = False
    var_2 = get_plugin_vars(var_0, var_0, str_0, str_1)
    var_3 = get_plugin_vars(int_0, var_1, set_0, int_0)
    var_4 = get_plugin_vars(str_0, int_1, str_1, boolean_1)
    var_5 = get_plugin_vars(int_1, int_1, set_0, str_1)

# Generated at 2022-06-25 14:16:17.262145
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    set_0 = None
    str_0 = '$d4{*>J'
    dict_0 = {set_0: set_0, str_0: str_0, str_0: set_0, set_0: set_0}
    var_0 = get_vars_from_path(set_0, str_0, str_0, dict_0)


# Generated at 2022-06-25 14:16:18.710982
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    with pytest.raises(Exception):
        get_vars_from_inventory_sources()

# Generated at 2022-06-25 14:16:22.069535
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    input_0 = None
    input_1 = 'a'
    input_2 = {input_0: input_1}
    input_3 = {}
    test_output = get_plugin_vars(input_0, input_1, input_2, input_3)
    assert test_output == {}


# Generated at 2022-06-25 14:16:22.558787
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert True

# Generated at 2022-06-25 14:16:28.659275
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    host = Host('host')
    host.vars = dict(var1='val1', var2='val2')
    group = Host('group')
    group.vars = dict(var1='val1', var2='val2')
    entities = [host, group]

    for stage in ('inventory', 'task'):
        data = get_vars_from_path(None, 'path', entities, stage)
        assert data['meta']['host']['var1'] == 'val1'
        assert data['meta']['host']['var2'] == 'val2'
        assert data['meta']['group']['var1'] == 'val1'
        assert data['meta']['group']['var2'] == 'val2'

# Generated at 2022-06-25 14:16:37.497010
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    loader_0 = None
    plugin_0 = ':p*^0)Z,}]^L'
    path_0 = 'I<A+pz"H_sOi,~gi'
    entities_0 = 'AiL-3[Kw\x7f\x7f|!0>'
    var_0 = get_plugin_vars(loader_0, plugin_0, path_0, entities_0)

# Generated at 2022-06-25 14:16:45.333660
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'a'
    str_1 = 'b'
    str_2 = 'c'
    str_3 = 'd'
    data = get_vars_from_path(str_0, str_1, str_2, str_3)
    assert data == {}


# Generated at 2022-06-25 14:16:50.485039
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'x '

    get_vars_from_path(str_0, str_0, str_0, str_0)
    var_0 = get_vars_from_path(str_0, str_0, str_0, str_0)



# Generated at 2022-06-25 14:16:55.250983
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_1 = 'a'
    str_2 = 'b'
    str_3 = 'c'
    str_4 = 'd'
    var_0 = get_vars_from_path(str_1, str_2, str_3, str_4)


# Generated at 2022-06-25 14:17:04.344354
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'inventory source'
    str_1 = 'a/path/'
    str_2 = 'stage'
    str_3 = 'a'
    str_4 = 'a'
    str_5 = 'a'
    str_6 = 'a'
    var_0 = get_vars_from_path(str_1, str_2, str_3, str_4)
    var_1 = get_plugin_vars(str_5, str_6, str_3, str_4)
    str_7 = 'a'
    var_2 = get_plugin_vars(str_5, str_6, str_7, str_4)
    str_8 = 'a'

# Generated at 2022-06-25 14:17:10.466482
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'a'
    vars_plugin_list_0 = list(vars_loader.all())
    for plugin_name_0 in C.VARIABLE_PLUGINS_ENABLED:
        if AnsibleCollectionRef.is_valid_fqcr(plugin_name_0):
            vars_plugin_0 = vars_loader.get(plugin_name_0)
            if vars_plugin_0:
                if vars_plugin_0 not in vars_plugin_list_0:
                    vars_plugin_list_0.append(vars_plugin_0)

# Generated at 2022-06-25 14:17:13.535109
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    str_0 = 'a'
    var_0 = get_plugin_vars(str_0, str_0, str_0, str_0)


# Generated at 2022-06-25 14:17:24.657813
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Load data from file
    str_data_0 = ('''
    ''')
    # Load data from file
    str_data_1 = ('''
    ''')
    # Load data from file
    str_data_2 = ('''
    ''')
    # Load data from file
    str_data_3 = ('''
    ''')
    str_data_4 = ('''
    ''')
    # Load data from file
    str_data_5 = ('''
    ''')
    str_data_6 = ('''
    ''')
    # Load data from file
    str_data_7 = ('''
    ''')
    str_data_8 = ('''
    ''')
    # Load data from file
    str_data_9

# Generated at 2022-06-25 14:17:32.683277
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'a'
    str_1 = 'b'
    str_2 = 'c'
    str_3 = 'd'
    str_4 = 'e'
    str_5 = 'f'
    str_6 = 'g'
    str_7 = 'h'
    str_8 = 'i'
    str_9 = 'j'
    str_10 = 'k'
    str_11 = 'l'
    str_12 = 'm'
    str_13 = 'n'
    str_14 = 'o'
    str_15 = 'p'
    str_16 = 'q'
    str_17 = 'r'
    str_18 = 's'
    str_19 = 't'

    vars_plugin_list = list(vars_loader.all())
   

# Generated at 2022-06-25 14:17:33.872494
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    assert False


# Generated at 2022-06-25 14:17:45.083229
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'a'
    str_1 = 'b'
    str_2 = 'c'
    str_3 = 'd'
    dict_0 = dict({})
    dict_1 = dict({'1': 1})
    dict_2 = dict({'2': 2})
    dict_3 = dict({'3': 3})
    dict_4 = dict({'4': 4})
    dict_0 = combine_vars(dict_0, dict_1)
    dict_0 = combine_vars(dict_0, dict_2)
    dict_0 = combine_vars(dict_0, dict_3)
    dict_0 = combine_vars(dict_0, dict_4)
    dict_5 = dict({})
    dict_6 = dict({'1': 1})
    dict_7

# Generated at 2022-06-25 14:17:55.980250
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    """
    AnsibleTests: Test for get_vars_from_inventory_sources.

    Test for get_vars_from_inventory_sources
    """
    path = '/Users/wuzhijin/fork/ansible/lib/ansible/plugins/vars/'
    sources = ['/Users/wuzhijin/fork/ansible/lib/ansible/vars/infoblox.yml']
    entities = Host(name='XXXX')
    result = get_vars_from_inventory_sources(path, sources, entities, 'task')
    #assert result == {'url': 'https://example.com/api/v1.0/', 'username': 'abc', 'password': 'abc'}

# Generated at 2022-06-25 14:17:58.372121
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert (get_vars_from_path(None, None, None, None) is not None)


# Generated at 2022-06-25 14:18:07.449285
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    try:
        obj_0 = AnsibleCollectionRef.get_collection_loader_from_namespace('fqcr', 'collection_loader')
        obj_1 = vars_loader.get('get_vars_from_path')
        int_0 = len(vars_loader.all())
        str_0 = 'mock'
        str_1 = 'mock'
        str_2 = 'mock'
        assert(get_vars_from_path(obj_0, str_0, str_1, str_2) == {})
    except AssertionError:
        display.error("AssertionError: ")



# Generated at 2022-06-25 14:18:09.498609
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    str_0 = 'abc'
    str_1 = 'abc'
    str_2 = 'abc'
    str_3 = 'abc'
    var_0 = get_vars_from_inventory_sources(str_0, str_1, str_2, str_3)

# Generated at 2022-06-25 14:18:10.866476
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    assert get_plugin_vars('loader', 'plugin', 'path', 'entities') == (
        None
    )



# Generated at 2022-06-25 14:18:13.804203
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Test the path with a valid plugin name
    var_0 = get_vars_from_path('a', 'a', 'a', 'a')
    assert var_0 == {}, "Failed to get var_0"

# Generated at 2022-06-25 14:18:15.117030
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    var_0 = get_vars_from_path(str_0, str_0, str_0, str_0)


# Generated at 2022-06-25 14:18:17.718529
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    assert get_plugin_vars(str_0, str_0, str_0, str_0) == var_0


# Generated at 2022-06-25 14:18:22.141849
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    print("Unit test for function get_vars_from_path")
    str_0 = 'a'
    str_1 = 'a'
    str_2 = 'a'
    get_plugin_vars(str_0, str_1, str_2, str_2)


# Generated at 2022-06-25 14:18:28.079925
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    vars_plugin_list = list(vars_loader.all())
    plugin_name = vars_plugin_list[0]._load_name
    C.VARIABLE_PLUGINS_ENABLED = [plugin_name]
    entities = ['fake_entities']
    path = 'fake_path'
    loader = 'fake_loader'
    stage = 'inventory'
    result = get_vars_from_path(loader, path, entities, stage)
    assert(result)


# Generated at 2022-06-25 14:18:38.708312
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert (get_vars_from_path('test', 'test', 'test', 'test') is not None)


# Generated at 2022-06-25 14:18:42.043289
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'a'
    var_1 = get_vars_from_path(str_0, str_0, str_0, str_0)
    return var_1



# Generated at 2022-06-25 14:18:45.585921
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    loader = 'loader'
    path = './hosts'
    entities = 'hosts'
    stage = 'inventory'
    assert get_vars_from_path(loader, path, entities, stage) == {}, 'The result is not as expected'


# Generated at 2022-06-25 14:18:55.536266
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # TODO
    str_0 = '*'
    str_1 = 'a'
    str_2 = 'b'
    class_0 = vars_loader.all()
    # TODO
    # assert class_0 == data
    class_1 = list()
    class_1.append(str_2)
    class_2 = C.VARIABLE_PLUGINS_ENABLED
    # TODO
    # assert class_2 == data
    class_3 = get_plugin_vars(str_0, str_1, str_0, class_1)
    # TODO
    # assert class_3 == data


# Generated at 2022-06-25 14:18:56.567660
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert True

# Generated at 2022-06-25 14:19:04.379158
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    int_0 = 0
    str_0 = 'a'
    str_1 = 'test'
    str_2 = 'a'
    str_3 = 'test'
    str_4 = 'a'
    str_5 = 'test'
    str_6 = 'a'
    str_7 = 'test'
    int_1 = 0
    int_2 = 0
    int_3 = 0
    int_4 = 0
    try:
        plugin_0 = vars_loader.get(str_0)
    except KeyError:
        plugin_0 = None

# Generated at 2022-06-25 14:19:05.330804
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    get_vars_from_path(str, str, str, str)

# Generated at 2022-06-25 14:19:06.231470
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    # Case 0:
    test_case_0()
    return True

# Generated at 2022-06-25 14:19:11.405933
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    var_0 = 'a'
    str_0 = 'b'
    check_0 = get_vars_from_path(var_0, str_0, str_0, str_0)
    assert check_0 == 1


# Generated at 2022-06-25 14:19:14.288360
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # str_1 = 'a'
    list_2 = []
    str_3 = 'a'
    get_vars_from_path(list_2, list_2, list_2, str_3)


# Generated at 2022-06-25 14:19:19.489049
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert True

# Generated at 2022-06-25 14:19:22.621269
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'a'
    str_1 = 'b'
    str_2 = 'c'
    str_3 = 'd'
    var_0 = get_vars_from_path(str_0, str_1, str_2, str_3)


# Generated at 2022-06-25 14:19:30.170409
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    print()
    print("****************************************************")
    print("*  Testing function \'get_plugin_vars\'             *")
    print("****************************************************")
    print()
    # Define test parameters
    get_plugin_vars_params = [
        ("path", "plugin", "loader", "entities"),
    ]
    # Define expected returns
    get_plugin_vars_expected = [
        {
            'a': 1
        }
    ]
    # Define test function
    for test_params, expected in zip(get_plugin_vars_params, get_plugin_vars_expected):
        if test_params == get_plugin_vars_params[0]:
            # Define return value
            temp_return = expected
            # Execute function
            return_value = get_plugin_vars

# Generated at 2022-06-25 14:19:33.798042
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    try:
        str_0 = 'a'
        var_0 = get_vars_from_path(str_0, str_0, str_0, str_0)

    except Exception as e:
        print(e)


# Generated at 2022-06-25 14:19:36.478747
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'a'
    var_0 = get_vars_from_path(str_0, str_0, str_0, str_0)


# Generated at 2022-06-25 14:19:40.457534
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    vars_loader = None
    path = None
    entities = None
    stage = None
    # Call function
    var_0 = get_vars_from_path(vars_loader, path, entities, stage)
    assert var_0 == {}

# Generated at 2022-06-25 14:19:48.799570
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'ScriptPlugin'
    str_1 = 'a'
    str_2 = 'Script: {}'.format(str_0)
    str_3 = 'ScriptPlugin._load_name'
    str_4 = 'Script: <None>'
    str_5 = 'ScriptPlugin._original_path'
    str_6 = 'Script: <None>'
    str_7 = 'ScriptPlugin.run'
    str_8 = 'Script: <built-in method run of _ScriptPlugin object at 0x7fadf655a988>'
    str_9 = 'ScriptPlugin.get_vars'
    str_10 = 'Script: <built-in method get_vars of _ScriptPlugin object at 0x7fadf655a988>'

# Generated at 2022-06-25 14:19:49.616873
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    pass


# Generated at 2022-06-25 14:19:56.702404
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    var_0 = C.ANSIBLE_INPUT_ENCODING
    var_1 = C.ANSIBLE_OUTPUT_ENCODING
    var_2 = C.ANSIBLE_PIPELINING
    var_3 = C.ANSIBLE_RETRY_FILES_ENABLED
    var_4 = C.ANSIBLE_ROLES_PATH
    var_5 = C.ANSIBLE_RUN_FROM_TASKS
    var_6 = C.ANSIBLE_RUNTIME_PATH
    var_7 = C.ANSIBLE_SSH_ARGS
    var_8 = C.ANSIBLE_TRANSPORT
    var_9 = C.ANSIBLE_VAULT_PASSWORD_FILE
    var_10 = C.ANSIBLE_VERBOSITY
    var_11 = C.ANSIBLE_VERSION

# Generated at 2022-06-25 14:19:59.994264
# Unit test for function get_plugin_vars

# Generated at 2022-06-25 14:20:07.471026
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'a'
    str_1 = 'a'
    str_2 = 'a'
    str_3 = 'a'
    var_0 = get_vars_from_path(str_0, str_1, str_2, str_3)

# Generated at 2022-06-25 14:20:10.136748
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    var_0 = get_vars_from_path(0, 0, 0, 0)
    assert var_0 == {}
    #Test for case 0 where path provided is not exist
    # so function should return empty dictionary


# Generated at 2022-06-25 14:20:11.590459
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    test_case_0()


# Generated at 2022-06-25 14:20:19.005976
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Test with invalid paramters
    assert get_vars_from_path(None, None, None, None) == {}
    # Now test with valid parameters
    assert get_vars_from_path(str('a'), str('a'), str('a'), str('a')) == {}
    # Now test with valid parameters but invalid types
    assert get_vars_from_path(str('a'), 123, {'a':1}, [1,2]) == {}


# Generated at 2022-06-25 14:20:21.741516
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # loader, path, entities, stage
    str_0 = 'a'
    var_0 = get_vars_from_path(str_0, str_0, str_0, str_0)


# Generated at 2022-06-25 14:20:32.887348
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    str_0 = 'a'
    str_1 = 'b'
    str_2 = 'c'
    str_3 = 'd'
    str_4 = 'e'
    str_5 = 'f'

    display.display(str_1)
    display.display(str_2)
    var_0 = get_plugin_vars(str_0, str_0, str_0, str_0)
    display.display(str_2)
    var_1 = get_plugin_vars(str_3, str_3, str_3, str_3)
    display.display(str_4)
    var_2 = get_plugin_vars(str_5, str_5, str_5, str_5)


if __name__ == '__main__':
    import sys
    print

# Generated at 2022-06-25 14:20:35.396518
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    path = 'a'
    entities = 'a'
    stage = 'a'
    var_0 = get_vars_from_path(path, entities, stage)


# Generated at 2022-06-25 14:20:39.604238
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_1 = 'a'
    str_2 = 'a'
    str_3 = 'a'
    str_4 = 'a'
    str_5 = 'a'
    test_case = get_vars_from_path(str_1, str_2, str_3, str_4)
    assert test_case == str_5


# Generated at 2022-06-25 14:20:41.819560
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    result = get_vars_from_path()
    assert result == None


# Generated at 2022-06-25 14:20:51.727111
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Declare a mocked function to be called after function `get_plugin_vars`
    # This is for preventing the AnsibleError being throwed, which would cause this test case fail
    def mocked_get_plugin_vars(loader, plugin, path, entities):
        return set()

    # Mock function `get_plugin_vars` to avoid the AnsibleError being thrown
    monkeypatch.setattr('ansible.inventory.vars_plugins.get_plugin_vars', mocked_get_plugin_vars)

    # Declare a AnsibleCollectionRef object to pass as the entities argument
    coll = AnsibleCollectionRef.from_string('namespace.collection')
    # Declare a AnsibleInventoryVarsPlugin object to pass as the plugin argument
    vars_plugin = AnsibleInventoryVarsPlugin()

    # Case 0: Ensure

# Generated at 2022-06-25 14:20:59.095638
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'a'
    str_1 = 'a'
    str_2 = 'a'
    var_0 = get_vars_from_path(str_0, str_1, str_2, str_2)


# Generated at 2022-06-25 14:20:59.755672
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    pass

# Generated at 2022-06-25 14:21:00.696278
# Unit test for function get_vars_from_path

# Generated at 2022-06-25 14:21:02.630775
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Test argument type for function 'get_vars_from_path'
    test_case_0()


# Generated at 2022-06-25 14:21:04.451449
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    display.display("Test get_vars_from_path:")
    test_case_0()


# Generated at 2022-06-25 14:21:12.131568
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    print('Test get_vars_from_path')

    data = {}
    vars_plugin_list = list(vars_loader.all())
    for plugin_name in C.VARIABLE_PLUGINS_ENABLED:
        if AnsibleCollectionRef.is_valid_fqcr(plugin_name):
            vars_plugin = vars_loader.get(plugin_name)
            if vars_plugin is None:
                # Error if there's no play directory or the name is wrong?
                continue
            if vars_plugin not in vars_plugin_list:
                vars_plugin_list.append(vars_plugin)


# Generated at 2022-06-25 14:21:16.260538
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'a'
    str_1 = 'a'
    str_2 = 'a'
    var_0 = get_vars_from_path(str_0, str_1, str_2, str_2)


# Generated at 2022-06-25 14:21:22.061835
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'a'
    str_1 = 'b'
    list_0 = ['c']
    list_1 = ['d']
    list_2 = ['e']
    var_0 = get_vars_from_path(list_0, list_1, list_2, str_0)
    assert var_0 == 'a'
    assert str_0 == 'a'


# Generated at 2022-06-25 14:21:25.996537
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'a'
    str_1 = 'b'
    str_2 = 'c'
    str_3 = 'd'
    var_0 = get_vars_from_path(str_0, str_1, str_2, str_3)

# Generated at 2022-06-25 14:21:29.295101
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # if C.VARIABLE_PLUGINS_ENABLED:
    #     data = get_vars_from_path(loader, path, entities, stage)
    pass


# Generated at 2022-06-25 14:21:40.710206
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'a'
    str_1 = 'a'
    str_2 = 'a'
    function_0 = get_vars_from_path(str_2, str_0, str_0, str_1)
    assert type(function_0) is dict


# Generated at 2022-06-25 14:21:47.810237
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    print('module test_get_vars_from_path')

    path = 'test_path'
    entities = [Host(name='host_0')]
    stage = 'inventory'
    loader = 'test_loader'

    # Test with a plugin that has get_vars, stage is 'inventory' and RUN_VARS_PLUGINS is 'start'
    def mock_vars_loader_get(a):
        class VarsPlugin:
            def __init__(self):
                self.REQUIRES_WHITELIST = False
            def get_vars(self, loader, path, entities):
                return {'test': '1'}
        return VarsPlugin()
    vars_loader.get = mock_vars_loader_get

# Generated at 2022-06-25 14:21:49.620184
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert get_plugin_vars(str_0, str_0, str_0, str_0)


# Generated at 2022-06-25 14:21:51.708893
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    assert get_plugin_vars(None, None, None, None) is None

# Unit tests for function get_vars_from_path

# Generated at 2022-06-25 14:21:55.739988
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    fake_0 = get_vars_from_path()
    fake_1 = get_vars_from_path()
    fake_2 = get_vars_from_path()
    fake_3 = get_vars_from_path()
    fake_4 = get_vars_from_path()


# Generated at 2022-06-25 14:21:57.980111
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'a'
    var_0 = get_vars_from_path(str_0, str_0, str_0, str_0)


# Generated at 2022-06-25 14:22:06.244829
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'a'
    str_1 = 'b'
    str_2 = 'c'
    str_3 = 'd'
    str_4 = 'e'
    str_5 = 'f'
    str_6 = 'g'
    str_7 = 'h'
    str_8 = 'i'
    list_0 = ['a', 'b', 'c', 'd']
    list_1 = ['e', 'f', 'g', 'h']
    list_2 = ['i', 'j', 'k', 'l']
    var_0 = get_vars_from_path(str_0, str_1, list_0, str_2)
    var_1 = get_vars_from_path(str_3, str_4, list_1, str_5)
    var

# Generated at 2022-06-25 14:22:12.422410
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    loader_0 = 'a'
    plugin_0 = 'a'
    path_0 = 'a'
    entities_0 = 'a'
    var_0 = get_plugin_vars(loader_0, plugin_0, path_0, entities_0)
    assert isinstance(var_0, dict)


# Generated at 2022-06-25 14:22:16.270740
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'a'
    str_1 = 'b'
    var_0 = get_vars_from_path(str_0, str_1, str_0, str_1)
    assert type(var_0) == dict


# Generated at 2022-06-25 14:22:23.475186
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    host_0 = Host(name='test_host_0')
    host_0.get_vars()
    host_0.get_host_vars()
    group_0 = Host(name='test_group_0')
    group_0.get_vars()
    group_0.get_group_vars()
    str_0 = 'a'
    test_case_0()
    try:
        get_plugin_vars(str_0, str_0, str_0, str_0)
    except AnsibleError:
        pass


# Generated at 2022-06-25 14:22:39.919614
# Unit test for function get_vars_from_path

# Generated at 2022-06-25 14:22:43.342767
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'a'
    get_vars_from_path(str_0, str_0, str_0, str_0)


# Generated at 2022-06-25 14:22:45.270421
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    try:
        assert True
    except AssertionError:
        display.error('Test Fail - get_plugin_vars')


# Generated at 2022-06-25 14:22:50.794321
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    
    test_loader = None
    test_path = 'y'
    test_entities = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y']
    test_stage = 'p'
    str_0 = get_vars_from_path(test_loader, test_path, test_entities, test_stage)
    assert str_0 != None

# Generated at 2022-06-25 14:22:52.947747
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    str_0 = 'a'
    var_0 = get_plugin_vars(str_0, str_0, str_0, str_0)
    print(var_0)


# Generated at 2022-06-25 14:22:56.481825
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'a'
    str_1 = 'a'
    str_2 = 'a'
    str_3 = 'a'

    var_1 = get_vars_from_path(str_0, str_1, str_2, str_3)
    pass



# Generated at 2022-06-25 14:22:57.932120
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    test_case_0()



# Generated at 2022-06-25 14:23:07.962866
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'a'
    str_1 = 'a'
    str_2 = 'a'
    str_3 = 'a'
    tuple_0 = (str_0, str_1, str_2)
    int_0 = 0
    int_1 = 1

    # Test if get_vars_from_path will return 2 when all the following conditions are met:
    # 1. there is a list in tuple_0
    # 2. list_0 is not empty
    assert get_vars_from_path(str_0, str_1, str_2, str_3) == int_0, "function get_vars_from_path fail."
    # Test if get_vars_from_path will return 1 when all the following conditions are met:
    # 1. there is a list in tuple_0


# Generated at 2022-06-25 14:23:09.890258
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert get_vars_from_path(None, None, None, None) == {}

# Generated at 2022-06-25 14:23:12.850909
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    test_0 = ('a', 'a', 'b', 'c')
    var_0 = get_vars_from_path(test_0)


# Generated at 2022-06-25 14:23:20.735686
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    pass



# Generated at 2022-06-25 14:23:22.837662
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'a'
    str_1 = 'b'
    data = get_vars_from_path(str_0, str_1, str_1, str_0)


# Generated at 2022-06-25 14:23:30.420409
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    loader = AnsibleCollectionRef.from_string('my.collection')
    sources = ['./plugins/loader/test_cases/vars_loader/0']
    entities = get_plugin_vars(loader, test_case_0, sources, 'inventory')
    stage = 'task'
    data = get_vars_from_inventory_sources(loader, sources, entities, stage)
    assert data == {'var_0': 'foo'}

# Generated at 2022-06-25 14:23:37.233873
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    try:
        os.mkdir('/tmp/test_ansible/vars')
        with open('/tmp/test_ansible/vars/test.yml', 'w') as f:
            f.write('---\nkey: value\n')
        res = get_vars_from_path('/tmp/test_ansible/vars', '/tmp/test_ansible/vars', [], 'task')
        assert res['key'] == 'value'
    finally:
        os.remove('/tmp/test_ansible/vars/test.yml')
        os.removedirs('/tmp/test_ansible/vars')

# Generated at 2022-06-25 14:23:40.422758
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    # Call the function
    func_ret_var = None
    assert func_ret_var == None
    func_ret_var = get_vars_from_path(*str_0, *str_0)
    assert func_ret_var == None


# Generated at 2022-06-25 14:23:41.720140
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    assert True


# Generated at 2022-06-25 14:23:49.435475
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Path /Users/jameelgibson/ansible/lib/ansible/plugins/vars/__init__.py
    # Line 33
    # Method get_vars_from_path
    #
    # Parameters:
    #   loader:
    #   path:
    #   entities:
    #   stage:

    path = list()
    entities = list()
    stage = str()

    vars_0 = get_vars_from_path(path, path, entities, stage)
    assert vars_0 == dict()


# Generated at 2022-06-25 14:23:50.301197
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    pass



# Generated at 2022-06-25 14:23:57.461046
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Load the vars plugin
    vars_plugin = get_plugin_vars(str_0, str_0, str_0, str_0)

    # Source the vars plugin
    vars_plugin_list = [vars_plugin]
    vars_plugin_list.append(vars_plugin)

    # Create a Host object
    host1 = Host(name='host1')

    # Create an entity
    entity_list = [host1]

    # Create a list of values for plugin_name
    plugin_name_list = [vars_plugin_list]

    # Create a list of values for stage
    stage_list = ['inventory']

    # Create a list of values for plugin
    plugin_list = [vars_plugin_list]

    # Create a list of values for path

# Generated at 2022-06-25 14:24:08.222406
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'a'
    str_1 = '/root/ansible/lib/ansible/plugins/vars/host_group_vars.py'
    str_2 = 'a'
    str_3 = '/root/ansible/lib/ansible/plugins/vars/group_vars.py'
    str_4 = 'a'
    str_5 = '/root/ansible/lib/ansible/plugins/vars/group_vars/all.yml'

    int_0 = 0
    int_1 = 1
    int_2 = 2
    int_3 = 3
    int_4 = 4
    int_5 = 5
    int_6 = 6
    int_7 = 7
    int_8 = 8
    int_9 = 9
    int_10 = 10
    int_

# Generated at 2022-06-25 14:24:32.043408
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    host_0 = Host(name='test_host')
    host_1 = Host(name='test_host')
    host_2 = Host(name='test_host')
    host_3 = Host(name='test_host')
    host_4 = Host(name='test_host')
    host_5 = Host(name='test_host')
    host_6 = Host(name='test_host')
    host_7 = Host(name='test_host')
    host_8 = Host(name='test_host')
    host_9 = Host(name='test_host')
    host_10 = Host(name='test_host')
    host_11 = Host(name='test_host')
    host_12 = Host(name='test_host')
    host_13 = Host(name='test_host')
    host_

# Generated at 2022-06-25 14:24:36.084067
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    f = get_vars_from_path
    path = 'a'
    entities = 'a'
    stage = 'a'
    loader = 'a'
    ret = get_vars_from_path(loader, path, entities, stage)
    assert(ret == {})



# Generated at 2022-06-25 14:24:40.136220
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    data = {}
    sources = [None]
    entities = [Host()]
    stage = 'inventory'
    result = get_vars_from_inventory_sources(data, sources, entities, stage)
    assert result is not None



# Generated at 2022-06-25 14:24:41.956049
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    print(get_vars_from_path())


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 14:24:46.799849
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    print('Testing function get_vars_from_path')
    # Test function inputs
    handle_0 = 'o'
    handle_1 = 'b'
    handle_2 = 'a'
    handle_3 = 'g'
    handle_4 = 's'
    str_0 = 'a'
    handle_5 = 'q'
    handle_6 = 'a'
    handle_7 = 'r'
    handle_8 = 'h'
    handle_9 = 'b'
    handle_10 = 'l'
    handle_11 = 'o'
    handle_12 = 'p'
    var_0 = get_vars_from_path(handle_0, handle_1, handle_2, handle_3)
    assert not var_0

# Generated at 2022-06-25 14:24:54.990124
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Unit test for get_vars_from_path functions
    str_0 = 'a'
    str_1 = 'a,b'
    str_2 = 'a/b'
    str_3 = 'a/b/c'
    str_4 = 'a/b/c/d'
    str_5 = 'a,b,c,d'
    str_6 = 'a/b/c/d'
    str_7 = 'a/b/c'
    str_8 = 'a/b'
    str_9 = 'a'
    str_10 = 'a,b,c,d'
    str_11 = 'a/b/c/d'
    str_12 = 'a/b/c'
    str_13 = 'a/b'
    str_14 = 'a'

# Generated at 2022-06-25 14:24:59.225445
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # get_vars_from_path(loader, path, entities, stage):
    str_0 = 'a'
    var_0 = get_vars_from_path(str_0, str_0, str_0, str_0)


# Generated at 2022-06-25 14:25:03.898903
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'var_vars_loader_'
    loader_0 = vars_loader.all()
    entities_0 = get_vars_from_path(loader_0, str_0, str_0, str_0)

    assert entities_0 is not None



# Generated at 2022-06-25 14:25:09.693799
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Initialize vars
    s_0 = [u'path', u'entities', u'stage']
    s_1 = [u'path', u'entities', u'stage']
    # Call get_vars_from_path with arguments
    t_0 = get_vars_from_path(s_0, s_1, 'entities', 'stage')


# Generated at 2022-06-25 14:25:11.776322
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'a'
    var_1 = get_vars_from_path(str_0, str_0, str_0, str_0)


# Generated at 2022-06-25 14:25:30.574602
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert True # Change me!


# Generated at 2022-06-25 14:25:33.065971
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    path = 'test/'
    entities = [1,2,3]
    stage = 'all'
    loader= 'test/'
    assert get_vars_from_path(loader, path, entities, stage) == {}

# Generated at 2022-06-25 14:25:36.072725
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Case 0
    str_0 = 'a'
    str_1 = 'b'
    str_2 = 'c'
    str_3 = 'd'
    str_4 = 'e'
    var_0 = get_vars_from_path(str_0, str_1, str_2, str_3)


# Generated at 2022-06-25 14:25:39.534271
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'a'
    str_1 = 'a'
    str_2 = 'a'
    str_3 = 'a'
    assert len(get_vars_from_path(str_0, str_1, str_2, str_3)) == 0
