

# Generated at 2022-06-25 14:16:14.247189
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    obj = {
        'sources': ['/home/frank/ansible/vars_plugins/hosts_lists.py'],
        'entities': ['server1', 'server2']
    }
    ansible.module_utils.basic.AnsibleModule.exit_json(**obj)

if __name__ == '__main__':
    test_get_vars_from_inventory_sources()

# Generated at 2022-06-25 14:16:18.053456
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    set_0 = None
    int_0 = 792
    set_1 = None
    var_0 = get_plugin_vars(set_0, set_1, set_0, int_0)


# Generated at 2022-06-25 14:16:23.406259
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    path = 'path'
    entities = [('host1'), ('host2'), ('host3')]
    stage = 'task'
    test_get_vars_from_path_0(path, entities, stage)
    test_get_vars_from_path_1(path, entities, stage)
    test_get_vars_from_path_2(path, entities, stage)
    test_get_vars_from_path_3(path, entities, stage)
    test_get_vars_from_path_4(path, entities, stage)


# Generated at 2022-06-25 14:16:24.426839
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    display.debug("TESTING get_vars_from_path")


# Generated at 2022-06-25 14:16:26.991543
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    set_0 = None
    int_0 = 792
    str_0 = 'VarsPlugin'
    var_0 = get_vars_from_path(set_0, 'FileNotFoundError', int_0, str_0)


# Generated at 2022-06-25 14:16:30.758296
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    set_0 = None
    int_0 = 792
    var_0 = get_vars_from_path(set_0, set_0, int_0, int_0)
    assert var_0 is None


# Generated at 2022-06-25 14:16:34.800167
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    set_0 = {
        'valid': (False, True),
    }
    int_0 = 632
    set_1 = {
        'valid': (False, True),
    }
    var_0 = get_vars_from_path(set_1, set_0, int_0, int_0)



# Generated at 2022-06-25 14:16:37.489616
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    class AnsibleModule:
        def __init__(self, set_0, int_0, int_1):
            self._load_name = set_0
            self._original_path = int_0
            self.run = int_1
    set_0 = AnsibleModule('set_0', 792, 792)
    int_0 = None
    int_1 = 792
    int_2 = 792
    var_0 = get_plugin_vars(int_0, set_0, int_1, int_2)


# Generated at 2022-06-25 14:16:41.481578
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    (set_0, int_0, var_0) = (None, 792, None)
    var_0 = get_vars_from_path(set_0, set_0, int_0, int_0)


# Generated at 2022-06-25 14:16:52.639578
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Path: str = path: str
    set_0 = None
    int_0 = 792
    var_1 = get_vars_from_path(set_0, set_0, int_0, int_0)
    assert var_1 != None  # bb
    assert var_1 == {}  # bb
    # Values: tuple[str, ...] = loaders._get_paths_relative_to_search_path(path: str, 'vars_plugins')
    values = None
    int_1 = 792
    var_2 = get_vars_from_path(values, values, int_1, int_1)
    assert var_2 == {}  # bb
    # Values: tuple[str, ...] = loaders._get_paths_relative_to_search_path(path:

# Generated at 2022-06-25 14:17:00.114184
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    loader = None
    plugin = None
    path = None
    entities = None
    assert get_plugin_vars(loader, plugin, path, entities) is not None


# Generated at 2022-06-25 14:17:02.757117
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    entities = [Host('h1')]
    loader = None
    path = './'
    stage = 'inventory'
    get_vars_from_path(loader, path, entities, stage)


# Generated at 2022-06-25 14:17:09.966330
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    # Imports.
    from ansible.plugins import loader

    # Setup variables.
    plugin_name_0 = 'script'
    module_utils_path_0 = 'test_module_utils_path_0'
    entities_0 = [loader.get('f5networks.bigip_command')]

    # Set up test.
    get_plugin_vars(module_utils_path_0, plugin_name_0, entities_0)


# Generated at 2022-06-25 14:17:10.970342
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    test_case_0()

# Generated at 2022-06-25 14:17:14.062682
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    plugin_name = 'test_vars_loader'
    path = 'test_path'
    entities = ['test_entities']

    print("Unit Test")

    get_vars_from_path(plugin_name, path, entities)

# Generated at 2022-06-25 14:17:16.028443
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    print('TESTING get_vars_from_path')

    print('TESTING get_vars_from_path COMPLETE')

# Generated at 2022-06-25 14:17:25.313043
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert type(get_vars_from_path()) == None
    str_0 = 'TESTING get_vars_from_path'
    assert get_vars_from_path(str_0) == dict
    data = dict
    assert get_vars_from_path(str_0, data) == dict
    str_1 = 'TESTING get_vars_from_path'
    data = dict
    str_2 = 'TESTING get_vars_from_path'
    assert get_vars_from_path(str_0, data, str_1, str_2) == dict


# Generated at 2022-06-25 14:17:27.326801
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    loader = None
    path = './'
    entities = Host()
    stage = 'inventory'
    result = get_vars_from_path(loader, path, entities, stage)


test_case_0()
#test_get_vars_from_path()

# Generated at 2022-06-25 14:17:28.507727
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert get_vars_from_path() == 'TESTING ', 'Test Failed'
    print('Test Passed!')

# Test code

# Generated at 2022-06-25 14:17:30.732917
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'TESTING get_vars_from_path'
    print(str_0)
    # Unit test for function get_vars_from_path


# Generated at 2022-06-25 14:17:49.818636
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    pass
# print(test_case_0())


# Generated at 2022-06-25 14:17:51.930929
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    print(test_case_0())
    assert test_case_0() == 'TESTING get_vars_from_path'



# Generated at 2022-06-25 14:17:55.613279
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    loader = None
    plugin = None
    path = str()
    entities = []
    # Call function get_plugin_vars and get data
    rt = get_plugin_vars(loader, plugin, path, entities)


# Generated at 2022-06-25 14:18:03.203903
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    inventory_file = 'test_data/test_inventory'
    cur_dir = os.path.dirname(os.path.abspath(__file__))
    inventory_path = os.path.join(cur_dir, inventory_file)
    loader = None
    plugin = None
    path = inventory_path
    entities = None
    # Check if the plugin is not working.
    # TODO: Check if this is the expected behavior
    assert plugin.get_vars is None


# Generated at 2022-06-25 14:18:08.155139
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'TESTING get_vars_from_path'
    path = '.'
    entities = [('', '', ''), '', '', '', '']
    stage = 'inventory'

    display.display('get_vars_from_path: '+str(get_vars_from_path(str_0, path, entities, stage)))

    return



# Generated at 2022-06-25 14:18:10.073060
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    #Path object, the path to use for getting variables.
    #Compound objects, usually a list of Host or Group objects.
    str_0 = 'TESTING get_vars_from_path'



# Generated at 2022-06-25 14:18:12.999773
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager

    sources = ["/var/ansible/contrib/inventory/test.py"]
    loader = InventoryManager(sources=sources)

    # call get_vars_from_inventory_sources()
    result = get_vars_from_inventory_sources(loader, sources, None, '')
    assert result == ''

# Generated at 2022-06-25 14:18:14.181467
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert 1 == 1
    test_case_0()


# Generated at 2022-06-25 14:18:24.972807
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # SETUP VARIABLES FOR TEST 1
    test_case_1_path = './../../'  # local dir
    test_case_1_loader = None
    test_case_1_entities = None
    test_case_1_stage = 'inventory'

    print("\nTESTING 1 get_vars_from_path()")
    print("Using path = ", test_case_1_path,
          "\nUsing stage = ", test_case_1_stage)


# Generated at 2022-06-25 14:18:28.910556
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    t_1 = {'host_vars':{'x':'y', 'a':'b'}, 'groupp_vars':{'x':'y', 'a':'b'}}
    t_2 = {'host_vars':{'x':0, 'a':1}, 'group_vars':{'x':0, 'a':1}}
    result = get_vars_from_path(t_1, t_2, None, None)
    assert result == {'group_vars': {'a': 1, 'x': 0}, 'host_vars': {'a': 1, 'x': 0}}


# Generated at 2022-06-25 14:18:45.850325
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='tests/inventory_test_hosts.yml')
    host = inventory.get_host('test_host')
    vars = get_vars_from_path(loader, './tests', host, 'inventory')
    assert vars == {'test_var': 'test_value'}



# Generated at 2022-06-25 14:18:48.769480
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    try:
        test_case_0()
    except Exception as e:
        print(e)
    else:
        print("No exception was thrown.")




# Generated at 2022-06-25 14:18:52.145127
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    int_0 = None
    int_0 = [ int_0 ]
    var_0 = get_vars_from_path(int_0, int_0, int_0, int_0)


# Generated at 2022-06-25 14:18:57.574454
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
  #pdb.set_trace()
  # var_0 = get_vars_from_path(loader, path, entities, stage)
  var_0 = get_vars_from_path(None, './test', ['localhost'], 'task')
  print(var_0)

# test case for get_vars_from_inventory_sources

# Generated at 2022-06-25 14:18:59.857846
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    int_1 = 795
    get_vars_from_path(int_1, int_1, int_1, int_1)



# Generated at 2022-06-25 14:19:01.669232
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert not get_vars_from_path(int_0, int_0, int_0, int_0)


# Generated at 2022-06-25 14:19:02.394833
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert 1 == 1


# Generated at 2022-06-25 14:19:08.479025
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    import os
    import yaml

    # Obtain object for test
    result_0 = yaml.load(open('tests/data/vars_plugins/0.yaml', 'r'))
    result_1 = yaml.load(open('tests/data/vars_plugins/1.yaml', 'r'))
    result_2 = yaml.load(open('tests/data/vars_plugins/2.yaml', 'r'))
    result_3 = yaml.load(open('tests/data/vars_plugins/3.yaml', 'r'))


# Generated at 2022-06-25 14:19:17.971299
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert get_vars_from_path(Loader_0, Path_0, Entities_0, Stage_0) == {}
    assert get_vars_from_path(Loader_1, Path_1, Entities_1, Stage_1) == {}
    assert get_vars_from_path(Loader_2, Path_2, Entities_2, Stage_2) == {}
    assert get_vars_from_path(Loader_3, Path_3, Entities_3, Stage_3) == {}
    assert get_vars_from_path(Loader_4, Path_4, Entities_4, Stage_4) == {}
    assert get_vars_from_path(Loader_5, Path_5, Entities_5, Stage_5) == {}

# Generated at 2022-06-25 14:19:21.313252
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    int_0 = 795
    var_0 = get_vars_from_path(int_0, int_0, int_0, int_0)

    # TODO - write unit test
    assert True

# Generated at 2022-06-25 14:19:41.901055
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Line 12
    loader_0 = 795
    # Line 13
    path_0 = 795
    # Line 14
    entities_0 = 795
    # Line 15
    stage_0 = 795
    # Line 16
    data_0 = {}
    # Line 17
    vars_plugin_list_0 = list(vars_loader.all())
    # Line 18
    iterator_0 = iter(C.VARIABLE_PLUGINS_ENABLED)

# Generated at 2022-06-25 14:19:43.951544
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    print("**** TESTING get_vars_from_path ****")
    test_case_0()
    print("")



# Generated at 2022-06-25 14:19:44.882630
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    test_case_0()


# Generated at 2022-06-25 14:19:45.787401
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    assert True == False



# Generated at 2022-06-25 14:19:48.409903
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # test_vars = get_vars_from_path(loader, path, entities, stage)
    assert get_vars_from_path() == 'test_get_vars_from_path()'


# Generated at 2022-06-25 14:19:50.633002
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    int_0 = 795
    var_0 = get_vars_from_path(int_0, int_0, int_0, int_0)
    assert var_0 == {}


# Generated at 2022-06-25 14:19:53.469015
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    # Unit test for function get_vars_from_inventory_sources
    int_0 = 795
    var_0 = get_vars_from_inventory_sources(int_0, int_0, int_0, int_0)

# Generated at 2022-06-25 14:19:57.315720
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.plugins.vars.core import TaskVars

    test_plugin = TaskVars()
    test_plugin.get_vars = lambda x, y, z: {"name": "foo"}
    test = get_plugin_vars(None, test_plugin, None, [])
    assert test["name"] == "foo"



# Generated at 2022-06-25 14:19:59.423514
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    int_0 = 795
    var_0 = get_vars_from_path(int_0, int_0, int_0, int_0)

    # print(var_0)

    # Asserts



# Generated at 2022-06-25 14:20:02.965509
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    int_0 = 795
    var_0 = get_plugin_vars(int_0, int_0, int_0, int_0)
    assert var_0 == AnsibleError("Cannot use v1 type vars plugin %s from %s" % (int_0, int_0))


# Generated at 2022-06-25 14:20:23.881017
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # check default args
    vars_dict_0 = {'var_0': 561, 'var_1': 'abc'}
    result_0 = get_vars_from_path(vars_dict_0, vars_dict_0, vars_dict_0, vars_dict_0)
    assert result_0 == {'var_0': 561, 'var_1': 'abc'}

    # check more args
    vars_dict_1 = {'var_0': 561, 'var_1': 'abc'}
    result_1 = get_vars_from_path(vars_dict_1, vars_dict_1, vars_dict_1, vars_dict_1)

# Generated at 2022-06-25 14:20:26.921717
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    int_0 = get_plugin_vars(0, 0, 0, 0)
    assert isinstance(int_0, dict)


# Generated at 2022-06-25 14:20:30.240533
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    int_0 = 795
    var_0 = get_vars_from_path(int_0, int_0, int_0, int_0)
    assert var_0 == 0.0


# Generated at 2022-06-25 14:20:34.390766
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    dataloader = DataLoader()
    inv_mgr = InventoryManager(loader=dataloader, sources="hosts")
    test_case_0()
    test_case_1()

# Generated at 2022-06-25 14:20:34.999785
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert True

# Generated at 2022-06-25 14:20:37.928715
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    int_0 = 795
    var_0 = get_vars_from_path(int_0, int_0, int_0, int_0)
    assert var_0 == {}, "get_vars_from_path function failed."


# Generated at 2022-06-25 14:20:38.787667
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    pass


# Generated at 2022-06-25 14:20:42.057913
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    int_1 = None
    int_2 = None
    int_3 = None
    int_4 = None

    # var_0 = get_vars_from_path(int_1, int_2, int_3, int_4)
    # print(var_0)



# Generated at 2022-06-25 14:20:49.559483
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    mock_entities = [{"name": "test1", "vars": {}}, {"name": "test2", "vars": {}}]
    mock_loader = { "_vars_plugins": {"test1": {"run": "test1"}, "test2": {"run": "test2"}},
                    "get_basedir": lambda x: x}
    mock_path = "/path/to/folder/with/plugins"
    mock_stage = "inventory"

    assert get_vars_from_path(mock_loader, mock_path, mock_entities, mock_stage) == {}


# Generated at 2022-06-25 14:20:53.121207
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    try:
        assert isinstance(get_plugin_vars(loader, plugin, path, entities), dict)
        # Fail, bad input
        raise AssertionError
    except AssertionError:
        print("Unit test for function get_plugin_vars failed.")


# Generated at 2022-06-25 14:21:06.932504
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    answer = {
        b"var_0": 795,
        b"var_1": 795,
        b"var_2": 795,
        b"var_3": 795
    }
    assert answer == test_case_0()

# Generated at 2022-06-25 14:21:09.369150
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    int_0 = 795
    var_0 = get_vars_from_path(int_0, int_0, int_0, int_0)
    assert (var_0 == None)


# Generated at 2022-06-25 14:21:15.156848
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    # Set up param for test case
    loader = AnsibleCollectionRef()
    plugin = 'var_plugin'
    path = 'test_path'
    entities = 'test_entities'

    # Execute the function under test
    var_0 = get_plugin_vars(loader, plugin, path, entities)



# Generated at 2022-06-25 14:21:17.651110
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    int_0 = 795
    var_0 = get_vars_from_path(int_0, int_0, int_0, int_0)

# Generated at 2022-06-25 14:21:25.516407
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    for entity in 'abc':
        for plugin_name in 'xyz':
            for source in 'ABC':
                plugin_line = plugin_name + ': ' + source
                output_vars_file_path = './testdata/output/' + plugin_line + '.vars'
                if os.path.exists(output_vars_file_path):
                    os.remove(output_vars_file_path)
                loader = 'abc'
                path = 'abc'
                entities = ['abc', 'xyz']
                stage = 'inventory'
                data = get_vars_from_path(loader, path, entities, stage)
                f = open(output_vars_file_path, 'w')
                f.write(str(data))
                f.close()

# Generated at 2022-06-25 14:21:28.678731
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    int_0 = 795
    var_0 = get_vars_from_path(int_0, int_0, int_0, int_0)


# Generated at 2022-06-25 14:21:37.349306
# Unit test for function get_vars_from_inventory_sources

# Generated at 2022-06-25 14:21:45.451907
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    vars_dict = {'vars': {'test': 'test_data'}}
    plugin_loader_object = None
    path = 'test/path'
    entities = ['test', 'test2']
    stage = 'inventory'

    # mock object for vars_loader
    class MockVarsLoader:
        def __init__(self, vars_dict, entities):
            self.vars_dict = vars_dict
            self.entities = entities

        def get_vars(self):
            return self.vars_dict

        def get_host_vars(self, entity):
            if entity in self.entities:
                return self.vars_dict
            else:
                return None

        def get_group_vars(self, entity):
            if entity in self.entities:
                return

# Generated at 2022-06-25 14:21:49.650259
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    int_0 = 795
    var_0 = get_vars_from_path(int_0, int_0, int_0, int_0)
    assert var_0 == {'ansible_play_hosts_all': int_0, 'ansible_play_batch': int_0, 'ansible_play_hosts': int_0}


# Generated at 2022-06-25 14:21:58.861962
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    int_0 = 159
    int_1 = 123
    list_0 = []

    class TestObj(object):
        """
        This object is defined to test the Ansible's functionality.
        """
        def __init__(self):
            self.name = 'ansible'

    plugin = TestObj()
    entities = [TestObj(), TestObj()]
    result = get_plugin_vars(int_0, plugin, int_0, entities)
    assert type(result) == dict
    assert result == {}
    list_0.append(TestObj())
    entities = [TestObj(), TestObj()]
    plugin = TestObj()
    plugin.get_host_vars = lambda *args: {int_0: int_1}

# Generated at 2022-06-25 14:22:13.496755
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    int_0 = 795
    var_0 = get_vars_from_inventory_sources(int_0, int_0, int_0, int_0)


# Generated at 2022-06-25 14:22:15.861644
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    int_0 = 795
    var_0 = get_vars_from_path(int_0, int_0, int_0, int_0)


# Generated at 2022-06-25 14:22:21.631587
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    NO_ERRORS = 0
    ERRORS = 1
    int_0 = 795
    var_0 = get_vars_from_path(int_0, int_0, int_0, int_0)
    assert(var_0 == {})

    int_0 = 83
    var_0 = get_vars_from_path(int_0, int_0, int_0, int_0)
    assert(var_0 == {})

    int_0 = 404
    var_0 = get_vars_from_path(int_0, int_0, int_0, int_0)
    assert(var_0 == {})

# Generated at 2022-06-25 14:22:24.327022
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    int_0 = 795
    var_0 = get_vars_from_path(int_0, int_0, int_0, int_0)



# Generated at 2022-06-25 14:22:27.286204
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    try:
        test_case_0()
    except Exception:
        display.error('UNEXPECTED EXCEPTION\n' + traceback.format_exc())
        traceback.print_exc()



# Generated at 2022-06-25 14:22:30.836373
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    int_0 = 0
    var_0 = get_vars_from_path(int_0, int_0, int_0, int_0)
    assert(type(var_0) == dict)


# Generated at 2022-06-25 14:22:35.058165
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    arg0 = 795
    arg1 = 795
    arg2 = 795
    arg3 = 795
    int_0 = get_vars_from_path(arg0, arg1, arg2, arg3)


# Generated at 2022-06-25 14:22:36.014739
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    assert test_case_0() == 0

# Generated at 2022-06-25 14:22:39.375508
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    int_0 = 795
    path_1 = '/etc/ansible/hosts'
    entities_2 = ['A', 'B', 'C']
    stage_3 = 'inventory'
    get_vars_from_path(int_0, path_1, entities_2, stage_3)



# Generated at 2022-06-25 14:22:49.665121
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    int_0 = 795
    var_0 = get_vars_from_path(int_0, int_0, int_0, int_0)

    # Test case 0
    int_1 = 795
    var_1 = get_vars_from_path(int_1, int_1, int_1, int_1)

    # Test case 1
    int_2 = 795
    var_2 = get_vars_from_path(int_2, int_2, int_2, int_2)

    # Test case 2
    int_3 = 795
    var_3 = get_vars_from_path(int_3, int_3, int_3, int_3)

    # Test case 3
    int_4 = 795
    var_4 = get_vars_from

# Generated at 2022-06-25 14:23:04.128882
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    vars_loader.clear()

    int_0 = 795
    test_case_0()

    var_0 = get_vars_from_path(int_0, int_0, int_0, int_0)



# Generated at 2022-06-25 14:23:05.793049
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    get_plugin_vars(int, int, int, int)
    assert True


# Generated at 2022-06-25 14:23:15.198581
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    print("")
    print("Test get_vars_from_path")
    print("=======================")

    # Generated from packet 139/140
    expected = {'ansible_facts': {'logicmonitor_collector_group': 'rhel_1'},
                'ansible_facts_d': {'ansible_facts': {'logicmonitor_collector_group': 'rhel_1'}},
                'ansible_groupvars_d': {'logicmonitor_collector_group': 'rhel_1'},
                'logicmonitor_collector_group': 'rhel_1',
                'logicmonitor_groupvars_d': {'logicmonitor_collector_group': 'rhel_1'}}

# Generated at 2022-06-25 14:23:16.027764
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert test_case_0()


# Generated at 2022-06-25 14:23:23.200205
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("int_0", type = int)
    parser.add_argument("int_1", type = int)
    parser.add_argument("int_2", type = int)
    parser.add_argument("int_3", type = int)
    args = parser.parse_args()
    int_0 = args.int_0
    int_1 = args.int_1
    int_2 = args.int_2
    int_3 = args.int_3
    var_0 = get_vars_from_path(int_0, int_1, int_2, int_3)


# Generated at 2022-06-25 14:23:24.968264
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert 'Ansible' == 'Ansible'


# Generated at 2022-06-25 14:23:32.652369
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    entity_0 = Host()
    entity_0.name = 'ansible_host'
    entity_1 = Host()
    entity_1.name = 'ansible_host'

    entities_0 = []
    entities_0.append(entity_0)
    entities_0.append(entity_1)

    display.display('entities_0: %s' % entities_0)

    test_case_0()


# Generated at 2022-06-25 14:23:33.518715
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    testcase_0(0)


# Generated at 2022-06-25 14:23:35.715775
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    int_0 = 795
    var_0 = get_vars_from_path(int_0, int_0, int_0, int_0)
    assert(var_0 == {})


# Generated at 2022-06-25 14:23:46.753558
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    test_case_0()

    int_0, str_0 = 1, 'bar.com'
    dict_0 = {str_0: int_0}
    var_0 = get_vars_from_path(dict_0, dict_0, dict_0, dict_0)

    dict_1 = {str_0: var_0}
    var_1 = get_vars_from_path(dict_1, dict_1, dict_1, dict_1)

    str_1 = 'ansible.builtin.vars_plugin'
    dict_2 = {str_1: var_1}
    var_2 = get_vars_from_path(dict_2, dict_2, dict_2, dict_2)

    var_3 = '*'

# Generated at 2022-06-25 14:24:01.767130
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    int_0 = 795
    var_0 = get_vars_from_path(int_0, int_0, int_0, int_0)
    assert var_0 == {}

# Generated at 2022-06-25 14:24:03.971229
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    var_0 = get_vars_from_inventory_sources(int(), int(), int(), int())


# Generated at 2022-06-25 14:24:08.899532
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    import ansible.inventory.manager
    i = ansible.inventory.manager.InventoryManager(loader=None, sources='localhost,')
    h = i.get_host(name='localhost')

    # Test function call
    ret = get_vars_from_path(i._loader, i.sources[0], h, 'task')
    assert ret == {'inventory_dir': '/etc/ansible', 'inventory_file': '/etc/ansible/localhost'}

# Generated at 2022-06-25 14:24:18.652506
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    class AnsibleLoader:
        class Host:
            name = ""
        class Group:
            name = ""


    # int_0 = 795
    # var_0 = get_vars_from_path(int_0, int_0, int_0, int_0)
    # class AnsibleLoader:
    #     class Host:
    #         name = ""
    #     class Group:
    #         name = ""
    #
    # class AnsibleVarsLoader:
    #     def __init__(self):
    #         self.inventory = AnsibleLoader()
    #
    #     def _get_directories(self, path):
    #         return path
    #
    #     def _load_plugins(self, plugin_dirs):
    #         return plugin_dirs
    #
    #

# Generated at 2022-06-25 14:24:28.427408
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    int_0 = 523
    for int_1 in range(0, int_0):
        var_0 = get_vars_from_path(int_1, int_1, int_1, int_1)

    int_0 = 684
    var_0 = get_vars_from_path(int_0, int_0, int_0, int_0)

    int_0 = 572
    var_0 = get_vars_from_path(int_0, int_0, int_0, int_0)

    int_0 = None
    var_0 = get_vars_from_path(int_0, int_0, int_0, int_0)

    int_0 = None

# Generated at 2022-06-25 14:24:29.799075
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    var_1 = get_vars_from_path(int(), int(), int(), int())
    return var_1



# Generated at 2022-06-25 14:24:31.262220
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    from ansible.plugins.loader import vars_loader
    var_0 = get_vars_from_path(vars_loader)


# Generated at 2022-06-25 14:24:33.669656
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # set up call to function under test
    int_0 = 795
    var_0 = get_vars_from_path(int_0, int_0, int_0, int_0)
    assert not var_0

# Generated at 2022-06-25 14:24:37.522979
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    int_0 = 795
    var_0 = get_vars_from_path(int_0, int_0, int_0, int_0)



# Generated at 2022-06-25 14:24:45.564718
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    host = Host('green')

    plugin = vars_loader.get('cache')
    path = '/etc/ansible/hosts'
    entities = [host]
    stage = 'inventory'
    data = get_plugin_vars(vars_loader, plugin, path, entities)
    print(data)

    data = get_vars_from_path(vars_loader, path, entities, 'inventory')
    print(data)


if __name__ == '__main__':
    # test_get_plugin_vars()
    test_get_vars_from_path()

# Generated at 2022-06-25 14:25:08.847703
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert func_return == var_expected


# Generated at 2022-06-25 14:25:10.806870
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert get_vars_from_path(0, 0, 0, 0) == {}

# Generated at 2022-06-25 14:25:20.014142
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    """
    # Normal
    int_0 = 795
    var_0 = get_vars_from_path(int_0, int_0, int_0, int_0)

    # Abnormal
    int_1 = 795
    var_1 = get_vars_from_path(int_1, int_1, int_1, int_1)

    # Abnormal
    int_2 = 795
    var_2 = get_vars_from_path(int_2, int_2, int_2, int_2)
    """
    assert func_name == "get_vars_from_path"
    assert len(inputs) == 4
    
    if inputs[3] is None:
        assert inputs[3] is None

# Generated at 2022-06-25 14:25:25.322209
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    import random
    # First parameter: input(inventory), second parameter: input(path), 
    # third parameter: input(entities), fourth parameter: input(stage)
    int_0 = random.randint(0, 100)
    int_1 = random.randint(0, 100)
    int_2 = random.randint(0, 100)
    int_3 = random.randint(0, 100)
    var_0 = get_vars_from_path(int_0, int_1, int_2, int_3)
    test_case_0()

# Generated at 2022-06-25 14:25:28.018896
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    int_0 = 795
    var_0 = get_vars_from_path(int_0, int_0, int_0, int_0)
    assert((int_0 == var_0[0]))


# Generated at 2022-06-25 14:25:35.350186
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    # simple case inventory file
    int_0 = "/etc/ansible/hosts"
    var_0 = get_vars_from_path(int_0, int_0, int_0, int_0)
    assert var_0 == 0

    # hosts files
    int_1 = "/etc/ansible/hosts,localhost"
    var_1 = get_vars_from_path(int_1, int_1, int_1, int_1)
    assert var_1 == 0

    # simple case for plugin specific setting
    int_2 = "/etc/ansible/hosts"
    var_2 = get_vars_from_path(int_2, int_2, "task", int_2)
    assert var_2 == 0

    # simple case for plugin specific setting

# Generated at 2022-06-25 14:25:37.843384
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    expected_0 = 795
    actual_0 = get_vars_from_path(expected_0, expected_0, expected_0, expected_0)
    assert actual_0 == expected_0


# Generated at 2022-06-25 14:25:39.560957
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    int_0 = 795
    var_0 = get_vars_from_path(int_0, int_0, int_0, int_0)
    assert var_0 is None


# Generated at 2022-06-25 14:25:41.470834
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    int_0 = 795
    var_0 = get_vars_from_path(int_0, int_0, int_0, int_0)
    assert var_0 == {}, "Test failed"

