

# Generated at 2022-06-25 14:15:55.182565
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'YAA)\t~`q'
    str_1 = ',Zmli^m'
    set_0 = {str_0, str_1}
    var_0 = get_vars_from_path(str_0, set_0, set_0, str_0)
    var_1 = get_vars_from_path(str_1, set_0, set_0, str_1)
    var_2 = get_vars_from_path(str_0, set_0, set_0, str_1)
    var_3 = get_vars_from_path(str_1, set_0, set_0, str_0)


# Generated at 2022-06-25 14:15:57.245324
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    init_var = get_vars_from_path(Paths, Paths, Paths, Paths)


# Generated at 2022-06-25 14:16:00.860661
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'YAA)\t~`q'
    set_0 = {str_0, str_0}
    var_0 = get_vars_from_path(str_0, set_0, set_0, set_0)


# Generated at 2022-06-25 14:16:02.543152
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    assert True  # get_vars_from_inventory_sources can't be tested at the moment

# Generated at 2022-06-25 14:16:09.854677
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    set_0 = {'a', 'b', 'c'}
    set_1 = {'r', 's'}
    tuple_0 = ('h', 'i', 'j')
    tuple_1 = ('u', 'p', 't')
    str_0 = 'd'
    str_1 = 'f'
    str_2 = 'g'
    str_3 = 'k'
    str_4 = 'l'
    str_5 = 'm'
    str_6 = 'n'
    str_7 = 'o'
    str_8 = 'p'
    str_9 = 'q'

    def func_0():
        for str_0 in set_0:
            for str_1 in tuple_0:
                yield str_0 + str_1

# Generated at 2022-06-25 14:16:13.613437
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    path_0 = 'random_folder'
    entities_0 = {'child_1', 99, 'child_1'}
    stage_0 = 'task'
    var_0 = get_vars_from_path(path_0, entities_0, stage_0)
    assert var_0 == {}, 'Test get_vars_from_path failed!'


# Generated at 2022-06-25 14:16:18.363907
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    list_0 = [str()]
    set_0 = {str(), str()}
    tuple_0 = (str(), str())
    dict_0 = {str(): str(), str(): str()}
    var_0 = get_vars_from_path(list_0, set_0, tuple_0, dict_0)

# Generated at 2022-06-25 14:16:21.152019
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'YAA)\t~`q'
    set_0 = {str_0, str_0}
    var_0 = get_vars_from_path(str_0, set_0, set_0, set_0)


# Generated at 2022-06-25 14:16:22.764437
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    var_0 = get_vars_from_path('boolean', '<', 'W=9aUv7', 'test')


# Generated at 2022-06-25 14:16:24.358781
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    assert test_case_0() == get_vars_from_inventory_sources(str_0, set_0, set_0, set_0)

# Generated at 2022-06-25 14:16:38.599011
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    var_0 = get_vars_from_path('', '', '', '')
    var_1 = get_vars_from_path('', '', '', '')
    var_2 = get_vars_from_path('', '', '', '')
    var_3 = get_vars_from_path('', '', '', '')
    var_4 = get_vars_from_path('', '', '', '')
    var_5 = get_vars_from_path('', '', '', '')
    var_6 = get_vars_from_path('', '', '', '')
    var_7 = get_vars_from_path('', '', '', '')
    var_8 = get_vars_from_path('', '', '', '')
   

# Generated at 2022-06-25 14:16:49.753066
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    var_1 = 'ansible_connection'
    var_2 = 'localhost'
    var_3 = {'hosts': {'host_0': {var_1: var_2}}}
    var_5 = 'playbook_dir'
    var_6 = 0
    var_7 = 'ansible_facts'
    var_8 = 'entities'

# Generated at 2022-06-25 14:16:52.310364
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert type(get_vars_from_path('<string>', '<string>', '<string>', '<string>')) is dict

# Generated at 2022-06-25 14:16:54.527495
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    get_plugin_vars("loader", "plugin", "path", "entities")


# Generated at 2022-06-25 14:16:56.976350
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    str_0 = '<'
    var_0 = get_vars_from_inventory_sources(str_0, str_0, str_0, str_0)

# Generated at 2022-06-25 14:16:57.924566
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    test_case_0()



# Generated at 2022-06-25 14:17:01.592752
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    loader = None
    path = "./ansible/plugins/vars"
    entities = None
    stage = "inventory"
    result = get_vars_from_path(loader, path, entities, stage)
    assert isinstance(result, (dict,))


# Generated at 2022-06-25 14:17:12.009133
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    host_0 = Host('my_host')
    str_0 = '<'
    str_1 = "'scope'"
    str_2 = '<'
    str_3 = '>'
    str_4 = '"'
    str_5 = "'''>"
    str_6 = '>'
    str_7 = '<'
    str_8 = '>'
    str_9 = '<'
    str_10 = '>'
    str_11 = '<'
    int_0 = 0
    int_1 = 1
    int_2 = 2
    int_3 = 3
    int_4 = 4
    int_5 = 5
    int_6 = 6
    int_7 = 7
    int_8 = 8
    int_9 = 9
    int_10 = 10
    int

# Generated at 2022-06-25 14:17:19.343978
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Test case: Default
    str_0 = '<'
    var_0 = get_vars_from_path(str_0, str_0, str_0, str_0)
    # Test case: Default
    str_0 = '<'
    str_1 = '>'
    var_0 = get_vars_from_path(str_0, str_1, str_0, str_0)
    # Test case: Default
    str_0 = '<'
    str_1 = '>'
    str_2 = '?'
    var_0 = get_vars_from_path(str_0, str_1, str_2, str_0)
    # Test case: Default
    str_0 = '<'
    str_1 = '>'
    str_2 = '?'

# Generated at 2022-06-25 14:17:25.786590
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    try:
        display.debug('Test: Run inventory variable plugins')
        str_0 = '<'
        var_0 = get_vars_from_path(str_0, str_0, str_0, str_0)
        display.debug('Test: Run inventory variable plugins')
    except Exception as err:
        display.display('Failed: test_get_vars_from_path')
        display.display(err.args)

# Generated at 2022-06-25 14:17:37.427748
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    var_0 = C.VARIABLE_PLUGINS_ENABLED
    var_1 = Host('n', 'n')
    var_2 = get_vars_from_inventory_sources(var_0, var_0, var_1, var_0)
    ## This test needs to be updated to actually provide a mocked implementation of Host()
    assert var_2 is not None


# Generated at 2022-06-25 14:17:48.174082
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    (str_0, var_0) = ('<', '>')
    (str_1, var_1, var_2, var_3, var_4) = ('_', '__', '___', '____', '_____')
    var_5 = '_'
    # Run unit test for clas
    # Run unit test for clas
    # Run unit test for clas
    # Run unit test for clas
    # Run unit test for clas
    # Run unit test for clas
    # Run unit test for clas
    # Run unit test for clas
    # Run unit test for clas
    # Run unit test for clas
    # Run unit test for clas
    # Run unit test for clas
    # Run unit test for clas
    # Run unit test for clas
    # Run unit test for cl

# Generated at 2022-06-25 14:17:48.711298
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert True

# Generated at 2022-06-25 14:17:52.210092
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = '<'
    var_0 = get_vars_from_path(str_0, str_0, str_0, str_0)
    print("var_0: ", var_0)



# Generated at 2022-06-25 14:17:53.995110
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # assert get_vars_from_path(loader, path, entities, stage) == False
    pass



# Generated at 2022-06-25 14:18:02.024155
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    print(">>> func_get_vars_from_path")
    func_get_vars_from_path()
    print(">>> func_get_vars_from_path")
    func_get_vars_from_path()
    print(">>> func_get_vars_from_path")
    func_get_vars_from_path()
    print(">>> func_get_vars_from_path")
    func_get_vars_from_path()


# Generated at 2022-06-25 14:18:04.734314
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    with pytest.raises(AnsibleError) as exc:
        test_case_0()
    assert "Invalid vars plugin  from <" in str(exc)

# Generated at 2022-06-25 14:18:08.963876
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    # Testing with var
    str_0 = '<'
    var_0 = get_vars_from_path(str_0, str_0, str_0, str_0)
    var_1 = get_plugin_vars(str_0, str_0, str_0, str_0)


# Generated at 2022-06-25 14:18:09.631180
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    assert callable(get_plugin_vars)

# Generated at 2022-06-25 14:18:12.612241
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = '<'
    var_0 = get_vars_from_path(str_0, str_0, str_0, str_0)



# Generated at 2022-06-25 14:18:35.554610
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Call function and test for no exceptions
    try:
        test_case_0()
    except Exception as e:
        assert False


# Generated at 2022-06-25 14:18:42.387823
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    # Invalid case
    assert not get_vars_from_path('<', '<', '<', '<')
    assert not get_vars_from_path('<', '<', '<', '>')
    assert not get_vars_from_path('<', '<', '>', '<')
    assert not get_vars_from_path('<', '>', '<', '<')

    # Normal case
    result = {}
    assert get_vars_from_path('<', '<', '<', '<') == result

    result = {}
    assert get_vars_from_path('<', '<', '>', '>') == result

# Generated at 2022-06-25 14:18:53.791627
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    const_str_0 = 'VARS_PLUGINS_ENABLED'
    const_str_1 = 'RUN_VARS_PLUGINS'
    const_str_2 = 'demand'
    const_str_3 = 'inventory'
    const_str_4 = 'start'
    const_str_5 = 'task'
    const_str_6 = 'stage'
    const_str_7 = 'all'
    const_var_0 = [const_str_0]
    const_var_1 = [const_str_1]
    const_var_2 = [const_str_6]
    const_var_3 = ['test']
    const_int_0 = 0
    const_int_1 = 2
    const_int_2 = 1
    const_int_3 = 10
    const

# Generated at 2022-06-25 14:18:56.703888
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = '<'
    var_0 = get_vars_from_path(str_0, str_0, str_0, str_0)
    assert var_0 == {}


# Generated at 2022-06-25 14:19:00.670857
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    path = C.DEFAULT_HOST_LIST
    # test for: inventory_loader, path, entities, stage
    # need to find a way to resolve the first three parameters
    # test_case_0()
    var_0 = get_vars_from_path(path, path, path, path)
    print(var_0)



# Generated at 2022-06-25 14:19:03.411825
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Path = ''
    assert get_vars_from_path('', '', '', '') == {}
    # Path = '/nonexistent'
    assert get_vars_from_path('', '/nonexistent', '', '') == {}
    # Path = '/test.py'
    assert get_vars_from_path('', '/test.py', '', '') == {}


# Test function get_vars_from_inventory_sources

# Generated at 2022-06-25 14:19:05.713428
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    str_0 = '<'
    var_0 = get_vars_from_inventory_sources(str_0, str_0, str_0, str_0)



# Generated at 2022-06-25 14:19:11.026446
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    var_0 = get_vars_from_path(
        loader = None,
        path = "test",
        entities = [],
        stage = None
    )

    assert var_0 == {}


# Generated at 2022-06-25 14:19:13.599415
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    var_0 = '<'
    var_1 = get_vars_from_path(var_0, var_0, var_0, var_0)
    assert(var_1 == {})

# Generated at 2022-06-25 14:19:14.450404
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    assert False


# Generated at 2022-06-25 14:19:27.285880
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    try:
        test_case_0()
        print("Testcase 0 Success")
    except Exception as err:
        print("Testcase 0 Failed")
        print(err)


# Generated at 2022-06-25 14:19:28.479222
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert test_case_0() == 0 # check return value


# Generated at 2022-06-25 14:19:31.394019
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert print(get_vars_from_path(0, 0, 0, 0))


# Generated at 2022-06-25 14:19:38.640356
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    var_1 = get_vars_from_path('m<Q', 'm<Q', 'm<Q', 'm<Q')
    assert var_1 == {}
    var_2 = get_vars_from_path('m+M', 'm+M', 'm+M', 'm+M')
    assert var_2 == {}
    var_3 = get_vars_from_path('m-Z', 'm-Z', 'm-Z', 'm-Z')
    assert var_3 == {}


# Generated at 2022-06-25 14:19:47.776918
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    ansible_0 = AnsibleError()
    str_0 = '|'
    str_1 = '}'
    str_2 = ']'
    str_3 = '0'
    str_4 = 'U'
    str_5 = 'V'
    str_6 = 'd'
    str_7 = '\\'
    str_8 = '9'
    str_9 = '>'
    str_10 = 'F'
    str_11 = 'C'
    str_12 = 'd'
    str_13 = 'h'
    str_14 = '4'
    str_15 = 'P'
    str_16 = '0'
    str_17 = '?'
    str_18 = '='
    str_19 = 'j'
    str_20 = 'l'
    str

# Generated at 2022-06-25 14:19:50.599584
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    # FIXME: this function is currently only called by get_vars, but
    #        it's otherwise unused. Commented out for now, in case
    #        it's needed later.
    #
    # test_case_0()

    pass


# Generated at 2022-06-25 14:19:53.200719
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert not bool(get_vars_from_path('<', '<', '<', '<'))
    assert not bool(get_vars_from_path(None, None, None, None))


# Generated at 2022-06-25 14:19:59.811393
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    ansible_vars_0 = {}
    ansible_vars_0['ansible_connection'] = 'local'
    ansible_vars_0['ansible_ssh_private_key_file'] = '/path/to/keyfile'
    ansible_vars_0['ansible_ssh_extra_args'] = '-o StrictHostKeyChecking=no'
    ansible_vars_0['ansible_port'] = '22'
    ansible_vars_0['ansible_host'] = 'ubuntu-8-xenial'
    ansible_vars_0['ansible_ssh_pass'] = 'V3ry_S3kr3t_P455w0rD'

# Generated at 2022-06-25 14:20:02.310552
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = '<'
    var_0 = get_vars_from_path(str_0, str_0, str_0, str_0)
    pass


# Generated at 2022-06-25 14:20:03.557047
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert get_vars_from_path == test_case_0

# Generated at 2022-06-25 14:20:17.298078
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    if test_case_0() != 0:
        return 1
    else:
        return 0



# Generated at 2022-06-25 14:20:20.474932
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    try:
        test_case_0()
    except AnsibleError as e:
        assert e.message == e.message
        assert e.exception == e.exception
        assert e.traceback == e.traceback


# Generated at 2022-06-25 14:20:22.974121
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    func_name = 'get_vars_from_path'
    try:
        loader, path, entities, stage
    except NameError:
        loader = None
        path = None
        entities = None
        stage = None
    test_case_0()


# Generated at 2022-06-25 14:20:26.447887
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    get_vars_from_path(str_0, str_0, str_0, str_0)

test_case_0()

# Generated at 2022-06-25 14:20:27.788290
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    test_case_0()


# Generated at 2022-06-25 14:20:29.248149
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert isinstance(test_case_0(), dict)


# Generated at 2022-06-25 14:20:31.133821
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert get_vars_from_path(None, None, None, None) is None


# Generated at 2022-06-25 14:20:34.492696
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    
    var_0 = '<'
    var_1 = '<'
    var_2 = '<'
    var_3 = get_vars_from_inventory_sources(var_0, var_1, var_2, var_3)

# Generated at 2022-06-25 14:20:37.765545
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    str_0 = '<'
    str_1 = '/home/santo/Documents/july/santo/'

    loader = 'A'
    sources = [str_1, ]
    entities = str_0
    stage = 'inventory'

    var_0 = get_vars_from_inventory_sources(loader, sources, entities, stage)

# Generated at 2022-06-25 14:20:45.142203
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    # Path test
    str_0 = os.path.join('test', 'ansible_test', 'test_cases', 'test_vars_from_path_case.py')
    with open(str_0, 'r') as f:
        content = f.read()
        assert 'test_case_0' in content

    # Result test
    import test_cases.test_vars_from_path_case as test_case
    test_results = test_case.test_results()
    assert test_results[0] == {'test_case_0': 'None'}

# Generated at 2022-06-25 14:21:02.115598
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    str_0 = '<'
    str_1 = '>'
    str_2 = '='
    str_3 = '@'
    plugin = vars_loader.get(str_0)
    if plugin is None: # error if there's no play directory or the name is wrong
        pass
    path = str_1
    entities = str_2
    var_0 = get_plugin_vars(plugin, str_3, path, entities)



# Generated at 2022-06-25 14:21:10.779205
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert not get_vars_from_path(None, None, None, None)
    assert not get_vars_from_path(False, False, False, False)
    assert not get_vars_from_path(0, 0, 0, 0)
    assert not get_vars_from_path(0.0, 0.0, 0.0, 0.0)
    assert not get_vars_from_path(True, True, True, True)
    assert not get_vars_from_path([], [], [], [])
    assert not get_vars_from_path((), (), (), ())
    assert not get_vars_from_path({}, {}, {}, {})
    assert not get_vars_from_path({0}, {0}, {0}, {0})
    assert not get_

# Generated at 2022-06-25 14:21:22.114721
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Test case 1
    str_1 = 'f_F(vRj4`w.HU6P3q#'
    entities_1 = 'mX9{,3q+]~$)'
    str_2 = 'J_5+5f5^R'
    var_0 = get_vars_from_path(str_1, entities_1, str_2, str_1)
    assert var_0 == {}

    # Test case 2
    str_1 = 't]1[B'
    entities_1 = '0xhB`~/D3'
    str_2 = '~=:e'
    str_3 = 'fR7r{x9'

# Generated at 2022-06-25 14:21:23.037779
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    test_case_0()

# Generated at 2022-06-25 14:21:33.213438
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = '-&$@;'
    str_1 = ''
    str_2 = '/'
    str_3 = '<'
    str_4 = "\x07"
    str_5 = 'P\x0e'
    str_6 = 'xH.1'
    str_7 = 'h'
    str_8 = '|\x0c'
    str_9 = '$\x0b'

# Generated at 2022-06-25 14:21:33.797045
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    assert True

# Generated at 2022-06-25 14:21:38.268314
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = '<'
    var_0 = get_vars_from_path(str_0, str_0, str_0, str_0)
    assert var_0 == dict()

    str_1 = '..'
    var_1 = get_vars_from_path(str_1, str_1, str_1, str_1)
    assert var_1 == dict()


# Generated at 2022-06-25 14:21:40.499678
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = '<'
    var_0 = get_vars_from_path(str_0, str_0, str_0, str_0)


# Generated at 2022-06-25 14:21:42.986263
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    path = '<path>'
    plugin = 1
    entities = '<entities>'
    var_0 = get_vars_from_path(path, plugin, entities, False)


# Generated at 2022-06-25 14:21:44.379305
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    print("Fn: get_vars_from_path")
    case_0()


# Generated at 2022-06-25 14:22:03.791203
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = '<'
    var_0 = get_vars_from_path(str_0, str_0, str_0, str_0)

    str_0 = '<'
    var_0 = get_vars_from_path(str_0, str_0, str_0, str_0)

    str_0 = '<'
    var_0 = get_vars_from_path(str_0, str_0, str_0, str_0)

    str_0 = '<'
    var_0 = get_vars_from_path(str_0, str_0, str_0, str_0)

    str_0 = '<'
    var_0 = get_vars_from_path(str_0, str_0, str_0, str_0)

# Generated at 2022-06-25 14:22:04.608645
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert 0 == 0


# Generated at 2022-06-25 14:22:06.024099
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert get_vars_from_path == test_case_0

# Generated at 2022-06-25 14:22:07.284511
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    test_case_0()

# Generated at 2022-06-25 14:22:11.220621
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = '<'
    var_0 = get_vars_from_path(str_0, str_0, str_0, str_0)


# Generated at 2022-06-25 14:22:16.400224
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    inventory_path = '/home/michael/ansible/plugins/inventory/terraform.py'
    source = '/home/michael/ansible/plugins/inventory/terraform.py,'
    entities = ','
    stage = ''
    result = get_vars_from_inventory_sources(inventory_path, source, entities, stage)
    print(result)

# Generated at 2022-06-25 14:22:26.614338
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    # Assign values to hard coded variables used in the function
    str_0 = '<'
    str_1 = '<'
    str_2 = '<'
    str_3 = '<'
    dict_0 = dict()
    dict_1 = dict()
    dict_2 = dict()
    dict_3 = dict()
    dict_4 = dict()
    dict_5 = dict()
    dict_6 = dict()
    dict_7 = dict()
    dict_8 = dict()
    dict_9 = dict()
    dict_10 = dict()
    dict_11 = dict()
    dict_12 = dict()
    dict_13 = dict()
    dict_14 = dict()
    dict_15 = dict()
    dict_16 = dict()
    dict_17 = dict()

# Generated at 2022-06-25 14:22:31.918085
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    str_0 = 'a'
    str_1 = 'b'
    list_0 = list()
    list_0.append(str_0)
    list_0.append(str_1)
    var_0 = get_vars_from_inventory_sources(list_0, list_0, list_0, str_1)

# Generated at 2022-06-25 14:22:37.475437
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert get_vars_from_path(get_vars_from_path, get_vars_from_path, get_vars_from_path, get_vars_from_path) == get_vars_from_path(get_vars_from_path, get_vars_from_path, get_vars_from_path, get_vars_from_path)


# Generated at 2022-06-25 14:22:38.309254
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    pass


# Generated at 2022-06-25 14:22:50.832631
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = '<'
    var_0 = get_vars_from_path(str_0, str_0, str_0, str_0)
    assert var_0 == {}
#

# Generated at 2022-06-25 14:22:52.707855
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    path = '.'
    entites = 'test'
    stage = 'play'
    loader = 'test'
    assert get_vars_from_path(loader, path, entites, stage) == {}



# Generated at 2022-06-25 14:22:54.484682
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    print('\nUnit test for function get_vars_from_path')
    test_case_0()


# Generated at 2022-06-25 14:22:55.748930
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert (callable(get_vars_from_path))


# Generated at 2022-06-25 14:22:56.283320
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert True

# Generated at 2022-06-25 14:23:07.063681
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    '''
    Function to test the get_vars_from_inventory_sources function.
    '''
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import inventory_loader
    from ansible.inventory.manager import InventoryManager
    from collections import namedtuple
    from ansible.vars.hostvars import HostVars, HostVarsVars

    vars = {}
    vars['inventory_dir'] = './test/integration/inventory/'
    vars['playbook_dir'] = './test/integration/playbooks/'
    vars['runner_dir'] = './test/integration/runner/'

    # Host1: f5demo-1.internal.ansible.com
    # Host2: f5demo-2.internal

# Generated at 2022-06-25 14:23:09.442596
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    str_0 = ']/7'
    var_0 = get_vars_from_inventory_sources(str_0, str_0, str_0, str_0)

# Generated at 2022-06-25 14:23:11.652705
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    print('test_get_vars_from_path')
    test_case_0()

# Generated at 2022-06-25 14:23:16.415700
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Path to the test directory
    test_path = os.path.dirname(os.path.realpath(__file__)) + "\\test_data" + "\\hosts"
    # Function parameters
    loader = 'test'
    entities = 'test'
    # Configure the Display object
    display.STRICT = True
    display.VERBOSITY = 1
    # Test function call
    test_case_0()

# Generated at 2022-06-25 14:23:19.191548
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    loader = 'loader'
    path = 'path'
    var_0 = Host('var_0')
    entities = [var_0]
    stage = 'all'

    var_1 = get_vars_from_path(loader, path, entities, stage)

    assert var_1 is not False


# Generated at 2022-06-25 14:23:33.199688
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    params = [
        ["", "", "", ""],
        ["", "", "", ""]
    ]
    for param in params:
        test_case_0()



# Generated at 2022-06-25 14:23:37.127320
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = '<'
    var_0 = get_vars_from_path(str_0, str_0, str_0, str_0)
    try:
        assert var_0 == {}, 'Expected {}, got {}' % ({}, var_0)
    except AssertionError:
        raise AssertionError('AssertionError: expected {}, got {}'.format({}, var_0))



# Generated at 2022-06-25 14:23:39.255093
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    str_0 = '<'
    var_0 = get_plugin_vars(str_0, str_0, str_0, str_0)


# Generated at 2022-06-25 14:23:49.969498
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Create mock_loader
    class mock_loader:
        def __init__(self):
            self.__name__ = 'loader'
            self.path_exists = True
            self.collection_playbook_path = 'collection_playbook_path'
            self.is_collection_playbook_path = True
            self.playbook_basedir = 'playbook_basedir'
            self.playbook_dir = 'playbook_dir'
            self.playbook_file = 'playbook_file'
            self.set_basedir = 'set_basedir'
            self.display = Display()

        def _get_collection_playbook_path(self, play_path):
            return self.collection_playbook_path

        def _is_collection_playbook_path(self, play_path):
            return self

# Generated at 2022-06-25 14:23:57.280177
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    # Make some fake plugins
    class VarsPlugin_A(object):
        def get_vars(self, loader, path, entities, cache=True):
            return self.get_host_vars('fake')

        def get_host_vars(self, hostname):
            return {'a': '1'}

    class VarsPlugin_B(object):
        def get_vars(self, loader, path, entities, cache=True):
            return self.get_host_vars('fake')

        def get_host_vars(self, hostname):
            return {'b': '2'}

    class VarsPlugin_C(object):
        def get_vars(self, loader, path, entities, cache=True):
            return self.get_host_vars('fake')


# Generated at 2022-06-25 14:24:03.119194
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # setup
    str_0 = '<'
    str_1 = '6'
    # tuple
    tuple_0 = (str_0, str_1)
    # function call
    value = get_vars_from_path(tuple_0, str_0, str_1, tuple_0)
    # assert
    assert value == {}


# Generated at 2022-06-25 14:24:06.789976
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    str_0 = '<'
    str_1 = 'Qi)'
    str_2 = '<'
    var_0 = get_plugin_vars(str_0, str_1, str_2, str_0)


# Generated at 2022-06-25 14:24:11.769407
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    print('')
    print('Test get_vars_from_path')

    data = get_vars_from_path('A', 'A', 'A', 'A')
    if data is None:
        print('SUCCESS: function returned None')
    else:
        print('FAILED: function returned ' + str(data))

# Generated at 2022-06-25 14:24:14.702279
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    path = 'a'
    entities = 'a'
    stage = 'a'
    var_1 = get_vars_from_path(path, entities, stage, stage)


# Generated at 2022-06-25 14:24:16.283905
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    # Catch exception if function throws one
    # Function call
    test_case_0()



# Generated at 2022-06-25 14:24:33.461570
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    arg_0 = '<>'
    arg_1 = '<>'
    arg_2 = '<>'
    arg_3 = '<>'
    ans = get_vars_from_path(arg_0, arg_1, arg_2, arg_3)
    assert ans == {}

    arg_0 = '<'
    arg_1 = '<'
    arg_2 = '<'
    arg_3 = '<'
    ans = get_vars_from_path(arg_0, arg_1, arg_2, arg_3)
    assert '<' != ans


# Generated at 2022-06-25 14:24:35.631334
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert func_call_count == 0

# Function test for function get_vars_from_path

# Generated at 2022-06-25 14:24:38.519608
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    # print("Test case #0 - get_plugin_vars function tests")
    # test_case_0()
    pass


# Generated at 2022-06-25 14:24:48.676388
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    str_0 = '../samples/vars_plugins/vars_plugin.py'
    str_1 = './samples/vars_plugins/vars_plugin.py'
    str_2 = '~/samples/vars_plugins/vars_plugin.py'
    str_3 = '/samples/vars_plugins/vars_plugin.py'
    str_4 = './samples/vars_plugins/vars_plugin.py'
    str_5 = './samples/vars_plugins/vars_plugin.py'
    str_6 = './samples/vars_plugins/vars_plugin.py'

# Generated at 2022-06-25 14:24:51.633668
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    path_0 = '7'
    entities_0 = '7'
    stage_0 = '7'
    var_0 = get_vars_from_path(path_0, entities_0, stage_0)



# Generated at 2022-06-25 14:24:53.882489
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    host = Host(vars={'foo': 'bar'})
    assert get_vars_from_path('path', [host], 'host', 'host') == {'foo': 'bar'}

# Generated at 2022-06-25 14:25:04.047749
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = '<'
    bool_0 = False
    str_1 = 'inventory_directory'
    # error expected because get_option returns None
    var_0 = get_vars_from_path(str_1, str_0, str_0, str_0)
    # error expected because of get_host_vars implementation
    var_1 = get_vars_from_path(str_0, str_0, str_0, str_0)
    # error expected because of get_group_vars implementation
    var_2 = get_vars_from_path(str_0, str_0, str_0, str_0)
    # error expected because of run implementation
    var_3 = get_vars_from_path(str_0, str_0, str_0, str_0)


# Generated at 2022-06-25 14:25:12.958517
# Unit test for function get_vars_from_path

# Generated at 2022-06-25 14:25:13.927002
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert test_case_0()

test_get_vars_from_path()



# Generated at 2022-06-25 14:25:14.308421
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    assert True
