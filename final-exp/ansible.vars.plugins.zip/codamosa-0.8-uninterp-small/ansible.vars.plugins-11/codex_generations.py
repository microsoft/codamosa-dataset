

# Generated at 2022-06-25 14:16:01.021576
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    list_0 = ['b', '\n', '#\x14D\x0c', '\x1e', '\nd']
    int_0 = -3396
    dict_0 = get_vars_from_path(list_0, list_0, list_0, int_0)
    assert dict_0 == {}

    list_0 = ['\x12', '\'\r8', '\x1e', '\r', '\x07']
    int_0 = -4167
    dict_0 = get_vars_from_path(list_0, list_0, list_0, int_0)
    assert dict_0 == {}

    list_0 = ['-', '\x1f', '\x1d', '\x0b', '\x0c']
    int_0

# Generated at 2022-06-25 14:16:08.868919
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'node2'
    dict_1 = {'@(#)PROGRAM:hostname PROJECT:hostname-90'}
    ansible_1 = {'ansible_connection': 'local', 'ansible_host': '127.0.0.1'}
    dict_3 = {'system': {'network': {'hostname': 'node2', 'fqdn': 'node2.example.com'}}}

    vars_1 = {'system': {'network': {'hostname': 'node2', 'fqdn': 'node2.example.com'}}}

# Generated at 2022-06-25 14:16:10.871391
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    param_0 = get_vars_from_path(list(), list(), list(), list())
    assert isinstance(param_0, dict)


# Generated at 2022-06-25 14:16:13.139914
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    list_0 = [str_0, int_0]
    var_0 = get_vars_from_inventory_sources(str_0, str_0, list_0, int_0)


# Generated at 2022-06-25 14:16:20.842432
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # TODO: 
    # PATH: str_0
    # ENTITIES: list_0
    # STAGE: str_1
    list_0 = ['Just got back from the library, man.', 'Just got back from the library, man.', 'Just got back from the library, man.', 'Just got back from the library, man.']
    str_0 = '`$=\x082S\x1f\x04'
    str_1 = '\x10W8'
    data = get_vars_from_path(str_0, list_0, list_0, str_1)
    assert data is not None


# Generated at 2022-06-25 14:16:24.391672
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    str_2 = '/Q7-^nya\x0b'
    list_2 = [str_2, str_2]
    int_2 = -2599
    var_2 = get_plugin_vars(str_2, list_2, list_2, int_2)


#  Unit test for function get_vars_from_path

# Generated at 2022-06-25 14:16:27.185575
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = '/Q7-^nya\x0b'
    list_0 = [str_0, str_0]
    int_0 = -2599
    assert get_vars_from_path(str_0, list_0, int_0, 'start') is None


# Generated at 2022-06-25 14:16:36.703138
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'l<\x11+'
    str_1 = 'z\x1aQx'
    str_2 = 'y#\x1c'
    str_3 = 'z\x1aQx'
    str_4 = 'YQ\x0f'
    str_5 = 'y#\x1c'
    int_0 = 1346

# Generated at 2022-06-25 14:16:47.664687
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    str_0 = 'bR\x16k\x14\t'
    str_1 = '+2P\x06\x19\x16'
    str_2 = '/\x1c'
    list_0 = [str_0, str_1, str_2]
    int_0 = 15836
    var_0 = get_plugin_vars(str_0, list_0, list_0, int_0)
    assert var_0 == [(str_2, [str_1, str_2]), (str_1, [str_0, str_1]), (str_0, [str_0, str_1, str_2])]
    str_3 = '\x03\x12\x00\x0b\x13\x00\x01\x1c\x00'
   

# Generated at 2022-06-25 14:16:54.329347
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = '<'                                           # compute_0
    str_1 = 'VW'                                          # compute_1
    list_0 = [str_0, str_1, str_1]
    int_0 = -7895                                         # compute_2
    str_2 = get_vars_from_path(list_0, str_1, list_0, int_0) # compute_3




# Generated at 2022-06-25 14:17:01.422685
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = ''
    list_0 = [str_0, str_0]
    int_0 = -2599
    str_1 = ''
    str_2 = ''
    var_0 = get_vars_from_path(str_0, str_1, list_0, int_0)
    var_1 = get_vars_from_path(str_0, str_2, list_0, int_0)
    

# Generated at 2022-06-25 14:17:11.690480
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    data_0 = b'nw\x1f3\r`d'
    int_0 = -2147483647

    str_0 = '/\x04\x1bO<o\x06\x0e)'
    str_1 = '\x1b\x0c[\x0c\x08\x1e\x1a'
    int_1 = -2147483647
    var_0 = get_vars_from_path(str_0, str_1, int_1, int_0)

    str_0 = 'O\x13\x1e\x1b\x1b^\x0c'
    str_1 = '\x06\x1c\x1e\x1f\x1c\x0b'
    int_1 = -2147

# Generated at 2022-06-25 14:17:22.989214
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Path to variables file in the 'group_vars' directory.
    group_file_path = 'ansible_collections/acme/simple/group_vars/all'
    # Entity name for the variable file in the 'group_vars' directory.
    group_entity = 'group'
    # Entity name for the variable file in the 'host_vars' directory.
    host_entity = 'host'
    # Path to variables file in the 'host_vars' directory.
    host_file_path = 'ansible_collections/acme/simple/host_vars/host2'
    # Loader for the variable files.
    loader = 'loader'
    # Stage name of the variable file.
    stage = 'inventory'
    # Variable values retrieved from the variable file in the 'group_vars' directory.


# Generated at 2022-06-25 14:17:26.654787
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = '^'
    list_0 = [str_0, str_0]
    int_0 = -2599
    var_0 = get_vars_from_path(str_0, list_0, int_0, str_0)


# Generated at 2022-06-25 14:17:33.947286
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    int_0 = -1746
    str_0 = '\x0bAuC'
    str_1 = '\x0b8'
    str_2 = 'd\x0b'
    str_3 = '\x0bAuC'
    int_1 = 15
    list_0 = [int_1, int_1, int_1, int_1, int_1, int_1, int_1, int_1, int_1, int_1]
    int_2 = -1560
    list_1 = [str_3, str_0, str_1, str_2, int_0, list_0, int_2, str_0]

# Generated at 2022-06-25 14:17:37.838592
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = '\n'
    list_0 = [str_0, str_0]
    int_0 = -2599
    var_0 = get_vars_from_path(str_0, list_0, list_0, int_0)


# Generated at 2022-06-25 14:17:43.017619
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = '/Qq?bH\t'
    list_0 = [str_0, str_0]
    int_0 = -14491
    var_0 = get_vars_from_path(str_0, list_0, list_0, int_0)


# Generated at 2022-06-25 14:17:46.557825
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    str_0 = '\x07'
    list_0 = [str_0, str_0]
    int_0 = 1685
    var_0 = get_plugin_vars(str_0, list_0, list_0, int_0)


# Generated at 2022-06-25 14:17:51.979969
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'multiprocessing'
    str_1 = 'platform'
    var_0 = get_vars_from_path(str_0, str_1, str_1, str_0)
    str_2 = '3'
    str_3 = 'platform'
    str_4 = 'if'
    str_5 = 'a'
    var_1 = get_vars_from_path(str_2, str_3, str_4, str_5)
    assert(-1401 == var_1)


# Generated at 2022-06-25 14:17:57.224219
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = ';/\n'
    list_0 = ['/}}U6', 'Q7-^nya\x0b', 'Pv6%S']
    int_0 = 0
    var_0 = get_vars_from_path(str_0, list_0, list_0, int_0)


# Generated at 2022-06-25 14:18:14.879206
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    # Testing with default parameter
    # Returns bool_0

    str_0 = 'o'
    int_0 = 0
    bool_0 = '!kZw'
    var_0 = get_vars_from_path(str_0, str_0, str_0, int_0)
    assert var_0 is bool_0

    # Testing with default parameter
    # Returns bool_0

    str_0 = 'c'
    int_0 = 0
    str_1 = '+'
    bool_0 = '!kZw'
    var_0 = get_vars_from_path(str_0, str_1, str_0, int_0)
    assert var_0 is bool_0

    # Testing with default parameter
    # Returns bool_0

    str_0 = 'O('
   

# Generated at 2022-06-25 14:18:17.120599
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    get_plugin_vars(str_0, str_0, str_0, int_0)


# Generated at 2022-06-25 14:18:27.106172
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    str_0 = 'x'
    int_0 = 0
    dict_0 = {}
    dict_1 = {}
    dict_1[str_0] = dict_0
    dict_0[str_0] = dict_1
    dict_1[str_0] = dict_0
    dict_0[str_0] = dict_1
    dict_1[str_0] = dict_0
    dict_0[str_0] = dict_1
    dict_1[str_0] = dict_0
    dict_0[str_0] = dict_1
    dict_1[str_0] = dict_0
    dict_0[str_0] = dict_1
    dict_1[str_0] = dict_0
    dict_0[str_0] = dict_1
   

# Generated at 2022-06-25 14:18:32.465885
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    int_0 = 0
    str_0 = ''
    bool_true = True
    bool_false = False
    data = {'ansible_inventory_sources': ['/tmp/sample.yml'], 'inventory_dir': '/tmp'}
    assert data == get_vars_from_path(str_0, str_0, str_0, int_0)


# Generated at 2022-06-25 14:18:41.531885
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    loader = 'O6U}}'
    plugin = 'U6O}}U6'
    path = 'U6}}6U'
    entities = '6}}U6'
    var_0 = get_plugin_vars(loader, plugin, path, entities)
    loader = 'O6U}}'
    plugin = 'U6O}}U6'
    path = 'U6}}6U'
    entities = '6}}U6'
    var_0 = get_plugin_vars(loader, plugin, path, entities)
    loader = 'O6U}}'
    plugin = 'U6O}}U6'
    path = 'U6}}6U'
    entities = '6}}U6'
    var_0 = get_plugin_vars(loader, plugin, path, entities)

# Generated at 2022-06-25 14:18:48.100253
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    str_0 = '/}}U6'
    int_0 = 0
    list_0 = list()
    # def proxy(*args, **kwargs): return func(*args, **kwargs)
    # proxy.run = get_plugin_vars
    # proxy._original_path = str_0
    # proxy._load_name = str_0
    # list_0.append(proxy)
    get_plugin_vars(int_0, list_0, str_0, int_0)


# Generated at 2022-06-25 14:18:51.865317
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = ''
    int_0 = 0
    var_0 = get_vars_from_path(str_0, str_0, str_0, int_0)
    test_case_0()



# Generated at 2022-06-25 14:18:55.582339
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = '/}}U6'
    int_0 = 0
    var_0 = get_vars_from_path(str_0, str_0, str_0, int_0)


# Generated at 2022-06-25 14:18:59.409025
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    str_0 = '/}}U6'
    int_0 = 0
    var_0 = get_vars_from_inventory_sources(str_0, str_0, str_0, int_0)
    print(var_0)

# Unit test fo function get_vars_from_path

# Generated at 2022-06-25 14:19:02.106403
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = '/}}U6'
    int_0 = 0
    var_0 = get_vars_from_path(str_0, str_0, str_0, int_0)
    return var_0
    pass



# Generated at 2022-06-25 14:19:19.008476
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Arguments for get_vars_from_path
    str_0 = '/}}U6'
    str_1 = '/}}U6'
    str_2 = '/}}U6'
    int_0 = 0
    get_vars_from_path(str_0, str_1, str_2, int_0)



# Generated at 2022-06-25 14:19:27.052199
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    str_0 = '/}}U6'
    assert str_0 == '/}}U6'
    int_0 = 0
    assert int_0 == 0
    sources_0 = ['/}}U6', '/}}U6', '/}}U6']
    assert sources_0 == ['/}}U6', '/}}U6', '/}}U6']
    entities_0 = False
    assert entities_0 == False
    stage_0 = 'inventory'
    assert stage_0 == 'inventory'
    var_1 = get_vars_from_inventory_sources(str_0, sources_0, entities_0, stage_0)
    assert var_1 == get_vars_from_inventory_sources(str_0, sources_0, entities_0, stage_0)

# Generated at 2022-06-25 14:19:30.758040
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    # User Input
    path_0 = '/usr/bin/{{ ansible_hostname }}'
    entities_0 = '/etc/'
    stage_0 = 'all'

    # Expected Result
    expected_result_0 = {}

    # Actual Result
    actual_result_0 = get_vars_from_path(path_0, entities_0, stage_0)

    # Verify
    assert expected_result_0 == actual_result_0



# Generated at 2022-06-25 14:19:33.569489
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    print('Testing get_vars_from_path')

    test_case_0()


# Program entry point
if __name__ == '__main__':
    test_get_vars_from_path()

# Generated at 2022-06-25 14:19:35.305462
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    assert get_plugin_vars(None, None, None, None) == {}, 'Test Passed'



# Generated at 2022-06-25 14:19:39.200024
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    var_0 = ''
    var_1 = ''
    var_2 = ''
    var_3 = ''

    assert get_plugin_vars(var_0, var_1, var_2, var_3) == {}


# Generated at 2022-06-25 14:19:41.943980
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    print("Testing function get_vars_from_path")
    result = get_vars_from_path(str, str, str, int)
    assert result == None



# Generated at 2022-06-25 14:19:46.072068
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    str_0 = ''
    str_1 = ''
    str_2 = ''
    int_0 = 0
    var_0 = get_plugin_vars(str_0, str_1, str_2, int_0)

if __name__ == "__main__":
    test_get_plugin_vars()

# Generated at 2022-06-25 14:19:48.961892
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    try:
        from ansible import constants as C
    except:
        assert False
    int_0 = 0
    str_0 = '/}}U6'
    assert get_vars_from_path(str_0, str_0, str_0, int_0) == None


# Generated at 2022-06-25 14:19:50.345763
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    result = get_plugin_vars('', '', '', '')
    assert result == {}, 'Expected {}, but got {}'.format({}, result)


# Generated at 2022-06-25 14:20:07.117859
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = ''
    assert get_vars_from_path(str_0, str_0, str_0, str_0) is None


# Generated at 2022-06-25 14:20:18.120243
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    str_0 = ''
    str_1 = 'test_inventory_sources_main_0'
    str_2 = 'test_inventory_sources_main_1'
    dict_0 = {}
    dict_0['test_key'] = 'test_value'
    str_3 = 'test_inventory_sources_main_2'
    str_4 = 'test_inventory_sources_main_3'
    str_5 = 'test_inventory_sources_main_4'
    str_6 = 'test_inventory_sources_main_5'
    str_7 = 'test_inventory_sources_main_6'
    str_8 = 'test_inventory_sources_main_7'

# Generated at 2022-06-25 14:20:23.856433
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = ''
    str_1 = ''
    str_2 = ''
    str_3 = ''
    dict_0 = dict()
    dict_1 = dict()
    dict_2 = dict()
    var_0 = get_vars_from_path(str_0, str_1, str_2, str_3)
    dict_0['hello'] = 'world'
    dict_1['hello'] = 'world'
    assert var_0 == dict_2


# Generated at 2022-06-25 14:20:30.448416
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    data_0 = {'foo': 'bar'}
    assert data_0 == get_vars_from_path(data_0, data_0, data_0, 'inventory')

    data_1 = {'foo': 'bar'}
    assert data_1 == get_vars_from_path(data_1, data_1, data_1, data_1)


# Generated at 2022-06-25 14:20:39.632354
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    p_0 = "path_0"
    e_0 = "entities_0"
    class A:
        def __init__(self):
            self.data = 0
        def get_vars(self, loader, path, entities):
            self.data += 1
            return "ansible_plugin"
    a_obj = A()
    class B:
        def __init__(self):
            self.data = 0
        def get_host_vars(self, name):
            self.data += 1
            return "ansible_plugin"
    b_obj = B()

# Generated at 2022-06-25 14:20:43.188177
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = ''
    list_1 = [str_0]
    var_0 = get_vars_from_path(str_0, str_0, list_1, str_0)


# Generated at 2022-06-25 14:20:44.458367
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    assert test_case_0()['str_0']


# Generated at 2022-06-25 14:20:44.902773
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    assert True

# Generated at 2022-06-25 14:20:46.846615
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert get_vars_from_path(str_0, str_0, str_0, str_0)


# Generated at 2022-06-25 14:20:51.329605
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'get_vars_from_path'
    dict_0 = {}
    list_0 = []
    dict_0 = get_vars_from_path(str_0, str_0, list_0, str_0)
    assert dict_0 == {}


# Generated at 2022-06-25 14:21:06.791342
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    test_case_0()



# Generated at 2022-06-25 14:21:09.911659
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    path = "./data/sample_inventory_hosts"
    entities = ""
    stage = "inventory"
    loader = "loader"

    res = get_vars_from_path(loader, path, entities, stage)
    assert res is not None


# Generated at 2022-06-25 14:21:11.078875
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    assert True


# Generated at 2022-06-25 14:21:12.091801
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # TODO
    pass



# Generated at 2022-06-25 14:21:15.842710
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # path = 'None'
    entities = list()
    stage = 'inventory'
    loader = None
    var_1 = get_vars_from_path(loader, None, entities, stage)



# Generated at 2022-06-25 14:21:16.877843
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    return


# Generated at 2022-06-25 14:21:20.024854
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = ''
    str_1 = ''
    str_2 = ''
    str_3 = ''
    str_4 = ''
    str_5 = ''


# Generated at 2022-06-25 14:21:22.686647
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = ''
    var_0 = get_vars_from_path(str_0, str_0, str_0, 'inventory')
    assert var_0 == {}



# Generated at 2022-06-25 14:21:25.915990
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    try:
        test_case_0()

    except Exception as e:
        print(e)

    finally:
        print('Successfully test get_plugin_vars')



# Generated at 2022-06-25 14:21:27.572273
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert va_1 == va_2

# Generated at 2022-06-25 14:21:50.160710
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    str_0 = ''
    var_0 = get_plugin_vars(str_0, str_0, str_0, str_0)



# Generated at 2022-06-25 14:21:53.209994
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_1 = ''
    str_2 = ''
    str_3 = ''
    var_1 = get_vars_from_path(str_1, str_2, str_3, str_3)


# Generated at 2022-06-25 14:21:55.885823
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = ''
    var_0 = get_vars_from_path(str_0, str_0, str_0, str_0)


# Generated at 2022-06-25 14:21:59.120242
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    stage = 'task'
    entities = [Host("test_host")]
    path = "/path/to/playbook"

    var_0 = get_vars_from_path(None, path, entities, stage)
    assert var_0 == {}



# Generated at 2022-06-25 14:22:07.117409
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    with pytest.raises(TypeError) as excinfo:
        test_case_0()
    assert 'Expected argument \'loader\' (pos 1) to be a str object' in str(excinfo.value)
    with pytest.raises(TypeError) as excinfo:
        test_case_0()
    assert 'Expected argument \'plugin\' (pos 2) to be a str object' in str(excinfo.value)
    with pytest.raises(TypeError) as excinfo:
        test_case_0()
    assert 'Expected argument \'path\' (pos 3) to be a str object' in str(excinfo.value)
    with pytest.raises(TypeError) as excinfo:
        test_case_0()

# Generated at 2022-06-25 14:22:16.053356
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = ''
    str_1 = ''
    list_0 = []
    var_0 = get_vars_from_path(str_0, str_0, str_0, list_0)
    var_1 = get_vars_from_path(str_0, str_0, str_0, list_0)
    var_2 = get_vars_from_path(str_0, str_0, str_1, list_0)
    assert var_0 == var_1
    assert var_1 != var_2


# Generated at 2022-06-25 14:22:16.612780
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert True



# Generated at 2022-06-25 14:22:22.094149
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = ''
    _loader = vars_loader.get(str_0)
    _plugin_name = C.VARIABLE_PLUGINS_ENABLED[0]
    _path = vars_loader.all()
    _entities = vars_loader.all()
    var_0 = get_vars_from_path(_loader, _path, _entities, str_0)

# Generated at 2022-06-25 14:22:22.667509
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    assert True



# Generated at 2022-06-25 14:22:26.613781
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = ''
    str_1 = ''
    str_2 = ''
    str_3 = ''

    var_0 = get_vars_from_path(str_0, str_1, str_2, str_3)


# Generated at 2022-06-25 14:23:17.277656
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'test'
    str_1 = 'test_0'
    str_2 = 'test_1'
    str_3 = 'test_2'
    str_4 = 'test_3'
    int_0 = 0
    int_1 = 1
    int_2 = 2
    int_3 = 3
    int_4 = 4
    int_5 = 5
    int_6 = 6
    int_7 = 7
    int_8 = 8
    int_9 = 9
    int_10 = 10
    int_11 = 11
    int_12 = 12
    int_13 = 13
    int_14 = 14
    int_15 = 15
    int_16 = 16
    int_17 = 17
    int_18 = 18
    int_19 = 19
    int_20 = 20

# Generated at 2022-06-25 14:23:18.558160
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = ''
    test_case_0()


# Generated at 2022-06-25 14:23:20.973823
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = ''
    str_1 = ''
    var_0 = get_vars_from_path(str_0, str_1, str_1, str_1)


# Generated at 2022-06-25 14:23:23.471331
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    loader, sources, entities, stage = str_0, str_0, str_0, str_0
    var_1 = get_vars_from_inventory_sources(loader, sources, entities, stage)
    return var_1



# Generated at 2022-06-25 14:23:29.644492
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    str_0 = ''
    # get_plugin_vars(loader, plugin, path, entities)
    # verify if the function execution throws an exception
    try:
        var_0 = get_plugin_vars(str_0, str_0, str_0, str_0)
        assert False
    except Exception:
        assert True



# Generated at 2022-06-25 14:23:34.375311
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    ansible_playbook_1 = [(str_0 == str_0)]
    setattr(AnsibleError, '_ansible_no_log', ansible_playbook_1)
    var_0 = get_vars_from_path(str_0, str_0, str_0, str_0)


# Generated at 2022-06-25 14:23:37.024367
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = ''
    # Test case 0
    #Test case with empty parameters
    var_0 = get_vars_from_path(str_0,str_0,str_0,str_0)

# Generated at 2022-06-25 14:23:47.775214
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = ''
    str_1 = 'str_1'
    str_2 = 'str_2'
    tuple_0 = ()
    tuple_1 = (str_1,)
    bool_0 = bool()
    bool_1 = True
    dict_0 = dict()
    dict_1 = {'dict_1_key_0': str_0, 'dict_1_key_1': str_1, 'dict_1_key_2': str_2}
    var_0 = get_vars_from_path(str_0, str_0, dict_0, str_0)
    var_1 = get_vars_from_path(dict_0, bool_0, bool_1, bool_1)

# Generated at 2022-06-25 14:23:52.300106
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    os.environ['ANSIBLE_INVENTORY'] = 'ansible/inventory/dynamic.yml'
    sources = []
    sources.append('ansible/inventory/dynamic.yml')
    entities = ['all']
    stage = 'inventory'
    var_0 = get_vars_from_inventory_sources(sources, entities, stage)

# Generated at 2022-06-25 14:23:54.354992
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    display.display('UnitTest: %s' % (test_get_vars_from_path.__name__), color='blue')
    test_case_0()

# Generated at 2022-06-25 14:24:20.725076
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    try:
        unit_test_msg = 'Function `get_vars_from_path` exists and expected type is `function`'
        assert hasattr(get_vars_from_path, '__call__'), unit_test_msg
        unit_test_msg = 'Function `get_vars_from_path` exists and expected type is `function`'
        assert callable(get_vars_from_path), unit_test_msg
    except AssertionError:
        display.error(unit_test_msg)
        raise



# Generated at 2022-06-25 14:24:24.207837
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = ''
    dict_0 = dict()
    dict_0 = get_vars_from_path(str_0, str_0, str_0, str_0)


# Generated at 2022-06-25 14:24:26.804989
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = ''
    list_0 = []
    str_1 = '0'
    var_0 = get_vars_from_path(str_0, str_0, list_0, str_1)

# Generated at 2022-06-25 14:24:33.490875
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    loader = 'a'
    sources = ['b']
    entities = ['c']
    stage = 'd'

    var_0 = get_vars_from_inventory_sources(loader, sources, entities, stage)

    var_1 = get_vars_from_inventory_sources(loader, sources, entities, stage)

    var_2 = get_vars_from_inventory_sources(loader, sources, entities, stage)

    var_3 = get_vars_from_inventory_sources(loader, sources, entities, stage)

    var_4 = get_vars_from_inventory_sources(loader, sources, entities, stage)


# Generated at 2022-06-25 14:24:36.578747
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = ''
    var_0 = get_vars_from_path(str_0, str_0, str_0, str_0)


# Generated at 2022-06-25 14:24:47.333755
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = ''
    class Plugin:
        def get_vars(self, loader, path, entities):
            return
        def get_group_vars(self, arg_0):
            return
        def get_host_vars(self, arg_1):
            return
    #Plugin.get_vars = get_plugin_vars(str_0, Plugin, str_0, str_0)
    Plugin._load_name = 'test_0'
    Plugin._original_path = 'test_1'
    #Plugin.has_option = [Plugin, Plugin, 'stage']
    #Plugin.get_option = [Plugin, 'stage']
    class Host:
        name = ''
    #Host.name = 'test_2'
    #Host.name = 'test_3'
    var_0 = get_

# Generated at 2022-06-25 14:24:53.565634
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    path = 'C:\\Users\\astrid\\Documents\\GitHub\\spark-ansible\\ansible-plugins\\callbacks\\default.py'
    entities = ['C:\\Users\\astrid\\Documents\\GitHub\\spark-ansible\\ansible-plugins\\callbacks\\default.py']
    stage = 'default.py'
    var_1 = get_vars_from_path('C:\\Users\\astrid\\Documents\\GitHub\\spark-ansible\\ansible-plugins\\callbacks\\default.py', path, entities, stage)


# Generated at 2022-06-25 14:24:56.231861
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    path = os.path.join(os.path.dirname(__file__), '..', '..', 'module_utils', 'basic.py')
    data = get_vars_from_path(None, path, None, None)
    assert data
    assert isinstance(data, dict)

# Generated at 2022-06-25 14:24:59.357550
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    str_0 = ''
    var_0 = get_plugin_vars(str_0, str_0, str_0, str_0)
    assert var_0 == {}



# Generated at 2022-06-25 14:25:10.361977
# Unit test for function get_vars_from_path

# Generated at 2022-06-25 14:25:42.125564
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    # test 'loader' type
    try:
        get_vars_from_path(0, '', '', '')
        display.error("Expected TypeError: Argument 'loader' has incorrect type (expected str, got int).")
    except TypeError:
        pass


    # test 'path' type
    try:
        get_vars_from_path('', 0, '', '')
        display.error("Expected TypeError: Argument 'path' has incorrect type (expected str, got int).")
    except TypeError:
        pass


    # test 'entities' type
    try:
        get_vars_from_path('', '', 0, '')
        display.error("Expected TypeError: Argument 'entities' has incorrect type (expected str, got int).")
    except TypeError:
        pass