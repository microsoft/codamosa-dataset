

# Generated at 2022-06-25 14:15:49.710609
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    pass


# Generated at 2022-06-25 14:15:51.921637
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    int_0 = -2100
    set_0 = {int_0, int_0}
    var_0 = get_vars_from_path(int_0, set_0, set_0, set_0)


# Generated at 2022-06-25 14:15:56.035017
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    set_1 = {'enabled', 'enabled'}
    list_0 = [set_1, 'enabled']
    str_0 = ""
    test = get_vars_from_path(str_0, list_0, list_0, str_0)


# Generated at 2022-06-25 14:16:05.103855
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    var_0 = get_vars_from_path(dict(), '', '', str())
    var_1 = get_vars_from_path(dict(), '', '', str())
    assert var_0 == var_1
    var_0 = get_vars_from_path(dict(), '', '', str())
    var_1 = get_vars_from_path(dict(), '', '', str())
    assert var_0 == var_1
    var_0 = get_vars_from_path(dict(), '', '', str())
    var_1 = get_vars_from_path(dict(), '', '', str())
    assert var_0 == var_1
    var_0 = get_vars_from_path(dict(), '', '', str())
    var_1 = get_v

# Generated at 2022-06-25 14:16:07.685471
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    int_0 = -100
    set_0 = {int_0, int_0}
    var_0 = get_vars_from_path(int_0, set_0, set_0, set_0)


# Generated at 2022-06-25 14:16:08.194431
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert True

# Generated at 2022-06-25 14:16:11.793105
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    kwargs = {}
    entities = kwargs['entities'] = {entities, entities}
    loader = kwargs['loader'] = {}
    stage = kwargs['stage'] = {stage, stage}
    int_0 = kwargs['path'] = {}
    var_0 = get_vars_from_path(**kwargs)



# Generated at 2022-06-25 14:16:15.903155
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    int_0 = -2100
    set_0 = {int_0, int_0}
    int_1 = -2980
    set_1 = {int_1, int_1}
    var_0 = get_vars_from_path(int_0, set_0, set_0, set_1)


# Generated at 2022-06-25 14:16:21.858410
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    int_0 = -3
    list_0 = [test_get_vars_from_path, test_get_vars_from_path]
    int_1 = 3
    str_0 = 'get_vars_from_path'
    var_0 = get_vars_from_path(int_0, list_0, list_0, int_1)
    var_1 = get_vars_from_path(list_0, test_get_vars_from_path, str_0, int_1)

# Generated at 2022-06-25 14:16:26.415783
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.vars import vars_plugin
    vars_plugin_0 = vars_plugin

    vars_plugin_0.get_vars()
    int_0 = -2890
    set_0 = {int_0, int_0}
    set_1 = {int_0, int_0}
    var_0 = get_vars_from_path(vars_plugin_0, set_0, set_1, int_0)
    assert var_0 == {}


# Generated at 2022-06-25 14:16:34.318508
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    data = 'pc'
    loader = 'Djp'
    path = 'pc'
    entities = 'R7'
    var_1 = get_vars_from_path(loader, path, entities, data)
    print(var_1)


# Generated at 2022-06-25 14:16:41.087598
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    mock_loader = 'loader'
    mock_path = 'path'
    mock_entities = 'entities'
    mock_stage = 'stage'
    mock_data = 'data'

    vars_plugin_list = MockVarsPluginList(
        vars_plugin_list=[
            MockVarsPlugin({'_load_name': 'load_name_1'}),
            MockVarsPlugin({'_load_name': 'load_name_2'}),
            MockVarsPlugin({'_load_name': 'load_name_3'})
        ]
    )
    vars_loader = MockVarsLoader(mock_vars_plugin_list=vars_plugin_list)

# Generated at 2022-06-25 14:16:43.330338
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    result = get_vars_from_path(1, 2, 3, 4)
    assert result is None


# Generated at 2022-06-25 14:16:54.884232
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.vars import combine_vars
    from ansible.inventory.plugin import InventoryPlugin
    from ansible.plugins.loader import vars_loader
    
    # Set up object HOSTS with attribute _hosts and default value of empty list
    HOSTS = type('', (object,), dict(_hosts=[]))
    # Set up object GROUPS with attribute _groups and default value of empty list
    GROUPS = type('', (object,), dict(_groups=[]))
    
    display.verbosity = 3
    
    def test_get_vars(self, loader, path, entities):
        if not hasattr(self, 'vars'):
            self.vars = {}
            
        if not path in self.vars:
            self.vars[path] = {}
            

# Generated at 2022-06-25 14:16:56.611195
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert get_vars_from_path(int, int, int, int)


# Generated at 2022-06-25 14:17:05.450238
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    var_0 = get_vars_from_path(int_0, int_0, int_0, int_0)
    int_1 = -100
    var_1 = get_vars_from_path(int_1, int_1, int_1, int_1)
    int_2 = -100
    var_2 = get_vars_from_path(int_2, int_2, int_2, int_2)
    int_3 = -100
    var_3 = get_vars_from_path(int_3, int_3, int_3, int_3)
    int_4 = -100
    var_4 = get_vars_from_path(int_4, int_4, int_4, int_4)
    int_5 = -100
    var_5

# Generated at 2022-06-25 14:17:08.845225
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    int_0 = -100
    var_0 = get_vars_from_path(int_0, int_0, int_0, int_0)


# Generated at 2022-06-25 14:17:11.597983
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    int_0 = -100
    var_0 = get_vars_from_path(int_0, int_0, int_0, int_0)



# Generated at 2022-06-25 14:17:16.278596
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    int_0 = -100
    str_0 = "hello"
    vars = get_vars_from_path(int_0, int_0, int_0, int_0)
    print(vars)

if __name__ == "__main__":
    test_get_vars_from_path()
    test_case_0()

# Generated at 2022-06-25 14:17:19.791593
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    var_0 = get_vars_from_path(int(0), int(0), int(0), int(0))
    assert isinstance(var_0, dict)


# Generated at 2022-06-25 14:17:27.233602
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    int_0 = -100
    var_0 = get_vars_from_path(int_0, int_0, int_0, "inventory")


# Generated at 2022-06-25 14:17:30.027788
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    host = Host('localhost')
    loader = None
    plugin = None
    path = 'my_path'
    entities = host
    var_0 = get_plugin_vars(loader, plugin, path, entities)


# Generated at 2022-06-25 14:17:31.260449
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 14:17:41.418948
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    var_0 = get_vars_from_path(loader, path, entities, stage)
    var_0 = get_vars_from_path(loader, path, entities, stage)
    var_0 = get_vars_from_path(loader, path, entities, stage)
    var_0 = get_vars_from_path(loader, path, entities, stage)
    var_0 = get_vars_from_path(loader, path, entities, stage)
    var_0 = get_vars_from_path(loader, path, entities, stage)
    var_0 = get_vars_from_path(loader, path, entities, stage)

# Generated at 2022-06-25 14:17:50.440823
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    int_0 = 2
    int_1 = 2
    int_2 = -1000
    int_3 = -1000
    int_4 = -1000
    int_5 = -1000
    int_6 = -1000
    int_7 = -1000
    int_8 = -1000
    int_9 = -1000

    var_0 = get_vars_from_path(int_0, int_1, int_2, int_3)

    var_1 = hosts_vars_from_inventory(int_4)

    var_2 = get_vars_from_inventory_sources(int_5, int_6, int_7, int_8)

    assert(var_0 == int_9)
    assert(var_1 == int_9)
    assert(var_2 == int_9)



# Generated at 2022-06-25 14:17:53.212874
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    int_0 = -100
    var_0 = get_vars_from_path(int_0, int_0, int_0, int_0)
    var_1 = get_vars_from_path(int_0, int_0, var_0, int_0)


# Generated at 2022-06-25 14:17:55.662513
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    try:
        get_vars_from_path(0, 0, 0, 0)
    except:
        pass


# Generated at 2022-06-25 14:18:06.917264
# Unit test for function get_plugin_vars

# Generated at 2022-06-25 14:18:08.883033
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    var_1 = get_vars_from_path(0,0,0,0)
    print("1")


# Generated at 2022-06-25 14:18:13.659165
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    try:
        from ansible.plugins.vars import builtin
        import ansible.inventory.host
        import ansible.inventory.group
        import ansible.module_utils.six
        test_case_0()
    except (AnsibleError, AssertionError) as e:
        display.error('Assertion failed : %s' % e)
        ansible.module_utils.six.reraise(AssertionError, AssertionError(e), sys.exc_info()[2])

# Generated at 2022-06-25 14:18:23.063985
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    int_0 = -100
    var_0 = get_vars_from_path(int_0, int_0, int_0, int_0)
    assert(var_0 == {})


# Generated at 2022-06-25 14:18:27.487685
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Constants:
    N_ITERATIONS = 1000
    # Variable:
    test_result = None

    # loop over multiple numbers of iterations
    for _ in range(N_ITERATIONS):
        # run the test case and check if output is as expected
        test_result = test_case_0()
        assert test_result.actual == test_result.expected

# Generated at 2022-06-25 14:18:30.652977
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    int_0 = -20
    var_0 = get_vars_from_path(int_0, int_0, int_0, int_0)
    var_1 = get_vars_from_path(int_0, int_0, int_0, int_0)
    assert var_0 != var_1


# Generated at 2022-06-25 14:18:32.849143
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    int_1 = -100
    str_0 = '0giYdgw_7'
    var_0 = get_vars_from_path(int_1, str_0, int_1, int_1)
    assert str_0 == var_0['i']


# Generated at 2022-06-25 14:18:36.096052
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Stores arbitrary value for int input var_0
    int_0 = 0

    # Stores arbitrary value for int input var_1
    int_1 = 0

    # Stores arbitrary value for int input var_2
    int_2 = 0

    # Stores arbitrary value for int input var_3
    int_3 = 0

    var_0 = get_vars_from_path(int_0, int_1, int_2, int_3)


# Generated at 2022-06-25 14:18:38.538370
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    int_0 = -100
    var_0 = get_plugin_vars(int_0, int_0, int_0, int_0)


# Generated at 2022-06-25 14:18:40.524100
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert get_vars_from_path(0, 0, 0, 0) is None


# Generated at 2022-06-25 14:18:45.187540
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    loader = "Loader"
    path = "./test_runner/test_modules/test_collect.py"
    entities = ["a", "b"]
    stage = "inventory"

    res = get_vars_from_path(loader, path, entities, stage)
    assert dict(res) == dict({'a': 'A', 'b': 'B'})

# Generated at 2022-06-25 14:18:56.658145
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    a0 = dict()
    a1 = dict()
    a2 = dict()
    a3 = -64
    r0 = get_vars_from_path(a0, a1, a2, a3)
    assert r0 == dict()
    a0 = dict()
    a1 = dict()
    a2 = dict()
    a3 = -39
    r0 = get_vars_from_path(a0, a1, a2, a3)
    assert r0 == dict()
    a0 = dict()
    a1 = dict()
    a2 = dict()
    a3 = -32
    r0 = get_vars_from_path(a0, a1, a2, a3)
    assert r0 == dict()
    a0 = dict()
    a1 = dict()

# Generated at 2022-06-25 14:19:01.549425
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    func_name = 'ansible.module_utils.vars_plugins.get_vars_from_path'
    # Create the required inputs
    stage = 'start'
    entities = 'hosts'
    plugin = 'vars_plugins'

    try:
        result = get_vars_from_path(stage, plugin, entities, entities)
    except Exception:
        result = 'Exception'
    assert result == 'Exception'


# Generated at 2022-06-25 14:19:11.405828
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    var_0 = get_plugin_vars(int_0, int_0, int_0, int_0)
    assert var_0 is None  # get_plugin_vars should return None if no condition is met



# Generated at 2022-06-25 14:19:19.540230
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    with patch.object(Display, "warning") as mock_warning:
        int_0 = 0
        int_1 = 1
        int_minus_1 = -1
        str_0 = "str1"
        str_1 = "str2"
        str_minus_1 = "str3"
        var_0 = get_vars_from_path(int_0, int_0, int_0, int_0)
        var_1 = get_vars_from_path(int_1, int_1, int_1, int_1)
        var_minus_1 = get_vars_from_path(int_minus_1, int_minus_1, int_minus_1, int_minus_1)

# Generated at 2022-06-25 14:19:27.655085
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    int_1 = 1
    int_100 = 100
    str_100 = "100"
    int_5000 = 5000
    str_5000 = "5000"
    int_0 = 0
    str_0 = "0"
    list_1 = [int_1]
    list_0_100_5000 = [int_0, int_100, int_5000]
    int_neg_1 = -1
    str_neg_1 = "-1"
    int_neg_100 = -100
    str_neg_100 = "-100"
    int_neg_5000 = -5000
    str_neg_5000 = "-5000"
    list_neg_1_neg_100_neg_5000 = [int_neg_1, int_neg_100, int_neg_5000]
    int_1000 = 1000
    int_1_

# Generated at 2022-06-25 14:19:29.066043
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert get_vars_from_path('loader', 'path', 'entities', 'stage') == {}


# Generated at 2022-06-25 14:19:31.803331
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    assert get_plugin_vars(0, 0, 0, 0)


# Generated at 2022-06-25 14:19:33.524916
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert get_vars_from_path == get_vars_from_path


# Generated at 2022-06-25 14:19:35.994286
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    int_0 = -100
    var_0 = get_vars_from_path(int_0, int_0, int_0, int_0)



# Generated at 2022-06-25 14:19:46.149793
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    int_0 = 100
    int_1 = 1
    int_2 = 4
    str_0 = "abc"
    str_1 = "abc"
    str_2 = "abc"
    str_3 = "abc"
    plugin_0 = get_vars_from_path(int_0, int_0, int_0, int_0)
    plugin_1 = get_vars_from_path(int_0, int_0, int_0, int_0)
    plugin_2 = get_vars_from_path(int_0, int_0, int_0, int_0)
    plugin_3 = get_vars_from_path(int_0, int_0, int_0, int_0)

# Generated at 2022-06-25 14:19:53.711490
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # get_vars_from_path(loader, path, entities, stage):
    test_loader = None
    test_path = None
    test_entities = None
    test_stage = None
    # Var 0
    int_0 = -100
    var_0 = get_vars_from_path(int_0, int_0, int_0, int_0)

    assert var_0 == None, "var_0 == '%s', expected None" % var_0
    # Var 1
    var_1 = vars_loader.all()
    var_1 = list(var_1)
    # Var 2
    str_0 = 'VARIABLE_PLUGINS_ENABLED'
    var_2 = C.VARIABLE_PLUGINS_ENABLED
    # Var 3
   

# Generated at 2022-06-25 14:19:55.794038
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    var = 'Linux'
    int_0 = -100
    var_0 = get_vars_from_path(int_0, int_0, int_0, int_0)



# Generated at 2022-06-25 14:20:03.038348
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    int_0 = -100
    var_0 = get_vars_from_inventory_sources(int_0, int_0, int_0, int_0)

# Generated at 2022-06-25 14:20:07.923236
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    module_result = AnsibleModule(
        argument_spec=dict(
            int_0=dict(type='int', required=False, default=0)
        )
    )

    # Test path parameter
    int_0 = module_result.params['int_0']
    function_result = get_vars_from_path(int_0, int_0, int_0, int_0)

    assert func_result == 'value'

# Generated at 2022-06-25 14:20:12.232115
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    int_0 = -100
    var_0 = get_vars_from_path(int_0, int_0, int_0, int_0)
    var_1 = get_vars_from_path(int_0, int_0, int_0, int_0)
    assert (var_0 != var_1)


# Generated at 2022-06-25 14:20:23.106221
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    my_data0 = {
        'plugin_var1': 'plugin_var1_value',
        'plugin_var2': 'plugin_var2_value',
    }

    class FakePlugin():
        def __init__(self, data):
            self.data = data

        def get_vars(self, loader, path, entities):
            return self.data

    class MockVarsPluginLoader():
        def __init__(self, data):
            self.data = data

        def all(self):
            return [FakePlugin(self.data)]

    loader = MockVarsPluginLoader(my_data0)
    var_0 = get_vars_from_path(loader, 'fake_path', 'fake_entities', 'fake_stage')
    assert var_0 == my_data0, var_0

    my

# Generated at 2022-06-25 14:20:25.022794
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert(test_case_0())

# Generated at 2022-06-25 14:20:26.500977
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert func_0 == func_1


# Generated at 2022-06-25 14:20:31.186634
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    int_0 = 0
    int_0 = -100
    int_1 = -1000
    int_1 = -10000
    int_0 = 0
    int_0 = -100
    int_1 = -1000
    int_1 = -10000
    int_0 = 0


# Generated at 2022-06-25 14:20:33.445865
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    entities = [
        Host('host-0'),
        Host('host-1')
    ]

    ansible_vars = get_vars_from_path(None, '/path/to/file', entities, 'inventory')

    assert ansible_vars == {}

    display.display('testing get_vars_from_path')



# Generated at 2022-06-25 14:20:34.011066
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert True

# Generated at 2022-06-25 14:20:41.508069
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    int_0 = -100
    dict_0 = {
        'list_0': [1, 2, 3],
        'list_1': [1, 2, 3],
        'list_2': ['ansible_*', 'ansible_*', 'ansible_*'],
    }
    dict_0 = get_vars_from_path(int_0, int_0, int_0, int_0)
    assert dict_0 == {
        'list_0': [1, 2, 3],
        'list_1': [1, 2, 3],
        'list_2': ['ansible_*', 'ansible_*', 'ansible_*'],
    }


# Generated at 2022-06-25 14:20:54.006460
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    # Stub code for plugin.get_vars
    # Stub code for plugin.get_host_vars
    # Stub code for plugin.get_group_vars
    # Stub code for plugin.run
    # Stub code for AnsibleError
    pass



# Generated at 2022-06-25 14:20:59.659575
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    # Mock class for Host
    class Host(object):
        def __init__(self, name):
            self.name = name

    test_host = Host('test')

    loader = 1;
    path = 2;
    entities = [test_host]
    stage = 'inventory'

    # The variable to test
    var_0 = get_vars_from_path(loader, path, entities, stage)


# Generated at 2022-06-25 14:21:08.988827
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    vars_plugin_list = vars_loader.all()
    has_stage = hasattr(vars_plugin_list, 'get_option') and vars_plugin_list.has_option('stage')

    # if a plugin-specific setting has not been provided, use the global setting
    # older/non shipped plugins that don't support the plugin-specific setting should also use the global setting
    use_global = (has_stage and vars_plugin_list.get_option('stage') is None) or not has_stage

    if use_global:
        C.RUN_VARS_PLUGINS == 'demand' and stage == 'inventory'
    elif has_stage and vars_plugin_list.get_option('stage') not in ('all', stage):
        pass

    pass



# Generated at 2022-06-25 14:21:21.164111
# Unit test for function get_vars_from_path

# Generated at 2022-06-25 14:21:25.551260
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # set up environment
    int_0 = -100
    var_0 = get_vars_from_path(int_0, int_0, int_0, int_0)
    # perform check
    assert (var_0 == {})


# Generated at 2022-06-25 14:21:35.150998
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    source_0 = os.path.join(os.path.dirname(__file__), 'fixtures',
                            'vars_plugin_var_a.yml')
    source_1 = os.path.join(os.path.dirname(__file__), 'fixtures',
                            'vars_plugin_var_b.yml')
    expected_0 = {'var_a': 'var_a_value'}
    expected_1 = {'var_b': 'var_b_value'}

    # Test with vars_plugin_var_a
    result_0 = get_vars_from_path(1, source_0, 1, 1)
    assert result_0 == expected_0, "Result does not match expected"
    # Test with vars_plugin_var_b
    result_1

# Generated at 2022-06-25 14:21:37.373285
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    int_0 = -100
    assert(get_vars_from_path(int_0, int_0, int_0, int_0) == {})
    assert(get_vars_from_path(int_0, int_0, int_0, int_0) == {})


# Generated at 2022-06-25 14:21:42.286701
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    int_0 = -100
    var_0 = get_vars_from_path(int_0, int_0, int_0, int_0)
    int_1 = 200
    var_1 = get_vars_from_path(int_1, int_1, int_1, int_1)
    var_2 = get_vars_from_path(var_1, int_0, var_1, var_0)
    var_3 = get_vars_from_path(var_2, var_2, var_2, var_1)
    var_4 = get_vars_from_path(var_3, int_0, var_0, var_1)

# Generated at 2022-06-25 14:21:44.443229
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    try:
        assert test_case_0() == 'Pass'
    except AssertionError as e:
        print(e)
        print('Testcase 0 failed')



# Generated at 2022-06-25 14:21:53.092183
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    print("--- Testing test_get_vars_from_path ---")
    # Testing conditions for if statements (line 21)
    if get_vars_from_path(get_vars_from_path, get_vars_from_path, get_vars_from_path, get_vars_from_path):
        print("Test 0: True")
    else:
        print("Test 0: False")
    try:
        int_0 = -100
        get_vars_from_path(int_0, int_0, int_0, int_0)
    except AnsibleError as e:
        print("Test 1: AnsibleError exception because int_0 is not a loader object")

# Generated at 2022-06-25 14:22:04.898713
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    if False:
        display.warning('Running get_vars_from_path unit test')
        display.vv('Running get_vars_from_path unit test')


# Generated at 2022-06-25 14:22:07.485411
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    int_0 = -100
    path = '/etc/group'
    entities = '[' + path + ']'
    views = get_vars_from_path(int_0, path, entities, int_0)
    assert type(views) == dict, "get_vars_from_path: Expected type is dict but got %s" % (type(views))


# Generated at 2022-06-25 14:22:11.850229
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    int_0 = -100
    var_0 = get_vars_from_path(int_0, int_0, int_0, int_0)
    assert var_0 == dict()


# Generated at 2022-06-25 14:22:19.052558
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    int_0 = Fixture_Variables.int_0

    var_0 = get_vars_from_path(int_0, int_0, int_0, int_0)
    var_1 = get_vars_from_path(int_0, int_0, int_0, int_0)
    var_2 = get_plugin_vars(int_0, var_1, int_0, int_0)
    var_3 = get_plugin_vars(int_0, var_1, int_0, int_0)

    assert var_2 == var_3

# Generated at 2022-06-25 14:22:23.023113
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    int_0 = 0
    str_0 = str()
    bool_0 = bool()
    float_0 = float()
    var_0 = test_case_0()
    print("Test passed!")



# Generated at 2022-06-25 14:22:25.440472
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    var = get_vars_from_path("", "", "", "")
    result = {}
    assert result == var


# Generated at 2022-06-25 14:22:26.748669
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    get_vars_from_path(0, 0, 0, 0)

# Generated at 2022-06-25 14:22:29.517991
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    int_0 = -100
    var_0 = get_vars_from_path(int_0, int_0, int_0, int_0)


# Generated at 2022-06-25 14:22:30.190667
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert True



# Generated at 2022-06-25 14:22:35.027164
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    # Run tests with ints as inputs
    int_0 = 0
    int_1 = 1
    int_100 = 100
    int_100_neg = -100
    # Test with string inputs
    str_0 = ""
    str_1 = "1"


# Generated at 2022-06-25 14:22:46.789876
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert get_vars_from_path(loader, path, entities, stage)

# Generated at 2022-06-25 14:22:54.361986
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    # unit test for calling the get_vars_from_inventory_sources function with a single argument
    int_0 = -100
    var_0 = get_vars_from_inventory_sources(int_0, int_0, int_0, int_0)

    if not isinstance(var_0, dict):
        raise ValueError('var_0 returns value of type %s, expected type is %s' % (type(var_0), 'dict'))

    if var_0:
        raise ValueError('var_0 returned value "%s", expected "%s"' % (var_0, ''))

    # unit test for calling the get_vars_from_inventory_sources function with a single argument
    int_0 = -100
    int_1 = -101
    int_2 = -102

# Generated at 2022-06-25 14:22:55.214230
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    test_case_0()


# Generated at 2022-06-25 14:22:56.118752
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    test_case_0()

# Generated at 2022-06-25 14:23:02.985611
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Create a host object
    var_0 = Host()
    # Call to function get_vars_from_path
    var_0 = get_vars_from_path(var_0, var_0, var_0, var_0)
    assert var_0 == {}, 'Expected {}, received "{}"'.format({}, var_0)

# Unit tests for function get_vars_from_inventory_sources

# Generated at 2022-06-25 14:23:10.779532
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    int_0 = -100
    var_0 = get_vars_from_path(int_0, int_0, int_0, int_0)
    assert var_0 == {}

    var_1 = get_vars_from_path(int_0, int_0, int_0, int_0)
    assert var_1 == {}

    var_2 = get_vars_from_path(int_0, int_0, int_0, int_0)
    assert var_2 == {}

    var_3 = get_vars_from_path(int_0, int_0, int_0, int_0)
    assert var_3 == {}

    var_4 = get_vars_from_path(int_0, int_0, int_0, int_0)
    assert var_

# Generated at 2022-06-25 14:23:13.958390
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    try:
        test_case_0()
    except Exception as err:
        print(err)

if __name__ == '__main__':
    test_get_vars_from_path()

# Generated at 2022-06-25 14:23:17.659869
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()


# Generated at 2022-06-25 14:23:25.326679
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    int_0 = -100
    str_0 = 'test'
    list_0 = ['test', 'test', 'test']
    list_1 = []
    dict_0 = {}

    # py2 and py3 have different type
    # if hasattr(int_0, '__int__'):
    #     int_0 = int_0.__int__()
    if hasattr(str_0, '__str__'):
        str_0 = str_0.__str__()
    if hasattr(list_0, '__iter__'):
        list_0 = list(list_0)
    if hasattr(list_1, '__iter__'):
        list_1 = list(list_1)
    if hasattr(dict_0, '__dict__'):
        dict_0 = dict_

# Generated at 2022-06-25 14:23:27.357218
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    test_case_0()



# Generated at 2022-06-25 14:23:39.897438
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    int_0 = -100
    int_1 = -100
    int_2 = -100
    get_plugin_vars(int_0, int_1, int_2, int_0)


# Generated at 2022-06-25 14:23:47.505374
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    int_0 = 0
    assert get_vars_from_path('', '', '', '') == ''
    assert get_vars_from_path(int_0, '', '', '') == ''
    assert get_vars_from_path('', int_0, '', '') == ''
    assert get_vars_from_path('', '', int_0, '') == ''
    assert get_vars_from_path('', '', '', int_0) == ''



# Generated at 2022-06-25 14:23:50.426224
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    int_0 = -100
    var_0 = get_vars_from_path(int_0, int_0, int_0, int_0)
    assert var_0 == {}, "Incorrect variable"


# Generated at 2022-06-25 14:23:51.977561
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert test_case_0() == None


# Generated at 2022-06-25 14:23:54.354048
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    int_0 = -100
    var_0 = get_vars_from_path(int_0, int_0, int_0, int_0)
    assert var_0 is dict()



# Generated at 2022-06-25 14:24:04.715178
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    import os

    # Create dynamic/static instance of 'AnsibleVars' class
    # with parametrized constructor values in order to test
    # method 'get_vars_from_path'

    # Create dynamic/static instance of 'VarsModule' class
    # with parametrized constructor values in order to test
    # method 'get_vars_from_path'
    var_12 = 'test'
    var_13 = 'test'
    var_14 = True
    obj_4 = VarsModule(var_12, var_13, var_14)

    # Invoke method 'get_vars_from_path' on objects
    # 'obj_0' and 'obj_4'
    assert test_case_0() == var_0



# Generated at 2022-06-25 14:24:07.228934
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # assert to guard against hard-coded values in function
    assert get_vars_from_path(0, 0, 0, 0) == {}, "Failed to set values correctly"


# Generated at 2022-06-25 14:24:13.840717
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    inventory_sources = ['ansible/inventory/hosts/test_var_0.yml',
                         'ansible/inventory/group_vars/test.yml']
    entities = ['test_host']
    stage = 'inventory'

    var_0 = get_vars_from_inventory_sources(inventory_sources, entities, stage)


if __name__ == '__main__':
    test_get_vars_from_inventory_sources()

# Generated at 2022-06-25 14:24:15.977238
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    try:
        test_case_0()
    except Exception:
        assert False, "Unhandled exception in test_case_0"


# Generated at 2022-06-25 14:24:25.705528
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.vars.manager import InventoryVarsManager
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import vars_loader
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import strategy_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import test_loader
    from ansible.plugins.loader import shell_loader
    from ansible.plugins.loader import module_loader
    from test.units.loader.test_plugin_loader import TestPluginLoaderV2
    from test.units.loader.test_plugin_loader import TestPluginLoaderV1

    plugin_loader_1 = TestPluginLoaderV1()


# Generated at 2022-06-25 14:24:46.593829
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    def test_1():
        int_0 = -40
        var_0 = get_vars_from_path(int_0, int_0, int_0, int_0)

    def test_2():
        int_0 = -43
        var_0 = get_vars_from_path(int_0, int_0, int_0, int_0)

    def test_3():
        int_0 = -34
        var_0 = get_vars_from_path(int_0, int_0, int_0, int_0)

    def test_4():
        int_0 = -14
        var_0 = get_vars_from_path(int_0, int_0, int_0, int_0)

    def test_5():
        int_0 = -6


# Generated at 2022-06-25 14:24:52.666394
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Test the default case
    try:
        assert True
        int_0 = -100
        var_0 = get_vars_from_path(int_0, int_0, int_0, int_0)
    except:
        assert False

    # Test the case with invalid parameters
    try:
        assert True
        int_0 = -100
        var_0 = get_vars_from_path(int_0, int_0, int_0, int_0)
        assert False
    except:
        assert True



# Generated at 2022-06-25 14:24:55.104552
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    int_0 = -100
    int_1 = 100
    var_0 = get_vars_from_path(int_0, int_0, int_0, int_1)
    assert var_0 == {}, "Failed to run test for function get_vars_from_path()"


# Generated at 2022-06-25 14:24:56.753969
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # bool([], True)
    # bool([], False)

    test_case_0()

# Generated at 2022-06-25 14:25:05.177370
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    int_0 = -100
    var_0 = get_plugin_vars(int_0, int_0, int_0, int_0)
    var_1 = get_plugin_vars(int_0, int_0, int_0, int_0)
    var_2 = get_plugin_vars(int_0, int_0, int_0, int_0)
    var_3 = get_plugin_vars(int_0, int_0, int_0, int_0)


# Generated at 2022-06-25 14:25:08.466013
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    int_0 = -100
    var_0 = get_plugin_vars(int_0, int_0, int_0, int_0)
    print(var_0)


# Generated at 2022-06-25 14:25:15.315741
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    int_0 = -100
    int_1 = -99
    int_2 = -98
    int_3 = -97
    int_4 = -96
    int_5 = -95
    int_6 = -94
    int_7 = -93
    int_8 = -92
    int_9 = -91
    var_0 = get_vars_from_path(int_0, int_1, int_2, int_3)


# Generated at 2022-06-25 14:25:20.449108
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    path = 'var_0'
    entities = ['entity_0', 'entity_1', 'entity_2']
    stage = 'start'
    var_0 = get_vars_from_path(path, entities, stage)

    assert var_0 is not 'entity_0'
    assert var_0 is not 'entity_1'
    assert var_0 is not 'entity_2'
    assert var_0 is not 'start'
    assert var_0 is not 'var_0'



# Generated at 2022-06-25 14:25:22.226628
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert isinstance(test_case_0(), dict)


# Generated at 2022-06-25 14:25:23.178333
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    assert get_plugin_vars(2, 3, 4, 5) is None