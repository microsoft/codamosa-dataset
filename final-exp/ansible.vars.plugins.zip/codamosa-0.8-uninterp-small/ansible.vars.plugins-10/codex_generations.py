

# Generated at 2022-06-25 14:15:59.630195
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    loader = None
    path = None
    entities = None
    stage = None
    try:
        test_case_function = get_vars_from_path
        # Try to set up and run the test case
        set_up_test_case(test_case_function)

        # Call the function being tested to run the test case
        test_case_function(loader, path, entities, stage)
        # Get the result of the test case
        result = test_case_function(loader, path, entities, stage)

        tear_down_test_case()

    except Exception as e:
        print(e)
        traceback.print_exc()
        return False

    return True


# Generated at 2022-06-25 14:16:01.513528
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert(get_vars_from_path('loader', 'path', 'entities', 'stage') == {})


# Generated at 2022-06-25 14:16:09.235091
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # get_vars_from_path(loader, path, entities, stage)

    # check the returned value for arg1 == bool()
    bool_0 = bool()
    str_0 = '_uC!am?CS2a\x0cs*(,p?R,'
    float_0 = -1308.7
    var_0 = get_vars_from_path(bool_0, str_0, float_0, str_0)

    # check the returned value for arg1 == True
    bool_0 = True
    str_0 = '_uC!am?CS2a\x0cs*(,p?R,'
    float_0 = -1308.7
    var_0 = get_vars_from_path(bool_0, str_0, float_0, str_0)

   

# Generated at 2022-06-25 14:16:10.021210
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    test_case_0()


# Generated at 2022-06-25 14:16:11.601451
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # AssertionError: expected exception
    with pytest.raises(AssertionError):
        test_case_0()


# Generated at 2022-06-25 14:16:12.363743
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    test_case_0()


# Generated at 2022-06-25 14:16:19.390691
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    str_0 = 'b9_=B\n0Y#\x7fC\x16-?y\x7f\x63\x7f\x08'
    int_0 = -817
    var_0 = get_vars_from_path(str_0, int_0, int_0, str_0)
    str_1 = '2'
    str_2 = ''
    int_1 = -3
    var_1 = get_plugin_vars(str_1, str_2, str_2, int_1)


# Generated at 2022-06-25 14:16:20.461786
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert False, 'Unimplemented Test'


# Generated at 2022-06-25 14:16:22.625567
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert get_vars_from_path(loader=True, path='/etc/yum.repos.d', entities=['\x03c\x0b'], stage='inventory') == {}


# Generated at 2022-06-25 14:16:23.405579
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    assert True



# Generated at 2022-06-25 14:16:31.869540
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'Ot_h^:+g[t%~'
    set_0 = None
    var_0 = get_vars_from_path(str_0, str_0, set_0, str_0)



# Generated at 2022-06-25 14:16:33.814210
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = ',|gK2-iVZ@E}W'
    set_0 = None
    test_case_0()

# Generated at 2022-06-25 14:16:36.931310
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    inventory_0 = get_vars_from_inventory_sources(str_0, str_0, set_0, str_0)
    assert inventory_0 is None
    var_0 = inventory_0
    test_case_0()


# Generated at 2022-06-25 14:16:47.975727
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = '-X^q<'
    set_0 = None
    str_1 = '3k1lr'
    str_2 = 'oX9Y'
    str_3 = "7%M"
    var_0 = get_vars_from_path(str_0, str_1, set_0, str_2)
    var_1 = get_vars_from_path(str_0, str_1, set_0, str_3)
    try:
        var_2 = get_vars_from_inventory_sources(str_0, str_1, set_0, str_2)
    except Exception as exception_0:
        var_2 = exception_0
    var_3 = isinstance(var_2, AnsibleError)
    var_4 = get_vars

# Generated at 2022-06-25 14:16:54.681745
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    loader = ")"
    path = "yP5%4P"
    entities = "inv"
    stage = ")"

    var_0 = get_vars_from_path(loader, path, entities, stage)
    if(var_0 == {}):
        print("var_0 = {0}".format(var_0))
    else:
        print("var_0 = {0}".format("{}"))



# Generated at 2022-06-25 14:17:00.572956
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    str_0 = '[Tt0D'
    str_1 = 'p&:'
    list_0 = []
    list_1 = []
    list_2 = []
    tuple_0 = (list_0, list_1, list_2)
    set_0 = tuple_0
    var_0 = get_vars_from_path(str_0, str_1, set_0, str_1)
    print(var_0)


# Generated at 2022-06-25 14:17:03.777171
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    str_0 = '<|*i|_#'
    list_0 = None
    str_1 = '5&t'
    var_0 = get_plugin_vars(str_0, str_0, str_1, list_0)


# Generated at 2022-06-25 14:17:08.562252
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    path = './test_vars_from_path/path'
    entities = set()
    stage = 'test'
    loader = './test_vars_from_path/loader'

    var_0 = get_vars_from_path(loader, path, entities, stage)
    assert var_0 == {}


# Generated at 2022-06-25 14:17:17.363064
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    vars_plugin_list = list(vars_loader.all())
    for plugin_name in C.VARIABLE_PLUGINS_ENABLED:
        if AnsibleCollectionRef.is_valid_fqcr(plugin_name):
            vars_plugin = vars_loader.get(plugin_name)
            if vars_plugin is None:
                # Error if there's no play directory or the name is wrong?
                continue
            if vars_plugin not in vars_plugin_list:
                vars_plugin_list.append(vars_plugin)


# Generated at 2022-06-25 14:17:23.094249
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    plugin_0 = C()
    plugin_1 = plugin_0
    loader_0 = str()
    path_0 = 'n'
    plugin_2 = plugin_1
    plugin_3 = None
    plugin_3 = get_plugin_vars(loader_0, plugin_2, path_0, plugin_3)


# Generated at 2022-06-25 14:17:29.253669
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert True == True


# Generated at 2022-06-25 14:17:40.726912
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = '~$5`=R,?'
    str_1 = '!9#1]c#-g(0'
    str_2 = '*?|e'
    str_3 = 'Ot_h^:+g[t%~'
    str_4 = 'P:|F?lW'
    str_5 = '~$5`=R,?'
    str_6 = '!9#1]c#-g(0'
    str_7 = '*?|e'
    str_8 = 'Ot_h^:+g[t%~'
    str_9 = 'P:|F?lW'
    str_10 = '~$5`=R,?'
    str_11 = '!9#1]c#-g(0'
    str_

# Generated at 2022-06-25 14:17:49.855970
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    import collections
    import logging
    import sys

    # Setup logging
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    ch = logging.StreamHandler(sys.stdout)
    ch.setLevel(level=logging.DEBUG)
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    ch.setFormatter(formatter)
    logger.addHandler(ch)

    # Test get_vars_from_path
    logger.debug("Test get_vars_from_path")
    str_0 = 'Ot_h^:+g[t%~'

# Generated at 2022-06-25 14:17:51.317593
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert get_vars_from_path(None, None, None, None) == {}

# Generated at 2022-06-25 14:17:52.024751
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    assert True



# Generated at 2022-06-25 14:17:55.096195
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    try:
        # Please enter the code you want to test here:
        test_case_0()

    except Exception as e:
        print(e)
        raise



# Generated at 2022-06-25 14:18:03.691189
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    entities = ['str', 'str', 'str']
    path = '/private/var/folders/f7/srf_rzvs53x34xm2zvffmlc0000gn/T'
    loader = '/private/var/folders/f7/srf_rzvs53x34xm2zvffmlc0000gn/T'
    stage = 'task'

    var_0 = get_vars_from_path(loader, path, entities, stage)
    assert var_0 or True, 'Could not get_vars_from_path'
    test_case_0()


# Generated at 2022-06-25 14:18:10.537819
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    try:
        test_case_0()
    except Exception as err:
        print('Test case 0 failed: ' + str(err))
    else:
        print('Test case 0: get_vars_from_path OK')

# Pre-defined parameters
sources_0 = 'https://raw.githubusercontent.com/ansible/ansible/devel/examples/ansible.cfg'
entities_0 = 'XG8~YWz|iK'
stage_0 = 'ossec'
path_0 = '/etc/ansible/hosts'


# Generated at 2022-06-25 14:18:12.432458
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    assert callable(get_plugin_vars)


# Generated at 2022-06-25 14:18:19.893813
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'Ot_h^:+g[t%~'
    str_1 = 'F/f/G&Z%1{W}B'
    str_2 = '+y-s[0C>O.R+'
    str_3 = '4)JU6m]jb(\^'
    var_x = get_vars_from_path(str_0, str_1, str_2, str_3)
    # TODO: Fix verify.
    # verify.equal(var_x, str_0)

# Generated at 2022-06-25 14:18:31.861833
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    var_0 = 'Ot_h^:+g[t%~'
    var_1 = 'N@t^8u.z/b%c'
    var_2 = 's/p;Xh)k(a^$k'

# Generated at 2022-06-25 14:18:36.397118
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'Ot_h^:+g[t%~'
    assert get_vars_from_path(str_0, str_0, str_0, str_0) == {}
    assert get_vars_from_path(str_0, str_0, str_0, str_0) == {}



# Generated at 2022-06-25 14:18:40.098048
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    path = 'test_path'
    entities = [Host('host_name1'), Host('host_name2')]
    loader = 'loader'
    plugin = 'plugin'
    var_return = get_plugin_vars(loader, plugin, path, entities)
    assert var_return == {}


# Generated at 2022-06-25 14:18:50.853342
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    # make sure we get a helpful message when loading a v1 plugin as a v2 plugin
    data = {
        'plugin_path': 'ansible.builtin.vars_loader',
        'plugin_name': 'vars_plugins',
        '_original_path': 'ansible.builtin.vars_loader.vars_plugins',
        '_load_name': 'vars_plugins.yaml',
    }
    plugin = type('Plugin', (), data)
    loader = type('Loader', (), {})
    path = ''
    entities = ''
    ansible_assert(get_plugin_vars(loader, plugin, path, entities) == AnsibleError("Cannot use v1 type vars plugin vars_plugins from ansible.builtin.vars_loader.vars_plugins"))


# Generated at 2022-06-25 14:18:54.503821
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    try:
        assert not get_plugin_vars(str_0, str_0, str_0, str_0)
    except Exception as e:
        print(e)



# Generated at 2022-06-25 14:19:03.039406
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # No parameters given
    assert get_vars_from_path() == True
    # One parameter given
    assert get_vars_from_path(loader='Ot_h^:+g[t%~') == True
    # Two parameters given
    assert get_vars_from_path(loader='Ot_h^:+g[t%~', path='Ot_h^:+g[t%~') == True
    # Three parameters given
    assert get_vars_from_path(loader='Ot_h^:+g[t%~', path='Ot_h^:+g[t%~', entities='Ot_h^:+g[t%~') == True
    # Four parameters given

# Generated at 2022-06-25 14:19:08.887038
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'Ot_h^:+g[t%~'
    var_0 = get_vars_from_path(str_0, str_0, str_0, str_0)

    str_0 = 'zqp3qw3Tf&'
    var_1 = get_vars_from_path(str_0, str_0, str_0, str_0)

    str_0 = 'J{`o5<5]g"Q'
    var_2 = get_vars_from_path(str_0, str_0, str_0, str_0)

    str_0 = 'Q-wJ_Om+>m'
    var_3 = get_vars_from_path(str_0, str_0, str_0, str_0)



# Generated at 2022-06-25 14:19:11.887263
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    var_0 = get_vars_from_path(7, "test.test", 3, 8)
    assert var_0 == {}


# Generated at 2022-06-25 14:19:14.368862
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    str_0 = 'Ot_h^:+g[t%~'
    var_0 = get_plugin_vars(str_0, str_0, str_0, str_0)


# Generated at 2022-06-25 14:19:21.848819
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from collections import namedtuple

    # Create a fake inventory
    inventory = InventoryManager(loader=DataLoader(), sources='localhost,')
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)

    # Make a fake plugin to test, the test scripts pass the 'entities' parameter
    # as a list of hosts.
    FakePlugin = namedtuple('FakePlugin', ['get_vars'])

    def _get_vars(loader, path, entities):
        # Check that the loader and path are correct
        assert loader._loader_name == 'yaml_loader'
        assert path is 'localhost,'
        # Make sure we got a list of hosts

# Generated at 2022-06-25 14:19:28.261333
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    global test_case_0
    test_case_0()

# Generated at 2022-06-25 14:19:34.170139
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert get_vars_from_path(None, None, None, None) == {}
    assert get_vars_from_path('Ot_h^:+g[t%~', 'Ot_h^:+g[t%~', 'Ot_h^:+g[t%~', 'Ot_h^:+g[t%~') == {}

# Generated at 2022-06-25 14:19:37.451694
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'Ot_h^:+g[t%~'
    var_0 = get_vars_from_path(str_0, str_0, str_0, str_0)



# Generated at 2022-06-25 14:19:47.085566
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'Ot_h^:+g[t%~'
    str_1 = 'n_p,)X[5+`'
    str_2 = '^=h%Imq3/u!'
    str_3 = '^]X9;(|uV>N'
    str_4 = 'U]^b0c%v@(y'
    str_5 = '2sC>zlmwB~'
    str_6 = ''
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    dict_3 = {}

    # Test arguments to function get_vars_from_path
    var_0 = get_vars_from_path(str_0, str_1, str_2, str_3)
    dict_0 = get_vars

# Generated at 2022-06-25 14:19:48.228812
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert get_vars_from_path is not None


# Generated at 2022-06-25 14:19:49.050970
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    pass


# Generated at 2022-06-25 14:19:50.785288
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    print('Running Test...')
    print('Test 1:')
    test_case_0()
    print('Test Complete')

if __name__ == '__main__':
  test_get_vars_from_path()

# Generated at 2022-06-25 14:19:53.821071
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    # Assuming that the function get_plugin_vars is purely internal
    # and therefore doesn't have a test case associated with it,
    # this test case exists only because the call graph evaluator
    # didn't find any callers of the function
    pass


# Generated at 2022-06-25 14:19:56.387457
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    # Test <arguments>
    str_0 = 'Ot_h^:+g[t%~' # <class 'str'>
    var_0 = get_plugin_vars(str_0, str_0, str_0, str_0)



# Generated at 2022-06-25 14:19:58.280184
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'Ot_h^:+g[t%~'
    assert get_vars_from_path(str_0, str_0, str_0, str_0) == {}


# Generated at 2022-06-25 14:20:03.817637
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert True == True

# Generated at 2022-06-25 14:20:12.929503
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert get_vars_from_path is not None
    str_0 = 'Ot_h^:+g[t%~'
    str_1 = 'uM7_f%\x1d.q`'
    str_2 = 'pvB_n\'\x18)jm'
    str_3 = 'W"\x17j&\x1d#Mb'
    str_4 = 'N\x15w2\x0e,=r'
    var_0 = get_vars_from_path(str_0, str_1, str_2, str_3)
    assert var_0 == {}
    var_0 = get_vars_from_path(str_0, str_1, str_2, str_4)
    assert var_0 == {}

# Unit

# Generated at 2022-06-25 14:20:19.745271
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'None'
    str_1 = 'None'
    str_2 = 'Test.txt'
    str_3 = 'Test.txt'
    str_4 = 'Test.txt'
    var_0 = get_vars_from_path(str_0, str_1, str_2, str_3)
    assert (var_0 == str_4)


# Generated at 2022-06-25 14:20:23.655620
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Test case 0
    vars = get_vars_from_path('Ot_h^:+g[t%~', 'Ot_h^:+g[t%~', 'Ot_h^:+g[t%~', 'Ot_h^:+g[t%~')
    assert vars == {}

# Generated at 2022-06-25 14:20:35.045712
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert get_vars_from_path('Ot_h^:+g[t%~', 'Ot_h^:+g[t%~',
                              'Ot_h^:+g[t%~', 'Ot_h^:+g[t%~') is None
    assert get_vars_from_path(
        '/srv/ansible/playbooks/playbooks.branch.9469404.cd4c4d4',
        '/srv/ansible/playbooks/playbooks.branch.9469404.cd4c4d4',
        '/srv/ansible/playbooks/playbooks.branch.9469404.cd4c4d4',
        'Ot_h^:+g[t%~') is None
    assert get_vars_from_path

# Generated at 2022-06-25 14:20:43.035264
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'Ot_h^:+g[t%~'
    str_1 = ':nJP|G[6F5UJ'
    str_2 = 'zm}6ybE)4%4*'
    str_3 = 'eK/W/h8|v[q(B'
    str_4 = ':8@J}=(9X(tJ'
    str_5 = 'be7I1@Fz?YdY'
    str_6 = '2dJ\\}@=Vu]#F'
    str_7 = 'Yhn7pjK:~$+7'
    str_8 = '7@u}eDm-7%uF'
    str_9 = '%+g(#Xl^/sPt'
    str

# Generated at 2022-06-25 14:20:52.639237
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    '''
    Test for get_vars_from_inventory_sources
    '''
    str_0 = 'C,+_'
    str_1 = '}3,^4'
    str_2 = 'ei`5V'
    tuple_0 = (
        str_2,
        )
    tuple_1 = (
        str_1,
        )
    tuple_2 = (
        tuple_0,
        )
    tuple_3 = (
        tuple_0,
        )
    tuple_4 = (
        tuple_1,
        )
    tuple_5 = (
        tuple_2,
        )
    tuple_6 = (
        tuple_3,
        )
    tuple_7 = (
        tuple_4,
        )

# Generated at 2022-06-25 14:20:59.930162
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    str_0 = None
    str_1 = 'ZtD>og(%bXg~e'
    str_2 = """
            ignore:
               - '.*'
            plugins:
              - ovirt
        """
    str_3 = None
    str_4 = 'e}6O-U6p|O6A~S'
    
    var_0 = get_vars_from_path(str_0, str_1, str_2, str_3)
    assert var_0 == str_4

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 14:21:01.244855
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    assert callable(get_plugin_vars)


# Generated at 2022-06-25 14:21:10.314064
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    def test_function(loader, plugin, path, entities):
        # get_vars_from_path(loader, path, entities, stage)
        data = {'host_var': 'host_var'}
        return data
    plugin = vars_loader.get('dummy')
    plugin.get_vars = test_function

    data = get_plugin_vars(None, plugin, 'path', 'entities')
    if data != {'host_var': 'host_var'}:
        print('Failed: function get_plugin_vars - test_get_plugin_vars test#1')
        return
    # Test with path that does not exist.
    data = get_plugin_vars(None, plugin, '/tmp', 'entities')

# Generated at 2022-06-25 14:21:22.939023
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    path = 'Ot_h^:+g[t%~'
    entities = 'Ot_h^:+g[t%~'
    stage = 'Ot_h^:+g[t%~'
    
    loader = ''
    try:
        loader = vars_loader.all()
    except Exception as e:
        print(e)
        loader = ''

    # Call function get_vars_from_path
    try:
        str_0 = get_vars_from_path(loader, path, entities, stage)
    except Exception as e:
        print(e)



# Generated at 2022-06-25 14:21:24.590701
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # TODO: create test for get_vars_from_path
    assert True == True



# Generated at 2022-06-25 14:21:29.766942
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # get_vars_from_path()
    # test case 1
    str_0 = 'Ot_h^:+g[t%~'
    var_0 = get_vars_from_path(str_0, str_0, str_0, str_0)
    assert var_0 == {}



# Generated at 2022-06-25 14:21:32.165780
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Make sure that no error is raised if path is not a string
    assert get_vars_from_path(None, 0, None, None) is not None


# Generated at 2022-06-25 14:21:34.752232
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'cdHrT2V7v*8s'
    var_0 = get_vars_from_path(str_0, str_0, str_0, str_0)



# Generated at 2022-06-25 14:21:35.919327
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # str(0) should return '' in python2
    test_case_0()

# Generated at 2022-06-25 14:21:44.325641
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    str_0 = 'f{nD@5PM5Ja5'
    str_1 = 'Z!'
    str_2 = 'H%cFl9,g+'
    str_3 = '+d*UJw6Ug7P'
    str_4 = '*'
    str_5 = '#'
    str_6 = '_'
    str_7 = '$'
    str_8 = '.'
    str_9 = 'c%+'
    str_10 = '{'
    str_11 = ']'
    str_12 = '^'
    str_13 = ')#'
    str_14 = '|'
    str_15 = '8'
    str_16 = '&'
    str_17 = '}'
    str_18 = '('
    str

# Generated at 2022-06-25 14:21:52.979578
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'Ot_h^:+g[t%~'
    var_0 = get_vars_from_path(str_0, str_0, str_0, str_0)
    # verify if var_0.has_key('vars_plugin_list')
    # assert(False)
    # verify if var_0['vars_plugin_list'].has_key('vars_plugin')
    # assert(False)
    # verify if var_0['vars_plugin_list']['vars_plugin'].has_key('_ansible_module')
    # assert(False)
    # verify if var_0['vars_plugin_list']['vars_plugin']['_ansible_module'].has_key('_ansible_path')
    # assert(False

# Generated at 2022-06-25 14:21:58.348914
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'Ot_h^:+g[t%~'
    str_1 = ':Z:+X~%>|'
    str_2 = 'K{+>>bwfR1'
    str_3 = 'K{+>>bwfR1'
    var_0 = get_vars_from_path(str_0, str_1, str_2, str_3)


# Generated at 2022-06-25 14:21:59.505396
# Unit test for function get_vars_from_path
def test_get_vars_from_path(): # test case for get_vars_from_path
    assert True


# Generated at 2022-06-25 14:22:16.053134
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'e|>!i'
    str_1 = 'Path to a directory to pull YAML files from with a list of variables.'
    str_2 = 'Ot_h^:+g[t%~'
    str_3 = 'Ot_h^:+g[t%~'
    var_0 = get_vars_from_path(str_0, str_1, str_2, str_3)
    assert var_0 == {}

    str_0 = 'e|>!i'
    str_1 = 'Path to a directory to pull YAML files from with a list of variables.'
    str_2 = 'Ot_h^:+g[t%~'
    str_3 = 'Ot_h^:+g[t%~'

# Generated at 2022-06-25 14:22:22.550543
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_1 = '0V0^U6<4u2(=Jb'
    str_2 = 'H_+7Vx{)M<n7VU'
    str_3 = 'B:J#oY+3qxi1fB'
    dict_0 = dict(str_2=str_2)
    dict_1 = dict(str_2=dict_0)
    dict_2 = dict(str_3=dict_1)
    dict_3 = dict(str_1=dict_2)
    dict_4 = dict(str_1=dict_3)
    dict_5 = dict(str_2=dict_0, str_3=dict_1)
    dict_6 = dict(str_1=dict_5)

# Generated at 2022-06-25 14:22:34.186639
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Input parameters
    str_0 = 'Ot_h^:+g[t%~'
    str_1 = 'D5do5)b;'
    str_2 = 'aLi.{z'
    str_3 = 't9}L'
    param_input_array = []
    param_input_array.append(str_0)
    param_input_array.append(str_1)
    param_input_array.append(str_2)
    param_input_array.append(str_3)

    # Expected output
    expected_result = {}
    expected_result['u'] = '.'
    expected_result['v'] = '1'
    expected_result['w'] = 'M'
    expected_result['x'] = '['

    # Perform the test
    result = get

# Generated at 2022-06-25 14:22:37.646694
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    str_0 = 'Ot_h^:+g[t%~'
    var_0 = get_plugin_vars(str_0, str_0, str_0, str_0)
    assert isinstance(var_0, dict)


# Generated at 2022-06-25 14:22:42.611196
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # test_case_0
    str_0 = 'Ot_h^:+g[t%~'
    var_0 = get_vars_from_path(str_0, str_0, str_0, str_0)



# Generated at 2022-06-25 14:22:46.748413
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    loader = 'dummy_loader'
    plugin = 'dummy_plugin'
    path = 'dummy_path'
    entities = 'dummy_entities'
    var_0 = get_plugin_vars(loader, plugin, path, entities)
    assert var_0 == 'dummy_result'


# Generated at 2022-06-25 14:22:54.361179
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'Ot_h^:+g[t%~'
    var_0 = get_vars_from_path(str_0, str_0, str_0, str_0)
    assert var_0 == Undefined
    str_1 = '_=^w|<5p%)J(>9'
    var_1 = get_vars_from_path('U6o80%6R`MX<8n^', str_1, str_1, str_1)
    assert var_1 == Undefined
    str_2 = '4]sHA<^j{!pX;M'
    var_2 = get_vars_from_path('J|KjhZO_m;)Q+{[', str_2, str_2, str_2)
    assert var_

# Generated at 2022-06-25 14:22:56.925615
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    display.info("TEST_GET_VARS_FROM_PATH: started")

    display.info("TEST_GET_VARS_FROM_PATH: Ended")

# Generated at 2022-06-25 14:22:59.589095
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert get_vars_from_path(str_0, str_0, str_0, str_0) == var_0

# Generated at 2022-06-25 14:23:04.221872
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = '2fC8CU'
    dict_0 = {}
    dict_1 = {'': 'P9', '3nT': 'Svk8I'}
    assert get_vars_from_path(dict_0, dict_0, dict_0, str_0) == dict_1


# Generated at 2022-06-25 14:23:13.950554
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert get_vars_from_path(str, str, str, str)


# Generated at 2022-06-25 14:23:14.501558
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    test_case_0()

# Generated at 2022-06-25 14:23:20.855525
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = '8W"n"gv_A^'
    str_1 = ''
    str_2 = '#>|2.e\x7f$/G%'
    str_3 = 'Ot_h^:+g[t%~'
    str_4 = '3OTq3H7^Tw'

    var_0 = get_vars_from_path(str_4, str_4, str_4, str_4)

    var_1 = get_vars_from_path(str_0, str_1, str_3, str_2)


# Generated at 2022-06-25 14:23:23.737472
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    var_0 = get_vars_from_path(None, None, None, None)
    assert var_0 == {}

    var_1 = get_vars_from_inventory_sources(None, None, None, None)
    assert var_1 == {}

# Generated at 2022-06-25 14:23:35.295734
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    var_0 = 'l'
    var_1 = 'D}Pj;'
    var_2 = ','
    var_3 = '!Cqb'
    var_4 = ';]*'
    var_5 = 'E'
    var_6 = '{'
    var_7 = 'yN'
    var_8 = 'x89'
    var_9 = '9'
    var_10 = '$>:'
    var_11 = 'z'
    var_12 = 'hY'
    var_13 = '5'
    var_14 = 'n'
    var_15 = 'b'
    var_16 = 'g_'
    var_17 = 'rv'
    var_18 = 'f'
    var_19 = 'BX'
    var_20

# Generated at 2022-06-25 14:23:38.451622
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    var_0 = get_vars_from_path('~|[+', 'Fb,:hp:', '={)2kM', '^cXH.>V')
    assert var_0 == {}



# Generated at 2022-06-25 14:23:42.811498
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = '/'
    str_1 = 'Ot_h^:+g[t%~'
    var_0 = get_vars_from_path(str_1, str_1, str_1, str_1)
    print(var_0)



# Generated at 2022-06-25 14:23:46.865957
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    assert get_vars_from_inventory_sources(get_vars_from_inventory_sources, get_vars_from_inventory_sources, get_vars_from_inventory_sources, get_vars_from_inventory_sources) == {}



# Generated at 2022-06-25 14:23:48.813934
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    var_1 = get_vars_from_path('', '', '', '')
    assert len(var_1) == 0



# Generated at 2022-06-25 14:23:50.345935
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    vars_loader.clear_all_vars_cache()
    test_case_0()
    pass

# Generated at 2022-06-25 14:24:16.192726
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    import ansible.playbook.play_context
    class obj_0(ansible.playbook.play_context.PlayContext):
        def __init__(self):
            self.var_0 = None
            self.var_1 = None

    var_2 = AnsibleCollectionRef('0.0.0.0')
    obj_1 = obj_0()
    var_3 = obj_1.var_0
    var_4 = obj_1.var_1
    res_0 = get_vars_from_path(var_3, var_3, var_4, var_2)

    assert res_0 is None

# Generated at 2022-06-25 14:24:17.764298
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    try:
        assert test_case_0() == ""
    except:
        return False
    return True


# Generated at 2022-06-25 14:24:18.990958
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert callable(get_vars_from_path)


# Generated at 2022-06-25 14:24:20.287284
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert True


# Generated at 2022-06-25 14:24:25.138514
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'Ot_h^:+g[t%~'
    var_0 = get_vars_from_path(str_0, str_0, str_0, str_0)
    print(var_0)


if __name__ == '__main__':
    test_get_vars_from_path()

# Generated at 2022-06-25 14:24:28.802561
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    capturedOutput = io.StringIO()
    sys.stdout = capturedOutput

    get_vars_from_path(str_0, str_0, str_0, str_0)

    sys.stdout = sys.__stdout__

    assert ("") in capturedOutput.getvalue()


# Generated at 2022-06-25 14:24:32.670044
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    path = "test/data/var_collections"
    entities = "test/data/var_collections"
    stage = "inventory"
    loader = "test/data/var_collections"
    assert get_vars_from_path(loader, path, entities, stage) == {'foo': 'bar', 'baz': 'qux'}


# Generated at 2022-06-25 14:24:33.401535
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert True


# Generated at 2022-06-25 14:24:35.615742
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'Ot_h^:+g[t%~'
    var_0 = get_vars_from_path(str_0, str_0, str_0, str_0)

    assert var_0 == None



# Generated at 2022-06-25 14:24:38.131950
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert test_case_0() == ('Yw_r%')
    return True


# Generated at 2022-06-25 14:25:00.753160
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    # Test using function alias
    try:
        get_vars_from_path_alias = vars_loader.get_vars_from_path
    except Exception:
        get_vars_from_path_alias = None

    if get_vars_from_path_alias:
        assert get_vars_from_path == get_vars_from_path_alias
        test_case_0()

# Generated at 2022-06-25 14:25:11.392732
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Test case #1
    str_0 = '@Y)Ya~6&%c6'
    str_1 = 'R:B`[#c~^'
    str_2 = 'C5&l]5A5Qz'
    str_3 = 'ZuV7Z~[Y"]vp_7'
    str_4 = 'y'
    func_0 = get_vars_from_path(str_0, str_1, str_2, str_3)
    assert func_0 == str_4
    # Test case #2
    str_0 = 'qpO/'
    str_1 = '%*~6XmC['
    str_2 = 'h^'
    str_3 = '+g{b]h*1DzL'

# Generated at 2022-06-25 14:25:20.350703
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Run function get_vars_from_path with arguments: ('Ot_h^:+g[t%~', 'Ot_h^:+g[t%~', 'Ot_h^:+g[t%~', 'Ot_h^:+g[t%~')
    assert test_case_0() == var_0
    # Run function get_vars_from_path with arguments: ('K1IhW', 'MO/\x7fC', 'aKjQe', 'w@\x7f{]')
    assert get_vars_from_path('K1IhW', 'MO/\x7fC', 'aKjQe', 'w@\x7f{]') == {}
    # Run function get_vars_from_path with arguments: ('Ot_

# Generated at 2022-06-25 14:25:24.811845
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    str_1 = 'Jvyil+-I=19@'
    str_2 = '0Nx%G6X?N{|p'
    str_3 = 'z-Lq+C=Y}Q/A'

    var_1 = get_vars_from_path(str_1, str_2, str_3, str_1)

    assert len(var_1) != 0



# Generated at 2022-06-25 14:25:26.138189
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    try:
        test_case_0()
    except AnsibleError as e:
        print(e)



# Generated at 2022-06-25 14:25:26.951439
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert True == True # passed

# Generated at 2022-06-25 14:25:29.042621
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    print('\nRunning test_get_vars_from_path...')
    test_case_0()
    print('Test finished.')

# Unit test main

# Generated at 2022-06-25 14:25:30.810002
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    data = get_vars_from_path(1, 1, 1, 1)
    assert data == {}


# Generated at 2022-06-25 14:25:31.932404
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert callable(get_vars_from_path)


# Generated at 2022-06-25 14:25:38.397565
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'Ot_h^:+g[t%~'
    str_1 = 'a'
    str_2 = 'rLx#{*J-9IN7'
    str_3 = 'VFJ*2~D(L'
    str_4 = 'v'
    str_5 = 'a'
    str_6 = '<,'
    str_7 = 'c'
    str_8 = '>'
    str_9 = '#'
    str_10 = ':'
    str_11 = 's'
    str_12 = '>'
    str_13 = ':v'
    str_14 = '='
    str_15 = 'm'
    str_16 = 'nZM'
    str_17 = ':'
    str_18 = 'r'