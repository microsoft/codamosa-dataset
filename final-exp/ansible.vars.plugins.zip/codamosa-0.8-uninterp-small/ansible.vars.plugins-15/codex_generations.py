

# Generated at 2022-06-25 14:16:05.631767
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'elp'
    str_1 = '^'
    complex_0 = None
    var_0 = get_vars_from_path(str_0, str_1, complex_0, complex_0)
    assert var_0 is None


# Generated at 2022-06-25 14:16:08.425165
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'ansible.plugins.vars.vars_plugins/'
    complex_0 = None
    var_0 = get_vars_from_path(str_0, str_0, complex_0, complex_0)
    print(var_0)

# Generated at 2022-06-25 14:16:12.020666
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = '/q'
    str_1 = '/q'
    str_2 = 'u'
    complex_0 = None

    try:
        var_0 = get_vars_from_path(str_0, str_1, complex_0, str_2)
    except:
        var_0 = None

    assert var_0 == None


# Generated at 2022-06-25 14:16:18.142141
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    entities = [Host(name='localhost'), Host(name='compute1')]
    data = get_vars_from_path('/', '/', entities,'tasks')
    print(data)
    assert data == {'inventory_dir': '/', 'inventory_dirname': '', 'inventory_file': '/', 'inventory_file_basename': '', 'playbook_dir': '/', 'playbook_dirname': '', 'playbook_file': '/'}



# Generated at 2022-06-25 14:16:25.401144
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    int_0 = 9
    float_0 = 3.5
    str_0 = 'X'
    complex_0 = None
    complex_1 = 'D'
    complex_2 = [int_0, float_0, str_0]
    var_0 = get_vars_from_path(int_0, float_0, complex_0, complex_1)
    var_1 = get_vars_from_path(complex_1, complex_2, complex_1, complex_1)
    var_2 = get_vars_from_path(float_0, str_0, complex_2, str_0)
    var_3 = get_vars_from_path(complex_2, complex_2, complex_2, complex_2)

# Generated at 2022-06-25 14:16:27.748509
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    inventory_0 = '/q'
    entities_0 = None
    stage_0 = None
    var_0 = get_vars_from_inventory_sources(inventory_0, inventory_0, entities_0, stage_0)
    assert var_0 == {}


# Generated at 2022-06-25 14:16:33.607714
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Test with a single path
    path = 'file.yaml'
    entities = None
    stage = 'task'
    complex_0 = get_vars_from_path(path, entities, stage)

    # Test with multiple entities
    path = 'file.yaml'
    entities = ['test', 'test', 'test']
    stage = 'inventory'
    complex_1 = get_vars_from_path(path, entities, stage)


# Generated at 2022-06-25 14:16:35.649855
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    host_0 = Host('str_1', port=1000)
    str_0 = 'str_0'
    complex_0 = None
    var_0 = get_plugin_vars(str_0, host_0, str_0, complex_0)
    if var_0 != 'str_1':
        raise Exception('Failed')


# Generated at 2022-06-25 14:16:45.926462
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    # Arguments:
    # str_0: absolute file path of this script
    # str_1: absolute file path of this script
    # complex_0: None
    # complex_1: None
    str_0 = os.path.abspath(__file__)
    str_1 = os.path.abspath(__file__)
    complex_0 = None
    complex_1 = None

    # Function call to function get_vars_from_inventory_sources
    function_result = get_vars_from_inventory_sources(str_0, str_1, complex_0, complex_1)

    # Check whether the complex 0th return value is equal to {'result': 0}

# Generated at 2022-06-25 14:16:57.383755
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    variable_plugins_enabled = C.VARIABLE_PLUGINS_ENABLED
    variable_plugins_enabled.append('var_test_plugin')
    variable_plugins_enabled.append('var_test_plugin_two')
    variable_plugins_enabled.append('var_test_plugin_three')
    variable_plugins_enabled.append('var_test_plugin_four')

    str_0 = '/q'
    complex_0 = None
    var_0 = get_vars_from_path(str_0, str_0, complex_0, complex_0)
    assert(var_0 == None)

    var_1 = get_vars_from_path(str_0, str_0, complex_0, complex_0, 't')
    assert(var_1 == None)

    var_2 = get

# Generated at 2022-06-25 14:17:04.358744
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    test_case_0()



# Generated at 2022-06-25 14:17:07.474505
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    var_0 = None
    try:
        var_0 = 1
    except Exception as e:
        var_0 = e
    assert var_0 == None


# Generated at 2022-06-25 14:17:08.592427
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert get_vars_from_path(var_0, var_1, None)


# Generated at 2022-06-25 14:17:12.052890
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # var_0 and var_1 should be defined in the function
    var_0 = 'path'
    var_1 = 'entities'
    for var in var_0, var_1:
        assert var in globals()


# Generated at 2022-06-25 14:17:15.313922
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    result = get_vars_from_path(var_0, var_1, var_2, var_3)
    assert result is None


# Generated at 2022-06-25 14:17:17.837764
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    assert(get_vars_from_inventory_sources(test_case_0, var_0, var_1) == var_1)



# Generated at 2022-06-25 14:17:21.896264
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    var_2 = None
    var_3 = None
    # Test case 0
    # Not testing return value
    get_vars_from_inventory_sources(var_0, var_1, var_2, var_3)


# Generated at 2022-06-25 14:17:23.803843
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    var_0 = None
    var_1 = None
    assert get_plugin_vars(var_0, var_1, '/foo/bar', []) == {}, "Expected %s but got %s" % ({}, get_plugin_vars(var_0, var_1, '/foo/bar', []))


# Generated at 2022-06-25 14:17:29.348339
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    var_0 = None
    var_1 = None

    # AssertionError if used with improper arguments
    # Type error if the argument is of improper type
    # AssertionError if used with improper arguments
    # Type error if the argument is of improper type
    # AssertionError if used with improper arguments
    # Type error if the argument is of improper type
    # AssertionError if used with improper arguments
    # Type error if the argument is of improper type


# Generated at 2022-06-25 14:17:30.173476
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    pass


# Generated at 2022-06-25 14:17:40.727508
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    var_0 = get_vars_from_path(str_0, str_0, str_0, str_0)
    assert 'ansible' in var_0
    assert 'plugins' in var_0
    assert 'vars' in var_0
    assert 'vars_plugins' in var_0

# Generated at 2022-06-25 14:17:49.892437
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    keyword_0, keyword_1, keyword_2, keyword_3, keyword_4, keyword_5, keyword_6, keyword_7, keyword_8, keyword_9, keyword_10, keyword_11, keyword_12, keyword_13, keyword_14, keyword_15, keyword_16, keyword_17, keyword_18, keyword_19, keyword_20, keyword_21, keyword_22, keyword_23, keyword_24, keyword_25, keyword_26, keyword_27, keyword_28, keyword_29, keyword_30, keyword_31, keyword_32, keyword_33, keyword_34, keyword_35, keyword_36, keyword_37, keyword_38, keyword_39, keyword_40, keyword_41, keyword_42, keyword_43, keyword_44, keyword_45, keyword_46, keyword_47, keyword_48, keyword_

# Generated at 2022-06-25 14:17:53.547265
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    str_0 = ' ansible.plugins.vars.vars_plugins/'
    str_1 = "SVW$?_o!"
    var_0 = get_vars_from_inventory_sources(str_0, str_1, str_0, str_1)
    assert var_0 is not None


# Generated at 2022-06-25 14:18:05.286500
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    plugin_0 = to_bytes('')
    entities_0 = {'entity_0': [{'key_0': 'value_0'}]}
    loader_0 = entities_0
    plugin_1 = AnsibleCollectionRef()
    entities_1 = {'entity_0': [{'key_0': 'value_0'}]}
    path_1 = {'key_0': 'value_0'}
    loader_1 = entities_1
    plugin_2 = entities_1
    entities_2 = entities_0
    loader_2 = entities_2
    plugin_3 = entities_2
    entities_3 = entities_1
    loader_3 = entities_3
    plugin_4 = AnsibleCollectionRef()
    entities_4 = entities_3
    path_4 = entities_3

# Generated at 2022-06-25 14:18:11.558381
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    # Setup test data
    str_0 = 'ansible.plugins.vars.vars_plugins/'
    str_1 = 'ansible.plugins.vars.vars_plugins/'
    str_2 = 'ansible.plugins.vars.vars_plugins/'

    # Run function get_vars_from_path with expected inputs
    # Dict with one key-value pair
    var_0 = get_vars_from_path(str_0, str_1, str_2, str_2)

    # Verify results



# Generated at 2022-06-25 14:18:21.772356
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    #str_0 = 'ansible.plugins.vars.vars_plugins/'
    str_0 = ''
    var_0 = get_vars_from_path(str_0, str_0, str_0, str_0)

    assert var_0 == {}
    assert var_0 == get_vars_from_path(str_0, str_0, str_0, str_0)
    assert var_0 == {}
    assert var_0 == {}
    #assert var_0 == {}
    assert var_0 == {}
    assert var_0 == {}
    assert var_0 == {}
    #assert var_0 == {}
    #assert var_0 == {}
    #assert var_0 == {}
    #assert var_0 == {}
    #assert var_0 == {}
    #assert var_

# Generated at 2022-06-25 14:18:28.080358
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    my_loader = 'ansible.plugins.vars.vars_plugins/'
    my_path = 'ansible.plugins.vars.vars_plugins/'
    my_entities = 'ansible.plugins.vars.vars_plugins/'
    my_stage = 'ansible.plugins.vars.vars_plugins/'
    var_1 = get_vars_from_path(my_loader, my_path, my_entities, my_stage)
    assert var_1 == {}


# Generated at 2022-06-25 14:18:37.455121
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    var_0 = get_vars_from_path(str_0, str_0, str_0, str_0)
    var_1 = get_vars_from_path(str_0, str_0, str_0, str_0)
    var_2 = get_vars_from_path(str_0, str_0, str_0, str_0)
    var_3 = get_vars_from_path(str_0, str_0, str_0, str_0)
    var_4 = get_vars_from_path(str_0, str_0, str_0, str_0)
    assert var_0.get_option(var_1) == var_2
    assert var_0 == var_3
    assert var_0 != var_4


# Generated at 2022-06-25 14:18:40.021449
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    get_vars_from_path(b"\x69\x6E\x76\x65\x6E\x74\x6F\x72\x79", "", "", "")

# Generated at 2022-06-25 14:18:42.658491
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    var_0 = get_plugin_vars(str_0, str_0, str_0, str_0)
    assert var_0 == str_0


# Generated at 2022-06-25 14:18:54.549462
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'ansible.plugins.vars.vars_plugins/'

    test_case_0()

# Generated at 2022-06-25 14:19:00.462715
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    try:
        str_0 = 'RU'
        str_1 = 'ansible.plugins.vars.vars_plugins/'
        str_2 = 'RUN_VARIABLE_PLUGINS_ENABLED/'
        var_0 = get_vars_from_path(str_0, str_1, str_2, str_0)
    except:
        print('Failed to run test for function get_vars_from_path')
        raise


# Generated at 2022-06-25 14:19:03.987154
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert 'ansible.plugins.vars.vars_plugins/' == get_vars_from_path('ansible.plugins.vars.vars_plugins/', 'ansible.plugins.vars.vars_plugins/', 'ansible.plugins.vars.vars_plugins/', 'ansible.plugins.vars.vars_plugins/')



# Generated at 2022-06-25 14:19:07.942830
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    sources = 'ansible.plugins.vars.vars_plugins/'
    entities = 'ansible.plugins.vars.vars_plugins/'
    stage = 'ansible.plugins.vars.vars_plugins/'
    loader = 'test/'
    path = 'test/'
    results = get_vars_from_path(loader, path, entities, stage)
    assert results == {}
    results = get_vars_from_path(loader, path, entities, stage)
    assert results == {}



# Generated at 2022-06-25 14:19:11.526791
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    try:
        assert isinstance(get_plugin_vars(), dict)
    except AssertionError:
        print('Variable returned is not of type dict')
        raise


# Generated at 2022-06-25 14:19:19.610013
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = '|'

# Generated at 2022-06-25 14:19:22.727276
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert not get_vars_from_path("sources/plugins/vars/vars_plugins/", "sources/plugins/vars/vars_plugins/", "sources/plugins/vars/vars_plugins/", "sources/plugins/vars/vars_plugins/")


# Generated at 2022-06-25 14:19:30.250168
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Path to file with inventory sources
    test_0 = 'test/units/plugins/vars/vars_plugin_test.yml'
    # Plugin name
    name_0 = 'git'

    # Initialize the host and group
    host_0 = 'inventory_hostname_short'
    group_0 = 'all'
    # Shorten the hostname
    host_0 = Host(host_0)
    # Initialize a plugin
    plugin_0 = vars_loader.get(name_0)

    # Get the plugin name and path
    name_1 = plugin_0.get_name()
    path_0 = plugin_0.get_path()

    # Get the plugin variables

# Generated at 2022-06-25 14:19:30.864337
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    pass


# Generated at 2022-06-25 14:19:35.213525
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    arg_1 = ''
    arg_3 = ''
    arg_2 = ''
    arg_4 = ''
    try:
        ret_0 = get_vars_from_path(arg_1, arg_2, arg_3, arg_4)
    except Exception as e:
        print(e)


# Generated at 2022-06-25 14:19:49.400408
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    path = 'ansible.plugins.vars.vars_plugins/'
    sources = 'ansible.plugins.vars.vars_plugins/'
    entities = 'ansible.plugins.vars.vars_plugins/'
    stage = 'ansible.plugins.vars.vars_plugins/'
    var_0 = get_vars_from_inventory_sources(path, sources, entities, stage)


# Generated at 2022-06-25 14:19:54.389336
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    ansible_constants = C
    ansible_constants.VARIABLE_PLUGINS_ENABLED = ['']
    ansible_inventory_host = Host('')
    ansible_constants.RUN_VARS_PLUGINS = 'demand'
    ansible_utils_vars = combine_vars({}, get_plugin_vars(str_0, str_0, str_0, [ansible_inventory_host]))

    assert ansible_utils_vars != var_0


# Generated at 2022-06-25 14:19:55.591537
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Create a new inventory source from a string
    test_case_0()

# Generated at 2022-06-25 14:19:58.724208
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    # Retrieve a plugin from the vars plugin directory
    plugin = vars_loader.get('env_vars')

    # Verify that the plugin was retrieved
    assert plugin is not None

    # Retrieve the vars from the plugin
    data = get_plugin_vars(vars_loader, plugin, '.', 'str_0')
    assert data is not None

# Generated at 2022-06-25 14:20:02.696334
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'ansible.plugins.vars.vars_plugins/'
    var_0 = get_vars_from_path(str_0, str_0, str_0, str_0)
    str_1 = 'test_vars_plugins/'
    var_1 = get_vars_from_path(str_1, str_1, str_1, str_1)
    str_2 = 'test_ansible_config'
    var_2 = get_vars_from_path(str_2, str_2, str_2, str_2)


# Generated at 2022-06-25 14:20:03.556997
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert var_0 == dict()

# Generated at 2022-06-25 14:20:10.326232
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.vars.vars_plugins import VarsModule
    plugin = VarsModule('/path/to/ansible.plugins.vars.vars_plugins/vars_plugins', 'vars_plugins', 'get_vars')
    path = 'path'
    entities = None
    stage = 'task'
    var_0 = get_plugin_vars(plugin, path, entities)
    var_1 = get_plugin_vars(plugin, path, entities)
    var_2 = get_vars_from_path(plugin, path, entities, stage)
    return var_2



# Generated at 2022-06-25 14:20:11.513196
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    pass

# Generated at 2022-06-25 14:20:15.714882
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'ansible.plugins.vars.vars_plugins/'
    var_0 = get_vars_from_path(str_0, str_0, str_0, str_0)


# Generated at 2022-06-25 14:20:19.516931
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'ansible.plugins.vars.vars_plugins/'
    var_0 = get_vars_from_path(str_0, str_0, str_0, str_0)


# Generated at 2022-06-25 14:20:38.909435
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    source = None
    entities = []
    stage = 'task'
    src_0 = 'ansible.plugins.vars.vars_plugins/'
    src_1 = 'tests/vars_plugins/'
    src_2 = '/ansible'
    src_3 = 'ansible-base/'
    src_4 = 'tests/'

    path_0 = src_0
    path_1 = src_0 + 'ansible/plugins/vars/'
    path_2 = src_0 + 'ansible/plugins/vars/'
    path_3 = src_0 + 'ansible/plugins/vars/'
    path_4 = src_0 + 'ansible/plugins/vars/'
    path_5 = src_0 + 'ansible/plugins/vars/'
    path_6

# Generated at 2022-06-25 14:20:49.083634
# Unit test for function get_vars_from_path

# Generated at 2022-06-25 14:20:50.689267
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    get_vars_from_path()



# Generated at 2022-06-25 14:20:53.923417
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    str_0 = 'ansible.plugins.vars.vars_plugins/'
    var_0 = get_vars_from_inventory_sources(str_0, str_0, str_0, str_0)
    assert var_0 == {}


# Generated at 2022-06-25 14:21:03.954807
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'asst'
    str_1 = 'vars_'
    str_2 = 'plugins/'
    str_3 = str_1 + str_1 + str_0 + str_2
    str_4 = '/'
    str_5 = str_3 + str_4 + 'get_chq' + str_1 + str_1
    str_6 = 'nt_vars'
    str_7 = 'p_name'
    str_8 = get_vars_from_path(str_0, str_0, str_0, str_0)
    str_9 = str_8 + str_7 + str_0 + str_1 + str_0

# Generated at 2022-06-25 14:21:04.688782
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Executing test case #0
    test_case_0()

# Generated at 2022-06-25 14:21:10.349228
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.plugins.loader import vars_loader

    loader = None
    sources = [
        'str_0',
    ]
    entities = [
        Host(name='str_0'),
        Group(name='str_1', hostname='str_1'),
    ]
    stage = 'inventory'

    var_0 = get_vars_from_inventory_sources(loader, sources, entities, stage)


# Generated at 2022-06-25 14:21:12.666566
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    print(get_vars_from_path(str_0, str_0, str_0, str_0))


# Generated at 2022-06-25 14:21:14.849865
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert not get_vars_from_path('', '', '', '')



# Generated at 2022-06-25 14:21:21.118409
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Run unit test
    debug_0 = get_vars_from_path(
	'ansible.plugins.vars.vars_plugins/', 
	'ansible.plugins.vars.vars_plugins/', 
	'ansible.plugins.vars.vars_plugins/', 
	'ansible.plugins.vars.vars_plugins/')
    assert debug_0 is not False


# Generated at 2022-06-25 14:21:33.090085
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    data = get_vars_from_path(str_0, str_0, str_0, str_0)
    assert data is not None

# Generated at 2022-06-25 14:21:36.855908
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    if C.ANSIBLER_DIRECTORY is not None:
        str_1 = os.path.join(C.ANSIBLER_DIRECTORY, 'plugins/vars/vars_plugins')
    else:
        str_1 = 'ansible.plugins.vars.vars_plugins/'
    var_1 = get_vars_from_path(str_1, str_1, str_1, str_1)
    assert type(var_1) == dict


# Generated at 2022-06-25 14:21:42.066113
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Start test.
    print("\n####### Start test for Ansible get_vars_from_path #######\n")
    # Function to which the test is being run.
    var_0 = test_case_0()
    print("\n####### End test for Ansible get_vars_from_path #######\n")
 

# Use the following lines to run this file if called directly.
# test_get_vars_from_path()

# Generated at 2022-06-25 14:21:44.251934
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    my_plugin = vars_loader.get('acl')
    assert(isinstance(get_plugin_vars(str, my_plugin, '.', str), dict))

# Generated at 2022-06-25 14:21:46.855198
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'ansible.plugins.vars.vars_plugins/'
    var_0 = get_vars_from_path(str_0, str_0, str_0, str_0)
    print(var_0)

# Generated at 2022-06-25 14:21:51.505089
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    try:
        str_0 = 'ansible.plugins.vars.vars_plugins/'
        var_0 = get_vars_from_path(str_0, str_0, str_0, str_0)
        return var_0
    except Exception as e:
        display.error(str(e))
        return False


# Generated at 2022-06-25 14:21:58.810124
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    print('Running test_get_vars_from_path()...')

    str_0 = 'ansible.plugins.vars.vars_plugins/'
    var_0 = get_vars_from_path(str_0, str_0, str_0, str_0)
    print('1')
    assert var_0 == {}, '<{}> != {}'.format(repr(var_0), '{}')
    print('2')
    assert var_0 is not False, '<{}> != {}'.format(repr(var_0), 'False')
    print('3')



# Generated at 2022-06-25 14:22:02.191846
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    # Tests for string input

    # Test for string of length 1
    str_1 = 'a'
    var_1 = get_vars_from_path(str_1, str_1, str_1, str_1)
    assert var_1 == {}

    # Test for string of length greater than 1
    str_2 = 'b'
    var_2 = get_vars_from_path(str_2, str_2, str_2, str_2)
    assert var_2 == {}

# Generated at 2022-06-25 14:22:04.838375
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    # get_vars_from_path(loader, path, entities, stage)

    var_0 = get_vars_from_path(str_0, str_0, str_0, str_0)



# Generated at 2022-06-25 14:22:12.646457
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    loader_0 = get_vars_from_path(str(init), str(init), str(init), str(init))
    plugin_0 = get_plugin_vars(loader_0, str(init), str(init), str(init))
    path_0 = os.path.basename(path)
    entities_0 = os.path.basename(path)
    assert plugin_0 is not False


# Generated at 2022-06-25 14:22:30.837015
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'ansible.plugins.vars.vars_plugins/'
    var_0 = get_vars_from_path(str_0, str_0, str_0, str_0)
    str_1 = 'ansible.plugins.vars.vars_plugins/'
    var_1 = get_vars_from_path(str_1, str_1, str_1, str_1)
    str_2 = 'ansible.plugins.vars.vars_plugins/'
    var_2 = get_vars_from_path(str_2, str_2, str_2, str_2)


# Generated at 2022-06-25 14:22:39.555048
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    str_1 = 'ansible.plugins.vars.vars_plugins/'
    str_2 = '../ansible.cfg'
    str_3 = '../ansible.cfg'
    assert get_vars_from_inventory_sources(str_1, str_2, str_3, str_1) == {'_ansible_config': '../ansible.cfg',
                                                                             '_ansible_config_name': '../ansible.cfg',
                                                                             '_ansible_config_path': '../ansible.cfg'}


if __name__ == '__main__':
    test_case_0()
    test_get_vars_from_inventory_sources()

# Generated at 2022-06-25 14:22:46.371485
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    path_0 = 'ansible.plugins.vars.vars_plugins/'
    stage_0 = 'all'
    entities_0 = 'ansible.plugins.vars.vars_plugins/'
    loader_0 = 'ansible.plugins.vars.vars_plugins/'
    var_0 = get_vars_from_path(loader_0, path_0, entities_0, stage_0)
    assert len(var_0) == 0


# Generated at 2022-06-25 14:22:48.612623
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Check error handling
    try:
        get_vars_from_path(None, None, None, None)
    except AnsibleError:
        pass



# Generated at 2022-06-25 14:22:55.592117
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    str_0 = 'ansible.plugins.vars.vars_plugins/'
    str_1 = 'ansible.plugins.vars_loader/'
    str_2 = '~/.ansible/var_plugins/'
    str_3 = '/etc/ansible/var_plugins/'
    str_4 = '~/.ansible/collections/ansible_collections/'
    str_5 = '/etc/ansible/collections/ansible_collections/'
    str_6 = 'ansible.plugins.vars.vars_plugins'
    str_7 = 'ansible.plugins.vars_loader'
    str_8 = 'vars_plugins'
    str_9 = 'vars_loader'
    str_10 = 'ansible.plugins.vars.vars_plugins/'


# Generated at 2022-06-25 14:22:56.494182
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    assert True


# Generated at 2022-06-25 14:22:57.932766
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert True


# Generated at 2022-06-25 14:23:02.081477
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    # Output variables
    var_0 = None

    # Test case
    test_case_0()

    # Value assertion
    assert var_0 is not None, "Unable to get value for output variable var_0"


# Generated at 2022-06-25 14:23:04.545130
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    try:
        get_vars_from_path(None, None, None, None)
    except TypeError:
        assert True
    else:
        assert False


# Generated at 2022-06-25 14:23:06.836080
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    result = None
    vars_plugins = {}
    assert type(get_vars_from_path(vars_plugins, result, result, result)) == dict


# Generated at 2022-06-25 14:23:22.874394
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    path = '/ansible/plugins/vars/vars_plugins/'
    loader = 'ansible.plugins.loader.vars_loader'
    plugin = 'ansible.plugins.vars.vars_plugins'
    entities = 'ansible.inventory.host.Host'
    host = 'ansible.plugins.inventory.host_list.HostList'
    group = 'ansible.vars.group_vars.GroupVars'
    get_host_vars = 'ansible.vars.host_vars.HostVars'
    run = 'ansible.plugins.loader.action_loader'

    data = {}

# Generated at 2022-06-25 14:23:23.764592
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    test_case_0()

# Generated at 2022-06-25 14:23:30.350090
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'ansible.plugins.vars.vars_plugins/'
    var_0 = get_vars_from_path('/etc/ansible/hosts', str_0, str_0, str_0)
    print(var_0)
    print(type(var_0))


# Generated at 2022-06-25 14:23:36.751035
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    # mock source value
    source = 'ansible.plugins.vars.vars_plugins/'
    # mock entities value
    entities = 'ansible.playbook.play_context.CLIARGS'
    # mock stage value
    stage = 'inventory'

    # mock call to get_vars_from_path
    mock_get_vars_from_path = ({'a': 1, 'b': 2, 'c': 3, 'd': 4})
    assert get_vars_from_inventory_sources(source, source, entities, stage) == mock_get_vars_from_path

# Generated at 2022-06-25 14:23:39.624479
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'ansible.plugins.vars.vars_plugins/'
    str_1 = get_vars_from_path(str_0, str_0, str_0, str_0)
    assert str_1


# Generated at 2022-06-25 14:23:40.661294
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    pass


# Generated at 2022-06-25 14:23:44.480517
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Tests that the function will return a dict object
    assert True == isinstance(get_vars_from_path(None, None, None, None), dict)



# Generated at 2022-06-25 14:23:48.814298
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert get_vars_from_path('ansible.plugins.vars.vars_plugins/', 'ansible.plugins.vars.vars_plugins/', 'ansible.plugins.vars.vars_plugins/', 'ansible.plugins.vars.vars_plugins/') == 'ansible.plugins.vars.vars_plugins/'

# Generated at 2022-06-25 14:23:52.339940
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    expected_0 = {'ansible_connection': 'local'}
    var_0 = get_vars_from_path('foo', 'plugins/inventory/host_vars', 'foo', 'foo')
    assert var_0 == expected_0


# Generated at 2022-06-25 14:23:53.486352
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # pylint: disable=undefined-variable
    assert True


# Generated at 2022-06-25 14:24:10.888761
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    loader = vars_loader.get('yaml_file')
    # Test with paths:
    # both existing
    path_0 = 'tests/functional/targets/test_case_0/'
    path_1 = 'tests/functional/targets/test_case_1/'
    path_2 = 'tests/functional/targets/test_case_2/'

    # path_0 existing, path_1 not existing
    path_3 = 'tests/functional/targets/test_case_3/'
    path_4 = 'tests/functional/targets/test_case_4/'

    # both not existing
    path_5 = 'tests/functional/targets/test_case_5/'

# Generated at 2022-06-25 14:24:16.582493
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_1 = 'ansible.plugins.vars.vars_plugins/'
    str_2 = 'ansible.plugins.vars.vars_plugins/'
    str_3 = 'ansible.plugins.vars.vars_plugins/'
    str_4 = 'ansible.plugins.vars.vars_plugins/'
    var_1 = get_vars_from_path(str_1, str_2, str_3, str_4)



# Generated at 2022-06-25 14:24:19.579978
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'ansible.plugins.vars.vars_plugins/'
    assert get_vars_from_path(str_0, str_0, str_0, str_0) is None


# Generated at 2022-06-25 14:24:20.165233
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    assert True

# Generated at 2022-06-25 14:24:23.597984
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    str_0 = 'ansible.plugins.vars.vars_plugins/'
    var_0 = get_plugin_vars(str_0, str_0, str_0, str_0)


# Generated at 2022-06-25 14:24:30.868923
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = '/usr/lib/python3.6/site-packages/ansible/plugins/vars/vars_plugins'
    str_1 = '/usr/lib/python3.6/site-packages/ansible/plugins/vars'
    str_2 = 'playbook.yml'
    str_3 = 'inventory'
    str_4 = '/etc/ansible/hosts'
    var_0 = get_vars_from_path(str_0, str_1, [str_2], str_3)
    var_1 = get_vars_from_path(str_0, str_4, [str_2], str_3)


# Generated at 2022-06-25 14:24:33.317476
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'ansible.plugins.vars.vars_plugins/'
    var_0 = get_vars_from_path(str_0, str_0, str_0, str_0)


# Generated at 2022-06-25 14:24:34.090078
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert True


# Generated at 2022-06-25 14:24:45.822934
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    # All inputs are of type 'str'
    str_0 = 'ansible.plugins.vars.vars_plugins/'
    # str_0: False
    assert isinstance(str_0, str)
    str_0 = 'ansible.plugins.vars.vars_plugins/'
    # str_1: False
    assert isinstance(str_0, str)
    str_0 = 'ansible.plugins.vars.vars_plugins/'
    # str_2: False
    assert isinstance(str_0, str)
    str_0 = 'ansible.plugins.vars.vars_plugins/'
    # str_3: False
    assert isinstance(str_0, str)

# Generated at 2022-06-25 14:24:54.256659
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'ansible.plugins.vars.vars_plugins/'
    assert get_vars_from_path(str_0, str_0, str_0, str_0)[str_0] == str_0
    assert get_vars_from_path(str_0, str_0, str_0, str_0)[str_0] == str_0
    assert get_vars_from_path(str_0, str_0, str_0, str_0)[str_0] == str_0
    assert get_vars_from_path(str_0, str_0, str_0, str_0)[str_0] == str_0
    assert get_vars_from_path(str_0, str_0, str_0, str_0)[str_0] == str_

# Generated at 2022-06-25 14:25:05.973645
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert False


# Generated at 2022-06-25 14:25:07.843309
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert get_vars_from_path('', '', '', '') == {}



# Generated at 2022-06-25 14:25:13.078395
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    file_path = os.path.dirname(os.path.abspath(__file__))
    str_0 = 'ansible.plugins.vars.vars_plugins/'
    str_1 = 'vars.py'
    str_2 = 'group_vars'
    str_3 = 'host_vars'

    var_0 = get_vars_from_path(file_path, str_0, str_1, str_2)
    assert(var_0 == {})



# Generated at 2022-06-25 14:25:17.231855
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    cases = [
        {
            'desc': 'basic path test',
            'args': {
                'path': 'ansible.plugins.vars.vars_plugins/',
                'entities': '',
                'stage': '',
            },
            'return_value': '',
        },
    ]
    for case in cases:
        ret = get_vars_from_path(**case['args'])
        assert ret == case['return_value'], 'Expected {0}, but returned {1}'.format(case['return_value'], ret)

# Generated at 2022-06-25 14:25:19.286952
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    try:
        test_case_0()
        return True
    except Exception as e:
        print('Exception: %s' % (e))
        return False


# Generated at 2022-06-25 14:25:26.028159
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    get_vars_from_path(ansible_plugins_vars_vars_plugins_ = None, path = None, entities = None, stage = None)
    str_0 = 'ansible.plugins.vars.vars_plugins/'
    str_1 = 'ansible.plugins.vars.vars_plugins/'
    str_2 = 'ansible.plugins.vars.vars_plugins/'
    str_3 = 'ansible.plugins.vars.vars_plugins/'
    var_0 = get_vars_from_path(str_3, str_2, str_1, str_0)
    var_0 = get_vars_from_path(str_3, str_2, str_1, str_0)

# Generated at 2022-06-25 14:25:29.391009
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'ansible.plugins.vars.vars_plugins/'
    var_0 = get_vars_from_path(str_0, str_0, str_0, str_0)
    assert var_0 == {}, "The expected return value is {}"


# Generated at 2022-06-25 14:25:32.312829
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'ansible.plugins.vars.vars_plugins/'
    var_0 = get_vars_from_path(str_0, str_0, str_0, str_0)
    assert type(var_0) == dict


# Generated at 2022-06-25 14:25:33.065821
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    pass



# Generated at 2022-06-25 14:25:40.943632
# Unit test for function get_vars_from_path