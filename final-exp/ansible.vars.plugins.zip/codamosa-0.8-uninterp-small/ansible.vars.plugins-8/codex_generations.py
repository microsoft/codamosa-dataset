

# Generated at 2022-06-25 14:15:57.882159
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    vars_0 = get_vars_from_path({'8D': 'y', '*4': 'c', '-1': '*', 'ZK': 'Q', '`22bv3': '`22bv3', '3': '3', 'd': 'd', '`': '`', '\n': '\n', 'm': 'm', 'w': 'w', 'R': 'R', '^': '^', 'mT': 'mT', 'c': 'c'}, '7', ['t', 'E', 'Z', 'r', 'b'], 'eJ')


# Generated at 2022-06-25 14:16:04.003464
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert get_vars_from_path('bfeeb1d8-ed6c-4756-9d6b-c9d8e1dcb57e', 'b4c3ca4d-8a5e-4ea7-a5cb-df5dfb6738a5', '0.513150571618086', 'ed6c0f6b-c908-4a8a-9cec-14f0845d82b1') == {}


# Generated at 2022-06-25 14:16:10.912082
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    dict_0 = {'e': 'mj', '*rw': '9gO', '1': 1, 'a': '*rw'}
    int_0 = -2147483648
    str_0 = '`22bv3'
    dict_1 = {'E0': dict_0, '*rw': dict_0, 'a': '*rw'}
    dict_0 = {'e': 'mj', str_0: '4yu', '`22bv3': int_0}
    dict_2 = {'a': '*rw', '*rw': dict_0, 'E0': dict_1}
    dict_0 = {'E0': dict_0, '*rw': '`22bv3', '1': dict_1}

# Generated at 2022-06-25 14:16:19.904060
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    class FixtureClass:
        def __init__(self, loader, path, entities):
            self.loader = loader
            self.path = path
            self.entities = entities
            self.has_option = hasattr(self, 'get_option') and self.has_option('stage')

    # Case 1:
    fixture_class_0 = FixtureClass(0, 1, 2)
    fixture_class_1 = FixtureClass(0, 1, 2)
    fixture_class_2 = FixtureClass(0, 1, 2)
    fixture_class_3 = FixtureClass(0, 1, 2)
    fixture_class_4 = FixtureClass(0, 1, 2)
    fixture_class_5 = FixtureClass(0, 1, 2)

# Generated at 2022-06-25 14:16:23.473616
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = '`22bv3'
    dict_0 = {str_0: str_0}
    list_0 = []
    float_0 = 3094.825
    var_0 = get_vars_from_path(dict_0, list_0, dict_0, float_0)
    assert var_0 is not None



# Generated at 2022-06-25 14:16:26.872341
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    dict_0 = {}
    dict_1 = {'==#': '==#'}
    str_0 = 'GYgIz&)'
    str_1 = 'GYgIz&)'
    var_0 = get_plugin_vars(dict_0, dict_1, str_0, str_1)
    assert var_0 == {}

# Generated at 2022-06-25 14:16:36.433998
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    float_0 = float("NaN")
    str_0 = '`22bv3'
    str_1 = ')T'
    str_2 = 'p$Mk~'
    dict_0 = {str_0: float_0}
    dict_1 = {str_0: float_0}
    dict_2 = {str_0: float_0}
    list_0 = [float_0, str_1]
    list_1 = [float_0, str_2]
    tuple_0 = (dict_0, list_0)
    tuple_1 = (dict_0, list_1)
    # Test the calling of the function by passing tuple_0 and tuple_1.
    assert get_plugin_vars(tuple_0, str_0, tuple_1, float_0) == 0

# Generated at 2022-06-25 14:16:40.893174
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    str_0 = '\'the'
    dict_0 = {str_0: str_0}
    dict_1 = {str_0: str_0}
    float_0 = 299.0
    get_plugin_vars(dict_0, dict_0, dict_1, float_0)


# Generated at 2022-06-25 14:16:47.557073
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    str_0 = '`22bv3'
    dict_0 = {str_0: str_0}
    float_0 = 1686.327
    var_0 = get_vars_from_inventory_sources(dict_0, str_0, dict_0, float_0)
    assert var_0 == {}, 'Expected {}, but got {}'.format({}, var_0)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 14:16:55.016733
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    dict_0 = {}
    dict_1 = {}
    dict_1['loader'] = dict_0
    str_0 = 'Z>@'
    dict_1['plugin'] = str_0
    list_0 = [str_0, str_0]
    dict_1['entities'] = list_0
    dict_0['path'] = list_0
    dict_1['stage'] = dict_0
    assert get_plugin_vars(**dict_1) == dict_0


# Generated at 2022-06-25 14:17:11.063322
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    plugin = '192.168.82.69'
    path = '\x07\xd2\x07\x84\x1e'
    entities = 'W\r8bv\x02'

    # Call function
    actual = get_plugin_vars(plugin, path, entities)
    expected = None
    assert actual == expected


# Generated at 2022-06-25 14:17:11.646941
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    assert True

# Generated at 2022-06-25 14:17:13.141089
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    raise NotImplementedError



# Generated at 2022-06-25 14:17:24.120306
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = '`\x0c '
    dict_0 = {str_0: 1, '/aux': 0, '@': int(), 'C:\\D': False, 'C:\\': '/users/', '`\\': None, '`\x0c ': '\x00', '/Users': -10, 'C:': 'u\x06', 'C:\\Users': '\x00', 'C:\\Users\\ko~~~': '\x0c', 'C:\\Users\\ko~~~\\': 'C'}

    # Testing with a dictionary
    var_0 = get_vars_from_path(dict_0, dict_0, dict_0, dict_0)

    # Testing with a string

# Generated at 2022-06-25 14:17:26.973333
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    import os
    import tempfile
    try:
        os.chdir(tempfile.mkdtemp())
        test_case_0()
    finally:
        os.chdir(tempfile.gettempdir())

# Generated at 2022-06-25 14:17:27.908078
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
  pass # TODO


# Generated at 2022-06-25 14:17:30.389535
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    assert(get_plugin_vars(str_0, str_0, str_0, str_0) == str_0)


# Generated at 2022-06-25 14:17:37.072240
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    str_1 = '~)%&N'
    str_2 = '\x01\x04\x04\x04\x07\x0c'
    str_3 = '\x17K\x0f'
    str_4 = '\x17K\x0f'
    int_0 = 5
    result_0 = get_plugin_vars(str_3, str_4, str_1, str_2)
    assert int_0 == result_0


# Generated at 2022-06-25 14:17:42.680632
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = '`\x0c '
    str_1 = '*'
    # want: len(set(str_0)), len(set(str_1))
    # ==> [1, 1]
    assert len(set(str_0)) == 1
    assert len(set(str_1)) == 1



# Generated at 2022-06-25 14:17:51.407491
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.module_utils.common.testing import AnsibleExitJson
    from ansible.utils.hashing import checksum_s

    # call test function
    str_0 = '`\x0c '
    ansible_exit_json_0 = AnsibleExitJson()
    ansible_exit_json_0.success = True
    str_1 = '|\x00\x00\x00\x00'
    str_2 = '%\x00\x00\x00\x00'
    str_3 = '\x01+\x00\x00\x00'
    str_4 = '\x00\x00\x00'
    str_5 = '\x00\x00\x00\x00\x00\x00\x00\x00'
    long_

# Generated at 2022-06-25 14:18:02.853130
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_arg1 = '`\x0c '
    str_arg2 = '`\x0c '
    str_arg3 = '`\x0c '
    str_arg4 = '`\x0c '
    var_ret = get_vars_from_path(str_arg1, str_arg2, str_arg3, str_arg4)
    assert isinstance(var_ret, dict)
    assert var_ret == {}

# Generated at 2022-06-25 14:18:03.700068
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert True
    #assert False  # FIXME: construct a test case, disable assert False until then


# Generated at 2022-06-25 14:18:07.229708
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    sources = "/path/to/source"
    entities = ""
    stage = "inventory"
    data = get_vars_from_inventory_sources(sources, entities, stage)
    print(data)



# Generated at 2022-06-25 14:18:11.026752
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    try:
        str_0 = '`\x0c '
        test_case_0()
        display.display("PASSED: Basic test for function get_vars_from_path")
    except:
        display.display("FAILED: Basic test for function get_vars_from_path")

test_get_vars_from_path()

# Generated at 2022-06-25 14:18:13.861561
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    var_1 = '<module>'
    var_2 = '<module>'
    var_3 = '<module>'
    var_4 = '<module>'
    var_5 = get_plugin_vars(var_1, var_2, var_3, var_4)

# Generated at 2022-06-25 14:18:17.293290
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    try:
        test_case_0()
    except:
        print('Test case 0 failed')
        raise


if __name__ == "__main__":
    test_get_vars_from_path()

# Generated at 2022-06-25 14:18:19.847118
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    assert type(get_plugin_vars('str_0', 'str_0', 'str_0', 'str_0')) == dict


# Generated at 2022-06-25 14:18:28.877493
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Should raise an exception
    try:
        str_1 = 'w`\x0c '
        str_2 = '\x99*\x0b'
        str_3 = '\x99*\x0b'
        get_vars_from_path(str_1, str_1, str_1, str_1)
    except Exception:
        pass
    else:
        assert False

    # Should raise an exception
    try:
        str_4 = '\x0c '
        str_5 = '\x0c '
        str_6 = '\x0c '
        str_7 = '\x0c '
        get_vars_from_path(str_4, str_4, str_4, str_4)
    except Exception:
        pass

# Generated at 2022-06-25 14:18:38.326647
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = "Cis-Ubuntu16.04-xenial"
    str_1 = 'host'
    str_2 = 'task'
    path_list_0 = []
    path_list_1 = []
    path_list_2 = []
    path_list_3 = []
    path_list_4 = []
    path_list_5 = []
    path_list_6 = []
    path_list_7 = []
    path_list_8 = []
    path_list_9 = []
    path_list_10 = []
    path_list_11 = []
    path_list_12 = []
    path_list_13 = []
    path_list_14 = []
    path_list_15 = []
    path_list_16 = []
    path_list_17 = []

# Generated at 2022-06-25 14:18:40.132705
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    data = get_vars_from_path(str, str, str, str)


# Generated at 2022-06-25 14:18:56.295484
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    display.display(">> Testing the function: 'get_vars_from_path'")
    str_0 = '\x0c'
    str_1 = '    '
    str_2 = '\xa0'
    str_3 = '\x0c``'
    str_4 = '` '
    str_5 = '``\x0c'
    test_var_0 = get_vars_from_path(str_0, str_1, str_2, str_3)
    if not test_var_0 == {'key_2': 'value_1', 'key_1': 'value_1'}:
        raise Exception('Failed!')
    test_var_1 = get_vars_from_path(str_4, str_5, str_2, str_3)

# Generated at 2022-06-25 14:19:05.048613
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = '\x01\x02\x03\x04\x05\x06\x07\x08'
    str_1 = '\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r'
    str_2 = '\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r'

# Generated at 2022-06-25 14:19:10.130571
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    sample_loader = '\x0b_?\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'

# Generated at 2022-06-25 14:19:13.157174
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = '`\x0c '
    var_0 = get_vars_from_path(str_0, str_0, str_0, str_0)



# Generated at 2022-06-25 14:19:20.920236
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    var_1 = get_vars_from_path("eAKC+[@4(4m-h3=Eydn-nB+", [], [], [])
    var_2 = get_vars_from_path("Dir6g(U-;", [], [], [])
    var_3 = get_vars_from_path("#", [], [], [])
    var_4 = get_vars_from_path("{@sV`", [], [], [])
    var_5 = get_vars_from_path("<Vq3s^p=Fn", [], [], [])
    var_6 = get_vars_from_path("7jb(+/", [], [], [])

# Generated at 2022-06-25 14:19:21.703697
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert test_case_0()



# Generated at 2022-06-25 14:19:23.549669
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    var_0 = get_vars_from_path()
    assert var_0 is not None


# Generated at 2022-06-25 14:19:25.214617
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    var_1 = get_plugin_vars(str_0, str_0, str_0, str_0)


# Generated at 2022-06-25 14:19:25.711058
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert True

# Generated at 2022-06-25 14:19:26.473706
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert True == True


# Generated at 2022-06-25 14:19:33.615257
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = '`\x0c '
    var_1 = get_vars_from_path(str_0, str_0, str_0, str_0)

# Generated at 2022-06-25 14:19:39.015870
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'a '
    str_1 = '`\x0c '
    str_2 = '0'
    str_3 = 'b'
    
    test_var_0 = get_vars_from_path(str_0, str_1, str_2, str_3)
    assert test_var_0 == {}



# Generated at 2022-06-25 14:19:48.026775
# Unit test for function get_vars_from_path

# Generated at 2022-06-25 14:19:48.934222
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert callable(get_vars_from_path)



# Generated at 2022-06-25 14:19:52.625687
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    path = 'conftest.py'
    entities = ['conftest.py']
    stage = 'setup'
    from ansible.plugins import vars_loader
    loader = vars_loader
    var = get_vars_from_path(loader, path, entities, stage)
    assert var == {'_failed_test': False}, "Failed to get expected variable"



# Generated at 2022-06-25 14:19:59.358939
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    data = {}
    vars_plugin_list = list(vars_loader.all())
    for plugin_name in C.VARIABLE_PLUGINS_ENABLED:
        if AnsibleCollectionRef.is_valid_fqcr(plugin_name):
            vars_plugin = vars_loader.get(plugin_name)
            if vars_plugin is None:
                # Error if there's no play directory or the name is wrong?
                continue
            if vars_plugin not in vars_plugin_list:
                vars_plugin_list.append(vars_plugin)


# Generated at 2022-06-25 14:20:00.178595
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert True


# Generated at 2022-06-25 14:20:02.347947
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    var_0 = None
    var_1 = get_plugin_vars(var_0, var_0, var_0, var_0)


# Generated at 2022-06-25 14:20:04.173079
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    data_0 = get_vars_from_path(None, '\x1d', None, '\x02')



# Generated at 2022-06-25 14:20:05.374129
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert True # TODO: implement your test here


# Generated at 2022-06-25 14:20:12.970102
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    assert get_vars_from_inventory_sources(str_0, str_0, str_0, str_0) == None


# Generated at 2022-06-25 14:20:21.238886
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    dut = 'inventory_plugins/vars_plugins/test.py'
    loader = 'loader'
    path = 'path'
    entities = 'entities'
    stage = 'stage'
    vars_plugin = vars_loader.get(dut)
    plugins = vars_loader.all()
    plugins.append(vars_plugin)
    expected = {'one': 1, 'two': 2}
    actual = get_vars_from_path(loader, path, entities, stage)
    assert actual == expected


# Generated at 2022-06-25 14:20:22.057035
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    pass


# Generated at 2022-06-25 14:20:33.354211
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    """
    ValueError
    """
    args = (1, 2, 3, 4)
    assert args == get_vars_from_path(*args), 'Expected Exception'

    args = (1, 1, 1, 1)
    assert args == get_vars_from_path(*args), 'Expected Exception'

    args = (0, 0, 0, 0)
    assert args == get_vars_from_path(*args), 'Expected Exception'

    args = ('', '', '', '')
    assert args == get_vars_from_path(*args), 'Expected Exception'

    args = ('`', '`', '`', '`')
    assert args == get_vars_from_path(*args), 'Expected Exception'


# Generated at 2022-06-25 14:20:34.758025
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert callable(get_vars_from_path)


# Generated at 2022-06-25 14:20:36.726886
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    import os
    import tempfile


# Generated at 2022-06-25 14:20:38.588540
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    assert func_return_0 == '<generator object get_plugin_vars at 0x7f85ab6ee150>'


# Generated at 2022-06-25 14:20:40.349903
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    assert get_vars_from_inventory_sources(str_0, str_0, str_0, str_0) == var_0

# Generated at 2022-06-25 14:20:41.432280
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert True # TODO: implement your test here


# Generated at 2022-06-25 14:20:51.329925
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    str_0 = 'cmFxdWV0ZXJz'
    str_1 = 'JHs='
    str_2 = 'J3BhdGgn'

# Generated at 2022-06-25 14:21:00.020860
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    host = Host('host0')
    group = Host('group0')
    test_val = get_vars_from_path('host0', host, group, 'inventory')
    if test_val != {}:
        raise AssertionError('get_vars_from_path does not return {}')



# Generated at 2022-06-25 14:21:00.610444
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert True

# Generated at 2022-06-25 14:21:02.904314
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    var_0 = get_plugin_vars(str_0, str_0, str_0, str_0)


# Generated at 2022-06-25 14:21:11.284723
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = '`\x0c '
    str_1 = 'T\x0eS8\x1c '
    str_2 = '`\x0c '
    str_3 = '`\x0c '
    str_4 = '`\x0c '
    str_5 = '`\x0c '
    str_6 = '`\x0c '
    str_7 = '`\x0c '
    str_8 = '`\x0c '
    str_9 = '`\x0c '
    str_10 = '`\x0c '
    str_11 = '`\x0c '
    str_12 = '`\x0c '
    str_13 = '`\x0c '

# Generated at 2022-06-25 14:21:16.722412
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    tests = [
        ['', '', '', '', None],
        ['', '', '', '', None],
        ['', '', '', '', None],
    ]
    for test in tests:
        assert test_case_0(test[0], test[1], test[2], test[3]) == test[4]



# Generated at 2022-06-25 14:21:21.024242
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    data = get_vars_from_path('inventory', 'inventory', 'entities', 'stage')
    assert data == {}
    assert isinstance(get_vars_from_path('inventory', 'inventory', 'entities', 'stage'), dict)



# Generated at 2022-06-25 14:21:23.439242
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert get_vars_from_path('loader', 'path', 'entities', 'stage') == {}


# Generated at 2022-06-25 14:21:24.386561
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    assert True == True



# Generated at 2022-06-25 14:21:25.588277
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert True


# Generated at 2022-06-25 14:21:29.013686
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    data = {}
    path = ''
    entities = {}
    stage = 'all'
    assert get_vars_from_path(data, path, entities, stage) == data


# Generated at 2022-06-25 14:21:36.694864
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = '`\x0c '
    var_0 = get_vars_from_path('\x00\x03', '\x00\x07', '\x02\x15', '\x00\x07')


# Generated at 2022-06-25 14:21:40.956516
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = '`\x0c '
    var_0 = get_vars_from_path(str_0, str_0, str_0, str_0)
    str_0 = '`\x0c '
    var_1 = get_vars_from_path(str_0, str_0, str_0, str_0)


# Generated at 2022-06-25 14:21:44.326940
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    sources = []
    sources.append(r'')
    entities = []
    entities.append(r'')

    stage = '`\x0c '
    loader = '`\x0c '
    assert get_vars_from_inventory_sources(loader, sources, entities, stage) == {}

# Generated at 2022-06-25 14:21:52.918222
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    # Populate the global vars plugins whitelist
    C.VARIABLE_PLUGINS_ENABLED = ['test']
    C.RUN_VARS_PLUGINS = 'start'

    # Populate the test plugin with get_vars and get_host_vars/get_group_vars
    class TestPlugin(object):
        def __init__(self):
            self.has_option = lambda x: True
            self._load_name = 'test'
            self._original_path = 'path'

        def get_vars(self, loader, path, entities):
            return {'test_data': 'test_data'}

        def get_host_vars(self, host):
            return {'host': 'host'}

        def get_group_vars(self, group):
            return

# Generated at 2022-06-25 14:21:57.307315
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    #pylint: disable=E0602
    # No sources given, should return an empty dict
    assert get_vars_from_inventory_sources([], [], [], "stage") == {}

    # test case 0
    #pylint: disable=W0612
    test_case_0()



# Generated at 2022-06-25 14:21:59.156225
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    assert isinstance(get_plugin_vars(), dict)
    assert isinstance(test_case_0(), dict)


# Generated at 2022-06-25 14:22:01.923251
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Test case 0
    str_0 = '`\x0c '
    var_0 = get_vars_from_path(str_0, str_0, str_0, str_0)


# Generated at 2022-06-25 14:22:02.721422
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    var_2 = 'plugin'

# Generated at 2022-06-25 14:22:09.426050
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    b_0 = 'F'

    # Test branches for try-except statement (try-except-else block)

# Generated at 2022-06-25 14:22:17.483271
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    assert(get_plugin_vars('get_plugin_vars',
                           'get_vars_from_path',
                           'get_vars_from_inventory_sources',
                           'get_vars_from_path') == get_plugin_vars(get_plugin_vars,
                                                                    get_vars_from_path,
                                                                    get_vars_from_inventory_sources,
                                                                    get_vars_from_path)
           )


# Generated at 2022-06-25 14:22:34.094160
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    str_0 = 'G'
    var_0 = get_plugin_vars(str_0, str_0, str_0, str_0)
    __builtins__.__dict__.__setitem__('str_1', 'o/')
    str_2 = '`\x0c '
    var_1 = get_plugin_vars(str_2, str_2, str_2, str_2)
    __builtins__.__dict__.__setitem__('str_3', ')')
    __builtins__.__dict__.__setitem__('str_4', '@')
    str_5 = '`\x0c '
    var_2 = get_plugin_vars(str_5, str_5, str_5, str_5)
    __builtins__.__

# Generated at 2022-06-25 14:22:41.759848
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    var_0 = get_vars_from_path(2, 4, 8, 16)
    assert var_0 == 2
    var_0 = get_vars_from_path(4, (4, 8), 16, 32)
    assert var_0 == 4
    var_0 = get_vars_from_path(8, (8, 16), 32, 64)
    assert var_0 == 8
    var_0 = get_vars_from_path(16, (16, 32), 64, 128)
    assert var_0 == 16
    var_0 = get_vars_from_path(32, (32, 64), 128, 256)
    assert var_0 == 32
    var_0 = get_vars_from_path(64, (64, 128), 256, 512)

# Generated at 2022-06-25 14:22:50.989128
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    # Load test data
    data = load_fixture('get_plugin_vars.yaml')
    data = data['test_cases']

    # Run test

# Generated at 2022-06-25 14:22:51.688191
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    display.warning('test not implemented')


# Generated at 2022-06-25 14:22:52.173947
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    assert True

# Generated at 2022-06-25 14:23:02.396541
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    subdir_path = './../../ansible/plugins/vars'
    sources = [subdir_path]
    str_0 = '`\x0c '
    str_1 = '\x0c'
    str_2 = 'om3tri3'
    str_3 = '2'
    str_4 = 'trio'
    str_5 = '2'
    str_6 = 'om3'
    var_0 = get_vars_from_path(sources, str_0, str_1, str_2)
    var_1 = get_vars_from_path(sources, str_3, str_4, str_5)
    var_2 = get_vars_from_path(sources, str_6, str_6, str_6)
    assert var_0

# Generated at 2022-06-25 14:23:09.965109
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    str_0 = '`\x0c '
    str_1 = '~\xeb\x8d'
    var_0 = get_plugin_vars(str_0, str_0, str_0, str_0)
    var_1 = get_plugin_vars(str_1, str_0, str_0, str_0)
    var_2 = get_plugin_vars(str_1, str_1, str_0, str_0)
    var_3 = get_plugin_vars(str_1, str_1, str_1, str_0)
    var_4 = get_plugin_vars(str_1, str_1, str_1, str_1)


# Generated at 2022-06-25 14:23:17.744030
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    # Arguments (positional)
    str_0 = '\x00\x10\x17F\x1d'
    str_1 = '\x00\x10\x17F\x1d'
    str_2 = '\x00\x10\x17F\x1d'
    str_3 = '\x00\x10\x17F\x1d'
    # Return values (types and ordering)
    return_values = (None,)
    # Actual return values (from call)
    actual = get_vars_from_path(str_0, str_1, str_2, str_3)

    assert actual == return_values

# Generated at 2022-06-25 14:23:19.051005
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    # Test case #0
    test_case_0()



# Generated at 2022-06-25 14:23:19.909356
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert callable(get_vars_from_path)

# Generated at 2022-06-25 14:23:47.725419
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    cwd = os.getcwd()
    f = os.listdir(cwd)
    if 'VARIABLES.txt' not in f:
        with open('VARIABLES.txt', 'w') as out:
            out.write('Testing')
        vars_loader.add_directory(cwd)
    else:
        with open('VARIABLES.txt', 'w') as out:
            out.write('Testing')

    str_0 = '`\x0c '
    var_0 = get_vars_from_path(str_0, str_0, str_0, str_0)
    assert var_0 == {}



# Generated at 2022-06-25 14:23:52.592912
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    var_1 = ' '
    var_2 = '\n'
    var_3 = '\x0c'
    var_4 = '\x0c\n'
    var_5 = get_plugin_vars(var_1, var_2, var_3, var_4)
    assert var_5 == {}, 'get_plugin_vars has failed.'


# Generated at 2022-06-25 14:23:53.746496
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    assert get_plugin_vars (str_1, str_1, str_1, str_1) == str_0


# Generated at 2022-06-25 14:23:54.873393
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    f = None

# Generated at 2022-06-25 14:23:55.988244
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    
    assert True # TODO: implement your test here


# Generated at 2022-06-25 14:23:59.917369
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    print('Start Function Test')
    print('Testing function get_vars_from_path')
    print('\tCase 0: Invalid Input')
    test_case_0()
    print('Function Test Completed')

test_get_vars_from_path()

# Generated at 2022-06-25 14:24:02.114166
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    var_0 = get_vars_from_path(str, str, str, str)


# Generated at 2022-06-25 14:24:04.905224
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    string = 'test/string'
    test_case_0()
    test_case_1()
    test_case_2()



# Generated at 2022-06-25 14:24:07.374150
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    # Test function arguments
    loader = ''
    plugin = ''
    path = ''
    entities = ''
    get_plugin_vars(loader, plugin, path, entities)



# Generated at 2022-06-25 14:24:12.308321
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # disable this test for now (before it even gets implemented)
    # see https://github.com/ansible/ansible/issues/54129
    # try:
    #     test_case_0()
    # except Exception as err:
    #     assert(err == 'unexpected error')
    pass


# Generated at 2022-06-25 14:24:23.425184
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert True



# Generated at 2022-06-25 14:24:27.829154
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    res_0_0 = get_vars_from_path(str_0, str_0, str_0, str_0)
    res_1_0 = get_vars_from_path(int_0, str_0, str_0, int_0)

    assert res_0_0 is None
    assert res_1_0 is None


# Generated at 2022-06-25 14:24:30.319532
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    # get_plugin_vars(loader, plugin, path, entities)
    # Calling with no arguments so a series of tests are run and results are printed to the terminal
    get_plugin_vars()



# Generated at 2022-06-25 14:24:36.643224
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    str_0 = '`\x0c '
    str_1 = ' #=g'
    str_2 = 's'
    str_3 = '\x00\x0a\r$\x7f%'
    str_4 = ','

# Generated at 2022-06-25 14:24:47.373854
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    var_0 = '|'
    var_1 = '\x02\x03\x0d\x10\x1c\x1d\x1f\x01\x07\x0a\x06\x0b\x04\x0e\x1a\x12\x15\x09\x14\x11\x17\x1e\x0f\x08\x13\x05'
    var_2 = '#'
    var_3 = 1
    var_4 = '<'
    var_5 = '^'

# Generated at 2022-06-25 14:24:55.427981
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Range 1: boolean, string, integer, real, none
    str_0 = '`\x0c '
    list_0 = [str_0, str_0, str_0, str_0, str_0]
    # Range 1: boolean, string, integer, real, none
    str_1 = 'lint'
    list_1 = [str_1, str_1, str_1, str_1, str_1]
    # Range 1: boolean, string, integer, real, none
    str_2 = 'YQ8Wc+E'
    list_2 = [str_2, str_2, str_2, str_2, str_2]
    # Range 1: boolean, string, integer, real, none
    str_3 = '\x18\x1a'

# Generated at 2022-06-25 14:25:03.114961
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'z@R#u'
    str_1 = 'test'
    str_2 = '*]/'
    str_3 = 'test'
    tuple_0 = (str_0, str_1)
    tuple_1 = (str_2, str_3)
    dict_0 = dict([tuple_0, tuple_1])
    var_0 = get_vars_from_path(str_3, str_3, str_3, str_3)
    assert var_0 == dict_0



# Generated at 2022-06-25 14:25:04.144394
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    assert True


# Generated at 2022-06-25 14:25:05.465491
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert False



# Generated at 2022-06-25 14:25:09.778632
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    f_0 = '/usr/sbin/libsopid'
    str_0 = 'S'
    str_1 = 'V'
    var_0 = get_vars_from_path(f_0, str_0, str_1, str_0)
    assert var_0 is None


# Generated at 2022-06-25 14:25:36.764869
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    path = '/var/log/'
    loader = '$LQE'
    stage = 'all'
    var_0 = get_vars_from_path(loader, path, None, stage)
    assert len(var_0) == 0