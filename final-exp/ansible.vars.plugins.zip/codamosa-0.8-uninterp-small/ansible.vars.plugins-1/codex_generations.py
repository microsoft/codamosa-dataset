

# Generated at 2022-06-25 14:16:02.964216
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    # Assume we have a file structure of this type:
    # host_vars
    #   host_0
    #   host_1
    # group_vars
    #   group_0
    #   group_1
    #   all
    host_0 = Host(name="host_0")
    host_1 = Host(name="host_1")
    host_2 = Host(name="host_2")
    group_0 = Host(name="group_0")
    group_1 = Host(name="group_1")
    group_2 = Host(name="group_2")

    dir_path = os.path.dirname(os.path.realpath(__file__))
    host_vars_path = os.path.join(dir_path, 'host_vars')
    group_vars

# Generated at 2022-06-25 14:16:06.241377
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    try:
        test_case_0()
    except Exception as ex:
        print('Unit test for function get_vars_from_path() failed: %s' % ex)
        return False
    else:
        print('Unit test for function get_vars_from_path() passed.')
        return True



# Generated at 2022-06-25 14:16:12.496670
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_1 = 'file:%(path)s'

# Generated at 2022-06-25 14:16:21.503338
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    # Test scenario where 'groups' are called on a plugin object
    plugin = vars_loader.get('group_vars')
    data = get_plugin_vars(plugin, 'inventory/hosts', ['group1', 'group2', 'group3'])
    assert len(data) == 3
    assert isinstance(data, dict)

    # Test scenario where 'hosts' are called on a plugin object
    plugin = vars_loader.get('host_vars')
    data = get_plugin_vars(plugin, 'inventory/hosts', ['host1', 'host2', 'host3'])
    assert len(data) == 3
    assert isinstance(data, dict)

    # Test scenario where 'host' is called on a plugin object
    plugin = vars_loader.get('host_vars')

# Generated at 2022-06-25 14:16:24.760691
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    bytes_0 = b'\xab'
    str_0 = 'local'

    s = '{\n"foo": "bar"\n}'
    result = get_vars_from_path(str_0, str_0, str_0, bytes_0)
    assert result == {'foo': 'bar'}



# Generated at 2022-06-25 14:16:25.237561
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    assert True

# Generated at 2022-06-25 14:16:27.212862
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    bytes_0 = b'\xab'
    str_0 = 'local'
    var_0 = get_plugin_vars(str_0, str_0, bytes_0, str_0)


# Generated at 2022-06-25 14:16:31.335038
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    bytes_0 = b'\xab'
    str_0 = 'K'
    var_0 = get_vars_from_path(str_0, bytes_0, str_0, str_0)
    assert var_0 == None


# Generated at 2022-06-25 14:16:35.923788
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    sources = False
    entities = None
    stage = 'task'
    var_0 = get_vars_from_inventory_sources(sources, entities, stage)
    print (var_0)
    print ("Unit test for function get_vars_from_inventory_sources completed")

if __name__ == "__main__":
    test_get_vars_from_inventory_sources()

# Generated at 2022-06-25 14:16:46.377933
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    result_0 = get_vars_from_path(str_0, bytes_0, str_0, str_0)
    result_1 = get_vars_from_path(str_0, bytes_0, str_0, str_0)
    result_2 = get_vars_from_path(str_0, bytes_0, str_0, str_0)
    result_3 = get_vars_from_path(str_0, bytes_0, str_0, str_0)

    str_1 = '|'

    assert result_0 in [result_1, result_2, result_3] and result_1 in [result_0, result_2, result_3] and result_2 in [result_0, result_1, result_3]

# Generated at 2022-06-25 14:17:00.208387
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    # Trying to load an unsupported v1 var plugin
    loader = 'loader'
    plugin = None
    path = 'path'
    entities = 'entities'

    try:
        get_plugin_vars(loader, plugin, path, entities)
    except AnsibleError as e:
        print(repr(e))
    else:
        raise Exception("Expected AnsibleError")


# Generated at 2022-06-25 14:17:02.839276
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    sources = ['./test/test_vars.txt', 'test_test.py']
    var_0 = get_vars_from_inventory_sources(bytes_0, sources, str_1, str_0)

# Generated at 2022-06-25 14:17:13.669399
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    '''
    This is the unit test for get_plugin_vars
    '''

    # create mock object
    loader = VarsLoader('/etc/ansible/ansible.cfg')
    plugin = VarsPlugin('/usr/share/ansible_plugins/vars/group_vars/all.yml')
    path = '<string>'
    entities = ['local', 'localhost']

    # test with invalid plugin.get_vars
    data = {}

# Generated at 2022-06-25 14:17:14.762168
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert True


# Generated at 2022-06-25 14:17:19.557231
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    plugin_name_0 = 'command'
    loader_0 = Display()
    path_0 = 'ansible/plugins/cache'
    entities_0 = 'runners/cache'

    # Call function get_plugin_vars
    get_plugin_vars(plugin_name_0, loader_0, path_0, entities_0)



# Generated at 2022-06-25 14:17:25.973196
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Print a message
    display.display(u"THIS IS A MESSAGE!")

    # Print an error message
    display.error(u"THIS IS AN ERROR!")

    # Print a warning message
    display.warning(u"THIS IS A WARNING!")

    # Print a deprecation message
    display.deprecated(u"THIS IS A DEPRECATION!")

    print(u"THIS IS PRINTED")

# Generated at 2022-06-25 14:17:26.928196
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    test_case_0()


# Generated at 2022-06-25 14:17:29.466108
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str = 'local'
    bytes = b'\xab'
    get_plugin_vars(str, str, bytes, str)
    get_vars_from_path(str, bytes, str, str)

# Generated at 2022-06-25 14:17:36.220536
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    bytes_0 = b'\xae'
    bytes_1 = b'\xab'
    str_0 = 'null'
    list_0 = []
    list_1 = []
    list_1.append('vars_loader')
    list_0.append(list_1)
    var_0 = VarsModule(str_0, list_0)
    var_1 = get_plugin_vars(var_0, bytes_0, bytes_1, str_0)



# Generated at 2022-06-25 14:17:42.284397
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    bytes_0 = b'\x30\x3a\x7a\x9e\xb8\xc3\x5e\x35\xee\x05'
    str_0 = 'role_1'
    var_0 = get_plugin_vars(str_0, bytes_0, bytes_0, str_0)


# Generated at 2022-06-25 14:18:07.577929
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    pass




# Generated at 2022-06-25 14:18:12.603719
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    var_0 = ansible.inventory.host.Host(b'\xab')
    var_0.vars = {'var_0': {'var_1': b'\xab'}, 'var_2': {'var_3': b'\xab'}}
    str_0 = b'\xab'
    str_1 = 'local'
    var_1 = get_vars_from_path(str_1, str_0, var_0, str_1)
    # Verify that var_1 equals {'var_1': b'\xab', 'var_2': {'var_3': b'\xab'}}.
    assert var_1 == {'var_1': b'\xab', 'var_2': {'var_3': b'\xab'}}
    var_

# Generated at 2022-06-25 14:18:23.250325
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    global get_vars_from_path
    # Unit tests for get_vars_from_path
    # Test case 0

    # Test case 1
    data_1 = get_vars_from_path(to_bytes('hostfile'), to_bytes(b'./ansible/modules/utilities/logic/assemble'), to_bytes('fake'), to_bytes('start'))
    assert data_1 == {}

    # Test case 2
    data_2 = get_vars_from_path(to_bytes('fake'), to_bytes(b'./ansible/modules/utilities/logic/assemble'), to_bytes('fake'), to_bytes('start'))
    assert data_2 == {}

    # Test case 3

# Generated at 2022-06-25 14:18:26.387997
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    bytes_0 = b'\xab'
    str_0 = 'local'
    var_0 = get_vars_from_path(str_0, bytes_0, str_0, str_0)

    assert var_0 == {}

# Generated at 2022-06-25 14:18:28.876491
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert get_vars_from_path(str, str, str, str) == {}, "Failed assertion test_get_vars_from_path"

# Generated at 2022-06-25 14:18:38.327208
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    # Testing parameters
    loader = 'local'
    entities = 'local'
    stage = 'local'

    # Testing with byte param byte
    byte_param = b'\xab'
    test_case_0()

    # Testing with str param str
    str_param = 'local'
    test_case_0()

    # Testing with AnsibleVars param AnsibleVars
    AnsibleVars_param = AnsibleVars(loader, entities, stage)
    test_case_0()

    # Testing with AnsibleVars param AnsibleVars
    AnsibleVars_param = AnsibleVars(loader, entities, stage)
    test_case_0()

    # Testing with AnsibleVars param AnsibleVars
    AnsibleVars_param = AnsibleVars(loader, entities, stage)
    test

# Generated at 2022-06-25 14:18:42.878139
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    test_case_0()
    # testing for exceptions
    try:
        get_vars_from_path('a')
        raise Exception("Failed")
    except TypeError:
        pass
    try:
        get_vars_from_path(None)
        raise Exception("Failed")
    except TypeError:
        pass



# Generated at 2022-06-25 14:18:44.155873
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    assert not get_plugin_vars()



# Generated at 2022-06-25 14:18:51.035831
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    bytes_0 = b'\xac'
    str_0 = 'amatage'
    int_0 = 1
    int_1 = 9
    int_2 = 1
    list_0 = [bytes_0, str_0, int_0, int_1]
    list_1 = [int_2, list_0]

    assert len(get_plugin_vars(str_0, int_0, list_1, list_0)) == 0



# Generated at 2022-06-25 14:18:53.347252
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
   assert True

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 14:19:13.278823
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    bytes_0 = b'\xd2\x1d\xa3\x8a\xd3'
    str_0 = 'local'
    str_1 = 'yS'
    list_0 = [bytes_0]
    i_0 = 257
    bool_0 = True
    var_0 = get_vars_from_inventory_sources(str_0, list_0, str_1, i_0, bool_0)
    try:
        display.display(var_0)
    except Exception as e_0:
        display.display(e_0)


# Generated at 2022-06-25 14:19:14.127910
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    pass



# Generated at 2022-06-25 14:19:16.217509
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    print('Case 0:')
    test_case_0()
    

if __name__ == '__main__':
    test_get_vars_from_inventory_sources()

# Generated at 2022-06-25 14:19:18.610803
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_1 = 'local'
    str_2 = 'inventory'
    data = get_vars_from_path(str_1, str_1, str_1, str_2)



# Generated at 2022-06-25 14:19:27.288550
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    bytes_0 = b'\xef\xac\x9a'
    str_0 = 'fjK?\x1f6U\xe6\x10y\xaf\xc9\x9a\x97\x1a\xbf\xf8\xd1\xea0\x94\x86\xb3\xda\x1d\x05\x10\x9e\x9a\x87\xfc\x98\xb8\xf4\x82\xcd\x81\x8b\xd0\x80\x91\x04\x8f\xe2\x1e\xc6\x00\x9a\xe7'

# Generated at 2022-06-25 14:19:38.285519
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    bytes_0 = b'\xab'
    str_0 = 'local'
    var_0 = get_vars_from_path(str_0, bytes_0, str_0, str_0)
    assert var_0 == {}

    # Test for paths with a YAML extension
    str_1 = 'a=2'
    str_2 = 'b=3'
    var_1 = get_vars_from_path(str_1, str_2, str_1, str_0)
    assert var_1 == {}

    # Test for paths with a JSON extension
    str_3 = 'a=4'
    str_4 = 'b=5'
    var_2 = get_vars_from_path(str_3, str_4, str_3, str_0)
    assert var

# Generated at 2022-06-25 14:19:43.682290
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    # Testing with
    # vars_loader = C.DEFAULT_VARS_PLUGIN_PATH
    # plugin = ??
    # path = ??
    # entities = ??
    bytes_0 = b'\xab'
    str_0 = 'local'
    var_0 = get_plugin_vars(str_0, bytes_0, str_0, str_0)


# Generated at 2022-06-25 14:19:47.478086
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    str_0 = 'a'
    str_1 = 'b'
    str_2 = 'f'
    str_3 = '2'
    bytes_0 = b'\xab'
    var_0 = get_vars_from_path(str_0, bytes_0, str_1, str_2)


# Generated at 2022-06-25 14:19:49.762137
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    bytes_0 = b'\xab'
    str_0 = 'start'
    var_0 = get_vars_from_inventory_sources(str_0, bytes_0, bytes_0, str_0)

# Generated at 2022-06-25 14:19:54.095066
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    byte_pattern = b'\xde\xad\xbe\xef'
    str_0 = 'inventory'
    str_1 = 'path'
    str_2 = 'entities'
    str_3 = 'stage'
    var_0 = get_vars_from_path(str_0, str_1, str_2, str_3)
    assert var_0 == {}



# Generated at 2022-06-25 14:20:08.003613
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    assert get_plugin_vars(str_0, str_0, str_0, str_0) == var_0


# Generated at 2022-06-25 14:20:09.163220
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert callable(get_vars_from_path)


# Generated at 2022-06-25 14:20:09.948742
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert False


# Generated at 2022-06-25 14:20:13.965902
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'S\x0b ;e\\aOm'
    assert get_vars_from_path(str_0, str_0, str_0, str_0) == {}, str_0

    test_case_0()

# Generated at 2022-06-25 14:20:15.942341
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert True


# Generated at 2022-06-25 14:20:18.212266
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert False, "No tests written for function get_vars_from_path"


# Generated at 2022-06-25 14:20:26.153384
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # The assumption here is that we have a valid directory named tests/vars_test/test_dir,
    # which contains a valid yaml file named test.yaml.

    # First we will test the case where there is a valid directory and file in it.
    test_path = os.getcwd() + "/tests/vars_test/test_dir"
    var_dict = get_vars_from_path(None, test_path, None, None)
    test_var = var_dict["ansible_var"]
    assert test_var == "This is a test var"

    # Test the case where there is no file in the passed in directory.
    test_path = os.getcwd() + "/tests/vars_test"

# Generated at 2022-06-25 14:20:36.519711
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'B\x0b\x0c9e\\aOm'
    str_1 = 'E\x0b ;e\\aOm'
    var_0 = get_vars_from_path(str_0, str_0, str_0, str_0)
    var_1 = get_vars_from_path(str_1, str_1, str_1, str_1)
    assert var_0 == var_1

    str_0 = '0\x0b ;e\\aOm'
    str_1 = 'C\x0b ;e\\aOm'
    var_0 = get_vars_from_path(str_0, str_0, str_0, str_0)

# Generated at 2022-06-25 14:20:37.390727
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    test_case_0()


# Generated at 2022-06-25 14:20:43.367738
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    func = get_vars_from_path
    param_0 = '\x0b'
    param_1 = {}
    param_2 = {}
    param_3 = {}
    param_4 = {}
    param_5 = {}
    param_6 = {}
    assert func(param_0, param_1, param_2, param_3, param_4, param_5, param_6)


# Generated at 2022-06-25 14:20:59.536981
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    ret_0 = get_vars_from_path('k\x0b', 'VN.F2', 'tXJ\x0b', 'production')
    ret_1 = get_vars_from_path('k\x0b', 'VN.F2', 'tXJ\x0b', 'production')
    assert ret_0 == ret_1



# Generated at 2022-06-25 14:21:08.872875
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'S\x0b ;e\\aOm'
    str_1 = 'S\x0b ;e\\aOm'
    str_2 = 'S\x0b ;e\\aOm'
    str_3 = 'S\x0b ;e\\aOm'
    str_4 = 'S\x0b ;e\\aOm'
    str_5 = 'S\x0b ;e\\aOm'
    dict_0 = {str_0: {str_1: str_2, str_3: str_4, str_5: 2.5}, '10.2.3.1': {'ansible_connection': 'local'}}

# Generated at 2022-06-25 14:21:10.563193
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    assert True

# Generated at 2022-06-25 14:21:18.650973
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'S\x0b ;e\\aOm'
    str_1 = 'Y\x1c gR\x0f\x0c\x15e'
    str_2 = 'C3\x13\x1c\x0e\x0c'
    var_0 = get_vars_from_path(str_0, str_1, str_2, str_0)
    assert str(var_0) == 'C3\x13\x1c\x0e\x0c'


# Generated at 2022-06-25 14:21:21.729495
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    assert get_vars_from_inventory_sources(None, None, None, None);
    assert get_vars_from_inventory_sources(None, "Hello World", None, None);


# Generated at 2022-06-25 14:21:27.401600
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Test with a path to a directory
    assert get_vars_from_path("/path", "/path", "", "") == {}

    # Test with a path to a file
    assert get_vars_from_path("/path/to/file.txt", "/path/to/file.txt", "", "") == {}

# Generated at 2022-06-25 14:21:28.597308
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert not get_vars_from_path(None, None, None, None)

# Generated at 2022-06-25 14:21:37.306305
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    path_0 = '/home/vagrant/a/a.py'
    path_1 = 'a,in,host,list'
    path_2 = '/home/vagrant'
    path_3 = '/home/vagrant/.vagrant.d/boxes/debian-VAGRANTSLASH-stretch64/7.9.2/virtualbox/box.ovf'
    list_0 = [path_0, path_1, path_2]
    list_1 = [path_0,path_1,path_2,path_3]
    str_0 = 'S\x0b ;e\\aOm'
    var_0 = get_vars_from_inventory_sources(list_0, list_1, str_0, str_0)


# Generated at 2022-06-25 14:21:45.420971
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    str_0 = 'S\x0b ;e\\aOm'
    str_1 = 'C\x1a4\x0e\x07\x0b\x14\x10!\x06\x1b\x1b'
    str_2 = ' q\x18\x16&\x0e\x1d\x13'
    str_4 = 'a\x10\x14\x00\x0c\x14\x05\x0b\x0e\x16'
    str_5 = 'c\x1a\x1f\x0f\x15\x18\x0f\x14'

# Generated at 2022-06-25 14:21:54.684035
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = ''
    assert get_vars_from_path(str_0, str_0, str_0, str_0) == {}
    str_0 = 'Q\x12\x0cF@\x1e\\\\|\x0f\\\x1f\x0f\x1c^'
    assert get_vars_from_path(str_0, str_0, str_0, str_0) == {}
    str_0 = "Q\x12\x0cF@\x1e\\\\|\x0f\\\x1f\x0f\x1c^J\x14\x0f'`\x1b\x08@"

# Generated at 2022-06-25 14:22:07.455603
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    test_case_0()


# Generated at 2022-06-25 14:22:09.451065
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert (get_vars_from_path == 'S\x0b ;e\\aOm')


# Generated at 2022-06-25 14:22:14.425602
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'S\x0b ;e\\aOm'
    var_0 = get_vars_from_path(str_0, str_0, str_0, str_0)
    assert var_0 == {}


# Generated at 2022-06-25 14:22:17.403110
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    str_0 = 'F}Z\x1e{R'
    var_0 = get_vars_from_inventory_sources(str_0, str_0, str_0, str_0)
    assert isinstance(var_0, dict)

# Generated at 2022-06-25 14:22:18.756406
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    pass


# Generated at 2022-06-25 14:22:21.553187
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    data = get_vars_from_path(str(), str(), str(), str())
    assert data is not None


# Generated at 2022-06-25 14:22:24.603147
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    my_var = 'test'
    s = []
    s.append(my_var)
    assert get_vars_from_path(s, s, s, s) == my_var

# Generated at 2022-06-25 14:22:27.777439
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'S\x0b ;e\\aOm'
    var_0 = get_vars_from_path(str_0, str_0, str_0, str_0)
    assert var_0 == {}



# Generated at 2022-06-25 14:22:29.463888
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    assert True # TODO: implement your test here


# Generated at 2022-06-25 14:22:38.133201
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Test setup:
    #
    # TODO(ssw): Setup parameters for test
    #
    # Example for each parameter:
    # var_0 = ['vars_loader', 'all']
    # var_1 = ['vars_loader', 'get', 'plugin_name']
    # var_2 = ['vars_loader', 'get_plugin_vars', 'loader', 'path', 'entities']
    # var_3 = ['loader']
    # var_4 = ['path']
    # var_5 = ['entities']
    # var_6 = ['stage']
    
    # Test case 1:
    test_case_0()

# Generated at 2022-06-25 14:22:54.687192
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = "10.1.183.82"
    str_1 = "10.1.183.83"
    str_2 = "10.1.183.84"
    str_3 = "10.1.183.85"
    str_4 = "g,tcp://10.1.183.83'Xtcp://10.1.183.84:22"
    str_5 = "tcp://10.1.183.85:22"
    str_6 = "tcp://10.1.183.86:22"
    str_7 = "tcp://10.1.183.87:22"
    str_8 = "tcp://10.1.183.88:22"
    str_9 = "tcp://10.1.183.89:22"

# Generated at 2022-06-25 14:22:57.266473
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assertTrue(get_vars_from_path, "Impossible to find function 'get_vars_from_path'") 


# Generated at 2022-06-25 14:23:02.451769
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    str_0 = 'S\x0b ;e\\aOm'
    var_0 = get_plugin_vars(str_0, str_0, str_0, str_0)
    var_1 = get_plugin_vars(str_0, str_0, str_0, str_0)


# Generated at 2022-06-25 14:23:06.632998
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'a'
    str_1 = 'b'
    str_2 = 'c'
    str_3 = 'd'
    var_0 = get_vars_from_path(str_0, str_1, str_2, str_3)
    print(var_0)


# Generated at 2022-06-25 14:23:14.083415
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    source_0 = ['plugins/vars/unittest_plugin.yml']
    loader_0 = 'plugins/vars/unittest_plugin.yml'
    entities_0 = 'plugins/vars/unittest_plugin.yml'
    stage_0 = 'plugins/vars/unittest_plugin.yml'

    var_0 = get_vars_from_path(loader_0, source_0, entities_0, stage_0)

    assert var_0 == dict({'var_val': 'test_value'})


# Generated at 2022-06-25 14:23:14.912366
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # simple sanity check
    test_case_0()


# Generated at 2022-06-25 14:23:16.346286
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert get_vars_from_path('', '', '', '') is None

# Generated at 2022-06-25 14:23:24.312007
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    # Test with 4 args
    str_0 = 'T\\Z'
    int_0 = 117
    str_1 = 'v-9'
    str_2 = 'e\\D'
    str_3 = '[8'
    str_4 = 'r~['
    str_5 = 'R?'
    str_6 = '7bQ'
    str_7 = 'o>3'
    str_8 = '5@5'
    str_9 = '<~4'
    str_10 = 'F_C'
    str_11 = 'e'
    str_12 = 'm'
    str_13 = 'd'
    str_14 = 'y'
    int_1 = 1
    int_2 = -1
    int_3 = -1
    int_4 = -1
    int

# Generated at 2022-06-25 14:23:31.218107
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    first_str = 'ABC123'
    second_str = 'DEF456'
    third_str = 'CBA321'
    fourth_str = '654FED'
    var_0 = get_vars_from_path(first_str, second_str, third_str, fourth_str)
    print(var_0)
    print(isinstance(var_0, dict))



# Generated at 2022-06-25 14:23:36.391909
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert callable(get_vars_from_path)
    str_1 = 't,\x7f<'
    var_0 = get_vars_from_path(str_1, None, None, None)
    assert var_0 == {}
    str_2 = 'S\x0b ;e\\aOm'
    var_1 = get_vars_from_path(str_2, str_2, str_2, str_2)


# Generated at 2022-06-25 14:23:54.390240
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    #print("Start test_get_vars_from_path")
    var_0 = get_vars_from_path(str, str, str, str)
    assert(type(var_0) == dict)

    var_0 = get_vars_from_path(list, str, str, str)
    assert(type(var_0) == dict)

    var_0 = get_vars_from_path(str, dict, str, str)
    assert(type(var_0) == dict)

    var_0 = get_vars_from_path(str, str, dict, str)
    assert(type(var_0) == dict)

    var_0 = get_vars_from_path(str, str, str, list)
    assert(type(var_0) == dict)

    var

# Generated at 2022-06-25 14:23:58.365408
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    _loader = None
    _path = None
    _entities = None
    _stage = None
    try:
        var_0 = get_vars_from_path(_loader, _path, _entities, _stage)
        test_case_0()
    except AnsibleError as error:
        print(error)
        raise error


# Generated at 2022-06-25 14:23:59.342947
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert True

# Generated at 2022-06-25 14:24:01.807608
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    var_0 = get_vars_from_path('start', None, 'start', 'start')



# Generated at 2022-06-25 14:24:02.410715
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    assert True

# Generated at 2022-06-25 14:24:04.805576
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    assert get_plugin_vars(str, str, str, str) == None


# Generated at 2022-06-25 14:24:07.867052
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Test with default input
    str_0 = 'S\x0b ;e\\aOm'
    var_0 = get_vars_from_path(str_0, str_0, str_0, str_0)
    return var_0


# Generated at 2022-06-25 14:24:11.780544
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    var_1 = get_vars_from_path(to_bytes('path'), to_bytes('C:\\'), to_bytes('C:\\'), to_bytes('path'))
    assert var_1


# Generated at 2022-06-25 14:24:13.731231
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert get_vars_from_path(str_0, str_0, str_0, str_0) == var_0

# Generated at 2022-06-25 14:24:23.743597
# Unit test for function get_vars_from_path

# Generated at 2022-06-25 14:24:39.905317
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert get_vars_from_path(None, None, None, None) == {}
    assert get_vars_from_path('S\x0b ;e\\aOm', 'S\x0b ;e\\aOm', 'S\x0b ;e\\aOm', 'S\x0b ;e\\aOm') == {}

test_case_0()

# Generated at 2022-06-25 14:24:42.682161
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'S\x0b ;e\\aOm'
    var_0 = get_vars_from_path(str_0, str_0, str_0, str_0)


# Generated at 2022-06-25 14:24:47.573863
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    try:
        # Test Default
        result = get_vars_from_path('loader', 'path', 'entities', 'stage')
        assert result is None
    except Exception as e:
        print("Test Case 0: FAIL")
        raise
    else:
        print("Test Case 0: PASS")


# Generated at 2022-06-25 14:24:52.923070
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'S\x0b ;e\\aOm'
    var_0 = get_vars_from_path(str_0, str_0, str_0, str_0)
    assert var_0 == {}

    str_1 = 'S\x0b ;e\\aOm'
    var_1 = get_vars_from_path(str_1, str_1, str_1, str_1)
    assert var_1 == {}

# Generated at 2022-06-25 14:24:53.571438
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    test_case_0()



# Generated at 2022-06-25 14:24:56.790197
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_1 = 'S\x0b ;e\\aOm'
    var_1 = get_vars_from_path(str_1, str_1, str_1, str_1)


if __name__ == '__main__':
    test_case_0()
    test_get_vars_from_path()

# Generated at 2022-06-25 14:24:57.850116
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    TEST_CASE_0('test_case_0')

# Generated at 2022-06-25 14:24:59.544242
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    test_case_0()


# Generated at 2022-06-25 14:25:10.505693
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Make sure the result of get_vars_from_path is deterministic

    # Setup
    test_desc = "Test get_vars_from_path"
    test_path = "/test/path"
    test_entities = [Host('test_host'), Host('test_host2')]
    test_stage = 'inventory'

    # Exercise
    var_0 = 'S\x0b ;e\\aOm'
    var_1 = get_vars_from_path(var_0, test_path, test_entities, test_stage)
    var_2 = get_vars_from_path(var_0, test_path, test_entities, test_stage)

    # Verify
    assert var_1 == var_2, "var_1 != var_2"


# Generated at 2022-06-25 14:25:11.473153
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert True


# Generated at 2022-06-25 14:25:31.724987
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    # Test injection of path into data returned by get_plugin_vars
    #
    # Must end in '__' to avoid collision with actual plugins.
    # Can't be called 'test' because that's a special case in combine_vars
    vars_loader.add('test_get_vars_from_path__', '_test_get_vars_from_path_')

    class _test_get_vars_from_path_(object):
        _load_name = '_test_get_vars_from_path_'
        def get_vars(self, loader, path, entities):
            return {'__test_get_vars_from_path__': path}

    # Path
    data = get_vars_from_path(vars_loader, '/path/to/ansible', None, None)

# Generated at 2022-06-25 14:25:39.964836
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    sources = [None, '/', '/home/test_user/.ansible/tmp/ansible-tmp-1560347742.16-47298745231666']
    entities = [None, 'localhost', '1.2.3.4']
    stage = [None, 'inventory', 'task']
    loader = ['localhost', None, '/']
    str_1 = '^\x00\x01\x00\x00:\x13\x04'
    str_2 = '^\x00\x01\x00\x00:\x13\x04\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    str_