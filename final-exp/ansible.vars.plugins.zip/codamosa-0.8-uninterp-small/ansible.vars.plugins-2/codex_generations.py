

# Generated at 2022-06-25 14:16:40.625049
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    assert True

# Generated at 2022-06-25 14:16:45.059990
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    bytes_0 = b'\xbb\x8dA"\xae\xacn\xdd\xa6,'
    str_0 = '$mt26)~F]]P'
    var_0 = get_vars_from_path(bytes_0, str_0, str_0, str_0)


# Generated at 2022-06-25 14:16:54.378293
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    # Some test code to get started
    bytes_0 = b'\xbb\x8dA"\xae\xacn\xdd\xa6,'
    str_0 = '$mt26)~F]]P'
    var_0 = get_vars_from_inventory_sources(bytes_0, str_0, str_0, str_0)

if __name__ == '__main__':
    for var in list(globals().keys()):
        if var.startswith('test_'):
            print('Testing %s' % var)
            globals()[var]()

# Generated at 2022-06-25 14:17:01.375494
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    bytes_0 = 'x\x9c\xbd\xbeO\x0f\x8bs\x90\x97\x05\x85q\x9b\x94\xcb'
    str_0 = '|\x06\xe2\x1d\xeb\x95\x9c\x14'
    int_0 = -1
    str_1 = 'C'
    var_0 = get_plugin_vars(bytes_0, str_0, int_0, str_1)
    assert var_0 == 6


# Generated at 2022-06-25 14:17:11.597647
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    bytes_0 = b'\xbb\x8dA"\xae\xacn\xdd\xa6,'
    str_0 = 'Xt0'
    str_1 = '*%_'
    str_2 = '~O&\x15\xcc\xa9'
    var_0 = get_vars_from_path(bytes_0, str_0, str_1, str_2)

# Generated at 2022-06-25 14:17:22.997936
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    arg_0 = None
    arg_1 = '/k\x1a\xca\x95\xed\x0c.\x1e\x81\x0f\x8e0\xea'
    arg_2 = '\x9fY\x18{>\xab\x99\x8e\x164\x07\xe8'
    arg_3 = '\x07\x95\x80ju\xfd.\x14\xccD\x8f\x19'
    out_0 = get_vars_from_inventory_sources(arg_0, arg_1, arg_2, arg_3)

# Generated at 2022-06-25 14:17:27.722609
# Unit test for function get_vars_from_path

# Generated at 2022-06-25 14:17:31.051689
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    loader = None
    path = 'YiNc%H'
    entities = None
    stage = 'tov/i=9'
    var_0 = get_vars_from_path(loader, path, entities, stage)


# Generated at 2022-06-25 14:17:40.810378
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    ansible_vars_all = get_vars_from_path('/home/work/ansible/lib/ansible/plugins/vars/', '/etc/ansible/hosts', 'all', 'task')
    assert isinstance(ansible_vars_all, dict)
    ansible_vars_windows = get_vars_from_path('/home/work/ansible/lib/ansible/plugins/vars/', 'C:/Users/Administrator/Desktop/ccc/aaa/ansible/hosts', 'all', 'task')
    assert isinstance(ansible_vars_windows, dict)


# Generated at 2022-06-25 14:17:43.191215
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    var_1 = get_vars_from_path(bytes_0, str_0, str_0, str_0)
    assert var_1 == var_0


# Generated at 2022-06-25 14:17:56.330911
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    check_content = {'ansible_connection': 'docker', 'ansible_network_os': 'ios',
                     'ansible_ssh_user': 'labuser', 'inventory_hostname': 'rtr01'}
    content = get_vars_from_path('', 'test_case_1/host_vars',
                                 '', '')
    assert content == check_content


# Generated at 2022-06-25 14:18:03.292777
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'Z%o'
    bytes_0 = b'\xd8\xfa\xce\xacK\xac\xaa\xac\xd2\x9b'
    bytes_1 = b'\x83\xd5\xfc\xda\xd8\xe1\xa9'
    var_0 = get_vars_from_path(bytes_0, str_0, bytes_1, str_0)


# Generated at 2022-06-25 14:18:05.337934
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    var_0 = get_vars_from_inventory_sources()
    assert var_0 == bytes_0



# Generated at 2022-06-25 14:18:13.439630
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    bytes_0 = b'\xe8\x89\x9f\x91\xa5\x11\xea\x83\x11\xa1I\xd0\x88\xf6\x9d\xab\xc1\x85\xd6\xd3\xfb\x8c\xa2+\x11\xaf\x1d\xe3s'
    vars_plugin_list_0 = list(vars_loader.all())
    for plugin_name_0 in C.VARIABLE_PLUGINS_ENABLED:
        # Test if condition true
        if 1:
            # Test if condition true
            if 1:
                vars_plugin_0 = vars_loader.get(plugin_name_0)

# Generated at 2022-06-25 14:18:24.171826
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    data = {'group_name': 'test_inventory.test_host'}
    entities = [Host(name='test_host')]
    path = 'test_path'

    loader = C.VARIABLE_PLUGINS_ENABLED
    return_value = {'test_plugin': 'test_result'}

    vars_loader_mock = 'ansible.plugins.loader.vars_loader.all'
    get_plugin_data_mock = 'ansible.plugins.loader.vars_loader.get_vars_from_path.get_plugin_vars'


# Generated at 2022-06-25 14:18:28.335468
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    bytes_0 = b'\xbb\x8dA"\xae\xacn\xdd\xa6,'
    str_0 = '$mt26)~F]]P'
    var_0 = get_plugin_vars(bytes_0, str_0, str_0, str_0)
    assert var_0 == str_0


# Generated at 2022-06-25 14:18:31.314258
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    bytes_0 = b'\xbb\x8dA"\xae\xacn\xdd\xa6,'
    str_0 = '$mt26)~F]]P'
    var_0 = get_plugin_vars(bytes_0, str_0, str_0, str_0)


# Generated at 2022-06-25 14:18:40.655151
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
  test_arg_0 = b'\xbb\x8dA"\xae\xacn\xdd\xa6,'
  test_arg_1 = '$mt26)~F]]P'
  test_arg_2 = '$mt26)~F]]P'
  test_arg_3 = '$mt26)~F]]P'
  test_arg_4 = '$mt26)~F]]P'
  test_arg_5 = '$mt26)~F]]P'
  test_arg_6 = '$mt26)~F]]P'
  test_arg_7 = '$mt26)~F]]P'
  test_arg_8 = '$mt26)~F]]P'
  test_arg_9 = '$mt26)~F]]P'
  test_arg

# Generated at 2022-06-25 14:18:44.968784
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    bytes_0 = b'\xbb\x8dA"\xae\xacn\xdd\xa6,'
    str_0 = '$mt26)~F]]P'

    var_0 = get_vars_from_path(bytes_0, bytes_0, str_0, str_0)



# Generated at 2022-06-25 14:18:52.834442
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory import Inventory

    sources = ['/etc/ansible/hosts']
    stage = 'inventory'

    inv = Inventory(loader=None, variable_manager=None, host_list=sources)
    data = get_vars_from_path(inv.loader, to_bytes(sources[0], errors='surrogate_or_strict'), inv.hosts, stage)

    # import pprint
    # pprint.pprint(data)

    assert data


# Generated at 2022-06-25 14:19:03.145043
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    bytes_0 = b'\xbb\x8dA"\xae\xacn\xdd\xa6,'
    str_0 = '$mt26)~F]]P'
    assert(get_vars_from_path(bytes_0, str_0, str_0, str_0) == None)

# Generated at 2022-06-25 14:19:08.333340
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    bytes_0 = b'\xbb\x8dA"\xae\xacn\xdd\xa6,'
    str_0 = '$mt26)~F]]P'
    var_0 = get_plugin_vars(bytes_0, str_0, str_0, str_0)

# Generated at 2022-06-25 14:19:14.045828
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    bytes_0 = b'd\xae\x81\x91\xad\x99\x8c\x01\xa3'
    str_0 = '-;R/d"`'
    entities = [str_0, str_0, str_0]
    var_0 = get_vars_from_path(bytes_0, str_0, entities, str_0)


# Generated at 2022-06-25 14:19:18.047595
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    bytes_0 = b'\xbb\x8dA"\xae\xacn\xdd\xa6,'
    str_0 = '$mt26)~F]]P'
    var_0 = get_vars_from_path(bytes_0, str_0, str_0, str_0)
    assert var_0 is None


# Generated at 2022-06-25 14:19:27.217666
# Unit test for function get_plugin_vars

# Generated at 2022-06-25 14:19:29.073095
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    data = dict()
    loader = dict()
    path = dict()
    entities = dict()
    stage = dict()
    assert (get_vars_from_path(loader, path, entities, stage) == data)

# Generated at 2022-06-25 14:19:37.403953
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    # 0: bytes
    bytes_0 = b'\xbb\x8dA"\xae\xacn\xdd\xa6,'
    str_0 = '$mt26)~F]]P'
    str_1 = 'g"%osEi?9'
    str_2 = 'Y.%cQ2<,M'
    var_0 = get_vars_from_path(bytes_0, str_0, str_1, str_2)

    assert var_0 != None


# Generated at 2022-06-25 14:19:47.013290
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    bytes_0 = b'\xc5\x017\x10-\x0c\x9a\xf5y\xee\x8e\x1e\xc5\x93Q\x1c\xec\xf9'
    str_0 = ''
    var_0 = get_vars_from_path(bytes_0, bytes_0, str_0, str_0)
    assert var_0 == {}

    bytes_0 = b'\x90\x9d\x1e\xfe\xab\x80\x0f\xbb\x19\x02\xb8\xfe\xb9F\xf0\x01\x14\xff'
    str_0 = 'm]n:Cm%B9'

# Generated at 2022-06-25 14:19:47.839241
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert True


# Generated at 2022-06-25 14:19:52.156782
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    bytes_0 = b'\xbb\x8dA"\xae\xacn\xdd\xa6,'
    str_0 = '$mt26)~F]]P'
    var_0 = get_vars_from_path(bytes_0, str_0, str_0, str_0)
    assert var_0 == get_vars_from_path(bytes_0, str_0, str_0, str_0)


# Generated at 2022-06-25 14:19:59.875750
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert get_vars_from_path(bytes_0, str_0, str_0, str_0) == {str_0:str_0, str_0:str_0}


# Generated at 2022-06-25 14:20:00.371074
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    pass

# Generated at 2022-06-25 14:20:04.171541
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    bytes_0 = b'\xbb\x8dA"\xae\xacn\xdd\xa6,'
    str_0 = '$mt26)~F]]P'
    var_0 = get_vars_from_path(bytes_0, str_0, str_0, str_0)


# Generated at 2022-06-25 14:20:08.187297
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    bytes_0 = b'\xbb\x8dA"\xae\xacn\xdd\xa6,'
    str_0 = '*&v=KwH'
    var_0 = get_plugin_vars(str_0, bytes_0, str_0, str_0)


# Generated at 2022-06-25 14:20:19.379663
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    bytes_0 = b'\xbb\x8dA"\xae\xacn\xdd\xa6,'
    str_0 = '\x10\x9f\x8d\x10g\xdf\xfb\x8d\x17\x80t\xaa\x9d\x8c\x06\xfa\x87\x01\xad\xc1\x91\x01\x9f\x8c\x18\x0e\xfa\x8e\xac\x80t\xaa\x9d\x8c\x06\xfa\x87\x01\xad\xc1\x91\x01\x9f\x8c\x18\x0e\xfa\x8e\xac'
    var_0

# Generated at 2022-06-25 14:20:24.229105
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    bytes_0 = b'\xc6\xaa\x06\x0e\xc5\xb3\x0c\xea'
    str_0 = '=j2e'
    str_1 = '5(j\x16'
    var_0 = get_vars_from_path(bytes_0, str_0, str_0, str_1)
    assert var_0 is not None

# Generated at 2022-06-25 14:20:35.349131
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    bytes_0 = b'\xe5\x1d\xab\xbe\x95\xcc\x88@\xb3\x1c\xcd\xb8\xac\xd1\xcd\x9b\x8c\x0c\xbf\xb4\x0b\x0b\xfe\x82\x9e\x0c\xd7\x92\xcb\xd6\xd8\x89\xde\x03\x0e\xf8\xa1\x92\x0e\x7f'
    dict_0 = dict()

# Generated at 2022-06-25 14:20:43.255683
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    vars_loader.add_directory(C.DEFAULT_VARS_PLUGIN_PATH)

# Generated at 2022-06-25 14:20:47.215731
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    bytes_0 = b'\xbb\x8dA"\xae\xacn\xdd\xa6,'
    str_0 = '$mt26)~F]]P'
    var_0 = get_vars_from_path(bytes_0, str_0, str_0, str_0)


# Generated at 2022-06-25 14:20:57.131544
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    bytes_0 = b'\xbb\x8dA"\xae\xacn\xdd\xa6,'
    str_0 = '$mt26)~F]]P'
    var_0 = get_vars_from_path(bytes_0, str_0, str_0, str_0)
    # With: `vars_loader.all()` as `plugin_name` 
    
    # Using: `get_plugin_vars` 
    
    # Using: `hasattr` 
    # Using: `getattr` 
    # Using: `isinstance` 
    # Using: `update` 
    
    # Using: `getattr` 
    # Using: `isinstance` 
    # Using: `update` 
    
    # Using: `AnsibleError`

# Generated at 2022-06-25 14:21:05.418791
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    bytes_0 = b'\xbb\x8dA"\xae\xacn\xdd\xa6,'
    str_0 = '$mt26)~F]]P'
    dict_1 = get_vars_from_path(bytes_0, str_0, str_0, str_0)

# Generated at 2022-06-25 14:21:10.713552
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    bytes_0 = b'\xbb\x8dA"\xae\xacn\xdd\xa6,'
    str_0 = '$mt26)~F]]P'
    dict_0 = dict()
    var_0 = get_vars_from_path(bytes_0, str_0, str_0, str_0)
    try:
        assert var_0 == dict_0
    except AssertionError as e:
        print(var_0)


# Generated at 2022-06-25 14:21:16.029283
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
	res = get_vars_from_path(b'\xbb\x8dA"\xae\xacn\xdd\xa6,', '$mt26)~F]]P', '$mt26)~F]]P', '$mt26)~F]]P')
	assert(res == {})


# Generated at 2022-06-25 14:21:22.183677
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    bytes_0 = b'\xbb\x8dA"\xae\xacn\xdd\xa6,'
    str_0 = '$mt26)~F]]P'

    var_0 = get_vars_from_path(bytes_0, str_0, str_0, str_0)

    if isinstance(var_0, dict):
        pass
    else:
        assert False


# Generated at 2022-06-25 14:21:23.078383
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    pass


# Generated at 2022-06-25 14:21:33.254014
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Set up test data
    plugin_name_0 = b'\xfcg\xe5\xbb\xa0\xaf0\xfe\xf1\xfc\xe8\xdd\xed\xfd\x92D'
    plugin_name_1 = '\xfcg\xe5\xbb\xa0\xaf0\xfe\xf1\xfc\xe8\xdd\xed\xfd\x92D'
    plugin_name_2 = '\x06P\x8fc\xdc\xa6\xe5\xb2\x94\xfb\x97\xed\xf4\x8d'

# Generated at 2022-06-25 14:21:38.912628
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    bytes_0 = b'\xf9I\x8f\xbf\xce\xed\x95\x99\x8df\xeb\xd5\x9d\xdd\x8b\xde\xde\xaf\xda\x8af\x95\xf9\xd2\x95\xb0\xc4\xb4\xbe\x97\x8d\x9d'
    str_0 = 'H'
    str_1 = 'To\t'
    str_2 = '[y\x82'
    data = get_vars_from_inventory_sources(bytes_0, str_0, str_1, str_2)
    test_case_0()
    assert data

# Test the variable plugins on the current system

# Generated at 2022-06-25 14:21:40.500153
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    res = get_vars_from_path('1', '1', '1', '1')
    assert res == {}

# Generated at 2022-06-25 14:21:47.685006
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    bytes_0 = b'^C\xcf\xe3\xceG\xa0\xac\xc3\xfd\xf3'
    str_0 = ',a'
    str_1 = '\x98\x95\x80\x94\x9d\x8b\x8b\x85\x81'
    str_2 = '\xef\x97\x9c\x8c\xd6\x94\x88\x88\x85'
    str_3 = '\xf3\x9c\x8f\x8c\x91\x94\x8c\x8f\x95'
    var_0 = get_vars_from_path(bytes_0, str_1, str_2, str_3)
    assert var_0 == str_

# Generated at 2022-06-25 14:21:52.069478
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    bytes_0 = b'\xbb\x8dA"\xae\xacn\xdd\xa6,'
    str_0 = '$mt26)~F]]P'
    var_0 = get_vars_from_path(bytes_0, str_0, str_0, str_0)


# Generated at 2022-06-25 14:21:58.849833
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = '1'
    assert get_vars_from_path(str_0, str_0, str_0, str_0)


# Generated at 2022-06-25 14:22:06.898595
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    path = './test/data/vars_plugins'
    entities = ['foo', 'bar']

    loader = vars_loader
    plugin_paths = loader.find_plugin_paths()
    assert plugin_paths
    loader.add_directory(path, 'test')
    plugin_paths = loader.find_plugin_paths()
    assert plugin_paths
    plugin_paths = [path for (path, desc) in plugin_paths]
    assert path in plugin_paths

    loader = vars_loader
    plugin_list = list(loader.all())
    assert plugin_list
    loader.add_directory(path, 'test')
    plugin_list = list(loader.all())
    assert plugin_list

    str_0 = 'stage'
    plugin_1 = plugin_list[0]

# Generated at 2022-06-25 14:22:11.160140
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = '1'
    dict_0 = {}
    assert get_vars_from_path(str_0, str_0, str_0, str_0) == dict_0


# Generated at 2022-06-25 14:22:20.235064
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = '1'
    str_1 = "a"
    str_2 = '2'
    str_3 = '/home/2'
    str_4 = "d"
    str_5 = 'e'
    str_6 = "f"
    str_7 = "/home/f"
    str_8 = '3'
    str_9 = "h"
    str_10 = 'i'
    str_11 = "j"
    str_12 = "/home/j"
    str_13 = '4'
    str_14 = "l"
    str_15 = 'm'
    str_16 = "n"
    str_17 = "/home/n"
    str_18 = "o"
    str_19 = 'p'
    str_20 = "q"
    str

# Generated at 2022-06-25 14:22:24.419107
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Tests if there is no error when executing get_vars_from_path()
    global get_vars_from_path
    try:
        test_case_0()
    except Exception as e:
        print("\nFAILED TO RUN test_case_0()\n")
        print(e)

# Generated at 2022-06-25 14:22:28.096977
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    host = Host('test')
    data = get_vars_from_path('localhost', host, 'inventory', 'task')
    # assert data == {}
    # assert data != {}
    assert data == {}, "Test for get_vars_from_path"


# Generated at 2022-06-25 14:22:33.777633
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = '1'
    str_1 = 'ansible.plugins.vars.test_vars_plugins'
    var_0 = get_vars_from_path(str_0, str_0, str_0, str_0)
    assert str_1 in var_0


# Generated at 2022-06-25 14:22:39.894090
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    vars_0 = 'foo'
    entities_0 = [0, 0, 0]
    var_0 = get_vars_from_path(vars_0, vars_0, entities_0, 'foo')
    assert var_0 == {vars_0: 'foo'}
    entities_1 = [0, 0, 1]
    var_1 = get_vars_from_path(vars_0, vars_0, entities_1, 'bar')
    assert var_1 == {vars_0: 'bar'}



# Generated at 2022-06-25 14:22:49.821779
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'z'
    str_1 = 'r'
    str_2 = '2'
    str_3 = 'L'
    str_4 = 'o'
    str_5 = 'O'
    str_6 = 'Cc'
    str_7 = 'o'
    str_8 = 'C'
    str_9 = '.'
    str_10 = '_'
    str_11 = 'x'
    str_12 = 'J'
    str_13 = 'm'
    str_14 = 'm'
    str_15 = 'u'
    str_16 = 'p'
    str_17 = 'e'
    str_18 = 'V'
    str_19 = 'M'
    str_20 = 'y'
    str_21 = 'c'
   

# Generated at 2022-06-25 14:22:56.412386
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    str_0 = '2'
    str_1 = '1'
    str_2 = '3'
    str_3 = '4'
    str_4 = '1'
    str_5 = '5'
    str_6 = '2'
    str_7 = '1'
    str_8 = '6'
    str_9 = '7'
    str_10 = '1'
    str_11 = '8'
    str_12 = '9'
    str_13 = '10'
    str_14 = '1'
    str_15 = '11'
    str_16 = '12'
    str_17 = '13'
    str_18 = '14'
    str_19 = '15'
    str_20 = '1'
    str_21 = '16'
   

# Generated at 2022-06-25 14:23:01.673526
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert False, "Test not implemented"


# Generated at 2022-06-25 14:23:09.965990
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = '0'
    str_1 = '1'
    str_2 = '2'
    str_3 = '3'
    str_4 = '4'
    str_5 = '5'
    str_6 = '6'
    str_7 = '7'
    str_8 = '8'
    str_9 = '9'
    str_10 = '10'
    str_11 = '11'
    str_12 = '12'


# Generated at 2022-06-25 14:23:16.107334
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    path_0 = '~/ansible/test'
    sources_0 = [path_0]
    entities_0 = ['host_0', 'host_1', 'host_2']
    stage_0 = 'inventory'
    var_0 = get_vars_from_inventory_sources('loader_0', sources_0, entities_0, stage_0)


if __name__ == "__main__":
    test_case_0()
    test_get_vars_from_inventory_sources()

# Generated at 2022-06-25 14:23:21.204395
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    display.display('Starting get_vars_from_path unit test')

    try:
        test_case_0()
    except Exception as e:
        display.display(str(e), color=display.Color.FAIL)
        display.display('Failed get_vars_from_path unit test')
        return False

    display.display('')
    display.display('Passed get_vars_from_path unit test')
    return True


# Generated at 2022-06-25 14:23:27.958118
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = '1'
    str_1 = '2'
    str_2 = '3'
    str_3 = '4'
    str_4 = '5'
    str_5 = '6'
    str_6 = '7'
    str_7 = '8'
    str_8 = '9'
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    dict_3 = {}
    dict_4 = {}
    dict_5 = {}
    dict_6 = {}
    dict_7 = {}
    dict_8 = {}
    dict_9 = {}
    dict_10 = {}
    dict_11 = {}
    dict_12 = {}
    dict_13 = {}
    dict_14 = {}
    dict_15 = {}
    test_case_0

# Generated at 2022-06-25 14:23:35.059246
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert get_vars_from_path('loader', 'path', ['entity'], 'stage') == {}
    assert get_vars_from_path('loader', 'path', ['entity'], 'stage') == {}
    assert get_vars_from_path('loader', 'path', ['entity'], 'stage') == {}
    assert get_vars_from_path('loader', 'path', ['entity'], 'stage') == {}
    assert get_vars_from_path('loader', 'path', ['entity'], 'stage') == {}


# Generated at 2022-06-25 14:23:40.896978
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    class plugin:
        def get_vars(self, loader, path, entities):
            pass
        def get_host_vars(self, host_name):
            pass
        def get_group_vars(self, group_name):
            pass
    plugin = plugin()
    loader = 'foo'
    path = 'foo'
    entities = 'foo'
    v0 = get_plugin_vars(loader, plugin, path, entities)
    assert(v0 == {})


# Generated at 2022-06-25 14:23:51.854955
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = '1'
    var_0 = get_vars_from_path(str_0, str_0, str_0, str_0)
    str_1 = var_0
    str_2 = '2'
    str_3 = '3'
    str_4 = '4'
    str_5 = '5'
    str_6 = '6'
    str_7 = '7'
    str_8 = '8'
    str_9 = '9'
    str_10 = '10'
    str_11 = '11'
    str_12 = '12'
    str_13 = '13'
    str_14 = '14'
    str_15 = '15'
    str_16 = '16'
    str_17 = '17'

# Generated at 2022-06-25 14:23:52.703753
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    test_case_0()


# Generated at 2022-06-25 14:23:53.524595
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert test_case_0() == None



# Generated at 2022-06-25 14:24:05.807099
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    path = None
    entities = None
    stage = None
    data = None
    vars_plugin_list = None
    plugin_name = None
    plugin = None
    vars_plugin = 'ansible.plugins.vars.vars_plugin'
    assert get_vars_from_path(path, entities, stage, data, vars_plugin_list, plugin_name, plugin, vars_plugin) == False



# Generated at 2022-06-25 14:24:07.430414
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = '1'
    var_0 = get_vars_from_path(str_0, str_0, str_0, str_0)


# Generated at 2022-06-25 14:24:15.763484
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = '1'
    str_1 = '1'
    str_2 = '1'
    str_3 = '1'
    str_4 = '1'
    str_5 = '1'
    str_6 = '1'
    str_7 = '1'
    str_8 = '1'

    var_0 = [str_2, str_3, str_4, str_5, str_6, str_7, str_8]
    var_0 = get_vars_from_path(str_0, str_1, var_0, str_0)


# Generated at 2022-06-25 14:24:17.341212
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Unit test for get_vars_from_path
    # TODO: add test cases
    assert True



# Generated at 2022-06-25 14:24:27.059383
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    os.chdir('tests')
    assert get_vars_from_path('/Users/toddclemmer/git/ansible/lib/ansible/plugins/vars', '.', 'localhost', 'inventory') is None
    assert get_vars_from_path('/Users/toddclemmer/git/ansible/lib/ansible/plugins/vars', 'tests/test_vars_plugins/vars_dir_test', 'localhost', 'inventory') == {'vars_test': 'value_for_all'}
    assert get_vars_from_path('/Users/toddclemmer/git/ansible/lib/ansible/plugins/vars', 'tests/test_vars_plugins/vars_dir_test', 'localhost', 'task') is None
    assert get_vars_

# Generated at 2022-06-25 14:24:30.598029
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    entities = ['127.0.0.1']
    paths = ['../../ansible']
    stages = ['task']

    loader = None
    for entity in entities:
        for path in paths:
            for stage in stages:
                get_vars_from_path(loader, path, entity, stage)

# Generated at 2022-06-25 14:24:31.175953
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    pass



# Generated at 2022-06-25 14:24:41.163930
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    entity_0 = Host(name='host_0', port=22)
    entity_1 = Host(name='host_1', port=22)
    entity_2 = Host(name='host_2', port=22)
    entity_3 = Host(name='host_3', port=22)
    entity_4 = Host(name='host_4', port=22)
    entity_5 = Host(name='host_5', port=22)
    entity_6 = Host(name='host_6', port=22)
    entity_7 = Host(name='host_7', port=22)
    entity_8 = Host(name='host_8', port=22)
    entity_9 = Host(name='host_9', port=22)
    entity_10 = Host(name='host_10', port=22)
   

# Generated at 2022-06-25 14:24:51.297512
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    test_host = Host(name='host')
    test_group = Host(name='group')
    test_inventory_plugin = 'plugin_name'
    test_path = 'path'
    test_stage = 'inventory'
    test_entities = []

    test_get_vars_from_path = get_vars_from_path(test_inventory_plugin, test_path, test_entities, test_stage)

    # check if we get the right output
    try:
        assert type(test_get_vars_from_path) == dict
    except AssertionError:
        raise AssertionError("Failed - unexpected output")

    # check if we get the right output, pass a host instead of list
    test_entities = test_host

# Generated at 2022-06-25 14:24:57.530011
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Setup fixture
    str_0 = '1'
    var_0 = get_vars_from_path(str_0, str_0, str_0, str_0)
    data = {}
    str_1 = '1'
    var_1 = get_vars_from_path(str_1, str_1, str_1, str_1)
    data = combine_vars(data, var_1)
    str_2 = '1'
    var_2 = get_vars_from_path(str_2, str_2, str_2, str_2)
    data = combine_vars(data, var_2)
    str_3 = '1'
    var_3 = get_vars_from_path(str_3, str_3, str_3, str_3)

# Generated at 2022-06-25 14:25:03.075633
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert True

# Generated at 2022-06-25 14:25:07.620091
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    str_0 = '1'
    str_1 = '2'
    str_2 = '3'
    str_3 = '4'
    var_0 = get_plugin_vars(str_0, str_1, str_2, str_3)
    assert var_0 is None


# Generated at 2022-06-25 14:25:10.229121
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    str_0 = '1'
    var_0 = get_plugin_vars(str_0, str_0, str_0, str_0)



# Generated at 2022-06-25 14:25:19.366376
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = '1'
    str_1 = '2'
    str_2 = '3'
    str_3 = '4'
    str_4 = '5'
    str_5 = '6'
    str_6 = '7'
    str_7 = '8'
    str_8 = '9'
    str_9 = '10'
    str_10 = '11'
    str_11 = '12'
    str_12 = '13'
    tuple_0 = (
        (str_0, str_1), str_2, str_3, (str_4, str_5),
        (str_6, str_7), str_8, str_9, (str_10, str_11), str_12
    )
    list_0 = list(tuple_0)


# Generated at 2022-06-25 14:25:20.124484
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    assert test_get_plugin_vars


# Generated at 2022-06-25 14:25:25.016973
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    mock_get_vars = MagicMock(return_value=None)
    with patch(builtin_module + '.get_vars', mock_get_vars):
        str_0 = '1'
        var_0 = get_vars_from_path(str_0, str_0, str_0, str_0)

        mock_get_vars.assert_called_with(str_0, str_0, str_0)
        assert (var_0 is None)



# Generated at 2022-06-25 14:25:32.844177
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = '~~'
    dict_0 = dict()
    dict_0['~'] = '~~'
    dict_0['.'] = '~~'
    dict_0['/'] = '~~'
    dict_0[''] = '~~'
    dict_0['='] = '~~'
    dict_0['``'] = '~~'
    dict_0['0'] = '~~'
    dict_0['*'] = '~~'
    dict_0['!'] = '~~'
    dict_0['**'] = '~~'
    dict_0['_'] = '~~'
    dict_0['9'] = '~~'
    dict_0['5'] = '~~'
    dict_0['-'] = '~~'
    dict_0[')'] = '~~'
    dict

# Generated at 2022-06-25 14:25:35.347546
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = '1'
    str_1 = '2'
    str_2 = '3'
    str_3 = '4'
    get_vars_from_path(str_0, str_1, str_2, str_3)


# Generated at 2022-06-25 14:25:36.282300
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    # input args: 'loader', 'plugin', 'path', 'entities'
    assert True

# Generated at 2022-06-25 14:25:38.897323
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    str_0 = '1'
    var_0 = get_vars_from_inventory_sources(str_0, str_0, str_0, str_0)
    assert var_0 == {}