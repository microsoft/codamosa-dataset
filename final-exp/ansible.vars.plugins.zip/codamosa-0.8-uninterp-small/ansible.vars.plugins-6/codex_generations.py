

# Generated at 2022-06-25 14:15:58.848933
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    bytes_0 = b'\x06\x80\xab\x88\x000\x04\xb8\xe8\x9c\xa6\n\x81'
    tuple_0 = ()
    set_0 = {tuple_0, bytes_0}
    var_1 = get_vars_from_path(bytes_0, bytes_0, set_0, None)


# Generated at 2022-06-25 14:16:07.514333
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    bytes_0 = to_bytes(b'ZsQE4\x9b\x99\x08\x80\x85\xba\xb3\x11\x01\x8b\x9b\xab\xb5\xf7')
    tuple_0 = ()
    set_0 = {tuple_0, bytes_0}
    var_0 = get_vars_from_path(bytes_0, set_0, set_0, b'K\x123\x03\x83\xb0\xed\x96')
    assert var_0 == {}

# Generated at 2022-06-25 14:16:11.740014
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    vm = VariableManager()
    host = Host('localhost')
    host.vars = {'var1': 'value1'}
    var = get_vars_from_path(loader, '', [], 'inventory')

    assert var == {u'var1': u'value1'}


# Generated at 2022-06-25 14:16:17.812662
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    bytes_0 = b'\x9ej50\x93\xce\xf9\xd8\x04\x80\x95\x00e\xb9\x19'
    tuple_0 = ()
    set_0 = {tuple_0, bytes_0}
    var_0 = get_plugin_vars(bytes_0, set_0, tuple_0, set_0)
    var_0.update(var_0)



# Generated at 2022-06-25 14:16:23.198756
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    from ansible.inventory.manager import InventoryManager

    im = InventoryManager()
    im.load_inventory("tests/units/inventory")
    sources = im._inventory.sources

    data = get_vars_from_inventory_sources("", sources, ((),), "inventory")
    assert "testvars_a" in data
    assert data["testvars_a"] == 1
    assert "testvars_b" in data
    assert data["testvars_b"] == 2
    assert "vars" in data
    assert data["vars"] == {"x": "y"}

# Generated at 2022-06-25 14:16:25.031274
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    path = '0'
    entities = set()
    stage = '0'
    var_0 = get_vars_from_path(path, entities, stage)


# Generated at 2022-06-25 14:16:28.263107
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    loader = b'\x9ej50\x93\xce\xf9\xd8\x04\x80\x95\x00e\xb9\x19'
    path = ()
    entities = {loader, path}
    stage = 'inventory'
    output = get_vars_from_path(loader, path, entities, stage)
    assert output == {}



# Generated at 2022-06-25 14:16:31.526052
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    loader = ''
    path = './'
    entities = set()
    stage = ''
    func_result = get_vars_from_path(loader, path, entities, stage)
    assert func_result is not None


# Generated at 2022-06-25 14:16:33.478344
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert get_vars_from_path(bytes_0, tuple_0, set_0, 'inventory') == set_0


# Generated at 2022-06-25 14:16:39.009601
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    bytes_0 = b'\xa2\xed\xfa\xca\x15\xbc\x04\xd7\x8d\x0e\x9a\xb0\xcc'
    tuple_0 = ()
    set_0 = {tuple_0, bytes_0}
    var_0 = get_vars_from_path(bytes_0, set_0, set_0, set_0)
    print(f'Exptected : {True}')
    print(f'Actual : {var_0}')


# Generated at 2022-06-25 14:16:47.505418
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    # Just a stub to test the function
    str_0 = get_plugin_vars(loader, plugin, path, entities)


# Generated at 2022-06-25 14:16:57.288563
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader

    plugin_name = 'test_vars_plugin'
    plugin_1 = vars_loader.get(plugin_name)

    # parse plugin_name
    data = plugin_1.get_vars(None, '/root/ansible/test/ansible_vars', ['/root/ansible/test/ansible_vars'])
    data_1 = plugin_1.get_vars(None, '/root/ansible/test/ansible_vars', ['/root/ansible/test/ansible_vars', None])

    print("%s" % (data))
    print("%s" % (data_1))



# Generated at 2022-06-25 14:17:02.347992
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    try:
        test_case_0()
    except Exception as err:
        raise Exception("Test Case No: 0 Failed - "+ str(err))

if __name__ == '__main__':
    try:
        test_get_vars_from_inventory_sources()
    except Exception as err:
        print("Test Failed - " + str(err))
        exit(1)

    print("Test Case Passed")

# Generated at 2022-06-25 14:17:09.454533
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    #print("###### Testing get_vars_from_path ######")

    # Test Case #0 from get_vars_from_path
    # Test case with arguments:
    #    loader=,
    #    path=,
    #    entities=,
    #    stage=

    try:
        test_case_0()
    except Exception:
        pass



    # Unit test for function get_vars_from_inventory_sources

# Generated at 2022-06-25 14:17:13.756314
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = 'inventory'
    dict_0 = dict([])
    list_0 = [dict_0]
    list_1 = []
    list_2 = []

    assert get_vars_from_path(list_0, str_0, list_1, list_2) == dict_0


# Generated at 2022-06-25 14:17:15.469442
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    try:
        assert True == True
    except:
        print("Failed")


# Generated at 2022-06-25 14:17:26.565477
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    # Unit test for function get_vars_from_path

    d = {}
    e = {}
    f = {}
    g = {}
    h = {}
    i = {}

    l = []
    m = ()
    n = []
    o = {}
    p = []
    q = {}

    r = []
    s = []
    t = {}
    u = {}
    v = []
    w = []

    # default test
    a = 'inventory'
    b = []
    c = []

    # simple test
    if a == 'inventory':
        if isinstance(b, list):
            for d in b:
                if isinstance(d, AnsibleCollectionRef):
                    q = d
                    if ',' in q:
                        continue

# Generated at 2022-06-25 14:17:29.769210
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    vars_loader = 'null'
    plugin = 'null'
    path = 'null'
    entities = 'null'
    result = get_plugin_vars(vars_loader, plugin, path, entities)
    assert result is None
    pass


# Generated at 2022-06-25 14:17:35.962466
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # testcase 1
    str_1 = 'inventory'
    loader_1 = vars_loader
    path_1 = '/Users/wfan/github/ansible/lib/ansible/utils/vars.py'
    entities_1 = 'localhost'
    stage_1 = 'inventory'
    # get_vars_from_path(loader, path, entities, stage)
    result = get_vars_from_path(loader_1, path_1, entities_1, stage_1)
    print('result is ', result)
    # testcase 2
    str_2 = 'inventory'
    loader_2 = vars_loader
    path_2 = '/Users/wfan/github/ansible/lib/ansible/utils/vars.py'
    entities_2 = 'localhost'

# Generated at 2022-06-25 14:17:37.788892
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    get_vars_from_inventory_sources(None, [None], [None], None)

# Generated at 2022-06-25 14:17:49.556548
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    bytes_0 = b'\x9ej50\x93\xce\xf9\xd8\x04\x80\x95\x00e\xb9\x19'
    var_0 = get_vars_from_path(bytes_0, bytes_0, bytes_0, bytes_0)


# Generated at 2022-06-25 14:17:53.024850
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    var_path = None
    var_entities = ()
    var_stage = None
    var_loader = None
    assert get_vars_from_path(var_loader, var_path, var_entities, var_stage) != None


# Generated at 2022-06-25 14:17:55.409443
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    loader = None
    plugin = None
    path = None
    entities = None
    assert test_case_0() == None


# Generated at 2022-06-25 14:18:04.691088
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    loader, path, entities, stage = b'\x9ej50\x93\xce\xf9\xd8\x04\x80\x95\x00e\xb9\x19', (), b'\x9ej50\x93\xce\xf9\xd8\x04\x80\x95\x00e\xb9\x19', b'\x9ej50\x93\xce\xf9\xd8\x04\x80\x95\x00e\xb9\x19'
    get_vars_from_path(loader, path, entities, stage)


# Generated at 2022-06-25 14:18:05.342512
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert True == True

# Generated at 2022-06-25 14:18:10.414400
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # The first path should be the file path, or inventory path. The second path is where vars plugins are stored
    # in the file-system. The file path is important because it will trigger the python loader for variables plugin
    # classes, which Ansible doesn't want it to do. So the second path (where vars plugins would normally live)
    # is being assigned to the first path to make sure only one path is being passed to get_vars_from_path().
    loader = ansible.parsing.dataloader.DataLoader()
    path = os.path.join(f'{C.DEFAULT_ROLES_PATH}', "_plugins")

    vars_plugin_list = sorted(list(vars_loader.all()))

# Generated at 2022-06-25 14:18:15.837746
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    bytes_0 = b'\xda\xac\xd6\xdf\x03\xbb\xdc\x11\x94m\x0c\x0cH\xcc'
    var_0 = ()
    var_1 = get_vars_from_path(bytes_0, bytes_0, var_0, bytes_0)


# Generated at 2022-06-25 14:18:26.308632
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Source files used in the unit test.
    test_paths = [
        './vars_plugin/',
    ]

    # Results of the unit test.
    result = {}

    # Expected results of the unit test.
    expected = {
        'ansible_playbook_python': '/usr/bin/python',
        'env_vars_plugin_var': 'env_vars_plugin_value',
    }

    for path in test_paths:
        # Load the vars plugins from the path.
        loader = vars_loader.get(path)

        # Generate the results.
        result = combine_vars(result, get_plugin_vars(loader, loader, test_paths, ()))

    # Test that the results are as expected.
    assert result == expected

# Generated at 2022-06-25 14:18:36.038542
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    bytes_0 = b'\x9ej50\x93\xce\xf9\xd8\x04\x80\x95\x00e\xb9\x19'
    bytes_1 = b'\xee\xab\x8f\xb5\x05\x9f\x9e\xca\xb5\x0a\x81\xcfQ\x1f\xa5\x06\x9b\xe8\xd4\x90\x02\xab\x03\xea\x19\xd6\x0b\x18\x93\xdf\r\x1b'
    var_0 = ()
    var_1 = get_vars_from_path(bytes_0, var_0, bytes_1, bytes_0)
    

# Unit

# Generated at 2022-06-25 14:18:39.158440
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    bytes_0 = b'\xf7_['
    var_0 = ()
    var_1 = get_vars_from_path(bytes_0, bytes_0, var_0, bytes_0)


# Generated at 2022-06-25 14:18:45.672574
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    test_case_0()


# Generated at 2022-06-25 14:18:57.140622
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    bytes_0 = b'\x9ej50\x93\xce\xf9\xd8\x04\x80\x95\x00e\xb9\x19'
    bytes_1 = b'\x89\xb3\x10\xf8\xec\xad\xf6\x19\xfe\xdd\x1a\x94\x06\xcd\x02\x9b\x11'

# Generated at 2022-06-25 14:18:58.401825
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    print('Test get_vars_from_path')
    test_case_0()

# Generated at 2022-06-25 14:18:59.848538
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert 0



# Generated at 2022-06-25 14:19:00.700436
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert True


# Generated at 2022-06-25 14:19:02.129358
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    # TODO: Improve test coverage
    # TODO: Raise an exception if a type error is found.
    var_0 = get_plugin_vars(1, 1, 1, 1)



# Generated at 2022-06-25 14:19:04.456799
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    var_1 = get_plugin_vars('\x00\xf5\xcc', b'\x00\xf5\xcc', '\x00\xf5\xcc', '\x00\xf5\xcc')

# Generated at 2022-06-25 14:19:15.749526
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    bytes_0 = b'\x9ej50\x93\xce\xf9\xd8\x04\x80\x95\x00e\xb9\x19'
    bytes_1 = b"\x10A\x9d\x94\x0b\x80\x00\x1a\x8b\x02\xef\x9b\x81\x00\xd2\x1d\xab\x10\xde\x15\x9e9\x08\x12\x91\x0f\xbb\x01\x90'_\xb1\x0c\x9e\x06"
    int_0 = 1
    int_1 = 2

# Generated at 2022-06-25 14:19:22.866732
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    bytes_0 = b'\x8f\xcb\xf3\x9e\xcb\x18"\xdd\x0e\xd4\xa8\xba\x90'
    bytes_1 = b'O\x13\xfa\x03\xe5t'
    bytes_2 = b'\xda\x9b\xb8\xf7'
    bytes_3 = b'\x8b\x7f\x1b\xb7\x8c\xbb\xdd\xb3\xcf\xa6\x81\x98\x99\xd6\xfd'

# Generated at 2022-06-25 14:19:26.977382
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    bytes_0 = b'\x9ej50\x93\xce\xf9\xd8\x04\x80\x95\x00e\xb9\x19'
    var_0 = get_plugin_vars(bytes_0, bytes_0, bytes_0, bytes_0)


# Generated at 2022-06-25 14:19:32.537950
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    pass

# Generated at 2022-06-25 14:19:35.028188
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    var_1 = get_vars_from_path(None, None, None, None)

    assert bytes_0 == b''
    assert var_1 == {}



# Generated at 2022-06-25 14:19:35.993568
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    assert 1



# Generated at 2022-06-25 14:19:42.270786
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    bytes_0 = b'\x9ej50\x93\xce\xf9\xd8\x04\x80\x95\x00e\xb9\x19'
    var_0 = get_plugin_vars(bytes_0, bytes_0, bytes_0, bytes_0)
    assert var_0 == {}, "Expected {}, but got: %s" % var_0


# Generated at 2022-06-25 14:19:49.610054
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    bytes_0 = bytes('\x9ej50\x93\xce\xf9\xd8\x04\x80\x95\x00e\xb9\x19', encoding='utf-8')
    bytes_1 = bytes('\x9ej50\x93\xce\xf9\xd8\x04\x80\x95\x00e\xb9\x19', encoding='utf-8')
    bytes_2 = bytes('\x9ej50\x93\xce\xf9\xd8\x04\x80\x95\x00e\xb9\x19', encoding='utf-8')
    int_0 = get_plugin_vars(bytes_0, bytes_1, bytes_2, bytes_0)


# Generated at 2022-06-25 14:19:50.518897
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    test_case_0()


# Generated at 2022-06-25 14:19:57.250942
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    bytes_0 = b'\x9ej50\x93\xce\xf9\xd8\x04\x80\x95\x00e\xb9\x19'
    bytes_1 = b'\x9fj50\x93\xce\xf9\xd8\x04\x80\x95\x00e\xb9\x19'
    bytes_2 = b'\xa0j50\x93\xce\xf9\xd8\x04\x80\x95\x00e\xb9\x19'
    bytes_3 = b'\xa1j50\x93\xce\xf9\xd8\x04\x80\x95\x00e\xb9\x19'

# Generated at 2022-06-25 14:20:00.507290
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Verify if the defined values are equal to the expected values
    assert test_case_0() == '\x9ej50\x93\xce\xf9\xd8\x04\x80\x95\x00e\xb9\x19'


# Generated at 2022-06-25 14:20:01.824604
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    print("This function should not be tested.")



# Generated at 2022-06-25 14:20:06.413693
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    bytes_0 = b'\x9ej50\x93\xce\xf9\xd8\x04\x80\x95\x00e\xb9\x19'
    var_0 = get_vars_from_path(bytes_0, bytes_0, bytes_0, bytes_0)

# Testing for function get_vars_from_inventory_sources

# Generated at 2022-06-25 14:20:13.255568
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert False


# Generated at 2022-06-25 14:20:15.441548
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    assert 1 == 1


# Generated at 2022-06-25 14:20:19.242202
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    loader = None
    path = '/tmp/ansible_test_workdir/'
    entities = None
    stage = 'inventory'
    var_0 = get_vars_from_path(loader, path, entities, stage)

# Generated at 2022-06-25 14:20:26.789592
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    bytes_0 = b'\x9ej50\x93\xce\xf9\xd8\x04\x80\x95\x00e\xb9\x19'
    bytes_1 = b'\x19\x85\x9a\xdb\x19\x1a\xf2\x1d\xdb\xce\x90'
    bytes_2 = b'\xc0\xaf\x1b\x8d\xfa\x06\xc1\x1d\xe9v\xc2\x0f\x90\x98\xef\x90\x1ab\x15\x06\xc1\x1d\xe9'

# Generated at 2022-06-25 14:20:27.498152
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert True

# Generated at 2022-06-25 14:20:31.061742
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    bytes_0 = b'\xd8\x85\x0c\x89\xef\x0b\xfb\xd5\x91\xd3\x87<\xeb\xcf\x03'
    bytes_1 = b'x\xcc\xa0\x9d\xd7\xe0\x14\xcb\x00\x1c\x92\xc6\xc3\xb9.\x81\x937\x89'
    bytes_2 = b'\xcf\x01\xb9\x9e\x10\x92\xee\xafM\xed\x8d6A\xde\x81\xd9Y\xd7\x06\x0fo'

# Generated at 2022-06-25 14:20:32.837692
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert get_vars_from_path(None, None, None, None) == {}


# Generated at 2022-06-25 14:20:37.060123
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    bytes_0 = b'\x9ej50\x93\xce\xf9\xd8\x04\x80\x95\x00e\xb9\x19'
    var_0 = get_vars_from_path(bytes_0, bytes_0, bytes_0, bytes_0)


# Generated at 2022-06-25 14:20:43.001145
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    loader = None
    ansible_facts = {}
    # ansible_facts_path = '/etc/ansible/facts.d/'
    ansible_facts_path = './sample/ansible_facts_dir'
    ansible_facts_files = [os.path.join(ansible_facts_path, x) for x in os.listdir(ansible_facts_path)]
    for f in ansible_facts_files:
        if os.path.isfile(f):
            ansible_facts.update(get_vars_from_path(loader, f, None, None))
    return ansible_facts

# Generated at 2022-06-25 14:20:52.635987
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # No plugins are enabled, so get_vars_from_path should return an empty dict
    assert get_vars_from_path(bytes_0, bytes_0, bytes_0, bytes_0) == {}

    # Now with DEBUG_VARS_PLUGINS == True
    C.RUN_VARS_PLUGINS = True

    # No plugins are enabled, so get_vars_from_path should return an empty dict
    assert get_vars_from_path(bytes_0, bytes_0, bytes_0, bytes_0) == {}

    # Now with a good vars plugin
    C.VARIABLE_PLUGINS_ENABLED = ['lookup_static']

    # Should return an empty dict

# Generated at 2022-06-25 14:21:02.299413
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    host = Host('hostname')
    loader = None
    path = ''
    entities = (host, )
    stage = 'inventory'
    var_0 = get_vars_from_path(loader, path, entities, stage)
    assert var_0 is not None


# Generated at 2022-06-25 14:21:10.903345
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    call_0 = dict(
            loader = {
                'get_basedir': lambda *args, **kw: 'C:/Ansible/test/test_plugins/test_lookup/test_get_plugin_vars/',
                'get_vars_files': lambda *args, **kw: None,
                'set_vars_files': lambda *args, **kw: None,

            },
            path = 'C:/Ansible/test/test_plugins/test_lookup/test_get_plugin_vars/',
            entities = {
                'get_groups': lambda *args, **kw: None,
                'get_hosts': lambda *args, **kw: None,
            },
        )
    plugin_0 = vars_loader.get('X', 'Y')
    plugin_0._load_name

# Generated at 2022-06-25 14:21:22.143746
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # key_0 is an int with value 0
    key_0 = 0
    # test_case_0 is [(0, b'\x9ej50\x93\xce\xf9\xd8\x04\x80\x95\x00e\xb9\x19', b'\x9ej50\x93\xce\xf9\xd8\x04\x80\x95\x00e\xb9\x19', b'\x9ej50\x93\xce\xf9\xd8\x04\x80\x95\x00e\xb9\x19')]

# Generated at 2022-06-25 14:21:27.864583
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    result = get_vars_from_path(b'\x00\x00\x00\x00', b'\x00\x00\x00\x00', [b'\x00\x00\x00\x00'], b'\x00\x00\x00\x00')
    assert(result == {})



# Generated at 2022-06-25 14:21:29.688269
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert get_vars_from_path('loader', 'path', ('entities', 'entities'), 'stage') == {}


# Generated at 2022-06-25 14:21:32.449045
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    loader = None
    plugin = None
    path = None
    entities = None
    result = get_plugin_vars(loader, plugin, path, entities)
    assert result is None



# Generated at 2022-06-25 14:21:36.984631
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Case 0
    bytes_0 = b'\x9ej50\x93\xce\xf9\xd8\x04\x80\x95\x00e\xb9\x19'
    var_0 = get_vars_from_path(bytes_0, bytes_0, bytes_0, bytes_0)
    assert var_0 is not None


# Generated at 2022-06-25 14:21:41.203426
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    bytes_0 = b'\x9ej50\x93\xce\xf9\xd8\x04\x80\x95\x00e\xb9\x19'
    var_0 = get_vars_from_path(bytes_0, bytes_0, bytes_0, bytes_0)

    assert var_0 == {}


# Generated at 2022-06-25 14:21:44.799070
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    bytes_0 = b'\x9ej50\x93\xce\xf9\xd8\x04\x80\x95\x00e\xb9\x19'
    var_0 = get_vars_from_path(bytes_0, bytes_0, bytes_0, bytes_0)



# Generated at 2022-06-25 14:21:53.561185
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    import ansible_collections
    import ansible_collections.nsbl.my_ceph

    bytes_0 = b'\xb1\xfa\xe6a!\x89\xd6\xea\x1f\x8b\xd1\x1d\x0c\xd7\x00'
    var_0 = ansible_collections.nsbl.my_ceph.plugins.vars_plugins.ceph_pool(bytes_0, bytes_0)
    bytes_1 = b'\x08\xa6\xaf\xe7\x8b\x87\xc9\xfc\xa0\x8d\x93\x16\xa1\xc7\x04\x93\xc9\x0f\x04\x16\xccl$'
    var_1

# Generated at 2022-06-25 14:22:01.923790
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    pass


# Generated at 2022-06-25 14:22:05.752290
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    bytes_0 = b'\xc1p\xa9Z\x9c\x83\x00\x82\x97\x98\xe1\x85\xc5\x9f'
    var_0 = get_plugin_vars(bytes_0, bytes_0, bytes_0, bytes_0)
    assert var_0 == {}


# Generated at 2022-06-25 14:22:08.636101
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    bytes_0 = b'\x9ej50\x93\xce\xf9\xd8\x04\x80\x95\x00e\xb9\x19'
    var_0 = get_vars_from_path(bytes_0, bytes_0, bytes_0, bytes_0)


# Generated at 2022-06-25 14:22:19.583152
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    var_0 = b'7\x19N\xc1\xd0\x8e\xa6\xca\xbc\xdc\x8c\xfc\x80\xcc\x10\x9c\xa7\x18\xd9\xac\xe8'

# Generated at 2022-06-25 14:22:27.061696
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    bytes_0 = b'\x9ej50\x93\xce\xf9\xd8\x04\x80\x95\x00e\xb9\x19'
    bytes_1 = b'\xcc\x93\x19\xd9\x9c\xcf\xf9\x16\xcb\x99\xcb'
    int_0 = 0
    assert get_vars_from_path(bytes_0, bytes_0, bytes_0, bytes_0) == (bytes_1, int_0)



# Generated at 2022-06-25 14:22:31.550814
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    file_path = 'test/test_vars_plugins.py'
    entity = 'test_case_0'
    stage = 'inventory'
    loader = 'test'
    get_vars_from_path(loader, file_path, entity, stage)

# Generated at 2022-06-25 14:22:33.672777
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    var_0 = get_vars_from_path()


# Generated at 2022-06-25 14:22:38.965485
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    bytes_0 = b''
    bytes_1 = b'\x9ej50\x93\xce\xf9\xd8\x04\x80\x95\x00e\xb9\x19'
    get_vars_from_path(bytes_0, bytes_0, bytes_0, bytes_0)
    get_vars_from_path(bytes_1, bytes_1, bytes_1, bytes_1)


# Generated at 2022-06-25 14:22:44.870154
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    bytes_0 = b'\x9ej50\x93\xce\xf9\xd8\x04\x80\x95\x00e\xb9\x19'
    var_0 = get_plugin_vars(bytes_0, bytes_0, bytes_0, bytes_0)


# Generated at 2022-06-25 14:22:49.821297
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # test_0
    bytes_0 = b'\x9ej50\x93\xce\xf9\xd8\x04\x80\x95\x00e\xb9\x19'
    var_0 = get_vars_from_path(bytes_0, bytes_0, bytes_0, bytes_0)
    if not var_0:
        raise Exception('assert error')


# Generated at 2022-06-25 14:23:19.714332
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    bytes_0 = b'\x9ej50\x93\xce\xf9\xd8\x04\x80\x95\x00e\xb9\x19'
    var_0 = get_vars_from_path(bytes_0, bytes_0, bytes_0, bytes_0)
    assert var_0 == {}



# Generated at 2022-06-25 14:23:23.271861
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    bytes_0 = b'\x9ej50\x93\xce\xf9\xd8\x04\x80\x95\x00e\xb9\x19'
    assert get_vars_from_path(bytes_0, bytes_0, bytes_0, bytes_0) == {}


# Generated at 2022-06-25 14:23:34.988810
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    path_0 = './inventory_plugins/vars/foo.yml'
    path_1 = './inventory_plugins/vars/bar.yml'
    path_2 = './inventory_plugins/vars/baz.yml'
    path_3 = './inventory_plugins/vars/quux.yml'
    path_4 = './inventory_plugins/vars/xyzzy.yml'
    path_5 = './inventory_plugins/vars/plugh.yml'
    path_6 = './inventory_plugins/vars/grue.yml'
    path_7 = './inventory_plugins/vars/zork.yml'
    path_8 = './inventory_plugins/vars/zork.yml'

    var_1 = get_vars_from_

# Generated at 2022-06-25 14:23:39.031488
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    bytes_0 = b'\x9ej50\x93\xce\xf9\xd8\x04\x80\x95\x00e\xb9\x19'
    var_0 = get_vars_from_inventory_sources(bytes_0, bytes_0, bytes_0, bytes_0)


# Generated at 2022-06-25 14:23:44.628146
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    bytes_0 = b'\x9ej50\x93\xce\xf9\xd8\x04\x80\x95\x00e\xb9\x19'
    var_0 = get_vars_from_path(bytes_0, bytes_0, bytes_0, bytes_0)


# Generated at 2022-06-25 14:23:48.938925
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    bytes_0 = b'\x9ej50\x93\xce\xf9\xd8\x04\x80\x95\x00e\xb9\x19'
    var_0 = get_vars_from_inventory_sources(bytes_0, bytes_0, bytes_0, bytes_0)


# Generated at 2022-06-25 14:23:50.464949
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # TODO: input data, expected result (the stuff you want tested)
    pass


# Generated at 2022-06-25 14:23:56.650792
# Unit test for function get_vars_from_inventory_sources

# Generated at 2022-06-25 14:24:05.342183
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.utils.collection_loader import AnsibleCollectionRef
    from ansible.utils.vars import combine_vars

    assert get_vars_from_path(
        bytes_0,
        bytes_0,
        bytes_0,
        bytes_0,
    )

    assert vars_loader.all()

    assert AnsibleCollectionRef.is_valid_fqcr(bytes_0)

    assert combine_vars(
        bytes_0,
        bytes_0,
    )



# Generated at 2022-06-25 14:24:09.024178
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    bytes_0 = b'\x9ej50\x93\xce\xf9\xd8\x04\x80\x95\x00e\xb9\x19'
    loader = None
    plugin = None
    path = None
    entities = None
    var_0 = get_plugin_vars(loader, plugin, path, entities)


# Generated at 2022-06-25 14:24:29.902057
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    data = b'\x9ej50\x93\xce\xf9\xd8\x04\x80\x95\x00e\xb9\x19'
    assert get_vars_from_path(data, data, data, data) == data


# Generated at 2022-06-25 14:24:33.298935
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    bytes_0 = b'\x9ej50\x93\xce\xf9\xd8\x04\x80\x95\x00e\xb9\x19'
    var_0 = get_vars_from_path(bytes_0, bytes_0, bytes_0, bytes_0)
    return var_0


# Generated at 2022-06-25 14:24:38.019071
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    string_0 = b'\x88\x85\xd9\xeb\x05\x07a\xe8\x1e\xec\xfa@\x8f\x9e\xb6\xbf\xde\xf8\xa1\x1c\xcf\x89\x86\x9e'
    bytes_0 = b'\x9ej50\x93\xce\xf9\xd8\x04\x80\x95\x00e\xb9\x19'
    var_0 = get_vars_from_path(string_0, bytes_0, bytes_0, bytes_0)
    assert type(var_0) == dict


# Generated at 2022-06-25 14:24:42.311566
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    bytes_0 = b'\x9ej50\x93\xce\xf9\xd8\x04\x80\x95\x00e\xb9\x19'
    var_0 = get_plugin_vars(bytes_0, bytes_0, bytes_0, bytes_0)


# Generated at 2022-06-25 14:24:52.184881
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    bytes_0 = b'\x00'
    bytes_1 = b'\x9ej50\x93\xce\xf9\xd8\x04\x80\x95\x00e\xb9\x19'
    bytes_2 = b'\x00'
    bytes_3 = b'\x9ej50\x93\xce\xf9\xd8\x04\x80\x95\x00e\xb9\x19'
    bytes_4 = b'\x00'
    bytes_5 = b'\x9ej50\x93\xce\xf9\xd8\x04\x80\x95\x00e\xb9\x19'
    bytes_6 = b'\x00'

# Generated at 2022-06-25 14:24:56.705339
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    path = 'tests/unit/mock/fake_vars_loader.py;tests/unit/mock/fake_vars_loader_no_command.py;tests/unit/mock/fake_vars_loader_old_style.py'
    entities = [Host('test', 'localhost')]
    loader = path
    stage = 'inventory'
    vars = get_vars_from_path(loader, path, entities, stage)
    assert vars == {'test': 'test', 'test2': 'test2'}


# Generated at 2022-06-25 14:24:58.440781
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert test_case_0() == None


# Generated at 2022-06-25 14:25:03.799029
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    fixture_input_path = ["path1","path2"]
    fixture_input_entities = ["entity1","entity2"]
    fixture_input_stage = "fixture_stage"
    #print(get_vars_from_path(fixture_input_path,fixture_input_entities,fixture_input_stage))


# Generated at 2022-06-25 14:25:09.651069
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    bytes_0 = b'\x1d\x8f\x9ej50\x93\xce\xf9\xd8\x04\x80\x95\x00e\xb9\x19'
    var_0 = get_vars_from_path(bytes_0, bytes_0, bytes_0, bytes_0)

# Generated at 2022-06-25 14:25:10.186081
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert True

# Generated at 2022-06-25 14:25:33.865612
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    pass

# Generated at 2022-06-25 14:25:41.525021
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    bytes_0 = b'\xeb\xe4\x8e\x04\x1d3\x9f\x9b\xd0\xcd\x08\x8c\x8b\x1d\x02\xe9\xed\xee\x1d\x02\x19\x00'
    var_0 = get_vars_from_path(bytes_0, bytes_0, bytes_0, bytes_0)
    bytes_1 = b'\x9ej50\x93\xce\xf9\xd8\x04\x80\x95\x00e\xb9\x19'
    var_1 = get_vars_from_path(bytes_1, bytes_1, bytes_1, bytes_1)
    assert var_0 == var_1
