

# Generated at 2022-06-25 14:15:57.019834
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    var_0 = get_vars_from_path('hostVars', 'host', ['hostVars'], 'task')


# Generated at 2022-06-25 14:16:05.816269
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    int_0 = int(1885.0)
    float_0 = float(int_0)
    ansible_host = Host(name = str(float_0))
    ansible_host.vars = {str(int_0): float_0}
    ansible_host.groups = ['arista']
    vars_loader_plugin = vars_loader.get(str(float_0))
    ansible_host.vars = {str(int_0): float_0}
    ansible_host.groups = ['arista']
    # map(lambda x: vars_loader_plugin.get_option('stage'), range(44))
    vars_loader_plugin.get_vars(dict(int_0, ansible_host), ansible_host)
    vars_loader_plugin.get_host_

# Generated at 2022-06-25 14:16:10.716113
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    # Step 0 : Setup
    # Stub path, sources, entities and stage
    # Step 1 : Initialize test variables
    int_0 = -922
    str_0 = 'pNu#^_2[Dwu%W#W0'
    dict_0 = {str_0: int_0, str_0: str_0, int_0: str_0, int_0: int_0}
    # Step 2 : Run function and validate results
    res = get_vars_from_inventory_sources(int_0, str_0, dict_0, dict_0)

# Generated at 2022-06-25 14:16:12.019589
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    get_vars_from_path(1, 2, 3, 4)
    pass


# Generated at 2022-06-25 14:16:21.013054
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    int_0 = 144584375
    int_1 = 788
    int_2 = 776
    str_0 = 'BS^i3zZHk~N7NgE6iO_s'
    str_1 = 'Ci*1.D0p#%0'
    str_2 = 'dxc!bpxBcmP@@X#'
    dict_0 = {int_0: int_1, int_2: str_0, str_2: int_0}
    list_0 = ['d)', '3zRC4Z7V.C', 'Fg7V%3OJX9&v' , '%O-N+ah8w']

# Generated at 2022-06-25 14:16:27.774787
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    test_str_0 = 'pNu#^_2[Dwu%W#W0'
    test_int_0 = -922
    test_dict_0 = {test_str_0: test_int_0, test_str_0: test_str_0, test_int_0: test_str_0, test_int_0: test_int_0}
    test_tuple_0 = (test_int_0, test_dict_0, test_int_0, test_dict_0, test_dict_0)
    test_list_0 = [test_dict_0, test_int_0, test_int_0]

# Generated at 2022-06-25 14:16:30.864258
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    int_0 = -922
    str_0 = 'pNu#^_2[Dwu%W#W0'
    dict_0 = {str_0: int_0, str_0: str_0, int_0: str_0, int_0: int_0}
    var_0 = get_vars_from_inventory_sources(int_0, str_0, dict_0, dict_0)
    return var_0



# Generated at 2022-06-25 14:16:37.394101
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    int_0 = -922
    str_0 = 'pNu#^_2[Dwu%W#W0'
    dict_0 = {str_0: int_0, str_0: str_0, int_0: str_0, int_0: int_0}
    dict_1 = {str_0: dict_0, int_0: dict_0, str_0: dict_0, int_0: dict_0}
    var_0 = get_vars_from_path(int_0, str_0, dict_1, dict_0)


# Generated at 2022-06-25 14:16:38.366174
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    test_case_0()


# Generated at 2022-06-25 14:16:43.871813
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    int_0 = 1
    str_0 = 'n>EtJ'
    dict_0 = {str_0: int_0, str_0: str_0, int_0: str_0, int_0: int_0}
    get_plugin_vars(int_0, str_0, dict_0, dict_0)


# Generated at 2022-06-25 14:16:52.742007
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = None
    int_0 = -4328
    var_0 = get_vars_from_path(str_0, int_0, str_0, int_0)


# Generated at 2022-06-25 14:16:56.073722
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = None
    int_0 = -4328
    var_0 = get_vars_from_path(str_0, str_0, int_0, str_0)


# Generated at 2022-06-25 14:17:05.018985
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = None
    str_1 = "8W^-L#9;1iOm:<I%8W^-L#9;1iOm:<I"
    str_2 = "nL"
    str_3 = "u1G@"
    str_4 = "get_vars_from_path"
    str_5 = "G.<i$8"

# Generated at 2022-06-25 14:17:08.759409
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = None
    str_1 = None
    var_0 = get_vars_from_path(str_0, str_1, str_1, str_1)



# Generated at 2022-06-25 14:17:14.018716
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = None
    entity_1 = Host('name_0')
    entity_2 = Host('name_0')
    list_0 = [entity_1, entity_2]
    path_0 = None
    stage_0 = 'start'
    var_0 = get_vars_from_path(str_0, path_0, list_0, stage_0)


# Generated at 2022-06-25 14:17:22.552010
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert get_vars_from_path(str_0, str_0, str_0, str_0)
    assert get_vars_from_path(str_0, str_0, int_0, str_0)
    assert get_vars_from_path(str_0, int_0, int_0, str_0)
    assert get_vars_from_path(int_0, str_0, int_0, int_0)
    assert get_vars_from_path(int_0, str_0, str_0, int_0)


# Generated at 2022-06-25 14:17:31.324148
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    str_0 = None
    int_0 = -4328
    str_1 = None
    int_1 = -2693
    str_2 = None
    int_2 = -2693
    var_1 = get_vars_from_path(str_0, int_0, str_1, int_1)
    var_2 = get_vars_from_path(str_0, int_0, int_1, str_1)
    var_3 = get_vars_from_path(str_2, int_1, str_1, int_1)
    var_4 = get_vars_from_path(str_0, str_1, int_1, int_1)

# Generated at 2022-06-25 14:17:34.291938
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    int_1 = 4025
    #  str_1 = get_vars_from_inventory_sources(int_1, int_1, int_1, int_1)


# Generated at 2022-06-25 14:17:45.451507
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    #
    # Assignment of simple variables
    #
    str_0 = ''
    str_1 = 'pytest.inventory'
    str_2 = 'inventory_file'
    str_3 = '/etc/ansible/hosts'
    str_4 = 'hosts'
    str_5 = 'inventory'
    str_6 = 'task'
    int_0 = 0
    int_1 = 0
    int_2 = -8482
    int_3 = 12193
    int_4 = -29890
    int_5 = 0
    int_6 = -9415
    int_7 = 0
    int_8 = -32666
    int_9 = -8440
    int_10 = -38158
    int_11 = -4331
    int_12 = 9011
    int_13 = 39

# Generated at 2022-06-25 14:17:47.241549
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    # Random coordinate
    class_0 = get_plugin_vars(None, None, None, None)


# Generated at 2022-06-25 14:17:55.740639
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    loader = 'test'
    path = 'test'
    entities = 'test'
    stage = 'test'
    assert get_vars_from_path(loader, path, entities, stage) == {}


# Generated at 2022-06-25 14:18:03.335599
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    print('\n##############################################################################')
    print('# Unit test case for function get_plugin_vars')

    # Case 1:
    #  arguments:

    expected_result = 4025
    

    actual_result = test_case_0()
    if (actual_result == expected_result):
        print('Case 0: Pass')
    else:
        print('Case 0: Fail')


if __name__ == "__main__":
    test_get_plugin_vars()

# Generated at 2022-06-25 14:18:05.744715
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    int_0 = 3
    test_0 = AnsibleError(int_0)
    dict_0 = {}
    dict_1 = {}


# Generated at 2022-06-25 14:18:06.734778
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    int_0 = 4025


# Generated at 2022-06-25 14:18:08.028020
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    assert True, "This is a test"


# Generated at 2022-06-25 14:18:11.103028
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    try:
        loader, path, entities, stage = None, None, None, None
        print(get_vars_from_path(loader, path, entities, stage))
    except (AnsibleError, IOError) as e:
        display.display(e)
        

# Generated at 2022-06-25 14:18:13.843244
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    vars_loader = VarsLoader()
    plugin = PluginLoader()

# Generated at 2022-06-25 14:18:18.762760
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    path = "/home/shubham/Downloads/ansible-2.8.1/lib/ansible/plugins/vars/"
    entities = ['all']
    stage = 'task'

    result = get_vars_from_path(ansible.plugins.loader.vars_loader, path, entities, stage)



# Generated at 2022-06-25 14:18:22.419462
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    vars_loader.clear()
    loader, path, entities, stage = [], [], [], []
    get_vars_from_path(loader, path, entities, stage)
    # How to check the result?


# Generated at 2022-06-25 14:18:26.672632
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    loader = MockDataLoader()
    entities = []
    sources = []

    try:
        result = get_vars_from_inventory_sources(loader, sources, entities, "inventory")
    except Exception as e:
        print("get_vars_from_inventory_sources() threw exception: " + str(e))



# Generated at 2022-06-25 14:18:34.589004
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = get_plugin_vars(var_0, var_1, var_0, var_2)


# Generated at 2022-06-25 14:18:38.875865
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    path_0 = None
    entities_0 = None
    stage_0 = None

    var_0 = path_0
    var_1 = entities_0
    var_2 = stage_0

    var_3 = get_vars_from_path(var_0, var_1, var_2, var_3)
    print(var_3)

# Generated at 2022-06-25 14:18:41.854998
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    var_0 = None
    var_1 = get_plugin_vars(var_0, var_0, var_0, var_0)


# Generated at 2022-06-25 14:18:52.981026
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # test_case_0: No parameters
    # Initiating the test case
    var_0 = None
    var_1 = get_vars_from_path(var_0, var_0, var_0, var_0)
    # Output
    assert var_1 == {}

    # test_case_1: with vars plugin list parameter
    # Initiating the test case
    var_0 = ['vars_plugin_1', 'vars_plugin_2']
    var_1 = get_vars_from_path(var_0, var_0, var_0, var_0)
    # Output
    assert var_1 == {}

    # test_case_2: with entities and path parameter
    # Initiating the test case
    var_0 = 'path'
    var_1 = ['entities']
   

# Generated at 2022-06-25 14:18:55.720354
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    var_0 = None
    var_1 = None
    var_2 = get_vars_from_path(var_0, var_0, var_1, var_0)

# Generated at 2022-06-25 14:18:58.360479
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    var_0 = None
    var_1 = get_vars_from_path(var_0, var_0, var_0, 'start')



# Generated at 2022-06-25 14:19:05.503971
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # get_vars_from_path(loader, path, entities, stage)

    class loader:
        def all(self):
            # returns entries as tuples of (name, plugin_object)
            return [('factory', factory()), ('b', b())]

        def get(self, name):
            return self.all()[0][1]

    class factory:
        def get_vars(self, loader, path, entities):
            return {
                'factory_a': 'A',
                'factory_b': 'B'
            }

        def get_group_vars(self, name):
            return {
                'factory_c': 'C'
            }

        def get_host_vars(self, name):
            return {
                'factory_d': 'D'
            }

# Generated at 2022-06-25 14:19:11.969062
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    var_0 = 'plugin_name'
    var_1 = 'path'
    var_2 = 'entities'
    var_3 = get_plugin_vars(var_0, var_1, var_2)
    assert isinstance(var_3, type(var_1))

# Generated at 2022-06-25 14:19:14.451269
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    var_0 = None
    var_1 = get_vars_from_path(var_0, var_0, var_0, var_0)
    assert isinstance(var_1, dict)


# Generated at 2022-06-25 14:19:15.904885
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    test_case_0()

# Test case function for function get_vars_from_path

# Generated at 2022-06-25 14:19:29.863067
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from tests.plugins.vars_loader.test_module import VarsModule

    var_0 = None
    var_1 = 'test1'
    var_2 = ['test2']
    var_3 = {'test3': 3}

    #
    # Test get_plugin_vars function
    #
    var_4 = VarsModule()
    var_5 = get_plugin_vars(var_0, var_4, var_0, var_2)
    assert var_5 == var_3

    var_6 = None
    var_7 = get_vars_from_path(var_0, var_6, var_2, var_6)
    assert var_7 == var_3

    #
    # Test get_plugin_vars by add new attribute
    #
    var_8 = V

# Generated at 2022-06-25 14:19:33.061077
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    var_2 = get_plugin_vars(var_0, var_0, var_0, var_0)
    assert var_2 == var_0


# Generated at 2022-06-25 14:19:43.548825
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Vars plugin list
    var_0 = None
    var_1 = list(vars_loader.all())
    var_2 = dict()
    var_3 = dict()
    var_4 = dict()
    var_5 = dict()
    for var_6 in C.VARIABLE_PLUGINS_ENABLED:
        if var_6:
            var_7 = AnsibleCollectionRef.is_valid_fqcr(var_6)
            if var_7:
                var_8 = vars_loader.get(var_6)
                if var_8 is None:
                    continue
                var_9 = None
                var_10 = var_8 not in var_1
                if var_10:
                    var_1.append(var_8)
    var_11 = dict()
    var

# Generated at 2022-06-25 14:19:50.490152
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    var_9 = None
    var_10 = None
    var_11 = None
    var_12 = None
    var_13 = None
    var_14 = None
    var_15 = False
    var_16 = None
    var_17 = None
    var_18 = None
    var_19 = None
    var_20 = None
    var_21 = None
    var_22 = None
    var_23 = None
    var_24 = None
    var_25 = None
    var_26 = None
    var_27 = None
    var_

# Generated at 2022-06-25 14:19:54.125358
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = ''
    var_4 = None
    var_5 = get_vars_from_path(var_3, var_3, var_3, var_3)
    assert var_5 is not None



# Generated at 2022-06-25 14:19:56.676221
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    var_0 = None
    var_1 = get_vars_from_path(var_0, var_0, var_0, var_0)

    if var_1 is None:
        raise Exception('returned value is None and should not be')



# Generated at 2022-06-25 14:19:59.655112
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    var_0 = None
    var_1 = get_vars_from_path(var_0, var_0, var_0, var_0)

    assert var_1 == {}


# Generated at 2022-06-25 14:20:08.187979
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    # This is a test function for get_vars_from_inventory_sources.
    var_0 = None
    var_1 = get_vars_from_inventory_sources(var_0, var_0, var_0, var_0)
    if var_1 == None:
        var_2 = var_1
    else:
        var_2 = var_0
    var_3 = get_vars_from_path(var_0, var_0, var_0, var_0)
    if var_3 == None:
        var_4 = var_3
    else:
        var_4 = var_0
    var_5 = combine_vars(var_0, var_3)

    if var_2 == var_4:
        return var_5
    else:
        return var_

# Generated at 2022-06-25 14:20:12.476602
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    print("Running test for function get_vars_from_inventory_sources")
    try:
        assert test_case_0() == 0
        print("Passed test for function get_vars_from_inventory_sources")
    except:
        print("Failed test for function get_vars_from_inventory_sources")

# Generated at 2022-06-25 14:20:13.337576
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    pass


# Generated at 2022-06-25 14:20:21.065012
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    var_0 = None
    var_1 = None
    var_2 = 'start'
    var_3 = get_vars_from_path(var_0, var_0, var_0, var_2)


# Generated at 2022-06-25 14:20:22.258577
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert test_case_0() is None


# Generated at 2022-06-25 14:20:27.494160
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    var_0 = None
    var_1 = get_plugin_vars(var_0, var_0, var_0, var_0)
    var_2 = get_vars_from_path(var_0, var_1, var_0, var_0)


# Generated at 2022-06-25 14:20:30.339772
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    loader = None
    plugin = None
    path = None
    entities = None
    assert get_plugin_vars(loader, plugin, path, entities) == None


# Generated at 2022-06-25 14:20:39.553796
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert get_vars_from_path(load_vars, None, None, None) == {}
    assert get_vars_from_path(load_vars, "", None, None) == {}
    assert get_vars_from_path(load_vars, "some_path", None, None) == {}
    assert get_vars_from_path(load_vars, "/some/path", "", "") == {}
    assert get_vars_from_path(load_vars, "/some/path", ["one", "two", "three"], "start") == {}
    assert get_vars_from_path(load_vars, "/some/path", "", "end") == {}
    assert get_vars_from_path(load_vars, "/some/path", "", "start") == {}

# Generated at 2022-06-25 14:20:44.502113
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    try:
        vars_plugin_list = list(vars_loader.all())
        get_vars_from_path(vars_plugin_list[0], vars_plugin_list[0], vars_plugin_list[0], vars_plugin_list[0])
    except Exception as e:
        print(e)

# Generated at 2022-06-25 14:20:47.091953
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    path = ""
    entities = ""
    stage = ""
    var_2 = None
    # var_3 = get_vars_from_path(var_2, path, entities, stage)



# Generated at 2022-06-25 14:20:56.209517
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    var_0 = None
    var_1 = get_vars_from_path(var_0, var_0, var_0, var_0)
    var_2 = None
    var_3 = get_vars_from_path(var_0, var_0, var_0, var_0)
    assert var_1 == var_3

    var_1 = get_vars_from_path(var_0, var_0, var_0, var_0)
    var_3 = get_vars_from_path(var_0, var_0, var_0, var_0)
    assert var_1 == var_3
    assert var_1 == var_3
    assert var_1 == var_3

# Generated at 2022-06-25 14:20:59.426052
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    get_vars_from_path(var_0, var_1, var_2, var_3)


# Generated at 2022-06-25 14:21:08.755404
# Unit test for function get_vars_from_path

# Generated at 2022-06-25 14:21:22.183005
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    var_0 = loader
    var_1 = path
    var_2 = entities
    var_3 = stage
    var_4 = get_vars_from_path(var_0, var_1, var_2, var_3)

# Generated at 2022-06-25 14:21:29.175142
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = get_vars_from_path(var_2, var_3, var_4, var_2)
    # verify example 1
    # assert var_5 == expected_1
    # verify example 2
    # assert var_5 == expected_2
    try:
        if not var_5:
            raise AssertionError
    except AssertionError:
        print('> assertion failed')


# Generated at 2022-06-25 14:21:32.205946
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    get_vars_from_path(var_0, var_1, var_2, var_3)



# Generated at 2022-06-25 14:21:33.130621
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    print("get vars from path")


# Generated at 2022-06-25 14:21:38.814645
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    vars_plugin_list = list(vars_loader.all())
    for plugin_name in C.VARIABLE_PLUGINS_ENABLED:
        if AnsibleCollectionRef.is_valid_fqcr(plugin_name):
            vars_plugin = vars_loader.get(plugin_name)
            if vars_plugin is None:
                # Error if there's no play directory or the name is wrong?
                continue
            if vars_plugin not in vars_plugin_list:
                vars_plugin_list.append(vars_plugin)

    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None

# Generated at 2022-06-25 14:21:39.690113
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    pass


# Generated at 2022-06-25 14:21:47.176161
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    plugin = getattr(AnsibleCollectionRef('ansible_collections.my_namespace.my_collection.plugins.module_utils', None, None), 'my_file')
    plugin._load_name = 'my_module'
    from ansible.plugins.vars import test_vars_plugin
    test_vars_plugin._load_name = 'test_vars_plugin'
    test_vars_plugin._original_path = 'test_vars_plugin'

    # Test without AttributeError
    data = get_plugin_vars(None, test_vars_plugin, None, None)
    # Test with AttributeError
    data = get_plugin_vars(None, plugin, None, None)

    var_0 = None

# Generated at 2022-06-25 14:21:50.284292
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    var_0 = None
    var_1 = get_vars_from_path(var_0, var_0, var_0, var_0)

    assert var_1 is None

test_case_0()



# Generated at 2022-06-25 14:21:59.118929
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    var_0 = 'C:\\Users\\jmatt\\Ansible'
    var_1 = '\\'
    var_2 = '\\'
    var_3 = '.'
    var_4 = '.'
    var_5 = var_3 + var_4
    var_6 = [var_0]
    var_7 = test_case_0()
    var_8 = ['all', var_5]
    var_9 = vars_loader.get(var_0)
    assert var_9 is var_7
    var_10 = var_9.get_vars(var_1, var_2, var_8)
    assert var_10 is not None
    assert var_10 is not ''
    assert var_10 is not 0


# Generated at 2022-06-25 14:22:07.117373
# Unit test for function get_vars_from_path

# Generated at 2022-06-25 14:22:27.778156
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    var_0 = None
    var_1 = get_vars_from_path(var_0, var_0, var_0, var_0)


# Generated at 2022-06-25 14:22:30.991357
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    var_0 = None
    var_1 = get_vars_from_path(var_0, var_0, var_0, var_0)


# Generated at 2022-06-25 14:22:40.431354
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    # Variables
    var_0 = None
    var_1 = AnsibleCollectionRef.is_valid_fqcr('xyz')

    var_2 = {}
    var_3 = var_2.update({'xyz' : 'abc'})

    var_4 = get_vars_from_path(var_0, var_0, var_0, var_0)

    var_5 = C.VARIABLE_PLUGINS_ENABLED
    var_6 = ['dummy_plugin']

    var_7 = not None
    var_8 = not None

    var_9 = {}
    var_10 = var_9.update({'xyz' : 'abc'})

    var_11 = vars_loader.all()
    var_12 = hasattr(var_11, 'get_option')

# Generated at 2022-06-25 14:22:44.325801
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    var_0 = None
    var_1 = get_vars_from_path(var_0, var_0, var_0, var_0)
    assert var_1 == {}


# Generated at 2022-06-25 14:22:45.885992
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert True

# Generated at 2022-06-25 14:22:50.164110
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    var_0 = None
    var_1 = "vars_plugins"
    var_2 = "hosts"
    var_3 = "inventory"
    res = get_vars_from_path(var_1, var_2, var_3, var_0)
    return res
# res = test_get_vars_from_path()
# print res


# Generated at 2022-06-25 14:22:52.335851
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    var_0 = None
    var_1 = None
    var_2 = get_vars_from_path(var_0, var_1, var_0, var_0)


# Generated at 2022-06-25 14:22:54.829114
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    for var_0 in range(1000):
        for var_0 in range(1000):
            for var_0 in range(1000):
                for var_0 in range(1000):
                    test_case_0(var_0, var_0, var_0, var_0)

# Generated at 2022-06-25 14:23:05.708601
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    testVars = {}

    def getVarsPlugin(self, loader, path, entities):
        return testVars

    vars_loader.set_module_args(path=__file__)
    vars_loader.set_module_name('test_var_loader')
    vars_loader.add_directory(os.getcwd(), 'test_var_loader')
    vars_loader._module_cache[('test_var_loader', '0.1', __file__)] = type('VarsModule', (object,), {'get_vars': getVarsPlugin})

    inventorySource = os.path.join(os.getcwd(), 'inventory_loading_test.yml')

    # Test case 0
    testVars = {}

# Generated at 2022-06-25 14:23:08.103184
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    var_0 = None
    var_1 = get_vars_from_path(var_0, var_0, var_0, var_0)
    assert var_1 is not None


# Generated at 2022-06-25 14:23:48.400729
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    var_0 = None
    var_1 = get_vars_from_inventory_sources(var_0, var_0, var_0, var_0)


# Generated at 2022-06-25 14:23:56.335116
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    """
    Test case for function get_plugin_vars

    """
    var_0 = None
    var_1 = vars_loader.get("test_var_1")
    var_2 = vars_loader.get("test_var_2")
    var_3 = [var_1, var_2]
    var_4 = [var_1, var_2]

    var_5 = get_plugin_vars(var_0, var_1, var_0, var_4)
    var_6 = get_plugin_vars(var_0, var_2, var_0, var_4)
    var_7 = get_plugin_vars(var_0, var_1, var_0, var_4)

# Generated at 2022-06-25 14:23:58.711532
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    var_0 = None
    var_1 = get_vars_from_path(var_0, var_0, var_0, var_0)



# Generated at 2022-06-25 14:24:04.231304
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    var_4 = None
    var_3 = var_4
    var_2 = var_4
    var_5 = var_4
    var_6 = get_vars_from_path(var_5, var_2, var_3, var_4)
    return var_6


# Generated at 2022-06-25 14:24:07.240505
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = get_vars_from_path(var_0, var_1, var_2, var_3)


# Generated at 2022-06-25 14:24:13.143866
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader, get_vars_from_path

    loader = None
    path = '/etc/ansible/hosts'
    entities = []
    stage = 'inventory'

    display.verbosity = 4


    # Do the test
    result = get_vars_from_path(loader, path, entities, stage)
    return result



# Generated at 2022-06-25 14:24:23.182301
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    var_9 = None

    var_10 = get_vars_from_path(var_0, var_1, var_2, var_3)

    var_9 = all(var_1)

    var_8 = all(var_1)

    var_0 = var_8 and var_9

    var_7 = all(var_1)

    var_6 = all(var_1)

    var_5 = all(var_1)

    var_2 = var_5 and var_6 and var_7

    var_1 = var_2

# Generated at 2022-06-25 14:24:23.785658
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert 1 == 1

# Generated at 2022-06-25 14:24:31.918489
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    os.environ['ANSIBLE_VAR_PLUGIN1'] = "vars_plugin_1"
    os.environ['ANSIBLE_VAR_PLUGIN2'] = "vars_plugin_2"
    os.environ['ANSIBLE_VAR_PLUGIN3'] = "vars_plugin_3"

    # Example usage:
    #   remote_user = get_vars_from_path(loader, path, entities, stage)

    # Sample Input:
    #   loader = None
    #   path = None
    #   entities = None
    #   stage = "inventory"
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()

# Generated at 2022-06-25 14:24:34.545581
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # create the test object
    var_0 = None
    var_1 = [host(var_0)]
    var_2 = get_vars_from_path(var_0, var_0, var_1, var_0)

