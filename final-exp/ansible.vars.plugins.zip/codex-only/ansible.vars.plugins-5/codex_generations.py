

# Generated at 2022-06-23 15:09:26.961769
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.vars import auto
    from ansible.plugins.loader import vars_loader

    vars_loader.add(auto.VarsModule())

    from ansible.inventory.manager import InventoryManager

    inv = InventoryManager(loader=None, sources=['test/functional/data/static_inventory'])

    groups = inv.groups.copy()
    host = inv.get_host('host_name')

    vars_from_path = get_vars_from_path(loader=None, path='test/functional/data', entities=[host, *groups], stage='task')

    assert len(vars_from_path) == 20
    assert vars_from_path['parent'] == 'all'
    assert vars_from_path['child'] == 'child'

# Generated at 2022-06-23 15:09:38.889255
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    mock_plugin = {
        '_load_name': 'mock_plugin',
        '_original_path': './mock/1.0.0/',
        'get_vars': lambda loader, path, entities: {'a': 1, 'b': 2},
    }
    assert get_plugin_vars(None, mock_plugin, None, []) == {'a': 1, 'b': 2}

    mock_plugin = {
        '_load_name': 'mock_plugin',
        '_original_path': './mock/1.0.0/',
        'get_host_vars': lambda host: {'c': 2, 'd': 4},
        'get_group_vars': lambda group: {'e': 8, 'f': 16},
    }

# Generated at 2022-06-23 15:09:50.652683
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    import os
    import sys
    sys.path.insert(0, os.path.abspath("tests/utils"))
    sys.path.insert(0, os.path.abspath("lib/ansible/inventory"))

    from .test_inventory import TestInventoryPluginBase
    from .test_inventory_plugin import MockCollectionRef

    class Example_vars_plugin(TestInventoryPluginBase):

        NAME = 'example_vars_plugin'

        def verify_file(self, path):
            return True

        def parse(self, inventory, loader, path, cache=True):
            super(Example_vars_plugin, self).parse(inventory, loader, path)

            testgroup = inventory.add_group('mygroup')
            testhost = inventory.add_host(group=testgroup, name='myhost')
            test

# Generated at 2022-06-23 15:10:02.404163
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    test_vars_path = (
        '/tmp/ansible_test_vars_path-%s' % os.getpid(),
        '/tmp/ansible_test_vars_path_dir-%s' % os.getpid()
    )
    os.mkdir(test_vars_path[1])
    dummy_plugin_path = os.path.join(test_vars_path[1], 'vars_plugin.py')
    vars_data = {
        'f1': 'bar',
        'f2': 42,
        'f3': [1, 2, 3],
        'f4': {'foo': 'bar'},
    }


# Generated at 2022-06-23 15:10:09.759242
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import dirnames
    import os

    plugin = dirnames.VarsModule()
    path = './test/integration/vars_plugins/varstest'
    entities = ['testvar']
    # This is a test of the function get_plugin_vars
    # We are testing the functionality of the vars plugin dirnames
    data = get_plugin_vars(plugin, path, entities)
    assert data['dirnames'] == os.listdir(path)

# Generated at 2022-06-23 15:10:11.276460
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    assert get_plugin_vars(None, None, None, None) == {}

# Generated at 2022-06-23 15:10:20.370129
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    import ansible.inventory

    sources_list = ["host_vars/host1.yml", "host_vars/vars2.yml",
                    "group_vars/group1.yml", "group_vars/group2.yml"]

    sources = []
    for s in sources_list:
        sources.append(os.path.join(os.getcwd(), s))

    hosts = ansible.inventory.Host("host1")
    groups = ansible.inventory.Group("group1")

    entities = [hosts, groups]

    loader = ansible.parsing.dataloader.DataLoader()

    data = get_vars_from_inventory_sources(loader, sources, entities, "task")

    assert data["direct"] == "direct"

# Generated at 2022-06-23 15:10:32.805319
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import test_vars_plugin

    plugin = test_vars_plugin.TestVarsModule()
    path = None
    hostnames = ['test-host']
    data = get_plugin_vars(None, plugin, path, hostnames)

    assert data == {'test_host_var': 'test_host_value'}

    groupnames = ['test-group']
    data = get_plugin_vars(None, plugin, path, groupnames)

    assert data == {'test_group_var': 'test_group_value'}

    hostnames.extend(groupnames)
    data = get_plugin_vars(None, plugin, path, hostnames)


# Generated at 2022-06-23 15:10:38.614732
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    assert get_plugin_vars({}, {'get_vars': lambda x: {'a': 'a'}}) == {'a': 'a'}
    assert get_plugin_vars({}, {'get_host_vars': lambda x: {'a': 'b'}}) == {'a': 'b'}
    assert get_plugin_vars({}, {'get_group_vars': lambda x: {'a': 'c'}}) == {'a': 'c'}

# Generated at 2022-06-23 15:10:49.165792
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    class FakeLoader:
        def __init__(self, sources):
            self.sources = sources

    # Case1. sources has a path and stage is inventory
    sources = ['/tmp/ansible_inventory', '/tmp/ansible_hosts']
    stage = 'inventory'
    entities = [sources[0], sources[1]]
    loader = FakeLoader(sources)
    assert get_vars_from_inventory_sources(loader, ['', '', '', ''], entities, stage) == get_vars_from_inventory_sources(loader, sources, entities, stage)
    assert get_vars_from_inventory_sources(loader, ['', '', ''], entities, stage) == get_vars_from_inventory_sources(loader, sources, entities, stage)

    # Case2. sources has no path

# Generated at 2022-06-23 15:11:00.606790
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.loader import var_plugins

    class TestPlugin:
        def get_group_vars(self, name):
            return {'group': 'groups/{}'.format(name)}

        def get_host_vars(self, name):
            return {'host': 'hosts/{}'.format(name)}

        def get_vars(self, loader, path, entities):
            return {'complex': 'complex'}

    class TestPluginGroupVars:
        def get_vars(self, loader, path, entities, *args, **kwargs):
            return {'group': 'group_plugin'}

    class TestPluginHostVars:
        def get_vars(self, loader, path, entities, *args, **kwargs):
            return {'host': 'host_plugin'}



# Generated at 2022-06-23 15:11:04.305303
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    loader = None
    sources = ["/tmp/hosts"]
    entities = None
    stage = None
    result = get_vars_from_inventory_sources(loader, sources, entities, stage)
    assert result == {}

# Generated at 2022-06-23 15:11:13.382824
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    CHANGED = 0
    ADDED = 1
    REMOVED = 2
    SKIPPED = 3
    OK = 4

    import unittest
    import ansible.plugins.loader as plugins
    try:
        import yaml
    except ImportError:
        raise unittest.SkipTest("yaml is not installed")

    class TestVarsPlugin(object):
        """
        Mock Vars plugin class
        """

        def __init__(self):
            self._load_name = "test_vars_plugin"


# Generated at 2022-06-23 15:11:20.721935
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    # Set up vars plugin as test subject
    plugin_path = 'plugins/vars/sample.yml'

    # Set up loader with the test subject
    from ansible import context

    current_play = context.CLIARGS._play
    context.CLIARGS._play = None
    loader = context.CLIARGS._loader
    from ansible.utils.display import Display
    from ansible.parsing.plugin_docs import vars_loader as plugins
    context.CLIARGS = None
    context.CLIARGS = context.CLIARGS._make_parser(['-vvv'])
    context.CLIARGS.connection = 'local'

# Generated at 2022-06-23 15:11:21.350944
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    assert False

# Generated at 2022-06-23 15:11:28.962917
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory_manager = InventoryManager(loader=loader,
                                         sources=['tests/inventory/plugin_loader/get_vars_from_inventory_sources/inventory'])
    variable_manager = VariableManager(loader=loader, inventory=inventory_manager)

    plugin_vars = get_vars_from_inventory_sources(loader, ['tests/inventory/plugin_loader/get_vars_from_inventory_sources'], ['all'], 'task')

    assert plugin_vars['plugin_type'] == 'v1' \
        and plugin_vars

# Generated at 2022-06-23 15:11:33.659854
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    entities = [Host("test_host")]
    loader = None  # TODO
    sources = ["/etc/ansible/hosts"]
    stage = "all"
    get_vars_from_inventory_sources(loader, sources, entities, stage)

# Generated at 2022-06-23 15:11:44.301323
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    # NOTE: This is an intentionally private function, but we use it here to test the public user-facing function get_vars_from_inventory_sources

    # check that the function raise an exception if path is a list
    from ansible.errors import AnsibleError

    class FakeInventory():

        def __init__(self):
            pass

    loader = FakeInventory()
    sources = [None, ['/etc/ansible/hosts', 'localhost'], '/etc/ansible/hosts']
    entities = ['/etc/ansible/hosts']
    stage = 'inventory'
    try:
        get_vars_from_path(loader, sources[1], entities, stage)
    except Exception as e:
        assert isinstance(e, AnsibleError)

    # check that the function return key items if path is a file


# Generated at 2022-06-23 15:11:53.226951
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    plugin_path = os.getcwd()
    plugin_class = os.path.join(plugin_path,"python_plugin_test.py")
    plugin_file = os.path.join(plugin_path,"test_plugin.py")

    def t1_get_plugin_instance():
        plugin_module = loader._find_plugin(plugin_file, 'vars')
        t1_vars_plugin = vars_loader._get_instance(plugin_module)
        return t1_vars_plugin

    def t2_get_plugin_instance():
        plugin_module = loader._find_plugin(plugin_class, 'vars')
        t2_vars_plugin = vars_loader._get_instance(plugin_module)
        return t2_vars_plugin

    def test_t1():
        vars

# Generated at 2022-06-23 15:11:55.041399
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    display.verbosity = 3

    assert get_vars_from_inventory_sources(None, [None], None, None) == {}

# Generated at 2022-06-23 15:12:00.315788
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import Direct
    a = Direct()
    b = Direct()
    a.data = {'foo': 'bar'}
    b.data = {'baz': 'bob'}
    loader = None
    path = ''
    entities = [a, b]
    assert get_plugin_vars(loader, a, path, entities) == {'foo': 'bar'}
    assert get_plugin_vars(loader, b, path, entities) == {'baz': 'bob'}


# Generated at 2022-06-23 15:12:03.034210
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    loader = None
    sources = ['/home/ansible/inventory', '/home/ansible/playbook.yml']
    entities = [{'name': 'localhost'}]
    stage = 'inventory'

    data = get_vars_from_inventory_sources(loader, sources, entities, stage)
    assert data is not None

# Generated at 2022-06-23 15:12:14.966591
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    import ansible.plugins.vars.host_group_vars
    from ansible.inventory.group import Group
    from ansible_collections.ansible.misc.tests.unit.compat.mock import Mock

    # Set some dummy variables
    path = 'path'
    entities = ['entities1', 'entities2']

    # Mock plugin by creating an object with the same methods
    plugin = Mock(return_value=None)
    plugin.get_vars = Mock(return_value='vars_returned')
    plugin.get_host_vars = Mock(return_value='get_host_vars_returned')
    plugin.get_group_vars = Mock(return_value='get_group_vars_returned')
    plugin.run = Mock(return_value='run_returned')

   

# Generated at 2022-06-23 15:12:19.602594
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    '''test get_plugin_vars'''
    plugin = vars_loader.get('name')
    if plugin is None:
        raise AnsibleError("Cannot use vars plugin %s" % plugin._load_name)
    data = get_plugin_vars(vars_loader, plugin, '.', [])
    return data

# Generated at 2022-06-23 15:12:28.522610
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    """
    Run unit tests for get_plugin_vars()
    """
    import unittest
    import sys
    import tempfile
    import os
    import shutil
    import json
    import glob

    sys.path.insert(0, os.getcwd())

    from ansible.plugins.vars import vars_loader

    # Dynamically create mapped_functions to call get_plugin_vars()
    mapped_functions = {}
    for plugin in vars_loader.all():
        mapped_functions[plugin._load_name] = plugin

    class TestPluginLoader(unittest.TestCase):
        def test_get_plugin_vars(self):
            for plugin_name in mapped_functions:
                plugin = mapped_functions[plugin_name]

# Generated at 2022-06-23 15:12:29.391831
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    pass

# Generated at 2022-06-23 15:12:30.428216
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    pass


# Generated at 2022-06-23 15:12:38.879434
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    tests = [  # testcase(test_get_vars_from_inventory_sources), path, stage, expected_list
        ('test1', 'test/static/hosts', 'inventory', ['host_var_a']),
        ('test2', 'test/group_vars/all', 'task', ['group_var_a']),
        ('test3', 'test/host_vars/host1', 'task', ['host_var_a']),
        ('test4', 'test/static/hosts', 'task', ['host_var_a']),
        ('test5', 'foo/host_vars/host1', 'task', []),
    ]

    for name, path, stage, expected in tests:
        loader = 'loader'
        entity = 'entities'
        d = get_vars_from_

# Generated at 2022-06-23 15:12:49.649765
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.utils.collection_loader import get_collection_ref_from_name
    from ansible.vars.hostvars import HostVars
    from ansible.vars.varsplugins import VarsModule

    # This test should not fail if VARIABLE_PLUGINS_ENABLED is not set
    vars_loader.clear_all_vars_sources()
    vars_loader.add_directory(os.path.join(os.path.dirname(__file__), 'vars_plugin_test'), with_subdir=True)
    assert len(vars_loader.all()) == 0


# Generated at 2022-06-23 15:12:56.375997
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.utils.vars import combine_vars

    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch


    inventory_path = 'ansible_collections/notstdlib/moveitallout/tests/unit/compat/vars_plugin_test_inventory'
    variable_manager = VariableManager()
    loader = variable_manager.loader

    # Generate the variable using generic vars plugin
    vars_plugin = vars_loader.get("vars")
    _hosts = ['host_a', 'host_b']
    _entities = [Host(name=_host) for _host in _hosts]
    entities = _entities.copy()
   

# Generated at 2022-06-23 15:13:03.814901
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    plugin_name = 'vars_from_dirs'
    plugin = vars_loader.get(plugin_name)
    path = './test_data/vars_from_dirs/'
    entities = ['test_group', 'test_host']
    data = get_plugin_vars(None, plugin, path, entities)
    expected_data = {'test_key': 'test_value'}
    assert expected_data == data

# Generated at 2022-06-23 15:13:14.505389
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    display.verbosity = 3
    loader = DataLoader()
    inv_mgr = InventoryManager(loader, sources=[])
    inv_mgr.add_group('g')
    inv_mgr.add_host('h', 'g')

    group = inv_mgr.groups['g']
    host = inv_mgr.hosts['h']
    vars_mgr = VariableManager(loader=loader, inventory=inv_mgr)

    # Test that base class raises before get_vars is called and that it is called with the correct arguments
    class TestPlugin0:
        _load_

# Generated at 2022-06-23 15:13:22.791453
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    ''' unit test for function get_plugin_vars '''

    fake_plugin = type('FakeVarsPlugin', (object,),
                       {'get_vars': lambda self, loader, path, entities: 'get_vars',
                        'get_host_vars': lambda self, entity: "get_host_vars",
                        'get_group_vars': lambda self, entity: "get_group_vars",
                        '_load_name': 'ignore',
                        '_original_path': 'ignore'})

    class FakeLoader(object):
        def get_basedir(self):
            return 'fake_basedir'

    fake_loader = FakeLoader()

    # v2 plugin

# Generated at 2022-06-23 15:13:34.470617
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import base
    from ansible.plugins.vars.group_vars import GroupVarsBase
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host

    # A valid host_vars plugin
    class MockVarsA(base.BaseVarsPlugin):
        pass

    # A valid group_vars plugin
    class MockVarsB(GroupVarsBase):
        pass

    # An invalid host_vars plugin
    class MockVarsC(base.BaseVarsPlugin):
        @staticmethod
        def get_vars(loader, path, entities):
            return dict((e, dict(foo=1)) for e in entities)

    # An invalid group_vars plugin

# Generated at 2022-06-23 15:13:40.883043
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import BaseVarsPlugin

    class TestVarsPlugin(BaseVarsPlugin):
        def get_vars(self, loader, path, entities):
            return {'test_key': 'test_value'}

    loader = None
    test_plugin_path = 'test/test_plugin_path'
    entities = []

    test_plugin = TestVarsPlugin()
    assert get_plugin_vars(loader, test_plugin, test_plugin_path, entities) == {'test_key': 'test_value'}



# Generated at 2022-06-23 15:13:52.178601
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    inventory_file_path = os.path.join(os.path.dirname(__file__), os.path.pardir, "inventory")

    inventory_file = os.path.join(inventory_file_path, "test_inventory")
    inventory_file_no_group = os.path.join(inventory_file_path, "test_inventory_no_group")
    inventory_dir = os.path.join(inventory_file_path, "dir1")

    sources = [inventory_file, inventory_dir, inventory_file_no_group]

    data = get_vars_from_inventory_sources(loader, sources, None, None)


# Generated at 2022-06-23 15:14:05.186124
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    import ansible.inventory.manager
    import ansible.parsing.dataloader


# Generated at 2022-06-23 15:14:16.638443
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    class MyClass:
        def _load_name(self):
            return 'test'
        def _original_path(self):
            return 'test.py'
        def get_vars(self, loader, path, entities):
            return {}
        def get_host_vars(self, host):
            return {}
        def get_group_vars(self, group):
            return {}

    loader = MyClass()
    entities = []
    vars_plugins_enabled = [
        'test',
        'test_stage_all',
        'test_stage_inventory',
        'test_stage_task',
        'test_stage_task_no_global',
        'test_stage_all_no_global',
        'test_stage_inventory_no_global',
    ]

    global C

# Generated at 2022-06-23 15:14:21.712604
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader, ["/dev/null"])
    inventory.add_group('group')
    group = inventory.get_group("group")
    group.add_host(Host("host"))

    inventory.add_group('all')
    all_group = inventory.get_group("all")
    all_group.add_host(Host("host2"))

    vars_manager = VariableManager(loader, inventory)
    vars_manager._vars_plugins = [FakeVarsPlugin(name='fake1'), FakeVarsPlugin(name='fake2')]

    assert vars_manager.get_vars_from

# Generated at 2022-06-23 15:14:33.551599
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    from ansible.plugins.vars import basic

    class VarsLoader:
        def add_directory(self, directory, with_subdir=False):
            pass

    class CollectionLoader:
        def get_basedir(self, collection_name):
            return '/collection_dir'

    class LoaderModule:
        def get_basedir(self):
            return '/module_dir'

        def get_collections(self):
            return [CollectionLoader()]

        def get_plugin_loader(self):
            return VarsLoader()

    class PlayContext:
        def __init__(self):
            self.vars_plugins_enabled = []

    class Plugin:
        class PluginOptions:
            def __init__(self):
                self.key = 'value'


# Generated at 2022-06-23 15:14:34.455095
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    pass

# Generated at 2022-06-23 15:14:44.908791
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from tests.unit.mock.loader import DictDataLoader

    def test_files_from_dir(dir_path):
        for dirname, _dirnames, filenames in os.walk(dir_path):
            for filename in filenames:
                yield os.path.join(dirname, filename)

    test_vars_plugin_dir = os.path.join(os.path.dirname(__file__), 'data', 'plugins')

    # test in-playbook vars
    test_path = os.path.join(test_vars_plugin_dir, 'v2_type_vars_plugins')
    test_loader = DictDataLoader({test_path: tuple(test_files_from_dir(test_path))})
    test_entities = [Host(name='test-host')]



# Generated at 2022-06-23 15:14:49.448502
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    # Setup
    loader = {1}
    sources = ['/somewhere']
    entities = {'test1', 'test2'}

    # Execute
    data = get_vars_from_inventory_sources(loader, sources, entities, 'test')

    # Assert
    assert data == {}

# Generated at 2022-06-23 15:14:55.776348
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    sources = ['hosts', '/does/not/exist/file.yml', '/does/not/exist/hosts.txt']
    entities = [Host(name='localhost'), Host(name='otherhost')]
    stage = 'task'
    assert {'localhost': {'var_one': 1}, 'otherhost': {'var_two': 2}} == get_vars_from_inventory_sources(None, sources, entities, stage)

# Generated at 2022-06-23 15:15:04.169623
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    test_sources = [
        ansible_dir('/test/path/with/many/commas'),
        '/test/path/with/comma',
        '/test/path/with/comma/hosts',
        None]
    test_entities = ['host1', 'host2', 'host3']
    # noinspection PyProtectedMember
    loader = vars_loader._create_loader('/etc/ansible/roles/')
    stage = 'inventory'
    vars = get_vars_from_inventory_sources(loader, test_sources, test_entities, stage)
    assert vars

# Generated at 2022-06-23 15:15:15.015800
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    from ansible.plugins.vars import TestVarsPlugin
    data = get_plugin_vars(None, TestVarsPlugin(), None, [Host('host_name')])
    assert data == {'common': {'host_name': 'host_name'}, 'host': {'host_name': 'host_name'}}

    data = get_plugin_vars(None, TestVarsPlugin(), None, [Host('host_name'), Host('host_name2')])
    assert data == {'common': {'host_name': 'host_name'},
                    'host': {'host_name': 'host_name', 'host_name2': 'host_name2'}}

# Generated at 2022-06-23 15:15:25.812151
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    assert get_vars_from_inventory_sources(None,
        ['/mock_inv/group_vars/'],
        [],
        'inventory'
    ) == {'group': {'a':1}}

    assert get_vars_from_inventory_sources(None,
        ['/mock_inv/vars/'],
        [],
        'inventory'
    ) == {'inv': {'a':2}}

    assert get_vars_from_inventory_sources(None,
        ['/mock_inv/host_vars/'],
        [],
        'inventory'
    ) == {'host': {'a':3}}


# Generated at 2022-06-23 15:15:36.188654
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader, sources=['localhost,', 'otherhost,', 'group1:group2,', 'group3:group4,'], vault_password='secret')

    vars_data = get_vars_from_path(loader, "/some/path", [inventory.hosts.get("localhost"), inventory.groups.get("group1"), inventory.groups.get("group3")], "inventory")

# Generated at 2022-06-23 15:15:48.017117
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    # See test_vars_plugin.py for tests of the variable_plugins code itself
    # we have to set up the mock vars plugins before loading an inventory
    from ansible.plugins.loader import vars_loader
    from ansible.plugins.vars import test_vars_plugin
    vars_loader.add(test_vars_plugin.TestVarsModule)

    # if the test inventory does not exist and we try to load it, we'll get an error unrelated to our actual code
    inv = dict(
        plugin='vars_file_with_inventory',
        name='test',
        options=dict(
            host_list='ansible/test/unit/inventory/bad_dir'),
    )
    loader, sources, _, _ = _get_inventory_sources(inv)
    data = get_vars_from

# Generated at 2022-06-23 15:16:00.283581
# Unit test for function get_vars_from_inventory_sources

# Generated at 2022-06-23 15:16:08.882392
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    class FakePlugin:

        def __init__(self, name):
            self._load_name = name

        def get_vars(self, loader, path, entities):
            return {'vars_plugin_name': self._load_name}

    class FakeLoader:
        pass

    fake_loader = FakeLoader()
    fake_path = '/path/to/somewhere'
    fake_entities = [Host('hostname')]
    fake_plugins = [FakePlugin('fake_plugin_1'), FakePlugin('fake_plugin_2')]
    fake_stage = 'inventory'
    expected_result = {'vars_plugin_name': ['fake_plugin_1', 'fake_plugin_2']}


# Generated at 2022-06-23 15:16:10.853171
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    assert get_vars_from_inventory_sources(None, ["/path/to/sources"], ["somelist"], "inventory")

# Generated at 2022-06-23 15:16:20.268301
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    loader = None
    stage = 'inventory'
    sources = ['test/test_inventories/test_inventory_vars_plugin/']
    host_name = 'test_inventory_vars_plugin_1'
    host = Host(host_name)
    entities = [host]
    # 'priority1' has the value from the file host_vars/test_inventory_vars_plugin_1.yml
    # 'priority2' has the value from the file group_vars/all.yml
    # 'priority3' has the value from the file group_vars/other_group.yml
    # 'priority4' has the value from the file group_vars/test_group.yml
    # 'priority5' has the value from the file inventory_vars.yml
    # 'priority6' has the

# Generated at 2022-06-23 15:16:23.948801
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Test that empty path and entities yields an empty vars
    assert {} == get_vars_from_path(None, "", [], "")



# Generated at 2022-06-23 15:16:27.177122
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_cache
    assert get_plugin_vars(vars_loader, vars_cache, '/path/to/inventory', []) == {}

# Generated at 2022-06-23 15:16:29.512922
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Test local_facts
    # Test group vars
    # Test host vars
    # Test v2 plugins
    pass


# Generated at 2022-06-23 15:16:36.935237
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.group import Group
    from ansible.inventory.ini import InventoryParser
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory_path = os.path.realpath("test/integration/inventory.ini")
    inv_parser = InventoryParser("host_list", loader, None, cache=False)
    inventory = inv_parser.parse_inventory(inventory_path)
    group = inventory.groups["ungrouped"]
    assert(group is not None)
    output = get_vars_from_inventory_sources(loader, [],"", group.hosts, "inventory")
    print(output)

# Generated at 2022-06-23 15:16:48.076846
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    # test data
    path = 'path/to/inventory/source/file'
    loader = DataLoader()
    inventory_file = 'inventory_file'
    inventory_directory = 'inventory_directory'
    inventory_directory_path = 'path/to/inventory/directory'
    sources = [None, inventory_file, inventory_directory, '{0},{1}'.format(inventory_file, inventory_file)]
    stage_all = 'all'
    stage_task = 'task'


# Generated at 2022-06-23 15:16:49.121336
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    pass

# Generated at 2022-06-23 15:16:58.457314
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.plugins.vars.core import VarsModule
    import ansible.plugins.vars.core

    config = {}

    class Plugin(VarsModule):  # pylint: disable=missing-docstring,too-few-public-methods
        def get_vars(self, loader=None, path=None, entities=None):
            del loader  # unused
            del path  # unused
            del entities  # unused
            return config

    test_path = '/foo/bar/baz'
    entities = None

    vars_loader.add('test_plugin', Plugin)
    assert config == get_vars_from_path(None, test_path, entities, "inventory")

    ansible.plugins.vars.core.VARS_PLUG

# Generated at 2022-06-23 15:17:05.440541
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins import vars_plugins

    plugin_name = 'test_vars_plugins'
    plugin_path = plugin_name + '.py'

    plugin = vars_plugins[plugin_path]

    vars_loader = AnsibleVarsPluginsLoader()
    vars_loader._vars_plugins = {}
    vars_loader._vars_plugins[plugin_name] = plugin

    entities = Host.__subclasses__()
    path = './'

    test_data = get_vars_from_path(vars_loader, path, entities, 'inventory')
    assert test_data == {'test': 'var'}

# Generated at 2022-06-23 15:17:13.463762
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    # import plugins only needed for unit test here
    # so we don't have to change code for other unit tests
    from ansible.plugins.loader import vars_loader
    from ansible.plugins.vars.host_group_vars import VarsModule
    from ansible_collections.ansible.builtin.plugins.module_utils.vars.host_group_vars import HostVars
    from collections import namedtuple

    # At the same time, we are testing vars_loader.__iter__()
    vars_plugin_list = list(vars_loader.all())
    assert len(vars_plugin_list) > 0

    # Old vars plugin is not compatible with Ansible 2.5.
    #   The old vars plugin does not support the 'run' method.
    old_vars_plug = None

# Generated at 2022-06-23 15:17:22.513195
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.plugins.loader import vars_loader as v
    assert isinstance(v.all(), list)
    assert len(v.all()) > 0
    assert v.all()[0]._load_name == 'hashivault_secret'
    assert v.all()[1]._load_name == 'aws_ec2'
    assert v.all()[2]._load_name == 'aws_ssm'
    assert v.all()[3]._load_name == 'yaml'
    assert v.all()[4]._load_name == 'ini'
    assert v.all()[5]._load_name == 'vault'

# Generated at 2022-06-23 15:17:30.551012
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader

    paths = [
        '/etc/ansible/hosts',
        '/etc/ansible/vars',
        '/etc/ansible/group_vars/all',
        '/etc/ansible/group_vars/www',
        '/etc/ansible/group_vars/webservers',
        '/etc/ansible/host_vars/host1',
        '/etc/ansible/host_vars/host2',
    ]

    plugin = vars_loader.get('always')

    loader = DataLoader()
    manager = InventoryManager(loader=loader)
    data = get

# Generated at 2022-06-23 15:17:38.417477
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.loader import vars_loader
    from ansible.utils.file_lookup import file_lookup_loader

    if 'inventory' not in vars_loader.all():
        vars_loader.add('inventory', os.path.join(os.path.dirname(__file__), 'inventory_vars'))

    loader = file_lookup_loader
    plugin = vars_loader.all()['inventory']

    _inventory = {'plugin_name': plugin._load_name, 'plugin_path': plugin._original_path}
    path = os.path.dirname(__file__)
    entities = ['test_entity']
    expected_dict = {'test_list': ['1', '2', '3'], 'test_string': 'test'}

# Generated at 2022-06-23 15:17:48.479334
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    from ansible.plugins.loader import vars_loader

    vars_plugin_list = list(vars_loader.all())
    for plugin_name in C.VARIABLE_PLUGINS_ENABLED:
        if AnsibleCollectionRef.is_valid_fqcr(plugin_name):
            vars_plugin = vars_loader.get(plugin_name)
            if vars_plugin is not None:
                if vars_plugin not in vars_plugin_list:
                    vars_plugin_list.append(vars_plugin)


# Generated at 2022-06-23 15:17:53.822538
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Tests using local plugins (in test/units/plugins)
    # This will fail if not run under test/units
    loader = vars_loader.get('v1')
    data = {}
    data = combine_vars(data, get_plugin_vars(loader, plugin, 'localhost', ['localhost']))
    assert isinstance(data, dict)

# Generated at 2022-06-23 15:18:01.069808
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    loader = None
    path = "/home/myhome/"
    entities = ["my_entity"]
    stage = "inventory"
    data = ["b"]

    test_plugin = vars_loader.get("test")
    vars_plugin_list = [test_plugin]

    test_plugin.get_vars = get_plugin_vars
    assert(get_vars_from_path(loader, path, entities, stage) == data)


# Generated at 2022-06-23 15:18:12.084415
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()

    test_inventory = os.path.join(os.path.dirname(__file__), 'inventory')
    sources = [test_inventory]

    playbook = Play()
    playbook._load_name = u'test_playbook'
    task = Task()
    task._role = None
    task._parent = playbook
    task._variable_manager = variable_manager

    test_vars = get_vars_from_inventory_sources(loader, sources, [task], 'task')

# Generated at 2022-06-23 15:18:20.906733
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.plugins.loader import vars_loader

    fake_loader = DataLoader()
    fake_inventory = InventoryManager(loader=fake_loader)

    fake_inventory_source = """
    [test_group1]
    test_host1
    """
    fake_inventory.load_inventory_from_source(fake_inventory_source)


# Generated at 2022-06-23 15:18:29.326962
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    test_host = Host()
    test_host.name = 'host1'
    test_host.groups.append('groupname')
    
    # Create a Mock loader class
    class MyLoader:
        def load_from_file(self, filename):
            return {}

    my_loader = MyLoader()

    # Create a Mock plugins class
    class MyPlugins:
        def _load_plugins(self):
            return []

    my_plugins = MyPlugins()
    my_data = get_vars_from_inventory_sources(my_loader, ['test'], [test_host], 'inventory')

# Generated at 2022-06-23 15:18:38.541603
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    # pylint: disable=unused-argument
    from ansible.inventory.manager import InventoryManager

    plugin_vars = [
        'group_vars',
        'host_vars',
        'a',
        'b',
        'd',
        'e',
        'c',
        'f',
        'g',
        'h',
        'i',
        'j',
    ]

    def _get_vars(loader, path, entities):
        return {'%s_%s' % (plugin._load_name, v): v for v in plugin_vars}

    class FakeVarsPlugin(object):
        def __init__(self, name):
            self._load_name = name

        def get_vars(self, loader, path, entities):
            return get_plugin_

# Generated at 2022-06-23 15:18:40.725132
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert get_vars_from_path(True, './', [], 'task') == {}

# Generated at 2022-06-23 15:18:49.971997
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.parsing.dataloader import DataLoader

    # Test 1 with env group
    loader = DataLoader()
    sources = ['inventory/env/group_vars/group_vars']
    entities = ['localhost']
    expected_data = {'pipeline': 'test'}
    result = get_vars_from_inventory_sources(loader, sources, entities, 'task')
    assert result == expected_data

    # Test 2 with global group
    loader = DataLoader()
    sources = ['inventory/env/hosts']
    entities = ['localhost']
    expected_data = {'pipeline': 'test'}
    result = get_vars_from_inventory_sources(loader, sources, entities, 'task')
    assert result == expected_data

    # Test 3 with task
    loader

# Generated at 2022-06-23 15:19:00.479341
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ...unit.compat.mock import patch
    from ...unit.plugins.loader import DictModule
    from ...unit.plugins.vars import TestVarsPlugin

    loader = DictModule()
    plugin = TestVarsPlugin(loader=loader)

    path = '/path/to/somewhere'
    entities = ['inventory']

    with patch.object(vars_loader, 'all') as mock_vars_loader_all:
        mock_vars_loader_all.return_value = [plugin]
        data = get_vars_from_path(loader, path, entities, stage='inventory')

        assert data == { 'foo': 'bar' }

        data = get_vars_from_path(loader, path, entities, stage='task')

        assert data == { }



# Generated at 2022-06-23 15:19:00.890291
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    pass

# Generated at 2022-06-23 15:19:01.450780
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    pass

# Generated at 2022-06-23 15:19:07.677901
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    # Test with a vars plugin, a fake source, and a get_vars function.
    # The get_vars function should be called with the source as an argument.
    def get_vars(original_path):
        return {'my_secret': original_path}

    vars_plugin = type('VarsPlugin', (object,), {'get_vars': get_vars})()
    source = './some/path'

    data = get_vars_from_inventory_sources(None, [source], None, None)
    assert data['my_secret'] == source

# Generated at 2022-06-23 15:19:12.000775
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    loader = None
    path = '/home/user/project'
    entities = ['host1', 'host2']
    stage = 'inventory'
    assert get_vars_from_path(loader, path, entities, stage)
    assert get_vars_from_path(loader, None, entities, stage)

# Generated at 2022-06-23 15:19:21.644453
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    global display
    display.verbosity = 0

    loader = vars_loader
    path = '/home/user/' #Unused, should not be needed
    entities = [Host(name="localhost")]

    # Test that a get_vars method is required
    try:
        class TestPlugin:
            def test_method(self):
                pass
        test_plugin = TestPlugin()
        plugin_data = get_plugin_vars(loader, test_plugin, path, entities)
    except AnsibleError as e:
        assert "get_vars" in e.message
    else:
        raise AssertionError("AnsibleError not raised")

    # Test that a get_host_vars or get_group_vars method is required