

# Generated at 2022-06-23 15:09:27.481875
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.collection.collection_artifact import AnsibleCollectionArtifact
    from ansible.inventory.manager import InventoryManager

    collection_artifact = AnsibleCollectionArtifact.init_artifact('/tmp', 'filename')

    host_definitions = '''
    [group1]
    host1 name="host1"
    [group2]
    host2 name="host2"
    [group1:vars]
    group1_var="this is group1 variable"
    [group2:vars]
    group2_var="this is group2 variable"
    '''

    collection_artifact.put_content(host_definitions, 'hosts')
    loader = collection_artifact.get_loader()
    inventory = InventoryManager(loader, '/tmp/hosts')
    entities = inventory.get_groups_dict

# Generated at 2022-06-23 15:09:28.039578
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    pass

# Generated at 2022-06-23 15:09:39.758653
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    from ansible.plugins.vars import vars_test
    from ansible.plugins.loader import vars_loader

    fake_loader = AnsibleLoader()
    fake_plugin = vars_test.VarsModule()
    fake_plugin.set_options({'hostname': 'somehost'})
    fake_plugin.set_context({'inventory_hostname': 'somehost', '_hostname': 'somehost'})
    # FIXME: monkey patch a real path into the plugin
    fake_plugin._original_path = 'test_plugins/vars/vars_test.py'
    fake_plugin._load_name = 'vars_test'
    fake_plugin._subdir = 'test_plugins/vars'

    vars_loader._inventory = fake_loader

    test_host = Host(name="testhost")

# Generated at 2022-06-23 15:09:41.389158
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    pass


# Generated at 2022-06-23 15:09:48.914875
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    path = os.path.dirname(__file__)
    entities = []
    stage = 'inventory'
    vars_from_inventory_sources = get_vars_from_inventory_sources(loader, [path], entities, stage)
    print(vars_from_inventory_sources)


if __name__ == '__main__':
    test_get_vars_from_inventory_sources()

# Generated at 2022-06-23 15:09:56.231176
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    import ansible.plugins.loader
    import ansible.plugins.vars.my_plugin
    import ansible.plugins.vars.my_other_plugin

    plugin = ansible.plugins.vars.my_plugin.MyPlugin()
    plugin.set_options([])
    loader = ansible.plugins.loader.VarsModuleLoader()
    host = Host(name='localhost')
    assert get_plugin_vars(loader, plugin, 'path', [host]) == plugin.get_vars(loader, 'path', [host])

    plugin = ansible.plugins.vars.my_other_plugin.MyOtherPlugin()
    plugin.set_options([])
    host = Host(name='localhost')
    group = Host(name='test')

# Generated at 2022-06-23 15:09:58.743138
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    assert get_plugin_vars('loader', 'plugin', 'path', 'entities') == {}


# Generated at 2022-06-23 15:10:08.660879
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    inventory_manager = InventoryManager(loader=loader, sources=["inventory"])

    sources = ['/etc/ansible/hosts']

    group_entities = inventory_manager.groups.values()
    host_entities = inventory_manager.hosts.values()

    data = get_vars_from_inventory_sources(loader, sources, group_entities, "inventory")
    assert data != {}

    data = get_vars_from_inventory_sources(loader, sources, host_entities, "inventory")
    assert data != {}



# Generated at 2022-06-23 15:10:16.905920
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    '''Unit test function get_plugin_vars'''
    import unittest
    import ansible.plugins.vars.ini_file as ini_file

    class TestVarsPlugin(ini_file.VarsModule):
        '''Test plugin class'''

        def __init__(self, *args, **kwargs):
            '''Mock init'''
            self.my_path = None
            self.my_group = None
            self.my_host = None
            self.my_entities = None
            self.my_loader = None
        def get_vars(self, loader, path, entities):
            '''Mock get_vars'''
            self.my_path = path
            self.my_loader = loader
            self.my_entities = entities
            data = {}
            data

# Generated at 2022-06-23 15:10:28.759677
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    import ansible.plugins.vars.base_vars
    plugin = ansible.plugins.vars.base_vars.BaseVars()

    assert get_plugin_vars(None, plugin, None, None) == {}

    plugin.get_vars = lambda a, b, c: {"c": 3}
    plugin._load_name = "test"
    plugin._original_path = "test"

    assert get_plugin_vars(None, plugin, None, None) == {"c": 3}

    plugin.get_host_vars = lambda a, b: {"d": 4}
    plugin.get_group_vars = lambda a, b: {"e": 5}

    assert get_plugin_vars(None, plugin, None, []) == {"c": 3}

# Generated at 2022-06-23 15:10:36.083114
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    assert get_vars_from_inventory_sources(None, [], [], "") == {}
    assert get_vars_from_inventory_sources(None, ["/foo/bar"], [], "") == {}
    assert get_vars_from_inventory_sources(None, ["/foo/bar"], [Host("localhost")], "") == {}
    assert get_vars_from_inventory_sources(None, ["/foo/bar"], [Host("localhost")], "") == {}

# Generated at 2022-06-23 15:10:37.140155
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    pass



# Generated at 2022-06-23 15:10:48.278664
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    from ansible.plugins.vars import vars_test1
    from ansible.plugins.vars import vars_test2
    from ansible.plugins.vars import vars_test3
    from ansible.plugins.vars import vars_test4

    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    vt1 = vars_test1()
    vt2 = vars_test2()
    vt3 = vars_test3()
    vt4 = vars_test4()

    test_entities = [
        Host(name='first'),
        Host(name='second'),
        Group(name='first'),
        Group(name='second')
        ]
    test_path = '/some/random/path'

    data = {}

    data = combine

# Generated at 2022-06-23 15:10:57.460363
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    def get_vars(loader, path, entities):
        data = {}
        for entity in entities:
            data[entity.name] = {
                'host_vars_test': True,
            }

        return data

    class TestVarsPlugin:
        pass

    plugin = TestVarsPlugin()
    plugin._load_name = 'test'
    plugin.get_vars = get_vars

    loader = {}
    path = 'path'
    entities = [Host(name='testhost')]

    assert get_plugin_vars(loader, plugin, path, entities)['testhost']['host_vars_test'] is True

# Generated at 2022-06-23 15:10:57.813557
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    assert True

# Generated at 2022-06-23 15:11:08.065029
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    loader, sources, entities, stage = None, [], [], 'inventory'

    # test with an empty list of sources
    assert get_vars_from_inventory_sources(loader, sources, entities, stage) == {}

    # test with an host list
    sources.append('host1,host2')
    assert get_vars_from_inventory_sources(loader, sources, entities, stage) == {}

    # test with an invalid host list
    sources.append('host1,host2')
    assert get_vars_from_inventory_sources(loader, sources, entities, stage) == {}

    # test with a valid inventory source directory, but it does not contain a plugin
    sources.append('test/test_vars_plugins/')

# Generated at 2022-06-23 15:11:19.166691
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    paths = []
    for path in vars_loader.ALL_PLUGINS:
        path = os.path.join(C.DEFAULT_LOCAL_TMP, path)
        if os.path.exists(path):
            paths.append(path)

    plugin_paths = []
    for path in paths:
        plugin_paths.append(os.path.join(path, 'vars_plugins'))

    assert get_vars_from_path("", "", "", "") == {}
    assert get_vars_from_path("", plugin_paths, "", "") != {}
    assert get_vars_from_path("", "", "", "") == {}
    assert get_vars_from_path("", "", "", "") == {}

# Generated at 2022-06-23 15:11:25.433418
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    loader = None
    sources = ['/path/to/my/folder', '/path/to/my/comma,delimited_source.txt']
    entities = []
    stage = 'inventory'
    get_vars_from_inventory_sources(loader, sources, entities, stage)

# Generated at 2022-06-23 15:11:28.799203
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.plugins.loader import var_plugins

    assert get_vars_from_inventory_sources(var_plugins, [], [], "") == {}

# Generated at 2022-06-23 15:11:40.502058
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import VarsModule
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.collection_loader import AnsibleCollectionRef
    from ansible.utils.vars import combine_vars
    import ansible.constants as C

    vars_loader.add(VarsModule(), 'test', AnsibleCollectionRef.root())

    vars = {}
    vars = combine_vars(vars, get_plugin_vars(DataLoader(), vars_loader.get('test'), '/var/test', [Group('group1'), Host('test')]))
    assert 'test_plugin_group' in vars
   

# Generated at 2022-06-23 15:11:47.649738
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    class TestEntity:
        def __init__(self, name):
            self.name = name

    display.verbosity = 3

    loader = None
    sources = ['host_vars', 'group_vars']
    entities = [TestEntity('testhost_name'), TestEntity('testgroup_name')]
    stage = 'inventory'

    assert get_vars_from_inventory_sources(loader, sources, entities, stage) == {'inventory_hostname': 'testhost_name', 'group_names': ['all', 'testgroup_name']}

# Generated at 2022-06-23 15:11:49.042110
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    pass



# Generated at 2022-06-23 15:11:57.107830
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    # Create a task queue manager
    tqm = TaskQueueManager()

    # Create an inventory (from test/integration/inventory) and load variables
    INVENTORY_FILE = os.path.join(os.path.dirname(os.path.realpath(__file__)), "..", "..", "..", "test", "integration", "inventory")
    inventory_manager = InventoryManager(loader=tqm.loader, sources=[INVENTORY_FILE])
    variable_manager = VariableManager(loader=tqm.loader, inventory=inventory_manager)

    # Get "all" group variables

# Generated at 2022-06-23 15:12:07.358731
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    test_dir = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'vars_test_dir/')

    loader = None
    sources = [os.path.join(test_dir, 'test_inventory_vars')]
    entities = ['test_group']
    stage = 'inventory'

    data = get_vars_from_inventory_sources(loader, sources, entities, stage)

    assert data['group_var_inventory_only'] == 'inventory_only', \
        "group var from test_inventory_vars did not contain correct value \"group_var_inventory_only\""

# Generated at 2022-06-23 15:12:17.539191
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    # patch our ansible.cfg file
    ansible_cfg_path = os.path.join(os.path.dirname(__file__), '../test/sanity/code/ansible.cfg')
    display.debug("Using ansible.cfg: %s" % ansible_cfg_path)
    C.config.load_config_file(ansible_cfg_path)

    # create a vars plugin
    vars_plugin = type('vars_plugin', (object,), {})()
    vars_plugin.get_vars = lambda x, y, z: {'result': 'pass'}
    vars_plugin._original_path = 'ansible/plugins/vars/test_vars.py'
    vars_plugin._load_name = 'test_vars'

    # create an inventory source


# Generated at 2022-06-23 15:12:28.008138
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Create fake vars plugins
    class FakePlugin1:
        def __init__(self):
            self._load_name = 'fake1'
            self._original_path = '/path1'
        def get_vars(self, loader, path, entities):
            return {'fake1': 1}
    class FakePlugin2:
        def __init__(self):
            self._load_name = 'fake2'
            self._original_path = '/path2'
            self.REQUIRES_WHITELIST = True
        def get_vars(self, loader, path, entities):
            return {'fake2': 2}
    class FakePlugin3:
        def __init__(self):
            self._load_name = 'fake3'
            self._original_path = '/path3'

# Generated at 2022-06-23 15:12:29.750187
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    get_vars_from_inventory_sources(None, None, None, None)

# Generated at 2022-06-23 15:12:39.608406
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    import tempfile
    import os

    # Test file plugin and automatic vars plugin functionality
    # by putting a vars plugin inside a vars directory inside a file
    # directory inside a vars directory
    # This is the expected layout:
    # temp/
    #     parent/
    #         groupvars/
    #             group1/
    #         hostvars/
    #             host1
    #         group_vars/
    #             group2/
    #                 varsdir/
    #                     varsdir/
    #                         func.yml
    #                         vars.yml
    # Created by michael.dehaan@gmail.com on Mon, July 3, 2017

    g1_fixture = """
---
key1: val1
key2: val2
"""


# Generated at 2022-06-23 15:12:50.584744
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    # for test
    os.environ['ANSIBLE_VARS_PLUGINS_ENABLED'] = "'test_plugin'"

    # prepare
    inventory = InventoryManager(loader=DataLoader(), sources='localhost,')
    var_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    path = '/ansible-test/example_playbooks'
    stage = 'inventory'
    entities = inventory.get_groups()

    # test
    vars_plugin_list = list(vars_loader.all())

# Generated at 2022-06-23 15:13:02.730326
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    """ Unit test for function get_vars_from_path """

    # create a loader object
    loader = vars_loader.VarsModule()

    # get a list of vars plugins
    vars_plugin_list = list(vars_loader.all())

    # check that the number of vars plugins stays the same before and after
    num_plugins_before = len(vars_plugin_list)

    for plugin_name in C.VARIABLE_PLUGINS_ENABLED:
        if AnsibleCollectionRef.is_valid_fqcr(plugin_name):
            vars_plugin = vars_loader.get(plugin_name)
            if vars_plugin is None:
                # Error if there's no play directory or the name is wrong?
                continue

# Generated at 2022-06-23 15:13:13.257863
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    loader, _, sources, entities, _ = _create_faked_variables_info(stage='inventory')

    data = get_vars_from_inventory_sources(loader, sources, entities, stage='inventory')


# Generated at 2022-06-23 15:13:22.019009
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    class MockPlugin:

        def get_vars(self, loader, path, entities):
            return {"key1": "get_vars", "key2": "get_vars"}

        def get_host_vars(self, host):
            return {"key1": "get_host_vars", "key3": "get_host_vars"}

        def get_group_vars(self, group):
            return {"key1": "get_group_vars", "key4": "get_group_vars"}

    class MockHost:

        def __init__(self, name):
            self.name = name

    class MockGroup:

        def __init__(self, name):
            self.name = name


# Generated at 2022-06-23 15:13:34.197524
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    # Test 1: data = {'var1': 'test1'}
    data = {'var1': 'test1'}
    # Test 2: data = {'var1': 'test1', 'var2': 'test2'}
    data.update({'var2': 'test2'})
    # Test 3: data = {'var1': 'test1', 'var2': 'test2', 'var3': {'k1': 'v1', 'k2': 'v2'}}
    data.update({'var3': {'k1': 'v1', 'k2': 'v2'}})
    # Test 4: data = {'var1': 'test1', 'var2': 'test2', 'var3': {'k1': 'v1', 'k2': 'v2'}, 'var4':

# Generated at 2022-06-23 15:13:41.451994
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import get_vault_secret

    import os
    import shutil
    import tempfile

    # create a temporary directory for testing
    test_dir = tempfile.mkdtemp()

    test_vars_file = os.path.join(test_dir, 'vars_file')
    test_vars_dict = {'hello': 'world'}

    # create a test vars_file
    with open(test_vars_file, 'w') as test_vars:
        test_vars.write(str(test_vars_dict))

    # create a test vault secret

# Generated at 2022-06-23 15:13:46.720679
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    plugin_path = os.path.join(os.path.dirname(__file__), '../../../test/units/plugins/vars')
    vars_plugin_list = vars_loader.all(plugin_path)
    plugin = vars_plugin_list[0]
    loader = None
    path = '/etc/'
    entities = [{'name': 'names1', 'nested': [{'nestedHost': 'nestedHost1'}, {'nestedHost': 'nestedHost2'}]},
                {'name': 'names2', 'nested': [{'nestedHost': 'nestedHost3'}, {'nestedHost': 'nestedHost4'}]}]
    data = get_plugin_vars(loader, plugin, path, entities)

# Generated at 2022-06-23 15:13:47.986229
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    # TODO: implement unit test
    pass

# Generated at 2022-06-23 15:13:48.938907
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    pass

# Generated at 2022-06-23 15:13:57.695925
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    class fake_plugin:
        _load_name = 'fake'
        _original_path = 'fake_path'

        def get_vars(self,  loader, path, entities):
            return {'var1': 'val1'}
    class fake_plugin2:
        _load_name = 'fake2'
        _original_path = 'fake_path2'

        def get_group_vars(self, group):
            return {'var2': 'val2'}

        def get_host_vars(self, host):
            return {'var2': 'val2'}

    loader = "fake_loader"
    plugin = fake_plugin()
    entities = ['fake_entity']
    path = '/fake/fake/'
    result = get_plugin_vars(loader, plugin, path, entities)

# Generated at 2022-06-23 15:14:01.119441
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    class TestVarsPlugin():

        def get_plugin_vars(self, loader, path, entities):
            return {'test_path': path, 'test_entities': entities}

    loader = None
    plugin = TestVarsPlugin()
    path = '/tmp/test_path'
    entities = {'group': 'test_group'}
    actual = get_plugin_vars(loader, plugin, path, entities)
    assert actual == {'test_path': path, 'test_entities': entities}

# Generated at 2022-06-23 15:14:07.519367
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    path = os.path.abspath(os.path.dirname(__file__))
    vars_plugin_list = list(vars_loader.all())
    vars_plugin_list.append(C.VARS_PLUGIN_PATH)
    loader = vars_loader
    sources = [path, None]
    entities = None
    stage = 'inventory'

    data = get_vars_from_inventory_sources(loader, sources, entities, stage)

    print(data)

# Generated at 2022-06-23 15:14:17.473246
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    import ansible.plugins

    loader = ansible.plugins.loader.vars_loader

    path = "tests/vars_plugins/collection/ansible_collections/dmahugh/vars"
    entities = ["group_name"]
    stage = "inventory"

    # Test function for the correct plugin is loaded
    data = get_vars_from_path(loader, path, entities, stage)
    assert data is not None
    assert data["test_var"] == "test_val"

    # Test function for the correct plugin is not loaded
    path = "tests/vars_plugins/collection/invalid_collection/vars"
    data = get_vars_from_path(loader, path, entities, stage)
    assert data is None


# Generated at 2022-06-23 15:14:26.577387
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    class MyVarsModule:
        def get_vars(self, loader, path, entities):
            return {'matched_var': 'myvar'}

    class MyVarsModuleV1:
        def run(self, hostname):
            return {'matched_var': 'myvar'}

    # Test with vars plugin that supports new signature
    vars_plugin = MyVarsModule()
    host = Host('testhost')
    loader = None
    path = 'path'
    entities = [host]
    assert get_plugin_vars(loader, vars_plugin, path, entities) == {'matched_var': 'myvar'}

    # Test with vars plugin that supports legacy signature
    vars_plugin = MyVarsModuleV1()

# Generated at 2022-06-23 15:14:33.728984
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    collection_path = os.path.join(C.DEFAULT_COLLECTIONS_PATH[0], 'nswebscale_netapp.test')

    # Set up
    plugin = vars_loader.get("nswebscale_netapp.test.plugins.vars.test_vars")
    path = collection_path
    entities = [Host("fake")]
    stage = 'inventory'

    # Test
    assert get_plugin_vars(None, plugin, path, entities) == {'test_vars': 'fake'}

# Generated at 2022-06-23 15:14:41.435743
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    assert get_vars_from_path(None, None, None, None) == {}
    assert get_vars_from_path(None, None, None, 'inventory') == {}
    assert get_vars_from_path(None, None, None, 'task') == {}
    assert get_vars_from_path(None, None, None, 'any') == {}
    assert get_vars_from_path(None, 'path', None, None) == {}
    assert get_vars_from_path(None, 'path', None, 'inventory') == {}
    assert get_vars_from_path(None, 'path', None, 'task') == {}
    assert get_vars_from_path(None, 'path', None, 'any') == {}

# Generated at 2022-06-23 15:14:52.383944
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    # if a plugin-specific setting has not been provided, use the global setting
    # older/non shipped plugins that don't support the plugin-specific setting should also use the global setting
    # C.RUN_VARS_PLUGINS == 'demand' and stage == 'inventory'
    data = {}
    data = combine_vars(data, get_vars_from_path('', '', '', 'inventory'))
    assert data

    # C.RUN_VARS_PLUGINS == 'start' and stage == 'task'
    data = {}
    data = combine_vars(data, get_vars_from_path('', '', '', 'task'))
    assert data

    # has_stage and plugin.get_option('stage') not in ('all', stage)
    data = {}
    data = combine_vars

# Generated at 2022-06-23 15:15:01.706063
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    d = get_vars_from_path(None, '.',
                           [Host(name='localhost', port=1), 'all'],
                           'inventory')
    assert d['inventory_dir'] == os.path.abspath('.')
    assert d['inventory_file'] == os.path.abspath(C.DEFAULT_HOST_LIST)
    assert d['inventory_hostname'] == 'localhost'
    assert d['inventory_hostname_short'] == 'localhost'
    assert d['playbook_dir'] == os.path.abspath('.')


# Generated at 2022-06-23 15:15:14.372300
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.errors import AnsibleError
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook import Playbook
    from ansible.vars.manager import VariableManager

    def run_get_vars_from_inventory_sources(path, stage):
        d = DataLoader()
        inv = InventoryManager(loader=d, sources=[path])
        var = VariableManager(loader=d, inventory=inv)
        pb = Playbook.load(path, var, loader=d)
        task = pb.get_plays()[0].get_tasks()[0]
        return get_vars_from_inventory_sources(d, [path], task.get_vars_files_from_task(), stage)


# Generated at 2022-06-23 15:15:22.932512
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # create plugin
    loader = vars_loader
    path = "/tmp/"
    stage = 'inventory'
    entities = Host(name="127.0.0.1")
    vars_plugin_list = list(vars_loader.all())
    # add plugin to folder and create plugin class
    plugin_name = 'test_get_vars_from_path'
    plugin_path = os.path.join(os.path.dirname(__file__), plugin_name + '.py')
    file = open(plugin_path, "w")

# Generated at 2022-06-23 15:15:28.018536
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    import ansible.plugins.vars.foo_vars
    loader = vars_loader

    plugin = ansible.plugins.vars.foo_vars.VarsModule()
    plugin_name = 'foo_vars'

    path = '../../lib/ansible/plugins/vars'
    entities = []

    assert get_plugin_vars(loader, plugin, path, entities) == {plugin_name: "bar"}

# Generated at 2022-06-23 15:15:28.566809
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    pass

# Generated at 2022-06-23 15:15:34.561921
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.host import Host
    loader = None
    temp_host = Host("localhost")
    temp_group = "all"
    temp_path = "/etc/ansible/"
    temp_entities = [temp_host, temp_group]
    data = get_vars_from_path(loader, temp_path, temp_entities, 'inventory')
    assert(data == {})



# Generated at 2022-06-23 15:15:44.117253
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    class Plugin(object):
        _load_name = 'test_get_plugin_vars'

        def __init__(self, plugin_name):
            self._name = plugin_name

        def get_vars(self, loader, path, entities):
            return {self._name: path}

        def get_group_vars(self, host):
            return {self._name: 'group_vars'}

        def get_host_vars(self, host):
            return {self._name: 'host_vars'}

    assert get_plugin_vars(None, Plugin('get_vars'), '/tmp', []) == {'test_get_plugin_vars': '/tmp'}
    assert get_plugin_vars(None, Plugin('get_host_vars'), '/tmp', [Host('testing')])

# Generated at 2022-06-23 15:15:52.784272
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # test inventory plugin in lib/ansible/plugins/inventory
    loader = None
    vars_plugin_list = list(vars_loader.all())
    for plugin in vars_plugin_list:
        if plugin._load_name not in C.VARIABLE_PLUGINS_ENABLED and getattr(plugin, 'REQUIRES_WHITELIST', False):
            # 2.x plugins shipped with ansible should require whitelisting, older or non shipped should load automatically
            continue
        data = get_plugin_vars(loader, plugin, "./", [])
        assert data=={}, "data should be empty"

if __name__ == "__main__":
    test_get_vars_from_path()

# Generated at 2022-06-23 15:16:00.011433
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='tests/inventory_vars_plugin')
    host = inventory.get_host('test_host')
    get_vars_from_inventory_sources(loader=loader, sources='tests/inventory_vars_plugin', entities=[host], stage='task')

# Generated at 2022-06-23 15:16:05.755475
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.loader import vars_loader
    from ansible.plugins.vars.foo import VarsModule as foo
    from ansible.plugins.vars.bar import VarsModule as bar
    from ansible.inventory.host import Host

    class FakeLoader(object):
        def __init__(self, path=None):
            self._path = path
    path = "/path/to/fake/dir"
    loader = FakeLoader(path)
    plugin = foo()
    entities = [Host(name="hostname")]

    data = get_plugin_vars(loader, plugin, path, entities)
    assert data['foo_path'] == path
    assert data['foo_name'] == "foo"
    assert data['foo_host_name'] == "hostname"

    plugin = bar()
    data = get

# Generated at 2022-06-23 15:16:15.539787
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    display = Display()
    display.verbosity = True

    # load test inventory file
    loader = C.get_config_loader()
    path = os.path.join(C.DEFAULT_LOCAL_TMP, 'test-get-vars.yml')
    display.display("Generating test inventory: {}".format(path))
    with open(path, 'w') as f:
        f.write("""
all:
  hosts:
    test:
      ansible_host: 127.0.0.1
""")

    # get vars from test inventory file
    sources = [path]
    entities = ['test']
    stage = 'inventory'
    data = {}
    data = combine_vars(data, get_vars_from_inventory_sources(loader, sources, entities, stage))

# Generated at 2022-06-23 15:16:24.550151
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    sources = ['./roles/test_role/inventory/test_inventory']

    from ansible.plugins.loader import vars_loader
    loader = vars_loader
    data = {}
    for path in sources:
        if path is None:
            continue
        if ',' in path and not os.path.exists(path):  # skip host lists
            continue
        elif not os.path.isdir(to_bytes(path)):
            # always pass the directory of the inventory source file
            path = os.path.dirname(path)

        data = combine_vars(data, get_vars_from_path(loader, path, 'all', 'all'))


if __name__ == '__main__':
    test_get_vars_from_inventory_sources()

# Generated at 2022-06-23 15:16:32.432471
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Create a fake set of vars plugins.
    fake_plugin = type('FakePlugin', (object,), {
        '_load_name': 'fake_plugin',
        'get_vars': lambda s, l, p, e: {'fake_variable': 'fake_value'},
    })
    vars_loader._all_plugins = {fake_plugin.__name__: fake_plugin}
    assert get_vars_from_path(None, None, (), 'start') == {'fake_variable': 'fake_value'}

# Generated at 2022-06-23 15:16:32.988495
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    pass

# Generated at 2022-06-23 15:16:41.090615
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    test_host = Host('testhost')
    test_group = Group('testgroup')

    fake_plugin_list = []

    data = get_vars_from_path(fake_plugin_list, None, [test_host], 'inventory')
    assert data == {}

    # Should not raise
    data = get_vars_from_path(fake_plugin_list, None, [test_group], 'inventory')

# Generated at 2022-06-23 15:16:41.771289
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    pass

# Generated at 2022-06-23 15:16:46.235727
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    loader = None
    sources = []
    entities = []
    stage = ''
    print(get_vars_from_inventory_sources(loader, sources, entities, stage))

if __name__ == '__main__':
    test_get_vars_from_inventory_sources()

# Generated at 2022-06-23 15:16:50.045768
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    ansible_capacity_vars_path = 'lib/ansible/plugins/vars/capacity.py'
    ansible_capacity_vars = vars_loader.get(ansible_capacity_vars_path)

    assert isinstance(get_plugin_vars(ansible_capacity_vars, ansible_capacity_vars, '/tmp'), dict)
    assert get_plugin_vars(ansible_capacity_vars, ansible_capacity_vars, '/tmp') == {}

# Generated at 2022-06-23 15:16:58.833370
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    class FakeLoader:
        _basedir = ''

    class FakePlugin:
        class FakeResult:
            def __init__(self, data):
                self.data = data

            def get_vars(self, loader, path, entities):
                return self.data

        def __init__(self, data):
            self.fake_result = FakePlugin.FakeResult(data)

        def get_vars(self, loader, path, entities):
            return self.fake_result.get_vars(loader, path, entities)

    class FakeHost:
        def __init__(self, name):
            self.name = name

    loader = FakeLoader()

    def data_from_path(path):
        return {'path': path}


# Generated at 2022-06-23 15:17:06.935514
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    class Plugin:
        def get_vars(self, data, entities):
            return {'a': 1, 'b': 2}
    assert get_plugin_vars(None, Plugin(), None, []) == {'a': 1, 'b': 2}

    class Plugin:
        def get_host_vars(self, data):
            return {'a': 1}
        def get_group_vars(self, data):
            return {'b': 2}
    assert get_plugin_vars(None, Plugin(), None, [Host('host1')]) == {'a': 1}
    assert get_plugin_vars(None, Plugin(), None, []) == {'b': 2}

# Generated at 2022-06-23 15:17:11.221744
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    loader = None
    sources = ['nonexistent']
    entities = ['nonexistent']
    stage = 'inventory'

    vars_loaded = get_vars_from_inventory_sources(loader, sources, entities, stage)
    assert not vars_loaded

# Generated at 2022-06-23 15:17:14.573951
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    C.VARIABLE_PLUGINS_ENABLED = ['host_group_vars']
    loader = None
    path = '~/.ansible/plugins/vars'
    entities = []
    stage = 'inventory'
    data = get_vars_from_path(loader, path, entities, stage)
    assert data == {}, 'data is not empty'


# Generated at 2022-06-23 15:17:15.152345
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    pass

# Generated at 2022-06-23 15:17:17.661599
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert get_vars_from_path(None, './examples', [], 'task')

# Generated at 2022-06-23 15:17:20.242436
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    loader = None
    plugin = None
    path = None
    entity = None
    # Test to check if function is returning the valid result or not
    assert isinstance(get_plugin_vars(loader, plugin, path, entity), dict)

# Generated at 2022-06-23 15:17:24.993864
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    from ansible.plugins.loader import vars_loader

    vars_loader._create_directory_tree_if_need()

    display.verbosity = 0
    vars_loader.add_directory(os.path.join(os.path.dirname(__file__), 'vars_plugins'))

    assert get_vars_from_path(None, os.getcwd(), None, None) == {"vars_from_path": "completed"}

# Generated at 2022-06-23 15:17:28.866278
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    loader = None
    path   = '.'
    entities = []
    stage = 'run'
    data = get_vars_from_path(loader, path, entities, stage)
    assert isinstance(data, dict)

# Generated at 2022-06-23 15:17:40.207242
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.hostvars import VariableManager
    from ansible.vars.manager import VariableManager
    import ansible.parsing.dataloader

    loader = ansible.parsing.dataloader.DataLoader()
    variable_manager = VariableManager(loader=loader)
    inventory_path = ["/ansible/tests/data/inventory/multivar/vars_plugins"]
    path_vars = get_vars_from_path(variable_manager, "/ansible/tests/data/inventory/multivar/", inventory_path, "inventory")
    assert isinstance(path_vars, dict)
    assert isinstance(path_vars["var1"], AnsibleUnsafeText)


# Generated at 2022-06-23 15:17:50.895320
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars
    from ansible.vars.manager import VariableManager

    # Setup inventory and sources
    hosts = ["host1", "host2", "host3", "host4", "host5"]
    group1_hosts = hosts[:2]
    group2_hosts = hosts[2:]

    i = InventoryManager()
    i.add_host("host1")
    i.add_host("host2")
    i.add_host("host3")
    i.add_host("host4")
    i.add_host("host5")
    i.add_group("group1")
    i.add_group("group2")
    i.add_child("group1", "host1")
    i.add

# Generated at 2022-06-23 15:17:59.894059
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    class MockPlugin(object):
        def __init__(self, name):
            self._load_name = name
            self._original_path = ''
            self._collection_name = ''

        def get_vars(self, loader, path, entities):
            return {name: 'get_vars'}

        def get_group_vars(self, group_name):
            return {group_name: 'get_group_vars'}

        def get_host_vars(self, host_name):
            return {host_name: 'get_host_vars'}

    loader = object()
    plugin = MockPlugin('plugin')
    entities = [object()]
    path = 'path'
    data = get_plugin_vars(loader, plugin, path, entities)

# Generated at 2022-06-23 15:18:01.853116
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    assert get_vars_from_inventory_sources(None, [], [], 'inventory')['first'] == 'foo'

# Generated at 2022-06-23 15:18:11.350499
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    # If is not present any plugin, get_plugin_vars function return an empty dictionary
    loader, plugin, path, entities = None, None, None, None
    assert get_plugin_vars(loader, plugin, path, entities) == {}

    # Case 1:
    # plugins: test1

    # If there is one plugin and the function get_vars is present, the function get_plugin_vars return the value
    # returned by get_vars function
    loader, plugin, path, entities = None, None, None, None
    assert get_plugin_vars(loader, test1_plugin, path, entities) == \
           test1_plugin.get_vars(loader, path, entities)

    # Case 2:
    # plugins: test2

    # If there is one plugin and the function get_host_vars and get

# Generated at 2022-06-23 15:18:12.069232
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    raise NotImplementedError()


# Generated at 2022-06-23 15:18:18.419290
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    test_data = {'k1': 'v1', 'k2': 2, 'k3': True, 'k4': {'k5': 'v5'}, 'k6': [1, 2, 3]}
    class TestPlugin:
        def get_vars(self, loader, path, entities):
            return test_data
    loader = None
    plugin = TestPlugin()
    path = None
    entities = []
    result = get_plugin_vars(loader, plugin, path, entities)
    assert result == test_data

# Generated at 2022-06-23 15:18:19.792344
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    assert True

# Generated at 2022-06-23 15:18:23.110375
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    loader = None
    path = None
    entities = None
    stage = None
    data = get_vars_from_path(loader, path, entities, stage)

    assert isinstance(data, dict)

# Generated at 2022-06-23 15:18:25.407620
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    result = get_vars_from_path(None, '/tmp/hello/world', None, None)
    assert result == {}

# Generated at 2022-06-23 15:18:28.442602
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    display.verbosity = 0
    assert get_vars_from_path(None, '/etc/ansible', [], 'inventory') is not None

# Generated at 2022-06-23 15:18:37.809735
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.vars import core

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    path = os.path.join(C.DEFAULT_LOCAL_TMP, 'test_vars_path')
    if not os.path.exists(path):
        os.makedirs(path)

    fd = open(os.path.join(path, 'vars.yml'), 'w')
    fd.write("vars:\n  test: test\n")
    fd.close()

    plugin

# Generated at 2022-06-23 15:18:44.698796
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import children
    from ansible.inventory.host import Host
    loader = vars_loader
    plugin = loader.get("children")
    hosts = [ Host("host1") ]
    path = "../ansible_collections/ansible/netcommon/plugins/vars"
    data = get_plugin_vars(loader, plugin, path, hosts)
    assert data.get("mc_dense_ips_conf")

# Generated at 2022-06-23 15:18:48.556395
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    loader = None
    plugin = None
    path = None
    entities = None
    assert get_plugin_vars(loader, plugin, path, entities) == {}

# Generated at 2022-06-23 15:18:59.441458
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    mock_inventory = [
        'host1 ansible_host=host1.example.org',
        'host2 ansible_host=host2.example.org',
        'host3 ansible_host=host31.example.org',
        '[group1]',
        'host1',
        'host2',
        '[group2]',
        'host2',
        'host3',
        '[group3:children]',
        'group1',
        'group2',
        ]

    loader = DictDataLoader({
        'my_inventory_file': '\n'.join(mock_inventory)
    })

    display.verbosity = 4

    class my_plugin(object):

        _load_name = "my_plugin"

        def get_vars(self, loader, path, entities):
            return

# Generated at 2022-06-23 15:19:03.953739
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    import ansible.plugins.loader as ploader
    vars_loader = ploader.vars_loader

    class Plugin:
        def get_vars(self, loader, path, entities):
            return {
                'a': 'b',
            }

    vars_loader.add(Plugin(), 'test_plugin')

    data = get_vars_from_path(loader, 'path', ['one', 'two', 'three'], 'test_stage')
    assert data == {
        'a': 'b',
    }

# Generated at 2022-06-23 15:19:16.147532
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    import ansible.plugins.loader as plugin_loader

    test_plugin_name = 'test_plugin.py'
    test_plugin_path = 'lib/ansible/plugins/vars/' + test_plugin_name
    test_plugin_fq_path = os.path.join(os.path.dirname(__file__), '..', test_plugin_path)

    vars_loader = plugin_loader.vars_loader
    # Load the test plugin
    vars_loader._get_all_plugin_loaders(C.AUTOMATIC_VARS_PLUGIN_PATHS)

    entities = []
    entity1 = Host("host1")
    entities.append(entity1)
    entity2 = Host("host2")
    entities.append(entity2)
