

# Generated at 2022-06-23 15:09:25.526632
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    sources = ['vars_plugins/inventory_plugins/test_vars_plugin.yml']
    items = ['group1']
    stage = 'inventory'
    display.verbosity = 3
    print("get_vars_from_inventory_sources(sources={0}, entities={1}, stage={2})".format(sources, items, stage))
    print("  returned: {0}".format(get_vars_from_inventory_sources({'sources': sources, 'sources_data': []}, sources, items, stage)))


# Generated at 2022-06-23 15:09:37.803465
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    from ansible.parsing.vault import VaultLib
    from ansible.plugins.vars.vault import VaultVars

    vault_password = "Password"
    vault = VaultLib(
        password=vault_password,
        random_salt_length=10,
        kdf=None,
        kdf_args=None
    )

    vault_vars = VaultVars(None)
    vault_vars.vault = vault

    data = {'private': {'foo': 'bar'}, 'public': {'foo': 'baz'}}

    # test no vault
    assert get_plugin_vars(None, vault_vars, '', []) == {}

    # test no password
    vault_vars.vault.encrypt(data)

# Generated at 2022-06-23 15:09:49.527868
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    class MockCollection:

        def __init__(self, _load_name, has_option, get_option, has_plugin):
            self._load_name = _load_name
            self.has_option = has_option
            self.get_option = get_option

        def get_vars(self, loader, path, entities):
            if self._load_name == 'pass_one':
                return {'pass_one': 'pass_one'}
            else:
                return {'pass_two': 'pass_two'}

    loader = Mock()
    loader.all = lambda: [MockCollection('pass_one', lambda a: True, lambda a: None, lambda a: True), MockCollection('pass_two', lambda a: True, lambda a: 'all', lambda a: True)]
    loader.get = load_name

# Generated at 2022-06-23 15:09:52.577687
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    assert get_vars_from_inventory_sources(None, ["path1", "path2"], [], "task") is not None
    assert get_vars_from_inventory_sources(None, ["path,1", "path2"], [], "task") is not None
    assert get_vars_from_inventory_sources(None, [None, "path2"], [], "task") is not None

# Generated at 2022-06-23 15:09:53.110709
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    # TODO
    pass



# Generated at 2022-06-23 15:09:59.656389
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins import vars_plugins
    from ansible.parsing.dataloader import DataLoader

    test_plugin = vars_plugins.TestVarPlugin()
    loader = DataLoader()
    entities = ['test_entity']
    assert get_vars_from_path(loader, 'nonsense', entities, 'task') == {}
    assert get_vars_from_path(loader, 'nonsense', entities, 'task') == {}

# Generated at 2022-06-23 15:10:10.685131
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    # A bit of a fake loader object.
    class TestLoader(object):
        def __init__(self, inventory):
            self.inventory = inventory
            self.vars_plugins = ['testplugin']


    # Fake inventory object.
    class TestInventory(object):

        def __init__(self, sources):
            self.sources = sources

    # A fake inventory source.
    class TestSource(object):
        def __init__(self, name, config):
            self.name = name
            self.config = config

        def get_hosts(self, pattern='all', ignore_restriction=False):
            if self.name == 'nothostlist':
                return [Host(name='thehost')]
            else:
                return []


# Generated at 2022-06-23 15:10:11.335257
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    None

# Generated at 2022-06-23 15:10:20.421440
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    # for this test, we don't care about the Inventory vs. Playbook files,
    # nor the group/host specifiers
    def _get_vars_for_inventory_path(path):
        data = get_vars_from_inventory_sources(
            loader,
            [path],
            [],
            stage='inventory',
        )
        return data

    # for this test, we don't care about the Inventory vs. Playbook files,
    # nor the group/host specifiers
    def _get_vars_for_task_path(path):
        data = get_vars_from_inventory_sources(
            loader,
            [path],
            [],
            stage='task',
        )
        return data

    # pretend we are loading this file as a plugin
    path = os.path.dirname

# Generated at 2022-06-23 15:10:21.049794
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    pass

# Generated at 2022-06-23 15:10:23.980435
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    assert get_vars_from_inventory_sources('test', ['test'], 'entities', 'stage') == 'test'

# Generated at 2022-06-23 15:10:29.960326
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    # Set up mock objects
    mock_host = Host('mockhost')
    mock_inv_source = 'mocksource'

    # Call function with mock arguments
    from ansible.plugins.loader.vars_plugins import get_vars_from_inventory_sources
    get_vars_from_inventory_sources('loader', mock_inv_source, mock_host, 'start')

# Generated at 2022-06-23 15:10:39.704522
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.vars import AnsibleVars
    loader = AnsibleVars()
    class Foo:
        _load_name = 'foo'
        def __init__(self, loader, path, entities):
            # add values to the instance, so they are returned by get_plugin_vars
            self.x = 1
            self.y = 2
        def __repr__(self):
            return "Foo"
    class Bar:
        _load_name = 'bar'
        def __init__(self, loader, path, entities):
            self.z = 1
        def __repr__(self):
            return "Bar"

# Generated at 2022-06-23 15:10:45.982020
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    basedir = os.path.dirname(__file__)
    # TODO: use portion of integration test inventory?
    source = [os.path.join(basedir, 'data', 'test_inventory_source')]
    loader = None
    entities = []
    stage = ''
    vars = get_vars_from_inventory_sources(loader, source, entities, stage)
    assert vars

# Generated at 2022-06-23 15:10:48.330503
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert isinstance(get_vars_from_path(None, None, None, None), dict)

# Generated at 2022-06-23 15:10:51.111048
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    loader = None
    sources = []
    entities = []
    data = get_vars_from_path(loader, sources, entities, 'inventory')
    assert data == {}


# Generated at 2022-06-23 15:11:00.365002
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    class PluginVars:

        def get_vars(self, loader, path, entities):
            return {'a': 1}

    loader = None
    plugin = PluginVars()
    path = './'
    entities = []
    data = get_plugin_vars(loader, plugin, path, entities)
    assert data['a'] is 1, \
        'get_plugin_vars() should return key a = 1 but returns %s' % data

    class PluginVars:

        def get_host_vars(self, name):
            return {'a': 1}

    loader = None
    plugin = PluginVars()
    path = './'
    entities = []
    data = get_plugin_vars(loader, plugin, path, entities)

# Generated at 2022-06-23 15:11:00.931612
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert 0

# Generated at 2022-06-23 15:11:01.704700
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    pass

# Generated at 2022-06-23 15:11:05.984824
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    try:
        import ansible_collections.ansible.test_collection.plugins.modules.test_data_loader  # noqa
        import ansible_collections.ansible.test_collection.plugins.vars.test_data_loader  # noqa
    except Exception:
        pytest.skip("cannot import test_data_loader plugins, this test will fail")

    from ansible.inventory.manager import InventoryManager

    inventory = InventoryManager(loader=None, sources='localhost,')
    loader = inventory._loader
    plugin = loader.vars_plugins['test_data_loader']

    test_data = get_plugin_vars(loader, plugin, '.', inventory.hosts)

    assert 'file_name' in test_data
    assert test_data['file_name'] == 'inventory_vars.yml'

# Generated at 2022-06-23 15:11:14.480438
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    from ansible.inventory.manager import InventoryManager

    sources = [u'/usr/share/ansible/collections/ansible_collections/foobar/tests/integration/targets/hosts']
    loader = InventoryManager(sources=sources)
    host = Host(name=u'host-a')
    host_data = get_vars_from_inventory_sources(loader, sources, [host], stage='inventory')
    assert host_data == {u'ansible_host': u'host-a',
                         u'foo': u'bar',
                         u'inventory_hostname': u'host-a'}

    group = loader.groups[u'group-a']
    group_data = get_vars_from_inventory_sources(loader, sources, [group], stage='inventory')
    assert group

# Generated at 2022-06-23 15:11:24.547329
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    loader = {}
    loader['_basedir'] = '.'
    sources = ['inventories/inventory_1/hosts', 'inventories/inventory_2/hosts']
    entities = [Host('host1'), Host('host2'), Host('host3'), Host('host4')]
    stage = 'inventory'

    vars = get_vars_from_inventory_sources(loader, sources, entities, stage)
    print ("Global vars = " + str(vars))
    assert vars['inventory_path'] == 'inventories/inventory_1'
    assert vars['inventory_dirname'] == 'inventories/inventory_1'
    assert vars['inventory_filename'] == 'hosts'

# Generated at 2022-06-23 15:11:25.421492
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    # Pending
    pass



# Generated at 2022-06-23 15:11:38.222703
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from .vars_plugin import VarsModule

    loader = vars_loader
    path = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
    entities = ["fake1", "fake2"]
    stage = "task"

    # setup a vars plugin to test
    plugin = VarsModule('vars_plugin_test', '', "", "", "", "", "", "", "", "", "", "", "")
    plugin.get_vars = lambda *args: {plugin._load_name: True}

    # add plugin to loader
    loader.add(plugin)
    assert plugin in vars_loader.all()

    # retrieve vars from loader as would be done by ansible run

# Generated at 2022-06-23 15:11:47.599745
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    # TODO:
    # I would like to put this into a common place such as 'unit/utils/'
    # but it seems doesn't work on 'python setup.py test'

    from ansible import context
    from ansible.plugins.vars.host_group_vars import VarsModule as VarsModuleHostGroupVars
    from ansible.plugins.vars.host_vars import VarsModule as VarsModuleHostVars
    from ansible.plugins.vars.yaml import VarsModule as VarsModuleYaml
    from ansible.plugins.loader import vars_loader

    # AnsibleContext must be initialized
    context.CLIARGS = {}
    # context.CLIARGS['vars_plugins'] = ['ansible.plugins.vars.yaml']

# Generated at 2022-06-23 15:11:50.232265
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    loader = None
    path = None
    entities = None
    stage = 'inventory'

    data = get_vars_from_path(loader, path, entities, stage)
    assert isinstance(data, dict)

# Generated at 2022-06-23 15:11:58.288411
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.plugins.vars import vars as vars_module
    from ansible.utils.display import Display

    test_path = 'tests/unit/plugins/vars_plugins/vars_func_test'
    test_entities = [
        Host('test_host_1'),
        Host('test_host_2'),
        Host('test_host_3'),
        Host('test_host_4'),
    ]

    # Load test vars plugin
    vars_plugin_test = vars_module.VarsModule()

    # Add test vars plugin to vars loader
    vars_loader.add({'vars_test': vars_plugin_test})

    # Save original display
    orig_display = display
    display = Display()

   

# Generated at 2022-06-23 15:12:08.578032
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    i = Inventory(loader=loader, variable_manager=None, host_list=["/dev/null"])
    assert not get_vars_from_inventory_sources(loader, [], [], 'inventory')
    assert not get_vars_from_inventory_sources(loader, [None], [], 'inventory')
    assert len(get_vars_from_inventory_sources(loader, ['/dev/null'], [], 'inventory')) > 0
    assert not get_vars_from_inventory_sources(loader, ['/dev/null'], [], 'task')

# Generated at 2022-06-23 15:12:14.027611
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import test_plugin
    loader = vars_loader.VarsModuleLoader()
    test_plugin = test_plugin.VarsModule()
    result = get_plugin_vars(loader, test_plugin, 'path', ['entity'])
    assert result == {'test_plugin': 'this_is_a_test'}

# Generated at 2022-06-23 15:12:21.375865
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    d = get_vars_from_inventory_sources(None, ["/tmp/foo/bar",
                                               "/tmp/foo/spam"],
                                        ['server1', 'server2'],
                                        'task')
    assert d == {}

    d = get_vars_from_inventory_sources(None, ["/tmp/foo/bar",
                                               "/tmp/foo/spam"],
                                        ['server1', 'server2'],
                                        'inventory')
    assert d == {}

# Generated at 2022-06-23 15:12:31.761202
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    import mock

    path = os.path.abspath(os.path.join(os.path.dirname(__file__), '../../inventory'))
    sources = [os.path.join(path, 'test_inventory.yaml')]

    with mock.patch('ansible.inventory.vars_plugins.get_vars_from_path') as m_gvfp:
        with mock.patch('ansible.inventory.vars_plugins.combine_vars') as m_cv:
            results = get_vars_from_inventory_sources(mock.MagicMock(), sources, mock.MagicMock(), 'inventory')

            assert results == m_cv.return_value
            assert m_gvfp.called_with(mock.ANY, path, mock.ANY)

# Generated at 2022-06-23 15:12:35.585619
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    # Make sure we get an empty data when no vars plugin is loaded
    assert isinstance(get_plugin_vars(None, None, None, []), dict)
    assert get_plugin_vars(None, None, None, []) == {}

# Generated at 2022-06-23 15:12:37.260899
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    assert get_vars_from_inventory_sources(None, [''], None, None) == {}

# Generated at 2022-06-23 15:12:44.428100
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.module_utils._text import to_native
    from ansible.parsing.vault import VaultLib

    groups = ['all', 'ungrouped']
    loader = DictDataLoader({})
    all_vars = {}
    inventory = Inventory(loader)

    v = VaultLib([])
    loader._vault = v
    loader.set_vault_secrets(path='test/test.yml')
    v.decrypt(to_bytes(loader.get_vault_secrets()))

    # Test inventory v1 plugin

# Generated at 2022-06-23 15:12:53.915378
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    ''' Run a few variations of the function to test it '''
    vars_paths = {
        '/': {
            'test.yml': 'testdata'
        },
        'testdata': {
            'test': {
                'test.yml': 'testdata'
            }
        },
        'testdata/test': {
            'test': {
                'test.yml': 'testdata'
            }
        },
        'testdata/test/test': {
            'test': {
                'test.yml': 'testdata'
            }
        }
    }

    for vars_path in vars_paths:
        try:
            os.makedirs(vars_path)
        except OSError:
            pass


# Generated at 2022-06-23 15:13:05.951770
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    # Remove constants
    c_run_vars_plugins = C.RUN_VARS_PLUGINS
    c_variable_plugins_enabled = C.VARIABLE_PLUGINS_ENABLED
    C.RUN_VARIABLE_PLUGINS = 'start'
    C.VARIABLE_PLUGINS_ENABLED = []

    # create mock loader, plugin, entities
    loader = [1, 2, 3]
    plugin = [1, 2, 3]
    entities = [1, 2, 3]
    sources = ['/some/path']

    # configure plugin
    plugin.get_vars = lambda *args: {'key': 'value'}
    plugin.has_option = lambda *args: True
    plugin.get_option = lambda *args: None
    plugin._load_name

# Generated at 2022-06-23 15:13:16.749231
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.config.loader import ConfigLoader


# Generated at 2022-06-23 15:13:22.027337
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    class TestVarsPlugin:
        def get_vars(self, loader, path, entities):
            return {'foo': 'bar'}

    loader = None
    plugin = TestVarsPlugin()
    path = None
    entity = Host('localhost')
    entities = [entity]
    data = get_plugin_vars(loader, plugin, path, entities)
    assert data.get('foo') == 'bar'

# Generated at 2022-06-23 15:13:34.244696
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    from ansible.inventory.manager import InventoryManager

    sources = ['/tmp/test','/tmp/test/subdir']
    entities = [InventoryManager(loader=None, sources=sources).inventory.get_host('localhost')]
    stage = 'not-known'


# Generated at 2022-06-23 15:13:42.330243
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    groups = {
        'group1': [
            'dummy-host1-one',
            'dummy-host1-two',
        ],
        'group2': [
            'dummy-host2-one',
            'dummy-host2-two',
        ],
    }

    inventory_sources = [
        './test_get_vars_from_inventory_sources__inventory_sources_1',
        './test_get_vars_from_inventory_sources__inventory_sources_2'
    ]


# Generated at 2022-06-23 15:13:51.945573
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    loader = None
    data = {}
    sources = []
    entities = []
    stage = 'inventory'
    assert get_vars_from_inventory_sources(loader, sources, entities, stage) == data

    loader = None
    data = {}
    sources = ['test']
    entities = []
    stage = 'inventory'
    assert get_vars_from_inventory_sources(loader, sources, entities, stage) == data

    loader = None
    data = {}
    sources = ['test1', 'test2']
    entities = []
    stage = 'inventory'
    assert get_vars_from_inventory_sources(loader, sources, entities, stage) == data

# Generated at 2022-06-23 15:14:00.000659
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    """Test the function"""
    # Returns vars, so we can directly test the data
    return get_vars_from_inventory_sources(None,
                                           ['test/unit/vars_plugins'],
                                           ['test/unit/vars_plugins/inventory1.yml'],
                                           None)

if __name__ == "__main__":
    print(test_get_vars_from_inventory_sources())

# Generated at 2022-06-23 15:14:09.568598
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    class FakeVars(object):

        def __init__(self, name):
            self._load_name = name
            self.vars = {
                'foo': 1,
                'bar': 2
            }

        def get_vars(self, loader, path, entities):
            return self.vars

        def get_group_vars(self, group):
            return {
                'bar_group': 1,
                'foo_group': 2
            }

        def get_host_vars(self, host):
            return {
                'bar_host': 1,
                'foo_host': 2
            }

    loader = object()
    plugin = FakeVars('test_plugin')

    class FakeInventory(object):

        def __init__(self, vars):
            self.vars = vars

# Generated at 2022-06-23 15:14:10.224118
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    pass

# Generated at 2022-06-23 15:14:19.365278
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    import tempfile
    import shutil
    import filecmp
    import textwrap

    vars_plugins_temp_dirs = []

    def create_vars_plugin(path, name, plugin_type=None):
        plugin_temp_dir = tempfile.mkdtemp()
        vars_plugins_temp_dirs.append(plugin_temp_dir)
        vars_plugin_name = '_'.join(name.split()) + '.py'
        vars_plugin_file = os.path.join(path, vars_plugin_name)


# Generated at 2022-06-23 15:14:25.822515
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.utils.vars import combine_vars

    test_host = Host('example')
    test_host.vars = {}
    test_host.set_variable("var_y", "value_y")
    test_group = Group('group')
    test_group.vars = {}
    test_group.set_variable("var_z", "value_z")

    test_empty_plugin = lambda : None
    test_empty_plugin.get_vars = lambda x: {}
    assert get_plugin_vars(None, test_empty_plugin, None, [test_host]) == {}

    test_host_vars = lambda : None

# Generated at 2022-06-23 15:14:27.959101
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    assert get_vars_from_inventory_sources(None, ['.', './inventory'], [], 'task') == {}

# Generated at 2022-06-23 15:14:36.253972
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.loader import variable_manager

    class MockLoader:
        all = variable_manager.all

    class MockVars:
        def run(self, loader, host):
            return "Hello"
        def get_option(self, key):
            return None

    class MockVars2:
        def get_vars(self, loader, path, entities):
            return 'World'

    result1 = get_plugin_vars(MockLoader(), MockVars(), '/path', ['entities'])
    assert result1 == {}
    result2 = get_plugin_vars(MockLoader(), MockVars2(), '/path', ['entities'])
    assert result2 == 'World'

# Generated at 2022-06-23 15:14:48.404352
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    #
    # Import test plugin
    #

    import sys
    current_path = os.path.dirname(os.path.abspath(__file__))
    plugin_dir = os.path.join(current_path, '../plugins/test_vars_loader')
    sys.path.append(plugin_dir)
    from test_plugin import VarsModule

    #
    # Setup
    #

    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    im = InventoryManager(loader=loader, sources=['hosts'])
    host = im.get_host('127.0.0.1')
    path = plugin_dir

    #
    # Define vars plugin list
    #

    vars_plugin

# Generated at 2022-06-23 15:14:49.024827
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    pass

# Generated at 2022-06-23 15:14:49.335628
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    assert False

# Generated at 2022-06-23 15:14:55.996845
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    plugin_name = 'test_vars'
    test_data = {'test_key1': 'test_value1', 'test_key2': 'test_value2'}

    class TestPlugin:

        def __init__(self, load_name):
            self._load_name = load_name

        def get_vars(self, loader, path, entities):
            return test_data

    for plugin_enable in [plugin_name, [plugin_name], ['test_vars1', plugin_name, 'test_vars2']]:
        with loader.load_single_plugin(vars_loader, 'vars', plugin_name, '', disable_extensions=True, plugin_enable=plugin_enable):
            plugin = vars_loader.get(plugin_name)

# Generated at 2022-06-23 15:14:56.636244
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    return None

# Generated at 2022-06-23 15:15:06.317013
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.plugins.loader import vars_loader
    from ansible.utils.display import Display
    from ansible.inventory.loader import InventoryLoader
    from ansible.parsing.dataloader import DataLoader

    display = Display()
    loader = DataLoader()
    inv_loader = InventoryLoader(loader, sources=['/tmp/dynamic_inventory'])
    inv = inv_loader.get_inventory()

    # vars_loader.all() returns generator object
    vars = get_vars_from_inventory_sources(loader, ['/tmp/dynamic_inventory'],
                                           entities=inv.get_hosts(), stage='inventory')

    assert isinstance(vars, dict)

    # FIXME: vars_loader.all() returns generator and you can't get len of it.
    # for

# Generated at 2022-06-23 15:15:18.033740
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    # Test old style vars plugin
    class OldVarsPlugin:
        def __init__(self):
            self._load_name = 'old_vars_plugin'
            self._original_path = '/path/to/old_vars_plugin'

        def get_host_vars(self, host):
            return {'test': 'old'}

    assert get_plugin_vars(None, OldVarsPlugin(), None, [Host('test')]) == {'test': 'old'}

    # Test v2 style vars plugin
    class NewVarsPlugin:
        def __init__(self):
            self._load_name = 'new_vars_plugin'
            self._original_path = '/path/to/new_vars_plugin'
            self.REQUIRES_WHITELIST = False



# Generated at 2022-06-23 15:15:28.883866
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    class FakePlugin:
        def get_group_vars(self, group):
            return {'group_' + group: True}
        def get_host_vars(self, host):
            return {'host_' + host: True}
        def get_vars(self, loader, path, entities):
            return {'path_' + path: True}
        def run(self):
            pass
    plugin = FakePlugin()
    loader = FakePlugin()
    plugin._load_name = 'fake'
    plugin._original_path = 'fake'
    vars_plugin_list = list(vars_loader.all())
    vars_plugin_list[0] = plugin

# Generated at 2022-06-23 15:15:39.527578
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from collections import namedtuple
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader

    AnsibleOptions = namedtuple('AnsibleOptions', 'connection remote_user private_key_file host_key_checking become become_method become_user')
    options = AnsibleOptions(connection='local', remote_user='admin', private_key_file=None, host_key_checking=False, become=False, become_method=None, become_user=None)
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory_with_vars_plugins'])
    inventory.subset('plugin')
    host = inventory.get_host(Host('plugin'))
    vars = get_

# Generated at 2022-06-23 15:15:40.141529
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    data = {}

# Generated at 2022-06-23 15:15:48.089270
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    # create a temp directory for testing
    import tempfile
    testdir = tempfile.mkdtemp()
    os.mkdir(os.path.join(testdir, 'group_vars'))
    os.mkdir(os.path.join(testdir, 'host_vars'))

    # create a test empty inventory file
    with open(os.path.join(testdir, 'inventory'), "w") as f:
        f.write("""
    [testgroup]
    host1
    host2

    [testgroup:vars]
    test_inventory_var=foo
    test_inventory_var2=bar

    [testgroup2]
    host2
    """)

    # create some host_vars

# Generated at 2022-06-23 15:15:50.155674
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    loader = None
    plugin = "Core"
    path = "/"
    entities = ""
    assert get_plugin_vars(loader, plugin, path, entities) is not None

# Generated at 2022-06-23 15:16:02.842227
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader

    # Inventory file with a group 'group1' and the group definition
    # having a single host 'host1'
    inv_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'test/inventory')
    loader = vars_loader.VarsModule()
    # get vars for an inventory directory
    inv_vars = get_vars_from_path(loader, inv_dir, [], "inventory")
    assert inv_vars == {
        'test_plugin_vars_value_inventory': 'test_plugin_vars_value_inventory',
        'test_plugin_vars_value_inventory_all': 'test_plugin_vars_value_inventory_all',
    }

    # get vars

# Generated at 2022-06-23 15:16:13.970289
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    test_name = 'test'
    loader = 'test_loader'
    path = 'test_path'
    entities = 'test_entities'
    data = {}
    data_expected = {'test_plugin': {}}

    class test_get_plugin_vars_class():

        def get_vars(self, loader, path, entities):
            return {'test_plugin': {}}

        def get_host_vars(self, host):
            return {'test_plugin': {}}

        def get_group_vars(self, group):
            return {'test_plugin': {}}

        _load_name = test_name
        _original_path = path

    plugin = test_get_plugin_vars_class()
    assert get_plugin_vars(loader, plugin, path, entities) == data

# Generated at 2022-06-23 15:16:19.209276
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.utils.vars import combine_vars
    from ansible.parsing.vault import VaultLib
    from ansible.utils.vault import VaultEditor
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from collections import namedtuple

    loader = namedtuple('loader', 'get_basedir')(get_basedir=lambda x: os.path.join(os.path.dirname(os.path.realpath(__file__)), 'vars_plugins'))

# Generated at 2022-06-23 15:16:29.977960
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    # path could be a directory or a file, in either case vars should be read from it
    # for a directory, test for a file that quite possibly does not exist
    # for a file, test for its directory even though the file does not exist
    path = 'does_not_exist'
    entities = []
    stage = 'task'

    vars_plugin_list = list(vars_loader.all())
    for plugin_name in C.VARIABLE_PLUGINS_ENABLED:
        if AnsibleCollectionRef.is_valid_fqcr(plugin_name):
            vars_plugin = vars_loader.get(plugin_name)

# Generated at 2022-06-23 15:16:39.059396
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    vars_loader.add_directory(os.path.join(os.path.dirname(__file__), 'vars_plugins'))

    loader = 'fake'
    path = os.path.join(os.path.dirname(__file__))
    entities = ['blah']
    stage = 'inventory'
    data = get_vars_from_path(loader, path, entities, stage)
    assert data == {'plugin_a': 'inv', 'plugin_b': 'inv'}



# Generated at 2022-06-23 15:16:51.024826
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    # FIXME: This is a very incomplete unit test for this function, but at least it catches some regressions
    # and makes sure that some cases don't crash/hang.
    import tempfile
    import shutil
    import random
    import os
    from ansible.module_utils.six.moves import configparser

    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory import Inventory
    from ansible.playbook.play_context import PlayContext

    test_vault_password = 'atestvaultpassword'
    test_vault_id = 'atestvaultid'

    vault_secret = VaultLib([test_vault_password])
    vault_secret_2 = VaultLib([test_vault_password])
    vault

# Generated at 2022-06-23 15:16:51.643587
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    pass

# Generated at 2022-06-23 15:17:03.038569
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    class FakePlugin(object):
        _load_name = 'FakePlugin'

        def get_vars(self, loader, path, entities):
            return {'FakePlugin': True}

        def get_group_vars(self, group):
            return {'FakePlugin': True}

        def get_host_vars(self, host):
            return {'FakePlugin': True}

    class FakeV1Plugin(object):
        _load_name = 'FakeV1Plugin'

        def run(self, inventory, host, vault_password=None):
            return {'FakeV1Plugin': True}

    assert(get_plugin_vars(None, FakePlugin(), None, None) == {'FakePlugin': True})

# Generated at 2022-06-23 15:17:09.949379
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    class VarsPlugin(object):
        def get_vars(self, loader, path, entities):
            return ({'test_plugin_vars': path}, )

    plugin = VarsPlugin()
    loader = object()
    path = '/tmp/path/'
    entities = ['host1']

    data = get_plugin_vars(loader, plugin, path, entities)

    assert data['test_plugin_vars'] == path



# Generated at 2022-06-23 15:17:15.341007
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    from ansible.plugins.loader import vars_loader

    loader = MockLoader()
    sources = ['/path/to/main.yaml']
    entities = [Host('foo')]
    stage = 'inventory'

    mod = get_vars_from_inventory_sources(loader, sources, entities, stage)

    assert len(mod.keys()) == 1
    assert mod['foo'] == 'bar'



# Generated at 2022-06-23 15:17:23.523002
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    # test data
    # mock ansible_constants.C config
    C.RUN_VARS_PLUGINS = "demand"
    C.VARIABLE_PLUGINS_ENABLED = ["here", "there"]
    # mock inventory source paths
    sources = ["/inventory/mock/source/one", "/inventory/mock/source/two", None]
    stage = "inventory"
    # mock hosts and groups
    mock_hosts = [Host('one'), Host('two')]
    mock_groups = [Host('three'), Host('four')]
    entities = mock_hosts + mock_groups
    # mock vars plugin output

# Generated at 2022-06-23 15:17:35.798465
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host, Group

    get_var = vars_loader.get("get_var")
    group_var = vars_loader.get("group_var")

    hosts = ["host1", "host2", "host3"]
    groups = ["group1", "group2", "group3"]
    entities = hosts + groups

    sources = ["/tmp/inventory","/tmp/inventory_hosts.yml","/tmp/inventory_host_group.yml","/tmp/inventory_host_group_host.yml"]

    manager = InventoryManager(loader=None, sources=sources)
    for host in hosts:
        manager.add_host(host)


# Generated at 2022-06-23 15:17:45.376607
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    from ansible.playbook.play_context import PlayContext

    class MockVarsPlugin:
        def get_vars(self, loader, path, entities):
            return {'plugin_vars': True}

        def get_host_vars(self, host):
            return {'host_vars': host}

        def get_group_vars(self, group):
            return {'group_vars': group}

    class MockVarsLoader:
        def __init__(self):
            self.vars_plugins = [
                MockVarsPlugin(),
                MockVarsPlugin(),
                MockVarsPlugin(),
                MockVarsPlugin(),
                MockVarsPlugin(),
                MockVarsPlugin(),
                MockVarsPlugin(),
                MockVarsPlugin(),
                MockVarsPlugin(),
            ]


# Generated at 2022-06-23 15:17:51.160972
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    sources = ['/etc/ansible/hosts']

# Generated at 2022-06-23 15:17:57.725150
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    plugin = {'run': None}
    with pytest.raises(AnsibleError):
        get_plugin_vars('', plugin, '', '')

    plugin = {'get_group_vars': None}
    with pytest.raises(AnsibleError):
        get_plugin_vars('', plugin, '', '')

    plugin = {'get_group_vars': '', 'get_host_vars': ''}
    assert get_plugin_vars('', plugin, '', '') == {}

# Generated at 2022-06-23 15:18:08.280294
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    # vars plugin
    class TestVars(object):
        def __init__(self):
            self.type = 'test'

        def get_vars(self):
            return {'test': 'var', 'test1': 'var1'}

    inventory = '''
        [test_group]
        localhost ansible_connection=local
        localhost2 ansible_connection=local
        '''

    entities = []
    for host in inventory.get_hosts():
        entities.append(host)

    sources = ['test_path']
    stage = 'inventory'
    loader = 'test_loader'

    data = get_vars_from_inventory_sources(loader, sources, entities, stage)
    assert data == {}

    vars_loader.add(TestVars())

    data = get_v

# Generated at 2022-06-23 15:18:16.384683
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    vars_mgr = VariableManager()

    # test a cli.vars_plugins_enabled value which is a list of plugin
    assert get_vars_from_inventory_sources(loader, [], [], '') == {}

if __name__ == '__main__':
    test_get_vars_from_inventory_sources()


# Utility function to get variables from a file that contains host names
# Returns a hash with key hostname and value of hash returned by get_vars_from_file


# Generated at 2022-06-23 15:18:28.638081
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['/etc/ansible/hosts'])

    inventory_dir = os.path.dirname(os.path.dirname(os.path.join(os.path.dirname(__file__), '__init__.py')))
    inventory_dir = os.path.join(inventory_dir, 'inventory')

    hosts = set([h.name for h in inventory.get_hosts()])
    vars_manager = VariableManager(loader=loader, inventory=inventory)

    # no vars should not be in inventory plugin
    data = get_vars_from_inventory_

# Generated at 2022-06-23 15:18:30.779425
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    import ansible.plugins.loader
    inventory = ansible.plugins.loader.vars_loader.all()
    assert inventory == []

# Generated at 2022-06-23 15:18:39.346363
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch
    from ansible.module_utils.six import PY3
    from ansible_collections.ansible.community.plugins.loader import var_precedence

    def get_vars(loader, path, entities, stage):
        var_data = {
            'YAML': {'key1': 'value1', 'key2': 'value2'},
            'JSON': {'key1': 'value1', 'key2': 'value2'},
            'group_vars': {'key1': 'value1', 'key2': 'value2'},
            'host_vars': {'key1': 'value1', 'key2': 'value2'},
        }
        return var_data


# Generated at 2022-06-23 15:18:49.351404
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible_collections.ansible.builtin.plugins.vars import foo
    from ansible.plugins.loader import vars_loader
    vars_loader.add(foo.FooModule)
    loader = vars_loader
    host = Host('foo')
    host.vars = {'foo': 'bar'}
    host_vars = {'ansible_connection': 'docker'}
    group = Host('foos')
    group.vars = {'foo': 'baz'}
    group_vars = {'ansible_connection': 'local'}
    entities = [host, group]
    stage = 'inventory'
    sources = ['/usr/local/ansible/test/test_plugins/test_vars_plugins']

# Generated at 2022-06-23 15:18:55.248901
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    sources = ['/home/myuser/ansible/myinventory']
    hosts = [Host('1.1.1.1'),Host('2.2.2.2')]
    loader = 'loader'
    stage = 'inventory'
    result = get_vars_from_inventory_sources(loader,sources,hosts,stage)


# Generated at 2022-06-23 15:18:57.184875
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # TODO:
    pass


# Generated at 2022-06-23 15:18:59.283361
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    ret = get_vars_from_path("loader","path","entities", "stage")
    assert isinstance(ret, dict)

# Generated at 2022-06-23 15:18:59.864851
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    assert True

# Generated at 2022-06-23 15:19:00.761507
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert get_vars_from_path is not None

# Generated at 2022-06-23 15:19:01.325590
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    assert False

# Generated at 2022-06-23 15:19:02.236783
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    assert 0

# Generated at 2022-06-23 15:19:09.720006
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    # TODO: Expand on the use-cases tested here, the current one is pretty basic.
    # TODO: Expand the tests to include other get_vars_from_path tests as well.
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    class DummyPlugin:
        def __init__(self, name):
            self._load_name = name
        def get_vars(self, loader, path, entities):
            return {self._load_name + '1': True}
        def get_host_vars(self, name):
            return {self._load_name + '2': True}
        def get_group_vars(self, name):
            return {self._load_name + '3': True}

    # Mock the vars_loader to return custom plugins

# Generated at 2022-06-23 15:19:14.273864
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    loader = vars_loader
    paths = ["/Users/jeyadev/Repository/ansible/lib/ansible/plugins/vars"]
    entities = ['localhost']
    stage = 'inventory'
    print(get_vars_from_inventory_sources(loader, paths, entities, stage))

# Generated at 2022-06-23 15:19:19.974874
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars.dir import VarsModule
    from ansible.plugins.loader import vars_loader

    plugin = VarsModule(path='', basedir='./test_vars_plugins')
    vars_loader.add(plugin)
    assert get_plugin_vars(None, plugin, './test_vars_plugins', []) == {'items': [1, 2]}
