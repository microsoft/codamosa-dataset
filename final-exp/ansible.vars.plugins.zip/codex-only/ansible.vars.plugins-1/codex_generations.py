

# Generated at 2022-06-23 15:09:28.572080
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    '''
    These 2 plugins for variables need to be properly mocked for unit testing
    to get_vars_from_path to have any meaning.
    '''
    class PluginV2:
        def get_vars(self, loader, path, entities):
            return {'ansible_env': {'VAR_FROM_PLUGIN': 'woo2'}}

    class PluginV1_1:
        def get_group_vars(self, name):
            return {'plugin_v1_1_group': 'group'}

        def get_host_vars(self, name):
            return {'plugin_v1_1_host': 'host'}

    class PluginV1_2:
        def run(self, host):
            return {'plugin_v1_2': 'host'}


# Generated at 2022-06-23 15:09:36.245653
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    sources = ['/etc/ansible/hosts']

    # Test that a single host in inventory doesn't trigger an error
    entities = ['localhost']
    vars = get_vars_from_inventory_sources(loader, sources, entities, 'task')
    assert(isinstance(vars, dict))

    # Test that a single group in inventory doesn't trigger an error
    entities = ['all']
    vars = get_vars_from_inventory_sources(loader, sources, entities, 'task')
    assert(isinstance(vars, dict))

    # Test that multiple entities in inventory doesn't trigger an error
    entities = ['localhost', 'all']

# Generated at 2022-06-23 15:09:38.698244
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    if os.stat.S_ISREG(get_vars_from_path(None, '/', None, None)):
        print(True)



# Generated at 2022-06-23 15:09:50.488129
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    from collections import namedtuple

    MockPlugin = namedtuple('MockPlugin', ['_load_name', '_original_path', 'get_host_vars'])
    MockHost = namedtuple('MockHost', 'name')

    plugin1 = MockPlugin('plugin1', '/etc/ansible/plugin1', lambda name: {'plugin1_host': 'plugin1'})
    plugin2 = MockPlugin('plugin2', '/etc/ansible/plugin2', lambda name: {'plugin2_group': {'p2g_key': 'p2g_val'}})
    plugin3 = MockPlugin('plugin3', '/etc/ansible/plugin3', lambda name: {'plugin3_group': {'p3g_key': 'p3g_val'}})

# Generated at 2022-06-23 15:10:02.405102
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from unittest import TestCase, mock
    from ansible.inventory import Inventory, Host, Group
    from ansible.parsing.dataloader import DataLoader

    sources = ["/dev/null/no_exist"]
    loader = DataLoader()
    entities = [Host("localhost")]

    class TestInventoryVars(vars_loader.VarsBase):
        def get_vars(self, loader, path, entities):
            return {"a": 1, "b": 2}

    with mock.patch('ansible.plugins.loader.vars_loader.all', lambda: [TestInventoryVars()]):
        data = get_vars_from_inventory_sources(loader, sources, entities, "inventory")
        TestCase().assertEqual(data, {"a": 1, "b": 2})


# Generated at 2022-06-23 15:10:12.997750
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    class FakeVarsPlugin(object):
        def __init__(self, name, original_path, plugin_type='vars'):
            self._load_name = name
            self._original_path = original_path
            self._plugin_type = plugin_type

        def get_vars(self, loader, path, entities):
            return {"key1": "value1"}

        def get_group_vars(self, group_name):
            return {"key2": "value2"}

        def get_host_vars(self, host_name):
            return {"key3": "value3"}

    class FakeHost(object):
        def __init__(self, hostname):
            self.name = hostname

    class FakeGroup(object):
        def __init__(self, groupname):
            self.name = group

# Generated at 2022-06-23 15:10:22.689315
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.cli.adhoc import AdHocCLI


# Generated at 2022-06-23 15:10:35.266526
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import vars_loader

    # setup data
    entity_list = [Host(name='test_host'), Group(name='test_group')]
    path_list = ['test_path']

    # get_vars_from_path
    data_from_path = {}
    for entity in entity_list:
        data_from_path = combine_vars(data_from_path, get_plugin_vars(path_list, entity))
    assert data_from_path  # this test should pass with an empty dict

    #

# Generated at 2022-06-23 15:10:43.145895
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    data = {}
    class FakeLoader:
        class FakeCollection:
            def get_plugin(plugin_name):
                class FakePlugin:

                    def get_vars(loader, path, entities):
                        return data
                return FakePlugin()
    loader = FakeLoader()
    path = "/path/to/example"
    plugin = loader.FakeCollection.get_plugin("fake")
    vars = get_plugin_vars(loader, plugin, path, [])
    assert vars == data

# Generated at 2022-06-23 15:10:44.364194
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    # FIXME: need to mock inventory and find some test inventory data
    assert False

# Generated at 2022-06-23 15:10:44.928120
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    assert True

# Generated at 2022-06-23 15:10:55.636608
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.cli.galaxy.test_utils import MockGalaxyCLI

    loader, all_vars = MockGalaxyCLI._mock_galaxy_environment('tests/unit/unit_data/vars_plugins_data',
                                                              paths=['my_vars_plugin', 'my_vars_subdir_plugin'],
                                                              class_name=AnsibleCollectionRef)

    assert len(C.VARIABLE_PLUGINS_ENABLED) == 0
    assert len(all_vars['vars_plugin']) == 0

    assert len(all_vars['vars_subdir_plugin']) == 0

    # vars plugin does not support v2.x, should be disabled

# Generated at 2022-06-23 15:11:03.845224
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    ##########################################################################
    # (1) test success case
    ##########################################################################

    # create a vars_plugin mock
    class MockVarsPlugin():
        def get_vars(self, loader, path, entities):
            return {"k1": "v1"}

    # create a vars_loader mock
    class MockVarsLoader():
        def __init__(self):
            self.plugins = [ MockVarsPlugin() ]

        def __getitem__(self, vars_plugin):
            return None

    # create an Inventory mock
    class MockInventory():
        def __init__(self):
            self.loader = MockVarsLoader()

    # test
    path = "/mock/path"
    inventory = MockInventory()

# Generated at 2022-06-23 15:11:12.846892
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    loader = vars_loader

    get_plugin_vars = __import__('ansible.plugins.loader').get_plugin_vars

    #test for given host

    host = Host('test1', port=22)

    #test for given group

    group = host.groups[0]
    group.name = 'testgroup'

    #test for given path

    path = os.path.join(os.getcwd(), 'test')

    #test for stage 'inventory'

    stage_inv = 'inventory'

    #test for stage 'task'

    stage_task = 'task'

    #test for stage 'all'

    stage_all = 'all'

    #test for VARIABLE_PLUGINS_ENABLED


# Generated at 2022-06-23 15:11:24.900943
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task

    hosts = ['localhost', 'other']
    task = Task()
    play = Play().load({}, variable_manager=None, loader=None)
    play._injector = {'inventory': InventoryManager(hosts=hosts, sources={'localhost' : None})}
    inventory = play.get_variable_manager().inventory
    task._play = play
    plugin = vars_plugin.VarsModule()

    data = get_plugin_vars(play.get_loader(), plugin, hosts[0], ['localhost'])
    assert isinstance(data, dict) and 'inventory_hostname' in data

    data = get

# Generated at 2022-06-23 15:11:37.625533
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars

    examples_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', '..', 'examples'))
    plugin_path = os.path.join(examples_path, 'plugins', 'vars')

    class MockVarsModule(vars.VarsModule):
        """
        A mock class just to run the _get_plugin_vars method and get plugins vars.
        """
        def __init__(self):
            self._load_name = 'mock-vars'
            self._original_path = 'mock-path'
            self.path = 'mock-path'

# Generated at 2022-06-23 15:11:47.076378
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.cli.playbook import PlaybookCLI
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import find_plugins

    sources = [
        os.path.expanduser('~/.ansible/cp/hosts'),
        '/etc/ansible/hosts',
        'localhost,'
    ]
    entities = []
    loader = PlaybookCLI(playbooks=[], inventory=sources, variable_manager=None, loader=None,
                         options=PlayContext(options=None), passwords=None)
    plugin_list = []
    for plugin_type in ('vars', 'vars_prompt'):
        plugin_list.extend(find_plugins(plugin_type, '.'))


# Generated at 2022-06-23 15:11:56.095321
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    class TestPlugin:
        def get_vars(self,loader,path,entities):
            self.path=path
            self.entities=entities
            return {'a': 1}

        def get_host_vars(self,host):
            self.host=host
            return {'b': 2}

        def get_group_vars(self,group):
            self.group=group
            return {'c': 3}

    class TestHost:
        def __init__(self,name):
            self.name=name

    class TestGroup:
        def __init__(self,name):
            self.name=name

    loader = {'_basedir': './'}
    plugin = TestPlugin()
    path = './'
    host = TestHost('host')

# Generated at 2022-06-23 15:12:00.836724
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    from ansible.plugins.vars import IndexedVars

    loader = None
    plugin = IndexedVars({ b"foo" : "bar" }, "test")
    path = "/tmp"
    entities = []

    assert plugin.get_vars(loader, path, entities) == { b"foo" : "bar" }



# Generated at 2022-06-23 15:12:10.579246
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    class AnsibleVariable:

        def __init__(self, stage='inventory', plugin_name='test_plugin'):
            self.run_vars_plugins = 'all'
            self.variable_plugins_enabled = [plugin_name]
            self.inventory_directory = ['/home/ansible/test_inventory_dir/']
            self.variable_plugins_path = ['/home/ansible/test_vars_plugin_dir/']
            self.plugin_stage = stage

    class AnsibleInventory:

        def __init__(self, group_name='test_group', group_name_list=['test_group'], host_list=['test_host'],
                     host_name='test_host'):
            self.group_list = group_name_list
            self.host_list = host_list
           

# Generated at 2022-06-23 15:12:18.883131
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.playbook import Playbook
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.plugins import vars_loader

    class TestInventory(object):
        def __init__(self):
            self.sources = ['tests/vars']

    def test_get_vars_from_path():
        loader = Playbook.loader
        context = PlayContext()
        play = Play.load(dict(
            name="Ansible Play",
            hosts='local',
            gather_facts='no',
            tasks=[dict(action=dict(module='debug', args=dict(msg='Test')))]
        ), variable_manager=Playbook.variable_manager, loader=loader)
        inventory = TestInventory()
        data = get_v

# Generated at 2022-06-23 15:12:29.750062
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    # just create a display object that only has a verbosity setting
    display.verbosity = 2

    # create a loader to load some test plugins
    loader = vars_loader.get('plugins/test_vars_plugin')

    # ensure the plugin is loaded
    assert loader._load_name == 'plugins/test_vars_plugin'

    # the inventory source is a list of directories to search for plugins
    # the first item in the list is always the current working directory
    test_dir = os.path.dirname(__file__)
    inventory_sources = ['.', test_dir + '/vars_plugins']

    # the entities to operate on
    entities = []
    # mock up an entity to test the inventory_dir plugin
    entities.append(Host('mock_host'))
    # mock up an entity to test the inventory

# Generated at 2022-06-23 15:12:36.169446
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    class MockPlugin:

        _load_name = 'MockPlugin'

        def get_vars(self, loader, path, entities):
            return {'path': path}

    mock_plugin = MockPlugin()
    loader = 'some_loader'
    path = 'some/path'
    entities = ['some/entities']
    data = get_plugin_vars(loader, mock_plugin, path, entities)
    assert 'path' in data and data['path'] == path

# Generated at 2022-06-23 15:12:37.614713
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    assert get_vars_from_inventory_sources('loader','sources','entities','stage') == None

# Generated at 2022-06-23 15:12:41.043312
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    path = 'some_path'
    entities = ['one', 'two']
    stage = 'inventory'
    assert get_vars_from_path(loader, path, entities, stage) == {}

# Generated at 2022-06-23 15:12:51.331451
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    host = Host('127.0.0.1')
    group = Host('group')
    plugin = vars_loader.get('vars_files')
    path = 'path'
    entities = [group, host]


# Generated at 2022-06-23 15:12:58.305941
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import vars_loader, inventory_loader

    inventory = InventoryManager(loader=inventory_loader, sources=[os.path.join('test', 'unit', 'correct_vars_plugin_order')])
    vars_loader.all()
    assert len(get_vars_from_inventory_sources(inventory.loader, inventory._sources, inventory.hosts.values(), 'inventory')) == 1

# Generated at 2022-06-23 15:13:06.366120
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    loader = None
    # Path should be an absolute path
    path = '/home/test/test'
    # Entities should always be a list, can contain multiple hosts and/or groups
    entities = [{'name': 'example.com'}, {'name': 'example2.com'}]
    # Stage should be either inventory or task
    stage = 'inventory'
    vars_from_path = get_vars_from_path(loader, path, entities, stage)
    assert isinstance(vars_from_path, dict)


# Generated at 2022-06-23 15:13:06.998038
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    pass

# Generated at 2022-06-23 15:13:17.657649
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inv = InventoryManager(loader=loader, sources=[
        "tests/inventory/test_inventory"])
    vars_manager = VariableManager(loader=loader, inventory=inv)

    # host vars
    res = get_vars_from_inventory_sources(loader, ['/tmp/test_inventory/host_vars/host1'], ['host1'], 'inventory')
    assert res == {'host_var': 'host1_host_var'}

    # group vars

# Generated at 2022-06-23 15:13:18.634781
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    data = {}
    return data


# Generated at 2022-06-23 15:13:22.308163
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    # Setup
    loader = None
    path = '~'
    entities = []
    stage = 'inventory'

    # Test
    data = get_vars_from_path(loader, path, entities, stage)

    # Verify
    assert isinstance(data, dict)

# Generated at 2022-06-23 15:13:34.431705
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    import ansible.constants as C

    C.RUN_VARS_PLUGINS = 'start'
    C.VARIABLE_PLUGINS_ENABLED = 'python_vars,aws_ec2_vars'

    # Add the current directory to import path
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.abspath(__file__)))

    loader = None
    sources = [None, 'test_content/inventory']
    entities = []
    stage = 'start'
    data = get_vars_from_inventory_sources(loader, sources, entities, stage)
    assert data == {'ansible_python_version_full': '3.6.8'}

    stage = 'task'
    data = get_vars_from_

# Generated at 2022-06-23 15:13:35.041826
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    pass

# Generated at 2022-06-23 15:13:40.005079
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader, [])
    variable_manager = VariableManager(loader, inventory)

    assert variable_manager.get_vars_from_inventory_sources(inventory.sources) == {}

# Generated at 2022-06-23 15:13:43.977934
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    loader = None
    path = '/path/to/group_vars/path'
    entities = [object()]
    stage = 'all'

    result = get_vars_from_path(loader, path, entities, stage)

    assert result == {}

# Generated at 2022-06-23 15:13:48.836532
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import group_vars
    from ansible.plugins.loader import vars_loader

    loader = vars_loader.get('group_vars')

    gv = group_vars.VarsModule()
    get_plugin_vars(loader, gv, 'test', [])

# Generated at 2022-06-23 15:13:57.662906
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    current_dir = os.path.dirname(os.path.realpath(__file__))
    fixtures_path = os.path.join(current_dir, '..', '..', 'unit', 'utils', 'loader', 'fixtures')
    loader = AnsibleFileLoader(None, 'file', False)
    fake_path = os.path.join(fixtures_path, 'vars_plugin', 'fake_path')
    entities = [
        Host(name='localhost'),
        Host(name='localhost'),
    ]
    stages = [
        'inventory',
        'task',
    ]

    vars_plugin = VarsModule(loader=loader, path=fake_path)
    vars_plugin.get_vars = lambda l, p, e: {'fake_vars': {'path': p}}
   

# Generated at 2022-06-23 15:14:08.123512
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.mod_args import ModuleArgsParser
    from ansible.cli.arguments import do_common_args
    from ansible.utils.collection_loader import AnsibleCollectionLoader

    sys_argv = [
        'ansible',
        '--version',
        '--inventory=%s/test/integration/inventory' % os.getcwd(),
        '--playbook_dir=%s/test/integration' % os.getcwd(),
        '--collection-paths=%s/' % os.getcwd()
    ]

    do_common_args(sys_argv[1:])

    # Initialize AnsibleCollectionLoader
    C.set_collection_paths([os.getcwd()])


# Generated at 2022-06-23 15:14:18.148290
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    class PluginMock():
        """ Mock plugin loaded by vars_loader """

        def __init__(self):
            self._load_name = 'test'
            self._name = 'test'
            self._original_path = 'test'
            self.get_vars = lambda x, y, z: {'test': True}

    class LoaderMock():
        """ Mock loader to load the plugin """

        def __init__(self):
            self.get = lambda x: PluginMock()
            self.all = lambda: [PluginMock()]

    class HostMock():
        """ Mock host entity """

        def __init__(self, uid):
            self.name = uid

    class GroupMock():
        """ Mock group entity """

        def __init__(self, uid):
            self.name

# Generated at 2022-06-23 15:14:25.565213
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    display.verbosity = 0

    # Test for v2 plugin
    d = dict(plugin_name='file')
    vars_plugin = vars_loader.get(d)

    entities = ['group']
    path = 'path/to/project'
    data = get_plugin_vars(vars_plugin, path, entities)

    # Test for v1 plugin
    d = dict(plugin_name='ini_file')
    vars_plugin = vars_loader.get(d)

    entities = ['group']
    path = 'path/to/project'
    data = get_plugin_vars(vars_plugin, path, entities)

# Generated at 2022-06-23 15:14:35.408800
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    from ansible.inventory.manager import InventoryManager
    from ansible.module_utils.common.collections import ImmutableDict


# Generated at 2022-06-23 15:14:39.500007
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    loader_mock = Mock()
    sources_mock = Mock()
    entities_mock = Mock()

    actual = get_vars_from_inventory_sources(loader_mock, sources_mock, entities_mock)

    assert actual == {}

# Generated at 2022-06-23 15:14:40.898227
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    assert get_vars_from_inventory_sources(None) == {}

# Generated at 2022-06-23 15:14:43.742263
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    assert get_vars_from_inventory_sources(None, ['path0', 'path1', 'path2'], [], 'task') == {}

# Generated at 2022-06-23 15:14:44.544409
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    pass

# Generated at 2022-06-23 15:14:46.603330
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    assert get_vars_from_inventory_sources("/path/to/one,/path/to/two") == {}

# Generated at 2022-06-23 15:14:57.543093
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from .test_inventory import TestInventoryPluginBase
    from .test_vars_plugins.test_vars_plugin import TestVars
    from .test_vars_plugins.another_test_vars_plugin import AnotherTestVars
    from ansible.plugins.manager import PluginLoader

    plugin_loader = PluginLoader(
        class_name='AnsiblePlugin',
        package='ansible.plugins',
        config=C,
        read_only=True
    )
    display.verbosity = 3

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])

# Generated at 2022-06-23 15:15:03.831735
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    sources = [
        '/path/to/inventory/dir',
        '/path/to/inventory/dir_2',
        'localhost,127.0.0.1,',
        None,
        ['/path/to/inventory/dir'],
        ['localhost'],
    ]

    loader = {}
    entities = ['localhost']

    data = get_vars_from_inventory_sources(loader, sources, entities)
    assert data == {}

# Generated at 2022-06-23 15:15:09.789102
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    display.verbosity = 3
    # testing a directory that doesn't exist
    path = '/my/made/up/path'
    entities = {}
    stage = 'inventory'
    data = get_vars_from_path('loader', path, entities, stage)
    assert 'data' in data
    assert len(data) == 1

# Generated at 2022-06-23 15:15:20.106779
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    sources = [
        "./test/test_vars_plugin.yml",
        "./test/test_vars_plugin"
    ]

    loader = DataLoader()
    inv = InventoryManager(loader=loader, sources=sources)
    sources_as_paths = [path for host_group in inv.groups.values() for path in host_group.vars_plugins.keys()]

    vars_results = get_vars_from_inventory_sources(loader, sources_as_paths, [], "inventory")

    assert vars_results['base'] == 'Hello World'
    assert vars_results['foo'] == 'bar'
    assert 'baz' not in vars_

# Generated at 2022-06-23 15:15:27.127051
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    '''Test get_vars_from_path function'''
    array_of_entities = []
    group_name = 'test'
    loader = None
    path = '/path/to/somewhere'
    stage = 'inventory'
    wrong_stage = 'wrong_stage'
    assert get_vars_from_path(loader, path, array_of_entities, stage) == {}
    assert get_vars_from_path(loader, path, array_of_entities, wrong_stage) == {}



# Generated at 2022-06-23 15:15:36.931630
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    path = 'test/path'
    sources = ['source1', 'source2']
    stage = 'inventory'
    test_data = 'test data'

    loader_mock = MockLoader()
    get_vars_from_path_mock = MagicMock(return_value=test_data)

    with patch.multiple(VarsModule, get_vars_from_path=get_vars_from_path_mock):
        get_vars_from_inventory_sources(loader_mock, sources, [], stage)

    result = get_vars_from_inventory_sources(loader_mock, sources, [], stage)

    if result != sources[0]:
        raise AssertionError



# Generated at 2022-06-23 15:15:48.171451
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    loader = None

    plugin = FakeVarsPlugin()
    entities = [MockHost('hostname')]
    path = '/path/to/inventory/'

    plugin.set_vars({'vars': 'value'})
    assert get_plugin_vars(loader, plugin, path, entities) == {'vars': 'value'}
    plugin.set_vars({'vars': 'value'})
    assert get_plugin_vars(loader, plugin, path, entities) == {'vars': 'value'}

    # plugin.get_host_vars gets called
    plugin = FakeVarsPlugin()
    plugin.set_vars({'vars': 'other_value'}, host='hostname')

# Generated at 2022-06-23 15:16:00.478992
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    path = '/path/to/file'


# Generated at 2022-06-23 15:16:08.972927
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.playbook.play_context import PlayContext

    class TestPlugin(object):
        def get_vars(self, loader=None, path=None, entities=None):
            return {"one": 1}

    vars_plugin_list = [TestPlugin()]
    plugin = vars_plugin_list[0]

    # Test old style vars plugin
    data = get_plugin_vars(PlayContext(), plugin, '', [])
    assert data == {"one": 1}

    del TestPlugin.get_vars

    class TestPlugin(object):
        def get_host_vars(self, host):
            return {"two": 2}

        def get_group_vars(self, host):
            assert False, "Shouldn't have called this"

    plugin = TestPlugin()
    data = get_plugin

# Generated at 2022-06-23 15:16:18.349419
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from test_inventory_plugins import _get_loader
    from ansible.parsing.dataloader import DataLoader


# Generated at 2022-06-23 15:16:25.361421
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    # NOTE: This test should be updated if the function signature is changed
    # Since this is a private function, it doesn't make sense to import this
    # module but use other test tools to verify the function.
    ansible_vars = {'test': 'foo'}
    plugin_instance = FakeVarsPlugin()

    assert get_plugin_vars(None, plugin_instance, None, None) == ansible_vars



# Generated at 2022-06-23 15:16:35.558538
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible import context
    from ansible.cli import CLI
    from ansible.config.manager import ConfigManager
    from ansible.parsing.dataloader import DataLoader

    context._init_global_context(CLI(args=[],
                                     config_manager=ConfigManager(os.path.join(os.path.dirname(__file__), 'ansible.cfg'))))
    loader = DataLoader()

    # Test by passing host ('samples') as a value to entities
    entities = ['samples']
    expected = {'vars_plugin_test': 'this is a test', 'vars_test': 'this is a vars test'}
    data = get_vars_from_path(loader, '../lib/ansible/plugins/vars', entities, 'task')

# Generated at 2022-06-23 15:16:42.164316
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    import unittest

    class TestVarsPlugin:
        def get_host_vars(self, host_name):
            return {host_name: ['test']}

    class TestVarsPluginV1:
        def run(self):
            pass

    class TestVarsPluginV2:
        def get_vars(self, loader, path, entities):
            return {'test': 'test'}

    class TestVarsPluginV3:
        def get_vars(self, loader, path, entities):
            return {'test': 'test'}

        def has_option(self, option):
            return True

        def get_option(self, option):
            return None


# Generated at 2022-06-23 15:16:53.745022
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    import os
    import sys
    try:
        import __main__ as main
    except ImportError:
        main = sys.modules['__main__']

    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory import Inventory

    from ansible.vars.manager import VariableManager
    from ansible.vars.plugins.vars import VarsModule

    from ansible.utils.vars import combine_vars

    from ansible.plugins.loader.vars_loader import _get_vars_plugins

    dataloader = DataLoader()
    inventory = Inventory(dataloader=dataloader, host_list=['localhost'])

    variable_manager = VariableManager(loader=dataloader, inventory=inventory)

# Generated at 2022-06-23 15:16:59.070114
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    class VarsPlugin(object):

        def get_vars(self, loader, path, entities):
            return {'foo': 'bar'}

    loader = VarsPlugin()
    assert {'foo': 'bar'} == get_plugin_vars(loader, loader, '/some/path', list())



# Generated at 2022-06-23 15:17:00.023800
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    # TODO
    pass

# Generated at 2022-06-23 15:17:07.584436
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # TODO: does't work with vars plugins in other collections
    # TODO: we should make it work
    ansible_path = os.path.join(C.DEFAULT_MODULE_PATH, 'ansible')
    path = os.path.join(C.DEFAULT_MODULE_PATH, 'library')
    plugin_wrapper = get_plugin_vars
    vars_plugin_list = list(vars_loader.all())
    plugin_list = []
    for plugin in vars_plugin_list:
        plugin.has_option = False
        plugin.get_option = False
        plugin.run = True
        plugin_list.append(plugin)
    assert not plugin_wrapper(loader, plugin_list, path, Host(None, 'dummy'))
    # assert_raises(AnsibleError, plugin

# Generated at 2022-06-23 15:17:08.248011
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    pass


# Generated at 2022-06-23 15:17:12.953338
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    vars_plugin_list = list(vars_loader.all())
    plugin = vars_plugin_list[0]
    path = "/home/vagrant/ansible/test/integration/targets/inventory_dir"
    loader = None
    entity_list = list()
    entity = Host(name='localhost')
    entity_list.append(entity)
    data = get_plugin_vars(loader, plugin, path, entity_list)
    assert len(data) > 0

# Generated at 2022-06-23 15:17:14.359942
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    assert get_plugin_vars(None, {}, None, None) == {}

# Generated at 2022-06-23 15:17:22.743672
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins import vars_plugin

    class TestVarsPlugin(vars_plugin.VarsModule):
        def __init__(self):
            super(TestVarsPlugin, self).__init__()
            self.called = False

        def get_vars(self, loader, path, entities, cache=True):
            assert loader
            assert path
            assert entities
            self.called = True
            return {'test': True}

    plugin = TestVarsPlugin()
    loader = 'FAKE LOADER'
    path = 'FAKE PATH'
    entities = ['FAKE ENTITY']
    assert plugin.get_vars(loader, path, entities) == {'test': True}


# Generated at 2022-06-23 15:17:24.289485
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert isinstance(get_vars_from_path(None, None, None, None), dict)

# Generated at 2022-06-23 15:17:28.508867
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    display.verbosity = 3
    vars_loader.add_directory(os.path.join(C.ROOT_DIR, 'lib/ansible/plugins/vars'))
    loader = vars_loader._create_loader()

    from ansible.playbook.play_context import PlayContext

    path = os.path.join(C.ROOT_DIR, 'lib/ansible/plugins/vars/test_vars')
    data = get_vars_from_path(loader, path, [PlayContext()], 'inventory')
    assert data == dict(plugin_path=path)

# Generated at 2022-06-23 15:17:39.983836
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    # If a valid vars plugin, no issue
    plugin = {
        "_load_name": "test",
        "get_vars": None
    }
    assert get_vars_from_path(None, None, None, None) is not None

    plugin['get_vars'] = lambda x,y,z: {'test': 'value'}
    assert get_vars_from_path(None, None, None, None) == {'test': 'value'}

    # If a plugin has get_host_vars, no issue
    plugin = {
        "_load_name": "test",
        "get_host_vars": None
    }
    assert get_vars_from_path(None, None, [], None) is not None


# Generated at 2022-06-23 15:17:47.287181
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['../docs/examples/hosts'])
    var_manager = VariableManager(loader=loader, inventory=inventory)
    plugins = vars_loader.all()
    result = get_vars_from_inventory_sources(loader, inventory.sources, inventory.get_groups_dict(), 'task')
    assert (result['redis_port'] == 6379)

# Generated at 2022-06-23 15:17:48.243296
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    pass

# Generated at 2022-06-23 15:17:50.722604
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert get_vars_from_path(None, '/test/path', [], 'inventory') == {}

# Generated at 2022-06-23 15:17:51.383227
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert 1 == 1

# Generated at 2022-06-23 15:17:53.681572
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # TODO: test static
    # TODO: test ldap
    # TODO: test script
    pass


# Generated at 2022-06-23 15:17:55.402807
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    import tempfile


# Generated at 2022-06-23 15:17:59.125800
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    # This unit test is current not used by any test.
    # It has been created to permit easier development of new unit tests
    # and should be moved to a proper place later.
    pass

# Generated at 2022-06-23 15:18:09.194453
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader

    # Need to run vars_loader.get_all() to get the plugin list.  
    #  This gets run from cli.py -- so we will not test this function.
    vars_loader.get_all()

    # Test function get_vars_from_path
    #   Don't have access to ansible.inventory.host.Host class
    #   Test with ansible.inventory.group.Group class
    #   Test with a dir that has vars plugin
    #   Test with a dir that doesn't have vars plugin
    #   Test with a nonexistent dir

    # Don't have access to ansible.inventory.host.Host class
    #   Test with ansible.inventory.group.Group class

# Generated at 2022-06-23 15:18:18.377026
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.vars import inventory_vars
    from ansible.inventory.manager import InventoryManager
    inventory_manager = InventoryManager(loader=None, sources=None)
    inventory_manager.groups = {'testgroup': {'vars': {'test': 'groupvar'}}}
    inventory_manager.hosts = {'testhost': {'vars': {'test': 'hostvar'}}}
    inventory_manager.hosts['testhost']['groups'] = ['testgroup']
    inventory_manager.hosts['testhost']['name'] = 'testhost'
    inventory_manager.cache = {'_meta': {'hostvars': {}}}

    fake_loader = object

# Generated at 2022-06-23 15:18:30.053841
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing import vault
    import tempfile
    import shutil

    # create temporary dir and files
    tmp_dir = tempfile.mkdtemp()
    shutil.copytree(os.path.join(os.path.dirname(__file__), '..', 'inventory', 'vars_plugins'), os.path.join(tmp_dir, 'vars_plugins'))

    # get the result
    inventory_path = os.path.join(tmp_dir, 'inventory.ini')

# Generated at 2022-06-23 15:18:39.158059
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    # Test v1 plugin (pre Ansible 2.9)
    test_plugin_v1 = vars_loader.get('test_vars_plugin')
    test_plugin_v1._get_vars_func = getattr(test_plugin_v1, 'get_vars')
    test_plugin_v1.get_vars = lambda self, loader, path, entities: {'test_vars_plugin': 'v1'}
    test_plugin_v1.get_group_vars = lambda self, name: {'test_vars_plugin': 'v1'}
    test_plugin_v1.get_host_vars = lambda self, name: {'test_vars_plugin': 'v1'}


# Generated at 2022-06-23 15:18:43.630015
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import random_plugin
    loader = False
    plugin = random_plugin.VarsModule()
    path = './test'
    entities = []
    get_plugin_vars(loader, plugin, path, entities)
    assert 1


# Generated at 2022-06-23 15:18:55.922497
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    import mock
    import textwrap

    class GroupVarsPlugin(mock.MagicMock):
        def get_group_vars(self, name):
            return {'group_var': name}

    class HostVarsPlugin(mock.MagicMock):
        def get_host_vars(self, name):
            return {'host_var': name}

    class NewVarsPlugin(mock.MagicMock):
        def get_vars(self, loader, path, entities):
            return {'new_vars_plugin': True}

    plugin_list = [GroupVarsPlugin(), HostVarsPlugin(), NewVarsPlugin()]

    for plugin in plugin_list:
        plugin.has_option = mock.MagicMock(return_value=True)

# Generated at 2022-06-23 15:19:01.533090
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Simple test, just check that it does not blow up

    # TODO: The test is not being call, it is here as a placeholder for
    #       when the function will be implemented.

    ent=[]
    loader=None
    path=None
    stage=None
    data = get_vars_from_path(loader, path, ent, stage)
    assert len(data) == 0

# Generated at 2022-06-23 15:19:12.697410
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    get_vars_from_path_result = {
        "a": 0,
        "b": 1,
        "c": 2,
        "foo": "bar",
        "my_magic_number": 42,
        "hostname": "ansible",
        "port": "22"
    }
    loader = {}
    plugin = {
        "_load_name": "my_vars_plugin",
        "get_vars": lambda loader, path, entities: {
            "a": 0,
            "b": 1,
            "c": 2
        },
        "get_group_vars": lambda name: {
            "foo": "bar"
        },
        "get_host_vars": lambda name: {
            "my_magic_number": 42
        }
    }
    path = None


# Generated at 2022-06-23 15:19:19.561942
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader

    test_plugin = 'tests/units/module_utils/legacy_vars_plugins/test_vars_plugin.py'
    vars_loader.add(test_plugin)

    ref = AnsibleCollectionRef.from_string('test_vars_plugin')
    plugin = vars_loader.get(ref)
    assert plugin.get_vars(None, None, None)['test_vars_plugin'] is True

