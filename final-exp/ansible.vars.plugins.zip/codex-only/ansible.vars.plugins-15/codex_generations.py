

# Generated at 2022-06-23 15:09:17.654841
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    pass

# Generated at 2022-06-23 15:09:22.602151
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    loader = 'dummy_loader'
    sources = [ './test/test_vars_plugin.yml' ]
    entities = [ 'all' ]
    stage = 'task'

    data = get_vars_from_inventory_sources(loader, sources, entities, stage)
    assert data == {'my_var': 'my_value'}

# Generated at 2022-06-23 15:09:31.511779
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    import ansible.plugins.vars.vars as vars_plugin
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    class FakeLoader(object):
        pass

    loader = FakeLoader()

    class MyVarsPlugin(vars_plugin.VarsBase):
        def run(self, terms, variables=None, **kwargs):
            if variables is None:
                variables = dict()
            variables['answer'] = 42
            return variables

    paths = ['/path/plugins/vars/a.yml', '/path/plugins/vars/a.py']
    plugin = MyVarsPlugin(loader=loader)
    plugin._load_name = 'a.yml'
    plugin._original_path = '/path/plugins/vars/a.yml'
    data = get

# Generated at 2022-06-23 15:09:38.581542
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    loader = None
    path = 'tests/integration/inventory/vars_plugin/'
    entities = ['plugin_a', 'plugin_b', 'plugin_c']
    stage = 'inventory'
    data = get_vars_from_path(loader, path, entities, stage)
    assert len(data) == 3
    assert data['a'] == 'a'
    assert data['b'] == 'b'
    assert data['c'] == 'c'



# Generated at 2022-06-23 15:09:50.406507
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins import vars_plugins
    # func_name = 'get_plugin_vars'
    vars_plugins.__path__ = os.path.dirname(os.path.realpath(__file__)) + '/../plugins/vars_plugins'
    from ansible.plugins.vars import magic
    plugin_name = "magic"
    loader = None
    path = ''
    entities = ['test']
    plugin = vars_loader.get(plugin_name)
    assert 'magic' not in get_plugin_vars(loader, plugin, path, entities)

    path = '/ansible/plugins/vars_plugins/magic'
    assert 'magic' in get_plugin_vars(loader, plugin, path, entities)
    assert magic.get_group_vars is None
    assert magic.get

# Generated at 2022-06-23 15:10:02.015119
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader

    dummy = vars_loader.get('dummy')
    dummy.get_vars = lambda x, y, z: {'dummy': 'plugin'}

    data = get_vars_from_path(None, None, None, None)
    assert 'dummy' in data
    assert data['dummy'] == 'plugin'

    dummy.get_vars = lambda x, y, z: {'dummy': 'plugin', 'test': 'fake'}

    data = get_vars_from_path(None, None, None, None)
    assert 'dummy' in data
    assert 'test' in data
    assert data['dummy'] == 'plugin'
    assert data['test'] == 'fake'

# Generated at 2022-06-23 15:10:07.252486
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    loader = None
    stage = 'inventory'
    sources = ['/etc/ansible/hosts']
    entities = [{"name": "localhost", "address": "127.0.0.1"}]
    data = get_vars_from_inventory_sources(loader, sources, entities, stage)
    assert data == {}

# Generated at 2022-06-23 15:10:16.065894
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_file_yaml
    plugin = vars_file_yaml.VarsModule()
    loader = None
    path = '~/ansible'
    group_dict = {'name': 'test_group', 'hosts': ['test_host'], 'vars': {'version': '1.0'}}
    group = Host(group_dict)
    host_dict = {'name': 'test_host', 'vars': {'version': '2.0'}}
    host = Host(host_dict)
    entities = [group, host]

    try:
        actual = get_plugin_vars(loader, plugin, path, entities)
    except AttributeError:
        actual = {}

    expected = {'version': '2.0'}

# Generated at 2022-06-23 15:10:28.047857
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    # Try to get vars for host 'localhost' from 'inventory_vars_dir' vars plugin
    # in dir 'inventory_vars_dir'.

    from ansible.plugins.inventory.vars_dir import InventoryVarsDir

    # Stub the get_vars(...) method to return vars for host 'localhost'.
    # This is used to get inventory vars for the host 'localhost'.

    def get_vars(loader, path, entities):

        # entities is a list with a single Host('localhost') entry.
        assert len(entities) == 1
        assert isinstance(entities[0], Host)

        # This method should return vars only for the Host('localhost')
        # object.  The object will be mapped to the name 'localhost' and
        # used in the template.


# Generated at 2022-06-23 15:10:29.803286
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    assert get_vars_from_inventory_sources([None], []) == {}

# Generated at 2022-06-23 15:10:39.597644
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    from ansible.plugins.loader import vars_loader

    loader = vars_loader

    path = os.getcwd()
    entities = ["host1", "host2"]
    stage = 'inventory'

    vars_plugin_list = list(vars_loader.all())

    for plugin in vars_plugin_list:
        if plugin._load_name not in C.VARIABLE_PLUGINS_ENABLED and getattr(plugin, 'REQUIRES_WHITELIST', False):
            # 2.x plugins shipped with ansible should require whitelisting, older or non shipped should load automatically
            continue

        has_stage = hasattr(plugin, 'get_option') and plugin.has_option('stage')

        # if a plugin-specific setting has not been provided, use the global setting
        # older/non

# Generated at 2022-06-23 15:10:48.213214
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    plugin = vars_loader.get("from_yaml")
    try:
        for plugin_name in C.VARIABLE_PLUGINS_ENABLED:
            plugin = vars_loader.get(plugin_name)
        test_data = get_plugin_vars(loader=None, plugin=plugin, path='test/test_plugin_test_vars', entities=['test/test_plugin_test_vars'])
    except AttributeError:
        raise AnsibleError("NOT a valid vars plugin")
    assert test_data['test_vars_var'] == "test_vars_var_value"

# Generated at 2022-06-23 15:10:52.224706
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    loader = None
    path = "/ansible/playbooks/play_dir/"
    entities = None
    stage = 'inventory'
    get_vars_from_path(loader, path, entities, stage)


# Generated at 2022-06-23 15:11:00.917353
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    # This function lives in the vars plugins folder.  To get it, we must append vars_plugins to the loader path
    try:
        # Add vars_plugins to the loader path
        C.DEFAULT_MODULE_UTILS_PATH.append(os.path.join(os.path.dirname(__file__), 'vars_plugins'))

        # Load the loader
        loader = vars_loader.VarsModuleLoader()
    finally:
        # Remove vars_plugins from the loader path
        C.DEFAULT_MODULE_UTILS_PATH.remove(os.path.join(os.path.dirname(__file__), 'vars_plugins'))

    # Return the plugin
    return loader.get('test_plugin')



# Generated at 2022-06-23 15:11:05.803272
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors as default_collectors_module
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils import facts
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.cache.memory import CacheModule as MemoryCache
    from ansible.plugins.loader import vars_loader, connection_loader, lookup_loader
    from ansible.plugins.strategy import StrategyBase as StrategyBase_module
    from ansible.plugins.vars import BaseVarsPlugin
    from ansible.utils.vars import combine_vars

    class TestVarsPlugin(BaseVarsPlugin):
        """
        A test vars plugin for usage in unit tests
        """
        NAME

# Generated at 2022-06-23 15:11:09.771989
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    loader = vars_loader
    plugin = loader.get('vault')
    path = ''
    entities = []
    stage = 'inventory'
    loader._all = [plugin]
    data = get_vars_from_path(loader, path, entities, stage)
    assert 'ansible_vault_password' in data

# Generated at 2022-06-23 15:11:11.810402
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert isinstance(get_vars_from_path(
        None,
        "/path/to/inventory",
        [],
        "inventory"
    ), dict)


# Generated at 2022-06-23 15:11:23.944766
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    sources = ['/etc/ansible/hosts', None, 'localhost,', 'all']
    entities = [Host('localhost'), Host('127.0.0.1'), Host('all')]
    inventory_data = {
        '_meta': {
            'hostvars': {
                'localhost': {
                    'name': 'localhost',
                },
                '127.0.0.1': {
                    'name': '127.0.0.1',
                },
                'all': {
                    'name': 'all',
                },
            }
        }
    }

    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader

    vault_pass = None
    vault_secret_files = []
    loader = DataLoader()
    vault_

# Generated at 2022-06-23 15:11:30.173921
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.vars.vars_plugins.yaml_file import VarsModule as TestPlugin
    test_entity_list = [ "raw_value", "character" ]
    test_yaml_fixture_dir = os.path.join(os.path.dirname(__file__), '..', '..', '..', '..', 'test', 'integration', 'targets', 'yaml_fixture')
    test_plugin = TestPlugin(None, test_yaml_fixture_dir)
    test_data = get_plugin_vars(None, test_plugin, test_yaml_fixture_dir, test_entity_list)
    assert test_data == {'character': 'Yaml', 'raw_value': 12}

# Generated at 2022-06-23 15:11:41.725242
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import InventoryDirectory
    from ansible.vars.hostvars import HostVars
    from ansible.vars.groupvars import GroupVars
    from ansible.vars.vars import Vars
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.persistent_fact_cache import FactCache

    class MockPlugin1(object):
        def get_vars(self, loader, path, entities):
            data = {'path': path,
                    'entities': entities}
            return data

        def get_group_vars(self, group):
            data = {'group': group}
            return data


# Generated at 2022-06-23 15:11:46.016480
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    class MockLoader:
        pass

    loader = MockLoader()
    sources = ['/home/vagrant/ansible/hacking/test/units/data/inventory/host_vars']
    entities = ['']
    stage = 'inventory'

    assert len(get_vars_from_inventory_sources(loader, sources, entities, stage)) == 2



# Generated at 2022-06-23 15:11:46.909039
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    pass

# Generated at 2022-06-23 15:11:55.161842
# Unit test for function get_vars_from_path
def test_get_vars_from_path():  # pylint: disable-msg=R0914
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.common.util import replace_relative_path
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch
    from ansible.utils.collection_loader import AnsibleCollectionLoader, load_collections

    import ansible_collections.notstdlib.moveitallout.tests.unit.modules.plugins.vars as test_vars_plugins


# Generated at 2022-06-23 15:12:01.393730
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    # create a fake plugin object
    class fake_plugin():
        def __init__(self):
            self.name = 'fake_plugin'

        def get_vars(self, loader, path, entities):
            return {'fake_plugin': {'output': 'true'}}

    # create a fake loader object
    class fake_loader():
        def __init__(self):
            self.name = 'fake_loader'

    # create and call the func
    plugin = fake_plugin()
    loader = fake_loader()
    data = get_plugin_vars(loader, plugin, "", "")
    assert data['fake_plugin']['output'] == 'true'

# Generated at 2022-06-23 15:12:07.275921
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin
    class TestVars(vars_plugin.VarsBase):
        def get_vars(self, loader, path, entities):
            return {'test': {'var': 'unit test'}}

    loader = {}
    path = '.'
    entities = []
    plugin = TestVars()

    assert get_plugin_vars(loader, plugin, path, entities) == {'test': {'var': 'unit test'}}

# Generated at 2022-06-23 15:12:15.692294
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    class DummyVars:
        def __init__(self, data):
            self.data = data

        def get_vars(self, loader, path, entities, cache=True):
            return self.data

    class DummyLoader:
        def get_basedir(self):
            return os.path.realpath(os.path.join(os.path.dirname(__file__), '..', '..'))

    data = {
        'test1': 'test1',
        'test2': 'test2',
    }

    loader_obj = DummyLoader()
    path = os.path.realpath(os.path.join(os.path.dirname(__file__), '..', '..', '..', 'contrib'))

    plugin_obj_1 = DummyVars(data)
   

# Generated at 2022-06-23 15:12:20.607060
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    loader = 'test.test'
    sources = ['test']
    for path in sources:
        if path is None:
            continue
        if ',' in path and not os.path.exists(path):  # skip host lists
            continue
        elif not os.path.isdir(to_bytes(path)):
            # always pass the directory of the inventory source file
            path = os.path.dirname(path)
        print (path)
        #data = combine_vars(data, get_vars_from_path(loader, path, entities, stage))

    return True

test_get_vars_from_inventory_sources()

# Generated at 2022-06-23 15:12:28.078744
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugins

    this_file = os.path.dirname(__file__)
    plugins_path = os.path.join(this_file, '..', '..', 'plugins', 'vars')

    plugin_path = os.path.join(plugins_path, 'vars_plugin.py')
    plugin = vars_plugins.get(plugin_path)
    assert plugin is not None

    loader = None
    assert plugin._load_name == 'vars_plugin'

    data = get_plugin_vars(loader, plugin, '.', [])
    assert data == {'var1': 'val1', 'var2': 'val2'}

# Generated at 2022-06-23 15:12:37.328622
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.vars.plugins.vars import VarsModule
    class VarsModuleTest(VarsModule):
        ''' used for testing only '''
        def __init__(self):
            self._original_path = __file__
            self._load_name = 'VarsModuleTest'
            self.get_vars = lambda x, y, z: dict(test='test result')
        def get_host_vars(self, hostname):
            return dict(hostname=hostname, host='host result')
        def get_group_vars(self, groupname):
            return dict(groupname=groupname, group='group result')
    class MockLoader(object):
        pass
    class MockEntity(object):
        def __init__(self, name, type):
            self.name = name
            self

# Generated at 2022-06-23 15:12:44.473060
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    from ansible.plugins.vars import test_yaml

    from ansible.playbook.play_context import PlayContext

    assert vars_loader.get('test_yaml') is None
    assert 'test_yaml' not in vars_loader._path_cache
    assert 'test_yaml' not in vars_loader._module_cache

    loader = vars_loader._loader

    # create an inventory source directory and place a yaml vars file in it
    tmpdir = '/tmp/ansible_test_inventory_source_vars_plugin'
    if os.path.exists(tmpdir):
        import shutil
        shutil.rmtree(tmpdir)
    os.mkdir(tmpdir)
    assert os.path.isdir(tmpdir)

# Generated at 2022-06-23 15:12:53.944037
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.group import Group
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import vars_loader

    # blank inventory
    loader = DataLoader()
    inventory = loader.inventory
    sources = [ 'tests/test_vars_plugins/inventory_empty' ]
    entities = [Group('all')]

    # test inventory get var plugins
    stage = 'inventory'
    vars_plugin_list = list(vars_loader.all())
    data_1 = get_vars_from_inventory_sources(loader, sources, entities, stage)

    # test get vars for
    stage = 'task'
    vars_plugin_list = list(vars_loader.all())
   

# Generated at 2022-06-23 15:13:04.129432
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars.host_group import HostGroupVars
    from ansible.plugins.vars.host_auto import HostVars

    entities = ['bob']
    path = '/tmp/foo'
    plugin = HostVars()
    expected = {'bob': 'bob'}
    actual = get_plugin_vars(None, plugin, path, entities)
    assert actual == expected

    path = '/tmp/foo'
    plugin = HostGroupVars()
    expected = {'group_names': ['bob']}
    actual = get_plugin_vars(None, plugin, path, entities)
    assert actual == expected

# Generated at 2022-06-23 15:13:08.278792
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import dirset
    plugin = dirset.VarsModule()

    # Test if plugin is v1 plugin
    if hasattr(plugin, 'run'):
        raise AnsibleError("Test Error: Cannot use v1 type vars plugin %s from %s" % (plugin._load_name, plugin._original_path))

    plugin.get_vars(None, None, [])

# Generated at 2022-06-23 15:13:10.098639
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    assert get_vars_from_inventory_sources(None, None, None, None) == {}

# Generated at 2022-06-23 15:13:16.657448
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    import tempfile
    from ansible.inventory import Inventory
    from ansible.plugins.loader import vars_loader

    # create file in temp directory
    tmpdir = to_bytes(tempfile.mkdtemp())
    test_parser_plugin_path = os.path.join(tmpdir, b'test_vars_inventory_sources.py')

    # copy test plugin file to temp

# Generated at 2022-06-23 15:13:19.719265
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    loader = None
    path = os.getcwd()
    entity = Host("localhost")
    entities = [entity]
    stage = "inventory"
    data = get_vars_from_path(loader, path, entities, stage)
    assert data

# Generated at 2022-06-23 15:13:20.339080
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    assert 1==1

# Generated at 2022-06-23 15:13:25.330778
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    assert get_vars_from_inventory_sources(loader, [], [], "inventory") == {}
    assert get_vars_from_inventory_sources(loader, [], [], "task") == {}

# Generated at 2022-06-23 15:13:35.458476
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader

    def get_vars_from_path(path, entities, stage):
        loader = None
        plugin = None

        data = {}

        vars_plugin_list = list(vars_loader.all())
        for plugin_name in C.VARIABLE_PLUGINS_ENABLED:
            if AnsibleCollectionRef.is_valid_fqcr(plugin_name):
                plugin = vars_loader.get(plugin_name)
                if plugin is None:
                    # Error if there's no play directory or the name is wrong?
                    continue
                if plugin not in vars_plugin_list:
                    vars_plugin_list.append(plugin)


# Generated at 2022-06-23 15:13:43.021462
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    import ansible.plugins.vars
    import ansible.plugins.vars.folders
    import ansible.plugins.vars.config_template
    import ansible.plugins.vars.group_vars_files
    import ansible.plugins.vars.host_vars_files
    loader, _, _ = vars_loader.all()  # get plugin loader
    plugin_names = ('config_template', 'folders', 'group_vars_files', 'host_vars_files')
    for plugin_name in plugin_names:
        plugin = loader.get(plugin_name)
        assert plugin is not None, "vars plugin %s should not be None" % plugin_name

# Generated at 2022-06-23 15:13:44.132517
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    pass



# Generated at 2022-06-23 15:13:54.796445
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.cli.playbook import PlaybookCLI as cli
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    options = cli.base_parser(
        runas_opts=True,
        async_opts=True,
        output_opts=True,
        connect_opts=True,
        check_opts=True,
        runtask_opts=True,
        vault_opts=True,
        fork_opts=True,
        module_opts=True,
        subs_opts=True,
        inventory_opts=True,
        pb_opts=True
    ).parse_args([])

    variable_manager

# Generated at 2022-06-23 15:14:06.351491
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars.test import MyVarsModule

    vars_module = MyVarsModule()
    vars_module._load_name = 'test'
    vars_module._original_path = 'test'

    res = get_plugin_vars(None, vars_module, '/my/path', [])
    assert res == {'foo': 'bar'}

    res = get_plugin_vars(None, vars_module, '/my/path', [Host('foo'), Host('bar'), Host('baz')])
    assert res == {'foo': 'bar', 'bar': 'foo', 'baz': 'bar'}

    res = get_plugin_vars(None, vars_module, '/my/path', ['foo', 'bar', 'baz'])

# Generated at 2022-06-23 15:14:11.235493
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    path = os.getcwd()
    host = Host('test', variable_manager={}, loader={})
    group = Host('test', variable_manager={}, loader={})
    entities = [host, group]
    get_plugin_vars({}, {}, path, entities)

# Generated at 2022-06-23 15:14:20.329468
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    # Create plugin to be tested
    class TestVarsPlugin:
        BYPASS_HOST_LOOP = True
        REQUIRES_WHITELIST = True

        def __init__(self, *args, **kwargs):
            pass

        def get_vars(self, *args, **kwargs):
            return {'some_key': 'some_value'}

    # Create a test inventory source path
    host_file_name = os.path.join(os.path.dirname(__file__), 'test_host_file')
    with open(host_file_name, 'w') as new_host_file:
        new_host_file.write('[test_group]\nlocalhost ansible_connection=local\n')

    # Create host/group/loader instance

# Generated at 2022-06-23 15:14:25.069429
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    inventory_source = ['tests/units/inventory/vars_plugins/test_inventory_file']
    entities = [Host('localhost')]
    loader = None
    
    vars_data = get_vars_from_path(loader, inventory_source[0], entities, stage='inventory')
    assert vars_data == {'ansible_test_inventory_vars': True}
    vars_data = get_vars_from_path(loader, inventory_source[0], entities, stage='task')
    assert vars_data == {'ansible_test_inventory_vars': False}

# Generated at 2022-06-23 15:14:28.916995
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    import ansible.plugins.vars.test_vars_plugin as test_vars_plugin

    pl = vars_loader
    pl.add(test_vars_plugin.TestVarsPlugin)

    p = pl.get(name="TestVarsPlugin")

    assert get_plugin_vars(pl, p, "/path/to/file", None) == {'test_vars_plugin_var': 'test_vars_plugin_value'}



# Generated at 2022-06-23 15:14:37.215088
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    # This test is only run if you have the required plugin installed
    # (see requirements.txt in this directory)
    # You can run it with: python -m test.unit.utils.vars_plugins test_get_vars_from_inventory_sources
    # This test requires the plugin to supply a 'host_vars_v2_enabled' variable and a 'group_vars_v2_enabled' variable

    # This is the class and name of the plugin to test
    plugin_name = 'ansible.builtin.vars_plugins.test_vars_plugin'
    plugin_class = vars_loader.get(plugin_name)
    # create an instance of the plugin
    plugin = plugin_class()

    # create a fake AnsibleLoader object
    loader = 'test_loader'

    # Create a fake entity object


# Generated at 2022-06-23 15:14:49.769937
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager

    inventory_manager = InventoryManager()
    variable_manager = VariableManager()

    inventory_manager.load_inventory(inventory_manager.get_inventory_sources())
    variable_manager.set_inventory(inventory_manager)

    host = inventory_manager.get_host('localhost')
    group = inventory_manager.get_group('localhost')

    for stage in ('inventory', 'task'):
        vars_from_inventory_sources = get_vars_from_inventory_sources(
            variable_manager.get_vars_loader(),
            variable_manager._inventory._sources,
            [host, group],
            stage
        )

        assert vars_from_inventory_sources


# Generated at 2022-06-23 15:14:56.291706
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    plugin = {'_load_name': 'plugins.test_plugin', '_original_path': 'plugins/test_plugin.py'}
    class FakePlugin:
        def get_vars(self, loader, path, entities):
            return {'result': 'get_vars'}

        def get_host_vars(self, host):
            return {'result': 'get_host_vars'}

        def get_group_vars(self, group):
            return {'result': 'get_group_vars'}

    assert get_plugin_vars(None, plugin, '', []) == {}
    assert get_plugin_vars(None, plugin, '', ['host']) == {}
    assert get_plugin_vars(None, plugin, '', ['group']) == {}

    plugin = FakePlugin

# Generated at 2022-06-23 15:15:06.060341
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    loader = None
    path = './test/integration/targets'
    entities = ['foo']
    stage = 'inventory'

    vars = get_vars_from_path(loader, path, entities, stage)

    assert vars == {'inventory_dir': './test/integration/targets', 'inventory_dirname': 'targets', 'inventory_file': './test/integration/targets'}, "get_vars_from_path function is failing with path = './test/integration/targets'"

    path = './test/integration/bogus_path'
    vars = get_vars_from_path(loader, path, entities, stage)


# Generated at 2022-06-23 15:15:14.586230
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vault
    plugin = vault.VaultVars()
    loader = lambda: None
    def assert_raises(msg, func, *args, **kwargs):
        try:
            func(*args, **kwargs)
            assert False, msg
        except:
            assert True
    assert_raises("Invalid argument", get_plugin_vars, loader, plugin, None, None)

    assert_raises("Invalid argument", get_plugin_vars, loader, None, None, None)

# Generated at 2022-06-23 15:15:21.523086
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    # Test no_plugins
    entities = [Host("dummyhost")]
    C.RUN_VARS_PLUGINS = 'demand'
    assert get_vars_from_inventory_sources("", "", entities, "inventory") == {}

    # Test plugin
    C.RUN_VARS_PLUGINS = 'yes'
    assert get_vars_from_inventory_sources("", "", entities, "inventory") == {'ansible_variable_priority': 'inventory'}

# Generated at 2022-06-23 15:15:23.040583
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    assert(get_plugin_vars(None, None, None, None) == {})

# Generated at 2022-06-23 15:15:30.332273
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin_base

    class DummyVars(vars_plugin_base.VarsBase):
        def get_vars(self, loader, path, entities):
            return {'key': 'value'}

    vars_plugin_list = [DummyVars()]

    loader = None
    path = "."
    entities = []

    data = {}
    try:
        data = get_plugin_vars(loader, vars_plugin_list[0], path, entities)
    except KeyError:
        pass

    assert 'key' in data and data['key'] == 'value'

# Generated at 2022-06-23 15:15:31.389641
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert isinstance(get_vars_from_path('loader','path','entities','stage'),dict)

# Generated at 2022-06-23 15:15:41.764500
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    # Mock objects
    _loader = None
    _entities = [Host("localhost")]
    _stage = 'task'

    # Mock function
    def _plugin_get_vars(path):
        # Check if path is passed correctly to the plugin
        assert path == _path
        return dict(var1="mock", var2="mock")

    # Mock class
    class _VarsPlugin:
        # Mock attributes
        _load_name = "mock"
        _original_path = "mockpath"
        get_vars = _plugin_get_vars

    # Mock function
    def _vars_loader_all():
        # Assume that there are no other vars plugins
        return [_VarsPlugin()]

    # Mock function

# Generated at 2022-06-23 15:15:48.892059
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    import tempfile
    import shutil

    test_dir = tempfile.mkdtemp(prefix='ansible-test-vars_')
    test_file = tempfile.NamedTemporaryFile(prefix='ansible-test-vars_', dir=test_dir, delete=False)
    test_vars = {'foo': 'bar'}
    test_vars_str = "%s\n" % test_vars
    test_file.write(to_bytes(test_vars_str))
    test_file.close()

    from ansible.inventory.loader import InventoryLoader
    loader = InventoryLoader()
    test_host = Host(name='127.0.0.1')

    vars_result = get_vars_from_path(loader, test_dir, [test_host], 'inventory')
   

# Generated at 2022-06-23 15:16:01.315846
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    host = Host('hostname')
    host_vars = {'host1': {'a': 1, 'b': 2}}
    group = Host('group1')
    group_vars = {'group1': {'a': 1, 'c': 3}}
    loader = "test_loader"
    path = "test_path"
    entities = [host]

    class DeprecatedVarsPluginMock(object):
        def __init__(self):
            self._load_name = 'DeprecatedVarsPluginMock'

        def get_host_vars(self, hostname=None):
            return host_vars

        def get_group_vars(self, groupname=None):
            return group_vars

    deprecated_vars_plugin = DeprecatedVarsPluginMock()
    assert get_plugin_

# Generated at 2022-06-23 15:16:09.506920
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    loader = AnsibleLoader()
    path = './test_data/'
    stage = "all"
    data = get_vars_from_path(loader, path, None, stage)
    assert data['list_of_dicts'] == {'ansible_1': 'ansible_value_1', 'ansible_2': 'ansible_value_2'}
    assert data['simple_dict'] == {'ansible_1': 'ansible_value_1'}
    assert data['ansible_var'] == 'ansible_value'
    assert data['simple_list'] == ['ansible_1', 'ansible_2']
    assert data['simple_string'] == 'ansible_value'

# Generated at 2022-06-23 15:16:17.938986
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    # Test v2 plugin
    vars_plugin_list = list(vars_loader.all())
    plugin = vars_plugin_list[0]
    path = 'path'
    entities = ['entity1', 'entity2']
    data = get_plugin_vars(None, plugin, path, entities)

    # Test v1 plugin (should raise an error)
    plugin_v1 = lambda: None
    plugin_v1.run = 1
    plugin_v1._load_name = 'name'
    plugin_v1._original_path = 'path'

    try:
        get_plugin_vars(None, plugin_v1, path, entities)
    except AnsibleError:
        pass

# Generated at 2022-06-23 15:16:27.936072
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    def test_plugin_v1(self, inventory, cache=True):
        return {'vars': inventory}

    def test_plugin_v2(self, loader, path, entities, cache=True):
        return {'vars': {'path': path, 'entities': entities}}

    from ansible.plugins.loader import vars_loader
    FakePlugin = type('FakePlugin', (object,), dict(get_vars=test_plugin_v1, get_host_vars=test_plugin_v1, get_group_vars=test_plugin_v1))
    FakePlugin2 = type('FakePlugin2', (object,), dict(get_vars=test_plugin_v2))
    vars_loader.add(FakePlugin, 'fake')

# Generated at 2022-06-23 15:16:34.400297
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from collections import namedtuple

    MockPlugin = namedtuple('MockPlugin', ['get_vars'])

    class MockLoader(object):
        pass

    loader = MockLoader()
    plugin = MockPlugin(
        get_vars=lambda x, y, z: {'a': 1}
    )
    plugin.get_vars.__self__ = plugin

    ret = get_plugin_vars(loader, plugin, None, None)
    assert ret == {'a': 1}

# Generated at 2022-06-23 15:16:46.115811
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins import vars_plugins

    class Test_vars_plugin(object):
        class VarsModule(object):
            pass

        def __init__(self):
            self.vars_module = Test_vars_plugin.VarsModule()

        def get_vars(self, loader, path, entities):
            pass

    class Test_loader(object):
        def load_plugin(self, name, path=None, class_only=False):
            assert class_only
            return Test_vars_plugin()

    loader = Test_loader()

    vars_plugin_list = list(vars_loader.all())
    vars_plugin_list.append(Test_vars_plugin())

    data = {}

# Generated at 2022-06-23 15:16:56.871438
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    hostvars_base = "hostvars"
    groupvars_base = "group_vars"
    data = {}
    path = os.path.abspath(os.path.dirname(__file__) + os.sep + 'fixtures/vars_dir')
    # create hostvars and groupvars directory
    hostvars_path = os.path.join(path, hostvars_base)
    os.mkdir(hostvars_path)
    groupvars_path = os.path.join(path, groupvars_base)
    os.mkdir(groupvars_path)
    # create a host and a group
    host = Host(u'localhost')
    entities = [host]

    # check for no plugins
    loader = vars_loader
    plugins_before = len

# Generated at 2022-06-23 15:16:58.882987
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    assert get_vars_from_inventory_sources() == 0


# Generated at 2022-06-23 15:16:59.508140
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert True

# Generated at 2022-06-23 15:17:07.320019
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    class TestVars():
        def __init__(self, name):
            self.name = name
            self.data = {}

        def get_vars(self, loader, path, entities):
            return self.data

    class TestLoader():
        def __init__(self):
            self._entities = [TestVars('test1'), TestVars('test2'), TestVars('test3')]

        def get_all_plugin_objects(self, *args, **kwargs):
            return self._entities

    path = '/test/path'
    entities = {'test3': None, 'test4': None}

    test_loader = TestLoader()
    result = get_vars_from_path(test_loader, path, entities, 'test_stage')


# Generated at 2022-06-23 15:17:15.757146
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    output = {
        'fact_1': 'val1',
        'fact_2': 'val2'
    }
    data = {
        'path': '',
        'entities': []
    }

    class test_object():

        _load_name = 'test_plugin'
        _original_path = '/test/path'

        def get_vars(self, loader, path, entities):
            assert data['path'] == path
            assert data['entities'] == entities
            return output
    plugin = test_object()

    assert output == get_plugin_vars(None, plugin, data['path'], data['entities'])


# Generated at 2022-06-23 15:17:17.649790
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    # Unit test to verify get_plugin_vars is simple.
    pass

# Generated at 2022-06-23 15:17:27.428315
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    from ansible.inventory.manager import InventoryManager

    loader = 'xxx'
    path = 'xxx'
    entities = []
    stage = 'xxx'

    # ansible.plugins.vars.aws_tag
    from ansible.plugins.vars import aws_tag
    plugin = aws_tag.VarsModule()

    data = get_plugin_vars(loader, plugin, path, entities)

    assert data == {}

    # ansible.plugins.vars.bundle_config
    from ansible.plugins.vars import bundle_config
    plugin = bundle_config.VarsModule()

    data = get_plugin_vars(loader, plugin, path, entities)

    assert data == {}
    try:
        data = plugin.get_vars(loader, path, entities)
    except Exception:
        pass

# Generated at 2022-06-23 15:17:29.932343
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    loader, path, entities, stage = None, None, None, None
    assert get_vars_from_path(loader, path, entities, stage) == {}

# Generated at 2022-06-23 15:17:37.011467
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    fake_sources = ['/fake/path/to/roles', '/fake/path/to/ansible.cfg', '/fake/path/to/hosts']
    fake_entities = ['fake.name', 'fake.other']

    fake_loader = object()

    assert get_vars_from_inventory_sources(loader=fake_loader, sources=fake_sources, entities=fake_entities, stage='inventory') == {}

# Generated at 2022-06-23 15:17:41.990639
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    import os

    vars_data = []

    test_data_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), os.pardir, "test_data/vars")

    vars_data.append(get_vars_from_path(vars_loader, test_data_path, "test_plugin", "task"))
    assert vars_data[0] == {'test_plugin': 'task'}

    vars_data.append(get_vars_from_path(vars_loader, test_data_path, "test_plugin", "inventory"))
    assert vars_data[1] == {'test_plugin': 'inventory'}


# Generated at 2022-06-23 15:17:43.675566
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    assert get_vars_from_inventory_sources(None, [], [], None) == {}

# Generated at 2022-06-23 15:17:54.731512
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    inventory_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.getcwd())))
    inventory_dir = os.path.join(inventory_dir, "lib", "ansible", "inventory")
    hosts_file = os.path.join(inventory_dir, "hosts")
    plugin_dirs_file = os.path.join(inventory_dir, "group_vars", "all")

    host = Host('localhost')
    entities = [host]
    sources = [hosts_file, plugin_dirs_file]
    loader = None

    data = get_vars_from_inventory_sources(loader, sources, entities, 'inventory')

    assert(data['foo'] == 'bar')


if __name__ == '__main__':
    test_get_

# Generated at 2022-06-23 15:17:56.580012
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    assert 'foo' == get_plugin_vars(None, None, None, None)

# Generated at 2022-06-23 15:18:03.353914
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import BaseVarsPlugin
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    test_entities = {'test_entities'}

    class TestVarsPlugin(BaseVarsPlugin):

        def get_vars(self, loader, path, entities, cache=True):
            return {'test_var': 'test_value'}

        def get_host_vars(self, host):
            return {'test_var': 'test_value'}

        def get_group_vars(self, group):
            return {'test_var': 'test_value'}

    test_plugin = TestVarsPlugin()


    expected_result = {'test_var': 'test_value'}
    result = get_plugin_vars

# Generated at 2022-06-23 15:18:07.025044
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    loader = None
    path = None
    entities = None
    stage = None

    # If we get here without raising an exception, then the function works
    get_vars_from_path(loader, path, entities, stage)

# Generated at 2022-06-23 15:18:07.658018
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    pass


# Generated at 2022-06-23 15:18:10.996316
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    res = get_vars_from_inventory_sources(None,
                                          [None, 'a,b', 'test', '/tmp/file,abc'],
                                          None,
                                          None)
    assert res == {}

# Generated at 2022-06-23 15:18:16.821773
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    host = Host("host")
    group = Host("group")
    plugin = vars_loader.get("file")
    loader = {}

    # Splat plugin
    data = get_plugin_vars(loader, plugin, "path", [host])
    assert data == {}

    data = get_plugin_vars(loader, plugin, "path", [group])
    assert data == {}

    # V2 plugin
    plugin = vars_loader.get("filev2")
    data = get_plugin_vars(loader, plugin, "path", [host])
    assert data == {}

    data = get_plugin_vars(loader, plugin, "path", [group])
    assert data == {}

    # V1 plugin
    plugin = vars_loader.get("filev1")

# Generated at 2022-06-23 15:18:29.122803
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    def test_plugin_vars(entity):
        return {'test_plugin_vars': entity}
    test_plugin = type('', (object,), {'get_vars': test_plugin_vars})()
    assert get_plugin_vars(None, test_plugin, None, ['test_entity']) == {'test_plugin_vars': 'test_entity'}

    def host_test_plugin_vars(host):
        return {'test_host_plugin_vars': host}
    def group_test_plugin_vars(group):
        return {'test_group_plugin_vars': group}

# Generated at 2022-06-23 15:18:38.385168
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    class MockLoader():
        def __init__(self, path):
            self.path = path

    class MockPlugin():
        def __init__(self, load_name):
            self._load_name = load_name

        def get_vars(self, loader, path, entities):
            return {self._load_name: self._load_name}

    loader = MockLoader('/tmp')
    vars_plugin_list = [MockPlugin('mock1'), MockPlugin('mock2')]
    entities = ['host']

    result = get_vars_from_path(loader, '/tmp', entities, 'task')
    assert len(result.keys()) == 2
    assert result['mock1'] == 'mock1'
    assert result['mock2'] == 'mock2'

# Generated at 2022-06-23 15:18:45.415253
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.vars.manager import VariableManager

    test_path = os.path.expanduser('~/ansible_dir/playbooks')

    loader = AnsibleLoader()
    entities = {'hostvars': {'testhost': {}}, 'group_names': {'testgroup': {}}}

    result = get_vars_from_path(loader, test_path, entities, 'task')

    assert result == loader.get_vars(VariableManager(), test_path, entities)

# Generated at 2022-06-23 15:18:46.664240
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    pass

# Generated at 2022-06-23 15:18:57.952673
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    import os
    import tempfile
    import ansible.plugins.loader as plugin_loader

    loader = plugin_loader.VarsModuleLoader()
    dirpath = tempfile.mkdtemp()
    path = os.path.join(dirpath, 'test.yml')
    with open(path, 'w') as f:
        f.write("""
---
key: value
""")

    vars_plugin_list = [
        plugin_loader.get('v2_variables.YamlVars'),
        plugin_loader.get('IniVars')
    ]

    for plugin in vars_plugin_list:
        data = get_vars_from_path(loader, path, [], 'inventory')
        assert 'key' in data
        assert data['key'] == 'value'

# Generated at 2022-06-23 15:19:06.764416
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    loader = 'AnsibleLoader'
    sources = ['/home/ansible/playbooks/aws-vars', '/etc/ansible/playbooks/home/aws-vars']
    inventory = 'AnsibleInventory'
    locals = ['/home/ansible/playbooks/aws-vars', '/etc/ansible/playbooks/home/aws-vars', '/home/ansible/playbooks/aws-vars', '/etc/ansible/playbooks/home/aws-vars', '/home/ansible/playbooks/aws-vars', '/etc/ansible/playbooks/home/aws-vars']
    stage = 'all'
    data = get_vars_from_inventory_sources(loader, sources, inventory, stage, locals)
    assert data == {'ansible_connection': 'local'}

# Generated at 2022-06-23 15:19:17.556354
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    # pylint: disable=unused-variable
    class InvalidVarsPluginA:
        # missing get_vars
        pass

    class InvalidVarsPluginB:
        # missing get_vars
        def get_group_vars(self, group):
            return {}

    class ValidVarsPluginV1:
        # valid v1 plugin
        def get_group_vars(self, group):
            return {}

    class ValidVarsPluginV2:
        # valid v2 plugin
        def get_vars(self, loader, path, entities):
            return {}

    class ValidVarsPluginV3:
        # valid v3 plugin
        def get_vars(self, loader, path, entities, cache=None):
            return {}
