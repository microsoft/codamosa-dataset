

# Generated at 2022-06-23 15:09:21.996402
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    sources = ['/tmp/inventory']
    entities = [Host('host1', port=22)]
    stage = 'inventory'

    assert get_vars_from_path(loader, '/tmp/inventory', entities, stage) == {}

# Generated at 2022-06-23 15:09:29.833625
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader

    vars_plugin_list = list(vars_loader.all())
    for plugin_name in C.VARIABLE_PLUGINS_ENABLED:
        if AnsibleCollectionRef.is_valid_fqcr(plugin_name):
            vars_plugin = vars_loader.get(plugin_name)
            if vars_plugin is None:
                # Error if there's no play directory or the name is wrong?
                continue
            if vars_plugin not in vars_plugin_list:
                vars_plugin_list.append(vars_plugin)

    print(vars_plugin_list)


# Generated at 2022-06-23 15:09:40.500360
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    # load vars plugin
    test_loader = vars_loader
    test_plugin = test_loader.get('test_vars_plugin')

    # load test inventory
    test_path = '/tmp/test_vars/'
    test_host = Host('test_host')
    test_group = test_host.get_group('test_group')

    # load test setting
    test_entities = [test_host, test_group]

    # run plugin
    result = get_plugin_vars(test_loader, test_plugin, test_path, test_entities)

    # check result
    assert result.items() == dict(test_vars_plugin_host={'test_host': 'OK'},
                                  test_vars_plugin_group={'test_group': 'OK'}).items()

# Generated at 2022-06-23 15:09:41.296943
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    pass

# Generated at 2022-06-23 15:09:50.692238
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.plugins.vars import test_var_a

    vars_plugin_list = list(vars_loader.all())

    for plugin in vars_plugin_list:
        plugin._load_name = 'test_var'  # ignore the list of enabled plugins and explicitly test the test_var plugin
        data = get_vars_from_path(plugin, '', '', '', '')

        assert(len(data) == 1)
        assert(list(data.keys())[0] == 'test_var')
        assert(list(data.values())[0] == 'test_var_a')

# Generated at 2022-06-23 15:09:57.244801
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    plugin_loader = vars_loader._create_plugin_loader()
    # Get the vars plugins
    plugin_loader.search_paths = [os.path.join(x[1], 'vars') for x in (
        pkgutil.iter_modules(ansible_vars.__path__))]

    fake_loader = DataLoader()
    inv_manager = InventoryManager(loader=fake_loader)
    sources = [os.path.join(os.path.dirname(__file__), 'vars_plugins')]
    var_structure = get_vars_from_path(inv_manager, sources, [], 'task')

    # Test the output

# Generated at 2022-06-23 15:10:06.669967
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.module_utils.common._collections_compat import MutableMapping

    class vars_plugin_impl():
        # Older plugins
        def get_host_vars(self, host):
            return {"plugin_return_val": host}

        def get_group_vars(self, group):
            return {"plugin_return_val": group}

        # Newer plugins
        def get_vars(self, loader, path, entities, cache=True):
            return {"plugin_return_val": path}

    vars_plugin_impl._load_name = 'vars_plugin_impl'
    vars_plugin_impl._original_path = './my_vars_plugin_impl.py'


# Generated at 2022-06-23 15:10:12.119458
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    vars_plugins = vars_loader.all()
    assert len(vars_plugins) == 0
    assert get_vars_from_path(None, None, None) == {}


if __name__ == '__main__':
    import sys
    import pytest
    sys.exit(pytest.main([__file__]))

# Generated at 2022-06-23 15:10:21.623987
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    collection_name = 'test_collection'
    collection_path = os.path.join(os.path.dirname(__file__), 'data/collection_fixtures/test_collection')
    collection_version = '1.0.0'
    ansible_collection_loader = C.config._ansible_collection_loader
    collection = ansible_collection_loader.load_collection_from_dir(collection_name, collection_path, collection_version)

    # Test that plugin with get_vars(self, loader, path, entities) method works
    # Test that plugin with get_group_vars(self, group) and get_host_vars(self, host) methods works
    host = Host('example.com', port=10)
    plugin_name = 'test_vars'
    plugin_path = collection.get_config

# Generated at 2022-06-23 15:10:34.045770
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.module_utils._text import to_native
    from ansible.plugins.loader import vars_loader
    from ansible.utils.collection_loader import AnsibleCollectionRef
    from ansible.utils.collection_loader import AnsibleCollectionRef

    plugin_list = list(vars_loader.all())
    assert len(plugin_list) > 0

    selected_plugin_list = []
    for plugin in plugin_list:
        if plugin._load_name in C.VARIABLE_PLUGINS_ENABLED:
            selected_plugin_list.append(plugin)
        elif not getattr(plugin, 'REQUIRES_WHITELIST', False):
            # this allows us to pre-load and test plugins that are not included in the default
            # collection for testing purposes
            selected_plugin_list.append

# Generated at 2022-06-23 15:10:38.115242
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    loader = AnsibleCollectionRef.load_collection()
    path = '/home/wbali/workspace/ansible/vars/host.py'
    entities = []
    stage = 'inventory'
    data = get_vars_from_path(loader, path, entities, stage)
    assert data['tmp1'] == 'A'

# Generated at 2022-06-23 15:10:48.873552
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    import os

    import pytest
    from ansible.inventory.host import Host
    from ansible.plugins.loader import vars_loader

    # Create the vars plugin
    class TmpPlugin:
        class vars:
            def __init__(self, loader, path, entities, filename):
                self.entities = entities
                self.filename = filename

            def run(self, **kwargs):
                return {self.filename: self.entities}

    TmpVarsPlugin = TmpPlugin()
    # Create a temporary plugin folder in the current directory
    tmp_folder = os.path.join(os.path.dirname(__file__), 'var_plugins')
    os.makedirs(tmp_folder)

# Generated at 2022-06-23 15:10:58.750868
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    loader = None
    sources = ["/etc/ansible/hosts", "/etc/ansible/hosts"]
    entities = []
    stage = "inventory"
    assert True == get_vars_from_inventory_sources(loader, sources, entities, stage)

    sources = ["/etc/ansible/hosts", "/etc/ansible/hosts"]
    entities = None
    stage = "inventory"
    assert True == get_vars_from_inventory_sources(loader, sources, entities, stage)

    sources = ["/etc/ansible/hosts", "/etc/ansible/hosts"]
    entities = []
    stage = "task"
    assert True == get_vars_from_inventory_sources(loader, sources, entities, stage)


# Generated at 2022-06-23 15:11:08.744610
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    class TestVarPlugin:

        def get_vars(self, loader, path, entities):
            return dict(this_is='get_vars')

        def get_group_vars(self, name):
            return dict(group=name)

        def get_host_vars(self, name):
            return dict(host=name)

    class TestVarPluginV2:

        def get_vars(self, loader, path, entities, cache=True):
            return dict(this_is='get_vars')

        def get_group_vars(self, name, cache=True):
            return dict(group=name)


# Generated at 2022-06-23 15:11:14.669626
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import dict_vars
    from ansible.inventory.manager import InventoryManager
    hosts = InventoryManager(['localhost', '127.0.0.1'])
    loader = None
    entities = list(hosts.hosts.values())
    plugin = dict_vars.VarsModule()
    plugin.set_options({'hosts': ['localhost']})
    path = '.'
    result = get_plugin_vars(loader, plugin, path, entities)
    assert result.get('ansible_hostname') == 'localhost'

# Generated at 2022-06-23 15:11:21.454073
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    """
    make a simple vars plugin, host and group object and run the function
    """

    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import vars_loader

    class TestVarsPlugin(object):
        def get_vars(self, loader, path, entities):
            return {'test': 'foo'}

    vars_loader._cache[('testvars',)] = TestVarsPlugin()

    C.VARIABLE_PLUGINS_ENABLED = ['testvars']

    inv = InventoryManager(loader=None, sources="/path/to/inventory")

    h = Host(name='localhost')
    g = Group(name='foo')
    inv.add_group(g)
    inv.add_host(h)

    result = get_vars_from_inventory

# Generated at 2022-06-23 15:11:29.499507
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()

    sources = [__file__.replace('.pyc', '.py')]

    # testing groups
    groups = [{'name': 'group_1', 'vars': {'group_var_1': 'group_var_1_value'}},
              {'name': 'group_2', 'vars': {'group_var_2': 'group_var_2_value'}},
              {'name': 'group_3', 'vars': {'group_var_3': 'group_var_3_value'}}]

    retval = get_vars_from_inventory_sources(loader, sources, groups, 'inventory')

# Generated at 2022-06-23 15:11:40.738408
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.script import InventoryScript
    from ansible.plugins import vars_plugins
    from ansible.plugins.loader import vars_loader

    # create a script source
    src = InventoryScript(name='fake')
    src.vars = {'foo': 'bar'}

    # create a plugin (it will have a base path of '<cwd>/test/units/modules/test_plugins/test_plugin_path')
    vars_plugin = type('TestVarsPlugin', (vars_plugins.BaseVarsPlugin,), {'_load_name': 'test_vars'})
    vars_loader.add(vars_plugin, 'test_plugins/test_plugin_path')
    vars_loader.all()

    # get vars from the script source and the plugin
    vars = get

# Generated at 2022-06-23 15:11:48.861049
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    # Create fake plugin
    import mock
    from ansible.plugins.loader import vars_loader

    fake_plugin = type(
        'test_get_vars_from_inventory_sources_plugin',
        (object,),
        dict(
            _load_name = 'test_get_vars_from_inventory_sources',
            get_vars = mock.Mock(return_value = {'plugin_key': 'plugin_value'}),
        )
    )

    # Make sure it isn't loaded before we add it
    assert fake_plugin not in vars_loader.all()

    # Add to plugins loader
    vars_loader.add(fake_plugin)
    assert fake_plugin in vars_loader.all()

    # Create fake loader
    from ansible.inventory.manager import InventoryManager
   

# Generated at 2022-06-23 15:11:55.202635
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    class MockLoader:
        pass

    class MockPlugin:
        _load_name = 'TestPlugin'
        _original_path = '/nonexistent/'

        def get_vars(self, loader, path, entities):
            return {'test_succeed_dict': True}

    loader = MockLoader()
    plugin = MockPlugin()
    path = '/nonexistent/'
    entities = []

    mock_data = get_plugin_vars(loader, plugin, path, entities)

    assert mock_data == {'test_succeed_dict': True}

# Generated at 2022-06-23 15:12:05.606097
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['test/ansible/vars_plugins/inventory_plugins'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    play_context.network_os = 'junos'
    play_context.remote_addr = "1.1.1.1"

    host = inventory.get_host('testing')

# Generated at 2022-06-23 15:12:16.535168
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.vars.host_group import VarPlugins
    from ansible.vars.plugins.jails import VarsModule as JailsVarsModule
    from ansible.vars.plugins.solaris_zones import VarsModule as SolarisZonesVarsModule

    loader = InventoryManager(paths=[])

    mock_plugin = VarPlugins()
    mock_plugin.run = lambda *args, **kwargs: [{'group_name': 'hostname', 'hosts': ['host1']}]
    mock_plugin.get_vars = lambda *args, **kwargs: {}
    mock_plugin.get_host_vars = lambda *args, **kwargs: {'hostname': 'host1'}
    mock_plugin.get_group

# Generated at 2022-06-23 15:12:21.070949
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    loader = 'fake_loader'
    sources = ['fake_source']
    entities = ['fake_entity']
    stage = 'fake_stage'

    data = get_vars_from_inventory_sources(loader, sources, entities, stage)

    assert data['__ansible_loader__'] == loader

# Generated at 2022-06-23 15:12:31.485865
# Unit test for function get_vars_from_path

# Generated at 2022-06-23 15:12:41.079735
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    loader = C.DEFAULT_INVENTORY_LOADER
    source = "/tmp/bogus"
    var_mgr = VariableManager()

    inv = InventoryManager(loader=loader, sources=source)
    assert not get_vars_from_path(loader, source, [inv], 'inventory')

    var_mgr.set_inventory(inv)
    assert not get_vars_from_path(loader, source, [inv], 'inventory')

    inv.add_group('foobar')

    assert not get_vars_from_path(loader, source, [inv], 'inventory')

# Generated at 2022-06-23 15:12:51.327140
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    import pytest
    from ansible.plugins.loader import vars_loader

    class MyPlugin:
        def __init__(self):
            self.name = 'MyPlugin'
            self.type = 'vars'

        def get_vars(self, loader, path, entities, cache=True):
            return dict(a=1)

    class MyPlugin2:
        def __init__(self):
            self.name = 'MyPlugin2'
            self.type = 'vars'

        def get_host_vars(self, hostname):
            return dict(b=2)

    class MyPlugin3:
        def __init__(self):
            self.name = 'MyPlugin3'
            self.type = 'vars'

        def get_host_vars(self, hostname):
            return dict

# Generated at 2022-06-23 15:12:52.086138
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert callable(get_vars_from_path)

# Generated at 2022-06-23 15:12:53.747373
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    # TODO: need to figure out how to setup tests for this
    pass

# Generated at 2022-06-23 15:13:05.967123
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.loader import var_plugins

    plugin = var_plugins.get('systeminfo')
    entities = [Host('localhost')]
    data = get_plugin_vars({}, plugin, '.', entities)
    assert 'ansible_facts' in data
    assert type(data['ansible_facts']) is dict
    assert 'system_info' in data['ansible_facts']
    assert type(data['ansible_facts']['system_info']).__name__ == 'dict'
    assert 'distribution' in data['ansible_facts']['system_info']
    assert type(data['ansible_facts']['system_info']['distribution']).__name__ == 'str'


# Unit tests for function get_vars_from_path

# Generated at 2022-06-23 15:13:08.633898
# Unit test for function get_vars_from_path

# Generated at 2022-06-23 15:13:16.565050
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    import tempfile
    import shutil
    # Create temporary directory
    temp_dir = tempfile.mkdtemp()
    # Create temporary plugin under temporary directory
    plugin_dir = os.path.join(temp_dir, 'plugins')
    os.makedirs(plugin_dir)
    # Create a sample vars plugin
    plugin_file = os.path.join(plugin_dir, 'vars_plugin.py')

# Generated at 2022-06-23 15:13:17.547438
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    pass


# Generated at 2022-06-23 15:13:20.807885
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    data = get_vars_from_path(vars_loader, '/home/sandeep/projects/ansible/infrastructure/', ['test'], 'play')
    print (data)

# Generated at 2022-06-23 15:13:32.641637
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.inventory.data import InventoryData
    loader = MockedLoader()

    # Testing vars plugin - get_vars
    plugin = MockedPluginVars1()
    path = os.path.dirname(__file__)
    entities = InventoryData()._entities_for_path([path])
    data = get_plugin_vars(loader, plugin, path, entities)
    assert data['name'] == 'hello'

    # Testing vars plugin - get_host_vars
    plugin2 = MockedPluginVars2()
    path = os.path.dirname(__file__)
    entities = InventoryData()._entities_for_path([path])
    data = get_plugin_vars(loader, plugin2, path, entities)
    assert data['name'] == 'hello2'


# Unit test

# Generated at 2022-06-23 15:13:39.547242
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager

    inv = InventoryManager(loader=None, sources=None)
    inv.set_inventory(['127.0.0.1'])
    path = '/'
    host = list(inv.get_hosts('all'))[0]
    group = list(inv.groups.values())[0]
    entities = [host, group]

    vars_plugin_list = list(vars_loader.all())
    vars_plugin_list.append(object)

    # to test if the error message is correct
    data = get_vars_from_path(None, path, entities, 'task')
    assert isinstance(data, dict)

# Generated at 2022-06-23 15:13:43.332586
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    # No inventory sources
    assert {} == get_vars_from_inventory_sources(None, [], [], 'inventory')

    # None path in inventory sources
    assert {} == get_vars_from_inventory_sources(None, [None, None], [], 'inventory')

    # Path is "," in inventory sources
    assert {} == get_vars_from_inventory_sources(None, [None, ','], [], 'inventory')

# Generated at 2022-06-23 15:13:54.190733
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    try:
        get_vars_from_inventory_sources(None, None, None)
    except TypeError:
        pass
    else:
        assert False, 'get_vars_from_inventory_sources() did not raise TypeError'

    try:
        get_vars_from_inventory_sources(None, ['example1/hosts', 'example2/hosts'], None)
    except TypeError:
        pass
    else:
        assert False, 'get_vars_from_inventory_sources() did not raise TypeError'

    try:
        get_vars_from_inventory_sources(None, [None], None)
    except TypeError:
        pass
    else:
        assert False, 'get_vars_from_inventory_sources() did not raise TypeError'


# Generated at 2022-06-23 15:13:55.922785
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    assert get_vars_from_path(object, object, object, object) is not None

# Generated at 2022-06-23 15:14:03.903371
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.loader import vars_loader

    class FakePlugin:
        def get_vars(self, loader, path, entities):
            return {'username': 'rachel'}

    vars_loader.add(FakePlugin())

    fake_var_provider = vars_loader.all()[0]
    fake_var_provider.get_vars('loader', 'path', 'entities') == {'username': 'rachel'}

# Generated at 2022-06-23 15:14:15.822730
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    class my_vars_class:
        def __init__(self, name):
            self._load_name = name
            self._original_path = name
            self.get_vars = lambda x, y, z: {'name': name}

    class vars_loader_class:
        def __init__(self, methods):
            self._methods = methods

        def all(self):
            return self._methods

    class loader_class:
        def __init__(self, plugins):
            self.vars = vars_loader_class(plugins)

    class host_class:
        def __init__(self, name):
            self.name = name


# Generated at 2022-06-23 15:14:18.963883
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert get_vars_from_path(None, '/home/ansible/test', None, 'inventory') == {'test': {'test1': 'test2'}}

# Generated at 2022-06-23 15:14:27.231471
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from .constants import TEST_INSTALL_FOLDER

    # Non-existent inventory sources should not raise an exception, but should not include results
    sources = [
        '/non/existent/path/to/inventory/source',
        '/non/existent/path/to/inventory/source/ansible.cfg',
    ]
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=sources)
    get_vars_from_inventory_sources(loader, sources, [inventory.get_host('example.com')], 'task')

    # A file can be both a source and a directory, but should not be double counted

# Generated at 2022-06-23 15:14:36.486427
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager
    from ansible.module_utils.common.collections import ImmutableDict
    inventory = InventoryManager(loader=None, sources=os.path.join(os.path.dirname(__file__), '../../../../examples/hosts'))
    sources_list = [os.path.join(os.path.dirname(__file__), '../../../../examples/hosts')]
    data = get_vars_from_path(None, sources_list[0], inventory.get_groups_dict()['all'].get_hosts(), 'inventory')
    expected_value = ImmutableDict({'http_port': 80, 'var1': 'value1', 'var2': ['a','b','c']})

# Generated at 2022-06-23 15:14:48.820568
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    import sys
    import unittest
    from ansible.plugins.loader import vars_loader

    class TestVarsPlugin(object):
        def get_vars(self, loader, path, entities):
            return {'test_var': 'foo'}

    class TestVarsPlugin2(object):
        def get_vars(self, loader, path, entities):
            return {'test_var_2': 'bar'}

    class TestVarsPlugin3(object):
        def get_host_vars(self, host):
            return {'test_var_3': 'baz'}

        def get_group_vars(self, group):
            return {'test_var_4': 'baz'}


# Generated at 2022-06-23 15:14:51.914257
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    # TODO: comment out these lines when we switch to the main plugin loader
    loader = None
    entities = []

    data = get_vars_from_path(loader, '/some/path', entities, 'inventory')
    assert data == {}

# Generated at 2022-06-23 15:14:55.280470
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    assert get_vars_from_inventory_sources(None, ["/path/to/dir1", None, "/path/to/dir2"], [], "start") == {}

# Generated at 2022-06-23 15:15:03.157367
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    data = {'k': 'v'}
    loader = {}
    path = 'path'
    entities = ['entities']
    stage = 'inventory'
    vars_loader.all = lambda: [
        plugin(loader=loader, path=path)
        for plugin in (AnsibleCoreVarsPlugin, NonePlugin, NoGetVarsPlugin, NoRunPlugin, InvalidPlugin)
    ]
    with display.override_logger(name='vars'):
        assert get_vars_from_path(loader, path, entities, stage) == data



# Generated at 2022-06-23 15:15:16.181213
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    '''
    Test get_vars_from_inventory_sources
    :return:
    '''
    display.verbosity = 2
    os.environ['ANSIBLE_SHOW_CUSTOM_STATS'] = '1'

    module_path = os.path.join(os.path.dirname(__file__), '../../')

    # we skip this test if the config module is not accessible to us
    try:
        from ansible.config import defaults as config_def
    except ImportError:
        print('Skipping, no config module found')
        return

    config_def.DEFAULT_BECOME_METHOD = 'sudo'
    config_def.ANSIBLE_CONFIG = os.path.join(module_path, "test/units/config/ansible.cfg")
    config_def.DE

# Generated at 2022-06-23 15:15:27.484036
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    # Test 1: get_plugin_vars return the expected data
    files_path = os.path.join(os.path.dirname(__file__), '../fixtures/module_utils/vars_plugins_test.py')
    vars_loader.add_directory(files_path)

    plugin_name = 'vars_plugins_test'
    plugin = vars_loader.get(plugin_name)
    if plugin is None:
        raise AnsibleError("Cannot use v1 type vars plugin %s from %s" % (plugin_name, plugin.original_path))
    data = get_plugin_vars(None, plugin, '/data/somepath', ['some_var'])
    assert {'somekey': 'some_var'} == data

    # Test 2: get_plugin_vars raises error if

# Generated at 2022-06-23 15:15:28.108999
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    assert True

# Generated at 2022-06-23 15:15:29.152636
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    try:
        get_vars_from_path(None, '', [])
    except:
        pass

# Generated at 2022-06-23 15:15:39.573084
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    loader = None
    path = '/path/to/file'
    entities = ['host1', 'group1']
    stage = 'inventory'

    # test plugin name in C.VARIABLE_PLUGINS_ENABLED
    plugin_name = 'name_in_C_VARIABLE_PLUGINS_ENABLED'
    plugin = MagicMock()
    plugin.get_host_vars.return_value = {'hosts': 'hosts_vars_data'}
    plugin.get_group_vars.return_value = {'groups': 'groups_vars_data'}
    plugin._load_name = plugin_name
    plugin._original_path = '/path/to/plugin'
    vars_loader.all = MagicMock(return_value=[plugin])
    C.VARIA

# Generated at 2022-06-23 15:15:43.039385
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    loader = None
    sources = [b'/tmp/non_existent/file.yml']
    entities = ["not relevant for this test"]
    stage = "not relevant for this test"
    assert get_vars_from_inventory_sources(loader, sources, entities, stage) == {}

# Generated at 2022-06-23 15:15:47.273454
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    import datetime
    from ansible.plugins.loader import vars_loader
    from ansible.utils.collection_loader import AnsibleCollectionRef

    v = vars_loader.all()
    data = {}

    for plugin in v:
        data = combine_vars(data, get_plugin_vars(None, plugin, "./scripts/", []))

    assert isinstance(data, dict)


# Generated at 2022-06-23 15:15:51.219739
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    loader = None
    sources = ['/foo/bar', None]
    entites = ['host1', 'host2']
    stage = 'task'
    assert get_vars_from_inventory_sources(loader, sources, entites, stage)['host1'] == None

# Generated at 2022-06-23 15:16:03.378636
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    basedir = os.path.dirname(os.path.realpath(__file__))
    inventory_dir = os.path.join(basedir, 'vars_plugins')
    loader = DataLoader()
    inventory_loader = loader.get_single_data_source(
        to_bytes(os.path.join(inventory_dir, 'inventory.yml')))
    inventory_sources = inventory_loader.get('inventory_sources')
    display.verbosity = 1
    vars_manager = VariableManager()

# Generated at 2022-06-23 15:16:14.285837
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    # ----------------------------------------------------------------
    #
    # ----------------------------------------------------------------
    class MockHost(object):
        def __init__(self, name):
            self.name = name

#    # ----------------------------------------------------------------
#    #
#    # ----------------------------------------------------------------
#    class MockVarsLoader(object):
#        def __init__(self):
#            self.names = []
#
#    def mock_vars_loader_all():
#        return self.names

    # ----------------------------------------------------------------
    #
    # ----------------------------------------------------------------
    class MockVarsPlugin(object):

        def __init__(self, name):
            self._load_name = name
            self._original_path = '_' + name

    # ----------------------------------------------------------------
    #
    # ----------------------------------------------------------------
    class MockModule(object):

        def __init__(self):
            pass

        def run(self):
            pass

   

# Generated at 2022-06-23 15:16:18.281482
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    """
    :return:
    """
    import ansible
    plugins_path = ansible.utils.plugins.__path__._path[0]
    data = get_vars_from_path(None, plugins_path, ['localhost'], 'task')
    assert 'ansible_python_version' in data
    ansible.utils.plugins.__path__._path = []

# Generated at 2022-06-23 15:16:22.464594
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.loader import vars_loader
    entities = ['test_host']
    path = 'test_path'
    loader = 'test_load'
    vars_plugins = vars_loader.all()
    for plugin in vars_plugins:
        get_plugin_vars(loader, plugin, path, entities)

# Generated at 2022-06-23 15:16:30.652837
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.utils.collection_loader import AnsibleCollectionRef
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.parsing.dataloader import DataLoader
    from ansible.collections.ansible.testns.plugins.vars import DummyVarsPlugin
    from ansible.collections.ansible.testns.plugins.module_utils.my_utils import DummyModuleUtilsVarsPlugin

    display = Display()
    loader = DataLoader()

    test_name = 'dummy'
    test_vars_value = {test_name : 'value'}
    plugin_list = list(vars_loader.all())

    # enable testns.plugins vars plugin
   

# Generated at 2022-06-23 15:16:38.544219
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import vars_loader
    loader = DataLoader()
    loader.set_basedir('/etc/ansible/roles')
    manager = InventoryManager(loader=loader, sources=['/dev/null'])
    all = manager.groups_list()
    display_all = ", ".join([x.name for x in all])
    display(display_all)
    assert display_all == "all"
    all = get_vars_from_inventory_sources(loader, ['/dev/null'], all, 'inventory')
    display_all = ", ".join([x for x in all])

# Generated at 2022-06-23 15:16:50.494403
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    im = InventoryManager(loader=loader, sources=['test/static/test_static_inventory.yml'])
    vm = VariableManager(loader=loader, inventory=im)

    data = get_vars_from_inventory_sources(loader, [C.DEFAULT_HOST_LIST], vm.hosts.values(), 'command')
    assert len(data) == 1
    data = get_vars_from_inventory_sources(loader, [C.DEFAULT_HOST_LIST], vm.groups.values(), 'command')
    assert len(data) == 1

    data = get_vars_from_inventory_

# Generated at 2022-06-23 15:16:57.742823
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    sources = ['/test/test.yml', '/test/test1.yml', None, 'localhost,127.0.0.1']
    test_data = {
        'test': 'test',
        'test1': 'test1',
        'test2': 'test2',
        'test3': 'test3'
    }
    load_data = get_vars_from_inventory_sources('', sources, [[sources[0]]], '')
    assert load_data == test_data


__all__ = ['get_vars_from_path', 'get_vars_from_inventory_sources']

# Generated at 2022-06-23 15:17:00.466014
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    loader = 'ansible.parsing.dataloader.DataLoader'
    sources = ['/etc/ansible/hosts']
    entities = ['localhost']
    stage = 'inventory'

    testdata = get_vars_from_inventory_sources(loader, sources, entities, stage)

    assert testdata is not None

# Generated at 2022-06-23 15:17:10.563897
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.vars.printer import get_vars_from_path
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    vars_plugin_list = list(vars_loader.all())
    sources = ['./test/units/parsing/yaml/group_vars/group_vars_host.yml']
    stage = 'inventory'
    entities = []
    result = get_vars_from_path(loader, sources, entities, stage)

    assert to_bytes(result) == b'{u\'host\': {u\'hostname\': u\'localhost\', u\'arch\': u\'x86_64\'}}'

# Generated at 2022-06-23 15:17:19.025665
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    """
    Test get_vars_from_inventory_sources with a fake inventory source
    """
    # Create a fake inventory source in a temporary directory
    # and add a vars file with a variable "test_var" to it.
    # The loader must be set to "true" otherwise a deprecation
    # warning will be displayed.
    path = tempfile.mkdtemp()
    inventory_source_path = os.path.join(path, 'inventory_source')
    with open(inventory_source_path, 'w') as inventory_source:
        inventory_source.write(
            '[group1]\n'
            'localhost\n'
            '[group2:vars]\n'
            'test_var=foo\n'
        )
    loader = DataLoader()
    loader.set_vault_sec

# Generated at 2022-06-23 15:17:28.252264
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    import unittest
    import tempfile

    from ansible.module_utils.six import StringIO, text_type
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play

    # setup the inventory
    test_host_name = 'test_host'
    test_group_name = 'test_group'
    test_group_var_name = 'test_group_var'
    test_group_var_value = 'test_group_var_value'

    test_group = {test_group_name: {'hosts': [test_host_name], test_group_var_name: test_group_var_value}}
    loader = DataLoader()

# Generated at 2022-06-23 15:17:35.293174
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin

    class test_plugin(vars_plugin):

        def get_vars(self, loader, path, entities):
            return {'test_plugin': 'get_vars'}

    data = get_plugin_vars(None, test_plugin(), None, [])
    assert data == {'test_plugin': 'get_vars'}


# Generated at 2022-06-23 15:17:43.590677
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.common._collections_compat import MutableMapping
    import os

    #set debug to True to see details
    debug = False

    # Make a test inventory source
    test_inventory_dir = os.path.join(os.getcwd(), "test_inventory")
    if not os.path.isdir(test_inventory_dir):
        os.mkdir(test_inventory_dir)

# Generated at 2022-06-23 15:17:51.484384
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    display.verbosity = 5
    cur_cwd = os.getcwd()
    C.DEFAULT_ROLES_PATH = os.path.join(cur_cwd, u'tests', u'roles')
    a, b, c = get_vars_from_inventory_sources(cur_cwd, entities=list(), stage='inventory')
    print(a)
    print(b)
    print(c)


if __name__ == "__main__":
    test_get_vars_from_inventory_sources()

# Generated at 2022-06-23 15:18:00.245982
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.vars.plugin_vars import AnsibleTowerVars
    class AnsibleTowerVarsTest():

        def get_vars(self, loader, path, entities):
            print('get_vars')
            return {'k': 'v'}

        def get_host_vars(self, host):
            print('get_host_vars')
            return {'k_host': 'v_host'}

        def get_group_vars(self, group):
            print('get_group_vars')
            return {'k_group': 'v_group'}

    atv = AnsibleTowerVars()
    assert get_plugin_vars(None, AnsibleTowerVarsTest(), None, None) == {'k': 'v'}
    assert get_plugin_v

# Generated at 2022-06-23 15:18:07.991187
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    # get_plugin_vars(self, path, entities, cache=True):
    # Here, entities is either a host or a group
    # test get_plugin_vars without error
    host = Host('localhost')
    assert isinstance(get_plugin_vars(None, vars_plugin_list[0], '/etc/ansible/hosts', host), dict)
    # test get_plugin_vars with error
    #assert isinstance(get_plugin_vars(vars_plugin_list[0], '/etc/ansible/hosts', host), dict)



# Generated at 2022-06-23 15:18:09.575234
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    # TODO: Create test
    pass


# Generated at 2022-06-23 15:18:15.637104
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.cli.galaxy import GalaxyCLI
    cli_galaxy = GalaxyCLI(args=[])
    from ansible.config.manager import ConfigManager
    from ansible.utils.vars import combine_vars
    C.VARIABLE_PLUGINS_ENABLED = ['galaxy']
    C.RUN_VARS_PLUGINS = 'all'
    config_manager = ConfigManager(cli_galaxy.options, [])
    loader = config_manager.get_loader()

    data = {}
    sources = [None, "../ansible/test/test_inventory_vars"]
    entities = [Host("test1"), Host("test2")]

    data = combine_vars(data, get_vars_from_inventory_sources(loader, sources, entities, 'inventory'))



# Generated at 2022-06-23 15:18:27.000952
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.plugins.loader import vars_loader

    plugin_list = list(vars_loader.all())

    # For vars_loader, we want to use the follow config
    C.VARIABLE_PLUGINS_ENABLED = ['vars_python.my_var_1', 'vars_python.my_var_2', 'vars_python.my_var_3']

    sources = ['host', 'group']
    entities = ['host', 'group']

    # Test for stage='inventory'
    C.RUN_VARS_PLUGINS = 'all'

    data = get_vars_from_inventory_sources(None, sources, entities, 'inventory')

    assert data['my_var_1'] == 'var_1'

# Generated at 2022-06-23 15:18:29.877369
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.vars.host_group_vars import VarsModule
    assert {} == get_vars_from_path(None, 'path', [], 'inventory') is None

# Generated at 2022-06-23 15:18:41.076369
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    collection_loader = AnsibleCollectionLoader()
    # This collection contains a vars plugin called test_vars.py
    collection_loader.add_collection_path("ansible_collections/test_ns/test_coll")
    plugin = collection_loader.get("test_ns.test_coll.test_vars")
    # This plugin reads a file from the directory that holds the plugin
    plugin_dir = plugin._original_path
    # env var ANSIBLE_COLLECTIONS_PATHS must include the collections path
    # for the AnsibleCollectionLoader to find the collection
    os.environ['ANSIBLE_COLLECTIONS_PATHS'] = "ansible_collections"
    # This test uses a mocked AnsibleLoader

# Generated at 2022-06-23 15:18:42.271220
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    # TODO: Add unittest
    pass

# Generated at 2022-06-23 15:18:53.666960
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    vars_plugin_list = [vars_loader.get(plugin) for plugin in C.VARIABLE_PLUGINS_ENABLED]
    plugin_name = C.VARIABLE_PLUGINS_ENABLED[0]
    vars_plugin = vars_loader.get(plugin_name)

    # Test Failed
    if vars_plugin_list != [vars_plugin]:
        return (1, "vars_plugin_list is not same for all plugins")

    # Test Success with same path
    test_plugin = vars_loader.get(plugin_name)
    plugin_data = get_plugin_vars(None, test_plugin, None, None)
    data = get_vars_from_path(None, None, None, None)

# Generated at 2022-06-23 15:19:00.839115
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    class TestClass(object):
        def __init__(self):
            self._load_name = 'testclass'
            self._original_path = 'tests/unit/plugins/vars/test.py'

    class TestClass1(TestClass):
        def get_vars(self, loader, path, entities):
            return {'a': 11, 'b': 22}

    assert get_plugin_vars(None, TestClass(), None, None) == {}
    assert get_plugin_vars(None, TestClass1(), None, None) == {'a': 11, 'b': 22}

# Generated at 2022-06-23 15:19:02.112197
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert get_vars_from_path is not None

# Generated at 2022-06-23 15:19:09.159123
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    """
    Test that when we supply a list of paths to get_vars_from_inventory_sources it returns expected results.
    """
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=["tests/unitsamples/inventory_sample"])
    inventory.parse_inventory(inventory.sources)
    data = get_vars_from_inventory_sources(loader, inventory.sources, inventory.hosts.values(), stage='task')
    print(data)
    assert data == {'fake_var': 'fake_value'}

# Generated at 2022-06-23 15:19:19.720324
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    from units.mock.loader import DictDataLoader
    from units.mock.plugins.vars.test_plugin import VarsModule
    from ansible.module_utils.common._collections_compat import MutableMapping

    class TestVarsPlugin(VarsModule):

        def __init__(self, name):
            super(TestVarsPlugin, self).__init__()
            self._load_name = name
            self._original_path = 'test_plugin'

        def get_option(self, option_name):
            return None

        def has_option(self, option_name):
            return False

    class TestHost(Host):

        def __init__(self, name):
            super(TestHost, self).__init__(name)
