

# Generated at 2022-06-23 15:09:25.862379
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.plugins.vars import yaml_vars

    path = os.path.join(os.path.dirname(__file__), 'data')
    entities = []
    test_host = Host(name='localhost', port=None)
    test_group = Group(name='test', vars={})
    entities.append(test_host)
    entities.append(test_group)
    data = get_plugin_vars(None, yaml_vars, path, entities)

# Generated at 2022-06-23 15:09:37.983172
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins import vars_plugins

    mock_loader = 'mock_loader'

    def mock_get_vars(loader, path, entities):
        vars = {'test_path': path, 'test_entities': [x.name for x in entities]}
        return vars

    def mock_get_group_vars(name):
        return {'test_group': name}

    def mock_get_host_vars(name):
        return {'test_host': name}

    values = {
        'test_path': 'mock_path',
        'test_entities': ['mock_host', 'mock_group'],
        'test_host': ['mock_host'],
        'test_group': ['mock_group'],
    }


# Generated at 2022-06-23 15:09:49.765357
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    # Check the vars are correct when both v2 and v1 inventory plugins are used
    loader = DummyLoader()
    plugin = DummyPlugin()
    plugin._load_name = 'vars_1'
    plugin._original_path = os.path.join('plugins', 'vars', 'vars_1')
    loader._plugins = [plugin]
    loader._paths = [os.path.join('plugins', 'vars', 'vars_1')]

    plugin_vars = get_vars_from_path(loader, os.path.join('plugins', 'vars', 'vars_1'), ['localhost'], 'task')

    plugin = DummyPlugin()
    plugin._load_name = 'vars_2'

# Generated at 2022-06-23 15:10:02.309726
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    from ansible.plugins.loader import vars_loader, path_loader
    from ansible.plugins.vars.base import VarsModule

    path = './'
    class CustomVarsModule(VarsModule):
        def get_vars(self, *args, **kwargs):
            return {"var1": "var1_value"}

    vars_plugin_list = vars_loader.all()
    vars_plugin_list.append(CustomVarsModule())

    assert 'var1' not in get_vars_from_path(None, path, [], 'inventory')
    assert 'var1' not in get_vars_from_path(vars_loader, path, [], 'inventory')

# Generated at 2022-06-23 15:10:12.998141
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader

    def gen_vars_plugin_loader(plugin):
        class VarPlug:
            def __init__(self, plugin):
                self._plugin = plugin

            def get_vars(self, loader, path, entities, cache=True):
                return self._plugin

            def get_group_vars(self, host, include_hostvars=True):
                return self._plugin

            def get_host_vars(self, host, include_hostvars=True):
                return self._plugin

        return VarPlug(plugin)

    vars_loader.add_directory(os.path.dirname(__file__) + '/../data/plugins/vars')

    plugin_list = []

# Generated at 2022-06-23 15:10:22.688815
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    loader = None
    sources = [os.path.abspath(__file__), os.path.abspath(os.path.join(__file__, "../../../../test/integration/inventory/test_inventory.yml")), os.path.abspath(os.path.join(__file__, "../../../../test/integration/inventory/included/static_inventory.yml"))]
    entities = None
    stage = "inventory"
    data = dict()
    for source in sources:
        if not os.path.isdir(to_bytes(source)):
            source = os.path.dirname(source)
        data = combine_vars(data, get_vars_from_path(loader, source, entities, stage))

# Generated at 2022-06-23 15:10:29.524541
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    plugin_name = 'other_vars.yml'
    path = 'path_to_dir'
    entities = ('host1', 'host2', 'host3')
    vars_plugin_list = [plugin_name]
    stage = 'task'

    data = get_vars_from_path(vars_plugin_list, path, entities, stage)

# Generated at 2022-06-23 15:10:39.410031
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    import ansible.constants as C

    C.VARIABLE_PLUGINS_ENABLED = ['vars_plugin_test_1', 'vars_plugin_test_2', 'vars_plugin_test_3']

    test_inventory_path = os.path.join(os.getcwd(), "test/integration/inventory/host_vars_plugins")
    inventory = InventoryManager(loader=None, sources=test_inventory_path)

    v1_plugin_name = "vars_plugin_test_1"
    v1_plugin = vars_loader.get(v1_plugin_name)
    v1_plugin.get_option

# Generated at 2022-06-23 15:10:46.766421
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    vars_data = {
        'ansible_play_hosts_all': ['spam']
    }

    class FakeVarsPlugin:
        def get_vars(self, loader, path, entities):
            return vars_data

    vars_plugin = FakeVarsPlugin()

    entities = []
    loader = None
    path = '/path/to/hosts/file'

    assert(get_plugin_vars(loader, vars_plugin, path, entities) == vars_data)

# Generated at 2022-06-23 15:10:57.078023
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    from ansible.inventory.inventory import Inventory
    from ansible.inventory.host import Host
    from ansible.plugins.loader import vars_loader
    from ansible.plugins.vars import BaseVarsPlugin

    class MockVarsPlugin(BaseVarsPlugin):

        class MockVarGroup:
            def __init__(self):
                pass

            def get_vars(self, play=None, host=None, task=None, include_hostvars=True, include_delegate_to=True):
                return dict(test="foo")

        class MockVarHost:
            def __init__(self):
                pass

            def get_vars(self, play=None, task=None, include_hostvars=True, include_delegate_to=True):
                return dict(test2="bar")


# Generated at 2022-06-23 15:11:07.440438
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.utils.display import Display

    loader = DataLoader()
    display = Display()
    display.verbosity = 4

    # create the inventory, use path to host config file as source or hosts in a comma separated string
    # to test that both sources are supported
    inventory_manager = InventoryManager(loader=loader, sources=['./test/hosts', 'host1,host2'])

    # create the variable manager, which will be shared across all groups, playbooks, etc.
    inventory = inventory_manager.get_inventory_object()
    variable_manager = VariableManager(loader=loader, inventory=inventory)


# Generated at 2022-06-23 15:11:14.912875
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    import os
    import tempfile
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory import Inventory
    from ansible.vars import combine_vars

    data = {}
    path1 = tempfile.mkdtemp()
    path2 = tempfile.mkdtemp()
    sources = [path1, path2]
    stage = 'inventory'
    loader = DataLoader()
    my_host = Host(name="test_host")
    my_group = Inventory()
    my_group.add_host(my_host)
    data = combine_vars(data, get_vars_from_inventory_sources(loader, sources, [my_group], stage))
    assert data == {}



# Generated at 2022-06-23 15:11:16.170907
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # add tests here
    pass


# Generated at 2022-06-23 15:11:16.796850
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    assert True

# Generated at 2022-06-23 15:11:26.745645
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    class MockVarsPlugin:

        def __init__(self, name):
            self._load_name = name

        def get_vars(self, loader, path, entities):
            assert isinstance(entities, list)
            return dict(foo=entities)

        def get_host_vars(self, host):
            return dict(host=host)

        def get_group_vars(self, group):
            return dict(group=group)

    class MockV1Plugin:

        def __init__(self, name):
            self._load_name = name

    def test_with_vars(entities, expected):
        data = get_vars_from_path(None, '.', entities, 'inventory')
        assert data == expected


# Generated at 2022-06-23 15:11:31.255563
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars.systeminfo import VarsModule as A
    from ansible.plugins.vars import vars_2_0

    assert get_plugin_vars(None, A(), '', []) == {}

# Generated at 2022-06-23 15:11:39.261168
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    plugin = {
        'v1': {'get_vars': 'dummy', 'get_host_vars': 'dummy', 'get_group_vars': 'dummy'},
        'v2': {'get_vars': 'dummy'}
    }

    try:
        get_plugin_vars(None, plugin['v1'], None, None)
    except AnsibleError:
        try:
            get_plugin_vars(None, plugin['v2'], None, None)
        except AnsibleError:
            pass

# Generated at 2022-06-23 15:11:48.131162
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    inventory_manager = __import__('ansible.inventory.manager').inventory.manager

    # Set vars plugin to test
    C.VARIABLE_PLUGINS_ENABLED = ["test_vars_plugin"]
    C.RUN_VARS_PLUGINS = "all"

    # Load plugins
    vars_loader = __import__('ansible.plugins.loader').plugins.loader.get_vars_loader()
    vars_loader._package_folder_paths = {}
    vars_loader._plugin_paths = []
    vars_loader.all()
    loader = __import__('ansible.parsing.dataloader').parsing.dataloader.DataLoader()
    loader.set_basedir('/')

    # Get inventory source
    host = Host("test")


# Generated at 2022-06-23 15:11:56.849106
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    class Dummy(object):
        pass

    class Dummy2(object):
        pass

    x = Dummy()
    y = Dummy2()
    y.name = 'test'
    x.get_vars = lambda a, b, c: {'test': 'test'}
    x.run = lambda: None
    assert get_plugin_vars(None, x, None, None) == {'test': 'test'}

    x.get_vars = None
    x.get_group_vars = lambda a: {'test': 'test'}
    assert get_plugin_vars(None, x, None, [y]) == {'test': 'test'}

    x.get_group_vars = None

# Generated at 2022-06-23 15:12:04.644435
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    # Test that get_vars_from_inventory_sources returns dict with variables for host and group
    sources = ['./test/integration/inventory_plugins/vars']
    stage = 'inventory'
    data = get_vars_from_inventory_sources(None, sources, ['localhost', 'group_name'], stage)
    expected_data = {'hostvars': {'localhost': {'var_host': 'host_var'}}, 'group_names': {'group_name': {'var_group': 'group_var'}}}

    assert(data == expected_data)

# Generated at 2022-06-23 15:12:15.904386
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    loader = vars_loader
    mgr = InventoryManager(loader=loader)
    inv_src = ["/Users/hongqiyu/Documents/qiyu/ansible/ansible/plugins/inventory/host_list.py"]
    sources = [mgr.get_inventory(i).basedir for i in inv_src]
    my_group = mgr.get_inventory(inv_src).get_group("all")
    my_hosts = mgr.get_inventory(inv_src).get_host("localhost")
    # entities = [my_group, my_hosts]
    entities = [my_hosts]
    stage ='task'


# Generated at 2022-06-23 15:12:26.423549
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    # Setup
    import os
    import sys
    import tempfile
    from ansible.inventory.manager import InventoryManager

    plugin_path = tempfile.mkdtemp()
    test_plugin_path = os.path.join(plugin_path, 'ansible/plugins/vars')

    os.makedirs(test_plugin_path)
    sys.path.append(plugin_path)

    # Create temporary inventory
    test_inventory = tempfile.NamedTemporaryFile(delete=False)
    test_inventory.close()

    # Create temporary test plugin
    test_plugin_path = os.path.join(test_plugin_path, 'test_plugin.py')
    test_plugin = open(test_plugin_path, 'w')
    test_plugin.write('class TestVarsPlugin: pass')
    test_plugin

# Generated at 2022-06-23 15:12:26.844433
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    pass

# Generated at 2022-06-23 15:12:36.383410
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import clean_error_msg
    from ansible.plugins.vars import yaml_loader
    from ansible.plugins.loader import vars_loader
    from ansible.utils.vars import combine_vars

    display = Display()

    plugin = vars_loader.get(yaml_loader.PATH)

    # create a loader and inject it as an attr so _get_file_vars() can find it
    loader = None
    plugin._loader = loader


    # test plugin without get_vars method

# Generated at 2022-06-23 15:12:43.490752
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.vars.vars_plugins import HostVars
    import ansible.vars.vars_plugins
    vars_loader.add(HostVars, 'test')
    assert len(vars_loader.all()) == 1
    assert get_vars_from_path(None, None, [], 'start') == {}
    assert get_vars_from_path(None, None, ['test'], 'start') == {}
    assert get_vars_from_path(None, None, [Host('test')], 'start') == {'test': 'ok'}
    vars_loader.remove('test')

# Generated at 2022-06-23 15:12:53.249058
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    import pytest
    from ansible.plugins.loader import vars_loader
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.inventory.manager import InventoryManager

    display.verbosity = 4

    # Tries to instantiate the vars plugin and verify that it is working
    #
    # The purpose of this test is to catch plugins for which instantiation
    # fails due to a bad configuration or an undefined variable.
    #
    # This test is designed to detect configuration errors, not bugs.  It
    # does not test plugins that do not support ansible_local and
    # ansible_group_priority because those are not used in any plugin shipped
    # with Ansible

    def test_vars_plugin(plugin_name):
        print("Testing vars plugin %s" % plugin_name)

# Generated at 2022-06-23 15:13:05.423466
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    import os
    import tempfile
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.vars import combine_vars, get_vars_from_path

    tmpdir = tempfile.gettempdir()
    # create one fake vault password file and one fake vault yaml file
    fake_vault_password_file = os.path.join(tmpdir, 'vault')
    with open(fake_vault_password_file, 'w') as f:
        f.write('test vault password')
    fake_vault_yaml_file = os.path.join(tmpdir, 'vault.yml')

# Generated at 2022-06-23 15:13:16.150197
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.loader import var_plugins

    def mock_get_vars(names):
        return {name: "value for %s" % name for name in names}

    def mock_get_host_vars(names):
        return {name: "value for host %s" % name for name in names}

    def mock_get_group_vars(names):
        return {name: "value for group %s" % name for name in names}

    def mock_get_group_host_vars(group_names, all_host_names):
        return {name: "value for group %s" % name for name in group_names}

    def mock_get_group_vars_for_host(host_name):
        return {host_name: "value for group %s" % host_name}

   

# Generated at 2022-06-23 15:13:20.806450
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    loader = None
    sources = [__file__]

    class TestHost:
        def __init__(self, name):
            self.name = name

    entities = [ TestHost('one'), TestHost('two') ]
    stage = 'inventory'

    vars = get_vars_from_inventory_sources(loader, sources, entities, stage)
    assert vars is not None


# Generated at 2022-06-23 15:13:21.752578
# Unit test for function get_vars_from_path

# Generated at 2022-06-23 15:13:32.450536
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    '''
    Unit test for function get_vars_from_inventory_sources
    '''
    # import json
    from .manager import InventoryManager
    from .host import Host

    C.RUN_VARS_PLUGINS = 'all'
    C.VARIABLE_PLUGINS_ENABLED = ('custom_vars',)

    host = Host(name="localhost")
    loader = InventoryManager()
    test_data = get_vars_from_inventory_sources(loader, [__file__], [host], 'start')
    assert test_data['inventory_filename'] == __file__
    assert test_data['inventory_hostname'] == 'localhost'

# Generated at 2022-06-23 15:13:37.799637
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    from ansible.plugins.loader import vars_loader
    from ansible.vars.manager import VariableManager

    plugin = vars_loader.get("yaml_file")(variable_manager=VariableManager())
    vars_loader.add("yaml_file", plugin)

    test_path = "/path/to/test/file"
    test_entity = "test"

    data = get_plugin_vars(None, plugin, test_path, [test_entity])

    assert data == {}, "empty variable list returned"

# Generated at 2022-06-23 15:13:49.040523
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import VarsModule

    class VarPlugin(VarsModule):
        def get_vars(self, loader, path, entities):
            return {'plugin': 'get_vars'}

        def get_group_vars(self, group):
            return {'plugin': 'get_group_vars'}

        def get_host_vars(self, host):
            return {'plugin': 'get_host_vars'}

    class Host(object):
        def __init__(self, name):
            self.name = name

    class Group(object):
        def __init__(self, name):
            self.name = name

    class DummyLoader(object):
        pass

    entities = [Host('host'), Group('group')]

    # Get vars back from get_

# Generated at 2022-06-23 15:13:50.667491
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # TODO: Write unit test
    pass


# Generated at 2022-06-23 15:13:58.640912
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    class mock_plugin():
        def __init__(self, plugin_name, plugin_path, plugin_type = None, run = False):
            self._load_name = plugin_name
            self._original_path = plugin_path
            self.REQUIRES_WHITELIST = True if plugin_type == 'v1' else False
            self.run = run

        def get_vars(self, loader, path, entities):
            return {'plugin_vars': True}

    class mock_loader():
        pass

    class mock_host():
        def __init__(self, host_name):
            self.name = host_name

    class mock_group():
        def __init__(self, group_name):
            self.name = group_name

    class mock_path():
        pass

    loader = mock

# Generated at 2022-06-23 15:14:08.736964
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    '''
    @summary: Test that the get_vars_from_inventory_sources() function
    correctly aggregates the variables information from all the sources.
    '''
    mock_loader = MockLoader()
    ansible_vars = {'ansible_key': 'ansible_value'}
    external_vars = {'external_key': 'external_value'}
    loader_vars = {'loader_key': 'loader_value'}
    MockVarsPlugin.__load_inv_vars__ = loader_vars
    path = os.path.abspath(os.path.join('.', 'test_vars_plugin.py'))

# Generated at 2022-06-23 15:14:18.497871
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    fake_loader = object()
    fake_entities = [Host(name="foo")]
    # Valid plugin
    test_dir = os.path.join('test', 'units', 'plugins')
    sys.path.insert(0, to_bytes(test_dir))
    plugin_vars_path = os.path.join(test_dir, 'vars')
    data1 = get_vars_from_path(fake_loader, plugin_vars_path, fake_entities, 'inventory')
    assert data1 == {"foo": "bar"}
    # Invalid plugin
    test_dir = os.path.join('test', 'units', 'plugins')
    sys.path.insert(0, to_bytes(test_dir))
    plugin_vars_path = os.path.join(test_dir, 'vars')

# Generated at 2022-06-23 15:14:25.182471
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from collections import namedtuple
    import os

    # inventory host
    FakeHost = namedtuple('FakeHost', 'name')

    # inventory group
    FakeGroup = namedtuple('FakeGroup', 'name')

    # create a fake loader
    FakeLoader = namedtuple('FakeLoader', 'get_basedir')

    # create a fake plugin
    FakePlugin = namedtuple('FakePlugin', '_load_name, get_group_vars, get_host_vars, run')

    # test variables
    plugin_name = os.getcwd() + '/plugins/test/vars/my_get_vars.py'
    plugin_name2 = os.getcwd() + '/plugins/test/vars/my_get_group_vars.py'

# Generated at 2022-06-23 15:14:29.891593
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible_collections.testns.testcoll.plugins.vars import plugin_vars
    loader = None

    plugin = plugin_vars()
    path = '/tmp/'
    entities = ['localhost']

    assert {'key1': 'value1'} == get_plugin_vars(loader, plugin, path, entities)


# Generated at 2022-06-23 15:14:30.636378
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    assert True

# Generated at 2022-06-23 15:14:40.101107
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    loader.set_basedir("/path")

    sources = ['/path/inventory/hosts']
    # create the host
    host = Host("host1")

    data = get_vars_from_inventory_sources(loader, sources, [host], "runtime")

    assert 'host1' in data and data['host1']
    assert 'ansible_all_ipv4_addresses' in data['host1']
    #ansible_all_ipv4_addresses should be a list
    assert isinstance(data['host1']['ansible_all_ipv4_addresses'], list)

# Generated at 2022-06-23 15:14:41.201973
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    pass


# Generated at 2022-06-23 15:14:52.174272
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    class MyPlugin():

        def get_plugin_name(self):
            return "my_plugin"

        def get_vars(self, loader, path, entities):
            return {'var2': 'val2'}

    class MyPlugin2():

        def get_plugin_name(self):
            return "my_plugin"

    loader = "dummy_loader"
    plugin = MyPlugin()
    path = "dummy_path"
    entities = ["entity1"]

    data = get_plugin_vars(loader, plugin, path, entities)
    assert data['var2'] == 'val2'

    with pytest.raises(AnsibleError):
        plugin = MyPlugin2()
        data = get_plugin_vars(loader, plugin, path, entities)



# Generated at 2022-06-23 15:14:52.740805
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    pass

# Generated at 2022-06-23 15:15:04.065280
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    class TestPlugin1(object):
        def get_vars(self, loader, path, entities):
            return {'a': 'A'}

    class TestPlugin1a(TestPlugin1):
        pass

    class TestPlugin2(object):
        def get_vars(self, loader, path, entities):
            return {'b': 'B'}

    class TestPlugin3(object):
        def get_vars(self, loader, path, entities):
            return {'c': 'C'}

    class TestLoader(object):
        def get(self, name):
            if name == 'TestPlugin1':
                return TestPlugin1()
            elif name == 'TestPlugin1a':
                return TestPlugin1a()
            elif name == 'TestPlugin2':
                return TestPlugin2()

# Generated at 2022-06-23 15:15:04.402244
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    pass

# Generated at 2022-06-23 15:15:16.589791
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    # reset vars_loader to not load any plugins
    vars_loader._package_paths = []
    # set the environment variable for the vars plugins path to
    # the test/vars_plugins directory
    os.environ['ANSIBLE_VARS_PLUGINS_PATH'] = './test/vars_plugins'
    vars_loader.add_directory(os.path.join(os.path.dirname(__file__), "../loader"))
    vars_loader.add_directory(os.path.join(os.path.dirname(__file__), "../vars_plugins"))

    assert len(C.VARIABLE_PLUGINS_ENABLED) == 0

    # create a vars_loader() object and load all the vars

# Generated at 2022-06-23 15:15:27.973576
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    import sys
    import mock
    import collections
    import ansible.plugins.loader as plugin_loader
    import ansible.plugins.vars as vars_plugins

    mock_inventory_source = collections.namedtuple('mock_inventory_source', ['inventory'])
    mock_plugin = mock.MagicMock(spec=vars_plugins.VarsModule, **{
        'REQUIRES_WHITELIST': False,
        'get_option.return_value': None,
        'get_vars.return_value': {'mock_plugin': 'mock_plugin'},
    })
    mock_loader = mock.MagicMock(spec=plugin_loader.PluginLoader, **{
        'all.return_value': [],
        'get.return_value': mock_plugin,
    })

    mock

# Generated at 2022-06-23 15:15:38.759304
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    loader, path, entities = None, None, None
    plugin = type('TestPlugin', (), {'get_vars': lambda s, loader, path, entities: {'test': 'test'}})
    assert get_plugin_vars(loader, plugin, path, entities) == {'test': 'test'}
    plugin = type('TestPlugin', (), {'get_host_vars': lambda s, host: {'test': 'test'}})
    assert get_plugin_vars(loader, plugin, path, [Host('test')]) == {'test': 'test'}
    plugin = type('TestPlugin', (), {'get_group_vars': lambda s, group: {'test': 'test'}})

# Generated at 2022-06-23 15:15:42.655730
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    '''
    Function under test is get_vars_from_path()
    '''

    loader = None
    path = ''
    entities = []
    stage = ''

    try:
        result = get_vars_from_path(loader, path, entities, stage)
    except Exception:
        pass

# Generated at 2022-06-23 15:15:45.935317
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    '''
    Test the get_vars_from_path function
    '''
    from ansible.vars.plugins.vars import VarsModule
    loader = vars_loader
    get_vars_from_path(loader, '/dir', ['entity1', 'entity2'], 'inventory')

# Generated at 2022-06-23 15:15:54.190015
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    vars_plugin_list = list(vars_loader.all())
    for plugin_name in C.VARIABLE_PLUGINS_ENABLED:
        if AnsibleCollectionRef.is_valid_fqcr(plugin_name):
            vars_plugin = vars_loader.get(plugin_name)
            if vars_plugin is None:
                # Error if there's no play directory or the name is wrong?
                continue
            if vars_plugin not in vars_plugin_list:
                vars_plugin_list.append(vars_plugin)


# Generated at 2022-06-23 15:16:03.025468
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    loader = {
        'module_utils': True,
        'all': True,
        'get': True,
        'none': True,
        'any': True,
        'set': True,
        'has_option': True,
        'get_option': True,
        'REQUIRES_WHITELIST': True
    }

    sources = ['*', 'file.yml']
    entities = ['*', 'host']
    stage = 'inventory'
    data = {}
    data = get_vars_from_inventory_sources(loader, sources, entities, stage)



# Generated at 2022-06-23 15:16:06.890177
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    loader = 'fake_loader'
    plugin = 'fake_plugin'
    path = 'fake_path'
    entities = 'fake_entities'
    get_plugin_vars(loader, plugin, path, entities)

# Generated at 2022-06-23 15:16:11.214716
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    loader = None
    plugin = MockPlugin()
    plugin.name = "mock"
    path = "/dev/null"
    entity = Host("localhost")
    entities = [entity]

    assert get_plugin_vars(loader, plugin, path, entities) == {"mock": True}


# Generated at 2022-06-23 15:16:19.100931
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    # test 1: no source passed
    loader = mock_loader()
    source = None
    entities = ['server1']
    stage = 'task'
    data = get_vars_from_inventory_sources(loader, source, entities, stage)
    assert data == {}

    # test 2: empty source passed
    loader = mock_loader()
    source = []
    entities = ['server1']
    stage = 'task'
    data = get_vars_from_inventory_sources(loader, source, entities, stage)
    assert data == {}

    # test 3: comma separated source passed
    loader = mock_loader()
    source = ['/test,test']
    entities = ['server1']
    stage = 'task'

# Generated at 2022-06-23 15:16:26.352515
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    plugin = {'get_vars': lambda a, b, c: {'color': 'blue', 'animal': 'dog'}}

    assert get_vars_from_path(None, './fake_path', None, None) == {}
    assert get_vars_from_path(None, './fake_path', None, None, [plugin]) == {'color': 'blue', 'animal': 'dog'}

# Generated at 2022-06-23 15:16:36.259260
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    class MyVarPlugin(object):
        def get_vars(self, loader, path, entities):
            return {'foo': 1}

    class MyOtherVarPlugin(object):
        def get_host_vars(self, host):
            return {'hostvar': 1}
        def get_group_vars(self, group):
            return {'groupvar': 1}

    loader = {}
    import ansible.plugins.loader
    path = '/tmp'
    entities = [Host('localhost')]
    stage = 'inventory'

    MyVarPlugin.REQUIRES_WHITELIST = True
    MyOtherVarPlugin.REQUIRES_WHITELIST = True
    ansible.plugins.loader.FILENAME_EXTENSIONS = []

    # Test that plugin is called if globally enabled
    data = get_

# Generated at 2022-06-23 15:16:47.345654
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    import sys
    if sys.version_info[:2] < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    import ansible.plugins.vars
    import os
    import shutil
    import tempfile

    class TestGetVarsFromPath(unittest.TestCase):

        def setUp(self):
            self.vars_dir = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.vars_dir)

        def _make_plugins(self, plugin_names):
            plugins = []
            for plugin_name in plugin_names:
                plugin_file_name = os.path.join(self.vars_dir, plugin_name)

# Generated at 2022-06-23 15:16:57.600870
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    import os.path
    import unittest

    # Create an inventory with three files and a subdirectory.
    inventory = InventoryManager(loader=None, sources=['/tmp/a', '/tmp/b,/tmp/c', '/tmp/d/e', '/tmp/f,/tmp/g'])
    assert len(inventory.sources) == 6

    sources = [s.origin for s in inventory.sources]
    sources.sort()
    assert sources == ['/tmp/a', '/tmp/b', '/tmp/c', '/tmp/d/e', '/tmp/f', '/tmp/g']

    # os.path.exists() used to determine if a file with a comma-separated list of paths was provided
    # we have to override this with our own test function because Ansible

# Generated at 2022-06-23 15:16:58.928556
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert get_vars_from_path()

# Generated at 2022-06-23 15:17:06.996852
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    import pprint
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    from ansible.test.vars.test_group_vars import GroupVarsTestPlugin
    from ansible.test.vars.test_host_vars import HostVarsTestPlugin
    from ansible.test.vars.test_vars_plugins import VarsTestPlugin

    sources = ['ansible/test/units/lib/ansible_test/_data/group_vars/group1',
               'ansible/test/units/lib/ansible_test/_data/group_vars/group2']

    display.verbosity = 3

    groupvars_path = 'ansible/test/units/plugins/vars/'

# Generated at 2022-06-23 15:17:16.726620
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    # Stub class for the plugin
    class StubPlugin():
        def get_vars(self, loader, path, entities):
            return dict({'plugin-vars1': 'plugin-vars-val1'})
        def get_host_vars(self, host):
            return dict({'plugin-host-vars1': 'plugin-host-vars-val1'})
        def get_group_vars(self, group_name):
            return dict({'plugin-group-vars1': 'plugin-group-vars-val1'})

        def run(self):
            return dict({'v1': 'v1-val'})

    # Stub class for the loader
    class StubLoader():
        pass

    # Mock class for the host
    class TestHost():
        name = 'test_host'

    #

# Generated at 2022-06-23 15:17:27.000073
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.inventory.manager import InventoryManager
    class VarsLoader:
        def __init__(self):
            self.vars_plugins = {'bar': 'foo'}

        def all(self):
            return self.vars_plugins.values()

    class TestPlugin:
        def __init__(self):
            self._load_name = 'foo'
            self._original_path = '/'

        def get_vars(self, loader, path, entities):
            return {'foo': 'bar'}

    class TestPlugin2:
        def __init__(self):
            self._load_name = 'foo'
            self._original_path = '/'

        def get_host_vars(self, hostname):
            return {'foo': 'bar'}


# Generated at 2022-06-23 15:17:38.814871
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    import ansible.plugins.vars
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager

    hosts = [Host("host1")]
    groups = [Group("group1")]

    # test_vars_loader_get_vars_from_path_v2_inventory_vars: Only one result is expected
    class test_vars_loader_get_vars_from_path_v2_inventory_vars(object):
        _load_name = "v2_inventory_vars"

        def get_vars(self, loader, path, entities):
            return {"var_name": "var_value"}


# Generated at 2022-06-23 15:17:49.369035
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    # requires a valid config file
    C.CONFIG_FILE = os.path.join(os.path.dirname(__file__), 'ansible.cfg')

    # load inventory
    from ansible.cli import CLI
    from ansible.parsing.dataloader import DataLoader
    options = CLI.base_parser(
        usage='%prog [options]',
        desc="Gets the variables for a list of hosts or groups within a project",
    ).parse_args()

    loader = DataLoader()
    cli = CLI(options)
    inventory = cli.inventory

    # test a group
    group = inventory.groups['all']
    assert group.vars == get_vars_from_inventory_sources(loader, inventory.sources, [group], 'inventory')

    # test a host
    host

# Generated at 2022-06-23 15:17:51.321228
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    print(get_vars_from_path({}, "../tests", ['test1', 'test2'], 'task'))

# Generated at 2022-06-23 15:17:52.057922
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    pass

# Generated at 2022-06-23 15:18:00.540184
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from units.mock.loader import DictDataLoader


# Generated at 2022-06-23 15:18:10.399212
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    # Testing the function
    disp = Display()
    disp.verbosity = 0
    vars_plugin_list = list(vars_loader.all())

    loader = __import__("ansible.parsing.dataloader.DataLoader", fromlist=["ansible.parsing.dataloader.DataLoader"])
    loader = loader.DataLoader()


# Generated at 2022-06-23 15:18:19.523944
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.inventory.data import InventoryData
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import vars_loader
    from ansible.vars import VariableManager
    inv = InventoryData().load()
    plugin = vars_loader.get('group_vars')
    variable_manager = VariableManager()
    variable_manager.add_group_vars_file()
    play_context = PlayContext()
    play_context._init_globals()
    variable_manager.set_inventory(inv)
    play = Play.load({}, variable_manager=variable_manager, loader=None, play_context=play_context)

# Generated at 2022-06-23 15:18:30.414840
# Unit test for function get_plugin_vars

# Generated at 2022-06-23 15:18:35.805482
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    host = Host('host_name')

    # Mock a plugin
    class MockPlugin:
        def get_vars(self, loader, path, entities):
            return {'test_get_vars': 'yes'}

        def get_group_vars(self, group):
            return {'test_get_group_vars': 'yes'}

        def get_host_vars(self, host):
            return {'test_get_host_vars': 'yes'}

    plugin = MockPlugin()
    assert get_plugin_vars(None, plugin, None, [])['test_get_vars'] == 'yes'
    assert get_plugin_vars(None, plugin, None, [host])['test_get_host_vars'] == 'yes'

# Generated at 2022-06-23 15:18:46.863075
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.strategy import StrategyModule
    from ansible.plugins.loader import strategy_loader
    from ansible.plugins.vars import VarsModule
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    inventory_manager = InventoryManager()
    inventory = inventory_manager.get_inventory_sources(["tests/units/test_plugins/test_vars/inventory"])[0]
    inventory.parse()
    plugin = (VarsModule)(vars_loader, 'test_plugin', 'test_plugin', StrategyModule)
    vars_loader.add(plugin)
    value = get_plugin_vars(vars_loader, plugin, os.path.dirname(__file__), inventory.hosts.values())

# Generated at 2022-06-23 15:18:55.093092
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    # test with plugin-specific setting instead of global setting
    from ansible.plugins.vars import vars_vmware_vm_inventory
    vars_vmware_vm_inventory.set_option('stage', 'all')

    # test with stage == "inventory"
    assert get_vars_from_path([], path='/foo', entities=[], stage='inventory') == {}

    # test with stage == "task"
    assert get_vars_from_path([], path='/foo', entities=[], stage='task') == {}

# Generated at 2022-06-23 15:19:05.616044
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    """Simple test that will read the current inventory file and
    extraction of the vars from it.
    Side effect: If user has a plugin 'foo' defined in the plugins/
    directory, the test will print some warnings about paths.
    WARNING: plugin foo not found in <my_plugins_path>
    It's not a problem, but it's ugly...
    """
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    hosts = ['localhost']
    inventory = InventoryManager(loader=DataLoader(), sources=['localhost,'])
    inventory.add_host(hosts[0])
    variables = VariableManager(loader=DataLoader(), inventory=inventory)
   

# Generated at 2022-06-23 15:19:11.258299
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # /tmp does not exist
    loader = None
    path = '/tmp'
    entities = None
    stage = 'inventory'
    data = {}

    if os.path.isdir(to_bytes(path)):
        data = combine_vars(data, get_plugin_vars(loader, path, entities))

    assert data == {}


# Generated at 2022-06-23 15:19:19.007436
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    my_loader = [{
      "name": "test_plugin",
      "path": "/tmp/test/test_plugin.py",
      "vars": {
        "value": "blah",
        "parsed": "true"
      }
    }]
    path = "/tmp"
    entities = []
    stage = "inventory"
    result = get_vars_from_path(my_loader, path, entities, stage)
    assert result["test_plugin"] == {"value": "blah", "parsed": "true"}

