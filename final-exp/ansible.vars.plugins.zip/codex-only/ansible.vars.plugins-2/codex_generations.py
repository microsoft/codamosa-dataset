

# Generated at 2022-06-23 15:09:18.862270
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    plugin = vars_loader.get('yaml_vars')
    entities = [Host('dummy')]
    path = '/'
    data = get_plugin_vars(None, plugin, path, entities)
    assert data == {}

# Generated at 2022-06-23 15:09:22.744558
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    sources = ['/some/discovered/source', 'some,discovered,source', '/some/real/source']
    entities = []

    loader = {}

    data = get_vars_from_inventory_sources(loader, sources, entities, 'inventory')

    assert data == {}

# Generated at 2022-06-23 15:09:25.269916
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    loader, inventory, sources, stage = None, None, None, None
    entities = None
    get_vars_from_inventory_sources(loader, sources, entities, stage)

# Generated at 2022-06-23 15:09:37.298956
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.cli.playbook import PlaybookCLI
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager

    cli = PlaybookCLI(['-i', 'localhost,', '-e', '@test_vars.yml', '-e', '{test_var: test_value}', 'test_vars_plugin.yml'])
    cli.parse()
    inventory = InventoryManager(cli.options, cli.args)
    play_context = PlayContext(cli.options, inventory=inventory)
    loader = cli.loader

    # test_vars_plugin.yml simply imports the plugin start.yml
    # which contains a variable test_var_from_host_vars with value 'test_value_from_host_vars'

# Generated at 2022-06-23 15:09:48.914746
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    import sys
    import tempfile
    import subprocess

    collection_content = '''
---
plugin_type: vars
short_description: This is a test plugin
description: >
  This is a test plugin
  with a long description.
author: Foo Bar
version: '1.0'
'''

    collection_path = tempfile.mkdtemp()
    plugin_path = os.path.join(collection_path, 'ansible_collections', 'foo', 'test', 'plugins', 'vars', 'test_plugin.yml')
    os.makedirs(os.path.dirname(plugin_path))

    with open(plugin_path, 'w+') as f:
        f.write(collection_content)

# Generated at 2022-06-23 15:09:51.641674
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    data = get_vars_from_path(None, '/path/to/host_vars_directory', [{'hostname': 'localhost', 'ip': '127.0.0.1'}], 'host')
    assert(data['hostvars']['localhost']['ip'] == '127.0.0.1')

# Generated at 2022-06-23 15:10:02.588739
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    """
    Ensure we get the expected output from the get_plugin_vars function.
    """
    # Setup test values
    loader = None
    plugin = "file"
    path = "/path/to/inventory/source"
    entities = [
        "webservers",
        "dbservers",
        "mail",
        "localhost",
        "mgmt",
        "mgmt2",
        "mgmt3",
        "mgmt4",
        "mgmt5",
        "mgmt6",
        "mgmt7",
        "mgmt8",
    ]

    # Call the function
    plugin_vars = get_plugin_vars(loader, plugin, path, entities)

    # Test output
    assert plugin_vars.get("version") == "2.0"

# Generated at 2022-06-23 15:10:13.152524
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import module_loader

    m = module_loader.get('test_plugin_vars')
    m._original_path = '/tmp/test_plugin_vars.py'
    m._load_name = 'test_plugin_vars'
    m.get_vars = lambda x,y,z: {'test_plugin_vars': 1}
    i = InventoryManager(loader=None, sources=[])
    h = Host(name='testhost')
    assert get_plugin_vars(i, m, '/tmp', [h]) == {'test_plugin_vars': 1}
    del m.get_vars

    m.get_host_vars = lambda x: {'test_plugin_vars': 1}
    assert get

# Generated at 2022-06-23 15:10:23.280885
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory import Inventory
    from ansible.parsing.utils.yaml import from_yaml

    loader = ansible.parsing.dataloader.DataLoader()
    inv_src_1 = """
        all:
          hosts:
            localhost:
            notlocalhost:
          children:
            child1:
              hosts:
                localhost:
                notlocalhost:
        group1:
          hosts:
            localhost:
          children:
            child2:
              hosts:
                localhost:
        group2:
          hosts:
            notlocalhost:
    """

# Generated at 2022-06-23 15:10:29.064227
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.vars.manager import VariableManager

    vars_loader.add_directory('./vars_plugins_test')
    # os.environ['ANSIBLE_VARIABLE_PLUGINS_ENABLED'] = 'var_plugin_test1,var_plugin_test2,var_plugin_test3'
    C.VARIABLE_PLUGINS_ENABLED = ['var_plugin_test1', 'var_plugin_test2', 'var_plugin_test3']

    # test case 1, C.RUN_VARS_PLUGINS = 'start', stage = 'inventory'
    C.RUN_VARS_PLUGINS = 'start'
    stage = 'inventory'
    path = './vars_plugins_test'
    entities = []
    loader = VariableManager()
    data

# Generated at 2022-06-23 15:10:39.262453
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    vars_loader.all()
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    h = Host('hostname')
    g = Group('groupname')

    inventory_source_path = '~/ansible/ansible/test/units/plugins/inventory/test_inventory.ini'
    loader = None
    data = get_vars_from_path(loader, inventory_source_path, [h, g], 'task')

# Generated at 2022-06-23 15:10:45.572954
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.plugins.vars import vars_plugins
    vars_loader._vars_plugins = vars_plugins

    sources = ['/etc/ansible/hosts', '/etc/ansible/group_vars']
    data = get_vars_from_inventory_sources(None, sources, [], 'task')

    print(data)

test_get_vars_from_inventory_sources()

# Generated at 2022-06-23 15:10:49.311863
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    import ansible.plugins.loader
    assert 'vars_plugins' in ansible.plugins.loader.all()

    assert get_vars_from_path(None, __file__, [], 'inventory') == {}

# Generated at 2022-06-23 15:10:59.068874
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    '''
        This is a unit test for get_plugin_vars function
    '''
    from ansible.plugins.vars import yaml_loader
    import os
    import sys

    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    class FakeVarsPlugin(object):

        def __init__(self):
            self._load_name = "fake_plugin"
            self._original_path = None

        def get_vars(self, loader, path, entities, cache=True):
            return {"fake_plugin": "fake_vars"}


# Generated at 2022-06-23 15:11:08.903189
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    # Run get_plugin_vars with a mock plugin and verify that:
    #   - If the plugin has a get_vars method, it is called with the correct arguments
    #   - If the plugin does not have a get_vars method but has a get_host_vars method, it is called with the correct
    #     arguments.
    #   - If the plugin does not have a get_vars method, a get_host_vars method or a get_group_vars method, the
    #     function throws an exception

    class MockEntity(object):
        def __init__(self, name):
            self.name = name

    class MockHost(object):
        def __init__(self, name):
            self.name = name

        def get_groups(self):
            return []


# Generated at 2022-06-23 15:11:20.494611
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    from ansible.plugins import vars_loader

    plugin = vars_loader.get('constants')
    assert plugin is not None
    assert plugin._load_name == 'constants'
    assert hasattr(plugin, 'get_vars')
    assert plugin.get_vars(None, None, None) == dict(C.constant_loaders())  # pylint: disable=no-member

    plugin = vars_loader.get('facts')
    assert plugin is not None
    assert plugin._load_name == 'facts'
    assert not hasattr(plugin, 'get_vars')
    assert hasattr(plugin, 'get_host_vars')
    assert hasattr(plugin, 'get_group_vars')
    assert hasattr(plugin, 'get_option')

# Generated at 2022-06-23 15:11:28.622510
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.context import CLIARGS
    from ansible.inventory.manager import InventoryManager

    test_plugin = None
    inventory = InventoryManager(loader=None, sources="localhost,")
    data = get_vars_from_inventory_sources(inventory.loader, inventory.sources, inventory.hosts, 'task')
    assert data == {}

    # Test with a test plugin
    data = {}
    test_plugin = TestPlugin()
    data = get_vars_from_inventory_sources(inventory.loader, inventory.sources, inventory.hosts, 'task')
    assert data == {}

    # Test with plugin list
    data = {}
    test_plugin = TestPlugin()
    C.VARIABLE_PLUGINS_ENABLED.append('test_plugin')
    data = get_vars_from

# Generated at 2022-06-23 15:11:40.387518
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    class MockVarsPlugin:
        def __init__(self):
            self.vars = {}

        def get_vars(self, loader, path, entities, cache=None):
            self.vars[path] = path

    # Test when the path is none
    sources = [None]
    expected = {}
    loader = None
    entities = []
    result = get_vars_from_inventory_sources(loader, sources, entities, 'inventory')
    assert expected == result, "Expected: %s, Got: %s" % (expected, result)

    # Test when the path does not exist
    sources = [os.path.sep + 'path', 'path,path2']
    expected = {}
    loader = None
    entities = []

# Generated at 2022-06-23 15:11:48.663184
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    import os
    test_path = os.path.join(os.path.dirname(__file__), 'vars_plugin')
    test_plugin = vars_loader.get("vars_plugin.yaml")
    test_entities = ['host1', 'host2', 'host3']


# Generated at 2022-06-23 15:11:56.161565
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    '''
    Test to see if it returns a dictionary of inventory variables
    '''
    # Setup the inventory plugin
    plugin = vars_loader.get('fake_vars_loader')
    # Setup the entities
    host = Host('localhost')
    group = Host('localhost')
    group.name = 'testgroup'
    # Setup the inventory source
    sources = [None, 'localhost']
    entities = [host, group]
    stage = 'task'

    value = get_vars_from_inventory_sources(plugin, sources, entities, stage)
    assert value != dict()
    assert value['group_names'] == 'testgroup'
    assert value['inventory_hostname'] == 'localhost'

# Generated at 2022-06-23 15:12:06.397439
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible import context

    def _create_path(*args):
        """Create a path relative to this test file"""
        return os.path.join(os.path.dirname(__file__), *args)

    plugin = './../plugins/inventory/test_vars_plugin/plugin.yml'
    C.VARIABLE_PLUGINS_ENABLED.insert(0, plugin)
    # Load host variable plugin
    plugin_loader = vars_loader.get(plugin)
    # create a local inventory to retrieve host variable
    host_vars_inventory = _create_path('host_vars_test_inventory')
    loader = context.CLIARGS['loader']
    entities = loader.inventory.hosts.keys()
    sources = {host_vars_inventory}
    stage = 'inventory'


# Generated at 2022-06-23 15:12:12.657654
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    # Test for issue #39197
    # When path is None, no exception is raised
    loader = None
    sources = [None]
    entities = []
    stage = "inventory"
    data = get_vars_from_inventory_sources(loader, sources, entities, stage)
    assert isinstance(data, dict)
    assert len(data) == 0



# Generated at 2022-06-23 15:12:20.312031
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    # import constants and vars_loader
    from ansible.plugins.loader import vars_loader as vars_loader_class

    # import vars plugins
    from ansible.plugins.vars import host_group_vars_plugin

    # create constants instance
    from ansible.module_utils.common.collections import ImmutableDict
    constants = ImmutableDict({'VARIABLE_PLUGINS_ENABLED': ['test_vars_plugin', 'host_group_vars'],
                               'RUN_VARS_PLUGINS': 'demand'})

    for obj in vars_loader_class._vars_plugins:
        setattr(obj, '_load_name', obj.__name__)
        setattr(obj, 'get_vars', obj.get_vars)

    # create

# Generated at 2022-06-23 15:12:25.765973
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    # vars_loader
    path = "path"
    entities = []
    stage = "inventory"

    # vars plugin
    class plugin:
        def get_vars(self, loader, path, entities):
            return {}

    vars_plugin = plugin()

    # vars_loader
    class loader:
        def all(self):
            return [vars_plugin]

    loader = loader()

    result = get_vars_from_path(loader, path, entities, stage)

    assert result == {}

# Generated at 2022-06-23 15:12:26.128018
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    return

# Generated at 2022-06-23 15:12:30.536990
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    # Test with no inventory sources
    assert (get_vars_from_inventory_sources(None, [], None, None) == {})

    # Test with an empty list of inventory sources
    assert (get_vars_from_inventory_sources(None, [''], None, None) == {})

# Generated at 2022-06-23 15:12:38.700584
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    class MockLoader(object):
        pass

    class MockPlugin(object):

        def __init__(self):
            self._load_name = 'TestVarPlugin'

        def get_vars(self, loader, path, entities):
            assert isinstance(loader, MockLoader)
            assert isinstance(path, str)
            assert isinstance(entities, list)
            return {'test_key': 'test_value'}

    loader = MockLoader()
    plugin = MockPlugin()

    entities = [None]  # make sure the entities arg can be a list of length 1 or greater

    result = get_plugin_vars(loader, plugin, None, entities)
    assert isinstance(result, dict)
    assert result['test_key'] == 'test_value'

# Generated at 2022-06-23 15:12:49.373438
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    """verify data returned by module_utils.vars.get_plugin_vars function
    :return:
    """
    from ansible.plugins.loader import vars_loader
    from ansible.plugins.vars import BaseVarsPlugin

    class TestVarsPlugin(BaseVarsPlugin):
        def get_vars(self, loader, path, entities, cache=True):
            return {'vars': {'x': '1'}, '_fact_cache': {}}

    class TestVarsPlugin2(BaseVarsPlugin):
        def run(self, terms, variables=None, **kwargs):
            return dict()

    for plugin in [TestVarsPlugin(), TestVarsPlugin2()]:
        vars_loader.add(plugin._load_name, plugin)

# Generated at 2022-06-23 15:12:54.387320
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host

    display.verbosity = 4
    inventory_file = 'test_vars_plugin_inventory.yml'
    inventory = InventoryManager(loader=None, sources=inventory_file)
    plugin_var_results = get_vars_from_path(inventory._loader, inventory_file, [Host('192.168.0.1')], 'inventory')
    assert plugin_var_results, 'should have at least one plugin var result'
    assert 'host_name' in plugin_var_results, 'should have plugin var host_name'
    assert plugin_var_results['host_name'] == 'localhost', 'plugin var host_name should be "localhost", not %s' % plugin_var_results['host_name']

# Generated at 2022-06-23 15:12:55.973409
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert get_plugin_vars == get_vars_from_path

# Generated at 2022-06-23 15:13:07.294841
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    from collections import namedtuple
    from ansible.config.manager import ConfigManager, Setting, DataLoader

    loader = DataLoader()
    path = '/some/path'
    plugin = namedtuple('Plugin', ['get_vars', 'get_host_vars', 'get_group_vars', '_original_path', '_load_name'])(get_vars=None, get_host_vars=None, get_group_vars=None, _original_path='/some/plugin', _load_name='plugin')

    data = get_plugin_vars(loader, plugin, path, [])

    assert data == {}


if __name__ == '__main__':
    import sys
    import pytest
    pytest.main([__file__] + sys.argv[1:])

# Generated at 2022-06-23 15:13:17.927392
# Unit test for function get_vars_from_path

# Generated at 2022-06-23 15:13:23.442510
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    '''
    This function tests get_vars_from_path function
    with passing an object of AnsibleLoader()
    '''

    loader = AnsibleLoader()
    path = '/root'
    entities = None
    stage = 'inventory'
    data = get_vars_from_path(loader, path, entities, stage)

    assert data is not None


# Generated at 2022-06-23 15:13:34.947347
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    class TestVariables():
        def get_vars(self, loader, path, entities, cache=True):
            return {'test': 'test2'}

    class TestVariables2():
        def get_group_vars(self, group, cache=True):
            return {'test': 'test3'}

        def get_host_vars(self, host, cache=True):
            return {'test': 'test4'}

    class TestAnsibleCollectionRef():
        @staticmethod
        def is_valid_fqcr(plugin_name):
            return True

    class TestVarsLoader():
        @staticmethod
        def get(plugin_name):
            return TestVariables()

        @staticmethod
        def all():
            return [TestVariables2()]


# Generated at 2022-06-23 15:13:42.735038
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    # Test that we can get vars from plugins by path
    class FakePlugin:
        def __init__(self, name):
            self._name = name

        def get_vars(self, loader, path, entities):
            assert path == '/path'
            assert entities == ['bla']
            return {
                self._name: 1,
            }

    # Test with one plugin
    loader = FakePlugin('pl1')
    data = get_vars_from_inventory_sources(None, ['/path'], ['bla'], 'inventory')
    assert data['pl1'] == 1

    # Test with multiple plugins
    loader = (FakePlugin('pl1'), FakePlugin('pl2'))

# Generated at 2022-06-23 15:13:47.614286
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    loader = None
    fake_path = "fake_path"
    fake_entities = "fake_entities"
    fake_result = "fake_result"

    class FakePlugin():
        _load_name = "test_plugin"
        _original_path = "/test/test_plugin"
        def get_vars(self, loader, path, entities):
            assert loader is None
            assert path == fake_path
            assert entities == fake_entities
            return fake_result
    plugin = FakePlugin()

    assert get_plugin_vars(loader, plugin, fake_path, fake_entities) == fake_result


# Generated at 2022-06-23 15:13:57.134691
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Initialize vars plugin loader and loader for collection
    # which contains vars plugins
    vars_loader.all()
    test_collection_loader = vars_loader._get_collection_loader()
    test_collection_loader.set_inventory_sources([])

    test_plugin = 'test.plugin.vars_from_path'

    # Get vars plugin
    plugin = test_collection_loader.get(test_plugin)
    assert plugin is not None

    # Get vars from path
    entities = [vars_loader.get('test.inventory_host_var')]
    data = get_plugin_vars(test_collection_loader, plugin, u'path', entities)

    assert data['foo'] == 'bar'

    # get_vars_from_path
    sources = ['path']

# Generated at 2022-06-23 15:13:59.518857
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    assert get_vars_from_inventory_sources(None, [], [], "") == {}

# Generated at 2022-06-23 15:14:08.930520
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    loader = None
    sources = ['test1/hosts','test2/hosts']
    entities = ['test1/hosts']
    stage = 'inventory'

    data = {}
    for path in sources:

        if path is None:
            continue
        if ',' in path and not os.path.exists(path):  # skip host lists
            continue
        elif not os.path.isdir(to_bytes(path)):
            # always pass the directory of the inventory source file
            path = os.path.dirname(path)
        else:
            path = "test1/vars/main"

        data = combine_vars(data, get_vars_from_path(loader, path, entities, stage))

    assert data['test_var'] == 1

# Generated at 2022-06-23 15:14:14.457245
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_files
    loader = vars_files.VarsModule()
    plugin = vars_files.VarsModule()
    path = b'c:\\programdata\\ansible\\'
    entities = []
    data = get_plugin_vars(loader, plugin, path, entities)
    assert data == {}

# Generated at 2022-06-23 15:14:24.720300
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    print("test_get_vars_from_inventory_sources")
    import os
    import tempfile
    import shutil
    os.environ['ANSIBLE_CONFIG'] = ''

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    print("using dir: %s" % tmpdir)

    # create a test plugin
    plugin_dir = os.path.join(tmpdir, 'test_plugin')
    os.mkdir(plugin_dir)

    plugin_file = os.path.join(plugin_dir, 'main.py')

# Generated at 2022-06-23 15:14:34.818339
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inv_obj = InventoryManager(loader=loader, sources=['tests/inventory/dynamic_inventory.yaml'])
    inv_obj.parse_inventory(cache=False)

    source_paths = inv_obj.sources._data['source_vars']
    sources = [source.get('source', None) for source in source_paths]

    test_entities = [
        inv_obj.get_host('test_host'),
        inv_obj.get_group('test_group'),
    ]
    vars_data = get_vars_from_inventory_sources(loader, sources, entities=test_entities, stage='inventory')

    # Tests for path

# Generated at 2022-06-23 15:14:41.802658
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    # Create a vars plugin object. Return single loader
    class TestVarPlugin(object):
        def get_vars(self, loader, path, entities, cache=True):
            return {'test_vars_key': 'test_vars_value'}

    vars_plugin_list = []
    vars_plugin_list.append(TestVarPlugin())

    # Create DataLoader object
    loader = DataLoader()

    # Create a vars_plugin variable
    vars_plugin = list(vars_plugin_list)[0]

    # Test call to get_vars_from_path function

# Generated at 2022-06-23 15:14:52.695985
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    loader = vars_loader
    # Test plugins in collection
    path = 'ansible.test_vars_plugins.vars_test'
    entities = ['localhost']
    stage = 'task'

    data = get_vars_from_path(loader, path, entities, stage)
    assert data['test_var'] == 'test_var_plugin'
    assert data['test_plugin_var'] == 'test_plugin_var_plugin'
    assert 'group_var_plugin' in data
    assert data['host_var_plugin'] == 'host_var_plugin_host'

    entities = ['localhost', 'test']
    data = get_vars_from_path(loader, path, entities, stage)
    assert 'group_var_plugin' in data

# Generated at 2022-06-23 15:14:57.168458
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    data = get_vars_from_inventory_sources(None, ['host_vars/hostname', "/etc/ansible", "localhost,", "vars_plugins"], [], 'initial')
    assert data
    assert isinstance(data, dict)

# Generated at 2022-06-23 15:15:06.614579
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.vars.manager import VariableManager

    class DummyModuleLoader():
        def __init__(self):
            self.module_vars = {}
            self.paths = []

        def add_directory(self, path):
            self.paths.append(path)

    class DummyPlugin():
        def __init__(self):
            self.vars = {}

        def get_vars(self, loader, path, entities):
            self.vars['loader'] = loader
            self.vars['path'] = path
            self.vars['entities'] = entities
            return {}

    loader = DummyModuleLoader()
    plugin = DummyPlugin()
    entity = Host("host1")
    data = get_plugin_vars(loader, plugin, "test_path", [entity])

# Generated at 2022-06-23 15:15:09.896329
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    plugin = vars_loader.get('from_from_yaml')
    assert get_plugin_vars(None, plugin, '/tmp/test', ['hostname']) == {}

# Generated at 2022-06-23 15:15:20.170079
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host

    loader = DataLoader()
    inv_mgr = InventoryManager(loader=loader, sources='tests/unit/test_vars_plugins/vars_plugins_src')

    all_group = Group(inventory=inv_mgr, name='all')
    all_group.vars = {
        'test_key': 'test_value'
    }

    host = Host(inventory=inv_mgr, name='fake_host')

    # TODO: Add some tests for groups also
    # test_group = Group(inventory=inv_mgr, name='test_group')
    # test_group.vars = {

# Generated at 2022-06-23 15:15:29.925487
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible import context
    from .test_inventory_plugins import BaseTestInventoryPlugin, TestInventoryPlugin, TestVarsPlugin

    class TestHost:
        def __init__(self, name):
            self.name = name

    context.CLIARGS = {'vars_plugins': ['test_vars']}
    loader = BaseTestInventoryPlugin()
    loader.add_plugin(TestInventoryPlugin())
    loader.add_plugin(TestVarsPlugin())

    # Test that empty sources doesn't raise an error
    assert get_vars_from_inventory_sources(loader, None, [], 'inventory') == {}

    # Test that a host list doesn't raise an error
    assert get_vars_from_inventory_sources(loader, ['some,hosts'], [], 'inventory') == {}

    #

# Generated at 2022-06-23 15:15:30.470244
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    assert False, 'No unit tests defined for this module.'

# Generated at 2022-06-23 15:15:40.557567
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    # Test a single invocation of get_vars_from_path to return some variables.
    def _get_vars_from_path(self):
        return {'test_var': 1}

    # Test that get_vars_from_inventory_sources invokes get_vars_from_path once
    # (with the right arguments).
    def _test_get_vars_from_path_called_once(self, loader, path, entities, stage):
        assert path == 'some_path'
        assert len(entities) == 1
        assert entities[0] == 'test_entity'
        assert stage == 'test_stage'
        return _get_vars_from_path(self)

    # Test that get_vars_from_inventory_sources returns the expected variables
    # when there is only one source.

# Generated at 2022-06-23 15:15:42.917322
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    loader = None
    plugin = None
    path = "path"
    data = {}
    entities = []
    assert get_plugin_vars(loader, plugin, path, entities) == data

# Generated at 2022-06-23 15:15:47.850962
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    # loader object is required, but not used
    class MockLoader():
        pass

    loader = MockLoader()

    # plugin object is required, but only 'get_vars' is needed
    class MockPlugin():
        def get_vars(self, loader, path, entities):
            return {'key': 'value'}

    plugin = MockPlugin()

    assert get_plugin_vars(loader, plugin, 'dummy path', []) == plugin.get_vars(loader, 'dummy path', [])

# Generated at 2022-06-23 15:16:00.011983
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    class VarsPluginFake:
        def __init__(self):
            return

        def get_vars(self, loader, path, entities):
            return {'fake_plugin_vars': 'fake_var_value'}

    class VarsPluginFake2:
        def __init__(self):
            return

        def get_vars(self, loader, path, entities):
            return {'fake_plugin2_vars': 'fake_var_value2'}

    class VarsPluginFake3:
        def __init__(self):
            return

        def get_host_vars(self, path):
            return {'fake_plugin3_vars': 'fake_var_value3'}


# Generated at 2022-06-23 15:16:05.755291
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    vars_plugin = vars_loader.get('vault_identity_lookup_plugin')
    data = get_vars_from_path(loader, '/home/saurabh', 'localhost', 'inventory')
    assert len(data) == 0

    data = get_vars_from_path(loader, None, 'localhost', 'inventory')
    assert len(data) == 0

    data = get_vars_from_path(loader, '/etc/ansible', 'localhost', 'task')
    assert len(data) == 0

    data = get_vars_from_path(loader, '/etc/ansible', 'localhost', 'inventory')
    assert len(data) == 1
    assert vars_plugin.get

# Generated at 2022-06-23 15:16:13.364027
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    def get_vars_from_inventory_sources(loader, sources, entities, stage):

        data = {}
        for path in sources:

            if path is None:
                continue
            if ',' in path and not os.path.exists(path):  # skip host lists
                continue
            elif not os.path.isdir(to_bytes(path)):
                # always pass the directory of the inventory source file
                path = os.path.dirname(path)

            data = combine_vars(data, get_vars_from_path(loader, path, entities, stage))

        return data

# Generated at 2022-06-23 15:16:16.833608
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    ''' Test that get_vars_from_path returns a dict '''
    loader = None

    vars_from_path = get_vars_from_path(loader, '/usr/local/etc/ansible/inventory', ['foo'], 'inventory')
    assert isinstance(vars_from_path, dict)

# Generated at 2022-06-23 15:16:26.211516
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins import vars_loader
    from ansible.plugins.vars import test_vars_plugin
    test_vars_plugin.reset()
    loader = vars_loader._create_loader()
    path = 'blah'
    group = Host('somehost', group='somemongroup')
    data = get_vars_from_path(loader, path, [group], 'inventory')
    assert isinstance(data, dict)
    assert data == {'test_host_variable': 'hostvar',
                    'test_group_variable': 'groupvar',
                    'test_inventory_variable': 'invvar'}
    # get_vars_from_path calls get_plugin_vars which calls get_vars on the plugin
    # assert that get_vars was called only once
    assert test_

# Generated at 2022-06-23 15:16:36.149532
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    import ansible.plugins.vars.test
    import ansible.plugins.vars.test2
    from ansible.inventory.manager import InventoryManager

    loader = 'True'
    path = 'True'
    entities = 'True'
    stage = 'True'

    data = {}
    plugin = ansible.plugins.vars.test.VarsModule()
    data = combine_vars(data, get_plugin_vars(loader, plugin, path, entities))

    test_pattern = 'True'
    plugin = ansible.plugins.vars.test2.VarsModule(test_pattern = test_pattern)
    data = combine_vars(data, get_plugin_vars(loader, plugin, path, entities))


# Generated at 2022-06-23 15:16:42.814454
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    plugin_name = 'test_vars'
    plugin_path = 'test_var_plugin.py'
    vars_plugin = vars_loader.get(plugin_name)
    data = get_plugin_vars(None, vars_plugin, None, None)
    assert plugin_path in data, "get_plugin_vars should return the data in the vars plugin"
    assert len(data) > 0, "get_plugin_vars should return some data"

# Generated at 2022-06-23 15:16:46.810136
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    loader = None
    path = "/path/"
    entities = None
    data = get_vars_from_path(loader, path, entities, 'start')
    assert isinstance(data, (dict))
    assert data == {}, "data value is not empty"

# Generated at 2022-06-23 15:16:55.129740
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    path = '/some/path'
    entities = ['entity1', 'entity2']

    example_vars_plugin_class = type('ExampleVarsPlugin', (object,), {
        'run': None,
        'get_vars': lambda self, loader, path, entities: {'path': path, 'entities': entities},
    })

    example_vars_plugin_instance = example_vars_plugin_class()

    assert get_vars_from_path(None, path, entities, None) == {'path': path, 'entities': entities}

# Generated at 2022-06-23 15:17:02.077948
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars.etc_environment import VarsModule
    plugin = VarsModule()

    inventory = {}
    loader = None
    path = '/etc'
    host = Host('127.0.0.1')
    host.vars = {}
    entities = [host]
    assert not plugin.get_vars(loader, path, entities)

    host.vars = {'ansible_connection': 'local'}
    assert plugin.get_vars(loader, path, entities)

# Generated at 2022-06-23 15:17:11.180972
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.vars.plugins.vars import VarsModule

    # Minimal vars plugin
    class MinPlugin(VarsModule):
        def get_vars(self, loader, path, entities):
            return {'mock plugin': True}

    # Minimal v2 plugin
    class SimplePlugin(object):
        def get_vars(self, loader, path, entities):
            return {'mock plugin': True}
        def get_options(self):
            return {'stage': ['all']}

    # Testing minimal plugin, v2
    test_plugin_vars = get_plugin_vars(None, SimplePlugin(), None, None)
    assert test_plugin_vars["mock plugin"]

    # Testing minimal plugin, v1

# Generated at 2022-06-23 15:17:19.327943
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.parsing.yaml.loader import AnsibleLoader

    plugin = AnsibleCollectionRef.from_string("community.general.autopep8")
    plugin = vars_loader.get(plugin)
    source = [
        "[all]\n",
        "192.168.0.1\n",
        "[test:children]\n",
        "test1\n",
        "test2\n",
        "[test1]\n",
        "192.168.0.2\n",
        "[test2]\n",
        "192.168.0.3\n"
    ]
    inventory = "".join(source)
    loader = AnsibleLoader(inventory, file_name=None)
    items = loader.get_single_data().items()
    data1 = get_plugin

# Generated at 2022-06-23 15:17:28.527603
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import combine_vars
    from ansible.plugins.vars import vars_loader
    from ansible.plugins.loader import vars_loader
    loader = DataLoader()
    sources = ['/path/to/ansible/inventory/source/file']
    entities = ['a', 'b']
    stage = 'inventory'
    orig_var_plug_list = vars_loader.all()
    my_plug_list = vars_loader.all()
    data = {}

# Generated at 2022-06-23 15:17:39.972551
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    test_dict = {'one': 1, 'two': 2}
    test_dict_two = {'three': 3, 'four': 4}
    test_dict_three = {'three': 5, 'five': 5}

    class TestPlugin:

        def __init__(self, path, test_dict):
            self.path = path
            self.test_dict = test_dict

        def get_vars(self, loader, path, entities):
            assert self.path is path
            return self.test_dict

    test_plugin = TestPlugin(None, test_dict)
    test_plugin_two = TestPlugin(None, test_dict_two)
    test_plugin_three = TestPlugin(None, test_dict_three)

    PluginLoader = vars_loader.__class__
    loader = PluginLoader()


# Generated at 2022-06-23 15:17:46.228933
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    class TestHost(Host):
        def __init__(self):
            self.name = 'localhost'
            self.vars = {'a': 'b'}
        def get_vars(self):
            return self.vars

    host = TestHost()
    hosts = [host]
    vars = get_vars_from_inventory_sources(inventory_manager, [], hosts, stage='task')
    assert len(vars) == 1
    assert vars['a'] == 'b'
    assert isinstance(vars, dict)

    vars = get_vars_from_inventory_sources(inventory_manager, [], hosts, stage='inventory')
    assert len(vars) == 0
    assert isinstance(vars, dict)



# Generated at 2022-06-23 15:17:51.984349
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    '''
    Test get_plugin_vars function
    '''

    class FakePlugin:
        _load_name = 'fake'

        def get_vars(self, loader, path, entities):
            return {'hello': 'world'}

    class FakePluginV1:
        _load_name = 'fake_v1'

        def get_group_vars(self, group):
            if group == 'group1':
                return {'foo': 'bar'}
            else:
                return {}

    # Test v2 plugin
    data = get_plugin_vars(None, FakePlugin(), 'some/place', ['host1', 'host2'])

    assert len(data) == 1
    assert 'hello' in data
    assert data['hello'] == 'world'

    # Test v1 plugin

# Generated at 2022-06-23 15:17:53.058947
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    # TODO
    pass

# Generated at 2022-06-23 15:18:04.460015
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    '''
    Test function get_plugin_vars with v2 plugins
    Test function get_plugin_vars with v1 plugin and no 'get_vars' method
    Test function get_plugin_vars with v1 plugin and no 'get_group_vars' method
    Test function get_plugin_vars with v1 plugin and no 'get_host_vars' method
    Test function get_plugin_vars with v1 plugin and 'run' method
    '''
    loader = MockLoader()
    plugin = MockVarsPlugin()

    plugin.get_vars = MagicMock()
    try:
        get_plugin_vars(loader, plugin, 'path', 'entities')
    except AnsibleError:
        assert False, "unexpected AnsibleError exception"

    del plugin.get_vars

# Generated at 2022-06-23 15:18:12.650504
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.plugins import vars_loader as vars_loader_mod

    class MockPlugin:
        def get_vars(self, loader, path, entities):
            return {'foo': 'bar'}

    mock_plugin = MockPlugin()
    vars_loader_mod.all.return_value = [mock_plugin]

    class MockLoader:
        pass

    sources = ["path1", "path2"]
    entities = ["test1", "test2"]
    stage = "test"

    vars = get_vars_from_inventory_sources(MockLoader, sources, entities, stage)
    assert vars == {'foo': 'bar'}

# Generated at 2022-06-23 15:18:21.293401
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    # code to be run before running the unit test
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    # Contexualized inventory - this is added to, so the
    # result of the test will change if other test have added
    # data to the inventory
    inventory = InventoryManager(loader=DataLoader(), sources=[])

    # create a host in the inventory
    host = inventory.hosts['host_with_vars']
    host.vars['host_var'] = 'host_value'

    # create a group in the inventory
    group = inventory.groups['group_with_vars']
    group.vars['group_var'] = 'group_value'

    # create a group in the inventory
   

# Generated at 2022-06-23 15:18:31.726226
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    loader = None
    path = "/etc/ansible/test_vars_dir"
    entities = []
    stage = None

    from ansible.plugins.vars import TestVarsPlugin

    vars_plugin_list = list(vars_loader.all())
    for plugin_name in C.VARIABLE_PLUGINS_ENABLED:
        vars_plugin = vars_loader.get(plugin_name)
        if vars_plugin is None:
            # Error if there's no play directory or the name is wrong?
            continue
        if vars_plugin not in vars_plugin_list:
            vars_plugin_list.append(vars_plugin)
    vars_plugin_list.append(TestVarsPlugin())


# Generated at 2022-06-23 15:18:39.126840
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    class MockVarsPlugin():

        class FakeHost():
            name = 'localhost'

        def get_vars(self, loader, path, entities):
            return {'test': 'v2'}

        def get_host_vars(self, path, host):
            return {'test': 'v1'}

        def get_group_vars(self, path, group):
            return {}

    loader = MockVarsPlugin()

    assert {'test': 'v1'} == get_plugin_vars(loader, loader, None, [MockVarsPlugin.FakeHost()])
    assert {'test': 'v2'} == get_plugin_vars(loader, loader, None, None)



# Generated at 2022-06-23 15:18:49.240451
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    class TestLoader:
        def get_basedir(self):
            return os.getcwd()

    class TestPlugin:
        def get_vars(self, loader, path, entities):
            return {'plugin_key': 'plugin_value'}

        def get_group_vars(self, name):
            return {'plugin_key_group': name}

        def get_host_vars(self, name):
            return {'plugin_key_host': name}

    class TestEntity:
        def __init__(self, name):
            self.name = name

    loader = TestLoader()
    plugin = TestPlugin()
    path = os.getcwd()
    entities = [TestEntity('test')]
    data = get_plugin_vars(loader, plugin, path, entities)

# Generated at 2022-06-23 15:18:52.588908
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    loader = None
    sources = []
    entities = {}
    stage = "inventory"
    assert get_vars_from_inventory_sources(loader, sources, entities, stage) == {}

# Generated at 2022-06-23 15:18:56.172638
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    assert get_vars_from_inventory_sources(
        loader=None,
        sources=['not-a-directory', 'also-not-a-directory'],
        entities=None,
        stage='task') == {}

# Generated at 2022-06-23 15:19:06.039948
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    class MockPlugin():
        def get_host_vars(self, host):
            return {'host_var': host}

        def get_group_vars(self, group):
            return {'group_var': group}

        def get_plugin_vars(self, loader, path, entities):
            return {'plugin_vars': True}

    import os
    import unittest
    from ansible.errors import AnsibleError

    class TestPlugin(unittest.TestCase):
        def setUp(self):
            self.loader = os
            self.path = 'foo/bar'
            self.entities = []


# Generated at 2022-06-23 15:19:17.077534
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Test with one host in a group and no vars plugins defined in config
    loader = None
    path = "path/to/inventory/file"
    host = Host(name="host")
    group = Host(name="group")
    group._set_vars_from_file("group_vars/group")
    group.add_child(host)
    entities = [ host, group ]
    stage = "inventory"
    data = get_vars_from_path(loader, path, entities, stage)
    assert data == {}, "get_vars_from_path returned an empty dict"

    # Test with one host in a group and one vars plugin defined in config
    C.VARIABLE_PLUGINS_ENABLED = [ "test_plugin" ]
    vars_plugin = object()
    vars_

# Generated at 2022-06-23 15:19:24.286214
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars.test_vars import TestVars
    class TestVars2(TestVars):
        def __init__(self):
            super(TestVars2, self).__init__()
            self.get_vars = self.get_host_vars

    class TestVars3(TestVars):
        def __init__(self):
            super(TestVars3, self).__init__()
            self.get_vars = self.get_group_vars

    class TestVars4(TestVars):
        def __init__(self):
            super(TestVars4, self).__init__()
            self.run = self.get_group_vars
