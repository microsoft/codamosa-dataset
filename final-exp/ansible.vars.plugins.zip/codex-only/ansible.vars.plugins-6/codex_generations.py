

# Generated at 2022-06-23 15:09:21.539859
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.loader import vars_loader
    from ansible.plugins.vars.dirname import VarsModule
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    path = '/root/.ansible/tmp/ansible-local-20005U5WQK/tmpRd6fZU'
    loader = DataLoader()
    inventory_manager = InventoryManager(loader=loader, sources=["hosts"])
    plugin = VarsModule()
    entity = Host(name='localhost')
    plugin._load_name = 'test.py'

# Generated at 2022-06-23 15:09:22.530413
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    for i in range(20):
        print (i)



# Generated at 2022-06-23 15:09:31.381648
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    class vars_plugin:
        def __init__(self, name):
            self.name = name

        def get_vars(self, loader, path, entities):
            return {self.name: 'v2'}

        def get_group_vars(self, group):
            return {self.name: 'v1'}

    class vars_plugin_v1:
        def __init__(self, name):
            self.name = name

        def get_group_vars(self, group):
            return {self.name: 'v1'}

    class vars_plugin_fail:
        def __init__(self, name):
            self.name = name

    class Loader:
        def __init__(self, name):
            self.name = name


# Generated at 2022-06-23 15:09:31.976799
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    pass

# Generated at 2022-06-23 15:09:41.311864
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    """Test to validate get plugin vars vars plugin is behaving correctly."""
    example_vars_path = os.path.join('test', 'units', 'vars_plugins', 'example_vars_plugin')
    vars_plugin = vars_loader.get(example_vars_path)
    actual = get_plugin_vars(vars_loader, vars_plugin, 'test/units/vars_plugins/example_vars_plugin/', [])
    expected = {
        'example_1': 'This is a first example',
        'example_2': 'This is a second example',
        'example_3': 'This is a third example',
        'example_4': 'This is a fourth example',
    }
    assert actual == expected

# Generated at 2022-06-23 15:09:44.976295
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    loader = 'test'
    entities = ['test']
    stage = 'test'
    sources = ['path']
    assert get_vars_from_inventory_sources(loader, sources, entities, stage) == {}

# Generated at 2022-06-23 15:09:51.242937
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['hosts'])
    for host in inventory.hosts.values():
        print(get_vars_from_path(loader, '', host, 'inventory'))

if __name__ == '__main__':
    test_get_vars_from_path()

# Generated at 2022-06-23 15:10:02.497054
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import BaseVarsPlugin

    class EmptyVars(BaseVarsPlugin):
        pass

    class HostVars(BaseVarsPlugin):
        def get_host_vars(self, hostname):
            return {'host_vars': 'host_vars'}

    class GroupVars(BaseVarsPlugin):
        def get_group_vars(self, groupname):
            return {'group_vars': 'group_vars'}

    class BothVars(BaseVarsPlugin):
        def get_host_vars(self, hostname):
            return {'host_vars': 'host_vars'}
        def get_group_vars(self, groupname):
            return {'group_vars': 'group_vars'}


    loader = v

# Generated at 2022-06-23 15:10:13.076151
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    from ansible.plugins.loader import vars_loader

    # load normal vars plugin
    vars_plugin = vars_loader.get('file')

    # load vars_plugins of host and group
    host_plugin = vars_loader.get('host_specific')
    group_plugin = vars_loader.get('static_group_vars_plugin')

    # test vars_plugin
    result = get_plugin_vars(vars_plugin, "./", None)
    assert isinstance(result, dict)

    # test host_plugin
    result = get_plugin_vars(group_plugin, "./", None)
    assert isinstance(result, dict)

    # test host_plugin
    result = get_plugin_vars(host_plugin, "./", None)

# Generated at 2022-06-23 15:10:22.832453
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    loader = 'fake_loader'
    stage = 'task'
    sources = ['/fake1', '/fake2']

    # get_vars_from_inventory_sources()
    # data = None
    # data = get_vars_from_inventory_sources(loader, sources, stage)
    # assert data == None

    # host_list_entity = ['fake_host']
    # host_list_entity = Host(loader, 'fake_host', 'fake_host')
    host_list_entity = ['myvm', 'myvm1', 'myvm2', 'myvm3', 'myvm4']
    data = {}
    data = get_vars_from_inventory_sources(loader, sources, host_list_entity, stage)
    assert data == {}


# Generated at 2022-06-23 15:10:34.047611
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import TestVarsPlugin

    entities = [('host1', 'group1'), ('host2', 'group2')]
    data = {
        'host1': {'test': 1},
        'host2': {'test': 2},
        'group1': {'test': 3},
        'group2': {'test': 4}
    }
    plugin = TestVarsPlugin(data=data)
    test_data = get_plugin_vars(None, plugin, None, entities)

    assert test_data.get('test') == 1
    assert test_data.get('group_vars', {}).get('group1', {}).get('test') == 3

# Generated at 2022-06-23 15:10:42.386579
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    inv = InventoryManager(loader=None, sources=['/etc/ansible/hosts', '/etc/ansible/hosts2:12'])
    vars = get_vars_from_inventory_sources(None, inv._inventory._sources, inv._inventory._hosts, 'inventory')
    assert vars is not None
    assert "test1" in vars.get("group", {})
    assert vars.get("group2", {}) is not None

# Generated at 2022-06-23 15:10:52.863297
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    # Test plugin with get_vars method

    class FakeVarsPlugin:
        def get_vars(loader, path, entities):
            return {'foo': 'bar'}

    data = get_plugin_vars('loader', FakeVarsPlugin(), 'path', 'entities')
    assert isinstance(data, dict)
    assert 'foo' in data
    assert data == {'foo': 'bar'}

    # Test plugin with get_host_vars and get_group_vars methods

    class FakeVarsPlugin2:
        def get_host_vars(self, hostname):
            return {'foo': 'bar'}

        def get_group_vars(self, groupname):
            return {}

    data = get_plugin_vars('loader', FakeVarsPlugin2(), 'path', 'entities')

# Generated at 2022-06-23 15:11:03.145748
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    print()
    # Set a global value of RUN_VARS_PLUGINS to a value other than 'start'
    current_run_vars_plugins = C.RUN_VARS_PLUGINS
    C.RUN_VARS_PLUGINS = 'demand'

    vars_plugin_list = list(vars_loader.all())
    for plugin_name in C.VARIABLE_PLUGINS_ENABLED:
        if AnsibleCollectionRef.is_valid_fqcr(plugin_name):
            vars_plugin = vars_loader.get(plugin_name)
            if vars_plugin is None:  # Error if there's no play directory or the name is wrong?
                continue

# Generated at 2022-06-23 15:11:10.308270
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    # Plugin returning empty dict
    def mock_get_vars(loader, path, entities):
        return {'a1': 1}
    result = {}
    result = get_vars_from_inventory_sources(None, ['path'], None, 'task')
    assert {} == result
    # Plugin returning dict 
    hostvars_loader_plugin.get_vars = mock_get_vars
    result = get_vars_from_inventory_sources(None, ['path'], None, 'task')
    assert {'a1': 1} == result
    

# Generated at 2022-06-23 15:11:15.987379
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
  display.verbosity=0
  loader = C.DEFAULT_LOADER
  path = "./"
  entities = []
  stage = "inventory"
  data = get_vars_from_path(loader, path, entities, stage)
  assert type(data) is dict
  assert "host_specific_vars" in data


# Generated at 2022-06-23 15:11:16.496327
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    assert False

# Generated at 2022-06-23 15:11:19.888674
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Setup
    loader = AnsibleLoader()
    path = '.'
    entities = [Host(name='localhost')]
    stage = 'inventory'

    # Execute
    data = get_vars_from_path(loader, path, entities, stage)

    # Assert
    assert data is not None
    assert len(data) > 0


# Generated at 2022-06-23 15:11:29.394871
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    display.verbosity = 0

    # no plugin
    result = get_vars_from_path(None, '/path/to/inventory', None, None)

    assert result == {}

    # fake plugin
    loader = None
    path = '/path/to/inventory'
    entity = None
    stage = None

    plugin = object()
    plugin.REQUIRES_WHITELIST = False
    plugin.get_vars = lambda x, y, z: dict(hello='world')

    get_plugin_vars(loader, plugin, path, entity)
    result = get_vars_from_path(loader, path, entity, stage)

    assert result == dict(hello='world')

    # fake plugin: get_host_vars
    plugin = object()

# Generated at 2022-06-23 15:11:33.367285
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    data = {}
    loader = None
    plugin_list = list(vars_loader.all())
    for plugin in plugin_list:
        data = get_plugin_vars(loader, plugin, '/tmp', ['test'])


# Generated at 2022-06-23 15:11:44.117029
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.vars.host_group_vars import HostVars
    from ansible.plugins.vars.host_group_vars import GroupVars
    from ansible.plugins.vars.host_group_vars import VarsModule

    class MockVarsPlugin(object):
        """a mock plugin with run as old v1 plugin have only run method"""

        def run(self):
            return dict()

    # Setup all possible plugin path
    loader = C.property_overrides.get('ANSIBLE_VARS_PLUGINS')
    if loader is not None:
        loader = os.environ.get('ANSIBLE_VARS_PLUGINS')
    if not loader:
        loader = C.DEFAULT_VARS_PLUGIN_PATH

    # if a user has specified an alternate plugin path,

# Generated at 2022-06-23 15:11:44.586269
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert True

# Generated at 2022-06-23 15:11:53.534653
# Unit test for function get_vars_from_path

# Generated at 2022-06-23 15:11:54.066829
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    pass

# Generated at 2022-06-23 15:11:55.722330
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    assert False, "The tests haven't been implemented yet"

# Generated at 2022-06-23 15:12:02.895122
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    vars_loader.add("test_vars", None, os.path.join(os.path.dirname(__file__), 'vars_plugins', 'test_vars.py'))

    assert get_vars_from_path(None, None, [], 'inventory') == {'a': 'foo', 'b': ['1', '2', '3'], 'c': {'d': 'ef'}}

    vars_loader.remove("test_vars")

# Generated at 2022-06-23 15:12:09.991757
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    # pylint: disable=no-self-use
    class mock_plugin:
        # pylint: disable=too-few-public-methods
        def __init__(self, vars_result):
            self._vars_result = vars_result

        def get_vars(self, loader, path, entities):
            return self._vars_result

    plugin = mock_plugin({'key1': 'value1'})
    assert get_plugin_vars(None, plugin, None, None) == {'key1': 'value1'}

# Generated at 2022-06-23 15:12:17.401363
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    test_data = {}
    test_data['inventory_file'] = 'tests/unit/inventory/test_inventory.yml'
    test_data['inventory_file_contents'] = """
    plugin_test_group:
      hosts:
        plugin_test_host:
          ansible_connection: local
          ansible_python_interpreter: '/usr/bin/python'
        plugin_test_host2:
          ansible_connection: local
          ansible_python_interpreter: '/usr/bin/python'
    """
    test_data['host_vars_file'] = 'tests/unit/inventory/group_vars/plugin_test_group'

# Generated at 2022-06-23 15:12:27.873370
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.cli import CLI

    data_loader = DataLoader()
    cli = CLI()
    cli.options = cli.base_parser(constants=C, usage="", output_opts=True).parse_args(args=[])
    inventory_manager = InventoryManager(loader=data_loader, sources=['tests/integration/inventory_manager/hostlist'])
    variable_manager = VariableManager(loader=data_loader, inventory=inventory_manager)

    # Get variables from host

# Generated at 2022-06-23 15:12:37.256397
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from string import ascii_letters
    _inventory_sources = ['/etc/ansible/hosts']
    _entities = ['localhost']

    # Build Dir tree for test
    for i in range(4):
        for dir_name in _entities:
            path = "test/test_get_vars_from_inventory_sources/{0}".format(dir_name)
            for j in range(i):
                path = "{0}/{1}".format(path, ''.join(random.choice(ascii_letters) for x in range(10)))
            os.makedirs(path)

    # Build Mock loader
    class Mock_Loader(object):
        def get_basedir(self):
            return "/etc/ansible"

    # Build Mock Entities

# Generated at 2022-06-23 15:12:43.121393
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    display.verbosity = 3
    my_loader = vars_loader
    my_plugin_list = list(my_loader.all())
    my_plugin = my_plugin_list[0]
    my_path = '.'
    my_entities = [
        "test1",
        "test2",
        "test3",
        "test4",
        "test5"
    ]
    print("test_get_plugin_vars:")
    my_data = get_plugin_vars(my_loader, my_plugin, my_path, my_entities)
    print("data is: ")
    print(my_data)
    assert(my_data == {})


# Generated at 2022-06-23 15:12:48.052418
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    # pylint: disable=unused-variable
    loader = None
    sources = ['/tmp/test.yml']
    inventory = None
    stage = 'task'
    result = get_vars_from_inventory_sources(loader, sources, inventory, stage)
    assert result == {'test_data': 'test_data'}

# Generated at 2022-06-23 15:12:53.344488
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    import ansible.plugins.vars.host_group_vars
    import ansible.plugins.vars.group_vars
    from ansible.plugins.loader import vars_loader

    vars_loader._cached_plugins = {}
    vars_loader._plugin_packages = {
        'vars': ansible.plugins.vars,
    }
    vars_loader.add_directory(os.path.join(os.path.dirname(__file__), 'test_vars_plugins'))
    assert ansible.plugins.vars.host_group_vars == vars_loader._modules['ansible.plugins.vars.host_group_vars']

# Generated at 2022-06-23 15:13:05.608142
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    loader = None
    path = None
    entities = []

    # Test Plugin that returns a dictionary
    class MockVarsPlugin1(object):
        def get_vars(self, loader, path, entities, cache=True):
            return {'Mock Vars Plugin' : 1 }

    plugin1 = MockVarsPlugin1()
    result = get_plugin_vars(loader, plugin1, path, entities)
    assert 'Mock Vars Plugin' in result
    assert result['Mock Vars Plugin'] == 1

    # Test Plugin that returns a list of dictionaries
    class MockVarsPlugin2(object):
        def get_vars(self, loader, path, entities, cache=True):
            return [{'Mock Vars Plugin' : 2 }, {'Mock Vars Plugin' : 3 }]


# Generated at 2022-06-23 15:13:08.634831
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    data = {}
    for entity in [Host('localhost'), Host('example.com')]:
        data.update(entity.name)

    assert data == {'localhost': None, 'example.com': None}


# Generated at 2022-06-23 15:13:17.182630
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    data = {}
    sources = ['test_path']
    entities = ['test_entity']
    stage = 'test_stage'

    test_result = {}
    test_plugin = vars_plugin()
    test_plugin.get_vars = test_func
    test_plugin.REQUIRES_WHITELIST = False

    vars_loader.all = lambda: [test_plugin]
    result = get_vars_from_path(None, sources, entities, stage)
    if result != test_result:
        raise AssertionError("Expected result is empty - got %s" % result)

    test_result = {'var':'test_value'}
    test_plugin.REQUIRES_WHITELIST = True

# Generated at 2022-06-23 15:13:26.778577
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import vars_loader

    class FakeHost(object):
        def __init__(self, name):
            self.name = name

    loader = vars_loader.get('yaml_file')
    context = PlayContext(loader=loader)
    entities = [FakeHost('test_host')]
    data = get_vars_from_path(loader, './test/unit/ansible_collections/test/files/library', entities, 'inventory')
    assert data == {'all_hosts': ['test_host'], 'test_host': {'boolean': True}}

# Generated at 2022-06-23 15:13:34.633573
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Arrange
    import types
    import sys
    import imp

    # create a plugin
    plugindir = os.path.join(sys.path[0], 'test-plugin')
    if not os.path.exists(plugindir):
        os.mkdir(plugindir)
    pluginfile = os.path.join(plugindir, 'vars.py')

# Generated at 2022-06-23 15:13:38.761964
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    path = './'
    stage = 'inventory'
    entities = None
    loader = 'loader'
    plugin = 'plugin'
    expected_result = '{}'
    actual_result = get_vars_from_path(loader, path, entities, stage)
    assert actual_result == expected_result

# Generated at 2022-06-23 15:13:50.428027
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.parsing.utils.addresses import Address, AddressRange
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    # This directory has the following structure:
    # data/
    #     example.yaml
    #     example.ini
    #     test.yaml
    #     test.ini
    host_vars_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data', 'host_vars')
    group_vars_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data', 'group_vars')
    loader = DataLoader()


# Generated at 2022-06-23 15:13:58.516216
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from unittest import TestCase
    from ansible.module_utils._text import to_text
    class StubPlugin:
        def get_vars(self, loader, path, entities):
            return {'vars': path}

    class StubHost:
        def __init__(self, name):
            self.name = name

    class GetPluginVarsTestCase(TestCase):

        def test_get_vars_with_get_vars(self):
            plugin = StubPlugin()
            loader = None
            path = 'test_path'
            entities = [StubHost('test')]
            result = get_plugin_vars(loader, plugin, path, entities)
            self.assertEqual(result['vars'], path)


# Generated at 2022-06-23 15:14:08.033525
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin_base
    from ansible.plugins.loader import vars_loader
    vars_loader.add("test_plugin", vars_plugin_base, "test")
    loader = vars_loader.all("test_plugin")
    test_plugin = loader[0]
    test_entity = Host("test_host")
    path = "test_path"
    entities = [test_entity]
    try:
        data = get_plugin_vars(loader, test_plugin, path, entities)
        display.display("failed to get error", verbosity=2)
        assert False
    except AnsibleError:
        display.display("received expected error", verbosity=2)
        assert True

# Generated at 2022-06-23 15:14:15.430637
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    class MockPlugin(object):
        def __init__(self):
            self._load_name = 'testmodule'

        def get_vars(self, loader, path, entities):
            return {'testvar': 'testvalue'}

    loader = object()
    plugin = MockPlugin()
    path = 'testpath'
    entities = [None]

    vars = get_plugin_vars(loader, plugin, path, entities)

    assert vars == {'testvar': 'testvalue'}


# Generated at 2022-06-23 15:14:25.527850
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars.host_list import VarsModule as VarsModuleHostList
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager

    plugin1 = VarsModuleHostList()
    plugin1._original_path = './test.yml'
    plugin1._load_name = 'host_list'
    vars_loader.add(plugin1, "test1")

    plugin2 = VarsModuleHostList()
    plugin2._original_path = './test.yml'
    plugin2._load_name = 'host_list'
    vars_loader.add(plugin2, "test2")

    entities = []

# Generated at 2022-06-23 15:14:26.473424
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    return None


# Generated at 2022-06-23 15:14:34.662952
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    assert get_vars_from_inventory_sources(None, ['/path/to/file'], ['entity'], 'inventory') == {}
    assert get_vars_from_inventory_sources(None, ['/path/to/file'], ['entity'], 'task') == {}

    data = {'test': 'a'}
    assert get_vars_from_inventory_sources(data, ['/path/to/file'], ['entity'], 'inventory') == data
    assert get_vars_from_inventory_sources(data, ['/path/to/file'], ['entity'], 'task') == data

# Generated at 2022-06-23 15:14:39.979606
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager

    inventory = InventoryManager(loader=None, sources=["test/integration/inventory/hosts_file_contains_vars_plugin_sections"])

    assert get_vars_from_inventory_sources(loader=None, sources=inventory._sources, entities=[], stage=None) == {'some_var': 'some_value',
                                                                                                                'some_other_var': 'foo',
                                                                                                                'some_other_different_var': 'bar'}

# Generated at 2022-06-23 15:14:41.039824
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    pass


# Generated at 2022-06-23 15:14:45.229221
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.loader import vars_loader
    plugin = vars_loader.get('test_vars_plugin')
    assert get_plugin_vars(None, plugin, None, []) == dict(plugin_key='plugin_value')

# Generated at 2022-06-23 15:14:52.217351
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import Facts

    plugin = Facts()
    entities = [Host(name='testhost')]
    assert(get_plugin_vars(None, plugin, 'testhost', entities) == {})

    # Facts plugin does not implement get_vars method
    plugin = Facts()
    entities = [Host(name='testhost')]
    assert(get_plugin_vars(None, plugin, 'testhost', entities) == {'ansible_testhost': {'inventory_hostname': 'testhost'}})

# Generated at 2022-06-23 15:15:03.595933
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    class fake_loader:
        def __init__(self, inventory_sources, stage):
            self.inventory_sources = inventory_sources
            self.stage = stage

    C.RUN_VARS_PLUGINS = None
    inventory_sources = [os.path.join(os.path.dirname(__file__), '../../../../../test/integration/inventory/')]
    stage = 'inventory'
    entities = ['host_1', 'host_2']
    loader = fake_loader(inventory_sources, stage)
    assert get_vars_from_inventory_sources(loader, inventory_sources, entities, stage) == {'host_1': 1, 'host_2': 2}

    stage = 'task'
    loader = fake_loader(inventory_sources, stage)
   

# Generated at 2022-06-23 15:15:11.154738
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    inventory = "./sample_hosts"
    stage = "task"
    source = [inventory]
    host = "host01"

    host = Host(host, groups=["group01", "group02"])

    loader = get_vars_from_inventory_sources(source, [host], stage)
    print(loader)


if __name__ == '__main__':
    test_get_vars_from_inventory_sources()

# Generated at 2022-06-23 15:15:20.743268
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.parsing.vault import VaultLib
    from ansible.plugins.loader import vars_loader

    vl = VaultLib('ADH', ['vault_password'])

# Generated at 2022-06-23 15:15:23.644410
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    assert get_vars_from_inventory_sources(None, ['/tmp/does_not_exist', '/tmp/does_not_exist_2'], [], 'start') == {}

# Generated at 2022-06-23 15:15:33.732161
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    inventory_sources="inventories/test/inventory_source"
    vars_plugin_list = list(vars_loader.all())
    loader = vars_loader.get("host_choice")
    sources=[inventory_sources]
    inventory = InventoryManager(loader=loader, sources=sources)
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    plugin = inventory.get_plugin(loader.get('host_choice'))
    data=get_plugin_vars(loader, plugin, '/etc/ansible', [Host('test_hostname')])
    assert data['host_choice']['value'] == 'a'

#

# Generated at 2022-06-23 15:15:43.531085
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    ansible_config = ('[defaults]\n'
                      'inventory = /tmp/\n'
                      'vars_plugins = ansible.builtin.yaml_file, ansible.builtin.vault\n'
                      'run_vars_plugins = demand\n')
    loader = MockLoader(ansible_config)
    sources = ['/tmp/hosts', '/tmp/group_vars/all.yml', '/tmp/host_vars/host1.yml']
    entities = [MockInventoryGroup('all'), MockInventoryHost('host1')]
    vars = get_vars_from_inventory_sources(loader, sources, entities, 'inventory')
    assert vars
    assert vars['group_var'] == 'group variable value'
    assert vars['group_var2']

# Generated at 2022-06-23 15:15:52.879047
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins import vars_plugins
    from ansible.vars.manager import VariableManager

    sources = ['tests/integration/targets/test_vars_plugin']

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=sources)
    while True:
        try:
            inventory.refresh_inventory()
            break
        except AnsibleError as e:
            pass
    host = Host(name="test_vars_plugin1")
    inventory.add_host(host)
    group = inventory.get_group("test_vars_plugin")
    group.add_host(host)
    DataManager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-23 15:15:55.279588
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    import tempfile
    open(tempfile.mktemp(), 'a').close()

# Generated at 2022-06-23 15:16:04.357933
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    sources = ['/path/to/inventories/aws/dev', '/path/to/inventories/aws/prod']
    assert get_vars_from_inventory_sources(None, sources, None, 'inventory')

    sources = ['/path/to/inventories/aws/dev', '']
    assert get_vars_from_inventory_sources(None, sources, None, 'inventory')

    assert get_vars_from_inventory_sources(None, [''], None, 'inventory')
    assert get_vars_from_inventory_sources(None, '', None, 'inventory')
    assert get_vars_from_inventory_sources(None, None, None, 'inventory')

# Generated at 2022-06-23 15:16:14.931973
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.module_utils.common._collections_compat import Mapping
    import sys
    import pytest
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.plugin_docs import read_docstring, _load_plugins

    class FakeLoader():
        def __init__(self, variable_manager):
            self.variable_manager = variable_manager

    class FakePlugin():
        def __init__(self, load_name, original_path):
            self.load_name = load_name
            self.original_path = original_path

        def get_vars(self, loader, path, entities):
            entities_name = []
            for entity in entities:
                entities_name.append(entity.name)

# Generated at 2022-06-23 15:16:23.913636
# Unit test for function get_vars_from_inventory_sources

# Generated at 2022-06-23 15:16:32.119997
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    # Init a plugin
    class TestPlugin(object):
        def __init__(self, plugin_name='test'):
            self._load_name = plugin_name
            self._original_path = plugin_name + '_test_path'

        def get_vars(self, loader, path, entities):
            return {'test': 'get_vars'}

    test_plugin = TestPlugin()
    assert get_plugin_vars(loader=None, plugin=test_plugin, path=None, entities=None) == {'test': 'get_vars'}

# Generated at 2022-06-23 15:16:43.878319
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    try:
        import ansible.plugins.vars.old_base
        old_base = ansible.plugins.vars.old_base.VarsModule
    except ImportError:
        old_base = None

    class TestBase():
        has_option = False
        REQUIRES_WHITELIST = False
        _load_name = "test"
        _original_path = "test"

    class TestVars(TestBase, old_base):
        def __init__(self):
            self.name = "test"
            self.vars = {'a': '1'}

        def get_vars(self, loader, path, entities):
            return self.vars

        def get_host_vars(self, host):
            return self.vars


# Generated at 2022-06-23 15:16:55.117012
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    class MockHost(object):
        def __init__(self, name):
            self.name = name

    class MockGroup(object):
        def __init__(self, name):
            self.name = name

    class MockVarsPlugin(object):
        def __init__(self):
            self.get_vars_called = False
            self.get_group_vars_called = False
            self.get_host_vars_called = False

        def get_vars(self, loader, path, entities):
            self.get_vars_called = True
            return {'get_vars': True}

        def get_group_vars(self, name):
            self.get_group_vars_called = True
            return {'get_group_vars': True}


# Generated at 2022-06-23 15:17:04.924746
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars

    # setup the loader with inventory
    loader = DataLoader()
    loader.set_basedir('/path/to/playbook')
    inventory = Inventory(loader, '/path/to/playbook/hosts')
    inventory.add_host('foo')
    inventory.add_group('bar')

    # load the hostvars plugin
    hostvars = HostVars(loader)
    hostvars._set_plugin_options({'stage': 'all', 'inventory_dir': '/path/to/playbook'})

    # test

# Generated at 2022-06-23 15:17:15.904757
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.vars.hashivault_fact import HashivaultFact
    loader = DummyLoader()
    plugin = HashivaultFact()
    path = '/path/to/dir'

    entities = [
        DummyHost('host1'),
        DummyHost('host2')
    ]
    result = get_plugin_vars(loader, plugin, path, entities)
    assert 'ansible_facts' in result
    assert result['ansible_facts']['host1']['ansible_hashivault_ansible_user'] == 'user'
    assert result['ansible_facts']['host2']['ansible_hashivault_ansible_user'] == 'user'

    entities = [
        DummyHost('host1'),
        DummyHostGroup('group1')
    ]

# Generated at 2022-06-23 15:17:18.179038
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    hosts = ['localhost', '127.0.0.1']
    get_vars_from_path(loader, hosts)

# Generated at 2022-06-23 15:17:19.723386
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert get_vars_from_path({}, '.', [], 'inventory') == {}

# Generated at 2022-06-23 15:17:21.208653
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert get_vars_from_path(None, None, None, None) is not None

# Generated at 2022-06-23 15:17:29.785020
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.cli.playbook import PlaybookCLI
    from ansible.plugins import plugin_loader
    import sys

    test_vars_path = os.path.join(os.path.dirname(__file__), "../../../../test/integration/vars_plugins")
    test_inventory_path = os.path.join(os.path.dirname(__file__), "../../../../test/integration/inventory/hosts")
    test_fqcr = 'ansible.test.vars_plugins'

    # Update plugin path
    plugin_loader.add_directory(test_vars_path)

    # Add test vars plugin to enabled list of vars plugins
    C.VARIABLE_PLUGINS_ENABLED.append(test_fqcr)

    # Set test inventory source

# Generated at 2022-06-23 15:17:31.088606
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    pass


# Generated at 2022-06-23 15:17:39.412674
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    plugin_path = 'plugins/vars/dummy.py'
    plugin_dir = os.path.dirname(plugin_path)
    plugin_file = os.path.basename(plugin_path)

    m = None
    vars_plugin_list = list(vars_loader.all())
    for vars_plugin in vars_plugin_list:
        if vars_plugin.__name__ == '_dummy':
            m = vars_plugin
            break
    assert m is not None

    host = Host('localhost')

# Generated at 2022-06-23 15:17:49.887369
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    loader = None
    path = None
    entities = []
    stage = 'inventory'
    # path = None
    # entities = ['localhost']
    # stage = 'inventory'
    # path = '.'
    # entities = ['/opt/dummy/my_collection/my_role/tasks']
    # stage = 'task'
    # path = '.'
    # entities = ['/opt/dummy/my_collection/my_role/tasks/main.yml']
    # stage = 'task'
    # path = '.'
    # entities = ['/opt/dummy/my_collection/my_role']
    # stage = 'task'
    data = get_vars_from_path(loader, path, entities, stage)
    print('Vars data: {}'.format(data))

# Unit test

# Generated at 2022-06-23 15:17:59.291431
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    from ansible.inventory.manager import InventoryManager

    sources = [
        "/etc/ansible/hosts",
        "/Users/joe/inventory",
        "localhost,"
    ]

    # add plugin vars here for testing

    vars_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), '../../../plugins/vars')

    os.environ['ANSIBLE_VAR_PLUGINS'] = vars_path
    vars_loader.add_directory(vars_path, with_subdir=False)

    inventory = InventoryManager(loader=None, sources=sources)

    # add test host and group
    host = Host("test_host")
    group = inventory.groups["ungrouped"]

    # add test_host to ungrouped group


# Generated at 2022-06-23 15:18:06.109552
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    from ansible.plugins.vars import vars_plugin

    class _TestPlugin(vars_plugin.VarsBase):
        pass

    loader = get_loader()

    plugin = _TestPlugin('test')
    plugin.get_vars = lambda loader, path, entities: {'test_data': 'test_value'}
    assert get_vars_from_path(loader, 'path', 'entities', 'stage') == {'test_data': 'test_value'}


# Generated at 2022-06-23 15:18:08.684082
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    display.verbosity = 0
    sources = ['tests/integration/inventory_test/test_inventory.yml']
    host = Host("arista_eos")
    entities = host.create_child_groups()
    data = get_vars_from_inventory_sources(None, sources, entities, 'inventory')
    assert data is not None

# Generated at 2022-06-23 15:18:17.849591
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible_collections import community
    import tempfile

    plugin_list = ['aio_inventory_service', 'aio_tower_cli', 'ansible', 'azure_rm', 'cowsay', 'dynamic_inventory', 'gcp_compute', 'host_list', 'inventory_service', 'netbox', 'nsot', 'onelogin', 'openstack', 'opendns', 'ovirt', 'ovirt_auth', 'packet_net', 'rax', 'rhev', 'rhv', 'script', 'test', 'trello', 'tower_cli', 'tranquil', 'vagrant', 'yandex']

    plugin_paths = []
    for plugin_name in plugin_list:
        plugin = vars_loader.get(plugin_name)

# Generated at 2022-06-23 15:18:29.810780
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.cli.inventory import InventoryCLI
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    vars_loader.ensure_all_plugins_loaded()

    parser = InventoryCLI(args=[], hosts_list=[], vault_password_files=[])
    parser.parse()
    loader = DataLoader()
    inventory = parser.inventory
    groups = inventory.get_groups()
    group_names = [g.name for g in groups]
    group_hosts = [g.hosts for g in groups]
    group_vars = [g.vars for g in groups]
    hosts = inventory.get_hosts()
    host_names = [h.name for h in hosts]

# Generated at 2022-06-23 15:18:33.440920
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    ''' This is used to assert parsable data is returned in the
        form of a dictionary.
    '''
    assert type(get_vars_from_path('loader','sources','entities','stage')) == dict

# Generated at 2022-06-23 15:18:43.473302
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import foo, bar
    assert get_plugin_vars(None, foo.VarsModule(), '.', []) == foo.get_vars(None, '.', [])
    assert get_plugin_vars(None, bar.VarsModule(), '.', []) == bar.get_vars(None, '.', [])
    assert get_plugin_vars(None, bar.VarsModule(), '.', ['localhost']) == bar.get_host_vars('localhost')
    assert get_plugin_vars(None, bar.VarsModule(), '.', ['group']) == bar.get_group_vars('group')

# Generated at 2022-06-23 15:18:50.949015
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    assert get_vars_from_inventory_sources("loader", [], [], "task") == {}
    assert get_vars_from_inventory_sources("loader", ["my_file", "my_other_file"], [], "task") == {}
    assert get_vars_from_inventory_sources("loader", ["my_file", "my_other_file"], "entities", "task") == {}


# Generated at 2022-06-23 15:19:00.803959
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    import ansible.plugins.loader as pl
    from ansible.utils.listify import listify_lookup_plugin_terms
    import ansible.inventory.manager
    import ansible.vars.manager
    import ansible.inventory.host
    import ansible.inventory.group

    class HostIncludeVars(pl.VarsBase):

        def run(self, terms, variables, **kwargs):

            data = self._flatten_hash(variables)

            results = []
            for term in terms:
                item = data
                for attr in listify_lookup_plugin_terms(term, templar=None, loader=None):
                    try:
                        item = item[attr]
                    except KeyError:
                        item = None
                        break
                if item:
                    results.append(item)

            return results

# Generated at 2022-06-23 15:19:12.087756
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.display import Display
    import os

    current_dir = os.path.dirname(os.path.realpath(__file__))
    display = Display()
    loader = get_loader(display)

    vars_plugin = loader.find_plugin('vars', os.path.join(current_dir, '..', 'plugins', 'vars'))
    assert(vars_plugin is not None)

    path_dir = os.path.join(current_dir, '..', 'plugins', 'vars')
    enitites = [Host('test_get_vars_from_path')]

    data = get_plugin_vars

# Generated at 2022-06-23 15:19:17.973712
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    plugin = vars_loader.get('yaml_file')
    path = './'
    entities = [{'name': 'localhost'}]
    result = get_plugin_vars(loader=None, plugin=plugin, path=path, entities=entities)
    for key,value in result.items():
        print ("%s: %s" % (key, value))
