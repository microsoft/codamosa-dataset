

# Generated at 2022-06-23 15:09:26.426774
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    # setup loader
    from ansible.plugins.loader import var_plugins

    plugin_list = list(var_plugins.all())
    for plugin in plugin_list:
        if plugin._load_name == 'set_fact':
            target_plugin = plugin
        break

    loader = var_plugins.PluginLoader(var_plugins.VARS_PLUGIN_PATH, 'vars', C.VARS_PLUGIN_FILENAME_EXTENSIONS)

    # setup path and entities
    path = os.path.dirname(os.path.abspath(__file__))
    path = path.replace('unit/plugins/vars', 'test/integration/roles/molecule_role/vars')
    path1 = path +'/test_v2.yml'

# Generated at 2022-06-23 15:09:38.417981
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import AutoDocVarsPlugin
    from ansible.plugins.loader import vars_loader
    from ansible.parsing.vault import VaultLib

    fake_plugin = AutoDocVarsPlugin()
    fake_plugin._load_name = 'AutoDocVarsPlugin'
    fake_plugin._original_path = 'fake_path'
    fake_plugin.get_vars = lambda x, y, z: {'key1': 'value1'}
    vars_loader._vars_plugins = [fake_plugin]

# Generated at 2022-06-23 15:09:50.224612
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.cli.arguments import parse_cli_args
    from ansible.config.manager import ConfigManager
    from ansible.context import init_context, get_context
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.vault import VaultLib
    from ansible.utils.display import Display

    display = Display()

    # 1. Prepare all arguments
    context = init_context(cli_args=parse_cli_args(constants=C))
    config_manager = ConfigManager(args=context.CLIARGS)

    vault_secret = os.path.join(test_dir, "vault_secrets.txt")
    loader = context.loader

# Generated at 2022-06-23 15:09:52.355770
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    import sys
    print(sys.path)

# Generated at 2022-06-23 15:09:53.692653
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    """
    This is one of the functions that would be hard to test in isolation
    """
    pass

# Generated at 2022-06-23 15:09:58.012703
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugins
    vars_plugins_list = list(vars_plugins.all())
    plugin = vars_plugins_list[0]
    return get_plugin_vars(None, plugin, '', [])

# Generated at 2022-06-23 15:09:58.746762
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    pass

# Generated at 2022-06-23 15:10:07.366462
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # generate vars_loader
    vars_loader_obj = vars_loader.get('./lib/ansible/plugins/vars')
    vars_loader_obj._load_plugins()
    vars_loader_obj.all()
    # generate loader
    loader_obj = loader.get('/usr/share/ansible/plugins')
    loader_obj._load_plugins()
    loader_obj.all()
    loader_obj.get('/usr/share/ansible/plugins')
    # generate host
    host_obj = Host(name='localhost')
    print(get_vars_from_path(loader_obj, '/home/ansible/ansible/lib/ansible', host_obj, 'inventory'))

# Generated at 2022-06-23 15:10:16.176840
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible_collections.ansible.community.tests.unit.compat.mock import MagicMock
    from ansible_collections.ansible.community.plugins.loader import vars_loader

    vars_plugin_list = vars_loader.all()
    for plugin in vars_plugin_list:
        plugin.get_vars = MagicMock(return_value={ 'foo': 'bar' })
        plugin.get_host_vars = MagicMock(return_value={ 'host1': 'baz' })
        plugin.get_group_vars = MagicMock(return_value={ 'group1': 'qux' })
        plugin.run = MagicMock(return_value={ 'run': True })
        plugin._load_name = 'mock'

# Generated at 2022-06-23 15:10:19.894620
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    loader = None
    sources = ['hosts', 'host_vars']
    entities = ['host1', 'host2']
    stage = 'start'
    get_vars_from_inventory_sources(loader, sources, entities, stage)

# Generated at 2022-06-23 15:10:26.617595
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    assert type(get_vars_from_inventory_sources([], ['tests/unit/vars_from_inventory_sources'], ['test_1', 'test_2'], 'inventory')) is dict
    assert type(get_vars_from_inventory_sources([], ['tests/unit/vars_from_inventory_sources'], ['test_1', 'test_2'], 'task')) is dict

# Generated at 2022-06-23 15:10:27.273701
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    pass

# Generated at 2022-06-23 15:10:37.584022
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    plugin_name = 'test_vars.py'
    # Load plugin
    loader = vars_loader._create_loader(
        'test_vars.py', C.VARS_PLUGIN_PATH, [], 'vars'
    )
    plugin = loader.get(plugin_name)
    fake_entity = 'fake_entity'
    expected = {plugin_name: plugin_name}
    result = get_plugin_vars(loader, plugin, 'fake_path', [fake_entity])
    assert expected == result
    result = get_plugin_vars(loader, plugin, 'fake_path', [])
    expected = {plugin_name: plugin_name, 'fake_path': 'fake_path'}
    assert expected == result



# Generated at 2022-06-23 15:10:47.278260
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.plugins.loader import vars_loader

    test_plugin_path = os.path.join('test/unit/plugins/test_vars_plugins', 'vars_plugins')

    vars_loader.add_directory(test_plugin_path)

    test_inventory_source = 'test/unit/plugins/test_vars_plugins/inventory_source'

    test_inventory_source_data = get_vars_from_inventory_sources(None, [test_inventory_source], [], 'inventory')

    assert test_inventory_source_data == {'test_vars': {'inventory_source_key': 'inventory_source_value'}}

# Generated at 2022-06-23 15:10:53.728349
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    test_loader = C.DEFAULT_INVENTORY_LOADER
    test_sources = ['/home/user/hosts']
    test_entities = ['host1']
    test_stage = 'inventory'
    result = get_vars_from_inventory_sources(test_loader, test_sources, test_entities, test_stage)
    if result == {}:
        print('Unit test successful.')
    else:
        print('Unit test failed.')

# Generated at 2022-06-23 15:11:04.862715
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import testvars
    loader = 'fake loader'
    plugin = testvars.VarsModule()
    path = 'fake path'
    entities = [
        {
            'name': 'fake group',
            '_metadata': {
                'hostvars': {
                    'fake host': {
                        'fake host var': 'real host var',
                    },
                    'fake host 2': {
                        'fake host var': 'real host var 2',
                    },
                },
            },
        },
    ]

    returned = get_plugin_vars(loader, plugin, path, entities)
    expected = {
        'fake group var': 'real group var',
        'fake host var': 'real host var',
        'fake host var 2': 'real host var 2',
    }

# Generated at 2022-06-23 15:11:12.249207
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    test_loader = None
    test_plugin = None
    test_path = None

    test_entities = None

    test_plugin.get_vars = lambda x, y, z: {'test': 'value'}

    assert get_plugin_vars(test_loader, test_plugin, test_path, test_entities) == {"test": "value"}

    test_plugin.get_vars = None
    test_plugin.get_group_vars = lambda x: {'test': 'value'}

    assert get_plugin_vars(test_loader, test_plugin, test_path, test_entities) == {"test": "value"}



# Generated at 2022-06-23 15:11:22.623210
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    # TODO: Make this a real test with a real loader and something to assert
    # right now it just runs, meaning no exceptions are raised

    class SampleVarsPlugin:
        def get_vars(self, loader, path, entities):
            data = {}
            for ent in entities:
                data[ent.name] = 'testhost'
            return data

    sources = ["test1", "test2"]
    entities = [Host(name='testhost')]
    stage = 'inventory'

    vars_loader.add('SampleVarsPlugin', SampleVarsPlugin())

    get_vars_from_inventory_sources(None, sources, entities, stage)

# Generated at 2022-06-23 15:11:30.003795
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    # essentially get_vars_from_path(..., 'tasks')
    data = get_vars_from_path(None, 'foo/bar/baz', entities=[], stage='task')


# Generated at 2022-06-23 15:11:32.514905
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import magic

    assert get_plugin_vars(None, magic, None, None)


# Generated at 2022-06-23 15:11:43.463553
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.loader import vars_loader

    class MockVariablePlugin(object):
        def get_vars(self, *args, **kwargs):
            return {'a': 1}

    class LegacyVarialbePlugin(object):
        def get_group_vars(self, *args, **kwargs):
            return {'b': 2}

    class LegacyVarialbePlugin(object):
        def get_host_vars(self, *args, **kwargs):
            return {'c': 3}

    class MockLoader(object):
        def __init__(self):
            self._contents = dict()

        def add_directory(self, directory, subdir=None, with_info=False):
            if directory not in self._contents:
                self._contents[directory] = list()

       

# Generated at 2022-06-23 15:11:51.566978
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    class test_plugin(object):
        def __init__(self, path):
            self.path = path
            self.data = {}
        def get_vars(self, loader, path, entities):
            assert self.path == path
            return self.data

    def get_vars_from_path(loader, path, entities):
        plugins = [
            test_plugin(path),
            test_plugin(path),
        ]

        return {'data': get_vars_from_path(loader, path, entities, plugins)}

    assert get_vars_from_path(None, "path", None) == {'data': {}}
    assert get_vars_from_path(None, "path", None)['data'] == {}

# Generated at 2022-06-23 15:11:59.526054
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # get_vars_from_path is shared between ansible-inventory and ansible-playbook
    # verify that ansible-inventory doesn't break when ansible-playbook adds
    #  additional VARIABLE_PLUGINS_ENABLED options (such as 'assertions')

    # get_vars_from_path is only called with stage='inventory' so test with that
    stage = 'inventory'

    # entities should be a list of Host or Group objects
    #  but get_vars_from_path just iterates over the list and
    #  passes each Host/Group to each plugin so just pass in a simple list
    entities = [None]

    # create a test plugin which has a `get_vars` method

# Generated at 2022-06-23 15:12:04.938756
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    inventory = InventoryManager(loader=None, sources='test_get_vars_from_inventory_sources_hosts')
    var = get_vars_from_inventory_sources(None, inventory.sources, [], 'inventory')
    assert var == {'test_var': 'inventory_vars', 'other_var': 'other_inventory_var'}

# Generated at 2022-06-23 15:12:05.873831
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    assert None



# Generated at 2022-06-23 15:12:07.996104
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    assert(get_vars_from_path(None, None, None, None) == {})

# Generated at 2022-06-23 15:12:14.159244
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import VarsBase

    class VarsModule(VarsBase):
        def get_vars(self, loader, path, entities):
            return {'mykey': 'myvalue'}

    vars_plugin = VarsModule()
    data = get_plugin_vars(None, vars_plugin, None, None)
    assert data['mykey'] == 'myvalue'

# Generated at 2022-06-23 15:12:21.020265
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    import pytest
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(),
    )

    assert get_vars_from_inventory_sources(None, '/does_not_exist', None, None) == {}

    path = module.resolve_path('../../lib/ansible/plugins/vars')
    assert get_vars_from_inventory_sources(None, [path], None, None) != {}

# Generated at 2022-06-23 15:12:26.515044
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    assert get_vars_from_inventory_sources(
        loader=None,
        sources=[None, "a.txt"],
        entities=[],
        stage="inventory"
    ) == {}

    assert get_vars_from_inventory_sources(
        loader=None,
        sources=[None, "a.txt"],
        entities=[],
        stage="task"
    ) == {}

# Generated at 2022-06-23 15:12:36.108936
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    module = 'ansible.plugins.vars.test_vars'
    vars_plugin_list = list(vars_loader.all())
    assert(len(vars_plugin_list) == 0)

    # test vars_loader._load_vars_plugins when no vars plugins in found
    vars_loader._load_vars_plugins(module)
    vars_plugin_list = list(vars_loader.all())
    assert(len(vars_plugin_list) == 3)
    vars_loader.reset()

    # test vars_loader._load_vars_plugins when vars plugins are already added
    # and module in not in C.VARS_PLUGINS_CACHEDIR
    vars_loader._load_vars_plugins(module)
    vars_plugin_list

# Generated at 2022-06-23 15:12:43.840105
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    display.verbosity = 3

    # test 1:
    # vars plugins
    # default settings
    # ansible.cfg settings
    #  AnsibleConfig settings
    # expected variables:
    #  ansible_local
    #  ansible_facts
    #  ansible_path
    #  ansible_version
    #  ansible_python_version
    #  ansible_architecture
    #  ansible_os_family
    #  ansible_playbook_python

    loader, inventory, play_context = load_fixture_data('get_vars_from_inventory_sources')
    loader.set_basedir('/data/ansible/ansible')

# Generated at 2022-06-23 15:12:53.500614
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    assert get_vars_from_inventory_sources(None, [None], None, 'task') == {}

    C.RUN_VARS_PLUGINS = 'start'
    C.VARIABLE_PLUGINS_ENABLED = ['test_vars_plugin']

    class Plugin:
        _load_name = 'test_vars_plugin'
        _original_path = '/home/test_vars_plugin'

        def get_vars(self, loader, path, entities):
            return {'test': 'get_vars'}

        def get_group_vars(self, loader, path, entities):
            return {'test': 'get_group_vars'}

        def get_host_vars(self, host):
            return {'test': 'get_host_vars'}

# Generated at 2022-06-23 15:13:05.693803
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    # Test case 1: path exists and a non-empty vars_dict is returned
    loader = None
    path = 'test'
    entities = None
    stage = None
    vars_dict = {'var1': 'value1', 'var2': 'value2'}

    vars_loader.add('my_test_plugin', vars_dict)

    data = get_vars_from_path(loader, path, entities, stage)

    assert data == vars_dict

    # Test case 2: path exists and an empty dict is returned
    loader = None
    path = 'test'
    entities = None
    stage = None
    vars_dict = {}

    vars_loader.add('my_test_plugin', vars_dict)


# Generated at 2022-06-23 15:13:07.928355
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    vars = get_vars_from_path(None, path='.', entities=[Host('example')], stage='task')
    assert vars == {}

# Generated at 2022-06-23 15:13:18.107846
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin_basic

    def get_plugin_vars_compare(loader, plugin, path, entities):
        return plugin.get_vars(loader, path, entities)

    loader = None
    plugin = vars_plugin_basic.VarsModule()
    plugin.vars = {
        'var1': 'value1',
        'var2': 'value2',
    }
    path = '/path/to/playbook'
    entities = [
        Host('localhost', port=None),
        Host('example.com', port=None),
    ]
    assert get_plugin_vars(loader, plugin, path, entities) == get_plugin_vars_compare(loader, plugin, path, entities)

# Generated at 2022-06-23 15:13:27.364240
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    inventory = InventoryManager(loader=DataLoader(), sources=['test/utils/vars_plugins/inventory'])
    host = inventory.get_host('test_host_2')
    assert host.get_vars() == {'foo': 'bar'}
    assert host.get_vars() == {'foo': 'bar'}
    assert host.get_group_vars() == {'bar': 'baz'}
    assert host.get_group_vars() == {'bar': 'baz'}



# Generated at 2022-06-23 15:13:34.279617
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    assert get_vars_from_inventory_sources('AT_loader', 'AT_sources', 'AT_entities', 'AT_stage') == {'data': {}, 'data': {'plugin': 'plugin', 'plugin': 'plugin'}, 'data': {'plugin': 'plugin', 'plugin': 'plugin'}, 'data': {'plugin': 'plugin', 'plugin': 'plugin'}, 'data': {'plugin': 'plugin', 'plugin': 'plugin'}}

# Unit tests for function get_vars_from_path

# Generated at 2022-06-23 15:13:38.851783
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    plugin = vars_loader.get('test_vars_plugin_1')
    loader = plugin.module_loader
    path = 'doesnt matter'
    entities = [Host('test', labels=['group'])]
    data = get_plugin_vars(loader, plugin, path, entities)
    assert data != {}
    entities = [entities[0]]
    data = get_plugin_vars(loader, plugin, path, entities)
    assert data != {}

# Generated at 2022-06-23 15:13:44.862114
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars.test_plugin import TestVarsPlugin
    plugin = TestVarsPlugin()
    entities = [Host("test")]
    data = get_plugin_vars(None, plugin, None, entities)
    assert data['test_var1'] == "test_var1_value"
    assert data['test_var2'] == "test_var2_value"



# Generated at 2022-06-23 15:13:55.335306
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.playbook.play.play_context import PlayContext
    from ansible.plugins.loader import vars_loader
    from ansible.plugins.loader import inventory_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from AnsibleModule import AnsibleModule

    class FakeInventoryPlugin(object):

        def __init__(self, name):
            self.name = name

        def get_vars(self, loaders, path, entities):
            results = dict()
            for entity in entities:
                if isinstance(entity, Host):
                    results[entity.name] = dict(a=1, b='fake')
                else:
                    results[entity.name] = dict(a=2, b='more fake')

            results['a'] = 5
           

# Generated at 2022-06-23 15:14:06.506288
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    class MyPlugin():
        pass

    plugin = MyPlugin()
    loader = None

    data = get_plugin_vars(loader, plugin, 'path', 'entities')
    assert data == {}

    plugin.get_vars = lambda loader, path, entities: {"a": "b"}
    data = get_plugin_vars(loader, plugin, 'path', 'entities')
    assert data == {'a': 'b'}

    plugin.get_vars = lambda loader, path, entities: {"a": "b1"}
    plugin.get_group_vars = lambda group: {"a": "b2"}
    data = get_plugin_vars(loader, plugin, 'path', 'entities')
    assert data == {'a': 'b2'}



# Generated at 2022-06-23 15:14:07.572637
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    pass

# Generated at 2022-06-23 15:14:12.029263
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars.host_group_vars import HostGroupVars

    hosts = [Host('testhost')]
    data = get_plugin_vars(None, HostGroupVars(), '.', hosts)
    assert isinstance(data, dict)


# Generated at 2022-06-23 15:14:20.819070
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    #
    # BROKEN - DO NOT USE
    #
    #    this test will fail if the vars_plugin_list is not already populated, 
    #    because it makes the incorrect assumption that this is the case. 
    #
    #    DO NOT USE
    #
    vars_plugin_list = list(vars_loader.all())
    loader = C.DEFAULT_LOADERS
    path = '.'
    entities = []
    stage = 'task'
    hosts = 'all'

    # get all the vars from path
    vars_from_path = get_vars_from_path(loader, path, entities, stage)

    assert vars_from_path is not None
    assert vars_from_path is not {}
    assert vars_from_path == {}

    # test that the v

# Generated at 2022-06-23 15:14:26.634028
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    # create the plugin object
    from ansible.plugins.loader import vars_loader
    from collections import namedtuple
    plugin_obj = namedtuple('plugin_obj', ['_load_name', '_original_path', 'get_group_vars', 'get_host_vars'])
    vars_plugin = plugin_obj('dummy_plugin_name', '/tmp/test/location/test.py', lambda a: {}, lambda b: {})
    vars_plugin_list = [vars_plugin]
    loader = {'_vars_plugins': vars_plugin_list}

    # creating the entity list
    entities = [Host('host1'), Host('host2')]

    # getting the vars
    data = get_plugin_vars(loader, vars_plugin, '/tmp', entities)

   

# Generated at 2022-06-23 15:14:27.315042
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    pass

# Generated at 2022-06-23 15:14:36.541814
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    # Basic test
    loader = None
    sources = "./tests/units/test_plugins/test_vars_plugin/inventory.ini"
    entities = [Host('127.0.0.1')]
    stage = 'inventory'

    # The data
    data = get_vars_from_inventory_sources(loader, sources, entities, stage)
    # Verify data
    expected = {'test_var_1': 'value1', 'test_var_2': 'value2'}
    assert data == expected

    # Test with multiple sources in the list
    loader = None
    sources = ["./tests/units/test_plugins/test_vars_plugin/inventory.ini", "./tests/units/test_plugins/test_vars_plugin/inventory2.ini"]

# Generated at 2022-06-23 15:14:48.922259
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    loader = DataLoader()
    var_manager = VariableManager()

    assert get_vars_from_path(loader, "./test/units/plugins/lookup/sample_vars_dir", [], "inventory") == {
        "test_list": [1, 2, 3],
        "test_var": "vars_test_var_1",
        "test_dict": {"test_a": 1, "test_b": 2, "test_c": 3}
    }

# Generated at 2022-06-23 15:14:56.045908
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['./test/integration/inventory.yaml'])
    group_vars = get_vars_from_inventory_sources(loader, inventory._sources, inventory.groups.values(), stage='inventory')
    assert group_vars == {'test_key': 'test_value'}

# Generated at 2022-06-23 15:14:59.807297
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    vars_data = get_vars_from_path(None, 'path', None, None)
    assert(isinstance(vars_data, dict))
    assert(len(vars_data) == 0)

# Generated at 2022-06-23 15:15:00.969432
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    assert get_vars_from_inventory_sources is not None

# Generated at 2022-06-23 15:15:09.683943
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    class Plugin:
        _original_path = None
        _load_name = 'test_get_plugin_vars'

        def get_vars(self, loader, path, entities):
            return {'foo': 'bar'}

    class Loader:
        pass

    class Host:
        pass

    entities = set()
    entities.add(Host())
    test_plugin = Plugin()
    test_loader = Loader()
    test_path = 'test_path'
    assert get_plugin_vars(test_loader, test_plugin, test_path, entities) == {'foo': 'bar'}

# Generated at 2022-06-23 15:15:20.040044
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory import Inventory

    def load_src(yaml_file):
        from ansible.parsing.dataloader import DataLoader
        from ansible.vars import VariableManager

        loader = DataLoader()
        variable_manager = VariableManager()

        inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=yaml_file)
        loader.set_basedir(inventory.basedir())

        # test all inventory sources
        sources = inventory.sources
        return get_vars_from_inventory_sources(loader, sources, entities={'all': []}, stage='inventory')

    # test 1: no files
    assert load_src(None) == {}

    # test 2: yaml file
    assert load_src("t/unit/plugins/vars/inventory.yaml")

# Generated at 2022-06-23 15:15:29.807475
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.play import Play

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/hosts'])
    host = Host('testhost', groups=['testgroup'])
    group = Group('testgroup')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test get_vars_from_path()
    # Load plugins from the test plugins dir and test with all enabled

# Generated at 2022-06-23 15:15:39.953864
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.vars.random_seed import VarsModule as RandomSeedPlugin

    loader = InventoryManager(paths='')
    fake_seed = 'FAKESEED'

    _path = '/some/path'
    _entities = list()

    class VarsPlugin:
        def get_vars(self, loader, path, entities):
            return {'FAKESEED': fake_seed}

    class Host:
        def __init__(self, name):
            self.name = name

    plugin = VarsPlugin()
    data = get_plugin_vars(loader, plugin, _path, _entities)
    assert 'FAKESEED' in data

    plugin = RandomSeedPlugin()

# Generated at 2022-06-23 15:15:43.038848
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    loader = None
    path = '.'
    entities = [Host("localhost")]
    stage = 'task'
    vars = get_vars_from_path(loader, path, entities, stage)
    assert len(vars) > 0

# Generated at 2022-06-23 15:15:49.826842
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    # test with vars_plugins set to all
    loader, inventory, variable_manager = get_loader_inventory_variable_manager(vars_plugins='all')
    sources = inventory.sources

    data = get_vars_from_inventory_sources(loader, sources, sources, 'task')
    assert(data['vars_test']['test_key'] == 'test_value')
    assert(data['vars_test_hosts']['test_hosts_key'] == 'test_hosts_value')
    assert(data['vars_test_hosts']['test_hosts_key_2'] == 'test_hosts_value_2')
    assert(data['vars_test_plugin']['p_key'] == 'p_value')

# Generated at 2022-06-23 15:16:02.478586
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    import pytest

    # test for inventory source file path
    loader = None
    entities = []
    stage = 'inventory'

    source_path_list = [
        '~/ansible/hosts'
        ]

    # both path and entities should be valid
    data = get_vars_from_inventory_sources(loader, source_path_list, entities, stage)
    assert data

    # entities should not be empty
    data = get_vars_from_inventory_sources(loader, [], entities, stage)
    assert not data

    # both path and entities should be valid
    host = Host('127.0.0.1')
    entities.append(host)
    data = get_vars_from_inventory_sources(loader, source_path_list, entities, stage)
    assert data

#

# Generated at 2022-06-23 15:16:10.146169
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible_collections.ansible.community.tests.unit.plugins.loader import (  # noqa
        dummy_vars_loader,
        dummy_vars_plugins
    )
    loader = dummy_vars_loader.get_loader()
    vars_plugin_1 = dummy_vars_plugins.get('vars_plugin_1')
    vars_plugin_2 = dummy_vars_plugins.get('vars_plugin_2')

    vars_plugin_1.get_vars = lambda *args: {'key_1': 'val_1'}
    vars_plugin_2.get_vars = lambda *args: {'key_2': 'val_2'}


# Generated at 2022-06-23 15:16:18.349452
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    loader = None
    plugin = None
    path = None
    entities = None

    plugin_path = os.path.join(os.path.dirname(__file__), 'test_plugins', 'vars_plugins')
    C.VARIABLE_PLUGINS_ENABLED.append('collection.test_vars_plugins.test')
    vars_loader.add_directory(plugin_path)
    plugin = vars_loader.get('collection.test_vars_plugins.test')
    data = get_plugin_vars(loader, plugin, path, entities)
    assert data == {'test_key': 'test_value'}


# Generated at 2022-06-23 15:16:28.461973
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible import context
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.utils.addresses import parse_address


# Generated at 2022-06-23 15:16:37.367752
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    """ test get_vars_from_path """
    import sys
    sys.path.append(os.path.dirname(__file__))
    test_env = {
        'TEST_ENV': 'testing',
        'TEST_ENV_FOO': 'bar',
    }
    os.environ.update(test_env)
    from ansible.plugins.vars.test_vars import TestVars

    plugin_obj = TestVars()
    plugin_obj._load_name = 'test_vars'
    plugin_obj._original_path = '/path/to/test_vars'
    plugins = [plugin_obj]
    path = '/test/vars/path'
    entities = [Host(), Host(), Host()]
    stage = 'start'
    assert get_vars_from

# Generated at 2022-06-23 15:16:48.495940
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from types import FunctionType

    class obj:
        def __init__(self, data):
            self.data = data

    plugin = obj({'a': 'b'})
    load_name = "load_name"
    path = "path"
    assert get_plugin_vars(None, plugin, path, None) == {'a': 'b'}
    plugin.get_vars = FunctionType(lambda: None, None, None)
    plugin._load_name = load_name
    plugin._original_path = path
    try:
        get_plugin_vars(None, plugin, path, None)
        assert False
    except AnsibleError as e:
        assert str(e) == "Cannot use v1 type vars plugin {} from {}".format(load_name, path)


# Generated at 2022-06-23 15:16:50.755377
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    """
    Unit test for function get_vars_from_path
    """
    pass

# Generated at 2022-06-23 15:16:55.721398
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin

    class TestVarsPlugin(vars_plugin.VarsBase):
        def get_vars(self, loader, path, entities):
            return {'test_key': 'test_value'}

    assert get_plugin_vars(None, TestVarsPlugin(), None, None) == {'test_key': 'test_value'}

# Generated at 2022-06-23 15:17:05.325613
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    '''
    Test the functionality of get_vars_from_inventory_sources function
    '''
    import sys
    import pytest
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.data import InventoryData
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    manager = InventoryManager(loader=loader)
    path = 'test/integration/inventory_vars'
    file_source = InventoryData(path)
    manager.add_inventory(file_source)
    inventory = manager.get_inventory_for_sources('test/integration/inventory_vars')

    # Run case 1: given test/integration/inventory_vars/hosts and test/integration/inventory_vars/group_vars/all/test_plugin.y

# Generated at 2022-06-23 15:17:07.179838
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    pass



# Generated at 2022-06-23 15:17:16.836433
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    class MockLoader(object):
        def __init__(self):
            pass

    loader = MockLoader()

    def assert_len_and_type(data, expected_len, expected_type):
        assert len(data) == expected_len
        assert all(isinstance(f, expected_type) for f in data)

    assert_len_and_type(get_vars_from_inventory_sources(loader, ['bad-directory', '/dev/null'], 'entities', 'stage'), 0, dict)
    assert_len_and_type(get_vars_from_inventory_sources(loader, [], 'entities', 'stage'), 0, dict)
    assert_len_and_type(get_vars_from_inventory_sources(loader, ['', None], 'entities', 'stage'), 0, dict)

# Generated at 2022-06-23 15:17:27.076906
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    from ansible.plugins.loader import vars_loader

    class FakeVarsPlugin(object):
        pass

    class FakeLoader(object):

        def __init__(self, *args, **kwargs):
            pass

    def fake_var_plugin_init(self, *args, **kwargs):
        self._load_name = 'fake_plugin_name'
        self._original_path = 'fake_plugin_path'

    def fake_var_plugin_get_vars(self, *args, **kwargs):
        return {'fake_plugin_name_vars': 'bar'}


# Generated at 2022-06-23 15:17:38.882985
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    # Case1: get_vars defined in vars plugin
    class plugin:
        def get_vars(self, loader, path, entities, **kwargs):
            return {'data':'test_get_vars'}
    loader = {}
    path = '/'
    entities = {}
    data = get_plugin_vars(loader, plugin, path, entities)
    assert data['data'] == 'test_get_vars'

    # Case2: get_host_vars defined in vars plugin
    class plugin:
        def get_host_vars(self, host):
            return {'data':'test_get_host_vars'}
    loader = {}
    path = '/'
    entities = []
    entity = Host()
    entity.name = 'test_host'

# Generated at 2022-06-23 15:17:42.119087
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    host = Host('host')
    group = Host('group')
    data = get_vars_from_inventory_sources(None, ['host', 'group', None], [host, group], 'inventory')


if __name__ == '__main__':
    test_get_vars_from_inventory_sources()

# Generated at 2022-06-23 15:17:53.206773
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    import ansible.plugins.loader as loader_mod
    loader_mod.add_directory(os.path.join(os.path.dirname(__file__), 'fixtures', 'vars_plugins'))
    config = {
        'actions': {'auto_vars': True},
        'settings': {'inventory': '/dev/null'},
    }
    loader = loader_mod.get(config, 'all')
    assert loader
    sources = loader.get_sources('/dev/null')
    assert sources == ['/dev/null']
    data = get_vars_from_inventory_sources(loader, sources, ['all'], 'inventory')

# Generated at 2022-06-23 15:18:04.644893
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    class Plugin_Vars_Loader:
        a_plugin_dict = {}
        def __init__(self):
            self.vars_plugins = [Vars_Plugin("a"), Vars_Plugin("b"), Vars_Plugin("c")]

        def all(self):
            return self.vars_plugins

        def get(self, name):
            return self.a_plugin_dict.get(name, None)

        def set(self, name, plugin):
            self.a_plugin_dict[name] = plugin
    
    class Vars_Plugin:
        def __init__(self, plugin_name):
            self._load_name = plugin_name
            self._original_path = plugin_name

# Simulate global vars

# Generated at 2022-06-23 15:18:05.839128
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert get_vars_from_path is None


# Generated at 2022-06-23 15:18:11.568682
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    """Test for get_vars_from_inventory_sources()."""
    loader = None
    sources = ["", None, ",", "foo,", "foo," * 5]
    entities = [None, ""]
    stage = ""
    # test with all possible inputs
    data = get_vars_from_inventory_sources(loader, sources, entities, stage)
    # data should be an empty dict
    assert data == {}

# Generated at 2022-06-23 15:18:20.499303
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    import collections
    import tempfile
    from ansible.plugins.loader import vars_plugin

    # Create a temp directory
    temp_path = tempfile.mkdtemp()

    # Create a vars plugin that returns a dict
    class MyVarsModule(vars_plugin.VarsBase):

        class VarsModule(object):

            def __init__(self, *args, **kwargs):
                self.vars = {'x': 1}
                self.omit_token = False

        def get_vars(self, *args, **kwargs):
            return self.VarsModule()

    # Create the plugin. This is going to get cleaned up automatically.
    plugin = MyVarsModule(temp_path + '/my-vars-plugin.py')

    # Create a dict of plugins, and add the plugin we just

# Generated at 2022-06-23 15:18:31.186853
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    class TestVarsPlugin:
        def __init__(self, test_data):
            self.test_data = test_data

        def get_vars(self, loader, path, entities):
            return self.test_data

    class TestVarsPlugin2:
        def get_vars(self, loader, path, entities):
            return None

    class TestVarsPlugin3:
        def get_host_vars(self, hostname):
            return None

    class TestVarsPlugin4:
        def get_host_vars(self, hostname):
            return None

        def get_group_vars(self, groupname):
            return None

    test_data_list = [{"VarsPluginTest": "test"}, None, None, None]
    for test_data in test_data_list:
        plugin

# Generated at 2022-06-23 15:18:34.894257
# Unit test for function get_plugin_vars

# Generated at 2022-06-23 15:18:46.340231
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    # Mock Ansible plugin loader
    class PluginLoaderMock:
        def get(self, name):
            return Foo()

    class VarsLoaderMock:
        def __init__(self):
            self.all = lambda: [Foo()]

        def get(self, name):
            return Bar()

    class Foo:
        def __init__(self):
            self._load_name = 'foo'
            self._original_path = 'foo'

        def get_vars(self, loader, path, entities):
            return {'foo': 'foo'}

    class Bar:
        def __init__(self):
            self._load_name = 'bar'
            self._original_path = 'bar'

        def get_group_vars(self, path):
            return {'bar': 'bar'}



# Generated at 2022-06-23 15:18:54.096296
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    import json
    import os

    result = get_vars_from_inventory_sources(None, ["/tmp"], [], "inventory")
    assert result == {}

    result = get_vars_from_inventory_sources(None, ["/tmp/hosts"], [], "inventory")
    assert result == {}

    result = get_vars_from_inventory_sources(None, ["/tmp/hosts"], [], "task")
    assert result == {}

    # test for vars_plugins
    result = get_vars_from_inventory_sources(None, ["/tmp"], [], "task")
    assert result == {}

    result = get_vars_from_inventory_sources(None, ["/tmp/hosts"], [], "task")
    assert result == {}

    # test for environment and yaml

# Generated at 2022-06-23 15:19:02.634444
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert get_vars_from_path(None, '/path/to/inventory', [], 'inventory') == {}
    assert get_vars_from_path(None, '/path/to/inventory', [None], 'inventory') == {}
    assert get_vars_from_path(None, '/path/to/inventory', [{}], 'inventory') == {}
    assert get_vars_from_path(None, '/path/to/inventory', [{'name': ''}], 'inventory') == {}
    assert get_vars_from_path(None, '/path/to/inventory', ['hostname'], 'inventory') == {}
    assert get_vars_from_path(None, '/path/to/inventory', ['hostname'], 'task') == {}


# Generated at 2022-06-23 15:19:03.122402
# Unit test for function get_vars_from_inventory_sources

# Generated at 2022-06-23 15:19:04.160312
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    assert False

# Generated at 2022-06-23 15:19:11.744678
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    # Load plugins

    # we need to setup a test environment here as VarsPluginPlugin base class init would normally load the vars plugin class
    # when a new PlaybookFileLoader object is created
    vars_loader.loaders = []
    for plugin_class_type in vars_loader.plugins:
        display.debug("Loading plugin class %s from %s" % (type(plugin_class_type).__name__, plugin_class_type._original_path))
        vars_loader.loaders.append(plugin_class_type(vars_loader.class_loader))

    # Load inventory source

    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.plugins.inventory import BaseInventoryPlugin


# Generated at 2022-06-23 15:19:18.385827
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import group_vars

    plugin = group_vars.GroupVars()
    data = get_plugin_vars(None, plugin, None, None)
    assert(data['a'] == 'b')

    plugin = group_vars.GroupVars()
    data = get_plugin_vars(None, plugin, 'test/unit/plugins/vars', ['f'])
    assert(data['f'] == 'g')