

# Generated at 2022-06-17 16:17:15.458338
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin_base
    import ansible.plugins.vars.test_vars_plugin
    import ansible.plugins.vars.yaml_vars
    import ansible.plugins.vars.toml_vars
    import ansible.plugins.vars.ini_vars
    import ansible.plugins.vars.json_vars
    import ansible.plugins.vars.python_vars
    import ansible.plugins.vars.host_vars
    import ansible.plugins.vars.group_vars

    class TestVarsPlugin(vars_plugin_base.VarsBase):
        def get_vars(self, loader, path, entities):
            return {'test_plugin': 'test_plugin'}


# Generated at 2022-06-17 16:17:25.990505
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugin'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # test inventory vars plugin
    assert variable_manager.get_vars(host=inventory.get_host('test_inventory_vars_plugin_host')) == {'test_inventory_vars_plugin_var': 'test_inventory_vars_plugin_value'}

    # test inventory vars plugin with host lists

# Generated at 2022-06-17 16:17:35.753522
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    loader = vars_loader
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    host = inventory.get_host('localhost')
    group = inventory.get_group('all')
    entities = [host, group]
    path = './test/integration/inventory_vars_plugins'
    stage = 'inventory'
    data = get_vars_from_path(loader, path, entities, stage)
    assert data['inventory_vars_plugin_test_var'] == 'inventory_vars_plugin_test_var_value'

# Generated at 2022-06-17 16:17:48.316061
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugin/hosts'])
    host = inventory.get_host('host1')
    group = inventory.get_group('group1')
    data = get_vars_from_path(loader, 'tests/inventory/test_inventory_vars_plugin', [host, group], 'inventory')
    assert data['test_vars_plugin_var'] == 'test_vars_plugin_var_value'

# Generated at 2022-06-17 16:17:58.990100
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_hosts'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    vars_plugin_list = list(vars_loader.all())

# Generated at 2022-06-17 16:18:00.422661
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # TODO: add unit test for function get_vars_from_path
    pass

# Generated at 2022-06-17 16:18:05.875759
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin_base
    from ansible.plugins.loader import vars_loader

    class TestVarsPlugin(vars_plugin_base.VarsBase):
        def get_vars(self, loader, path, entities):
            return {'test_var': 'test_value'}

    vars_loader.add(TestVarsPlugin, 'test_vars_plugin')
    assert get_plugin_vars(None, TestVarsPlugin(), None, None) == {'test_var': 'test_value'}

# Generated at 2022-06-17 16:18:17.436550
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugin'])
    host = inventory.get_host('testhost')
    group = inventory.get_group('testgroup')
    data = get_vars_from_path(loader, 'tests/inventory/test_inventory_vars_plugin', [host, group], 'inventory')
    assert data['test_var'] == 'test_value'
    assert data['test_var_group'] == 'test_value_group'
    assert data['test_var_host'] == 'test_value_host'

# Generated at 2022-06-17 16:18:27.492431
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.utils.collection_loader import AnsibleCollectionRef
    from ansible.utils.vars import combine_vars

    # Test with a v2 plugin
    plugin_name = 'test_vars_plugin'
    plugin_path = 'test_vars_plugin_path'
    plugin_data = {'test_vars_plugin_data': 'test_vars_plugin_data'}
    plugin_data_2 = {'test_vars_plugin_data_2': 'test_vars_plugin_data_2'}
    plugin_data_3 = {'test_vars_plugin_data_3': 'test_vars_plugin_data_3'}

# Generated at 2022-06-17 16:18:36.695618
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test with a host
    host = inventory.get_host('test_inventory_vars_plugins')
    assert isinstance(host, Host)
    assert get_vars_from_path(loader, 'tests/inventory/test_inventory_vars_plugins', [host], 'inventory')

# Generated at 2022-06-17 16:18:47.285730
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugins

    class TestVarsPlugin(object):
        def get_vars(self, loader, path, entities):
            return {'test_key': 'test_value'}

    class TestVarsPlugin2(object):
        def get_host_vars(self, host):
            return {'test_key': 'test_value'}

        def get_group_vars(self, group):
            return {'test_key': 'test_value'}

    class TestVarsPlugin3(object):
        def run(self):
            return {'test_key': 'test_value'}

    class TestVarsPlugin4(object):
        def get_vars(self, loader, path, entities):
            return {'test_key': 'test_value'}

# Generated at 2022-06-17 16:18:52.504486
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin_base

    class TestVarsPlugin(vars_plugin_base):
        def get_vars(self, loader, path, entities):
            return {'test_key': 'test_value'}

    loader = None
    plugin = TestVarsPlugin()
    path = None
    entities = None
    data = get_plugin_vars(loader, plugin, path, entities)
    assert data == {'test_key': 'test_value'}



# Generated at 2022-06-17 16:18:59.795487
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.plugins.callback import CallbackBase
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

# Generated at 2022-06-17 16:19:09.164193
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # test with a v2 plugin
    plugin = vars_loader.get('vars_plugin_test_v2')
    assert plugin is not None
    assert plugin.get_vars(loader, '.', [inventory.get_host('localhost')]) == {'test_vars_plugin_v2': 'test_vars_plugin_v2'}

    # test with a v1 plugin
    plugin = vars_

# Generated at 2022-06-17 16:19:19.409594
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['test/inventory/test_hosts'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(loader=loader, variable_manager=variable_manager)

    # test with a single host
    host = inventory.get_host('host1')
    assert get_vars_from_inventory_sources(loader, ['test/inventory/test_hosts'], [host], 'inventory') == {'test_var': 'test_value'}

    # test

# Generated at 2022-06-17 16:19:26.362771
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test with a host
    host = inventory.get_host('test_host')
    data = get_vars_from_path(loader, 'tests/inventory/test_inventory_vars_plugins', [host], 'inventory')
    assert data == {'test_host_var': 'test_host_value'}

    # Test

# Generated at 2022-06-17 16:19:36.479431
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugin'])
    host = inventory.get_host('test_host')
    group = inventory.get_group('test_group')

    vars_plugin_list = list(vars_loader.all())

# Generated at 2022-06-17 16:19:49.764599
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test with a host
    host = inventory.get_host('test_host')
    assert host is not None
    assert isinstance(host, Host)
    assert host.name == 'test_host'

    # Test with a group
    group = inventory.get_group('test_group')
    assert group is not None
    assert group.name == 'test_group'

    # Test with a host and a group
    entities = [host, group]

    # Test with a

# Generated at 2022-06-17 16:19:55.381436
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test inventory vars plugins
    assert get_vars_from_inventory_sources(loader, ['tests/inventory/test_inventory_vars_plugins'], inventory.get_groups_dict(), 'inventory') == {'test_inventory_vars_plugins': 'inventory'}

    # Test group vars plugins

# Generated at 2022-06-17 16:20:04.315953
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin
    from ansible.plugins.loader import vars_loader
    from ansible.utils.collection_loader import AnsibleCollectionRef

    class TestVars(vars_plugin.VarsBase):
        def get_vars(self, loader, path, entities):
            return {'test_var': 'test_value'}

    vars_loader.add(TestVars, 'test_vars')
    plugin = vars_loader.get('test_vars')
    assert get_plugin_vars(vars_loader, plugin, 'path', 'entities') == {'test_var': 'test_value'}


# Generated at 2022-06-17 16:20:16.680929
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inv = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    host = inv.get_host('test_host')
    group = inv.get_group('test_group')

    vars_plugin_list = list(vars_loader.all())

# Generated at 2022-06-17 16:20:25.898159
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_

# Generated at 2022-06-17 16:20:36.713444
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import vars_loader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test with a single host
    host = inventory.get_host('test_host')
    vars = get_vars_from_inventory_sources(loader, inventory.sources, [host], 'inventory')
    assert vars == {'test_host': {'test_host_var': 'test_host_value'}}

    # Test with a single group

# Generated at 2022-06-17 16:20:49.880370
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin_base
    class TestVarsPlugin(vars_plugin_base):
        def get_vars(self, loader, path, entities):
            return {'test_vars': 'test_vars'}

    class TestVarsPlugin2(vars_plugin_base):
        def get_host_vars(self, host):
            return {'test_host_vars': 'test_host_vars'}

        def get_group_vars(self, group):
            return {'test_group_vars': 'test_group_vars'}

    class TestVarsPlugin3(vars_plugin_base):
        def run(self, host, vault_password=None):
            return {'test_run': 'test_run'}


# Generated at 2022-06-17 16:20:59.327857
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test vars_plugin_list
    vars_plugin_list = list(vars_loader.all())
    assert len(vars_plugin_list) == 0

    # Test get_vars_from_path
    path = '.'
    entities = [inventory.get_host('localhost')]
    stage = 'inventory'
    data = get_vars_from_path(loader, path, entities, stage)


# Generated at 2022-06-17 16:21:05.972737
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    host = inventory.get_host('host1')
    group = inventory.get_group('group1')
    data = get_vars_from_path(loader, 'tests/inventory/test_inventory_vars_plugins', [host, group], 'inventory')
    assert data == {'group1': {'group_var': 'group1'}, 'host1': {'host_var': 'host1'}}


# Generated at 2022-06-17 16:21:13.938771
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.collection_loader import AnsibleCollectionRef

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory'])

# Generated at 2022-06-17 16:21:24.668540
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.plugins.vars import BaseVarsPlugin
    from ansible.utils.collection_loader import AnsibleCollectionRef

    class TestVarsPlugin(BaseVarsPlugin):
        def get_vars(self, loader, path, entities):
            return {'test_var': 'test_value'}

    vars_loader.add(AnsibleCollectionRef.from_string('test_collection.test_namespace.test_plugin'), TestVarsPlugin)

    assert get_vars_from_path(None, '/tmp', [], 'inventory') == {'test_var': 'test_value'}

# Generated at 2022-06-17 16:21:31.089932
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin_base
    class TestPlugin(vars_plugin_base):
        def get_vars(self, loader, path, entities):
            return {'test': 'test'}

    loader = None
    plugin = TestPlugin()
    path = None
    entities = []
    assert get_plugin_vars(loader, plugin, path, entities) == {'test': 'test'}

# Generated at 2022-06-17 16:21:37.020603
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.plugins.vars import BaseVarsPlugin
    from ansible.utils.collection_loader import AnsibleCollectionRef
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars

    display = Display()

    class TestVarsPlugin(BaseVarsPlugin):
        def get_vars(self, loader, path, entities):
            return {'test_vars_plugin': 'test_vars_plugin'}

    class TestVarsPlugin2(BaseVarsPlugin):
        def get_vars(self, loader, path, entities):
            return {'test_vars_plugin2': 'test_vars_plugin2'}


# Generated at 2022-06-17 16:21:50.824098
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    host = inventory.get_host('host1')
    group = inventory.get_group('group1')
    entities = [host, group]

    vars_plugin_list = list(vars_loader.all())

# Generated at 2022-06-17 16:21:58.708223
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin_base

    class TestVarsPlugin(vars_plugin_base):
        def get_vars(self, loader, path, entities):
            return {'test_key': 'test_value'}

    loader = 'loader'
    plugin = TestVarsPlugin()
    path = 'path'
    entities = ['entities']
    assert get_plugin_vars(loader, plugin, path, entities) == {'test_key': 'test_value'}

# Generated at 2022-06-17 16:22:02.574939
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin_base
    class TestVarsPlugin(vars_plugin_base):
        def get_vars(self, loader, path, entities):
            return {'test_key': 'test_value'}

    loader = None
    plugin = TestVarsPlugin()
    path = None
    entities = None
    result = get_plugin_vars(loader, plugin, path, entities)
    assert result == {'test_key': 'test_value'}

# Generated at 2022-06-17 16:22:12.047006
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['test/integration/inventory_vars_plugins/hosts'])
    host = inventory.get_host('test_host')
    group = inventory.get_group('test_group')

    data = get_vars_from_path(loader, 'test/integration/inventory_vars_plugins', [host, group], 'inventory')
    assert data == {'test_host_var': 'test_host_value', 'test_group_var': 'test_group_value'}

# Generated at 2022-06-17 16:22:22.653990
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude

# Generated at 2022-06-17 16:22:33.420014
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    inventory.parse_sources()

    # Test with host
    host = inventory.get_host('host1')
    data = get_vars_from_inventory_sources(loader, inventory.sources, [host], 'inventory')
    assert data == {'host_var': 'host1_value', 'group_var': 'group1_value', 'all_var': 'all_value'}

    # Test with group
    group = inventory.get_group('group1')

# Generated at 2022-06-17 16:22:41.443384
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    host = inventory.get_host('test_host')
    group = inventory.get_group('test_group')

    # Test vars plugins
    vars_plugin_list = list(vars_loader.all())

# Generated at 2022-06-17 16:22:52.093770
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.plugins.vars import BaseVarsPlugin
    from ansible.utils.collection_loader import AnsibleCollectionRef

    class TestVarsPlugin(BaseVarsPlugin):
        def get_vars(self, loader, path, entities):
            return {'test_vars_plugin': 'test_vars_plugin'}

    class TestVarsPlugin2(BaseVarsPlugin):
        def get_vars(self, loader, path, entities):
            return {'test_vars_plugin2': 'test_vars_plugin2'}


# Generated at 2022-06-17 16:22:59.019133
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    host = Host(name='localhost')
    group = Group(name='group')

    # test with v2 plugin
    vars_plugin = vars_loader.get('test_vars_plugin')
    assert vars_plugin is not None

# Generated at 2022-06-17 16:23:05.383041
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # test for group
    group = inventory.groups['ungrouped']
    data = get_vars_from_path(loader, 'tests/inventory', [group], 'inventory')
    assert data['test_group_var'] == 'test_group_value'

    # test for host
    host = inventory.get_host('testhost')

# Generated at 2022-06-17 16:23:27.092061
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugins
    from ansible.plugins.loader import vars_loader
    from ansible.utils.collection_loader import AnsibleCollectionRef
    from ansible.utils.vars import combine_vars

    vars_plugin_list = list(vars_loader.all())
    for plugin_name in C.VARIABLE_PLUGINS_ENABLED:
        if AnsibleCollectionRef.is_valid_fqcr(plugin_name):
            vars_plugin = vars_loader.get(plugin_name)
            if vars_plugin is None:
                # Error if there's no play directory or the name is wrong?
                continue
            if vars_plugin not in vars_plugin_list:
                vars_plugin_list.append(vars_plugin)



# Generated at 2022-06-17 16:23:34.252521
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin_base
    from ansible.plugins.loader import vars_loader

    class TestVarsPlugin(vars_plugin_base.VarsBase):
        def get_vars(self, loader, path, entities):
            return {'test_vars': 'test_vars'}

    vars_loader.add(TestVarsPlugin, 'test_vars')

    loader = None
    path = None
    entities = None
    assert get_plugin_vars(loader, TestVarsPlugin(), path, entities) == {'test_vars': 'test_vars'}

# Generated at 2022-06-17 16:23:42.808316
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    from ansible.executor.process.worker import WorkerProcess
    from ansible.utils.vars import combine_vars
    from ansible.plugins.vars import test_vars_plugin

# Generated at 2022-06-17 16:23:52.456776
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.source import InventorySource
    from ansible.utils.collection_loader import AnsibleCollectionRef
    from ansible.utils.vars import combine_vars

    # Create a fake inventory source

# Generated at 2022-06-17 16:24:03.038022
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # test with a v2 plugin
    plugin = vars_loader.get('vars_plugin_test_v2')
    assert plugin is not None
    assert hasattr(plugin, 'get_vars')
    assert not hasattr(plugin, 'get_host_vars')
    assert not hasattr(plugin, 'get_group_vars')
    assert not hasattr(plugin, 'run')

    data = get_

# Generated at 2022-06-17 16:24:07.176273
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/unit/inventory/test_inventory_vars_plugins'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test for host
    host = Host(name='test_host')
    inventory.add_host(host)
    vars_plugin_list = list(vars_loader.all())

# Generated at 2022-06-17 16:24:15.517564
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars
    from ansible.plugins.vars import BaseVarsPlugin


# Generated at 2022-06-17 16:24:26.525255
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    # Create a fake inventory
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    inventory.add_host(host=Host(name='localhost'))
    inventory.add_group(group=inventory.groups['all'])
    inventory.add_group(group=inventory.groups['ungrouped'])

    # Create a fake vars plugin
    class FakeVarsPlugin:
        def __init__(self):
            self._load_name = 'fake_vars_plugin'
            self._original_path = 'fake_vars_plugin'


# Generated at 2022-06-17 16:24:38.033607
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.plugins.vars import BaseVarsPlugin
    from ansible.utils.collection_loader import AnsibleCollectionRef

    class TestVarsPlugin(BaseVarsPlugin):
        def get_vars(self, loader, path, entities):
            return {'test_vars_plugin': 'test_vars_plugin'}

    class TestVarsPlugin2(BaseVarsPlugin):
        def get_vars(self, loader, path, entities):
            return {'test_vars_plugin2': 'test_vars_plugin2'}


# Generated at 2022-06-17 16:24:48.219307
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(loader=loader, variable_manager=variable_manager)
    variable_manager.set_host_variable(inventory.get_host('test_host'), 'ansible_host', '127.0.0.1')

# Generated at 2022-06-17 16:25:09.585926
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.plugins.loader import vars_loader
    from ansible.plugins.vars import yaml_loader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_from_inventory_sources'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Get vars from inventory sources
    sources = inventory.get_sources()
    entities = inventory.get_hosts() + inventory.get_groups()
    stage = 'inventory'
    data = get

# Generated at 2022-06-17 16:25:16.293999
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugins
    loader = vars_loader
    plugin = vars_plugins.get('test_vars_plugin')
    path = '/path/to/test/dir'
    entities = ['test_entity']
    data = get_plugin_vars(loader, plugin, path, entities)
    assert data == {'test_key': 'test_value'}

# Generated at 2022-06-17 16:25:24.956379
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    host = inventory.get_host('testhost')
    group = inventory.get_group('testgroup')

    # test get_vars_from_path
    vars_plugin_list = list(vars_loader.all())

# Generated at 2022-06-17 16:25:34.848129
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    from ansible.plugins.loader import vars_loader

    vars_loader.add_directory(os.path.join(os.path.dirname(__file__), 'vars_plugins'))

    # test with a single host
    host = Host('test_host')
    data = get_vars_from_path(None, os.path.dirname(__file__), [host], 'inventory')
    assert data == {'test_host_var': 'test_host_value'}

    # test with a single group
    group = Host('test_group')
    data = get_vars_from_path(None, os.path.dirname(__file__), [group], 'inventory')
    assert data == {'test_group_var': 'test_group_value'}

    # test with a host and a

# Generated at 2022-06-17 16:25:45.079304
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin_base
    class TestVarsPlugin(vars_plugin_base):
        def get_vars(self, loader, path, entities):
            return {'test_vars': 'test_vars_value'}

    class TestVarsPlugin2(vars_plugin_base):
        def get_host_vars(self, host):
            return {'test_host_vars': 'test_host_vars_value'}

        def get_group_vars(self, group):
            return {'test_group_vars': 'test_group_vars_value'}

    class TestVarsPlugin3(vars_plugin_base):
        def run(self, host):
            return {'test_run': 'test_run_value'}



# Generated at 2022-06-17 16:25:46.512096
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # TODO: add unit test
    pass


# Generated at 2022-06-17 16:25:52.081026
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    inventory.parse_inventory(inventory)
    host = inventory.get_host('test_host')
    group = inventory.get_group('test_group')
    data = get_vars_from_inventory_sources(loader, ['tests/inventory/test_inventory_vars_plugins'], [host, group], 'inventory')
    assert data['test_host_var'] == 'test_host_value'
    assert data['test_group_var'] == 'test_group_value'

# Generated at 2022-06-17 16:25:59.919182
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin_base
    from ansible.plugins.loader import vars_loader

    class TestVars(vars_plugin_base.VarsBase):
        def get_vars(self, loader, path, entities):
            return {'test_vars': 'test_vars'}

    class TestVars2(vars_plugin_base.VarsBase):
        def get_host_vars(self, host):
            return {'test_host_vars': 'test_host_vars'}

        def get_group_vars(self, group):
            return {'test_group_vars': 'test_group_vars'}


# Generated at 2022-06-17 16:26:05.990659
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = VariableManager(loader=loader)
    inventory.add_host(Host('host1'))
    inventory.add_host(Host('host2'))
    inventory.add_group(Group('group1'))
    inventory.add_group(Group('group2'))

    # test vars plugin
    class TestVarsPlugin:
        def __init__(self):
            self._load_name = 'test_vars_plugin'
            self._original_path = '/path/to/test_vars_plugin'

# Generated at 2022-06-17 16:26:16.320285
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test vars plugin
    data = get_vars_from_path(loader, 'tests/inventory/test_inventory_vars_plugins', [inventory.groups['all']], 'inventory')
    assert data['test_inventory_vars_plugins_var'] == 'test_inventory_vars_plugins_value'

    # Test vars plugin with a file

# Generated at 2022-06-17 16:26:42.910296
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # test that vars plugins are loaded from inventory sources
    assert variable_manager.get_vars(host=None, include_hostvars=False) == {'inventory_vars_plugin_test': 'inventory_vars_plugin_test'}

# Generated at 2022-06-17 16:26:52.636791
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.source import InventorySource
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Create a host
    host = Host(name='localhost')
    host.set_variable('ansible_connection', 'local')

# Generated at 2022-06-17 16:27:00.037039
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(loader=loader, variable_manager=variable_manager, hostname='localhost')

    # Test with a vars plugin that has get_vars
    plugin = vars_loader.get('test_vars_plugin')
    assert plugin is not None