

# Generated at 2022-06-17 16:17:13.086077
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    inv = inv_manager.get_inventory()
    host = inv.get_host('test_host')
    group = inv.get_group('test_group')

    # Test with a v2 plugin
    vars_plugin_list = list(vars_loader.all())

# Generated at 2022-06-17 16:17:23.152986
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    inv_manager.parse_sources()
    inv = inv_manager.inventory

    # test with a host
    host = inv.get_host('test_host')
    data = get_vars_from_path(loader, 'tests/inventory/test_inventory_vars_plugins', [host], 'inventory')
    assert data == {'test_host_var': 'test_host_var_value'}

    # test with a group
    group = inv.get_group('test_group')

# Generated at 2022-06-17 16:17:30.064752
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_sources'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    data = get_vars_from_inventory_sources(loader, inventory.sources, inventory.hosts, 'inventory')
    assert data['test_var'] == 'test_value'

# Generated at 2022-06-17 16:17:38.400426
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.source import InventorySource
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Create a group
    group = Group('test_group')
    inventory.add_group(group)

    # Create a host
    host = Host('test_host')
    inventory.add_host(host)

   

# Generated at 2022-06-17 16:17:49.435038
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    # Create a fake inventory
    inventory = InventoryManager(loader=None, sources=['localhost,'])
    inventory.add_host(Host(name='localhost', port=22))

    # Create a fake variable manager
    variable_manager = VariableManager(loader=None, inventory=inventory)

    # Create a fake loader
    loader = None

    # Create a fake path
    path = './'

    # Create a fake entity
    entity = inventory.get_host('localhost')

    # Create a fake stage
    stage = 'inventory'

    # Test the function
    data = get_vars_from_path(loader, path, entity, stage)

    # Check the result
   

# Generated at 2022-06-17 16:17:54.014624
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin_base
    import ansible.plugins.vars.test_vars_plugin as test_vars_plugin
    import ansible.plugins.vars.test_vars_plugin_v2 as test_vars_plugin_v2
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test v1 plugin
    plugin = test_vars_plugin.TestVarsPlugin()


# Generated at 2022-06-17 16:18:04.532920
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin_base
    from ansible.plugins.loader import vars_loader

    class TestVarsPlugin(vars_plugin_base.VarsBase):
        def get_vars(self, loader, path, entities):
            return {'test_vars_plugin': 'test_vars_plugin'}

    class TestHostVarsPlugin(vars_plugin_base.VarsBase):
        def get_host_vars(self, host):
            return {'test_host_vars_plugin': 'test_host_vars_plugin'}


# Generated at 2022-06-17 16:18:16.249905
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['test/inventory/test_inventory_vars_plugins'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test for host
    host = Host(name='testhost')
    inventory.add_host(host)
    inventory.add_child('testgroup', host)
    inventory.add_child('all', host)
    inventory.add_child('ungrouped', host)
    inventory.add_child('testgroup2', host)

# Generated at 2022-06-17 16:18:26.611802
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars
    from ansible.plugins.vars import vars_plugin
    from ansible.plugins.vars import vars_plugin_v

# Generated at 2022-06-17 16:18:36.063344
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test with a host
    host = Host(name="localhost")
    host.vars = get_vars_from_path(loader, './test/units/plugins/vars/', [host], 'task')
    assert host.vars['test_vars_plugin_var'] == 'bar'

    # Test with a group

# Generated at 2022-06-17 16:18:53.180565
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin_base
    from ansible.plugins.loader import vars_loader
    from ansible.utils.collection_loader import AnsibleCollectionLoader

    class TestVarsPlugin(vars_plugin_base.VarsBase):
        def get_vars(self, loader, path, entities):
            return {'test_vars': 'test_vars'}

    class TestVarsPlugin2(vars_plugin_base.VarsBase):
        def get_host_vars(self, host):
            return {'test_host_vars': 'test_host_vars'}

        def get_group_vars(self, group):
            return {'test_group_vars': 'test_group_vars'}


# Generated at 2022-06-17 16:19:00.228237
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    host = inventory.get_host('host1')
    group = inventory.get_group('group1')
    data = get_vars_from_path(loader, 'tests/inventory/test_inventory_vars_plugins', [host, group], 'inventory')
    assert data == {'host_var': 'host1', 'group_var': 'group1', 'all_var': 'all'}

    # test with a plugin that does not support v2
    vars_plugin = vars_loader.get

# Generated at 2022-06-17 16:19:09.570456
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    host = inventory.get_host('testhost')
    group = inventory.get_group('testgroup')

    vars_plugin_list = list(vars_loader.all())

# Generated at 2022-06-17 16:19:19.748413
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.plugins.vars import BaseVarsPlugin
    from ansible.utils.collection_loader import AnsibleCollectionRef

    class TestVarsPlugin(BaseVarsPlugin):
        def get_vars(self, loader, path, entities):
            return {'test_var': 'test_value'}

    vars_loader.add(TestVarsPlugin, 'test_vars_plugin')
    vars_loader.all()

    loader = None
    path = 'test_path'
    entities = ['test_entity']
    stage = 'test_stage'

    data = get_vars_from_path(loader, path, entities, stage)
    assert data == {'test_var': 'test_value'}


# Generated at 2022-06-17 16:19:28.941020
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin_base
    from ansible.plugins.loader import vars_loader

    class TestVarsPlugin(vars_plugin_base.VarsBase):
        def get_vars(self, loader, path, entities):
            return {'test_vars': 'test_vars'}

    vars_loader.add(TestVarsPlugin, 'test_vars')
    assert get_plugin_vars(None, TestVarsPlugin(), None, None) == {'test_vars': 'test_vars'}

# Generated at 2022-06-17 16:19:39.852806
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    host = inventory.get_host('test_host')
    group = inventory.get_group('test_group')

    # test with stage=inventory
    data = get_vars_from_inventory_sources(loader, inventory.sources, [host, group], 'inventory')
    assert data == {'test_host': {'test_host_var': 'test_host_value'}, 'test_group': {'test_group_var': 'test_group_value'}}

    # test with stage=task
    data = get_vars_from_inventory_

# Generated at 2022-06-17 16:19:51.282953
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test for host
    host = inventory.get_host('test_host')
    assert host.name == 'test_host'
    assert host.vars == {}
    assert host.get_vars() == {}
    assert host.get_group_vars

# Generated at 2022-06-17 16:20:01.637045
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugin'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # get_vars_from_path should return a dict
    assert isinstance(get_vars_from_path(loader, 'tests/inventory/test_inventory_vars_plugin', inventory.hosts, 'inventory'), dict)

    # get_vars_from_path should return a dict with the correct data

# Generated at 2022-06-17 16:20:13.708488
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    host = Host(name='localhost')
    host.set_variable('ansible_connection', 'local')
    inventory.add_host(host)
    group = inventory.get_group('all')
    group.add_host(host)

# Generated at 2022-06-17 16:20:24.235998
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin_base
    from ansible.plugins.loader import vars_loader

    class TestVarsPlugin(vars_plugin_base.VarsBase):
        def get_vars(self, loader, path, entities):
            return {'test_vars_plugin': 'test_vars_plugin'}

    class TestVarsPlugin2(vars_plugin_base.VarsBase):
        def get_host_vars(self, host):
            return {'test_vars_plugin2': 'test_vars_plugin2'}


# Generated at 2022-06-17 16:20:38.924763
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.plugins.vars import BaseVarsPlugin
    from ansible.plugins.vars.host_group import HostGroupVars
    from ansible.plugins.vars.host_group import GroupVars

# Generated at 2022-06-17 16:20:48.335952
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin_base

    class TestVarsPlugin(vars_plugin_base):
        def get_vars(self, loader, path, entities):
            return {'test_key': 'test_value'}

    loader = None
    plugin = TestVarsPlugin()
    path = None
    entities = None
    data = get_plugin_vars(loader, plugin, path, entities)
    assert data == {'test_key': 'test_value'}

# Generated at 2022-06-17 16:20:58.566319
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugin'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # test with a host
    host = inventory.get_host('test_host')
    data = get_vars_from_path(loader, 'tests/inventory/test_inventory_vars_plugin', [host], 'inventory')
    assert data == {'test_host_var': 'test_host_value'}

    # test with a group
    group = inventory.get_

# Generated at 2022-06-17 16:21:07.261419
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugin'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test get_vars_from_path with a host
    host = inventory.get_host('host1')
    vars_from_path = get_vars_from_path(loader, 'tests/inventory/test_inventory_vars_plugin', [host], 'inventory')

# Generated at 2022-06-17 16:21:14.074473
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory'])
    group = inventory.groups['ungrouped']
    host = inventory.get_host('testhost')
    assert get_vars_from_inventory_sources(loader, ['tests/inventory'], [group, host], 'inventory') == {'group_var': 'group_var_value', 'group_var_all': 'group_var_all_value', 'host_var': 'host_var_value', 'host_var_all': 'host_var_all_value'}

# Generated at 2022-06-17 16:21:24.669776
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    loader = vars_loader
    path = './test/integration/inventory/'
    inventory = InventoryManager(loader=loader, sources=path)
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    entities = variable_manager.get_vars(host=inventory.get_host('localhost'), include_hostvars=True)
    data = get_vars_from_path(loader, path, entities, 'inventory')
    assert data['test_var'] == 'test_var_value'

# Generated at 2022-06-17 16:21:34.322182
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.plugins.vars import BaseVarsPlugin
    from ansible.utils.collection_loader import AnsibleCollectionRef

    class TestVarsPlugin(BaseVarsPlugin):
        def get_vars(self, loader, path, entities):
            return {'test_vars': 'test_vars'}

    class TestVarsPlugin2(BaseVarsPlugin):
        def get_host_vars(self, host):
            return {'test_vars2': 'test_vars2'}

    class TestVarsPlugin3(BaseVarsPlugin):
        def get_group_vars(self, group):
            return {'test_vars3': 'test_vars3'}


# Generated at 2022-06-17 16:21:48.152176
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test with a host
    host = inventory.get_host('host1')
    data = get_vars_from_inventory_sources(loader, inventory.sources, [host], 'inventory')
    assert data['test_var_plugin_host'] == 'test_var_plugin_host'

    # Test with a group
    group = inventory.get_group('group1')
    data

# Generated at 2022-06-17 16:21:49.411932
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    # TODO: write unit test for function get_plugin_vars
    pass

# Generated at 2022-06-17 16:21:57.097219
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test get_vars_from_path with a host
    host = Host(name='foobar')
    variable_manager.set_host_variable(host, 'ansible_connection', 'local')

# Generated at 2022-06-17 16:22:28.392982
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader

    vars_plugin_list = list(vars_loader.all())
    for plugin_name in C.VARIABLE_PLUGINS_ENABLED:
        if AnsibleCollectionRef.is_valid_fqcr(plugin_name):
            vars_plugin = vars_loader.get(plugin_name)
            if vars_plugin is None:
                # Error if there's no play directory or the name is wrong?
                continue
            if vars_plugin not in vars_plugin_list:
                vars_plugin_list.append(vars_plugin)


# Generated at 2022-06-17 16:22:35.383098
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin_base
    class TestPlugin(vars_plugin_base):
        def get_vars(self, loader, path, entities):
            return {'test': 'test'}
    loader = vars_loader
    plugin = TestPlugin()
    path = None
    entities = None
    assert get_plugin_vars(loader, plugin, path, entities) == {'test': 'test'}

# Generated at 2022-06-17 16:22:48.675012
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins/hosts'])
    plugin = vars_loader.get('test_vars_plugin')
    path = 'tests/inventory/test_inventory_vars_plugins'
    entities = [inventory.get_host('test_host')]

    data = get_vars_from_path(loader, path, entities, 'inventory')
    assert data == {'test_var': 'test_value'}

# Generated at 2022-06-17 16:22:56.508614
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    host = inventory.get_host('test_host')
    group = inventory.get_group('test_group')

    # Test vars plugin
    plugin = vars_loader.get('test_vars_plugin')
    assert plugin is not None
    assert get_plugin_vars(loader, plugin, 'tests/inventory/test_inventory_vars_plugins', [host]) == {'test_host_var': 'test_host_value'}

# Generated at 2022-06-17 16:23:01.902979
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['test/inventory'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-17 16:23:12.554077
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test get_vars_from_path
    # Test vars_plugins
    vars_plugin_list = list(vars_loader.all())

# Generated at 2022-06-17 16:23:18.261648
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugin'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test with a host
    host = inventory.get_host('test_host')
    data = get_vars_from_path(loader, 'tests/inventory/test_inventory_vars_plugin', [host], 'inventory')
    assert data == {'test_host_var': 'test_host_value'}

    # Test with a group
    group = inventory.get_

# Generated at 2022-06-17 16:23:27.881649
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    host = Host(name='localhost')
    group = Group(name='group')
    entities = [host, group]
    path = '.'
    stage = 'inventory'
    data = get_vars_from_path(loader, path, entities, stage)
    assert data == {}


# Generated at 2022-06-17 16:23:35.931600
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    host = inventory.get_host('test_host')
    group = inventory.get_group('test_group')
    data = get_vars_from_path(loader, 'tests/inventory/test_inventory_vars_plugins', [host, group], 'inventory')
    assert data == {'test_host_var': 'test_host_var_value', 'test_group_var': 'test_group_var_value'}

# Generated at 2022-06-17 16:23:47.792617
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin_base
    from ansible.plugins.loader import vars_loader

    class TestVarsPlugin(vars_plugin_base.VarsBase):
        def get_vars(self, loader, path, entities):
            return {'test_key': 'test_value'}

    vars_loader.add(TestVarsPlugin, 'test_vars_plugin')
    assert get_plugin_vars(vars_loader, TestVarsPlugin(), '', []) == {'test_key': 'test_value'}

# Generated at 2022-06-17 16:25:22.367402
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # test inventory source
    inventory_sources = ['tests/inventory/test_inventory_vars_plugins/host_vars/host1.yml']
    entities = [inventory.get_host('host1')]
    data = get_vars_from_inventory_sources(loader, inventory_sources, entities, 'inventory')
    assert data['inventory_hostname'] == 'host1'

# Generated at 2022-06-17 16:25:30.591372
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.plugins.vars import BaseVarsPlugin

    class TestVarsPlugin(BaseVarsPlugin):
        def get_vars(self, loader, path, entities):
            return {'test_vars_plugin': 'test_vars_plugin'}

    vars_loader.add('test_vars_plugin', TestVarsPlugin)
    assert get_vars_from_path(None, '/tmp', [], 'inventory') == {'test_vars_plugin': 'test_vars_plugin'}

# Generated at 2022-06-17 16:25:37.602381
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars_file

# Generated at 2022-06-17 16:25:46.620858
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    host = Host(name='localhost')
    group = Group(name='group')

    # test get_vars_from_path
    vars_plugin_list = list(vars_loader.all())

# Generated at 2022-06-17 16:25:57.561928
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader

    vars_plugin_list = list(vars_loader.all())
    for plugin_name in C.VARIABLE_PLUGINS_ENABLED:
        if AnsibleCollectionRef.is_valid_fqcr(plugin_name):
            vars_plugin = vars_loader.get(plugin_name)
            if vars_plugin is None:
                # Error if there's no play directory or the name is wrong?
                continue
            if vars_plugin not in vars_plugin_list:
                vars_plugin_list.append(vars_plugin)


# Generated at 2022-06-17 16:26:03.385184
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.plugins.vars import BaseVarsPlugin

    class TestVarsPlugin(BaseVarsPlugin):
        def get_vars(self, loader, path, entities):
            return {'test_var': 'test_value'}

    vars_loader.add(TestVarsPlugin, 'test_vars')

    loader = None
    path = '/path/to/inventory'
    entities = []

    data = get_vars_from_path(loader, path, entities, 'inventory')

    assert data == {'test_var': 'test_value'}

# Generated at 2022-06-17 16:26:13.794017
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test with a vars plugin
    vars_plugin_list = list(vars_loader.all())
    for plugin in vars_plugin_list:
        if plugin._load_name == 'system':
            data = get_plugin_vars(loader, plugin, 'localhost,', [inventory.get_host('localhost')])
            assert data['ansible_system'] == 'Linux'
            break

    # Test with a

# Generated at 2022-06-17 16:26:23.608546
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    vars_plugin_list = list(vars_loader.all())
    for plugin_name in C.VARIABLE_PLUGINS_ENABLED:
        if AnsibleCollectionRef.is_valid_fqcr(plugin_name):
            vars_plugin = vars_loader.get(plugin_name)

# Generated at 2022-06-17 16:26:32.482049
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin_base
    from ansible.plugins.loader import vars_loader

    class TestVarsPlugin(vars_plugin_base.VarsBase):
        def get_vars(self, loader, path, entities):
            return {'test_vars': 'test_vars'}

    vars_loader.add(TestVarsPlugin, 'test_vars')

    assert get_plugin_vars(None, TestVarsPlugin(), None, None) == {'test_vars': 'test_vars'}

# Generated at 2022-06-17 16:26:38.827714
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin_base
    class TestVarsPlugin(vars_plugin_base):
        def get_vars(self, loader, path, entities):
            return {'test_vars': 'test_vars'}

    loader = None
    plugin = TestVarsPlugin()
    path = None
    entities = None
    assert get_plugin_vars(loader, plugin, path, entities) == {'test_vars': 'test_vars'}