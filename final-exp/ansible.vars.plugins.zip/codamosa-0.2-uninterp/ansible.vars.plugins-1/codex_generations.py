

# Generated at 2022-06-17 16:17:15.202042
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # test get_vars_from_path
    vars_plugin_list = list(vars_loader.all())

# Generated at 2022-06-17 16:17:25.739066
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.play import Play

    # Create a fake inventory
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    host = Host(name='localhost')
    group = Group(name='group')
    group.add_host(host)
    inventory.add_group(group)
    inventory.add_host(host)

    # Create a fake variable manager
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Create

# Generated at 2022-06-17 16:17:35.429998
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    host = inventory.get_host('test_host')
    group = inventory.get_group('test_group')

    vars_plugin_list = list(vars_loader.all())

# Generated at 2022-06-17 16:17:47.926458
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.play_context import PlayContext

# Generated at 2022-06-17 16:17:53.182734
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin_base
    from ansible.plugins.loader import vars_loader

    class TestVarsPlugin(vars_plugin_base.VarsBase):
        def get_vars(self, loader, path, entities):
            return {'test': 'test'}

    vars_loader.add(TestVarsPlugin, 'test')
    assert get_plugin_vars(None, vars_loader.get('test'), None, None) == {'test': 'test'}
    vars_loader.remove('test')

# Generated at 2022-06-17 16:18:03.886763
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.vars.hostvars import HostVars
    from ansible.vars.groupvars import GroupVars
    from ansible.plugins.vars import group_vars
    from ansible.plugins.vars import host_vars
    from ansible.plugins.vars import vars_plugins
    from ansible.plugins.loader import vars_loader
    from ansible.plugins.loader import vars_loader
    from ansible.plugins.vars.host_vars import HostVarsModule
    from ansible.plugins.vars.group_vars import GroupVarsModule
   

# Generated at 2022-06-17 16:18:15.874171
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugin'])
    host = inventory.get_host('test_host')
    group = inventory.get_group('test_group')

    # Test vars plugin with get_vars method
    plugin = vars_loader.get('test_vars_plugin')
    assert plugin is not None
    data = get_vars_from_path(loader, 'tests/inventory/test_inventory_vars_plugin', [host], 'inventory')
    assert data == {'test_host': 'test_host_vars'}


# Generated at 2022-06-17 16:18:26.278513
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.plugins.vars import BaseVarsPlugin
    from ansible.utils.collection_loader import AnsibleCollectionRef

    class TestVarsPlugin(BaseVarsPlugin):
        def get_vars(self, loader, path, entities):
            return {'test_vars_plugin': 'test_vars_plugin'}

    class TestVarsPlugin2(BaseVarsPlugin):
        def get_vars(self, loader, path, entities):
            return {'test_vars_plugin2': 'test_vars_plugin2'}


# Generated at 2022-06-17 16:18:35.805565
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import vars_loader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['test/inventory'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-17 16:18:48.345122
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    host = Host(name='testhost')
    group = Group(name='testgroup')
    entities = [host, group]

    vars_plugin_list = list(vars_loader.all())

# Generated at 2022-06-17 16:19:09.329475
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-17 16:19:19.545467
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['test/integration/inventory_vars_plugins/hosts'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    data = get_vars_from_inventory_sources(loader, inventory.sources, inventory.hosts.values(), 'inventory')
    assert data['inventory_hostname'] == 'localhost'
    assert data['inventory_hostname_short'] == 'localhost'
    assert data['inventory_file'] == 'test/integration/inventory_vars_plugins/hosts'

# Generated at 2022-06-17 16:19:26.435839
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.hostvars import HostVars
    from ansible.vars.groupvars import GroupVars
    from ansible.vars.unsafe_proxy import UnsafeProxy

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    host = Host(name='localhost')
    group = Group(name='all')

# Generated at 2022-06-17 16:19:27.136887
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    pass

# Generated at 2022-06-17 16:19:36.995132
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    vars_plugin_list = list(vars_loader.all())
    for plugin in vars_plugin_list:
        if plugin._load_name not in C.VARIABLE_PLUGINS_ENABLED and getattr(plugin, 'REQUIRES_WHITELIST', False):
            # 2.x plugins shipped with ansible should require whitelisting, older or non shipped should load automatically
            continue

        has

# Generated at 2022-06-17 16:19:49.957394
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins/hosts'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    host = inventory.get_host('testhost')

    # test vars plugin
    plugin = vars_loader.get('test_vars_plugin')
    assert plugin is not None

# Generated at 2022-06-17 16:20:00.385864
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['test/ansible/inventory/test_inventory_vars_plugins'])
    host = Host(name='test_host')
    group = Group(name='test_group')
    data = get_vars_from_path(loader, 'test/ansible/inventory/test_inventory_vars_plugins', [host, group], 'inventory')

# Generated at 2022-06-17 16:20:06.878057
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin_base

    class TestVarsPlugin(vars_plugin_base):
        def get_vars(self, loader, path, entities):
            return {'test_plugin_vars': 'test_plugin_vars'}

    class TestVarsPlugin2(vars_plugin_base):
        def get_host_vars(self, host):
            return {'test_plugin_vars2': 'test_plugin_vars2'}

    class TestVarsPlugin3(vars_plugin_base):
        def get_group_vars(self, group):
            return {'test_plugin_vars3': 'test_plugin_vars3'}


# Generated at 2022-06-17 16:20:16.126251
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test with a host
    host = inventory.get_host('host1')
    data = get_vars_from_path(loader, 'tests/inventory/test_inventory_vars_plugins', [host], 'inventory')

# Generated at 2022-06-17 16:20:16.998147
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # TODO: implement
    pass

# Generated at 2022-06-17 16:20:39.462621
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # test vars plugin
    vars_plugin = vars_loader.get('test_vars_plugin')
    assert vars_plugin is not None

# Generated at 2022-06-17 16:20:50.424133
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    host = inventory.get_host('test_host')
    group = inventory.get_group('test_group')
    data = get_vars_from_path(loader, 'tests/inventory/test_inventory_vars_plugins', [host, group], 'inventory')
    assert data == {'test_host_var': 'test_host_var_value', 'test_group_var': 'test_group_var_value'}

# Generated at 2022-06-17 16:20:59.799790
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    inventory.parse_inventory(inventory)
    host = inventory.get_host('test_host')
    group = inventory.get_group('test_group')
    assert get_vars_from_inventory_sources(loader, ['tests/inventory/test_inventory_vars_plugins'], [host], 'inventory') == {'test_host_var': 'test_host_var_value'}

# Generated at 2022-06-17 16:21:04.987371
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugin'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    host = inventory.get_host('test_host')
    hostvars = HostVars(host, variable_manager)
    assert hostvars.get('test_var') == 'test_value'

# Generated at 2022-06-17 16:21:13.243295
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader

    # Create a fake vars plugin
    class FakeVarsPlugin:
        def get_vars(self, loader, path, entities):
            return {'foo': 'bar'}

    # Create a fake loader
    class FakeLoader:
        pass

    # Create a fake host
    class FakeHost:
        def __init__(self, name):
            self.name = name

    # Create a fake group
    class FakeGroup:
        def __init__(self, name):
            self.name = name

    # Create a fake path
    fake_path = '/fake/path'

    # Create a fake entity
    fake_entity = FakeHost('fake_host')

    # Create a fake stage
    fake_stage = 'inventory'

    # Create a fake plugin manager
   

# Generated at 2022-06-17 16:21:20.150899
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test get_vars_from_path
    # Test with a host
    host = inventory.get_host('host1')
    data = get_vars_from_path(loader, 'tests/inventory/test_inventory_vars_plugins', [host], 'inventory')

# Generated at 2022-06-17 16:21:25.101076
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader

    # Test for vars_loader.all()
    assert len(list(vars_loader.all())) > 0

    # Test for get_vars_from_path()
    assert len(get_vars_from_path(None, None, None, None)) == 0

# Generated at 2022-06-17 16:21:31.124285
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin_base

    class TestPlugin(vars_plugin_base):
        def get_vars(self, loader, path, entities):
            return {'test': 'test'}

    loader = None
    plugin = TestPlugin()
    path = None
    entities = None

    assert get_plugin_vars(loader, plugin, path, entities) == {'test': 'test'}

# Generated at 2022-06-17 16:21:37.040053
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test with a vars plugin that returns a dict
    vars_plugin = vars_loader.get('test_vars_plugin_return_dict')
    assert vars_plugin is not None
    assert vars_plugin._load_name == 'test_vars_plugin_return_dict'
    assert vars_plugin._original_path == 'test_vars_plugin_return_dict'
    assert vars_plugin

# Generated at 2022-06-17 16:21:49.473876
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager

    # Create a vars plugin
    class TestVarsPlugin:
        def get_vars(self, loader, path, entities):
            return {'test_vars_plugin': True}

    # Create a vars plugin that will fail
    class TestVarsPluginFail:
        def get_vars(self, loader, path, entities):
            raise Exception('This is a test exception')

    # Create a vars plugin that will fail
    class TestVarsPluginFail2:
        def get_host_vars(self, host):
            raise Exception('This is a test exception')

    # Create a vars plugin that will fail

# Generated at 2022-06-17 16:22:13.861377
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    host = Host(name='localhost')
    group = Group(name='all')

    entities = [host, group]

    path = './test/units/plugins/vars/'
    data = get_vars_from_path(loader, path, entities, 'inventory')

    assert data['test_vars_from_path']

# Generated at 2022-06-17 16:22:24.742401
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.plugins.vars import vars_plugins
    from ansible.plugins.vars.host_group_vars import VarsModule as HostGroupVars
    from ansible.plugins.vars.host_vars import VarsModule as HostVars
    from ansible.plugins.vars.group_vars import VarsModule as GroupVars

# Generated at 2022-06-17 16:22:25.688997
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # TODO: write unit tests
    pass

# Generated at 2022-06-17 16:22:35.826255
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    host = inventory.get_host('test_host')
    group = inventory.get_group('test_group')
    data = get_vars_from_path(loader, 'tests/inventory/test_inventory_vars_plugins', [host, group], 'inventory')
    assert data == {'test_host_var': 'test_host_var_value', 'test_group_var': 'test_group_var_value'}

# Generated at 2022-06-17 16:22:49.647459
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.source import InventorySource
    from ansible.utils.collection_loader import AnsibleCollectionRef

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Create a dummy plugin
    class DummyVarsPlugin:
        def __init__(self):
            self._load_name = 'dummy_vars_plugin'

# Generated at 2022-06-17 16:22:57.048400
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugin'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    host = Host(name='testhost')
    variable_manager.set_host_variable(host, 'test_var', 'test_value')
    variable_manager.set_host_variable(host, 'test_var_2', 'test_value_2')

# Generated at 2022-06-17 16:22:58.548933
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    assert get_vars_from_inventory_sources(None, [], [], '') == {}

# Generated at 2022-06-17 16:23:05.347345
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.play_context import PlayContext

# Generated at 2022-06-17 16:23:15.551383
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    host = Host(name='localhost')
    group = Group(name='group')

    # test with a v2 plugin
    plugin = vars_loader.get('yaml')
    data = get_vars_from_path(loader, './test/unit/plugins/vars_plugins/yaml', [host], 'inventory')


# Generated at 2022-06-17 16:23:27.064638
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    host = inventory.get_host('localhost')

    # test with a v2 vars plugin
    plugin = vars_loader.get('test_vars_plugin')
    assert plugin is not None
    assert plugin.get_vars(loader, '.', [host]) == {'test_vars_plugin': 'test_vars_plugin'}

    # test with a v1 vars plugin
    plugin = vars_loader.get('test_vars_plugin_v1')
    assert plugin is not None
    assert plugin.get_host_

# Generated at 2022-06-17 16:24:04.273101
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    host = Host('host1')
    group = Group('group1')

    # Test with a vars plugin that has get_vars
    plugin = vars_loader.get('test_vars_plugin')
    data = get_vars_from_path(None, '.', [host, group], 'inventory')
    assert data == {'host_var': 'host1', 'group_var': 'group1'}

    # Test with a vars plugin that has get_host_vars and get_group_vars
    plugin = vars_loader.get('test_vars_plugin_legacy')

# Generated at 2022-06-17 16:24:14.520058
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.hostvars import HostVars
    from ansible.vars.groupvars import GroupVars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['/dev/null'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # create a host
    host = Host(name='testhost')
    # add it to the inventory
    inventory.add_host(host)
    # create a group
    group = Group

# Generated at 2022-06-17 16:24:25.426825
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugin'])
    host = inventory.get_host('test_host')
    group = inventory.get_group('test_group')
    data = get_vars_from_path(loader, 'tests/inventory/test_inventory_vars_plugin', [host, group], 'inventory')
    assert data == {'test_host_var': 'test_host_value', 'test_group_var': 'test_group_value'}

# Generated at 2022-06-17 16:24:37.311106
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test with a v2 plugin
    plugin = vars_loader.get('vars_plugins.test_vars_plugin')
    assert plugin is not None
    assert plugin._load_name == 'vars_plugins.test_vars_plugin'
    assert plugin._original_path == 'vars_plugins/test_vars_plugin.py'

# Generated at 2022-06-17 16:24:47.977450
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    vars_plugin_list = list(vars_loader.all())

# Generated at 2022-06-17 16:24:59.005186
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin_base
    from ansible.plugins.loader import vars_loader

    class TestVarsPlugin(vars_plugin_base.VarsBase):
        def get_vars(self, loader, path, entities):
            return {'test_vars_plugin': 'test_vars_plugin'}

    class TestVarsPlugin2(vars_plugin_base.VarsBase):
        def get_host_vars(self, host):
            return {'test_vars_plugin2': 'test_vars_plugin2'}


# Generated at 2022-06-17 16:25:10.499811
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=["tests/inventory/test_inventory_vars_plugins"])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    host = Host(name="testhost")
    group = Group(name="testgroup")

    # Test with a v2 plugin
    vars_plugin = vars_loader.get("test_vars_plugin")
    assert vars_plugin is not None
    data = get_plugin_

# Generated at 2022-06-17 16:25:21.873289
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars
    from ansible.plugins.vars import BaseVarsPlugin
    from ansible.plugins.vars import vars_plugin
   

# Generated at 2022-06-17 16:25:27.579084
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test with a vars plugin that returns a dict
    plugin = vars_loader.get('test_vars_plugin')
    data = get_vars_from_path(loader, '.', [inventory.get_host('localhost')], 'inventory')
    assert data == {'test_vars_plugin': {'test_vars_plugin': 'test_vars_plugin'}}

    # Test with a vars plugin

# Generated at 2022-06-17 16:25:36.326436
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # test with host
    host = Host(name='localhost')
    host.vars = get_vars_from_path(loader, 'localhost,', [host], 'inventory')
    assert host.vars == {'inventory_hostname': 'localhost', 'inventory_hostname_short': 'localhost'}

    # test with group


# Generated at 2022-06-17 16:26:18.251618
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    host = Host(name='localhost')
    host.vars = get_vars_from_path(loader, './test/units/plugins/vars/', [host], 'inventory')
    assert host.vars['test_var'] == 'test_value'

# Generated at 2022-06-17 16:26:26.082091
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    entities = [inventory.get_host('host1'), inventory.get_host('host2')]

    # test with a single plugin
    plugin = vars_loader.get('test_vars_plugin')

# Generated at 2022-06-17 16:26:36.600089
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    vars_plugin_list = list(vars_loader.all())
    for plugin_name in C.VARIABLE_PLUGINS_ENABLED:
        if AnsibleCollectionRef.is_valid_fqcr(plugin_name):
            vars_plugin = vars_loader.get(plugin_name)

# Generated at 2022-06-17 16:26:49.023660
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    host = inventory.get_host('host1')
    group = inventory.get_group('group1')
    entities = [host, group]

    # test vars plugins
    vars_plugin_list = list(vars_loader.all())

# Generated at 2022-06-17 16:26:58.475052
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.plugins.vars import BaseVarsPlugin
    from ansible.utils.collection_loader import AnsibleCollectionRef

    class TestVarsPlugin(BaseVarsPlugin):
        def get_vars(self, loader, path, entities):
            return {'test_vars_plugin': 'test_vars_plugin'}

    vars_loader.add(AnsibleCollectionRef.from_string('test_vars_plugin'), TestVarsPlugin)

    assert get_vars_from_path(None, None, None, None) == {}
    assert get_vars_from_path(None, None, None, None) == {}
    assert get_vars_from_path(None, None, None, 'inventory') == {}
    assert get_vars