

# Generated at 2022-06-17 16:17:13.024547
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.groupvars import GroupVars
    from ansible.vars.groupvars import GroupVarsVars
    from ansible.vars.hostvars import HostVarsVarsVars
    from ansible.vars.groupvars import GroupVarsVarsVars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['test/integration/inventory_vars_plugins/hosts'])

# Generated at 2022-06-17 16:17:23.044051
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.collection_loader import AnsibleCollectionRef

    # Create a host
    host = Host('test')

    # Create a group
    group = Group('test')

    # Create an inventory
    inventory = InventoryManager(loader=DataLoader(), sources=None)

    # Create a variable manager
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)

    # Create a list of entities
    entities = [host, group]

    # Create a list of plugins

# Generated at 2022-06-17 16:17:29.640156
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin_base
    class TestVarsPlugin(vars_plugin_base):
        def get_vars(self, loader, path, entities):
            return {'test_key': 'test_value'}

    loader = vars_loader.get('TestVarsPlugin')
    plugin = loader.get('TestVarsPlugin')
    data = get_plugin_vars(loader, plugin, '', [])
    assert data == {'test_key': 'test_value'}

# Generated at 2022-06-17 16:17:35.772568
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    host = Host(name='localhost')
    group = Group(name='all')
    entities = [host, group]

    # test for v2 plugins
    vars_plugin = vars_loader.get('test_vars_plugin')
    data = get_plugin_vars(loader, vars_plugin, '', entities)
    assert data == {'test_vars_plugin': 'test_vars_plugin'}

    # test for v1 plugins

# Generated at 2022-06-17 16:17:48.397169
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['test/units/plugins/inventory/test_vars_plugin/hosts'])
    host = inventory.get_host('test_host')
    group = inventory.get_group('test_group')
    entities = [host, group]
    path = 'test/units/plugins/inventory/test_vars_plugin'
    stage = 'inventory'
    data = get_vars_from_path(loader, path, entities, stage)

# Generated at 2022-06-17 16:17:54.910730
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.utils.collection_loader import AnsibleCollectionRef
    from ansible.inventory.manager import InventoryManager

    # Create a fake plugin
    class FakePlugin:
        def __init__(self, name):
            self._load_name = name

        def get_vars(self, loader, path, entities):
            return {'fake_plugin_vars': 'fake_plugin_vars'}

    # Create a fake loader
    class FakeLoader:
        def __init__(self, plugin_list):
            self._plugin_list = plugin_list

        def all(self):
            return self._plugin_list

    # Create a fake inventory
    class FakeInventory:
        def __init__(self, sources):
            self.sources = sources

    #

# Generated at 2022-06-17 16:18:04.922019
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.plugins.vars import BaseVarsPlugin
    from ansible.utils.collection_loader import AnsibleCollectionRef

    class TestVarsPlugin(BaseVarsPlugin):
        def get_vars(self, loader, path, entities):
            return {'test_vars_plugin': True}

    vars_loader.add(TestVarsPlugin, 'test_vars_plugin')

    class TestVarsPlugin2(BaseVarsPlugin):
        def get_host_vars(self, host):
            return {'test_vars_plugin2': True}

    vars_loader.add(TestVarsPlugin2, 'test_vars_plugin2')


# Generated at 2022-06-17 16:18:16.591263
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

    # test with a host
    host = inventory.get_host('testhost')
    data = get_vars_from_path(loader, 'tests/inventory', [host], 'inventory')
    assert data['inventory_dir'] == 'tests/inventory'

# Generated at 2022-06-17 16:18:26.932887
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-17 16:18:35.300661
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin_base
    from ansible.plugins.loader import vars_loader

    class TestVarsPlugin(vars_plugin_base.VarsBase):
        def get_vars(self, loader, path, entities, cache=True):
            return {'test_var': 'test_value'}

    vars_loader.add(TestVarsPlugin, 'test_vars')

    loader = None
    path = None
    entities = None
    plugin = TestVarsPlugin()
    data = get_plugin_vars(loader, plugin, path, entities)
    assert data == {'test_var': 'test_value'}

# Generated at 2022-06-17 16:18:52.349008
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test get_vars_from_path with a host
    host = Host(name='localhost')
    host.vars = get_vars_from_path(loader, 'localhost,', [host], 'inventory')

# Generated at 2022-06-17 16:18:59.683960
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    host = inventory.get_host('host1')
    group = inventory.get_group('group1')

    # Test with a single host
    data = get_vars_from_path(loader, 'tests/inventory/test_inventory_vars_plugins', [host], 'inventory')
    assert data == {'host_vars': {'host1': {'host_var': 'host1'}}}

    # Test with a single group

# Generated at 2022-06-17 16:19:09.084398
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugin'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test get_vars_from_path
    entities = [Host('test_host')]
    data = get_vars_from_path(loader, 'tests/inventory/test_inventory_vars_plugin', entities, 'inventory')

# Generated at 2022-06-17 16:19:19.318529
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin_base
    from ansible.plugins.loader import vars_loader

    class TestVarsPlugin(vars_plugin_base.VarsBase):
        def get_vars(self, loader, path, entities):
            return {'test_vars': 'test_vars'}

    class TestVarsPlugin2(vars_plugin_base.VarsBase):
        def get_host_vars(self, host):
            return {'test_host_vars': 'test_host_vars'}

        def get_group_vars(self, group):
            return {'test_group_vars': 'test_group_vars'}


# Generated at 2022-06-17 16:19:23.192627
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugins
    plugin = vars_plugins.get('file')
    loader = None
    path = '/path/to/file'
    entities = ['test_entity']
    data = get_plugin_vars(loader, plugin, path, entities)
    assert data == {'test_entity': {'test_var': 'test_value'}}

# Generated at 2022-06-17 16:19:33.938519
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['test/unit/plugins/test_vars_plugin/hosts'])
    host = inventory.get_host('testhost')
    group = inventory.get_group('testgroup')

    # Test with a single host
    data = get_vars_from_path(loader, 'test/unit/plugins/test_vars_plugin/', [host], 'inventory')
    assert data == {'test_var': 'testhost'}

    # Test with a single group

# Generated at 2022-06-17 16:19:43.997248
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['test/integration/inventory_vars_plugins/hosts'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # test get_vars_from_path
    vars_plugin_list = list(vars_loader.all())

# Generated at 2022-06-17 16:19:50.256762
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin_base
    class TestPlugin(vars_plugin_base):
        def get_vars(self, loader, path, entities):
            return {'test_key': 'test_value'}

    loader = None
    plugin = TestPlugin()
    path = None
    entities = None
    data = get_plugin_vars(loader, plugin, path, entities)
    assert data == {'test_key': 'test_value'}

# Generated at 2022-06-17 16:20:00.615381
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['test/inventory/test_inventory_sources'])
    host = inventory.get_host('test_host')
    group = inventory.get_group('test_group')

    # Test with a single host
    data = get_vars_from_inventory_sources(loader, ['test/inventory/test_inventory_sources'], [host], 'task')
    assert data == {'test_host_var': 'test_host_value', 'test_group_var': 'test_group_value'}

    # Test with a single group

# Generated at 2022-06-17 16:20:09.596308
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin_base
    class TestVarsPlugin(vars_plugin_base):
        def get_vars(self, loader, path, entities):
            return {'test_key': 'test_value'}
    loader = vars_loader
    plugin = TestVarsPlugin()
    path = 'test_path'
    entities = ['test_entity']
    assert get_plugin_vars(loader, plugin, path, entities) == {'test_key': 'test_value'}

# Generated at 2022-06-17 16:20:28.724254
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test for Host
    host = Host(name='localhost')
    host.vars = {'test_host_var': 'test_host_var_value'}
    host.groups = [Group(name='test_group')]

# Generated at 2022-06-17 16:20:36.029511
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin_base
    class TestVarsPlugin(vars_plugin_base):
        def get_vars(self, loader, path, entities):
            return {'test_var': 'test_value'}

    loader = None
    plugin = TestVarsPlugin()
    path = None
    entities = None
    assert get_plugin_vars(loader, plugin, path, entities) == {'test_var': 'test_value'}

# Generated at 2022-06-17 16:20:49.714875
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.collection_loader import AnsibleCollectionRef

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/unit/inventory/test_inventory_vars_plugins'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test vars plugin
    vars_plugin = vars_loader.get(AnsibleCollectionRef.from_string('test_vars_plugin'))
    assert vars_plugin is not None

# Generated at 2022-06-17 16:20:59.207741
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin_base

    class TestVarsPlugin(vars_plugin_base.VarsBase):
        def get_vars(self, loader, path, entities):
            return {'test_vars_plugin': True}

    class TestVarsPlugin2(vars_plugin_base.VarsBase):
        def get_host_vars(self, host):
            return {'test_vars_plugin2': True}

    class TestVarsPlugin3(vars_plugin_base.VarsBase):
        def get_group_vars(self, group):
            return {'test_vars_plugin3': True}


# Generated at 2022-06-17 16:21:04.451886
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin_base
    class TestVarsPlugin(vars_plugin_base):
        def get_vars(self, loader, path, entities):
            return {'test_key': 'test_value'}

    loader = None
    plugin = TestVarsPlugin()
    path = None
    entities = []
    assert get_plugin_vars(loader, plugin, path, entities) == {'test_key': 'test_value'}

# Generated at 2022-06-17 16:21:12.749086
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.vars.hostvars import HostVars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    host = Host(name='localhost')
    host.vars = HostVars(host=host, variables=dict())
    variable_manager._hostvars = {'localhost': host.vars}
    variable_manager._fact_cache = {'localhost': dict()}
    variable_manager._fact_cache_file

# Generated at 2022-06-17 16:21:19.853068
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test if the function can handle a list of entities
    entities = [Host(name='localhost')]
    data = get_vars_from_path(loader, '.', entities, 'inventory')
    assert data == {}

    # Test if the function can handle a list of entities
    entities = [Group(name='all')]
   

# Generated at 2022-06-17 16:21:29.646144
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    host = Host(name="testhost")
    group = Group(name="testgroup")
    data = get_vars_from_path(loader, 'tests/inventory', [host, group], 'inventory')

# Generated at 2022-06-17 16:21:39.205970
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['test/inventory'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_source = dict(
        name="Ansible Play",
        hosts='localhost',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='debug', args=dict(msg='{{test_var}}')))
        ]
    )
    play = Play

# Generated at 2022-06-17 16:21:49.555855
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['test/inventory/test_inventory_vars_plugin'])
    host = inventory.get_host('testhost')
    group = inventory.get_group('testgroup')
    data = get_vars_from_path(loader, 'test/inventory/test_inventory_vars_plugin', [host, group], 'inventory')
    assert data == {'testhost': {'testhost_var': 'testhost_value'}, 'testgroup': {'testgroup_var': 'testgroup_value'}}

# Generated at 2022-06-17 16:22:35.945924
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    host = Host(name='localhost')
    group = Group(name='group')
    inventory.add_host(host)
    inventory.add_group(group)
    entities = [host, group]

    # test get_vars_from_path

# Generated at 2022-06-17 16:22:49.679144
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.loader import vars_loader
    from ansible.plugins.vars import BaseVarsPlugin
    from ansible.utils.collection_loader import AnsibleCollectionRef

    class TestVarsPlugin(BaseVarsPlugin):
        def get_vars(self, loader, path, entities):
            return {'test_key': 'test_value'}

    vars_loader.add(TestVarsPlugin, 'test_vars_plugin')
    plugin = vars_loader.get('test_vars_plugin')
    assert plugin is not None
    assert get_plugin_vars(None, plugin, None, None) == {'test_key': 'test_value'}

    # Test that an error is raised if the plugin is a v1 type plugin

# Generated at 2022-06-17 16:22:54.102519
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin_base
    class TestVarsPlugin(vars_plugin_base):
        def get_vars(self, loader, path, entities):
            return {'test': 'test'}

    loader = None
    plugin = TestVarsPlugin()
    path = None
    entities = None
    assert get_plugin_vars(loader, plugin, path, entities) == {'test': 'test'}

# Generated at 2022-06-17 16:23:03.136173
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars
    from ansible.plugins.vars import BaseVarsPlugin

# Generated at 2022-06-17 16:23:14.422273
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    host = inventory.get_host('testhost')
    group = inventory.get_group('testgroup')

    # Test with a v2 plugin
    plugin = vars_loader.get('test_vars_plugin')
    data = get_vars_from_

# Generated at 2022-06-17 16:23:18.704957
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.plugins.vars import BaseVarsPlugin

    class TestVarsPlugin(BaseVarsPlugin):
        def get_vars(self, loader, path, entities):
            return {'test_vars_plugin': 'test_vars_plugin'}

    vars_loader.add(TestVarsPlugin, 'test_vars_plugin')
    assert get_vars_from_path(None, 'test_path', [], 'inventory') == {'test_vars_plugin': 'test_vars_plugin'}

# Generated at 2022-06-17 16:23:27.998170
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    from ansible.plugins.callback import CallbackBase
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.utils.path import unfrackpath
    from ansible.utils.vars import load_extra_vars

# Generated at 2022-06-17 16:23:36.589273
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    class test_plugin(vars_plugin):
        def get_vars(self, loader, path, entities):
            return {'test_plugin': 'test_plugin'}

    class test_plugin_v1(vars_plugin):
        def get_host_vars(self, host):
            return {'test_plugin_v1': 'test_plugin_v1'}

    class test_plugin_v2(vars_plugin):
        def get_group_vars(self, group):
            return {'test_plugin_v2': 'test_plugin_v2'}


# Generated at 2022-06-17 16:23:50.412840
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.utils.collection_loader import AnsibleCollectionRef

    vars_plugin_list = list(vars_loader.all())
    for plugin_name in C.VARIABLE_PLUGINS_ENABLED:
        if AnsibleCollectionRef.is_valid_fqcr(plugin_name):
            vars_plugin = vars_loader.get(plugin_name)
            if vars_plugin is None:
                # Error if there's no play directory or the name is wrong?
                continue
            if vars_plugin not in vars_plugin_list:
                vars_plugin_list.append(vars_plugin)


# Generated at 2022-06-17 16:24:02.403694
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    host = inventory.get_host('test_host')
    group = inventory.get_group('test_group')
    data = get_vars_from_path(loader, 'tests/inventory/test_inventory_vars_plugins', [host, group], 'inventory')
    assert data == {'test_host_var': 'test_host_value', 'test_group_var': 'test_group_value'}

    # Test with a v1 vars plugin

# Generated at 2022-06-17 16:24:27.569617
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test with a host
    host = inventory.get_host("testhost")
    data = get_vars_from_path(loader, 'tests/inventory', [host], 'inventory')
    assert data['test_var'] == 'testhost'

    # Test with a group

# Generated at 2022-06-17 16:24:38.375821
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin_base
    from ansible.plugins.loader import vars_loader
    from ansible.plugins.vars.host_group import HostGroupVars
    from ansible.plugins.vars.host_group import HostVars

    class TestVars(vars_plugin_base.VarsBase):
        def get_vars(self, loader, path, entities):
            return {'test_vars': 'test_vars'}

    class TestHostVars(HostVars):
        def get_host_vars(self, host):
            return {'test_host_vars': 'test_host_vars'}


# Generated at 2022-06-17 16:24:45.996835
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,', 'otherhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    vars_plugin_list = list(vars_loader.all())

# Generated at 2022-06-17 16:24:51.885342
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.source import InventorySource
    from ansible.utils.collection_loader import AnsibleCollectionRef
    from ansible.utils.vars import combine_vars

    # Create a loader
    loader = DataLoader()

    # Create a group
    group = Group('group')

    # Create a host
    host = Host('host')

    # Create a variable manager
    variable_manager = VariableManager()

    # Create a inventory source

# Generated at 2022-06-17 16:24:57.865314
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin_base

    class TestVarsPlugin(vars_plugin_base):
        def get_vars(self, loader, path, entities):
            return {'test_key': 'test_value'}

    loader = None
    plugin = TestVarsPlugin()
    path = None
    entities = None

    data = get_plugin_vars(loader, plugin, path, entities)

    assert data == {'test_key': 'test_value'}

# Generated at 2022-06-17 16:25:09.805002
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    host = inventory.get_host('test_host')
    group = inventory.get_group('test_group')

    # test vars plugin
    plugin = vars_loader.get('test_vars_plugin')
    assert plugin is not None
    assert get_plugin_vars(loader, plugin, '', [host]) == {'test_host_var': 'test_host_value'}

# Generated at 2022-06-17 16:25:21.398203
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars

# Generated at 2022-06-17 16:25:32.825279
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # test vars_loader
    vars_plugin_list = list(vars_loader.all())

# Generated at 2022-06-17 16:25:38.508428
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugins
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    host = Host(name='localhost')
    group = Group(name='group')
    entities = [host, group]
    path = '.'


# Generated at 2022-06-17 16:25:46.905353
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-17 16:26:26.808058
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    path = 'tests/inventory/test_inventory_vars_plugins'
    entities = [inventory.get_group('all'), inventory.get_group('ungrouped')]
    stage = 'inventory'
    data = get_vars_from_path(loader, path, entities, stage)
    assert data['test_var_1'] == 'test_var_1'

# Generated at 2022-06-17 16:26:31.821739
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.groupvars import GroupVars
    from ansible.vars.vars_plugins.yaml import VarsModule as YamlVarsModule
    from ansible.vars.vars_plugins.ini import VarsModule as IniVarsModule
    from ansible.vars.vars_plugins.json import VarsModule as JsonVarsModule

# Generated at 2022-06-17 16:26:37.023990
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.plugins.vars import vars_plugins

    vars_loader.add(vars_plugins.VarsModule())
    vars_loader.add(vars_plugins.VarsModule())

    assert len(vars_loader.all()) == 2

    assert get_vars_from_path(None, None, None, None) == {}

# Generated at 2022-06-17 16:26:46.556314
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    from ansible.executor.process.worker import WorkerProcess
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.utils.collection_loader import AnsibleCollection

# Generated at 2022-06-17 16:26:55.826894
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.collection_loader import AnsibleCollectionRef

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['test/unit/inventory/test_inventory_vars_plugins'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    vars_plugin_list = list(vars_loader.all())