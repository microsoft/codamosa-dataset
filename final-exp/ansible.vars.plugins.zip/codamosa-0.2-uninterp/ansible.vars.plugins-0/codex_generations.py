

# Generated at 2022-06-17 16:17:25.617790
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin
    from ansible.plugins.loader import vars_loader
    from ansible.utils.collection_loader import AnsibleCollectionRef

    class TestVarsPlugin(vars_plugin.VarsBase):
        def get_vars(self, loader, path, entities):
            return {'test_vars': 'test_vars'}

    test_vars_plugin = TestVarsPlugin(AnsibleCollectionRef.from_string('test_namespace.test_collection.test_plugin'))
    vars_loader.add(test_vars_plugin)

    assert get_plugin_vars(None, test_vars_plugin, None, None) == {'test_vars': 'test_vars'}

# Generated at 2022-06-17 16:17:35.321469
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import IncludeRole

# Generated at 2022-06-17 16:17:46.142606
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test with a vars plugin that does not implement get_vars
    plugin = vars_loader.get('vars_plugin_test_v1')
    path = '/path/to/inventory'
    entities = [inventory.get_host('localhost')]
    data = get_vars_from_path(loader, path, entities, 'inventory')

# Generated at 2022-06-17 16:17:53.581705
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    host = Host('hostname')
    group = Group('groupname')

    # Test with a v2 plugin
    plugin = vars_loader.get('vars_plugin_test')
    assert get_plugin_vars(None, plugin, None, [host]) == {'hostname': 'host'}
    assert get_plugin_vars(None, plugin, None, [group]) == {'groupname': 'group'}

    # Test with a v1 plugin
    plugin = vars_loader.get('vars_plugin_test_v1')

# Generated at 2022-06-17 16:18:03.622395
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    vars_plugin_list = list(vars_loader.all())
    for plugin in vars_plugin_list:
        data = get_vars_from_path(loader, './test/units/plugins/vars/', [inventory.hosts['localhost']], 'inventory')
        assert data['test_var'] == 'test_value'

# Generated at 2022-06-17 16:18:15.784277
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_

# Generated at 2022-06-17 16:18:26.158059
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.collection_loader import AnsibleCollectionRef

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test with a v2 plugin
    plugin = vars_loader.get(AnsibleCollectionRef.from_string('ansible.builtin.vars_files'))
    data = get_plugin_vars(loader, plugin, 'tests/inventory', inventory.get_hosts())

# Generated at 2022-06-17 16:18:34.361178
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin_base
    from ansible.plugins.loader import vars_loader

    class TestVarsPlugin(vars_plugin_base.VarsBase):
        def get_vars(self, loader, path, entities):
            return {'test_vars': 'test_vars'}

    vars_loader.add(TestVarsPlugin, 'test_vars_plugin')
    assert get_plugin_vars(vars_loader, vars_loader.get('test_vars_plugin'), '', []) == {'test_vars': 'test_vars'}

# Generated at 2022-06-17 16:18:43.795251
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # test get_vars_from_path
    # test vars_plugins
    vars_plugins = vars_loader.all()

# Generated at 2022-06-17 16:18:47.569741
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader

    vars_plugin_list = list(vars_loader.all())
    for plugin_name in C.VARIABLE_PLUGINS_ENABLED:
        if AnsibleCollectionRef.is_valid_fqcr(plugin_name):
            vars_plugin = vars_loader.get(plugin_name)
            if vars_plugin is None:
                # Error if there's no play directory or the name is wrong?
                continue
            if vars_plugin not in vars_plugin_list:
                vars_plugin_list.append(vars_plugin)


# Generated at 2022-06-17 16:19:01.254209
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    host = Host(name='localhost')
    inventory.add_host(host)

    vars_plugin_list = list(vars_loader.all())

# Generated at 2022-06-17 16:19:10.434342
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.utils.collection_loader import AnsibleCollectionRef
    from ansible.utils.vars import combine_vars
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    vars_plugin_list = list(vars_loader.all())

# Generated at 2022-06-17 16:19:20.527573
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.play import Play

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    host = Host(name='localhost')
    group = Group(name='group')
    play = Play().load({}, variable_manager=variable_manager, loader=loader)

    # test with v2 plugin
    plugin = vars_loader.get('test_vars_plugin')
   

# Generated at 2022-06-17 16:19:32.468400
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.groupvars import GroupVars
    from ansible.vars.hostvars import HostVars
    from ansible.vars.groupvars import GroupVars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    host = inventory.get_host('testhost')
    group = inventory.get_group('testgroup')

    # Test with a v2 plugin
    plugin = HostVars(inventory)
    data = get_

# Generated at 2022-06-17 16:19:40.451512
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin_base
    from ansible.plugins.loader import vars_loader

    class TestVarsPlugin(vars_plugin_base.VarsBase):
        def get_vars(self, loader, path, entities):
            return {'test_key': 'test_value'}

    vars_loader.add(TestVarsPlugin, 'test_vars_plugin')
    assert get_plugin_vars(None, vars_loader.get('test_vars_plugin'), None, None) == {'test_key': 'test_value'}

# Generated at 2022-06-17 16:19:48.392146
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    host = inventory.get_host('test_host')
    group = inventory.get_group('test_group')

    # Test with a v2 plugin
    plugin = vars_loader.get('yaml_file')

# Generated at 2022-06-17 16:19:54.221108
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugins
    loader = vars_loader
    plugin = vars_plugins.get('yaml')
    path = './test/integration/inventory/test_inventory_vars_plugins/'
    entities = ['test_host']
    data = get_plugin_vars(loader, plugin, path, entities)
    assert data['test_var'] == 'test_value'

# Generated at 2022-06-17 16:20:03.603214
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    # Create a fake vars plugin
    class FakeVarsPlugin:
        def get_vars(self, loader, path, entities):
            return {'fake_vars_plugin': 'fake_vars_plugin'}

    # Create a fake vars plugin that uses the old API
    class FakeVarsPluginOldAPI:
        def get_host_vars(self, host):
            return {'fake_vars_plugin_old_api': 'fake_vars_plugin_old_api'}

    # Create a fake vars plugin that uses the old API

# Generated at 2022-06-17 16:20:14.979127
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    host = inventory.get_host('localhost')

    # Test with a v2 plugin
    vars_plugin = vars_loader.get('test_vars_plugin')
    assert vars_plugin is not None
    data = get_vars_from_path(loader, '.', [host], 'inventory')
    assert data == {'test_vars_plugin': 'test_vars_plugin'}

    # Test with a v1 plugin
    vars_plugin = vars_loader.get('test_vars_plugin_v1')


# Generated at 2022-06-17 16:20:24.471470
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['test/unit/plugins/inventory/test_inventory_vars_plugins/hosts'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    host = Host(name='testhost')
    group = Group(name='testgroup')
    entities = [host, group]
    path = 'test/unit/plugins/inventory/test_inventory_vars_plugins'
    stage = 'inventory'

    data

# Generated at 2022-06-17 16:20:36.531933
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin
    class TestVarsPlugin(vars_plugin.VarsBase):
        def get_vars(self, loader, path, entities):
            return {'test': 'test'}

    loader = None
    plugin = TestVarsPlugin()
    path = None
    entities = None
    assert get_plugin_vars(loader, plugin, path, entities) == {'test': 'test'}

# Generated at 2022-06-17 16:20:49.815040
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.groupvars import GroupVars
    from ansible.vars.unsafe_proxy import UnsafeProxy

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    host = Host(name='testhost')

# Generated at 2022-06-17 16:20:59.287995
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    vars_loader.add_directory(os.path.join(os.path.dirname(__file__), 'vars_plugins'))
    vars_loader.all()
    loader = None
    path = os.path.join(os.path.dirname(__file__), 'vars_plugins')
    entities = []
    stage = 'inventory'
    data = get_vars_from_path(loader, path, entities, stage)
    assert data['test_var'] == 'test_var_value'
    assert data['test_var_2'] == 'test_var_2_value'
    assert data['test_var_3'] == 'test_var_3_value'

# Generated at 2022-06-17 16:21:05.966672
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # test with a host
    host = Host(name='localhost')
    host.vars = {'foo': 'bar'}
    data = get_vars_from_path(loader, '.', [host], 'inventory')
    assert data == {'foo': 'bar'}

    # test with a group
    group = Group

# Generated at 2022-06-17 16:21:15.241758
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    host = inventory.get_host('testhost')
    group = inventory.get_group('testgroup')

    # Test with a v2 plugin
    plugin = vars_loader.get('yaml_file')
    path = 'tests/vars_plugins/yaml_file'

# Generated at 2022-06-17 16:21:24.807118
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    host = inventory.get_host('test_host')
    group = inventory.get_group('test_group')

    data = get_vars_from_inventory_sources(loader, ['tests/inventory/test_inventory_vars_plugins'], [host, group], 'inventory')
    assert data == {'test_host': 'test_host_value', 'test_group': 'test_group_value'}

# Generated at 2022-06-17 16:21:34.321373
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugins
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    test_host = Host('test_host')
    test_group = Group('test_group')

    test_plugin = vars_plugins.TestVarsPlugin()
    vars_loader.add(test_plugin, 'test_plugin')

    assert get_plugin_vars(vars_loader, test_plugin, 'test_path', [test_host]) == {'test_host': 'test_host'}
    assert get_plugin_vars(vars_loader, test_plugin, 'test_path', [test_group]) == {'test_group': 'test_group'}
    assert get_plugin_

# Generated at 2022-06-17 16:21:48.117399
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.utils.collection_loader import AnsibleCollectionRef
    from ansible.utils.vars import combine_vars

    # Test for vars_loader.all()
    vars_plugin_list = list(vars_loader.all())
    assert vars_plugin_list is not None

    # Test for vars_loader.get()
    vars_plugin = vars_loader.get('test_plugin')
    assert vars_plugin is not None

    # Test for AnsibleCollectionRef.is_valid_fqcr()
    assert AnsibleCollectionRef.is_valid_fqcr('test_plugin')

    # Test for combine_vars()
    data = {}
    data = combine_vars(data, {'test': 'test'})


# Generated at 2022-06-17 16:21:56.108508
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.collection_loader import AnsibleCollectionRef

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugin'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # test vars plugin
    vars_plugin = vars_loader.get(AnsibleCollectionRef.from_string('ansible.builtin.vars_plugin'))
    assert vars_plugin is not None



# Generated at 2022-06-17 16:22:04.268324
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test with a single host
    host = inventory.get_host('test_host')
    data = get_vars_from_path(loader, 'tests/inventory/test_inventory_vars_plugins', [host], 'inventory')
    assert data == {'test_host_var': 'test_host_value'}

    # Test with a group
    group = inventory.get

# Generated at 2022-06-17 16:22:27.928550
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugins
    from ansible.plugins.loader import vars_loader

    vars_plugin_list = list(vars_loader.all())
    for plugin_name in C.VARIABLE_PLUGINS_ENABLED:
        if AnsibleCollectionRef.is_valid_fqcr(plugin_name):
            vars_plugin = vars_loader.get(plugin_name)
            if vars_plugin is None:
                # Error if there's no play directory or the name is wrong?
                continue
            if vars_plugin not in vars_plugin_list:
                vars_plugin_list.append(vars_plugin)


# Generated at 2022-06-17 16:22:38.890114
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin_base
    class TestVarsPlugin(vars_plugin_base):
        def get_vars(self, loader, path, entities):
            return {'test_vars_plugin': True}
    class TestVarsPlugin2(vars_plugin_base):
        def get_host_vars(self, host):
            return {'test_vars_plugin_2': True}
    class TestVarsPlugin3(vars_plugin_base):
        def get_group_vars(self, group):
            return {'test_vars_plugin_3': True}
    class TestVarsPlugin4(vars_plugin_base):
        def run(self, host):
            return {'test_vars_plugin_4': True}


# Generated at 2022-06-17 16:22:51.334747
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['test/inventory/test_inventory_vars_plugin'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    host = Host(name='test_host')
    group = inventory.groups['test_group']

    # test_vars_plugin.yml is a v2 plugin
    data = get_vars_from_path(loader, 'test/inventory/test_inventory_vars_plugin', [host], 'inventory')

# Generated at 2022-06-17 16:22:58.551947
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['test/inventory/test_inventory_vars_plugins'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test with stage=inventory
    vars_from_inventory_sources = get_vars_from_inventory_sources(loader, inventory.sources, inventory.hosts, 'inventory')
    assert vars_from_inventory_sources['inventory_vars_plugin_test_var'] == 'inventory_vars_plugin_test_var_value'

    # Test with stage=task

# Generated at 2022-06-17 16:23:05.348908
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    host = Host(name='localhost')
    group = Group(name='group')

    # test with v2 plugin
    plugin = vars_loader.get('vars_plugin_test')
    assert plugin is not None

# Generated at 2022-06-17 16:23:15.550750
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    import ansible.plugins.vars.host_group_vars
    import ansible.plugins.vars.host_vars
    import ansible.plugins.vars.yaml
    import ansible.plugins.vars.json

    class TestVarsPlugin(object):
        def __init__(self, name):
            self._load_name = name

        def get_vars(self, loader, path, entities):
            return {'test_vars_plugin': True}

    class TestVarsPlugin2(object):
        def __init__(self, name):
            self._load_name = name

        def get_host_vars(self, host):
            return {'test_vars_plugin2': True}


# Generated at 2022-06-17 16:23:27.065077
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources=['tests/inventory_vars_plugin'])
    variable_manager = VariableManager(loader=loader, inventory=inv_manager)

    host = Host(name='testhost')
    group = Group(name='testgroup')

    data = get_vars_from_path(loader, 'tests/inventory_vars_plugin', [host, group], 'inventory')


# Generated at 2022-06-17 16:23:35.719950
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test with a host
    host = inventory.get_host('host1')
    data = get_vars_from_inventory_sources(loader, inventory.sources, [host], 'task')

# Generated at 2022-06-17 16:23:49.854731
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    all_hosts = inventory.get_hosts()
    all_groups = inventory.get_groups()

    # test inventory vars plugins
    # test vars plugins in inventory source directory
    data = get_vars_from_inventory_sources(loader, ['tests/inventory/test_inventory_vars_plugins'], all_hosts, 'inventory')
    assert data['inventory_vars_plugin_test_var'] == 'inventory_vars_plugin_test_value'

# Generated at 2022-06-17 16:23:53.613448
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin_base
    class TestVarsPlugin(vars_plugin_base.VarsBase):
        def get_vars(self, loader, path, entities):
            return {'test_key': 'test_value'}

    loader = None
    plugin = TestVarsPlugin()
    path = None
    entities = None
    data = get_plugin_vars(loader, plugin, path, entities)
    assert data == {'test_key': 'test_value'}

# Generated at 2022-06-17 16:24:26.754341
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin_base
    class TestPlugin(vars_plugin_base):
        def get_vars(self, loader, path, entities):
            return {'test_plugin': 'test_plugin'}
    plugin = TestPlugin()
    loader = None
    path = None
    entities = None
    assert get_plugin_vars(loader, plugin, path, entities) == {'test_plugin': 'test_plugin'}


# Generated at 2022-06-17 16:24:38.200002
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    host = inventory.get_host('test_host')
    group = inventory.get_group('test_group')
    data = get_vars_from_path(loader, 'tests/inventory/test_inventory_vars', [host, group], 'inventory')
    assert data['test_host_var'] == 'test_host_var_value'
    assert data['test_group_var'] == 'test_group_var_value'

# Generated at 2022-06-17 16:24:45.855671
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugins

    class TestVarsPlugin:
        def get_vars(self, loader, path, entities):
            return {'test_vars': 'test_vars'}

        def get_host_vars(self, host):
            return {'test_host_vars': 'test_host_vars'}

        def get_group_vars(self, group):
            return {'test_group_vars': 'test_group_vars'}

    class TestVarsPlugin2:
        def run(self, host):
            return {'test_vars2': 'test_vars2'}

    class TestVarsPlugin3:
        def run(self, host):
            return {'test_vars3': 'test_vars3'}

# Generated at 2022-06-17 16:24:50.910460
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test get_vars_from_path with a vars plugin that does not implement get_vars
    plugin = vars_loader.get('test_vars_plugin')
    path = './test/units/plugins/vars/test_vars_plugin'
    entities = [inventory.get_host('localhost')]
    data = get_vars_from_path(loader, path, entities, 'inventory')
   

# Generated at 2022-06-17 16:24:59.741975
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['test/inventory/test_inventory_vars_plugins'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    assert get_vars_from_inventory_sources(loader, ['test/inventory/test_inventory_vars_plugins'], inventory.get_groups_dict(), 'inventory') == {'group_vars': {'all': {'group_var': 'group_var_value'}}, 'host_vars': {'host1': {'host_var': 'host_var_value'}}}
    assert get_vars_from_inventory

# Generated at 2022-06-17 16:25:10.947555
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=["tests/inventory/test_inventory_vars_plugin"])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    vars_plugin_list = list(vars_loader.all())

# Generated at 2022-06-17 16:25:22.145093
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.utils.collection_loader import AnsibleCollectionRef
    from ansible.utils.vars import combine_vars
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.data import InventoryData
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    inventory.add_group('group1')
    inventory.add_host(Host('host1', groups=['group1']))

# Generated at 2022-06-17 16:25:33.136561
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['test/inventory'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test for host
    host = inventory.get_host('test_host')
    data = get_vars_from_path(loader, 'test/inventory', [host], 'inventory')
    assert data == {'test_host_var': 'test_host_var_value'}

    # Test for group

# Generated at 2022-06-17 16:25:44.707633
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    path = './test/integration/inventory_vars_plugins'
    entities = [inventory.get_host('localhost')]
    stage = 'inventory'

    data = get_vars_from_path(loader, path, entities, stage)
    assert data['inventory_vars_plugin_test_var'] == 'inventory_vars_plugin_test_var_value'

    # test that the vars plugin is not loaded if the stage is 'task'
    stage = 'task'

# Generated at 2022-06-17 16:25:51.608581
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.collection_loader import AnsibleCollectionRef

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test with a v2 plugin
    plugin = vars_loader.get(AnsibleCollectionRef.from_string('ansible.builtin.vars_plugins.test_plugin'))
    assert plugin is not None

# Generated at 2022-06-17 16:26:58.572912
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.play_context import PlayContext