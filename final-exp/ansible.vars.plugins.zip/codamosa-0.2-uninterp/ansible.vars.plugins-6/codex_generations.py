

# Generated at 2022-06-17 16:17:15.156959
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(loader=loader, variable_manager=variable_manager)
    variable_manager.set_host_variable(inventory.get_host('testhost'), 'ansible_host', '127.0.0.1')
    variable_manager.set_host_variable(inventory.get_host('testhost'), 'ansible_port', '22')
   

# Generated at 2022-06-17 16:17:25.690808
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    vars_plugin_list = list(vars_loader.all())
    for plugin in vars_plugin_list:
        if plugin._load_name not in C.VARIABLE_PLUGINS_ENABLED and getattr(plugin, 'REQUIRES_WHITELIST', False):
            # 2.x plugins shipped with ansible should require whitelisting, older or non shipped should load automatically
            continue

# Generated at 2022-06-17 16:17:33.405118
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader

    # Test that the function returns a dictionary
    assert isinstance(get_vars_from_path(vars_loader, '', [], 'inventory'), dict)

    # Test that the function returns a dictionary with the correct keys
    assert 'test_key' in get_vars_from_path(vars_loader, '', [], 'inventory')

    # Test that the function returns a dictionary with the correct values
    assert get_vars_from_path(vars_loader, '', [], 'inventory')['test_key'] == 'test_value'

# Generated at 2022-06-17 16:17:40.336946
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.collection_loader import AnsibleCollectionRef

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test with a v2 plugin
    plugin = vars_loader.get(AnsibleCollectionRef.from_string('ansible.builtin.vars_plugins.test_vars_plugin'))
    assert plugin is not None
    assert plugin._load_

# Generated at 2022-06-17 16:17:49.969151
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['test/unit/plugins/inventory/test_vars_plugin/hosts'])
    host = inventory.get_host('test_host')
    group = inventory.get_group('test_group')
    data = get_vars_from_path(loader, 'test/unit/plugins/inventory/test_vars_plugin', [host, group], 'inventory')
    assert data == {'test_host': 'test_host_vars', 'test_group': 'test_group_vars'}

    # Test v1 vars plugin
    vars_loader.add

# Generated at 2022-06-17 16:18:01.813924
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin_base

    class TestVarsPlugin(vars_plugin_base):
        def get_vars(self, loader, path, entities):
            return {'test_vars': 'test_vars'}

    class TestVarsPlugin2(vars_plugin_base):
        def get_host_vars(self, host):
            return {'test_host_vars': 'test_host_vars'}

        def get_group_vars(self, group):
            return {'test_group_vars': 'test_group_vars'}

    class TestVarsPlugin3(vars_plugin_base):
        def run(self, host, vault_password=None):
            return {'test_run': 'test_run'}


# Generated at 2022-06-17 16:18:07.634530
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase
    from ansible.utils.vars import combine_vars


# Generated at 2022-06-17 16:18:18.145784
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    host = inventory.get_host('test_inventory_vars_plugins')
    group = inventory.get_group('test_inventory_vars_plugins')
    assert host.get_vars() == {'test_inventory_vars_plugins': 'test_inventory_vars_plugins'}

# Generated at 2022-06-17 16:18:27.899361
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test with a host
    host = inventory.get_host('test_host')
    assert get_vars_from_path(loader, 'tests/inventory/test_inventory_vars_plugins', [host], 'inventory') == {'test_host_var': 'test_host_value'}

    # Test with a group
    group = inventory.get_group('test_group')

# Generated at 2022-06-17 16:18:36.926906
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['test/inventory/test_inventory_vars_plugins'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test for host
    host = inventory.get_host('host1')
    data = get_vars_from_path(loader, 'test/inventory/test_inventory_vars_plugins', [host], 'inventory')

# Generated at 2022-06-17 16:18:54.443514
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    # Test with a single source
    sources = ['/path/to/inventory/source']
    entities = ['host1', 'host2']
    stage = 'inventory'
    data = get_vars_from_inventory_sources(None, sources, entities, stage)
    assert data == {'host1': {'var1': 'value1'}, 'host2': {'var2': 'value2'}}

    # Test with multiple sources
    sources = ['/path/to/inventory/source', '/path/to/inventory/source2']
    entities = ['host1', 'host2']
    stage = 'inventory'
    data = get_vars_from_inventory_sources(None, sources, entities, stage)

# Generated at 2022-06-17 16:19:01.006851
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.collection_loader import AnsibleCollectionRef

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugin'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test the vars plugin in the inventory directory
    plugin_name = 'test_vars_plugin'
    plugin_path = 'tests/inventory/test_inventory_vars_plugin/vars_plugins/%s.py' % plugin_name

# Generated at 2022-06-17 16:19:04.565430
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin_base
    class TestVarsPlugin(vars_plugin_base):
        def get_vars(self, loader, path, entities):
            return {'test': 'test'}
    loader = vars_loader
    plugin = TestVarsPlugin()
    path = '/path/to/inventory'
    entities = [Host('test')]
    assert get_plugin_vars(loader, plugin, path, entities) == {'test': 'test'}

# Generated at 2022-06-17 16:19:14.430583
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    host = inventory.get_host('localhost')

    vars_plugin_list = list(vars_loader.all())

# Generated at 2022-06-17 16:19:23.299915
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=["tests/inventory/test_inventory_vars_plugin"])
    host = inventory.get_host("testhost")
    group = inventory.get_group("testgroup")
    data = get_vars_from_path(loader, "tests/inventory/test_inventory_vars_plugin", [host, group], "inventory")
    assert data == {'testhost': {'hostvars': {'testhost': {'test_host_var': 'test_host_value'}}},
                    'testgroup': {'groupvars': {'testgroup': {'test_group_var': 'test_group_value'}}}}

# Generated at 2022-06-17 16:19:33.937890
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test that the vars plugin is loaded
    assert vars_loader.get('test_vars_plugin') is not None

    # Test that the vars plugin is not loaded
    assert vars_loader.get('test_vars_plugin_disabled') is None

    # Test that the vars plugin is loaded

# Generated at 2022-06-17 16:19:43.998549
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugin'])
    inv_manager.parse_sources()
    variable_manager = VariableManager(loader=loader, inventory=inv_manager)

    # Test with a host
    host = inv_manager.get_host('host1')
    data = get_vars_from_inventory_sources(loader, inv_manager.sources, [host], 'inventory')
    assert data == {'test_var': 'test_value'}

    # Test with a group

# Generated at 2022-06-17 16:19:50.193523
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.utils.collection_loader import AnsibleCollectionRef
    from ansible.plugins.loader import vars_loader

    display = Display()
    loader = DataLoader()

# Generated at 2022-06-17 16:20:00.615220
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['test/inventory'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    host = Host(name='testhost')
    group = Group(name='testgroup')

    # Test with stage=inventory
    vars = get_vars_from_inventory_sources(loader, inventory.sources, [host, group], 'inventory')

# Generated at 2022-06-17 16:20:12.306123
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    variable_manager.set_inventory(inventory)
    variable_manager.extra_vars = {'foo': 'bar'}

    # Test with a host
    host = inventory.get_host('host1')
    hostvars = HostVars(host, variable_manager)
    assert hostvars.get('test_var') == 'test_value'

    # Test

# Generated at 2022-06-17 16:20:28.636118
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    vars_plugin_list = list(vars_loader.all())
    for plugin in vars_plugin_list:
        if plugin._load_name not in C.VARIABLE_PLUGINS_ENABLED and getattr(plugin, 'REQUIRES_WHITELIST', False):
            # 2.x plugins shipped with ansible should require whitelisting, older or non shipped should load automatically
            continue
        has

# Generated at 2022-06-17 16:20:36.032601
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin_base
    class TestPlugin(vars_plugin_base):
        def get_vars(self, loader, path, entities):
            return {'test_key': 'test_value'}

    loader = None
    plugin = TestPlugin()
    path = None
    entities = None
    data = get_plugin_vars(loader, plugin, path, entities)
    assert data == {'test_key': 'test_value'}

# Generated at 2022-06-17 16:20:46.080856
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin_base

    class TestVarsPlugin(vars_plugin_base):
        def get_vars(self, loader, path, entities):
            return {'test_key': 'test_value'}

    loader = None
    plugin = TestVarsPlugin()
    path = None
    entities = None
    assert get_plugin_vars(loader, plugin, path, entities) == {'test_key': 'test_value'}

# Generated at 2022-06-17 16:20:57.233783
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.utils.plugin_docs import get_docstring
    from ansible.plugins.vars import BaseVarsPlugin


# Generated at 2022-06-17 16:21:05.959982
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    host = Host(name='localhost')
    host.set_variable('ansible_connection', 'local')
    inventory.add_host(host)
    group = inventory.get_group('all')
    group.add_host(host)

    # Test with a v2 plugin
    vars_plugin = vars_loader.get('test_vars_plugin')
    data = get_plugin_vars(loader, vars_plugin, '.', [host, group])

# Generated at 2022-06-17 16:21:15.238755
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    host = inventory.get_host('test_host')
    group = inventory.get_group('test_group')

    # test vars plugin
    vars_plugin = vars_loader.get('test_vars_plugin')
    assert vars_plugin is not None
    assert vars_plugin.get_vars(loader, 'tests/inventory/test_inventory_vars_plugins', [host]) == {'test_host_var': 'test_host_var_value'}
    assert vars

# Generated at 2022-06-17 16:21:26.095170
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    host = inventory.get_host('test_host')
    group = inventory.get_group('test_group')

    # test with a single host
    vars = get_vars_from_inventory_sources(loader, inventory.sources(), [host], 'inventory')
    assert vars == {'test_host_var': 'test_host_var_value', 'test_group_var': 'test_group_var_value'}

    # test with a single group

# Generated at 2022-06-17 16:21:31.000640
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugin'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    vars_plugin_list = list(vars_loader.all())
    plugin = vars_plugin_list[0]
    path = 'tests/inventory/test_inventory_vars_plugin'
    entities = [Host(name='testhost'), Group(name='testgroup')]


# Generated at 2022-06-17 16:21:39.692598
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader

    vars_plugin_list = list(vars_loader.all())
    for plugin_name in C.VARIABLE_PLUGINS_ENABLED:
        if AnsibleCollectionRef.is_valid_fqcr(plugin_name):
            vars_plugin = vars_loader.get(plugin_name)
            if vars_plugin is None:
                # Error if there's no play directory or the name is wrong?
                continue
            if vars_plugin not in vars_plugin_list:
                vars_plugin_list.append(vars_plugin)


# Generated at 2022-06-17 16:21:50.510994
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    host = Host(name='localhost')
    host.set_variable('ansible_connection', 'local')
    inventory.add_host(host)

    # test vars_loader
    vars_plugin_list = list(vars_loader.all())

# Generated at 2022-06-17 16:22:13.824081
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.utils.collection_loader import AnsibleCollectionRef
    from ansible.utils.vars import combine_vars
    from ansible.plugins.vars import vars_plugins

    vars_plugin_list = list(vars_loader.all())
    for plugin_name in C.VARIABLE_PLUGINS_ENABLED:
        if AnsibleCollectionRef.is_valid_fqcr(plugin_name):
            vars_plugin = vars_loader.get(plugin_name)
            if vars_plugin is None:
                # Error if there's no play directory or the name is wrong?
                continue
            if vars_plugin not in vars_plugin_list:
                vars_plugin_list.append(vars_plugin)



# Generated at 2022-06-17 16:22:24.693541
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inv_path = os.path.join(os.path.dirname(__file__), '..', '..', '..', 'test', 'units', 'inventory', 'hosts')
    inv_path = os.path.abspath(inv_path)
    inventory = InventoryManager(loader=loader, sources=inv_path)
    host = inventory.get_host('testhost')
    group = inventory.get_group('testgroup')
    data = get_vars_from_path(loader, inv_path, [host, group], 'inventory')
    assert data['test_var'] == 'test_value'
   

# Generated at 2022-06-17 16:22:29.002127
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin_base
    class MyVarsPlugin(vars_plugin_base):
        def get_vars(self, loader, path, entities):
            return {'foo': 'bar'}
    loader = vars_loader
    plugin = MyVarsPlugin()
    path = 'path'
    entities = ['entities']
    assert get_plugin_vars(loader, plugin, path, entities) == {'foo': 'bar'}

# Generated at 2022-06-17 16:22:36.818287
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin_base
    from ansible.plugins.loader import vars_loader

    class TestVarsPlugin(vars_plugin_base.VarsBase):
        def get_vars(self, loader, path, entities):
            return {'test_var': 'test_value'}

    vars_loader.add(TestVarsPlugin, 'test_vars_plugin')
    assert get_plugin_vars(None, TestVarsPlugin(), None, None) == {'test_var': 'test_value'}

# Generated at 2022-06-17 16:22:50.397271
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    host = inventory.get_host('test_host')
    group = inventory.get_group('test_group')
    data = get_vars_from_path(loader, 'tests/inventory/test_inventory_vars_plugins', [host, group], 'inventory')
    assert data['test_host_var'] == 'test_host_value'

# Generated at 2022-06-17 16:22:57.806019
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    host = inventory.get_host('host1')
    hostvars = HostVars(loader=loader, variable_manager=variable_manager, host=host)
    data = get_vars_from_path(loader, 'tests/inventory/test_inventory_vars_plugins', [host], 'inventory')
    assert data == hostvars.data

# Generated at 2022-06-17 16:23:03.933632
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager

    loader = vars_loader
    path = './test/integration/inventory_vars_plugins'
    inventory = InventoryManager(loader=loader, sources=path)
    host = inventory.get_host('host1')
    group = inventory.get_group('group1')
    data = get_vars_from_path(loader, path, [host, group], 'inventory')
    assert data['host_var'] == 'host1'
    assert data['group_var'] == 'group1'
    assert data['all_var'] == 'all'

# Generated at 2022-06-17 16:23:14.699366
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # test with a host
    host = inventory.get_host('localhost')
    data = get_vars_from_path(loader, './test/units/vars_plugins/', [host], 'inventory')
    assert data == {'test_host_var': 'test_host_var_value'}

    # test with a group
    group = inventory.get_group('all')
    data = get_v

# Generated at 2022-06-17 16:23:20.267249
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugin'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test with a host
    host = inventory.get_host('test_host')
    data = get_vars_from_path(loader, 'tests/inventory/test_inventory_vars_plugin', [host], 'inventory')
    assert data == {'test_host': {'test_var': 'test_value'}}

    # Test with a group

# Generated at 2022-06-17 16:23:31.163476
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test with stage=inventory
    vars_from_inventory_sources = get_vars_from_inventory_sources(loader, inventory.sources, inventory.hosts, 'inventory')
    assert vars_from_inventory_sources['test_inventory_vars_plugins_var'] == 'test_inventory_vars_plugins_var_value'

    # Test with stage=task

# Generated at 2022-06-17 16:24:13.792854
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test for vars_plugins
    vars_plugin_list = list(vars_loader.all())

# Generated at 2022-06-17 16:24:26.009937
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_manager'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # get_vars_from_path(loader, path, entities, stage)
    # get_vars_from_path(loader, 'tests/inventory/test_inventory_manager', ['test_host'], 'inventory')
    # get_vars_from_path(loader, 'tests/inventory/test_inventory_manager', ['test_group'], 'inventory')
    # get_vars

# Generated at 2022-06-17 16:24:37.667459
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import vars_loader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test vars plugin
    vars_plugin_list = list(vars_loader.all())

# Generated at 2022-06-17 16:24:45.335602
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.plugins.vars import BaseVarsPlugin
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import combine_

# Generated at 2022-06-17 16:24:51.758178
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    vars_plugin_list = list(vars_loader.all())
    for plugin_name in C.VARIABLE_PLUGINS_ENABLED:
        if AnsibleCollectionRef.is_valid_fqcr(plugin_name):
            vars_plugin = vars_loader.get(plugin_name)
            if vars_plugin is None:
                # Error if there's no play directory or the name is wrong?
                continue
            if vars_plugin not in vars_plugin_list:
                vars_plugin_list.append(vars_plugin)


# Generated at 2022-06-17 16:24:58.904672
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.plugins.vars import BaseVarsPlugin
    from ansible.utils.collection_loader import AnsibleCollectionRef

    class TestVarsPlugin(BaseVarsPlugin):
        def get_vars(self, loader, path, entities):
            return {'test_key': 'test_value'}

    vars_loader.add(AnsibleCollectionRef.from_string('test_collection.test_namespace.test_plugin'), TestVarsPlugin)
    assert get_vars_from_path(None, None, None, None) == {'test_key': 'test_value'}

# Generated at 2022-06-17 16:25:10.434051
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    host = Host(name='testhost')
    group = Group(name='testgroup')
    data = get_vars_from_path(loader, 'tests/inventory/test_inventory_vars_plugins', [host, group], 'inventory')

# Generated at 2022-06-17 16:25:21.841687
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_manager/hosts'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = HostVars(loader=loader, inventory=inventory)
    variable_manager.set_host_variable(host=inventory.get_host('localhost'), varname='ansible_connection', value='local')

# Generated at 2022-06-17 16:25:33.065802
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.utils.collection_loader import AnsibleCollectionRef
    from ansible.utils.vars import combine_vars

    # Test with vars_loader.all()
    vars_plugin_list = list(vars_loader.all())
    for plugin_name in C.VARIABLE_PLUGINS_ENABLED:
        if AnsibleCollectionRef.is_valid_fqcr(plugin_name):
            vars_plugin = vars_loader.get(plugin_name)
            if vars_plugin is None:
                # Error if there's no play directory or the name is wrong?
                continue
            if vars_plugin not in vars_plugin_list:
                vars_plugin_list.append(vars_plugin)

    # Test

# Generated at 2022-06-17 16:25:44.708515
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.plugins.vars.host_group_vars import VarsModule as host_group_vars
    from ansible.plugins.vars.host_vars import VarsModule as host_vars

    vars_loader.add(host_group_vars, 'test_host_group_vars')
    vars_loader.add(host_vars, 'test_host_vars')

    loader = None
    path = '/tmp/test_path'
    entities = ['test_host']

    data = get_vars_from_path(loader, path, entities, 'inventory')

# Generated at 2022-06-17 16:26:27.244093
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin_base
    from ansible.plugins.loader import vars_loader

    class TestVarsPlugin(vars_plugin_base.VarsBase):
        def get_vars(self, loader, path, entities):
            return {'test_vars_plugin': 'test_vars_plugin'}

    class TestVarsPlugin2(vars_plugin_base.VarsBase):
        def get_host_vars(self, host):
            return {'test_vars_plugin2': 'test_vars_plugin2'}


# Generated at 2022-06-17 16:26:37.545900
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['test/inventory'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-17 16:26:46.913212
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test with a host
    host = inventory.get_host('host1')
    data = get_vars_from_inventory_sources(loader, inventory.sources, [host], 'task')
    assert data == {'test_inventory_vars_plugins': {'host_var': 'host_var_value'}}

    # Test with a group
    group = inventory.get_group

# Generated at 2022-06-17 16:26:52.736957
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test with stage=inventory
    data = get_vars_from_inventory_sources(loader, inventory.sources, inventory.hosts, 'inventory')
    assert data == {'inventory_vars_plugin_data': 'inventory_vars_plugin_data'}

    # Test with stage=task

# Generated at 2022-06-17 16:27:00.122620
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugin'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test that the vars plugin is loaded
    assert len(vars_loader.all()) == 1
    assert vars_loader.all()[0]._load_name == 'test_vars_plugin'

    # Test that the vars plugin is called