

# Generated at 2022-06-17 16:17:13.895327
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.collection_loader import AnsibleCollectionRef

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    host = inventory.get_host('test_host')
    group = inventory.get_group('test_group')

    # test vars plugins
    vars_plugin_list = list(vars_loader.all())


# Generated at 2022-06-17 16:17:23.967147
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory.yaml'])
    host = inventory.get_host('test_host')
    group = inventory.get_group('test_group')
    data = get_vars_from_path(loader, 'tests/inventory/test_inventory.yaml', [host, group], 'inventory')
    assert data['test_var'] == 'test_value'
    assert data['test_group_var'] == 'test_group_value'
    assert data['test_host_var'] == 'test_host_value'

# Generated at 2022-06-17 16:17:32.661902
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    host = Host(name='localhost')
    group = Group(name='group')
    host.add_group(group)

    entities = [host, group]
    path = './test/units/plugins/vars/'

    data = get_vars_from_path(loader, path, entities, 'inventory')
    assert data

# Generated at 2022-06-17 16:17:39.975574
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugin'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test vars plugin
    plugin = vars_loader.get('test_vars_plugin')
    path = 'tests/inventory/test_inventory_vars_plugin'

# Generated at 2022-06-17 16:17:49.785326
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.plugins.vars import BaseVarsPlugin
    from ansible.utils.collection_loader import AnsibleCollectionRef
    from ansible.utils.vars import combine_vars
    import os

    class TestVarsPlugin(BaseVarsPlugin):
        def get_vars(self, loader, path, entities):
            return {'test_var': 'test_value'}

    vars_loader.add(TestVarsPlugin, 'test_vars')

    data = get_vars_from_path(None, os.path.dirname(__file__), [], 'inventory')
    assert data == {'test_var': 'test_value'}

    # Test that the plugin is not called if the stage is not correct
    data = get_vars

# Generated at 2022-06-17 16:18:01.576074
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager

    inventory = InventoryManager(loader=None, sources=['localhost,'])
    host = inventory.get_host('localhost')
    group = inventory.get_group('all')

    vars_plugin_list = list(vars_loader.all())
    for plugin in vars_plugin_list:
        if plugin._load_name not in C.VARIABLE_PLUGINS_ENABLED and getattr(plugin, 'REQUIRES_WHITELIST', False):
            # 2.x plugins shipped with ansible should require whitelisting, older or non shipped should load automatically
            continue


# Generated at 2022-06-17 16:18:07.471716
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars
    from ansible.utils.collection_loader import AnsibleCollectionRef

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # test get_vars_from_path with a host
    host = inventory.get_host('host1')
    data = get_vars_from_

# Generated at 2022-06-17 16:18:18.084662
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=["tests/inventory/test_inventory_vars_plugins"])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Get vars from path
    path = "tests/inventory/test_inventory_vars_plugins"
    entities = [Host(name="testhost")]
    data = get_vars_from_path(loader, path, entities, "inventory")

# Generated at 2022-06-17 16:18:25.997167
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin_base
    class TestVarsPlugin(vars_plugin_base):
        def get_vars(self, loader, path, entities):
            return {'test_key': 'test_value'}
    loader = vars_loader
    plugin = TestVarsPlugin()
    path = '/path/to/inventory'
    entities = ['test_entity']
    data = get_plugin_vars(loader, plugin, path, entities)
    assert data == {'test_key': 'test_value'}

# Generated at 2022-06-17 16:18:27.472820
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    assert get_vars_from_inventory_sources(None, [], [], 'inventory') == {}

# Generated at 2022-06-17 16:18:37.666684
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inv = InventoryManager(loader=loader, sources=["tests/inventory/test_inventory_manager/hosts"])
    host = inv.get_host("test_host")
    group = inv.get_group("test_group")

    vars_plugin_list = list(vars_loader.all())
    for plugin_name in C.VARIABLE_PLUGINS_ENABLED:
        if AnsibleCollectionRef.is_valid_fqcr(plugin_name):
            vars_plugin = vars_loader.get(plugin_name)

# Generated at 2022-06-17 16:18:49.493569
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    vars_plugin_list = list(vars_loader.all())
    for plugin in vars_plugin_list:
        if plugin._load_name not in C.VARIABLE_PLUGINS_ENABLED and getattr(plugin, 'REQUIRES_WHITELIST', False):
            # 2.x plugins shipped with ansible should require whitelisting, older or non shipped should load automatically
            continue

        has

# Generated at 2022-06-17 16:18:51.358670
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    # TODO: Write unit test for function get_plugin_vars
    pass


# Generated at 2022-06-17 16:18:59.037605
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_sources'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test with a host
    host = inventory.get_host('test_host')
    data = get_vars_from_inventory_sources(loader, inventory.sources, [host], 'inventory')
    assert data == {'test_host_var': 'test_host_value'}

    # Test with a group
    group = inventory.get_group('test_group')

# Generated at 2022-06-17 16:19:08.590983
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.plugins.vars import vars_plugins

    display = Display()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory'])

# Generated at 2022-06-17 16:19:18.764599
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.collection_loader import AnsibleCollectionRef
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # test vars_loader.all()
    vars_plugin_list = list(vars_loader.all())
    assert len(vars_plugin_list) == 0

    # test get_v

# Generated at 2022-06-17 16:19:30.378282
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.hostvars import HostVarsGroupVars
    from ansible.vars.hostvars import HostVarsAll
    from ansible.vars.hostvars import HostVarsAllGroupVars
    from ansible.vars.hostvars import HostVarsAllGroups
    from ansible.vars.hostvars import HostVarsAllGroupsAll
    from ansible.vars.hostvars import HostVarsAllGroupsAllVars

# Generated at 2022-06-17 16:19:40.957132
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test inventory vars plugins
    assert get_vars_from_inventory_sources(loader, inventory.sources, inventory.hosts.values(), 'inventory') == {'inventory_vars_plugin_var': 'inventory_vars_plugin_var_value'}

    # Test group vars plugins

# Generated at 2022-06-17 16:19:48.777805
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugin'])
    inv_manager.parse_sources()
    inv_manager.add_group('all')
    inv_manager.add_host(Host('testhost', groups=['all']))
    inv_manager.add_host(Host('testhost2', groups=['all']))
    inv_manager.add_host(Host('testhost3', groups=['all']))
    inv_manager.add_host(Host('testhost4', groups=['all']))

# Generated at 2022-06-17 16:19:59.308423
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugins

    class MockPlugin(object):
        def get_vars(self, loader, path, entities):
            return {'test': 'test'}

    class MockPlugin2(object):
        def get_host_vars(self, host):
            return {'test': 'test'}

    class MockPlugin3(object):
        def get_group_vars(self, group):
            return {'test': 'test'}

    class MockPlugin4(object):
        def run(self):
            pass

    class MockHost(object):
        def __init__(self, name):
            self.name = name

    class MockGroup(object):
        def __init__(self, name):
            self.name = name


# Generated at 2022-06-17 16:20:15.346631
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugin'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test with a host
    host = inventory.get_host('test_host')
    data = get_vars_from_path(loader, 'tests/inventory/test_inventory_vars_plugin', [host], 'inventory')

# Generated at 2022-06-17 16:20:24.739208
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    vars_plugin_list = list(vars_loader.all())
    for plugin_name in C.VARIABLE_PLUGINS_ENABLED:
        if AnsibleCollectionRef.is_valid_fqcr(plugin_name):
            vars_plugin = vars_loader.get(plugin_name)
            if vars_plugin is None:
                # Error if there's no play directory or the name is wrong?
                continue
            if vars_plugin not in vars_plugin_list:
                vars_plugin_list.append(vars_plugin)


# Generated at 2022-06-17 16:20:30.218345
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    host = inventory.get_host('host1')
    group = inventory.get_group('group1')

    data = get_vars_from_inventory_sources(loader, inventory.sources, [host, group], 'inventory')
    assert data == {'group_var': 'group1', 'host_var': 'host1', 'inventory_var': 'inventory'}

    data = get_vars_from_inventory_sources(loader, inventory.sources, [host, group], 'task')

# Generated at 2022-06-17 16:20:38.452460
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    sources = inventory.sources()
    entities = inventory.get_hosts() + inventory.get_groups()
    stage = 'inventory'
    data = get_vars_from_inventory_sources(loader, sources, entities, stage)
    assert data['test_inventory_vars_plugins_var'] == 'test_inventory_vars_plugins_var_value'
    assert data['test_inventory_vars_plugins_group_var'] == 'test_inventory_vars_plugins_group_var_value'

# Generated at 2022-06-17 16:20:50.530477
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources=['tests/inventory/test_inventory_vars_plugin'])
    variable_manager = VariableManager(loader=None, inventory=inventory)

    # Test get_vars_from_path
    vars_plugin_list = list(vars_loader.all())
    for plugin in vars_plugin_list:
        if plugin._load_name not in C.VARIABLE_PLUGINS_ENABLED and getattr(plugin, 'REQUIRES_WHITELIST', False):
            # 2.x plugins shipped with ansible should require whitelisting, older or non shipped should load automatically
            continue

        has_

# Generated at 2022-06-17 16:20:54.534316
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # test with no vars plugins
    C.VARIABLE_PLUGINS_ENABLED = []
    assert get_vars_from_inventory_sources(loader, inventory.sources(), inventory.get_hosts(), 'inventory') == {}

    # test with vars plugins
    C.VARIABLE_PLUGINS_ENABLED = ['vars_plugins/test_vars_plugin.py']
    assert get_

# Generated at 2022-06-17 16:21:03.082985
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test that the vars plugin is loaded
    assert 'test_vars_plugin' in C.VARIABLE_PLUGINS_ENABLED

    # Test that the vars plugin is loaded and returns the correct data

# Generated at 2022-06-17 16:21:11.648691
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test with a host
    host = inventory.get_host('localhost')
    hostvars = HostVars(host=host, variable_manager=variable_manager)
    assert get_vars_from_path(loader, './test/units/vars_plugins/', [hostvars], 'inventory') == {'test_host_vars': 'test_host_vars'}

    # Test with a group

# Generated at 2022-06-17 16:21:18.982421
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.plugins.vars import BaseVarsPlugin
    from ansible.utils.collection_loader import AnsibleCollectionRef

    class TestVarsPlugin(BaseVarsPlugin):
        def get_vars(self, loader, path, entities):
            return {'test_vars_plugin': 'test_vars_plugin'}

    vars_loader.add(TestVarsPlugin, 'test_vars_plugin')

    data = get_vars_from_path(None, '.', [], 'inventory')
    assert data == {'test_vars_plugin': 'test_vars_plugin'}

    vars_loader.remove(AnsibleCollectionRef.parse('test_vars_plugin'))

# Generated at 2022-06-17 16:21:28.919195
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['test/units/plugins/inventory/test_inventory.yml'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    host = inventory.get_host(Host('testhost'))
    group = inventory.get_group('testgroup')

    data = get_vars_from_path(loader, 'test/units/plugins/vars/', [host, group], 'inventory')
    assert data['test_var'] == 'test_value'


# Generated at 2022-06-17 16:21:38.365466
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugin'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # test get_vars_from_path
    host = Host(name='test_host')
    group = Group(name='test_group')
    entities = [host, group]
    vars_plugin_list = list(vars_loader.all())

# Generated at 2022-06-17 16:21:43.158900
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    inv = inv_manager.get_inventory()
    hosts = inv.get_hosts()
    groups = inv.get_groups()

    # Test inventory vars
    vars = get_vars_from_inventory_sources(loader, inv.sources, hosts, 'inventory')
    assert vars['test_inventory_var'] == 'test_inventory_var_value'

    # Test inventory group vars
    vars = get_vars_from_inventory_sources(loader, inv.sources, groups, 'inventory')

# Generated at 2022-06-17 16:21:53.490957
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test with a host
    host = inventory.get_host(hostname='localhost')
    data = get_vars_from_path(loader, './test/units/plugins/vars/', [host], 'inventory')
    assert data['test_host_var'] == 'test_host_var_value'

    # Test with

# Generated at 2022-06-17 16:22:02.023329
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugin'])
    inv_manager.parse_sources()
    inv = inv_manager.inventory
    inv.add_host(Host('testhost'))
    inv.add_group(inv.get_group('testgroup'))

    # Test with no plugins
    C.VARIABLE_PLUGINS_ENABLED = []
    C.RUN_VARS_PLUGINS = 'start'

# Generated at 2022-06-17 16:22:13.284086
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    class TestVarsPlugin(vars_plugin.VarsBase):
        def get_vars(self, loader, path, entities):
            return {'test_vars': 'test_vars'}

    class TestVarsPlugin2(vars_plugin.VarsBase):
        def get_host_vars(self, host):
            return {'test_host_vars': 'test_host_vars'}

        def get_group_vars(self, group):
            return {'test_group_vars': 'test_group_vars'}


# Generated at 2022-06-17 16:22:18.255563
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['test/inventory/test_inventory_vars_plugin'])
    host = inventory.get_host('test_host')
    group = inventory.get_group('test_group')
    data = get_vars_from_inventory_sources(loader, ['test/inventory/test_inventory_vars_plugin'], [host, group], 'inventory')
    assert data == {'test_host_vars': 'test_host_vars', 'test_group_vars': 'test_group_vars'}

# Generated at 2022-06-17 16:22:28.391826
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    host = inventory.get_host('test_host')
    group = inventory.get_group('test_group')
    data = get_vars_from_path(loader, 'tests/inventory/test_inventory_vars_plugins', [host, group], 'inventory')
    assert data == {'test_host': 'test_host', 'test_group': 'test_group'}

# Generated at 2022-06-17 16:22:39.293768
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugins
    from ansible.plugins.loader import vars_loader
    vars_loader.add(vars_plugins.VarsModule())
    vars_loader.add(vars_plugins.VarsModule())
    vars_loader.add(vars_plugins.VarsModule())
    vars_loader.add(vars_plugins.VarsModule())
    vars_loader.add(vars_plugins.VarsModule())
    vars_loader.add(vars_plugins.VarsModule())
    vars_loader.add(vars_plugins.VarsModule())
    vars_loader.add(vars_plugins.VarsModule())
    vars_loader.add(vars_plugins.VarsModule())

# Generated at 2022-06-17 16:22:50.664888
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['test/inventory/test_inventory_vars'])
    inventory.parse_inventory(inventory)

    # Test for host
    host = inventory.get_host('host1')
    assert host.vars == {'var1': 'value1'}

    # Test for group
    group = inventory.get_group('group1')
    assert group.vars == {'var2': 'value2'}

    # Test for inventory
    assert inventory.vars == {'var3': 'value3'}

# Generated at 2022-06-17 16:23:01.933190
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    host = inventory.get_host('test_host')
    group = inventory.get_group('test_group')
    entities = [host, group]
    path = 'tests/inventory/test_inventory_vars_plugins'
    stage = 'inventory'

    vars_plugin_list = list(vars_loader.all())

# Generated at 2022-06-17 16:23:17.456978
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory.yml'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # test for host
    host = inventory.get_host('host1')
    vars_from_path = get_vars_from_path(loader, 'tests/inventory/test_inventory.yml', [host], 'inventory')
    assert vars_from_path == {'test_var': 'test_value'}

    # test for group
    group = inventory.get_group('group1')
    vars_from_path = get

# Generated at 2022-06-17 16:23:27.621934
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test with vars_plugin_list empty
    vars_plugin_list = []
    path = 'test/test_vars_plugin'
    entities = [inventory.get_host('localhost')]
    stage = 'inventory'
    data = get_vars_from_path(loader, path, entities, stage)
    assert data == {}

    # Test with vars_plugin_list not empty
    vars_plugin

# Generated at 2022-06-17 16:23:36.246125
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host

    # Create a fake inventory
    inventory = InventoryManager(loader=None, sources=['localhost,'])
    inventory.add_group('test_group')
    inventory.add_host(Host(name='localhost', port=22))
    inventory.add_host(Host(name='localhost', port=22))
    inventory.add_child('test_group', 'localhost')
    inventory.add_child('test_group', 'localhost')

    # Create a fake loader
    class FakeLoader(object):
        def __init__(self):
            self.path_exists = True
            self.path_isdir = True
            self.path_isfile = True
            self.path_ex

# Generated at 2022-06-17 16:23:50.082547
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test with a v2 plugin
    plugin = vars_loader.get('test_vars_plugin')
    assert plugin is not None
    assert plugin.get_vars(loader, '.', [inventory.get_host('localhost')]) == {'test_vars_plugin': 'test_vars_plugin'}

    # Test with a v1 plugin

# Generated at 2022-06-17 16:24:02.339525
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    host = inventory.get_host('test_host')
    group = inventory.get_group('test_group')

    # test vars plugin
    plugin = vars_loader.get('test_vars_plugin')
    assert plugin is not None
    assert get_plugin_vars(loader, plugin, 'tests/inventory/test_inventory_vars_plugins', [host]) == {'test_host_var': 'test_host_var_value'}

# Generated at 2022-06-17 16:24:10.264888
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader

    class TestPlugin:
        def get_vars(self, loader, path, entities):
            return {'test_plugin': 'test_plugin'}

    vars_loader.add(TestPlugin(), 'test_plugin')

    loader = None
    path = '.'
    entities = []
    stage = 'inventory'
    data = get_vars_from_path(loader, path, entities, stage)
    assert data == {'test_plugin': 'test_plugin'}

# Generated at 2022-06-17 16:24:17.171595
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.plugins.vars import BaseVarsPlugin
    from ansible.plugins.vars.host_group import HostGroupVars
    from ansible.plugins.vars.host_group import GroupVars

# Generated at 2022-06-17 16:24:27.385904
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.group import Group
    from ansible.inventory.ini import InventoryParser
    from ansible.inventory.yaml import InventoryYAMLParser

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['test/unit/inventory/hosts'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    host = Host(name='testhost')
    group = Group(name='testgroup')

# Generated at 2022-06-17 16:24:38.349834
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['test/unit/inventory/test_inventory_vars_plugins'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    host = inventory.get_host('testhost')
    hostvars = HostVars(host, variable_manager)
    assert hostvars.get('test_var') == 'test_value'
    assert hostvars.get('test_var2') == 'test_value2'

# Generated at 2022-06-17 16:24:43.491843
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin_base
    class TestVarsPlugin(vars_plugin_base.VarsBase):
        def get_vars(self, loader, path, entities, cache=True):
            return {'test_vars_plugin': True}

    loader = None
    plugin = TestVarsPlugin()
    path = None
    entities = None
    assert get_plugin_vars(loader, plugin, path, entities) == {'test_vars_plugin': True}

# Generated at 2022-06-17 16:25:00.367229
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['test/unit/plugins/inventory/test_inventory_vars_plugins.yml'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # test get_vars_from_path
    host = Host(name='test_host')
    group = Group(name='test_group')

# Generated at 2022-06-17 16:25:11.101726
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test get_vars_from_path
    # Test with a host
    host = inventory.get_host('host1')

# Generated at 2022-06-17 16:25:22.229071
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory.yaml'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    host = Host(name='testhost')
    host.set_variable('ansible_connection', 'local')
    variable_manager.set_host_variable(host, 'ansible_connection', 'local')
    variable_manager.set_host_variable(host, 'ansible_python_interpreter', '/usr/bin/python')
   

# Generated at 2022-06-17 16:25:33.213016
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    host = Host(name='localhost')
    group = Group(name='group')
    assert get_vars_from_path(loader, '.', [host], 'inventory') == {}
    assert get_vars_from_path(loader, '.', [group], 'inventory') == {}
    assert get_vars_from_path

# Generated at 2022-06-17 16:25:44.740341
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    inv = inv_manager.get_inventory()
    variable_manager = VariableManager(loader=loader, inventory=inv)
    host = inv.get_host('test_inventory_vars_plugins')
    group = inv.get_group('group1')
    data = get_vars_from_path(loader, 'tests/inventory/test_inventory_vars_plugins', [host, group], 'inventory')

# Generated at 2022-06-17 16:25:56.226098
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    vars_plugin_list = list(vars_loader.all())
    for plugin in vars_plugin_list:
        if plugin._load_name not in C.VARIABLE_PLUGINS_ENABLED and getattr(plugin, 'REQUIRES_WHITELIST', False):
            # 2.x plugins shipped with ansible should require whitelisting, older or non shipped should load automatically
            continue

# Generated at 2022-06-17 16:26:03.473900
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    host = inventory.get_host('test_host')
    group = inventory.get_group('test_group')
    data = get_vars_from_path(loader, 'tests/inventory/test_inventory_vars_plugins', [host, group], 'inventory')
    assert data['test_host_var'] == 'test_host_var_value'
    assert data['test_group_var'] == 'test_group_var_value'

# Generated at 2022-06-17 16:26:05.255053
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # TODO: write unit test
    pass

# Generated at 2022-06-17 16:26:09.737798
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.groupvars import GroupVars
    from ansible.vars.hostvars import HostVarsFile
    from ansible.vars.groupvars import GroupVarsFile
    from ansible.vars.hostvars import HostVarsDir
    from ansible.vars.groupvars import GroupVarsDir
    from ansible.vars.hostvars import HostVarsAll
    from ansible.vars.groupvars import GroupVarsAll

    loader = DataLoader()

# Generated at 2022-06-17 16:26:20.243756
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    host = inventory.get_host('localhost')

    # Test with a v2 plugin
    vars_plugin = vars_loader.get('test_vars_plugin_v2')
    data = get_vars_from_path(loader, '.', [host], 'inventory')
    assert data['test_vars_plugin_v2_inventory'] == 'inventory'

    # Test with a v1 plugin
    vars_plugin = vars_loader.get('test_vars_plugin_v1')
    data = get_vars_from

# Generated at 2022-06-17 16:26:34.175798
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test get_vars_from_path
    # Test with a host
    host = inventory.get_host('host1')

# Generated at 2022-06-17 16:26:44.062636
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.source import InventorySource
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    host = Host(name='localhost')
    group = Group(name='group')
    inventory.add_host(host)
    inventory.add_group(group)

    # test vars plugin

# Generated at 2022-06-17 16:26:51.108898
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test with a host
    host = Host(name="localhost")
    host.vars = {'test': 'test'}
    inventory.add_host(host)
    inventory.add_group('test')
    inventory.add_child('test', host)

# Generated at 2022-06-17 16:26:59.106318
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.collection_loader import AnsibleCollectionRef

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/unit/inventory/test_inventory_vars_plugins'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test get_vars_from_path with a host
    host = inventory.get_host(Host('testhost'))