

# Generated at 2022-06-17 16:17:16.777654
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin_base
    class TestVarsPlugin(vars_plugin_base):
        def get_vars(self, loader, path, entities):
            return {'test_key': 'test_value'}

    loader = None
    plugin = TestVarsPlugin()
    path = None
    entities = None
    assert get_plugin_vars(loader, plugin, path, entities) == {'test_key': 'test_value'}

# Generated at 2022-06-17 16:17:20.533504
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars.test import TestVarsPlugin
    loader = None
    plugin = TestVarsPlugin()
    path = '.'
    entities = ['test']
    data = get_plugin_vars(loader, plugin, path, entities)
    assert data == {'test': 'test'}

# Generated at 2022-06-17 16:17:29.214494
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager

    loader = vars_loader
    path = './test/integration/inventory_vars_plugins'
    entities = [Host('host1'), Group('group1')]
    stage = 'inventory'

    data = get_vars_from_path(loader, path, entities, stage)
    assert data == {'host1': {'host_var': 'host1_var'}, 'group1': {'group_var': 'group1_var'}}



# Generated at 2022-06-17 16:17:35.554236
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.hostvars import HostVars
    from ansible.vars.groupvars import GroupVars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # create a host
    host = Host(name="testhost")
    host.set_variable('ansible_connection', 'local')

# Generated at 2022-06-17 16:17:47.926412
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    plugin_name = 'test_vars_plugin'
    plugin_path = 'test/units/plugins/vars/' + plugin_name + '.py'
    vars_loader.add(plugin_name, plugin_path)

    path = 'test/units/plugins/vars'
    entities = [inventory.get_host('localhost')]
    stage = 'inventory'

    data = get_vars_from_path

# Generated at 2022-06-17 16:17:52.373965
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.utils.collection_loader import AnsibleCollectionRef
    from ansible.utils.vars import combine_vars

    vars_plugin_list = list(vars_loader.all())
    for plugin_name in C.VARIABLE_PLUGINS_ENABLED:
        if AnsibleCollectionRef.is_valid_fqcr(plugin_name):
            vars_plugin = vars_loader.get(plugin_name)
            if vars_plugin is None:
                # Error if there's no play directory or the name is wrong?
                continue
            if vars_plugin not in vars_plugin_list:
                vars_plugin_list.append(vars_plugin)


# Generated at 2022-06-17 16:18:03.700128
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # test with a v2 plugin
    plugin = vars_loader.get('vars_plugin_test')
    path = './test/units/plugins/vars/vars_plugin_test'
    entities = [inventory.get_host('localhost')]
    data = get_vars_from_path(loader, path, entities, 'inventory')
    assert data == {'test_var': 'test_value'}



# Generated at 2022-06-17 16:18:15.822973
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager

    inventory = InventoryManager(loader=None, sources=['localhost,'])
    host = Host(name='localhost')
    group = Group(name='group')
    entities = [host, group]

    vars_plugin_list = list(vars_loader.all())
    for plugin in vars_plugin_list:
        if plugin._load_name not in C.VARIABLE_PLUGINS_ENABLED and getattr(plugin, 'REQUIRES_WHITELIST', False):
            # 2.x plugins shipped with ansible should require whitelisting, older or non shipped should load automatically
            continue


# Generated at 2022-06-17 16:18:26.198562
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # test with a host
    host = Host(name='localhost')
    inventory.add_host(host)
    vars_from_path = get_vars_from_path(loader, '.', [host], 'inventory')
    assert vars_from_path == {}

    # test with a group

# Generated at 2022-06-17 16:18:32.845200
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin_base
    class TestPlugin(vars_plugin_base):
        def get_vars(self, loader, path, entities):
            return {'test_key': 'test_value'}
    loader = None
    plugin = TestPlugin()
    path = None
    entities = None
    assert get_plugin_vars(loader, plugin, path, entities) == {'test_key': 'test_value'}

# Generated at 2022-06-17 16:18:49.332903
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    host = Host(name='localhost')
    inventory.add_host(host)

    vars_plugin_list = list(vars_loader.all())
    for plugin in vars_plugin_list:
        if plugin._load_name not in C.VARIABLE_PLUGINS_ENABLED and getattr(plugin, 'REQUIRES_WHITELIST', False):
            # 2.x plugins shipped with ansible should require whitelisting, older or non shipped should load automatically
            continue

       

# Generated at 2022-06-17 16:18:55.473238
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin
    from ansible.plugins.loader import vars_loader

    class MyVarsPlugin(vars_plugin.VarsBase):
        def get_vars(self, loader, path, entities):
            return {'foo': 'bar'}

    vars_loader.add(MyVarsPlugin, 'myvars')
    data = get_plugin_vars(vars_loader, MyVarsPlugin(), '', [])
    assert data == {'foo': 'bar'}

# Generated at 2022-06-17 16:19:06.149639
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test with a vars plugin that does not support the v2 API
    vars_plugin = vars_loader.get('vars_plugin_v1')
    data = get_vars_from_path(loader, './', [inventory.get_host('localhost')], 'inventory')
    assert data == {}

    # Test with a vars plugin that supports the v2 API

# Generated at 2022-06-17 16:19:16.020438
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['test/inventory/test_inventory_vars_plugins'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test get_vars_from_inventory_sources with a host
    host = Host(name='testhost')
    host.vars = {'test_var': 'test_value'}
    data = get_vars_from_inventory_sources(loader, inventory.sources, [host], 'inventory')

# Generated at 2022-06-17 16:19:21.865739
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin_base
    class vars_plugin(vars_plugin_base):
        def get_vars(self, loader, path, entities):
            return {'test_key': 'test_value'}

    loader = None
    plugin = vars_plugin()
    path = None
    entities = None
    assert get_plugin_vars(loader, plugin, path, entities) == {'test_key': 'test_value'}


# Generated at 2022-06-17 16:19:33.350948
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    host = inventory.get_host('localhost')

    vars_plugin_list = list(vars_loader.all())
    for plugin in vars_plugin_list:
        if plugin._load_name not in C.VARIABLE_PLUGINS_ENABLED and getattr(plugin, 'REQUIRES_WHITELIST', False):
            # 2.x plugins shipped with ansible should require whitelisting, older or non shipped should load automatically
            continue

        has_stage = hasattr(plugin, 'get_option') and plugin.has_

# Generated at 2022-06-17 16:19:42.709963
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    host = inventory.get_host('test_host')
    group = inventory.get_group('test_group')
    data = get_vars_from_path(loader, 'tests/inventory/test_inventory_vars_plugins', [host, group], 'inventory')

# Generated at 2022-06-17 16:19:52.371171
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.vars.plugins.vars import VarsModule

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    vars_plugin_list = list(vars_loader.all())
    vars_plugin_list.append(VarsModule())
    vars_loader.set_all(vars_plugin_list)

    path = './test/integration/vars_plugins/'
    entities = [inventory.get_host('localhost')]
    stage = 'inventory'
    data = get_vars_from_

# Generated at 2022-06-17 16:20:02.335193
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    host = Host(name='localhost')
    group = Group(name='group')
    entities = [host, group]
    path = './'
    stage = 'inventory'
    data = get_vars_from_path(loader, path, entities, stage)
    assert data == {}

# Generated at 2022-06-17 16:20:08.039696
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin_base

    class TestVarsPlugin(vars_plugin_base):
        def get_vars(self, loader, path, entities):
            return {'test': 'test'}

    loader = None
    plugin = TestVarsPlugin()
    path = '/path/to/somewhere'
    entities = [Host('testhost')]
    assert get_plugin_vars(loader, plugin, path, entities) == {'test': 'test'}

    class TestVarsPlugin(vars_plugin_base):
        def get_host_vars(self, host):
            return {'test': 'test'}

    loader = None
    plugin = TestVarsPlugin()
    path = '/path/to/somewhere'

# Generated at 2022-06-17 16:20:24.356863
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['test/inventory'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test with a host
    host = Host(name="testhost")
    data = get_vars_from_path(loader, 'test/inventory', [host], 'inventory')
    assert data == {'test_var': 'test_value'}

    # Test with a group
    group = Group(name="testgroup")

# Generated at 2022-06-17 16:20:35.728453
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugins

    class FakePlugin:
        def get_vars(self, loader, path, entities):
            return {'foo': 'bar'}

    class FakePlugin2:
        def get_host_vars(self, host):
            return {'foo': 'bar'}

        def get_group_vars(self, group):
            return {'foo': 'bar'}

    class FakePlugin3:
        def run(self):
            pass

    class FakeHost:
        def __init__(self, name):
            self.name = name

    class FakeGroup:
        def __init__(self, name):
            self.name = name

    fake_plugin = FakePlugin()
    fake_plugin2 = FakePlugin2()
    fake_plugin3 = FakePlugin3

# Generated at 2022-06-17 16:20:49.632310
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugin'])
    host = inventory.get_host('test_host_1')
    group = inventory.get_group('test_group_1')
    data = get_vars_from_path(loader, 'tests/inventory/test_inventory_vars_plugin', [host, group], 'inventory')

# Generated at 2022-06-17 16:20:59.126394
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition

# Generated at 2022-06-17 16:21:07.780598
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    host = Host(name='localhost')
    host.vars = get_vars_from_path(loader, 'localhost,', [host], 'inventory')
    variable_manager.set_host_variable(host, host.vars)

# Generated at 2022-06-17 16:21:13.245039
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    host = inventory.get_host('localhost')
    path = os.path.dirname(__file__)
    data = get_vars_from_path(loader, path, [host], 'inventory')
    assert data['test_var'] == 'test_value'

# Generated at 2022-06-17 16:21:14.232377
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # TODO: Add unit tests for this function
    pass

# Generated at 2022-06-17 16:21:26.020898
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_manager'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test with a host
    host = inventory.get_host('test_host')
    data = get_vars_from_path(loader, 'tests/inventory/test_inventory_manager', [host], 'inventory')
    assert data['test_var'] == 'test_host'

    # Test with a group
    group = inventory.get_group('test_group')

# Generated at 2022-06-17 16:21:34.447210
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.source import InventorySource

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    host = Host(name='localhost')
    group = Group(name='group')
    inventory.add_host(host)
    inventory.add_group(group)

    # test vars plugins
    vars_plugin_list = list(vars_loader.all())

# Generated at 2022-06-17 16:21:48.296645
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test get_vars_from_path with a file
    path = 'tests/inventory/test_inventory_vars/group_vars/all'
    entities = [inventory.get_group('all')]
    data = get_vars_from_path(loader, path, entities, 'inventory')

# Generated at 2022-06-17 16:22:01.844645
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test with stage=inventory
    data = get_vars_from_inventory_sources(loader, inventory.sources(), inventory.hosts, 'inventory')
    assert data == {'test_inventory_vars_plugins': 'inventory'}

    # Test with stage=task
    data = get_vars_from_inventory_sources(loader, inventory.sources(), inventory.hosts, 'task')

# Generated at 2022-06-17 16:22:10.151379
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    host = inventory.get_host('test_host')
    group = inventory.get_group('test_group')
    data = get_vars_from_path(loader, 'tests/inventory/test_inventory_vars_plugins', [host, group], 'inventory')
    assert data == {'test_host_var': 'test_host_var_value', 'test_group_var': 'test_group_var_value'}

# Generated at 2022-06-17 16:22:20.875973
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import vars_loader
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import strategy_loader

# Generated at 2022-06-17 16:22:31.407921
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    host = inventory.get_host('test_host')
    group = inventory.get_group('test_group')
    entities = [host, group]
    vars_plugin_list = list(vars_loader.all())

# Generated at 2022-06-17 16:22:40.604318
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.utils.vars import combine_vars
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    host = Host(name='localhost')
    host.set_variable('foo', 'bar')
    inventory.add_host(host)
    group = inventory.get_group('all')
    group.set_variable('foo', 'baz')

    # test with a vars plugin that does not support v2
    vars_plugin = vars_loader.get('vars_plugin_v1')
    data = get_vars_from_

# Generated at 2022-06-17 16:22:48.821748
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin_base

    class TestVarsPlugin(vars_plugin_base):
        def get_vars(self, loader, path, entities):
            return {'test_key': 'test_value'}

    loader = None
    plugin = TestVarsPlugin()
    path = None
    entities = None
    assert get_plugin_vars(loader, plugin, path, entities) == {'test_key': 'test_value'}

# Generated at 2022-06-17 16:22:53.968994
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    vars_plugin_list = list(vars_loader.all())
    for plugin in vars_plugin_list:
        if plugin._load_name not in C.VARIABLE_PLUGINS_ENABLED and getattr(plugin, 'REQUIRES_WHITELIST', False):
            # 2.x plugins shipped with ansible should require whitelisting, older or non shipped should load automatically
            continue
        has

# Generated at 2022-06-17 16:23:03.136058
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # test vars_plugins
    vars_plugins = vars_loader.all()
    for vars_plugin in vars_plugins:
        vars_plugin.get_vars(loader, '.', [])

    # test get_vars_from_path
    get_vars_from_path(loader, '.', [], 'inventory')

# Generated at 2022-06-17 16:23:14.419303
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    vars_loader.add_directory(os.path.join(os.path.dirname(__file__), 'vars_plugins'))

    # test get_vars_from_path
    vars_from_path = get_vars_from_path(loader, './', [inventory.get_host('localhost')], 'inventory')

# Generated at 2022-06-17 16:23:18.716398
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    inventory.parse_inventory(inventory)
    assert get_vars_from_inventory_sources(loader, ['tests/inventory/test_inventory_vars_plugins'], [inventory.groups['all']], 'inventory') == {'test_var': 'test_value'}

# Generated at 2022-06-17 16:23:36.580819
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    vars_plugin_list = list(vars_loader.all())
    for plugin in vars_plugin_list:
        if plugin._load_name not in C.VARIABLE_PLUGINS_ENABLED and getattr(plugin, 'REQUIRES_WHITELIST', False):
            # 2.x plugins shipped with ansible should require whitelisting, older or non shipped should load automatically
            continue


# Generated at 2022-06-17 16:23:50.413462
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test with a v2 plugin
    vars_plugin = vars_loader.get('test_vars_plugin')
    data = get_plugin_vars(loader, vars_plugin, '.', [inventory.get_host('localhost')])
    assert data['test_vars_plugin_key'] == 'test_vars_plugin_value'

    # Test with a v1 plugin
    vars_plugin = v

# Generated at 2022-06-17 16:24:02.403061
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.groupvars import GroupVars
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.unsafe_proxy import wrap_var

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    host = Host('localhost')

# Generated at 2022-06-17 16:24:06.636685
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    loader = None
    path = 'test_path'
    entities = ['test_entity']
    stage = 'test_stage'
    assert get_vars_from_path(loader, path, entities, stage) == {}

# Generated at 2022-06-17 16:24:09.486619
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    assert get_vars_from_inventory_sources(None, ['test/test_data/inventory_sources'], [], 'inventory') == {'test_var': 'test_value'}

# Generated at 2022-06-17 16:24:16.756585
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin
    class TestPlugin(vars_plugin.VarsBase):
        def get_vars(self, loader, path, entities):
            return {'test_plugin': 'test_plugin'}

    class TestPlugin2(vars_plugin.VarsBase):
        def get_host_vars(self, host):
            return {'test_plugin2': 'test_plugin2'}

    class TestPlugin3(vars_plugin.VarsBase):
        def get_group_vars(self, group):
            return {'test_plugin3': 'test_plugin3'}

    class TestPlugin4(vars_plugin.VarsBase):
        def run(self):
            return {'test_plugin4': 'test_plugin4'}


# Generated at 2022-06-17 16:24:27.214167
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugin'])
    inv = inv_manager.get_inventory()
    variable_manager = VariableManager(loader=loader, inventory=inv)
    vars_plugin_list = list(vars_loader.all())

# Generated at 2022-06-17 16:24:38.348134
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugins

    class FakePlugin:
        def __init__(self, name):
            self._load_name = name

        def get_vars(self, loader, path, entities):
            return {self._load_name: True}

    class FakePlugin2:
        def __init__(self, name):
            self._load_name = name

        def get_host_vars(self, host):
            return {self._load_name: True}

        def get_group_vars(self, group):
            return {self._load_name: True}

    class FakePlugin3:
        def __init__(self, name):
            self._load_name = name


# Generated at 2022-06-17 16:24:45.970062
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    vars_plugin_list = list(vars_loader.all())
    for plugin in vars_plugin_list:
        if plugin._load_name not in C.VARIABLE_PLUGINS_ENABLED and getattr(plugin, 'REQUIRES_WHITELIST', False):
            # 2.x plugins shipped with ansible should require whitelisting, older or non shipped should load automatically
            continue

        has

# Generated at 2022-06-17 16:24:51.887894
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.hostvars import HostVars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    host = Host(name='testhost')
    group = Group(name='testgroup')
    hostvars = HostVars(host=host, variables={'testvar': 'testvalue'})
    variable_manager.set

# Generated at 2022-06-17 16:25:11.484007
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.utils.collection_loader import AnsibleCollectionRef
    from ansible.plugins.vars import BaseVarsPlugin
    from ansible.plugins.vars.host_group import HostGroupVars

# Generated at 2022-06-17 16:25:22.464929
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    host = Host(name='foobar')
    variable_manager.set_host_variable(host, 'ansible_connection', 'local')
    variable_manager.set_host_variable(host, 'ansible_python_interpreter', '/usr/bin/python')

# Generated at 2022-06-17 16:25:33.396936
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.play_context import PlayContext

# Generated at 2022-06-17 16:25:44.816673
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.vars.plugins.vars import VarsModule

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    variable_manager._vars_plugins = [VarsModule()]

    # Test with a single host
    host = inventory.get_host('localhost')
    vars = get_vars_from_path(loader, '.', [host], 'inventory')
    assert vars == {'inventory_dir': '.', 'inventory_file': 'localhost,'}

    # Test with a single group

# Generated at 2022-06-17 16:25:56.262168
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugin'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test get_vars_from_path with a host
    host = inventory.get_host('host1')
    assert host is not None
    assert isinstance(host, Host)
    vars_plugin_list = list(vars_loader.all())
    assert len(vars_plugin_list) == 1

# Generated at 2022-06-17 16:26:03.474247
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_manager'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test get_vars_from_path
    path = 'tests/inventory/test_inventory_manager'
    entities = [inventory.get_group('group1'), inventory.get_group('group2')]
    stage = 'inventory'
    data = get_vars_from_path(loader, path, entities, stage)

# Generated at 2022-06-17 16:26:13.881052
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_source = dict(
        name="Ansible Play",
        hosts='localhost',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='debug', args=dict(msg='{{test_var}}')))
        ]
    )
    play = Play

# Generated at 2022-06-17 16:26:20.569256
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    vars_loader.add_directory(os.path.join(os.path.dirname(__file__), 'vars_plugins'))
    vars_loader.all()
    plugin = vars_loader.get('test_vars_plugin')
    assert plugin is not None
    assert plugin.get_vars(None, None, None) == {'test_vars_plugin': 'test_vars_plugin'}

# Generated at 2022-06-17 16:26:27.528536
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    vars_plugin_list = list(vars_loader.all())
    for plugin in vars_plugin_list:
        if plugin._load_name not in C.VARIABLE_PLUGINS_ENABLED and getattr(plugin, 'REQUIRES_WHITELIST', False):
            # 2.x plugins shipped with ansible should require whitelisting, older or non shipped should load automatically
            continue

# Generated at 2022-06-17 16:26:37.767367
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.source import InventorySource
    from ansible.utils.collection_loader import AnsibleCollectionRef

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Create a host
    host = Host(name="test_host")
    host.set_variable('ansible_host', '127.0.0.1')

# Generated at 2022-06-17 16:27:01.076291
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.groupvars import GroupVars
    from ansible.vars.hostvars import HostVarsFile
    from ansible.vars.groupvars import GroupVarsFile
    from ansible.plugins.vars import BaseVarsPlugin
    from ansible.plugins.vars import HostVarsModule
    from ansible.plugins.vars import GroupVarsModule
    from ansible.plugins.vars import HostVarsFile as HostVarsFilePlugin
    from ansible.plugins.vars import GroupVarsFile as GroupVarsFilePlugin
