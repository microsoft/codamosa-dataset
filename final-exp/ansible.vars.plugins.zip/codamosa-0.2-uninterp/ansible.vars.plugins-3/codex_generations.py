

# Generated at 2022-06-17 16:17:13.810601
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test with stage=inventory
    vars_from_inventory_sources = get_vars_from_inventory_sources(loader, inventory.sources, inventory.hosts, 'inventory')
    assert vars_from_inventory_sources == {'test_inventory_vars_plugins': 'inventory'}

    # Test with stage=task
    vars_from_inventory_sources = get_vars_from_inventory_sources

# Generated at 2022-06-17 16:17:23.872133
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['test/inventory'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-17 16:17:32.597229
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugins

    class TestVarsPlugin:
        def get_vars(self, loader, path, entities):
            return {'test_vars_plugin': True}

    class TestVarsPlugin2:
        def get_host_vars(self, host):
            return {'test_vars_plugin2': True}

    class TestVarsPlugin3:
        def get_group_vars(self, group):
            return {'test_vars_plugin3': True}

    class TestVarsPlugin4:
        def run(self, host, vault_password=None):
            return {'test_vars_plugin4': True}


# Generated at 2022-06-17 16:17:45.427142
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.plugins.vars import BaseVarsPlugin

    class TestVarsPlugin(BaseVarsPlugin):
        def get_vars(self, loader, path, entities):
            return {'test_vars_plugin': 'test_vars_plugin'}

    vars_loader.add('test_vars_plugin', TestVarsPlugin)

    assert get_vars_from_path(None, None, None, None) == {}
    assert get_vars_from_path(None, None, None, None) == {}
    assert get_vars_from_path(None, 'test_path', None, None) == {'test_vars_plugin': 'test_vars_plugin'}

# Generated at 2022-06-17 16:17:53.213105
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    host = Host(name='localhost')
    group = Group(name='group')
    path = '.'
    stage = 'inventory'
    entities = [host, group]
    data = get_vars_from_path(loader, path, entities, stage)
    assert data == {}

# Generated at 2022-06-17 16:17:54.132887
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # TODO: write unit test
    pass

# Generated at 2022-06-17 16:18:01.094512
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin_base
    class TestVarsPlugin(vars_plugin_base):
        def get_vars(self, loader, path, entities):
            return {'test_key': 'test_value'}
    loader = vars_loader.get('TestVarsPlugin')
    assert get_plugin_vars(loader, loader, '', []) == {'test_key': 'test_value'}

# Generated at 2022-06-17 16:18:07.587513
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.plugins.loader import action_loader

# Generated at 2022-06-17 16:18:15.613828
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    loader = vars_loader
    path = './test/integration/inventory/'
    entities = InventoryManager(loader=loader, sources=path).get_hosts()
    stage = 'inventory'
    data = get_vars_from_path(loader, path, entities, stage)
    assert data['test_var'] == 'test_value'

# Generated at 2022-06-17 16:18:25.873602
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.source import InventorySource
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.hostvars import HostVarsGroup
    from ansible.vars.hostvars import HostVarsIncludeVars
    from ansible.vars.hostvars import HostVarsIncludeVarsVars

# Generated at 2022-06-17 16:18:35.805036
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    group = inventory.groups['all']
    host = inventory.get_host('testhost')

    # Test v2 plugin
    plugin = vars_loader.get('test_vars_plugin')
    assert plugin is not None

# Generated at 2022-06-17 16:18:48.355854
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    vars_plugin_list = list(vars_loader.all())
    for plugin in vars_plugin_list:
        if plugin._load_name not in C.VARIABLE_PLUGINS_ENABLED and getattr(plugin, 'REQUIRES_WHITELIST', False):
            # 2.x plugins shipped with ansible should require whitelisting, older or non shipped should load automatically
            continue

        has

# Generated at 2022-06-17 16:18:56.982644
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.collection_loader import AnsibleCollectionRef

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugin'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test the vars plugin
    plugin = vars_loader.get('test_vars_plugin')
    assert plugin is not None

# Generated at 2022-06-17 16:19:07.704445
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    inventory.parse_inventory(inventory)

    # Test with stage=inventory
    data = get_vars_from_inventory_sources(loader, inventory.sources, inventory.hosts.values(), 'inventory')
    assert data == {'inventory_var': 'inventory_var_value'}

    # Test with stage=task
    data = get_vars_from_inventory_sources(loader, inventory.sources, inventory.hosts.values(), 'task')

# Generated at 2022-06-17 16:19:17.784699
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_manager'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    path = 'tests/inventory/test_inventory_manager'
    entities = [inventory.get_host('host1'), inventory.get_group('group1')]
    stage = 'inventory'
    data = get_vars_from_path(loader, path, entities, stage)
    assert data == {'group1': {'group1_var': 'group1_value'}, 'host1': {'host1_var': 'host1_value'}}

# Generated at 2022-06-17 16:19:25.442460
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugins
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugin'])
    plugin = vars_plugins.VarsModule()
    plugin._load_name = 'vars'
    plugin._original_path = 'ansible/plugins/vars/vars.py'
    path = 'tests/inventory/test_inventory_vars_plugin'
    entities = inventory.get_hosts() + inventory.get_groups()
    data = get_plugin_vars(loader, plugin, path, entities)

# Generated at 2022-06-17 16:19:35.692633
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    host = inventory.get_host('test_host')
    group = inventory.get_group('test_group')
    data = get_vars_from_path(loader, 'tests/inventory/test_inventory_vars_plugins', [host, group], 'inventory')

# Generated at 2022-06-17 16:19:49.389593
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    host = Host(name='localhost')
    group = Group(name='group')
    path = '/etc/ansible'

    # Test with a vars plugin that has get_vars method
    plugin = vars_loader.get('vars_plugin_test')

# Generated at 2022-06-17 16:19:59.560010
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.groupvars import GroupVars
    from ansible.vars.hostvars import HostVarsFile
    from ansible.vars.groupvars import GroupVarsFile
    from ansible.vars.hostvars import HostVarsVault
    from ansible.vars.groupvars import GroupVarsVault
    from ansible.vars.hostvars import HostVarsYaml
    from ansible.vars.groupvars import GroupVarsYaml
    from ansible.vars.hostvars import HostVarsJson
   

# Generated at 2022-06-17 16:20:06.446624
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    vars_plugin_list = list(vars_loader.all())
    for plugin in vars_plugin_list:
        if plugin._load_name not in C.VARIABLE_PLUGINS_ENABLED and getattr(plugin, 'REQUIRES_WHITELIST', False):
            # 2.x plugins shipped with ansible should require whitelisting, older or non shipped should load automatically
            continue

# Generated at 2022-06-17 16:20:20.051395
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test with a host
    host = inventory.get_host("testhost")
    data = get_vars_from_path(loader, 'tests/inventory/test_inventory_vars_plugins', [host], 'inventory')
    assert data == {'testhost_var': 'testhost_value'}

    # Test with a group

# Generated at 2022-06-17 16:20:27.820529
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.collection_loader import AnsibleCollectionRef
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.errors import AnsibleError

    display = Display()

    # Create a fake inventory
    inventory = InventoryManager(loader=DataLoader(), sources=['localhost,'])
    host = Host(name='localhost')
    group = Group(name='all')
    group.add_host(host)

# Generated at 2022-06-17 16:20:35.160535
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugins
    plugin = vars_plugins.get('yaml')
    loader = None
    path = 'test/test_vars_plugins/yaml_vars_plugin'
    entities = ['test_host']
    data = get_plugin_vars(loader, plugin, path, entities)
    assert data == {'test_host': {'test_var': 'test_value'}}

# Generated at 2022-06-17 16:20:49.463271
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    host = inventory.get_host('localhost')

    # Test with a vars plugin that has a get_vars method
    plugin = vars_loader.get('test_vars_plugin')
    data = get_plugin_vars(loader, plugin, '.', [host])
    assert data == {'test_vars_plugin': 'test_vars_plugin'}

    # Test with a vars plugin that has a get_host_vars method
    plugin = vars_loader.get('test_vars_plugin_2')
    data

# Generated at 2022-06-17 16:20:58.968117
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.utils.collection_loader import AnsibleCollectionRef

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    host = Host(name='localhost')
    group = Group(name='group')
    entities = [host, group]

    # test vars plugin
    vars_plugin_list = list(vars_loader.all())

# Generated at 2022-06-17 16:21:03.560015
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin_base
    class TestPlugin(vars_plugin_base):
        def get_vars(self, loader, path, entities):
            return {'test': 'test'}

    loader = None
    plugin = TestPlugin()
    path = 'path'
    entities = ['entity']
    assert get_plugin_vars(loader, plugin, path, entities) == {'test': 'test'}

# Generated at 2022-06-17 16:21:12.110804
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    host = Host(name='localhost')
    group = Group(name='group')
    assert get_vars_from_path(loader, './', [host], 'inventory') == {}
    assert get_vars_from_path(loader, './', [group], 'inventory') == {}
    assert get_vars_from_path

# Generated at 2022-06-17 16:21:19.457867
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test with a host
    host = inventory.get_host('host1')
    assert host.name == 'host1'
    assert host.vars == {}

    # Test with a group
    group = inventory.get_

# Generated at 2022-06-17 16:21:21.047495
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert get_vars_from_path(None, None, None, None) == {}

# Generated at 2022-06-17 16:21:31.480145
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader

    vars_plugin_list = list(vars_loader.all())
    for plugin_name in C.VARIABLE_PLUGINS_ENABLED:
        if AnsibleCollectionRef.is_valid_fqcr(plugin_name):
            vars_plugin = vars_loader.get(plugin_name)
            if vars_plugin is None:
                # Error if there's no play directory or the name is wrong?
                continue
            if vars_plugin not in vars_plugin_list:
                vars_plugin_list.append(vars_plugin)


# Generated at 2022-06-17 16:21:49.446716
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['/etc/ansible/hosts'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    host = inventory.get_host('localhost')
    group = inventory.get_group('all')

    # Test with a v2 plugin
    plugin = vars_loader.get('yaml')
    path = '/etc/ansible/host_vars/localhost'

# Generated at 2022-06-17 16:21:57.126258
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugin'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # test for host
    host = inventory.get_host('host1')
    assert get_vars_from_path(loader, 'tests/inventory/test_inventory_vars_plugin', [host], 'inventory') == {'test_vars_plugin_var': 'test_vars_plugin_value'}

    # test for group
    group = inventory.get_group('group1')
    assert get_vars_from_path

# Generated at 2022-06-17 16:22:02.641446
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.utils.path import unfrackpath
    from ansible.plugins.loader import vars_loader
    from ansible.plugins.vars import BaseVarsPlugin

# Generated at 2022-06-17 16:22:10.659334
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugin'])
    inventory.parse_inventory(inventory.sources)
    assert get_vars_from_inventory_sources(loader, inventory.sources, inventory.hosts.values(), 'inventory') == {'test_inventory_vars_plugin': 'test_inventory_vars_plugin'}

# Generated at 2022-06-17 16:22:21.231542
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    host = inventory.get_host('testhost')
    group = inventory.get_group('testgroup')
    entities = [host, group]

    vars_plugin_list = list(vars_loader.all())

# Generated at 2022-06-17 16:22:31.752368
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugin'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    inventory.parse_sources()

    # test for host
    host = inventory.get_host('host1')
    assert get_vars_from_inventory_sources(loader, inventory.sources, [host], 'inventory') == {'vars_plugin_test_var': 'host1'}

    # test for group
    group = inventory.get_group('group1')
    assert get_vars_from_inventory_sources

# Generated at 2022-06-17 16:22:40.792585
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test get_vars_from_inventory_sources with stage='inventory'
    # Test with a single host
    host = inventory.get_host('host1')
    vars_from_inventory_sources = get_vars_from_inventory_sources(loader, inventory.sources, [host], 'inventory')

# Generated at 2022-06-17 16:22:51.955411
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    inventory.parse_inventory(inventory)

    # test with stage = 'inventory'
    data = get_vars_from_inventory_sources(loader, inventory.sources, inventory.hosts.values(), 'inventory')
    assert data == {'inventory_vars_plugin_test': 'inventory_vars_plugin_test'}

    # test with stage = 'task'
    data = get_vars_from_inventory_sources(loader, inventory.sources, inventory.hosts.values(), 'task')

# Generated at 2022-06-17 16:23:01.863166
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = vars_loader
    path = './test/integration/inventory/host_vars_plugins'
    host = Host('test_host')
    group = Group('test_group')
    entities = [host, group]
    stage = 'inventory'

    data = get_vars_from_path(loader, path, entities, stage)
    assert data == {'test_host': {'test_host_var': 'test_host_value'}, 'test_group': {'test_group_var': 'test_group_value'}}

# Generated at 2022-06-17 16:23:12.555434
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader

    # Create a fake plugin
    class FakeVarsPlugin:
        def __init__(self):
            self._load_name = 'fake_vars_plugin'
            self._original_path = 'fake_vars_plugin_path'

        def get_vars(self, loader, path, entities):
            return {'fake_vars_plugin': 'fake_vars_plugin'}

    # Create a fake loader
    class FakeLoader:
        def __init__(self):
            self.vars_plugins = {'fake_vars_plugin': FakeVarsPlugin()}

    # Create a fake path
    fake_path = 'fake_path'

    # Create a fake entity
    class FakeEntity:
        def __init__(self):
            self.name

# Generated at 2022-06-17 16:23:37.479464
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.plugins.vars import BaseVarsPlugin
    from ansible.utils.collection_loader import AnsibleCollectionRef

    class TestVarsPlugin(BaseVarsPlugin):
        def get_vars(self, loader, path, entities):
            return {'test_vars_plugin': 'test_vars_plugin'}

    vars_loader.add(TestVarsPlugin, 'test_vars_plugin')
    assert get_vars_from_path(None, None, None, None) == {}
    assert get_vars_from_path(None, None, None, 'inventory') == {'test_vars_plugin': 'test_vars_plugin'}
    assert get_vars_from_path(None, None, None, 'task')

# Generated at 2022-06-17 16:23:50.802855
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    vars_plugin_list = list(vars_loader.all())
    for plugin in vars_plugin_list:
        if plugin._load_name not in C.VARIABLE_PLUGINS_ENABLED and getattr(plugin, 'REQUIRES_WHITELIST', False):
            # 2.x plugins shipped with ansible should require whitelisting, older or non shipped should load automatically
            continue
        data

# Generated at 2022-06-17 16:24:02.721288
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    host = inventory.get_host('test_host')
    group = inventory.get_group('test_group')
    data = get_vars_from_path(loader, 'tests/inventory/test_inventory_vars_plugins', [host, group], 'inventory')
    assert data['test_host_var'] == 'test_host_var_value'
    assert data['test_group_var'] == 'test_group_var_value'

# Generated at 2022-06-17 16:24:13.549324
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.utils.path import unfrackpath
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.vars import Variable
    from ansible.inventory.vars_plugins.host_list import HostList

# Generated at 2022-06-17 16:24:25.873376
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.source import InventorySource
    from ansible.utils.collection_loader import AnsibleCollectionRef

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    host = Host(name="localhost")
    group = Group(name="test_group")
    inventory.add_host(host)
    inventory.add_group(group)

# Generated at 2022-06-17 16:24:37.351322
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins/hosts'])
    host = inventory.get_host(name='testhost')
    group = inventory.get_group(name='testgroup')
    data = get_vars_from_path(loader, 'tests/inventory/test_inventory_vars_plugins/', [host, group], 'inventory')
    assert data == {'test_host_var': 'test_host_var_value', 'test_group_var': 'test_group_var_value'}

# Generated at 2022-06-17 16:24:45.027403
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.groupvars import GroupVars
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.unsafe_proxy import wrap_var

    # Create a fake inventory
    inventory = InventoryManager(loader=DataLoader(), sources=['localhost'])
    host = Host(name='localhost')
    group = Group(name='group')
    inventory.add_host(host)


# Generated at 2022-06-17 16:24:50.360128
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.source import InventorySource
    from ansible.vars.hostvars import HostVars
    from ansible.vars.groupvars import GroupVars
    from ansible.vars.hostvars import HostVars
    from ansible.vars.groupvars import GroupVars
    from ansible.vars.hostvars import HostVars
    from ansible.vars.groupvars import GroupVars
    from ansible.utils.vars import combine_v

# Generated at 2022-06-17 16:24:59.646073
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test that a vars plugin can be loaded from a collection
    plugin = vars_loader.get('test_vars_plugin.test_vars_plugin')
    assert plugin is not None

    # Test that a vars plugin can be loaded from a path
    plugin = vars_loader.get('test_vars_plugin')
    assert plugin is not None

    # Test that a vars plugin can be loaded from a path


# Generated at 2022-06-17 16:25:10.871100
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.collection_loader import AnsibleCollectionRef

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugin'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # test vars plugin
    plugin = vars_loader.get(AnsibleCollectionRef.from_string('test_vars_plugin.test_vars_plugin'))
    assert plugin is not None
    assert plugin

# Generated at 2022-06-17 16:25:33.464773
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Create a host
    host = Host(name='localhost')
    host.set_variable('ansible_python_interpreter', '/usr/bin/python3')
    host.set_variable('ansible_connection', 'local')
    host.set_variable('ansible_host', 'localhost')

# Generated at 2022-06-17 16:25:44.799405
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    host = Host(name='localhost')
    group = Group(name='group')
    path = '/path/to/inventory'

    # Test with v2 plugin
    vars_plugin = vars_loader.get('test_vars_plugin')

# Generated at 2022-06-17 16:25:56.261711
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    host = Host(name='localhost')
    group = Group(name='group')
    host.set_variable('var1', 'value1')
    group.set_variable('var2', 'value2')
    variable_manager.set_nonpersistent_facts(host, {'var3': 'value3'})
    variable_manager

# Generated at 2022-06-17 16:26:02.696914
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin_base
    class TestVarsPlugin(vars_plugin_base):
        def get_vars(self, loader, path, entities):
            return {'test_key': 'test_value'}
    loader = vars_loader.get('TestVarsPlugin')
    assert get_plugin_vars(loader, loader, '', []) == {'test_key': 'test_value'}
    assert get_plugin_vars(loader, loader, '', [Host('test_host')]) == {'test_key': 'test_value'}
    assert get_plugin_vars(loader, loader, '', [Host('test_host'), Host('test_host2')]) == {'test_key': 'test_value'}

# Generated at 2022-06-17 16:26:12.944997
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    host = Host(name='test_host')
    group = Group(name='test_group')
    inventory.add_host(host)
    inventory.add_group(group)

    vars_plugin_list = list(vars_loader.all())

# Generated at 2022-06-17 16:26:22.875553
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.collection_loader import AnsibleCollectionRef

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugin'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    vars_plugin_list = list(vars_loader.all())

# Generated at 2022-06-17 16:26:32.561205
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin
    from ansible.plugins.loader import vars_loader

    class TestVarsPlugin(vars_plugin.VarsBase):
        def get_vars(self, loader, path, entities, cache=True):
            return {'test_plugin_vars': 'test_plugin_vars'}

    vars_loader.add(TestVarsPlugin, 'test_vars_plugin')
    assert get_plugin_vars(None, TestVarsPlugin(), None, None) == {'test_plugin_vars': 'test_plugin_vars'}

# Generated at 2022-06-17 16:26:36.992584
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.plugins.vars import BaseVarsPlugin
    from ansible.utils.collection_loader import AnsibleCollectionRef
    from ansible.utils.display import Display
    from ansible.module_utils._text import to_bytes


# Generated at 2022-06-17 16:26:49.151242
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    host = Host(name='localhost')
    group = Group(name='all')
    data = get_vars_from_path(loader, '.', [host, group], 'inventory')
    assert data == {'inventory_dir': '.', 'inventory_file': 'localhost,'}

    data = get_vars_from_path(loader, '.', [host, group], 'task')

# Generated at 2022-06-17 16:26:58.508758
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test with a host
    host = Host(name='localhost')
    host.vars = {'foo': 'bar'}
    inventory.add_host(host)
    inventory.add_group('test')
    inventory.add_child('test', host)

    # Test with a group
    group = Group(name='test')