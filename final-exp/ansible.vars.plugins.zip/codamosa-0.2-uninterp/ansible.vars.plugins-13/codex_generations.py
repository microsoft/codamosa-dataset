

# Generated at 2022-06-17 16:17:18.375483
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test with a host
    host = Host(name='testhost')
    inventory.add_host(host)
    inventory.add_group('testgroup')
    inventory.add_child('testgroup', host)

# Generated at 2022-06-17 16:17:25.457479
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin_base

    class TestVarsPlugin(vars_plugin_base.VarsBase):
        def get_vars(self, loader, path, entities):
            return {'test_key': 'test_value'}

    plugin = TestVarsPlugin()
    loader = None
    path = None
    entities = None
    assert get_plugin_vars(loader, plugin, path, entities) == {'test_key': 'test_value'}

# Generated at 2022-06-17 16:17:33.204961
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test with a host
    host = inventory.get_host('host1')
    data = get_vars_from_path(loader, 'tests/inventory/test_inventory_vars_plugins', [host], 'inventory')
    assert data == {'test_inventory_vars_plugins': {'host_var': 'host1'}}

    # Test with a group
    group = inventory.get_group('group1')

# Generated at 2022-06-17 16:17:40.245045
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugin'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # test get_vars_from_inventory_sources with stage=inventory
    data = get_vars_from_inventory_sources(loader, inventory.sources, inventory.hosts.values(), 'inventory')
    assert data['test_inventory_vars_plugin_var'] == 'inventory'

    # test get_vars_from_inventory_sources with stage=task
    data = get_vars_from_inventory_sources

# Generated at 2022-06-17 16:17:49.969402
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test with stage=inventory
    data = get_vars_from_inventory_sources(loader, inventory.sources, inventory.hosts.values(), 'inventory')
    assert data['inventory_vars_plugin_var'] == 'inventory_vars_plugin_var_value'
    assert data['inventory_vars_plugin_var_start'] == 'inventory_vars_plugin_var_start_value'

# Generated at 2022-06-17 16:17:55.373614
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin_v2
    from ansible.plugins.loader import vars_loader

    class TestVarsPlugin(vars_plugin_v2.VarsModule):
        def get_vars(self, loader, path, entities):
            return {'test_key': 'test_value'}

    vars_loader.add(TestVarsPlugin, 'test_vars_plugin')
    loader = None
    path = '/path/to/inventory'
    entities = ['test_entity']
    data = get_plugin_vars(loader, TestVarsPlugin(), path, entities)
    assert data == {'test_key': 'test_value'}

# Generated at 2022-06-17 16:18:05.145923
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    host = inventory.get_host('test_host')
    group = inventory.get_group('test_group')
    data = get_vars_from_path(loader, 'tests/inventory/test_inventory_vars_plugins', [host, group], 'inventory')
    assert data['test_host_var'] == 'test_host_var_value'
    assert data['test_group_var'] == 'test_group_var_value'
    assert data['test_host_var_from_group']

# Generated at 2022-06-17 16:18:16.791328
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.play_context import PlayContext

# Generated at 2022-06-17 16:18:26.965292
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    loader = vars_loader
    path = 'tests/vars_plugins/'
    entities = [Host('host1'), Group('group1')]
    stage = 'inventory'

    data = get_vars_from_path(loader, path, entities, stage)

    assert data['plugin_var1'] == 'plugin_var1_value'
    assert data['plugin_var2'] == 'plugin_var2_value'
    assert data['plugin_var3'] == 'plugin_var3_value'

# Generated at 2022-06-17 16:18:36.343054
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    host = Host(name='testhost')
    group = Group(name='testgroup')
    variable_manager.set_inventory(inventory)
    variable_manager.set_host_variable(host, 'hostvar', 'hostvalue')
    variable_manager.set_host_variable(host, 'groupvar', 'groupvalue')


# Generated at 2022-06-17 16:18:53.772403
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager

    vars_plugin_list = list(vars_loader.all())
    for plugin_name in C.VARIABLE_PLUGINS_ENABLED:
        if AnsibleCollectionRef.is_valid_fqcr(plugin_name):
            vars_plugin = vars_loader.get(plugin_name)
            if vars_plugin is None:
                # Error if there's no play directory or the name is wrong?
                continue
            if vars_plugin not in vars_plugin_list:
                vars_plugin_list.append(vars_plugin)


# Generated at 2022-06-17 16:19:04.585044
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.collection_loader import AnsibleCollectionRef

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugin'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test with a v2 plugin
    plugin = vars_loader.get('test_vars_plugin')
    path = 'tests/inventory/test_inventory_vars_plugin'

# Generated at 2022-06-17 16:19:14.478723
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugin'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    host = inventory.get_host('host1')
    group = inventory.get_group('group1')
    entities = [host, group]
    path = 'tests/inventory/test_inventory_vars_plugin'
   

# Generated at 2022-06-17 16:19:23.334293
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.vars.hostvars import HostVars

    # Create a loader
    loader = DataLoader()

    # Create an inventory
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])

    # Create a variable manager
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Create a host
    host = Host(name='testhost')

    # Create a group
    group = inventory.groups['testgroup']

    # Create a hostvars
    hostv

# Generated at 2022-06-17 16:19:34.020024
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars_files

# Generated at 2022-06-17 16:19:44.434138
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugins

    class TestPlugin(object):
        def get_vars(self, loader, path, entities):
            return {'test': 'test'}

    class TestPlugin2(object):
        def get_host_vars(self, host):
            return {'test': 'test'}

    class TestPlugin3(object):
        def get_group_vars(self, group):
            return {'test': 'test'}

    class TestPlugin4(object):
        def run(self):
            return {'test': 'test'}

    class TestPlugin5(object):
        def get_vars(self, loader, path, entities):
            return {'test': 'test'}


# Generated at 2022-06-17 16:19:52.927457
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.play_context import PlayContext

# Generated at 2022-06-17 16:20:03.123039
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin_base

    class TestVarsPlugin(vars_plugin_base):
        def get_vars(self, loader, path, entities):
            return {'test_vars': 'test_vars'}

    class TestVarsPlugin2(vars_plugin_base):
        def get_host_vars(self, host):
            return {'test_host_vars': 'test_host_vars'}

        def get_group_vars(self, group):
            return {'test_group_vars': 'test_group_vars'}

    class TestVarsPlugin3(vars_plugin_base):
        def run(self):
            return {'test_run': 'test_run'}


# Generated at 2022-06-17 16:20:12.381203
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin_base
    class TestVarsPlugin(vars_plugin_base):
        def get_vars(self, loader, path, entities):
            return {'test_vars': 'test_vars'}
    loader = vars_loader
    plugin = TestVarsPlugin()
    path = '/path/to/somewhere'
    entities = ['entity1', 'entity2']
    assert get_plugin_vars(loader, plugin, path, entities) == {'test_vars': 'test_vars'}

# Generated at 2022-06-17 16:20:19.029745
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugin'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    host = inventory.get_host('test_inventory_vars_plugin')

    # test vars plugin
    vars_plugin = vars_loader.get('test_inventory_vars_plugin')
    assert vars_plugin is not None

# Generated at 2022-06-17 16:20:38.332621
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['test/inventory'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test vars plugin
    plugin = vars_loader.get('test_vars_plugin')
    assert plugin is not None
    assert plugin.get_vars(loader, 'test/inventory', []) == {'test_vars_plugin': 'test_vars_plugin'}

    # Test group vars plugin


# Generated at 2022-06-17 16:20:46.735382
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.source import InventorySource
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Create a host
    host = Host(name="test_host")
    # Create a group
    group = Group(name="test_group")
    # Create a group

# Generated at 2022-06-17 16:20:56.515965
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = vars_loader
    path = './test/unit/plugins/vars/test_vars_plugins'
    host = Host('test_host')
    group = Group('test_group')
    entities = [host, group]
    stage = 'inventory'

    data = get_vars_from_path(loader, path, entities, stage)

    assert data['test_host_var'] == 'test_host_value'
    assert data['test_group_var'] == 'test_group_value'

# Generated at 2022-06-17 16:21:05.269127
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['test/inventory/test_inventory_vars_plugins'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test with a host
    host = Host(name='testhost')
    inventory.add_host(host)
    inventory.reconcile_inventory()
    vars_from_inventory_sources = get_vars_from_inventory_sources(loader, inventory.sources, [host], 'inventory')
    assert vars_from_

# Generated at 2022-06-17 16:21:13.376623
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    path = './test/integration/inventory/test_inventory_vars_plugins'
    entities = [Host('testhost')]
    stage = 'inventory'
    data = get_vars_from_path(loader, path, entities, stage)
    assert data == {'test_inventory_vars_plugins': 'test_inventory_vars_plugins'}

    vars_plugin_list = list(vars_loader.all())

# Generated at 2022-06-17 16:21:18.218789
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.plugins.vars import BaseVarsPlugin
    from ansible.utils.collection_loader import AnsibleCollectionRef

    class TestVarsPlugin(BaseVarsPlugin):
        def get_vars(self, loader, path, entities):
            return {'test_vars_plugin': True}

    vars_loader.add(TestVarsPlugin, 'test_vars_plugin')
    vars_loader.add(TestVarsPlugin, AnsibleCollectionRef.from_string('test_namespace.test_collection.test_vars_plugin'))

    loader = None
    path = '/path/to/inventory'
    entities = []
    stage = 'inventory'

    data = get_vars_from_path(loader, path, entities, stage)



# Generated at 2022-06-17 16:21:28.428358
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    vars_loader.add_directory(os.path.join(os.path.dirname(__file__), '../../../test/units/plugins/vars'))
    vars_loader.all()
    vars_loader.enable_all()
    vars_loader.disable_all()
    vars_loader.enable_by_name('test_vars_plugin')
    vars_loader.disable_by_name('test_vars_plugin')
    vars_loader.enable_by_name('test_vars_plugin_2')
    vars_loader.disable_by_name('test_vars_plugin_2')
    vars_loader.enable_by_name('test_vars_plugin_3')

# Generated at 2022-06-17 16:21:35.451368
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # test with a host
    host = inventory.get_host('test_inventory_vars_plugins')
    host_vars = get_vars_from_inventory_sources(loader, inventory.sources, [host], 'inventory')

# Generated at 2022-06-17 16:21:49.126546
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    vars_plugin_list = list(vars_loader.all())
    for plugin in vars_plugin_list:
        if plugin._load_name not in C.VARIABLE_PLUGINS_ENABLED and getattr(plugin, 'REQUIRES_WHITELIST', False):
            # 2.x plugins shipped with ansible should require whitelisting, older or non shipped should load automatically
            continue

        has

# Generated at 2022-06-17 16:21:56.953031
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.plugins.loader import vars_loader
    from ansible.plugins.vars import yaml_loader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugin'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test get_vars_from_inventory_sources with a host
    host = inventory.get_host(hostname='testhost')
    assert host.name == 'testhost'
    assert host.vars == {}


# Generated at 2022-06-17 16:22:18.761584
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    host = Host(name='localhost')
    group = Group(name='group')
    path = '/path/to/inventory'

    # Test with v2 plugin
    vars_plugin = vars_loader.get('test_vars_plugin')
    assert vars_plugin is not None
    assert get_vars_from_path

# Generated at 2022-06-17 16:22:28.509730
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.play_context import PlayContext

# Generated at 2022-06-17 16:22:39.436708
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    display = Display()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['test/integration/inventory'])

# Generated at 2022-06-17 16:22:51.570632
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # test get_vars_from_path
    path = 'tests/inventory/group_vars/all'
    entities = inventory.get_groups_dict().values()
    data = get_vars_from_path(loader, path, entities, 'inventory')
    assert data['test_var'] == 'test_value'

    # test get_vars_from_inventory_sources
    sources = ['tests/inventory/group_vars/all']
    data = get

# Generated at 2022-06-17 16:22:58.741885
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test with a single host
    host = inventory.get_host('host1')
    data = get_vars_from_path(loader, 'tests/inventory', [host], 'inventory')
    assert data == {'var1': 'value1', 'var2': 'value2', 'var3': 'value3'}

    # Test with a single group
    group = inventory.get_group('group1')
   

# Generated at 2022-06-17 16:23:10.859163
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    host = inventory.get_host('test_host')
    group = inventory.get_group('test_group')

    # test get_vars_from_path

# Generated at 2022-06-17 16:23:18.716855
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['/etc/ansible/hosts'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    all_hosts = inventory.get_hosts()
    all_groups = inventory.get_groups()
    print(get_vars_from_inventory_sources(loader, ['/etc/ansible/hosts'], all_hosts, 'inventory'))
    print(get_vars_from_inventory_sources(loader, ['/etc/ansible/hosts'], all_groups, 'inventory'))


# Generated at 2022-06-17 16:23:28.673507
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.plugins.vars import BaseVarsPlugin
    from ansible.plugins.vars.host_group_vars import HostGroupVars

# Generated at 2022-06-17 16:23:30.486036
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert get_vars_from_path(None, None, None, None) == {}

# Generated at 2022-06-17 16:23:37.667330
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugin'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # test get_vars_from_path
    host = Host(name='test_host')
    group = Group(name='test_group')

# Generated at 2022-06-17 16:24:03.708332
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    vars_plugin_list = list(vars_loader.all())
    for plugin in vars_plugin_list:
        if plugin._load_name not in C.VARIABLE_PLUGINS_ENABLED and getattr(plugin, 'REQUIRES_WHITELIST', False):
            # 2.x plugins shipped with ansible should require whitelisting, older or non shipped should load automatically
            continue

        has

# Generated at 2022-06-17 16:24:13.191271
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager

    loader = vars_loader
    path = './test/integration/inventory_vars_plugins/'
    inventory = InventoryManager(loader=loader, sources=path)
    host = inventory.get_host('test_host')
    group = inventory.get_group('test_group')
    entities = [host, group]
    stage = 'inventory'
    data = get_vars_from_path(loader, path, entities, stage)
    assert data == {'test_host': {'host_var': 'host_var_value'}, 'test_group': {'group_var': 'group_var_value'}}

# Generated at 2022-06-17 16:24:25.592377
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.plugins.vars import BaseVarsPlugin
    from ansible.utils.vars import combine_vars

    class TestVarsPlugin(BaseVarsPlugin):
        def get_vars(self, loader, path, entities):
            return {'test_vars_plugin': True}

    vars_loader.add('test_vars_plugin', TestVarsPlugin)

    assert get_vars_from_path(None, None, None, None) == {}
    assert get_vars_from_path(None, None, None, None) == {}
    assert get_vars_from_path(None, None, None, None) == {}
    assert get_vars_from_path(None, None, None, None) == {}
    assert get

# Generated at 2022-06-17 16:24:37.471194
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugin'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    host = inventory.get_host('test_host')
    group = inventory.get_group('test_group')
    hostvars = HostVars(loader=loader, inventory=inventory)

    # Test with a single host

# Generated at 2022-06-17 16:24:48.023271
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    loader = vars_loader
    path = './test/integration/inventory_vars_plugins/'
    inventory = InventoryManager(loader=loader, sources=path)
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    data = get_vars_from_path(loader, path, variable_manager.get_vars(host=None, include_hostvars=False), 'inventory')
    assert data['inventory_vars_plugin_test_var'] == 'inventory_vars_plugin_test_var_value'

# Generated at 2022-06-17 16:24:59.032679
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    host = inventory.get_host('test_host')
    group = inventory.get_group('test_group')

    # test with a single host
    vars_from_path = get_vars_from_path(loader, 'tests/inventory/test_inventory_vars_plugins', [host], 'inventory')
    assert vars_from_path == {'test_host_var': 'test_host_var_value'}

    # test with a single group
    vars_from_path = get

# Generated at 2022-06-17 16:24:59.993354
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 16:25:08.626413
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin_base
    class TestPlugin(vars_plugin_base):
        def get_vars(self, loader, path, entities):
            return {'test_key': 'test_value'}

    loader = None
    plugin = TestPlugin()
    path = '/path/to/somewhere'
    entities = ['test_entity']
    assert get_plugin_vars(loader, plugin, path, entities) == {'test_key': 'test_value'}

# Generated at 2022-06-17 16:25:13.775336
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.plugins.vars import BaseVarsPlugin
    from ansible.utils.vars import combine_vars


# Generated at 2022-06-17 16:25:22.816151
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    variable_manager._vars_plugins = vars_loader.all()

    # Test with a single host
    host = inventory.get_host(hostname='localhost')
    assert get_vars_from_path(loader, '', [host], 'inventory') == {}

    # Test with a single group
    group = inventory.get_group(groupname='all')

# Generated at 2022-06-17 16:26:12.000369
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager

    class TestVarsPlugin:
        def __init__(self, name):
            self._load_name = name

        def get_vars(self, loader, path, entities):
            return {self._load_name: path}

    vars_loader.add(TestVarsPlugin('test1'))
    vars_loader.add(TestVarsPlugin('test2'))

    inventory = InventoryManager(loader=None, sources=['localhost,'])
    host = inventory.get_host('localhost')
    group = inventory.get_group('all')


# Generated at 2022-06-17 16:26:19.193587
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin_base

    class TestVarsPlugin(vars_plugin_base):
        def get_vars(self, loader, path, entities):
            return {'test_plugin_vars': 'test_plugin_vars'}

    loader = None
    plugin = TestVarsPlugin()
    path = None
    entities = None

    assert get_plugin_vars(loader, plugin, path, entities) == {'test_plugin_vars': 'test_plugin_vars'}

# Generated at 2022-06-17 16:26:25.241967
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin_base
    from ansible.plugins.loader import vars_loader

    class TestVarsPlugin(vars_plugin_base.VarsBase):
        def get_vars(self, loader, path, entities):
            return {'test_key': 'test_value'}

    vars_loader.add(TestVarsPlugin, 'test_vars_plugin')
    assert get_plugin_vars(None, vars_loader.get('test_vars_plugin'), None, None) == {'test_key': 'test_value'}

# Generated at 2022-06-17 16:26:34.953747
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.plugins.vars import BaseVarsPlugin
    from ansible.utils.collection_loader import AnsibleCollectionRef

    class TestVarsPlugin(BaseVarsPlugin):
        def get_vars(self, loader, path, entities):
            return {'test_vars_plugin': True}

    vars_loader.add(AnsibleCollectionRef.from_string('test_collection.test_ns.test_plugin'), TestVarsPlugin)

    loader = None
    path = None
    entities = []
    stage = 'inventory'

    data = get_vars_from_path(loader, path, entities, stage)
    assert data['test_vars_plugin'] == True

# Generated at 2022-06-17 16:26:48.667246
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    host = inventory.get_host('test_inventory_vars_plugins')
    group = inventory.get_group('all')

    vars_plugin_list = list(vars_loader.all())
    for plugin_name in C.VARIABLE_PLUGINS_ENABLED:
        if AnsibleCollectionRef.is_valid_fqcr(plugin_name):
            vars_plugin = vars_loader.get(plugin_name)

# Generated at 2022-06-17 16:26:57.893736
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugin'])
    host = inventory.get_host('test_host')
    group = inventory.get_group('test_group')
    data = get_vars_from_path(loader, 'tests/inventory/test_inventory_vars_plugin', [host, group], 'inventory')
    assert data == {'test_host_var': 'test_host_value', 'test_group_var': 'test_group_value'}

# Generated at 2022-06-17 16:27:07.562760
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test with a host
    host = inventory.get_host('testhost')
    vars = get_vars_from_inventory_sources(loader, inventory.sources, [host], 'inventory')
    assert vars['test_var'] == 'testhost'

    # Test with a group
    group = inventory.get_group('testgroup')
    vars = get_vars_from_inventory_sources(loader, inventory.sources, [group], 'inventory')