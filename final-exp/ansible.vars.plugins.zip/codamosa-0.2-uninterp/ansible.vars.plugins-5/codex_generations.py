

# Generated at 2022-06-17 16:17:19.118351
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test vars from group_vars/all
    vars_from_path = get_vars_from_path(loader, 'tests/inventory/test_inventory_vars_plugins/group_vars', [inventory.groups['all']], 'inventory')
    assert vars_from_path['group_var_all'] == 'group_var_all'

    # Test v

# Generated at 2022-06-17 16:17:29.264557
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    host = inventory.get_host('localhost')

    # Test vars_loader.all()
    vars_plugin_list = list(vars_loader.all())
    assert len(vars_plugin_list) > 0

    # Test get_vars_from_path
    data = get_vars_from_path(loader, '.', [host], 'inventory')
    assert len(data) > 0

    # Test get_plugin_vars

# Generated at 2022-06-17 16:17:35.676838
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['test/inventory/test_inventory_vars_plugins'])
    inventory.parse_sources()
    data = get_vars_from_inventory_sources(loader, ['test/inventory/test_inventory_vars_plugins'], inventory.hosts.values(), 'inventory')
    assert data == {'inventory_hostname': 'localhost', 'inventory_hostname_short': 'localhost'}

# Generated at 2022-06-17 16:17:39.623712
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin_base
    class TestVarsPlugin(vars_plugin_base):
        def get_vars(self, loader, path, entities):
            return {'test_key': 'test_value'}
    loader = vars_loader.get('TestVarsPlugin')
    assert get_plugin_vars(loader, loader, '', []) == {'test_key': 'test_value'}

# Generated at 2022-06-17 16:17:49.634717
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase
    from ansible.utils.vars import combine_vars

    class TestCallback(CallbackBase):
        def __init__(self, *args, **kwargs):
            super(TestCallback, self).__init__(*args, **kwargs)


# Generated at 2022-06-17 16:18:01.315097
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    variable_manager._fact_cache = {}
    variable_manager._vars_cache = {}
    variable_manager._extra_vars = {}
    variable_manager._options_vars = {}
    variable_manager._host_vars_files = {}
    variable_manager._group_vars_files = {}
    variable_manager._vars_plugins = vars

# Generated at 2022-06-17 16:18:07.687346
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    vars_loader.add_directory(os.path.join(os.path.dirname(__file__), '../../../test/unit/plugins/vars_plugins'))
    vars_loader.all()
    vars_loader.enable_vars_plugins()

# Generated at 2022-06-17 16:18:18.166976
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test get_vars_from_path
    # Test with a host
    host = inventory.get_host('test_host_0')

# Generated at 2022-06-17 16:18:27.899920
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars
    from ansible.plugins.vars import BaseVarsPlugin
    from ansible.plugins.vars.host_group import HostGroupVars

# Generated at 2022-06-17 16:18:36.747804
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    host = Host(name='localhost')
    host.vars = get_vars_from_path(loader, './', [host], 'task')
    variable_manager.set_host_variable(host, host.vars)
    print(variable_manager.get_vars(host=host))


# Generated at 2022-06-17 16:18:48.213912
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader

    # Test with a v2 plugin
    plugin = vars_loader.get('test_vars_plugin')
    assert plugin is not None

    # Test with a v1 plugin
    plugin = vars_loader.get('test_vars_plugin_v1')
    assert plugin is not None

    # Test with a v1 plugin that doesn't have a run method
    plugin = vars_loader.get('test_vars_plugin_v1_no_run')
    assert plugin is not None

    # Test with a v1 plugin that doesn't have a run method
    plugin = vars_loader.get('test_vars_plugin_v1_no_run')
    assert plugin is not None

    # Test with a v1 plugin that doesn't have a run method
    plugin

# Generated at 2022-06-17 16:18:56.842936
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.utils.collection_loader import AnsibleCollectionRef
    from ansible.plugins.vars import BaseVars

# Generated at 2022-06-17 16:19:07.586444
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory'])
    host = inventory.get_host('test_host')
    group = inventory.get_group('test_group')

    # Test with a v2 plugin
    plugin = vars_loader.get('test_vars_plugin')
    assert plugin is not None
    assert get_vars_from_path(loader, 'tests/inventory', [host], 'inventory') == {'test_host_var': 'test_host_value'}
    assert get_

# Generated at 2022-06-17 16:19:17.596627
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.plugins.vars import BaseVarsPlugin
    from ansible.utils.collection_loader import AnsibleCollectionRef

    class TestVarsPlugin(BaseVarsPlugin):
        def get_vars(self, loader, path, entities):
            return {'test_vars_plugin': 'test_vars_plugin'}

    class TestVarsPlugin2(BaseVarsPlugin):
        def get_vars(self, loader, path, entities):
            return {'test_vars_plugin2': 'test_vars_plugin2'}


# Generated at 2022-06-17 16:19:25.299758
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    host = Host(name="localhost")
    group = Group(name="group")

    entities = [host, group]

    # Test with a v2 plugin
    plugin = vars_loader.get('test_vars_plugin')
    assert plugin is not None
    assert get_plugin_vars(loader, plugin, '', entities)

# Generated at 2022-06-17 16:19:35.570786
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.groupvars import GroupVars
    from ansible.vars.groupvars import GroupVarsVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.hostvars import HostVarsVars

# Generated at 2022-06-17 16:19:49.350693
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugin'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # test vars plugin
    plugin = vars_loader.get('test_vars_plugin')
    assert plugin is not None
    assert plugin.get_vars(loader, 'tests/inventory/test_inventory_vars_plugin', [inventory.get_group('all')]) == {'test_vars_plugin': 'test_vars_plugin'}

    # test vars plugin with get_host_vars
    plugin = v

# Generated at 2022-06-17 16:19:59.518186
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugins

    class MockPlugin:
        def get_vars(self, loader, path, entities):
            return {'foo': 'bar'}

    class MockPlugin2:
        def get_host_vars(self, host):
            return {'foo': 'bar'}

    class MockPlugin3:
        def get_group_vars(self, group):
            return {'foo': 'bar'}

    class MockPlugin4:
        def run(self):
            pass

    class MockPlugin5:
        def get_vars(self, loader, path, entities):
            return {'foo': 'bar'}
        REQUIRES_WHITELIST = True


# Generated at 2022-06-17 16:20:06.423310
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader

    # Create a fake vars plugin
    class FakeVarsPlugin:
        def get_vars(self, loader, path, entities):
            return {'fake_vars_plugin': 'fake_vars_plugin'}

    # Create a fake loader
    class FakeLoader:
        pass

    # Create a fake entity
    class FakeEntity:
        pass

    # Create a fake path
    fake_path = 'fake_path'

    # Create a fake stage
    fake_stage = 'fake_stage'

    # Create a fake vars plugin list
    fake_vars_plugin_list = [FakeVarsPlugin()]

    # Create a fake vars plugin
    fake_vars_plugin = FakeVarsPlugin()

    # Create a fake vars plugin name
    fake

# Generated at 2022-06-17 16:20:15.921276
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.plugins.vars import TestVarsPlugin
    from ansible.plugins.vars.test_vars_plugin import TestVarsModule
    from ansible.utils.collection_loader import AnsibleCollectionLoader

    collection_path = os.path.join(os.path.dirname(__file__), 'fixtures', 'ansible_collections', 'test_namespace', 'test_collection')
    collection_loader = AnsibleCollectionLoader()
    collection_loader.load(collection_path)

    vars_loader.add(TestVarsPlugin(collection_loader))

    loader = collection_loader.get('test_namespace.test_collection')

# Generated at 2022-06-17 16:20:37.942356
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test with an inventory source that has a vars plugin
    sources = ['tests/inventory/test_inventory_vars_plugins/hosts']
    entities = inventory.get_hosts()
    stage = 'inventory'
    data = get_vars_from_inventory_sources(loader, sources, entities, stage)
    assert data['test_inventory_vars_plugins_var'] == 'test_inventory_vars_plugins_value'

# Generated at 2022-06-17 16:20:50.343022
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.plugins.vars import BaseVarsPlugin
    from ansible.utils.collection_loader import AnsibleCollectionRef

    class TestVarsPlugin(BaseVarsPlugin):
        def get_vars(self, loader, path, entities):
            return {'test_vars_plugin': 'test_vars_plugin'}

    vars_loader.add(TestVarsPlugin, 'test_vars_plugin')
    assert get_vars_from_path(None, None, None, None) == {}
    assert get_vars_from_path(None, None, None, 'inventory') == {}
    assert get_vars_from_path(None, None, None, 'task') == {}

# Generated at 2022-06-17 16:20:59.725403
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # test get_vars_from_path
    # test vars plugin
    vars_plugin_list = list(vars_loader.all())

# Generated at 2022-06-17 16:21:05.987656
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    host = Host(name='test_host')
    group = inventory.groups['test_group']
    data = get_vars_from_path(loader, 'tests/inventory/test_inventory_vars_plugins', [host, group], 'inventory')

# Generated at 2022-06-17 16:21:15.274823
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # test for host
    host = inventory.get_host('test_host')
    data = get_vars_from_path(loader, 'tests/inventory', [host], 'inventory')
    assert data == {'test_var': 'test_value'}



# Generated at 2022-06-17 16:21:26.131724
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test with a single host
    host = inventory.get_host('host1')
    vars = get_vars_from_inventory_sources(loader, inventory._sources, [host], 'inventory')
    assert vars == {'host1_var': 'host1_value', 'group1_var': 'group1_value', 'all_var': 'all_value'}

    # Test with a single group
    group = inventory.get

# Generated at 2022-06-17 16:21:31.044144
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.plugins.vars import BaseVarsPlugin
    from ansible.utils.collection_loader import AnsibleCollectionRef

    class TestVarsPlugin(BaseVarsPlugin):
        def get_vars(self, loader, path, entities):
            return {'test_vars_plugin': 'test_vars_plugin'}

    class TestVarsPlugin2(BaseVarsPlugin):
        def get_host_vars(self, host):
            return {'test_vars_plugin2': 'test_vars_plugin2'}

    class TestVarsPlugin3(BaseVarsPlugin):
        def get_group_vars(self, group):
            return {'test_vars_plugin3': 'test_vars_plugin3'}


# Generated at 2022-06-17 16:21:39.692249
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugin'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # test inventory vars plugin
    inventory_vars = get_vars_from_inventory_sources(loader, inventory.sources, inventory.hosts, 'inventory')
    assert inventory_vars == {'inventory_var': 'inventory_value'}

    # test group vars plugin

# Generated at 2022-06-17 16:21:50.510386
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    group = inventory.groups['group1']
    host = inventory.get_host('test_host')

    vars_plugin_list = list(vars_loader.all())

# Generated at 2022-06-17 16:21:57.845534
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    from ansible.plugins.loader import vars_loader

    # Test with a vars plugin that does not support the new API
    class TestVarsPlugin:
        def __init__(self):
            self._load_name = 'test_vars_plugin'
            self._original_path = 'test_vars_plugin'

        def get_host_vars(self, host):
            return {'test_vars_plugin_host': host}

        def get_group_vars(self, group):
            return {'test_vars_plugin_group': group}

    vars_loader.add(TestVarsPlugin())

    # Test with a vars plugin that supports the new API

# Generated at 2022-06-17 16:22:10.923391
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    variable_manager = VariableManager(loader=loader, inventory=inv_manager)
    host = inv_manager.get_host('test_host_0')
    group = inv_manager.get_group('test_group_0')
    data = get_vars_from_path(loader, 'tests/inventory/test_inventory_vars_plugins', [host, group], 'inventory')

# Generated at 2022-06-17 16:22:21.397313
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    host = inventory.get_host('test_host')
    group = inventory.get_group('test_group')

    vars_plugin_list = list(vars_loader.all())

# Generated at 2022-06-17 16:22:32.023851
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    host = Host(name='localhost')
    group = Group(name='all')
    entities = [host, group]
    path = './test/integration/inventory_vars_plugins/'
    stage = 'inventory'
    data = get_vars_from_path(loader, path, entities, stage)

# Generated at 2022-06-17 16:22:40.910715
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    host = Host(name='localhost')
    host.set_variable('foo', 'bar')
    inventory.add_host(host)
    group = inventory.get_group('all')
    group.set_variable('foo', 'baz')

    # Test with a vars plugin that supports v2
    vars_plugin = vars_loader.get('test_vars_plugin')
    vars_plugin.get_vars = lambda x, y, z: {'foo': 'test'}
   

# Generated at 2022-06-17 16:22:51.975393
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test with a host
    host = inventory.get_host(hostname="testhost")
    vars_plugin_list = list(vars_loader.all())

# Generated at 2022-06-17 16:23:02.641711
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugin'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # test get_vars_from_path
    entities = [Host(name='localhost', port=22)]
    path = 'tests/inventory/test_inventory_vars_plugin'
    stage = 'inventory'
    data

# Generated at 2022-06-17 16:23:13.201003
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    inv_manager.parse_sources()
    inv = inv_manager.inventory

    # test inventory vars
    assert get_vars_from_inventory_sources(loader, inv.sources, [inv.get_host('test_host')], 'inventory') == {'test_inventory_var': 'test_inventory_var_value'}

    # test group vars

# Generated at 2022-06-17 16:23:18.773287
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inv = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    host = inv.get_host('host1')
    group = inv.get_group('group1')
    data = get_vars_from_path(loader, 'tests/inventory/test_inventory_vars_plugins', [host, group], 'inventory')
    assert data['test_var'] == 'test_value'
    assert data['test_var_group'] == 'test_value_group'
    assert data['test_var_host'] == 'test_value_host'

# Generated at 2022-06-17 16:23:28.714580
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # test get_vars_from_path with a v2 plugin
    vars_plugin = vars_loader.get('test_vars_plugin')
    assert vars_plugin is not None
    assert vars_plugin.get_vars(loader, '.', [inventory.get_host('localhost')]) == {'test_vars_plugin': 'test_vars_plugin'}

    # test get_vars

# Generated at 2022-06-17 16:23:37.018312
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    path = './test/integration/vars_plugins/'
    entities = inventory.get_hosts('all')
    data = get_vars_from_path(loader, path, entities, 'inventory')
    assert data == {'test_vars_plugin_1': 'test_vars_plugin_1', 'test_vars_plugin_2': 'test_vars_plugin_2'}


# Generated at 2022-06-17 16:23:46.872623
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    # TODO: write unit test for function get_plugin_vars
    pass

# Generated at 2022-06-17 16:23:53.660811
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory'])

    vars_plugin_list = list(vars_loader.all())
    for plugin_name in C.VARIABLE_PLUGINS_ENABLED:
        if AnsibleCollectionRef.is_valid_fqcr(plugin_name):
            vars_plugin = vars_loader.get(plugin_name)
            if vars_plugin is None:
                # Error if there's no play directory or the name is wrong?
                continue
            if vars_plugin not in vars_plugin_list:
                vars_plugin_list

# Generated at 2022-06-17 16:24:03.313468
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test with a single host
    host = inventory.get_host('host1')
    assert host is not None
    assert host.name == 'host1'

    data = get_vars_from_path(loader, 'tests/inventory/test_inventory_vars_plugins', [host], 'inventory')

# Generated at 2022-06-17 16:24:13.585529
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    host = Host(name='localhost')
    host.vars = get_vars_from_path(loader, './test/units/plugins/vars/', [host], 'inventory')
    variable_manager.set_host_variable(host, host.vars)
    assert variable_manager.get_vars(host=host)['test_var'] == 'test_value'

# Generated at 2022-06-17 16:24:25.905668
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['/tmp/test_inventory'])
    inventory.clear_pattern_cache()
    inventory.parse_inventory(inventory.sources)

    host = Host(name='test_host')
    group = Group(name='test_group')

    vars_plugin_list = list(vars_loader.all())

# Generated at 2022-06-17 16:24:37.665928
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test with a host
    host = Host(name="localhost")
    vars = get_vars_from_path(loader, './test/units/vars_plugins/', [host], 'inventory')
    assert vars == {'test_host_vars': 'test_host_vars_value'}

    # Test

# Generated at 2022-06-17 16:24:48.116414
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.source import InventorySource
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.utils.collection_loader import AnsibleCollectionRef

    class TestVarsPlugin:
        def __init__(self, name):
            self._load_name = name

        def get_vars(self, loader, path, entities):
            return {self._load_name: 'get_vars'}


# Generated at 2022-06-17 16:24:59.091235
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory.yml'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    host = inventory.get_host('testhost')
    group = inventory.get_group('testgroup')

    vars_plugin_list = list(vars_loader.all())

# Generated at 2022-06-17 16:25:10.559687
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    loader = vars_loader
    path = './test/integration/inventory/'
    inventory = InventoryManager(loader=loader, sources=path)
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    group = inventory.groups['all']
    host = inventory.get_host('localhost')
    entities = [group, host]
    stage = 'inventory'
    data = get_vars_from_path(loader, path, entities, stage)
    assert data['group_var_test'] == 'group_var_test_value'
    assert data['group_var_test_2'] == 'group_var_test_2_value'
   

# Generated at 2022-06-17 16:25:21.904838
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_manager'])
    host = inventory.get_host('test_inventory_manager')

    vars = get_vars_from_path(loader, 'tests/inventory/test_inventory_manager', [host], 'inventory')
    assert vars == {'test_inventory_manager_var': 'test_inventory_manager_value'}

    vars = get_vars_from_path(loader, 'tests/inventory/test_inventory_manager', [host], 'task')
    assert vars == {'test_inventory_manager_var': 'test_inventory_manager_value'}


# Generated at 2022-06-17 16:25:37.404088
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['test/inventory/test_inventory_vars_plugin'])
    inventory.parse_sources()

    # Test with a host
    host = inventory.get_host('testhost')
    data = get_vars_from_inventory_sources(loader, inventory.sources, [host], 'inventory')
    assert data == {'test_vars_plugin_var': 'test_vars_plugin_value'}

    # Test with a group
    group = inventory.get_group('testgroup')
    data = get_vars_from_inventory_sources(loader, inventory.sources, [group], 'inventory')
   

# Generated at 2022-06-17 16:25:46.620754
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.play_context import PlayContext

# Generated at 2022-06-17 16:25:57.561140
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin_base

    class TestVarsPlugin(vars_plugin_base.VarsBase):
        def get_vars(self, loader, path, entities):
            return {'test_vars_plugin': 'test_vars_plugin'}

        def get_host_vars(self, host):
            return {'test_host_vars': 'test_host_vars'}

        def get_group_vars(self, group):
            return {'test_group_vars': 'test_group_vars'}


# Generated at 2022-06-17 16:26:04.404338
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars.host_group_vars import VarsModule as HostGroupVarsModule
    from ansible.plugins.vars.host_vars import VarsModule as HostVarsModule
    from ansible.plugins.vars.group_vars import VarsModule as GroupVarsModule

    class MockVarsModule(object):
        def __init__(self, name):
            self._load_name = name
            self._original_path = name

    class MockVarsModule2(object):
        def __init__(self, name):
            self._load_name = name
            self._original_path = name

        def get_vars(self, loader, path, entities):
            return {'test_get_vars': True}


# Generated at 2022-06-17 16:26:15.201695
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.plugins.vars import BaseVarsPlugin
    from ansible.utils.display import Display
    from ansible.utils.path import unfrackpath

    display = Display()
    loader = DataLoader()
    inventory = InventoryManager

# Generated at 2022-06-17 16:26:24.117012
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.plugins.loader import vars_loader
    from ansible.plugins.vars import BaseVarsPlugin
    from ansible.plugins.vars.host_group import HostGroupV

# Generated at 2022-06-17 16:26:35.661868
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    host = Host(name='localhost')
    host.vars = get_vars_from_path(loader, 'localhost', [host], 'inventory')
    variable_manager.set_host_variable(host, host.vars)
    print(variable_manager.get_vars(host=host))

    group = inventory.groups.get('all')

# Generated at 2022-06-17 16:26:48.340989
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    host = Host(name='localhost')
    group = Group(name='group')

    vars = get_vars_from_path(loader, './test/units/plugins/vars/', [host, group], 'inventory')
    assert vars['test_vars_from_path'] == 'success'

# Generated at 2022-06-17 16:26:55.070192
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin_base
    class TestVarsPlugin(vars_plugin_base):
        def get_vars(self, loader, path, entities):
            return {'test_key': 'test_value'}

    loader = None
    plugin = TestVarsPlugin()
    path = None
    entities = None
    assert get_plugin_vars(loader, plugin, path, entities) == {'test_key': 'test_value'}

# Generated at 2022-06-17 16:27:05.265818
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.utils.vars import combine_vars

    # Create a host and group to test with
    host = Host(name='testhost')
    group = Group(name='testgroup')

    # Create a variable manager
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Create a vars plugin