

# Generated at 2022-06-17 16:17:14.403843
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.collection_loader import AnsibleCollectionRef

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugin'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # test vars plugin
    vars_plugin = vars_loader.get(AnsibleCollectionRef.from_string('test_namespace.test_collection.test_vars_plugin'))
    assert vars_

# Generated at 2022-06-17 16:17:24.651021
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.hostvars import HostVars
    from ansible.vars.groupvars import GroupVars
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.unsafe_proxy import wrap_var

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    host = Host(name='localhost')
    group = Group

# Generated at 2022-06-17 16:17:31.700196
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugin'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    host = inventory.get_host('host1')
    hostvars = HostVars(host, variable_manager)
    assert hostvars.get('test_var') == 'test_value'

# Generated at 2022-06-17 16:17:39.573626
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugins

    class TestVarsPlugin(object):
        def get_vars(self, loader, path, entities):
            return {'test_vars': 'test_vars'}

    class TestVarsPlugin2(object):
        def get_host_vars(self, host):
            return {'test_host_vars': 'test_host_vars'}

        def get_group_vars(self, group):
            return {'test_group_vars': 'test_group_vars'}

    class TestVarsPlugin3(object):
        def run(self, host):
            return {'test_run': 'test_run'}

    class TestHost(object):
        def __init__(self, name):
            self.name = name

# Generated at 2022-06-17 16:17:46.308478
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin_base
    class TestVarsPlugin(vars_plugin_base):
        def get_vars(self, loader, path, entities):
            return {'test_key': 'test_value'}

    loader = None
    plugin = TestVarsPlugin()
    path = None
    entities = None
    assert get_plugin_vars(loader, plugin, path, entities) == {'test_key': 'test_value'}

# Generated at 2022-06-17 16:17:53.684609
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    host = Host(name='localhost')
    group = Group(name='group')

    entities = [host, group]

    path = os.path.join(os.path.dirname(__file__), '../../../test/units/vars_plugins/')


# Generated at 2022-06-17 16:18:04.321710
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['test/unit/inventory/test_inventory_vars_plugin'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test vars plugin
    plugin = vars_loader.get('test_vars_plugin')
    assert plugin is not None
    assert plugin._load_name == 'test_vars_plugin'

# Generated at 2022-06-17 16:18:16.018701
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    host = inventory.get_host('test_host')
    group = inventory.get_group('test_group')
    data = get_vars_from_path(loader, 'tests/inventory/test_inventory_vars_plugins', [host, group], 'inventory')
    assert data == {'test_host_vars': 'test_host_vars', 'test_group_vars': 'test_group_vars'}

    # test v1 plugins

# Generated at 2022-06-17 16:18:26.426321
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    host = inventory.get_host('host1')
    group = inventory.get_group('group1')

    # test with stage=inventory
    data = get_vars_from_inventory_sources(loader, inventory.sources, [host, group], 'inventory')
    assert data == {'group_var': 'group1', 'host_var': 'host1', 'inventory_var': 'inventory'}

    # test with stage=task

# Generated at 2022-06-17 16:18:27.596004
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert get_vars_from_path(None, None, None, None) == {}

# Generated at 2022-06-17 16:18:43.692091
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test with a host
    host = Host(name="localhost")
    variable_manager.set_host_variable(host, 'test_var', 'test_value')
    vars_plugin_list = list(vars_loader.all())

# Generated at 2022-06-17 16:18:47.486930
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test with a v2 plugin
    plugin = vars_loader.get('test_vars_plugin')
    assert plugin is not None
    assert plugin.get_vars(loader, '.', [inventory.get_host('localhost')]) == {'test_vars_plugin': 'test_vars_plugin'}

    # Test with a v1 plugin

# Generated at 2022-06-17 16:18:56.056903
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    host = Host(name='localhost')
    group = Group(name='group')
    entities = [host, group]
    path = '.'
    stage = 'inventory'

    vars_plugin_list = list(vars_loader.all())

# Generated at 2022-06-17 16:19:06.919218
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Create a host and group
    host = Host(name='localhost')
    group = Group(name='group1')
    inventory.add_host(host, 'all')
    inventory.add_group(group)
    inventory.add_child('all', group)

    # Create a vars plugin

# Generated at 2022-06-17 16:19:09.112334
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    # TODO: implement
    pass


# Generated at 2022-06-17 16:19:19.364246
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader

    vars_plugin_list = list(vars_loader.all())
    for plugin_name in C.VARIABLE_PLUGINS_ENABLED:
        if AnsibleCollectionRef.is_valid_fqcr(plugin_name):
            vars_plugin = vars_loader.get(plugin_name)
            if vars_plugin is None:
                # Error if there's no play directory or the name is wrong?
                continue
            if vars_plugin not in vars_plugin_list:
                vars_plugin_list.append(vars_plugin)


# Generated at 2022-06-17 16:19:26.337808
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.plugins.callback import CallbackBase
    from ansible.plugins.callback.default import CallbackModule
    from ansible.plugins.callback.json import CallbackModule as JsonCallback

# Generated at 2022-06-17 16:19:36.477048
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugin'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test get_vars_from_path()
    # Test get_vars_from_path() with a host
    host = inventory.get_host('test_inventory_vars_plugin')
    entities = [host]
    path = 'tests/inventory/test_inventory_vars_plugin'
    stage = 'inventory'
    data = get_vars_from_path

# Generated at 2022-06-17 16:19:49.726893
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    host = inventory.get_host('test_host')
    group = inventory.get_group('test_group')
    vars_plugin_list = list(vars_loader.all())

# Generated at 2022-06-17 16:19:55.362416
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugin'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # test for get_vars_from_path
    vars_plugin_list = list(vars_loader.all())

# Generated at 2022-06-17 16:20:06.746238
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test with inventory source as a directory
    path = 'tests/inventory/test_inventory_vars_plugins'
    entities = [inventory.get_group('group1'), inventory.get_group('group2')]
    data = get_vars_from_inventory_sources(loader, [path], entities, 'inventory')

# Generated at 2022-06-17 16:20:16.050277
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugin'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    host = inventory.get_host('test_host')
    group = inventory.get_group('test_group')
    hostvars = HostVars(loader=loader, hostname='test_host')

    # Test vars plugin
    plugin = vars_loader.get('test_vars_plugin')
    assert plugin is not None
    assert get_plugin_vars

# Generated at 2022-06-17 16:20:25.377688
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    host = Host(name='localhost')
    group = Group(name='group')

    assert get_vars_from_path(loader, '.', [host], 'inventory') == {}
    assert get_vars_from_path(loader, '.', [group], 'inventory') == {}

    vars_plugin = vars_loader

# Generated at 2022-06-17 16:20:36.333859
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.groupvars import GroupVars
    from ansible.vars.plugins.vars import VarsModule
    from ansible.vars.plugins.host_vars import HostVarsModule
    from ansible.vars.plugins.group_vars import GroupVarsModule

    # Create a fake inventory
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
   

# Generated at 2022-06-17 16:20:49.782220
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.plugins.vars import BaseVarsPlugin
    from ansible.utils.collection_loader import AnsibleCollectionRef

    class TestVarsPlugin(BaseVarsPlugin):
        def get_vars(self, loader, path, entities):
            return {'test_vars_plugin': 'test_vars_plugin'}

    class TestVarsPlugin2(BaseVarsPlugin):
        def get_vars(self, loader, path, entities):
            return {'test_vars_plugin2': 'test_vars_plugin2'}


# Generated at 2022-06-17 16:20:59.246984
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.common._collections_compat import Mapping

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugin'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    vars_plugin_list = list(vars_loader.all())

# Generated at 2022-06-17 16:21:05.943467
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test with stage set to 'inventory'
    data = get_vars_from_inventory_sources(loader, inventory.sources, inventory.hosts.values(), 'inventory')
    assert data['inventory_hostname'] == 'test_inventory_vars_plugins'
    assert data['inventory_hostname_short'] == 'test_inventory_vars_plugins'

# Generated at 2022-06-17 16:21:13.909455
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.groupvars import GroupVars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_manager'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test with vars_loader
    vars_loader.add(HostVars(variable_manager))
    vars_loader.add(GroupVars(variable_manager))

# Generated at 2022-06-17 16:21:25.982589
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.source import InventorySource
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    host = inventory.get_host('localhost')
    group = inventory.get_group('all')
    entities = [host, group]
    path = './test/integration/inventory_vars_plugins'
    stage

# Generated at 2022-06-17 16:21:34.420197
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugins
    from ansible.plugins.loader import vars_loader

    vars_plugin_list = list(vars_loader.all())
    for plugin_name in C.VARIABLE_PLUGINS_ENABLED:
        if AnsibleCollectionRef.is_valid_fqcr(plugin_name):
            vars_plugin = vars_loader.get(plugin_name)
            if vars_plugin is None:
                # Error if there's no play directory or the name is wrong?
                continue
            if vars_plugin not in vars_plugin_list:
                vars_plugin_list.append(vars_plugin)


# Generated at 2022-06-17 16:21:54.649166
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.vars.hostvars import HostVars
    from ansible.vars.groupvars import GroupVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import wrap_var

    loader = DataLoader()

# Generated at 2022-06-17 16:22:02.984930
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    inv = inv_manager.get_inventory()
    host = inv.get_host('test_host')
    group = inv.get_group('test_group')
    data = get_vars_from_path(loader, 'tests/inventory/test_inventory_vars_plugins', [host, group], 'inventory')
    assert data['test_host_var'] == 'test_host_var_value'
    assert data['test_group_var'] == 'test_group_var_value'


# Generated at 2022-06-17 16:22:10.214570
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin
    class TestPlugin(vars_plugin.VarsBase):
        def get_vars(self, loader, path, entities):
            return {'test_key': 'test_value'}

    loader = None
    plugin = TestPlugin()
    path = None
    entities = None
    assert get_plugin_vars(loader, plugin, path, entities) == {'test_key': 'test_value'}

# Generated at 2022-06-17 16:22:20.917564
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test with a vars plugin that has get_vars()
    plugin = vars_loader.get('test_vars_plugin')
    assert plugin is not None
    assert hasattr(plugin, 'get_vars')
    assert not hasattr(plugin, 'get_host_vars')
    assert not hasattr(plugin, 'get_group_vars')
    assert not hasattr(plugin, 'run')

   

# Generated at 2022-06-17 16:22:29.498522
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugin'])
    host = inventory.get_host('test_host')
    group = inventory.get_group('test_group')
    data = get_vars_from_path(loader, 'tests/inventory/test_inventory_vars_plugin', [host, group], 'inventory')
    assert data == {'test_host': 'test_host_value', 'test_group': 'test_group_value'}

# Generated at 2022-06-17 16:22:39.680266
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['test/unit/plugins/vars/inventory_vars_plugin/inventory'])
    host = inventory.get_host('host1')
    group = inventory.get_group('group1')
    entities = [host, group]
    path = 'test/unit/plugins/vars/inventory_vars_plugin/'
    stage = 'inventory'
    data = get_vars_from_path(loader, path, entities, stage)

# Generated at 2022-06-17 16:22:51.656186
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    host = inventory.get_host('localhost')

    # Test with a v2 plugin
    plugin = vars_loader.get('vars_plugin_test_v2')
    data = get_vars_from_path(loader, '.', [host], 'inventory')
    assert data == {'vars_plugin_test_v2': 'vars_plugin_test_v2'}

    # Test with a v1 plugin
    plugin = vars_loader.get('vars_plugin_test_v1')
    data = get_vars

# Generated at 2022-06-17 16:22:58.794167
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    from ansible.utils.vars import combine_vars
    from ansible.plugins.vars import BaseVarsPlugin
    from ansible.plugins.vars.host_group import HostGroupVars

# Generated at 2022-06-17 16:23:10.857582
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugin'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # test vars plugin
    plugin_name = 'test_vars_plugin'
    plugin = vars_loader.get(plugin_name)
    assert plugin is not None

    # test get_vars

# Generated at 2022-06-17 16:23:16.593756
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    host = inventory.get_host('host1')
    group = inventory.get_group('group1')
    path = 'tests/inventory/test_inventory_vars_plugins'

    data = get_vars_from_path(loader, path, [host], 'inventory')
    assert data == {'host_var': 'host1', 'group_var': 'group1', 'all_var': 'all'}


# Generated at 2022-06-17 16:23:52.009705
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugin'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    vars_plugin_list = list(vars_loader.all())

# Generated at 2022-06-17 16:24:02.816570
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test with a group
    group = inventory.groups['group1']
    group_vars = get_vars_from_inventory_sources(loader, inventory.sources, [group], 'inventory')
    assert group_vars['group_var'] == 'group_var_value'
    assert group_vars['group_var_file'] == 'group_var_file_value'

    # Test with a host
    host = inventory

# Generated at 2022-06-17 16:24:11.468930
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin_base
    class test_plugin(vars_plugin_base):
        def get_vars(self, loader, path, entities, cache=True):
            return {'test_key': 'test_value'}
    loader = vars_loader.get('test_plugin')
    plugin = loader.get('test_plugin')
    path = 'test_path'
    entities = ['test_entity']
    assert get_plugin_vars(loader, plugin, path, entities) == {'test_key': 'test_value'}


# Generated at 2022-06-17 16:24:17.778736
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/unit/inventory/test_inventory_vars_plugins'])
    host = inventory.get_host('test_host')
    group = inventory.get_group('test_group')

    vars_plugin_list = list(vars_loader.all())

# Generated at 2022-06-17 16:24:27.645944
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test with a single host
    host = inventory.get_host('host1')
    data = get_vars_from_path(loader, 'tests/inventory/test_inventory_vars_plugins', [host], 'inventory')
    assert data == {'test_inventory_vars_plugins': {'host1': {'host_var': 'host1'}}}

    # Test with a single group

# Generated at 2022-06-17 16:24:36.622797
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.plugins.vars import BaseVarsPlugin
    from ansible.utils.collection_loader import AnsibleCollectionRef

    class TestVarsPlugin(BaseVarsPlugin):
        def get_vars(self, loader, path, entities):
            return {'test': 'test'}

    vars_loader.add(AnsibleCollectionRef.from_string('test.test.test'), TestVarsPlugin)
    assert get_vars_from_path(None, '.', [], 'inventory') == {'test': 'test'}

# Generated at 2022-06-17 16:24:47.703380
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    host = inventory.get_host('localhost')

    # Test vars plugins
    vars_plugin_list = list(vars_loader.all())

# Generated at 2022-06-17 16:24:58.871178
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    vars_plugin_list = list(vars_loader.all())
    for plugin in vars_plugin_list:
        if plugin._load_name not in C.VARIABLE_PLUGINS_ENABLED and getattr(plugin, 'REQUIRES_WHITELIST', False):
            # 2.x plugins shipped with ansible should require whitelisting, older or non shipped should load automatically
            continue



# Generated at 2022-06-17 16:25:10.401822
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    host = inventory.get_host(name='test_inventory_vars_plugins')
    group = inventory.get_group(name='test_inventory_vars_plugins')
    data = {}
    data = combine_vars

# Generated at 2022-06-17 16:25:21.839886
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_hosts'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    vars_plugin_list = list(vars_loader.all())
    for plugin_name in C.VARIABLE_PLUGINS_ENABLED:
        if AnsibleCollectionRef.is_valid_fqcr(plugin_name):
            vars_plugin = vars_loader.get(plugin_name)

# Generated at 2022-06-17 16:26:23.778572
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.utils.path import unfrackpath
    import json
    import os
    import sys
    import shutil
    import temp

# Generated at 2022-06-17 16:26:35.497672
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test that vars plugins are loaded
    vars_plugins = vars_loader.all()
    assert len(vars_plugins) > 0

    # Test that vars plugins are loaded
    vars_plugins = vars_loader.all()
    assert len(vars_plugins) > 0

    # Test that vars plugins are loaded
    vars_plugins = vars_loader.all()

# Generated at 2022-06-17 16:26:48.811379
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inv_manager)

    # test vars plugin
    vars_plugin_list = list(vars_loader.all())

# Generated at 2022-06-17 16:26:58.475517
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['test/inventory/test_inventory_vars_plugin'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # test with host
    host = Host(name='testhost')
    host.vars = variable_manager.get_vars(host=host)
    assert host.vars['test_inventory_vars_plugin_host'] == 'testhost'