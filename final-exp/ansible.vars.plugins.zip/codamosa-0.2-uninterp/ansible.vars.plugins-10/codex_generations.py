

# Generated at 2022-06-17 16:17:18.638242
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin_base
    from ansible.plugins.loader import vars_loader

    class TestVarsPlugin(vars_plugin_base.VarsBase):
        def get_vars(self, loader, path, entities):
            return {'test_plugin': 'test_plugin_value'}

    vars_loader.add(TestVarsPlugin, 'test_vars_plugin')
    plugin = vars_loader.get('test_vars_plugin')
    data = get_plugin_vars(vars_loader, plugin, '', [])
    assert data == {'test_plugin': 'test_plugin_value'}

# Generated at 2022-06-17 16:17:27.193099
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = vars_loader
    path = './test/integration/inventory/test_inventory_vars_plugins/'
    entities = [Host('host1'), Group('group1')]
    stage = 'inventory'

    data = get_vars_from_path(loader, path, entities, stage)

    assert data == {'group1': {'group1_var': 'group1_value'}, 'host1': {'host1_var': 'host1_value'}}

# Generated at 2022-06-17 16:17:34.305016
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test with a host
    host = inventory.get_host('test_host')
    data = get_vars_from_path(loader, 'tests/inventory/test_inventory_vars_plugins', [host], 'inventory')
    assert data == {'test_host_var': 'test_host_var_value'}

    # Test with a group

# Generated at 2022-06-17 16:17:40.682713
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.handler import Handler

# Generated at 2022-06-17 16:17:50.224294
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['test/units/plugins/inventory/test_inventory_vars_plugin/hosts'])
    host = inventory.get_host("test_host")
    group = inventory.get_group("test_group")
    assert host.vars == {'test_host_var': 'test_host_value'}
    assert group.vars == {'test_group_var': 'test_group_value'}

# Generated at 2022-06-17 16:17:58.364906
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    sources = ['/etc/ansible/hosts']
    inventory = InventoryManager(loader=loader, sources=sources)
    entities = [inventory.get_group('all')]
    stage = 'inventory'
    data = get_vars_from_inventory_sources(loader, sources, entities, stage)
    assert data['ansible_ssh_user'] == 'root'

# Generated at 2022-06-17 16:18:06.299857
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test vars plugins
    vars_plugin_list = list(vars_loader.all())

# Generated at 2022-06-17 16:18:17.774508
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.hostvars import HostVars
    from ansible.vars.groupvars import GroupVars
    from ansible.vars.unsafe_proxy import UnsafeProxy

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['/dev/null'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    plugin = vars_loader.get('hostvars')

# Generated at 2022-06-17 16:18:23.593618
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin_base

    class TestPlugin(vars_plugin_base):
        def get_vars(self, loader, path, entities):
            return {'test': 'test'}

    plugin = TestPlugin()
    assert get_plugin_vars(None, plugin, None, None) == {'test': 'test'}

# Generated at 2022-06-17 16:18:28.233156
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin_base

    class TestVarsPlugin(vars_plugin_base):
        def get_vars(self, loader, path, entities):
            return {'test_key': 'test_value'}

    loader = None
    plugin = TestVarsPlugin()
    path = None
    entities = None

    assert get_plugin_vars(loader, plugin, path, entities) == {'test_key': 'test_value'}

# Generated at 2022-06-17 16:18:43.109682
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.hostvars import HostVarsGroupVars
    from ansible.vars.hostvars import HostVarsAllVars
    from ansible.vars.hostvars import HostVarsAllGroupVars
    from ansible.vars.hostvars import HostVarsAllGroupVarsAll
    from ansible.vars.hostvars import HostVarsAllGroupVarsAllAll

# Generated at 2022-06-17 16:18:47.736532
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin_base
    class TestVarsPlugin(vars_plugin_base):
        def get_vars(self, loader, path, entities):
            return {'test_key': 'test_value'}
    loader = vars_loader.get('TestVarsPlugin')
    plugin = TestVarsPlugin()
    plugin._load_name = 'TestVarsPlugin'
    plugin._original_path = 'TestVarsPlugin'
    path = 'TestVarsPlugin'
    entities = ['TestVarsPlugin']
    data = get_plugin_vars(loader, plugin, path, entities)
    assert data == {'test_key': 'test_value'}

# Generated at 2022-06-17 16:18:54.194769
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin_base
    from ansible.plugins.loader import vars_loader

    class TestVarsPlugin(vars_plugin_base.VarsBase):
        def get_vars(self, loader, path, entities):
            return {'test_var': 'test_value'}

    vars_loader.add(TestVarsPlugin, 'test_vars_plugin')
    assert get_plugin_vars(None, TestVarsPlugin(), None, None) == {'test_var': 'test_value'}

# Generated at 2022-06-17 16:19:04.942586
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugins
    from ansible.plugins.loader import vars_loader

    vars_plugin_list = list(vars_loader.all())
    for plugin_name in C.VARIABLE_PLUGINS_ENABLED:
        if AnsibleCollectionRef.is_valid_fqcr(plugin_name):
            vars_plugin = vars_loader.get(plugin_name)
            if vars_plugin is None:
                # Error if there's no play directory or the name is wrong?
                continue
            if vars_plugin not in vars_plugin_list:
                vars_plugin_list.append(vars_plugin)


# Generated at 2022-06-17 16:19:14.827146
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin_base
    class TestVarsPlugin(vars_plugin_base):
        def get_vars(self, loader, path, entities):
            return {'test_vars_plugin': True}

    class TestVarsPlugin2(vars_plugin_base):
        def get_host_vars(self, host):
            return {'test_vars_plugin2': True}

    class TestVarsPlugin3(vars_plugin_base):
        def get_group_vars(self, group):
            return {'test_vars_plugin3': True}

    class TestVarsPlugin4(vars_plugin_base):
        def run(self, host, vault_password=None):
            return {'test_vars_plugin4': True}

   

# Generated at 2022-06-17 16:19:19.802388
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin_base

    class TestVarsPlugin(vars_plugin_base):
        def get_vars(self, loader, path, entities):
            return {'test_var': 'test_value'}

    plugin = TestVarsPlugin()
    loader = None
    path = None
    entities = None
    assert get_plugin_vars(loader, plugin, path, entities) == {'test_var': 'test_value'}

# Generated at 2022-06-17 16:19:28.302085
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin_base
    class TestVarsPlugin(vars_plugin_base):
        def get_vars(self, loader, path, entities):
            return {'test_var': 'test_value'}

    loader = None
    plugin = TestVarsPlugin()
    path = None
    entities = []
    data = get_plugin_vars(loader, plugin, path, entities)
    assert data == {'test_var': 'test_value'}

# Generated at 2022-06-17 16:19:38.607589
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    vars_loader.add('test_vars_plugin', 'test_vars_plugin')
    vars_loader.add('test_vars_plugin2', 'test_vars_plugin2')
    vars_loader.add('test_vars_plugin3', 'test_vars_plugin3')
    vars_loader.add('test_vars_plugin4', 'test_vars_plugin4')
    vars_loader.add('test_vars_plugin5', 'test_vars_plugin5')

# Generated at 2022-06-17 16:19:50.406379
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    host = Host(name='localhost')
    host.vars = get_vars_from_path(loader, './test/units/plugins/vars/', [host], 'inventory')
    assert host.vars['test_vars_plugin_var'] == 'test_vars_plugin_var_value'

# Generated at 2022-06-17 16:20:00.655185
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test with a host
    host = Host(name="localhost")
    variable_manager.set_host_variable(host, 'foo', 'bar')
    variable_manager.set_host_variable(host, 'baz', 'qux')

# Generated at 2022-06-17 16:20:15.084993
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugin'])
    inv_manager.parse_sources()
    variable_manager = VariableManager(loader=loader, inventory=inv_manager)

    # Test that the vars plugin is loaded
    assert 'vars_plugin' in variable_manager.get_vars(host=inv_manager.get_host('test_host'))
    assert 'vars_plugin' in variable_manager.get_vars(host=inv_manager.get_host('test_host'), include_hostvars=True)

# Generated at 2022-06-17 16:20:21.686476
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars

    # Create a fake inventory
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    host = inventory.get_host('localhost')
    group = Group('all')
    group.add_host(host)
    inventory.add_group(group)

    # Create a fake variable manager
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Create a fake vars plugin
   

# Generated at 2022-06-17 16:20:26.974333
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin_base

    class TestPlugin(vars_plugin_base):
        def get_vars(self, loader, path, entities):
            return {'test_plugin': 'test_plugin'}

    loader = None
    plugin = TestPlugin()
    path = None
    entities = None

    result = get_plugin_vars(loader, plugin, path, entities)
    assert result == {'test_plugin': 'test_plugin'}

# Generated at 2022-06-17 16:20:37.424039
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin_base
    from ansible.plugins.loader import vars_loader
    from ansible.utils.collection_loader import AnsibleCollectionLoader

    class TestVarsPlugin(vars_plugin_base.VarsBase):
        def get_vars(self, loader, path, entities, cache=True):
            return {'test_vars_plugin': 'test_vars_plugin'}

    class TestVarsPlugin2(vars_plugin_base.VarsBase):
        def get_host_vars(self, host):
            return {'test_vars_plugin2': 'test_vars_plugin2'}


# Generated at 2022-06-17 16:20:46.465691
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin_base

    class TestVarsPlugin(vars_plugin_base):
        def get_vars(self, loader, path, entities):
            return {'test': 'test'}

    loader = None
    plugin = TestVarsPlugin()
    path = None
    entities = None
    assert get_plugin_vars(loader, plugin, path, entities) == {'test': 'test'}

# Generated at 2022-06-17 16:20:52.329072
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    inv_manager.parse_sources()
    host = inv_manager.get_host('test_host')
    group = inv_manager.get_group('test_group')
    data = get_vars_from_path(loader, 'tests/inventory/test_inventory_vars_plugins', [host, group], 'inventory')
    assert data == {'test_host': 'test_host', 'test_group': 'test_group'}

# Generated at 2022-06-17 16:20:57.799234
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin_base
    from ansible.plugins.loader import vars_loader

    class TestVarsPlugin(vars_plugin_base.VarsBase):
        def get_vars(self, loader, path, entities):
            return {'test_vars_plugin': True}

    vars_loader.add(TestVarsPlugin, 'test_vars_plugin')
    assert get_plugin_vars(None, TestVarsPlugin(), None, None) == {'test_vars_plugin': True}

# Generated at 2022-06-17 16:21:06.462551
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    host = inventory.get_host('localhost')
    group = inventory.get_group('all')

    vars_plugin_list = list(vars_loader.all())
    for plugin_name in C.VARIABLE_PLUGINS_ENABLED:
        if AnsibleCollectionRef.is_valid_fqcr(plugin_name):
            vars_plugin = vars_loader.get(plugin_name)
            if vars_plugin is None:
                # Error if there's no play directory or the name is wrong?
                continue
           

# Generated at 2022-06-17 16:21:13.279151
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin_base
    from ansible.plugins.loader import vars_loader

    class TestVarsPlugin(vars_plugin_base.VarsBase):
        def get_vars(self, loader, path, entities):
            return {'test_key': 'test_value'}

    vars_loader.add(TestVarsPlugin, 'test_vars_plugin')

    loader = None
    path = None
    entities = None
    plugin = vars_loader.get('test_vars_plugin')

    assert get_plugin_vars(loader, plugin, path, entities) == {'test_key': 'test_value'}

# Generated at 2022-06-17 16:21:20.170280
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    vars_plugin_list = list(vars_loader.all())
    for plugin in vars_plugin_list:
        if plugin._load_name not in C.VARIABLE_PLUGINS_ENABLED and getattr(plugin, 'REQUIRES_WHITELIST', False):
            # 2.x plugins shipped with ansible should require whitelisting, older or non shipped should load automatically
            continue

# Generated at 2022-06-17 16:21:49.419530
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.collection_loader import AnsibleCollectionRef
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test vars_plugins
    plugin_name = 'test_vars_plugin'
    plugin = vars_loader.get(plugin_name)
   

# Generated at 2022-06-17 16:21:59.721938
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.source import InventorySource
    from ansible.inventory.data import InventoryData
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    host = Host(name='localhost')
    group = Group(name='group')
    inventory.add_host(host)
    inventory.add_group(group)

   

# Generated at 2022-06-17 16:22:10.252374
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugin'])
    host = inventory.get_host('test_host')
    group = inventory.get_group('test_group')

    vars_plugin_list = list(vars_loader.all())

# Generated at 2022-06-17 16:22:20.918083
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader

    vars_plugin_list = list(vars_loader.all())
    for plugin_name in C.VARIABLE_PLUGINS_ENABLED:
        if AnsibleCollectionRef.is_valid_fqcr(plugin_name):
            vars_plugin = vars_loader.get(plugin_name)
            if vars_plugin is None:
                # Error if there's no play directory or the name is wrong?
                continue
            if vars_plugin not in vars_plugin_list:
                vars_plugin_list.append(vars_plugin)


# Generated at 2022-06-17 16:22:31.452889
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.utils.collection_loader import AnsibleCollectionRef
    from ansible.plugins.vars import BaseVarsPlugin


# Generated at 2022-06-17 16:22:40.632489
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    host = inventory.get_host('localhost')

    vars_plugin_list = list(vars_loader.all())
    for plugin in vars_plugin_list:
        if plugin._load_name not in C.VARIABLE_PLUGINS_ENABLED and getattr(plugin, 'REQUIRES_WHITELIST', False):
            # 2.x plugins shipped with ansible should require whitelisting, older or non shipped should load automatically
            continue

        has_stage = hasattr(plugin, 'get_option') and plugin.has_

# Generated at 2022-06-17 16:22:51.891573
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    vars_plugin_list = list(vars_loader.all())
    for plugin in vars_plugin_list:
        if plugin._load_name not in C.VARIABLE_PLUGINS_ENABLED and getattr(plugin, 'REQUIRES_WHITELIST', False):
            # 2.x plugins shipped with ansible should require whitelisting, older or non shipped should load automatically
            continue

        has

# Generated at 2022-06-17 16:23:02.609659
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.utils.collection_loader import AnsibleCollectionRef
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['test/integration/inventory_vars_plugins/hosts'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    host = inventory.get_host('host1')
    group = inventory.get_group('group1')
    data = {}
    data = combine_

# Generated at 2022-06-17 16:23:13.202547
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    host = inventory.get_host('localhost')
    group = inventory.get_group('all')
    entities = [host, group]

    vars_plugin_list = list(vars_loader.all())

# Generated at 2022-06-17 16:23:20.040445
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['test/integration/inventory'])

# Generated at 2022-06-17 16:23:50.770016
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['test/inventory'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-17 16:24:02.687349
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['/dev/null'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test with a v2 plugin
    plugin = vars_loader.get('test_vars_plugin')
    assert plugin is not None
    assert plugin.get_vars(loader, '/dev/null', []) == {'test_vars_plugin': 'test_vars_plugin'}

    # Test with a v1 plugin

# Generated at 2022-06-17 16:24:13.551229
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugin'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test with a group
    group = inventory.groups['group1']
    data = get_vars_from_path(loader, 'tests/inventory/test_inventory_vars_plugin', [group], 'inventory')
    assert data['group_var'] == 'group1'
    assert data['group_var_2'] == 'group1'

# Generated at 2022-06-17 16:24:25.872749
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory_vars_plugin'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # test with a host
    host = inventory.get_host('test_host')
    assert get_vars_from_path(loader, 'tests/inventory_vars_plugin', [host], 'inventory') == {'inventory_hostname': 'test_host', 'inventory_hostname_short': 'test_host'}

    # test with a group
    group = inventory.get_group('test_group')
    assert get_vars_from_path

# Generated at 2022-06-17 16:24:37.672323
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    host = inventory.get_host('test_host')
    group = inventory.get_group('test_group')

    # test get_vars_from_path
    vars_plugin_list = list(vars_loader.all())

# Generated at 2022-06-17 16:24:47.271908
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.plugins.vars import BaseVarsPlugin
    from ansible.utils.collection_loader import AnsibleCollectionRef

    class TestVarsPlugin(BaseVarsPlugin):
        def get_vars(self, loader, path, entities):
            return {'test_vars_plugin': 'test_vars_plugin'}

    vars_loader.add(TestVarsPlugin, 'test_vars_plugin')
    assert get_vars_from_path(None, '', None, None) == {}
    assert get_vars_from_path(None, '', None, 'inventory') == {'test_vars_plugin': 'test_vars_plugin'}
    assert get_vars_from_path(None, '', None, 'task')

# Generated at 2022-06-17 16:24:58.607598
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    sources = ['/etc/ansible/hosts']
    inventory = InventoryManager(loader=loader, sources=sources)
    entities = [inventory.get_host('localhost')]
    stage = 'inventory'
    data = get_vars_from_inventory_sources(loader, sources, entities, stage)
    assert data['inventory_dir'] == '/etc/ansible'
    assert data['inventory_file'] == '/etc/ansible/hosts'
    assert data['inventory_file_abs'] == '/etc/ansible/hosts'
    assert data['inventory_file_rel'] == 'hosts'

# Generated at 2022-06-17 16:25:10.238149
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    host = inventory.get_host('test_host')
    group = inventory.get_group('test_group')

    # Test that a plugin can be loaded from a collection
    plugin = vars_loader.get('test_collection.test_vars_plugin')
    assert plugin is not None
    assert plugin.get_vars(loader, 'tests/inventory/test_inventory_vars_plugins', [host]) == {'test_collection_var': 'test_collection_value'}

    # Test that a

# Generated at 2022-06-17 16:25:21.704050
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test for host
    host = Host(name='localhost')
    host.vars = get_vars_from_path(loader, './test/units/plugins/vars/', [host], 'inventory')
    assert host.vars['test_var'] == 'test_value'

    # Test for group
    group = Group

# Generated at 2022-06-17 16:25:33.061262
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test get_vars_from_path with a host
    host = inventory.get_host('host1')
    assert host.vars == get_vars_from_path(loader, 'tests/inventory/test_inventory_vars_plugins', [host], 'inventory')

    #

# Generated at 2022-06-17 16:26:17.728034
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.source import InventorySource
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    host = Host(name='localhost')
    group = Group(name='group')
    inventory.add_host(host)
    inventory.add_group(group)
    inventory.add_child('group', host)
   

# Generated at 2022-06-17 16:26:25.792739
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_vars_plugins'])
    host = inventory.get_host('test_host')
    group = inventory.get_group('test_group')
    data = get_vars_from_path(loader, 'tests/inventory/test_inventory_vars_plugins', [host, group], 'inventory')
    assert data['test_host_var'] == 'test_host_var_value'
    assert data['test_group_var'] == 'test_group_var_value'

# Generated at 2022-06-17 16:26:31.276402
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import test_vars_plugin
    loader = None
    plugin = test_vars_plugin.TestVarsPlugin()
    path = '/path/to/somewhere'
    entities = ['foo', 'bar']
    assert get_plugin_vars(loader, plugin, path, entities) == {'foo': 'bar'}


# Generated at 2022-06-17 16:26:41.423296
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    host = inventory.get_host('localhost')

    # test vars plugin
    vars_plugin = vars_loader.get('vars_plugin')
    vars_plugin.get_vars = lambda x, y, z: {'vars_plugin': True}
    vars_plugin.get_host_vars = lambda x: {'vars_plugin': True}
    vars_plugin.get_group_vars = lambda x: {'vars_plugin': True}

    # test vars plugin v2
    vars_plugin

# Generated at 2022-06-17 16:26:50.527919
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.groupvars import GroupVars
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.unsafe_proxy import wrap_var

    # Create a fake inventory
    inventory = InventoryManager(loader=DataLoader(), sources=['localhost,'])
    host = Host(name='localhost')
    group = Group(name='group')
    inventory.add_host(host)


# Generated at 2022-06-17 16:26:58.674383
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    host = Host(name='localhost')
    group = Group(name='group')
    path = './'
    entities = [host, group]
    stage = 'inventory'
    vars_plugin_list = list(vars_loader.all())