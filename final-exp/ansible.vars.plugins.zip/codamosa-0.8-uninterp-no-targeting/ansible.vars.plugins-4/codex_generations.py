

# Generated at 2022-06-21 09:37:56.742932
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    class Foo:
        _load_name = 'foo'
        _original_path = 'foo/foo.py'

        def get_vars(self, loader, path, entities):
            return {'a': 1}

        def get_host_vars(self, host):
            return {'b': 2}

        def get_group_vars(self, group):
            return {'c': 3}

    class Bar:
        # vars plugin 2.0
        _load_name = 'bar'
        _original_path = 'bar/bar.py'

        def get_vars(self, loader, path, entities):
            return {'d': 4}

    class Baz:
        # vars plugin 1.0
        _load_name = 'baz'

# Generated at 2022-06-21 09:38:05.899602
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.plugins.vars.vars_files import VarsModule

    vars_data = {
        'a': 'b',
        'foo': 'bar',
        'list': [1, 2, 3]
    }
    path = '/fake/path'
    vars_plugin = VarsModule(path)
    vars_plugin.vars = vars_data

    assert get_vars_from_path(vars_plugin, path, [], 'task') == vars_data

    vars_loader._plugins = {'VarsModule': vars_plugin}
    assert get_vars_from_path(vars_loader, path, [], 'task') == vars_data

# Generated at 2022-06-21 09:38:06.525144
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    pass

# Generated at 2022-06-21 09:38:10.822422
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    vars_plugin_list = list(vars_loader.all())
    for plugin in vars_plugin_list:
        if plugin._load_name not in C.VARIABLE_PLUGINS_ENABLED:
            continue
        print(plugin._load_name)

# Generated at 2022-06-21 09:38:17.561739
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    # Given
    source_paths = ('/path/to/inventory-sources', '/path/to/other/source')
    entities = [Host('fake.example.com'), Host('another.example.com')]
    mock_loader = MockLoader()

    # When
    result = get_vars_from_inventory_sources(mock_loader, source_paths, entities, 'task')

    # Then
    for host in entities:
        assert 'fake_host_vars' in result[host.name]
        assert result[host.name]['fake_host_vars'] == host.get_vars()
        assert 'fake_group_vars' in result[host.name]
        assert result[host.name]['fake_group_vars'] == host.get_group_vars()


# Unit

# Generated at 2022-06-21 09:38:26.842684
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.vars.clean import clean_facts
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.reserved import is_reserved_name
    from ansible.module_utils._text import to_text
    from ansible.parsing.dataloader import DataLoader

    display = Display()
    loader = DataLoader()

    vars_plugin_list = list(vars_loader.all())

    # test the host_name vars plugin
    vmware_host_vars = {u'hostname': u'vmware'}
    vmware_host_vars = clean_facts(vmware_host_vars, loader=loader, filter_internal=True)

# Generated at 2022-06-21 09:38:31.179894
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    loader = 'Test'

    get_vars_from_path(loader, './', [], 'inventory')

    # os.path.isdir(to_bytes(path))
    get_vars_from_path(loader, 'test/test_vars.py', [], 'inventory')



# Generated at 2022-06-21 09:38:41.381913
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    class FakePlugin:
        def get_vars(self, loader, path, entities):
            return {"var": "val"}

    class FakeHost:
        def __init__(self, name):
            self.name = name

    class FakeGroup:
        def __init__(self, name):
            self.name = name

    loader = {}
    host = FakeHost("localhost")
    group = FakeGroup("all")
    path = "path"
    ret = get_plugin_vars(loader, FakePlugin(), path, [host, group])
    assert ret == {"var": "val"}

    class FakePlugin1:
        def get_host_vars(self, host):
            return {"host": host}

        def get_group_vars(self, group):
            return {"group": group}

    ret = get_

# Generated at 2022-06-21 09:38:45.759781
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    loader = vars_loader
    sources = 'temp/dc1.ini'
    has_stage = hasattr(loader, 'get_option') and loader.has_option('stage')
    entities = {'all'}
    stage = 'inventory'
    data = get_vars_from_inventory_sources(loader, sources, entities, stage)
    assert data == {}

# Generated at 2022-06-21 09:38:54.323291
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    loader = vars_loader
    plugin = vars_loader.get('group_vars')
    path = '.'
    entities = ['example.com']

    data = get_plugin_vars(loader, plugin, path, entities)
    assert data == {'ansible_user': 'jack', 'random_var': 'random value'}

    plugin = vars_loader.get('host_vars')
    data = get_plugin_vars(loader, plugin, path, entities)
    assert data == {u'ansible_host': u'127.0.1.1', u'ansible_port': u'2222'}


# Generated at 2022-06-21 09:39:05.040334
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    vars_plugin_list = list(vars_loader.all())
    assert get_plugin_vars(None, vars_plugin_list[0], None, None) == {}



# Generated at 2022-06-21 09:39:08.223697
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Test for no data
    assert get_vars_from_path(None, None, ['a'], None) == {}

    # Test for no entities
    assert get_vars_from_path(None, None, None, None) == {}

# Generated at 2022-06-21 09:39:17.781679
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.plugins.loader import inventory_loader

    # inventory_sources is a list of directories containing dynamic inventory sources.
    inventory_sources = ['/home/yugantar/ansible/test/inventory']
    loader = inventory_loader.get('auto')
    entity_list = []
    entity_list.append(Host('localhost'))
    print('vars:', get_vars_from_inventory_sources(loader, inventory_sources, entity_list, 'inventory'))

#test_get_vars_from_inventory_sources()

# Generated at 2022-06-21 09:39:28.287323
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    class VarsPluginFake(object):
        def get_vars(self, loader, path, entities):
            return {'test': 'test'}

    class PluginLoaderFake(object):
        def __init__(self):
            self.all = lambda: [VarsPluginFake()]

    class DataLoaderFake(PluginLoaderFake):
        def __init__(self):
            super(DataLoaderFake, self).__init__()
            self.get = lambda name: VarsPluginFake()

    class VarsLoaderFake(PluginLoaderFake):
        pass

    class PluginLoader(object):
        def __init__(self):
            self.vars_loader = VarsLoaderFake()
            self.data_loader = DataLoaderFake()

    loader = PluginLoader()


# Generated at 2022-06-21 09:39:39.903288
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    loader, inventory, variable_manager = _prepare_test_setup()

    plugin = Test_v2_plugin()
    plugin.set_option('stage', 'inventory')

    path = './test/test_playbooks/playbook/'
    entities = [Host('testhost', variable_manager=variable_manager, get_group_vars=fake_get_group_vars)]

    data = {}
    data = combine_vars(data, get_plugin_vars(loader, plugin, path, entities))

    assert data['a'] == 1
    assert data['b'] == [1, 2]
    assert data['c'] == {'a': 1, 'b': 2}
    assert data['d'] == 'host'
    assert data['e'] == {'a': 1, 'b': 2}

# Generated at 2022-06-21 09:39:44.938572
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    '''Return a vars plugin that is valid on its own'''

    # The loader and plugin are not used in this call
    class plugin():
        def get_vars(loader, path, entities):
            return {'a': 1}

    return plugin

# Generated at 2022-06-21 09:39:48.577030
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    # Test setup
    assert get_vars_from_inventory_sources(None, ['/test/path', '/test/path,localhost'], ['localhost'], 'inventory') == {}
    # Test function
    assert get_vars_from_inventory_sources(None, ['/test/path'], ['localhost'], 'inventory') == {}

# Generated at 2022-06-21 09:40:00.427261
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    from ansible.plugins.loader import vars_loader

    plugin_list = list(vars_loader.all())
    for plugin_name in C.VARIABLE_PLUGINS_ENABLED:
        if AnsibleCollectionRef.is_valid_fqcr(plugin_name):
            vars_plugin = vars_loader.get(plugin_name)
            if vars_plugin is None:
                # Error if there's no play directory or the name is wrong?
                continue
            if vars_plugin not in plugin_list:
                plugin_list.append(vars_plugin)


# Generated at 2022-06-21 09:40:12.586150
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    import tempfile
    import shutil

    def setup_fake_var_plugins():
        v2_plugin_dir = tempfile.mkdtemp()
        v2_plugin_file = os.path.join(v2_plugin_dir, '__init__.py')
        with open(v2_plugin_file, 'wb') as f:
            f.write(b'#!/bin/python\n')
            f.write(b'\n')
            f.write(b'def get_vars(loader, path, entities):\n')
            f.write(b'  return dict(a=1)\n')
        return v2_plugin_dir

    def cleanup_fake_var_plugins(plugin_dir):
        shutil.rmtree(plugin_dir)


# Generated at 2022-06-21 09:40:24.195802
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    class VarsPlugin():
        """
        A test class to test get_plugin_vars function
        """
        def __init__(self):
            self._load_name = 'test_vars_plugin'
            self._original_path = '/test/path'
            self.finished = False

        def get_vars(self, loader, path, entities):
            return {'test': 'get_vars'}

        def get_host_vars(self, host):
            return {'test': 'get_host_vars'}

    class NoHostVarsPlugin():
        """
        A test class to test get_plugin_vars function
        """
        def __init__(self):
            self._load_name = 'no_host_vars_plugin'

# Generated at 2022-06-21 09:40:36.068064
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins import vars_sources
    plugin = vars_sources.get("test_vars_file")
    class DummyLoader(object):
        def get_basedir(self):
            return '.'
    loader = DummyLoader()
    assert get_plugin_vars(loader, plugin, os.path.join('test', 'data', 'vars_plugins'), {}) == {'x': 'y1', 'y': True}

# Generated at 2022-06-21 09:40:43.394864
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    my_vars_plugin_class = type('testVarsPlugin', (object,),
                                dict(get_vars=lambda: dict(answer=42)))
    C.VARIABLE_PLUGINS_ENABLED.append('testVarsPlugin')
    vars_loader.add('testVarsPlugin', my_vars_plugin_class)
    ans = get_plugin_vars(None, my_vars_plugin_class(), None, [])
    try:
        assert ans == dict(answer=42)
    finally:
        vars_loader.remove('testVarsPlugin')
        C.VARIABLE_PLUGINS_ENABLED.pop()



# Generated at 2022-06-21 09:40:54.576252
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    """
    This unit test was for the following issue:

    - https://github.com/ansible/ansible/issues/53964
    """
    from ansible.plugins.loader import vars_loader
    from ansible.utils import context_objects as co
    from ansible.vars.manager import VarManager
    from ansible.inventory.manager import InventoryManager
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop as mock_unfrackpath

    # inventory_dir needs to be kept in sync with the vars plugin code
    inventory_dir = os.path.expanduser('~/.ansible/test_vars_inventory')
    os.makedirs(inventory_dir, exist_ok=True)

    inventory_source = os.path

# Generated at 2022-06-21 09:41:01.065476
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    """
    Some plugins implement 'get_vars' (which is called directly), while others implement
    'get_host_vars' and 'get_group_vars' (which are called for each inventory entity separately).
    In the latter case, the function returns a dict for each entity, which is grouped together.
    """
    from ansible.plugins.vars import VarsBase

    # Example data from plugins

# Generated at 2022-06-21 09:41:12.588093
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    plugin_list = [
        {
            '_load_name': 'fake_vars',
            '_original_path': 'test/test-plugins/test_vars_plugin.py'
        }
    ]
    path = 'test/test-plugins/test-vars-plugin-data'
    entities = ['test_host']
    stage = 'inventory'
    loader = 'test_loader'

    assert get_vars_from_path(loader, path, entities, stage) == {
        '_from': 'fake_vars',
        'from_path': 'test/test-plugins/test-vars-plugin-data',
        '_plugin': 'test_vars_plugin',
        'plugin_path': 'test/test-plugins/test_vars_plugin.py'
    }


# Unit

# Generated at 2022-06-21 09:41:25.044973
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    # create vars_plugin list
    vars_plugin_list = list(vars_loader.all())
    for plugin_name in C.VARIABLE_PLUGINS_ENABLED:
        if AnsibleCollectionRef.is_valid_fqcr(plugin_name):
            vars_plugin = vars_loader.get(plugin_name)
            if vars_plugin not in vars_plugin_list:
                vars_plugin_list.append(vars_plugin)

    # create inventory sources list
    inventory_sources = ['a', 'b', 'c/d']

    # create loader object
    loader = None

    # create entities list
    entities = ['a', 'b']

    # create stage name
    stage = 'inventory'

    # create data object
    data = {}

    # get_

# Generated at 2022-06-21 09:41:32.742187
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    loader = None
    sources = ['test/test_data/test_vars_plugins/inventory_sources/inventory_source_test_1',
               'test/test_data/test_vars_plugins/inventory_sources/inventory_source_test_2']
    entities = ['test_host']
    stage = 'inventory'
    data = get_vars_from_inventory_sources(loader, sources, entities, stage)
    assert data.get('var_one') == 'value_one'
    assert data.get('var_two') == 'value_two'
    assert data.get('var_three') == 'value_three'

# Generated at 2022-06-21 09:41:42.173439
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    def get_host_vars(host_name):
        return {host_name: host_name}

    def get_group_vars(group_name):
        return {group_name: group_name}

    class C:
        pass

    class D:
        pass

    # Case: plugin with get_vars method
    def get_vars(loader, path, entities):
        return {"case_ok": "case_ok"}

    C.get_vars = get_vars
    C._load_name = 'name'
    C._original_path = 'path'

    result = get_plugin_vars(None, C, None, [])
    assert result == {"case_ok": "case_ok"}

    # Case: plugin with get_host_vars and get_group_vars methods

# Generated at 2022-06-21 09:41:49.987018
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.inventory.host import Host
    from ansible.plugins import vars_plugins
    from ansible.plugins.loader import vars_loader
    vars_loader.add("test_get_plugin_vars", vars_plugins.TestGetPluginVars)
    test_plugin = vars_loader.get("test_get_plugin_vars")
    data = get_plugin_vars(vars_loader, test_plugin, "/tmp", ['foo', Host("test")])
    assert data == {'var': 'foo'}

# Generated at 2022-06-21 09:41:59.067821
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    class fake_loader:
        def __init__(self):
            self.collection_loader = AnsibleCollectionRef.from_string("community.general")

    test_loader = fake_loader()
    test_path = os.path.abspath(".")
    test_entities = []

    # no errors
    get_plugin_vars(test_loader, vars_loader.get("community.general.get_url_file"), test_path, test_entities)

    # Can't use v1 style plugin
    try:
        get_plugin_vars(test_loader, vars_loader.get("ansible.builtin.set_fact"), test_path, test_entities)
        assert False, "AnsibleError exception was not raised"
    except AnsibleError:
        assert True
    # Invalid plugin
   

# Generated at 2022-06-21 09:42:21.202448
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    loader = None
    path = '/root/ansible/collections/ansible_collections/test/test_ns/plugins/vars/'
    entities = []

# Generated at 2022-06-21 09:42:31.918722
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import Auto
    class test_plugin(Auto):
        def get_vars(self, loader, path, entities, cache=True):
            return {'run_get_vars': True}

        def get_host_vars(self, host):
            return {'run_get_host_vars': True}

        def get_group_vars(self, group):
            return {'run_get_group_vars': True}

    loader = object()
    plugin = test_plugin(plugin_name='test_plugin_name', config=dict())

    # Testing with get_vars method
    entities = []
    data = get_plugin_vars(loader, plugin, os.getcwd(), entities)
    assert data == {'run_get_vars': True}

    #

# Generated at 2022-06-21 09:42:43.789615
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    # Set up fake objects for use in testing
    class FakeVarsPlugin:
        _load_name = 'fakevarsplugin'
        def get_vars(self, loader, path, entities):
            return {'fake_vars_plugin_vars': 1}

    class FakeVarsPlugin2:
        _load_name = 'fakevarsplugin2'
        def get_vars(self, loader, path, entities):
            return {'fake_vars_plugin_2_vars': 2}

    class FakeVarsPlugin3:
        _load_name = 'fakevarsplugin3'
        def get_host_vars(self, name):
            return {'fake_vars_plugin_3_vars': 3}


# Generated at 2022-06-21 09:42:46.187451
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    import yaml
    assert get_vars_from_path(None, None, None, None) == {}



# Generated at 2022-06-21 09:42:47.201297
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # todo
    pass

# Generated at 2022-06-21 09:42:57.219425
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    assert '/usr/share/ansible/plugins/vars' not in C.DEFAULT_CUSTOM_VARS_PLUGIN_PATH
    assert '/usr/share/ansible/plugins/vars' in C.CUSTOM_VARS_PLUGIN_PATH

    # test using built-in config
    # this is the same as what would be done in a start or demand vars plugin
    entities = [Host('testhost')]
    data = get_vars_from_path('loader', '/usr/share/ansible/plugins/vars', entities, 'inventory')
    assert data['testhost'] == 'test'

    # test for plugins installed by other methods
    # test for custom vars plugin path
    # this is the same as what would be done in a start or demand vars plugin

# Generated at 2022-06-21 09:43:00.740999
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    assert get_vars_from_inventory_sources(
        loader=None,
        sources=['my_hosts'],
        entities=['my_host'],
        stage='all'
    ) == {}


# Generated at 2022-06-21 09:43:02.464046
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert get_vars_from_path('loader', 'path', 'entities', 'stage') == {}

# Generated at 2022-06-21 09:43:07.395946
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    loaders = []
    display.display = []
    import ansible.plugins.vars.test_plugin_v2
    vars_plugin_path = ansible.plugins.vars.test_plugin_v2.__path__[0]
    data = get_vars_from_path(loaders, vars_plugin_path, [], '')
    assert 'key' in data
    assert data['key'] == 'value'
    assert display.display == ['called_1', 'called_2']

# Generated at 2022-06-21 09:43:11.386676
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # ensure that at least one vars plugin is installed
    assert C.VARIABLE_PLUGINS_ENABLED is not None
    assert len(C.VARIABLE_PLUGINS_ENABLED) > 0

    # verify that the vars template plugin is installed
    assert 'template' in C.VARIABLE_PLUGINS_ENABLED


# Generated at 2022-06-21 09:43:38.033147
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import vars_loader
    from ansible.plugins.vars import IniVars
    from ansible.vars import combine_vars

    loader = DataLoader()

    plugin = vars_loader.get('IniVars')
    path = os.path.join(os.path.dirname(__file__), '..', '..', 'data', 'vars_plugin_data', 'ini_vars')

# Generated at 2022-06-21 09:43:40.621759
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    res = get_plugin_vars('loader', 'plugin', 'path', 'entities')
    assert res == {}

# Generated at 2022-06-21 09:43:49.066308
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    # Load a simple plugin
    vars_loader.add_directory(os.path.join(os.path.dirname(__file__), '../module_utils/plugins/vars'))

    loader = vars_loader

    host = Host("foo")
    host.set_variable("simple_plugin_var", "foo")

    entities = [host]
    sources = ['test_vars', '/not/a/real/path']

    # Now that we have a loader, test the function.

    data = get_vars_from_inventory_sources(loader, sources, entities, "host")

    assert data == {'simple_plugin_var': 'foo'}



# Generated at 2022-06-21 09:43:59.402818
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager


# Generated at 2022-06-21 09:44:09.711514
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.loader import vars_loader
    from ansible.plugins.vars import test_vars

    plugin = test_vars.TestVarsPlugin()
    loader = vars_loader
    path = 'some/path'

    # Test handling of v2 plugins
    data = get_plugin_vars(loader, plugin, path, ['one'])
    assert data == {'one': {'test': 'a'}}

    # Test handling of v1 plugins
    plugin = test_vars.TestVarsPluginLegacy()
    data = get_plugin_vars(loader, plugin, path, ['one'])
    assert data == {'one': {'legacy': 'leg'}}

# Generated at 2022-06-21 09:44:21.416710
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    # We don't have any vars plugins loaded at this point, but some of the tests should succeed anyway.
    sources = [None, '~/nonexistent.txt', '~/nonexistent.txt,~/nonexistent2.txt', '~/foo/bar']
    entities = [Host('localhost'), Host('otherhost'), Host('localhost'), Host('localhost')]
    assert get_vars_from_inventory_sources(None, sources, entities, 'inventory') == {}
    assert get_vars_from_inventory_sources(None, sources, entities, 'task') == {}
    assert get_vars_from_inventory_sources(None, sources, entities, 'setup') == {}
    assert get_vars_from_inventory_sources(None, sources, entities, 'teardown') == {}
    assert get_

# Generated at 2022-06-21 09:44:30.562167
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    # Create a fake plugin to test get_plugin_vars
    class FakePlugin:
        def get_vars(self, loader, path, entities):
            return {'a': 1}

        def get_host_vars(self, host):
            return {'b': 2}
        def get_group_vars(self, host):
            return {'c': 3}

    plugin = FakePlugin()

    fake_loader = 'fake_loader'

    # Prepare fake entities
    fake_path = 'fake_path'
    fake_entities = [
        'fake_entity_1',
        'fake_entity_2',
    ]

    # Get plugin variables and check return results
    plugin_vars = get_plugin_vars(fake_loader, plugin, fake_path, fake_entities)

# Generated at 2022-06-21 09:44:42.730803
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    class A:
        def get_vars(self, loader, path, entities):
            return {"a":"value"}

    class B:
        def get_host_vars(self, host):
            return {"b":"value"}

    class C:
        def get_group_vars(self, group):
            return {"c":"value"}

    class D:
        def get_host_vars(self, host):
            return {"d":"value"}

        def get_group_vars(self, group):
            return {"d":"value"}

    class E:
        def get_vars(self, loader, path, entities):
            return {"e":"value"}

        def get_host_vars(self, host):
            return {"e":"value"}

        def get_group_vars(self, group):
            return

# Generated at 2022-06-21 09:44:52.807145
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars.host_group_vars import VarsModule as HostGroupVarsModule
    from ansible.plugins.vars.host_vars import VarsModule as HostVarsModule
    from ansible.inventory.host import Host
    from ansible.utils.collection_loader import AnsibleCollectionLoader

    loader = AnsibleCollectionLoader()

    plugin_vars = get_plugin_vars(loader, HostGroupVarsModule(), '/foo/bar', [])
    assert isinstance(plugin_vars, dict)
    assert not plugin_vars

    plugin_vars = get_plugin_vars(loader, HostGroupVarsModule(), '/foo/bar', [Host('ham'), Host('eggs')])
    assert isinstance(plugin_vars, dict)
    assert not plugin_vars

    plugin_

# Generated at 2022-06-21 09:45:03.557487
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    import sys
    test_plugin_path = '/usr/share/ansible_plugins/vars/test_plugin.py'

    test_class = type('test_class', (object,), {'_load_name': 'test_plugin.py', '_original_path': test_plugin_path})
    test_plugin = test_class()
    test_entity = type('test_entity', (object,), {'name': 'test_entity'})
    test_entity.__module__ = test_entity.__class__.__name__

    # test the get_vars function
    test_plugin.get_vars = lambda x, y, z: 'test_vars'
    assert get_plugin_vars(None, test_plugin, None, None) == 'test_vars'

    # test the get_host_

# Generated at 2022-06-21 09:45:52.007945
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    import ansible.plugins.loader as ploader
    import ansible.plugins.vars.host_list as hl
    import ansible.plugins.vars.yaml as yaml
    from ansible.module_utils._text import to_text

    loader = ploader.get("vars")
    ploader.add_directory(os.path.join(os.path.dirname(__file__), 'fixtures/vars_plugin_loader'), with_subdir=True)

    # Testing VARIABLE_PLUGINS_ENABLED and C.RUN_VARS_PLUGINS
    C.VARIABLE_PLUGINS_ENABLED = ['yaml']
    C.RUN_VARS_PLUGINS = 'demand'

# Generated at 2022-06-21 09:46:02.828317
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    import unittest2 as unittest
    from ansible.compat.tests.mock import patch
    from ansible.module_utils import basic

    class Test_get_vars_from_path(unittest.TestCase):
        ''' test that function get_vars_from_path returns expected variables '''
        def test_get_vars_from_path(self):
            # Monkeypatch get_vars(loader, path, entities) so that it returns the path
            # This is so that we can verify that the inventory plugin is called correctly
            def get_vars_func(loader, path, entities):
                return path
            get_vars_func_mon = patch.object(basic.AnsibleModule, 'get_vars')

            # Monkeypatch _remove_internal_keys(data) so that it returns


# Generated at 2022-06-21 09:46:12.401517
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    class test_vars_plugin():
        _load_name = 'test_get_plugin_vars'

        def get_vars(self, loader, path, entities):
            return {'test_vars_plugin_get_vars': 'test_vars_plugin_get_vars_true'}

        def get_group_vars(self, group):
            return {'test_vars_plugin_get_group_vars': 'test_vars_plugin_get_group_vars_true'}

        def get_host_vars(self, host):
            return {'test_vars_plugin_get_host_vars': 'test_vars_plugin_get_host_vars_true'}

    class host():
        name = 'test_host1'


# Generated at 2022-06-21 09:46:22.253208
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.inventory.host import Host
    from ansible.plugins.vars.custom_vars import vars_plugin as custom_vars_plugin
    from ansible.plugins.vars.custom_vars import VariableManager
    vm = VariableManager()
    p = custom_vars_plugin(vm, "plugin_name", "plugin_path")
    loader = "loader"
    path = "path"
    h = Host("test_host", "group1")
    g = Host("group1")
    entities = [h, g]
    assert get_plugin_vars(loader, p, path, entities) == {}
    data = {'test1': 'test1', 'test2': 'test2', 'test3': 'test3'}

# Generated at 2022-06-21 09:46:31.600012
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    # get_plugin_vars(loader, plugin, path, entities)

    # Here we will fake the loader and plugin objects
    class FakePlugin():
        def get_vars(self, loader, path, entities):
            return {'my_var': 'my_val'}

    class FakeLoader():
        pass

    # Here we will fake the Host and Group objects
    class FakeEntity():
        def __init__(self, name):
            self.name = name

    test_plugin = FakePlugin()
    test_loader = FakeLoader()
    test_entity = FakeEntity('my_entity')

    expected_results = {'my_var': 'my_val'}
    results = get_plugin_vars(test_loader, test_plugin, '/some/path', [test_entity])
    assert expected_results == results



# Generated at 2022-06-21 09:46:42.743755
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import test_vars_plugin

    entities = ['test_host']
    l = FakeLoader()
    p = test_vars_plugin.TestVarsModule()
    path = '/path/to/inventories/dir'

    data = get_plugin_vars(l, p, path, entities)
    assert sorted(data.keys()) == [u'file_vars', u'group_vars', u'host_vars', u'vars']
    assert data['file_vars']['test_key'] == path
    assert data['group_vars']['test_key'] == [u'test_host']
    assert data['host_vars']['test_key'] == u'test_host'

# Generated at 2022-06-21 09:46:43.354585
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    assert get_vars_from_path(None, None, None, None) == {}

# Generated at 2022-06-21 09:46:46.825556
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    class MockLoader(object):
        test = None

    loader = MockLoader()
    sources = ['test/test/test', MockLoader]
    entities = ['test/test/test']
    stage = 'inventory'
    data = get_vars_from_inventory_sources(loader, sources, entities, stage)
    assert(data == {'test': 'test'})

# Generated at 2022-06-21 09:46:54.094558
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    class TestPlugin(object):
        def get_vars(self, loader, path, entities):
            return {'var_test': 'test_var'}

    plugin = TestPlugin()
    loader = 'test_loader'

    path = '/fake/path'
    entities = 'test_entities'

    data = get_plugin_vars(loader, plugin, path, entities)

    assert data == {'var_test': 'test_var'}

# Generated at 2022-06-21 09:47:05.051513
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    import ansible.plugins.loader
    import ansible.plugins.vars
    import ansible.vars.manager

    test_vars = [
        'a: 1',
    ]

    vars_loader = ansible.plugins.loader.vars_loader
    vars_loader.add("a_plugin", ansible.plugins.vars.a_plugin.VarsModule())
    vars_loader.add("b_plugin", ansible.plugins.vars.b_plugin.VarsModule())

    # test that plugin b doesn't run if global run_vars_plugins is set to start
    C.RUN_VARS_PLUGINS = 'start'
    sources = ['/tmp/test_get_vars_from_inventory_sources/inventory']
    assert ansible.vars.manager.get_v