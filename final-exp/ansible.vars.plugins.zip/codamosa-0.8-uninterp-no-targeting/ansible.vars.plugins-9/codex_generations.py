

# Generated at 2022-06-21 09:38:01.721754
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    inv = os.path.join(C.DEFAULT_LOCAL_TMP, 'foo')
    with open(inv, 'w') as f:
        f.write("[foobar]\n")
        f.write("foo ansible_port=43 ansible_user=root\n")
        f.write("bar ansible_port=443\n")

    h = Host("foo")
    h.vars = dict()
    g = h.get_group("foobar")
    g.vars = dict()
    loader = DictDataLoader({inv: ""})
    vars = get_vars_from_inventory_sources(loader, [inv], [h], "play")
    assert g.vars == dict()
    assert h.vars == dict()
    assert vars == dict()

    vars

# Generated at 2022-06-21 09:38:07.460791
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    from ansible.module_utils.common.collections import ImmutableDict

    loader = None
    sources = ['/tmp/ansible-inventory-dir/']
    entities = [Host('example-1'), Host('example-2')]
    stage = 'inventory'
    data = get_vars_from_inventory_sources(loader, sources, entities, stage)

    assert data == ImmutableDict({})



# Generated at 2022-06-21 09:38:16.112700
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.cli.playbook import PlaybookCLI
    from ansible.parsing.dataloader import DataLoader

    dl = DataLoader()
    pb = PlaybookCLI(
        [
            '-i',
            '../../../test/integration/inventory/hosts.yml',
            '--extra-vars',
            '@../../../test/integration/inventory/host_vars/host0.yml',
            '--extra-vars',
            '@../../../test/integration/inventory/group_vars/group0.yml',
            '../../../test/integration/inventory/test_vars_plugin.yml'
        ],
        runas_pass=None
    )
    pb.parse()
    loader = pb._loader
   

# Generated at 2022-06-21 09:38:20.897797
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    from ansible.utils.collection_loader import AnsibleCollectionLoader

    loader = AnsibleCollectionLoader()
    path = '/tmp/a_collection_path'
    entities = {'toto': 'titi'}
    stage = 'inventory'
    data = get_vars_from_path(loader, path, entities, stage)
    assert isinstance(data, dict)

# Generated at 2022-06-21 09:38:28.873306
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    def mock_vars_plugin():
        class DummyVarsPlugin:
            def get_vars(self, loader, path, entities):
                return {'a': 1}

        return DummyVarsPlugin()

    def mock_vars_plugin_legacy():
        class DummyVarsPlugin:
            def get_host_vars(self, host):
                return {'a': 1}

            def get_group_vars(self, group):
                return {'a': 1}

        return DummyVarsPlugin()

    def assert_get_plugin_vars_result(plugin, expectation):
        assert get_plugin_vars(None, plugin, None, None) == expectation

    assert_get_plugin_vars_result(mock_vars_plugin(), {'a': 1})
    assert_get

# Generated at 2022-06-21 09:38:39.618505
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    test_collection = './test_collection/test_collection.test_ns.test_coll/'
    sys_path = [
        './test_vars_plugins/',
        './test_collection/',
        test_collection + 'module_utils/library/',
    ]

    for path in sys_path:
        # ensure path exists in sys.path
        if path not in sys.path:
            sys.path.append(path)

    data = get_vars_from_inventory_sources(None, [test_collection + 'vars_plugins'], [], 'inventory')
    assert data['vars'] == 'vars_plugins'
    assert data['vars_no_priority'] == 'vars_plugins_no_priority'

# Generated at 2022-06-21 09:38:47.180319
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    loader = None
    sources = ['/usr/share/ansible/plugins/vars/']
    entities = ['localhost']
    stage = 'inventory'
    assert get_vars_from_inventory_sources(loader, sources, entities, stage) != {}
    loader = None
    sources = ['/usr/share/ansible/plugs/vars/']
    entities = ['localhost']
    stage = 'inventory'
    assert get_vars_from_inventory_sources(loader, sources, entities, stage) != {}
    loader = None
    sources = ['/usr/share/ansible/plugs/vars/']
    entities = ['localhost']
    stage = 'task'
    assert get_vars_from_inventory_sources(loader, sources, entities, stage) != {}
    loader = None

# Generated at 2022-06-21 09:38:57.911011
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    ''' test loading vars plugins from both inventory and task level '''
    from ansible.module_utils.six import StringIO
    from ansible.parsing.dataloader import DataLoader

    env = {'ANSIBLE_CONFIG': os.path.join(C.TEST_DIR, 'test_vars_plugins.cfg')}
    loader = DataLoader()
    plugin_files = [f for f in os.listdir(os.path.join(C.TEST_DIR, 'data/vars_plugin/')) if f.endswith('.yaml')]
    test_entities = [
        Host('inventory_1'),
        Host('inventory_2'),
        Host('inventory_3'),
        Host('inventory_4'),
        Host('inventory_5'),
    ]

    # test inventory level


# Generated at 2022-06-21 09:39:04.042379
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars.test import VarsModuleTestPlugin
    loader = None # vars_loader.get('test', class_only=True)
    plugin = VarsModuleTestPlugin()
    path = 'test'
    entities = ['foo', 'bar']
    assert get_plugin_vars(loader, plugin, path, entities) == {
        'foo': 'spam',
        'bar': ['eggs', 'spam'],
    }



# Generated at 2022-06-21 09:39:04.651531
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert False

# Generated at 2022-06-21 09:39:25.311765
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    """
    Verify the correctness of function get_vars_from_inventory_sources
    This is to validate the dynamic includes in inventory file which are the source of the entities
    in function get_vars_from_inventory_sources
    """

    loader = None

# Generated at 2022-06-21 09:39:32.648034
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import VarsModule

    class TestVarsPlugin(VarsModule):
        data = dict(one=dict(two=dict(three=dict(four=44))))

        def get_vars(self, loader, path, entities):
            return self.data

    loader = vars_loader.get(None)
    p = TestVarsPlugin()
    vars = get_plugin_vars(loader, p, '/', None)
    assert vars.get('one').get('two').get('three').get('four') == 44



# Generated at 2022-06-21 09:39:42.760475
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    import pytest
    from ansible.plugins.loader import vars_loader

    # test that vars path plugins are called
    # verify that the results are returned
    # verify that the correct path is passed in

    class MyVars(object):
        def __init__(self, path):
            self.path = path

        def get_vars(self, loader, path, entities):
            if self.path != path:
                pytest.fail("Path does not match")
            return {'a': 'b'}

    vars_loader._modules.update({'myvars': MyVars})

    vars_data = get_vars_from_inventory_sources(None, ['/some/path/somefile.yaml', '/some/path2/somefile2.yaml'], None, 'task')

# Generated at 2022-06-21 09:39:51.393355
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    import ansible.plugins.loader as plugin_loader

    class MockLoader(object):
        def __init__(self):
            self.cache = {}

        def _add_directory(self, path):
            self.paths = [path]

        def get(self, var_name, *args, **kwargs):
            if var_name not in self.cache:
                self.cache[var_name] = plugin_loader.get(
                    var_name,
                    class_only=True,
                    config=C,
                    collection_list=[],
                    subdirs=False,
                    package_errors='warn'
                )
            return self.cache[var_name]

    sources = ['/path/to/sources']
    entities = []
    stage = 'inventory'

    # Check that the output data is dict.


# Generated at 2022-06-21 09:39:59.208587
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vault

    plugin = vault.VaultVarsModule()
    loader = None
    path = None
    entities = ['localhost']

    data = plugin.get_vars(loader, path, entities)
    assert 'vault_files' in data
    assert 'vault_password_files' in data
    assert data['vault_password_files'] == []
    assert data['vault_files'] == []

# Generated at 2022-06-21 09:40:11.710109
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    # Unit test for function get_vars_from_inventory_sources
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import vars_loader

    plugin_path = os.path.join(os.path.dirname(__file__), '../plugins/inventory')
    plugin_loader = DataLoader()
    plugin_loader.set_basedir(plugin_path)
    vars_loader.add_directory(plugin_path)
    sources = [plugin_path]
    entities = ['test']
    stage = 'task'
    data = get_vars_from_inventory_sources(plugin_loader, sources, entities, stage)
    assert data == {'test': 'abc'}
    vars_loader.clear_all_data()

# Generated at 2022-06-21 09:40:19.940054
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    """
    :return: returns inventory source host_vars in a dict
    """
    def return_host_vars(loader, path, entities):
        return {'host_vars': 'host_vars'}

    entity_list = []
    entity_list.append(Host('localhost'))
    loader = {'get_basedir': lambda x: '<base_dir>'}
    plugin = return_host_vars
    assert get_vars_from_inventory_sources(loader, ['<base_dir>'], entity_list, 'task') == {'host_vars': 'host_vars'}

# Generated at 2022-06-21 09:40:32.172003
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    # test 1: test with an non-existent inventory path
    print ("test 1: test with an non-existent inventory path")
    sources = ['/etc/ansible/hosts']
    entities = []
    stage = 'inventory'
    loader = None
    data = get_vars_from_inventory_sources(loader, sources, entities, stage)

    assert(len(data) == 0)

    # test 2: test with an existing inventory path
    print ("test 2: test with an existing inventory path")
    sources = ['/etc/ansible/hosts']
    entities = []
    stage = 'inventory'
    loader = None
    data = get_vars_from_inventory_sources(loader, sources, entities, stage)
    assert(len(data) > 0)

    # test 3: test with a valid and invalid

# Generated at 2022-06-21 09:40:32.804176
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    pass

# Generated at 2022-06-21 09:40:34.612763
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    assert get_plugin_vars(None, {}, None, None) == {}

# Generated at 2022-06-21 09:41:04.797573
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    """
    Example of hostvars.py in inventory source path ../inventory/
    #!/usr/bin/env python
    #coding:utf8

    def get_vars(loader, path, entities):
        return {
            'vars' : True,
        }
    """
    loader = None
    sources = ['../inventory/']
    entities = []
    stage = 'inventory'
    vars = get_vars_from_inventory_sources(loader, sources, entities, stage)

    # vars should be return by vars plugin.
    assert True == vars.get('vars')



# Generated at 2022-06-21 09:41:14.084629
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import VarsBase
    from ansible.plugins.vars.vars_plugins import VarsModule
    class FooPlugin(VarsBase):
        def get_group_vars(self, name):
            return dict(var="group " + name)
        def get_host_vars(self, name):
            return dict(var="host " + name)

    class BarPlugin(VarsModule):
        def run(self, host):
            return dict(var="host " + host.name)

    loader = MockLoader()
    host = Host("host")
    group = MockGroup("group")

    for plugin in (FooPlugin("test"), BarPlugin("test")):
        plugin.set_loader(loader)

        # Mocked loader doesn't return any inventory source, the path is ignored.
       

# Generated at 2022-06-21 09:41:19.365900
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    '''
    get_vars_from_path will return a dictionary with
    key/value pair, filename and dictionary.
    :return:
    '''
    assert isinstance(get_vars_from_path(None, './test/vars/host_vars/hostname', None, None), dict)

# Generated at 2022-06-21 09:41:30.678617
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    # test v1 plugins

    data = {}

    # define a v1 plugin
    class v1_get_vars_plugin(object):
        def get_vars(self, loader, path, entities):
            return {'v1_get_vars': 'foo'}

    data = get_plugin_vars(None, v1_get_vars_plugin(), None, None)
    assert isinstance(data, dict)
    assert data['v1_get_vars'] == 'foo'

    # define a v1 plugin that doesn't have get_vars but has get_host/group_vars
    class v1_host_group_plugin(object):
        def get_host_vars(self, hostname):
            return {'v1_host_group_plugin': 'bar'}
    data = get

# Generated at 2022-06-21 09:41:39.527715
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    class FakeLoader:
        pass
    class FakePlugin:
        def __init__(self, name):
            self._load_name = name
        def get_vars(self, loader, path, entities):
            return {'test_var': 'true'}
    class FakeHost:
        def __init__(self, name):
            self.name = name
    fake_loader = FakeLoader()
    fake_plugin = FakePlugin('test_plugin')
    fake_host = FakeHost('fake_host')
    assert get_vars_from_inventory_sources(fake_loader, ['/etc/ansible/hosts'], [fake_host], 'task')['test_vars'] == 'true'



# Generated at 2022-06-21 09:41:40.064647
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    pass

# Generated at 2022-06-21 09:41:50.342355
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import BaseVarsPlugin

    class Test1(BaseVarsPlugin):
        def get_vars(self, loader, path, entities=None):
            return {'test_result': 'Test1'}

    class Test2(BaseVarsPlugin):
        def get_vars(self, loader, path, entities=None):
            return {'test_result': 'Test2'}

    class Test3(BaseVarsPlugin):
        def get_group_vars(self, group):
            return {'test_result': 'Test3'}

    class Test4(BaseVarsPlugin):
        def get_group_vars(self, group):
            return {'test_result': 'Test4'}

    # Test class with get_vars method

# Generated at 2022-06-21 09:41:59.276433
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    x = InventoryManager('/dev/null')
    g = x.groups[u'testgroup']
    h = Host(name="testhost", port=5678)
    y = VariableManager(loader=None, inventory=x)
    z = {'bar': 1, 'baz': 2, 'foo': 3}
    y._vars_plugins[u'inventory'][u'host'][u'set_vars'] = (g, h)
    y._vars_plugins[u'inventory'][u'path'][u'set_vars'] = (g, h)

# Generated at 2022-06-21 09:42:02.642918
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    loader = {}
    sources = ['hosts', 'host_vars']
    entities = ['hosts']

    data = get_vars_from_inventory_sources(loader, sources, entities, stage)
    assert len(data) == 0

# Generated at 2022-06-21 09:42:09.747480
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    path = '../../tests/plugins/test_vars'
    class mock_entity:
        def __init__(self, name):
            self.name = name
    class mock_loader:
        def __init__(self, path):
            pass
        def __getitem__(self, item):
            return item
        def get(self, item, *args, **kwargs):
            return item
        def all(self, *args, **kwargs):
            return ["plugin_1", "plugin_2"]

    # Test that plugins without stage will run by default
    plugin_results = get_vars_from_path(mock_loader(path), path, [mock_entity('test_entity')], 'start')

# Generated at 2022-06-21 09:42:33.686308
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager

    inv = InventoryManager([])
    inv.host_sources = 'localhost'
    inv.parse_sources()
    inv.add_host(Host(name='localhost', port=22))
    data = get_vars_from_path(os.path.dirname(__file__), os.path.dirname(__file__), inv.hosts, 'all')

    vars_plugin_list = list(vars_loader.all())
    assert len(vars_plugin_list) > 0
    assert len(data) > 0

# Generated at 2022-06-21 09:42:37.321126
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    inventory = []
    path = '/home/ansible/playbooks'
    expected = {}
    actual = get_plugin_vars(None, None, path, inventory)
    assert expected == actual



# Generated at 2022-06-21 09:42:49.322359
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.utils.vars import combine_vars
    from ansible.plugins.vars import gce_vars

    class TestLoader():
        def get_basedir(self, host):
            return 'tests/vars_plugins'

    class TestHost():
        def __init__(self, name):
            self.name = name

    test_loader = TestLoader()
    test_entity_list = [TestHost('localhost')]
    test_path = 'tests/inventory'
    plugin = gce_vars.VarsModule()

    test_data = get_plugin_vars(test_loader, plugin, test_path, test_entity_list)
    assert isinstance(test_data, dict)
    assert 'gce_availability_zone' in test_data.keys()



# Generated at 2022-06-21 09:42:58.195361
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import vars_loader

    loader = InventoryManager(sources=['tests/inventory/test_static_plugin_vars/group_vars/all.yaml'])
    entities = loader.get_hosts()
    path = os.path.dirname(loader.sources[0])

    plugin = vars_loader.get("test_vars_plugins.all")

    data = get_plugin_vars(loader, plugin, path, entities)

    assert data == dict(
        test_static_plugin_vars=dict(
            test_groups_all='test_value',
            test_group_vars_all='test_value'
        )
    )


# Generated at 2022-06-21 09:43:06.843446
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.plugins.vars import auto
    from .mock.loader import DictDataLoader

    class TestVars(auto.BaseVarsPlugin):

        def get_vars(self, loader, path, entities):
            return {b'foo': b'bar'}

    vars_loader.add(TestVars, 'test_var')

    inventory_sources = ['/dev/null']
    entities = [Host('foo')]

    loader = DictDataLoader({})
    assert get_vars_from_path(loader, inventory_sources, entities, 'inventory') == {b'foo': b'bar'}

# Generated at 2022-06-21 09:43:08.054511
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    ''' Returns the vars data collected from the inventory source directory '''
    pass

# Generated at 2022-06-21 09:43:08.599593
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    pass



# Generated at 2022-06-21 09:43:14.215878
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    class _loader_mock(object):
        pass

    class _vars_mock(object):
        def __init__(self, return_value):
            self._return_value = return_value

        def get_vars(self, loader, path, entities):
            return self._return_value

    return_value = {'my_key': 'my_value'}
    plugin = _vars_mock(return_value)
    loader = _loader_mock()
    path = 'foo'
    entities = ['localhost']
    result = get_plugin_vars(loader, plugin, path, entities)
    assert result == return_value

# Generated at 2022-06-21 09:43:22.429894
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    class TestPlugin:

        class Meta:
            name = 'test'

        def __init__(self, loader):
            self._load_name = 'test'

        def get_vars(self, loader, path, entities):
            return {'test_plugin': True}

    class TestHostPlugin:

        class Meta:
            name = 'test'

        def __init__(self, loader):
            self._load_name = 'test'

        def get_host_vars(self, host):
            return {'test_host_plugin': True}

    class TestGroupPlugin:

        class Meta:
            name = 'test'

        def __init__(self, loader):
            self._load_name = 'test'


# Generated at 2022-06-21 09:43:23.837957
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    # TODO: Get some test data into test/unit/data/plugins/vars
    pass

# Generated at 2022-06-21 09:43:57.313406
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    loader = vars_loader
    plugin = loader.get('host_group')
    path = '/dev/null'
    groups = ['a_group']
    data = get_plugin_vars(loader, plugin, path, groups)
    assert data != {}

# Generated at 2022-06-21 09:44:02.463099
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    from ansible.plugins.vars import vars_plugins

    vars_plugin_list = list(vars_loader.all())

    assert vars_plugin_list != []

    data = {}
    for path in vars_plugin_list:
        data = combine_vars(data, get_plugin_vars(vars_plugin_list, path, "path", "entities"))

    assert data != {}

# Generated at 2022-06-21 09:44:10.820356
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    class TEST_PLUGIN:
        def get_vars(self, filename, data, entities):
            return {'test': 'foo'}

    loader = None
    plugin = TEST_PLUGIN()
    plugin._load_name = 'test'
    plugin._original_path = 'test'

    path = 'test'
    entities = ['test']
    assert get_plugin_vars(loader, plugin, path, entities) == {'test': 'foo'}

# Generated at 2022-06-21 09:44:11.624503
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    pass

# Generated at 2022-06-21 09:44:19.820557
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    loader = InventoryManager(C.DEFAULT_HOST_LIST)
    path_1 = '/etc/ansible/hosts'
    path_2 = '/etc/ansible/hosts_test'
    sources=[path_1, path_2]
    entities=loader.get_hosts(pattern='127.0.0.1')
    stage='inventory'
    result = get_vars_from_inventory_sources(loader, sources, entities, stage)
    assert isinstance(result, dict)


# Generated at 2022-06-21 09:44:20.983388
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    pass

# Generated at 2022-06-21 09:44:29.674413
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    # Add a fake vars plugin to import
    os.environ['FAKE_VARS_PATH'] = 'tests/units/plugins/vars'
    vars_loader.add_directory(os.environ['FAKE_VARS_PATH'])
    vars_plugin_list = vars_loader.all()
    assert len(vars_plugin_list) == 1

    loader = None
    path = '/path/to/inventory'
    entities = ['test', Host('test')]

    for entity in entities:
        data = get_plugin_vars(loader, vars_plugin_list[0], path, [entity])
        assert 'fake_vars_plugin' in data


# Test for get_vars_from_path

# Generated at 2022-06-21 09:44:42.252770
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager
    from ansible.vars.vars_plugins.test_collection.plugins.vars import TestCollectionVars
    from ansible.vars.vars_plugins.test_collection.plugins.v2 import TestCollectionVars2
    from ansible.vars.vars_plugins.test.plugins.vars import TestVars
    from ansible.vars.vars_plugins.test.plugins.v2 import TestVars2

    # Initialize VariableManager
    group = Group('test_group')
    group.vars = { 'foo_group': 'bar_group'}
    group.hosts.append(Host('test_host'))

# Generated at 2022-06-21 09:44:52.442214
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    # Setup mocks
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import vars_loader
    from ansible.vars.manager import VariableManager

    class MockPlugin:
        def __init__(self, load_name, plugin_type):
            self._load_name = load_name
            self._plugin_type = plugin_type

        def get_vars(self, *args, **kwargs):
            if self._plugin_type == 'type1':
                return {self._load_name: 1}
            elif self._plugin_type == 'type2':
                return {self._load_name: 2}


# Generated at 2022-06-21 09:45:03.253457
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    import ansible.plugins.loader as pluginloader
    pluginloader._find_plugins("vars")

    class FakeVarsPlugin:
        def get_option(*args, **kwargs):
            return None

    class FakeInventorySource:
        sources = None

    fake_loader = FakeInventorySource()
    fake_vars_plugin = FakeVarsPlugin()

    # Test a valid path
    result = get_vars_from_path(fake_loader, "/usr/lib/ansible", ["dummy"], "hostvars")
    assert(isinstance(result, dict))
    assert(result == {})

    # Test an invalid path
    result = get_vars_from_path(fake_loader, "foo", ["dummy"], "hostvars")
    assert(isinstance(result, dict))

# Generated at 2022-06-21 09:46:12.691700
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    pass

# Generated at 2022-06-21 09:46:13.662242
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    # FIXME: write a proper unit test for this function
    pass



# Generated at 2022-06-21 09:46:15.325209
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    assert get_vars_from_inventory_sources(None, ['foo'], [], 'inventory') == {}

# Generated at 2022-06-21 09:46:24.986199
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    display.debug("Entering test case")
    from ansible.module_utils.ansible_release import __version__
    from ansible.compat.tests import unittest
    import ansible.utils.collection_loader

    collections = ["one", "two", "three", "four", "five", "six", "seven", "eight"]

    def fake_get(name):
        if name in collections:
            return "fake"
        else:
            return None

    ansible.utils.collection_loader.get = fake_get
    C.VARIABLE_PLUGINS_ENABLED = ["one", "two", "three", "four", "five", "six", "seven", "eight"]

    # If a collection that is whitelisted is not found, we should raise an exception
    # C.VARIABLE_PL

# Generated at 2022-06-21 09:46:29.696920
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    class FakeVarsPlugin:
        def get_vars(self, path, entities):
            return {'a': 1, 'b': 2}

    loader = FakeVarsPlugin()
    data = get_plugin_vars(loader, loader, None, None)
    assert data == {'a': 1, 'b': 2}


# Generated at 2022-06-21 09:46:36.190562
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    import pytest
    from ansible.parsing.utils.addresses import parse_address

    # A test host that has runner vars set
    host = Host(parse_address('localhost'))
    host.vars = dict(a=1, b=2, c=3)

    # A test group that has vars set
    group = parse_address('group1')
    group.vars = dict(d=4, e=5, f=6)

    # A test path to the test inventory
    path = os.path.join(os.path.dirname(__file__), './test/test_inventory.cfg')

    # a test directory that contains a test vars plugin

# Generated at 2022-06-21 09:46:45.484800
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    from ansible.plugins.loader import var_list_loader
    var_list_loader.add_directory(os.path.join(os.path.dirname(__file__), 'test_vars_plugin'))

    vars_plugin_list = list(vars_loader.all())
    for plugin_name in ['test_vars_plugin.file', 'test_vars_plugin.script']:
        plugin = vars_loader.get(plugin_name)
        if plugin not in vars_plugin_list:
            vars_plugin_list.append(plugin)

    loader = None
    path = ''
    entities = None
    stage = ''
    data = {}

# Generated at 2022-06-21 09:46:49.920552
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    sources = ["/path/to/inventory"]
    entities = [Host(name="localhost")]
    stage = "task"
    data = get_vars_from_inventory_sources(None, sources, entities, stage)
    print(data)

# Generated at 2022-06-21 09:46:51.695253
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    loader = None
    sources = ['test/vars/inventory.yml']
    entities = ['localhost']
    stage = 'inventory'
    data = get_vars_from_inventory_sources(loader, sources, entities, stage)
    assert data == {'a': 1, 'b': 2}

# Generated at 2022-06-21 09:47:02.622913
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    """
    Function get_vars_from_path tests.
    """

    from ansible.parsing.utils.vars_plugins import vars_loader as vars_loader_helper
    from ansible.parsing.utils.vars_plugins.vault import VaultVars
    from ansible.plugins.vars.host_group_vars import VarsModule as HostGroupVarsVarsModule
    from ansible.plugins.vars.vault_mixed import VarsModule as VaultMixedVarsModule

    loader = vars_loader_helper()

    path = '/etc/ansible'
    host = Host('127.0.0.1')
    host.set_variable('ansible_playbook_python', '/usr/bin/python3')