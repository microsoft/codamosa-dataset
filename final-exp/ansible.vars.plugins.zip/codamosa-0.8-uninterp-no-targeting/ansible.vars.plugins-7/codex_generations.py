

# Generated at 2022-06-21 09:37:58.684088
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.module_utils.collection_loader import AnsibleCollectionRef
    from ansible.plugins.vars import vars_plugin_list
    from ansible.plugins.vars.host_list import HostListVars
    from ansible.plugins.lookup import LookupBase
    from ansible.plugins.vars.fact_cache import FactCacheVars
    from ansible.plugins.loader import vars_loader
    from ansible.utils.path import unfrackpath

    inv = InventoryManager(loader=None, sources=[unfrackpath('/path/to/path_in_inventory.yaml')])

    inv.add_group('testgroup')
    testhost = Host(name='testhost')
    inv.add_host

# Generated at 2022-06-21 09:38:09.318049
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    from ansible.plugins.loader import vars_loader
    from ansible.module_utils.common.collections import ImmutableDict

    class FakeLoader:
        def get_basedir(self):
            return '.'

        def path_dwim_relative(self, basedir, given, subdir, check=True):
            # always return the 'given' path
            return given

    class FakeVarsPlugin:

        _load_name = 'FakeVarsPlugin'

        def get_vars(self, loader, path, entities):
            return {'inventory_foo': 'bar'}

    loader = FakeLoader()
    plugin = FakeVarsPlugin()
    vars_loader.add(plugin)

    path = '.'
    entities = []
    stage = 'task'

    data = get_vars_from_path

# Generated at 2022-06-21 09:38:09.925808
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    pass



# Generated at 2022-06-21 09:38:17.114191
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Uncomment one of the three lines below to have the unit test fail
    # path = os.path.dirname(os.path.abspath(__file__))
    # path = os.path.dirname(os.path.abspath(__file__)) + "/../../../plugins/vars"
    path = os.path.dirname(os.path.abspath(__file__)) + "/../../../plugins/vars/host_group_vars.py"
    entities = []
    stage = 'inventory'
    display.debug("Vars_Loader.all() = {}".format(vars_loader.all()))
    display.debug("get_vars_from_path() = {}".format(get_vars_from_path(vars_loader, path, entities, stage)))

# Unit test

# Generated at 2022-06-21 09:38:21.449405
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    loader = vars_loader
    sources = ['tests/inventory/host_vars/all',
               ]
    entities = ['all']
    stage = 'inventory'
    data = get_vars_from_inventory_sources(loader, sources, entities, stage)
    assert 'all_var2' in data

# Generated at 2022-06-21 09:38:29.521463
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    TestInventory = type('TestInventory', (object,), dict(loader=None, sources=None, hosts=None, groups=None))
    TestGroup = type('TestGroup', (object,), dict(name=None))
    TestHost = type('TestHost', (object,), dict(name=None))

    display.verbosity = 3

    # Test loading groups
    groups = [TestGroup(name='test-group')]

    # Test loading from directory
    inventory = TestInventory(hosts=None, groups=groups)
    sources = ['./test/unit/plugins/test_vars_plugins/']
    vars = get_vars_from_inventory_sources(inventory.loader, sources, groups, 'inventory')
    assert vars['test_var_groups'] == 'test-group'

    # Test loading from

# Generated at 2022-06-21 09:38:37.575248
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    # Test the normal case
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    sources = [inventory._sources['localhost,']._source]
    entities = inventory.get_hosts()

    get_vars_from_inventory_sources(loader, sources, entities, 'inventory')

# Generated at 2022-06-21 09:38:44.927081
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    import ansible.plugins.vars.test
    import ansible.inventory.host
    import ansible.inventory.group

    loader = DummyLoader()
    test_plugin = ansible.plugins.vars.test.VarsModule()

    data = get_plugin_vars(loader, test_plugin, None, [])
    assert not data

    host = ansible.inventory.host.Host("test_host")
    data = get_plugin_vars(loader, test_plugin, None, [host])
    assert data['test_plugin_host_var'] == 'test_plugin_host_var'

    group = ansible.inventory.group.Group("test_group")
    data = get_plugin_vars(loader, test_plugin, None, [group])

# Generated at 2022-06-21 09:38:54.994170
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.vars import test_vars_plugin
    plugin_loader = vars_loader
    loader = None
    path = "fake_path"
    entities = None
    stage = None
    assert plugin_loader.find_plugin(test_vars_plugin._load_name) == test_vars_plugin

    vars = get_vars_from_path(loader, path, entities, stage)
    assert vars['test_vars_plugin_var_1'] == 'example_value_1'
    assert vars['test_vars_plugin_var_2'] == 'example_value_2'
    assert vars['test_vars_plugin_var_3'] == 'example_value_3'

# Generated at 2022-06-21 09:39:02.901064
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    assert get_plugin_vars({}, {'get_vars': {}}, 'path', 'entities') == {}
    assert get_plugin_vars({}, {'get_vars': {'one': 1}}, 'path', 'entities') == {'one': 1}
    assert get_plugin_vars({}, {'get_host_vars': {'one': 1}}, 'path', [{'name': 'test'}]) == {'one': 1}
    assert get_plugin_vars({}, {'get_host_vars': {}}, 'path', [{'name': 'test'}]) == {}
    assert get_plugin_vars({}, {'has_option': {'stage': None}}, 'path', 'entities') == {}



# Generated at 2022-06-21 09:39:20.897357
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    # Test that the function ignores invalid paths
    # We test against a single valid path, which is the base case
    sources = ['/nodir', os.path.dirname(__file__)]
    data = get_vars_from_inventory_sources(None, sources, [], True)
    assert data == {'test_vars_path_foo': 'bar'}

# Generated at 2022-06-21 09:39:29.504945
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    import ansible.inventory.host
    import ansible.inventory.manager
    import ansible.inventory.script
    import ansible.vars.manager
    import tempfile

    loader = ansible.vars.manager.VariableManager()

    print(C.VARIABLE_PLUGINS_ENABLED)

    # Create a sample vars plugin
    plugin_dir = tempfile.mkdtemp()
    plugin_file = os.path.join(plugin_dir, "testvars.py")
    plugin_name = 'testvars'


# Generated at 2022-06-21 09:39:40.707320
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inv1 = InventoryManager(loader=loader, sources=['/tmp/hosts1'])
    inv2 = InventoryManager(loader=loader, sources=['/tmp/hosts2'])

    vars_plugin = vars_plugin_t1()
    vars_plugin_list = list(vars_loader.all())
    vars_plugin_list.append(vars_plugin)

    vars_loader.clear_cache()
    vars_loader.add(vars_plugin)
    print (get_vars_from_path(loader, '/tmp/hosts1', [], 'inventory'))

# Generated at 2022-06-21 09:39:46.343862
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    # Setup
    loader = None
    path = '/var/lib/awx/projects/_12_/'
    entities = ['host1']
    stage = 'inventory'

    # Exercise
    data = get_vars_from_path(loader, path, entities, stage)

    # Verify
    assert data is not None

    # Cleanup
    # Cleared automatically

# Generated at 2022-06-21 09:39:50.362196
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    stub_loader = object()
    stub_sources = ['/path/to/inventory/source']
    stub_entities = [{'hostname': 'host1'}]
    stub_stage = 'inventory'
    assert not get_vars_from_inventory_sources(stub_loader, stub_sources, stub_entities, stub_stage)

# Generated at 2022-06-21 09:39:55.852252
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    fake_plugin = vars_loader.get("test")
    system = {'test_variable':'this value',
              'another_var':'another value'}

    # When a list of entities is passed in
    entities = ['group1', 'group2', 'host1', 'host2']
    test_data = get_vars_from_inventory_sources(None, None, entities, 'inventory')
    assert test_data == system

    # When an empty list of entities is passed in
    entities = []
    test_data = get_vars_from_inventory_sources(None, None, entities, 'inventory')
    assert test_data == system

    # When a None entities is passed in
    test_data = get_vars_from_inventory_sources(None, None, None, 'inventory')
    assert test

# Generated at 2022-06-21 09:40:08.622680
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    class Plugin(object):
        def get_host_vars(self, host):
            return {host: host}

    class Loader(object):
        pass

    loader = Loader()
    loader.get_basedir = lambda: b'/etc/ansible'

    hosts = ['foo.example.com', 'bar.example.com']
    entities = [Host(name) for name in hosts]

    result = get_vars_from_path(loader, b'/etc/ansible', entities, 'inventory')

    expected = {
        u'foo.example.com': u'foo.example.com',
        u'bar.example.com': u'bar.example.com',
    }
    assert result == expected, 'Unexpected result: %s' % result



# Generated at 2022-06-21 09:40:11.572007
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.loader import vars_loader
    plugin = vars_loader.get('include_vars')
    entities = []
    path = '/home/vikas/git/ansible/demo/read_file.yml'
    data = get_plugin_vars(None, plugin, path, entities)
    assert data['content'] == 'Hello Vikas\n'

# Generated at 2022-06-21 09:40:13.574986
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    sources = ["foo", "bar", "baz"]
    result = get_vars_from_inventory_sources(sources, 'inventory')
    print(result)


# Generated at 2022-06-21 09:40:23.130293
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    from ansible.inventory.host import Host
    from ansible.utils.collection_loader import _get_collection_base_path
    loader, _, _ = _get_collection_base_path(None)
    plugin_name = "collection.community.general.awx_cluster_config"
    path = "/tmp/test_inventory"
    entities = [Host("db1")]
    plugin = loader._load_plugin('vars', plugin_name, 'vars_plugins')
    data = get_plugin_vars(loader, plugin, path, entities)
    assert data == {"awx": {"cluster_host": "db1"}}

# Generated at 2022-06-21 09:40:28.716305
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    pass

# Generated at 2022-06-21 09:40:35.556054
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    import pytest
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    sources = ['/tmp/doesnotexist', '/tmp/alsodoesnotexist']
    entities = ['localhost', 'anotherhost']
    stage = 'task'
    result = get_vars_from_inventory_sources(loader, sources, entities, stage)
    assert result == {}

# Generated at 2022-06-21 09:40:43.795019
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin
    class HostVarsPlugin(vars_plugin.VarsPlugin):

        def get_vars(self, load, path, entities):
            vars = {'get_vars': 'get_vars'}
            return vars

        def get_group_vars(self, group):
            vars = {'get_group_vars': 'get_group_vars'}
            return vars

        def get_host_vars(self, host):
            vars = {'get_host_vars': 'get_host_vars'}
            return vars

    plugin = HostVarsPlugin(None, 'host_vars_plugin', None, [], None)


# Generated at 2022-06-21 09:40:44.457991
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    pass

# Generated at 2022-06-21 09:40:55.423709
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    from ansible.plugins.vars import test_vars_plugin

    # Create instance of vars loader and add test plugin
    loader = vars_loader.vars_loader(None)
    loader.add_plugin(test_vars_plugin.TestVarsPlugin('test', os.path.join(os.path.dirname(__file__), 'vars/test_vars_plugin')))

    plugin = loader.get(test_vars_plugin.TestVarsPlugin.testvars_name)

    path = os.path.join(os.path.dirname(__file__), 'vars')
    data = get_plugin_vars(loader, plugin, path, None)

    assert data['foo'] == 'bar'
    assert data['bar'] == 'baz'
    assert data['baz'] == 1

# Generated at 2022-06-21 09:41:05.791533
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.loader import vars_loader
    vars_plugins = list(vars_loader.all())
    if len(vars_plugins) < 1:
        raise Exception("No variable plugins found!")

    plugin = vars_plugins[0]
    import ansible.inventory.manager
    loader = ansible.inventory.manager.InventoryManager(loader=None, sources=None, vault_password=None)
    entities = ['localhost']
    path = 'path'

    data = get_plugin_vars(loader, plugin, path, entities)

    if not isinstance(data, dict):
        raise Exception("Invalid variable returned!")

# Generated at 2022-06-21 09:41:14.563501
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()


# Generated at 2022-06-21 09:41:26.895209
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    # Test inventory files in the working directory
    test_inventory_dir = os.path.join(os.getcwd(), 'test/unit/inventory/')

# Generated at 2022-06-21 09:41:28.442989
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    #Need to add test case
    assert True


# Generated at 2022-06-21 09:41:35.736288
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.loader import vars_loader

    plugin = vars_loader.get('dict_lookup')
    entities = [{'name': 'localhost', 'port':1234}]
    data = get_plugin_vars(sources=[], plugin=plugin, path='.', entities=entities)
    assert 'dict_lookup_file_name' in data

    with pytest.raises(AnsibleError) as e:
        get_plugin_vars(sources=[], plugin=plugin, path='.', entities=None)
    assert "Cannot use v1 type vars plugin" in str(e.value)


# Generated at 2022-06-21 09:41:45.539089
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    assert False

# Generated at 2022-06-21 09:41:55.067798
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    import sys
    import unittest
    from ansible.plugins.vars.host_list import HostListVars
    from ansible.plugins.loader import vars_loader

    class Test_get_vars_from_inventory_sources(unittest.TestCase):
        def test_get_vars_from_inventory_sources(self):

            # Create a fake plugin that returns a specific value
            class MyVarsPlugin(object):
                def get_vars(self, loader, path, entities):
                    return {'vars': {'test': 'value'}}

            # Add fake plugin to the vars plugin loader
            vars_loader.add(MyVarsPlugin, 'my_vars_plugin')

            # Create a loader object

# Generated at 2022-06-21 09:41:55.908583
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    # TODO
    pass

# Generated at 2022-06-21 09:41:58.081806
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert get_vars_from_path(loader="loader", path="./", entities=["entities"], stage="stage") == {}

# Generated at 2022-06-21 09:41:58.695223
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    pass

# Generated at 2022-06-21 09:42:07.620769
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    class testplugin:
        def get_vars(self, loader, path, entities):
            return {"testplugin": True}

    class testplugin2:
        def get_group_vars(self, name):
            return {"testplugin2": name}

        def get_host_vars(self, name):
            return {"testplugin2": name}

    class testplugin3:
        def run(self):
            pass

    class Entity:
        def __init__(self, name):
            self.name = name


    loader = {}
    path = "/foo/bar"
    plugin = testplugin()
    assert get_plugin_vars(loader, plugin, path, None) == {"testplugin": True}

    plugin = testplugin2()

# Generated at 2022-06-21 09:42:21.155864
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    vars_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['test/inventory/script_plugins/vars/source1', 'test/inventory/script_plugins/vars/source2'], variable_manager=vars_manager)
    inventory.parse_sources()

    entities = [inventory.get_group('group1'), inventory.get_host('host1'), inventory.get_host('host2')]
    plugin_vars = get_vars_from_path(loader, 'test/inventory/script_plugins/vars', entities, 'inventory')


# Generated at 2022-06-21 09:42:31.872009
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    class AnsibleVars(object):
        def __init__(self):
            self.vars = {}

        def get_vars(self, loader, path, entities):
            return self.vars

    class AnsibleVars2x(object):
        def __init__(self):
            self.vars = {}

        def get_group_vars(self, name):
            return self.vars

        def get_host_vars(self, name):
            return self.vars

    def get_vars_from_path_test(method, stage, vars_plugin_enabled, ansible_vars, expect_error=False):
        loader = None
        if not expect_error:
            if method == 'v2':
                # ensure we have a v2 plugin
                loader = vars_loader
               

# Generated at 2022-06-21 09:42:38.906176
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    # for now, we just run it and look for crashes, but we could add more here
    script_dir = os.path.dirname(os.path.realpath(__file__))
    inventory_dir = os.path.join(script_dir, '../../../inventory')
    loader = None
    sources = [os.path.join(inventory_dir, 'host_vars/host1.yml')]
    entities = ['host1']
    stage = 'inventory'

    data = get_vars_from_inventory_sources(loader, sources, entities, stage)
    #assert 'foo' in data
    #assert data['foo'] == 'bar'
    print(data)

# Generated at 2022-06-21 09:42:51.080262
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    path = 'inventory'

    class VarsPlugin(object):
        def __init__(self):
            self.data = {
                'group_names': ['group1', 'group2'],
                'groups': [
                    {'name': 'group1', 'children': ['child1', 'child2'], 'vars': {'var1': 'test'}},
                    {'name': 'group2', 'hosts': ['host1'], 'vars': {'var2': 'test'}},
                ],
                'host_names': ['host1', 'host2'],
                'hosts': [
                    {'name': 'host1'},
                    {'name': 'host2', 'vars': {'var3': 'test'}},
                ]
            }

# Generated at 2022-06-21 09:43:19.383871
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    from ansible.inventory.manager import InventoryManager

    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    inventory = InventoryManager(loader=loader, sources=['test/ansible/inventory/plugin_get_vars/hosts'])
    group = inventory.groups['all']

    data = get_vars_from_inventory_sources(loader, ['test/ansible/inventory/plugin_get_vars/group_vars', 'test/ansible/inventory/plugin_get_vars/host_vars'], [group], 'inventory')
    assert data['gv1'] == 'gv1'
    assert data['gv2'] == 'gv2'
    assert data['hv1'] == 'hv1'

# Generated at 2022-06-21 09:43:27.163791
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    # fake plugin to test with
    plugin = vars_loader.get('yaml_test')
    # add the plugin to the list of all vars plugins so that it will be tested
    vars_loader.all()[plugin._load_name] = plugin
    # get the fake inventory files path
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'fixtures', 'fake_playbooks', 'get_plugin_vars_test')
    # create a script which should be executed when the plugin is imported
    with open(os.path.join(path, 'main.yml'), 'w+') as main:
        main.write('test_var: hello world')

    # now test
    hostname = 'bootstrap-host'
    host = Host(hostname)


# Generated at 2022-06-21 09:43:36.761750
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    plugin = vars_loader.get('yaml')
    entities = ['localhost']

    #empty_path = os.path.join(os.path.dirname(__file__), 'unit', 'vars_plugins', 'empty_dir')
    #assert get_plugin_vars(None, plugin, empty_path, entities) == {}
    #
    #single_file_path = os.path.join(os.path.dirname(__file__), 'unit', 'vars_plugins', 'single_file')
    #assert get_plugin_vars(None, plugin, single_file_path, entities) == {'foo': 'bar', 'baz': 'qux'}
    #
    #multi_file_path = os.path.join(os.path.dirname(__file__), 'unit', 'vars

# Generated at 2022-06-21 09:43:45.452965
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    test_sources = [
        '/test/inventory1.yml',
        '/test/inventory2.yml',
        '/test/inventory3.ini',
    ]

    test_hosts = []

    test_hosts.append(Host('host1'))
    test_hosts.append(Host('host2'))
    test_hosts.append(Host('host3'))

    data = get_vars_from_inventory_sources(test_sources, test_hosts, 'inventory')

    assert data == {'test_host_var': 'test_host_value'}

    return True

# Generated at 2022-06-21 09:43:48.356952
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    data = get_vars_from_inventory_sources(None, ["/etc/ansible/hosts"], None, None)
    assert(data == {})

# Generated at 2022-06-21 09:43:53.101028
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    from os.path import abspath
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager  # noqa

    path = abspath(__file__)
    assert get_vars_from_path(vars_loader, path, [], 'inventory') == {}


# Test for function get_vars_from_inventory_sources

# Generated at 2022-06-21 09:43:58.253775
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.plugins.loader import vars_loader
    from ansible.utils import context_objects as co

    inventory = co.GlobalInventory()
    loader = co.GlobalLoader()

    # Load get_vars module
    vars_loader.all(inventory, loader)

    # Simple test to ensure that vars is loaded
    assert inventory.extra_vars == {}

# Generated at 2022-06-21 09:44:01.499677
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    vars_plugin_list=[]
    plugin_name='test'
    loader=var_vars
    path='/tmp'
    entities=[]

    assert vars_plugin_list == get_plugin_vars(vars_plugin_list, plugin_name, path, entities)

# Generated at 2022-06-21 09:44:07.462110
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    import pytest
    from ansible.plugins.vars import vars as vars_module

    class MyVars(vars_module):
        def get_vars(self, loader, path, entities):
            return {'var': 'test'}

    class MyVars2(vars_module):
        def get_vars(self, loader, path, entities):
            return {'var': 'test2'}

    class MyVars3(vars_module):
        def get_vars(self, loader, path, entities):
            return {'var': 'test2'}

    class MockLoader:
        def all(self):
            return []

    loader = MockLoader()

# Generated at 2022-06-21 09:44:18.783896
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    path = '/home/test/unit-tests/vars/'

    loader = {}

    sources = [None]
    data = get_vars_from_inventory_sources(loader, sources, None, None)
    assert data == {}

    sources = ["/home/test/unit-tests/vars/group_vars"]
    data = get_vars_from_inventory_sources(loader, sources, None, None)
    assert data == {}

    sources = ["/home/test/unit-tests/vars/dev/group_vars"]
    data = get_vars_from_inventory_sources(loader, sources, None, None)
    assert data == {'example': "Hello World"}


# Generated at 2022-06-21 09:45:03.117936
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    loader = None
    path = None
    entities = None
    stage = None
    data = get_vars_from_path(loader, path, entities, stage)
    assert data == {}, 'get_vars_from_path should return empty dict if no plugin is enabled or plugin-specific stage is wrong'


# Generated at 2022-06-21 09:45:08.342022
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.vars.manager import VariableManager

    vm = VariableManager()

    sources = ['/tmp/host_vars', '/tmp/group_vars']

    for plugin in vars_loader.all():
        vm.vars_plugins.append(plugin)

    data = get_vars_from_path(vm, '/tmp/host_vars', sources, 'task')

    assert isinstance(data, dict)

# Generated at 2022-06-21 09:45:17.959759
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.loader import vars_loader
    from ansible.plugins.vars import DefaultVarsPlugin
    from ansible.plugins.vars.host_group_vars import HostVars, GroupVars

    loader = vars_loader
    plugin = DefaultVarsPlugin(None)

    entities = [ Host('host1'), Host('host2') ]
    path = '/path/to/vars/directory'

    b_path = to_bytes(path, errors='surrogate_or_strict')

    def test_get_vars(plugin):
        assert get_plugin_vars(loader, plugin, path, entities) == {}
        assert get_plugin_vars(loader, plugin, b_path, entities) == {}
        assert get_plugin_vars(loader, plugin, path, []) == {}

# Generated at 2022-06-21 09:45:25.131245
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager

    # tested host and group names
    test_host_name = 'test_host'
    test_group_name = 'test_group'

    # reset old VARIABLE PLUGINS to be able to use the test ones
    VARIABLE_PLUGINS_ENABLED = C.VARIABLE_PLUGINS_ENABLED
    C.VARIABLE_PLUGINS_ENABLED = None

    # load the test plugins
    vars_loader.add_directory(os.path.join(os.path.dirname(__file__), 'test_plugins/var_plugins'))

    # create test host and group with data
    test_host = Host(name=test_host_name)

# Generated at 2022-06-21 09:45:31.579702
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    base_dir = 'unit/utils/inventory_sources'
    loader = fake_loader(base_dir)
    inventory_sources = [os.path.join(base_dir, 'inv_source.yaml')]
    entities = [
        Host('test_host1'),
        Host('test_host2'),
        Host('test_host3'),
        Host('test_host4')
    ]
    data = get_vars_from_inventory_sources(loader, inventory_sources, entities, 'inventory')
    assert data['first_inventory_source'] == 'inv_source.yaml'
    assert data['inventory_var'] == 'foo'
    assert data['inventory_var2'] == 'bar'
    assert data['inventory_var3'] == 'baz'



# Generated at 2022-06-21 09:45:39.702418
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    # Load plugin from collection
    from ansible_collections.community.general.plugins.modules import vars_plugin

    data = {}
    plugin = vars_plugin.VarsModule()
    host_name = 'localhost'
    host_entity = Host(name=host_name)
    data = combine_vars(data, get_plugin_vars('loader', plugin, 'path', host_entity))
    assert data[host_name]['vars_plugin_item'] == 'bar'
    assert data[host_name]['vars_plugin_host'] == 'baz'



# Generated at 2022-06-21 09:45:49.938099
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    def get_vars_from_path_mock(self, path, entities):
        return {'a': 'b'}

    class MockVarPlugin:

        _load_name = 'foo'
        _original_path = 'bar'

        def get_vars(self, loader, path, entities):
            return {'foo': 'bar'}

    mock_loader = MagicMock()
    # test that get_vars is called first and get_vars_from_path_mock as a fallback
    mock_loader.get_vars_from_path.return_value = {'foo': 'bar'}
    mock_loader.get_vars_from_path_mock = get_vars_from_path_mock
    vars_loader.add(MockVarPlugin, 'foo')

    loader

# Generated at 2022-06-21 09:45:51.455387
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    assert get_plugin_vars(None, vars_loader.get('static'), None, None) == {}



# Generated at 2022-06-21 09:46:02.171158
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    class FakeVars(object):

        def __init__(self, name):
            self.name = name
            self._original_path = 'ansible/plugins/vars/fake'
            self._load_name = 'fake'
            self.has_option = lambda x: True
            self.get_option = lambda x: 'demand' if x == 'stage' else None

        def get_vars(self, loader, path, entities):
            return {self.name: self.name}

    assert get_vars_from_path(
        loader=None,
        path='/path/to/file',
        entities=[],
        stage='inventory'
    ) == {}


# Generated at 2022-06-21 09:46:11.955864
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars.config_template import VarsModule as template_plugin
    from ansible.plugins.vars.hostname import VarsModule as hostname_plugin
    from ansible.plugins.vars.ip_addrs import VarsModule as ip_addrs_plugin
    from ansible.plugins.vars.group_by import VarsModule as group_by_plugin

    class FakeLoader():
        def __init__(self, path=None):
            self.path = path

    loader = FakeLoader('/some/path')

    plugin_data = get_plugin_vars(loader, template_plugin(), '/some/path', [])
    assert 'config_template_path' in plugin_data and plugin_data['config_template_path'] == '/some/path'

    plugin_data = get_plugin_v