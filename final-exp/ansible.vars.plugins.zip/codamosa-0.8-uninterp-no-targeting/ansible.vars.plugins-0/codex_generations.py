

# Generated at 2022-06-21 09:37:49.252465
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    entities = [Host('example')]

    # test function with correct signature
    mock_plugin = type("MyMockPlugin", (object,), {
        'get_vars': lambda *args: 'test-get_vars'
    })
    assert get_plugin_vars('dummy-loader', mock_plugin, 'dummy-path', entities) == 'test-get_vars'

    # test function with incorrect signature
    mock_plugin = type("MyMockPlugin", (object,), {
        'get_vars': lambda *args, **kwargs: 'test-get_vars'
    })

# Generated at 2022-06-21 09:37:58.292979
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    """
    Return vars plugin data
    """

    class FakePlugin(object):
        def __init__(self, name, vars):
            self._load_name = name
            self._original_path = 'fake path'
            self.vars = vars
        def get_vars(self, loader, path, entities):
            return self.vars

    class FakeVarsLoader(object):
        def all(self):
            return ()

    results = get_plugin_vars(FakeVarsLoader(), FakePlugin('plugin_name', {'data': 'data'}),
                              'path', ['entities'])
    assert isinstance(results, dict)
    assert 'data' in results
    assert results['data'] == 'data'

# Generated at 2022-06-21 09:38:08.766553
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin
    from ansible.utils.vars import combine_vars

    plugin = vars_plugin.VarsModule.load(path='/tmp/vars', name='vars_plugin', namespace='ansible')
    host = Host('localhost')
    path = '/tmp'

    # test_get_vars()
    plugin.get_vars = lambda loader, path, entities: {'a': '1'}
    assert get_plugin_vars(None, plugin, path, [host]) == {'a': '1'}

    # test_get_host_vars()
    plugin.get_host_vars = lambda host: {'b': '2'}

# Generated at 2022-06-21 09:38:16.518014
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # This can be used to test vars plugins
    # Should return a dict with key 'vars_plugin_test'
    from ansible.plugins.vars import testvars
    from ansible.plugins.loader import become_loader

    loader = become_loader

    plugin_list = loader.all()
    for plugin in plugin_list:
        if plugin.has_option('vars_plugin'):
            if not plugin.get_option('vars_plugin'):
                continue
            else:
                vars_plugin = plugin.get_option('vars_plugin')
                plugin._load_name = vars_plugin

    # Add testvars plugin to vars_plugin_list
    vars_plugin_list = list(vars_loader.all())
    vars_plugin_list.append(testvars)
   

# Generated at 2022-06-21 09:38:17.734164
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert 0

# Generated at 2022-06-21 09:38:21.280773
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    loader = None
    sources = [ "/etc/ansible/hosts" ]
    entities = []
    stage = "inventory"
    assert(get_vars_from_inventory_sources(loader, sources, entities, stage) is not None)

# Generated at 2022-06-21 09:38:29.393980
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    class MockVarsPlugin(object):
        def get_vars(loader, path, entities):
            return {'mock_vars_plugin': path}

    vars_loader.add(MockVarsPlugin, 'mock_vars_plugin')
    path = '/path/to/somewhere'

    class MockEntity(object):
        def __init__(self, name):
            self.name = name

    entities = [MockEntity('entity_name') for x in range(4)]
    stage = 'inventory'

    try:
        result = get_vars_from_path(Mock(), path, entities, stage)
        assert result['mock_vars_plugin'] == path
    finally:
        vars_loader.remove('mock_vars_plugin', MockVarsPlugin)


# Generated at 2022-06-21 09:38:39.983919
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import persistent
    from ansible.plugins.loader import vars_loader
    from ansible.vars.manager import VariableManager

    def mock_get_vars(loader, path, entities):
        return {'plugin_get_vars': 'plugin_get_vars'}

    def mock_vars_loader():
        def _add_directory(path):
            pass

        def _filter_files(files):
            return files

        def _get(name, *args, **kwargs):
            if name == 'persistent':
                return persistent.VarsModule()
            else:
                raise Exception()

        v1_vars_plugins = {
            'persistent': {'obj': mock_get_vars, 'name': 'persistent'},
        }


# Generated at 2022-06-21 09:38:45.517949
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    class TestPlugin:
        def get_option(self, string):
            return None

    plugin = TestPlugin()
    vars_plugin_list = [plugin]
    loader = None
    path = ''
    entities = []
    stage = ''
    plugin_data = get_plugin_vars(loader, plugin, path, entities)
    assert plugin_data == {}
    data = get_vars_from_path(loader, path, entities, stage)
    assert data == {}

# Generated at 2022-06-21 09:38:52.162150
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    import os
    from ansible.inventory.host import Host
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[os.path.dirname(__file__) + '/../../../test/support/vars_data/hosts'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    host = Host(name='testhost')
    entities = [host]

    # The vars plugin doesn't have a get_vars function, so it should raise an exception
    plugin_name = 'test_get_vars_from_path'

# Generated at 2022-06-21 09:38:57.261716
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    pass

# Generated at 2022-06-21 09:39:07.420520
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.loader import vars_loader
    from ansible.plugins.vars import base

    class DummyVarsPlugin(base.VarsBase):
        def get_vars(self, loader, path, entities, cache=True):
            return {'test': 'test'}

    class DummyPlugin(base.VarsBase):
        def get_host_vars(self, host):
            return {'test': 'test'}
        def get_group_vars(self, group):
            return {'test': 'test'}

    class DummyV1Plugin(object):
        def __init__(self, *args, **kwargs): pass
        def __call__(self, *args, **kwargs): pass

    plugin_list = []
    vars_plugin = DummyVarsPlugin()

# Generated at 2022-06-21 09:39:08.125807
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    pass

# Generated at 2022-06-21 09:39:20.682744
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    """
    Validate that variables are read correctly from the appropriate
    inventory sources, when those sources are a list of directories.
    """

    from ansible.inventory.manager import InventoryManager

    sources = [
        os.path.join(os.path.dirname(__file__), "data/vars_plugin/ansible_test.yml"),
        os.path.join(os.path.dirname(__file__), "data/vars_plugin/test.yaml"),
    ]

    # prepare inventory, and group/host lists
    loader = vars_loader._create_loader()
    inv_manager = InventoryManager(loader=loader, sources=sources)
    inv_data = inv_manager.get_inventory_data()
    hostlist = inv_manager.get_hosts()
    grouplist = inv_manager

# Generated at 2022-06-21 09:39:30.167989
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    display.verbosity = 0
    # no-op test class
    class Plugin(object):
        pass
    vars_path = Plugin()
    vars_path._load_name = 'vars_path'
    vars_path._original_path = 'vars_path'
    vars_host = Plugin()
    vars_host._load_name = 'vars_host'
    vars_host._original_path = 'vars_host'
    vars_host.get_host_vars = lambda x: {'host_vars': x}
    vars_group = Plugin()
    vars_group._load_name = 'vars_group'
    vars_group._original_path = 'vars_group'

# Generated at 2022-06-21 09:39:41.130538
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    """
    Verify that the vars plugins are properly limited
    """
    from ansible.plugins.vars import vars_cache
    from ansible.plugins.vars.aws_ec2 import VarsModule as aws_ec2_vars

    has_stage = hasattr(aws_ec2_vars, 'get_option') and aws_ec2_vars.has_option('stage')

    assert has_stage

    assert aws_ec2_vars.get_option('stage') is None

    assert C.VARIABLE_PLUGINS_ENABLED == ['aws_ec2']

    assert aws_ec2_vars._load_name in C.VARIABLE_PLUGINS_ENABLED

    vars_plugin_list = list(vars_loader.all())
    assert v

# Generated at 2022-06-21 09:39:41.956919
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    pass

# Generated at 2022-06-21 09:39:44.410970
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    host = Host(name='test_host')
    vars_data = {}
    vars_data = get_vars_from_path(None, None, None, None)
    assert type(vars_data) == dict

# Generated at 2022-06-21 09:39:45.968863
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    assert get_vars_from_inventory_sources() == "Yo, this is a test"

# Generated at 2022-06-21 09:39:46.706520
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    assert True

# Generated at 2022-06-21 09:39:57.495890
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    loader = vars_loader._create_loader()
    vars_loader.add_directory(os.path.join(os.path.dirname(__file__), 'test_vars_plugins'))
    result = get_vars_from_path(loader, "test_vars_plugins", None)
    assert result['test_vars_path_plugin'] == 'success'

# Generated at 2022-06-21 09:39:58.260605
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    assert False

# Generated at 2022-06-21 09:40:10.943077
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars.varsplugin import VarsModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.utils.path import unfrackpath

    class MyVarsModule(VarsModule):
        def get_vars(self, loader, path, entities):
            return {'foo': 'found'}

    data = {}
    module = AnsibleModule(argument_spec={})
    plugin = MyVarsModule()

    plugin._load_name = 'my_vars_module'
    plugin._original_path = unfrackpath('/usr/lib/python2.7/site-packages/ansible/plugins/vars')
    plugin._compat_basename = 'my_vars_module.py'


# Generated at 2022-06-21 09:40:15.620725
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    # Test a vars plugin that supports the new style API
    test_dir = os.path.join(C.DEFAULT_LOCAL_TMP, 'test_get_plugin_vars')
    os.makedirs(test_dir)
    plugin = os.path.join(test_dir, 'test_plugin')

# Generated at 2022-06-21 09:40:27.943237
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager
    from ansible.cli import CLI
    from ansible.utils.collection_loader import AnsibleCollectionLoader

    test_vars = {'test_vars_system': True,
                 'test_vars_file': True,
                 'test_vars_dir': True,
                 'test_vars_all': True,
                 'test_vars_start': True,
                 'test_vars_demand': True,
                 'test_vars_plugin_file': True,
                 'test_vars_plugin_dir': True,
                 'test_vars_plugin_all': True,
                 'test_vars_plugin_start': True,
                 'test_vars_plugin_demand': True}


# Generated at 2022-06-21 09:40:34.154459
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    host = Host('localhost')
    host.vars = {'test1': 'test1val', 'test2': 'test2val'}

    _vars = get_plugin_vars(None, host, None, None)

    assert _vars['test1'] == 'test1val'
    assert _vars['test2'] == 'test2val'

# Generated at 2022-06-21 09:40:39.908742
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager

    loader = 'ansible.parsing.dataloader.DataLoader'
    sources = 'inventory/hosts,localhost,'
    entities = ','
    stage = 'inventory'

    i = InventoryManager(loader=loader, sources=sources)
    vars = get_vars_from_inventory_sources(i, sources, entities, stage)
    print(vars)

# Generated at 2022-06-21 09:40:49.776249
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    loader = None

    sources = ["hosts.yml", "hosts.ini", "hosts.new.ini", "hosts.txt", "hosts.yaml", "hosts.yaml.j2", "hosts.yaml.jinja2", "hosts.jinja", "hosts.jinja2", "hosts.py", "hosts.cfg"]

    data = get_vars_from_inventory_sources(loader, sources, entities=None, stage='inventory')

    assert data == {'vars': {'data': 'test'}}, "data is not equal to expected result"

# Generated at 2022-06-21 09:40:58.573297
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    loader = None
    entities = []
    stage = 'inventory'

    data = {}
    path = './ansible/plugins/vars'

    vars_plugin_list = list(vars_loader.all())
    for plugin_name in C.VARIABLE_PLUGINS_ENABLED:
        vars_plugin = vars_loader.get(plugin_name)
        if vars_plugin is None:
            # Error if there's no play directory or the name is wrong?
            continue
        if vars_plugin not in vars_plugin_list:
            vars_plugin_list.append(vars_plugin)


# Generated at 2022-06-21 09:41:11.487884
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    from ansible.plugins import vars_plugins

    loader = vars_plugins.VarsModule()
    plugin = vars_plugins.VarsModule()

    # Grab the path from this file
    path = os.path.dirname(os.path.realpath(__file__))

    # Mock entities
    entities = []
    ip = Host('127.0.0.1')
    entities.append(ip)
    g = vars_plugins.VarsModule()
    entities.append(g)

    # Check that get_plugin_vars can handle a valid vars plugin
    plugin_names = vars_loader.all()

    for plugin in plugin_names:

        if plugin.has_vars():
            data = get_plugin_vars(loader, plugin, path, entities)

# Generated at 2022-06-21 09:41:30.169872
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    """
    This test checks the output of get_vars_from_inventory_sources
    :return:
    """
    from ansible.inventory.manager import InventoryManager
    from ansible.cli import CLI

    inventory_manager = InventoryManager(loader=CLI.base_parser('').get_ansible_loader())
    inventory_manager.load_inventory('test/resources/host_vars_plugins/.ansible/host_vars/localhost')
    inventory_manager.load_inventory('test/resources/host_vars_plugins/.ansible/group_vars/all')
    inventory_manager.load_inventory('test/resources/host_vars_plugins/.ansible/group_vars/all_other_vars')

# Generated at 2022-06-21 09:41:40.258322
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    # pylint: disable=unused-argument
    class FooVars(object):
        _load_name = 'foovars'
        _original_path = 'original/path'
        get_vars = lambda self, loader, path, entities: {'FooVars': True}

    class BarVars(object):
        _load_name = 'barvars'
        _original_path = 'original/path'
        get_host_vars = lambda self, hostname: {'BarVars': True}
        get_group_vars = lambda self, groupname: {'BarVars': True}

    class BazVars(object):
        _load_name = 'bazvars'
        _original_path = 'original/path'
        run = lambda self: {'BazVars': True}

# Generated at 2022-06-21 09:41:50.692770
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    test_collection = AnsibleCollectionRef("ansible_collections.testing/foo")
    plugin = vars_loader.get(test_collection)
    path = "."
    entities = [Host("hostname", groups=["group1"])]
    data = get_plugin_vars(None, plugin, path, entities)

# Generated at 2022-06-21 09:41:55.513185
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin_base
    class MyVars(vars_plugin_base.VarsBase):
        def get_vars(self, loader, path, entities):
            return {'group_vars': entities[0].name, 'host_vars': entities[1].name}

    return get_plugin_vars(None, MyVars(), None, [Host('Group'), Host('Host')])

# Generated at 2022-06-21 09:41:57.654453
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    assert get_vars_from_inventory_sources(None, ['a', None, 'b'], [], '') == {}


# Generated at 2022-06-21 09:42:06.912642
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    class AnsibleVarsPlugin1:
        def get_vars(self, loader, path, entities):
            return {'a' : 1, 'b' : 2, 'c' : 3}

    class AnsibleVarsPlugin2:
        def get_group_vars(self, group):
            return {'a' : 1, 'b' : 2, 'c' : 3}

    class AnsibleVarsPlugin3:
        def get_host_vars(self, host):
            return {'a' : 1, 'b' : 2, 'c' : 3}

    class AnsibleVarsPlugin4:
        _load_name = 'plugin4'
        REQUIRES_WHITELIST = True


# Generated at 2022-06-21 09:42:07.823984
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    pass

# Generated at 2022-06-21 09:42:09.761645
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # test_vars_plugin.py has enough coverage
    assert True

# Generated at 2022-06-21 09:42:22.643720
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    #set stage and test variable plugins
    stage = 'inventory'
    C.VARIABLE_PLUGINS_ENABLED = ['host_vars', 'group_vars']
    C.RUN_VARS_PLUGINS = 'demand'
    loader = None
    sources = [os.path.dirname(__file__)]
    entities = ['any']
    #Check plugin host_vars
    assert get_vars_from_path(loader, sources[0], entities, stage)['host_var'] == 'host_var_value'
    assert get_vars_from_path(loader, sources[0], entities, stage)['host_var_v2'] == 'host_var_value2'
    #Check plugin group_vars

# Generated at 2022-06-21 09:42:28.631975
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    class MockVars:
        def get_vars(self, loader, path, entities):
            return {'test_key': 'test_val'}

    loader = MockVars()
    path = None
    entity_list = None

    retval = get_plugin_vars(loader, loader, path, entity_list)
    assert(retval['test_key'] == 'test_val')



# Generated at 2022-06-21 09:42:54.502087
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    loader = None
    path = 'test_path'
    entities = ['entities1','entities2','entities3','entities4']
    stage = 'inventory'
    vars_plugin_list = list(vars_loader.all())
    for plugin_name in C.VARIABLE_PLUGINS_ENABLED:
        if AnsibleCollectionRef.is_valid_fqcr(plugin_name):
            vars_plugin = vars_loader.get(plugin_name)
            if vars_plugin is None:
                # Error if there's no play directory or the name is wrong?
                continue
            if vars_plugin not in vars_plugin_list:
                vars_plugin_list.append(vars_plugin)
    

# Generated at 2022-06-21 09:43:01.093622
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    # test for ansible/ansible#54015
    # get_vars_from_inventory_sources used to use os.path.dirname to get the directory
    # which would break if you pass a file path without a directory as the inventory.
    # get_vars_from_inventory_sources now passes the directory of the inventory source file
    loader = None
    sources = ['/tmp/doesntexist']
    entities = []

    result = get_vars_from_inventory_sources(loader, sources, entities, 'task')
    assert result == {}

# Generated at 2022-06-21 09:43:01.653898
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    pass

# Generated at 2022-06-21 09:43:10.562510
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    vars_plugin_list = list(vars_loader.all())
    test_path = '/path'
    test_group = Host('test_group')
    test_host = Host('test_host')
    test_entities = [test_group, test_host]

    for plugin in vars_plugin_list:
        if hasattr(plugin, 'get_option') and plugin.has_option('stage'):
            if plugin.get_option('stage') is None:
                plugin.set_option('stage', 'inventory')
            elif plugin.get_option('stage') not in ('all', 'inventory', 'task'):
                plugin.set_option('stage', 'inventory')
        else:
            plugin.set_option('stage', 'inventory')


# Generated at 2022-06-21 09:43:19.957119
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    # Test Plugin
    class TestVarsPlugin:
        def __init__(self):
            self._load_name = 'test'
            self._original_path = 'test'

        def get_vars(self, loader, path, entities):
            plugin_vars = dict()
            for entity in entities:
                for i in range(4):
                    plugin_vars[('plugin_var_%s_%s' % (entity.name, i))] = 'Plugin Vars test'
            return plugin_vars

    plugin = TestVarsPlugin()

    # Test Class
    class TestEntities:
        def __init__(self, name):
            self.name = name

    entities = []
    for i in range(2):
        entities.append(TestEntities('test_%s' % i))

    loader

# Generated at 2022-06-21 09:43:21.877446
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    result = get_plugin_vars(None, vars_loader.get("static"), "/bla", [])
    assert result == {}

# Generated at 2022-06-21 09:43:28.590330
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    data_loader = DataLoader()
    inventory = InventoryManager(loader=data_loader, sources=['./test/inventory_2.3', './test/group_vars'])
    variable_manager = VariableManager(loader=data_loader, inventory=inventory)

    data = get_vars_from_inventory_sources(data_loader, ['./test/inventory_2.3', './test/group_vars'], [inventory], 'inventory')
    assert data == variable_manager.get_vars(play=None, task=None, include_hostvars=True)

# Generated at 2022-06-21 09:43:33.602065
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    plugin_name = 'test_var_plugin.py'
    path = os.path.expanduser('~/test_var_plugin.py')
    entities = []
    plugin = vars_loader.get(plugin_name)
    ans = get_plugin_vars(None, plugin, path, entities)
    assert ans == {'test': '123'}

# Generated at 2022-06-21 09:43:44.939829
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from collections import namedtuple

    # Init inventory
    loader = DataLoader()
    inv = Inventory(loader=loader, variable_manager=VariableManager(loader=loader))
    inv.get_hosts('dummy')

    # TODO: Find a way to init the variables_manager with a inventory
    # For now get them from the plugins
    vm = namedtuple('VariableManager', 'get_vars')
    vm.get_vars = lambda: inv.get_vars()['inventory_hostname']

    # Init vars plugin
    plugin = vars_loader.get('identity.yml')
    plugin

# Generated at 2022-06-21 09:43:48.135213
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    assert get_vars_from_inventory_sources(None, [None], None, None) == {}

    assert get_vars_from_inventory_sources(None, ['/path/to/hosts'], [], 'inventory') == {}

# Generated at 2022-06-21 09:44:14.555257
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    import ansible.plugins.loader as plugin_loader
    import ansible.plugins.vars as vars_plugins
    plugin_loader.add_directory(os.path.join(os.path.dirname(__file__), '../test/vars_plugins'))
    plugin_loader.load_all()

    inventory_path = os.path.join(os.path.dirname(__file__), '../test/hosts')
    entities = {
        'group': [],
        'host': [],
    }

    # Get a 'host' plugin
    for plugin in vars_plugins.all():
        if plugin.name == 'testvars':
            result = get_plugin_vars(None, plugin, inventory_path, entities)
            assert result['testvars_plugin_var'] == 'plugin var'



# Generated at 2022-06-21 09:44:26.095754
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    data = {}
    entities = ['testentity']
    stage = 'inventory'
    path = './test_vars_plugins'

    vars_plugin_list = list(vars_loader.all())
    plugin_names = ['test_vars_plugin_get_vars', 'test_vars_plugin_get_group_vars', 'test_vars_plugin_run']
    for plugin_name in plugin_names:
        vars_plugin = vars_loader.get('test_vars_plugins.' + plugin_name)
        if vars_plugin is None:
            continue
        if vars_plugin not in vars_plugin_list:
            vars_plugin_list.append(vars_plugin)


# Generated at 2022-06-21 09:44:26.700910
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    pass

# Generated at 2022-06-21 09:44:28.255568
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    # TODO: Add some test data and assertions.
    __ = get_vars_from_inventory_sources

# Generated at 2022-06-21 09:44:34.527345
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    sources = ['/home/username/ansible/inventory/inventory_file']
    loader = "mocked_loader"
    path = os.path.dirname(sources[0])
    plugin_data = {"mocked_plugin": "some_data"}
    data = get_vars_from_inventory_sources(loader, sources, [], "inventory")
    assert data == plugin_data

# Generated at 2022-06-21 09:44:45.784804
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    class TestVarsPlugin:
        _load_name = 'test_plugin'
        _original_path = 'plugins/test/plugin'
        run = get_vars

        def get_vars(self, loader, path, entities):
            return {'test': True}

    class TestVarsPlugin2:
        _load_name = 'test_plugin2'
        _original_path = 'plugins/test/plugin2'
        run = get_vars

        def get_vars(self, loader, path, entities):
            return {'test2': True}

    loader = classobj()
    loader.list_plugin_names = classobj()
    loader.list_plugin_names.return_value = ['test_plugin', 'test_plugin2']
    loader.get = classobj()
    loader.get.return_

# Generated at 2022-06-21 09:44:48.543132
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    loader = None
    plugin = get_vars_from_path
    path = "path/vars_plugins_path"
    entities = {"group": "group_name"}
    stage = "inventory"
    assert get_plugin_vars(loader, plugin, path, entities) == {'group': 'group_name'}

# Generated at 2022-06-21 09:44:55.598867
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    class MockPlugin():
        def get_vars(self, loader, path, entities):
            return {'a': 1}

    assert get_plugin_vars(None, MockPlugin(), None, None) == {'a': 1}

    class MockPlugin():
        def get_host_vars(self, host):
            return {'a': f'{host}-a'}
        def get_group_vars(self, group):
            return {'b': f'{group}-b'}

    assert get_plugin_vars(None, MockPlugin(), None, [Host('localhost'), 'group']) == {'a': 'localhost-a', 'b': 'group-b'}

# Generated at 2022-06-21 09:44:57.595756
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    # TODO: write unit test for get_vars_from_inventory_sources
    assert False

# Generated at 2022-06-21 09:45:07.690221
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    def _test(paths, entities, stage, results):
        loader = DummyLoader()
        assert get_vars_from_inventory_sources(loader, paths, entities, stage) == results

    _test(['/etc/ansible/hosts'], ['foo'], 'inventory',
          {'group': {'foo': {'gvar': 'gx'}},
           'host': {'foo': {'hvar': 'hx'}},
           'loader': loader(path='/etc/ansible/hosts', entities=['foo'])})

# Generated at 2022-06-21 09:45:44.793100
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    # this is just a sanity check to make sure that the function works
    # because the vars plugins change often, it will not be tested
    #  in detail here.
    plugin = vars_loader.get("hashivault")
    assert plugin._load_name == "hashivault"  # getting the right plugin

# Generated at 2022-06-21 09:45:46.903765
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    assert {} == get_plugin_vars("loader", "plugin", "path", "entities")

# Generated at 2022-06-21 09:45:54.654013
# Unit test for function get_vars_from_path

# Generated at 2022-06-21 09:46:05.408063
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    inventory = '''[all:vars]
foo=bar
[ungrouped]
1.1.1.1
'''
    loader = '''#!/usr/bin/python

DOCUMENTATION = '''
    loader_class_path = '/tmp/test_get_vars_from_inventory_sources.py'

    with open(loader_class_path, 'w') as f:
        f.write(loader)

    with open('/tmp/inventory.ini', 'w') as f:
        f.write(inventory)

    result = get_vars_from_inventory_sources('/tmp/inventory.ini', ['all', 'ungrouped'])
    assert result == {'foo': 'bar'}
    os.unlink(loader_class_path)

# Generated at 2022-06-21 09:46:07.741981
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert(get_vars_from_path(None, None, None, None) == {})

# Generated at 2022-06-21 09:46:08.744718
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    pass



# Generated at 2022-06-21 09:46:10.237002
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    assert get_plugin_vars({}, {}, '', []) == {}


# Generated at 2022-06-21 09:46:20.752085
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.constants import DEFAULT_KUBERNETES_CONFIG_FILE
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.k8s.common import AUTH_ARG_SPEC
    from ansible.module_utils.k8s.raw import KubernetesRawModule
    from ansible.module_utils.k8s.common import AUTH_ARG_SPEC
    from ansible.plugins.loader import k8s_loader
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.urls import open_url, fetch_url

    from ansible.module_utils.six.moves.urllib.error import HTTPError

# Generated at 2022-06-21 09:46:30.778958
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Create a dummy vars plugin
    class DummyVarsLoader(object):
        def get(self, name):
            if name == 'dummy':
                return DummyVarsPlugin()
            else:
                return None

    class DummyVarsPlugin(object):
        def get_vars(self, loader, path, entities):
            return {'foo': 'bar'}

    # Test get_vars_from_path with a real vars plugin
    loader = DummyVarsLoader()
    vars1 = get_vars_from_path(loader, '', [], 'inventory')
    assert vars1['foo'] == 'bar'

    # Test get_vars_from_path with a fake vars plugin
    loader = DummyVarsLoader()
    vars2 = get_vars_from_path

# Generated at 2022-06-21 09:46:36.608408
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    from ansible.plugins.loader import vars_loader

    test_data = {'a': 1, 'b': 2}

    class Plugin:

        def get_vars(self, loader, path, entities):
            return test_data

    loader = None
    plugin = Plugin()
    path = None
    entities = None

    assert get_plugin_vars(loader, plugin, path, entities) == test_data

# Generated at 2022-06-21 09:47:13.775546
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.vars.vars_plugins import vars_plugins
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.utils.display import Display

    display = Display()

    # Setup a test inventory
    data = """
    [local]
    localhost ansible_connection=local ansible_python_interpreter=/usr/bin/python
    """

    ds = DataLoader()
    inv_man = InventoryManager(loader=ds, sources=data)

    # Setup a test VariableManager()
    var_man = VariableManager(loader=ds, inventory=inv_man)

    # Setup variable_manager.host_cache
    variable_

# Generated at 2022-06-21 09:47:23.141445
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.groupvars import GroupVars
    from ansible.vars.inventory_sources import InventorySources
    data = {
        "nested": {
            "a": "b"
        }
    }

    expected = {
        "nested": {
            "a": "b"
        },
        "test": "a"
    }

    class TestVars(object):
        def get_vars(self, loader, path, entities):
            return data

    class TestSources(object):
        def __init__(self):
            self._sources = [TestVars()]

    class TestLoader(object):
        def __init__(self):
            self._inventory_sources = TestSources()
            self._

# Generated at 2022-06-21 09:47:33.384380
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import vars_loader

    inventory = InventoryManager(loader=None, sources=['test/inventory'])
    loader = inventory._loader
    vars = get_vars_from_path(loader, 'test/inventory', [inventory.hosts.get('hostname')], 'inventory')

    assert vars['test_var'] == 'test_inventory_value'

    # check that the test plugin actually only runs once
    test_plugin = vars_loader.get('test_var_plugin')
    global_test_vals = test_plugin._test_vals

    assert global_test_vals['test_var'] == 1
    assert global_test_vals['test_other_var'] == 1