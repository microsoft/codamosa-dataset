

# Generated at 2022-06-21 09:38:02.253101
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.errors import AnsibleCollectionNotFound
    from ansible.plugins.loader import vars_loader
    from ansible.utils.collection_loader import AnsibleCollectionInventory

    inventory_file = 'test/units/plugins/inventory/test_vars_plugin.py'

    collection = AnsibleCollectionInventory(
        'test.test_vars_plugin',
        collection_name='test.test_vars_plugin',
        inventory_base='.',
        inventory_file=inventory_file,
        config=None,
        loader=None,
    )

    plugin = vars_loader.get('test.test_vars_plugin')
    assert plugin is not None, "test_vars_plugin collection not found"


# Generated at 2022-06-21 09:38:12.682813
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    # get_vars_from_path
    collection = 'test_collection.test_plugin'
    path = 'path'
    plugin = vars_loader.get(collection, path)
    plugin.get_vars = lambda x, y, z: {'test': 'test'}
    entities = [Host(name="test")]
    data = get_plugin_vars(None, plugin, None, entities)
    assert isinstance(data, dict)
    assert data.get('test') == 'test'
    del plugin.get_vars
    plugin.get_host_vars = lambda x: {}
    plugin.get_group_vars = lambda x: {}
    data = get_plugin_vars(None, plugin, None, entities)
    assert isinstance(data, dict)

# Generated at 2022-06-21 09:38:22.889019
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    from ansible.plugins.vars.test import TestVars
    from ansible.parsing.vault import VaultLib

    vault_password = 'VaultPassword'
    vault = VaultLib(password=vault_password)
    test_vars_plugin = TestVars(C.DEFAULT_VAULT_ID_MATCH, C.DEFAULT_VAULT_PASSWORD_FILE)
    test_vars_plugin.vault = vault

    entities = [{'name': 'test_get_plugin_vars'}]
    test_plugin_vars = get_plugin_vars(None, test_vars_plugin, None, entities)
    assert 'myhost' in test_plugin_vars
    assert 'mygroup' in test_plugin_vars
    assert test_plugin_vars['myhost']

# Generated at 2022-06-21 09:38:28.275889
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    import ansible.plugins.vars.yaml_processor

    my_vars_plugin = ansible.plugins.vars.yaml_processor.VarsModule()

    my_loader = {}

    my_path = '/path/to/my/file'

    my_entity = ['entity1', 'entity2']

    assert get_plugin_vars(my_loader, my_vars_plugin, my_path, my_entity) == {'entity1': {}, 'entity2': {}}


# Generated at 2022-06-21 09:38:32.553882
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    data = {}
    path = "test"
    entities = []

    for plugin in vars_loader.all():
        if plugin._load_name == "yaml":
            data = combine_vars(data, get_plugin_vars(loader, plugin, path, entities))



# Generated at 2022-06-21 09:38:42.299096
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import test_vars_plugin
    from ansible.plugins.loader import vars_loader

# Generated at 2022-06-21 09:38:50.082900
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.inventory import Inventory

    # Test a vars plugin with a get_vars method
    plugin_data_get_vars = {'k1': 'v1'}

    class vars_plugin_get_vars(object):
        def get_vars(self, loader, path, entities):
            return plugin_data_get_vars

    test_plugin_get_vars = vars_plugin_get_vars()

    # Test a vars plugin with legacy get_host_vars and get_group_vars methods
    plugin_data_get_vars_host = {'k1': 'v1'}
    plugin_data_get_vars_group = {'k2': 'v2'}


# Generated at 2022-06-21 09:38:57.259029
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    import sys
    sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
    from ansible.plugins.loader import vars_loader

    plugin = vars_loader.get('mytest_var')
    plugin._original_path = 'test'
    plugin._load_name = 'mytest_var'

    #test simple call
    test_data = get_plugin_vars(None, plugin, 'test_path', ['test'])
    assert test_data == {u'test': u'ok'}

    #test call with Host
    host = Host('test')
    test_data = get_plugin_vars(None, plugin, 'test_path', [host])

# Generated at 2022-06-21 09:39:07.381794
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    def _get_vars_from_path(path, entities):
        return get_vars_from_path(None, path, entities, None)

    vars_loader.add_directory(os.path.join(os.path.dirname(__file__), 'vars_plugins'))
    loader = DataLoader()
    var_manager = VariableManager(loader=loader)

    # test that __mapper__ is correctly parsed (for ansible.cfg)
    data = _get_vars_from_path(os.path.join(os.path.dirname(__file__), 'vars_plugins'), [])

# Generated at 2022-06-21 09:39:20.003084
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    from ansible.utils._text import to_bytes
    import ansible.plugins.loader

    plugin_dir = os.path.join(os.path.dirname(ansible.plugins.loader.__file__), 'vars')
    plugin_paths = [os.path.join(plugin_dir, f) for f in os.listdir(plugin_dir) if os.path.isfile(os.path.join(plugin_dir, f))]

    loader = ansible.plugins.loader.VarsModuleLoader()
    plugin = loader.find_plugin('b_vars', plugin_paths)
    path = '/tmp'
    entities = ['example.com']

    data = get_plugin_vars(loader, plugin, path, entities)
    display.display(data)

# Generated at 2022-06-21 09:39:29.837248
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # TODO: Fix this test
    pass


# Generated at 2022-06-21 09:39:39.641879
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.parsing.utils.addresses import parse_address

    loader = DictDataLoader({})

    # DictDataLoader does not resolve real paths
    sources = ['/etc/ansible/hosts']
    entities = [parse_address('example.com')]
    stage = 'task'

    assert type(get_vars_from_inventory_sources(loader, sources, entities, stage)) == dict


# Returns a data structure that looks like:
# {
#   'g1': { ... }
#   'g2': { ... }
#   'host1': { ... }
#   'host2': { ... }
# }

# Generated at 2022-06-21 09:39:50.260638
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    loader = 'fake_loader'
    fake_plugin = 'fake_plugin'
    fake_path = 'fake_path'
    fake_entities = ['fake_entities']
    fake_stage = 'fake_value'

    # test empty plugin
    vars_loader.add(fake_plugin, None)
    actual = get_vars_from_path(loader, fake_path, fake_entities, fake_stage)
    assert actual == {}

    # test plugin with get_vars()
    class Fake_plugin():
        def get_vars(self, loader, path, entities):
            return 'fake_vars'

    vars_loader.add

# Generated at 2022-06-21 09:39:55.729623
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    class DummyPlugin():
        def get_vars(self, loader, path, entities, cache=True):
            return {'a': 1}

    class DummyInventory():
        def __init__(self, path):
            self.name = path

    class DummyHost():
        def __init__(self, name):
            self.name = name

    loader = DummyPlugin()
    sources = ['/etc/hosts1', '/etc/hosts2']
    host_entities = [DummyHost('host1'), DummyHost('host2')]
    inv_entities = [DummyInventory('inv1'), DummyInventory('inv2')]


# Generated at 2022-06-21 09:39:59.986187
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert get_vars_from_path(None, "./test/data/test_inventory_override_vars", [], None) == {"test": 1, "test2": 2, "test3": 3}

# Generated at 2022-06-21 09:40:12.210183
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.utils.collection_loader import AnsibleCollectionRef

    vars_loader.add("test_vars_plugin", "my_test_folder")
    test_plugin = vars_loader.all("test_vars_plugin")[0]
    test_plugin.get_vars = lambda x,y,z: {"my": "vars"}

    assert get_vars_from_path("test","test",[], "inventory")['my'] == "vars"
    assert get_vars_from_path("test_vars_plugin","test",[], "inventory") == {}

    test_plugin = vars_loader.all("test_vars_plugin")[0]
    test_plugin.run = lambda x: None

# Generated at 2022-06-21 09:40:23.665912
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    import ansible.plugins.loader as ploader

    class MockVars(object):
        def __init__(self, name):
            self._load_name = name
            self._original_path = name

        def get_vars(self, loader, path, entities):
            return {self._load_name: path}

    class MockLoader(object):
        def __init__(self):
            self.all_candidate_vars_plugins = []
            self.all_vars_plugins = []

        def register(self, path, plugin):
            return plugin

    mock_vars = MockVars('mock_vars')
    loader = MockLoader()
    ploader.vars_loader = loader
    loader.all_vars_plugins.append(mock_vars)
    assert get_plugin_

# Generated at 2022-06-21 09:40:25.776513
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    assert(get_vars_from_inventory_sources(None, [], [], 'inventory'))

# Generated at 2022-06-21 09:40:37.429812
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'extra_var': 'extra_var_value'}
    path_inventory = '../../lib/ansible/test/test_inventory/test_plugin_group_vars_inventory/'
    inventory = InventoryManager(loader=loader, sources=[path_inventory])
    variable_manager.set_inventory(inventory)
    entities = [inventory.get_group('test_group')]
    variable_manager.inventory.set_variable(entities[0], 'ansible_group_vars_test_group', 'test_group_vars_value')

# Generated at 2022-06-21 09:40:44.699725
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.loader import vars_loader

    if not hasattr(vars_loader, 'all'):
        # ansible < 2.8, use the plugin cache instead of the loader
        from ansible.plugins.vars import vars_cache
        vars_plugin_list = vars_cache._find_plugins()
    else:
        vars_plugin_list = list(vars_loader.all())

    # we only want to test specific plugins

# Generated at 2022-06-21 09:40:57.768527
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    # --- test 01 --- #
    # no sources
    sources = None
    entities = []
    stage = None

    result_data = get_vars_from_inventory_sources(sources, entities, stage)
    assert result_data == {}

    # --- test 02 --- #
    # data from vars plugin
    sources = ['/root/ansible/my_custom_plugins/vars/variables.yml']
    entities = [1, 2]
    stage = "inventory"
    result_data = get_vars_from_inventory_sources(sources, entities, stage)
    assert result_data == {"var1": 1, "var2": 2}

    # --- test 03 --- #
    # global stage is inventory, plugin stage is task

# Generated at 2022-06-21 09:40:58.367483
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    pass



# Generated at 2022-06-21 09:41:11.332889
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.inventory.vars_plugins.test_vars import TestVars
    from ansible.inventory.vars_plugins.test_vars_v2 import TestVarsV2
    from ansible.plugins.loader import vars_loader
    vars_loader.add(TestVars())
    vars_loader.add(TestVarsV2(), 'test_vars.test_vars_v2')

    host = Host(name='test_host')
    loader = MockDataLoader()
    # Test version 1 plugin
    data = get_plugin_vars(loader, vars_loader.get('test_vars'), None, [host])
    assert data == {'test1': '1'}
    # Test version 2 plugin

# Generated at 2022-06-21 09:41:19.829318
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    test_data = {'base':{'var1':'value1'}}
    loader = None

    # Test no data
    plugin = FakePlugin()
    assert get_vars_from_path(loader, None, None, None) == {}

    # Test no plugin
    assert get_vars_from_path(loader, 'base', None, None) == {}

    # Test with plugin
    vars_loader.add(plugin)
    assert get_vars_from_path(loader, 'base', None, None) == test_data



# Generated at 2022-06-21 09:41:31.137213
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    import json
    import os
    import platform
    import sys
    import tempfile
    import unittest
    import unittest.mock
    import yaml

    import ansible.inventory.host
    import ansible.module_utils.common.collections
    import ansible.plugins.loader

    _, test_file = tempfile.mkstemp()
    with open(test_file, 'w') as f:
        f.write('{{ test_var }}')

    if not hasattr(yaml, 'CSafeLoader'):
        # yaml.CSafeLoader was new in PyYAML 5.1
        raise unittest.SkipTest('yaml.CSafeLoader is not present')

    # Testing some use cases of get_vars_from_inventory_sources
    # which is not tested by integration tests


# Generated at 2022-06-21 09:41:39.824873
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    from ansible.plugins.loader import collection_loader, vars_loader
    from ansible.plugins.vars import BaseVarsPlugin

    class MockVarsPlugin(BaseVarsPlugin):

        def get_vars(self, loader, path, entities, cache=True):
            return {'test2': True}

    assert get_vars_from_path(collection_loader, '', [], '') == {}

    collection_loader._module_cache = {}
    vars_loader._module_cache = {}
    vars_loader.add(MockVarsPlugin())

    assert get_vars_from_path(collection_loader, '/', [], '') == {'test2': True}

# Generated at 2022-06-21 09:41:47.561133
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['/usr/share/ansible/inventory/'])
    v_mgr = VariableManager()
    assert v_mgr._get_vars_from_inventory_sources(loader, inventory._sources, [Host(name='localhost')])

# Generated at 2022-06-21 09:41:56.807812
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    class FakePlugin(object):
        def get_vars(self, x, y, z):
            return {self:('get_vars', (x, y, z))}

        def get_group_vars(self, y):
            return {self:('get_group_vars', y)}

        def get_host_vars(self, y):
            return {self:('get_host_vars', y)}

    class FakeLoader(object):
        pass

    fp1 = FakePlugin()
    fp2 = FakePlugin()
    fp3 = FakePlugin()

    fake_loader = FakeLoader()

    class FakeHost(object):
        def __init__(self, name):
            self.name = name


# Generated at 2022-06-21 09:41:59.919622
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    loader, sources, entities, stage = None, 2, 3, 4
    try:
        get_vars_from_inventory_sources(loader, sources, entities, stage)
    except TypeError:
        assert True

# Generated at 2022-06-21 09:42:04.871823
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.plugins.vars.yaml_plugin import VarsModule as YAML_plugin
    from ansible.plugins.vars.ini_plugin import VarsModule as INI_plugin
    loader = VarsModule(None)

    types_of_plugins = {
        'YAML_plugin': YAML_plugin,
        'INI_plugin': INI_plugin
    }

    sources = {
        'sources': ['tests/integration/inventory/host_vars',
                    'tests/integration/inventory/host_vars/host_vars.yml',
                    'tests/integration/inventory/host_vars/host_vars.yaml',
                    'tests/integration/inventory/host_vars/host_vars.ini']
    }

    host = Host("test")

# Generated at 2022-06-21 09:42:24.557789
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.inventory.manager import InventoryManager

    data_p1 = {
        'a': 'b',
        'c': {
            'd': 'e',
            'f': {
                'g': 'h'
            }
        }
    }
    data_p2 = {
        'j': 'k',
        'c': {
            'l': 'm',
            'f': {
                'n': 'o'
            }
        }
    }
    data_p3 = {
        'c': {
            'f': 'x'
        }
    }


# Generated at 2022-06-21 09:42:34.521641
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.module_utils.common._collections_compat import Sequence
    from ansible.plugins.vars import PluginVars
    from ansible.plugins.loader import vars_loader

    class FakePluginVars(PluginVars):

        def __init__(self, *args, **kwargs):
            super(FakePluginVars, self).__init__(*args, **kwargs)
            self.args = args
            self.kwargs = kwargs

        def get_vars(self, loader, path, entities):
            return {"foo": "bar"}

    class FakeLoader(object):
        pass

    fake_loader = FakeLoader()
    fake_plugin = FakePluginVars("fake_plugin_vars")

    expected_plugin_vars = {
        "foo": "bar"
    }

    #

# Generated at 2022-06-21 09:42:46.653321
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from units.mock.loader import DictDataLoader

# Generated at 2022-06-21 09:42:56.805031
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    '''
    Unit test for function get_plugin_vars
    '''
    test_plugin = type("var_plugin", (object,), {'get_vars': lambda a, b, c: ({'key': 'value'}), 'get_host_vars': lambda a: {}, 'get_group_vars': lambda a: {}})

    loader = type("loader", (object,), {'get_basedir': lambda a: ''})

    plugin = test_plugin('')
    loader = loader()
    result = get_plugin_vars(loader, plugin, '', [])

    assert result == {'key': 'value'}

    # use get_host_vars
    entities = [type("entitiy", (object,), {'name': 'test'})]

# Generated at 2022-06-21 09:43:06.477873
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    # Create a class that at least looks like a vars plugin
    class FakeVarsPlugin:
        class FakeVarsLoader:
            def all(self):
                return [FakeVarsPlugin()]

        def __init__(self):
            self._loader = self.FakeVarsLoader()

        def get_vars(self, loader, path, entities):
            # Check that all parameters are passed as expected
            assert loader == self._loader
            assert path == '/home/somebody/ansible'
            assert entities == [Host('host1'), Host('host2')]
            return {'foo': 'bar'}

        def get_host_vars(self, host):
            assert host == 'host1'
            return {'foo': 'bar'}


# Generated at 2022-06-21 09:43:12.452356
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    from . import vars_plugin_test  # pylint: disable=unused-import

    plugin = vars_loader.get("vars_plugin_test")
    loader = None
    entities = None
    path = "~/ansible/test_data"
    stage = "task"

    data = get_vars_from_path(loader, path, entities, stage)
    expected_data = {'test_data':{'test_key':'test_value'}}
    assert data == expected_data, "get_vars_from_path returned: %s" % data


# Generated at 2022-06-21 09:43:13.315170
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    # TODO: Write test for this function
    pass

# Generated at 2022-06-21 09:43:21.952327
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    plugin = MockPlugin()

    data = {'foo': {'bar': 'baz'}, 'blip': [1, 2, 3]}

    assert get_plugin_vars(None, plugin, '', []) == data

    class MyHost(object):
        def __init__(self, name):
            self.name = name

    assert get_plugin_vars(None, plugin, '', [MyHost(name='test')]) == {'test': {'foo': 'bar'}}

    class MyGroup(object):
        def __init__(self, name):
            self.name = name

    assert get_plugin_vars(None, plugin, '', [MyGroup(name='test')]) == {'group_test': {'foo': 'bar'}}



# Generated at 2022-06-21 09:43:26.093193
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    assert get_vars_from_inventory_sources(None, [os.path.join(str(os.getcwd()), 'lib/ansible/test/test_multiple_inventories/test_vars')], ['*'], 'inventory') == \
           {'dyn_group_all': 'dyn_group_all_value, inventory', 'all': 'all_value, all'}

# Generated at 2022-06-21 09:43:31.703182
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    loader = None
    sources = ['../ansible/inventory', '../ansible/inventory/hosts']
    stage = 'inventory'
    # test list of hosts
    entities = ['host1', 'host2']
    data = get_vars_from_inventory_sources(loader, sources, entities, stage)
    # test list of groups
    entities = ['group1', 'group2']
    data = get_vars_from_inventory_sources(loader, sources, entities, stage)
    # test combination of hosts and groups
    entities = ['host1', 'group1', 'group2', 'host2']
    data = get_vars_from_inventory_sources(loader, sources, entities, stage)


# Generated at 2022-06-21 09:43:49.852352
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    test_loader = 'test_loader'
    test_sources = ['/path/to/inventory/source']
    test_entities = ['test_entity1', 'test_entity2']
    test_stage = 'inventory'
    test_vars = {'test_key': 'test_value'}

    def fake_get_vars_from_path(loader, path, entities, stage):
        assert loader == 'test_loader'
        assert path == '/path/to/inventory/source'
        assert entities == test_entities
        assert stage == 'inventory'
        return test_vars

    result = get_vars_from_inventory_sources(test_loader, test_sources, test_entities, test_stage, get_vars_from_path=fake_get_vars_from_path)


# Generated at 2022-06-21 09:43:55.423084
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    loader = vars_loader

    # Make sure we can get vars from a real plugin
    vars_plugin = vars_loader.get(C.VARIABLE_PLUGINS_ENABLED[0])
    path = '.'
    data = get_vars_from_path(loader, path, [], 'inventory')
    assert data

# Generated at 2022-06-21 09:44:01.131105
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    assert get_vars_from_inventory_sources(None, ['a'], [], "") == {}
    assert get_vars_from_inventory_sources(None, ['/dev/null'], [], "") == {}
    assert get_vars_from_inventory_sources(None, ['/dev/null, a'], [], "") == {}
    assert get_vars_from_inventory_sources(None, [], [], "") == {}

# Generated at 2022-06-21 09:44:08.006178
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.cli import CLI

    cli = CLI()
    cli._login()
    loader = cli._loader
    sources = ['/home/vagrant/sources.txt']
    entities = ('all', 'children', 'vars')
    stage = 'task'
    assert get_vars_from_inventory_sources(loader, sources, entities, stage)

# Generated at 2022-06-21 09:44:12.397456
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    data = get_plugin_vars({}, FakePlugin('first_data'), None, [])
    assert data == {'first_data': 'foo'}

    data = get_plugin_vars({}, FakePlugin('second_data'), None, [])
    assert data == {'second_data': 'bar'}


# Generated at 2022-06-21 09:44:12.959857
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    assert False

# Generated at 2022-06-21 09:44:21.713581
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    '''
    Unit test for get_plugin_vars():
    '''
    import ansible.plugins.vars.file
    sample_plugin_dict = {'int_plugin': ansible.plugins.vars.file.VarsModule}
    plugin_loader = vars_loader.get('int_plugin')
    assert get_plugin_vars(plugin_loader, plugin_loader, path="", entities="") == {}
    assert get_plugin_vars(
        vars_loader.get('int_plugin'), plugin_loader, path="", entities="") == {}

# Generated at 2022-06-21 09:44:25.223806
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    assert get_vars_from_inventory_sources(None, ['a.yaml'], None, 'inventory') == {}
    assert get_vars_from_inventory_sources(None, ['a.yaml'], None, 'task') == {}

# Generated at 2022-06-21 09:44:32.675265
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.loader import vars_loader
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.utils.yaml import from_yaml

    test_data = '''
plugin:
    test: value
'''
    plugin_name = "example"
    expected_data = {
        'plugin': {
            'test': 'value',
            'data': 'more data',
            'data2': 'more data 2'
        }
    }

    plugin = TestVarsPlugin()

    class TestLoader(object):
        def path_dwim(self, x):
            return os.path.dirname(x)

    loader = TestLoader()

    vars_plugin_list = [plugin]

# Generated at 2022-06-21 09:44:42.668243
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    loader = DataLoader()
    loader.set_vault_secrets(dict(vault_password='vault_password'))
    sources = ['test/units/lib/ansible/inventory/host_list', 'test/units/lib/ansible/inventory/host_vars/hostname/host_vars.yaml']
    result = get_vars_from_inventory_sources(loader, sources, ['hostname'], "task")
    assert(result['secret'] == 'secret')

# Generated at 2022-06-21 09:45:08.191211
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible import context
    from ansible.vars import combine_vars


# Generated at 2022-06-21 09:45:09.098694
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    pass

# Generated at 2022-06-21 09:45:11.487671
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import yamlvars
    data = yamlvars.get_vars('/a/b')
    assert data == {}

# Generated at 2022-06-21 09:45:20.065092
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.module_utils.six.moves import configparser
    from ansible.parsing.vault import VaultLib
    from ansible.plugins import vars_loader as test_vars_loader

    hc = configparser.ConfigParser()
    hc.optionxform = str  # file doesn't support unicode
    hc.read([C.DEFAULT_HOST_LIST])
    hc.set('all', 'vars_plugins', 'vars_plugin_test')

    collection = 'ansible_collections.my_namespace.my_collection'
    test_vars_loader.collection_loader.add_collection_paths(collection)

    os.environ['ANSIBLE_VAULT_IDENTITY_LIST'] = 'test_vault_identity'

# Generated at 2022-06-21 09:45:28.342339
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    loader = None
    sources = ['tests/inventory/plugins/vars/host_vars/host_vars_in_dir/hosts', 'tests/inventory/plugins/vars/group_vars/group_vars_in_dir/hosts']
    entities = ['test_host']
    stage = 'inventory'
    data = get_vars_from_inventory_sources(loader, sources, entities, stage)
    assert data['test_var_in_dir'] == "test_var_in_dir_value"
    assert data['test_var_in_dir_file'] == "test_var_in_dir_file_value"
    assert data['test_var_in_dir_dir'] == "test_var_in_dir_dir_value"

# Generated at 2022-06-21 09:45:38.665857
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    def get_vars_mock(loader, path, entities):
        if len(entities) == 2:
            return {'a': 1, 'b': 2}
        elif len(entities) == 3:
            return {'c': 3, 'd': 4}
        else:
            return {'e': 5, 'f': 6}

    def host_vars_mock(name):
        if name == 'foo':
            return {'a': 1, 'b': 2}
        elif name == 'bar':
            return {'c': 3, 'd': 4}
        else:
            return {'e': 5, 'f': 6}

    def group_vars_mock(name):
        if name == 'foo':
            return {'a': 1, 'b': 2}
        el

# Generated at 2022-06-21 09:45:48.214144
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    class fake_loader(object):
        pass
    # Create a fake 'sources' path to test
    dummy_sources = ['fake/path/sources', 'dummy/path/foo', 'another/path/bar']
    dummy_entities = [
        {'name': 'fake_host'},
        {'name': 'dummy_host'},
        {'name': 'another_host'},
        {'name': 'fake_group'},
        {'name': 'dummy_group'},
        {'name': 'another_group'}
    ]

    data = get_vars_from_inventory_sources(fake_loader, dummy_sources, dummy_entities, 'start')
    assert data == {}

# Generated at 2022-06-21 09:45:55.307600
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    '''
    Ansible needs to deprecate both the behavior of variable plugins that return
    the variable data when "set_host_var" is called and the old style of variable
    plugin file which is executed and returns data.  This is the current behavior
    that we need to also support.
    '''

    class test_plugin:
        def set_host_var(self, host, varname, value):
            return {'set_host_var': value}

    vars_dict = get_plugin_vars(None, test_plugin(), None, None)
    assert vars_dict == {'set_host_var': ''}, "Expected {'set_host_var': ''} but returned %s" % vars_dict


# Generated at 2022-06-21 09:46:06.714847
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    old_vars_plugin_list = C.VARIABLE_PLUGINS_ENABLED
    C.VARIABLE_PLUGINS_ENABLED = ('foo', 'bar')
    old_v1_plugins = C.V1_PLUGINS_ENABLED
    C.V1_PLUGINS_ENABLED = ('baz',)
    vars_plugin_list = list(vars_loader.all())
    entities = []
    old_vars_plugin_list_size = len(vars_plugin_list)
    print("Old Vars plugin list size is %d" % old_vars_plugin_list_size)
    print("Vars plugin list is %s" % vars_plugin_list)

# Generated at 2022-06-21 09:46:14.703972
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    # test no sources for var plugins
    sources = []
    entities = []
    data = get_vars_from_inventory_sources('loader', sources, entities, 'task')
    assert data == {}

    # test valid inventory sources for var plugins
    sources = ['/path/to/valid/inventory/source/file']
    entities = [Host('some.host'), Host('some.other.host')]
    data = get_vars_from_inventory_sources('loader', sources, entities, 'task')
    assert data == {}

    # test valid inventory sources for var plugins
    sources = ['/path/to/valid/inventory/source/file', '/path/to/another/valid/inventory/source/file']
    entities = [Host('some.host'), Host('some.other.host')]
    data = get_vars

# Generated at 2022-06-21 09:46:57.250517
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    # Use role_name in the collection name to avoid having set up a
    # playbook or inventory to get the collection version.
    plugin_name = 'ansible.netcommon.gather_subset'
    plugin = vars_loader.get(plugin_name)
    plugin_collection_name = plugin._collection_name
    if not plugin_collection_name:
        plugin_collection_name = os.path.join(os.path.dirname(plugin._original_path), plugin._load_name)
    plugin_collection_name = '.'.join((plugin_collection_name, plugin._load_name))
    plugin_collection_name = plugin_collection_name.replace('/', '.')

    os.environ['ANSIBLE_VARIABLE_PLUGINS_ENABLED'] = plugin_collection_name
    # Use a directory

# Generated at 2022-06-21 09:47:02.932972
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    test_vars_path = 'tests/unit/plugins/vars/'
    expected_path = {
        'version': 1,
        'vars1': 'yes',
        'vars_from_vars_plugin': 'yes',
    }
    expected_path_v2 = {
        'version': 2,
        'vars1': 'yes',
        'vars_from_vars_plugin': 'yes',
    }

    assert get_vars_from_path(None, test_vars_path, [], 'task') == expected_path
    assert get_vars_from_path(None, test_vars_path, [], 'start') == expected_path_v2
    assert get_vars_from_path(None, test_vars_path, [], 'demand') == expected

# Generated at 2022-06-21 09:47:12.697451
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    # First, we need to create a mocked ansible_collections_paths
    def mock_ansible_collections_paths():
        return ['.']

    def mock_collection_loader():
        return {
            'plugins.vars.countries': {
                'name': 'plugins.vars.countries',
                'class_name': 'Countries',
                'paths': [],
            },
            'plugins.vars.usstates': {
                'name': 'plugins.vars.usstates',
                'class_name': 'USStates',
                'paths': [],
            }
        }


# Generated at 2022-06-21 09:47:18.717039
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader

    class PluginFoo(object):
        def get_vars(self, *args, **kwargs):
            return {'foo': 1, 'bar': 2}
    class PluginBar(object):
        def get_vars(self, *args, **kwargs):
            return {'baz': 3, 'bar': 4}
    class PluginQux(object):
        def get_vars(self, *args, **kwargs):
            return {'qux': 5}
        def run(*args, **kwargs):
            return None, None

    vars_loader._create_by_name('foo', PluginFoo)
    vars_loader._create_by_name('bar', PluginBar)

# Generated at 2022-06-21 09:47:29.132498
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    # Temporarily empty vars loader
    tmp = vars_loader.all()
    vars_loader.all_vars = []

    class Plugin(object):
        _load_name = 'test'
        _original_path = '/path/to/test.py'

        def get_vars(self, loader, path, entities):
            return {'vars': 'from get_vars'}

    class PluginOld(object):
        _load_name = 'test_old'
        _original_path = '/path/to/test_old.py'

        def get_group_vars(self, name):
            return {'vars': 'from get_group_vars'}

# Generated at 2022-06-21 09:47:33.046962
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars.plugins.vars import VarsModule
    loader = None
    path = "/Users/vfarcic/repos/scratch2/tests/vars/"
    entities = []
    assert get_plugin_vars(loader, VarsModule(), path, entities) == {}