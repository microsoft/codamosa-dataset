

# Generated at 2022-06-21 09:37:55.346520
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.loader import vars_loader
    from ansible.plugins.vars import test_vars_plugin
    import mock

    def get_vars_mock(self, loader, path, entities, cache=False):
        return {'vars_plugin_test': 'yes'}
    test_vars_plugin.get_vars = get_vars_mock

    with mock.patch.object(vars_loader, 'all') as vars_loader_all:
        vars_loader_all.return_value = [test_vars_plugin]
        vars = get_plugin_vars(None, test_vars_plugin, None, [])
        assert vars['vars_plugin_test'] == 'yes'

# Generated at 2022-06-21 09:37:59.417248
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    fake_loader = None
    fake_sources = ["/home/ansible/hosts"]
    fake_entities = ["host1", "host2"]
    fake_stage = "all"
    assert get_vars_from_inventory_sources(fake_loader, fake_sources, fake_entities, fake_stage) is not None

# Generated at 2022-06-21 09:38:04.697088
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    class LocalVarsPlugin:
        _load_name = 'vars'

        def get_vars(self, loader, path, entities):
            return {'foo': 'bar'}

    loader = None
    plugin = LocalVarsPlugin()
    path = None
    entities = None
    data = get_plugin_vars(loader, plugin, path, entities)
    assert data == {'foo': 'bar'}

# Generated at 2022-06-21 09:38:14.603760
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.plugins.loader import vars_loader
    loader = vars_loader

    display = Display()
    vars_plugins_enabled = C.VARIABLE_PLUGINS_ENABLED
    C.VARIABLE_PLUGINS_ENABLED = {'vars_from_inventory_1': 'vars_from_inventory_1',
                                  'vars_from_inventory_2': 'vars_from_inventory_2',
                                  'vars_from_inventory_3': 'vars_from_inventory_3'}
    run_vars_plugins = C.RUN_VARS_PLUGINS

# Generated at 2022-06-21 09:38:20.386859
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    loader = None
    sources = ['plugins/inventory/vars.yaml']
    host = Host('test')
    entities = [host,]
    stage = 'inventory'
    result = get_vars_from_inventory_sources(loader, sources, entities, stage)
    assert result.get('test') == 'default'

# Generated at 2022-06-21 09:38:28.708057
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    import sys
    if sys.version_info >= (3, 0):
        from io import StringIO
    else:
        from StringIO import StringIO

    # Mock get_vars(loader, path, entities)
    class _MockPlugin(object):
        def get_vars(self, loader, path, entities):
            return {
                'all': {
                    'host': {
                        'name': {
                            'test_key': 'test_value',
                        },
                    },
                },
                'host': {
                    'name': {
                        'test_key': 'test_value',
                    },
                },
                'group': {
                    'name': {
                        'test_key': 'test_value',
                    },
                },
            }

    # Mock get_host_vars(self, hostname

# Generated at 2022-06-21 09:38:37.574892
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin

    class MockVarsPlugin(vars_plugin.VarsBase):
        def get_vars(self, loader, path, entities, cache=True):
            return {'mock_plugin': True}

    loader = C.VARS_PLUGIN_PATH
    plugin = MockVarsPlugin(loader, 'mock_plugin', '_original_path', None)
    path = '_path'
    entities = '_entities'

    assert get_plugin_vars(loader, plugin, path, entities) == {'mock_plugin': True}



# Generated at 2022-06-21 09:38:38.365051
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    pass

# Generated at 2022-06-21 09:38:46.156890
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    test_plugin = vars_loader.get('test_vars')
    test_path = os.path.expanduser("~/ansible_test_plugin")
    test_entities = ['host1', 'host2', 'host3']
    data = get_plugin_vars(None, test_plugin, test_path, test_entities)
    assert data[test_entities[0]] == test_entities[0]
    assert data[test_entities[1]] == test_entities[1]
    assert data[test_entities[2]] == test_entities[2]
    assert data["plugin_run_count"] == 1



# Generated at 2022-06-21 09:38:54.033857
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.loader import vars_loader
    from ansible.utils.vars import combine_vars

    class TestVars:

        def get_vars(self, loader, path, entities):
            return {'group_vars': {'all': {'is_test': True}}}

    data = {}
    loader.add(TestVars())

    data = combine_vars(data, get_plugin_vars(loader, TestVars(), '', []))
    assert data['group_vars']['all']['is_test']

# Generated at 2022-06-21 09:39:08.409037
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    assert_test_result = {'passed': 0, 'failed': 0}
    print("")
    print("Running Test: test_get_vars_from_inventory_sources")
    # First test no data
    loader = None
    sources = None
    entities = []
    stage = 'task'
    test = get_vars_from_inventory_sources(loader, sources, entities, stage)
    passed = False
    if (test):
        passed = True
    assert_test(assert_test_result, "No data", passed)
    # First test empty strings in data
    loader = ""
    sources = ""
    entities = []
    stage = 'task'
    test = get_vars_from_inventory_sources(loader, sources, entities, stage)
    passed = False

# Generated at 2022-06-21 09:39:11.186063
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    assert 'test_key' in get_vars_from_path(None, None, None, None)

# Generated at 2022-06-21 09:39:23.077955
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible_collections.ansible.community.plugins.vars import ansible_local as ansible_local_vars

    # Make sure ansible-local is always loaded so we can test it
    C.VARIABLE_PLUGINS_ENABLED.append('ansible.community.local')

    # Create a fake ansible.cfg and define the var_plugin_dir
    var_plugin_dir = '/tmp/var_plugin_dir'
    os.makedirs(var_plugin_dir)
    os.environ['ANSIBLE_CONFIG'] = '/tmp/ansible.cfg'
    with open('/tmp/ansible.cfg', 'w') as f:
        f.write('[defaults]\nvar_plugin_dir=' + var_plugin_dir + '\n')

# Generated at 2022-06-21 09:39:23.887170
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    assert True

# Generated at 2022-06-21 09:39:25.810504
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    assert get_vars_from_inventory_sources == get_vars_from_path



# Generated at 2022-06-21 09:39:27.226320
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert get_vars_from_path("/foo/bar", "demo", "demo2") == {}

# Generated at 2022-06-21 09:39:38.946259
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    vars_plugin_list = list(vars_loader.all())
    res = get_vars_from_path(None, 'tests/test_vars/vars', [], 'inventory')
    assert res == {'foo': 'ansible', 'bar': 'ansible'}

    inventory_source = 'tests/test_vars/inventory'
    res = get_vars_from_path(None, inventory_source, [], 'inventory')

    test_plugin = vars_plugin_list[0]
    assert test_plugin.name() == "test_vars"
    assert test_plugin.get_vars(None, inventory_source, None) == {'foo': 'ansible'}

    plugin = vars_plugin_list[1]

# Generated at 2022-06-21 09:39:39.860532
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    pass


# Generated at 2022-06-21 09:39:41.885252
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    pass


# Generated at 2022-06-21 09:39:45.454753
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    test_loader = [None]
    test_sources = [None]
    test_entities = [None]
    test_stage = [None]
    var_data = get_vars_from_inventory_sources(test_loader, test_sources, test_entities, test_stage)
    assert isinstance(var_data, dict)

# Generated at 2022-06-21 09:39:51.207798
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    assert get_vars_from_inventory_sources(None, [None], None, None) == {}

# Generated at 2022-06-21 09:39:51.792917
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    pass

# Generated at 2022-06-21 09:40:02.105003
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Load the test plugins
    load_plugins = vars_loader.get("nested_vars_plugin")

    # Set the path and entities for the test
    path = "/path/to/dir/with/vars/test.vars"
    host = Host("testserver")
    host.vars = {'testing': 'test'}
    entities = [ host ]

    # Run the function for testing
    data = get_vars_from_path(None, path, entities, "inventory")

    # Test the result
    assert data['nested']['var'] == 'test_inv'

# Generated at 2022-06-21 09:40:13.849516
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    import yaml

    class _Loader:
        def __init__(self):
            self.path = None
            self.data = {}

        def get_basedir(self, path):
            return os.path.dirname(path)

        def get_content(self, path):
            if os.path.exists(path):
                return yaml.safe_load(open(path))
            elif path in self.data:
                return yaml.safe_load(self.data[path])
            else:
                raise AnsibleError("%s not found" % path)

    loader = _Loader()

    class _Plugin:
        def __init__(self, name):
            self._name = name

        def get_vars(self, loader, path, entities):
            return {self._name: path}

    plugin

# Generated at 2022-06-21 09:40:25.829476
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # set up vars and plugins
    from ansible.plugins.vars import aws_ec2
    from ansible.plugins.vars import identity
    from ansible.plugins.vars import github
    from ansible.plugins.vars import namespace

    # create some fake plugins to test with
    class TestVarsPlugin():
        REQUIRES_WHITELIST = False
    class TestVarsPluginRequiresWhitelist():
        REQUIRES_WHITELIST = True
    class TestVarsPluginHasStage():
        REQUIRES_WHITELIST = False
        def __init__(self):
            self.options = {}
        def has_option(self, option):
            return option in self.options
        def get_option(self, option):
            return self.options[option]

    # test that plugins

# Generated at 2022-06-21 09:40:37.480367
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    class DummyVarsPlugin(object):

        def get_options(self):
            return {}

        def get_vars(self, loader, path, entities):
            if 'is_special' in path:
                return {'special': 'some_val'}
            return {}

        def get_host_vars(self, host):
            return {'host': host}

        def get_group_vars(self, group):
            return {'group': group}

    loader = DummyVarsPlugin()
    path = None

    assert get_vars_from_path(loader, path, [], 'inventory') == {}

    host = Host(name='host')

# Generated at 2022-06-21 09:40:44.717399
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.utils.vars import combine_vars

    assert combine_vars(var1={'a': 1}, var2={'b': 2}) == {'a': 1, 'b': 2}
    assert combine_vars(var1={'a': 1}, var2={'a': 2}) == {'a': 2}
    assert combine_vars(var1={'a': [1, 2]}, var2={'a': [3, 4]}) == {'a': [3, 4]}
    assert combine_vars(var1={'a': [1, 2]}, var2={'a': 2}) == {'a': [1, 2]}
    assert combine_vars(var1={'a': 1}, var2={'a': [2, 3]}) == {'a': [2, 3]}

# Generated at 2022-06-21 09:40:55.627921
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    import ansible.plugins.vars.host_group_vars
    import ansible.plugins.vars.group_vars
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    data = {}
    loader = DataLoader()
    host = Host('localhost')
    group = Host('localhost/group1')
    group1 = Host('localhost/group2')
    group2 = Host('localhost/group3')
    # test case where vars is a dictionary
    v1 = ansible.plugins.vars.group_vars.VarsModule()
    v1.get_vars = lambda x, y, z: {'test': 'value'}
    v2 = ansible.plugins.vars.host_group_vars.VarsModule()
   

# Generated at 2022-06-21 09:41:08.460163
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    load_result = {'a': {'b': {2: 3, 'c': 4}}}
    test_plugin_name = __name__ + '.test_plugin.test_plugin'
    test_plugin = getattr(__import__(test_plugin_name, fromlist=["*"]), 'test_plugin')
    loader = getattr(__import__(__name__ + '.vars_loader', fromlist=["*"]), 'vars_loader')
    plugin_mock = type('plugin_mock', (object,), {'_load_name': test_plugin_name, 'get_vars': test_plugin.get_vars})
    result = get_plugin_vars(loader, plugin_mock, '/path/to/somewhere', [])
    assert load_result == result

# Generated at 2022-06-21 09:41:15.551361
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    import collections
    import copy
    import re

    from ansible.module_utils._text import to_text

    from ansible.plugins.vars import vars_plugin

    from ansible.plugins.vars import auto

    orig_path = auto.__path__[0]
    test_path = os.path.join(os.path.dirname(__file__), 'test_vars_plugin')
    auto.__path__.insert(0, to_text(test_path))

    vars_loader.add_directory(auto.__path__[0])

    def teardown_module():
        auto.__path__.remove(auto.__path__[0])
        auto.__path__.insert(0, orig_path)


# Generated at 2022-06-21 09:41:33.548140
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.parsing.dataloader import DataLoader
    from ansible.module_utils.collection_loader import AnsibleCollectionRef

    loader = DataLoader()

    # Test when all plugins have been whitelisted
    assert(get_vars_from_path(loader, '/path/to/inventory/file', [], 'inventory') ==
           {'plugin_a_data': 'plugin_a_value', 'plugin_b_data': 'plugin_b_value'})

    # Test when a plugin has not been whitelisted
    plugin_a = AnsibleCollectionRef.create('ansible.vars_plugins.plugin_a')
    loader.module_finder._module_cache[plugin_a.module_name] = plugin_a

# Generated at 2022-06-21 09:41:42.729643
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.loader import vars_loader
    from ansible.plugins.vars import BaseVarsPlugin

    class BadVarsPlugin(BaseVarsPlugin):
        pass

    class GoodVarsPlugin:
        def __init__(self):
            self._load_name = 'good_vars_plugin'

        def get_vars(self, loader, path, entities):
            return {'bad': 'bad'}

    class BetterVarsPlugin:
        def __init__(self):
            self._load_name = 'better_vars_plugin'
            self._name = 'better'
            self._original_path = 'path'

        def get_vars(self, loader, path, entities):
            return {'good': 'good'}


# Generated at 2022-06-21 09:41:46.209954
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    assert get_vars_from_inventory_sources(None, ['foo'], None, None) == {}
    assert get_vars_from_inventory_sources(None, [None], None, None) == {}

# Generated at 2022-06-21 09:41:55.590227
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.common.collections import ImmutableDict

    this_dir = os.path.dirname(os.path.realpath(__file__))
    data_loader = DataLoader()

    inventory_manager = InventoryManager(loader=data_loader, sources=[os.path.join(this_dir, '../test/test_data/test_vars_plugin/hosts.yml')])
    variable_manager = VariableManager(loader=data_loader, inventory=inventory_manager)

    test_host = inventory_manager.get_host('test_host')
    assert test_host._resource_cache['vars'] == ImmutableD

# Generated at 2022-06-21 09:42:05.281502
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    '''
    Unit test for get_vars_from_inventory_sources() function
    '''
    from ansible.inventory.manager import InventoryManager

    INVENTORY_PATH = os.path.join(C.TEST_DIR, 'test_inventory')
    sources = [os.path.join(INVENTORY_PATH, 'hosts')]

    # Success tests
    # get_vars_from_inventory_sources() should return group_vars and host_vars for the groups and hosts in the inventory host's file.
    inventory = InventoryManager(sources=sources)
    entities = inventory.get_hosts()
    entities.extend(inventory.groups.values())
    data = get_vars_from_inventory_sources(None, sources, entities, 'inventory')

    # Check that all the group

# Generated at 2022-06-21 09:42:18.731466
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.cli import CLI
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    cli = CLI(args=[])
    cli.parse()
    Options = cli.options
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    inventory._inventory.hosts = [Host(name='localhost')]
    inventory._inventory.groups = [inventory.new_group('all')]
    for host in inventory._inventory.hosts:
        inventory._inventory.groups[0].add_host(host)

    expected_plugin_name = 'plugin'

# Generated at 2022-06-21 09:42:27.202046
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    paths_that_exist = [os.path.join(C.DEFAULT_LOCAL_TMP, 'test_vars_loader')]
    for path in paths_that_exist:
        os.makedirs(path)
        os.makedirs(os.path.join(path, 'group_vars', 'test_group'))
        path = os.path.join(path, 'group_vars', 'test_group', 'vars.yml')
        with open(path, 'wt') as f:
            f.write('test_var: test_val')

    inventory_source = ','.join(paths_that_exist)
    loader = 'ansible.parsing.dataloader.DataLoader'
    sources = [inventory_source]
    entities = ['test_group']
    stage

# Generated at 2022-06-21 09:42:36.497360
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    """
    Test the get_vars_from_path function
    """
    loader = 'test'
    path = '/path/to/ansible'
    entities = [loader, path]
    require_whitelist = 'test'
    display = 'test'
    stage = 'inventory'

    vars_loader.add_directory(path)

    for plugin in vars_loader.all():

        if plugin._load_name not in C.VARIABLE_PLUGINS_ENABLED and getattr(plugin, 'REQUIRES_WHITELIST', False):
            continue

        has_stage = hasattr(plugin, 'get_option') and plugin.has_option('stage')

        # if a plugin-specific setting has not been provided, use the global setting
        # older/non shipped plugins that don't support the plugin

# Generated at 2022-06-21 09:42:48.504029
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.errors import AnsibleError
    from ansible.inventory.host import Host
    from ansible.utils.collection_loader import AnsibleCollectionLoader

    class TestPluginLoader:

        def all(self):
            return []

        def get(self, name):
            return None

    class TestHost(Host):

        def __init__(self, name):
            super(TestHost, self).__init__(name)

    loader = TestPluginLoader()
    sources = ['/path/to/inventory']

    entities = [TestHost('host1'), TestHost('host2')]

    # no vars plugin available, will return empty dict.

# Generated at 2022-06-21 09:42:54.111484
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    host = Host('localhost')
    host.set_variable('ansible_python_interpreter', 'bar')

    test_data = get_vars_from_path({}, './tests/plugins/vars/', [host], 'task')

    assert test_data['foobar'] == 'bar'
    assert test_data['foobaz'] == 'foo'

# Generated at 2022-06-21 09:43:30.631255
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    plugin_file = {}
    vars_plugin_list = []
    for name in C.VARIABLE_PLUGINS_ENABLED:
        plugin_file = __import__('ansible.plugins.vars', globals(), locals(), [name])
        vars_plugin_list.append(getattr(plugin_file, name))

    get_vars_from_inventory_sources(None, ['../test/integration/targets/variable_plugins/'], None, None)

# Generated at 2022-06-21 09:43:38.618462
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.vars.hostvars import HostVars

    # Create a mock loader object
    class MockLoader(object):
        def __init__(self, host_list=None, group_list=None):
            self.host_list = host_list
            self.group_list = group_list

    # Test path /home/test/vars_dir
    # Create a mock hostvars plugin object
    class MockHostVars(object):
        def __init__(self, host_var_dict, group_var_dict):
            self.host_var_dict = host_var_dict
            self.group_var_dict = group_var_dict

        def get_vars(self, loader, path, entities):
            vars_data = {}

# Generated at 2022-06-21 09:43:49.274710
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.loader import cached

    # Test default behavior
    assert get_plugin_vars(None, cached.VarsModule(), "path", []) == {}
    # Test old behavior
    assert get_plugin_vars(None, cached.VarsModule(), "path", [Host("test")]) == {}

    # Test new behavior
    assert get_plugin_vars(None, cached.NewVarsModule(), "path", [Host("test")]) == {'test': {'test_var': 'Test Value'}}
    assert get_plugin_vars(None, cached.NewVarsModule(), "path", [Host("test1")]) == {'test1': {'test_var': 'Test Value'}}

    # Test new behavior with list

# Generated at 2022-06-21 09:43:58.209006
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager

    test_inventory_file = './lib/ansible/playbooks/inventory/test_inventory_data'

    inventory_manager = InventoryManager(loader=None, sources=test_inventory_file)

    inventory = inventory_manager.inventory
    data = get_vars_from_path(loader=None, path='ansible/playbooks', entities=inventory.hosts.values(), stage='task')

    assert 'ansible_playbooks' in data
    assert 'bananas' in data['ansible_playbooks']
    assert 'pears' in data['ansible_playbooks']
    assert 'type' not in data['ansible_playbooks']

# Generated at 2022-06-21 09:44:05.511383
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.utils.addresses import parse_address
    from ansible.utils.path import unfrackpath
    from ansible.utils.collection_loader import AnsibleCollectionFinder

    cwd = os.getcwd()
    path0 = unfrackpath(cwd + "/lib/ansible/plugins/vars/foovars.py")
    path1 = unfrackpath(cwd + "/lib/ansible/plugins/vars/foovars/")
    path2 = unfrackpath(cwd + "/lib/ansible/plugins/vars/foovars/vars.py")
    path3 = unfrackpath(cwd + "/lib/ansible/plugins/vars/foovars/vars.yaml")
    path4 = unfrack

# Generated at 2022-06-21 09:44:09.035025
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    import mock
    from ansible.module_utils._text import to_bytes
    import tempfile
    import json

    # Test that get_vars_from_inventory_sources ignores the host list file name
    config = mock.Mock()
    config.config_data = {b'host_record_priorities': [b'vars_files', b'inventory', b'fact']}
    config.get_config_value = lambda key, default: config.config_data.get(key, default)
    with tempfile.NamedTemporaryFile() as f:
        loader = mock.Mock()
        loader.path_dwim = lambda path: path
        loader.file_exists = lambda path: f.name in path
        loader.is_file = lambda path: True

# Generated at 2022-06-21 09:44:20.177962
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host


# Generated at 2022-06-21 09:44:21.757860
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    pass


# Generated at 2022-06-21 09:44:22.396996
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    pass

# Generated at 2022-06-21 09:44:31.147857
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    import tempfile
    import os

    from ansible.parsing.dataloader import DataLoader

    sys_paths = [os.path.join(C.DEFAULT_MODULE_PATH, os.path.pardir, 'plugins', 'vars')]
    sys_paths.insert(0, os.path.join(C.DEFAULT_MODULE_PATH, os.path.pardir, 'lib', 'ansible'))

    # create a temp file to work with
    tmp_fd, tmp_path = tempfile.mkstemp()
    os.close(tmp_fd)
    inv_path = tmp_path + '.yml'

    # create a temp collection
    collection_dir = tempfile.mkdtemp()
    collection_dir_1 = os.path.join(collection_dir, 'x')


# Generated at 2022-06-21 09:45:23.719264
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    from ansible.plugins.loader import vars_loader

    loader = DummyLoader()                                                                                                                
    path = "/etc"
    entities = [Host("host1"), Host("host2")]
    stage = "inventory"

    data = get_vars_from_path(loader, path, entities, stage)

    assert data['inv_source'] == path
    assert data['entities'] == entities

    data = get_vars_from_path(loader, "/etc", entities, stage)
    assert data == {}

    data = get_vars_from_path(loader, "/etc/ansible", entities, stage)
    assert data['inv_source'] == "/etc/ansible"
    assert data['entities'] == entities



# Generated at 2022-06-21 09:45:25.602937
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    loader = None
    plugin = None
    path = None
    entities = None
    result = get_plugin_vars(loader, plugin, path, entities)
    assert None is result

# Generated at 2022-06-21 09:45:31.508283
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    """
    Load plugins and create a list of inventory sources to get variables from
    """
    sources = ['.', './test_plugins/inventory/']

    # Get plugins
    loader, inventory_loader, cache = loader_mock()
    all_vars_plugins = vars_loader.all(inventory_loader=inventory_loader)

    # Create vars plugin

# Generated at 2022-06-21 09:45:33.208525
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert get_vars_from_path(None, '.', None, None) == {}

# Generated at 2022-06-21 09:45:43.740710
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.parsing.dataloader import DataLoader

    fake_loader = DataLoader()

    # create list of fake sources
    sources = []
    for path in ['~/fake_path/', 
                 '~/fake_path/fake_group_vars', 
                 '~/fake_path/fake_host_vars',
                 '~/fake_path/no_vars_here',
                 '~/fake_path/fake_group_vars/fake_group_vars1',
                 '~/fake_path/fake_host_vars/fake_host_vars1']:
        sources.append(fake_loader.path_dwim(path, True))

    # TODO: create mocks for

# Generated at 2022-06-21 09:45:52.654400
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    # vars_from_path should return data from 1st plugin
    vars_from_path_plugin1 = {'plugin1': 'plugin1'}
    vars_from_path_plugin2 = {'plugin2': 'plugin2'}
    loader = mock_loader(vars_from_path_plugin1, vars_from_path_plugin2)
    assert get_vars_from_inventory_sources(loader, ['host_vars'], ['host1'], 'inventory') == vars_from_path_plugin1

    # get_vars_from_inventory_sources should return data from all plugins
    expected_data = {'plugin1': 'plugin1', 'plugin2': 'plugin2'}

# Generated at 2022-06-21 09:46:03.397580
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager

    inventory = InventoryManager(loader=None, sources=['/usr/local/ansible/inventory'])
    sources = ['/usr/local/ansible/inventory']

    # We need to overwrite the collections_paths to run the test in a "isolated" environment
    for c in vars_loader.all():
        c.collections_paths = ['/usr/local/ansible/test/unit/plugins/test_collections/collections/ansible_collections/test/test_plugins/plugins/vars/']

    # We need to add the plugins to the file_loader because they are missing in the isolated environment
    vars_loader.add(['test.test_plugins.plugins.vars.plugin1'])

# Generated at 2022-06-21 09:46:12.535134
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    """Required plugin: vars_plugin_test.py
    """

    from ansible.plugins.vars import vars_plugin_test

    def load_module(name):
        return None

    loader_name = 'loader'
    path = 'path'
    entity = 'host1'

    vars_plugin = vars_plugin_test.VarsModule(loader_name, 'vars_plugin', '/usr/share/ansible')
    plugin_data = get_plugin_vars(load_module, vars_plugin, path, entity)
    assert plugin_data['_loader_name'] == loader_name
    assert plugin_data['_path'] == path
    assert plugin_data['_entity'] == entity
    assert not plugin_data['_plugin_data']

# Generated at 2022-06-21 09:46:15.974559
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    class SamplePlugin:

        def get_vars(self, loader, path, entities):
            return {'var1': 'foo'}

    assert get_plugin_vars(None, SamplePlugin(), None, None) == {'var1': 'foo'}

# Generated at 2022-06-21 09:46:17.660532
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    assert False  # TODO: Implement test!
