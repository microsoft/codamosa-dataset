

# Generated at 2022-06-21 09:38:02.066705
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    loader = None
    path = "/path/to/test/vars"
    entities = ['test_host1', 'test_host2']
    stage = 'inventory'
    # expected data
    var_data1 = {'var1': 'value1', 'var2': 'value2'}
    var_data2 = {'var3': 'value3'}
    data = combine_vars(var_data1, var_data2)

    data_from_plugin = get_plugin_vars(loader, [var_data1, var_data2], path, entities)
    assert data == data_from_plugin

    data_from_path = get_vars_from_path(loader, path, entities, stage)
    return data == data_from_path



# Generated at 2022-06-21 09:38:12.606487
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars.host_group import HostGroupVarsPlugin
    from ansible.plugins.vars.group_vars import GroupVarsPlugin
    from ansible.plugins.vars import VarsModule
    from ansible.inventory.host import Host

    # v2 plugin
    plugin = HostGroupVarsPlugin()
    loader = None
    path = 'path'
    entities = [Host('test')]
    data = get_plugin_vars(loader, plugin, path, entities)
    assert data == {'hostvars': {'test':{}}}

    # v1 plugin
    plugin = GroupVarsPlugin()
    loader = None
    path = 'path'
    entities = ['test']
    data = get_plugin_vars(loader, plugin, path, entities)
    assert data == {}

   

# Generated at 2022-06-21 09:38:13.996273
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    assert {} == get_vars_from_inventory_sources('loader', [None], [], 'inventory')

# Generated at 2022-06-21 09:38:20.818804
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin

    test_plugin = vars_plugin.VarsModule()
    test_plugin._load_name = 'fake_name'
    test_plugin._original_path = '/path/to/fake'

    inventory_entities = ['test_entity']
    data = get_plugin_vars(None, test_plugin, None, inventory_entities)
    assert data == {}

# Generated at 2022-06-21 09:38:28.692801
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    '''
    Test functionality of get_vars_from_inventory_sources
    '''
    import ansible.plugins.vars as vars_plugins
    from ansible.cli import CLI

    print("Running function get_vars_from_inventory_sources")

    # Create test directory
    test_dir = "test_dir"
    if not os.path.exists(test_dir):
        os.makedirs(test_dir)

    # Create mock inventory file
    mock_path = test_dir + "/mock_inv.txt"
    with open(mock_path, 'w') as mock_file:
        mock_file.write("mock")

    # Create mock group_vars directory
    group_vars_dir = test_dir + "/group_vars"
    os.makedirs

# Generated at 2022-06-21 09:38:39.321804
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = None
    path = './test/data/precedence'
    host = Host('test')
    group = Group('test')
    entities = [host, group]

    vm = VariableManager(loader=loader)
    vm.set_inventory(InventoryManager(loader=loader, sources=path))

    # get_vars_from_path should be able to load variables from 2.0 vars plugins stored in inventory directory
    vars_plugin_list = list(vars_loader.all())

# Generated at 2022-06-21 09:38:48.087907
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from units.mock.loader import DictDataLoader
    from units.mock.plugins.loader import PluginLoader
    from units.mock.plugins.source_vars import PluginVars
    import os

    expected_results = {
        'vars': {
            'x': 1,
            'y': 2,
            'z': '3',
        },
        'vars_start': {
            'x': 4,
            'y': 5,
            'z': '6',
        },
        'vars_inventory': {
            'x': 7,
            'y': 8,
            'z': '9',
        },
    }

    class TestPlugin(PluginVars):

        def get_vars(self, loader, path, entities):
            data = {}

# Generated at 2022-06-21 09:38:53.339130
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    data = {}
    sources = ['/tmp/inventory', '/tmp/hosts']
    entities = ['host', 'host2']
    stage = 'task'

    data = combine_vars(data, get_vars_from_path(sources, entities, stage))

    assert data == {}

# Generated at 2022-06-21 09:39:02.013101
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    from unittest2 import TestCase
    from ansible.module_utils.six import PY3, iteritems

    class GetPluginVarsTestCase(TestCase):
        def setUp(self):
            self.real_vars_plugin_list = vars_loader.all()
            self.real_VARIABLE_PLUGINS_ENABLED = C.VARIABLE_PLUGINS_ENABLED

            class ImplicitVarsPlugin(object):
                def get_vars(self, loader, path, entities):
                    return {'vars_from': 2}

            class ExplicitVarsPlugin(object):
                def get_vars(self, loader, path, entities):
                    return {'vars_from': 3}


# Generated at 2022-06-21 09:39:04.901923
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert get_vars_from_path(None, "/tmp/nonsense/test_get_vars_from_path", [], "inventory") == {}

# Generated at 2022-06-21 09:39:22.432469
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_init

    test_collection_collection_namespace = 'test_namespace'

    vars_init.init_vars_plugins(display=display)

    test_collection_collection = vars_loader.get(test_collection_collection_namespace + '.test_collection')
    assert test_collection_collection

    test_plugin_name = 'test_plugin'
    test_plugin_plugin_name = test_collection_collection_namespace + '.' + test_plugin_name
    test_plugin = vars_loader.get(test_plugin_plugin_name)
    assert test_plugin

    # test v2 plugin

# Generated at 2022-06-21 09:39:31.098629
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    class TestPlugin:
        def get_vars(self, *args, **kwargs):
            return {'x':'y'}
        def run(self, *args, **kwargs):
            return {'x':'y'}

    loader = None
    path = '/path/to/thing'
    entities = ['pizza', 'fish']
    stage = 'inventory'

    # test None
    vars = get_vars_from_path(loader, path, entities, stage)
    assert vars == {}

    # test with plugin of old type
    vars = get_vars_from_path(loader, path, entities, stage, [TestPlugin()])
    assert vars['x'] == 'y'

    # test with valid plugin

# Generated at 2022-06-21 09:39:36.749570
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    from ansible.inventory.host import Host
    from ansible.plugins.loader import vars_loader
    import tempfile

    tmp = tempfile.NamedTemporaryFile(delete=False)
    pathname = tmp.name

# Generated at 2022-06-21 09:39:45.654734
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars.plugin_loader import PluginLoader

    plugin = MockVarsPlugin()

    loader = PluginLoader('/path/to/non/existing/directory', 'vars', 'vars_plugins')
    loader._get_categories = lambda: ['test']
    loader._get_plugins_by_category = lambda category: [plugin]
    loader.all = lambda: [plugin]

    assert get_plugin_vars(loader, plugin, '/path/to/non/existing/directory', entities=[]) == {'test': 'ok'}



# Generated at 2022-06-21 09:39:46.664946
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    assert False, "Unit tests are not implemented for this module"

# Generated at 2022-06-21 09:39:50.261793
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.loader import vars_loader
    from ansible.plugins.vars.test_vars_plugin import TestVarsModule
    vars_loader.add(TestVarsModule, 'test_vars_plugin')

    assert get_plugin_vars(None, TestVarsModule(), None, ['fake']) == {'test': 'success'}

# Generated at 2022-06-21 09:39:50.712581
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    pass

# Generated at 2022-06-21 09:40:03.798234
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible_collections.ansible.community.tests.unit.plugins.test_vars_plugins import TestVarsPluginDynamicV2
    import ansible.plugins.loader as ploader

    class FakeVarPlugin:
        def __init__(self, *args, **kwargs):
            self.foo = 1

        def get_vars(self, *args, **kwargs):
            return dict(foo=1)

    class FakeInventoryPlugin:
        def __init__(self, *args, **kwargs):
            self.foo = 2

        def get_host_vars(self, *args, **kwargs):
            return dict(foo=2)


# Generated at 2022-06-21 09:40:14.741924
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    # Empty data
    data = {}
    assert get_vars_from_path(None, None, None, 'task') == data

    # No vars plugins enabled
    C.VARIABLE_PLUGINS_ENABLED = []
    assert get_vars_from_path(None, None, None, 'task') == data

    # Vars plugins enabled but run_vars_plugins is not set
    C.VARIABLE_PLUGINS_ENABLED = ['vars_file']
    C.RUN_VARS_PLUGINS = None
    assert get_vars_from_path(None, None, None, 'task') == data

    # Vars plugins enabled but run_vars_plugins is set to 'demand'
    C.RUN_VARS_PLUGINS = 'demand'
    C

# Generated at 2022-06-21 09:40:26.922054
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    # Plugin does not support get_vars method
    class A:
        _load_name = "A"
        _original_path = "A.py"

        def get_host_vars(self, host):
            return {"x": "a"}

    a = A()
    loader = None
    path = "some_path"
    entities = [Host("example.com")]
    assert get_plugin_vars(loader, a, path, entities) == {"x": "a"}

    # Plugin supports get_vars method
    class B:
        _load_name = "B"
        _original_path = "B.py"

        def get_vars(self, loader, path, entities):
            return {"y": "b"}

    b = B()

# Generated at 2022-06-21 09:40:36.918754
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert get_vars_from_path(None, "path/to/file", None, None)

# Generated at 2022-06-21 09:40:42.381082
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    myinv = InventoryManager(loader=None, sources=['/tmp/foo'])
    myinv.add_group('mygroup')
    myinv.add_host('myhost', groups=['mygroup'])
    myinv.add_host('otherhost')
    assert get_vars_from_inventory_sources(None, myinv.sources, [myinv.groups['mygroup'], myinv.hosts['otherhost']], 'inventory') == {}

# Generated at 2022-06-21 09:40:49.668372
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    # test collection load
    yaml_data = get_vars_from_path(None, '', None, 'start')
    assert yaml_data['ansible_version']['full'] is not None

    # test v2 vars plugin path
    yaml_data = get_vars_from_path(None, 'tests/vars_plugins/', None, 'start')
    assert yaml_data['test_vars_plugin_yaml'] == 'success'

# Generated at 2022-06-21 09:40:53.613288
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    assert get_vars_from_inventory_sources(None, ['/home/samples/ansible.cfg'], None, None) == {} and \
        get_vars_from_inventory_sources(None, ['/home/ansible'], None, None) == {}

# Generated at 2022-06-21 09:41:04.095140
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    # TODO: This test is broken
    class FakeVarsPlugin():
        def get_vars(self, loader, path, entities):
            assert(loader)
            assert(path)
            assert(entities)
            return dict(a=1)

    result = get_plugin_vars(None, FakeVarsPlugin(), None, None)
    assert(result == dict(a=1))

    class FakeVarsPlugin():
        def get_group_vars(self, name):
            return dict(a=1)

    result = get_plugin_vars(None, FakeVarsPlugin(), None, ['test'])
    assert(result == dict(a=1))

# Generated at 2022-06-21 09:41:13.861469
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    import unittest
    import sys
    from ansible.plugins.vars import ini_vars

    class FakePlugin(object):
        def get_vars(self, *args, **kwargs):
            return {
                'a': 'b',
                'c': 'd'
            }

    class FakePlugin2(object):
        def run(self):
            return {
                'a': 'b',
                'c': 'd'
            }

    class FakePlugin3(object):
        def get_host_vars(self, *args, **kwargs):
            return {
                'a': 'b',
                'c': 'd'
            }


# Generated at 2022-06-21 09:41:19.364357
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    # TODO: extend this to test merging with other dicts (set, dict, etc)
    # TODO: test the returned merged dict type
    assert type(get_plugin_vars(None, {'get_vars': lambda path: {'foo': 'bar'}}, None, None)) == dict

# Generated at 2022-06-21 09:41:29.997266
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    import ansible.plugins.loader
    ansible_vars_dir = os.path.join('test', 'data', 'test_vars_plugin_dir')
    loader = ansible.plugins.loader.PluginLoader(
        'vars',
        'test',
        None,
    )
    loader.add_directory(ansible_vars_dir)
    data = get_vars_from_path(loader, ansible_vars_dir, [], None)
    assert data["foo"] == "bar"
    assert data["baz"] == "foo"
    assert data["dict"] == {"a": 1, "b": 2}
    assert data["dict2"] == {"a": "foo", "b": 1234}

# Generated at 2022-06-21 09:41:40.056354
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    class TestLoader:
        def __init__(self):
            sources = ['./data/inventory_plugins/vars_plugins/']
            sources_data = [
                {'path': sources[0],
                 'data': get_vars_from_path(self, sources[0], ['all'], 'inventory')}
            ]
            self._inventory_sources_data = sources_data

        def __getitem__(self, item):
            return self._inventory_sources_data[0]['data']


    class UnitTestHost:
        def __init__(self, hostname):
            self.name = hostname

    loader = TestLoader()
    host = UnitTestHost('host1')

# Generated at 2022-06-21 09:41:45.686978
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    assert get_vars_from_inventory_sources(loader=None, sources=["my_dir"], entities=None, stage='inventory') == {}
    assert get_vars_from_inventory_sources(loader=None, sources=[None], entities=None, stage='inventory') == {}
    assert get_vars_from_inventory_sources(loader=None, sources=["my_dir", "my_dir"], entities=None, stage='inventory') == {}

# Generated at 2022-06-21 09:42:27.361460
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    class MockPlugin():
        def get_vars(self, loader, path, entities):
            return {'vars_plugin': 'all'}

        def get_host_vars(self, host):
            return {'vars_plugin': 'host'}

        def get_group_vars(self, group):
            return {'vars_plugin': 'group'}

    class MockHost():
        name = 'localhost'

    class MockGroup():
        name = 'default'

    class MockLoader():
        pass

    loader = MockLoader()
    plugin = MockPlugin()
    path = '../'

    # Test if get_vars is implemented in the plugin
    assert get_plugin_vars(loader, plugin, path, [MockHost()]) == {'vars_plugin': 'all'}
    assert get

# Generated at 2022-06-21 09:42:28.776518
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    assert get_vars_from_inventory_sources(None,"", []) == {}

# Generated at 2022-06-21 09:42:31.918688
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugin_basic

    data = get_plugin_vars("loader", vars_plugin_basic, "path", "entities")

    assert data == {}

# Generated at 2022-06-21 09:42:37.322971
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    sources = [
        "/etc/ansible/test.yaml",
        "test1.yaml",
        None,
        ""
    ]
    expected_output = {
        "some_key1": "value1",
        "some_key2": "value2",
        "some_key3": "value3"
    }
    data = get_vars_from_inventory_sources(None, sources, [], 'task')

    assert data == expected_output

# Generated at 2022-06-21 09:42:40.581313
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    loader = {}
    plugin = {}
    path = {}
    entities = [{},{}]

    data = get_plugin_vars(loader, plugin, path, entities)
    assert data == {}

# Generated at 2022-06-21 09:42:53.020808
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    write_path = os.path.join(C.DEFAULT_LOCAL_TMP, 'vars_test')
    os.makedirs(write_path)
    os.chdir(write_path)
    for fname in ['group_vars/all/vars.yml', 'group_vars/foo/vars.yml',
                  'host_vars/foo/bar.yml']:
        with open(fname, 'w') as f:
            f.write('---\nfoo: bar\n')
    loader = _get_loader({'foo': 'foo'}, ['foo'], write_path)

    assert get_vars_from_inventory_sources(loader, [write_path], ['foo'], 'inventory') == {'foo': 'bar'}


# Generated at 2022-06-21 09:43:02.641627
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    from ansible.plugins.loader import plugin_loader
    from ansible.plugins.loader.vars_loader import VarsModule

    import collections
    import re

    class MyVarsModule(VarsModule):

        def get_vars(self, loader, path, entities):
            if path in self._testing_data:
                return self._testing_data[path]
            raise AnsibleError('Invalid data')

    MyVarsModule._testing_data = {
        '/path/to/inventory/src': {
            'my_var': 1
        },
        '/path/to/task/src': {
            'my_var': 2
        }
    }

    plugin_loader.add_plugin(MyVarsModule, 'myvars')

# Generated at 2022-06-21 09:43:10.447865
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    import os
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.plugins.loader import vars_loader

    var_plug_dir = os.path.join(os.path.dirname(__file__), '..', 'vars_plugins')
    loader = AnsibleCollectionLoader()
    loader.set_vars_directory(var_plug_dir)
    vars_plugins = list(vars_loader.all())

    plugin = vars_plugins[0]
    path = var_plug_dir
    entities = []
    expected_result = {'vars_plugin_0': 'vars_plugin_0_value'}
    actual_result = get_plugin_vars(loader, plugin, path, entities)
    assert actual_result == expected_result

# Generated at 2022-06-21 09:43:18.711040
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader

    result_dict = {
        'var1': 'value1',
        'var2': 'value2',
        'var3': {
            'var4': 'value4',
        }
    }
    data = get_vars_from_path(vars_loader, 'tests/unit/mock_collections/ansible_namespace/namespace/collection/', [], 'demand')
    assert data == result_dict
    data = get_vars_from_path(vars_loader, 'tests/unit/mock_collections/ansible_namespace/namespace/collection/', ['host1'], 'demand')
    assert data == result_dict

# Generated at 2022-06-21 09:43:26.749699
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    # Create mock vars plugin which has three methods defined
    class MockVars:
        _load_name = 'mock'
        _original_path = '/path/to/plugins/tests/mock'
        def get_vars(self, loader, path, entities):
            return {'v1': 1, 'v2': 2, 'v3': 3}
        def get_host_vars(self, host):
            return {'v1': 1, 'v2': 2, 'v3': 3}
        def get_group_vars(self, group):
            return {'v1': 1, 'v2': 2, 'v3': 3}
    plugin = MockVars()
    # Loader
    from ansible import inventory
    loader = inventory.InventoryLoader()
    # Data
    data = {}


# Generated at 2022-06-21 09:43:49.757143
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    from ansible.plugins.vars import test_vars_plugin
    from ansible.utils.collection_loader import AnsibleCollectionLoader

    loader = AnsibleCollectionLoader()
    plugin = test_vars_plugin.TestVarsPlugin(loader, 'test_vars', 'test/test_vars_plugin')

    assert get_plugin_vars(loader, plugin, 'path', ['entities']) == dict(plugin.get_vars(loader, 'path', ['entities']))

# Generated at 2022-06-21 09:43:52.754268
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    plugins = vars_loader.all()
    plugin1 = next(plugins)
    assert isinstance(get_plugin_vars(None, plugin1, None, None), dict)

# Generated at 2022-06-21 09:43:59.694142
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    fake_host = Host('hostname')
    fake_group = Host(name='groupname')
    fake_nested = Host(name='nested', groups={})

    # minimal fake plugin class
    class FakeVarsPlugin:
        def get_vars(self, loader, path, entities):
            return {'test': 'foo'}

    # make sure get_vars() takes precedence over
    # get_group_vars() and get_host_vars()
    plugin = FakeVarsPlugin()
    result = get_plugin_vars(None, plugin, None, [fake_host, fake_group, fake_nested])
    assert result == {'test': 'foo'}

    # minimal fake plugin class
    class FakeVarsPlugin2:
        def get_host_vars(self, host):
            return

# Generated at 2022-06-21 09:44:03.009567
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Test Python 2
    test_get_vars_from_path_base(loader_mock={'vars_plugins': []})

    # Test Python 3
    test_get_vars_from_path_base(loader_mock={'vars_plugins': dict()})



# Generated at 2022-06-21 09:44:15.836142
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    class MockPlugin:
        def get_vars(self, *args, **kwargs):
            return {
                'test_key': 'test_value'
            }

    class MockInvalidPlugin:
        def run(self):
            pass

    class MockPlugin2:
        def get_host_vars(self, host):
            return {
                'key_' + host: 'value_' + host
            }

        def get_group_vars(self, group):
            return {
                'group_' + group: 'group_' + group
            }

    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    host = inventory.get_host

# Generated at 2022-06-21 09:44:27.189742
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    def __get_plugin_vars(loader, path, entities):
        return get_plugin_vars(loader, plugin, path, entities)

    class MockEntity:
        def __init__(self, name):
            self.name = name

    class MockVars:

        def __init__(self, data):
            self._data = data

        def get_vars(self, loader, path, entities):
            return self._data

        def get_group_vars(self, group):
            return {'group_' + group: 'group_value'}

        def get_host_vars(self, host):
            return {'host_' + host: 'host_value'}

    # V2 plugin
    plugin = MockVars({'foo': 'bar'})

# Generated at 2022-06-21 09:44:39.015917
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import ansible_loader
    from ansible.plugins.vars import HostVars
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    # create a vars plugin
    class MyVarsPlugin(object):
        def __init__(self):
            self.vars = [
                'a.yml',
                'b.yml',
                'c.yml',
                'd.yml',
                'e.yml',
            ]
            self._load_name = 'my_vars_plugin'


# Generated at 2022-06-21 09:44:49.748242
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.config import Config
    from ansible.executor.task_result import TaskResult
    from ansible.module_utils.six.moves import configparser
    from ansible.module_utils.six.moves import StringIO
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import vars_loader
    from ansible.utils.collection_loader import AnsibleCollectionRef

    class TestLoader:
        def list_collection_roles(self, collection_name):
            return []


    class TestVarPlugin:
        REQUIRES_WHITELIST = False

        def get_vars(self, loader, path, entities):
            return {'src_data': 'foo'}

    class WhiteListVarPlugin:
        REQUIRES_WHITELIST

# Generated at 2022-06-21 09:44:56.988998
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    import ansible.inventory.manager
    import ansible.plugins.loader

    entities = ['host1','host2','host3','host4','host5','host6','host7','host8','host9','host10','host11','host12']

    # This is a plugin based on 1.x playbook.plugins
    class PluginVars1(object):
        def __init__(self):
            self._load_name = "vars_plugin_1"
            self._original_path = "vars_plugin_1.py"
        def get_vars(self, loader, path, entities):
            return {'vars_plugin_1': 'vars_plugin_1'}
        def get_host_vars(self, hostname):
            return {'vars_plugin_1': 'vars_plugin_1'}

# Generated at 2022-06-21 09:45:07.157367
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    from ansible.inventory.manager import InventoryManager
    from ansible.vars import combine_vars
    from ansible.vars.cache import fact_cache
    from ansible.utils.vars import load_extra_vars
    from pytest_ansible.test_utils import FakeLoader, FakeDisplay
    import os

    display = FakeDisplay()
    plugin = 'pytest_ansible.plugins.example_vars_plugin'
    instance = vars_loader.get(plugin)
    assert isinstance(instance, vars_loader.all()[plugin])

    data = {'foo': 'bar'}
    assert get_plugin_vars(FakeLoader(), instance, os.getcwd(), []) == data

    data = {'foo': 'baz'}

# Generated at 2022-06-21 09:45:53.672814
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    loader = None
    path = 'test/test_vars_plugins/'
    entities = ['example1', 'example2']
    stage = 'inventory'

    # expect vars_path1 to be loaded
    data = get_vars_from_path(loader, path, entities, stage)
    assert(len(data) == 1)
    assert(data['vars_plugin_test'] == 'vars_path1')

    # expect vars_path2 to be loaded
    stage = 'task'
    data = get_vars_from_path(loader, path, entities, stage)
    assert (len(data) == 1)
    assert (data['vars_plugin_test'] == 'vars_path2')

    # expect both vars_path1 and vars_path3 to be loaded
    loader = None

# Generated at 2022-06-21 09:46:04.591802
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars.dictvar import VarsModule as dictvar
    host = Host('testhostname')
    entities = [host]
    plugin = dictvar()
    loader = None
    path = None

    plugin.get_vars = lambda x, y, z: {'testkey': 'testval'}
    data = get_plugin_vars(loader, plugin, path, entities)
    assert data == {'testkey': 'testval'}

    # check that get_vars() is called and not get_host_vars() or get_group_vars()
    plugin.get_vars = None
    plugin.get_host_vars = lambda x: {'host': 'host'}
    plugin.get_group_vars = lambda x: {'group': 'group'}
    data

# Generated at 2022-06-21 09:46:05.230488
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    pass

# Generated at 2022-06-21 09:46:10.623276
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    loader = []
    plugin = {'_base_dir': '/Users/foo/bar/baz'}
    path = '/Users/foo/bar/baz/mydir'
    entities = [{'name': 'host1'}, {'name': 'group1'}, {'name': 'host2'}]
    assert get_plugin_vars(loader, plugin, path, entities) == {}

# Generated at 2022-06-21 09:46:11.171598
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    pass

# Generated at 2022-06-21 09:46:21.474430
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import vars_plugins

    class DummyVarsPlugin:
        """ Dummy Vars Plugin for testing purposes.
            Expected Result for get_vars:
            {'a': 'b'}
            Expected Result for get_group_vars:
            {'c': 'd'}
            Expected Result for get_host_vars:
            {'e': 'f'}
        """

        def run(self, **kwargs):
            return dict(test="test")

        @property
        def _load_name(self):
            return "dummy.py"

        @property
        def _original_path(self):
            return "some/path/to/dummy.py"


# Generated at 2022-06-21 09:46:25.864571
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    loader = InventoryManager(['tests/inventory_dir_2'])
    sources = ['tests/inventory_dir_2/host_vars']
    entities = ['host_vars/host1.example.com']
    data = {}
    assert get_vars_from_inventory_sources(loader, sources, entities, "inventory") != data

# Generated at 2022-06-21 09:46:26.557892
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    # TBD
    pass

# Generated at 2022-06-21 09:46:31.882101
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    class FakePlugin:
        def get_vars(self, *args):
            return {'foo': 'bar'}
    class FakeLoader:
        vars_plugins = [FakePlugin()]

    path = '/path/to/somedir'
    entities = [True]
    result = get_vars_from_path(FakeLoader(), path, entities, 'inventory')

    assert result == {'foo': 'bar'}


# Generated at 2022-06-21 09:46:42.936463
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # mock the loader to make testing easier
    class TestLoader:
        def get_basedir(self):
            return '/some/path'

    # populate the vars plugins
    from ansible.plugins.vars import yaml_script
    assert vars_loader.get('yaml_script') is None

    test_loader = TestLoader()
    path = 'test_path'
    entities = ['test_entity']

    # ensure the plugin has been loaded and get the expected value
    result = get_vars_from_path(test_loader, path, entities, 'task')
    assert yaml_script.get_vars(test_loader, path, entities) == result
    # make sure the path has been normalized in the plugin