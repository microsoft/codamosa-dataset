

# Generated at 2022-06-21 09:37:55.963409
# Unit test for function get_vars_from_path
def test_get_vars_from_path():


    # fake loader and paths
    loader = dict()
    path = "abc"

    # fake vars plugins
    class VarsPlugin:

        def __init__(self):
            self._name = "plugin1"
            self.get_vars = lambda x, y, z: {"plugin1_vars":1}

    class VarsPlugin2:
        def __init__(self):
            self._name = "plugin2"
            self.get_vars = lambda x, y, z: {"plugin2_vars":2}

    class VarsPlugin3:
        def __init__(self):
            self._name = "plugin3"
            self.get_host_vars = lambda x: {"plugin3_vars":3}

# Generated at 2022-06-21 09:38:01.001076
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    from ansible.vars import version_info_var

    from ansible.plugins.vars import version_info

    vars_plugin1 = version_info_var()
    vars_plugin1.set_options(None, version_info={})

    data = get_plugin_vars(None, vars_plugin1, '', [])

    assert data

    data = get_plugin_vars(None, version_info, '', [])

    assert data

# Generated at 2022-06-21 09:38:12.052136
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.loader import vars_loader
    path = '/test/test/test'
    fake_vars_loader = vars_loader.VarsModule()
    fake_vars_loader._load_name = 'test'
    fake_vars_loader._original_path = '/test/test'

    class fake_plugin:
        def get_vars(loader, path, entities):
            return {'test': 'test'}
    fake_plugin._load_name = 'test'
    fake_plugin._original_path = '/test/test'
    plugin = fake_plugin()
    group = vars_loader.VarsModule()
    group_name = 'test'
    host_name = 'test'
    host = Host(host_name)


# Generated at 2022-06-21 09:38:22.625380
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    # we should not get_vars_from_path for host lists
    sources = ['/var/lib/awx/ansible/inventory/hosts,', '/var/lib/awx/ansible/inventory/hosts,', '/var/lib/awx/ansible/inventory/hosts/child']

    from ansible.inventory.host import Group
    entities = [Group(name='all')]
    loader = None
    stage = 'task'
    assert get_vars_from_inventory_sources(loader, sources, entities, stage) == {}

    # we should get_vars_from_path for directory, not for file

# Generated at 2022-06-21 09:38:28.068704
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    plugin_name = 'test_var_plugin'
    path = 'dummy/path/for/test'
    entities = ['dummy/' + entity for entity in os.listdir('dummy/')]
    plugin = vars_loader.get(plugin_name)
    data = get_plugin_vars(None, plugin, path, entities)
    assert len(data) == len(entities)
    for entity in entities:
        assert data[entity] == 'dummy_data'


# Generated at 2022-06-21 09:38:36.092077
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    plugin = vars_loader.get('test_vars_plugin')
    class FakeHost():
        def __init__(self, hostname):
            self.name = hostname

    host = FakeHost('hostx')
    loader = vars_loader.get('test_vars_plugin')
    path = '/var/tmp'
    entities = [host]
    data = {'hostx': 'hostx_data', 'common': 'common_data'}
    result = get_plugin_vars(loader, plugin, path, entities)
    assert data == result

# Generated at 2022-06-21 09:38:42.929785
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.modules.extras.test.test_utils import AnsibleExitJson, AnsibleFailJson, ModuleTestCase
    from ansible.module_utils.common.json_utils import AnsibleJSONEncoder

    class VarsJson(object):
        def __init__(self, value):
            self.value = value

        def get_vars(self, loader, path, entities):
            return self.value

    loader = AnsibleJSONEncoder()
    plugin = VarsJson(dict(foo=42))

    assert get_plugin_vars(loader, plugin, './path', []) == dict(foo=42)

# Generated at 2022-06-21 09:38:50.497461
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import _VarsModule

    class TestVarsModule(_VarsModule):

        def get_vars(self, *args, **kwargs):
            return {"get_vars": True,
                    "args": args,
                    "kwargs": kwargs}

        def get_host_vars(self, *args, **kwargs):
            return {"get_host_vars": True,
                    "args": args,
                    "kwargs": kwargs}

        def get_group_vars(self, *args, **kwargs):
            return {"get_group_vars": True,
                    "args": args,
                    "kwargs": kwargs}

    path = "/tmp"
    entities = [{"name": "test"}]
    plugin = TestVarsModule()

   

# Generated at 2022-06-21 09:38:51.237355
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    assert True

# Generated at 2022-06-21 09:39:00.514173
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    # Setup mocks and dummy objects
    class DummyVarsPlugin:
        REQUIRES_WHITELIST = False
        DEPRECATED = False
        STAGE = 'all'

        def get_vars(self, loader, path, entities):
            if path == "path_one":
                return {'a': '1'}
            else:
                return {}

    class DummyVarsPluginTwo:
        REQUIRES_WHITELIST = False
        DEPRECATED = False
        STAGE = 'all'

        def get_vars(self, loader, path, entities):
            if path == "path_one":
                return {'b': '2'}
            else:
                return {'c': '3'}

    class DummyVarsPluginThree:
        REQUIRES_

# Generated at 2022-06-21 09:39:16.122821
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    results = get_vars_from_inventory_sources(
        '',
        [
            InventoryManager(
                DataLoader()
            )._inventory.hosts,
        ],
        [],
        ''
    )
    assert results

# Generated at 2022-06-21 09:39:19.315906
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    '''Test function get_plugin_vars'''

    # TODO: Create a plugin which can be used for testing this function
    # get_plugin_vars(loader, plugin, path, entities)
    pass

# Generated at 2022-06-21 09:39:29.290755
# Unit test for function get_vars_from_path

# Generated at 2022-06-21 09:39:40.181449
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    sources = [None, '/root/test.cfg']
    hosts_vars = {}
    groups_vars = {}
    inventory = Inventory(loader=loader, host_list=[], sources="")
    inventory.set_variable('host_vars', hosts_vars)
    inventory.set_variable('group_vars', groups_vars)
    inventory.set_variable('inventory_sources', sources)
    print (get_vars_from_inventory_sources(loader, sources, [], "inventory"))
    print (get_vars_from_inventory_sources(loader, "/root/test.cfg", [], "inventory"))

# Generated at 2022-06-21 09:39:50.363218
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    import ansible.module_utils.vars_plugins.test0 as test0
    import ansible.module_utils.vars_plugins.test1 as test1
    import ansible.module_utils.vars_plugins.test2 as test2
    import ansible.module_utils.vars_plugins.test3 as test3
    import ansible.module_utils.vars_plugins.test4 as test4

    plugin = test0.VarsModule()
    assert plugin.get_vars(None, None, None) == {}
    assert get_vars_from_path(None, None, None, None) == {}
    assert plugin.get_host_vars('test') == {'var_0': 'test'}

# Generated at 2022-06-21 09:39:55.783384
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    class AnsibleLoaderFake:
        pass

    def execute_iterator_fake(iterator):
        target = []
        while iterator.has_next():
            target.append(iterator.get_next())
        return target

    class AnsibleFake:
        def __init__(self):
            self.constants = AnsibleFakeConstants()
            self.inventory = AnsibleFakeInventory(self)
            self.plugins = AnsibleFakePlugins(self)

    class AnsibleFakeConstants:
        def __init__(self):
            self.RUN_VARS_PLUGINS = 'start'
            self.VARIABLE_PLUGINS_ENABLED = 'test_vars_inventory'
            self.VARS_PLUGIN_ENV = {'test_vars_inventory':'True'}


# Generated at 2022-06-21 09:39:56.636524
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    pass

# Generated at 2022-06-21 09:40:09.707361
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.module_utils.common.removed import removed
    assert removed is not None, 'removed module import check failed'

    from ansible.module_utils.common.collections import ImmutableDict
    assert ImmutableDict is not None, 'ImmutableDict import check failed'

    from ansible.module_utils.common.file import is_executable
    assert is_executable is not None, 'is_executable import check failed'

    from ansible.parsing.vault import VaultSecret
    assert VaultSecret is not None, 'VaultSecret import check failed'

    from ansible.plugins.vars import ini
    assert ini is not None, 'ini module import check failed'

    from ansible.plugins.vars import yaml
    assert yaml is not None, 'yaml module import check failed'

# Generated at 2022-06-21 09:40:15.767239
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    class TestPlugin():
        path = '/test/path'
        entities = ['entity1', 'entity2']

        def get_vars(loader, path, entities):
            # FIXME: if inventory plugin
            return {'bar': 'baz'}

    loader = ''
    path = '/test/path'
    plugin = TestPlugin()
    data = get_plugin_vars(loader, plugin, path, plugin.entities)

    assert data == {'bar': 'baz'}



# Generated at 2022-06-21 09:40:28.033811
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.cli.galaxy import GalaxyCLI
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import vars_loader

    # Prepare galaxy directory for testing
    galaxy_dir = os.path.join(C.DEFAULT_LOCAL_TMP, 'ansible_collections')
    if os.path.isdir(galaxy_dir):
        shutil.rmtree(galaxy_dir)

    # Install mock role
    collection_name = 'ansible_collections.jctanner.test'
    collection_path = GalaxyCLI.install_collections(collection_name, galaxy_dir)

    # Prepare mock inventory
    inventory = InventoryManager(loader=None, sources=collection_path)

# Generated at 2022-06-21 09:40:42.234035
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    __import__('ansible.plugins.vars.vars_file')
    __import__('ansible.plugins.vars.env')
    __import__('ansible.plugins.vars.system')
    __import__('ansible.plugins.vars.gce')
    __import__('ansible.plugins.vars.package_facts')

    # make sure that only the whitelisted plugins are loaded
    assert set([p._load_name for p in vars_loader.all()]) == set(C.VARIABLE_PLUGINS_ENABLED)

    # test the function get_vars_from_path in utils/vars/__init__.py
    loader = None
    path = "."
    entities = []
    stage = "inventory"
    data = get_vars_from_path

# Generated at 2022-06-21 09:40:53.798518
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    from ansible import inventory

    # A fake loader class that returns a fake plugin class
    class FakeVarsLoader(object):
        def get(self, name):
            # return the fake plugin
            return VarsModule()

        def all(self):
            return [VarsModule()]

    # A fake vars plugin
    class VarsModule(object):
        def get_vars(self, loader, path, entities):
            return {'foo_var': 'bar'}

        def get_group_vars(self, group):
            return {'group_var': 'bar'}

        def get_host_vars(self, host):
            return {'host_var': 'bar'}

    # entities is a list of groups, used in get_vars_from_path()
    entities = ['group_a']



# Generated at 2022-06-21 09:41:06.227686
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    class MyPlugin:
        def get_vars(self, loader, path, entities):
            data = {'plugin_vars': 'plugin'}
            return data

    class MyPlugin2:
        def get_host_vars(self, host):
            data = {'host_vars': 'host'}
            return data

    class MyPlugin3:
        def get_group_vars(self, group):
            data = {'group_vars': 'group'}
            return data

    class MyPlugin4:
        def run(self):
            return {}

    class MyLoader:
        def __init__(self, plugin):
            self.plugin = plugin

    class MyHost:
        def __init__(self, name=None):
            self.name = name


# Generated at 2022-06-21 09:41:15.577952
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    loader = None
    inventory_sources = [
        "/Users/lady/ansible/test/foo/bar.yml",
        "/Users/lady/ansible/test/foo/bar/bar.yml",
        "/Users/lady/ansible/test/foo/bar/baz.yml",
    ]
    entities = [
        Host(name="host1"),
        Host(name="host2"),
        Host(name="host3"),
        Host(name="host4"),
    ]
    stage = 'inventory'

    assert get_vars_from_inventory_sources(loader, inventory_sources, entities, stage) == {
        'foo': 'test',
        'bar': 'test',
        'baz': 'test'
    }

# Generated at 2022-06-21 09:41:22.936970
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    test_data = {'a': 1, 'b': 2, 'c': 3}
    hosts = ['host1', 'host2']
    path = 'test_path'
    loader = 'Mock_loader'
    sources = ['source1', 'source2']
    entities = ['host1', 'host2']
    stage = 'inventory'
    data = get_vars_from_inventory_sources(loader, sources, entities, stage)
    assert data == {}

# Generated at 2022-06-21 09:41:32.741766
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    # Simulate an object which implements get_vars
    class DummyGetVars:
        def get_vars(self, loader, path, entities):
            return {'a': 1}

    # Simulate an object which implements get_host_vars and get_group_vars
    class DummyGetHostGroupVars:
        def get_host_vars(self, host):
            return {'a': 1}

        def get_group_vars(self, group):
            return {'b': 2}

    # Simulate an object which implements run
    class DummyRun:
        def run(self, tmp, task_vars):
            return {'c': 3}

    assert get_plugin_vars(None, DummyGetVars(), None, None) == {'a': 1}
    assert get_

# Generated at 2022-06-21 09:41:34.148147
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    assert get_vars_from_path(None, None, None, None) == {}

# Generated at 2022-06-21 09:41:43.079664
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inv_mgr = InventoryManager(loader=loader, sources='localhost')
    var_mgr = VariableManager(loader=loader, inventory=inv_mgr)
    inv_data = get_vars_from_inventory_sources(loader, inv_mgr._inventory.sources, inv_mgr._inventory.hosts, 'task')

    assert 'inventory_dir' in inv_data

    if C.RUN_VARS_PLUGINS == 'action':
        assert 'bogus_var' in inv_data
    else:
        assert 'bogus_var' not in inv_data

# Generated at 2022-06-21 09:41:53.452290
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    import ansible.plugins.loader
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager

    #
    # Configure plugin
    #
    plugin = ansible.plugins.loader.vars_loader.get("vars_foo")
    plugin._original_path = "./test/plugins/vars_plugins/vars_foo/__init__.py"
    plugin._load_name = "vars_foo"
    plugin.get_group_vars = mock_get_group_vars
    plugin.get_host_vars = mock_get_host_vars
    plugin.get_vars = mock_get_vars

    #
    # Configure loader
    #
    loader = ansible.plugins.loader.v

# Generated at 2022-06-21 09:41:57.860179
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars.foo import VarsModule as FooPlugin
    plugin = FooPlugin()
    plugin._load_name = 'foo_plugin'
    plugin._original_path = '/path/to/plugin'
    data = get_plugin_vars(None, plugin, None, None)
    assert data == {'foo_key': 'foo_value'}

# Generated at 2022-06-21 09:42:06.492980
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.data import InventoryParser
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    parser = InventoryParser(loader,host_list='localhost,')
    inventory = InventoryManager(loader=loader, sources=parser)
    display.verbosity = 3
    vars = get_vars_from_path(loader, "./", ["localhost,"], "task")

    print("Vars: ", str(vars))

# Generated at 2022-06-21 09:42:08.895051
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    assert get_vars_from_inventory_sources(1, [], [], None) == {}

# Generated at 2022-06-21 09:42:18.620805
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    import ansible.plugins.vars.test as test_plugin
    loader = AnsibleLoader(vars_loader)
    data = {}
    test_vars = {'test_var': 'test_value'}
    data = get_vars_from_path(loader, 'host_vars', [], 'host')
    assert test_vars not in data

    data = {}
    data = get_vars_from_path(loader, '/tmp/ansible_test/host_vars', [], 'host')
    assert test_vars in data

# Generated at 2022-06-21 09:42:27.147798
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import VarsModule
    from ansible.utils.vars import combine_vars
    from collections import namedtuple

    vars_module = VarsModule()
    fake_plugin = namedtuple("fake_plugin", "get_vars")

    assert get_plugin_vars(vars_module, fake_plugin(get_vars="get_vars"), 'path', 'entities') == "get_vars"
    assert get_plugin_vars(vars_module, fake_plugin(), 'path', 'entities') == dict()

    assert get_vars_from_path(vars_module, 'path', 'entities', 'stage') == dict()


# Generated at 2022-06-21 09:42:31.919226
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars.fact_cache import VarsModule as Plugin
    loader = MockVarsModuleLoader()
    entities = []

    plugin_data = get_plugin_vars(loader, Plugin(), '/', entities)
    assert plugin_data == {'a': 1, 'b': 2, 'c': 3}


# Generated at 2022-06-21 09:42:32.789647
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    pass

# Generated at 2022-06-21 09:42:43.013163
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    from ansible.plugins.vars import testvars

    loader, path, entities = None, None, None
    plugin = testvars.VarsModule()

    # Test for No Attribute Error
    vars_output = get_plugin_vars(loader, plugin, path, entities)
    expected_output = {u'plugin_key': u'plugin_value'}
    assert vars_output == expected_output

    # Test for Attribute Error
    delattr(testvars.VarsModule, 'get_vars')
    vars_output = get_plugin_vars(loader, plugin, path, entities)
    expected_output = {}
    assert vars_output == expected_output


# Generated at 2022-06-21 09:42:48.591544
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    """
    get_plugin_vars(loader.py)
    """
    from ansible.inventory.loader import InventoryLoader

    loader = InventoryLoader()
    for plugin in vars_loader.all():
        print(plugin)
        data = get_plugin_vars(loader, plugin, None, [])
        print(data)

# Generated at 2022-06-21 09:42:53.118867
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    # test empty vars
    assert get_vars_from_inventory_sources("", [], [], "") == {}
    # test empty inventory_sources
    assert get_vars_from_inventory_sources("", [], []) == {}



# Generated at 2022-06-21 09:43:02.804445
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    class Plugin:
        pass

    loader = None
    path = ['/path']
    plugin = Plugin()
    plugin.get_vars = lambda loader, path, entities: {'a': 'b'}
    entities = [1, 2, 3]

    result = get_plugin_vars(loader, plugin, path, entities)
    assert result == {'a': 'b'}

    plugin.get_vars = None
    plugin.get_host_vars = lambda n: {'a': n}
    result = get_plugin_vars(loader, plugin, path, entities)
    assert result == {'a': 3}

    plugin.get_host_vars = None
    plugin.get_group_vars = lambda n: {'a': n}

# Generated at 2022-06-21 09:43:22.410297
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.groupvars import GroupVars
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inv = InventoryManager(loader=loader, sources=[])
    vars_defs = []
    vars = VariableManager(loader=loader, inventory=inv, variable_manager=vars_defs)
    inv.add_host(Host('localhost'))
    host = inv.get_host('localhost')

    vars_plugin_list = [HostVars, GroupVars]
    data = {}

# Generated at 2022-06-21 09:43:30.427270
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    '''
    Unit test for function get_vars_from_path.
    Currently, this test only makes sure that the function doesn't crash when calling.

    Eventually, this test should assert that the function returns the expected values.
    '''
    # TODO: Add additional test cases
    # TODO: Assert that the function doesn't return an error
    loader = None
    path = '/dev/null'
    entities = ['localhost']
    stage = 'inventory'
    result = get_vars_from_path(loader, path, entities, stage)



# Generated at 2022-06-21 09:43:31.027857
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    pass

# Generated at 2022-06-21 09:43:38.842118
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    from ansible.plugins.loader import vars_loader
    from ansible_collections.ansible.builtin.plugins.vars import vars_plugins
    from ansible.plugins.vars import vars_one

    class MockLoader:
        def __init__(self):
            pass

        def get(self, *args, **kwargs):
            return None

    class MockPlugin:
        def __init__(self):
            self._load_name = 'vars_plugins'
            self._original_path = '/some/path'

        def get_vars(self, *args, **kwargs):
            return dict(plugin_vars=True)

    loader = MockLoader()
    plugin = MockPlugin()
    vars_loader.add(plugin, 'vars_plugins')
    path = '/some/path'

# Generated at 2022-06-21 09:43:49.356445
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    ''' Unit test for vars plugins. '''
    from ansible.inventory.manager import InventoryManager
    import ansible.plugins.loader as plugin_loader
    plugin_loader.all(class_only=True)

    plugin_vars = {}
    loader = None
    entities = None
    stage = ''

    # No vars plugin is enabled.
    assert (get_vars_from_path(loader, '.', entities, stage) == {})

    # Enable one vars plugin and make sure it gets called.
    C.VARIABLE_PLUGINS_ENABLED = 'test_vars'
    plugin_vars = {'return': 'test_value'}
    assert (get_vars_from_path(loader, '.', entities, stage) == plugin_vars)

    # Disable the vars

# Generated at 2022-06-21 09:43:59.796567
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    class InventoryVarPlugin(object):
        def __init__(self):
            self.get_vars_args = []

        def get_vars(self, loader, path, entities, cache=True):
            self.get_vars_args.append((loader, path, entities, cache))
            return {
                'plugin_vars': 'true',
            }

    class InventoryVarsPluginDefaultDirOnly(object):
        def __init__(self):
            self.get_vars_args = []

        def get_vars(self, loader, path, entities, cache=True):
            self.get_vars_args.append((loader, path, entities, cache))

# Generated at 2022-06-21 09:44:00.886130
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    assert(get_vars_from_inventory_sources is not None)

# Generated at 2022-06-21 09:44:13.000978
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    # 1st test case
    class mockPlugin():
        def get_vars(self, loader, path, entities):
            return {'plugin_vars': ['plugin_var']}

    # 2nd test case
    class mockPlugin_older():
        def get_host_vars(self, host):
            return {'host_vars': ['host_var']}

    # 3rd test case
    class mockPlugin_newer():
        def get_host_vars(self, host):
            return {'host_vars': ['host_var']}
        def run(self):
            pass

    loader = {'_inventory': {'sources': 'test'}}
    path = 'test-path'
    entities = 'test-entities'

    # 1st test case
    plugin = mockPlugin()
    result

# Generated at 2022-06-21 09:44:24.760840
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager

    display.verbosity = 0
    sources = [
        'tests/unit/inventory/test_plugin_vars/hosts',
        'tests/unit/inventory/test_plugin_vars/hosts2',
        'tests/unit/inventory/test_plugin_vars/hosts3',
    ]

    loader = InventoryManager(sources=[sources[0]], vault_password='ansible')
    loader.parse_inventory(loader.loader.inventory_sources[0])


# Generated at 2022-06-21 09:44:29.114696
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    class TestPlugin():
        _load_name = "myplugin_load_name"
        _original_path = "myplugin_original_path"

        def get_vars(self, loader, path, entities):
            return {'test': 'data'}

    assert get_plugin_vars(object, TestPlugin(), None, None)['test'] == 'data'

# Generated at 2022-06-21 09:44:53.284785
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    for path in ['/etc/ansible/hosts', 'host_list,host_list2', None]:
        sources = [path]
        entities = ['web-server']
        stage = 'task'
        # pass the test if no exception is raised

# Generated at 2022-06-21 09:44:54.041671
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    pass


# Generated at 2022-06-21 09:45:05.028183
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Make sure we can import files from the same dir as this test.
    import sys
    test_dir = os.path.dirname(__file__)
    test_lib_path = os.path.join(test_dir, '..', '..', '..', 'lib')
    sys.path.append(test_lib_path)

    from ansible.plugins import vars_loader
    from ansible.module_utils import basic

    test_file_path = os.path.join(test_dir, "test_vars_plugin.yml")

    data = get_vars_from_path(vars_loader, test_file_path, [], "inventory")

# Generated at 2022-06-21 09:45:12.658971
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    # Test get_vars_from_inventory_sources function
    # 1. Test if the vars plugin is skipped if RUN_VARS_PLUGINS is set to demand
    # 2. Test if vars plugin is loaded if RUN_VARS_PLUGINS is not set to demand
    # 3. Test if the vars plugin is skipped for a specific host
    # 4. Test if the vars plugin is loaded for a specific host
    # 5. Test if the vars plugin is skipped for a specific group

    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    display.verbosity = 3

    vars_plugin_list = list(vars_loader.all())

# Generated at 2022-06-21 09:45:20.658726
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    '''This is a unit test to prove that the get_plugin_vars functions.  It is intended to be run through pytest.'''
    import tempfile
    import yaml

    # Create a temporary directory to use as the vars directory to be tested
    test_dir = tempfile.mkdtemp()

    # Write some mock plugin_vars to the temporary directory
    with open(os.path.join(test_dir, 'test_vars_directory.yaml'), 'w') as test_file:
        test_file.write(yaml.dump({'test_vars_directory': True}, default_flow_style=False))

# Generated at 2022-06-21 09:45:22.239450
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    """ dummy function for test_utils.py to load """



# Generated at 2022-06-21 09:45:23.793400
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert get_vars_from_path("loader", "", [], "") == {}

# Generated at 2022-06-21 09:45:30.558950
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.loader import vars_loader
    from unittest import TestCase

    class TestHost(Host):
        def __init__(self, name):
            super(TestHost, self).__init__(name)

    class TestVars(object):
        def __init__(self, name):
            self._load_name = name

        def get_vars(self, loader, path, entities):
            if self._load_name == '1':
                raise Exception('Cannot use v1 type vars plugin %s' % self._load_name)
            elif self._load_name == '2':
                return self.get_host_vars(entities[0].name)

# Generated at 2022-06-21 09:45:41.505880
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    try:
        from ansible.plugins.test.test_vars import TestVars2
    except ImportError:
        return

    test_collection = 'ansible_collections.ansible_unit_tests.plugins.test_vars'
    vars_plugin_list = list(vars_loader.all())

    plugin = vars_loader.get(test_collection + ".TestVars2")
    vars_plugin_list.append(plugin)
    assert plugin.get_vars('loader', 'path', 'entities') == {'Foo': 'Bar', 'Baz': 'Quux'}
    assert plugin.get_host_vars('somename') == {'Foo': 'Bar', 'Baz': 'Quux'}

# Generated at 2022-06-21 09:45:46.263183
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    loader = None
    sources = None
    entities = None
    stage = None

    from ansible.plugins.vars.host_list import VarsModule
    VarsModule.get_host_vars("testhost")

if __name__ == '__main__':
    test_get_vars_from_inventory_sources()

# Generated at 2022-06-21 09:46:43.805344
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.vars.plugins.vars import VarsModule

    test_host_vars = {'host1': {'var1': 'host1_var1'}, 'host2': {'var1': 'host2_var1'}}
    test_group_vars = {'group1': {'var1': 'group1_var1'}, 'group2': {'var1': 'group2_var1'}}

    class TestVarsModule1(VarsModule):
        """Class to test the vars function 'get_vars_from_inventory_sources'
        """

        name = 'test_vars_get_vars_from_inventory_sources'

        def get_vars(self, loader, path, entities):
            return test_host_vars


# Generated at 2022-06-21 09:46:49.536215
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.utils.collection_loader import AnsibleCollectionRef

    b_path = to_bytes("./somepath")
    b_plugin_name = to_bytes("test_name")

    test_plugin = MockVarsPlugin(b_plugin_name)

    test_loader = MockLoader()

    C.VARIABLE_PLUGINS_ENABLED = []
    data = get_vars_from_path(test_loader, b_path, [], 'test_stage')
    assert data == {}

    C.VARIABLE_PLUGINS_ENABLED = [b_plugin_name]
    data = get_vars_from_path(test_loader, b_path, [], 'test_stage')
    assert data == {}
    assert test_loader._path == './somepath'

# Generated at 2022-06-21 09:47:01.382648
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    from ansible.modules.extras.inventory.vars_plugins.test_vars import TestVars

    source, source_path = tempfile.mkstemp(prefix='ansible_vars_plugins_')


# Generated at 2022-06-21 09:47:10.647756
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.vars import PluginVars
    from ansible.vars.manager import VariableManager

    class TestPlugin(PluginVars):
        def __init__(self, name):
            super(TestPlugin, self).__init__(name=name)

        def get_vars(self, loader, path, entities, cache=True):
            return {"test": "test"}

    vm = VariableManager(host_vars={"host": {"host_test": "host_test"}}, inventory=None)
    loader = None
    plugin = TestPlugin("test_plugin")
    path = "path"
    entities = []

    assert get_plugin_vars(loader, plugin, path, entities) == {"test": "test"}


# Generated at 2022-06-21 09:47:11.199099
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    pass

# Generated at 2022-06-21 09:47:16.489281
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    class TestLoader:
        pass
    class TestPlugin:
        def get_vars(self, loader, path, entities):
            ret = dict()
            ret["test_value"] = True
            return ret
    loader = TestLoader()
    loader.path_sep = ':'
    vars_loader.add(TestPlugin())
    data = get_vars_from_path(loader, "/test/path", [], "inventory")
    assert data["test_value"] == True

test_get_vars_from_path()

# Generated at 2022-06-21 09:47:26.432068
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.parsing.dataloader import DataLoader
    from ansible.cli.playbook import PlaybookCLI

    # create a loader to use in our plugins
    cli = PlaybookCLI(['', '--inventory', 'tests/inventory_test_complex/'])
    loader = DataLoader()
    cli.parse()

    sources = cli.inventory.get_host_vars_sources('localhost')
    entities = cli.inventory.get_hosts('localhost')
    vars = get_vars_from_inventory_sources(loader, sources, entities, stage='inventory')

    assert vars['test_var'] == 'infra'
    assert vars['test_var2'] == 2
    assert vars['test_var3'] == 1

# Generated at 2022-06-21 09:47:36.125671
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    my_host = Host(name='example')
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=["hosts"])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    vars = get_vars_from_path(loader, './', [my_host,], 'task')
    assert vars == {'example_var': 'example_var_value'}

    vars = get_vars_from_path(loader, './', [my_host,], 'inventory')
    assert vars == {}