

# Generated at 2022-06-21 09:37:47.830948
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert get_vars_from_path(None, os.getcwd(), None, None) == {}

# Generated at 2022-06-21 09:37:57.537242
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    # NOTE: this is not a full test of the function,
    #       it is only enough to exercise the code path to
    #       fix bugs.
    from ansible.plugins.loader import vars_loader
    from ansible.parsing.dataloader import DataLoader

    collection_loader = DataLoader()
    vars_loader.add_directory(collection_loader, './lib/ansible/plugins/vars')
    sources = ['samples/test_vars_plugin/inventory_sources']
    entities = [Host('localhost')]
    stage='inventory'
    vars = get_vars_from_inventory_sources(collection_loader, sources, entities, stage)
    assert vars == {'foo': 'bar', 'baz': 'qux'}

# Generated at 2022-06-21 09:38:01.079055
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    class TestPluginVars:
        def get_vars(self, loader, path, entities):
            return {'a': 'b'}

    result = get_plugin_vars(None, TestPluginVars(), '', [])
    assert isinstance(result, dict), result
    assert 'a' in result, result



# Generated at 2022-06-21 09:38:07.903063
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.module_utils.six import PY3
    from ansible.plugins.vars import ini_file

    if PY3:
        plugin_class = ini_file.VarsModule
    else:
        plugin_class = ini_file.VarsModule
    loader = 'test'
    path = 'test'
    entities = 'test'

    assert get_plugin_vars(loader, plugin_class, path, entities) == {}

# Generated at 2022-06-21 09:38:11.381470
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    loader = None
    path = ''
    stage = ''
    entities = []
    data = get_vars_from_path(loader, path, entities, stage)
    assert data == {}



# Generated at 2022-06-21 09:38:21.855379
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    test_data = {
        'a': 1,
        'b': 2,
        'c': 3,
    }
    assert get_vars_from_path(None, None, None, None) == {}
    assert get_vars_from_path(None, './', None, None) == {}
    assert get_vars_from_path(None, './', ['a'], None) == {}
    assert get_vars_from_path(None, './', ['a'], None) == {}
    assert get_vars_from_path(None, './', [], None) == {}
    assert get_vars_from_path(None, './', ['a', 'b'], None) == {}

# Generated at 2022-06-21 09:38:25.859207
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    plugin = vars_loader.get("yaml")
    loader = vars_loader
    
    path = "/etc/ansible"
    entities = [Host("localhost")]
    stage = "inventory"
    
    data = get_plugin_vars(loader, plugin, path, entities)
    return data


# Generated at 2022-06-21 09:38:37.301720
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager

    class TestPlaybook(object):
        pass

    class TestTask(object):
        pass

    class TestImplementation(object):
        pass

    class TestResult(object):
        def __init__(self, value):
            self.value = value

    test_object = TestPlaybook()
    test_object._entries = []

    options = {'inventory': 'localhost,'}
    inventory_manager = InventoryManager(loader=None, sources=options['inventory'].split(',')[0])
    play_context = PlayContext()
    play_context.inventory = inventory_manager.get_inventory()


# Generated at 2022-06-21 09:38:44.274487
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    display.verbosity = 3
    vars_plugin = vars_loader.get('file')
    path = os.path.dirname(__file__)
    entities = []
    data = get_plugin_vars(None, vars_plugin, path, entities)
    assert "file" in data, "file is not in vars"
    assert "meta" in data.get('file'), "meta is not in vars -> file"
    assert type(data.get('file').get('meta')) is dict, "meta is not dict"

# Generated at 2022-06-21 09:38:54.235074
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    vars_loader.add_directory(os.path.join(os.path.dirname(__file__), '..', '..', '..', 'test', 'unit', 'plugins', 'modules'))

    # This plugin defines VARS_PLUGIN_VARS_PATH = 'plugin_vars', test_plugin
    # defines VARS_PLUGIN_INIT_* and VARS_PLUGIN_GET_VARS_* to make sure that
    # all functions are called according to the method used
    vars_loader.add_directory(os.path.join(os.path.dirname(__file__), '..', '..', '..', 'test', 'unit', 'plugins', 'vars'))


# Generated at 2022-06-21 09:39:12.104766
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    '''
    This is a utility function used by the inventory class and not intended to be
    part of a public api.  The return value of this function is not defined and should not
    be relied on.
    '''
    class FakeVarsPlugin:
        _load_name = 'foo'
        _original_path = 'baz'
        def get_vars(self, loader, path, entities):
            return dict(foo=1, bar=2)

    class FakeVarsPlugin2:
        _load_name = 'bar'
        _original_path = 'baz'
        def get_host_vars(self, name):
            return dict(foo=1, bar=2)

    class FakeVarsPlugin3:
        _load_name = 'baz'
        _original_path = 'baz'
       

# Generated at 2022-06-21 09:39:23.988480
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    def _is_in_path(path, string):
        return path.find(string) != -1

    from ansible.cli.playbook import PlaybookCLI
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import vars_loader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    test_loader = 'test_loader'
    test_namespace = 'test_namespace'

    # Empty inventory, empty sources
    vars = get_vars_from_inventory_sources(test_loader, [], [], 'task')
    assert(vars == {})

    # Empty inventory, one source that doesn't match a file.

# Generated at 2022-06-21 09:39:31.793401
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    # inventory data example file path
    test_file_path = "/path/to/data_example.yml"
    # plugin data example
    test_plugin_data = {"test_data": "test data", "another_test_data": "test data 2"}

    # Mock AnsiblePlugin and AnsibleCollectionPlugin objects
    class Mock_AnsiblePlugin:
        _load_name = 'test_plugin'
        _original_path = '/path/to/test_plugin'
        VERSION = 2

        def __init__(self):
            pass

        def get_vars(self, loader, path, entities):
            return test_plugin_data

    class Mock_AnsibleCollectionPlugin:
        _load_name = 'test_collection_plugin'
        _original_path = '/path/to/test_collection_plugin'


# Generated at 2022-06-21 09:39:34.568415
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    try:
        data = get_plugin_vars('loader', plugin, path, entities)
    except Exception as e:
        raise e



# Generated at 2022-06-21 09:39:38.980492
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.loader import vars_loader
    plugin = vars_loader.all()[0]
    loader = None
    path = os.path.dirname(__file__)
    entities = None
    assert get_plugin_vars(loader, plugin, path, entities) is not None

# Generated at 2022-06-21 09:39:44.721948
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager

    loader = InventoryManager("/tmp/foo")
    data = get_vars_from_inventory_sources(loader, ['/tmp/foo'], [], 'inventory')
    assert data == {}

# Generated at 2022-06-21 09:39:52.148975
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    loader = "ansible/plugins/vars"
    path = "ansible/plugins/vars/group_vars/all.yml"

    # Source: https://github.com/ansible/ansible/blob/devel/lib/ansible/inventory/host.py#L431
    class TestHost(object):
        """
        A base representation for hosts in the inventory.
        """
        def __init__(self, name, port=None, variables=None, defaults=None):
            self.name = name
            self.vars = variables or {}
            self.groups = []
            self.defaults = defaults or {}
            self.set_variable('ansible_ssh_port', port or self.defaults.get('port', C.DEFAULT_REMOTE_PORT))

# Generated at 2022-06-21 09:40:05.262212
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager

    plugin_vars = {}

    def get_plugin_vars_mock(loader, plugin, path, entities):
        plugin_vars[plugin.get_name()] = plugin
        return {}

    # Monkey patch the function
    get_plugin_vars.side_effect = get_plugin_vars_mock

    # Test what happens with an invalid inventory source
    i = InventoryManager([], sources=["foobar"])
    vars_from_inventory_sources = get_vars_from_inventory_sources(i._loader, i._sources, i.get_hosts('all'), 'inventory')
    assert vars_from_inventory_sources == {}

    # Test a valid inventory source

# Generated at 2022-06-21 09:40:15.771609
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    # Case 1: A simple function
    def func_vars_plugin(var1, var2):
        return {var1: var2}

    assert get_plugin_vars(None, func_vars_plugin, '', [1, 2]) == {1: 2}

    # Case 2: A simple class
    class ClassVarsPlugin:
        def __init__(self, var1, var2):
            self.result = {var1: var2}

        def get_vars(self, loader, path, entities):
            return self.result

    result = get_plugin_vars(None, ClassVarsPlugin(1, 2), '', [])
    assert isinstance(result, dict)
    assert result == {1: 2}

    # Case 3: A class with get_vars and no __init__ method


# Generated at 2022-06-21 09:40:18.808265
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    assert get_vars_from_path(None, '/', [], 'inventory') == {}, "get_vars_from_path failed"

# Generated at 2022-06-21 09:40:24.648809
# Unit test for function get_vars_from_inventory_sources

# Generated at 2022-06-21 09:40:25.623174
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    loader = AnsibleLoader()

    # Can't do much here as it's constructor only
    print(loader.get_plugin_vars(None, None, None, None))



# Generated at 2022-06-21 09:40:31.802251
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    class plugin:
        def get_vars(self, loader, path, entities):
            return {'vars': 'value'}

    loader = 'loader'
    path = 'path'
    entities = 'entities'
    vars = get_plugin_vars(loader, plugin, path, entities)
    if vars['vars'] == 'value':
        return True
    return False


# Generated at 2022-06-21 09:40:33.589986
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    # vars_loader can't be mocked in a clean way
    pass


# Generated at 2022-06-21 09:40:42.764881
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    loader = None
    sources = [None, 'tests/data/vars_file/vars.yml', 'tests/data/vars_file/vars/sub1.yml',
               'tests/data/vars_file/vars/sub2.yml', 'tests/data/vars_file/vars/sub2/subsub1.yml',
               'tests/data/vars_file/vars/sub2/subsub2.yml']
    entities = [Host('localhost', 'localhost', {}, loader)]
    stage = 'inventory'

# Generated at 2022-06-21 09:40:45.243258
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert get_vars_from_path(None, 'file1', ['file1', 'file2'], 'inventory') == {}

# Generated at 2022-06-21 09:40:53.134600
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    inventory = Inventory(loader=DataLoader(), variable_manager=None, host_list=["localhost"])
    inventory.get_hosts("all")
    vars = inventory.get_vars()

    assert vars.get("ansible_facts") is None
    assert vars.get("ansible_all_ipv4_addresses") is None
    assert vars.get("ansible_all_ipv6_addresses") is None

# Generated at 2022-06-21 09:40:55.047520
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert get_vars_from_path('loader', 'path', 'entities', 'stage') == {}

# Generated at 2022-06-21 09:41:02.866850
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins import vars_plugins
    from ansible.plugins.loader import vars_loader
    from ansible.vars.manager import VariableManager

    vars_loader.add(vars_plugins.CommentedVars)
    vm = VariableManager()
    vars_plugin = vm.get_plugin_loader().get(vars_plugins.CommentedVars.__name__)
    assert get_plugin_vars(vm, vars_plugin, path="", entities=[]) == {}

# Generated at 2022-06-21 09:41:13.418843
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    # Test all variables enabled case
    assert len(get_vars_from_inventory_sources(loader=None, sources=[], entities=[], stage=None)) == 0

    # Test all variables disabled case
    C.VARIABLE_PLUGINS_ENABLED = []
    assert len(get_vars_from_inventory_sources(loader=None, sources=[], entities=[], stage=None)) == 0
    C.VARIABLE_PLUGINS_ENABLED = ['test']

    # Test vars plugin global demand disabled case
    C.RUN_VARS_PLUGINS = 'demand'
    assert len(get_vars_from_inventory_sources(loader=None, sources=[], entities=[], stage='inventory')) == 0
    C.RUN_VARS_PLUGINS = 'start'



# Generated at 2022-06-21 09:41:29.909950
# Unit test for function get_vars_from_path
def test_get_vars_from_path():

    # This is the absolute path to the path_of_plugins.py script in the test directory
    path = os.path.join(os.path.dirname(__file__), 'path_of_plugins.py')

    # Make a fake inventory and add the path to it.
    class FakeInventory:
        def __init__(self, p):
            self.basedir = p

    inv = FakeInventory(os.path.dirname(path))

    # Make a fake collection and add the path to it.
    class FakeCollection:
        def __init__(self, p):
            self.basedir = os.path.dirname(p)

    collection = FakeCollection(path)

    loader = vars_loader.get(collection)

    # Get the data from the plugins in the path
    data = get_vars_from

# Generated at 2022-06-21 09:41:31.021428
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # TODO
    pass

# Generated at 2022-06-21 09:41:40.812316
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    # Create an empty vars plugin
    class TestVars(object):
        def __init__(self):
            self.run = False

    p = TestVars()
    p._load_name = "test"
    p._original_path = "/some/where"

    data = {
        'plugin_path': '/some/where',
        'plugin_name': 'test',
    }

    got = get_plugin_vars(None, p, None, [])
    assert got == data

    # Create a v1 plugin
    class TestVarsV1(object):
        def __init__(self):
            pass

        def get_vars(self, loader, path, entities):
            return data

    p = TestVarsV1()
    p._load_name = "test"
    p._original_path

# Generated at 2022-06-21 09:41:51.540598
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    C.DEFAULT_VARS_PLUGINS_ENABLED = True
    C.VARIABLE_PLUGINS_ENABLED = [
        'yaml_jinja'
    ]
    C.RUN_VARS_PLUGINS = 'start'

    # yaml_jinja is in 2.10 by default
    assert 'yaml_jinja' in C.VARIABLE_PLUGINS_ENABLED

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=None)
    hosts = [h for h in inventory.hosts]
    groups = [g for g in inventory.groups]
    print(groups)
    print(hosts)

# Generated at 2022-06-21 09:41:59.896653
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    class Dummy(object):
        def run(self, *args, **kwargs):
            return 'test1'
    assert get_plugin_vars(None, Dummy(), None, None) == 'test1'

    class Dummy(object):
        def get_vars(self, *args, **kwargs):
            return 'test1'
    assert get_plugin_vars(None, Dummy(), None, None) == 'test1'

    class Dummy(object):
        def get_group_vars(self, *args, **kwargs):
            return 'test1'
    assert get_plugin_vars(None, Dummy(), None, [object()]) == dict()


# Generated at 2022-06-21 09:42:05.520960
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    parser = DataLoader()
    inventory_manager = InventoryManager(loader=parser)
    inventory_manager.set_inventory(inventory_manager.get_inventory_sources())
    return get_vars_from_inventory_sources(
        parser,
        inventory_manager.sources,
        inventory_manager.hosts,
        'inventory'
    )

# Generated at 2022-06-21 09:42:13.653316
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    # Patch is required for inventory plugins to work
    from ansible.plugins.loader import inventory_loader
    from ansible.plugins.inventory import ini
    inventory_loader.add(ini.InventoryModule())

    loader = 'test-loader'
    sources = ["/path/to/hosts"]
    entities = ['host1']
    stage = 'test'

    data = get_vars_from_inventory_sources(loader, sources, entities, stage)

    assert data

# Generated at 2022-06-21 09:42:14.021899
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    pass

# Generated at 2022-06-21 09:42:16.533173
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    result = get_vars_from_inventory_sources(object, [], [], 'inventory')
    assert result == {}

# Generated at 2022-06-21 09:42:26.170628
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Importing only here to avoid circular dependency
    from ansible.inventory.manager import InventoryManager

    loader = 'setup'
    path = os.path.join(
        'test', 'units', 'plugins', 'vars', 'fixtures', 'inventory', 'test_vars')
    stage = 'inventory'

    # Test with a host
    inventory_manager = InventoryManager(loader, [path], [], [])
    host = inventory_manager.get_host('localhost')
    entities = [host]
    loader = inventory_manager._loader

    # Stage should be default
    data = {'var1': 'host', 'var2': 'hostvar'}
    assert get_vars_from_path(loader, path, entities, stage) == data

    # Test with a group

# Generated at 2022-06-21 09:42:38.961430
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # Load test var plugin
    import imp
    import os
    test_plugin_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'test_vars_plugin.py')
    plugin = imp.load_source('VarPlugin', test_plugin_path)
    plugin = plugin.VarPlugin()
    # Load Vars plugin loader
    import ansible.plugins.loader as loader
    loader._load_vars_plugins()
    # list to hold entities (groups and hosts)
    entities = []
    # create instance of loader
    loader = loader.VarsModuleLoader()
    # add test data to entities
    entities.append(Host('test1'))
    entities.append(Host('test2'))
    # get vars from test plugin
    data = get_plugin_v

# Generated at 2022-06-21 09:42:51.077931
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.inventory.host import Host
    from ansible.plugins.loader import vars_loader
    from ansible.plugins.vars import TestVarsPlugin
    import os

    plugin = vars_loader.get(TestVarsPlugin._load_name)
    path = os.path.abspath('.')
    assert get_plugin_vars(vars_loader, plugin, path, [Host('example.com')]) == {'test_vars': {'host_vars': 'example.com'}}
    assert get_plugin_vars(vars_loader, plugin, path, [Host('example.com', groups=['group1'])]) == {'test_vars': {'group_vars': 'group1'}}

# Generated at 2022-06-21 09:42:51.728739
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    pass

# Generated at 2022-06-21 09:42:52.616585
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    assert True

# Generated at 2022-06-21 09:43:02.153026
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    path = "/home/user/project/inventory/hosts"
    
    # test_sources variable below should be equal to the inventory sources
    # in your inventory/hosts file, e.g. subgroups:
    # test_sources = [
    #   "/home/user/project/inventory/group_vars/all",
    #   "/home/user/project/inventory/group_vars/group1",
    #   "/home/user/project/inventory/group_vars/group2",
    #   "/home/user/project/inventory/web/host_vars/host1",
    #   "/home/user/project/inventory/web/host_vars/host2",
    # ]
    

# Generated at 2022-06-21 09:43:07.675984
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = VariableManager(loader=loader)
    group = inventory.add_group('group')
    host = inventory.add_host('host', group=group)
    data = get_vars_from_inventory_sources(loader, [__file__, None], [host], 'task')
    return data



# Generated at 2022-06-21 09:43:08.906267
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    # TODO - load a path and assert vars are loaded
    pass


# Generated at 2022-06-21 09:43:16.155056
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars import base
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.path import unfrackpath

    loader = AnsibleCollectionLoader()
    plugin = base.VarsModule()

    assert get_plugin_vars(loader, plugin, None, []) is None

    yml = '''
a:
  b: value
  c:
    - 1
    - 2
    - 3
'''
    path = unfrackpath(u'/tmp')
    data = loader.load_from_file(path, yml)
    assert get_plugin_vars(loader, plugin, path, []) == data


# Generated at 2022-06-21 09:43:19.423853
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    loader = None
    plugin = None
    path = None
    entities = None
    assert get_plugin_vars(loader, plugin, path, entities) == {}
    assert get_plugin_vars(loader, plugin, path, entities) == {}

# Generated at 2022-06-21 09:43:19.960607
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    pass

# Generated at 2022-06-21 09:43:36.258646
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    fake_loader = C.VARIABLE_PLUGINS_ENABLED

    class FakePluginRv2():
        def get_vars(self, loader, path, entities):
            return {'foo': 'bar'}

    class FakePluginV1():
        def get_group_vars(self, group):
            return {'foo': 'bar'}

    class FakePlugin():
        def run(self):
            return {'foo': 'bar'}

    fake_plugin_rv2 = FakePluginRv2()
    fake_plugin_v1 = FakePluginV1()
    fake_plugin_no_run = FakePlugin()

    fake_host = Host('fake_host')
    fake_group = Host('fake_group')

    entities = [fake_host, fake_group]

    # Good, Real v

# Generated at 2022-06-21 09:43:43.710980
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    import os
    import tempfile
    import shutil
    # Create a temp directory
    tmpdir = tempfile.mkdtemp()
    test_plugin_dir = os.path.join(tmpdir, "test_plugin")
    os.makedirs(test_plugin_dir)
    # Write __value.py file
    test_plugin_file = open(os.path.join(test_plugin_dir, "__value.py"), "w")

# Generated at 2022-06-21 09:43:50.461145
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    class MockVarLoader(object):
        pass

    class MockPlugin(object):
        def __init__(self, name):
            self._load_name = name

        def get_vars(self, loader, path, entities):
            return {self._load_name: 'ok'}

    vars_loader = MockVarLoader()

    vars_loader.all = lambda: iter([
        MockPlugin('plugin1'),
        MockPlugin('plugin2')
    ])

    assert get_plugin_vars(vars_loader, MockPlugin('plugin1'), '', []) == {'plugin1': 'ok'}

# Generated at 2022-06-21 09:43:56.454226
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    """
    Function to test get_vars_from_inventory_sources function
    """
    from ansible.vars import combine_vars

    assert os.path.exists(get_vars_from_inventory_sources('/etc/ansible/hosts'))
    assert isinstance(data, dict)
    assert isinstance(plugins, list)
    assert combine_vars(data, plugin)

# Generated at 2022-06-21 09:44:04.572951
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    """
    test_get_vars_from_path is a standalone function call to ensure that the get_vars_from_path function returns
    the correct results. This is a white-box test.
    """
    class MockLoader():
        def get_basedir(self, path):
            return path

    class MockHost():
        def __init__(self, name):
            self.name = name

    class MockGroup():
        def __init__(self, name, hostnames):
            self.name = name
            self.hostnames = hostnames

    class MockPlugin():
        _load_name = 'test'
        _original_path = 'test/test/'

        def get_vars(self, loader, path, entities):
            return {}


# Generated at 2022-06-21 09:44:17.158059
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    data = {}
    class DummyPlugin:
        def get_vars(self, loader, path, entities):
            data.update({'get_vars': {'loader': loader}})
            return data

    class DummyPlugin1:
        def get_host_vars(self, host):
            data.update({'get_host_vars': host})
            return data

        def get_group_vars(self, group):
            data.update({'get_group_vars': group})
            return data

    class DummyPlugin2:
        def get_host_vars(self, host):
            data.update({'get_host_vars': host})
            return data

        def get_group_vars(self, group):
            data.update({'get_group_vars': group})


# Generated at 2022-06-21 09:44:25.085702
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    loader = lambda: None

    sources = [
        '/path/to/inventory/file',
        '/path/to/another/inventory/file'
    ]

    entities = [
        Host(name='host1'),
        Host(name='host2')
    ]

    stage = 'inventory'

    data = get_vars_from_inventory_sources(loader, sources, entities, stage)

    assert data == {
        'public_vars': {'group1': 'var1'},
        'vars': {'group2': 'var2'}
    }

# Generated at 2022-06-21 09:44:36.206674
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    class FakeVarsPlugin(object):
        def get_vars(self, loader, path, entities, cache=True):
            return dict(foo=dict(bar=1))
        def get_host_vars(self, host):
            return dict(foo=dict(baz=1))
        def get_group_vars(self, group):
            return dict(foo=dict(group=1))

    class FakeVarsPluginWithoutV2(object):
        def get_host_vars(self, host):
            return dict(foo=dict(baz=1))
        def get_group_vars(self, group):
            return dict(foo=dict(group=1))


# Generated at 2022-06-21 09:44:45.740463
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    class Foo(object):

        def get_vars(self, loader, path, entities):
            return {"foo": "bar"}

    class Bar(object):

        def get_host_vars(self, name):
            return {"bar": name}

        def get_group_vars(self, name):
            return {"baz": name}

    loader = { "Bar": Bar() }
    assert get_plugin_vars(loader, Foo(), None, None) == {"foo": "bar"}
    assert get_plugin_vars(loader, Bar(), None, [Host("foo"), Host("bar")]) == {"bar": "bar", "baz": "bar"}



# Generated at 2022-06-21 09:44:47.247831
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    assert get_vars_from_path(None, None, None, None) == {}

# Generated at 2022-06-21 09:45:01.826434
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    # Test an old vars plugin
    plugin = MockVarsPlugin()

    hosts = [MockHost('test1'), MockHost('test2')]
    data = get_plugin_vars(None, plugin, '/', hosts)

    assert set(data.keys()) == set(['test1', 'test2'])
    assert all(v == {'key': 'value'} for k, v in data.items())

    # Test a new vars plugin
    plugin = MockVars2Plugin()
    data = get_plugin_vars(None, plugin, '/', hosts)

    assert data == {'key': 'value'}



# Generated at 2022-06-21 09:45:11.145818
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    import os
    import sys
    import tempfile
    import shutil
    from ansible.errors import AnsibleError
    from ansible.plugins.loader import vars_loader

    tmpdir = tempfile.mkdtemp(prefix='ansible-test-vars')
    testvars_dir = os.path.join(tmpdir, 'vars_plugin_path', 'vars_plugins')
    os.makedirs(testvars_dir)
    old_sys_path = sys.path
    sys.path.append(testvars_dir)

    plugin_abs_path = os.path.join(testvars_dir, 'test_vars_plugin.py')

# Generated at 2022-06-21 09:45:19.803480
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.vars.manager import InventoryVariableManager
    from ansible.utils.display import Display
    from ansible.vars.hostvars import HostVars
    from ansible.vars.groupvars import GroupVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.cli import CLI
    from ansible.utils.vars import combine_vars
    from ansible.module_utils._text import to_bytes
    from ansible.utils.collection_loader import AnsibleCollectionRef
    from ansible.plugins.loader import vars_loader
    from ansible.plugins.vars import VarsBase

    class vars_plugin0(VarsBase):
        pass

    class vars_plugin1(VarsBase):
        pass


# Generated at 2022-06-21 09:45:20.560542
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    pass



# Generated at 2022-06-21 09:45:28.768877
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.parsing.dataloader import DataLoader

    def get_plugin_vars(loader, plugin, path, entities):
        return {'test_var': 'test_val'}

    display.verbosity = 4

    # test with C.RUN_VARS_PLUGINS set to 'demand' and stage set to inventory
    # expect an empty dict returned
    C.RUN_VARS_PLUGINS = 'demand'
    stage = 'inventory'
    data = get_vars_from_inventory_sources(DataLoader(), ['dummy_path'], ['dummy_entity'], stage)
    assert data == {}

    # test with C.RUN_VARS_PLUGINS set to 'start' and stage set to task
    # expect an empty dict returned
    C.RUN_VARS

# Generated at 2022-06-21 09:45:34.971918
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible_collections.ansible.plugins.vars import test_vars_plugin

    test_plugin = test_vars_plugin.VarsModule()

    loader = vars_loader
    path = "tests/files/test_get_vars_from_path"
    entities = []

    test_data = get_plugin_vars(loader, test_plugin, path, entities)
    expected_data = {'plugin_var': 'test'}

    assert test_data == expected_data

# Generated at 2022-06-21 09:45:46.115809
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    import os
    import tempfile

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file containing a list of inventory source paths
    fd, path = tempfile.mkstemp()
    os.close(fd)
    with open(path, 'w+') as f:
        f.write('''
          host_vars
          group_vars
        ''')

    # Create a temporary directory with host and group vars
    os.mkdir(os.path.join(tmpdir, 'host_vars'))
    os.mkdir(os.path.join(tmpdir, 'group_vars'))

# Generated at 2022-06-21 09:45:53.997364
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    import unittest
    import tempfile
    import os
    import shutil
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.six import PY3

    class StubVarsPlugin:

        _load_name = 'test_vars_plugin'
        _original_path = b'/test/test_vars_plugin.py'
        VARS_CACHE_DATABASE = None

        @staticmethod
        def get_vars(loader, path, entities, cache=True):
            with open(os.path.join(path, 'vars_plugin')) as f:
                return yaml.safe_load(f)


# Generated at 2022-06-21 09:46:02.211345
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager

    sources = ['./inventory/a', './inventory/b']
    entities = InventoryManager(loader=None, sources=sources).hosts

    data = get_vars_from_inventory_sources(None, None, entities, 'start')
    assert data == {
        'a_var': False,
        'b_var': True
    }

    data = get_vars_from_inventory_sources(None, sources, entities, 'start')
    assert data == {
        'a_var': True,
        'b_var': True
    }

# Generated at 2022-06-21 09:46:03.624657
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    # unit tests for this function are not implemented as yet.
    return 0

# Generated at 2022-06-21 09:46:25.689878
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    import ansible.plugins.vars
    import os
    import sys

    # Test variables that change per-platform
    test_vars = {
        "example": {"variable": "value"},
        "directory": {
            "separator": os.path.sep,
            "script": sys.executable,
        }
    }

    # Test variables that are the same everywhere

# Generated at 2022-06-21 09:46:33.324185
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    sources = [os.path.join(os.path.dirname(__file__), 'vars', 'inventory_1')]
    inventory = InventoryManager(loader, sources)
    assert 'host1_var1' in get_vars_from_inventory_sources(loader, sources, inventory.groups['all'].get_hosts(), 'task')
    assert 'group1_var1' in get_vars_from_inventory_sources(loader, sources, inventory.groups['group1'].get_hosts(), 'inventory')

# Generated at 2022-06-21 09:46:43.962600
# Unit test for function get_plugin_vars
def test_get_plugin_vars():

    # Mock the plugin object
    class MockVars_Plugin:
        def get_vars(self, loader, path, entities):
            # Mock the new v2 vars plugin
            return {'test_dict': {'test_key1': 'test_value1', 'test_key2': 'test_value2'}}

    class MockVars_Node_Plugin:
        def get_host_vars(self, host):
            # Mock the new v2 vars plugin
            return {'test_node': 'test_value'}

    class MockVars_Group_Plugin:
        def get_group_vars(self, group):
            # Mock the new v2 vars plugin
            return {'test_group': 'test_value'}


# Generated at 2022-06-21 09:46:55.637704
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.vars.test_vars_plugin import VarsModule
    from ansible.plugins import vars_loader
    from ansible.utils.collection_loader import AnsibleCollectionRef

    data = VarsModule.get_vars({}, None, {})
    assert data == {'test_get_vars': True}, 'test_get_vars failed: %s' % data
    data = VarsModule.get_host_vars('localhost')
    assert data == {'test_get_host_vars': True}, 'test_get_host_vars failed: %s' % data
    data = VarsModule.get_group_vars('all')
    assert data == {'test_get_group_vars': True}, 'test_get_group_vars failed: %s' % data



# Generated at 2022-06-21 09:47:03.824575
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    sources = ['/var/lib/awx/projects/test-project/', '/etc/ansible/hosts']
    entities = ['localhost', 'test-host']
    loader = 'loader'
    stage = 'task'
    expected_data = {
        'localhost': {
            'test_value': 'local_host'
        },
        'test-host': {
            'test_value': 'test_host'
        }
    }

    actual_data = get_vars_from_inventory_sources(loader, sources, entities, stage)

    assert expected_data == actual_data

# Generated at 2022-06-21 09:47:07.414732
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():
    from ansible.errors import AnsibleError
    from ansible.plugins import vars_loader
    try:
        vars_loader.all()
    except AnsibleError:
        raise Exception('Cannot load plugins from a non-existent directory')

# Generated at 2022-06-21 09:47:13.775764
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    from ansible.plugins.loader import vars_loader as vars_loader2
    from ansible.plugins.vars.host_list import VarsModule as VarsModule2
    _loader = vars_loader2()
    plugin = VarsModule2()
    plugin_name = 'host_list'
    plugin_path = '/tmp/'
    # Call get_plugin_vars function
    data = get_plugin_vars(loader=_loader, plugin=plugin, path=plugin_path, entities=[plugin_name])
    print(data)



# Generated at 2022-06-21 09:47:20.064985
# Unit test for function get_vars_from_path
def test_get_vars_from_path():
    def get_plugin_vars_mock():
        def get_vars(path, entities):
            return {'path': path, 'entities': entities}
        return get_plugin_vars_mock

    loader = None
    path = 'bar'
    entities = ['foo']
    stage = 'task'
    vars_loader.get = get_plugin_vars_mock()
    result = get_vars_from_path(loader, path, entities, stage)
    assert result == {'path': path, 'entities': entities}

# Generated at 2022-06-21 09:47:27.573950
# Unit test for function get_vars_from_inventory_sources
def test_get_vars_from_inventory_sources():

    display.verbosity = 3
    display.debug("testing get_vars_from_inventory_sources() with invalid inventory source")
    source = "/etc/null"
    sources = [ source ]
    assert (get_vars_from_inventory_sources(None, sources, None, None) == {})

    display.debug("testing get_vars_from_inventory_sources() with valid inventory source")
    source = "/etc/hosts"
    sources = [ source ]
    assert (get_vars_from_inventory_sources(None, sources, None, None) == {})

# Generated at 2022-06-21 09:47:37.349869
# Unit test for function get_plugin_vars
def test_get_plugin_vars():
    # Import this to prevent circular imports.
    from ansible.plugins.vars import test_vars_plugin_v2

    entities = [Host('localhost')]
    loader = None
    plugin = test_vars_plugin_v2
    plugin._load_name = 'test_vars_plugin_v2'
    plugin.plugin_collection = AnsibleCollectionRef.from_string('test.test_vars_plugin')
    path = '/tmp/test/test_vars_plugin_v2/'