

# Generated at 2022-06-26 05:56:48.338317
# Unit test for function get_new_command
def test_get_new_command():
    tuple_0 = ()
    var_0 = get_new_command(tuple_0)


# Generated at 2022-06-26 05:56:50.451191
# Unit test for function get_new_command
def test_get_new_command():
    tuple_0 = ()
    var_0 = get_new_command(tuple_0)


# Generated at 2022-06-26 05:56:55.340193
# Unit test for function get_new_command
def test_get_new_command():
    # assert match('git-add "foo"')
    # assert match('git add foo')
    # assert match('git add bar')
    pass
    # assert get_new_command('git add foo') == 'git add foo --force'
    # assert get_new_command('git add bar') == 'git add bar --force'

# Generated at 2022-06-26 05:56:57.984180
# Unit test for function match
def test_match():
    assert match(None) == False

    command = Command(script='git add .', output='Use -f if you really want to add them.')
    assert match(command) == True


# Generated at 2022-06-26 05:57:00.046924
# Unit test for function get_new_command
def test_get_new_command():
    tuple_0 = ()
    var_0 = get_new_command(tuple_0)
    assert var_0 == 'git add --force'

# Generated at 2022-06-26 05:57:02.547542
# Unit test for function match
def test_match():
    tuple_0 = Command('git add .', 'fatal: pathspec \'foobar\' did not match any files\nUse -f if you really want to add them.')
    var_0 = match(tuple_0)
    assert var_0 == False


# Generated at 2022-06-26 05:57:06.951859
# Unit test for function match
def test_match():
    if match(Command('git add', 'warning: LF will be replaced by CRLF in .travis.yml.\nThe file will have its original line endings in your working directory.')):
        assert True
    else:
        assert False



# Generated at 2022-06-26 05:57:08.580505
# Unit test for function match
def test_match():
    assert match(tuple_0) == var_0


# Generated at 2022-06-26 05:57:13.937734
# Unit test for function match
def test_match():
    assert match(Command('git add', output='Use -f if you really want to add them.'))
    assert not match(Command('git add', output='foo'))
    assert not match(Command('git branch', output='Use -f if you really want to add them.'))
    assert not match(Command('git add', output='fatal: not a git repository'))


# Generated at 2022-06-26 05:57:17.850586
# Unit test for function match
def test_match():
    tuple_0 = Command('git add', 'The following paths are ignored by one of your .gitignore files:\nfatal: no files added\nUse -f if you really want to add them.')
    var_0 = match(tuple_0)
    tuple_1 = Command('git add', '')
    var_1 = match(tuple_1)
    return var_0, var_1


# Generated at 2022-06-26 05:57:21.616490
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("git add --all", "Use -f if you really want to add them.")
    expected = "git add --force --all"
    assert get_new_command(command) == expected

# Generated at 2022-06-26 05:57:30.174817
# Unit test for function match
def test_match():
    assert match(Command('git add',
                         output='fatal: pathspec \'0x00\' did not match any files\n'
                                'Use -f if you really want to add them.'))
    assert not match(Command('ls'))
    assert not match(Command('git add .',
                             output='fatal: pathspec \'0x00\' did not match any files\n'
                                    'Use -f if you really want to add them.'))
    assert not match(Command('git add',
                             output='fatal: pathspec \'0x00\' did not match any files\n'))


# Generated at 2022-06-26 05:57:33.476264
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git add README.md', 
        'The following paths are ignored by one of your '.format(
            environ['HOME']), 
        'Use -f if you really want to add them.')) == 'git add --force README.md'

# Generated at 2022-06-26 05:57:37.194994
# Unit test for function match
def test_match():
    assert match(Command('git add dir/file.txt', '', 'fatal: Path \'dir/file.txt\' is in submodule \'dir/\'\nUse -f if you really want to add them.'))
    assert not match(Command('git add dir/file.txt', '', ''))


# Generated at 2022-06-26 05:57:38.267781
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git add') == 'git add --force'

# Generated at 2022-06-26 05:57:40.170607
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git add file.txt', 'Use -f if you really want to add them.')
    assert get_new_command(command) == 'git add --force file.txt'


# Generated at 2022-06-26 05:57:44.783776
# Unit test for function get_new_command
def test_get_new_command():
    command1 = Command('git add .', '', '')
    command2 = Command('git add .', 'Use -f if you really want to add them.', '')
    get_new_command(command1) == 'git add .'
    get_new_command(command2) == 'git add --force .'

# Generated at 2022-06-26 05:57:49.358402
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git add file1 file2 file3', 'The following untracked working tree files would be overwritten by merge:\n    file1\n    file2\n    file3\nPlease move or remove them before you can merge.')
    assert get_new_command(command) == 'git add --force file1 file2 file3'

# Generated at 2022-06-26 05:57:53.512417
# Unit test for function match
def test_match():
    assert not match(Command('git branch', '', ''))
    assert match(Command('git add main', '', ''))

# Generated at 2022-06-26 05:57:55.616203
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git add', 'Use -f if you really want to add them.')) == 'git add --force'

# Generated at 2022-06-26 05:58:01.713302
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git add *.txt', 'fatal: pathspec \'*.txt\' did not match any files\nUse -f if you really want to add them.')) == 'git add --force *.txt'


enabled_by_default = False

# Generated at 2022-06-26 05:58:05.151578
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git add', '', 'Use -f if you really want to add them.')) == 'git add --force'

# Generated at 2022-06-26 05:58:11.803068
# Unit test for function match
def test_match():
    assert (match(Command('git add fileToAdd', 'error: The following untracked working tree files would be overwritten by merge:\n	fileToAdd\n')) ==
            True)
    assert (match(Command('git add fileToAdd', 'error: Unknown option: -f')) ==
            False)
    assert (match(Command('git add --force fileToAdd', 'error: Unknown option: -f')) ==
            False)
    assert (match(Command('git add .', 'error: The following untracked working tree files would be overwritten by merge:\n	fileToAdd\n')) ==
            False)
    assert (match(Command('git add fileToAdd', 'error: pathspec \'fileToAdd\' did not match any files')) ==
            False)


# Generated at 2022-06-26 05:58:21.033715
# Unit test for function get_new_command
def test_get_new_command():

    """ Unit test for function get_new_command """
    from thefuck.rules.git_add_ignored import get_new_command

    # Test 1: When string 'add' is present and command outputs the same
    #         error message
    command = Command('git add')
    command.script_parts = command.script.split(' ')
    command.output = ('The following paths are ignored by one of your .'
                      'gitignore files:\n'
                      'dataset\n'
                      'Use -f if you really want to add them.')
    correct_command = 'git add --force'

    assert get_new_command(command) == correct_command

    # Test 2: When string 'add' is not present in command
    command = Command('git')
    command.script_parts = command.script.split(' ')

# Generated at 2022-06-26 05:58:26.104059
# Unit test for function match
def test_match():
    assert match(Command('git add README.md',
                         output='The following paths are ignored by one of your .gitignore files:\nREADME.md\nUse -f if you really want to add them.\nfatal: no files added\n'))
    assert not match(Command('git add README.md', output='fatal: no files added\n'))
    assert not match(Command('git add README.md', output='error: bad line'))


# Generated at 2022-06-26 05:58:34.297076
# Unit test for function match
def test_match():
    assert match(Command('git add .', ''))
    assert match(Command('$ git add .', ''))
    assert match(Command('git add', ''))
    assert match(Command('$ git add', ''))
    assert not match(Command('git add .', 'Use -f if you really want to add them.'))
    assert not match(Command('$ git add .', 'Use -f if you really want to add them.'))
    assert not match(Command('git add', 'Use -f if you really want to add them.'))
    assert not match(Command('$ git add', 'Use -f if you really want to add them.'))


# Generated at 2022-06-26 05:58:37.431794
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('sudo git add', 'The following untracked working tree files would be overwritten by merge:\n    filename.txt\n\nPlease move or remove them before you merge.\n\nAborting')
    assert get_new_command(command) == 'sudo git add --force'


# Generated at 2022-06-26 05:58:41.640164
# Unit test for function match
def test_match():
    # GIVEN a git command with a file we don't have permission to write to
    command = Command('git add foo.txt', 'foo.txt: Permission denied')

    # WHEN we check if this command matches with match function
    result = match(command)

    # THEN match should return True
    assert result



# Generated at 2022-06-26 05:58:45.914334
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.git_use_f_to_force_add import get_new_command
    assert get_new_command(Command('git add *',
                                   "fatal: Path 'test.py' is in submodule 'test'\nUse -f if you really want to add them.\n")) == 'git add --force *'



# Generated at 2022-06-26 05:58:50.891681
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git add *.py',
                      'The following paths are ignored by one of your .gitignore files:\n*.pyc\nUse -f if you really want to add them.\nfatal: no files added')
    new_command = get_new_command(command)
    assert new_command == 'git add --force *.py'

# Generated at 2022-06-26 05:58:58.381529
# Unit test for function match
def test_match():
    assert match(Command(script='git add', output='Use -f if you really want to add them.'))
    assert not match(Command(script='git add', output='Error: No such file or directory'))



# Generated at 2022-06-26 05:59:03.329792
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git add foo') == 'git add --force foo'



# Generated at 2022-06-26 05:59:04.669570
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command ('git add 4') == 'git add --force 4'

# Generated at 2022-06-26 05:59:06.334930
# Unit test for function match

# Generated at 2022-06-26 05:59:08.490367
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git add',
                            output='error: The following untracked working tree files would be overwritten by merge:\n')) == 'git add --force'

# Generated at 2022-06-26 05:59:11.988191
# Unit test for function match
def test_match():
    assert match(Command('git add test.txt', 'fatal: Pathspec \'test.txt\' is in submodule \'sub/test/\'\nUse --force if you really want to add them.\n', None))
    assert not match(Command('git add test.txt', '', None))


# Generated at 2022-06-26 05:59:18.169082
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script='git add', output='The following untracked working tree files would be overwritten by merge:\n    bar\n    foo\n')
    assert get_new_command(command) == 'git add --force'


# Generated at 2022-06-26 05:59:23.039373
# Unit test for function match
def test_match():
    command = Command('git add foo',
                      "The following paths are ignored by one of your .gitignore files:",
                      0)
    assert match(command)
    command = Command('git add foo',
                      "The following paths are ignored by one of your .gitignore files:",
                      1)
    assert not match(command)


# Generated at 2022-06-26 05:59:28.379436
# Unit test for function match
def test_match():
    assert match(Command('git add .'))
    assert match(Command('git add .', 'nothing added to commit but untracked files present (use "git add" to track)'))
    assert not match(Command('git add -f .'))
    assert not match(Command('git put .'))

# Generated at 2022-06-26 05:59:39.634918
# Unit test for function match
def test_match():
    # Complete match
    assert match(Command('git add .', 'fatal: pathspec \'@\' did not match any files\nUse -f if you really want to add them.'))
    # Match with extra arguments
    assert match(Command('git add . --all', 'fatal: pathspec \'@\' did not match any files\nUse -f if you really want to add them.'))
    assert match(Command('git add . --all -a', 'fatal: pathspec \'@\' did not match any files\nUse -f if you really want to add them.'))
    # Partial match
    assert not match(Command('git add .', 'fatal: pathspec \'@\' did not match any files\nUse -f if you really want to add them.'))
    # No match

# Generated at 2022-06-26 05:59:52.040117
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('''git add .''') == 'git add --force .'

# Generated at 2022-06-26 05:59:58.626006
# Unit test for function match
def test_match():
	from thefuck.rules.git_force_add import match
	from thefuck.rules.git_force_add import get_new_command
	from thefuck.shells import Shell
	
	correct_input = "git add test.txt "
	wrong_input = "git status"
	
	funct = match(Shell(correct_input, "Use -f if you really want to add them."))
	funct2 = match(Shell(wrong_input, "nothing"))
	
	assert(funct==True)
	assert(funct2==False)


# Generated at 2022-06-26 06:00:04.527888
# Unit test for function match
def test_match():
        command = Command("git add && git commit -m 'Add new file'",
                          "The following paths are ignored by one of your .gitignore files:\nfoo.txt\nUse -f if you really want to add them.\nfatal: no files added\n")
        assert match(command)


# Generated at 2022-06-26 06:00:07.136488
# Unit test for function match
def test_match():
    assert match(Command('git add file.txt', ''))
    assert not match(Command('git add file.txt', '', stderr=''))
    assert not match(Command('git stash', '', stderr=''))


# Generated at 2022-06-26 06:00:09.761773
# Unit test for function match
def test_match():
    assert match(Command('git add',
                         'Use -f if you really want to add them.'))
    assert not match(Command('git add', ''))
    assert not match(Command('ls', ''))


# Generated at 2022-06-26 06:00:14.639431
# Unit test for function get_new_command
def test_get_new_command():
    assert_equal(get_new_command(Command(script='git add .',
                                         output='Use -f if you really want to add them.')),
                 'git add --force .')

    assert_equal(get_new_command(Command(script='git add file.txt',
                                         output='Use -f if you really want to add them.')),
                 'git add --force file.txt')



# Generated at 2022-06-26 06:00:18.437580
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git add foo', 'The following paths are ignored by one of your .gitignore files:', '')
    assert get_new_command(command) == 'git add --force foo'


enabled_by_default = True

# Generated at 2022-06-26 06:00:20.435348
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("git add .gitignore", '', '', 0)) == "git add --force .gitignore"

# Generated at 2022-06-26 06:00:23.515061
# Unit test for function match
def test_match():
    assert match(Command('git add file1 file2 file3', 'Use -f if you really want to add them.', None))
    assert not match(Command('git add file1 file2 file3', '', None))


# Generated at 2022-06-26 06:00:26.130306
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.shells import Bash
    assert get_new_command(
        Bash('git add .', 'use "git add <file>..." to update what will be committed',
             '', 1)) == 'git add --force .'


# Generated at 2022-06-26 06:00:55.317579
# Unit test for function match
def test_match():
    assert not match('git add')
    assert not match('git add newfile')
    assert not match('git add .')
    
    output = '''The following paths are ignored by one of your .gitignore files:
files
Use -f if you really want to add them.
fatal: no files added
'''
    
    assert match('git add -f files', output)
    assert match('git add -f files', output)
    output = '''The following paths are ignored by one of your .gitignore files:
files
Use -f if you really want to add them.
'''
    assert match('git add -f files', output)
    assert match('git add -f files', output)

# Generated at 2022-06-26 06:01:02.373687
# Unit test for function match
def test_match():
    assert match(Command("git add .", output="The following paths are ignored by one of your .gitignore files:\n.gitignore\nUse -f if you really want to add them.\n"))
    assert not match(Command("git add .", output="The following paths are ignored by one of your .gitignore files:\n.gitignore\nUse -f if you really want to add them.\ngit status"))
    assert not match(Command("git add .", output="The following paths are ignored by one of your .gitignore files:\n.gitignore\nUse -f if you really want to add them."))

# Generated at 2022-06-26 06:01:06.382700
# Unit test for function get_new_command
def test_get_new_command():
    mock_command = Mock(script='git add file.py',
                        output='The following paths are ignored by one of your .gitignore files:',
                        stderr='Use -f if you really want to add them.')
    assert get_new_command(mock_command) == 'git add --force file.py'


# Generated at 2022-06-26 06:01:14.077808
# Unit test for function match
def test_match():
    assert match(Command()) == False
    assert match(Command('git add')) == False
    assert match(Command('git add .')) == False
    assert (match(Command(
        'git add .',
        'error: The following untracked working tree files would be ' +
        'overwritten by merge:\n' +
        '\ta.txt\n' +
        'Please move or remove them before you can merge.\n' +
        'Aborting\n')) == False)
    assert (match(Command(
        'git add .',
        'error: The following untracked working tree files would be added by merge:\n' +
        '\ta.txt\n' +
        'Please move or remove them before you can merge.\n' +
        'Aborting\n')) == True)

# Generated at 2022-06-26 06:01:21.777876
# Unit test for function match
def test_match():
    assert match(Command('git add .',
                'fatal: pathspec \'test.txt\' is in submodule \'test\''))
    assert match(Command('git add .', 'fatal: pathspec \'test.txt\' is in submodule \'test\''))
    assert match(Command('git add .', 'fatal: pathspec is in submodule \'test\''))
    assert not match(Command('git add .', ''))
    assert not match(Command('git add', ''))
    assert not match(Command('ls', ''))



# Generated at 2022-06-26 06:01:22.701792
# Unit test for function match
def test_match():
    command = Command('git add', '')
    assert match(command)



# Generated at 2022-06-26 06:01:24.175106
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.git_add_error import get_new_command
    assert not get_new_command('git add fichero.txt')
    assert get_new_command('git add fichero.txt')[1] == 'git add --force fichero.txt'

# Generated at 2022-06-26 06:01:29.617259
# Unit test for function match
def test_match():
    assert match(Command(script = 'git add -A', output = 'Use -f if you really want to add them.'))
    assert match(Command(script = 'git add -A', output = 'Use -f if you really want to add them.'))
    assert not match(Command(script = 'git add -A', output = 'You found me'))
    assert not match(Command(script = 'git add -A', output = 'You found me'))


# Generated at 2022-06-26 06:01:34.973480
# Unit test for function get_new_command
def test_get_new_command():

    command = botcmd.Command('git add', \
                             'fatal: LF would be replaced by CRLF in README.md' \
                             '\nUse -f if you really want to add them.'\
                             '\n', '')

    assert git.get_new_command(command) == 'git add --force'

# Generated at 2022-06-26 06:01:39.087811
# Unit test for function match
def test_match():
    assert match(Command('git add app.py',
                         'error: The following untracked working tree files would be overwritten by merge:\n    app.py\nPlease move or remove them before you can merge.\nAborting',
                         '', 1))
    assert not match(Command('git add app.py', '', '', 1))


# Generated at 2022-06-26 06:02:42.462229
# Unit test for function get_new_command
def test_get_new_command():
    command = "git add ."
    output = "The following paths are ignored by one of your .gitignore files:\nfoo.txt\nUse -f if you really want to add them."
    assert get_new_command(MagicMock(script=command, output=output)) == "git add --force ."

# Generated at 2022-06-26 06:02:47.631330
# Unit test for function match
def test_match():
    assert match(Command("git rebase --edit-todo",
                         "error: The following untracked working tree files would be overwritten by checkout:\n"
                         "        scripts/build-deb\n"
                         "Please move or remove them before you can switch branches.\n"
                         "Aborting",
                         ""))
    assert not match(Command("git rebase --edit-todo", "", ""))


# Generated at 2022-06-26 06:02:56.278726
# Unit test for function match
def test_match():

    # Test match function when command is correct
    command = Command('git add', 'The following paths are ignored by one of '
                      'your .gitignore files:\n'
                      'swagger-ui/\n'
                      'Use -f if you really want to add them.')
    assert match(command)

    # Test match function when command is wrong
    command = Command('git commit', 'The following paths are ignored by one of '
                      'your .gitignore files:\n'
                      'swagger-ui/\n'
                      'Use -f if you really want to add them.')
    assert not match(command)



# Generated at 2022-06-26 06:02:58.571448
# Unit test for function get_new_command
def test_get_new_command():
    result = get_new_command('git add file')
    assert result == ('git add --force file')

# Generated at 2022-06-26 06:03:03.172071
# Unit test for function match
def test_match():
    assert match(Command('git add .', 'fatal: pathspec \'.\' did not match any files\nUse -f if you really want to add them.'))
    assert not match(Command('git add .', 'fatal: pathspec \'.\' did not match any files'))
    assert not match(Command('git pull', 'fatal: pathspec \'.\' did not match any files\nUse -f if you really want to add them.'))


# Generated at 2022-06-26 06:03:03.868342
# Unit test for function get_new_command
def test_get_new_command():
    print(get_new_command('git add'))

# Generated at 2022-06-26 06:03:09.312198
# Unit test for function match
def test_match():
    assert match(Command('git add ABC', 'The following paths are ignored by one of your .gitignore files:\nABC\nUse -f if you really want to add them.'))
    assert not match(Command('git add ABC', ''))
    assert not match(Command('git log ABC', 'ABC\nUse -f if you really want to add them.'))


# Generated at 2022-06-26 06:03:13.045423
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git add *', output='The following paths are ignored by one of your .gitignore files:')
    new_command = get_new_command(command)
    assert 'git add --force *' == new_command


# Generated at 2022-06-26 06:03:14.564217
# Unit test for function match
def test_match():
    match_output = match(Command('git add', stderr='test/test1: needs merge\nUse -f if you really want to add them.'))
    assert match_output


# Generated at 2022-06-26 06:03:17.706925
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='git add .', output="The following paths are ignored by one of your .gitignore files: Use -f if you really want to add them.")) == 'git add --force .'


# Generated at 2022-06-26 06:05:35.850188
# Unit test for function match
def test_match():
    assert match(Command('git add file',
                         'fatal: pathspec \'file\' did not match any files',
                         '', 1))
    assert match(Command('git add file',
                         'fatal: pathspec \'file\' did not match any files\n'
                         'Use -f if you really want to add them.',
                         '', 1))
    assert not match(Command('git add file',
                             'fatal: pathspec \'file\' did not match any files\n'
                             'Use -f if you really want to add them\n'
                             'add --force file',
                             '', 1))
    assert not match(Command('git add file', ''))


# Generated at 2022-06-26 06:05:39.837531
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git add file') == 'git add --force file'
    assert get_new_command('git add --all') == 'git add --all'

# Generated at 2022-06-26 06:05:43.603794
# Unit test for function match
def test_match():
    command = Command('git add .', 'The following paths are ignored by one of your .gitignore files:\nfoo\nUse -f if you really want to add them.')
    assert match(command)


# Generated at 2022-06-26 06:05:48.069218
# Unit test for function match

# Generated at 2022-06-26 06:05:52.762383
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('add non_existing_file', '', '', 'Use -f if you really want to add them.')
    assert get_new_command('git add non_existing_file', command) == 'git add --force non_existing_file'

# Generated at 2022-06-26 06:05:56.809777
# Unit test for function match
def test_match():
    # test that add --force is added if git output is
    # Use -f if you really want to add them
    from thefuck.rules.git_add_force import match
    f = match(Command('git add -A', 'Use -f if you really want to add them.'))
    assert f == True



# Generated at 2022-06-26 06:06:01.901098
# Unit test for function match
def test_match():
    assert match(Command('git add test.txt',
                         'fatal: Pathspec \'test.txt\' is in submodule \'sub\'',
                         ''))

    assert not match(Command('git add test.txt', '', ''))


# Generated at 2022-06-26 06:06:07.079085
# Unit test for function match
def test_match():
    assert match(Command('git add -A', '', '', '', 1, None))
    assert not match(Command('git bla', '', '', '', 1, None))


# Generated at 2022-06-26 06:06:17.300340
# Unit test for function match
def test_match():
    assert match(Command('git add app/models/user.rb',
                         'fatal: Pathspec \'app/models/user.rb\' is in submodule \'app/models\'\n'
                         'Use --force to add the submodule.'))
    assert match(Command('git add app/models/user.rb',
                         'The following paths are ignored by one of your .gitignore files:\n'
                         'app/models/user.rb\n'
                         'Use -f if you really want to add them.'))
    assert not match(Command('git add app/models/user.rb', ''))


# Generated at 2022-06-26 06:06:19.054819
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git add .') == 'git add --force .'
    assert get_new_command('git add *') == 'git add --force *'