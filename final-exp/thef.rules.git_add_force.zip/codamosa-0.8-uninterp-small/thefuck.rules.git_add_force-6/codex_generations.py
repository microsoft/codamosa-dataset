

# Generated at 2022-06-26 05:56:52.529513
# Unit test for function match
def test_match():
    assert match(bool_0)


# Generated at 2022-06-26 05:56:57.619158
# Unit test for function get_new_command
def test_get_new_command():
    stderr = ("The following paths are ignored by one of your .gitignore files:\n"
              "    foo\n"
              "Use -f if you really want to add them.\n"
              "fatal: no files added\n")
    assert get_new_command('git add foo', stderr) \
        == 'git add --force foo'

# Generated at 2022-06-26 05:56:58.557899
# Unit test for function get_new_command

# Generated at 2022-06-26 05:57:02.087674
# Unit test for function match
def test_match():
    var_0 = Command('git add', 'The following paths are ignored by one of your .gitignore files:', stderr='Use -f if you really want to add them.')
    bool_0 = True
    var_1 = match(var_0)
    assert bool_0 == bool(var_1)


# Generated at 2022-06-26 05:57:07.930845
# Unit test for function get_new_command
def test_get_new_command():
    # Test: Defined input
    command = Command(script="git add --force", output=None)
    assert(get_new_command(command) == command.script)

    # Test: Undefined input
    command = Command(script=None, output=None)
    assert(get_new_command(command) is None)


# Generated at 2022-06-26 05:57:11.890348
# Unit test for function match
def test_match():
    assert not match(Command('git add .', '', ''))
    assert match(Command('git add .', '',
                        'fatal: pathspec \'fi\' did not match any files\nUse -f if you really want to add them.'))



# Generated at 2022-06-26 05:57:16.088641
# Unit test for function get_new_command
def test_get_new_command():

    # (1) Assert function `get_new_command` returns a string value
    assert (type(get_new_command(True)) == str)
    
    # (2) Assert function `get_new_command` returns 
    assert (get_new_command(True) == 'git add --force')



# Generated at 2022-06-26 05:57:25.930690
# Unit test for function match
def test_match():

    bool_0 = True

    var_0 = 'git add .'

    var_1 = 'fatal: pathspec \'Life\' did not match any files\nUse -f if you really want to add them.\n'

    var_2 = 'git add .'

    var_3 = 'fatal: pathspec \'Life\' did not match any files\nUse -f if you really want to add them.\n'

    var_4 = 'git add .'

    var_5 = 'fatal: pathspec \'Life\' did not match any files\nUse -f if you really want to add them.\n'

    var_6 = match(var_0, var_1)
    assert(var_6 == False)

    var_7 = match(var_2, var_3)
    assert(var_7 == False)

# Generated at 2022-06-26 05:57:28.289281
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git add foo') == 'git add --force foo'
    assert get_new_command('git add *') == 'git add --force *'

# Generated at 2022-06-26 05:57:30.445083
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(False)
    assert not get_new_command(True)


# Generated at 2022-06-26 05:57:39.896710
# Unit test for function match
def test_match():
    assert match('git add')
    assert match('git add ')
    assert match('git add file')
    assert match('git add file ')
    assert match('git add .')
    assert match('git add . ')
    assert match('git add *')
    assert match('git add * ')
    assert match('git add -A')
    assert match('git add -A ')
    assert not match('git add --force')
    assert not match('git add --force ')
    assert not match('git add --force file')
    assert not match('git add --force file ')
    assert not match('git add --force .')
    assert not match('git add --force . ')
    assert not match('git add --force *')
    assert not match('git add --force * ')

# Generated at 2022-06-26 05:57:41.197557
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git add .') == 'git add --force .'

# Generated at 2022-06-26 05:57:47.001866
# Unit test for function get_new_command
def test_get_new_command():
    command = 'git add -A'

# Generated at 2022-06-26 05:57:47.728558
# Unit test for function get_new_command
def test_get_new_command():
    assert True == True

# Generated at 2022-06-26 05:57:50.334621
# Unit test for function match
def test_match():
    assert git_support(match, 'git add -f')
    assert git_support(match, 'git add -f')
    assert git_support(match, 'git add -f')

# Generated at 2022-06-26 05:57:51.581557
# Unit test for function match
def test_match():
    test_case_0()

# Generated at 2022-06-26 05:57:52.736767
# Unit test for function match
def test_match():
    bool_0 = True
    var_0 = match(bool_0)
    assert var_0 == bool_0

# Generated at 2022-06-26 05:57:54.226809
# Unit test for function match
def test_match():
    var_0 = match('git add ')


# Generated at 2022-06-26 05:57:55.491415
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(True) is not None


# Generated at 2022-06-26 05:57:59.955287
# Unit test for function get_new_command
def test_get_new_command():
    check_function(get_new_command, [], get_new_command)
    check_function(get_new_command, [], get_new_command)
    check_function(get_new_command, [], get_new_command)
    check_function(get_new_command, [], get_new_command)
    check_function(get_new_command, [], get_new_command)


# Generated at 2022-06-26 05:58:06.816167
# Unit test for function match
def test_match():
    from thefuck.types import Command
    assert match(Command('git add',
                         'fatal: pathspec \'non-existent-file\' did not match any files',
                         '/bin/git'))
    assert not match(Command('git add', '', '/bin/git'))


# Generated at 2022-06-26 05:58:12.611005
# Unit test for function match
def test_match():
    output_1 = r"""
The following paths are ignored by one of your .gitignore files:
dummy.java
Use -f if you really want to add them.
fatal: no files added
"""
    output_2 = r"""
The following paths are ignored by one of your .gitignore files:
dummy.java
Use -f if you really want to add them.
"""
    output_3 = r"""
fatal: pathspec 'dummy.java' did not match any files
"""
    output_4 = r"""
error: pathspec 'dummy.java' did not match any files
"""
    output_5 = r"""
error: pathspec 'dummy.java' did not match any files
Use -f if you really want to add them.
"""

# Generated at 2022-06-26 05:58:15.433912
# Unit test for function match
def test_match():
    assert match(Command('add', 'fatal: pathspec \'a\' did not match any files'))
    assert not match(Command('add', ''))
    assert not match(Command('git add', ''))


# Generated at 2022-06-26 05:58:19.259195
# Unit test for function get_new_command
def test_get_new_command():
    command_input = 'git add file1 file2 file3'
    command_output = 'Use -f if you really want to add them.'
    command = Command(command_input, command_output)
    new_command = get_new_command(command)
    assert new_command == 'git add --force file1 file2 file3'

# Generated at 2022-06-26 05:58:25.675105
# Unit test for function match
def test_match():
    assert (match(Command('git add', '', 'The following paths are ignored by one of your .gitignore files:\n\
    .idea\n\
Use -f if you really want to add them.')) == True)
    assert (match(Command('git add .idea', '', 'The following paths are ignored by one of your .gitignore files:\n\
    .idea/\n\
Use -f if you really want to add them.')) == True)
    assert match(Command('git add', '', 'fatal: pathspec \'file\' did not match any files')) == False



# Generated at 2022-06-26 05:58:28.516205
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git add folder', 'The following paths are ignored by one of your .gitignore files:')
    assert get_new_command(command) == 'git add --force folder'

# Generated at 2022-06-26 05:58:30.693430
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git add', 'Use -f if you really want to add them.')) \
        == 'git add --force'

# Generated at 2022-06-26 05:58:38.629709
# Unit test for function match
def test_match():

    assert match(Command('git add .',
                     stderr='fatal: LF would be replaced by CRLF in package.json.\n'
                            'The file will have its original line endings in your working directory.\n'
                            'Use -f if you really want to add them.'))
    assert not match(Command('git commit',
                          stderr='fatal: LF would be replaced by CRLF in package.json.\n'
                                 'The file will have its original line endings in your working directory.\n'
                                 'Use -f if you really want to add them.'))

# Generated at 2022-06-26 05:58:41.837168
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.git_staged_but_not_updated import get_new_command

# Generated at 2022-06-26 05:58:44.784446
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git add', '', stderr="fatal: Pathspec 'a' is in submodule 'b'\nUse -f if you really want to add them.")) == 'git add --force'

# Generated at 2022-06-26 05:58:55.013146
# Unit test for function match
def test_match():
    assert match(Command('git add a b', '', 'Use -f if you really want to add them\n'))
    assert match(Command('git add -A', '', 'Use -f if you really want to add them\n'))
    assert match(Command('git add .', '', 'Use -f if you really want to add them\n'))
    assert not match(Command('', '', ''))
    assert not match(Command('ls', '', 'Use -f if you really want to add them\n'))
    assert not match(Command('git add a b', '', 'No such file or directory\n'))


# Generated at 2022-06-26 05:58:56.144472
# Unit test for function match
def test_match():
    assert_true(match(Command('git add .', '')))


# Generated at 2022-06-26 05:59:01.180123
# Unit test for function match
def test_match():
    assert match(Command('git add file', 'error: "file" has other changes staged'))
    assert not match(Command('git add file', ''))



# Generated at 2022-06-26 05:59:05.261711
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git add test.py',
                      'The following paths are ignored by one of your .gitignore files:\n'
                      'test.py\nUse -f if you really want to add them.\nfatal: no files added')
    assert get_new_command(command) == 'git add --force test.py'

test_get_new_command()

# Generated at 2022-06-26 05:59:08.187295
# Unit test for function match
def test_match():
    assert match(Command("git add foo", "", "fatal: LF would be replaced by CRLF in foo\n"
                                           "Use -f if you really want to add them."))



# Generated at 2022-06-26 05:59:15.570931
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git add file.txt', '')
    assert get_new_command(command) == 'git add --force file.txt'

    command = Command('git add --force file.txt', '')
    assert get_new_command(command) == 'git add --force file.txt'

    command = Command('git add .', '')
    assert get_new_command(command) == 'git add --force .'

    command = Command('git add', '')
    assert get_new_command(command) == 'git add --force'

# Generated at 2022-06-26 05:59:21.321683
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script='git add',
                      output = 'fatal: The following paths are ignored by one of your .gitignore files:\n.direnv\nUse -f if you really want to add them.\nfatal: no files added\n')
    assert get_new_command(command) == 'git add --force'



# Generated at 2022-06-26 05:59:24.469745
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("git add file.txt", "fatal: LF would be replaced by CRLF in file.txt.\nUse -f if you really want to add them.")
    assert get_new_command(command) == 'git add --force file.txt'

# Generated at 2022-06-26 05:59:26.535014
# Unit test for function match
def test_match():
    assert match(Command('git add'))


# Generated at 2022-06-26 05:59:28.379327
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git add', '')) == 'git add --force'

# Generated at 2022-06-26 05:59:37.444133
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git add .', 'The following paths are ignored by one of your .gitignore files:\nfoo\nUse -f if you really want to add them.')
    assert get_new_command(command) == "git add . --force"

# Generated at 2022-06-26 05:59:42.620013
# Unit test for function match
def test_match():
    assert not match(Command('git add foo',
               ''))
    assert match(Command('git add foo',
               'fatal: pathspec \'foo\' did not match any files'))

# Generated at 2022-06-26 05:59:46.295837
# Unit test for function match
def test_match():
    match1 = match(Command('git reset', 'fatal: pathspec \'reset\' did not match any files'))
    assert match1 == False
    match2 = match(Command('git add test.txt', 'error: pathspec \'test.txt\' did not match any files\nUse -f if you really want to add them.'))
    assert match2 == True

# Generated at 2022-06-26 05:59:50.148612
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git add .', '') == 'git add . --force'
    assert get_new_command('git add file', '') == 'git add file --force'

# Generated at 2022-06-26 05:59:59.294466
# Unit test for function match

# Generated at 2022-06-26 06:00:01.206432
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git add --all') == 'git add --all --force'

# Generated at 2022-06-26 06:00:05.196809
# Unit test for function match
def test_match():
    assert match(Command('git add',
                         'The following paths are ignored by one of your .gitignore files:\nfile\nUse -f if you really want to add them.'))


# Generated at 2022-06-26 06:00:10.450226
# Unit test for function match
def test_match():
    assert match(Command('git add .', 'error: The following untracked working '
                                    'tree files would be overwritten by merge:'
                                    '\nREADME.md\nUse -f if you really '
                                    'want to add them.'))
    assert not match(Command('git add .', 'error: The following untracked '
                                         'working tree files would be '
                                         'overwritten by merge:\nREADME.md\n'
                                         'Use -f if you really want to add '
                                         'them.\n'))
    assert not match(Command('git commit -am "first commit"', '', ''))


# Generated at 2022-06-26 06:00:14.444021
# Unit test for function match
def test_match():
    assert match(Command('git add', '', 'error: The following untracked working tree files would be overwritten by merge:\n'
                         '        .gitignore\n'
                         'Please move or remove them before you can merge.'))
    assert not match(Command('git add .', '', ''))


# Generated at 2022-06-26 06:00:19.687660
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git add src/')
    assert get_new_command(command) == 'git add --force src/'

    command = Command('git add -p')
    assert get_new_command(command) == 'git add --force -p'

    command = Command('git add -u')
    assert get_new_command(command) == 'git add --force -u'

# Generated at 2022-06-26 06:00:36.287830
# Unit test for function match
def test_match():
    assert match(Command('git add file', '', 'fatal: pathspec \'file\''
                         ' did not match any files'))
    assert match(Command('git add', '', 'fatal: pathspec \''
                         ' did not match any files'))
    assert not match(Command('git add', '', ''))

# Generated at 2022-06-26 06:00:40.024286
# Unit test for function get_new_command
def test_get_new_command():
    """Test that get_new_command works properly."""
    command = Command('git add .', "fatal: Path 'file' is in submodule './sm'"
        "Use '--force' if you really want to add it.")
    assert get_new_command(command) == 'git add --force .'

# Generated at 2022-06-26 06:00:44.884228
# Unit test for function get_new_command
def test_get_new_command():
    command_script_parts = ['git', 'add']
    command_output = 'Use -f if you really want to add them.'
    command_script = ' '.join(command_script_parts)
    command = Command(script=command_script,
                      output=command_output,
                      script_parts=command_script_parts)
    assert ("git add --force" in get_new_command(command))

# Generated at 2022-06-26 06:00:47.254061
# Unit test for function get_new_command
def test_get_new_command():
    command = 'git add'
    assert get_new_command(command) == 'git add --force'

# Generated at 2022-06-26 06:00:48.911922
# Unit test for function match
def test_match():
    assert match(CliCommand('git add .'))
    assert not match(CliCommand('git add'))



# Generated at 2022-06-26 06:00:52.425876
# Unit test for function get_new_command
def test_get_new_command():
    """
    Tests for function get_new_command()
    """
    # function get_new_command should return string
    assert isinstance(get_new_command("git add .").script, str)

    # function get_new_command should return string with --force argument
    assert("--force" in get_new_command("git add .").script)



# Generated at 2022-06-26 06:00:59.194774
# Unit test for function match
def test_match():
    assert match(Command('git add', stderr='error: The following untracked \
working tree files would be overwritten by merge:\n'
                                            '	bin/a.out\n'
                                            '	src/hello.c\n'
                                            'Please move or remove them \
before you can merge.\n'
                                            'Aborting'))
    assert not match(Command('git add'))
    assert not match(Command('ls'))


# Generated at 2022-06-26 06:01:02.266281
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command([u'git', u'add', u'Test.py']) == [u'git', u'add', u'--force', u'Test.py']


# Generated at 2022-06-26 06:01:10.215754
# Unit test for function match
def test_match():
    assert match(Command('git add test',
                         stderr='Aborting\nfatal: pathspec \'test\' '
                                'did not match any files\nUse -f if you '
                                'really want to add them.'))
    assert not match(Command('git add test',
                             stderr='fatal: pathspec \'test\' did not '
                                    'match any files\nUse -f if you really '
                                    'want to add them.'))
    assert not match(Command('ls', stderr='fatal: pathspec \'test\' '
                                          'did not match any files\nUse -f '
                                          'if you really want to add them.'))



# Generated at 2022-06-26 06:01:16.256453
# Unit test for function get_new_command
def test_get_new_command():
    assert ("git add .", "git add --force .") == get_new_command(Command('git add .',
                                                    'fatal: Pathspec '.replace(' ', '') +
                                                    '\'.\' is in submodule '.replace(' ', '') +
                                                    '\'test\''.replace(' ', '') +
                                                    ' Use --ignore-submodules if you really want to add them.'.replace(' ', '')))

# Generated at 2022-06-26 06:01:44.816372
# Unit test for function match
def test_match():
    assert match(Command('git add file0 file1', '', 'fatal: pathspec \'file1\' did not match any files', '', 1, 1))


# Generated at 2022-06-26 06:01:45.979459
# Unit test for function get_new_command
def test_get_new_command():
  assert get_new_command("git add") == "git add --force"

# Generated at 2022-06-26 06:01:49.031134
# Unit test for function match
def test_match():
    assert match(Command('git add no_such_file_exist',
        'The following paths are ignored by one of your .gitignore files:',
        'Use -f if you really want to add them.'))


# Generated at 2022-06-26 06:01:53.498171
# Unit test for function match
def test_match():
    assert match(Command('git add .',
                         'fatal: cannot add files to staging area '
                         '(did you forget to "git add"?)'))
    assert match(Command('git add .',
                         'The following paths are ignored by one of your .gitignore files:'
                         '\nfoo'
                         '\nUse -f if you really want to add them.'))
    assert not match(Command('git add .', ''))
    assert not match(Command('git commit', ''))


# Generated at 2022-06-26 06:01:54.457863
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command.from_string("git add")) == "git add --force"

# Generated at 2022-06-26 06:01:57.544053
# Unit test for function match
def test_match():
    assert match(Command('git ad README.md', 
                         'The following paths are ignored by one of your .gitignore files:\nREADME.md\nUse -f if you really want to add them.\nfatal: no files added\n',
                          9))
    assert not match(Command('git add README.md',
                             'fatal: pathspec \'README.md\' did not match any files\n', 
                             9))


# Generated at 2022-06-26 06:01:58.781812
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("git add ")
    assert get_new_command(command) == "git add --force "

# Generated at 2022-06-26 06:02:01.886985
# Unit test for function match
def test_match():
    assert match(Command(script='git add mail', output='Use -f if you really want to add them.'))
    assert not match(Command(script='git add mail', output='Use -f if you really was to add them.'))


# Generated at 2022-06-26 06:02:04.335230
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git add', 'The following paths are ignored by one of your .gitignore files:', 'Use -f if you really want to add them.')) == 'git add --force'

# Generated at 2022-06-26 06:02:08.146124
# Unit test for function match
def test_match():
    assert match(Command('git add .',
                         'fatal: The following paths are ignored by one of your .gitignore files:\nsrc/\nUse -f if you really want to add them.'))


# Generated at 2022-06-26 06:03:11.521790
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command('git add -i') == 'git add --force -i')

# Generated at 2022-06-26 06:03:14.541206
# Unit test for function match
def test_match():
    command = Command('git add unsafe_file', 'fatal: \'unsafe_file\' is outside repository', '')
    assert match(command)

    command = Command('git add safe_file', '', '')
    assert not match(command)



# Generated at 2022-06-26 06:03:24.143513
# Unit test for function match

# Generated at 2022-06-26 06:03:27.355225
# Unit test for function match
def test_match():
    assert match(script="git add .", output="fatal: paths with -a does not make sense.")
    assert not match(script="git add .", output="")
    assert not match(script="", output="")



# Generated at 2022-06-26 06:03:31.177309
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git add .', 'The following paths are ignored by one of your .gitignore files:\nnode_modules\nUse -f if you really want to add them.\nfatal: no files added')
    assert get_new_command(command) == 'git add --force .'

# Generated at 2022-06-26 06:03:34.631019
# Unit test for function match
def test_match():
    assert match(Command('git add',
                         stderr='error: The following paths are ignored by one of your .gitignore files'))
    assert not match(Command('git branch',
                             stderr='error: The following paths are ignored by one of your .gitignore files'))

# Generated at 2022-06-26 06:03:37.551284
# Unit test for function match
def test_match():
    assert match(Command("git add -A", "fatal: pathspec '.' did not match any files\nUse -f if you really want to add them."))
    assert not match(Command("git add -A", ""))
    

# Generated at 2022-06-26 06:03:41.518195
# Unit test for function match
def test_match():
    assert match(Command('git add file1',
                         'fatal: pathspec \'file1\' did not match any\
files\nUse -f if you really want to add them.'))
    assert not match(Command('git add file1',
                             'fatal: pathspec \'bfile1\' did not match any\
files\nUse -f if you really want to add them.'))
    assert match(Command('git add file1', 'file1: needs merge\nUse -f if you really want to add them.'))


# Generated at 2022-06-26 06:03:46.035507
# Unit test for function match
def test_match():
    # Test case 1: no 'Use -f if you really want to add them.' in command output
    assert not match(Command('git add', ''))

    # Test case 2: 'Use -f if you really want to add them.' in command output
    assert match(Command('git add', 'Use -f if you really want to add them.'))


# Generated at 2022-06-26 06:03:51.827634
# Unit test for function match
def test_match():
    assert match(Command('git add',
                         stderr='The following paths are ignored by one of your .gitignore files:\npath/to/files\nUse -f if you really want to add them.'))
    assert not match(Command())
    assert not match(Command('git add',
                             stderr='The following paths are ignored by one of your .gitignore files:\npath/to/files\nUse -f if you really want to add them.'))


# Generated at 2022-06-26 06:06:16.625849
# Unit test for function match

# Generated at 2022-06-26 06:06:19.847985
# Unit test for function match
def test_match():
    assert match(Command('git add', 'fatal: pathspec * did not match any files'))
    assert not match(Command('git add', ''))

# Generated at 2022-06-26 06:06:23.442974
# Unit test for function match
def test_match():
    assert match(Command('git add .', output='Use -f if you really want to add them.')) is True


# Generated at 2022-06-26 06:06:27.663576
# Unit test for function match
def test_match():
	assert match(Command('git add some_file', '', '', 1, 2))
	assert not match(Command('git add', '', '', 1, 2))
	assert not match(Command('git add some_file', '', 'Use -f if you really want to add them.', 1, 2))
	assert not match(Command('git add some_file', '', '', 1, 2))

# Generated at 2022-06-26 06:06:31.152834
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git add', '', 'Use -f if you really want to add them.')) == 'git add --force'

# Generated at 2022-06-26 06:06:36.933197
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git add concatenated_command', 'fatal: Path \'concatenated_command\' is in the .gitignore file.\n'\
                      'Use -f if you really want to add them.')
    assert get_new_command(command) == 'git add --force concatenated_command'

# Generated at 2022-06-26 06:06:40.308378
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git add something', 'Use -f if you really want to add them.')) == 'git add --force something'

# Generated at 2022-06-26 06:06:43.706942
# Unit test for function match
def test_match():
    assert match(Command('git add foobar',
                         'Use -f if you really want to add them.'))



# Generated at 2022-06-26 06:06:50.628435
# Unit test for function match
def test_match():
    # returns True when stderr message has "add --force" in it
    assert (match(Command('git add .',
        err='warning: The following paths are ignored by one of your .gitignore files:\npath/to/file\nUse -f if you really want to add them.',
        ))
        == True)
    # returns False when stderr message does not have "add --force" in it
    assert (match(Command('git add .',
        err='warning: The following paths are ignored by one of your .gitignore files:\npath/to/file\n',
        ))
        == False)
