

# Generated at 2022-06-22 01:34:00.344231
# Unit test for function match
def test_match():
    assert match(Command('git add', '$ git add file\n'
                                      'The following paths are ignored by one of your .gitignore files:\n'
                                      'file\n'
                                      'Use -f if you really want to add them.\n'))


# Generated at 2022-06-22 01:34:08.504430
# Unit test for function match
def test_match():
    command = Command('git add .')
    assert match(command) is True
    command = Command('git add')
    assert match(command) is False
    command = Command('git remote add origin')
    assert match(command) is False
    command = Command('git remote add .')
    assert match(command) is False
    command = Command('git remote add .', 'error: The following untracked working tree files would be overwritten by merge:\n\tnew.txt\nPlease move or remove them before you can merge.')
    assert match(command) is True


# Generated at 2022-06-22 01:34:11.713100
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git add .')) == 'git add --force .', 'git add --force .'

# Generated at 2022-06-22 01:34:17.721395
# Unit test for function get_new_command
def test_get_new_command():
    assert match(Command('git add file.txt',
        'The following paths are ignored by one of your .gitignore files:\nfile.txt\nUse -f if you really want to add them.'))
    assert get_new_command(Command('git add file.txt',
        'The following paths are ignored by one of your .gitignore files:\nfile.txt\nUse -f if you really want to add them.')) == 'git add --force file.txt'

# Generated at 2022-06-22 01:34:21.163466
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git add', 'error: The following untracked working tree files would be overwritten by merge: Use -f if you really want to add them.')) == 'git add --force'


# Generated at 2022-06-22 01:34:29.988485
# Unit test for function match
def test_match():
    # type: () -> None
    assert match(Command('git add',
                         stderr='fatal: Unable to create '.split()))
    assert match(Command('git add foo.py',
                         stderr='fatal: unable to stat '.split()))
    assert match(Command('git add bar/',
                         stderr='fatal: Not a git repository '.split()))
    assert match(Command('git add foo.py bar.py',
                         stderr='error: pathspec '.split()))
    assert not match(Command('git add', stderr='fatal: pathspec '.split()))


# Generated at 2022-06-22 01:34:33.011014
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script='git add -m "message"', output='error')
    assert get_new_command(command) == 'git add --force -m "message"'

# Generated at 2022-06-22 01:34:44.055592
# Unit test for function match
def test_match():
    assert match(Command('git add', 'The following paths are ignored by one of your .gitignore files:\nUse -f if you really want to add them.'))
    assert match(Command('git add -f', 'The following paths are ignored by one of your .gitignore files:\nUse -f if you really want to add them.'))
    assert not match(Command('git add', ' '))
    assert not match(Command('git add', 'The following paths are ignored by one of your .gitignore files:'))
    assert not match(Command('git add', 'No such file or directory'))
    assert match(Command('git add', 'The following paths are ignored by one of your .gitignore files:\nUse -f if you really want to add them.'))

# Generated at 2022-06-22 01:34:46.314256
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("git add -N &-A") == "git add --force -N &-A"

# Generated at 2022-06-22 01:34:49.603965
# Unit test for function match
def test_match():
    command = Command('git add "*"')
    assert match(command)
    assert not match(Command('git notmatch', "'*'", "Use -f if you really want to add them."))



# Generated at 2022-06-22 01:34:54.803788
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git add') == 'git add --force'
    assert get_new_command('git add .') == 'git add --force .'
    assert get_new_command('git add -f .') == 'git add -f .'

# Generated at 2022-06-22 01:34:57.913139
# Unit test for function get_new_command
def test_get_new_command():
    assert "git add --force" == get_new_command(
        Command('git add', 'Use -f if you really want to add them.'))



# Generated at 2022-06-22 01:35:00.733608
# Unit test for function get_new_command
def test_get_new_command():
    assert 'add --force' == get_new_command(Command('git add', '', 'Use -f if you really want to add them.'))

# Generated at 2022-06-22 01:35:05.153604
# Unit test for function get_new_command
def test_get_new_command():
	old_command = Command("fuck git status", "git add./js-unit-test.js\nUse -f if you really want to add them.\n")
	new_command = get_new_command(old_command)
	assert new_command == "git add --force./js-unit-test.js"

# Generated at 2022-06-22 01:35:11.040901
# Unit test for function match
def test_match():
    command = Command('git add dir1', output='The following paths are ignored by one of your .gitignore files:',
                      stderr='The following paths are ignored by one of your .gitignore files:\n'
                             'dir1/dir2/dir3\nUse -f if you really want to add them.\nfatal: no files added\n')
    assert match(command)


# Generated at 2022-06-22 01:35:22.627633
# Unit test for function match
def test_match():
    assert match(Command('git add untracked.py',
                         'The following untracked working tree files would be overwritten by checkout:\n'
                         '\t.gitignore\n'
                         '\tLICENSE.md\n'
                         '\ttest.py\n'
                         'Please move or remove them before you can switch branches.\n'
                         'Aborting')) == True
    assert match(Command('git add .', 'The following untracked working tree files would be overwritten by checkout:\n'
                         '\t.gitignore\n'
                         '\tLICENSE.md\n'
                         '\ttest.py\n'
                         'Please move or remove them before you can switch branches.\n'
                         'Aborting')) == True

# Generated at 2022-06-22 01:35:24.968597
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git add -A', '', '/', '', '', '')) == 'git add --force -A'

# Generated at 2022-06-22 01:35:26.818314
# Unit test for function get_new_command
def test_get_new_command():
    get_new_command(Command('/bin/false', 'git add .'))

# Generated at 2022-06-22 01:35:31.506616
# Unit test for function match
def test_match():
    assert match(Command('git add foo', 'fatal: Path \'foo\' is in the way', ''))
    assert match(Command('git add foo',
        'fatal: Path \'foo\' is in the way', '')) is False
    assert match(Command('git add', '', '')) is False


# Generated at 2022-06-22 01:35:34.827006
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git add .', 'Use -f if you really want to add them.')
    assert get_new_command(command) == 'git add --force .'

# Generated at 2022-06-22 01:35:49.135969
# Unit test for function get_new_command
def test_get_new_command():
    # Test when the script is 'git add'
    testcommand1 = Command('git add', 'The following paths are ignored by one of your .gitignore files:\n' \
                           'test/test.py\n' \
                           'Use -f if you really want to add them.\n' \
                           'fatal: no files added\n')
    assert get_new_command(testcommand1) == 'git add --force'
    # Test when the script is 'git add test/test.py'

# Generated at 2022-06-22 01:35:58.022855
# Unit test for function match
def test_match():
    assert match(Command('git add', "warning: LF will be replaced by CRLF in ./1.txt.\r\nThe file will have its original line endings in your working directory.\r\nwarning: LF will be replaced by CRLF in ./2.txt.\r\nThe file will have its original line endings in your working directory.\r\nUse -f if you really want to add them.", '', 0, ''))
    assert match(Command('git add', 'fatal: pathspec \'not-exist-file.txt\' did not match any files', '', 0, '')) is None


# Generated at 2022-06-22 01:36:01.816129
# Unit test for function match
def test_match():
    e1 = ['git', 'add', 'fileA', 'fileB', 'fileC']
    e2 = "The following paths are ignored by one of your .gitignore files:\nfileB\nUse -f if you really want to add them."
    c1 = Command(e1, e2)

    assert match(c1)


# Generated at 2022-06-22 01:36:06.169669
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git add .', 
        'The following paths are ignored by one of your .gitignore files:\n'
        'test\nUse -f if you really want to add them.')) == 'git add . --force'

# Generated at 2022-06-22 01:36:11.774637
# Unit test for function get_new_command
def test_get_new_command():
    
    # Get new command
    new_command = get_new_command(Command('git add test', 'Use -f if you really want to add them.'))

    # Check if it is a Command object
    assert isinstance(new_command, Command)

    # Check if command is replaced correctly
    assert new_command.script == 'git add test --force'



# Generated at 2022-06-22 01:36:16.835141
# Unit test for function match
def test_match():
    assert match(Command('', '', ''))
    assert match(Command(script='git add',
                         stdout='error: The following paths are ignored by one of your .gitignore files:',
                         stderr=''))
    assert match(Command('', '', ''))


# Generated at 2022-06-22 01:36:25.438222
# Unit test for function match
def test_match():
# The format of the git command is incorrect
    assert match(Command('git add', "fatal: pathspec 'files.txt' did not match any files\nUse -f if you really want to add them."))
    
# The format of the git command is correct
    assert not match(Command('git add file.txt', "On branch master\nChanges to be committed:\n  (use \"git reset HEAD <file>...\" to unstage)\n\n\tmodified:   file.txt\n"))
    
    # Unit test for function get_new_command

# Generated at 2022-06-22 01:36:29.150026
# Unit test for function match
def test_match():
    assert match(Command('git add test.py',
                         'test.py: needs merge\nUse -f if you really want to add them.'))
    assert not match(Command('git add test.py',
                             'test.py: needs merge\nno'))


# Generated at 2022-06-22 01:36:33.618471
# Unit test for function match
def test_match():
    assert match(Command('git add .',
                     stderr='Use -f if you really want to add them.',))
    assert not match(Command('git add .',
                          stderr='Use --ignore-missing if you really want to add them.',))


# Generated at 2022-06-22 01:36:35.506882
# Unit test for function get_new_command

# Generated at 2022-06-22 01:36:42.946408
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git add')) == 'git add --force'

# Generated at 2022-06-22 01:36:44.590420
# Unit test for function match
def test_match():
    pytest.raises(AssertionError, match)


# Generated at 2022-06-22 01:36:50.861233
# Unit test for function match
def test_match():
    assert match(Command("git add src", "fatal: Not a git repository (or any of the parent directories): .git\n"))
    assert not match(Command("git remote", "fatal: Not a git repository (or any of the parent directories): .git\n"))
    assert match(Command("git add file.py", "fatal: pathspec 'file.py' did not match any files\n"))



# Generated at 2022-06-22 01:36:52.586439
# Unit test for function get_new_command
def test_get_new_command():
	assert get_new_command('')


# Generated at 2022-06-22 01:36:54.034293
# Unit test for function match
def test_match():
    assert match(Command('git add .', "'' is outside repository"))



# Generated at 2022-06-22 01:36:55.105952
# Unit test for function get_new_command
def test_get_new_command():
	assert get_new_command(Command('git add')) == 'git add --force'

# Generated at 2022-06-22 01:37:00.464353
# Unit test for function match
def test_match():
    assert match(Command('git add',
                        'warning: LF will be replaced by CRLF \
in /home/test/.gitconfig.\nThe file will have its original line endings in your working directory.'))
    assert not match(Command('git add', ' '))


# Generated at 2022-06-22 01:37:06.553491
# Unit test for function match
def test_match():
    assert match(Command('git add .', 'fatal: some files do not exist anymore, but still exist in the index. Cannot add them.'))
    assert match(Command('git add -u', 'fatal: some files do not exist anymore, but still exist in the index. Cannot add them.'))
    assert not match(Command('git add', ''))
    assert not match(Command('git add 1', ''))


# Generated at 2022-06-22 01:37:09.336355
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.git_add_force import get_new_command
    # Function get_new_command is tested in the test_prefix.py file.
    # For the moment, this test is useless.

# Generated at 2022-06-22 01:37:15.222482
# Unit test for function match
def test_match():
    assert match(Command('git add file.txt',
                         'The following paths are ignored by one of your .gitignore files:\nfile.txt\nUse -f if you really want to add them.'))
    assert not match(Command('git add file.txt', ''))
    assert not match(Command('ls', ''))



# Generated at 2022-06-22 01:37:25.888374
# Unit test for function get_new_command
def test_get_new_command():
    assert(
        get_new_command(
            Command(
                'git add "Documents and Settings"',
                'fatal: '
                'pathspec \'Documents and Settings\' did not match any files\n'
                'Use -f if you really want to add them.')) ==
        'git add --force "Documents and Settings"'
    )

# Generated at 2022-06-22 01:37:29.684249
# Unit test for function match
def test_match():
    assert match(Command('git add jasdk', 'fatal: Pathspec \'jasdk\' is in submodule \'jasdk\'\nUse --force if you really want to add them.'))


# Generated at 2022-06-22 01:37:34.362207
# Unit test for function match
def test_match():
    assert match(Command('git add .',
                         'The following paths are ignored by one of your .gitignore files:\n[List of files]\nUse -f '
                         'if you really want to add them.'))
    assert not match(Command('git add .', ''))



# Generated at 2022-06-22 01:37:38.987310
# Unit test for function match
def test_match():
    command = Command("git add --all app/controllers/index.rb", "error: The following untracked working tree files would be overwritten by merge:\n\tapp/controllers/index.rb\nPlease move or remove them before you can merge.")
    assert match(command)


# Generated at 2022-06-22 01:37:44.236338
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git add .',
                                   'error: The following untracked working tree files would be overwritten by merge:\n'
                                   '\tREADME.md\n'
                                   '\tLICENSE\n'
                                   '\n'
                                   'Please move or remove them before you merge.\n'
                                   'Aborting')) == 'git add --force .'

# Generated at 2022-06-22 01:37:49.335058
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git add .', r'The following paths are ignored by one of your .gitignore files:\n.gitignore\nUse -f if you really want to add them.')
    assert get_new_command(command) == "git add --force ."

# Generated at 2022-06-22 01:37:54.086040
# Unit test for function get_new_command
def test_get_new_command():
    command = 'git add -A'
    output = 'The following paths are ignored by one of your .gitignore files: \nUse -f if you really want to add them.'
    command_obj = Command(command,output)
    assert get_new_command(command_obj) == 'git add --force -A'

# Generated at 2022-06-22 01:37:58.873340
# Unit test for function match
def test_match():
    assert match(Command('git add file1.txt', ''))
    assert not match(Command('git add --force file1.txt', ''))
    assert not match(Command('git commit -m "Add file1.txt"', ''))
    assert not match(Command('svn add file1.txt', ''))
    assert not match(Command('ls file1.txt', ''))


# Generated at 2022-06-22 01:38:11.185593
# Unit test for function match
def test_match():
    # 1st case, command with 'add' and a message in the output
    assert match(Command('git add this/is/a/test',
                         output='The following paths are ignored by one of '
                                'your .gitignore files:\n'
                                'this/is/a/test\n'
                                'Use -f if you really want to add them.'))

    # 2nd case, command with 'add' and a different output
    assert not match(Command('git add this/is/a/test',
                             output='The following paths are ignored by one of '
                                    'your .gitignore files:\n'
                                    'this/is/a/test\n'))

    # 3rd case, command without 'add' in it

# Generated at 2022-06-22 01:38:13.439227
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git add .', 'The following paths are ignored by one of your .gitignore files:\nblah\nUse -f if you really want to add them.')
    assert get_new_command(command) == 'git add --force .'


# Generated at 2022-06-22 01:38:30.056837
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script="git add")) == "git add --force"
    assert get_new_command(Command(script="git add .")) == "git add --force ."
    assert get_new_command(Command(script="git add --force .")) == "git add --force ."

# Generated at 2022-06-22 01:38:33.668134
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git add .', 'fatal: Pathspec \'...\' is in submodule \'...\'\nUse -f if you really want to add them.')
    assert get_new_command(command) == 'git add --force .'

# Generated at 2022-06-22 01:38:37.931945
# Unit test for function get_new_command
def test_get_new_command():
    script = "git add ."
    output = "The following paths are ignored by one of your .gitignore files:\n\
.classpath\n\
Use -f if you really want to add them."

    assert get_new_command(Command(script, output)) \
            == "git add --force ."


# Generated at 2022-06-22 01:38:42.560747
# Unit test for function match
def test_match():
    assert match(Command('git add .', '', '', 1, None), None)
    assert not match(Command('', '', '', 1, None), None)
    assert not match(Command('git add .', '', '', 1, None), None)

# Generated at 2022-06-22 01:38:45.751523
# Unit test for function match
def test_match():
    assert match(Command('git add foo.cpp',
                         'fatal: Pathspec \'foo.cpp\' is in submodule \'src/foo.cpp\'',
                         '', 1))


# Generated at 2022-06-22 01:38:49.426049
# Unit test for function match
def test_match():
    assert match(Command('git add *.js',
                         'fatal: Pathspec \'*.js\' is in submodule \'foo\'',
                         ''))
    assert not match(Command('git add .', '', ''))


# Generated at 2022-06-22 01:38:53.894769
# Unit test for function match
def test_match():
    assert match(Command('git add .', 'warning: adding embedded git repository: .git\nUse -f if you really want to add them.'))
    assert not match(Command('git add .', ''))
    assert not match(Command('git commit -m message', ''))


# Generated at 2022-06-22 01:39:02.745193
# Unit test for function match
def test_match():
    assert match(Command("git add 5.py 6.py", "error: The following untracked"
                         " working tree files would be overwritten by merge:\n"
                         "        x.py\n"
                         "Please move or remove them before you can merge."
                         "\n\nAborting"))
    assert not match(Command("git add", "error: The following untracked"
                             " working tree files would be overwritten by merge:\n"
                         "        x.py\n"
                         "Please move or remove them before you can merge."
                         "\n\nAborting"))


# Generated at 2022-06-22 01:39:08.095587
# Unit test for function match
def test_match():
	assert match(Command('git add -A',
						 'The following paths are ignored by one of your .gitignore files:\n'
						 'src\n'
						 '\n'
						 'Use -f if you really want to add them.\n'
						 'fatal: no files added'))


# Generated at 2022-06-22 01:39:12.630623
# Unit test for function match
def test_match():
    assert match(Command('git add newFile', 'Use -f if you really want to add them.'))
    assert match(Command('git push', '')) == False
    assert match(Command('git add .', '')) == False


# Generated at 2022-06-22 01:39:40.901468
# Unit test for function match
def test_match():
    assert match(Command('git add .',
                         'The following paths are ignored by one of your .gitignore files:\nUse -f if you really want to add them.\n'))
    assert not match(Command('git add .',
                             'The following paths are ignored by one of your .gitignore files:\n'))
    assert not match(Command('ls',
                             'The following paths are ignored by one of your .gitignore files:\nUse -f if you really want to add them.\n'))


# Generated at 2022-06-22 01:39:43.638870
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git add -A', 'Use -f if you really want to add them.')
    assert get_new_command(command) == "git add -A --force"

# Generated at 2022-06-22 01:39:50.306394
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git add', "fatal: pathspec '__pycache__' did not match any files\n"
        "Use -f if you really want to add them.")) == 'git add --force'
    assert get_new_command(Command('git add',
        "fatal: pathspec 'foo' did not match any files\n"
        "Use -f if you really want to add them.")) == 'git add --force foo'

# Generated at 2022-06-22 01:39:52.888826
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("git add --a-trash-file") == "git add --a-trash-file --force"

# Generated at 2022-06-22 01:39:58.582356
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git add file', '')) == 'git add --force file'
    assert get_new_command(Command('git add .', '')) == 'git add --force .'
    assert get_new_command(Command('git add', '')) == 'git add --force'


# Generated at 2022-06-22 01:40:03.207160
# Unit test for function match
def test_match():
    assert match(Command('git add', ''))
    assert match(Command('git add',
                         'Use -f if you really want to add them.'))
    assert not match(Command('git add', 'foo'))


# Generated at 2022-06-22 01:40:05.719569
# Unit test for function match
def test_match():
    assert match(Command(script='git add .', output='Use -f if you really want to add them.'))
    assert not match(Command(script='git rm .'))



# Generated at 2022-06-22 01:40:12.967769
# Unit test for function match
def test_match():
    test_string = ["git add .", "git add -A"]
    # Check the first line of the output from git add --help
    test_output = "The following paths are ignored by one of your .gitignore files:\n"
    test_output += "Use -f if you really want to add them.\n"
    # Check if the match is successful.
    for item in test_string:
        assert match(Command(item, test_output)) == True



# Generated at 2022-06-22 01:40:17.522563
# Unit test for function match
def test_match():
	assert (match(Command('git add test', 'test: will be added as an untracked file\
			\nUse -f if you really want to add them.')))
	assert not (match(Command('git add test', 'test: will be added as an untracked file')))

# Generated at 2022-06-22 01:40:18.823342
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('')

# Generated at 2022-06-22 01:41:15.520057
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git add -A', 'The following untracked working tree files would be overwritten by merge:\n\tfile\nPlease move or remove them before you can merge.\nAborting')
    assert get_new_command(command) == 'git add --force -A'

# Generated at 2022-06-22 01:41:17.199672
# Unit test for function get_new_command
def test_get_new_command():
    commandLine = "git add ."
    assert get_new_command(commandLine) == "git add --force ."

# Generated at 2022-06-22 01:41:19.584748
# Unit test for function match
def test_match():
    assert match(Command('git add',
                         "error: The following untracked working tree files would be overwritten by merge:\n"))
    assert not match(Command('git add', 'error'))

# Generated at 2022-06-22 01:41:22.696465
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git add foo/bar', 'Use -f if you really want to add them.')) == 'git add --force foo/bar'


# Generated at 2022-06-22 01:41:31.993101
# Unit test for function match
def test_match():
    command = Command('git add .', 'Aborting'
                      'The following paths are ignored by one of your .gitignore files:\n'
                      'foo\n'
                      'Use -f if you really want to add them.\n'
                      'fatal: no files added', '', 1, 0)
    assert match(command)
    command = Command('git add .', 'Aborting'
                      'The following paths are ignored by one of your .gitignore files:\n'
                      'foo\n'
                      'Use -f if you really want to add them.', '', 1, 0)
    assert not match(command)
    command = Command('git add .', '', '', 1, 0)
    assert not match(command)


# Generated at 2022-06-22 01:41:39.039206
# Unit test for function match
def test_match():
    assert match(Command('git add file',
             'fatal: pathspec \'file\' did not match any files'))
    assert match(Command('git add .',
             'fatal: pathspec \'file\' did not match any files'))
    assert match(Command('git add *',
             'error: pathspec \'.\' did not match any files'))
    assert match(Command('git add file',
             'fatal: pathspec \'file\' did not match any files\n'
             'Use -f if you really want to add them.'))
    assert match(Command('git add .',
             'fatal: pathspec \'file\' did not match any files\n'
             'Use -f if you really want to add them.'))

# Generated at 2022-06-22 01:41:43.199096
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command('git add file.py', 
        'The following paths are ignored by one of your .gitignore files:\nfile.py\nUse -f if you really want to add them.\n',
        '', 1)) == "git add --force file.py")



# Generated at 2022-06-22 01:41:46.935275
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git add .') == 'git add --force .'
    assert get_new_command('git add --verbose .') == 'git add --force --verbose .'

# Generated at 2022-06-22 01:41:52.433622
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command('git add --dry-run',
                                   'error: The following untracked working tree files would be overwritten by merge:\n'
                                   '\tmy_file.txt\n'
                                   'Please move or remove them before you can merge.\n'
                                   'Aborting\n',
                                   '', 1)) == 'git add --force'

enabled_by_default = True

# Generated at 2022-06-22 01:41:57.653878
# Unit test for function match
def test_match():
    assert (match(Command(script ="git add --all",
               output = "fatal: The following untracked working tree files would be overwritten by merge:\n        \"I am file 1.txt\"\n        \"I am file 2.txt\"\nPlease move or remove them before you can merge.\nAborting\n")) == True)
