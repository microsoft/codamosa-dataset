

# Generated at 2022-06-22 01:34:04.033850
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git add .', 'The following paths are ignored by one of your .gitignore files:\nUse -f if you really want to add them.\nfatal: no files added')
    assert get_new_command(command).script == 'git add --force .'

# Generated at 2022-06-22 01:34:07.319919
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git add test.txt', '', 'The following paths are ignored by one of your .gitignore files:\ntest.txt\nUse -f if you really want to add them.')) == 'git add --force test.txt'

# Generated at 2022-06-22 01:34:08.995230
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git add .') == 'git add --force .'

# Generated at 2022-06-22 01:34:11.328452
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command(Command('git add', 'Use -f if you really want to add them.')) == 'git add --force')

# Generated at 2022-06-22 01:34:18.094348
# Unit test for function match
def test_match():
    assert match(Command('git add .',
                         stderr=('fatal: pathspec \'..\' did not match any files\n'
                                 'Use -f if you really want to add them.')))
    assert not match(Command('git add .', stderr=''))

# Generated at 2022-06-22 01:34:20.444927
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git add fdafda', '')) == 'git add --force fdafda'


# Generated at 2022-06-22 01:34:23.102197
# Unit test for function get_new_command
def test_get_new_command():
    assert "git add --force" == get_new_command("git add")
    assert "git add -f ." == get_new_command("git add .")


# Generated at 2022-06-22 01:34:29.334119
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git add file') == 'git add --force file'
    assert get_new_command('git add file1 file2') == 'git add --force file1 file2'
    assert get_new_command('git add') == 'git add --force'
    assert get_new_command('git add --invalid-option') == 'git add --force --invalid-option'

# Generated at 2022-06-22 01:34:40.421954
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git add', 'Use -f if you really want to add them.')).script == 'git add --force'
    assert get_new_command(Command('git add --all', 'Use -f if you really want to add them.')).script == 'git add --force --all'
    assert get_new_command(Command('git add *', 'Use -f if you really want to add them.')).script == 'git add --force *'
    assert get_new_command(Command('git add .', 'Use -f if you really want to add them.')).script == 'git add --force .'
    assert get_new_command(Command('git add .*', 'Use -f if you really want to add them.')).script == 'git add --force .*'


# Generated at 2022-06-22 01:34:46.315524
# Unit test for function match
def test_match():
    assert match(Command('git add file.txt', '', "The following paths are ignored by one of your .gitignore files:\nfile.txt\nUse -f if you really want to add them."))
    assert not match(Command('git add file.txt', '', 'error: pathspec \'file.txt\' did not match any file(s) known to git'))


# Generated at 2022-06-22 01:34:52.005912
# Unit test for function match
def test_match():
    assert match(Command('git add app.css', None, 'The following paths are ignored by one of your .gitignore files: app.css\nUse -f if you really want to add them.'))
    assert not match(Command('git add app.css', None, ''))


# Generated at 2022-06-22 01:34:54.810095
# Unit test for function get_new_command
def test_get_new_command():
    script = 'git add file1 file2'
    new_script = replace_argument(script, 'add', 'add --force')
    assert get_new_command(script)==new_script

# Generated at 2022-06-22 01:34:57.913276
# Unit test for function match
def test_match():
    assert match(Command('git add .', '',
            'fatal: Pathspec \'test.py\' is in submodule \'src/test\''))


# Generated at 2022-06-22 01:35:02.403773
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git add .', 'The following paths are ignored by one of your .gitignore files:\nM .gitignore\n\nUse -f if you really want to add them.\n', '', '')
    assert get_new_command(command) == 'git add --force .'

# Generated at 2022-06-22 01:35:05.512646
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.git_add_force import get_new_command
    command = 'git add'
    new_command = get_new_command(command)
    assert new_command == 'git add --force'

# Generated at 2022-06-22 01:35:14.252309
# Unit test for function match
def test_match():
    assert (match(Command('git add foo bar', 'fatal: pathspec \'foo\' '
                                             'did not match any files'))
            == True)
    assert match(Command('ls foo bar', 'fatal: pathspec \'foo\' '
                                             'did not match any files')) == False
    assert match(Command('git add', 'nothing added to commit but untracked files present (use "git add" to track)')) == False
    assert match(Command('git reset', 'Use -f if you really want to add them.')) == False


# Generated at 2022-06-22 01:35:16.671206
# Unit test for function match
def test_match():
    assert match(Command('git add file',
                      'fatal: pathspec \'file\' did not match any files\n', False))


# Generated at 2022-06-22 01:35:27.795487
# Unit test for function match
def test_match():
    assert(match(Command('git add *',
        'The following paths are ignored by one of your .gitignore files:\n'
        'add *\n'
        'Use -f if you really want to add them.\n'
        'fatal: no files added', '', 2)))
    assert(match(Command(' command with git add',
        'The following paths are ignored by one of your .gitignore files:\n'
        'add *\n'
        'Use -f if you really want to add them.\n'
        'fatal: no files added', '', 2)))

# Generated at 2022-06-22 01:35:30.742880
# Unit test for function match
def test_match():
    assert match(['git add'])
    assert match(['git add', 'some_file'])
    assert not match(['git commit'])


# Generated at 2022-06-22 01:35:36.973235
# Unit test for function match
def test_match():
    assert match(Command('git add stuff',
                         'The following untracked working tree files would be '
                         'overwritten by checkout:\n\n'
                         '\tfile.txt\n\n'
                         'Please move or remove them before you can switch '
                         'branches.\n\n'
                         'Aborting',
                         '', 1, 0))



# Generated at 2022-06-22 01:35:45.346064
# Unit test for function match
def test_match():
    assert match(Command(script='git add *',
                         output='The following paths are ignored by one of your .gitignore files:\n\nall_tests.py\n\nUse -f if you really want to add them.\n'))
    assert not match(Command(script='git add *',
                             output='The following paths are ignored by one of your .gitignore files:\n\nall_tests.py\n'))
    assert not match(Command(script='git add',
                             output='The following paths are ignored by one of your .gitignore files:\n\nall_tests.py\n\nUse -f if you really want to add them.\n'))


# Generated at 2022-06-22 01:35:47.999327
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git add', '', 'The following paths are ignored by one of your .gitignore files:\n...')) == 'git add --force'

# Generated at 2022-06-22 01:35:59.888013
# Unit test for function match
def test_match():
    # Function match() returns True when the command contains "add" and the
    # command output contains "Use -f if you really want to add them."
    # The mock command is "git add"
    command = Command("git add", "", "Use -f if you really want to add them.")
    assert match(command)

    # Function match() returns False when the command contains "add" but the
    # command output does not contain "Use -f if you really want to add them."
    # The mock command is "git add"
    command = Command("git add", "", "")
    assert match(command) is False

    # Function match() returns False when the command does not contain "add"
    # but the command output contains "Use -f if you really want to add them."
    # The mock command is "git status"

# Generated at 2022-06-22 01:36:10.199658
# Unit test for function match
def test_match():
    assert match(Command('git add file',
                         stderr='The following paths are ignored by one of your .gitignore files:\n'
                                'file\n'
                                'Use -f if you really want to add them.\n'))
    assert match(Command('git add .',
                         stderr='The following paths are ignored by one of your .gitignore files:\n'
                                '.\n'
                                'Use -f if you really want to add them.\n'))
    assert not match(Command('git add file',
                             stderr='The following paths are ignored by one of your .gitignore files:\n'
                                    'file\n'))

# Generated at 2022-06-22 01:36:12.349949
# Unit test for function match
def test_match():
    assert match(Command('git add ', 'fatal: Not a git repository (or any of the parent directories): .git\nUse -f if you really want to add them.'))


# Generated at 2022-06-22 01:36:17.823437
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command('git add .',
                                   '')) == 'git add --force .'
    assert get_new_command(Command('git add .',
                                   'Use -f if you really want to add them.')) == 'git add --force .'

# Generated at 2022-06-22 01:36:21.525753
# Unit test for function match
def test_match():
    assert match(Command('git branch foo', '', '', 0, None))
    assert not match(Command('ls', '', '', 0, None))


# Generated at 2022-06-22 01:36:25.282156
# Unit test for function get_new_command
def test_get_new_command():
    newCommand = "git add --force file_or_dir"
    assert get_new_command(Command('git add file_or_dir',
                                   "Use -f if you really want to add them."
                                   " Aborting")) == newCommand

# Generated at 2022-06-22 01:36:28.509251
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git add file1 file2', "fatal: pathspec 'file1' did not match any files\nUse -f if you really want to add them.\n")
    assert get_new_command(command) == 'git add --force file1 file2'

# Generated at 2022-06-22 01:36:32.206852
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git add --test and --force', 'Use -f if you really want to add them.')
    assert get_new_command(command) == 'git add --test and --force --force'

# Generated at 2022-06-22 01:36:38.230031
# Unit test for function match
def test_match():
    assert match(Command('git add file1.py file2.py file3.py', 'error'))
    assert not match(Command('ls', 'message'))
    assert not match(Command('git add', 'error'))
    assert not match(Command('git add file', 'message'))


# Generated at 2022-06-22 01:36:39.526894
# Unit test for function get_new_command
def test_get_new_command():
	assert get_new_command(Command('git add', '')) == 'git add --force'

# Generated at 2022-06-22 01:36:43.333118
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git add',
                                   'fatal: refusing to add unignored file'))\
        == 'git add --force'

# Generated at 2022-06-22 01:36:47.196679
# Unit test for function match
def test_match():
    assert match(Command('git add .',
                         'error: The following paths are ignored by one of '
                         'your .gitignore files:\n'
                         'foo\n'
                         'Use -f if you really want to add them.'))
    assert match(Command('git add .',
                         'error: The following paths are ignored by one of '
                         'your .gitignore files:\n'
                         'foo\n'))
    assert not match(Command('git add .', ''))


# Generated at 2022-06-22 01:36:51.514634
# Unit test for function get_new_command
def test_get_new_command():
    script = 'git add --all .'
    new_script = get_new_command(Command(script, 'Use -f if you really want to add them.'))
    assert script != new_script
    assert new_script == 'git add --force --all .'

# Generated at 2022-06-22 01:36:57.949543
# Unit test for function match
def test_match():
    assert match(Command('git add .',
                        stderr='fatal: Adding (or removing) write access to a'
                               'git-annex special remote repository is not'
                               'supported.\n'
                               'Use -f if you really want to add them.'))
    assert not match(Command('git add .',
                        stderr='fatal: Adding (or removing) write access to a'
                               'git-annex special remote repository is not'
                               'supported.'))
    assert not match(Command('git commit .',
                        stderr='fatal: Adding (or removing) write access to a'
                               'git-annex special remote repository is not'
                               'supported.'))


# Generated at 2022-06-22 01:37:07.033775
# Unit test for function match
def test_match():
    assert match(Command('git add file', 'stderr: The following untracked working tree files would be overwritten by merge:\n  file\nPlease move or remove them before you can merge.'))
    assert not match(Command('git checkout file', 'stderr: The following untracked working tree files would be overwritten by merge:\n  file\nPlease move or remove them before you can merge.'))
    assert not match(Command('git add', 'stderr: The following untracked working tree files would be overwritten by merge:\n  file\nPlease move or remove them before you can merge.'))



# Generated at 2022-06-22 01:37:15.641622
# Unit test for function match
def test_match():
    assert match(Command('git add file1 file2',
                         'file1.pyc file2.pyc',
                         'error: pathspec \'file1.pyc\' did not match any file(s) known to git.\n'
                         'error: pathspec \'file2.pyc\' did not match any file(s) known to git.\n'
                         '\n'
                         'Did you forget to \'git add\'?'))
    assert not match(Command('git add file1 file2',
                             '',
                             ''))
    assert not match(Command('ls', '', ''))


# Generated at 2022-06-22 01:37:26.971581
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git add',
                                   'The following paths are ignored by one of your .gitignore files:\n\
                                   bin/\n\
                                   Use -f if you really want to add them.')) == 'git add --force'
    assert get_new_command(Command('git add',
                                   'The following paths are ignored by one of your .gitignore files:\n\
                                   bin/\n\
                                   Use -f if you really want to add them.')) == 'git add --force'
    assert get_new_command(Command('git add',
                                   'The following paths are ignored by one of your .gitignore files:\n\
                                   bin/\n\
                                   Use -f if you really want to add them.')) == 'git add --force'

# Generated at 2022-06-22 01:37:29.448481
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git add A B', 'Use -f if you really want to add them.')) == 'git add --force A B'

# Generated at 2022-06-22 01:37:35.387417
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git add', 'error: The following untracked working tree files would be overwritten by merge:\n\tfoobar\n\nPlease move or remove them before you can merge.')) == 'git add --force'

# Generated at 2022-06-22 01:37:42.559167
# Unit test for function match
def test_match():
    assert match(Command('git add file1',
                         stderr='fatal: pathspec \'file2\' did not match any files\nUse -f if you really want to add them.\n'))
    assert match(Command('git add .',
                         stderr='fatal: pathspec \'file2\' did not match any files\nUse -f if you really want to add them.\n'))
    assert not match(Command('git add b'))


# Generated at 2022-06-22 01:37:53.987030
# Unit test for function match
def test_match():
    assert match(Command('git add',
                         "The following paths are ignored by one of your .gitignore files:\nfoo\nUse -f if you really want to add them.\n", 1, None))
    assert match(Command('git add foo', "error: foo: aaaaa\nUse -f if you really want to add them.\n", 1, None))
    assert match(Command('git add foo', "error: foo: aaaaa\nUse -f if you really want to add them.\n", 1, None))
    assert not match(Command('git commit', '', 1, None))
    assert not match(Command('git foo', 'foo: command not found', 1, None))



# Generated at 2022-06-22 01:37:58.662188
# Unit test for function match
def test_match():
    assert match(Command('git add', 'The following paths are ignored by one of your .gitignore files:\r\n\r\napp/models/person.rb\r\nUse -f if you really want to add them.'))
    assert not match(Command('git add', 'fatal: pathspec \'lol.txt\' did not match any files'))


# Generated at 2022-06-22 01:38:03.457130
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command('git add test.txt',
                                    'test.txt: needs merge\n'
                                    'Use -f if you really want to add them.', '')) ==
            'git add --force test.txt')

# Generated at 2022-06-22 01:38:10.790213
# Unit test for function match
def test_match():
    assert match(Command("git add .", "The following patterns did not match any file(s): '.'\n"
                                        "Use -f if you really want to add them.'", ""))
    assert not match(Command("git push", "The following patterns did not match any file(s): '.'\n"
                                        "Use -f if you really want to add them.'", ""))
    assert not match(Command("git push", "The following patterns did not match any file(s): '.'", ""))


# Generated at 2022-06-22 01:38:13.467459
# Unit test for function get_new_command
def test_get_new_command():
    assert('git add --force' == get_new_command('git add'))
    assert('git add --force' == get_new_command('git add foo.py'))
    assert('git add --force foo.py' == get_new_command('git add foo.py bar.py'))


# Generated at 2022-06-22 01:38:21.630065
# Unit test for function get_new_command
def test_get_new_command():
    # Test a single file
    command = Command('git add README.md', 'fatal: Path "README.md" is in the index. Use --force to add anyway.')
    assert get_new_command(command) == 'git add --force README.md'

    # Test multiple files
    command = Command('git add README.md LICENSE',
                      'fatal: Path "README.md" is in the index. Use --force to add anyway.\nfatal: Path "README.md" is in the index. Use --force to add anyway.')
    assert get_new_command(command) == 'git add --force README.md LICENSE'

# Generated at 2022-06-22 01:38:23.809973
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git add test.txt', '')
    assert get_new_command(command) == 'git add --force test.txt'

# Generated at 2022-06-22 01:38:31.511011
# Unit test for function match
def test_match():
	m = match(Command("git add .", "error: The following untracked working tree files would be overwritten by merge:\n\thello.c\n\tworld.c\n\nPlease move or remove them before you can merge.\nAborting"))
	assert m == True
	
	m = match(Command("git add .", "Aborting"))
	assert m == False
	
	m = match(Command("git add .", "Aborting"))
	assert m == False

# Generated at 2022-06-22 01:38:37.979438
# Unit test for function get_new_command
def test_get_new_command():
    # If the message contains the string
    # "Use -f if you really want to add them.", and the fuck is launched,
    # the command with --force option is printed
    command = Command('git add test', 'Use -f if you really want to add them.')
    assert get_new_command(command) == 'git add --force test'

# Generated at 2022-06-22 01:38:41.510618
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git add .', "Use -f if you really want to add them.")
    assert get_new_command(command) == 'git add --force .'



# Generated at 2022-06-22 01:38:47.581829
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git add', 'The following paths are ignored by one of your .gitignore files:\nUse -f if you really want to add them.')) \
           == 'git add --force'
    assert get_new_command(Command('git commit', 'The following paths are ignored by one of your .gitignore files:\nUse -f if you really want to add them.')) \
           == 'git commit'

# Generated at 2022-06-22 01:38:54.671371
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git add file.txt',
            'fatal: Pathspec \'file.txt\' is in submodule \'src/crypto\'\n'
            'Use --force if you really want to add it.\n'
            'fatal: Pathspec \'file.txt\' is in submodule \'src/crypto\'\n'
            'Use --force if you really want to add it.')
    assert get_new_command(command) == 'git add --force file.txt'

# Generated at 2022-06-22 01:38:58.261478
# Unit test for function match
def test_match():
    # Test if function match is working
    assert match(Command('git add *.py', 'fatal: pathspec \'*.py\' did not match any files\nUse -f if you really want to add them.\n'))



# Generated at 2022-06-22 01:39:04.023782
# Unit test for function match
def test_match():
    assert(match(Command("git add newfolder", "error: The following untracked working tree files would be overwritten by merge:\nerror:     newfolder\nUse -f if you really want to add them.\nfatal: no files added")))
    assert(not match(Command("git add newfile", "", "")))
    assert(not match(Command("git commit", "", "")))


# Generated at 2022-06-22 01:39:15.784995
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.specific.git import GitRule

    rule = GitRule()
    assert rule._build_new_command('git add .', 'error: The following untracked working tree files would be overwritten by merge:\nUse -f if you really want to add them.') == 'git add . --force'
    assert rule._build_new_command('git add --all .', 'error: The following untracked working tree files would be overwritten by merge:\nUse -f if you really want to add them.') == 'git add --all . --force'

# Generated at 2022-06-22 01:39:27.058235
# Unit test for function match

# Generated at 2022-06-22 01:39:30.163059
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git add', '', '', 'Use -f if you really want to add them.', '', '')) == "git add --force"

# Generated at 2022-06-22 01:39:33.043326
# Unit test for function get_new_command
def test_get_new_command():
    _command = Command('git init', '', 1)
    _command.script_parts = ['git', 'init']
    assert get_new_command(_command) == 'git add --force'

# Generated at 2022-06-22 01:39:36.373773
# Unit test for function match
def test_match():
    assert match(Command('git stash', ''))
    assert not match(Command('git add', ''))
    assert match(Command('git add -A', 'Use -f if you really want to add them.'))
    assert match(Command('git add --all', 'Use -f if you really want to add them.'))


# Generated at 2022-06-22 01:39:38.402499
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git add file.txt', 'error: The following unmerged paths', None, None)
    newcommand = get_new_command(command)
    assert newcommand.script == "git add --force file.txt"


# Generated at 2022-06-22 01:39:41.658272
# Unit test for function get_new_command
def test_get_new_command():
    assert_equals(get_new_command('git add'), 'git add --force')


# Generated at 2022-06-22 01:39:45.488773
# Unit test for function match
def test_match():
    assert match(Command('git add .',
                         'The following paths are ignored by one of your .gitignore files:\nbuild\nUse -f if you really want to add them.'))


# Generated at 2022-06-22 01:39:46.266182
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git add --help')
    assert get_new_command(command) == 'git add --force --help'

# Generated at 2022-06-22 01:39:49.419557
# Unit test for function match
def test_match():
    assert match(Command('git add', '',
                  'The following paths are ignored by one of your .gitignore '
                  'files:\n.DS_Store\nUse -f if you really want to add them.'))


# Generated at 2022-06-22 01:39:53.027631
# Unit test for function match
def test_match():
    assert match(Command('add .', '/', '', '', '', ''))
    assert match(Command('git add .', '/', '', '', '', ''))
    assert not match(Command('add /', '/', '', '', '', ''))
    assert not match(Command('remove .', '/', '', '', '', ''))


# Generated at 2022-06-22 01:40:05.838668
# Unit test for function match

# Generated at 2022-06-22 01:40:09.975497
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git add file_name',
    'error: The following untracked working tree files would be overwritten by merge:\n file_name\nPlease move or remove them before you can merge.\nAborting\n',
    '')) == 'git add --force file_name'


# Generated at 2022-06-22 01:40:14.741619
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command('git add foo',
                          'The following paths are ignored by one of your .gitignore files:\nfoo\nUse -f if you really want to add them.'))
            == 'git add --force foo')

# Generated at 2022-06-22 01:40:18.925840
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command('git add foo', '')) == 'git add --force foo')

# Generated at 2022-06-22 01:40:23.183369
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git add .') == 'git add --force .'
    assert get_new_command('git add .', 'git add --force .') == 'git add --force .'

# Generated at 2022-06-22 01:40:28.580688
# Unit test for function match
def test_match():
    command = Command('git add file3 file5', 'The following paths are ignored by one of your .gitignore files:', 'Use -f if you really want to add them.')
    assert match(command)
    command = Command('git add file3 file5', '', 'Use -f if you really want to add them.')
    assert not match(command)


# Generated at 2022-06-22 01:40:32.572118
# Unit test for function match
def test_match():
    assert match(Command('git add file', 'fatal: foo'))
    assert match(Command('git add file', 'fatal: not a git repository'))
    assert not match(Command('git add file', '', stderr=''))
    assert not match(Command('git add file', 'fatal: foo', stderr=''))
    assert not match(Command('git add file', 'fatal: not a git repository',
                             stderr=''))


# Generated at 2022-06-22 01:40:37.158774
# Unit test for function get_new_command
def test_get_new_command():
    command = 'git add --all'
    new_command = replace_argument(command, 'add', 'add --force')
    assert new_command == 'git add --force --all'

# Generated at 2022-06-22 01:40:44.729676
# Unit test for function match
def test_match():
    assert match(Command('git add',
                         "fatal: Path 'test' is in submodule 'mod1'\nUse " +
                         "'git add --force' if you really want to add it.\n"))
    assert match(Command('git add', "fatal: Path 'test' is in submodule " +
                         "'mod1'\nUse 'git add --force' if you really want " +
                         "to add it."))
    assert match(Command('git add .', "fatal: Path 'test' is in " +
                         "submodule 'mod1'\nUse 'git add --force' if " +
                         "you really want to add it."))


# Generated at 2022-06-22 01:40:45.900843
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git add .') == 'git add --force .'

# Generated at 2022-06-22 01:40:56.703375
# Unit test for function match
def test_match():
    command = Command('git add --ignore-removal gg.py',
                      'fatal: Pathspec \'gg.py\' is in submodule \'gg\'\n'
                      'Did you forget to \'git add\'?')
    assert match(command)
    
    command = Command('git add gg.py',
                      'fatal: Pathspec \'gg.py\' is in submodule \'gg\'\n'
                      'Did you forget to \'git add\'?')
    assert not match(command)
    
    command = Command('git status',
                      'fatal: Pathspec \'gg.py\' is in submodule \'gg\'\n'
                      'Did you forget to \'git status\'?')
    assert not match(command)
    

# Generated at 2022-06-22 01:40:59.371948
# Unit test for function match
def test_match():
    assert match(Command('git add', '', 'fatal: Pathspec \'\' is in submodule \'a\'\nUse \"git add --force ...\" if you really want to add them.'))
    assert not m

# Generated at 2022-06-22 01:41:05.996719
# Unit test for function match
def test_match():
    assert match(Command(script = 'git add file.txt', output = 'The following paths are ignored by one of your .gitignore files: file.txt Use -f if you really want to add them.'))
    assert not match(Command(script = 'git add file.txt', output = 'Warning: LF will be replaced by CRLF in file.txt.\nThe file will have its original line endings in your working directory.'))


# Generated at 2022-06-22 01:41:13.653307
# Unit test for function match
def test_match():
    assert match(Command('git add',
        'error: The following untracked working tree files would be overwritten by merge:\n\
         b.txt\n\
         Please move or remove them before you merge.\n\
         Aborting\n\
         error: The following untracked working tree files would be overwritten by merge:\n\
         b.txt\n\
         Please move or remove them before you merge.\n\
         Aborting\n\
         ',
        'git add'))
    assert not match(Command('git add hello.py', ''))
    assert not match(Command('git add', ''))
    

# Generated at 2022-06-22 01:41:18.114669
# Unit test for function match
def test_match():
    assert match(Command('git add file1 file2', '', 'The following paths are ignored by one of your .gitignore files:\nfile1\nUse -f if you really want to add them.'))
    assert not match(Command('ls', '', 'ls: cannot access file: No such file or directory\nls: cannot access file: No such file or directory'))


# Generated at 2022-06-22 01:41:28.337482
# Unit test for function get_new_command
def test_get_new_command():
    command1 = "git add --all"
    new_command1 =  get_new_command(command1)
    assert new_command1 == "git add --force --all"

    command2 = "git add ."
    new_command2 =  get_new_command(command2)
    assert new_command2 == "git add --force ."

    command3 = "git add"
    new_command3 =  get_new_command(command3)
    assert new_command3 == "git add --force"

    command4 = "git -add ."
    new_command4 =  get_new_command(command4)
    assert new_command4 == "git -add --force ."

    command5 = "git add --all ."
    new_command5 =  get_new_command(command5)
    assert new_command

# Generated at 2022-06-22 01:41:31.312255
# Unit test for function match
def test_match():
    assert match(Command('git add blah blah', 'fatal: pathspec \'blah\' did not match any files\nUse -f if you really want to add them.'))
    

# Generated at 2022-06-22 01:41:34.024421
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command

    script = "git add ."
    output = "The following paths are ignored by one of your .gitignore files:"
    assert get_new_command(Command(script, output)) == "git add --force ."

# Generated at 2022-06-22 01:41:36.654407
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git add main.c',
                      'The following paths are ignored by one of your .gitignore files:\nmain.c\nUse -f if you really want to add them.')
    assert get_new_command(command) == 'git add --force main.c'

# Generated at 2022-06-22 01:41:37.227935
# Unit test for function get_new_command

# Generated at 2022-06-22 01:41:38.736420
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git add --all') == 'git add --all  --force'
    assert get_new_command('set -x ; git commit --no-status -m "Creating branch.') is None

# Generated at 2022-06-22 01:41:42.764347
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command('git add .',
                                   'The following paths are ignored by one of your .gitignore files:\n.env\nUse -f if you really want to add them.\n')) == \
                                   'git add --force .'

# Generated at 2022-06-22 01:41:50.122380
# Unit test for function match
def test_match():
    assert match(Command(script="git add fuck", stderr='error: The following untracked working tree files would be overwritten by merge:\n#\tfuck\nPlease move or remove them before you can merge.\nAborting', error_code=1))
    assert match(Command(script="git add fuck", stderr='error: The following untracked working tree files would be overwritten by merge:\n#\tfuck\nPlease move or remove them before you can merge.\nAborting', error_code=0)) == False


# Generated at 2022-06-22 01:42:07.054865
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git status')
    command.output = '''
File abc  is untracked.
File xyz is untracked.
    Use -f if you really want to add them.
'''
    assert get_new_command(command) == \
        'git status'

    command = Command('git status')
    command.output = '''
File abc  is untracked.
File xyz is untracked.
    Use -f if you really want to add them.
'''
    assert get_new_command(command) == \
        'git status'


# Generated at 2022-06-22 01:42:09.121704
# Unit test for function get_new_command
def test_get_new_command():
	result = get_new_command(Command('git add', '', ''))
	assert result == 'git add --force'


# Generated at 2022-06-22 01:42:15.970257
# Unit test for function match
def test_match():
    assert match(Command('git add .',
                'error: '
                'The following untracked working tree files would be overwritten by merge:\n'
                '\t.gitignore.bak\n'
                '\t.gitignore.bak~\n'
                '\ttmp.txt\n'
                '\ttmp.txt~\n'
                'Please move or remove them before you can merge.\n'
                'Aborting\n',
                '', 1))
    assert not match(Command('cd .', '', '', 1))



# Generated at 2022-06-22 01:42:21.949521
# Unit test for function match
def test_match():
    assert match(Command('git add',
                         'The following untracked working tree files would be overwritten by merge:\n'
                         '/home/user/file.txt\n'
                         'Please move or remove them before you can merge.\n'
                         'Aborting\n'), None)
    assert not match(Command('git add', ''), None)


# Generated at 2022-06-22 01:42:26.529749
# Unit test for function match
def test_match():
    assert not match(Command('git add "string with space"'))
    assert match(Command('git add "string with space"',
                         'error: pathspec \'string\' did not match any file(s) known to git.\n'
                         'Did you forget to \'git add\'?'))



# Generated at 2022-06-22 01:42:35.221227
# Unit test for function match
def test_match():
    assert match(Command('git pull origin master', '', '', '', '', '', ''))
    assert match(Command('git commit', '', '', '', '', '', ''))
    assert match(Command('git commit -m test', '', '', '', '', '', ''))
    assert match(Command('git add', '', '', '', '', '', ''))
    assert not match(Command('git status', '', '', '', '', '', ''))
    assert not match(Command('git commit -m', '', '', '', '', '', ''))
    assert not match(Command('git tig', '', '', '', '', '', ''))


# Generated at 2022-06-22 01:42:39.062931
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git branch something') == 'git branch --force something'
    assert get_new_command('git branch --force something') == 'git branch --force --force something'

# Generated at 2022-06-22 01:42:43.693937
# Unit test for function get_new_command
def test_get_new_command():
    script = 'git add foo bar'
    command = Command(script, 'fatal: pathspec \'foo\' did not match any files\nUse -f if you really want to add them.')
    assert 'git add --force foo bar' == get_new_command(command)

# Generated at 2022-06-22 01:42:46.549306
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command('git add file.txt') == 'git add --force file.txt')
    assert(get_new_command('git add file1.txt file2.txt') == 'git add --force file1.txt file2.txt')

# Generated at 2022-06-22 01:42:52.629722
# Unit test for function match
def test_match():
    # there is no error message
    assert not match(Command('git add .', stderr='Nothing specified, nothing added.'))
    # there should be error message
    assert match(Command('git add .', stderr='The following paths are ignored by one of your .gitignore files'))
    # with commit words
    assert match(Command('git commit -m "update readme"', stderr='The following paths are ignored by one of your .gitignore files'))


# Generated at 2022-06-22 01:43:09.716686
# Unit test for function get_new_command
def test_get_new_command():
    assert match(Command('git add blah', '', 'Use -f if you really want to add them.'))
    assert get_new_command(Command('git add test', '', 'Use -f if you really want to add them.')) == 'git add --force test'
    assert not match(Command('git add test', '', ''))
    assert match(Command('git add .', '', 'Use -f if you really want to add them.'))
    assert get_new_command(Command('git add .', '', 'Use -f if you really want to add them.')) == 'git add --force .'

# Generated at 2022-06-22 01:43:16.566398
# Unit test for function match
def test_match():
    command_1 = Command('git add test.py', 'The following paths are ignored by one of your .gitignore files:\nfixtures\nUse -f if you really want to add them.')
    command_2 = Command('git add test.py', 'The following paths are ignored by one of your .gitignore files:\nfixtures')
    command_3 = Command('git add test.py', 'abcedfg')
    assert match(command_1)
    assert not match(command_2)
    assert not match(command_3)


# Generated at 2022-06-22 01:43:22.878380
# Unit test for function match
def test_match():
    assert not match(Command(script='git add', output='', stderr='output'))
    assert match(Command(script='git add', output=('The following paths are ignored by one of your .gitignore files:\n'
                                                   'foo.txt\n'
                                                   'Use -f if you really want to add them.'), stderr='output'))
    assert match(Command(script='git add', output=('The following paths are ignored by one of your .gitignore files:\n'
                                                   'foo.txt\n'
                                                   'Use -f if you really want to add them.'), stderr='output'))

# Generated at 2022-06-22 01:43:26.742479
# Unit test for function match
def test_match():
    command = Command('git add README.md', 'The following paths are ignored by one of your .gitignore files:')
    assert match(command)
    assert not match(Command('ls', ''))


# Generated at 2022-06-22 01:43:30.434181
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    assert get_new_command(Command('git add . && git commit -m "msg"', '', '', 'fatal: Pathspec \'script.py\' is in submodule \'scripts\'\nUse -f if you really want to add them.')) == 'git add --force . && git commit -m "msg"'

# Generated at 2022-06-22 01:43:31.726349
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git add -- "myfile"') == 'git add --force -- "myfile"'

# Generated at 2022-06-22 01:43:32.630764
# Unit test for function match
def test_match():
    assert match(Command('git add .'))


# Generated at 2022-06-22 01:43:34.553166
# Unit test for function match
def test_match():
    assert match(Command('git add .',
                         "fatal: pathspec '.gitignore' did not match any files"))



# Generated at 2022-06-22 01:43:37.227922
# Unit test for function match
def test_match():
    assert match(Command('git add .',
                         stderr='fatal: Pathspec \'\' is in submodule \'src/sub\'',
                         script='git add .'))



# Generated at 2022-06-22 01:43:38.513919
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('add --file')
    assert get_new_command(command) == 'add --force --file'

# Generated at 2022-06-22 01:43:53.975727
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git add') == 'git add --force'
    assert get_new_command('git add *') == 'git add --force *'
    assert get_new_command('git add .') == 'git add --force .'
    assert get_new_command('git add --all') == 'git add --force --all'

# Generated at 2022-06-22 01:44:01.269323
# Unit test for function match
def test_match():
    # The most obvious test case
    assert match(Command('git add file1 file2',
                         'fatal: Pathspec \'file2\' is in submodule \'file1\'\nUse --force if you really want to add them.'))
    # Shouldn't match --force version
    assert not match(Command('git add --force file1 file2',
                         'fatal: Pathspec \'file2\' is in submodule \'file1\'\nUse --force if you really want to add them.'))
    # Shouldn't match when no error message
    assert not match(Command('git add file1 file2', ''))
    # Shouldn't match different error
    assert not match(Command('git add file1 file2',
                         'fatal: Pathspec \'file2\' is in submodule \'file1\''))
