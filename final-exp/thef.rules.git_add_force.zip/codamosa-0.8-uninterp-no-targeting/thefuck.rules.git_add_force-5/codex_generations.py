

# Generated at 2022-06-22 01:33:56.802982
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='add',
                                   output='Use -f if you really want to add them.')) == 'add --force'


enabled_by_default = True

# Generated at 2022-06-22 01:34:00.991281
# Unit test for function get_new_command
def test_get_new_command():
	command = Command('git add .', 'The following paths are ignored by one of your .gitignore files:\n.DS_Store\nUse -f if you really want to add them.')
	new_command = get_new_command(command)
	assert new_command == 'git add --force .'

# Generated at 2022-06-22 01:34:05.074471
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git add',
                                   output='The following paths are ignored by one of your .gitignore files:\nUse -f if you really want to add them.')) == 'git add --force'

# Generated at 2022-06-22 01:34:08.544781
# Unit test for function get_new_command
def test_get_new_command():
    from types import SimpleNamespace
    assert (get_new_command(SimpleNamespace(
        script='git add',
        script_parts=['git', 'add'],
        output='Use -f if you really want to add them.'))
            == 'git add --force')

# Generated at 2022-06-22 01:34:12.202532
# Unit test for function match
def test_match():
    command = Command(script = "git add",
                      output = "\"poem.txt\" already exists in the index"
                               "Use -f if you really want to add them.")
    assert match(command) == True



# Generated at 2022-06-22 01:34:21.378414
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command([u"git", u"add"]).script == u"git add --force"
    assert get_new_command([u"git", u"add", u"file"]).script == u"git add --force file"
    assert get_new_command([u"git", u"add", u"file1", u"file2"]).script == u"git add --force file1 file2"
    assert get_new_command([u"git", u"add", u"-n"]).script == u"git add -n --force"
    assert get_new_command([u"git", u"add", u"--"]).script == u"git add --force --"


# Generated at 2022-06-22 01:34:27.239066
# Unit test for function match
def test_match():
    assert match(Command('git add a b',
                         'fatal: Pathspec \'a\' is in submodule \'b\''
                         'Use --ignore-submodules to skip it.'))
    assert not match(Command('git add a b', ''))
    assert not match(Command('git add a b', 'fatal: Pathspec \'a\' is in submodule \'b\''))

# Generated at 2022-06-22 01:34:30.126274
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git add not_existing_file', '', 'git add: not_existing_file: no such file or directory\nUse -f if you really want to add them.\n')) == 'git add --force not_existing_file'


# Generated at 2022-06-22 01:34:32.733584
# Unit test for function match
def test_match():
    command = Command('git add somefile', 'fatal: Path \'somefile\' is in the way')
    assert match(command)



# Generated at 2022-06-22 01:34:34.709873
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git add test', None)
    assert get_new_command(command) == 'git add --force test'

# Generated at 2022-06-22 01:34:39.041701
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='git add file1 file2', output='Use -f if you really want to add them.')) == 'git add --force file1 file2'

# Generated at 2022-06-22 01:34:41.811642
# Unit test for function match
def test_match():
    command = Command('git add .', 'The following paths are ignored by one of your .gitignore files:\n...', '', 0)
    assert match(command)



# Generated at 2022-06-22 01:34:53.592037
# Unit test for function match
def test_match():
	# case 1
	thefuck.shells.get_appropriate_shell = lambda: thefuck.shells.Bash()
	command = Command('git add --all',
					  'error: The following patterns have no matches:\n*.pyc\nUse -f if you really want to add them.')
	assert match(command)

	# case 2
	thefuck.shells.get_appropriate_shell = lambda: thefuck.shells.Bash()
	command = Command('git add --all',
					  'error: The following patterns have no matches:\n*.pyc\nUse -f if you really want to add them.\n')
	assert match(command)
	
	# case 3
	thefuck.shells.get_appropriate_shell = lambda: thefuck.shells.Bash()

# Generated at 2022-06-22 01:35:01.438760
# Unit test for function match
def test_match():
    assert match(Command('git add', 'On branch master\r\n'
                       + 'Your branch is up-to-date with \'origin/master\'.\r\n'
                       + 'Untracked files:\r\n  (use "git add <file>..." to include in what will be committed)\r\n\t'
                       + 'file1\r\n\tfile2\r\n\r\nnothing added to commit but untracked files present (use "git add" to track)'))


# Generated at 2022-06-22 01:35:04.134305
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    assert ('git add --force .' == get_new_command(Command('git add .',
        'fatal: The following paths are ignored by one of your .gitignore files:\n'
        'Use -f if you really want to add them.\n'
        'fatal: no files added', '')))

# Generated at 2022-06-22 01:35:06.526178
# Unit test for function get_new_command
def test_get_new_command():
    from . import assert_equals

    assert_equals(get_new_command(git('add *')),
                  git('add --force *'))

# Generated at 2022-06-22 01:35:08.826973
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git add .', 'Use -f if you really want to add them.')) == 'git add --force .'

# Generated at 2022-06-22 01:35:11.261007
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("git add .", "Use -f if you really want to add them.", None, 1)) == "git add --force ."

# Generated at 2022-06-22 01:35:16.084144
# Unit test for function match
def test_match():
    """
    Test for function match
    """
    assert match(Command('git add .',
              'The following paths are ignored by one of your .gitignore files:\n\
              test.html\n\
              Use -f if you really want to add them.'))



# Generated at 2022-06-22 01:35:19.917094
# Unit test for function match
def test_match():
    assert match(Command('git add 1.txt ', ''))
    assert match(Command('git add 1.txt 2.txt', ''))
    assert match(Command('git add .', ''))
    assert match(Command('git add -p', ''))
    assert match(Command('git add', ''))
    assert not match(Command('git commit', ''))
    assert not match(Command('git status', ''))

# Generated at 2022-06-22 01:35:23.506803
# Unit test for function match
def test_match():
    assert match(Command('git add', 'The following paths are ignored by one of your .gitignore files:', ''))
    assert not match(Command('git add', '', ''))


# Generated at 2022-06-22 01:35:27.147305
# Unit test for function match
def test_match():
    command = Command('git add DIR', 'fatal: CRLF would be replaced by LF in DIR.\nUse -f if you really want to add them.')
    assert match(command)


# Generated at 2022-06-22 01:35:30.525163
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git add -r some_dir', 
                                   'Use -f if you really want to add them.')) == 'git add --force -r some_dir'

# Generated at 2022-06-22 01:35:32.144977
# Unit test for function get_new_command
def test_get_new_command():
    assert 'git add --force' == get_new_command("git add -A").script

# Generated at 2022-06-22 01:35:34.244941
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git add .', 'test') == 'git add --force .'

# Generated at 2022-06-22 01:35:45.993080
# Unit test for function match
def test_match():
    assert (match(Command('git add --without-a-flag')) == False)
    assert (match(Command('git add --force')) == False)
    assert (match(Command('git add')) == False)
    assert (match(Command('git add test.py')) == False)
    assert (match(Command('git add --with-a-flag test.py')) == False)
    assert (match(Command('git add --force test.py')) == False)
    assert (match(Command('git add --with-a-flag --with-another-flag test.py')) == False)
    assert (match(Command('git add --with-a-flag --with-another-flag --force test.py')) == False)

# Generated at 2022-06-22 01:35:50.373604
# Unit test for function match
def test_match():
    assert match(Command("git add",
                         "error: The following untracked working tree files would be overwritten by merge:\n"
                         " Dockerfile\n"
                         " README.md\n"
                         " Use -f if you really want to add them."))
    assert not match(Command("git add",
                             "error: The following untracked working tree files would be overwritten by merge:\n"
                             " Dockerfile\n"
                             " README.md\n"
                             " Please move or remove them before you can merge."))


# Generated at 2022-06-22 01:35:53.141825
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command

    assert get_new_command(Command('git add test.png')) == 'git add --force test.png'

# Generated at 2022-06-22 01:35:54.966932
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("git add -- -a") == "git add --force -- -a"

# Generated at 2022-06-22 01:36:06.879539
# Unit test for function match
def test_match():
    assert match(Command('git add .', 'The following paths are ignored by one of your .gitignore files:', 'Use -f if you really want to add them.'))
    assert not match(Command('git add .', 'The following paths are ignored by one of your .gitignore files:', 'Use -i if you really want to add them.'))
    assert not match(Command('git add .', 'The following paths are ignored by one of your .gitignore files:', 'Use -e if you really want to add them.'))
    assert not match(Command('git add .', 'The following paths are ignored by one of your .gitignore files:', 'Use -y if you really want to add them.'))

# Generated at 2022-06-22 01:36:16.203215
# Unit test for function match
def test_match():
    assert match(Command('git add abc.txt', 'The following paths are ignored by one of your .gitignore files:\nabc.txt\nUse -f if you really want to add them.'))
    assert not match(Command('git add abc.txt', 'The following paths is ignored by one of your .gitignore files:\nabc.txt\nUse -f if you really want to add them.'))
    assert not match(Command('git config abc.txt', 'The following paths are ignored by one of your .gitignore files:\nabc.txt\nUse -f if you really want to add them.'))
    assert not match(Command('git add abc.txt', 'The following paths are ignored by one of your gitignore files:\nabc.txt\nUse -f if you really want to add them.'))

# Generated at 2022-06-22 01:36:19.530120
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git add', '', 'The following paths are ignored by one of your .gitignore files:', 'Use -f if you really want to add them.'))

# Generated at 2022-06-22 01:36:22.849142
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git add .')
    new_command = get_new_command(command)
    assert new_command == 'git add --force .'

# Generated at 2022-06-22 01:36:30.647957
# Unit test for function get_new_command
def test_get_new_command():

	# Test 1
	test_script_parts = ["git", "add", "file1", "file2", "file3", "-s"]
	test_output = "fatal: pathspec file2 did not match any files\nfatal: pathspec file3 did not match any files\nUse -f if you really want to add them."
	test_script = "git add file1 file2 file3 -s"
	
	command = Command(script = test_script, script_parts = test_script_parts, output = test_output)
	new_command = get_new_command(command)
	
	assert new_command == "git add --force file1 file2 file3 -s"

	# Test 2
	test_script_parts = ["git", "add", "file1", "file2", "file3"]
	test_

# Generated at 2022-06-22 01:36:36.049512
# Unit test for function match
def test_match():
    assert match(Command('git add *'))
    assert match(Command('git add *', 'error: The following untracked working tree files would be overwritten by merge:\n\n\t.gitignore\n\tLICENSE\n\nPlease move or remove them before you can merge.'))
    assert not match(Command('git add -f'))


# Generated at 2022-06-22 01:36:42.783966
# Unit test for function match
def test_match():    
    # Test 1.1
    assert match(Command('git add',
        'The following paths are ignored by one of your .gitignore files:\n'
        'docs/modules/docs\n'
        'Use -f if you really want to add them.\n'
        'fatal: no files added\n')) == True, 'Test 1.1'
    
    # Test 1.2
    assert match(Command('git add ',
        'The following paths are ignored by one of your .gitignore files:\n'
        'docs/modules/docs\n'
        'Use -f if you really want to add them.\n'
        'fatal: no files added\n')) == True, 'Test 1.2'
    
    # Test 2.1

# Generated at 2022-06-22 01:36:44.859274
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git add', '', 'The following paths are ignored by one of your .gitignore files:')) == 'git add --force'
    assert get_new_command(Command('git commit', '', 'The following paths are ignored by one of your .gitignore files:')) == 'git commit'

# Generated at 2022-06-22 01:36:47.350460
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git add', '', 'The following untracked working tree files would be overwritten by merge:\n\ta.txt\n\tb.txt\nPlease move or remove them before you can merge.')) == 'git add --force'

# Generated at 2022-06-22 01:36:52.064535
# Unit test for function match
def test_match():
    assert match(Command('git add file.txt',
                         'error: The following untracked working tree files would be overwritten by checkout:\n'
                         'file.txt\n'
                         'Please move or remove them before you can switch branches.\n'
                         'Aborting'))


# Generated at 2022-06-22 01:36:55.708488
# Unit test for function match
def test_match():
    assert match(Command('git add -A',
                  'The following paths are ignored by one of your .gitignore files:\nlib'
                  'Use -f if you really want to add them.'))
    assert not match(Command('git add -A', 'nothing'))

# Generated at 2022-06-22 01:37:02.280263
# Unit test for function get_new_command
def test_get_new_command():
    # The function get_new_command should take the "add" command, and add the --force 
    # to the end of the command and return it
    command = Command("git add .*")
    assert get_new_command(command) == "git add --force ."

# Generated at 2022-06-22 01:37:05.159405
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git add file1 file2 file3', '', '/home/')
    assert get_new_command(command) == "git add --force file1 file2 file3"

# Generated at 2022-06-22 01:37:09.633677
# Unit test for function match
def test_match():
    assert match(Command('git add .', stderr='Use -f if you really want to add them.'))
    assert match(Command('git add .', stderr='Use -f if you really want to add them.'))
    assert not match(Command('git add', stderr='error: no such option: -f'))

# Generated at 2022-06-22 01:37:16.367305
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git add') == 'git add --force'
    assert get_new_command('git add .') == 'git add --force .'
    assert get_new_command('git add --force') == 'git add --force'
    assert get_new_command('git add') == 'git add --force'
    assert get_new_command('git add .') == 'git add --force .'

# Generated at 2022-06-22 01:37:19.178363
# Unit test for function get_new_command
def test_get_new_command():
    input = 'git add --dry-run'
    output = 'git add --force'
    assert(get_new_command(input) == output)

# Generated at 2022-06-22 01:37:23.353687
# Unit test for function match
def test_match():
    assert match(Command('git add .',
                         'The following paths are ignored by one of your .gitignore files:\n  file.txt\nUse -f if you really want to add them.'))
    assert match(Command('git add .', '')) is None

	

# Generated at 2022-06-22 01:37:27.463954
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script="git add . && git commit -m 'fix errors'",
                           output="The following untracked working tree files would be overwritten by merge:\n	a.txt\nUse -f if you really want to add them.",
                           )) == "git add --force ."

# Generated at 2022-06-22 01:37:33.051779
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    
    assert get_new_command(Command('git add file.txt', ' ')) == 'git add --force file.txt'
    assert get_new_command(Command('git add *', ' ')) == 'git add --force *'
    assert not get_new_command(Command('git add ..', ''))

# Generated at 2022-06-22 01:37:36.936940
# Unit test for function get_new_command
def test_get_new_command():
    script = "git add ."
    old_command = "git add ."
    new_command = "git add --force ."
    command = Command(script, old_command, None)
    assert get_new_command(command) == new_command

# Generated at 2022-06-22 01:37:39.625478
# Unit test for function get_new_command
def test_get_new_command():
    input_command = 'git add'
    command = Command(input_command, '')
    assert get_new_command(command) == 'git add --force'



# Generated at 2022-06-22 01:37:42.402450
# Unit test for function match

# Generated at 2022-06-22 01:37:51.654603
# Unit test for function match
def test_match():
    assert match(Command('git branch foo',
                         'error: the following untracked working tree files would be overwritten by merge:\n'
                         '\tfile1\n\tfile2\n\n'
                         'Please move or remove them before you can merge.\n'
                         'Aborting')) is True

    assert match(Command('git branch foo',
                         'error: the following untracked working tree files would be overwritten by merge:\n'
                         '\tfile1\n\tfile2\n\n')) is False



# Generated at 2022-06-22 01:37:56.951761
# Unit test for function match
def test_match():
    assert match(Command('git add ',
    'The following paths are ignored by one of your .gitignore files:\n\
    directory/file.ext\n\
    Use -f if you really want to add them.\n\
    fatal: no files added'))
    assert not match(Command('git add file.ext', ''))


# Generated at 2022-06-22 01:38:01.454475
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git add -a', stderr=('The following untracked working tree files would be overwritten by merge:\n'
                                                          '\ta.txt'))) == 'git add --force -a'

# Generated at 2022-06-22 01:38:04.315992
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command('git add file', '', 'Use -f if you really want to add them.')) ==
            'git add --force file')

# Generated at 2022-06-22 01:38:05.934937
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git add .') == 'git add --force .'

# Generated at 2022-06-22 01:38:09.808370
# Unit test for function match
def test_match():
    assert match(Command('git add .', stderr='warning: adding embedded git repository: .git\nUse -f if you really want to add them.'))
    assert not match(Command('git add .', stderr=''))


# Generated at 2022-06-22 01:38:11.581232
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command('git add file.md') == 'git add --force file.md')

# Generated at 2022-06-22 01:38:13.726505
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command('git add', 'Use -f if you really want to add them.')) ==
            'git add --force')

# Generated at 2022-06-22 01:38:18.437925
# Unit test for function match
def test_match():
    assert match(Command('git add hello.txt',
        'fatal: pathspec \'hello.txt\' did not match any files\n'
        'Use -f if you really want to add them.'))
    assert not match(Command('git add hello.txt', ''))
    assert not match(Command('git commit', ''))


# Generated at 2022-06-22 01:38:25.774842
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git add a b', 'fatal: Pathspec \'a\' is in submodule \'b\'')
    assert get_new_command(command) == 'git add --force a b'


# Generated at 2022-06-22 01:38:27.689337
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command('git add foo', '', ''))
            == 'git add --force foo')

# Generated at 2022-06-22 01:38:31.798778
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git add',
                                   output='The following paths are ignored by one of your .gitignore files:\nUse -f if you really want to add them.')) == 'git add --force'


# Generated at 2022-06-22 01:38:43.398211
# Unit test for function match
def test_match():
    assert match(Command('git add file.txt', 'The following paths are ignored by one of your .gitignore files:\nfile.txt\nUse -f if you really want to add them.'))
    assert not match(Command('git add file.txt', 'The following paths are ignored by one of your .gitignore files:\nfile.txt\nUse -f if you really want to add them.', '', '', '', 123))
    assert not match(Command('git add --force file.txt', 'The following paths are ignored by one of your .gitignore files:\nfile.txt\nUse -f if you really want to add them.'))
    assert not match(Command('git add', 'The following paths are ignored by one of your .gitignore files:\nfile.txt\nUse -f if you really want to add them.'))


# Generated at 2022-06-22 01:38:45.019790
# Unit test for function match
def test_match():
    assert not match(Command('git branch f'))
    

# Generated at 2022-06-22 01:38:51.091051
# Unit test for function match
def test_match():
    assert match(Command('git add "foo bar"',
                         'fatal: pathspec \'foo bar\' did not match any files\nUse -f if you really want to add them.'))

    assert not match(Command('git add "foo bar"',
                             'fatal: pathspec \'foo bar\' did not match any files\nUse -f if you really want to add them.',
                             error=123))


# Generated at 2022-06-22 01:38:52.365249
# Unit test for function match
def test_match():
    """
    Test case for match function
    :return: assert
    """
    assert match(Command('git add . && git commit -m "lmao"'))
    assert not match(Command('ls'))


# Test for function get_new_command

# Generated at 2022-06-22 01:39:01.157528
# Unit test for function match

# Generated at 2022-06-22 01:39:03.664632
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git add', 'The following paths are ignored by one of your .gitignore files:\nUse -f if you really want to add them.')
    assert get_new_command(command) == "git add --force"

# Generated at 2022-06-22 01:39:06.781477
# Unit test for function match
def test_match():
    assert match(Command('git add', stderr='Use -f if you really want to add them.'))
    assert not match(Command('git add'))
    assert not match(Command('git add', stderr='something else'))


# Generated at 2022-06-22 01:39:11.921116
# Unit test for function match
def test_match():
	assert match(Command('git add .', 'Use -f if you really want to add them.'))


# Generated at 2022-06-22 01:39:16.234274
# Unit test for function match
def test_match():
    assert match(Command('git add test_match',
                         "Use -f if you really want to add them."
                         " Aborting"))
    assert not match(Command('git add',
                             "Use -f if you really want to add them."
                             " Aborting"))


# Generated at 2022-06-22 01:39:19.180488
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='git add a b', output='Use -f if you really want to add them.'))\
            == 'git add --force a b'

# Generated at 2022-06-22 01:39:25.672191
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("git add . && git commit -am 'message'",
                      'fatal: Pathspec '
                      '\'../../../../../../../../../../../../../../../../'
                      'etc/passwd\' is in submodule '
                      '\'sub\'\nUse -f if you really want to add them.')
    assert get_new_command(command) == "git add --force . && git commit -am 'message'"

# Generated at 2022-06-22 01:39:30.328647
# Unit test for function get_new_command
def test_get_new_command():
	 cmd = Command('git add .',
    'The following paths are ignored by one of your .gitignore files:\n'
    '*.pyc\n'
    'Use -f if you really want to add them.',
'')
	 assert(get_new_command(cmd) == 'git add --force .')

# Generated at 2022-06-22 01:39:33.247842
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("git add .", "use \"git add --force\" to override")
    assert get_new_command(command) == 'git add --force .'


# Generated at 2022-06-22 01:39:41.695152
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.git_add_f import get_new_command
    #(1)

# Generated at 2022-06-22 01:39:43.997958
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git add .') == 'git add --force .'
    assert get_new_command('git status') == 'git status'

# Generated at 2022-06-22 01:39:48.829177
# Unit test for function match
def test_match():
    command = Command("git add file.txt", "git add file.txt\r\nThe following paths are ignored by one of your .gitignore files:\r\nfile.txt\r\nUse -f if you really want to add them.\r\n")
    assert match(command)


# Generated at 2022-06-22 01:39:53.083820
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git add') == 'git add --force'
    assert get_new_command('git add file') == 'git add --force file'
    assert get_new_command('git add file1 file2') == 'git add --force file1 file2'
    assert get_new_command('git add .') == 'git add --force .'
    assert get_new_command('git add ../*') == 'git add --force ../*'

# Generated at 2022-06-22 01:39:59.781595
# Unit test for function match
def test_match():
    assert not match(Command('git log'))
    assert match(Command(
        'git add .', 'Use -f if you really want to add them.'))



# Generated at 2022-06-22 01:40:03.505406
# Unit test for function match
def test_match():
    arr = 'pip install pip-'
    out = 'Command python setup.py egg_info failed with error code 1'
    assert match(arr,out) == False


# Generated at 2022-06-22 01:40:06.350959
# Unit test for function get_new_command
def test_get_new_command():
	new_command = get_new_command(Command("git add somefile", "Use -f if you really want to add them.", "", None, None))
	assert new_command == "git add --force somefile"

# Generated at 2022-06-22 01:40:08.391221
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git add file.txt', '', 'Use -f if you really want to add them.')) == 'git add --force file.txt'

# Generated at 2022-06-22 01:40:20.811350
# Unit test for function match
def test_match():
    assert_true(match(Command('git add .', output='fatal: LF would be replaced by CRLF in foo. Warning: CRLF will be replaced by LF in bar. The file will have its original line endings in your working directory.')))
    assert_true(match(Command('git add file.txt', output='fatal: LF would be replaced by CRLF in foo. Warning: CRLF will be replaced by LF in bar. The file will have its original line endings in your working directory.')))
    assert_true(match(Command('git add file.txt', output='fatal: LF would be replaced by CRLF in foo. Warning: CRLF will be replaced by LF in bar. The file will have its original line endings in your working directory.')))

# Generated at 2022-06-22 01:40:24.236049
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git add file', "fatal: pathspec 'file' did not match any files\nUse -f if you really want to add them.")
    assert get_new_command(command) == 'git add --force file'

# Generated at 2022-06-22 01:40:26.533617
# Unit test for function match
def test_match():
    assert match(Command(script='git add --all', stderr='Use -f if you really want to add them.'))


# Generated at 2022-06-22 01:40:29.686096
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    correct = "git add --force"
    assert get_new_command(Command("git add", "Use -f if you really want to add them.", "")) == correct

# Generated at 2022-06-22 01:40:31.604856
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command('git add', '', 'Use -f if you really want to add them.'))
            == 'git add --force')

# Generated at 2022-06-22 01:40:34.630869
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command('git add foo.txt') == 'git add --force foo.txt')

# Generated at 2022-06-22 01:40:44.931158
# Unit test for function match
def test_match():
    assert match(Command('git add', '', ''))
    assert not match(Command('rm -rf', '', ''))


# Generated at 2022-06-22 01:40:47.703695
# Unit test for function match
def test_match():
    assert match(Command('git add file',
                         stderr='Use -f if you really want to add them.'))


# Generated at 2022-06-22 01:40:51.459622
# Unit test for function match
def test_match():
    assert match(Command('git add app/',
                         'fatal: Path app/ is in submodule app/\n'
                         'Use -f if you really want to add them.'))
    assert not match(Command('git add app/'))


# Generated at 2022-06-22 01:40:54.143795
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command('git add test.txt') == 'git add --force test.txt')

# Generated at 2022-06-22 01:41:00.181980
# Unit test for function match
def test_match():
    assert match(Command('git add file1 file2 file3',
                         'The following paths are ignored by one of your .gitignore files:\nfile1\nUse -f if you really want to add them.'))
    assert not match(Command('git add file1 file2 file3',
                             'The following paths are ignored by one of your .gitignore files:\nfile1\nUse -f if you really want to add them.\n'))
    assert not match(Command('git add file1 file2 file3', ''))

# Generated at 2022-06-22 01:41:08.913434
# Unit test for function match
def test_match():
    assert match(Command('git add',
                         'fatal: Pathspec \'...\' is in submodule \'...\'\n'
                         'Use --ignore-submodules to skip submodules '
                         'and use -f if you really want to add them.'))
    assert not match(Command('git add',
                             'fatal: Pathspec \'...\' is in submodule \'...\'\n'
                             'Use --ignore-submodules to skip submodules '
                             'and never use -f, you want to not add them.'))


# Generated at 2022-06-22 01:41:10.590057
# Unit test for function get_new_command
def test_get_new_command():
    assert_equals('git add --force .',
                  get_new_command(Command('git add .', '.')))

# Generated at 2022-06-22 01:41:14.588433
# Unit test for function match
def test_match():
    assert match(Command('git add',
                         'Use -f if you really want to add them.'))
    assert not match(Command('git add', ''))
    assert not match(Command('git status',
                             'Use -f if you really want to add them.'))


# Generated at 2022-06-22 01:41:18.380183
# Unit test for function match
def test_match():
    assert match(Command('git add hello', ''))
    assert match(Command('git add hello', 'Use -f if you really want to add them.'))
    assert not match(Command('git add', ''))
    assert not match(Command('git add', 'Use -f if you really want to add them.'))


# Generated at 2022-06-22 01:41:20.553948
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("git add", "Use -f if you really want to add them.")) == "git add --force"

# Generated at 2022-06-22 01:41:37.528694
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git add .',
                                   'The following paths are ignored by one of your .gitignore files:\nfoo',
                                   'output')) == 'git add --force .'

# Generated at 2022-06-22 01:41:38.249171
# Unit test for function match
def test_match():
    assert match(Command('git add __init__.py'))



# Generated at 2022-06-22 01:41:42.987191
# Unit test for function match
def test_match():
	assert match(Command('git add *', 'The following paths are ignored by one of your .gitignore files:', 'Use -f if you really want to add them.'))
	assert not match(Command('git add *', 'The following paths are ignored by one of your .gitignore files:', 'Use -f if you really want to add them.', 'error: pathspec \'z\' did not match any file(s) known to git.'))

# Generated at 2022-06-22 01:41:50.027223
# Unit test for function match
def test_match():
    assert match(Command('git add test.py',
                         'The following paths are ignored by one of your .gitignore files:\n'
                         'test.py\n'
                         'Use -f if you really want to add them.'))
    assert not match(Command('git add test.py', ''))
    assert not match(Command('git add test.py',
                             'The following paths are ignored by one of your .gitignore files:\n'
                             'test.py\n'))


# Generated at 2022-06-22 01:41:53.612926
# Unit test for function get_new_command
def test_get_new_command():
    x = Command('git add znikola.py', 'The following paths are ignored by one of your .gitignore files:\n.env\nUse -f if you really want to add them.')
    assert get_new_command(x) == 'git add --force znikola.py'

# Generated at 2022-06-22 01:41:56.026985
# Unit test for function get_new_command
def test_get_new_command():
    s = 'a test string'
    command = make_command(s)
    assert(get_new_command(command) == make_command(s.replace('add','add --force')))

# Generated at 2022-06-22 01:41:59.303603
# Unit test for function match
def test_match():
    assert match(Command('git add --force',
                         'Use -f if you really want to add them.'))
    assert not match(Command('git add', 'foo'))


# Generated at 2022-06-22 01:42:05.660614
# Unit test for function match
def test_match():
    assert match(Command('git add file.txt', 'fatal: pathspec \'file.txt\' did not match any files\nUse -f if you really want to add them.'))
    assert not match(Command('git add file.txt', ''))
    assert not match(Command('men add file.txt', 'fatal: pathspec \'file.txt\' did not match any files\nUse -f if you really want to add them.'))


# Generated at 2022-06-22 01:42:07.478596
# Unit test for function match
def test_match():
    assert match(Command('git add .'))
    assert not match(Command('git addi .'))



# Generated at 2022-06-22 01:42:09.876256
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git add .', 'fatal: Pathspec', 'git add .')
    assert get_new_command(command) == 'git add --force .'

# Generated at 2022-06-22 01:42:53.056593
# Unit test for function match
def test_match():
    assert match(Command('git add file1 file2 file3',
                         'fatal: pathspec file2 did not match any files', ))
    assert match(Command('git add file1 file2 file3',
                         'fatal: pathspec \'file2\' did not match any files', ))
    assert match(Command('git add file1 file2 file3',
                         'fatal: pathspec \'file2\' did not match any files', ))
    assert match(Command('git add file1 file2 file3',
                         'fatal: pathspec \'file2\' did not match any files', ))
    assert match(Command('git add file1 file2 file3',
                         'fatal: pathspec file2 did not match any files', ))

# Generated at 2022-06-22 01:42:56.232219
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.git_add_force import get_new_command
    assert get_new_command('''git add test''', '') == 'git add --force test'

# Generated at 2022-06-22 01:43:04.148719
# Unit test for function match
def test_match():
    # stdout ist not empty and contains "Use -f if you really want to add them."
    assert match(Command('git add foo.txt', '', '', 0))

    # stdout is not empty but doesn't contains "Use -f if you really want to add them."
    assert not match(Command('git add foo.txt', '', '', 0))

    # stdout is not empty and contains "Use -f if you really want to add them."
    # but script doesn't contains "add"
    assert not match(Command('git add foo.txt', '', '', 0))


# Generated at 2022-06-22 01:43:07.771487
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git add', 'test_get_new_command.py')
    assert get_new_command(command) == 'git add --force test_get_new_command.py'


# Generated at 2022-06-22 01:43:15.729096
# Unit test for function get_new_command
def test_get_new_command():
    with patch('builtins.print') as print_mock:
        command = Command("git add path/to/file", "error: The following untracked working tree files would be overwritten by merge:\n"
            "    apps/trips/file1.txt\n"
            "    apps/trips/file2.txt\n"
            "    apps/trips/file3.txt\n"
            "    apps/trips/file4.txt\n"
            "Use -f if you really want to add them.\n")
        assert get_new_command(command) == "git add --force path/to/file"

# Generated at 2022-06-22 01:43:18.647611
# Unit test for function match
def test_match():
    assert match(Command('git add a b', 'fatal: Pathspec \'a\' is in \
submodule \'b\'\nUse --force if you really want to add them.\n', '', 1))


# Generated at 2022-06-22 01:43:20.115321
# Unit test for function match
def test_match():
    assert match(Command('git add', 'The following paths are ignored by one of your .gitignore files:', True))



# Generated at 2022-06-22 01:43:24.331267
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command

    assert get_new_command(
        Command('git add',
                output='The following paths are ignored by one of your .gitignore files:\n'
                       'folder/path\n'
                       'Use -f if you really want to add them.')) == 'git add --force'

# Generated at 2022-06-22 01:43:28.418297
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.specific.git import git_support
    command = Command('git add .', 'fatal: This operation must be run in a work tree\n')
    assert git_support.get_new_command(command) == 'git add --force .'

# Generated at 2022-06-22 01:43:31.271967
# Unit test for function get_new_command
def test_get_new_command():
    command = type('Command', (object,),{
        'script': 'git add .',
        'output': 'Use -f if you really want to add them.'})
    assert 'git add --force .' == get_new_command(command)
