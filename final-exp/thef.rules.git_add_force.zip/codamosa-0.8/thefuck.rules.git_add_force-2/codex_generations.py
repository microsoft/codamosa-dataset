

# Generated at 2022-06-12 11:18:40.691928
# Unit test for function match
def test_match():
    assert match(Command('git add',
                         stderr='fatal: LF would be replaced by CRLF in input.'
                                'Use -f if you really want to add them.'))


# Generated at 2022-06-12 11:18:50.890594
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert (get_new_command(Command('git add .',
                                    'error: The following untracked working tree files would be overwritten by merge:\nPlease move or remove them before you can merge.\nabort: Aborting\n\nUse -f if you really want to add them.'))
            == 'git add --force .')
    assert (get_new_command(Command('git add -A',
                                    'error: The following untracked working tree files would be overwritten by merge:\nPlease move or remove them before you can merge.\nabort: Aborting\n\nUse -f if you really want to add them.'))
            == 'git add --force -A')

# Generated at 2022-06-12 11:18:53.900073
# Unit test for function get_new_command
def test_get_new_command():
    assert "git add --force" == get_new_command("git add")

# Generated at 2022-06-12 11:19:01.847252
# Unit test for function get_new_command

# Generated at 2022-06-12 11:19:05.152909
# Unit test for function match
def test_match():
    assert match(Command('git add', 'Use -f if you really want to add them.'))
    assert not match(Command('git add', ''))
    assert not match(Command('ls', ''))


# Generated at 2022-06-12 11:19:09.411116
# Unit test for function match
def test_match():
    assert match(Command('git add failed_file',
            output='The following untracked working tree files would be overwritten by merge:\n    failed_file\nPlease move or remove them before you can merge.\nAborting\nUse -f if you really want to add them.'))


# Generated at 2022-06-12 11:19:14.386036
# Unit test for function match
def test_match():
    assert match(Command('git add 1.txt', 'The following paths are ignored by one of your .gitignore files:\n1.txt\nUse -f if you really want to add them.'))
    assert not match(Command('git add 1.txt', 'The following paths are ignored by one of your .gitignore files:\nUse -f if you really want to add them.'))
    assert not match(Command('git add 1.txt', 'The following paths are ignored by one of your .gitignore files:\n1.txt\nUse -f if you really want to add them.'))


# Generated at 2022-06-12 11:19:16.529230
# Unit test for function get_new_command
def test_get_new_command():
    command = 'git add'
    new_command = 'git add --force'
    assert get_new_command(command) == new_command

# Generated at 2022-06-12 11:19:21.657253
# Unit test for function match
def test_match():
    command = Command('add --all', 'fatal: Pathspec \"??\" is in submodule'
                      '\'web/static/dist\' Use -f if you really want to add them.')
    assert match(command) is True

    command = Command('add --all', '')
    assert match(command) is False


# Generated at 2022-06-12 11:19:25.867444
# Unit test for function get_new_command
def test_get_new_command():
    command = 'git add -A test/'
    output = 'fatal: The following untracked working tree files would be overwritten by merge:\n	test/\nPlease move or remove them before you can merge.\nAborting\n'

    assert get_new_command(Command(command, output)) == 'git add --force -A test/'

# Generated at 2022-06-12 11:19:28.951837
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git add', '')) == 'git add --force'

# Generated at 2022-06-12 11:19:30.892794
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(
            fuck.Command('git add',
                output="error: The following untracked working tree files would be overwritten by merge:\n    a\n    b\n    c\nPlease move or remove them before you can merge.\nAborting")) == 'git add --force'

# Generated at 2022-06-12 11:19:33.508380
# Unit test for function match
def test_match():
    assert not match(Command('git status'))
    assert not match(Command('git add'))
    assert not match(Command('git add .'))
    assert match(Command('git add .', 'The following paths are ignored'))


# Generated at 2022-06-12 11:19:38.458400
# Unit test for function match
def test_match():
    assert match(Command('git add file1 dir1', 'The following paths are ignored by one of your .gitignore files:\n\tdir1\nUse -f if you really want to add them.'))
    assert match(Command('git add file1 dir1', 'The following paths are ignored by one of your .gitignore files:\n\tdir1\nUse -f if you really want to add them.')) is False


# Generated at 2022-06-12 11:19:41.936008
# Unit test for function get_new_command
def test_get_new_command():
	from thefuck.types import Command 
	output = Command(script = 'git add test', stdout = 'The following paths are ignored by one of your .gitignore files:\n\ntest\n\nUse -f if you really want to add them.')
	assert get_new_command(output) == "git add --force test"

# Generated at 2022-06-12 11:19:44.211374
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.git_force_add import get_new_command
    assert get_new_command(Command('git add .', 'The following paths are ignored by one of your .gitignore files:\nUse -f if you really want to add them.')) == 'git add --force .'

# Generated at 2022-06-12 11:19:47.475775
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git add .',
                                   output='The following paths are ignored by one of your .gitignore files:\nUse -f if you really want to add them.')) == 'git add --force .'

# Generated at 2022-06-12 11:19:56.852518
# Unit test for function get_new_command
def test_get_new_command():
    func = get_new_command
    assert func(Command('git add', 'error: The following untracked working tree files would be overwritten by merge: ...\nUse -f if you really want to add them.')) == 'git add --force'
    assert func(Command('git add .', 'error: The following untracked working tree files would be overwritten by merge: ...\nUse -f if you really want to add them.')) == 'git add --force .'
    assert func(Command('git add --all', 'error: The following untracked working tree files would be overwritten by merge: ...\nUse -f if you really want to add them.')) == 'git add --force --all'



# Generated at 2022-06-12 11:19:59.437588
# Unit test for function match
def test_match():
    git_cmd = "git add foo bar"
    command = Command(script=git_cmd, output='')
    ret = match(command)
    assert ret is None


# Generated at 2022-06-12 11:20:03.388509
# Unit test for function match
def test_match():
    assert match(Command('git add .'))
    assert not match(Command('whois .'))
    assert not match(Command('git add .', 'error: The following untracked working tree files would be overwritten by merge:\nUse -f if you really want to add them.'))


# Generated at 2022-06-12 11:20:07.387575
# Unit test for function match
def test_match():
	script = "git add"
	output = "Use -f if you really want to add them."
	assert match(Command("git add", script, output))
	assert not match(Command("git add", script, "gogogogogo"))


# Generated at 2022-06-12 11:20:17.001115
# Unit test for function match
def test_match():
    assert match(Command('git add main.py', 'fatal: pathspec \'main.py\' did not match any files\nUse -f if you really want to add them.'))
    assert not match(Command('git add main.py', ''))
    assert not match(Command('git add main.py', 'fatal: pathspec \'main.py\' did not match any files\n'))
    assert not match(Command('git add main.py', 'fatal: pathspec \'main.py\' did not match any files\nUse -f if you really want to add them.\n'))
    assert not match(Command('cd .', 'fatal: pathspec \'main.py\' did not match any files\nUse -f if you really want to add them.'))


# Generated at 2022-06-12 11:20:22.181230
# Unit test for function get_new_command
def test_get_new_command():
    # 'git add'
    assert(get_new_command('git add .') == 'git add . --force')
    # 'git add '
    assert(get_new_command('git add .') == 'git add . --force')
    # 'git add       .   '
    assert(get_new_command('git add       .   ') == 'git add       .   --force')

# Generated at 2022-06-12 11:20:24.779620
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git add non_existent_file', '')) == 'git add --force non_existent_file'

# Generated at 2022-06-12 11:20:28.774978
# Unit test for function get_new_command
def test_get_new_command():
    test_output = '''The following paths are ignored by one of your .gitignore files:
  .DS_Stores
Use -f if you really want to add them.
fatal: no files added
'''
    test_script = 'git add .'
    test_command = Command(script = test_script, output = test_output)
    assert get_new_command(test_command) == 'git add --force .'

# Generated at 2022-06-12 11:20:37.664711
# Unit test for function match
def test_match():
    assert match(Command('git add',
                         stderr='error: The following untracked working tree files would be overwritten by merge:\n'
                                        '    folder/test.txt\n'
                                        'Please move or remove them before you merge.\n'
                                        'Aborting\n'))
    assert match(Command('git add *',
                         stderr='error: The following untracked working tree files would be overwritten by merge:\n'
                                        '    folder/test.txt\n'
                                        'Please move or remove them before you merge.\n'
                                        'Aborting\n'))

# Generated at 2022-06-12 11:20:39.225114
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command(script='git add '))
            == 'git add --force ')

# Generated at 2022-06-12 11:20:42.830660
# Unit test for function match
def test_match():
    assert match(Command('git add file1 file2 file3 file4',
                         "fatal: 'file3' is outside repository",
                         "fatal: 'file5' is outside repository",
                         "Use -f if you really want to add them.",
                         ''))


# Generated at 2022-06-12 11:20:46.390984
# Unit test for function match
def test_match():
	assert match(Command("git add .", "fatal: Pathspec '.' is in submodule 'src/git'\nUse --force if you really want to add them.\n")) == True
	assert match(Command("git add .", "fatal: Pathspec '.' is in submodule 'src/git'\nUse -f if you really want to add them.\n")) == True
	assert match(Command("git add .", "fatal: Pathspec '.' is in submodule 'src/git'\nUse --force if you really want to add them.\n")) == True
	assert match(Command("git add .", "fatal: Pathspec '.' is in submodule 'src/git'\nUse -f if you really want to add them.\n")) == True

# Generated at 2022-06-12 11:20:49.415059
# Unit test for function match
def test_match():
    assert git_support()
    assert match(Script('git add file.txt'))
    assert not match(Script('git diff file.txt'))


# Generated at 2022-06-12 11:20:54.616222
# Unit test for function get_new_command
def test_get_new_command():
   from thefuck.rules.git_add_patch import get_new_command
   command = command_called('git add file.py', output='Use -f if you really want to add them.')
   assert get_new_command(command) == 'git add --force file.py'

# Generated at 2022-06-12 11:20:56.304405
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git add .') == 'git add --force .'



# Generated at 2022-06-12 11:20:58.188824
# Unit test for function match
def test_match():
    assert match(Command('git add', ''))
    assert not match(Command('git add --force', ''))


# Generated at 2022-06-12 11:21:01.060139
# Unit test for function match
def test_match():
    assert match(Command('git add', 'Use -f if you really want to add them.'))
    assert not match(Command('git add', 'foobar'))



# Generated at 2022-06-12 11:21:05.003255
# Unit test for function match
def test_match():
    def match(script, output):
        assert git.match(Command(script, output))

    match('git add', 'fatal: I do not like this file')
    match('git add', 'Use -f if you really want to add them.')


# Generated at 2022-06-12 11:21:09.327016
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git add', 'The following paths are ignored by one of '
            'your .gitignore files:\n\n    .gitignore\n\nUse -f if you really '
            'want to add them.')
    assert get_new_command(command) == 'git add --force'

# Generated at 2022-06-12 11:21:13.912921
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("git add file.txt", "The following paths are ignored by one of your .gitignore files:\nfile.txt\nUse -f if you really want to add them.\nfatal: no files added", "")
    assert get_new_command(command) == 'git add --force file.txt'

# Generated at 2022-06-12 11:21:18.716823
# Unit test for function match
def test_match():
    assert match(Command('git add file', stderr=('The following paths are ignored by one of your .gitignore files:\n'
                                                 'file\n'
                                                 'Use -f if you really want to add them.')))
    assert not match(Command('git add file', stderr=''))
    assert not match(Command('git commit -m', stderr=''))


# Generated at 2022-06-12 11:21:23.231458
# Unit test for function match
def test_match():
    assert match(Command('git add --name spam', '', stderr='The following untracked working tree files would be overwritten by merge:\n\tspam\n'))
    assert not match(Command('git add --name spam', '', stderr='fatal: Path \'spam\' is in the way\n'))

# Generated at 2022-06-12 11:21:27.408108
# Unit test for function match
def test_match():
    command = Command('git add TODO', '')
    assert not match(command)

    command = Command('git add TODO',
                      'The following paths are ignored by one of your .gitignore files:\nTODO\n'
                      'Use -f if you really want to add them.')
    assert match(command)


# Generated at 2022-06-12 11:21:34.012858
# Unit test for function get_new_command
def test_get_new_command():
    assert_equals(get_new_command('git add'), 'git add --force')
    assert_equals(get_new_command('git add -n'), 'git add --force -n')
    assert_equals(get_new_command('git add --dry-run'), 'git add --force --dry-run')

# Generated at 2022-06-12 11:21:36.360072
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git add .') == 'git add --force .'
    assert get_new_command('git add foo') == 'git add --force foo'

# Generated at 2022-06-12 11:21:41.471808
# Unit test for function match
def test_match():
    assert match(Command('git add', stderr='error: The following untracked working tree files would be overwritten by merge:\n\n\tPlease move or remove them before you can merge.'))
    assert not match(Command('git branch', stderr='error: The following untracked working tree files would be overwritten by merge:\n\n\tPlease move or remove them before you can merge.'))


# Generated at 2022-06-12 11:21:44.442192
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("git add .", "Use -f if you really want to add them.")
    assert get_new_command(command) == "git add --force ."

# Generated at 2022-06-12 11:21:48.856212
# Unit test for function match
def test_match():
    command = ShellCommand('git add .', 'error: The following untracked working tree files would be overwritten by merge:\nabc\nUse -f if you really want to add them.')
    assert match(command)
    command = ShellCommand('git add .', 'error: The following untracked working tree files would be overwritten by merge:')
    assert not match(command)


# Generated at 2022-06-12 11:21:55.363225
# Unit test for function match
def test_match():
    assert match(Command('git add app/others.py',
                         stderr='The following paths are ignored by one of your .gitignore files:\napp/others.py\nUse -f if you really want to add them.'))
    assert not match(Command('git add app/others.py',
                             stderr='The following paths are ignored by one of your .gitignore files:\napp/others.py'))
    assert not match(Command('git add app/others.py'))


# Generated at 2022-06-12 11:22:00.112996
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git add *', 
                      "The following paths are ignored by one of your .gitignore files:\n"
                      "client/dist\n"
                      "Use -f if you really want to add them.\n"
                      "fatal: no files added\n")
    assert get_new_command(command) == 'git add --force *'



# Generated at 2022-06-12 11:22:09.974789
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(
        Command('git add',
                'The following paths are ignored by one of your .gitignore files:',
                'Use -f if you really want to add them.')) == 'git add --force'

    assert get_new_command(
        Command('git config --global -e',
                'error: pathspec \'--global\' did not match any file(s) known to git.',
                'Use -f if you really want to add them.')) == 'git config --global -e'

    assert get_new_command(
        Command('git lga',
                'The following paths are ignored by one of your .gitignore files:',
                'Use -f if you really want to add them.')) == 'git lga --force'


# Generated at 2022-06-12 11:22:12.155758
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script="git add -f", output="Use -f if you really want to add them.")) == "git add -f --force"

# Generated at 2022-06-12 11:22:13.935478
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git add .')) == 'git add --force .'

# Generated at 2022-06-12 11:22:19.402627
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git add')
    assert get_new_command(command) == 'git add --force'

# Generated at 2022-06-12 11:22:23.816918
# Unit test for function match
def test_match():
    assert match(
        Command('git add .', 'The following paths are ignored by one of your .gitignore files:\n\t.idea\nUse -f if you really want to add them.'))
    assert not match(
        Command('git add', 'The following paths are ignored by one of your .gitignore files:\n\t.idea\nUse -f if you really want to add them.'))


# Generated at 2022-06-12 11:22:27.167146
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script = "git add .",
                          output = "error: The following untracked working tree files would be overwritten by merge:\ngit-stats.py\nPlease move or remove them before you can merge.\nAborting\nUse -f if you really want to add them.")) == "git add --force ."


# Generated at 2022-06-12 11:22:28.329590
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("git add file") == "git add --force file"

# Generated at 2022-06-12 11:22:36.281801
# Unit test for function match
def test_match():
    assert match(Command('git add',
                         output='fatal: pathspec \'foo\' did not match any files'))
    assert not match(Command('git add foo',
                         output='fatal: pathspec \'foo\' did not match any files'))
    assert match(Command('git add',
                         output='fatal: pathspec \'foo\' did not match any files\nUse -f if you really want to add them.'))
    assert not match(Command('git add',
                         output="fatal: pathspec 'foo' did not match any files\nUse -f if you really want to add them."))
    assert match(Command('git add --force',
                         output='fatal: pathspec \'foo\' did not match any files'))

# Generated at 2022-06-12 11:22:41.088706
# Unit test for function match
def test_match():
    command1 = Command('git add .')
    command2 = Command('git add .', output='Use -f if you really want to add them.')
    command3 = Command('git add .', output='Use -f if you really want to add them')

    assert not match(command1)
    assert match(command2)
    assert not match(command3)


# Generated at 2022-06-12 11:22:45.438742
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    assert get_new_command(Command('git add', 
                                   "The following paths are ignored by one of your .gitignore files:\n.idea\nUse -f if you really want to add them.\nabort: no files added\n", 
                                   '', 1)) == 'git add --force'

# Generated at 2022-06-12 11:22:47.225356
# Unit test for function match
def test_match():
    assert match(Command('git add *'))
    assert not match(Command('git add'))


# Generated at 2022-06-12 11:22:50.903945
# Unit test for function match
def test_match():
	output = '''The following paths are ignored by one of your .gitignore files:
www/config/autoload/local.php
Use -f if you really want to add them.
fatal: no files added
'''

	assert(match(Command('git add www/config/autoload/local.php', output)) == True)



# Generated at 2022-06-12 11:22:53.641529
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("git add . && git commit -m 'Make file'")) == "git add --force . && git commit -m 'Make file'"


# Generated at 2022-06-12 11:23:03.506613
# Unit test for function match
def test_match():
    command = Command('git add a', 'fatal: LF would be replaced by CRLF in a\nUse -f if you really want to add them.')
    assert match(command)
    command = Command('git add a', '')
    assert not match(command)
    command = Command('git add a', 'fatal: LF would be replaced by CRLF in a\nUse -f if you really want to add them.')
    assert get_new_command(command) == 'git add --force a'

# Generated at 2022-06-12 11:23:06.471790
# Unit test for function match
def test_match():
	assert match(Command('git add .', "error: The following pathspecs did not match any file(s) known to git.\n Use -f if you really want to add them."))


# Generated at 2022-06-12 11:23:09.648745
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git add --all')
    assert get_new_command(command) == 'git add --all --force'
    command = Command('git add .')
    assert get_new_command(command) == 'git add . --force'

# Generated at 2022-06-12 11:23:14.212433
# Unit test for function match
def test_match():
    new_output = ("The following paths are ignored by one of your .gitignore files:\n"
        "README.md\n"
        "Use -f if you really want to add them.\n"
        "fatal: no files added")
    assert match(Command("git add .", new_output))


# Generated at 2022-06-12 11:23:17.069339
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git add *') == 'git add --force *'
    assert get_new_command('git add .') == 'git add --force .'

# Generated at 2022-06-12 11:23:21.715225
# Unit test for function match
def test_match():
    assert match(Command('git add', stderr='error: The following untracked working tree files would be overwritten by merge:\n'))
    assert not match(Command('git add', stderr='error: The following untracked working tree files would be overwritten by merge:\n'))

# Generated at 2022-06-12 11:23:24.594327
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git add', 'The following paths are ignored by one of your .gitignore files:', 'Use -f if you really want to add them.')) == "git add --force"

# Generated at 2022-06-12 11:23:25.904345
# Unit test for function get_new_command
def test_get_new_command():
    assert_equal('git add --force', get_new_command('git add'))

# Generated at 2022-06-12 11:23:27.591585
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git add --force', '')) == 'git add --force'

# Generated at 2022-06-12 11:23:35.795236
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command('git add mysubmodule/.',
                                   'error: The following untracked working tree files would be overwritten by merge:\n        mysubmodule/subfile\nPlease move or remove them before you can merge.\nAborting\nUse -f if you really want to add them.')) == 'git add --force mysubmodule/.'
    assert get_new_command(Command('git add',
                                   'error: The following untracked working tree files would be overwritten by merge:\n        mysubmodule/subfile\nPlease move or remove them before you can merge.\nAborting\nUse -f if you really want to add them.')) == 'git add --force'

# Generated at 2022-06-12 11:23:47.260248
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command('git add ./test.txt',
                              'fatal: pathspec \'test.txt\' did not match any files',
                              'git add')) == 'git add --force ./test.txt'

# Generated at 2022-06-12 11:23:48.935140
# Unit test for function get_new_command
def test_get_new_command():
   assert get_new_command('git add readme.txt') == 'git add --force readme.txt'

# Generated at 2022-06-12 11:23:56.110665
# Unit test for function match
def test_match():
    assert (match(
        Command('git add foo', ''))
        == True)
    assert (match(
        Command('git add foo', 'Use -f if you really want to add them.'))
        == True)
    assert (match(
        Command('git add foo', 'Use -f if you really want to add them.'))
        == True)
    assert (match(
        Command('git add foo', 'Use -f if you really want to add them.'))
        == True)
    assert (match(
        Command('git add -f foo', 'Use -f if you really want to add them.'))
        == False)


# Generated at 2022-06-12 11:23:58.608295
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git add .', 'Use -f if you really want to add them.')).script == 'git add --force .'

# Generated at 2022-06-12 11:24:02.026759
# Unit test for function get_new_command
def test_get_new_command():
    test_cmd = Command('git add pom.xml', "fatal: LF would be replaced by CRLF in pom.xml\nUse -f if you really want to add them.\n")
    assert get_new_command(test_cmd) == 'git add --force pom.xml'

# Generated at 2022-06-12 11:24:04.301027
# Unit test for function get_new_command
def test_get_new_command():
     command_output = Command(script= 'git add .', output='Use -f if you really want to add them.')
     assert get_new_command(command_output) == 'git add --force'

# Generated at 2022-06-12 11:24:15.461737
# Unit test for function match
def test_match():
    assert match(Command('git add "*.py" "*.:"',
                         output="fatal: Path '*.py' exists on disk, but not in 'HEAD'.\n"
                                "Use -f if you really want to add them."))
    assert not match(Command('git add "*.py" "*.:"',
                         output="fatal: Path '*.py' exists on disk, but not in 'HEAD'."))
    assert match(Command('git checkout "*.py" "*.:"',
                         output="error: pathspec '*.:' did not match any file(s) known to git.\n"
                                "error: pathspec '*.py' did not match any file(s) known to git."))

# Generated at 2022-06-12 11:24:23.140453
# Unit test for function match
def test_match():
    assert match(Command('git add $foo', stderr='ERROR: add $foo: No such file or directory\nUse -f if you really want to add them.'))
    assert match(Command('git add $foo', stderr='error: add $foo: no such file or directory\nUse -f if you really want to add them.'))
    assert match(Command('git add $foo', stderr='error: add $foo: no such file or directory\nUse -f if you really want to add them.\nwarning: LF will be replaced by CRLF in .phpstorm.meta.php'))
    assert not match(Command('git add $foo', stderr='error: add $foo: No such file or directory'))

# Generated at 2022-06-12 11:24:24.315664
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command('git add file') == 'git add --force file')

# Generated at 2022-06-12 11:24:26.846229
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git add .') == 'git add --force .'
    assert get_new_command('git add foobar') == 'git add --force foobar'

enabled_by_default = True

# Generated at 2022-06-12 11:24:42.892654
# Unit test for function match
def test_match():
    assert match(Command('git add .', 'error: The following untracked working tree files would be overwritten by merge:\n testtest'))
    assert not match(Command('git add .', ''))

# Generated at 2022-06-12 11:24:47.512603
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git add --all',
                      "error: The following paths are ignored "
                      "(use -f to override)\n"
                      " .DS_Store\n"
                      "Use -f if you really want to add them.\n")
    assert get_new_command(command) == 'git add --force --all'

# Generated at 2022-06-12 11:24:52.048641
# Unit test for function match
def test_match():
    assert match(command=Command('git add file1 file2 file3', 'error: '
        'The following untracked working tree files would be overwritten '
        'by merge:\n\n\tfile1\n\tfile2\n\tfile3\n\nPlease move or remove them '
        'before you can merge.\nAborting'),)


# Generated at 2022-06-12 11:24:53.841580
# Unit test for function match
def test_match():
    assert match(Command('git add'))
    assert not match(Command('ls'))


# Generated at 2022-06-12 11:24:58.897272
# Unit test for function match
def test_match():
    assert match(Command('git add', u"""fatal: pathspec 'README.md' did not match any files
Use 'git add <file>...' to specify the files you wish to add.
Use 'git add --ignore-removal <file>...' to add the contents of removed files.
""", ""))



# Generated at 2022-06-12 11:25:01.224332
# Unit test for function match
def test_match():
    assert match('git add test')
    assert match('git add --all')
    assert not match('git add -f test')
    assert not match('git rm test')



# Generated at 2022-06-12 11:25:03.182323
# Unit test for function match
def test_match():
    assert match(Command('git add -A', 'fatal: LF would be replaced by CRLF in package-lock.json.\n'
                                          'The file will have its original line endings in your working directory.\n'
                                          'Use -f if you really want to add them.'))

# Generated at 2022-06-12 11:25:05.853046
# Unit test for function get_new_command

# Generated at 2022-06-12 11:25:10.808189
# Unit test for function match
def test_match():
    assert match(Command('git add', "fatal: cannot stat 'file': Permission denied\nUse -f if you really want to add them.", ''))
    assert not match(Command('git status', "", ''))
    assert not match(Command('git add', "error: Please enter a commit message to explain why this merge is necessary, especially if it merges an updated upstream into a topic branch.", ''))


# Generated at 2022-06-12 11:25:12.363917
# Unit test for function match
def test_match():
    assert match(Command('git add.', 'Use -f if you really want to add them.'))
    assert not match(Command('git add', ''))

# Generated at 2022-06-12 11:25:45.876841
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.git_add_dot import get_new_command
    assert get_new_command('git add .') == 'git add --force .'

# Generated at 2022-06-12 11:25:47.423965
# Unit test for function match
def test_match():
    assert match(Command('git add',
                         ''))
    assert not match(Command('git add',
                             '',
                             ''))


# Generated at 2022-06-12 11:25:49.719000
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git add .')
    command.output = 'Use -f if you really want to add them.'
    assert get_new_command(command) == 'git add --force .'

# Generated at 2022-06-12 11:25:50.513541
# Unit test for function match
def test_match():
    assert match("git add a")


# Generated at 2022-06-12 11:25:55.079956
# Unit test for function match
def test_match():
    assert match(Command('git add ', stderr='The following paths are ignored by one of your .gitignore files:\n'
                                            '.idea\n'
                                            'Use -f if you really want to add them.'))
    assert not match(Command(script='git add'))



# Generated at 2022-06-12 11:25:59.937665
# Unit test for function match
def test_match():
    # Test case 1: If there's no Use -f if you really want to add them. in command.output
    command = Command('git add', 'fatal: pathspec \'log\' is in submodule')
    assert match(command) == False
    # Test case 2: If there's no \'add\' in command.script_parts
    command = Command('git add --force', 'fatal: pathspec \'log\' is in submodule')
    assert match(command) == False


# Generated at 2022-06-12 11:26:02.602450
# Unit test for function match
def test_match():
    assert match(u'git add .gitignore && git commit -m"Add .gitignore"', u'')
    assert not match(u'git commit -m"Add .gitignore"', u'')
    assert not match(u'', u'')

# Generated at 2022-06-12 11:26:09.214548
# Unit test for function match
def test_match():
    assert match(Command('git add .', 'error: The following untracked working tree files would be overwritten by merge:\n\tfilename\n\tfilename\nPlease move or remove them before you can merge.'))
    assert not match(Command('git add .', 'error: The following untracked working tree files would be overwritten by merge:\n\tfilename\n\tfilename\nPlease move or remove them before you can merge.\nUse -f if you really want to add them.'))


# Generated at 2022-06-12 11:26:14.192289
# Unit test for function match
def test_match():
    output = "The following paths are ignored by one of your .gitignore files: " \
        "Vagrantfile Use -f if you really want to add them."
    command = Command("git add .")
    command.output = output
    assert match(command) is True
    assert get_new_command(command) == 'git add --force .'

# Generated at 2022-06-12 11:26:19.831120
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git add .', 'Use -f if you really want to add them.')) == 'git add --force .'
    assert get_new_command(Command('git add test.txt', 'Use -f if you really want to add them.')) == 'git add --force test.txt'
    assert get_new_command(Command('git add --force test.txt', 'Use -f if you really want to add them.')) == 'git add --force --force test.txt'

# Generated at 2022-06-12 11:27:22.528475
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git add', '', 'Use -f if you really want to add them.')) == 'git add --force'

# Generated at 2022-06-12 11:27:24.816040
# Unit test for function get_new_command
def test_get_new_command():
    result=get_new_command('git add --')
    assert result=='git add --force --'

# Generated at 2022-06-12 11:27:29.221016
# Unit test for function match
def test_match():
    command = Command(script="do not add .gitignore",
            output="The following paths are ignored by one of your .gitignore files: .gitignore Use -f if you really want to add them.")
    assert match(command)
    command = Command(script="do not add .gitignore",
            output="The following paths are ignored by one of your .gitignore files: .gitignore Use -f if you really want to add them.")
    assert not match(command)


# Generated at 2022-06-12 11:27:30.212214
# Unit test for function match

# Generated at 2022-06-12 11:27:32.042860
# Unit test for function match
def test_match():
    assert match(Command('git stash add'))
    assert match(Command('git stash add --force'))
    assert match(Command('git stash add -i'))


# Generated at 2022-06-12 11:27:37.309912
# Unit test for function match
def test_match():
    # Test 1: command: git add filename1 filename2
    # Expected: True
    command = Command(script="git add filename1 filename2", 
    	stderr="error: The following untracked working tree files would be overwritten by merge:\n" \
    		"filename1\nfilename2\nPlease move or remove them before you can merge.\n" \
    		"Aborting\n")
    assert match(command) is True

    # Test 2: command: git add filename1 filename2
    # Expected: False
    command = Command(script="git add filename1 filename2", 
    	stderr="please move or remove them before you can merge.\n" \
    		"Aborting\n")
    assert match(command) is False



# Generated at 2022-06-12 11:27:42.005740
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git add app.py', 'The following paths are ignored by one of your .gitignore files:\n\napp.py\nUse -f if you really want to add them.')
    assert get_new_command(command) == 'git add --force app.py'

# Generated at 2022-06-12 11:27:44.086486
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git add -A', 'Use -f if you really want to add them.')
    assert get_new_command(command) == 'git add --force -A'

# Generated at 2022-06-12 11:27:51.683749
# Unit test for function get_new_command
def test_get_new_command():
    # command = Command('./main.py', 'git add -A', 'error: The following untracked working tree files would be overwritten by merge:\n', 'error: The following untracked working tree files would be overwritten by merge:\nfile.py\n\nPlease move or remove them before you can merge.\n\nAborting')
    command = Command('git add -A', 'error: The following untracked working tree files would be overwritten by merge:\n', 'error: The following untracked working tree files would be overwritten by merge:\nfile.py\n\nPlease move or remove them before you can merge.\n\nAborting')
    assert get_new_command(command).script == 'git add --force -A'


# Generated at 2022-06-12 11:27:55.975229
# Unit test for function match
def test_match():
    assert match(Command('git add', 'warning: some tracked files were not added',
                         'warning: some untracked files were not added',
                         'Use -f if you really want to add them.'))
    assert not match(Command('git status',
                             'warning: some tracked files were not added',
                             'warning: some untracked files were not added',
                             'Use -f if you really want to add them.'))

