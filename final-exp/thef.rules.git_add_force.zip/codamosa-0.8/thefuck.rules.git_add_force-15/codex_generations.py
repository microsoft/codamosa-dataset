

# Generated at 2022-06-12 11:18:46.578778
# Unit test for function match
def test_match():
    assert match(Command('git add', stderr='error: The following untracked working tree files would be overwritten by merge:\n...\nUse -f if you really want to add them.'))


# Generated at 2022-06-12 11:18:54.821823
# Unit test for function match
def test_match():
    assert match(Command('git add .',
                         stderr=(
                             'error: The following untracked working tree '
                             'files would be overwritten by merge: .gitignore\n'
                             'Please move or remove them before you can merge.\n'
                             'Aborting\n'
                             'fatal: '
                             'Adding (use --force to override)')))
    assert not match(Command('git add .',
                             stderr=(
                                 'error: The following untracked working tree '
                                 'files would be overwritten by merge: .gitignore\n'
                                 'Please move or remove them before you can merge.\n'
                                 'Aborting\n'
                                 'fatal: ')))

# Generated at 2022-06-12 11:19:02.247151
# Unit test for function match
def test_match():
    assert match(Command('git add file.txt',
        "warning: You ran 'git add' with neither '-A (--all)' or "
        "'--ignore-removal', whose behaviour will change in Git 2.0 with "
        "respect to paths you removed. Paths like 'file.txt' that are "
        "removed from your working tree are ignored with this version of Git. "
        "* 'git add --ignore-removal <pathspec>', which is the current default, "
        "ignores paths you removed from your working tree.\n"
        "* 'git add --all <pathspec>' will let you also record the removals.\n"
        "Run 'git status' to check the paths you removed from your working tree.",
        '', 0)) == True



# Generated at 2022-06-12 11:19:07.790013
# Unit test for function match
def test_match():
    command = Command('git add .', "The following paths are ignored by one of your .gitignore files:")
    assert match(command)

    # Returning false if "Use -f if you really want to add them." is not in output
    command = Command('git add .', "The following paths are ignored by one of your .gitignore files:\n.dfdf")
    assert not match(command)


# Generated at 2022-06-12 11:19:10.261531
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit -m', '', 'a\nUse -f if you really want to add them.')) == 'git commit -m --force'

# Generated at 2022-06-12 11:19:15.462198
# Unit test for function match
def test_match():
    assert (match(Command('git add', 'The following paths are ignored by '
                          'one of your .gitignore files: test.txt\n'
                          'Use -f if you really want to add them.')))
    assert not match(Command('git add', 'The following paths are ignored by '
                             'one of your .gitignore files: test.txt\n'))
    assert not match(Command('git add', ''))
    assert not match(Command('git commit -m', ''))


# Generated at 2022-06-12 11:19:21.752386
# Unit test for function match
def test_match():
    assert match(Command('git add n',
                         'The following paths are ignored by one of your .gitignore files:\n    n\nUse -f if you really want to add them.'))
    assert not match(Command('git add n', ''))
    assert not match(Command('git foo n',
                         'The following paths are ignored by one of your .gitignore files:\n    n\nUse -f if you really want to add them.'))


# Generated at 2022-06-12 11:19:25.288066
# Unit test for function match
def test_match():
    assert match(Command('git add a/b',
                         'The following paths are ignored by one of your .gitignore files:\n',
                         'Use -f if you really want to add them.'))
    assert not match(Command('ls', ''))



# Generated at 2022-06-12 11:19:28.286866
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git add file') == 'git add --force file'
    assert (get_new_command('git bran add file') == 'git bran add --force file')
    

# Generated at 2022-06-12 11:19:33.011137
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(
        Command('git add *', 'fatal: Pathspec \'*\' is in submodule \'docs\'\n'
                'Use --force if you really want to add them.\n'
                'fatal: Pathspec \'*\' is in submodule \'docs\'\n'
                'Use -f if you really want to add them.')) \
        == 'git add --force *'
        

# Generated at 2022-06-12 11:19:36.226767
# Unit test for function match
def test_match():
    assert match(Command('git add test', 'The following paths are ignored ...'))



# Generated at 2022-06-12 11:19:39.594617
# Unit test for function match
def test_match():
    assert match(Command ('git add *.txt', 'fatal: Pathspec \'.\' is in submodule \'src\'', 'src'))
    assert not match(Command ('git add .', 'fatal: Pathspec \'.\' is in submodule \'src\'', 'src'))

# Generated at 2022-06-12 11:19:40.985770
# Unit test for function get_new_command
def test_get_new_command():
    assert_equals(get_new_command(Command('git add he', '')),
                  'git add --force he')

# Generated at 2022-06-12 11:19:44.294186
# Unit test for function match
def test_match():
    output = '''The following paths are ignored by one of your .gitignore files:

assets/js/dest/js/vendor/fontawesome/fontawesome.js
Use -f if you really want to add them.'''
    command = Command('git add .', output)
    assert match(command)



# Generated at 2022-06-12 11:19:47.889485
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git add SOMETHING', 'The following untracked working tree files would be overwritten by merge:\nUse -f if you really want to add them.')) == 'git add -f SOMETHING'

# Generated at 2022-06-12 11:19:53.027452
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git add', "error: The following untracked working tree files would be overwritten by merge:\n"
                                             "file.c\n"
                                             "file.h\n"
                                             "Please move or remove them before you merge.")) == 'git add --force'



# Generated at 2022-06-12 11:20:03.022507
# Unit test for function get_new_command

# Generated at 2022-06-12 11:20:09.875957
# Unit test for function match
def test_match():
    assert match(Command('git add', stderr='The following paths are ignored:'))
    assert match(Command('git add .', stderr='The following paths are ignored:'))
    assert match(Command('git add .', stderr='The following paths are ignored by one of your .gitignore files:'))
    assert match(Command(
        'git add an_uncommitted_file',
        stderr='The following paths are ignored by one of your .gitignore files:'))
    assert match(Command(
        'git add an_uncommitted_file',
        stderr='The following paths are ignored by your .gitignore:'))
    assert match(Command(
        'git add an_uncommitted_file',
        stderr='The following paths are ignored by your .git/info/exclude file:'))

# Generated at 2022-06-12 11:20:14.622496
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    script = 'git add untrackedfile'
    output = 'The following untracked working tree files would be overwritten by merge:\n\tuntrackedfile\n\tPlease move or remove them before you merge.'
    command = Command(script, output)

    assert (get_new_command(command)
            == 'git add --force untrackedfile')

# Generated at 2022-06-12 11:20:21.303108
# Unit test for function match
def test_match():
    assert match(Command('git add .',
                         'fatal: Pathspec \'drive\' is in submodule \'scripts\''))
    assert match(Command('git add .',
                         'fatal: Pathspec \'project/java\' is in submodule \'project\''))
    assert match(Command('git add .',
                         'error: unable to create new backup file ' +
                         '\'project/java/.classpath.swp\': Permission denied'))
    assert match(Command('git add .',
                         'fatal: Pathspec \'docs/HEADER.html\' is in submodule \'docs\''))
    assert isinstance(get_new_command(Command('git add .',
                                               'fatal: Pathspec \'drive\' is in submodule \'scripts\'')),
                      Command)

# Generated at 2022-06-12 11:20:26.043530
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script="git add .", output="fatal: LF would be replaced by CRLF in README.md")
    assert get_new_command(command) == "git add --force ."

# Generated at 2022-06-12 11:20:29.731532
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.specific.git import git_support

    assert git_support
    assert git_support.match("git add file1 file2")

    command = git_support.get_new_command("git add file1 file2")
    assert "--force" in command

# Generated at 2022-06-12 11:20:36.073034
# Unit test for function match
def test_match():
    # Test when it matches
    assert match(Command('echo My file is : foo ; git add foo', 'fatal: pathspec \'foo\' did not match any files', '', 0))

    # Test when it doesn't match
    assert not match(Command('echo My file is : foo ; git add foo', '', '', 0))

    # Test when it doesn't match
    assert not match(Command('echo My message is : foo ; git commit -m foo', 'fatal: pathspec \'foo\' did not match any files', '', 0))



# Generated at 2022-06-12 11:20:38.996725
# Unit test for function match
def test_match():
    assert match(Command('git add --all',
                     'fatal: pathspec \'--all\' did not match any files\n'
                     'Use \'git add --force --all\' to override this check.\n',
                     None, None, 'git add --all'))



# Generated at 2022-06-12 11:20:46.362985
# Unit test for function match
def test_match():
    assert match(Command('git add a.txt',
                         stderr='error: The following untracked working tree files would be overwritten by merge:\n'
                         'a.txt\n'
                         'Please move or remove them before you can merge.'))
    assert not match(Command('cd some/path',
                             stderr='error: The following untracked working tree files would be overwritten by merge:\n'
                             'a.txt\n'
                             'Please move or remove them before you can merge.'))
    assert not match(Command('git add a.txt', stderr=''))


# Generated at 2022-06-12 11:20:50.547296
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='git add .',
                                   output='The following paths are ignored by one of your .gitignore files:\n\n[...]\n\nUse -f if you really want to add them.')) == 'git add --force .'

# Generated at 2022-06-12 11:20:51.894343
# Unit test for function get_new_command
def test_get_new_command():
    assert 'git add --force' == get_new_command(Command('git add'))

# Generated at 2022-06-12 11:20:55.171763
# Unit test for function match
def test_match():
    assert match(Command('git add dir',
                         "The following paths are ignored by one of your .gitignore files:\n"
                         "\t<file>\n"
                         "Use -f if you really want to add them.",
                         '', 0))


# Generated at 2022-06-12 11:21:03.592444
# Unit test for function match
def test_match():
	assert match(Command('git add *', 'The following paths are ignored by one of your .gitignore files:', 'Use -f if you really want to add them.'))
	assert match(Command('git add', 'The following paths are ignored by one of your .gitignore files:', 'Use -f if you really want to add them.'))
	assert not match(Command('git a', 'The following paths are ignored by one of your .gitignore files:', 'Use -f if you really want to add them.'))
	assert not match(Command('git add', 'The following paths are ignored by one of your .gitignore files:', ''))


# Generated at 2022-06-12 11:21:06.506875
# Unit test for function get_new_command

# Generated at 2022-06-12 11:21:10.039739
# Unit test for function match
def test_match():
    assert match(Command('git add test.py', 'fatal: pathspec \'test.py\' did not match any files', '', 1))
    assert not match(Command('git push', '', '', 2))
    assert not match(Command('git', '', '', 1))


# Generated at 2022-06-12 11:21:13.546113
# Unit test for function match
def test_match():
    assert match(Command('git add test.txt', '', ''))
    assert not match(Command('git add test.txt',
                             "error: '.': no such file or directory", ''))

# Generated at 2022-06-12 11:21:15.851752
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git add', 'Use -f if you really want to add them.')) == 'git add --force'

# Generated at 2022-06-12 11:21:19.351750
# Unit test for function match
def test_match():
    assert match(Script("error: 'gpg-agent' is not a known subcommand of 'git'"))
    assert match(Script("error: pathspec 'git' did not match any file(s) known to git."))
    assert match(Script("error: unknown subcommand: git"))
    assert not match(Script('git add --help'))


# Generated at 2022-06-12 11:21:24.860910
# Unit test for function match
def test_match():
    assert match(Command('git add README.md', "error: The following untracked working tree files would be overwritten by merge:\nREADME.md\nPlease move or remove them before you can merge.\nAborting", ""))
    assert not match(Command('git add README.md', 'fatal: pathspec ?README.md? did not match any files', ''))


# Generated at 2022-06-12 11:21:29.004835
# Unit test for function get_new_command
def test_get_new_command():
    script = "git add --all"
    output = "error: The following untracked working tree files would be overwritten by checkout:"
    command = Command(script, output)
    assert get_new_command(command) == "git add --all --force"

test_depends_on_command = ['test_get_new_command']


# Generated at 2022-06-12 11:21:32.500977
# Unit test for function match
def test_match():
    assert match(Command('git add hello.txt',
            'The following paths are ignored by one of your .gitignore files:\nhello.txt\nUse -f if you really want to add them.'))
    assert not match(Command('git add hello.txt', ''))



# Generated at 2022-06-12 11:21:36.671406
# Unit test for function match
def test_match():
    assert match(Command('git add',
        output='fatal: pathspec \'poop.py\' did not match any files\nUse -f if you really want to add them.'))
    assert not match(Command('git add', output='fatal: pathspec \'poop.py\' did not match any files'))

# Generated at 2022-06-12 11:21:42.850427
# Unit test for function get_new_command
def test_get_new_command():
    # Sample output of git add
    output = '''The following paths are ignored by one of your .gitignore files:
    test1/test2/*
Use -f if you really want to add them.
fatal: no files added
'''

    # Command line input
    command = 'git add'

    # Expected output
    expected = 'git add --force'

    assert get_new_command(Command(script=command, output=output)) == expected

# Generated at 2022-06-12 11:21:48.716415
# Unit test for function match
def test_match():
    # Needs Windows since this is a Windows error message
    assert not match(Command('git status', '', '', 9))
    assert match(Command('git add path/file', '', '', 0))
    assert match(Command('git add path/file', '', "When you run 'git add <pathspec>...'", 0))
    assert match(Command('git add path/file', '', "When you run 'git add <pathspec>...'\r\nUse -f if y", 0))


# Generated at 2022-06-12 11:21:53.627288
# Unit test for function match
def test_match():
    assert match("git add")

# Generated at 2022-06-12 11:22:00.905631
# Unit test for function match
def test_match():
    assert_equal(match(Command('git add', stderr='The following paths are ignored by one of your .gitignore files:')), True)
    assert_equal(match(Command('git add', stderr='The following paths are ignored by one of your .gitignore files:')), True)
    assert_equal(match(Command('git push', stderr='The following paths are ignored by one of your .gitignore files:')), False)
    assert_equal(match(Command('git reset', stderr='The following paths are ignored by one of your .gitignore files:')), False) 


# Generated at 2022-06-12 11:22:05.950521
# Unit test for function match
def test_match():
    """Test that the function match return True if git output
    is 'Use -f if you really want to add them.'"""
    assert match(Command('git add file.txt',
            output='Use -f if you really want to add them.'))
    assert not match(Command('git add file.txt',
            output='No error'))


# Generated at 2022-06-12 11:22:09.334990
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(
        Command('git add .', 'The following paths are ignored by one of your .gitignore files:\nUse -f if you really want to add them.\n')
    ) == 'git add --force .'


# Generated at 2022-06-12 11:22:18.012350
# Unit test for function match
def test_match():
    assert match(Command('git add -A', '', 'error: The following untracked working tree files would be overwritten by merge:\n'
'	system/src/main/java/com/system/service/SystemService.java\n'
'Please move or remove them before you can merge.\n'
'Aborting\n'
'error: The following untracked working tree files would be overwritten by merge:\n'
'	system/src/main/java/com/system/service/SystemService.java\n'
'Please move or remove them before you can merge.\n'
'Aborting'))
    assert not match(Command('git add -A', '', 'Lorem ipsum'))


# Generated at 2022-06-12 11:22:24.941423
# Unit test for function match
def test_match():
    command1 = Command('git add README.md','''
            The following paths are ignored by one of your .gitignore files:
            .ipynb_checkpoints
            Use -f if you really want to add them.
            fatal: no files added
            ''')
    command2 = Command('git add .','''
            The following paths are ignored by one of your .gitignore files:
            .ipynb_checkpoints
            Use -f if you really want to add them.
            fatal: no files added
            ''')
    assert match(command1)
    assert match(command2)



# Generated at 2022-06-12 11:22:33.889057
# Unit test for function get_new_command
def test_get_new_command():
    # test case with git add:
    output_git_add = '''The following paths are ignored by one of your .gitignore files:
src/nibabel/externals/babel_config.pyc
Use -f if you really want to add them.
fatal: no files added'''
    command_git_add_1 = "git add ." # type: Command
    command_git_add_1.script_parts = ['git', 'add', '.']
    command_git_add_1.output = output_git_add
    assert get_new_command(command_git_add_1) == "git add --force ."
    # test case with add command:

# Generated at 2022-06-12 11:22:43.995032
# Unit test for function match
def test_match():
    assert match(Command('git add file.py'
                         , "fatal: LF would be replaced by CRLF in file.py."
                           "The file will have its original line endings in your working directory."))
    assert not match(Command('git add file.vim'
                         , "fatal: LF would be replaced by CRLF in file.vim."
                           "The file will have its original line endings in your working directory."))
    assert not match(Command('git add -f file.vim'
                         , "fatal: LF would be replaced by CRLF in file.vim."
                           "The file will have its original line endings in your working directory."))

# Generated at 2022-06-12 11:22:51.826707
# Unit test for function match
def test_match():
    assert match(Command('git add .', '', '', 0))
    assert match(Command('git add file.txt', '', '', 0))
    assert match(Command('git add DIR', '', '', 0))
    assert match(Command(u'git add «dir»', '', '', 0))
    assert match(Command(u'git add Maël', '', '', 0))
    assert not match(Command('git add', '', '', 0))
    assert not match(Command('git add -f', '', '', 0))
    assert not match(Command('git add --force', '', '', 0))
    assert not match(Command('git commit -m "message"', '', '', 0))


# Generated at 2022-06-12 11:23:02.481449
# Unit test for function match

# Generated at 2022-06-12 11:23:20.004341
# Unit test for function match
def test_match():
    assert match(Command('git add -f', '', 'error: The following untracked working tree files would be overwritten by merge:\nerror:   files/newone.cs\nerror:   files/newthree.cs\nU       files/fileone.cs\nU       files/filethree.cs\nU       files/filetwo.cs\nerror: The following untracked working tree files would be overwritten by merge:\nerror:   files/newone.cs\nerror:   files/newthree.cs\nPlease move or remove them before you can merge.\nAborting')) == True
    assert match(Command('git')) == False

# Generated at 2022-06-12 11:23:25.069527
# Unit test for function match
def test_match():
    command = Command('git add foobar', "fatal: pathspec 'foobar' did not match any files")
    assert match(command)
    command = Command('git add foobar', 'Use -f if you really want to add them.')
    assert match(command)
    command = Command('asdf foobar', 'Use -f if you really want to add them.')
    assert not match(command)


# Generated at 2022-06-12 11:23:29.243857
# Unit test for function match
def test_match():
    assert match(Command('git add file', ''))
    assert match(Command('git add file', 'error: the following files have ' \
                         'changes staged in the index'))
    assert not match(Command('git add file', 'Use -f if you really want ' \
                             'to add them.'))
    assert not match(Command('git commit file', ''))

    

# Generated at 2022-06-12 11:23:31.214640
# Unit test for function match
def test_match():
    assert match(Command('git add', 'Use -f if you really want to add them.'))
    assert not match(Command('git status', ''))



# Generated at 2022-06-12 11:23:33.277651
# Unit test for function get_new_command
def test_get_new_command():
	assert 'add --force' in get_new_command('git add')


# Generated at 2022-06-12 11:23:35.619892
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git add file.txt',
                                   'Use -f if you really want to add them.')) == 'git add --force file.txt'

# Generated at 2022-06-12 11:23:37.301243
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git add', '')) == 'git add --force'

# Generated at 2022-06-12 11:23:42.779724
# Unit test for function match
def test_match():
    alias = GitAlias()

    # No error output
    assert match(Command('git add')) == False
    assert match(Command('git add --help')) == False
    assert match(Command('git add .')) == False    
    
    # Error output
    assert match(Command('git add asdf/')) == True
    assert match(Command('git add foo/src/')) == True
    assert match(Command('git add .gitignore')) == True
    assert match(Command('git add --asdf')) == False
    assert match(Command('git add -e')) == False
    

# Generated at 2022-06-12 11:23:50.251233
# Unit test for function match
def test_match():
    assert match(Command('add file.txt',
                         'fatal: Pathspec \'"file.txt"\' is in submodule '
                         '\'folder/subfolder\'.\n'
                         'Use --ignore-submodules to ignore this path.'))
    assert match(Command('git add file.txt',
                         'fatal: Pathspec \'"file.txt"\' is in submodule '
                         '\'folder/subfolder\'.\n'
                         'Use --ignore-submodules to ignore this path.'))
    assert not match(Command('add file.txt', ''))

# Generated at 2022-06-12 11:23:53.001269
# Unit test for function match
def test_match():
    assert match(Command('git add file1 file2 file3', 'The following paths are ignored by one of your .gitignore files:\nfile1\nUse -f if you really want to add them.'))


# Generated at 2022-06-12 11:24:12.533136
# Unit test for function match
def test_match():
    assert match(Command('git add a', 'Please move or remove them before you can merge.'))

# Generated at 2022-06-12 11:24:16.036940
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    old = 'git add .'
    new = get_new_command(Command(old, '', u'Use -f if you really want to add them.'))
    assert new == 'git add --force .'

# Generated at 2022-06-12 11:24:23.419882
# Unit test for function get_new_command
def test_get_new_command():
    output = '''error: The following untracked working tree files would be overwritten by merge:
	src/main/java/com/company/project/GradleBuild.java
	src/main/java/com/company/project/Help.java
	src/main/java/com/company/project/Main.java
	src/main/java/com/company/project/MD5.java
	src/main/java/com/company/project/XMLParser.java
	src/main/java/com/company/project/XMLWriter.java
	src/main/java/com/company/project/YAML.java
Please move or remove them before you can merge.
Aborting
'''
    command = Command('git add', output)
    new_command = get_new_command(command)

# Generated at 2022-06-12 11:24:27.180921
# Unit test for function match
def test_match():
    command = Command('git add .', 'error: The following untracked working tree files would be overwritten by merge:...', '')
    assert match(command)
    command = Command('git add .', 'error: use "git add <file>..." to include in what will be committed', '')
    assert not match(command)


# Generated at 2022-06-12 11:24:29.390449
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git add', 'Use -f if you really want to add them.')) == 'git add --force'

# Generated at 2022-06-12 11:24:38.976329
# Unit test for function match
def test_match():
    assert match(Command("git add a b c",
                         "The following paths are ignored by one of your ." +
                         "gitignore files:\n\tb\nUse -f if you really want to add them."))

    assert not match(Command("git add a b c",
                         "The following paths are not ignored by one of your ." +
                         "gitignore files:\n\tb\nUse -f if you really want to add them."))

    assert not match(Command("git add a b c",
                         "The following paths are ignored by one of your ." +
                         "gitignore files:\n\tb\nUse -f if you really want to add them.\n\tb"))


# Generated at 2022-06-12 11:24:42.674518
# Unit test for function match
def test_match():
    assert match(Command('git add .',
                         'The following untracked working tree files would be overwritten by merge:\n    test.txt\nPlease move or remove them before you can merge.'))



# Generated at 2022-06-12 11:24:47.588375
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git add /data/file',
                      'The following paths are ignored by one of your .gitignore files:\n'
                      '/data/file\n'
                      'Use -f if you really want to add them.\n'
                      'fatal: no files added\n')
    assert get_new_command(command) == 'git add --force /data/file'

# Generated at 2022-06-12 11:24:52.806338
# Unit test for function match
def test_match():
    assert match(Script(script='git add', stderr='Use -f if you really want to add them.'))

# Generated at 2022-06-12 11:24:55.921656
# Unit test for function match
def test_match():
    assert match(Command('git add --no-all',
                         'fatal: The following untracked working tree files would be overwritten by merge:\n'
                         '    a\n    c\n'
                         'Please move or remove them before you can merge.\n'
                         'Aborting\n'))



# Generated at 2022-06-12 11:25:27.942119
# Unit test for function match

# Generated at 2022-06-12 11:25:30.437048
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='git add a/b/c', output='Use -f if you really want to add them.')) == 'git add --force a/b/c'

# Generated at 2022-06-12 11:25:34.063991
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git add foo', 'The following paths are ignored by one of your .gitignore files:\n\nfoo\nUse -f if you really want to add them.')
    assert get_new_command(command) == 'git add --force foo'

# Generated at 2022-06-12 11:25:37.417870
# Unit test for function match
def test_match():
    assert match(Command('git add test.txt', 
                         'Use -f if you really want to add them.'))
    assert not match(Command('git add test.txt', ''))
    assert not match(Command('git commit -m "committing changes"', ''))



# Generated at 2022-06-12 11:25:40.277926
# Unit test for function match
def test_match():
    # Basic case where if an executable is matched to a function
    # command is standard input
    command = Command('git add .', 'fatal: Pathspec . is in submodule .')
    assert match(command)
    

# Generated at 2022-06-12 11:25:47.040978
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command('git add file',
        output='fatal: pathspec \'file\' did not match any files')) ==
        'git add --force file')
    assert (get_new_command(Command('git add .',
        output='fatal: pathspec \'.\' did not match any files')) ==
        'git add --force .')
    assert (get_new_command(Command('git add .',
        output='fatal: pathspec \'file\' did not match any files')) ==
        'git add --force .')


# Generated at 2022-06-12 11:25:50.652613
# Unit test for function match
def test_match():
    command = Command('git add -A', 'fatal: Pathspec \'A\' is in submodule \'thefuck\'')
    assert(match(command) == True)
    command = Command('git', 'fatal: Pathspec \'A\' is in submodule \'thefuck\'')
    assert(match(command) == False)


# Generated at 2022-06-12 11:25:54.182991
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git add file', 'error: file ... use -f if you really want to add them.')
    new_command = get_new_command(command)
    assert new_command == 'git add --force file'

# Generated at 2022-06-12 11:25:56.039939
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git add .')) == 'git add --force .'

# Generated at 2022-06-12 11:26:01.146686
# Unit test for function match
def test_match():
    assert match(Command('git add .',
        "The following paths are ignored by one of your .gitignore files:",
        "Use -f if you really want to add them."))
    assert not match(Command('git add .', '', ''))
    assert match(Command('git add .', "The following paths are ignored by one of your .gitignore files:\n", "Use -f if you really want to add them."))
    assert not match(Command('git add .', "The following paths are ignored by one of your .gitignore files:\n"))


# Generated at 2022-06-12 11:26:31.099243
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Script('git add .', 'The following paths are ignored:\nUse -f if you really want to add them.')) == 'git add --force .'


enabled_by_default = True

# Generated at 2022-06-12 11:26:36.046143
# Unit test for function match
def test_match():
    assert list(match(Command('git add .',
                              'The following paths are ignored by one of your .gitignore files:\n'
                              'file1.txt\n'
                              'Use -f if you really want to add them.')))

    assert not match(Command('git add .',
                             'file1.txt\n'
                             'Use -f if you really want to add them.'
                             'The following paths are ignored by one of your .gitignore files:\n'))



# Generated at 2022-06-12 11:26:43.729654
# Unit test for function match
def test_match():
    assert match(Command('git add abc.txt', stderr='The following paths are ignored by one of your .gitignore files:\nabc.txt\nUse -f if you really want to add them.'))
    assert match(Command('git add abc.txt', stderr='The following paths are ignored by one of your .gitignore files:\nabc.txt\nUse -f if you really want to add them.'))
    assert not match(Command('git add abc.txt', stderr='something wrong'))
    assert not match(Command('git status', stderr='something wrong'))


# Generated at 2022-06-12 11:26:49.055923
# Unit test for function match
def test_match():
    assert match(Command('git add', '', 'fatal: pathspec \'f.txt\' did not match any files\nUse -f if you really want to add them.\n'))
    assert not match(Command('git commit', '', 'fatal: pathspec \'f.txt\' did not match any files\nUse -f if you really want to add them.\n'))


# Generated at 2022-06-12 11:26:53.137636
# Unit test for function match

# Generated at 2022-06-12 11:26:57.324519
# Unit test for function match
def test_match():
	print('*** Test match ***')
	cmd = 'git add .'
	command = Command(cmd, 'warning: the following paths are ignored by one of your .gitignore files:\n\n\t.gitignore\n\tconfig.py\n\tinit.py\n\nUse -f if you really want to add them.\n')
	assert match(command)


# Generated at 2022-06-12 11:27:00.638489
# Unit test for function get_new_command
def test_get_new_command():
	command = Command('git add hello.txt', 'The following paths are ignored by one of your .gitignore files:\nUse -f if you really want to add them.\nfatal: no files added', '', 0, None)
	assert get_new_command(command) == 'git add --force hello.txt'

# Generated at 2022-06-12 11:27:04.903317
# Unit test for function get_new_command
def test_get_new_command():
    git_add_result = Command('git add .', '', '',
            "The following paths are ignored by one of your .gitignore files:\n\
            src/upload\n\
            Use -f if you really want to add them.\n\
            fatal: no files added\n")
    assert get_new_command(git_add_result) == 'git add --force .'

# Generated at 2022-06-12 11:27:07.995538
# Unit test for function match
def test_match():
    from thefuck.types import Command
    assert match(Command('git add .',
                         "fatal: pathspec '.' did not match any files\n"
                         'Use -f if you really want to add them.'))



# Generated at 2022-06-12 11:27:09.069037
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git add')) == 'git add --force'

# Generated at 2022-06-12 11:28:26.925512
# Unit test for function match
def test_match():
    assert match(Command('git add foobar',
                         stderr='fatal: pathspec \'foobar\' did not match any files\nUse -f if you really want to add them.'))
    assert not match(Command('git add foobar',
                             stderr='fatal: pathspec \'foobar\' did not match any files'))


# Generated at 2022-06-12 11:28:35.101078
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git add', 
                                   "fatal: pathspec 'file.txt' did not match any files\nUse -f if you really want to add them.\n")) == "git add --force"
    assert get_new_command(Command('git add *', 
                                   "fatal: pathspec 'file.txt' did not match any files\nUse -f if you really want to add them.\n")) == "git add --force *"
    assert get_new_command(Command('git add file.txt', 
                                   "fatal: pathspec 'file.txt' did not match any files\nUse -f if you really want to add them.\n")) == "git add --force file.txt"

# Generated at 2022-06-12 11:28:41.553575
# Unit test for function match
def test_match():
    assert match(Command('git add file.txt',
             stderr='The following paths are ignored by one of your .gitignore files:\n'
                    'file.txt\n'
                    'Use -f if you really want to add them.\n'
                    'fatal: no files added'))
    assert not match(Command('git add file.txt',
                             'The following paths are ignored by one of your .gitignore files:\n'
                             'file.txt\n'
                             'Use -f if you really want to add them.\n'
                             'fatal: no files added'))

# Generated at 2022-06-12 11:28:43.928931
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='git add', 
                                   output='Use -f if you really want to add them.')) \
           == 'git add --force'