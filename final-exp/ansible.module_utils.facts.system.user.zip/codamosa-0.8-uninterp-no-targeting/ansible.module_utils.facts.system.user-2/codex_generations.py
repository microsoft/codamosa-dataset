

# Generated at 2022-06-20 20:03:49.937245
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    test_obj = UserFactCollector()
    result = test_obj.collect()
    assert isinstance(result, dict)


# Generated at 2022-06-20 20:03:56.124010
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_facts = UserFactCollector().collect()

    # Check if the facts are collected
    assert user_facts['user_id']
    assert user_facts['user_uid']
    assert user_facts['user_gid']
    assert user_facts['user_gecos']
    assert user_facts['user_dir']
    assert user_facts['user_shell']
    assert user_facts['real_user_id']
    assert user_facts['effective_user_id']
    assert user_facts['real_group_id']
    assert user_facts['effective_group_id']

# Generated at 2022-06-20 20:04:02.821714
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Check that facts are correctly gathered
    # Initialization of the class
    user_fact = UserFactCollector()

    # Definition of the facts that we expect

# Generated at 2022-06-20 20:04:04.605763
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    output = UserFactCollector()
    output = output.collect()

    assert output is not None


# Generated at 2022-06-20 20:04:11.582850
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector().collect()
    assert "user_id" in user_facts

    #The real user id should be the same as the effective user id
    assert user_facts["real_user_id"] == user_facts["effective_user_id"]

    #The real group id should be the same as the effective group id
    assert user_facts["real_group_id"] == user_facts["effective_group_id"]

# Generated at 2022-06-20 20:04:18.195343
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    from ansible.module_utils.facts.collectors import UserFactCollector
    collector = UserFactCollector()
    real_user_id = os.getuid()
    effective_user_id = os.geteuid()
    real_group_id = os.getgid()
    effective_group_id = os.getegid()

    assert collector.collect().get('real_user_id') == real_user_id
    assert collector.collect().get('effective_user_id') == effective_us

# Generated at 2022-06-20 20:04:27.766079
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import os

    class MockModule(object):
        pass

    class MockPwd(object):
        def __init__(self, uname):
            self.uname = uname
            return

        def getpwnam(self, uname):
            if uname == self.uname:
                return MockPwd(self.uname)
            else:
                raise KeyError

        def getpwuid(self, uid):
            return MockPwd(self.uname)

        pw_uid = 12345
        pw_gid = 23456
        pw_gecos = "Test GECOS"
        pw_dir = "/home/test"
        pw_shell = "/bin/bash"

    class MockGetpass(object):
        def getuser(self):
            return "test"

   

# Generated at 2022-06-20 20:04:30.637369
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert user_fact_collector is not None
    assert type(user_fact_collector) is UserFactCollector


# Generated at 2022-06-20 20:04:40.519924
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact = UserFactCollector()
    user_fact_collected = user_fact.collect()
    assert isinstance(user_fact_collected, dict)
    assert type(user_fact_collected['user_id']) is str
    assert type(user_fact_collected['user_uid']) is int
    assert type(user_fact_collected['user_gid']) is int
    assert type(user_fact_collected['user_gecos']) is str
    assert type(user_fact_collected['user_dir']) is str
    assert type(user_fact_collected['user_shell']) is str
    assert type(user_fact_collected['real_user_id']) is int
    assert type(user_fact_collected['effective_user_id']) is int


# Generated at 2022-06-20 20:04:51.762671
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    from ansible.module_utils.facts.collector import UserFactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import collector
    import pwd
    c=UserFactCollector()
    # Check number of results
    assert len(c.collect()) == 9
    # Check names of the results
    assert c.collect().keys() == dict.fromkeys([u'user_gecos', u'effective_group_id', u'effective_user_id', u'user_uid', u'user_id', u'user_dir', u'real_user_id', u'user_shell', u'real_group_id', u'user_gid'])

# Generated at 2022-06-20 20:05:01.362437
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    foo = UserFactCollector()
    assert foo.name == 'user'
    assert foo._fact_ids == {'user_id', 'user_uid', 'user_gid',
                             'user_gecos', 'user_dir', 'user_shell',
                             'real_user_id', 'effective_user_id',
                             'effective_group_ids'}

# Generated at 2022-06-20 20:05:06.900697
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    userFact = UserFactCollector()
    userFact_result = userFact.collect()

    if not isinstance(userFact_result, dict) or 'user_shell' not in userFact_result or userFact_result['user_shell'] != '/bin/bash':
        raise Exception("The collected values are not valid. Should be a dictionary with the key 'user_shell' with the value '/bin/bash'. Instead, it is: {}".format(userFact_result))
    elif 'user_uid' not in userFact_result:
        raise Exception("The collected values are not valid. Should be a dictionary with the key 'user_uid'. Instead, it is: {}".format(userFact_result))

# Generated at 2022-06-20 20:05:18.579285
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():

    gid = os.getgid()
    uid = os.getuid()
    user_name = getpass.getuser()

    ufc = UserFactCollector()
    assert ufc.name == 'user'
    assert ufc._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                 'user_gecos', 'user_dir', 'user_shell',
                                 'real_user_id', 'effective_user_id',
                                 'effective_group_ids'])

    facts = ufc.collect()

    assert facts['user_id'] == user_name

    assert facts['user_uid'] == uid
    assert facts['user_gid'] == gid
    assert facts['real_user_id'] == uid

# Generated at 2022-06-20 20:05:24.967442
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    c = UserFactCollector()
    assert c.name == 'user'
    assert c._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                               'user_gecos', 'user_dir', 'user_shell',
                               'real_user_id', 'effective_user_id',
                               'effective_group_ids'])


# Generated at 2022-06-20 20:05:30.970009
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufcoll = UserFactCollector()
    test_facts = {'user_id': 'root', 'user_uid': 0, 'user_gid': 0, 'user_gecos': 'root',
                  'user_dir': '/root', 'user_shell': '/bin/bash', 'real_user_id': 0,
                  'effective_user_id': 0, 'real_group_id': 0, 'effective_group_id': 0}

    assert ufcoll.collect() == test_facts

# Generated at 2022-06-20 20:05:39.396583
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    expected_name = 'user'
    expected_fact_ids = set(['user_id', 'user_uid', 'user_gid',
                             'user_gecos', 'user_dir', 'user_shell',
                             'real_user_id', 'effective_user_id',
                             'effective_group_ids'])
    userFactCollector = UserFactCollector()
    assert userFactCollector.name == expected_name
    assert userFactCollector._fact_ids == expected_fact_ids



# Generated at 2022-06-20 20:05:47.515060
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    """
    Unit test for method collect of class UserFactCollector
    """
    collector = UserFactCollector()

    collected_facts = collector.collect()

    assert collected_facts['user_id'] == getpass.getuser()
    assert collected_facts['real_user_id'] == os.getuid()
    assert collected_facts['effective_user_id'] == os.geteuid()
    assert collected_facts['real_group_id'] == os.getgid()
    assert collected_facts['effective_group_id'] == os.getegid()

# Generated at 2022-06-20 20:05:54.873997
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fact_collector = UserFactCollector()
    fact = fact_collector.collect()
    assert fact == {
        'effective_group_id': 1000,
        'effective_user_id': 1000,
        'real_group_id': 1000,
        'real_user_id': 1000,
        'user_dir': '/home/user',
        'user_gecos': 'user,,,',
        'user_gid': 1000,
        'user_id': 'user',
        'user_shell': '/bin/bash',
        'user_uid': 1000,
    }

# Generated at 2022-06-20 20:06:00.643766
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()

    user_facts = user_fact_collector.collect()

    assert ('user_id' in user_facts)
    assert ('user_uid' in user_facts)
    assert ('user_gid' in user_facts)
    assert ('user_gecos' in user_facts)
    assert ('user_dir' in user_facts)
    assert ('user_shell' in user_facts)
    assert ('real_user_id' in user_facts)
    assert ('effective_user_id' in user_facts)
    assert ('effective_group_ids' in user_facts)

# Generated at 2022-06-20 20:06:02.123617
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    pass

# Generated at 2022-06-20 20:06:10.349951
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ufc = UserFactCollector()
    result = ufc.collect()
    assert result['user_id'] == "ubuntu" or result['user_id'] == "root"

# Generated at 2022-06-20 20:06:13.106566
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    c = UserFactCollector()
    assert c.name() == "user"
    assert "user_id" in c.collect()

# Generated at 2022-06-20 20:06:21.023435
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import inspect
    from ansible.module_utils.facts.collectors import UserFactCollector
    u = UserFactCollector()
    user_facts = u.collect(None, None)

    assert user_facts is not None
    assert isinstance(user_facts, dict)
    assert '_ansible_user_id' in user_facts
    assert '_ansible_user_uid' in user_facts
    assert '_ansible_user_gid' in user_facts
    assert '_ansible_user_gecos' in user_facts
    assert '_ansible_user_dir' in user_facts
    assert '_ansible_user_shell' in user_facts
    assert '_ansible_real_user_id' in user_facts
    assert '_ansible_effective_user_id' in user_

# Generated at 2022-06-20 20:06:31.991361
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import os

    fake_getuid = os.getuid
    fake_geteuid = os.geteuid
    fake_getgid = os.getgid
    fake_getegid = os.getegid

    _user_id = 'user'
    def fake_getuid():
        return _user_id
    def fake_geteuid():
        return _user_id
    def fake_getgid():
        return _user_id
    def fake_getegid():
        return _user_id

    _pwent = pwd.struct_passwd((
        'username',
        'x',
        _user_id,
        _user_id,
        'gecos',
        '/home/username',
        '/bin/sh'
    ))


# Generated at 2022-06-20 20:06:37.795711
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    collector = UserFactCollector()
    assert collector.name == 'user'
    assert collector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                       'user_gecos', 'user_dir', 'user_shell',
                                       'real_user_id', 'effective_user_id',
                                       'effective_group_ids'])



# Generated at 2022-06-20 20:06:47.334754
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Note: if this test ever fails it is due to the fact that the user running
    # the test has a different gecos, homedir, or shell
    user_facts = UserFactCollector().collect()
    # The following values can be different depending on what user this is
    # running as
    assert user_facts['user_id']
    assert user_facts['user_uid']
    assert user_facts['user_gid']
    # The following values are supposed to be the same
    assert user_facts['user_gecos'] == 'Test User'
    assert user_facts['user_dir'] == '/home/test'
    assert user_facts['user_shell'] == '/bin/bash'
    assert user_facts['real_user_id'] == user_facts['user_uid']

# Generated at 2022-06-20 20:06:49.774813
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collector = UserFactCollector()
    assert collector.collect() is not None

# Generated at 2022-06-20 20:06:58.069551
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    """
        Test collect method of UserFactCollector.
        The test will pass.
    """
    obj = UserFactCollector()

    user_facts = {
        'user_id': 'ansible',
        'user_uid': 1000,
        'user_gid': 1000,
        'user_gecos': 'Ansible',
        'user_dir': '/home/ansible',
        'user_shell': '/bin/bash',
        'real_user_id': 1000,
        'effective_user_id': 1000,
        'real_group_id': 1000,
        'effective_group_id': 1000
    }

    assert obj.collect(collected_facts=user_facts) == user_facts

# Generated at 2022-06-20 20:07:05.504496
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector().collect()
    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['user_uid'] == pwent.pw_uid
    assert user_facts['user_gid'] == pwent.pw_gid
    assert user_facts['user_gecos'] == pwent.pw_gecos
    assert user_facts['user_dir'] == pwent.pw_dir
    assert user_facts['user_shell'] == pwent.pw_shell
    assert user_facts['real_user_id'] == os.getuid()
    assert user_facts['effective_user_id'] == os.geteuid()
    assert user_facts['real_group_id'] == os.getgid()

# Generated at 2022-06-20 20:07:09.752527
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    """
    This method is the unit test for method collect of class
    UserFactCollector.
    """
    user_fact_collector = UserFactCollector()
    retval = user_fact_collector.collect()
    print(retval)
    assert retval != None

if __name__ == '__main__':
    test_UserFactCollector_collect()

# Generated at 2022-06-20 20:07:28.310616
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Test object creation
    fact_collector = UserFactCollector()
    fact_collector.collect()

    # Test function return value
    assert(fact_collector.collect()['user_id'] == 'ansible')
    assert(fact_collector.collect()['user_uid'] == 1000)
    assert(fact_collector.collect()['user_gid'] == 1000)
    assert(fact_collector.collect()['user_gecos'] == 'ansible')
    assert(fact_collector.collect()['user_dir'] == '/home/ansible')
    assert(fact_collector.collect()['user_shell'] == '/bin/bash')
    assert(fact_collector.collect()['real_user_id'] == 1000)

# Generated at 2022-06-20 20:07:31.491589
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    user_facts = UserFactCollector().collect()

    assert user_facts['real_user_id'] == 'root'
    assert user_facts['effective_user_id'] == 'root'
    assert user_facts['real_group_id'] == 'root'
    assert user_facts['effective_group_id'] == 'root'

# Generated at 2022-06-20 20:07:39.118270
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    result = ufc.collect()
    assert result['user_id']
    assert result['user_uid']
    assert result['user_gid']
    assert result['user_gecos']
    assert result['user_dir']
    assert result['user_shell']
    assert result['real_user_id']
    assert result['effective_user_id']
    assert result['real_group_id']
    assert result['effective_group_id']


# Generated at 2022-06-20 20:07:45.022935
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    assert UserFactCollector.name == 'user'
    assert UserFactCollector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                               'user_gecos', 'user_dir', 'user_shell',
                                               'real_user_id', 'effective_user_id',
                                               'effective_group_ids'])

# Functional test for UserFactCollector

# Generated at 2022-06-20 20:07:46.703223
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    user_fact_collector.collect()

# Generated at 2022-06-20 20:07:56.183620
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc_dict = UserFactCollector().collect()
    assert isinstance(ufc_dict, dict)
    assert 'user_id' in ufc_dict
    assert 'user_uid' in ufc_dict
    assert 'user_gid' in ufc_dict
    assert 'user_gecos' in ufc_dict
    assert 'user_dir' in ufc_dict
    assert 'user_shell' in ufc_dict
    assert 'real_user_id' in ufc_dict
    assert 'effective_user_id' in ufc_dict
    assert 'real_group_id' in ufc_dict
    assert 'effective_group_id' in ufc_dict

# Generated at 2022-06-20 20:08:04.077490
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fact_collector = UserFactCollector()
    user_facts = fact_collector.collect()
    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['user_uid'] == pwd.getpwuid(os.geteuid()).pw_uid
    assert user_facts['user_gid'] == pwd.getpwuid(os.geteuid()).pw_gid
    assert user_facts['user_gecos'] == pwd.getpwuid(os.geteuid()).pw_gecos
    assert user_facts['user_dir'] == pwd.getpwuid(os.geteuid()).pw_dir
    assert user_facts['user_shell'] == pwd.getpwuid(os.geteuid()).pw

# Generated at 2022-06-20 20:08:09.660187
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    from ansible.module_utils.facts.collectors.user import UserFactCollector
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()
    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['effective_user_id'] == os.geteuid()

# Generated at 2022-06-20 20:08:11.342621
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ufc = UserFactCollector()
    assert ufc.name == 'user'


# Generated at 2022-06-20 20:08:16.007339
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    u = UserFactCollector()
    assert u.name == 'user'
    assert u.fact_ids == set(['user_id', 'user_uid', 'user_gid',
                              'user_gecos', 'user_dir', 'user_shell',
                              'real_user_id', 'effective_user_id',
                              'effective_group_ids'])


# Test for method UserFactCollector.collect()

# Generated at 2022-06-20 20:08:34.340622
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    user_facts_collector = UserFactCollector()
    user_facts = user_facts_collector.collect(collected_facts=None)

    assert user_facts['real_user_id'] == os.getuid()
    assert user_facts['effective_user_id'] == os.geteuid()
    assert user_facts['user_id'] == getpass.getuser()

# Generated at 2022-06-20 20:08:39.222447
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    """
    Test if the expected facts are collected
    """
    # make sure the expected facts are collected
    fact_collector = UserFactCollector()
    facts = fact_collector.collect()
    assert facts is not None
    assert type(facts) is dict
    assert 'user_id' in facts
    assert 'user_uid' in facts
    assert 'user_gid' in facts
    assert 'user_gecos' in facts
    assert 'user_dir' in facts
    assert 'user_shell' in facts
    assert 'real_user_id' in facts
    assert 'effective_user_id' in facts
    assert 'real_group_id' in facts
    assert 'effective_group_id' in facts
    assert len(facts) == 10

    # make sure the user uid and gid are integers

# Generated at 2022-06-20 20:08:40.073911
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    UserFactCollector().collect()

# Generated at 2022-06-20 20:08:46.388834
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import os
    import os.path
    import shutil
    import tempfile

    test_dir = tempfile.mkdtemp()
    os.chdir(test_dir)


# Generated at 2022-06-20 20:08:55.909988
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert user_fact_collector is not None
    assert user_fact_collector.name == 'user'
    assert len(user_fact_collector._fact_ids) == 9
    assert 'user_id' in user_fact_collector._fact_ids
    assert 'user_uid' in user_fact_collector._fact_ids
    assert 'user_gid' in user_fact_collector._fact_ids
    assert 'user_gecos' in user_fact_collector._fact_ids
    assert 'user_dir' in user_fact_collector._fact_ids
    assert 'user_shell' in user_fact_collector._fact_ids
    assert 'real_user_id' in user_fact_collector._fact_ids

# Generated at 2022-06-20 20:09:06.388032
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_facts = UserFactCollector()  # UserFactCollector Constructor
    assert user_facts is not None     # Verify that the constructor did not return None
    assert user_facts.name == 'user',\
        'Expected UserFactCollector.name to be user, but got {}'.format(user_facts.name)

# Generated at 2022-06-20 20:09:06.774571
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    pass

# Generated at 2022-06-20 20:09:17.135036
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collector = UserFactCollector()
    user_facts = collector.collect()

    assert isinstance(user_facts, dict)

    assert 'user_id' in user_facts
    assert 'user_uid' in user_facts
    assert 'user_gid' in user_facts
    assert 'user_gecos' in user_facts
    assert 'user_dir' in user_facts
    assert 'user_shell' in user_facts
    assert 'real_user_id' in user_facts
    assert 'effective_user_id' in user_facts
    assert 'real_group_id' in user_facts
    assert 'effective_group_id' in user_facts

# Generated at 2022-06-20 20:09:18.910394
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ufc = UserFactCollector()
    assert(ufc is not None)


# Generated at 2022-06-20 20:09:19.685857
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collector = UserFactCollector()
    collector.collect()

# Generated at 2022-06-20 20:09:57.314294
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fc = UserFactCollector()
    user_id = getpass.getuser()
    assert user_id in user_fc.name
    assert 'user_id' in user_fc._fact_ids


# Generated at 2022-06-20 20:10:02.663301
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_collector = UserFactCollector()
    assert user_collector.name == 'user'
    assert user_collector._fact_ids == set(['user_id', 'user_uid', 'user_gid', 'user_gecos', 'user_dir', 'user_shell', 'real_user_id', 'effective_user_id', 'effective_group_ids'])

# Generated at 2022-06-20 20:10:07.124493
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ufc = UserFactCollector()
    assert ufc is not None, 'cannot create UserFactCollector object'

# Generated at 2022-06-20 20:10:10.029785
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    input_module = None
    input_collected_facts = None
    x = UserFactCollector()
    collected_facts = x.collect(module=input_module,
                                collected_facts=input_collected_facts)


# Generated at 2022-06-20 20:10:14.342635
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    u = UserFactCollector()
    assert u.name == 'user'
    assert u._fact_ids == {'user_id', 'user_uid', 'user_gid',
                           'user_gecos', 'user_dir', 'user_shell',
                           'real_user_id', 'effective_user_id',
                           'effective_group_ids'}

# Generated at 2022-06-20 20:10:25.036751
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert 'user' == user_fact_collector.name
    assert 'user_id' in user_fact_collector._fact_ids
    assert 'user_uid' in user_fact_collector._fact_ids
    assert 'user_gid' in user_fact_collector._fact_ids
    assert 'user_gecos' in user_fact_collector._fact_ids
    assert 'user_dir' in user_fact_collector._fact_ids
    assert 'user_shell' in user_fact_collector._fact_ids
    assert 'real_user_id' in user_fact_collector._fact_ids
    assert 'effective_user_id' in user_fact_collector._fact_ids
    assert 'effective_group_ids' in user_

# Generated at 2022-06-20 20:10:31.863815
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts_expect = {'user_id': 'nobody', 'user_uid': 99, 'user_gid': 99,
                         'user_gecos': 'nobody', 'user_dir': '/',
                         'user_shell': '/bin/false', 'real_user_id': 99,
                         'effective_user_id': 99, 'real_group_id': 99,
                         'effective_group_id': 99}
    userFactCollector = UserFactCollector()
    user_facts = userFactCollector.collect()

    assert user_facts == user_facts_expect

# Generated at 2022-06-20 20:10:39.964344
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()

    # Test if the user_id fact exists and if the value is correct
    assert 'user_id' in user_facts
    assert user_facts['user_id'] == getpass.getuser()

    # Test if the user_uid fact exists and if the value is correct
    assert 'user_uid' in user_facts
    assert user_facts['user_uid'] == pwd.getpwuid(os.getuid()).pw_uid
    
    # Test if the user_gid fact exists and if the value is correct
    assert 'user_gid' in user_facts
    assert user_facts['user_gid'] == pwd.getpwuid(os.getuid()).pw_gid

# Generated at 2022-06-20 20:10:44.142120
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    username = "dummyuser"

    # Create dummy class object
    user_collector = UserFactCollector()

    # Call collect method
    user_facts = user_collector.collect()

    # Check user_id
    assert user_facts['user_id'] == username

    # Check user_uid
    assert isinstance(user_facts['user_uid'], int)

    # Check user_gid
    assert isinstance(user_facts['user_gid'], int)

    # Check user_gecos
    assert isinstance(user_facts['user_gecos'], str)

    # Check user_dir
    assert isinstance(user_facts['user_dir'], str)

    # Check user_shell
    assert isinstance(user_facts['user_shell'], str)

    # Check real_user_id

# Generated at 2022-06-20 20:10:46.900222
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    from ansible.module_utils.facts.collectors.user import UserFactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    user = UserFactCollector()
    assert isinstance(user,BaseFactCollector)

# Generated at 2022-06-20 20:12:08.840992
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    assert UserFactCollector.name == 'user'
    assert UserFactCollector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                               'user_gecos', 'user_dir', 'user_shell',
                                               'real_user_id', 'effective_user_id',
                                               'effective_group_ids'])



# Generated at 2022-06-20 20:12:09.698134
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    pass

# Generated at 2022-06-20 20:12:12.258974
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert user_fact_collector.name == 'user'

# Generated at 2022-06-20 20:12:18.673622
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    '''
    Test for User fact collector
    '''
    facter_fact_dict = {
                               'user_id': 'ansible',
                               'user_uid': 1000,
                               'user_gid': 1000,
                               'user_gecos': 'Ansible',
                               'user_dir': '/home/ansible',
                               'user_shell': '/bin/bash',
                               'real_user_id': 1000,
                               'effective_user_id': 1000,
                               'real_group_id': 1000,
                               'effective_group_id': 1000,
                               'effective_group_ids': [1000, 27, 4, 10, 24, 46, 116]
                               }
    fact = UserFactCollector()
    fact_data = fact.collect()

    assert fact_

# Generated at 2022-06-20 20:12:27.817968
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    # Create instance of class UserFactCollector
    user_fc = UserFactCollector()

    # Run method collect
    user_facts = user_fc.collect()

    assert 'user_id' in user_facts
    assert 'user_uid' in user_facts
    assert 'user_gid' in user_facts
    assert 'user_gecos' in user_facts
    assert 'user_dir' in user_facts
    assert 'user_shell' in user_facts
    assert 'real_user_id' in user_facts
    assert 'effective_user_id' in user_facts
    assert 'real_group_id' in user_facts
    assert 'effective_group_id' in user_facts

# Generated at 2022-06-20 20:12:29.963150
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ufc = UserFactCollector()
    assert ufc.name == 'user'
    assert len(ufc._fact_ids) == 10



# Generated at 2022-06-20 20:12:30.791155
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    u = UserFactCollector()



# Generated at 2022-06-20 20:12:37.995864
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = {}
    user_facts['user_id'] = 'gonzalos'
    user_facts['user_uid'] = '1000'
    user_facts['user_gid'] = '1000'
    user_facts['user_gecos'] = 'Gonzalo Sanchez'
    user_facts['user_dir'] = '/home/gonzalos'
    user_facts['user_shell'] = '/bin/bash'
    user_facts['real_user_id'] = '1000'
    user_facts['effective_user_id'] = '1000'
    user_facts['real_group_id'] = '1000'
    user_facts['effective_group_id'] = '1000'

    assert user_facts == UserFactCollector().collect()

# Generated at 2022-06-20 20:12:42.385394
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ubuntu = UserFactCollector()
    assert ubuntu.name == 'user'
    assert ubuntu._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                    'user_gecos', 'user_dir', 'user_shell',
                                    'real_user_id', 'effective_user_id',
                                    'effective_group_ids'])


# Generated at 2022-06-20 20:12:47.921544
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    assert UserFactCollector.name == 'user'
    assert UserFactCollector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                     'user_gecos', 'user_dir', 'user_shell',
                     'real_user_id', 'effective_user_id',
                     'effective_group_ids'])
