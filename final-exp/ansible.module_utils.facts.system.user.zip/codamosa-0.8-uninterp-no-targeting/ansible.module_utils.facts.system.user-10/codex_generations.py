

# Generated at 2022-06-20 20:03:56.512282
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    result = {}

    result['user_id'] = getpass.getuser()
    result['real_user_id'] = os.getuid()
    result['effective_user_id'] = os.geteuid()
    result['real_group_id'] = os.getgid()
    result['effective_group_id'] = os.getgid()

    try:
        pwent = pwd.getpwnam(getpass.getuser())
    except KeyError:
        pwent = pwd.getpwuid(os.getuid())

    result['user_uid'] = pwent.pw_uid
    result['user_gid'] = pwent.pw_gid
    result['user_gecos'] = pwent.pw_gecos
    result['user_dir'] = pwent.pw

# Generated at 2022-06-20 20:04:01.221432
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Setup
    test_obj = UserFactCollector()
    user_id = getpass.getuser()
    pwent = pwd.getpwuid(os.getuid())

    # Execution
    user_facts = test_obj.collect()

    # Assertion
    assert user_id == user_facts['user_id'] and pwent.pw_uid == user_facts['user_uid'] and pwent.pw_gid == user_facts['user_gid']

# Generated at 2022-06-20 20:04:03.699720
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    module = type('', (), {})()
    user_facts = UserFactCollector(module).collect()
    assert isinstance(user_facts, dict)

# Generated at 2022-06-20 20:04:04.701959
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
  assert UserFactCollector.name == 'user'

# Generated at 2022-06-20 20:04:15.414408
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    # The actual call
    user_facts = UserFactCollector().collect()

    # Assert the data type
    assert isinstance(user_facts, dict)

    # Assert the data structure
    assert 'user_uid' in user_facts
    assert 'user_id' in user_facts
    assert 'user_gid' in user_facts
    assert 'user_gecos' in user_facts
    assert 'user_dir' in user_facts
    assert 'user_shell' in user_facts
    assert 'real_user_id' in user_facts
    assert 'effective_user_id' in user_facts
    assert 'real_group_id' in user_facts
    assert 'effective_group_id' in user_facts

# Generated at 2022-06-20 20:04:22.467955
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    userFactCollector = UserFactCollector()

    # Test without any argument
    try:
        userFactCollector.collect()
    except:
        assert True

    # Test with bogus arguments
    assert userFactCollector.collect(5,5) == {}
    assert userFactCollector.collect(5) == {}
    assert userFactCollector.collect(collected_facts = 5) == {}
    assert userFactCollector.collect(collected_facts = {'user_id': 'saju'}) == {}

# Generated at 2022-06-20 20:04:26.752002
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ufc = UserFactCollector()
    assert ufc.name == 'user'
    assert ufc._fact_ids == {'user_id', 'user_uid', 'user_gid',
                             'user_gecos', 'user_dir', 'user_shell',
                             'real_user_id', 'effective_user_id',
                             'effective_group_ids'}

# Generated at 2022-06-20 20:04:34.815980
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fact_collector = UserFactCollector()
    facts = fact_collector.collect()
    assert facts['user_id'] is not None
    assert facts['user_uid'] is not None
    assert facts['user_gid'] is not None
    assert facts['user_gecos'] is not None
    assert facts['user_dir'] is not None
    assert facts['user_shell'] is not None
    assert facts['real_user_id'] is not None
    assert facts['effective_user_id'] is not None
    assert facts['effective_group_ids'] is not None

# Generated at 2022-06-20 20:04:43.637895
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    assert hasattr(UserFactCollector, 'name')
    assert hasattr(UserFactCollector, '_fact_ids')
    assert hasattr(UserFactCollector, 'collect')
    assert UserFactCollector.name == 'user'
    assert ('user_id' in UserFactCollector._fact_ids)
    assert ('user_uid' in UserFactCollector._fact_ids)
    assert ('user_gid' in UserFactCollector._fact_ids)
    assert ('user_gecos' in UserFactCollector._fact_ids)
    assert ('user_dir' in UserFactCollector._fact_ids)
    assert ('user_shell' in UserFactCollector._fact_ids)
    assert ('real_user_id' in UserFactCollector._fact_ids)

# Generated at 2022-06-20 20:04:53.211594
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_facts = UserFactCollector()
    assert 'user_id' in user_facts._fact_ids
    assert 'user_uid' in user_facts._fact_ids
    assert 'user_gid' in user_facts._fact_ids
    assert 'user_gecos' in user_facts._fact_ids
    assert 'user_dir' in user_facts._fact_ids
    assert 'user_shell' in user_facts._fact_ids
    assert 'real_user_id' in user_facts._fact_ids
    assert 'effective_user_id' in user_facts._fact_ids
    assert 'effective_group_ids' in user_facts._fact_ids

# Generated at 2022-06-20 20:04:56.930896
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    obj = UserFactCollector()
    assert obj.name == 'user'

# Unit test to check method collect of class UserFactCollector

# Generated at 2022-06-20 20:04:58.286393
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    assert UserFactCollector().name == 'user'

# Generated at 2022-06-20 20:05:05.792539
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    assert UserFactCollector.name == 'user'
    assert 'user_id' in UserFactCollector._fact_ids
    assert 'user_uid' in UserFactCollector._fact_ids
    assert 'user_gid' in UserFactCollector._fact_ids
    assert 'user_gecos' in UserFactCollector._fact_ids
    assert 'user_dir' in UserFactCollector._fact_ids
    assert 'user_shell' in UserFactCollector._fact_ids
    assert 'real_user_id' in UserFactCollector._fact_ids
    assert 'effective_user_id' in UserFactCollector._fact_ids
    assert 'effective_group_ids' in UserFactCollector._fact_ids

# Generated at 2022-06-20 20:05:06.487380
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    pass

# Generated at 2022-06-20 20:05:18.013110
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Set up parameters
    module = None
    collected_facts = None

    # Test method collect of class UserFactCollector
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect(module, collected_facts)
    assert 'user_id' in user_facts
    assert 'user_uid' in user_facts
    assert 'user_gid' in user_facts
    assert 'user_gecos' in user_facts
    assert 'user_dir' in user_facts
    assert 'user_shell' in user_facts
    assert 'real_user_id' in user_facts
    assert 'effective_user_id' in user_facts
    assert 'real_group_id' in user_facts
    assert 'effective_group_id' in user_facts

# Generated at 2022-06-20 20:05:25.557543
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    module = None
    result = UserFactCollector().collect(module)
    assert result == {'user_id': 'test_user', 'user_uid': '1000', 'user_gid': '1000', 'user_gecos': 'test', 'user_dir': '/home/test_user', 'user_shell': '/bin/bash', 'real_user_id': '1000', 'effective_user_id': '1000', 'real_group_id': '1000', 'effective_group_id': '1000'}

# Generated at 2022-06-20 20:05:27.612836
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    fi = UserFactCollector()
    assert fi
    assert fi.name == 'user'
    return True

#Unit test for collect method of class UserFactCollector

# Generated at 2022-06-20 20:05:33.096535
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    # Test missing user (not logged in)
    user_fact_collector = UserFactCollector()
    user_fact_collector._fact_ids = set()
    user_facts = user_fact_collector.collect()
    assert user_facts['user_id'] == 'root'
    assert user_facts['user_uid'] == 0
    assert user_facts['user_gid'] == 0
    assert user_facts['user_gecos'] == 'root'
    assert user_facts['user_dir'] == '/root'
    assert user_facts['user_shell'] == '/bin/bash'
    assert user_facts['real_user_id'] == 0
    assert user_facts['effective_user_id'] == 0
    assert user_facts['real_group_id'] == 0

# Generated at 2022-06-20 20:05:43.770569
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    class A(BaseFactCollector):
        name = 'a'
        _fact_ids = set(['1', '2'])
    class B(BaseFactCollector):
        name = 'b'
        _fact_ids = set(['3', '4'])
    assert UserFactCollector() is not A() is not B()
    assert UserFactCollector() == A() == B()
    UserFactCollector._fact_ids.add('6')
    assert UserFactCollector() != A() == B()
    A._fact_ids.add('6')
    assert UserFactCollector() == A() != B()
    B._fact_ids.add('6')
    assert UserFactCollector() == A() == B()
    UserFactCollector._fact_ids.discard('6')
    assert UserFactCollector

# Generated at 2022-06-20 20:05:48.401552
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    uf = UserFactCollector()
    assert uf.name == 'user'
    assert uf._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                'user_gecos', 'user_dir', 'user_shell',
                                'real_user_id', 'effective_user_id',
                                'effective_group_ids'])


# Generated at 2022-06-20 20:06:00.268423
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Arrange
    import grp
    import os

    fake_pwd = [('tests.unit', 'x', 1000, 1000, 'tests.unit', '/home/tests.unit', '/bin/bash')]
    fake_grp = [('tests.unit', '*', 1000, ('tests.unit'))]

    # mock out the pwd/grp calls
    old_getpwnam = pwd.getpwnam
    pwd.getpwnam = lambda *args: fake_pwd[0]
    old_getpwuid = pwd.getpwuid
    pwd.getpwuid = lambda *args: fake_pwd[0]

    def fake_getgrall():
        return fake_grp

    old_getgrall = grp.getgrall
    grp.getgr

# Generated at 2022-06-20 20:06:02.984211
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector()
    user_facts.collect()
    assert user_facts.name is 'user'

# Generated at 2022-06-20 20:06:11.155606
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    from ansible.module_utils.facts import FactCollector

    # Create an object of class UserFactCollector
    user_fact_collector = FactCollector.fact_collector_classes['user']()

    # Get the facts
    facts = user_fact_collector.collect()

    # Check if the facts are not None
    assert facts is not None

    # Check the data type of facts
    assert isinstance(facts, dict)

    # Check the facts dictionary
    assert isinstance(facts['user_id'], str)
    assert isinstance(facts['user_uid'], int)
    assert isinstance(facts['user_gid'], int)
    assert isinstance(facts['user_gecos'], str)
    assert isinstance(facts['user_dir'], str)

# Generated at 2022-06-20 20:06:19.825382
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user = UserFactCollector()
    result = user.collect()
    assert result['user_id'] == getpass.getuser()
    assert result['user_uid'] == os.getuid()
    assert result['user_gid'] == os.getgid()
    assert result['user_gecos'] == pwd.getpwuid(os.getuid()).pw_gecos
    assert result['user_dir'] == pwd.getpwuid(os.getuid()).pw_dir
    assert result['user_shell'] == pwd.getpwuid(os.getuid()).pw_shell
    assert result['real_user_id'] == os.getuid()
    assert result['effective_user_id'] == os.geteuid()

# Generated at 2022-06-20 20:06:31.387570
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    obj = UserFactCollector()
    assert obj.name == "user"
    assert obj._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                     'user_gecos', 'user_dir', 'user_shell',
                     'real_user_id', 'effective_user_id',
                     'effective_group_ids'])
    
    try:
        pwent = pwd.getpwnam(getpass.getuser())
    except KeyError:
        pwent = pwd.getpwuid(os.getuid())

    assert obj.collect()['user_id'] == getpass.getuser()
    assert obj.collect()['user_uid'] == pwent.pw_uid
    assert obj.collect()['user_gid'] == pwent.pw_gid

# Generated at 2022-06-20 20:06:39.007219
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    collector = UserFactCollector()
    assert collector is not None
    assert collector.name == 'user'
    assert collector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                       'user_gecos', 'user_dir', 'user_shell',
                                       'real_user_id', 'effective_user_id',
                                       'effective_group_ids'])


# Generated at 2022-06-20 20:06:43.360490
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    assert UserFactCollector.name == 'user'
    assert UserFactCollector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                               'user_gecos', 'user_dir', 'user_shell',
                                               'real_user_id', 'effective_user_id',
                                               'effective_group_ids'])

# Generated at 2022-06-20 20:06:50.476054
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    x = UserFactCollector()
    assert x
    assert x.name == 'user'
    assert x._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                               'user_gecos', 'user_dir', 'user_shell',
                               'real_user_id', 'effective_user_id',
                               'effective_group_ids'])


# Generated at 2022-06-20 20:06:52.059041
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    UserFactCollector.collect()

if __name__ == '__main__':
    test_UserFactCollector()

# Generated at 2022-06-20 20:07:01.132700
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    class MockUserFactCollector(UserFactCollector):
        def __init__(self):
            self.gid = 100
            self.uid = 200
            self.gecos = "Test User"
            self.dir = "/home/test"
            self.shell = "/bin/sh"
            self.user_id = 'test_user'

            self.pwent_uid = 300
            self.pwent_gid = 400
            self.pwent_gecos = "Test User 2"
            self.pwent_dir = "/home/test2"
            self.pwent_shell = "/bin/sh2"

            self.getuid_retval = 500
            self.geteuid_retval = 600
            self.getgid_retval = 700
            self.getegid_retval = 800


# Generated at 2022-06-20 20:07:11.929960
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    assert UserFactCollector.name == 'user'
    assert set(['user_id', 'user_uid', 'user_gid',
                     'user_gecos', 'user_dir', 'user_shell',
                     'real_user_id', 'effective_user_id',
                     'effective_group_ids']).issubset(UserFactCollector._fact_ids)

# Generated at 2022-06-20 20:07:12.442021
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    pass

# Generated at 2022-06-20 20:07:20.320241
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    from ansible.module_utils.facts import search_plugin_name
    from ansible.module_utils.facts.collector import gather_subset

    obj = UserFactCollector()

    facts = gather_subset(obj, search_plugin_name('user'))

    assert facts['user_id'] == facts['real_user_id']
    assert facts['user_id'] == facts['effective_user_id']
    assert facts['user_id'] != facts['real_group_id']
    assert facts['user_id'] != facts['effective_group_id']

# Generated at 2022-06-20 20:07:31.658816
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    from ansible.module_utils.facts import FactCollector

    collected_facts = {}
    test_fact_collector = FactCollector(collected_facts)
    test_collector = UserFactCollector(test_fact_collector)
    test_collector.collect()
    assert 'user_id' in collected_facts
    assert 'user_uid' in collected_facts
    assert 'user_gid' in collected_facts
    assert 'user_gecos' in collected_facts
    assert 'user_dir' in collected_facts
    assert 'user_shell' in collected_facts
    assert 'real_user_id' in collected_facts
    assert 'effective_user_id' in collected_facts
    assert 'real_group_id' in collected_facts
    assert 'effective_group_id' in collected_facts



# Generated at 2022-06-20 20:07:37.170958
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    obj = UserFactCollector()
    assert obj.name == 'user'
    assert obj._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                 'user_gecos', 'user_dir', 'user_shell',
                                 'real_user_id', 'effective_user_id',
                                 'effective_group_ids'])

# Generated at 2022-06-20 20:07:46.593916
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collector = UserFactCollector()

    result = collector.collect()
    assert result['user_id'] == getpass.getuser()
    assert result['user_uid'] == pwd.getpwuid(os.getuid()).pw_uid
    assert result['user_gid'] == pwd.getpwuid(os.getuid()).pw_gid
    assert result['user_gecos'] == pwd.getpwuid(os.getuid()).pw_gecos
    assert result['user_dir'] == pwd.getpwuid(os.getuid()).pw_dir
    assert result['user_shell'] == pwd.getpwuid(os.getuid()).pw_shell
    assert result['real_user_id'] == os.getuid()

# Generated at 2022-06-20 20:07:47.857518
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    '''
    Unit test for constructor of class UserFactCollector
    '''
    # Create object
    obj = UserFactCollector()
    assert obj is not None

# Generated at 2022-06-20 20:07:50.785042
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    us_inst = UserFactCollector()
    assert us_inst.name == 'user'
    assert us_inst._fact_ids == set(['user_id', 'user_uid', 'user_gid', 'user_gecos', 'user_dir', 'user_shell', 'real_user_id', 'effective_user_id', 'effective_group_ids'])
    #assert us_inst.collect() == {}


# Generated at 2022-06-20 20:08:01.241741
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_collector = UserFactCollector()
    user_facts = user_collector.collect()
    assert user_facts['user_id'] == getpass.getuser()
    try:
        pwent = pwd.getpwnam(getpass.getuser())
    except KeyError:
        pwent = pwd.getpwuid(os.getuid())
    assert user_facts['user_uid'] == pwent.pw_uid
    assert user_facts['user_gid'] == pwent.pw_gid
    assert user_facts['user_gecos'] == pwent.pw_gecos
    assert user_facts['user_dir'] == pwent.pw_dir
    assert user_facts['user_shell'] == pwent.pw_shell

# Generated at 2022-06-20 20:08:12.817673
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    # Create a dummy module
    class Module(object):
        pass
    module = Module()

    # Create a dummy collected_facts
    collected_facts = {}

    # Call method
    user_fact_collector = UserFactCollector()
    result = user_fact_collector.collect(module, collected_facts)
    print(result)

    # Assertions
    assert('user_id' in result)
    assert('user_uid' in result)
    assert('user_gid' in result)
    assert('user_gecos' in result)
    assert('user_dir' in result)
    assert('user_shell' in result)
    assert('real_user_id' in result)
    assert('effective_user_id' in result)
    assert('effective_group_ids' in result)

# Generated at 2022-06-20 20:08:30.123568
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector().collect()

    assert user_facts['user_id'] is not None
    assert user_facts['user_uid'] is not None
    assert user_facts['user_gid'] is not None
    assert user_facts['user_gecos'] is not None
    assert user_facts['user_dir'] is not None
    assert user_facts['user_shell'] is not None
    assert user_facts['real_user_id'] is not None
    assert user_facts['effective_user_id'] is not None
    assert user_facts['real_group_id'] is not None
    assert user_facts['effective_group_id'] is not None

# Generated at 2022-06-20 20:08:39.481598
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_collector = UserFactCollector()
    user_facts = user_collector.collect()
    assert type(user_facts) is dict
    assert user_facts['user_id'] is not None
    assert user_facts['user_uid'] is not None
    assert user_facts['user_gid'] is not None
    assert user_facts['user_gecos'] is not None
    assert user_facts['user_dir'] is not None
    assert user_facts['user_shell'] is not None
    assert user_facts['real_user_id'] is not None
    assert user_facts['effective_user_id'] is not None
    assert user_facts['effective_group_ids'] is not None

# Generated at 2022-06-20 20:08:43.339018
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    fact = UserFactCollector()
    assert fact.name == 'user'
    assert fact._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                  'user_gecos', 'user_dir', 'user_shell',
                                  'real_user_id', 'effective_user_id',
                                  'effective_group_ids'])


# Generated at 2022-06-20 20:08:48.523422
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    uf = UserFactCollector()
    assert uf.name == 'user'
    assert uf._fact_ids == {'user_id', 'user_uid', 'user_gid',
                            'user_gecos', 'user_dir', 'user_shell',
                            'real_user_id', 'effective_user_id',
                            'effective_group_ids'}

# Generated at 2022-06-20 20:08:53.600893
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    #Create a new instance of UserFactCollector
    ufc = UserFactCollector()

    #Create variable to store the result of the collect method
    result = ufc.collect()

    #Assert result is not empty
    assert result

    #Assert the result contains user_id variable
    assert 'user_id' in result

    #Assert the result contains gecos variable
    assert 'user_gecos' in result

# Generated at 2022-06-20 20:08:54.612245
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    UserFactCollector().collect()

# Generated at 2022-06-20 20:09:01.579322
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact = UserFactCollector()
    assert user_fact.name == "user"
    assert user_fact._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                       'user_gecos', 'user_dir', 'user_shell',
                                       'real_user_id', 'effective_user_id',
                                       'effective_group_ids'])

# Generated at 2022-06-20 20:09:03.503162
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    obj = UserFactCollector()
    assert isinstance(obj.collect(collected_facts={}), dict)
    assert obj.name == 'user'

# Generated at 2022-06-20 20:09:04.958555
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_facts = UserFactCollector()
    assert (user_facts.name == 'user')

# Generated at 2022-06-20 20:09:08.348204
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    a = UserFactCollector()
    assert a.name == 'user'
    assert a._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                     'user_gecos', 'user_dir', 'user_shell',
                     'real_user_id', 'effective_user_id',
                     'effective_group_ids'])


# Generated at 2022-06-20 20:09:39.834018
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
     user_facts = UserFactCollector().collect()
     assert 'real_user_id' in user_facts
     assert 'effective_user_id' in user_facts
     assert 'effective_group_id' in user_facts
     assert 'user_gid' in user_facts
     assert 'user_gecos' in user_facts
     assert 'user_dir' in user_facts
     assert 'user_shell' in user_facts

# Generated at 2022-06-20 20:09:44.772097
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    obj = UserFactCollector()
    assert obj.name == 'user'
    assert obj._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                 'user_gecos', 'user_dir', 'user_shell',
                                 'real_user_id', 'effective_user_id', 'effective_group_ids'])

# Generated at 2022-06-20 20:09:54.696206
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Make sure that collect actually calls getuser and getpwuid, so that
    # we can be confident that the module will work correctly on other
    # systems.

    import unittest.mock as mock

    userid = 'testuser'
    uid = 12345
    gid = 23456
    comment_field = 'Test User'
    home = '/home/' + userid
    shell = '/bin/bash'
    egid = 223344

    def getpwnam(name):
        class pwent:
            pw_uid = uid
            pw_gid = gid
            pw_gecos = comment_field
            pw_dir = home
            pw_shell = shell

        if name == userid:
            return pwent
        else:
            raise KeyError()


# Generated at 2022-06-20 20:09:56.706973
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collection = UserFactCollector()
    collected_facts = {}
    collection.collect(module=None, collected_facts=collected_facts)
    assert 'user_uid' in collected_facts

# Generated at 2022-06-20 20:09:58.959333
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    result = ufc.collect()
    assert result['user_id'] == getpass.getuser()

# Generated at 2022-06-20 20:10:07.756883
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_collector = UserFactCollector()
    user_facts = user_collector.collect()
    assert user_facts['user_id'] == 'root'
    assert user_facts['user_uid'] == 0
    assert user_facts['user_gid'] == 0
    assert user_facts['user_gecos'] == 'root'
    assert user_facts['user_dir'] == '/root'
    assert user_facts['user_shell'] == '/bin/bash'
    assert user_facts['real_user_id'] == 0
    assert user_facts['effective_user_id'] == 0
    assert user_facts['real_group_id'] == 0
    assert user_facts['effective_group_id'] == 0

# Generated at 2022-06-20 20:10:09.299952
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector().collect()
    assert user_facts['user_id'] == getpass.getuser()

# Generated at 2022-06-20 20:10:14.459004
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    c = UserFactCollector()
    assert c.name == 'user'
    assert c._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                               'user_gecos', 'user_dir', 'user_shell',
                               'real_user_id', 'effective_user_id',
                               'effective_group_ids'])


# Generated at 2022-06-20 20:10:25.092464
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    collected_facts = {}
    collected_facts['os_family'] = 'Linux'
    collected_facts['distribution'] = 'RedHat'
    collected_facts['distribution_major_version'] = '7'
    collected_facts['distribution_version'] = '7.2'
    collected_facts['distribution_version_id'] = '7.2'
    gfc = ufc.collect(collected_facts)
    assert gfc.has_key('user_id') == True
    assert gfc.has_key('user_uid') == True
    assert gfc.has_key('user_gid') == True
    assert gfc.has_key('user_gecos') == True
    assert gfc.has_key('user_dir') == True
    assert gfc

# Generated at 2022-06-20 20:10:35.632649
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_facts = {}
    user_facts['user_id'] = getpass.getuser()
    try:
        pwent = pwd.getpwnam(getpass.getuser())
    except KeyError:
        pwent = pwd.getpwuid(os.getuid())

    user_facts['user_uid'] = pwent.pw_uid
    user_facts['user_gid'] = pwent.pw_gid
    user_facts['user_gecos'] = pwent.pw_gecos
    user_facts['user_dir'] = pwent.pw_dir
    user_facts['user_shell'] = pwent.pw_shell
    user_facts['real_user_id'] = os.getuid()
    user_facts['effective_user_id'] = os.geteu

# Generated at 2022-06-20 20:11:37.638207
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    test_fact_colector = UserFactCollector()

    assert test_fact_colector.name == 'user'
    assert test_fact_colector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                                'user_gecos', 'user_dir', 'user_shell',
                                                'real_user_id', 'effective_user_id',
                                                'effective_group_ids'])


# Generated at 2022-06-20 20:11:48.081946
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_class
    from ansible.module_utils.facts.collector import get_collector_names

    # Get the name of all fact collectors
    names = get_collector_names()

    # Get the user class and run the method collect
    user = get_collector_class('user')
    name = 'user'
    facts = user().collect()

    # assert all names found
    assert name in names, \
           "UserFactCollector not in list of names: %s" % names
    assert name in facts, \
           "UserFactCollector not in list of facts: %s" % facts
    assert 'user_id' in facts['user']

# Generated at 2022-06-20 20:11:54.022015
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user = UserFactCollector()
    user_facts = user.collect()

    assert 'user_id' in user_facts
    assert 'user_uid' in user_facts
    assert 'user_gecos' in user_facts
    assert 'user_dir' in user_facts
    assert 'user_shell' in user_facts
    assert 'real_user_id' in user_facts
    assert 'effective_user_id' in user_facts
    assert 'real_group_id' in user_facts
    assert 'effective_group_id' in user_facts
    assert 'effective_group_ids' in user_facts

# Generated at 2022-06-20 20:11:57.351446
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    collector = UserFactCollector()
    assert collector.name == 'user'
    assert collector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                       'user_gecos', 'user_dir', 'user_shell',
                                       'real_user_id', 'effective_user_id',
                                       'effective_group_ids'])


# Generated at 2022-06-20 20:12:07.031619
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Run the method collect with a mocked module
    result = UserFactCollector.collect(module=None)

    assert result['user_id'] is not None
    assert result['user_uid'] is not None
    assert result['user_gid'] is not None
    assert result['user_gecos'] is not None
    assert result['user_dir'] is not None
    assert result['user_shell'] is not None
    assert result['real_user_id'] is not None
    assert result['effective_user_id'] is not None
    assert result['real_group_id'] is not None
    assert result['effective_group_id'] is not None

# Generated at 2022-06-20 20:12:14.295226
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    print("test collect method of class UserFactCollector")
    module_mock = None
    collected_facts_mock = None
    user_fact_collector_obj = UserFactCollector()
    collected_facts_dict = user_fact_collector_obj.collect(module_mock, collected_facts_mock)
    print("Collected Facts: ", collected_facts_dict)

    assert ('user_id' in collected_facts_dict)
    assert ('user_uid' in collected_facts_dict)
    assert ('user_gid' in collected_facts_dict)
    assert ('user_gecos' in collected_facts_dict)
    assert ('user_dir' in collected_facts_dict)
    assert ('user_shell' in collected_facts_dict)

# Generated at 2022-06-20 20:12:20.672307
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    u = UserFactCollector()
    f = u.collect()
    assert isinstance(f, dict)
    assert set(['user_id', 'user_uid', 'user_gid',
                     'user_gecos', 'user_dir', 'user_shell',
                     'real_user_id', 'effective_user_id',
                     'effective_group_ids']) == set(f.keys())

# Generated at 2022-06-20 20:12:24.862933
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    collector = UserFactCollector()
    assert collector.name == 'user'
    assert collector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                       'user_gecos', 'user_dir', 'user_shell',
                                       'real_user_id', 'effective_user_id',
                                       'effective_group_ids'])

# Generated at 2022-06-20 20:12:34.683135
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    uid = os.getuid()
    user = pwd.getpwuid(uid).pw_name
    group_id = os.getgid()
    group = pwd.getpwuid(uid).pw_name
    userFacts = UserFactCollector()
    collectedUserFacts = userFacts.collect()
    assert collectedUserFacts
    assert collectedUserFacts['real_user_id'] == uid
    assert collectedUserFacts['effective_user_id'] == uid
    assert collectedUserFacts['real_group_id'] == group_id
    assert collectedUserFacts['effective_group_id'] == group_id
    assert collectedUserFacts['user_gid'] == group_id
    assert collectedUserFacts['user_id'] == user

# Generated at 2022-06-20 20:12:35.211458
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    pass