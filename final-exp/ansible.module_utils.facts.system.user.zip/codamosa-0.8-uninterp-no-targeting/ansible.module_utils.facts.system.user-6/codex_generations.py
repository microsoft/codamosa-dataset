

# Generated at 2022-06-20 20:03:46.170085
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    import pytest
    user = UserFactCollector()
    assert user.name == 'user'
    assert user._fact_ids == {'user_id', 'user_uid', 'user_gid',
                              'user_gecos', 'user_dir', 'user_shell',
                              'real_user_id', 'effective_user_id',
                              'effective_group_ids'}


# Generated at 2022-06-20 20:03:51.786239
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    obj = UserFactCollector()
    assert obj.name == 'user'
    assert obj._fact_ids == set(['user_id', 'user_uid', 'user_gid', 'user_gecos', 'user_dir', 'user_shell', 'real_user_id', 'effective_user_id', 'effective_group_ids'])

# Generated at 2022-06-20 20:03:56.840803
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    print("Testing UserFactCollector class constructor")
    tester = UserFactCollector()
    assert tester.name == 'user'
    assert tester._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                     'user_gecos', 'user_dir', 'user_shell',
                     'real_user_id', 'effective_user_id',
                     'effective_group_ids'])



# Generated at 2022-06-20 20:04:00.400481
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    c = UserFactCollector()
    assert c.name == 'user'
    assert c._fact_ids == {'user_id', 'user_uid', 'user_gid',
                           'user_gecos', 'user_dir', 'user_shell',
                           'real_user_id', 'effective_user_id',
                           'effective_group_ids'}

# Generated at 2022-06-20 20:04:03.899479
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_collector = UserFactCollector()
    user_facts = user_collector.collect()
    assert isinstance(user_facts, dict)

# Generated at 2022-06-20 20:04:05.274475
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    c = UserFactCollector()
    output = c.collect()
    assert output

# Generated at 2022-06-20 20:04:12.255164
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    dict_test = {'user_id': None, 'effective_user_id': None, 'user_shell': None, 'user_gid': None, 'user_gecos': None, 'user_dir': None, 'real_user_id': None, 'user_uid': None, 'real_group_id': None, 'effective_group_id': None}
    assert ufc.collect() == dict_test

# Generated at 2022-06-20 20:04:23.189498
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()
    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['user_uid'] == os.getuid()
    assert user_facts['user_gid'] == os.getgid()
    assert user_facts['user_gecos'] == pwd.getpwuid(os.getuid()).pw_gecos
    assert user_facts['user_dir'] == pwd.getpwuid(os.getuid()).pw_dir
    assert user_facts['user_shell'] == pwd.getpwuid(os.getuid()).pw_shell
    assert user_facts['real_user_id'] == os.getuid()
    assert user_facts

# Generated at 2022-06-20 20:04:25.750018
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    test_obj = UserFactCollector()
    result = test_obj.collect()
    print(result)

if __name__ == '__main__':
    #test_UserFactCollector_collect()
    pass

# Generated at 2022-06-20 20:04:32.655962
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert user_fact_collector.name == 'user'
    assert user_fact_collector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                                 'user_gecos', 'user_dir', 'user_shell',
                                                 'real_user_id', 'effective_user_id',
                                                 'effective_group_ids'])


# Generated at 2022-06-20 20:04:42.299929
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Create an instance of the UserFactCollector class
    user_fact_collector = UserFactCollector()

    # Obtain a dictionary of user facts
    user_facts = user_fact_collector.collect(module=None, collected_facts=None)

    # Assert that the method call is successful
    assert isinstance(user_facts, dict)
    assert 'user_id' in user_facts.keys()
    assert 'user_uid' in user_facts.keys()
    assert 'user_gid' in user_facts.keys()
    assert 'user_gecos' in user_facts.keys()
    assert 'user_dir' in user_facts.keys()
    assert 'user_shell' in user_facts.keys()
    assert 'real_user_id' in user_facts.keys()

# Generated at 2022-06-20 20:04:46.720905
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    test_module = {}
    fact_collector = UserFactCollector()
    fact_collector.collect(module=test_module)
    assert fact_collector.name == "user"

# Generated at 2022-06-20 20:04:48.066403
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    """
    collect method of UserFactCollector
    """
    pass

# Generated at 2022-06-20 20:04:49.027989
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    assert UserFactCollector.name == 'user'

# Generated at 2022-06-20 20:04:57.160934
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_collector = UserFactCollector()
    user_facts = user_collector.collect()
    assert 'user_id' in user_facts
    assert 'user_uid' in user_facts
    assert 'user_gid' in user_facts
    assert 'user_gecos' in user_facts
    assert 'user_dir' in user_facts
    assert 'user_shell' in user_facts
    assert 'real_user_id' in user_facts
    assert 'effective_user_id' in user_facts
    assert 'real_group_ids' in user_facts
    assert 'effective_group_ids' in user_facts

# Generated at 2022-06-20 20:04:59.676088
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector()
    assert user_facts.collect()

# Generated at 2022-06-20 20:05:00.953048
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    fc = UserFactCollector()
    assert fc.name == 'user'

# Generated at 2022-06-20 20:05:12.811683
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    result = ufc.collect()
    assert isinstance(result, dict)
    assert result.get('user_id') == 'root'
    assert isinstance(result.get('effective_group_id'), int)
    assert isinstance(result.get('real_group_id'), int)
    assert isinstance(result.get('real_user_id'), int)
    assert isinstance(result.get('effective_user_id'), int)
    assert isinstance(result.get('user_shell'), str)
    assert isinstance(result.get('user_dir'), str)
    assert isinstance(result.get('user_gecos'), str)
    assert isinstance(result.get('user_gid'), int)
    assert isinstance(result.get('user_uid'), int)

# Generated at 2022-06-20 20:05:23.957807
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert user_fact_collector.name == 'user'
    # the constructor of BaseFactCollector appends to this fact_ids so set it to empty
    user_fact_collector._fact_ids = set()

# Generated at 2022-06-20 20:05:28.254678
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    collector = UserFactCollector()
    assert collector.name == 'user'
    assert collector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                       'user_gecos', 'user_dir', 'user_shell',
                                       'real_user_id', 'effective_user_id',
                                       'effective_group_ids'])


# Generated at 2022-06-20 20:05:33.176363
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user = UserFactCollector()
    assert 'user_id' in user.collect()

# Generated at 2022-06-20 20:05:41.382164
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_collector = UserFactCollector()
    assert user_collector.name == 'user'
    print("USerFactCollector() - correct name")
    assert user_collector._fact_ids == {'user_id', 'user_uid',
                                        'user_gid', 'user_gecos',
                                        'user_dir', 'user_shell',
                                        'real_user_id', 'effective_user_id',
                                        'effective_group_ids'}
    print("USerFactCollector() - correct fact_ids")


# Generated at 2022-06-20 20:05:43.526150
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    assert UserFactCollector.name == 'user'
    assert set(UserFactCollector.collect()) == UserFactCollector._fact_ids

# Generated at 2022-06-20 20:05:48.513694
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert user_fact_collector.name == 'user'
    assert user_fact_collector._fact_ids == {'real_group_id', 'user_uid', 'effective_user_id', 'user_dir', 'effective_group_ids', 'user_shell', 'user_gid', 'real_user_id', 'user_gecos', 'user_id'}


# Generated at 2022-06-20 20:05:50.880116
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    try:
        u = UserFactCollector()
    except Exception:
        assert 0, 'UserFactCollector constructor failed.'
    else:
        assert u



# Generated at 2022-06-20 20:05:58.902824
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    filtered_facts = {'user_dir': '/home/ansible', 'real_user_id': 1001,
                      'effective_user_id': 1001, 'real_group_id': 1002,
                      'effective_group_id': 1001, 'user_gid': 1001,
                      'user_uid': 1002, 'user_gecos': 'ansible,123,456,789',
                      'user_shell': '/bin/sh', 'user_id': 'ansible'}
    collected_facts = {}
    u = UserFactCollector()
    returned_facts = u.collect(collected_facts=collected_facts)
    assert returned_facts == filtered_facts

# Generated at 2022-06-20 20:06:09.073540
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collected_facts = {}
    user_facts = UserFactCollector().collect(collected_facts=collected_facts)

    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['user_uid'] == pwd.getpwnam(getpass.getuser()).pw_uid
    assert user_facts['user_gid'] == pwd.getpwnam(getpass.getuser()).pw_gid
    assert user_facts['user_gecos'] == pwd.getpwnam(getpass.getuser()).pw_gecos
    assert user_facts['user_dir'] == pwd.getpwnam(getpass.getuser()).pw_dir

# Generated at 2022-06-20 20:06:16.403200
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    u = UserFactCollector()
    facts = u.collect()
    assert isinstance(facts, dict)
    assert 'user_id' in facts
    assert 'user_uid' in facts
    assert 'user_gid' in facts
    assert 'user_gecos' in facts
    assert 'user_dir' in facts
    assert 'user_shell' in facts
    assert 'real_user_id' in facts
    assert 'effective_user_id' in facts
    assert 'real_group_id' in facts
    assert 'effective_group_id' in facts


# Generated at 2022-06-20 20:06:22.717458
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_facts = UserFactCollector()

    # Ensure that we have all the facts that we need
    assert 'user_id' in user_facts._fact_ids
    assert 'user_uid' in user_facts._fact_ids
    assert 'user_gid' in user_facts._fact_ids
    assert 'user_gecos' in user_facts._fact_ids
    assert 'user_dir' in user_facts._fact_ids
    assert 'user_shell' in user_facts._fact_ids
    assert 'real_user_id' in user_facts._fact_ids
    assert 'effective_user_id' in user_facts._fact_ids
    assert 'effective_group_ids' in user_facts._fact_ids

# Generated at 2022-06-20 20:06:27.409718
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    x = UserFactCollector()
    assert x.name == 'user'
    assert x._fact_ids == {'user_id', 'user_uid', 'user_gid',
                     'user_gecos', 'user_dir', 'user_shell',
                     'real_user_id', 'effective_user_id',
                     'effective_group_ids'}


# Generated at 2022-06-20 20:06:40.887810
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    module = {}

    # Test with empty dict
    collected_facts = {}
    ufc = UserFactCollector()
    user_facts = ufc.collect(module, collected_facts)
    assert user_facts['user_id'] == getpass.getuser()

    # Test with full dict
    collected_facts = {'some_key': 'some_val'}
    user_facts = ufc.collect(module, collected_facts)
    assert user_facts['user_id'] == getpass.getuser()



# Generated at 2022-06-20 20:06:46.894156
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector().collect()

    assert isinstance(user_facts, dict)
    assert user_facts['user_id'] == user_facts['real_user_id']
    assert user_facts['effective_user_id'] == user_facts['real_user_id']
    assert user_facts['effective_group_id'] == user_facts['real_group_id']
    assert user_facts['user_gecos'] == user_facts['user_id']


# Generated at 2022-06-20 20:06:57.406489
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user = UserFactCollector()
    assert user.name == 'user'
    assert user._fact_ids == {'user_id', 'user_uid', 'user_gid', 'user_gecos', 'user_dir', 'user_shell', 'real_user_id', 'effective_user_id', 'effective_group_ids'}
    facts = user.collect()
    assert type(facts) == dict
    assert facts.get('user_id') == getpass.getuser()
    assert facts.get('user_uid') != None
    assert facts.get('user_gid') != None
    assert facts.get('user_gecos') != None
    assert facts.get('user_dir') != None
    assert facts.get('user_shell') != None
    assert facts.get('real_user_id') == os

# Generated at 2022-06-20 20:07:05.117721
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    tc = UserFactCollector()
    user_facts = tc.collect()

    # Check the contents of the 'user_id' fact, expect it's the same as
    # value of '$USER'
    assert user_facts['user_id'] == getpass.getuser()

    # Check the contents of the 'user_uid' fact, expect it's the same as
    # value of '$UID'
    assert user_facts['user_uid'] == os.getuid()

    # Check the contents of the 'user_gid' fact, expect it's the same as
    # value of '$GID'
    assert user_facts['user_gid'] == os.getgid()

    # Check the contents of the 'user_gecos' fact, expect it's the same as
    # value of '$GECOS'
   

# Generated at 2022-06-20 20:07:06.300822
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    collector = UserFactCollector()
    assert collector.name == 'user'
    assert collector.collect()

# Generated at 2022-06-20 20:07:10.511069
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert user_fact_collector.name == 'user'
    assert user_fact_collector._fact_ids == {'effective_group_id', 'user_id', 'effective_user_id', 'user_shell', 'user_gecos', 'user_uid', 'real_group_id', 'user_gid', 'user_dir', 'real_user_id'}


# Generated at 2022-06-20 20:07:11.527868
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    assert isinstance(UserFactCollector(), UserFactCollector)

# Generated at 2022-06-20 20:07:11.959454
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    UserFactCollector()

# Generated at 2022-06-20 20:07:22.173886
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ''' Unit test for method collect of class UserFactCollector '''
    ufc = UserFactCollector()
    user_facts = ufc.collect()
    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['user_uid'] == pwd.getpwuid(os.getuid()).pw_uid
    assert user_facts['user_gid'] == pwd.getpwuid(os.getuid()).pw_gid
    assert user_facts['user_gecos'] == pwd.getpwuid(os.getuid()).pw_gecos
    assert user_facts['user_dir'] == pwd.getpwuid(os.getuid()).pw_dir

# Generated at 2022-06-20 20:07:28.701856
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    assert UserFactCollector.name == 'user'
    assert UserFactCollector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                               'user_gecos', 'user_dir', 'user_shell',
                                               'real_user_id', 'effective_user_id',
                                               'effective_group_ids'])

# Generated at 2022-06-20 20:07:45.897128
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    obj = UserFactCollector()
    assert isinstance(obj, UserFactCollector)
    assert obj.name == 'user'
    assert len(obj._fact_ids) == 9


# Generated at 2022-06-20 20:07:54.009840
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert isinstance(user_fact_collector, BaseFactCollector)
    assert user_fact_collector.name == "user"
    assert user_fact_collector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                                 'user_gecos', 'user_dir', 'user_shell',
                                                 'real_user_id', 'effective_user_id',
                                                 'effective_group_ids'])

# Generated at 2022-06-20 20:07:58.655478
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    obj = UserFactCollector()
    result = obj.collect()
    assert result['effective_user_id'] == os.geteuid()
    assert result['real_user_id'] == os.getuid()
    assert result['user_id'] == getpass.getuser()

# Generated at 2022-06-20 20:08:05.409539
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    userFactCollector = UserFactCollector()
    assert(userFactCollector.name == 'user')
    assert({'user_id', 'user_uid', 'user_gid', 'user_gecos', 'user_dir',
            'user_shell', 'real_user_id', 'effective_user_id',
            'effective_group_ids'} in userFactCollector._fact_ids)

# Generated at 2022-06-20 20:08:15.275411
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector().collect()
    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['user_uid'] == pwd.getpwuid(os.getuid()).pw_uid
    assert user_facts['user_gid'] == pwd.getpwuid(os.getuid()).pw_gid
    assert user_facts['user_gecos'] == pwd.getpwuid(os.getuid()).pw_gecos
    assert user_facts['user_dir'] == pwd.getpwuid(os.getuid()).pw_dir
    assert user_facts['user_shell'] == pwd.getpwuid(os.getuid()).pw_shell
    assert user_facts['real_user_id'] == os

# Generated at 2022-06-20 20:08:20.935320
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    collector = UserFactCollector()
    assert collector.name == 'user'
    assert collector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                     'user_gecos', 'user_dir', 'user_shell',
                     'real_user_id', 'effective_user_id',
                     'effective_group_ids'])


# Generated at 2022-06-20 20:08:21.460673
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    pass

# Generated at 2022-06-20 20:08:23.505186
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_facts = UserFactCollector()
    assert(user_facts.name == 'user')


# Generated at 2022-06-20 20:08:29.566749
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    test_data = UserFactCollector().collect()

    assert getpass.getuser() == test_data['user_id']
    assert os.getuid() == test_data['real_user_id']
    assert os.geteuid() == test_data['effective_user_id']

    try:
        pwent = pwd.getpwnam(getpass.getuser())
    except KeyError:
        pwent = pwd.getpwuid(os.getuid())

    assert pwent.pw_uid == test_data['user_uid']
    assert pwent.pw_gid == test_data['user_gid']
    assert pwent.pw_gecos == test_data['user_gecos']
    assert pwent.pw_dir == test_data['user_dir']

# Generated at 2022-06-20 20:08:33.711046
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    try:
        user_facts = UserFactCollector().collect()
        assert isinstance(user_facts, dict)
    except Exception:
        assert False, 'Unable to instantiate UserFactCollector class'

# Generated at 2022-06-20 20:09:08.970810
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    from ansible.module_utils.facts.collector.user import UserFactCollector
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    import sys
    # save real classes
    real_BaseFactCollector = BaseFactCollector
    real_UserFactCollector = UserFactCollector

    # create mocks
    class mock_BaseFactCollector(BaseFactCollector):
        def __init__(self, *args, **kwargs):
            pass
    class mock_UserFactCollector(UserFactCollector):
        def __init__(self, *args, **kwargs):
            pass
    # replace modules with our mocks
    sys.modules['ansible.module_utils.facts.collector.base'] = mock_BaseFactCollector

# Generated at 2022-06-20 20:09:11.182630
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert user_fact_collector.name == 'user'

# Generated at 2022-06-20 20:09:20.111169
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts = {}
    user_facts = user_fact_collector.collect(collected_facts=user_facts)
    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['user_uid'] == pwd.getpwuid(os.getuid()).pw_uid
    assert user_facts['user_gid'] ==  pwd.getpwuid(os.getuid()).pw_gid
    assert user_facts['user_gecos'] ==  pwd.getpwuid(os.getuid()).pw_gecos
    assert user_facts['user_dir'] ==  pwd.getpwuid(os.getuid()).pw_dir

# Generated at 2022-06-20 20:09:21.276730
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_test = UserFactCollector()
    assert 'user_id' in user_test.collect()

# Generated at 2022-06-20 20:09:21.701829
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
  pass

# Generated at 2022-06-20 20:09:22.880774
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    assert ufc.collect()['user_id'] == getpass.getuser()

# Generated at 2022-06-20 20:09:30.753552
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ufc = UserFactCollector()
    assert ufc.name == 'user'
    assert sorted(ufc._fact_ids) == sorted(['user_id', 'user_uid', 'user_gid',
                                           'user_gecos', 'user_dir', 'user_shell',
                                           'real_user_id', 'effective_user_id',
                                           'effective_group_ids'])


# Generated at 2022-06-20 20:09:33.029459
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()

    user_facts = user_fact_collector.collect()
    assert user_facts['user_id'] == getpass.getuser()

# Generated at 2022-06-20 20:09:40.388597
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import inspect

    # instantiate collector
    c = UserFactCollector()

    # check if constructor is tested
    assert c.name == 'user'
    assert c._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                               'user_gecos', 'user_dir', 'user_shell',
                               'real_user_id', 'effective_user_id',
                               'effective_group_ids'])

    # check if proper methods were called
    m = inspect.getmembers(UserFactCollector())
    assert 'collect' in str(m[3][1])

    # check method return type
    assert isinstance(c.collect(), dict)

# Generated at 2022-06-20 20:09:48.449995
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    user = ufc.collect()
    assert user['user_id'] == getpass.getuser()
    assert user['user_uid'] == pwd.getpwnam(getpass.getuser()).pw_uid
    assert user['user_gid'] == pwd.getpwnam(getpass.getuser()).pw_gid
    assert user['user_gecos'] == pwd.getpwnam(getpass.getuser()).pw_gecos
    assert user['user_dir'] == pwd.getpwnam(getpass.getuser()).pw_dir
    assert user['user_shell'] == pwd.getpwnam(getpass.getuser()).pw_shell


# Generated at 2022-06-20 20:10:52.775883
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_collector = UserFactCollector()
    
    user_facts = user_collector.collect()
    assert user_facts['user_uid'] == os.getuid()
    assert user_facts['user_gid'] == os.getgid()
    assert user_facts['user_gecos'] == pwd.getpwuid(os.getuid()).pw_gecos
    assert user_facts['user_dir'] == pwd.getpwuid(os.getuid()).pw_dir
    assert user_facts['user_shell'] == pwd.getpwuid(os.getuid()).pw_shell
    assert user_facts['real_user_id'] == os.getuid()
    assert user_facts['effective_user_id'] == os.geteuid()
    assert user_facts

# Generated at 2022-06-20 20:10:59.998492
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()

    assert 'user_id' in user_facts
    assert 'user_uid' in user_facts
    assert 'user_gid' in user_facts
    assert 'user_gecos' in user_facts
    assert 'user_dir' in user_facts
    assert 'user_shell' in user_facts
    assert 'real_user_id' in user_facts
    assert 'effective_user_id' in user_facts
    assert 'real_group_id' in user_facts
    assert 'effective_group_id' in user_facts

# Generated at 2022-06-20 20:11:08.138885
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_collector_obj = UserFactCollector()
    assert user_collector_obj.name == 'user'
    assert user_collector_obj._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                                'user_gecos', 'user_dir', 'user_shell',
                                                'real_user_id', 'effective_user_id',
                                                'effective_group_ids'])

# Generated at 2022-06-20 20:11:12.991376
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    fact_info = UserFactCollector()
    assert fact_info.name == 'user'
    assert fact_info._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                       'user_gecos', 'user_dir', 'user_shell',
                                       'real_user_id', 'effective_user_id',
                                       'effective_group_ids'])

# Generated at 2022-06-20 20:11:17.827934
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    assert UserFactCollector().name == 'user'
    assert UserFactCollector()._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                     'user_gecos', 'user_dir', 'user_shell',
                     'real_user_id', 'effective_user_id',
                     'effective_group_ids'])


# Generated at 2022-06-20 20:11:25.731122
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    # Assert that user_fact_collector object is created
    assert user_fact_collector, "UserFactCollector object creation failed"
    # Assert that name is set properly
    assert user_fact_collector.name == 'user', \
        "UserFactCollector object creation: name mismatch"
    # Assert that fact_ids is set properly
    fact_ids = set(['user_id', 'user_uid', 'user_gid',
                    'user_gecos', 'user_dir', 'user_shell',
                    'real_user_id', 'effective_user_id', 'real_group_id',
                    'effective_group_id'])

# Generated at 2022-06-20 20:11:27.834622
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    UserFactCollector.populate()
    assert 'user_id' in UserFactCollector.collect()

# Generated at 2022-06-20 20:11:32.342478
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Create instance of user fact collecter class
    collector = UserFactCollector()

    # Call collect method
    result = collector.collect()

    # Assert the result
    assert 'user_id' in result.keys()
    assert 'user_uid' in result.keys()
    assert 'user_gid' in result.keys()
    assert 'user_gecos' in result.keys()
    assert 'user_dir' in result.keys()
    assert 'user_shell' in result.keys()
    assert 'real_user_id' in result.keys()
    assert 'effective_user_id' in result.keys()
    assert 'effective_group_ids' in result.keys()

# Generated at 2022-06-20 20:11:34.218671
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    collector = UserFactCollector()

    # Test the truthiness of UserFactCollector
    assert collector

# Generated at 2022-06-20 20:11:43.371885
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    u = UserFactCollector()
    assert u.collect()['user_id'] == getpass.getuser()
    assert u.collect()['user_uid'] == os.getuid()
    assert u.collect()['user_gid'] == os.getgid()
    assert u.collect()['user_gecos'] == pwd.getpwuid(os.getuid()).pw_gecos
    assert u.collect()['user_dir'] == pwd.getpwuid(os.getuid()).pw_dir
    assert u.collect()['user_shell'] == pwd.getpwuid(os.getuid()).pw_shell
    assert u.collect()['real_user_id'] == os.getuid()
    assert u.collect()['effective_user_id'] == os.geteu