

# Generated at 2022-06-20 20:03:49.081160
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()
    assert(user_facts['user_id']) == getpass.getuser()
    assert(user_facts['user_uid']) == pwd.getpwnam(getpass.getuser()).pw_uid
    assert(user_facts['user_gid']) == pwd.getpwnam(getpass.getuser()).pw_gid
    assert(user_facts['user_gecos']) == pwd.getpwnam(getpass.getuser()).pw_gecos
    assert(user_facts['user_dir']) == pwd.getpwnam(getpass.getuser()).pw_dir
    assert(user_facts['user_shell']) == p

# Generated at 2022-06-20 20:03:57.592687
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    """Test UserFactCollector class"""
    user_fact_collector = UserFactCollector()
    assert user_fact_collector.name == 'user'
    assert 'user_id' in user_fact_collector._fact_ids
    assert 'user_uid' in user_fact_collector._fact_ids
    assert 'user_gid' in user_fact_collector._fact_ids
    assert 'user_gecos' in user_fact_collector._fact_ids
    assert 'user_dir' in user_fact_collector._fact_ids
    assert 'user_shell' in user_fact_collector._fact_ids
    assert 'real_user_id' in user_fact_collector._fact_ids
    assert 'effective_user_id' in user_fact_collector._fact_ids

# Generated at 2022-06-20 20:04:01.467605
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()

    assert user_fact_collector.name == 'user'
    assert user_fact_collector._fact_ids == ('user_id', 'user_uid', 'user_gid',
                                             'user_gecos', 'user_dir', 'user_shell',
                                             'real_user_id', 'effective_user_id',
                                             'effective_group_ids')

# Generated at 2022-06-20 20:04:12.910729
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()

    assert 'user_id' in user_fact_collector._fact_ids
    assert 'user_uid' in user_fact_collector._fact_ids
    assert 'user_gid' in user_fact_collector._fact_ids
    assert 'user_gecos' in user_fact_collector._fact_ids
    assert 'user_dir' in user_fact_collector._fact_ids
    assert 'user_shell' in user_fact_collector._fact_ids
    assert 'real_user_id' in user_fact_collector._fact_ids
    assert 'effective_user_id' in user_fact_collector._fact_ids
    assert 'effective_group_ids' in user_fact_collector._fact_ids


# Generated at 2022-06-20 20:04:23.622293
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    test_obj = UserFactCollector()
    test_user_facts = test_obj.collect()

    assert type(test_user_facts) is dict
    assert type(test_user_facts['user_id']) is str
    assert type(test_user_facts['user_uid']) is int
    assert type(test_user_facts['user_gid']) is int
    assert type(test_user_facts['user_gecos']) is str
    assert type(test_user_facts['user_dir']) is str
    assert type(test_user_facts['user_shell']) is str
    assert type(test_user_facts['real_user_id']) is int
    assert type(test_user_facts['effective_user_id']) is int

# Generated at 2022-06-20 20:04:25.805483
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()
    print(user_facts)

# Generated at 2022-06-20 20:04:32.692291
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_collector = UserFactCollector()
    name = "user"
    user_fact_ids = {'user_id', 'user_uid', 'user_gid', 'user_gecos', 'user_dir', 'user_shell', 'real_user_id', 'effective_user_id', 'effective_group_ids'}
    assert user_collector.name == name
    assert user_collector._fact_ids == user_fact_ids


# Generated at 2022-06-20 20:04:39.515025
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    uc = UserFactCollector()

    facts_dict = uc.collect()

    keys = ['real_user_id', 'effective_user_id', 'real_group_id', 'effective_group_id', 'user_dir']
    for key in keys:
        assert key in facts_dict
        assert facts_dict[key] is not None
    assert facts_dict['real_user_id']  != facts_dict['effective_user_id']
    assert facts_dict['real_group_id'] != facts_dict['effective_group_id']

# Generated at 2022-06-20 20:04:43.607123
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ufc = UserFactCollector()
    assert ufc.name == 'user'
    assert ufc._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                 'user_gecos', 'user_dir', 'user_shell',
                                 'real_user_id', 'effective_user_id',
                                 'effective_group_ids'])


# Generated at 2022-06-20 20:04:45.796181
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_facts = UserFactCollector()
    assert isinstance(user_facts, UserFactCollector)


# Generated at 2022-06-20 20:04:57.123566
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    user_facts = ufc.collect()
    assert 'user_id' in user_facts
    assert 'user_uid' in user_facts
    assert 'user_gid' in user_facts
    assert 'user_gecos' in user_facts
    assert 'user_dir' in user_facts
    assert 'user_shell' in user_facts
    assert 'real_user_id' in user_facts
    assert 'effective_user_id' in user_facts
    assert 'real_group_id' in user_facts
    assert 'effective_group_id' in user_facts

# Generated at 2022-06-20 20:04:59.237661
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    userCollector = UserF

# Generated at 2022-06-20 20:05:01.305972
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    test_obj = UserFactCollector()
    result = test_obj.collect()
    # This is just to show that you can test your facts
    assert(type(result['user_uid']) == int)


# Generated at 2022-06-20 20:05:07.081314
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    obj = UserFactCollector()
    assert obj.name == 'user'
    assert obj._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                 'user_gecos', 'user_dir', 'user_shell',
                                 'real_user_id', 'effective_user_id',
                                 'effective_group_ids'])



# Generated at 2022-06-20 20:05:15.105430
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
  user_facts = UserFactCollector()
  assert user_facts.name == "user"
  assert user_facts.allowed_values == set(['user_id', 'user_uid', 'user_gid',
                     'user_gecos', 'user_dir', 'user_shell',
                     'real_user_id', 'effective_user_id',
                     'effective_group_ids'])
  assert user_facts.allowed_types == set(['str','int','list','bool','float'])


# Generated at 2022-06-20 20:05:26.083790
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fake_module = None
    fake_module_args = None
    fake_ansible_module = None
    fake_ansible_module_args = None
    user_fact_collector = UserFactCollector()
    fact_list = user_fact_collector.collect(fake_module, fake_ansible_module, fake_ansible_module_args)

# Generated at 2022-06-20 20:05:29.727856
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    u = UserFactCollector()
    assert u.name == 'user'
    assert u._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                               'user_gecos', 'user_dir', 'user_shell',
                               'real_user_id', 'effective_user_id',
                               'effective_group_ids'])

# Generated at 2022-06-20 20:05:33.023295
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    assert(UserFactCollector.name == 'user')
    assert('effective_group_ids' in UserFactCollector._fact_ids)
    assert(len(UserFactCollector._fact_ids) == 9)

# Generated at 2022-06-20 20:05:43.740544
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    test_collector = UserFactCollector()
    test_user_facts = test_collector.collect()
    test_collector._fact_ids.add('real_group_id')

# Generated at 2022-06-20 20:05:48.363910
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_facts = UserFactCollector()
    assert user_facts.name == 'user'
    assert user_facts._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                     'user_gecos', 'user_dir', 'user_shell',
                     'real_user_id', 'effective_user_id',
                     'real_group_id', 'effective_group_id'])

# Generated at 2022-06-20 20:05:56.203216
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    pass

# Generated at 2022-06-20 20:06:04.505623
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():

    from ansible.module_utils.facts.collectors import UserFactCollector
    user_collector = UserFactCollector()

    assert user_collector.name == 'user'
    assert user_collector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                            'user_gecos', 'user_dir', 'user_shell',
                                            'real_user_id', 'effective_user_id',
                                            'effective_group_ids'])


# Generated at 2022-06-20 20:06:12.111325
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors.user import UserFactCollector
    # create object
    obj = UserFactCollector()
    # verify it is an instance of the correct class
    assert isinstance(obj, UserFactCollector)
    # parent
    assert isinstance(obj, Collector)
    # verify some members
    assert hasattr(obj, 'name')
    assert obj.name == 'user'
    assert hasattr(obj, '_fact_ids')
    assert len(obj._fact_ids) == 10
    assert 'user_id' in obj._fact_ids
    assert 'user_uid' in obj._fact_ids
    assert 'user_gid' in obj._fact_ids
    assert 'user_gecos' in obj._fact

# Generated at 2022-06-20 20:06:19.558578
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_col = UserFactCollector()
    user_facts = user_fact_col.collect()
    assert isinstance(user_facts, dict)
    assert 'user_id' in user_facts
    assert 'user_uid' in user_facts
    assert 'user_gid' in user_facts
    assert 'user_gecos' in user_facts
    assert 'user_dir' in user_facts
    assert 'user_shell' in user_facts
    assert 'real_user_id' in user_facts
    assert 'effective_user_id' in user_facts
    assert 'real_group_id' in user_facts
    assert 'effective_group_id' in user_facts

# Generated at 2022-06-20 20:06:21.830038
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ufc = UserFactCollector()
    assert ufc.name == "user"

# Generated at 2022-06-20 20:06:27.134939
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    assert UserFactCollector.name == 'user'
    assert UserFactCollector._fact_ids == set(['user_id', 'user_uid', 'user_gid', \
    'user_gecos', 'user_dir', 'user_shell', 'real_user_id', 'effective_user_id', \
    'effective_group_ids'])


# Generated at 2022-06-20 20:06:37.794972
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import ansible.module_utils.facts.system.user
    ansible.module_utils.facts.system.user.pwd = __mock_pwd()
    user_facts = UserFactCollector().collect()
    assert type(user_facts) is dict
    assert user_facts['user_dir'] == '/home/fake_user'
    assert user_facts['user_gid'] == 500
    assert user_facts['user_gecos'] == 'Mocked User,,,'
    assert user_facts['user_id'] == 'fake_user'
    assert user_facts['user_shell'] == '/bin/bash'
    assert user_facts['user_uid'] == 500
    assert user_facts['effective_group_id'] == 500
    assert user_facts['effective_user_id'] == 500

# Generated at 2022-06-20 20:06:42.903278
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    module = MagicMock()
    collected_facts = {}
    collector = UserFactCollector()
    facts = collector.collect(module, collected_facts)
    assert set(facts.keys()) == set(['user_id', 'user_uid', 'user_gid',
                                     'user_gecos', 'user_dir', 'user_shell',
                                     'real_user_id', 'effective_user_id',
                                     'real_group_id', 'effective_group_id'])

# Generated at 2022-06-20 20:06:44.599432
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector().collect()
    assert user_facts.get('user_id') == getpass.getuser()

# Generated at 2022-06-20 20:06:55.299362
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import __builtin__
    import pwd

    user_id_fact = 'admin'
    user_uid_fact = 123456
    user_gid_fact = 123456
    user_gecos_fact = 'admin,Admin,1,1,Acme,Inc.,admin@acme.com'
    user_dir_fact = '/home/admin'
    user_shell_fact = '/bin/sh'
    real_user_id_fact = 123456
    effective_user_id_fact = 123456
    real_group_id_fact = 123456
    effective_group_id_fact = 123456

    class UserFactCollectorTest(UserFactCollector):
        def __init__(self):
            pass

    class MockGetpassGetuser(object):
        def getuser(self):
            return user_id_

# Generated at 2022-06-20 20:07:07.793331
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    u = UserFactCollector()
    assert u.name == 'user'
    assert u._fact_ids == {'user_id', 'user_uid', 'user_gid',
                           'user_gecos', 'user_dir', 'user_shell',
                           'real_user_id', 'effective_user_id',
                           'effective_group_ids'}

# Generated at 2022-06-20 20:07:10.884083
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact = UserFactCollector()
    assert user_fact.name == "user"
    assert set(user_fact.collect().keys()) == user_fact._fact_ids


# Generated at 2022-06-20 20:07:17.701707
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert user_fact_collector.name == 'user'
    assert user_fact_collector._fact_ids == set(['user_id', 'user_uid',
                                                 'user_gid', 'user_gecos',
                                                 'user_dir', 'user_shell',
                                                 'real_user_id',
                                                 'effective_user_id',
                                                 'effective_group_ids'])


# Generated at 2022-06-20 20:07:29.146392
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import unittest

    # Create an instance of the UserFactCollector class
    user_collector = UserFactCollector()

    # Call the method collect of class UserFactCollector
    user_facts = user_collector.collect()

    # Make sure that the returned user_facts is a list.
    assert type(user_facts) == type({})

    # Make sure that all the facts that are returned is in the set
    # of facts that are to be collected by this collector
    assert user_collector._fact_ids.issubset(set(user_facts.keys()))

    # Make sure that the returned user_id is a string
    assert type(user_facts['user_id']) == type('')

    # Make sure that the returned user_uid is an integer
    assert type(user_facts['user_uid'])

# Generated at 2022-06-20 20:07:35.571668
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    # create instance of UserFactCollector
    user_fact_collector = UserFactCollector()

    # check type of user_fact_collector
    assert isinstance(user_fact_collector, UserFactCollector)
    # check user_fact_collector.name
    assert user_fact_collector.name == 'user'
    # check user_fact_collector._fact_ids is set
    assert isinstance(user_fact_collector._fact_ids, set)

# Generated at 2022-06-20 20:07:36.320087
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    pass

# Generated at 2022-06-20 20:07:46.050644
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    assert getpass.getuser() == 'vagrant'
    assert os.getuid() == 1000
    assert os.geteuid() == 1000
    assert os.getgid() == 1000

    collector = UserFactCollector()
    facts = collector.collect()

    assert facts.get('user_id') == 'vagrant'
    assert facts.get('user_uid') == 1000
    assert facts.get('user_gid') == 1000
    assert facts.get('user_gecos') == 'vagrant,,,'
    assert facts.get('user_dir') == '/home/vagrant'
    assert facts.get('user_shell') == '/bin/bash'
    assert facts.get('real_user_id') == 1000
    assert facts.get('effective_user_id') == 1000

# Generated at 2022-06-20 20:07:48.807405
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    test_instance = UserFactCollector()
    collected_facts = {}
    assert isinstance(test_instance.collect(collected_facts=collected_facts), dict)


# Generated at 2022-06-20 20:07:55.106123
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    obj = UserFactCollector()
    assert obj.name == 'user'
    assert obj._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                 'user_gecos', 'user_dir', 'user_shell',
                                 'real_user_id', 'effective_user_id',
                                 'effective_group_ids'])


# Generated at 2022-06-20 20:08:00.880540
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ufc = UserFactCollector()
    assert ufc.name == 'user'
    assert ufc._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                 'user_gecos', 'user_dir', 'user_shell',
                                 'real_user_id', 'effective_user_id',
                                 'effective_group_ids'])

# Generated at 2022-06-20 20:08:21.018292
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    collected_facts = {}
    collected_facts = user_fact_collector.collect(collected_facts)
    assert collected_facts['user_id'] == getpass.getuser()
    assert collected_facts['user_shell'] ==  pwd.getpwnam(getpass.getuser()).pw_shell

# Generated at 2022-06-20 20:08:22.912238
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collector = UserFactCollector()
    data = collector.collect()
    assert data['user_id'] == getpass.getuser()

# Generated at 2022-06-20 20:08:29.489094
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    """
    Test if collect method of UserFactCollector class works properly. Also
    verify if all the facts are present in the returned dictionary.
    """
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()

    assert isinstance(user_facts, dict), "User facts are not of type dictionary"
    assert user_facts['user_id'] == getpass.getuser(), "User fact 'user_id' is not correct."
    assert user_facts['user_uid'] == pwd.getpwuid(os.getuid()).pw_uid, "User fact 'user_uid' is not correct."

# Generated at 2022-06-20 20:08:36.067196
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert user_fact_collector.name == 'user'
    assert user_fact_collector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                     'user_gecos', 'user_dir', 'user_shell',
                     'real_user_id', 'effective_user_id',
                     'effective_group_ids'])

# Generated at 2022-06-20 20:08:37.375376
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    testobj = UserFactCollector()
    testobj.collect()

# Generated at 2022-06-20 20:08:44.649494
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ufc = UserFactCollector()
    assert ufc.name == 'user'
    assert isinstance(ufc._fact_ids, set)
    assert len(ufc._fact_ids) == 10
    assert 'user_id' in ufc._fact_ids
    assert 'user_uid' in ufc._fact_ids
    assert 'user_gid' in ufc._fact_ids
    assert 'user_gecos' in ufc._fact_ids
    assert 'user_dir' in ufc._fact_ids
    assert 'user_shell' in ufc._fact_ids
    assert 'real_user_id' in ufc._fact_ids
    assert 'effective_user_id' in ufc._fact_ids
    assert 'real_group_id' in ufc._fact_ids

# Generated at 2022-06-20 20:08:49.729941
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user = UserFactCollector()
    assert user.name == 'user'
    assert user._fact_ids == set(['user_id', 'user_uid', 'user_gid',
        'user_gecos', 'user_dir', 'user_shell', 'real_user_id',
        'effective_user_id', 'effective_group_ids'])

# Generated at 2022-06-20 20:08:55.405413
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    test_obj = UserFactCollector()
    user_facts = test_obj.collect()

    #assert(user_facts['user_id'] == getpass.getuser())
    #assert(user_facts['user_uid'] == pwd.getpwnam(getpass.getuser()).pw_uid)
    #assert(user_facts['user_gid'] == pwd.getpwnam(getpass.getuser()).pw_gid)

# Generated at 2022-06-20 20:09:05.036732
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Setup
    testobject = UserFactCollector()

    # Execute
    result = testobject.collect()

    # Verify
    assert result is not None
    assert result['user_id'] is not None
    assert result['user_uid'] is not None
    assert result['user_gid'] is not None
    assert result['user_gecos'] is not None
    assert result['user_dir'] is not None
    assert result['user_shell'] is not None
    assert result['real_user_id'] is not None
    assert result['effective_user_id'] is not None
    assert result['real_group_id'] is not None
    assert result['effective_group_id'] is not None

# Generated at 2022-06-20 20:09:10.096374
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    factCollector = UserFactCollector()
    user_facts = factCollector.collect()
    assert user_facts['user_id'] == getpass.getuser()
    try:
        pwent = pwd.getpwnam(getpass.getuser())
    except KeyError:
        pwent = pwd.getpwuid(os.getuid())
    assert user_facts['user_uid'] == pwent.pw_uid
    assert user_facts['user_gid'] == pwent.pw_gid
    assert user_facts['user_gecos'] == pwent.pw_gecos
    assert user_facts['user_dir'] == pwent.pw_dir
    assert user_facts['user_shell'] == pwent.pw_shell
    assert user_facts['real_user_id']

# Generated at 2022-06-20 20:09:47.281693
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    uc = UserFactCollector()
    assert isinstance(uc, UserFactCollector)
    assert uc.name == 'user'
    assert uc._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                'user_gecos', 'user_dir', 'user_shell',
                                'real_user_id', 'effective_user_id',
                                'effective_group_ids'])


# Generated at 2022-06-20 20:09:53.189524
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ufc = UserFactCollector()
    assert ufc.name == 'user'
    assert ufc._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                 'user_gecos', 'user_dir', 'user_shell',
                                 'real_user_id', 'effective_user_id',
                                 'effective_group_ids'])


# Generated at 2022-06-20 20:09:55.281797
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    collector = UserFactCollector()
    assert collector.name == "user"



# Generated at 2022-06-20 20:10:04.100416
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collected_facts = {}
    fact_collector = UserFactCollector()
    fact_collector.collect(collected_facts=collected_facts)

    assert 'user_id' in collected_facts
    assert 'user_uid' in collected_facts
    assert 'user_gid' in collected_facts
    assert 'user_gecos' in collected_facts
    assert 'user_dir' in collected_facts
    assert 'user_shell' in collected_facts
    assert 'real_user_id' in collected_facts
    assert 'effective_user_id' in collected_facts
    assert 'real_group_id' in collected_facts
    assert 'effective_group_id' in collected_facts

# Generated at 2022-06-20 20:10:13.261862
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_facts = UserFactCollector()
    assert  len(user_facts._fact_ids) == 9
    assert 'user_id' in user_facts._fact_ids
    assert 'user_uid' in user_facts._fact_ids
    assert 'user_gid' in user_facts._fact_ids
    assert 'user_gecos' in user_facts._fact_ids
    assert 'user_dir' in user_facts._fact_ids
    assert 'user_shell' in user_facts._fact_ids
    assert 'real_user_id' in user_facts._fact_ids
    assert 'effective_user_id' in user_facts._fact_ids
    assert 'effective_group_ids' in user_facts._fact_ids


# Generated at 2022-06-20 20:10:24.344279
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    import time
    import sys
    import os

    # Fake the values of getuid, geteuid, getgid, getegid, getpwnam and getpwuid since these methods
    # are not available in a unit test.
    orig_pwuid = os.getuid
    orig_geteuid = os.geteuid
    orig_getgid = os.getgid
    orig_getegid = os.getegid
    orig_pwd_getpwnam = pwd.getpwnam
    orig_getpwuid = pwd.getpwuid

    fake_uid = 1234
    fake_getuid = lambda: fake_uid
    fake_euid = 5678
    fake_geteuid = lambda: fake_euid
    fake_gid = 5678
    fake_get

# Generated at 2022-06-20 20:10:24.879949
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    pass

# Generated at 2022-06-20 20:10:28.173428
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()

    collected_facts = {}

    assert type(user_fact_collector.collect(collected_facts)) is dict
    assert 'user_id' in user_fact_collector.collect(collected_facts)

# Generated at 2022-06-20 20:10:34.499046
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_collector = UserFactCollector()
    # Test that the user_collector is a UserFactCollector object
    assert(isinstance(user_collector, UserFactCollector))
    # Test that user_collector is a BaseFactCollector object
    assert(isinstance(user_collector, BaseFactCollector))
    # Test that user_collector is not a PgFactCollector object
    assert(not isinstance(user_collector, 'PgFactCollector'))

# Generated at 2022-06-20 20:10:36.977501
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()
    assert user_facts['user_id'] == getpass.getuser()


# Generated at 2022-06-20 20:11:50.663845
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    user_facts = ufc.collect()
    assert len(user_facts) != 0

# Generated at 2022-06-20 20:11:51.140924
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    pass

# Generated at 2022-06-20 20:11:57.995945
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    from ansible.module_utils.facts.collector import CollectorsProcess
    from ansible.module_utils.facts.collector.user import UserFactCollector
    from ansible.module_utils._text import to_text

    fact_collector = CollectorsProcess(UserFactCollector())
    fact_collector.start()
    tests_collected_facts = fact_collector.get_collected_facts()
    assert "user" in tests_collected_facts
    assert "user_id" in tests_collected_facts["user"]
    assert "user_uid" in tests_collected_facts["user"]
    assert "user_gid" in tests_collected_facts["user"]
    assert "user_gecos" in tests_collected_facts["user"]
    assert "user_dir" in tests_collected

# Generated at 2022-06-20 20:12:08.622792
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import platform
    import tempfile
    import pwd
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary user
    pw = pwd.getpwnam('root')
    os.chown(tmpdir, pw.pw_uid, pw.pw_gid)

    # Run command as the created temporary user
    os.setuid(pw.pw_uid)
    os.setgid(pw.pw_gid)

    # Test the method collect of class UserFactCollector
    ufc = UserFactCollector()
    result = ufc.collect()

    assert result['user_id'] == 'root'
    assert result['user_uid'] == 0
    assert result['user_gid'] == 0
    assert result

# Generated at 2022-06-20 20:12:17.510546
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    user_fact_collector_id = user_fact_collector.name
    user_fact_collector_ids = user_fact_collector.collect()
    assert id == user_fact_collector_id
    assert 'user_id' in user_fact_collector_ids
    assert 'user_uid' in user_fact_collector_ids
    assert 'user_gid' in user_fact_collector_ids
    assert 'user_gecos' in user_fact_collector_ids
    assert 'user_dir' in user_fact_collector_ids
    assert 'user_shell' in user_fact_collector_ids
    assert 'real_user_id' in user_fact_collector_ids

# Generated at 2022-06-20 20:12:25.952204
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    userFacts = UserFactCollector().collect()
    assert isinstance(userFacts, dict)
    assert len(userFacts) == 8
    assert isinstance(userFacts['user_id'], str)
    assert isinstance(userFacts['user_uid'], int)
    assert isinstance(userFacts['user_gid'], int)
    assert isinstance(userFacts['user_gecos'], str)
    assert isinstance(userFacts['user_dir'], str)
    assert isinstance(userFacts['user_shell'], str)
    assert isinstance(userFacts['real_user_id'], int)
    assert isinstance(userFacts['effective_user_id'], int)

# Generated at 2022-06-20 20:12:29.296768
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    facts = {}
    fact_collector = UserFactCollector()
    fact_collector.collect(None, facts)
    assert facts.get('user_id') == getpass.getuser()


# Generated at 2022-06-20 20:12:31.051965
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collector = UserFactCollector()
    result = collector.collect()
    assert result['user_id'] == getpass.getuser()

# Generated at 2022-06-20 20:12:38.764598
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import sys
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.user import UserFactCollector

    # Set up some inputs
    collected_facts = dict()

    # Create the UserFactCollector object
    fact_collector = UserFactCollector(module=None, collected_facts=collected_facts)

    # Call collect with our inputs
    facts = fact_collector.collect()

    # Compare results
    assert 'user_id' in facts
    assert 'user_uid' in facts
    assert 'user_gid' in facts
    assert 'user_gecos' in facts
    assert 'user_dir' in facts
    assert 'user_shell' in facts
    assert 'real_user_id' in facts

# Generated at 2022-06-20 20:12:40.526102
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user = UserFactCollector()
    user_facts = user.collect()
    
    assert user_facts['user_id'] == getpass.getuser()