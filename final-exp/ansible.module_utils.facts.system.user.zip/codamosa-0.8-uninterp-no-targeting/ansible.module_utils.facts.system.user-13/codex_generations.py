

# Generated at 2022-06-20 20:03:52.467186
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    fact = UserFactCollector()
    assert fact.name == 'user'
    assert fact._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                  'user_gecos', 'user_dir', 'user_shell',
                                  'real_user_id', 'effective_user_id',
                                  'effective_group_ids'])


# Generated at 2022-06-20 20:03:54.923078
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    assert user_fact_collector.collect() != None


# Generated at 2022-06-20 20:04:02.060165
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    """Unit test for method ``UserFactCollector.collect`` for class ``UserFactCollector``"""

    import pwd
    from ansible.module_utils.facts.collector import BaseFactCollector

    from ansible.module_utils.facts.virtual import UserFactCollector

    def mock_getpwnam(username):
        """Mock method ``getpwnam`` of module ``pwd``"""
        class struct_passwd():
            pw_name = 'mock_user'
            pw_passwd = 'x'
            pw_uid = 0
            pw_gid = 0
            pw_gecos = ''
            pw_dir = '/home/mock_user'
            pw_shell = '/bin/bash'

        fake_user = struct_passwd()

        return fake_user



# Generated at 2022-06-20 20:04:03.566251
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    # Test with no arg
    ufc = UserFactCollector()
    assert ufc is not None

    # Test with arg
    ufc = UserFactCollector(None)
    assert ufc is not None

# Generated at 2022-06-20 20:04:04.196193
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
  pass

# Generated at 2022-06-20 20:04:10.570831
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    obj = UserFactCollector()
    assert obj.name == 'user'
    assert set(obj._fact_ids) == set(['user_id', 'user_uid', 'user_gid',
                                      'user_gecos', 'user_dir', 'user_shell',
                                      'real_user_id', 'effective_user_id',
                                      'effective_group_ids'])

# Generated at 2022-06-20 20:04:11.952291
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user = UserFactCollector()
    user.collect()
    assert user.collect()['real_user_id'] == os.getuid()

# Generated at 2022-06-20 20:04:22.733905
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()

    user_facts = user_fact_collector.collect()

    assert user_facts['user_id'] != ""
    # On some systems effective_user_id and user_id can be different
    #assert user_facts['user_id'] == user_facts['effective_user_id']
    assert user_facts['real_user_id'] == user_facts['effective_user_id']
    assert user_facts['real_group_id'] == user_facts['effective_group_id']
    assert user_facts['user_uid'] > 0
    assert user_facts['user_gid'] > 0
    assert user_facts['user_gecos'] != ""
    assert user_facts['user_dir'] != ""
    assert user_facts['user_shell'] != ""

# Generated at 2022-06-20 20:04:25.018786
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    _UserFactCollector = UserFactCollector()
    assert _UserFactCollector.name == "user"

# Generated at 2022-06-20 20:04:27.120386
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ''' User fact collection method testcase '''
    user_fact_collector = UserFactCollector()
    user_fact_collector.collect()

# Generated at 2022-06-20 20:04:30.665210
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    userfact = UserFactCollector()
    assert isinstance(userfact.name, str)
    assert isinstance(userfact._fact_ids, set)

# Generated at 2022-06-20 20:04:40.239756
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    """Unit test for method collect of class UserFactCollector"""
    user_facts = UserFactCollector().collect()
    print("user_facts:\n" + "".join(["{}: {}\n".format(key, val)
                                     for key, val in user_facts.items()]))
    assert 'user_id' in user_facts
    assert 'user_uid' in user_facts
    assert 'user_gid' in user_facts
    assert 'user_gecos' in user_facts
    assert 'user_dir' in user_facts
    assert 'user_shell' in user_facts
    assert 'real_user_id' in user_facts
    assert 'effective_user_id' in user_facts
    assert 'effective_group_ids' in user_facts

# Generated at 2022-06-20 20:04:44.098858
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    obj = UserFactCollector()
    assert obj.name == 'user'
    assert obj._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                 'user_gecos', 'user_dir', 'user_shell',
                                 'real_user_id', 'effective_user_id',
                                 'effective_group_ids'])


# Generated at 2022-06-20 20:04:49.965584
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user = UserFactCollector()
    assert user.name == 'user'
    assert user._fact_ids == set(['user_id', 'user_uid', 'user_gid', 
                                  'user_gecos', 'user_dir', 'user_shell', 
                                  'real_user_id', 'effective_user_id', 'effective_group_ids'])

#TODO: Add test for function collect in UserFactCollector class

# Generated at 2022-06-20 20:04:50.456123
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fact_collector = UserF

# Generated at 2022-06-20 20:04:59.333225
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector()

    result = user_facts.collect()

    assert('user_id' in result)
    assert('user_uid' in result)
    assert('user_gid' in result)
    assert('user_gecos' in result)
    assert('user_dir' in result)
    assert('user_shell' in result)
    assert('real_user_id' in result)
    assert('effective_user_id' in result)
    assert('real_group_id' in result)
    assert('effective_group_id' in result)


# Generated at 2022-06-20 20:05:00.953051
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    userFactCollector = UserFactCollector()
    assert userFactCollector.name == 'user'

# Generated at 2022-06-20 20:05:02.411176
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fact_collector = UserFactCollector()
    fact_collector.collect()


# Generated at 2022-06-20 20:05:10.391276
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    assert UserFactCollector.name == 'user'
    assert UserFactCollector._fact_ids == set(['user_id', 'user_uid',
                                               'user_gid', 'user_gecos',
                                               'user_dir', 'user_shell',
                                               'real_user_id',
                                               'effective_user_id',
                                               'effective_group_ids'])


# Generated at 2022-06-20 20:05:16.161598
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    collected_facts = user_fact_collector.collect()
    #check if the facts are collected
    fact_ids = collected_facts.keys()
    assert len(fact_ids) > 0
    #check if the collected facts are valid
    for fact_name in user_fact_collector._fact_ids:
        assert fact_name in fact_ids
    


# Generated at 2022-06-20 20:05:28.719315
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    o = UserFactCollector()
    # Does the constructor create a non-empty, non-None object?
    assert o is not None, "UserFactCollector constructor returned None."
    assert o, "UserFactCollector constructor returned empty object."
    # Does the constructor set the expected attributes?
    assert isinstance(o.name, str), \
            "UserFactCollector.name is not a string."
    assert o.name, "UserFactCollector.name is empty."
    assert isinstance(o._fact_ids, set), \
            "UserFactCollector._fact_ids is not a set."
    assert o._fact_ids, \
            "UserFactCollector._fact_ids is empty."
    # Does the constructor return a different object each time?

# Generated at 2022-06-20 20:05:40.427448
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    facts = ufc.collect()
    assert 'user_id' in facts
    assert 'user_uid' in facts
    assert 'user_gid' in facts
    assert 'user_gecos' in facts
    assert 'user_dir' in facts
    assert 'user_shell' in facts
    assert 'real_user_id' in facts
    assert 'effective_user_id' in facts
    assert 'real_group_id' in facts
    assert 'effective_group_id' in facts
    assert 'user_id' == facts['user_id']
    assert 'user_uid' == facts['user_uid']
    assert 'user_gid' == facts['user_gid']
    assert 'user_gecos' == facts['user_gecos']

# Generated at 2022-06-20 20:05:44.831366
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_id = getpass.getuser()
    test_UserFactCollector = UserFactCollector()
    assert 'user_id' in test_UserFactCollector.collect()
    assert test_UserFactCollector.collect()['user_id'] == user_id



# Generated at 2022-06-20 20:05:56.201815
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    os.environ['ANSIBLE_COLLECT_FACTS'] = 'True'
    ufc = UserFactCollector()
    assert ufc.name == 'user'
    assert ufc._fact_ids == {
        'user_id', 'user_uid', 'user_gid', 'user_gecos',
        'user_dir', 'user_shell', 'real_user_id', 'effective_user_id',
        'real_group_id', 'effective_group_id'
    }


# Generated at 2022-06-20 20:06:03.387856
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_collector = UserFactCollector()
    assert user_collector.name == 'user'
    assert user_collector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                            'user_gecos', 'user_dir', 'user_shell',
                                            'real_user_id', 'effective_user_id',
                                            'effective_group_ids'])


# Generated at 2022-06-20 20:06:11.365779
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fact_collector = UserFactCollector()
    collected_facts = fact_collector.collect(collected_facts={})

    assert collected_facts['user_id'] == getpass.getuser()
    assert collected_facts['user_uid'] == os.getuid()
    assert collected_facts['user_gid'] == os.getgid()
    assert collected_facts['user_gecos'] == None
    assert collected_facts['user_dir'] == os.getenv('HOME')
    assert collected_facts['user_shell'] == '/bin/sh'
    assert collected_facts['real_user_id'] == os.getuid()
    assert collected_facts['effective_user_id'] == os.geteuid()
    assert collected_facts['real_group_id'] == os.getgid()
    assert collected_facts

# Generated at 2022-06-20 20:06:15.302087
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    u = UserFactCollector()
    res = u.collect(collected_facts=None)
    assert res.get('user_id', None) == getpass.getuser()
    assert res.get('user_uid', None) == pwd.getpwnam(getpass.getuser()).pw_uid

# Generated at 2022-06-20 20:06:15.810199
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    pass

# Generated at 2022-06-20 20:06:17.694334
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_instance = UserFactCollector()
    assert user_fact_instance.name == 'user'


# Generated at 2022-06-20 20:06:19.096778
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    collector = UserFactCollector()
    assert collector is not None
    assert collector.name == 'user'


# Generated at 2022-06-20 20:06:25.856797
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    pass

# Generated at 2022-06-20 20:06:29.174822
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # collect user facts
    expected_user_facts = {
        'user_id': 'user1',
        'user_uid': 5001,
        'user_gid': 5001,
        'user_gecos': 'User1',
        'user_dir': '/home/user1',
        'user_shell': '/bin/bash',
        'real_user_id': 5001,
        'effective_user_id': 5001,
        'real_group_id': 5001,
        'effective_group_id': 5001,
    }
    real_user_facts = UserFactCollector().collect() 
    assert real_user_facts == expected_user_facts

# Generated at 2022-06-20 20:06:35.098526
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    u = UserFactCollector()
    assert u.name == 'user'
    assert hasattr(u, '_fact_ids')
    assert u._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                               'user_gecos', 'user_dir', 'user_shell',
                               'real_user_id', 'effective_user_id',
                               'effective_group_ids'])


# Generated at 2022-06-20 20:06:42.976031
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    
    # Test 1
    fact_collector = UserFactCollector()
    fact_collector.collect()
    assert(len(fact_collector._fact_ids) == 9)
    assert(fact_collector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                            'user_gecos', 'user_dir', 'user_shell',
                                            'real_user_id', 'effective_user_id', 'effective_group_ids']))
    assert(fact_collector.name == 'user')
    assert(len(fact_collector.collect()) == 9)
    
    
test_UserFactCollector_collect()

# Generated at 2022-06-20 20:06:44.804950
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    pass

# Generated at 2022-06-20 20:06:55.451867
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    module_mock = type('module_mock', (object,), {'params': {}})
    print(module_mock)
    user_collector = UserFactCollector(module=module_mock)
    user_facts = user_collector.collect()
    assert user_facts is not None
    assert len(user_facts) > 0
    assert user_facts['user_id'] is not None
    assert user_facts['user_uid'] is not None
    assert user_facts['user_gid'] is not None
    assert user_facts['user_gecos'] is not None
    assert user_facts['user_dir'] is not None
    assert user_facts['user_shell'] is not None
    assert user_facts['real_user_id'] is not None

# Generated at 2022-06-20 20:07:00.403748
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()

    assert user_fact_collector.name == 'user'
    assert user_fact_collector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                                 'user_gecos', 'user_dir', 'user_shell',
                                                 'real_user_id', 'effective_user_id',
                                                 'effective_group_ids'])

# Generated at 2022-06-20 20:07:03.509314
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_collector = UserFactCollector()
    actual_user_facts = user_collector.collect()
    actual_user_id = actual_user_facts['user_id']
    assert actual_user_id is not None

if __name__ == '__main__':
    test_UserFactCollector_collect()

# Generated at 2022-06-20 20:07:09.593774
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    facts = {'user_id': getpass.getuser(),
             'user_uid': os.getuid(),
             'user_gid': os.getgid(),
             'real_user_id': os.getuid(),
             'effective_user_id': os.geteuid(),
             'real_group_id': os.getgid(),
             'effective_group_id': os.getegid()}

    collected_facts = UserFactCollector().collect()

    for fact_name in UserFactCollector._fact_ids:
        assert collected_facts[fact_name] == facts[fact_name]



# Generated at 2022-06-20 20:07:13.744073
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import pytest
    from . import TestAnsibleModule

    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()
    assert 'user_id' in user_facts
    assert 'user_uid' in user_facts
    assert 'user_gid' in user_facts
    assert 'user_gecos' in user_facts
    assert 'user_dir' in user_facts
    assert 'user_shell' in user_facts
    assert 'real_user_id' in user_facts
    assert 'effective_user_id' in user_facts
    assert 'real_group_id' in user_facts
    assert 'effective_group_id' in user_facts

    # Test with mocked ansible module
    ansible_module = TestAnsibleModule()
    user_

# Generated at 2022-06-20 20:07:27.784001
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    obj = UserFactCollector()


# Generated at 2022-06-20 20:07:33.351031
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    uf = UserFactCollector()
    assert uf.name == 'user'
    assert set(uf._fact_ids) == set(['user_id', 'user_uid', 'user_gid',
                                     'user_gecos', 'user_dir', 'user_shell',
                                     'real_user_id', 'effective_user_id',
                                     'effective_group_ids'])

# Generated at 2022-06-20 20:07:35.461961
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    assert UserFactCollector.name == 'user'
    assert UserFactCollector.priority == 60

# Generated at 2022-06-20 20:07:40.848567
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    assert UserFactCollector.name == 'user'
    assert UserFactCollector._fact_ids == set([
        'user_id', 'user_uid', 'user_gid', 'user_gecos', 'user_dir', 'user_shell',
        'real_user_id', 'effective_user_id', 'effective_group_ids'])

# Generated at 2022-06-20 20:07:48.377082
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    """
    Returns a fact for 'user' key
    """
    expected_fact = {'user': {
                        'user_id': 'cisco',
                        'user_uid': "1",
                        'user_gid': "1",
                        'user_gecos': 'cisco,,,',
                        'user_dir': '/home/cisco',
                        'user_shell': '/bin/bash',
                        'real_user_id': '1',
                        'effective_user_id': '1',
                        'real_group_id': '1',
                        'effective_group_id': '1'
                     }
                     }

    assert UserFactCollector().collect() == expected_fact

# Generated at 2022-06-20 20:07:49.677843
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user = UserFactCollector()
    assert set(user.collect().keys()) == user._fact_ids, 'Attributes should be in _fact_ids'

# Generated at 2022-06-20 20:08:00.987048
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector().collect()
    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['user_uid'] == os.getuid()
    assert user_facts['user_gid'] == os.getgid()
    # gecos is not set on my system so test for none
    assert user_facts['user_gecos'] is None
    assert user_facts['user_dir'] == os.getcwd()
    assert user_facts['user_shell'] == os.getenv('SHELL')
    assert user_facts['real_user_id'] == os.getuid()
    assert user_facts['effective_user_id'] == os.geteuid()
    assert user_facts['real_group_id'] == os.getgid()
    assert user_facts

# Generated at 2022-06-20 20:08:07.721679
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact = UserFactCollector()
    assert user_fact.name == 'user'
    assert user_fact._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                     'user_gecos', 'user_dir', 'user_shell',
                     'real_user_id', 'effective_user_id',
                     'effective_group_ids'])


# Generated at 2022-06-20 20:08:10.482068
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    collected_facts = user_fact_collector.collect()

    assert collected_facts['effective_group_id'] == os.getgid()

# Generated at 2022-06-20 20:08:17.640810
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import os
    import pwd
    import sys

    if sys.version_info[0] == 2:
        class MockModule(object):
            """This is a mock class for test purpose"""

            def __init__(self):
                self.params = {}
        module = MockModule()
    else:
        from unittest.mock import Mock

        module = Mock()

    from ansible.module_utils.facts.collector.user import UserFactCollector
    user_fact = UserFactCollector()
    user_facts = user_fact.collect(module=module, collected_facts={})

    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['user_gid'] == pwd.getpwnam(getpass.getuser()).pw_gid
    assert user_

# Generated at 2022-06-20 20:08:53.668689
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    module = AnsibleModule()
    fact_collector = UserFactCollector()

    # Test without ansible_facts
    collected_facts = {}
    returned_facts = fact_collector.collect(module=module, collected_facts=collected_facts)

    # pwd.getpwuid() is used to get the user's properties
    assert returned_facts['user_id'] == getpass.getuser()
    pwent = pwd.getpwnam(getpass.getuser())
    assert returned_facts['user_uid'] == pwent.pw_uid
    assert returned_facts['user_gid'] == pwent.pw_gid
    assert returned_facts['user_gecos'] == pwent.pw_gecos
    assert returned_facts['user_dir'] == pwent.pw_dir
   

# Generated at 2022-06-20 20:08:57.598700
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    u = UserFactCollector()
    assert u.name == "user"
    assert hasattr(u, "_fact_ids")
    assert u._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                               'user_gecos', 'user_dir', 'user_shell',
                               'real_user_id', 'effective_user_id',
                               'effective_group_ids'])

# Generated at 2022-06-20 20:09:04.173171
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fc = UserFactCollector()
    assert user_fc.name == 'UserFactCollector'
    assert user_fc._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                     'user_gecos', 'user_dir', 'user_shell',
                     'real_user_id', 'effective_user_id',
                     'effective_group_ids'])

# Generated at 2022-06-20 20:09:06.210536
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    fact_collector = UserFactCollector()
    assert isinstance(fact_collector, UserFactCollector)
    assert 'user' == fact_collector.name


# Generated at 2022-06-20 20:09:07.724343
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    userFactCollector = UserFactCollector()
    assert userFactCollector.collect()

# Generated at 2022-06-20 20:09:18.106431
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    o = UserFactCollector()
    result = o.collect()
    assert isinstance(result, dict)
    assert result['user_gecos'] == "dummy gecos"
    assert result['user_id'] == "dummyuser"
    assert result['user_uid'] == 1234
    assert result['user_gid'] == 1234
    assert result['user_dir'] == "/home/dummyuser"
    assert result['user_shell'] == "/bin/sh"
    assert result['real_user_id'] == 1234
    assert result['effective_user_id'] == 1234
    assert result['real_group_id'] == 1234
    assert result['effective_group_id'] == 1234

# Generated at 2022-06-20 20:09:20.111134
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    collected_facts = {}
    user_collector = UserFactCollector()
    user_collector.collect(collected_facts)
    return user_collector.name

# Generated at 2022-06-20 20:09:22.792069
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    userFactsCollector = UserFactCollector()
    assert userFactsCollector is not None
    assert userFactsCollector._fact_ids is not None

# Generated at 2022-06-20 20:09:28.288927
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import pwd
    import operator
    
    for user_pwent in pwd.getpwall():
        user_id = user_pwent.pw_name
        user_uid = user_pwent.pw_uid
        user_gid = user_pwent.pw_gid
        user_gecos = user_pwent.pw_gecos
        user_dir = user_pwent.pw_dir
        user_shell = user_pwent.pw_shell

        os.setreuid(0,0)
        os.setregid(0,0)
        os.setresuid(0,0)
        os.setresgid(0,0)

        os.setreuid(user_uid, user_uid)

# Generated at 2022-06-20 20:09:29.433749
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_obj = UserFactCollector()
    assert user_obj.name == 'user'


# Generated at 2022-06-20 20:10:28.978822
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert user_fact_collector is not None

# Generated at 2022-06-20 20:10:30.573280
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fact_collector = UserFactCollector()
    fact_collector.collect()

# Generated at 2022-06-20 20:10:39.305845
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = {}
    fact_collector = UserFactCollector()
    fact_collector.collect(collected_facts=user_facts)
    assert len(user_facts) == 9
    assert user_facts['user_id'] == getpass.getuser()
    pwent = pwd.getpwnam(getpass.getuser())
    assert user_facts['user_uid'] == pwent.pw_uid
    assert user_facts['user_gid'] == pwent.pw_gid
    assert user_facts['user_gecos'] == pwent.pw_gecos
    assert user_facts['user_dir'] == pwent.pw_dir
    assert user_facts['user_shell'] == pwent.pw_shell

# Generated at 2022-06-20 20:10:44.785836
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user = UserFactCollector()
    assert user.name == 'user'
    assert user._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                  'user_gecos', 'user_dir', 'user_shell',
                                  'real_user_id', 'effective_user_id',
                                  'effective_group_ids'])


# Generated at 2022-06-20 20:10:52.203790
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ufc = UserFactCollector()

    assert ufc.name == "user"

    assert "user_id" in ufc._fact_ids
    assert "user_uid" in ufc._fact_ids
    assert "user_gid" in ufc._fact_ids
    assert "user_gecos" in ufc._fact_ids
    assert "user_dir" in ufc._fact_ids
    assert "user_shell" in ufc._fact_ids
    assert "real_user_id" in ufc._fact_ids
    assert "effective_user_id" in ufc._fact_ids
    assert "effective_group_ids" in ufc._fact_ids


# Generated at 2022-06-20 20:10:59.469677
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fact_collector = UserFactCollector()
    facts = fact_collector.collect()
    assert 'user_id' in facts
    assert 'user_uid' in facts
    assert 'user_gid' in facts
    assert 'user_gecos' in facts
    assert 'user_dir' in facts
    assert 'user_shell' in facts
    assert 'real_user_id' in facts
    assert 'effective_user_id' in facts
    assert 'real_group_id' in facts
    assert 'effective_group_id' in facts

if __name__ == '__main__':
    test_UserFactCollector_collect()

# Generated at 2022-06-20 20:11:11.380963
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts_list = UserFactCollector().collect()
    assert len(user_facts_list) == 9
    assert user_facts_list['user_id'] == getpass.getuser()
    assert type(user_facts_list['user_uid']) == int
    assert type(user_facts_list['user_gid']) == int
    assert type(user_facts_list['user_gecos']) == str
    assert type(user_facts_list['user_dir']) == str
    assert type(user_facts_list['user_shell']) == str
    assert type(user_facts_list['real_user_id']) == int
    assert type(user_facts_list['effective_user_id']) == int
    assert type(user_facts_list['real_group_id']) == int

# Generated at 2022-06-20 20:11:13.311993
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert user_fact_collector.name == 'user'

# Generated at 2022-06-20 20:11:14.131778
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    assert UserFactCollector(None).name == 'user'

# Generated at 2022-06-20 20:11:24.641025
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    import pwd
    test_user_facts = UserFactCollector()
    test_collector = Collector()

    # Success test case
    test_collector.collectors.append(test_user_facts)
    test_collector.collect()
    assert(test_collector.collected_facts['user_id']) == getpass.getuser()
    assert(test_collector.collected_facts['user_uid']) == pwd.getpwnam(getpass.getuser()).pw_uid
    assert(test_collector.collected_facts['user_gid']) == pwd.getpwnam(getpass.getuser()).pw_gid

# Generated at 2022-06-20 20:13:51.892999
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import os
    import pwd
    from ansible.module_utils.facts.collector import BaseFactCollector
    ufc = UserFactCollector()

    class mock_user:
        def __init__(self):
            return

        def environ(self, user_id=None):
            if user_id is not None:
                self.user_id = user_id
            else:
                return self.user_id
            return

    class mock_group:
        def __init__(self):
            return

        def getgrgid(self, gid):
            self.gid = gid

    class mock_pwd:
        def __init__(self):
            return

        def getpwnam(self, user_id):
            self.pw_uid = 5
            self.pw_g