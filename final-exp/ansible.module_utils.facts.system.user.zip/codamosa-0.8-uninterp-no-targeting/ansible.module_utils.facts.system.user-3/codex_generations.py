

# Generated at 2022-06-20 20:03:54.822106
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    user_facts = UserFactCollector()
    user_facts_dict = user_facts.collect()
    assert "user_id" in user_facts_dict
    assert "real_user_id" in user_facts_dict
    assert "effective_user_id" in user_facts_dict
    assert "real_group_id" in user_facts_dict
    assert "user_shell" in user_facts_dict
    assert "user_uid" in user_facts_dict
    assert "user_gid" in user_facts_dict
    assert "user_gecos" in user_facts_dict
    assert "user_dir" in user_facts_dict

# Generated at 2022-06-20 20:03:55.333339
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    pass

# Generated at 2022-06-20 20:04:02.212674
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    collected_facts = {}

    # Collect all facts of class UserFactCollector
    user_fact_collector.collect(collected_facts=collected_facts)

    assert collected_facts['user_id'] == getpass.getuser()
    assert collected_facts['user_uid'] != ""
    assert collected_facts['user_gid'] != ""
    assert collected_facts['user_gecos'] != ""
    assert collected_facts['user_dir'] != ""
    assert collected_facts['user_shell'] != ""
    assert collected_facts['real_user_id'] != ""
    assert collected_facts['effective_user_id'] != ""
    assert collected_facts['effective_group_id'] != ""

# Generated at 2022-06-20 20:04:04.733742
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    """
    Sanity test for UserFactCollector
    """
    user = UserFactCollector()
    assert user.name == 'user'
    assert user.priority == 70


# Generated at 2022-06-20 20:04:08.234464
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fc = UserFactCollector()
    collected_facts = user_fc.collect(collected_facts=None)
    assert collected_facts['user_id']

# Generated at 2022-06-20 20:04:14.262859
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert user_fact_collector.name == 'user'
    assert user_fact_collector._fact_ids == set(['user_id', 'user_uid', 'user_gid', 'user_gecos', 'user_dir', 'user_shell', 'real_user_id', 'effective_user_id', 'effective_group_ids'])

# Generated at 2022-06-20 20:04:18.436577
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    assert UserFactCollector

# Generated at 2022-06-20 20:04:20.189771
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    collect_user_facts = UserFactCollector()
    assert collect_user_facts.name == 'user'

# Generated at 2022-06-20 20:04:21.220259
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    UserFactCollector().collect()

# Generated at 2022-06-20 20:04:24.230864
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import doctest
    failed, total = doctest.testmod(UserFactCollector)
    if failed > 0:
        exit(1)
    else:
        exit(0)

# Generated at 2022-06-20 20:04:28.556515
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_obj = UserFactCollector()
    assert user_obj.name == 'user'


# Generated at 2022-06-20 20:04:32.870950
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    from ansible.module_utils.facts import collector

    try:
        gf = collector.get_collector_for_type('user')
        u = gf.collect()
        assert u['user_id'] == getpass.getuser()
    except Exception:
        assert False, 'UserFactCollector_collect() test failed!'


# Generated at 2022-06-20 20:04:42.205202
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    """Test to collect user facts"""
    userfact_collector_obj = UserFactCollector()
    userfacts = userfact_collector_obj.collect()
    assert userfacts.has_key('user_id') == True
    assert userfacts.has_key('user_uid') == True
    assert userfacts.has_key('user_gid') == True
    assert userfacts.has_key('user_gecos') == True
    assert userfacts.has_key('user_dir') == True
    assert userfacts.has_key('user_shell') == True
    assert userfacts.has_key('real_user_id') == True
    assert userfacts.has_key('effective_user_id') == True
    assert userfacts.has_key('real_group_id') == True
    assert userfacts.has_key

# Generated at 2022-06-20 20:04:45.256516
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
     us = UserFactCollector(None)
     us.collect()

# Generated at 2022-06-20 20:04:47.700745
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    fact_inst = UserFactCollector()
    assert isinstance(fact_inst, UserFactCollector)
    

# Generated at 2022-06-20 20:04:49.072619
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ufc = UserFactCollector()
    assert ufc.name == 'user'

# Generated at 2022-06-20 20:04:50.440502
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collector = UserFactCollector()

    print(collector.collect())

# Generated at 2022-06-20 20:04:52.371744
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    fact_module = UserFactCollector()
    assert fact_module is not None
    assert fact_module.name == "user"


# Generated at 2022-06-20 20:04:55.158857
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # No need to test the code below, it is already tested by test_module_utils_facts_collector
    # user_facts = UserFactCollector().collect()
    pass

# Generated at 2022-06-20 20:04:59.373476
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    # Create an instance of UserFactCollector
    user_fact_collector = UserFactCollector()
    # Assert that UserFactCollector instance is created
    assert user_fact_collector is not None

# Generated at 2022-06-20 20:05:14.920231
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector.collect()

    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['user_uid'] == pwd.getpwnam(getpass.getuser()).pw_uid
    assert user_facts['user_gid'] == pwd.getpwnam(getpass.getuser()).pw_gid
    assert user_facts['user_gecos'] == pwd.getpwnam(getpass.getuser()).pw_gecos
    assert user_facts['user_dir'] == pwd.getpwnam(getpass.getuser()).pw_dir
    assert user_facts['user_shell'] == pwd.getpwnam(getpass.getuser()).pw_shell

# Generated at 2022-06-20 20:05:24.850844
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    name = 'user'
    fact_ids = set(['user_id', 'user_uid', 'user_gid',
                    'user_gecos', 'user_dir', 'user_shell',
                    'real_user_id', 'effective_user_id',
                    'effective_group_ids'])
    expected_collector = UserFactCollector(
        name, 'ansible.module_utils.facts.collector.user_fact_collector')
    assert name == expected_collector.name
    assert fact_ids == expected_collector._fact_ids



# Generated at 2022-06-20 20:05:29.870179
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_collector = UserFactCollector()
    assert user_collector.name == 'user'
    assert user_collector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                            'user_gecos', 'user_dir', 'user_shell',
                                            'real_user_id', 'effective_user_id',
                                            'effective_group_ids'])


# Generated at 2022-06-20 20:05:32.447886
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():

    # Constructor test
    user_fact_collector = UserFactCollector()
    assert user_fact_collector

# Generated at 2022-06-20 20:05:40.427950
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector
    import json
    import sys

    user = UserFactCollector()
    user_facts = user.collect()
    user_facts_json = json.dumps(user_facts)

    sys.stderr.write("User facts from UserFactCollector :\n" + user_facts_json + "\n")

    # file = open('test','w+')
    # file.write(user_facts_json)
    # file.close()
    #

# Generated at 2022-06-20 20:05:50.624358
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector().collect()
    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['user_uid'] == pwd.getpwuid(os.getuid()).pw_uid
    assert user_facts['user_gid'] == pwd.getpwuid(os.getuid()).pw_gid
    assert user_facts['user_gecos'] == pwd.getpwuid(os.getuid()).pw_gecos
    assert user_facts['user_dir'] == pwd.getpwuid(os.getuid()).pw_dir
    assert user_facts['user_shell'] == pwd.getpwuid(os.getuid()).pw_shell
    assert user_facts['real_user_id'] == os

# Generated at 2022-06-20 20:05:58.736040
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    userfc = UserFactCollector()
    user_facts = userfc.collect()
    assert user_facts['user_id'] is not None
    assert user_facts['user_uid'] is not None
    assert user_facts['user_gid'] is not None
    assert user_facts['user_gecos'] is not None
    assert user_facts['user_dir'] is not None
    assert user_facts['user_shell'] is not None
    assert user_facts['real_user_id'] is not None
    assert user_facts['effective_user_id'] is not None
    assert user_facts['effective_group_ids'] is not None


# Generated at 2022-06-20 20:06:01.518590
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    result = UserFactCollector().collect()
    assert result['user_id'] == getpass.getuser()
    assert result['user_uid'] == os.getuid()
    assert result['real_user_id'] == os.getuid()
    assert result['effective_user_id'] == os.geteuid()
    assert result['real_group_id'] == os.getgid()
    assert result['effective_group_id'] == os.getgid()

# Generated at 2022-06-20 20:06:03.636074
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    userFactCollector = UserFactCollector()
    userFactCollector.collect()



# Generated at 2022-06-20 20:06:11.492484
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    """
    This function tests the collecting facts by UserFactCollector.
    """
    # Create an object of class UserFactCollector
    user_fact_collector = UserFactCollector()
    # Assert that the value of variable name of UserFactCollector
    # is expected: 'user'
    assert user_fact_collector.name == 'user'
    # Assert that the set of variable _fact_ids of UserFactCollector
    # is as expected.
    user_fact_ids = set(['user_id', 'user_uid', 'user_gid', 'user_gecos',
                         'user_dir', 'user_shell', 'real_user_id',
                         'effective_user_id', 'effective_group_ids'])
    assert user_fact_collector._fact_ids == user_fact_ids


# Generated at 2022-06-20 20:06:20.144395
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ufc = UserFactCollector()
    assert ufc is not None


# Generated at 2022-06-20 20:06:31.479988
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    user_fact_collector.collect()
    assert user_fact_collector.name == 'user'
    assert 'user_id' in user_fact_collector._fact_ids
    assert 'user_uid' in user_fact_collector._fact_ids
    assert 'user_gid' in user_fact_collector._fact_ids
    assert 'user_gecos' in user_fact_collector._fact_ids
    assert 'user_dir' in user_fact_collector._fact_ids
    assert 'user_shell' in user_fact_collector._fact_ids
    assert 'real_user_id' in user_fact_collector._fact_ids
    assert 'effective_user_id' in user_fact_collector._fact_ids
   

# Generated at 2022-06-20 20:06:38.268316
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact = UserFactCollector()
    assert user_fact.collect() == {
        'effective_group_id': 1000,
        'effective_user_id': 1000,
        'real_group_id': 1000,
        'real_user_id': 1000,
        'user_dir': '/home/user01',
        'user_gecos': 'user01_gecos',
        'user_gid': 1000,
        'user_id': 'user01',
        'user_shell': '/bin/bash',
        'user_uid': 1000,
    }

# Generated at 2022-06-20 20:06:43.438275
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    collector = UserFactCollector()
    # test constructor of class
    assert collector.name == 'user'
    assert collector._fact_ids == set(['user_id', 'user_uid',
                                       'user_gid', 'user_gecos',
                                       'user_dir', 'user_shell',
                                       'real_user_id', 'effective_user_id',
                                       'effective_group_ids'])



# Generated at 2022-06-20 20:06:46.145958
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    obj = UserFactCollector()
    assert 'user_id' in obj.collect(collected_facts=None)

# Generated at 2022-06-20 20:06:56.626284
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    user_facts = ufc.collect()
    assert isinstance(user_facts, dict)
    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['user_uid'] == pwd.getpwuid(os.getuid()).pw_uid
    assert user_facts['user_gid'] == pwd.getpwuid(os.getuid()).pw_gid
    assert user_facts['user_gecos'] == pwd.getpwuid(os.getuid()).pw_gecos
    assert user_facts['user_dir'] == pwd.getpwuid(os.getuid()).pw_dir

# Generated at 2022-06-20 20:07:03.676884
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    """
    Unit test for method collect of class UserFactCollector
    """
    ufc = UserFactCollector()
    user_facts = ufc.collect()

    assert 'user_id' in user_facts
    assert 'user_uid' in user_facts
    assert 'user_gid' in user_facts
    assert 'user_gecos' in user_facts
    assert 'user_dir' in user_facts
    assert 'user_shell' in user_facts
    assert 'real_user_id' in user_facts
    assert 'effective_user_id' in user_facts
    assert 'real_group_id' in user_facts
    assert 'effective_group_id' in user_facts

# Generated at 2022-06-20 20:07:12.323038
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    # Test UserFactCollector.collect()
    # Test for groups
    user_facts = UserFactCollector().collect()

    assert "user_id" in user_facts
    assert "user_uid" in user_facts
    assert "user_gid" in user_facts
    assert "user_gecos" in user_facts
    assert "user_dir" in user_facts
    assert "user_shell" in user_facts
    assert "real_user_id" in user_facts
    assert "effective_user_id" in user_facts
    assert "real_group_id" in user_facts
    assert "effective_group_id" in user_facts

# Generated at 2022-06-20 20:07:17.837236
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    assert UserFactCollector.name == 'user'
    assert UserFactCollector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                     'user_gecos', 'user_dir', 'user_shell',
                     'real_user_id', 'effective_user_id',
                     'effective_group_ids'])


# Generated at 2022-06-20 20:07:19.410607
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fact_collector = UserFactCollector()
    fact_collector.collect()

# Generated at 2022-06-20 20:07:34.994165
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert user_fact_collector.name == 'user'
    assert user_fact_collector.collect()['user_id'] == 'root'

# Generated at 2022-06-20 20:07:38.954667
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts_collector = UserFactCollector()
    assert user_facts_collector.collect()["user_id"] == getpass.getuser()
    assert user_facts_collector.collect()["user_uid"] == os.getuid()


# Generated at 2022-06-20 20:07:44.881142
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    obj = UserFactCollector()
    assert obj.name == 'user'
    assert obj._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                     'user_gecos', 'user_dir', 'user_shell',
                     'real_user_id', 'effective_user_id',
                     'effective_group_ids'])
    assert obj.collect()['real_user_id'] > -1

# Generated at 2022-06-20 20:07:55.893934
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    passwd_dict = { 'username': { 'pw_uid': 100,
                                  'pw_gid': 100,
                                  'pw_gecos': 'Ansible',
                                  'pw_dir': '~/',
                                  'pw_shell': '/bin/sh'}
                   }

    def getpwnam(name=None):
        if name:
            return passwd_dict[name]
        else:
            return None

    def getpwuid(uid=None):
        if uid:
            for k in passwd_dict:
                if passwd_dict[k]['pw_uid'] == uid:
                    return passwd_dict[k]
        else:
            return None


# Generated at 2022-06-20 20:08:01.191800
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    collector = UserFactCollector()
    assert collector.name == "user"
    assert collector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                       'user_gecos', 'user_dir', 'user_shell',
                                       'real_user_id', 'effective_user_id',
                                       'effective_group_ids'])

# Generated at 2022-06-20 20:08:07.838156
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    assert UserFactCollector.name == 'user'
    assert UserFactCollector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                               'user_gecos', 'user_dir', 'user_shell',
                                               'real_user_id', 'effective_user_id',
                                               'effective_group_ids'])


# Generated at 2022-06-20 20:08:09.532076
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    collector = UserFactCollector()
    assert collector.name == 'user'



# Generated at 2022-06-20 20:08:14.072669
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    assert UserFactCollector.name == 'user'
    assert UserFactCollector._fact_ids == set(['user_id', 'user_uid', 'user_gid', 'user_gecos', 'user_dir', 'user_shell', 'real_user_id', 'effective_user_id', 'effective_group_ids'])

# Generated at 2022-06-20 20:08:17.514289
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    userFact = UserFactCollector()
    assert userFact.name == "user"

# Generated at 2022-06-20 20:08:23.026107
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    collect = UserFactCollector()
    assert collect.name == 'user'
    assert collect._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                     'user_gecos', 'user_dir', 'user_shell',
                                     'real_user_id', 'effective_user_id',
                                     'real_group_id', 'effective_group_id'])

# Unit test of method UserFactCollector.collect()

# Generated at 2022-06-20 20:08:49.763469
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    fact_collector = UserFactCollector()
    fact_collector.collect()

# Generated at 2022-06-20 20:08:50.390536
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user = UserFactCollector()
    assert isinstance(user.collect(), dict)

# Generated at 2022-06-20 20:08:51.617361
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    instance = UserFactCollector()
    assert isinstance(instance, UserFactCollector)

# Generated at 2022-06-20 20:08:59.322334
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    class FakeModule:
        def __init__(self):
            self.params = {'gather_subset': ['user'], 'filter': 'user'}

    fact_module = FakeModule()
    user = UserFactCollector(fact_module=fact_module)
    ansible_user = user.collect()
    assert 'user_id' in ansible_user
    assert 'user_uid' in ansible_user
    assert 'user_gid' in ansible_user
    assert 'user_gecos' in ansible_user
    assert 'user_dir' in ansible_user
    assert 'user_shell' in ansible_user
    assert 'real_user_id' in ansible_user
    assert 'effective_user_id' in ansible_user
    assert 'effective_group_ids' in ansible

# Generated at 2022-06-20 20:09:05.065509
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    ansible_facts = {
        'user_id': 'ansible',
        'user_uid': 1122,
        'user_gid': 1234,
        'user_gecos': 'Ansible User,,,',
        'user_dir': '/home/ansible',
        'user_shell': '/bin/bash',
        'real_user_id': 1122,
        'effective_user_id': 1122,
        'effective_group_ids': [1234]
    }
    assert(user_fact_collector.collect() == ansible_facts)

# Generated at 2022-06-20 20:09:16.019480
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    # import ansible.constants as C
    # C.HOST_KEY_CHECKING = False
    collector = UserFactCollector()
    _facts = collector.collect()
    assert isinstance(_facts, dict)
    assert _facts["user_id"] != None
    assert _facts["user_uid"] != None
    assert _facts["user_gid"] != None
    assert _facts["user_gecos"] != None
    assert _facts["user_dir"] != None
    assert _facts["user_shell"] != None
    assert _facts["real_user_id"] != None
    assert _facts["effective_user_id"] != None
    assert _facts["real_group_id"] != None
    assert _facts["effective_group_id"] != None
    # assert _facts['ansible_user_id'] == u'

# Generated at 2022-06-20 20:09:17.212823
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fact_collector = UserFactCollector()
    fact_collector.collect()

# Generated at 2022-06-20 20:09:19.577524
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_collector = UserFactCollector()
    user_collector.collect()

    assert user_collector.collect()['user_id'] == getpass.getuser()

# Generated at 2022-06-20 20:09:22.560285
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    instance = UserFactCollector()

    assert isinstance(instance, UserFactCollector)


# Generated at 2022-06-20 20:09:28.144884
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.system.user import UserFactCollector
    from ansible.module_utils.facts.system import user as user_platform
    from ansible.module_utils.facts.utils import get_file_content

    # Test with real data
    module = None
    collected_facts = {}
    UserFactCollector.collect(module, collected_facts)
    assert len(collected_facts) == len(UserFactCollector._fact_ids), \
        "Facts count is not the expected one."
    assert isinstance(collected_facts['user_id'], str), \
        "Facts user_id is not the expected one."

# Generated at 2022-06-20 20:10:31.410669
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()
    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['user_uid'] == os.getuid()
    assert user_facts['user_gid'] == os.getgid()
    assert user_facts['real_user_id'] == os.getuid()
    assert user_facts['effective_user_id'] == os.geteuid()
    assert user_facts['real_group_id'] == os.getgid()
    assert user_facts['effective_group_id'] == os.getegid()

# Generated at 2022-06-20 20:10:41.254909
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector().collect()
    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['user_uid'] == pwd.getpwuid(os.getuid()).pw_uid
    assert user_facts['user_gid'] == pwd.getpwuid(os.getuid()).pw_gid
    assert user_facts['user_gecos'] == pwd.getpwuid(os.getuid()).pw_gecos
    assert user_facts['user_dir'] == pwd.getpwuid(os.getuid()).pw_dir
    assert user_facts['user_shell'] == pwd.getpwuid(os.getuid()).pw_shell
    assert user_facts['real_user_id'] == os

# Generated at 2022-06-20 20:10:50.650973
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Create instance of UserFactCollector class
    # (i.e. user fact collector)
    user_fact_collector = UserFactCollector()

    # Call collect method of UserFactCollector class
    # and assign result to variable user_facts
    user_facts = user_fact_collector.collect()

    # Asserts to ensure that the result
    # of the call to collect method of UserFactCollector
    # class has the required fields
    assert user_facts['user_id']
    assert user_facts['user_uid']
    assert user_facts['user_gid']
    assert user_facts['user_gecos']
    assert user_facts['user_dir']
    assert user_facts['user_shell']
    assert user_facts['real_user_id']

# Generated at 2022-06-20 20:10:55.643115
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    from ansible.module_utils.facts.collectors import get_collector_object
    mock_ansible_module = MockAnsibleModule()
    user_fact_collector = get_collector_object('user', {}, mock_ansible_module)
    collected_facts = user_fact_collector.collect({}, {})
    assert collected_facts['user_id'] != None


# Generated at 2022-06-20 20:11:00.947321
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user = UserFactCollector()
    assert user.name == 'user'
    assert user._fact_ids == {'user_id', 'user_uid', 'user_gid',
                              'user_gecos', 'user_dir', 'user_shell',
                              'real_user_id', 'effective_user_id',
                              'effective_group_ids'}
    assert type(user) == UserFactCollector

if __name__ == "__main__":
    test_UserFactCollector()

# Generated at 2022-06-20 20:11:12.606512
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    module = {}
    collector = UserFactCollector(module=module)

    # Testing with default values
    collected_facts = {}

# Generated at 2022-06-20 20:11:13.786269
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    instance = UserFactCollector()
    assert instance.name == 'user'

# Generated at 2022-06-20 20:11:22.889688
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    from mock import patch

    from ansible.module_utils.facts import collector

    pwent = "pwent"
    pw_uid = 123
    pw_gid = 456
    pw_gecos = "test"
    pw_dir = "/home"
    pw_shell = "/bin/bash"
    user_id = "test_user"

    with patch.object(collector.UserFactCollector, '_pwd') as mock_pwd, \
         patch.object(collector.UserFactCollector, '_os') as mock_os, \
         patch.object(collector.UserFactCollector, '_getpass') as mock_getpass:

        mock_os.getuid.return_value = 123
        mock_os.getgid.return_value = 456
        mock_

# Generated at 2022-06-20 20:11:29.237751
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Execution with default settings
    test_object = UserFactCollector()
    result = test_object.collect()
    assert result['user_id'] == getpass.getuser()
    assert result['user_uid'] == pwd.getpwuid(os.getuid()).pw_uid
    assert result['user_gid'] == pwd.getpwuid(os.getuid()).pw_gid
    assert result['user_gecos'] == pwd.getpwuid(os.getuid()).pw_gecos
    assert result['user_dir'] == pwd.getpwuid(os.getuid()).pw_dir
    assert result['user_shell'] == pwd.getpwuid(os.getuid()).pw_shell

# Generated at 2022-06-20 20:11:34.859281
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    # Setup stubs
    class StubModule(object):
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = ['!all', 'user']

    class StubCollectedFacts(object):
        def __init__(self):
            self.__dict__ = {}

    # Test
    ufc = UserFactCollector()
    facts = ufc.collect(StubModule(), StubCollectedFacts())
    assert facts