

# Generated at 2022-06-20 20:03:53.018815
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()

    user_facts = user_fact_collector.collect()

    assert user_facts['user_id'] == getpass.getuser()
    try:
        pwent = pwd.getpwnam(getpass.getuser())
    except KeyError:
        pwent = pwd.getpwuid(os.getuid())

    assert user_facts['user_uid'] == pwent.pw_uid
    assert user_facts['user_gid'] == pwent.pw_gid
    assert user_facts['user_gecos'] == pwent.pw_gecos
    assert user_facts['user_dir'] == pwent.pw_dir
    assert user_facts['user_shell'] == pwent.pw_shell

# Generated at 2022-06-20 20:03:58.408858
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_collector = UserFactCollector()

    module = FakeModule()
    facts = {}

    user_collector.collect(module, facts)
    # Verify keys in facts
    assert 'user_id' in facts
    assert 'user_uid' in facts
    assert 'user_gid' in facts
    assert 'user_gecos' in facts
    assert 'user_dir' in facts
    assert 'user_shell' in facts
    assert 'real_user_id' in facts
    assert 'effective_user_id' in facts


# Generated at 2022-06-20 20:03:59.765118
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    userFact = UserFactCollector()
    assert userFact


# Generated at 2022-06-20 20:04:02.359016
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    userFactCollector = UserFactCollector()
    userFactCollector.collect()

# Generated at 2022-06-20 20:04:09.034457
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    c = UserFactCollector()
    assert c.name == 'user'
    assert c._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                               'user_gecos', 'user_dir', 'user_shell',
                               'real_user_id', 'effective_user_id',
                               'real_group_id', 'effective_group_id'])


# Generated at 2022-06-20 20:04:15.953486
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    x = UserFactCollector()
    assert x.name == 'user'
    assert x._fact_ids == set(['real_user_id',
                               'real_group_id',
                               'user_id',
                               'effective_user_id',
                               'user_gid',
                               'effective_group_id',
                               'user_gecos',
                               'user_dir',
                               'user_uid',
                               'user_shell'])


# Generated at 2022-06-20 20:04:20.936481
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    collector = UserFactCollector()
    assert collector.name == 'user'
    assert collector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                     'user_gecos', 'user_dir', 'user_shell',
                     'real_user_id', 'effective_user_id',
                     'effective_group_ids'])

# Generated at 2022-06-20 20:04:24.617271
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():

    user_fact = UserFactCollector()
    assert user_fact.name == 'user'
    assert isinstance(user_fact._fact_ids, set)

# Test set of all fact ids with collector name as prefix

# Generated at 2022-06-20 20:04:29.083495
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ufc = UserFactCollector()
    assert ufc.name == 'user'
    assert ufc._fact_ids.issubset(ufc.collect().keys())
    assert ufc.collect()['user_id'] == getpass.getuser()

# Generated at 2022-06-20 20:04:31.397808
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # get dict with only configured facts
    result = UserFactCollector.collect()

    # check if we can get a value from it
    assert(result['user_id'])

# Generated at 2022-06-20 20:04:43.413438
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import os
    import stat
    import tempfile
    import pwd

    FACT_NAME = 'user_gecos'
    FACT_VALUE = 'foo'
    TEST_USER = 'ansible_test_user'
    TEST_GROUP = 'ansible_test_group'
    TEST_UID = 777
    TEST_GID = 666
    TEST_HOME = '/home/%s' % TEST_USER
    TEST_SHELL = '/bin/sh'
    TEST_FILE = 'foo'
    TEST_FILE_PATH = os.path.join(TEST_HOME, TEST_FILE)

    # Ensure that the test user does no already exist
    try:
        pwd.getpwnam(TEST_USER)
        raise Exception('Test user already exists on the system')
    except KeyError:
        pass


# Generated at 2022-06-20 20:04:53.211913
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    facts = ufc.collect()
    assert facts['user_id'] == getpass.getuser()
    assert facts['user_uid'] == os.getuid()
    assert facts['user_gid'] == os.getgid()
    assert facts['user_dir'] == os.path.expanduser('~')
    assert facts['user_shell'] == os.getenv('SHELL')
    assert facts['real_user_id'] == os.getuid()
    assert facts['effective_user_id'] == os.geteuid()
    assert facts['real_group_id'] == os.getgid()
    assert facts['effective_group_id'] == os.getegid()

# Generated at 2022-06-20 20:05:03.625151
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    class AnsibleModuleMock(object):
        def __init__(self):
            self.params = {}

    class AnsibleFactsMock(object):
        def __init__(self):
            self.facts = {}

    module = AnsibleModuleMock()
    facts = AnsibleFactsMock()

    fact = UserFactCollector()
    fact.collect(module, facts)

    assert 'user_id' in facts.facts
    assert 'user_uid' in facts.facts
    assert 'user_gid' in facts.facts
    assert 'user_gecos' in facts.facts
    assert 'user_dir' in facts.facts
    assert 'user_shell' in facts.facts
    assert 'real_user_id' in facts.facts
    assert 'real_group_id' in facts.facts

# Generated at 2022-06-20 20:05:14.833749
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()

    Facter.collect = Mock(return_value=dict())

    result = user_fact_collector.collect()

    assert result.has_key('user_id')
    assert result.has_key('user_uid')
    assert result.has_key('user_gid')
    assert result.has_key('user_gecos')
    assert result.has_key('user_dir')
    assert result.has_key('user_shell')
    assert result.has_key('real_user_id')
    assert result.has_key('effective_user_id')
    assert result.has_key('real_group_id')
    assert result.has_key('effective_group_id')

# Generated at 2022-06-20 20:05:24.851097
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_collector = UserFactCollector()
    collected_facts = user_collector.collect()
    print(collected_facts)
    assert 'user_id' in collected_facts
    assert 'user_uid' in collected_facts
    assert 'user_gid' in collected_facts
    assert 'user_gecos' in collected_facts
    assert 'user_dir' in collected_facts
    assert 'user_shell' in collected_facts
    assert 'real_user_id' in collected_facts
    assert 'effective_user_id' in collected_facts
    assert 'real_group_id' in collected_facts
    assert 'effective_group_id' in collected_facts


# Generated at 2022-06-20 20:05:30.500008
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    data = UserFactCollector().collect()
    assert isinstance(data, dict)
    assert 'user_id' in data
    assert 'user_uid' in data
    assert 'user_gid' in data
    assert 'user_gecos' in data
    assert 'user_dir' in data
    assert 'user_shell' in data
    assert 'real_user_id' in data
    assert 'effective_user_id' in data
    assert 'effective_group_ids' in data

# Generated at 2022-06-20 20:05:41.571351
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    """
    Unit test for method collect of class UserFactCollector
    """
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()

    assert user_facts['user_id'] is not None
    assert user_facts['user_uid'] is not None
    assert user_facts['user_uid'] >= 0
    assert user_facts['user_gid'] is not None
    assert user_facts['user_gid'] >= 0
    assert user_facts['user_gecos'] is not None
    assert user_facts['user_dir'] is not None
    assert user_facts['user_shell'] is not None

    assert user_facts['real_user_id'] is not None
    assert user_facts['real_user_id'] >= 0

# Generated at 2022-06-20 20:05:49.058182
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    user_collector = UserFactCollector()

    # test collecting facts about the current user
    user_facts = user_collector.collect()

    assert 'user_id' in user_facts
    assert 'user_uid' in user_facts
    assert 'user_gid' in user_facts
    assert 'user_gecos' in user_facts
    assert 'user_dir' in user_facts
    assert 'user_shell' in user_facts
    assert 'real_user_id' in user_facts
    assert 'effective_user_id' in user_facts
    assert 'real_group_id' in user_facts
    assert 'effective_group_id' in user_facts

# Generated at 2022-06-20 20:05:58.702297
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()

    # Test for root
    if os.getuid() == 0:
        collected_facts = ufc.collect()
        assert collected_facts['user_id'] == 'root'
        assert collected_facts['effective_user_id'] == 'root'
        assert collected_facts['user_uid'] == 0
        assert collected_facts['user_gid'] == 0
        assert collected_facts['user_gecos'] == 'root'
        assert collected_facts['user_dir'] == '/root'
        assert collected_facts['user_shell'] == '/bin/bash'

    # Test for non-root
    else:
        collected_facts = ufc.collect()
        assert collected_facts['user_id'] == getpass.getuser()

# Generated at 2022-06-20 20:06:09.141449
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    from mock import patch, MagicMock
    from nose.plugins.skip import SkipTest
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.user import UserFactCollector
    try:
        import pwd
        import grp
    except ImportError:
        raise SkipTest("UserFactCollector test class is only supported on Unix systems.")

    # Create mocks
    test_module = MagicMock()
    test_collected_facts = MagicMock()
    # test_pwent = MagicMock()

    # Create test class instance
    test_user_fact_collector = UserFactCollector(test_module, test_collected_facts)

    # Run collect method
    test_user_fact_collector.collect()

    # Check results


# Generated at 2022-06-20 20:06:19.859224
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ufc = UserFactCollector()
    assert ufc.name == 'user'
    assert ufc._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                 'user_gecos', 'user_dir', 'user_shell',
                                 'real_user_id', 'effective_user_id',
                                 'effective_group_ids'])

# Generated at 2022-06-20 20:06:22.880300
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    # test UserFactCollector constructor
    ufc = UserFactCollector()
    assert ufc.name == 'user'

# Generated at 2022-06-20 20:06:28.769961
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    result = UserFactCollector().collect()
    assert ('user_id' in result)
    assert ('user_uid' in result)
    assert ('user_gid' in result)
    assert ('user_gecos' in result)
    assert ('user_dir' in result)
    assert ('user_shell' in result)
    assert ('real_user_id' in result)
    assert ('effective_user_id' in result)

# Generated at 2022-06-20 20:06:34.371893
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    '''
    Method to test collect of class UserFactCollector
    '''
    user_fact_collector = UserFactCollector()

    user_facts = user_fact_collector.collect()
    assert isinstance(user_facts, dict)
    assert 4 in user_facts['effective_group_ids']
    assert 0 in user_facts['effective_group_ids']
    assert 1002 in user_facts['effective_group_ids']

# Generated at 2022-06-20 20:06:43.549855
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    my_collector = UserFactCollector()

    # Unit test for empty collect method
    result = my_collector.collect()
    print('\n' + str(result))
    assert result
    assert type(result) == dict
    assert len(result) >= 7
    assert 'user_id' in result
    assert 'user_uid' in result
    assert 'user_gid' in result
    assert 'user_gecos' in result
    assert 'user_dir' in result
    assert 'user_shell' in result
    assert 'real_user_id' in result
    assert 'effective_user_id' in result
    assert 'real_group_id' in result
    assert 'effective_group_id' in result


# Execute module

# Generated at 2022-06-20 20:06:45.177175
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
  user = UserFactCollector()
  assert user.name == 'user'
  assert 'user_id' in user._fact_ids

# Generated at 2022-06-20 20:06:53.269338
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector().collect()
    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['user_gid'] > 0
    assert user_facts['user_uid'] > 0
    assert user_facts['user_shell'] != ''
    assert user_facts['real_user_id'] == os.getuid()
    assert user_facts['effective_user_id'] == os.geteuid()
    assert user_facts['real_group_id'] == os.getgid()
    assert user_facts['effective_group_id'] == os.getegid()

# Generated at 2022-06-20 20:07:02.191525
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    from ansible.module_utils.facts.collector import FactsCollector
    import os

    role_path = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'lib/ansible/roles/test_role')
    facts_collector = FactsCollector(include_factsets=['user'],collect_subset=['all'],minimum_gather_subset=['all'],roles_paths=[role_path])

    user_facts = facts_collector.collect()
    assert(user_facts['user_id'] == getpass.getuser())
    assert(user_facts['real_user_id'] == os.getuid())
    assert(user_facts['effective_user_id'] == os.geteuid())

# Generated at 2022-06-20 20:07:06.808591
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    assert not hasattr(UserFactCollector(), '_fact_ids')
    assert hasattr(UserFactCollector(), 'collect')
    assert hasattr(UserFactCollector(), 'name')
    assert UserFactCollector().name == 'user'


# Generated at 2022-06-20 20:07:08.971064
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    '''
    Unit test for method collect of class UserFactCollector
    '''
    user_collector_obj = UserFactCollector()
    user_collector_obj.collect()

# Generated at 2022-06-20 20:07:32.801954
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    from mock import Mock, patch
    from ansible.module_utils.facts import Facts
    import ansible.module_utils.facts.system.user

    user_facts = ansible.module_utils.facts.system.user.UserFactCollector(Mock())
    user_facts._cache = Mock(Facts)
    user_facts._collect = user_facts.collect
    user_facts._collect.return_value = dict()

    with patch.object(getpass, "getuser") as mock_getpass:
        mock_getpass.return_value = 'ansibler'
        result = user_facts._collect()
        assert isinstance(result, dict)
        assert result['user_id'] == 'ansibler'


# Generated at 2022-06-20 20:07:39.118410
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    obj = UserFactCollector()
    assert obj.name == 'user'
    assert obj._fact_ids == {'user_id', 'user_uid', 'user_gid',
                             'user_gecos', 'user_dir', 'user_shell',
                             'real_user_id', 'effective_user_id',
                             'effective_group_ids'}


# Generated at 2022-06-20 20:07:47.752338
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    """Unit test for method collect of class UserFactCollector"""

    # create and test the UserFactCollector class
    userfact_collector = UserFactCollector()
    user_facts = userfact_collector.collect()

    # test the user_id parameter
    assert user_facts['user_id'] is not None
    assert isinstance(user_facts['user_id'], str)

    # test the user_uid parameter
    assert user_facts['user_uid'] is not None
    assert isinstance(user_facts['user_uid'], int)

    # test the user_gid parameter
    assert user_facts['user_gid'] is not None
    assert isinstance(user_facts['user_gid'], int)

    # test the user_gecos parameter

# Generated at 2022-06-20 20:07:50.784685
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert user_fact_collector.name == 'user'
    assert user_fact_collector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                                 'user_gecos', 'user_dir', 'user_shell',
                                                 'real_user_id', 'effective_user_id',
                                                 'effective_group_ids'])

# Generated at 2022-06-20 20:07:54.527346
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ufc = UserFactCollector()
    assert ufc.name == 'user'
    assert ufc.collect() == ufc.collect(collected_facts={})


# Generated at 2022-06-20 20:07:56.888033
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    result = UserFactCollector()
    assert result.name == 'user'
    assert isinstance(result, BaseFactCollector)

# Generated at 2022-06-20 20:07:58.934753
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    ufc.collect()

# Generated at 2022-06-20 20:08:04.456676
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    assert UserFactCollector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                               'user_gecos', 'user_dir', 'user_shell',
                                               'real_user_id', 'effective_user_id',
                                               'effective_group_ids'])



# Generated at 2022-06-20 20:08:06.127279
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    assert UserFactCollector.name == "user"

# Generated at 2022-06-20 20:08:15.448468
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact = UserFactCollector()
    collected_facts = {}
    user_facts = user_fact.collect(collected_facts)
    assert user_facts['user_id'] is not None
    assert user_facts['user_uid'] is not None
    assert user_facts['user_gid'] is not None
    assert user_facts['user_gecos'] is not None
    assert user_facts['user_dir'] is not None
    assert user_facts['user_shell'] is not None
    assert user_facts['real_user_id'] is not None
    assert user_facts['effective_user_id'] is not None
    assert user_facts['real_group_id'] is not None
    assert user_facts['effective_group_id'] is not None

# Generated at 2022-06-20 20:08:35.506205
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert(user_fact_collector.name == "user")
    assert(user_fact_collector._fact_ids == set(['user_id', 'user_uid', 'user_gid', 'user_gecos', 'user_dir', 'user_shell', 'real_user_id', 'effective_user_id', 'effective_group_ids']))


# Generated at 2022-06-20 20:08:37.848586
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    mod_args = None
    collected_facts = None
    user_facts_collector = UserFactCollector()
    user_facts_collector.collect(mod_args, collected_facts)

# Generated at 2022-06-20 20:08:40.310054
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ''' Unit test for method collect of class UserFactCollector '''
    uhfc = UserFactCollector()
    assert(uhfc.collect()['user_id'] == getpass.getuser())


# Generated at 2022-06-20 20:08:43.185300
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    assert UserFactCollector._fact_ids

# Generated at 2022-06-20 20:08:48.763986
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_collector=UserFactCollector()
    assert user_collector
    assert user_collector.name == 'user'

# Unit test UserFactCollector collect method
# test if user_id, user_uid, user_gid, user_gecos, user_dir, user_shell,
# real_user_id, effective_user_id and effective_group_ids are present
# in user_facts


# Generated at 2022-06-20 20:08:56.923691
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    test_user = UserFactCollector()
    test_user_collect_results = test_user.collect()
    assert test_user_collect_results['user_id'] == getpass.getuser()
    assert test_user_collect_results['user_uid'] == os.getuid()
    assert test_user_collect_results['user_gid'] == os.getgid()
    assert test_user_collect_results['user_gecos'] == pwd.getpwuid(os.getuid()).pw_gecos
    assert test_user_collect_results['user_dir'] == pwd.getpwuid(os.getuid()).pw_dir
    assert test_user_collect_results['user_shell'] == pwd.getpwuid(os.getuid()).pw_shell

# Generated at 2022-06-20 20:09:03.344247
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    assert UserFactCollector.__name__ == 'UserFactCollector'
    assert UserFactCollector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                     'user_gecos', 'user_dir', 'user_shell',
                     'real_user_id', 'effective_user_id',
                     'effective_group_ids'])

# Generated at 2022-06-20 20:09:04.727860
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    c = UserFactCollector()
    assert isinstance(c.collect(), dict)


# Generated at 2022-06-20 20:09:05.462838
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    UserFactCollector().collect()

# Generated at 2022-06-20 20:09:10.857424
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    checked_facts_ids = {}
    facts = ufc.collect()
    checked_facts_ids = ufc.get_fact_ids()

    assert facts['user_id'] == getpass.getuser()
    assert facts['user_uid'] == pwd.getpwuid(os.getuid()).pw_uid
    assert facts['user_gid'] == pwd.getpwuid(os.getuid()).pw_gid
    assert facts['user_gecos'] == pwd.getpwuid(os.getuid()).pw_gecos
    assert facts['user_dir'] == pwd.getpwuid(os.getuid()).pw_dir

# Generated at 2022-06-20 20:09:42.938865
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ufc = UserFactCollector()
    assert ufc.name == 'user'
    assert ufc.collect()['user_id'] == getpass.getuser()

# Generated at 2022-06-20 20:09:51.820503
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    '''
    Test that UserFactCollector correctly collects facts 
    '''

    from ansible.module_utils.facts.collector import UserFactCollector
    UserFactCollector.name = 'user'

    # Create instance of class UserFactCollector
    ufc = UserFactCollector()

    # Get current user's name
    user_local_name = getpass.getuser()

    # Collect facts
    facts = ufc.collect()

    assert 'user_id' in facts.keys()
    assert 'user_uid' in facts.keys()
    assert 'user_gid' in facts.keys()
    assert 'user_gecos' in facts.keys()
    assert 'user_dir' in facts.keys()
    assert 'user_shell' in facts.keys()
    assert 'real_user_id' in facts

# Generated at 2022-06-20 20:09:57.825417
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_factcollector = UserFactCollector()
    # UserFactCollector's attributes
    assert user_factcollector.name == 'user'
    assert user_factcollector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                     'user_gecos', 'user_dir', 'user_shell',
                     'real_user_id', 'effective_user_id',
                     'effective_group_ids'])


# Generated at 2022-06-20 20:10:03.255930
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    assert UserFactCollector.name == 'user'
    assert UserFactCollector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                               'user_gecos', 'user_dir', 'user_shell',
                                               'real_user_id', 'effective_user_id',
                                               'effective_group_ids'])

# Generated at 2022-06-20 20:10:13.450350
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collector = UserFactCollector()
    result = collector.collect()
    assert result['user_id'] == getpass.getuser()
    assert result['user_uid'] == pwd.getpwnam(getpass.getuser()).pw_uid
    assert result['user_gid'] == pwd.getpwnam(getpass.getuser()).pw_gid
    assert result['user_gecos'] == pwd.getpwnam(getpass.getuser()).pw_gecos
    assert result['user_dir'] == pwd.getpwnam(getpass.getuser()).pw_dir
    assert result['user_shell'] == pwd.getpwnam(getpass.getuser()).pw_shell
    assert result['real_user_id'] == os.getuid()


# Generated at 2022-06-20 20:10:14.074209
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    pass

# Generated at 2022-06-20 20:10:24.887727
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    # test when no module argument is passed
    collector = UserFactCollector()
    assert collector.name == "user"
    assert collector._fact_ids == set(['user_id', 'user_uid', 'user_gid', 'user_gecos',
                                       'user_dir', 'user_shell', 'real_user_id',
                                       'effective_user_id', 'effective_group_ids'])

    # test when module argument is provided
    collector = UserFactCollector(module=None)
    assert collector.name == "user"

# Generated at 2022-06-20 20:10:34.032439
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collector = UserFactCollector()
    result = collector.collect()
    assert result is not None
    assert result['user_id']  == getpass.getuser()
    assert isinstance(result['user_uid'], int)
    assert isinstance(result['user_gid'], int)
    assert isinstance(result['effective_group_id'], int)
    assert isinstance(result['user_gecos'], str)
    assert isinstance(result['user_dir'], str)
    assert isinstance(result['user_shell'], str)
    assert isinstance(result['real_user_id'], int)
    assert isinstance(result['effective_user_id'], int)

# Generated at 2022-06-20 20:10:40.092399
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collector = UserFactCollector()
    result = collector.collect(None, None)
    assert result['user_id']
    assert type(result['user_uid']) is int
    assert type(result['user_gid']) is int
    assert result['user_gecos']
    assert result['user_dir']
    assert result['user_shell']
    assert type(result['real_user_id']) is int
    assert type(result['effective_user_id']) is int
    assert type(result['real_group_id']) is int
    assert type(result['effective_group_id']) is int

# Generated at 2022-06-20 20:10:46.040347
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ufc = UserFactCollector()
    assert (ufc.name == 'user')
    assert (sorted(ufc._fact_ids) ==
            sorted(['user_id', 'user_uid', 'user_gid',
                    'user_gecos', 'user_dir', 'user_shell',
                    'real_user_id', 'effective_user_id',
                    'effective_group_ids']))



# Generated at 2022-06-20 20:11:55.389120
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    with open('./test/unit/ansible_collections/ansible/builtin/tests/unit/module_utils/facts/test_user.json', 'r') as f:
        user_facts = UserFactCollector().collect()

        for fact in user_facts:
            assert user_facts[fact] == f.readline().strip()
        f.close()


# Generated at 2022-06-20 20:12:04.318184
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collector = UserFactCollector()
    collected_facts = collector.collect()
    assert 'user_id' in collected_facts
    assert 'user_uid' in collected_facts
    assert 'user_gid' in collected_facts
    assert 'user_gecos' in collected_facts
    assert 'user_dir' in collected_facts
    assert 'user_shell' in collected_facts
    assert 'real_user_id' in collected_facts
    assert 'effective_user_id' in collected_facts
    assert 'effective_group_id' in collected_facts

# Generated at 2022-06-20 20:12:10.073427
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    x = UserFactCollector()
    assert x.name == "user"
    assert repr(x._fact_ids) == repr(set(['user_id', 'user_uid', 'user_gid',
                                          'user_gecos', 'user_dir', 'user_shell',
                                          'real_user_id', 'effective_user_id',
                                          'effective_group_ids']))

# Generated at 2022-06-20 20:12:17.777706
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    module = None
    collected_facts = {}

    # This test runs as root which is the most common case in servers running
    # ansible.
    collector = UserFactCollector()
    facts = collector.collect(module, collected_facts)
    assert facts['user_id'] == 'root'
    assert facts['user_uid'] == 0
    assert facts['user_gid'] == 0
    assert facts['user_gecos'] == 'root'
    assert facts['user_dir'] == '/root'
    assert facts['user_shell'] == '/bin/bash'
    assert facts['real_user_id'] == 0
    assert facts['effective_user_id'] == 0
    assert facts['real_group_id'] == 0
    assert facts['effective_group_id'] == 0

# Generated at 2022-06-20 20:12:27.365883
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Setup
    user_fact_collector = UserFactCollector()

    # Test
    user_facts = user_fact_collector.collect()

    # Verify
    assert user_facts['user_id'] is not None
    assert user_facts['user_uid'] is not None
    assert user_facts['user_gid'] is not None
    assert user_facts['user_gecos'] is not None
    assert user_facts['user_dir'] is not None
    assert user_facts['user_shell'] is not None
    assert user_facts['real_user_id'] is not None
    assert user_facts['effective_user_id'] is not None
    assert user_facts['real_group_id'] is not None
    assert user_facts['effective_group_id'] is not None

# Generated at 2022-06-20 20:12:33.689435
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_collector = UserFactCollector()
    collected_facts = user_collector.collect()
    assert collected_facts['user_id'] == getpass.getuser()
    try:
        pwent = pwd.getpwnam(getpass.getuser())
    except KeyError:
        pwent = pwd.getpwuid(os.getuid())
    assert collected_facts['user_uid'] == pwent.pw_uid
    assert collected_facts['user_gid'] == pwent.pw_gid
    assert collected_facts['user_gecos'] == pwent.pw_gecos
    assert collected_facts['user_dir'] == pwent.pw_dir
    assert collected_facts['user_shell'] == pwent.pw_shell

# Generated at 2022-06-20 20:12:38.235299
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert user_fact_collector.name == 'user'
    assert user_fact_collector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                                 'user_gecos', 'user_dir', 'user_shell',
                                                 'real_user_id', 'effective_user_id',
                                                 'real_group_id', 'effective_group_id'])

# Generated at 2022-06-20 20:12:38.988089
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    pass

# Generated at 2022-06-20 20:12:42.812285
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():

    # Test with empty constructor
    c = UserFactCollector()
    assert c.name == 'user'

    # Test with string argument
    c = UserFactCollector('test')
    assert c.name == 'test'

    # Test with list argument
    c = UserFactCollector(['test1', 'test2'])
    assert c.name == ['test1', 'test2']

# Generated at 2022-06-20 20:12:47.995498
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    c = UserFactCollector()
    assert c.name == 'user'
    assert c._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                               'user_gecos', 'user_dir', 'user_shell',
                               'real_user_id', 'effective_user_id',
                               'effective_group_ids'])