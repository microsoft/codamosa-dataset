

# Generated at 2022-06-20 20:03:44.002911
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    from ansible.module_utils.facts import collector
    user_facts = collector.collect('user')
    assert user_facts['user_id'] == getpass.getuser()


# Generated at 2022-06-20 20:03:51.601520
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    from ansible.module_utils.facts import Collector
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.system import UserFactCollector
    from ansible.module_utils.facts.system.user import UserFactCollector
    # create instance of FactsCollector
    facts_collector = FactsCollector()
    # register collectors
    facts_collector.register_collector(UserFactCollector())
    # collect facts
    facts = facts_collector.collect(module=None, collected_facts={})
    # test if facts are collected correctly
    assert(facts['user_id'] == 'root')
    assert(facts['user_uid'] == 0)
    assert(facts['user_gid'] == 0)

# Generated at 2022-06-20 20:03:52.925747
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    assert UserFactCollector().name == 'user'


# Generated at 2022-06-20 20:03:56.880325
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    assert UserFactCollector.name == "user"
    assert UserFactCollector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                               'user_gecos', 'user_dir', 'user_shell',
                                               'real_user_id', 'effective_user_id',
                                               'effective_group_ids'])

# Generated at 2022-06-20 20:04:03.194149
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    user_facts = UserFactCollector().collect()

    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['user_uid'] == pwd.getpwuid(os.getuid()).pw_uid
    assert user_facts['user_gid'] == pwd.getpwuid(os.getuid()).pw_gid
    assert user_facts['user_gecos'] == pwd.getpwuid(os.getuid()).pw_gecos
    assert user_facts['user_dir'] == pwd.getpwuid(os.getuid()).pw_dir
    assert user_facts['user_shell'] == pwd.getpwuid(os.getuid()).pw_shell
    assert user_facts['real_user_id'] == os

# Generated at 2022-06-20 20:04:09.995621
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert user_fact_collector.name == 'user'
    assert user_fact_collector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                     'user_gecos', 'user_dir', 'user_shell',
                     'real_user_id', 'effective_user_id',
                     'effective_group_ids'])


# Generated at 2022-06-20 20:04:18.335966
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_obj = UserFactCollector()
    user_facts = user_obj.collect()
    assert isinstance(user_facts, dict)
    keys = set(['user_id', 'user_uid', 'user_gid',
                'user_gecos', 'user_dir', 'user_shell',
                'real_user_id', 'effective_user_id',
                'real_group_id', 'effective_group_id'])
    assert set(user_facts.keys()) == keys
    for key in user_facts.keys():
        assert key in keys
        assert isinstance(user_facts[key], (str, int))

# Generated at 2022-06-20 20:04:20.108345
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ufc = UserFactCollector()
    assert isinstance(ufc, UserFactCollector)

# Generated at 2022-06-20 20:04:23.622152
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    userCollectObj = UserFactCollector()
    testDict = userCollectObj.collect()
    # Asserting the test result
    assert testDict['user_id'] == getpass.getuser()

# Generated at 2022-06-20 20:04:30.340606
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    result = user_fact_collector.collect()
    assert result.get('user_id') is not None
    assert result.get('user_uid') is not None
    assert result.get('user_gid') is not None
    assert result.get('user_gecos') is not None
    assert result.get('user_dir') is not None
    assert result.get('user_shell') is not None
    assert result.get('real_user_id') is not None
    assert result.get('real_group_id') is not None
    assert result.get('effective_user_id') is not None
    assert result.get('effective_group_id') is not None

# Generated at 2022-06-20 20:04:34.345498
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    UserFactCollector()

# Generated at 2022-06-20 20:04:43.278017
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    obj = UserFactCollector()
    ret = obj.collect()

    # assert isinstance(ret, dict) is True
    # assert len(ret.keys()) == 4
    # assert ret['real'] == {'effective': 'Rajesh Kumar', 'real': 'Rajesh Kumar', 'saved': 'Rajesh Kumar'}
    # assert ret['effective'] == {'effective': 'Rajesh Kumar', 'real': 'Rajesh Kumar', 'saved': 'Rajesh Kumar'}
    # assert ret['real'] == {'effective': 'Rajesh Kumar', 'real': 'Rajesh Kumar', 'saved': 'Rajesh Kumar'}
    # assert ret['saved'] == {'effective': 'Rajesh Kumar', 'real': 'Rajesh Kumar', 'saved': 'Rajesh Kumar'}


# Generated at 2022-06-20 20:04:46.821190
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    userFactCollector = UserFactCollector()
    assert userFactCollector.name == 'user'
    assert len(userFactCollector._fact_ids) == 9


# Generated at 2022-06-20 20:04:56.835150
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    """Unit test for method collect of class UserFactCollector"""
    ufc = UserFactCollector()
    utest = ufc.collect()
    assert utest['user_id'] == getpass.getuser()
    assert utest['user_uid'] == os.getuid()
    assert utest['user_gid'] == os.getgid()
    assert utest['user_gecos'] == pwd.getpwuid(os.getuid()).pw_gecos
    assert utest['user_dir'] == pwd.getpwuid(os.getuid()).pw_dir
    assert utest['user_shell'] == pwd.getpwuid(os.getuid()).pw_shell
    assert utest['real_user_id'] == os.getuid()

# Generated at 2022-06-20 20:05:05.874988
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts_collector = UserFactCollector()
    user_facts_output = user_facts_collector.collect()
    assert user_facts_output['user_id'] == getpass.getuser()
    try:
        pwent = pwd.getpwnam(getpass.getuser())
    except KeyError:
        pwent = pwd.getpwuid(os.getuid())
    assert user_facts_output['user_uid'] == pwent.pw_uid
    assert user_facts_output['user_gid'] == pwent.pw_gid
    assert user_facts_output['user_gecos'] == pwent.pw_gecos
    assert user_facts_output['user_dir'] == pwent.pw_dir

# Generated at 2022-06-20 20:05:17.497154
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    real_user_id = os.getuid()
    effective_user_id = os.geteuid()
    real_group_id = os.getgid()
    effective_group_id = os.getegid()

    ufc = UserFactCollector()
    user_facts = ufc.collect()

    assert(user_facts['user_id'] == getpass.getuser())
    assert(user_facts['user_uid'] == os.getuid())
    assert(user_facts['real_user_id'] == real_user_id)
    assert(user_facts['effective_user_id'] == effective_user_id)
    assert(user_facts['real_group_id'] == real_group_id)
    assert(user_facts['effective_group_id'] == effective_group_id)

# Generated at 2022-06-20 20:05:18.121739
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fa

# Generated at 2022-06-20 20:05:21.558105
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fact_collector = UserFactCollector()
    fact_collector.collect()

if __name__ == '__main__':
    test_UserFactCollector_collect()

# Generated at 2022-06-20 20:05:30.035664
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()
    assert user_facts['user_id'] == getpass.getuser()
    try:
        pwent = pwd.getpwnam(getpass.getuser())
        assert user_facts['user_uid'] == pwent.pw_uid
        assert user_facts['user_gid'] == pwent.pw_gid
        assert user_facts['user_gecos'] == pwent.pw_gecos
        assert user_facts['user_dir'] == pwent.pw_dir
        assert user_facts['user_shell'] == pwent.pw_shell
    except KeyError:
        pwent = pwd.getpwuid(os.getuid())

# Generated at 2022-06-20 20:05:37.268863
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    assert UserFactCollector.name == 'user'
    assert UserFactCollector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                     'user_gecos', 'user_dir', 'user_shell',
                     'real_user_id', 'effective_user_id',
                     'real_group_id', 'effective_group_id'])


# Generated at 2022-06-20 20:05:45.408782
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    assert UserFactCollector().name == 'user'


# Generated at 2022-06-20 20:05:52.649846
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()

    user_facts = user_fact_collector.collect()

    assert 'user_id' in user_facts
    assert 'user_uid' in user_facts
    assert 'user_gid' in user_facts
    assert 'user_gecos' in user_facts
    assert 'user_dir' in user_facts
    assert 'user_shell' in user_facts
    assert 'real_user_id' in user_facts
    assert 'real_group_id' in user_facts
    assert 'effective_user_id' in user_facts
    assert 'effective_group_id' in user_facts

# Generated at 2022-06-20 20:05:57.139706
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    assert 'user' == UserFactCollector.name
    assert set(['user_id', 'user_uid', 'user_gid', 'user_gecos', 'user_dir', 'user_shell', 'real_user_id',
                'effective_user_id', 'effective_group_ids']) == UserFactCollector._fact_ids

# Generated at 2022-06-20 20:06:05.645524
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector().collect()
    
    assert "user_id" in user_facts
    assert "user_uid" in user_facts
    assert "user_gid" in user_facts
    assert "user_gecos" in user_facts
    assert "user_dir" in user_facts
    assert "user_shell" in user_facts
    assert "real_user_id" in user_facts
    assert "effective_user_id" in user_facts
    assert "real_group_id" in user_facts
    assert "effective_group_id" in user_facts

# Generated at 2022-06-20 20:06:07.813929
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    """ validate the collect function of UserFactCollector
    """
    collector = UserFactCollector()
    result = collector.collect()
    assert(isinstance(result, dict))

# Generated at 2022-06-20 20:06:15.909856
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    "Test that the constructor of class UserFactCollector initializes properly."
    userfact = UserFactCollector()

    assert isinstance(userfact.name, str)
    assert userfact.name == "user"

    assert isinstance(userfact._fact_ids, set)
    assert userfact._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                      'user_gecos', 'user_dir', 'user_shell',
                                      'real_user_id', 'effective_user_id',
                                      'effective_group_ids'])


# Generated at 2022-06-20 20:06:17.471260
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    obj = UserFactCollector()
    assert isinstance(obj, UserFactCollector)


# Generated at 2022-06-20 20:06:22.232668
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()

    # trigger the collection
    facts = ufc.collect()

    assert 'user_id' in facts
    assert 'user_uid' in facts
    assert 'user_gid' in facts
    assert 'user_gecos' in facts
    assert 'user_dir' in facts
    assert 'user_shell' in facts
    assert 'effective_user_id' in facts
    assert 'real_user_id' in facts
    assert 'real_group_id' in facts
    assert 'effective_group_id' in facts

# Generated at 2022-06-20 20:06:24.212982
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert user_fact_collector != None

# Generated at 2022-06-20 20:06:28.433600
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    """Test method collect of class UserFactCollector"""
    user_facts = UserFactCollector()

    real_user_id = os.getuid()
    user_uid = pwd.getpwuid(real_user_id).pw_uid
    user_gid = pwd.getpwuid(real_user_id).pw_gid
    user_gecos = pwd.getpwuid(real_user_id).pw_gecos
    user_dir = pwd.getpwuid(real_user_id).pw_dir
    user_shell = pwd.getpwuid(real_user_id).pw_shell

    effective_user_id = os.geteuid()
    effective_group_id = os.getegid()


# Generated at 2022-06-20 20:06:45.438600
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ufc = UserFactCollector()
    assert hasattr(ufc, 'name')
    assert hasattr(ufc, '_fact_ids')

# Generated at 2022-06-20 20:06:55.976643
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collector = UserFactCollector()
    user_facts = collector.collect()

    # Test whether a user_id is present in the collection
    assert_is_not_none(user_facts['user_id'])

    # Test whether a GID is present in the collection
    assert_is_not_none(user_facts['user_gid'])

    # Test whether a UID is present in the collection
    assert_is_not_none(user_facts['user_uid'])

    # Test whether a GECOS is present in the collection
    assert_is_not_none(user_facts['user_gecos'])

    # Test whether a home directory is present in the collection
    assert_is_not_none(user_facts['user_dir'])

    # Test whether a shell is present in the collection
    assert_is_

# Generated at 2022-06-20 20:06:57.524086
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_collector = UserFactCollector()
    user_collector.collect(module=None, collected_facts=None)

# Generated at 2022-06-20 20:07:08.853595
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Arrange
    user_id = 'johndoe'
    real_user_id = 12345
    effective_user_id = 12345
    real_group_id = 12345
    effective_group_id = 12345
    user_uid = 12345
    user_gid = 12345
    user_gecos = 'John Doe'
    user_dir = '/home/johndoe'
    user_shell = '/bin/bash'

    mock_getpass = getpass.getuser
    getpass.getuser = lambda: user_id

    mock_pwd = pwd.getpwnam

# Generated at 2022-06-20 20:07:17.757895
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector().collect()

    assert isinstance(user_facts, dict)
    assert 'user_id' in user_facts
    assert 'user_uid' in user_facts
    assert 'user_gid' in user_facts
    assert 'user_gecos' in user_facts
    assert 'user_dir' in user_facts
    assert 'user_shell' in user_facts
    assert 'real_user_id' in user_facts
    assert 'effective_user_id' in user_facts
    assert 'effective_group_ids' in user_facts

# Unit test fot method name of class UserFactCollector

# Generated at 2022-06-20 20:07:29.195838
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    from os import setresgid, setresuid
    from pwd import getpwuid, getpwnam
    from grp import getgrgid, getgrnam
    import sys

    # These attributes are imported dynamically because the group and user
    # attributes of the modules must be the ones defined on the system.
    # This is because methods like getpwuid() rely on the __getattr__ methods
    # of the objects.
    setattr(sys.modules['__main__'], 'UserFactCollector', UserFactCollector)
    setattr(sys.modules['__main__'], 'getpwuid', getpwuid)
    setattr(sys.modules['__main__'], 'getpwnam', getpwnam)

# Generated at 2022-06-20 20:07:33.280545
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert user_fact_collector.name == 'user'
    assert user_fact_collector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                                 'user_gecos', 'user_dir', 'user_shell',
                                                 'real_user_id', 'effective_user_id',
                                                 'effective_group_ids'])

# Generated at 2022-06-20 20:07:41.040745
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    userFactCollector = UserFactCollector()
    assert isinstance(userFactCollector, UserFactCollector)
    assert userFactCollector.name == 'user'
    assert userFactCollector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                               'user_gecos', 'user_dir', 'user_shell',
                                               'real_user_id', 'effective_user_id',
                                               'effective_group_ids'])


# Generated at 2022-06-20 20:07:45.858359
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    user_fact_collector.collect()
    assert user_fact_collector.name == 'user'
    assert user_fact_collector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                     'user_gecos', 'user_dir', 'user_shell',
                     'real_user_id', 'effective_user_id',
                     'effective_group_ids'])

# Generated at 2022-06-20 20:07:52.250624
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ans_obj = UserFactCollector()
    assert ans_obj.name == 'user'
    assert ans_obj._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                     'user_gecos', 'user_dir', 'user_shell',
                     'real_user_id', 'effective_user_id',
                     'effective_group_ids'])


# Generated at 2022-06-20 20:08:25.231859
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    collector = UserFactCollector()
    assert collector.name == 'user'
    assert collector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                       'user_gecos', 'user_dir', 'user_shell',
                                       'real_user_id', 'effective_user_id',
                                       'effective_group_ids'])



# Generated at 2022-06-20 20:08:25.687408
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    pass

# Generated at 2022-06-20 20:08:30.698286
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ''' UserFactCollector.collect should return dictionary of all facts '''
    user_collector = UserFactCollector()
    user_collector.collect()
    assert user_collector.collect() == {'effective_group_ids': [0, 0],
                                        'effective_user_id': 0,
                                        'real_group_id': 0,
                                        'real_user_id': 0,
                                        'user_dir': '/root',
                                        'user_gecos': 'root',
                                        'user_gid': 0,
                                        'user_id': 'root',
                                        'user_shell': '/bin/bash',
                                        'user_uid': 0}

# Generated at 2022-06-20 20:08:34.187546
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    user_facts = UserFactCollector()
    assert user_facts.collect()['user_id'] == getpass.getuser()


# Generated at 2022-06-20 20:08:35.131420
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    assert UserFactCollector.collect()

# Generated at 2022-06-20 20:08:43.167411
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
   ufc = UserFactCollector()
   facts = ufc.collect()

   # Check that all expected facts are present
   assert set(facts.keys()) == ufc._fact_ids

   # Check for the existence of values for particular facts
   assert facts['user_id'] == getpass.getuser()
   assert facts['user_uid'] == pwd.getpwuid(os.getuid()).pw_uid
   assert facts['user_gid'] == pwd.getpwuid(os.getuid()).pw_gid
   assert facts['user_gecos'] == pwd.getpwuid(os.getuid()).pw_gecos
   assert facts['user_dir'] == pwd.getpwuid(os.getuid()).pw_dir
   assert facts['user_shell'] == p

# Generated at 2022-06-20 20:08:48.760944
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():

    user_fact_collector = UserFactCollector()

    assert user_fact_collector.name == 'user'
    assert user_fact_collector._fact_ids == set(['user_id', 'user_uid', 'user_gid', 'user_gecos', 'user_dir', 'user_shell', 'real_user_id', 'effective_user_id', 'effective_group_ids'])

# Generated at 2022-06-20 20:08:58.124282
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    userFactCollector = UserFactCollector()

# Generated at 2022-06-20 20:09:04.215162
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user = UserFactCollector()
    assert user.name == 'user'
    assert user._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                     'user_gecos', 'user_dir', 'user_shell',
                     'real_user_id', 'effective_user_id',
                     'effective_group_ids'])



# Generated at 2022-06-20 20:09:10.336054
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fact_collector = UserFactCollector()
    fact_collector_output = fact_collector.collect()

    real_user_id = os.getuid()
    effective_user_id = os.geteuid()
    real_group_id = os.getgid()
    effective_group_id = os.getegid()

    try:
        pwent = pwd.getpwnam(getpass.getuser())
    except KeyError:
        pwent = pwd.getpwuid(os.getuid())

    assert fact_collector_output['user_id'] == getpass.getuser()
    assert fact_collector_output['user_uid'] == pwent.pw_uid
    assert fact_collector_output['user_gid'] == pwent.pw_gid

# Generated at 2022-06-20 20:09:50.922465
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    def getpwnam(self, user_id):
        pwnam = dict()
        pwnam['pw_uid'] = 50
        pwnam['pw_gid'] = 51
        pwnam['pw_gecos'] = 'user'
        pwnam['pw_dir'] = '/home/user'
        pwnam['pw_shell'] = '/bin/bash'
        return pwnam

    user_fac_col = UserFactCollector(module=None, collected_facts=None)
    user_fac_col.pwd.getpwnam = getpwnam
    user_fac_col.os.getuid = lambda: 50
    user_fac_col.os.geteuid = lambda: 51
    user_fac_col.getpass.getuser = lambda: 'user'

# Generated at 2022-06-20 20:10:00.786839
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Create a class to mock the BaseFactCollector and the UserFactCollector
    class MockBaseFactCollector():
        def __init__(self):
            self._fact_ids = set()

        def set_fact_ids(self, fact_ids):
            self._fact_ids = self._fact_ids.union(fact_ids)

    class MockUserFactCollector():
        def __init__(self):
            self.name = 'user'
            self._fact_ids = set(['user_id', 'user_uid', 'user_gid',
                                  'user_gecos', 'user_dir', 'user_shell',
                                  'real_user_id', 'effective_user_id',
                                  'effective_group_ids'])


# Generated at 2022-06-20 20:10:05.627263
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    collector = UserFactCollector()
    assert collector.name == 'user'
    assert collector._fact_ids == {'effective_group_ids', 'user_id', 'user_uid', 'user_gid', 'user_gecos', 'user_dir', 'user_shell', 'real_user_id', 'effective_user_id'}


# Generated at 2022-06-20 20:10:14.660316
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    test_UserFactCollector = UserFactCollector()
    test_user_facts = test_UserFactCollector.collect(
        collected_facts=dict())

    assert test_user_facts['user_id'] == getpass.getuser()
    assert test_user_facts['user_uid'] == pwd.getpwuid(os.getuid()).pw_uid
    assert test_user_facts['user_gid'] == pwd.getpwuid(os.getuid()).pw_gid
    assert test_user_facts['user_gecos'] == pwd.getpwuid(os.getuid()).pw_gecos
    assert test_user_facts['user_dir'] == pwd.getpwuid(os.getuid()).pw_dir

# Generated at 2022-06-20 20:10:25.226972
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    """Testing UserFactCollector.collect"""

    import sys
    import os
    import unittest

    # test of collect method on Linux
    if sys.platform.startswith('linux'):
        from ansible.module_utils.facts.collectors.user import UserFactCollector

        class TestUserFactCollectorLinux(unittest.TestCase):
            """Test for UserFactCollector.collect()"""

            def setUp(self):
                self.test_obj = UserFactCollector()

            def test_collect(self):
                """Testing correct behavior on Linux"""
                result = self.test_obj.collect()
                self.assertIsInstance(result, dict)

# Generated at 2022-06-20 20:10:36.002124
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import platform
    import socket
    import time

    from ansible.module_utils.facts.collector import CollectedFacts

    if platform.system() == 'Linux':
        collector = UserFactCollector()
        collected_facts = CollectedFacts(
            internal_dict={
                'ansible_env': {
                    'HOME': str(dict(os.environ)['HOME']),
                    'USER': str(dict(os.environ)['USER']),
                    'TERM': str(dict(os.environ)['TERM']),
                    }
                }
            )

        # Expected value changed by 'import time'
        user_facts = collector.collect(collected_facts=collected_facts)
        assert user_facts['user_id'] == socket.gethostname()

# Generated at 2022-06-20 20:10:40.092380
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    assert UserFactCollector.name == 'user'
    assert UserFactCollector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                                'user_gecos', 'user_dir', 'user_shell',
                                                'real_user_id', 'effective_user_id',
                                                'effective_group_ids'])


# Generated at 2022-06-20 20:10:40.537966
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    pass

# Generated at 2022-06-20 20:10:49.988849
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    class Mock_pwd(object):
        def __init__(self, uid):
            self.pw_uid  = uid
            self.pw_gid  = 0
            self.pw_gecos = "gecos"
            self.pw_dir = "dir"
            self.pw_shell = "shell"

    # Create the uid we expect and the one that is used
    mock_user = "user_id"
    mock_euid = 1

    ufc = UserFactCollector()
    # Create the mock object
    pwd_mock = Mock_pwd(mock_euid)
    # Call the method we want to test with the mock objects
    result = ufc.collect(pwd=pwd_mock, getpass=mock_user)

    assert mock_user

# Generated at 2022-06-20 20:10:59.107335
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
  ufc = UserFactCollector()

  facts = ufc.collect()

  assert facts['user_id'] == getpass.getuser()
  assert facts['user_uid'] == os.getuid()
  assert facts['user_gid'] == os.getgid()
  assert facts['user_gecos'] == pwd.getpwuid(os.getuid()).pw_gecos
  assert facts['user_shell'] == pwd.getpwuid(os.getuid()).pw_shell
  assert facts['real_user_id'] == os.getuid()
  assert facts['effective_user_id'] == os.geteuid()
  assert facts['real_group_id'] == os.getgid()
  assert facts['effective_group_id'] == os.getegid()

# Generated at 2022-06-20 20:12:13.411088
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    assert UserFactCollector().name == 'user'

# Generated at 2022-06-20 20:12:23.549216
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = {}

    user_facts['user_id'] = getpass.getuser()

    try:
        pwent = pwd.getpwnam(getpass.getuser())
    except KeyError:
        pwent = pwd.getpwuid(os.getuid())

    user_facts['user_uid'] = pwent.pw_uid
    user_facts['user_gid'] = pwent.pw_gid
    user_facts['user_gecos'] = pwent.pw_gecos
    user_facts['user_dir'] = pwent.pw_dir
    user_facts['user_shell'] = pwent.pw_shell
    user_facts['real_user_id'] = os.getuid()
    user_facts['effective_user_id'] = os.geteu

# Generated at 2022-06-20 20:12:30.415421
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert user_fact_collector.name == 'user'
    assert user_fact_collector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                                  'user_gecos', 'user_dir', 'user_shell',
                                                  'real_user_id', 'effective_user_id',
                                                  'real_group_id', 'effective_group_id'])


# Generated at 2022-06-20 20:12:35.096839
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    fc = UserFactCollector()
    assert fc.name == 'user'
    assert fc._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                'user_gecos', 'user_dir', 'user_shell',
                                'real_user_id', 'effective_user_id',
                                'real_group_id', 'effective_group_id'])


# Generated at 2022-06-20 20:12:35.514486
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
   pass

# Generated at 2022-06-20 20:12:36.339203
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    assert UserFactCollector().collect()

# Generated at 2022-06-20 20:12:38.886961
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    x = UserFactCollector()
    assert(x.collect()['user_id'] == getpass.getuser())

# Generated at 2022-06-20 20:12:46.260582
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    kf = UserFactCollector()

    assert kf.collect() is not None

# Generated at 2022-06-20 20:12:56.108828
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Create a class object of UserFactCollector class
    user_fact_collector = UserFactCollector()

    # Call the method collect of UserFactCollector class
    result = user_fact_collector.collect()

    # Assert the result
    assert result['user_id'] == getpass.getuser()
    assert isinstance(result['user_id'], str)
    assert isinstance(result['user_uid'], int)
    assert isinstance(result['user_gid'], int)
    assert isinstance(result['user_gecos'], str)
    assert isinstance(result['user_dir'], str)
    assert isinstance(result['user_shell'], str)
    assert isinstance(result['real_user_id'], int)

# Generated at 2022-06-20 20:13:06.211802
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts_collector = UserFactCollector()
    collected_facts = user_facts_collector.collect()

    assert isinstance(collected_facts, dict)
    assert 'user_id' in collected_facts
    assert 'user_uid' in collected_facts
    assert 'user_gid' in collected_facts
    assert 'user_gecos' in collected_facts
    assert 'user_dir' in collected_facts
    assert 'user_shell' in collected_facts
    assert 'real_user_id' in collected_facts
    assert 'effective_user_id' in collected_facts
    assert 'real_group_id' in collected_facts
    assert 'effective_group_id' in collected_facts