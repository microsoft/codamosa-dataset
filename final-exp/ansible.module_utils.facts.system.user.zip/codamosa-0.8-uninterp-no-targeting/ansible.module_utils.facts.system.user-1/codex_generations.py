

# Generated at 2022-06-20 20:03:52.774955
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():

    obj = UserFactCollector()

    assert obj.name == 'user'
    assert set(obj._fact_ids) == set(['user_id', 'user_uid', 'user_gid',
                                      'user_gecos', 'user_dir', 'user_shell',
                                      'real_user_id', 'effective_user_id',
                                      'real_group_id', 'effective_group_id'])


# Generated at 2022-06-20 20:03:53.849674
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert user_fact_collector.name == 'user'

# Generated at 2022-06-20 20:03:56.337092
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector()
    assert user_facts.collect() == user_facts.collect()
    assert user_facts.get_facts() == user_facts.collect()

# Generated at 2022-06-20 20:03:59.308487
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user = UserFactCollector()
    user_facts = user.collect()

    # Ensure it returns a dictionary
    assert type(user_facts) == dict
    # Ensure expected fact is returned
    assert 'user_id' in user_facts
    assert user_facts['user_id'] == getpass.getuser()

# Generated at 2022-06-20 20:04:04.341058
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()
    assert 'ansible_user_id' in user_facts
    assert 'ansible_user_uid' in user_facts
    assert 'ansible_user_gid' in user_facts
    assert 'ansible_user_gecos' in user_facts
    assert 'ansible_user_dir' in user_facts
    assert 'ansible_user_shell' in user_facts
    assert 'ansible_real_user_id' in user_facts
    assert 'ansible_effective_user_id' in user_facts
    assert 'ansible_real_group_id' in user_facts
    assert 'ansible_effective_group_id' in user_facts

# Generated at 2022-06-20 20:04:07.408643
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collector = UserFactCollector()
    result = collector.collect()
    assert result['user_id'] == getpass.getuser()

# Generated at 2022-06-20 20:04:09.737039
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ufc = UserFactCollector()
    assert isinstance(ufc, UserFactCollector)
    assert ufc.name == 'user'

# Generated at 2022-06-20 20:04:11.684041
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
  userFactCollector = UserFactCollector()
  assert userFactCollector.name == 'user'


# Generated at 2022-06-20 20:04:15.952843
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()

    # test case 1 - only call the function
    user_fact_collector.collect()

    # test case 2 - call the function with arguments
    # user_fact_collector.collect(module = module_name, collected_facts = dict)

# Generated at 2022-06-20 20:04:26.061382
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    test_facts = UserFactCollector.collect()
    assert isinstance(test_facts, dict)
    assert isinstance(test_facts['user_id'], str)
    assert isinstance(test_facts['user_uid'], int)
    assert isinstance(test_facts['user_gid'], int)
    assert isinstance(test_facts['user_gecos'], str)
    assert isinstance(test_facts['user_dir'], str)
    assert isinstance(test_facts['user_shell'], str)
    assert isinstance(test_facts['real_user_id'], int)
    assert isinstance(test_facts['effective_user_id'], int)
    assert isinstance(test_facts['real_group_id'], int)

# Generated at 2022-06-20 20:04:35.246140
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    collector = UserFactCollector()
    assert collector.name == 'user'
    # The following test is valid for Unix systems only
    assert collector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                       'user_gecos', 'user_dir', 'user_shell',
                                       'real_user_id', 'effective_user_id',
                                       'real_group_id', 'effective_group_id'])


# Generated at 2022-06-20 20:04:39.109623
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():

    user_facts = UserFactCollector()
    assert user_facts.name == 'user'
    assert user_facts.user_facts == 'user'
    assert user_facts.cacheable == True
    assert user_facts.cache_valid_time == 30

# Generated at 2022-06-20 20:04:45.150064
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
  assert UserFactCollector.name == 'user'
  assert UserFactCollector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                             'user_gecos', 'user_dir', 'user_shell',
                                             'real_user_id', 'effective_user_id',
                                             'effective_group_ids'])


# Generated at 2022-06-20 20:04:51.324173
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ut_user_fact_collector = UserFactCollector()
    assert ut_user_fact_collector.name == 'user'
    assert ut_user_fact_collector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                                    'user_gecos', 'user_dir', 'user_shell',
                                                    'real_user_id', 'effective_user_id',
                                                    'effective_group_ids'])

# Generated at 2022-06-20 20:04:57.220127
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact = UserFactCollector()
    assert user_fact.name == 'user'
    assert user_fact._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                       'user_gecos', 'user_dir', 'user_shell',
                                       'real_user_id', 'effective_user_id',
                                       'effective_group_ids'])


# Generated at 2022-06-20 20:05:04.565996
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
   ufc = UserFactCollector(None)

   gather_subset = ['all']
   gather_timeout = 10
   result = ufc.collect(gather_subset=gather_subset, gather_timeout=gather_timeout)
   assert 'user_id' in result
   assert 'user_uid' in result
   assert 'user_gid' in result
   assert 'user_gecos' in result
   assert 'user_dir' in result
   assert 'user_shell' in result
   assert 'real_group_id' in result
   assert 'effective_group_id' in result

# Generated at 2022-06-20 20:05:06.885507
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Should return a dictionary that contains only user facts
    collector = UserFactCollector()
    assert collector.collect() != None


# Generated at 2022-06-20 20:05:13.434740
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    assert UserFactCollector().name == 'user'
    assert UserFactCollector()._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                                 'user_gecos', 'user_dir', 'user_shell',
                                                 'real_user_id', 'effective_user_id',
                                                 'effective_group_ids'])

# Generated at 2022-06-20 20:05:19.111037
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ufc = UserFactCollector()
    assert ufc.name == 'user'
    assert ufc._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                 'user_gecos', 'user_dir', 'user_shell',
                                 'real_user_id', 'effective_user_id',
                                 'effective_group_ids'])


# Generated at 2022-06-20 20:05:26.358160
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert user_fact_collector.name == 'user'
    assert (user_fact_collector._fact_ids) == ('user_gecos',
                                               'effective_group_ids',
                                               'real_user_id',
                                               'user_id',
                                               'user_shell',
                                               'user_dir',
                                               'effective_user_id',
                                               'user_uid',
                                               'user_gid')


# Generated at 2022-06-20 20:05:34.975568
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # TODO: implement this test
    assert False

# Generated at 2022-06-20 20:05:36.784744
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # This is to test whether the method UserFactCollector.collect() collects expected user facts.
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()
    assert type(user_facts) == dict

# Generated at 2022-06-20 20:05:41.799556
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    module = None
    collected_facts = None
    user_facts = UserFactCollector().collect(module, collected_facts)
    assert len(user_facts) == 8
    for fact in user_facts:
        assert fact in ['user_id', 'user_uid', 'user_gid',
                        'user_gecos', 'user_dir', 'user_shell',
                        'real_user_id', 'effective_user_id']

# Generated at 2022-06-20 20:05:50.206409
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    gefacs = UserFactCollector()
    res = gefacs.collect()
    assert res['user_id'] == getpass.getuser()
    pwent = pwd.getpwnam(getpass.getuser())
    assert res['user_uid'] == pwent.pw_uid
    assert res['user_gid'] == pwent.pw_gid
    assert res['user_gecos'] == pwent.pw_gecos
    assert res['user_dir'] == pwent.pw_dir
    assert res['user_shell'] == pwent.pw_shell
    assert res['real_user_id'] == os.getuid()
    assert res['effective_user_id'] == os.geteuid()
    assert res['real_group_id'] == os.getgid()
   

# Generated at 2022-06-20 20:05:52.238897
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    #TODO
    pass

# Generated at 2022-06-20 20:05:57.974984
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    test_coll = UserFactCollector()
    assert test_coll.name == 'user'
    assert test_coll.platform == 'all'
    assert sorted(test_coll._fact_ids) == sorted(['user_id', 'user_uid', 'user_gid',
                     'user_gecos', 'user_dir', 'user_shell',
                     'real_user_id', 'effective_user_id',
                     'effective_group_ids'])

# Generated at 2022-06-20 20:05:58.437133
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    pass

# Generated at 2022-06-20 20:06:01.913088
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    print('Testing constructor of UserFactCollector')
    user_fact_collector = UserFactCollector()
    assert user_fact_collector is not None


# Generated at 2022-06-20 20:06:04.113723
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ufc = UserFactCollector()
    assert ufc.name == 'user'
    assert isinstance(ufc._fact_ids, set)

# Generated at 2022-06-20 20:06:10.946185
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_info = UserFactCollector().collect()
    assert user_info['user_id'] == getpass.getuser()
    assert user_info['user_uid'] == os.getuid()
    assert user_info['user_gid'] == os.getgid()
    assert 'user_gecos' in user_info['user_gecos']
    assert user_info['real_user_id'] == os.getuid()
    assert user_info['effective_user_id'] == os.geteuid()
    assert user_info['real_group_id'] == os.getgid()
    assert user_info['effective_group_id'] == os.getgid()

# Generated at 2022-06-20 20:06:21.828662
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    user_facts = ufc.collect()

    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['real_user_id'] == os.getuid()
    assert user_facts['effective_user_id'] == os.geteuid()
    assert user_facts['real_group_id'] == os.getgid()
    assert user_facts['effective_group_id'] == os.getgid()

# Generated at 2022-06-20 20:06:24.906222
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collector = UserFactCollector()

    # Assert that the collect method
    # return a dict of user facts
    assert isinstance(collector.collect(), dict)

# Generated at 2022-06-20 20:06:26.558226
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
	Collector = UserFactCollector()
	assert Collector.collect()['user_id'] == getpass.getuser()

# Generated at 2022-06-20 20:06:32.725307
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert user_fact_collector.name == 'user'
    assert user_fact_collector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                                 'user_gecos', 'user_dir', 'user_shell',
                                                 'real_user_id', 'effective_user_id',
                                                 'effective_group_ids'])

# Generated at 2022-06-20 20:06:37.513934
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    fc = UserFactCollector()
    assert fc.name == 'user'
    assert fc._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                'user_gecos', 'user_dir', 'user_shell',
                                'real_user_id', 'effective_user_id',
                                'effective_group_ids'])


# Generated at 2022-06-20 20:06:39.914916
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert user_fact_collector.name == 'user'
    assert len(user_fact_collector._fact_ids) == 8

# Generated at 2022-06-20 20:06:44.206083
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user = UserFactCollector()
    assert user.name == 'user'
    assert user._fact_ids == set(['user_id', 'user_uid', 'user_gid', 'user_gecos', 'user_dir', 'user_shell', 'real_user_id', 'effective_user_id', 'effective_group_ids'])


# Generated at 2022-06-20 20:06:54.535215
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    cur = UserFactCollector()
    cur_dict = cur.collect()
    assert isinstance(cur_dict, dict)
    assert 'user_id' in cur_dict
    assert 'user_uid' in cur_dict
    assert 'user_gid' in cur_dict
    assert 'user_gecos' in cur_dict
    assert 'user_dir' in cur_dict
    assert 'user_shell' in cur_dict
    assert 'real_user_id' in cur_dict
    assert 'effective_user_id' in cur_dict
    assert 'real_group_id' in cur_dict
    assert 'effective_group_id' in cur_dict

# Generated at 2022-06-20 20:06:56.503877
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    userFactCollector = UserFactCollector()
    userFactCollector.collect()


# Generated at 2022-06-20 20:07:01.939450
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user = UserFactCollector()
    expected_name = 'user'
    expected_fact_ids = {'user_id', 'user_uid', 'user_gid',
                         'user_gecos', 'user_dir', 'user_shell',
                         'real_user_id', 'effective_user_id',
                         'real_group_id', 'effective_group_id'}
    assert user._name == expected_name
    assert user._fact_ids == expected_fact_ids


# Generated at 2022-06-20 20:07:20.320577
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    assert UserFactCollector.name == 'user'
    assert UserFactCollector._fact_ids == set(['user_id', 'user_uid',
                                               'user_gid', 'user_gecos',
                                               'user_dir', 'user_shell',
                                               'real_user_id',
                                               'effective_user_id',
                                               'effective_group_ids'])

# Generated at 2022-06-20 20:07:21.185438
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    UserFactCollector()


# Generated at 2022-06-20 20:07:24.093839
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    uf = UserFactCollector()
    result = uf.collect()
    assert 'user_id' in result
    assert result.get('user_id') == getpass.getuser()


# Generated at 2022-06-20 20:07:31.096066
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    collector = UserFactCollector()
    assert collector.name == "user"
    assert collector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                       'user_gecos', 'user_dir', 'user_shell',
                                       'real_user_id', 'effective_user_id',
                                       'effective_group_ids'])


# Generated at 2022-06-20 20:07:36.947069
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ufc = UserFactCollector()
    assert ufc.name == 'user'
    assert ufc._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                 'user_gecos', 'user_dir', 'user_shell',
                                 'real_user_id', 'real_group_id',
                                 'effective_user_id', 'effective_group_id'])

# Generated at 2022-06-20 20:07:46.504657
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import pwd
    from ansible.module_utils.facts.collector import UserFactCollector

    fact_c = UserFactCollector()
    fact_c.collect()
    pwent = pwd.getpwuid(os.getuid())

# Generated at 2022-06-20 20:07:50.578115
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    module = {"user": {"uid": "", "gid": "", "gecos": "", "dir": "", "shell": ""}}
    test_user = UserFactCollector()
    assert test_user.collect(module) == module

# Generated at 2022-06-20 20:07:57.689064
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_facts_collector = UserFactCollector()
    assert user_facts_collector.name == "user"
    assert user_facts_collector._fact_ids == set(['user_id', 'user_uid',
                                                  'user_gid', 'user_gecos',
                                                  'user_dir', 'user_shell',
                                                  'real_user_id',
                                                  'effective_user_id',
                                                  'effective_group_ids'])

# Generated at 2022-06-20 20:08:06.655608
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector().collect()
    assert 'user_id' in user_facts
    assert 'user_uid' in user_facts
    assert 'user_gid' in user_facts
    assert 'user_gecos' in user_facts
    assert 'user_dir' in user_facts
    assert 'user_shell' in user_facts
    assert 'real_user_id' in user_facts
    assert 'effective_user_id' in user_facts
    assert 'effective_group_ids' in user_facts

# Generated at 2022-06-20 20:08:15.928700
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    module = {'ANSIBLE_MODULE_ARGS':{'test':'test'}}
    fact_collector = UserFactCollector()
    fact_collector.collect(module)

# Generated at 2022-06-20 20:08:51.115935
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collector = UserFactCollector()
    facts = collector.collect()

    assert facts is not None
    assert isinstance(facts, dict)
    assert 'user_id' in facts
    assert 'user_uid' in facts
    assert 'user_gid' in facts
    assert 'user_gecos' in facts
    assert 'user_dir' in facts
    assert 'user_shell' in facts
    assert 'real_user_id' in facts
    assert 'effective_user_id' in facts
    assert 'real_group_id' in facts
    assert 'effective_group_id' in facts

# Generated at 2022-06-20 20:09:02.215091
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fact = UserFactCollector()
    collected_facts = {}
    fact_value = fact.collect(collected_facts)
    assert fact_value['user_id'] == getpass.getuser()
    assert fact_value['user_uid'] == pwd.getpwuid(os.getuid()).pw_uid
    assert fact_value['user_gid'] == pwd.getpwuid(os.getuid()).pw_gid
    assert fact_value['user_dir'] == pwd.getpwuid(os.getuid()).pw_dir
    assert fact_value['user_shell'] == pwd.getpwuid(os.getuid()).pw_shell
    assert fact_value['real_user_id'] == os.getuid()

# Generated at 2022-06-20 20:09:04.091483
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Unit test for method collect of class UserFactCollector
    f = UserFactCollector()
    facts = f.collect()
    assert (facts != {})

# Generated at 2022-06-20 20:09:07.725682
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert user_fact_collector._fact_ids == {
        'user_id', 'user_uid', 'user_gid',
        'user_gecos', 'user_dir', 'user_shell',
        'real_user_id', 'effective_user_id',
        'effective_group_ids'}

# Generated at 2022-06-20 20:09:11.955556
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user = UserFactCollector()
    assert user.name == 'user'
    assert isinstance(user._fact_ids, set)

# Generated at 2022-06-20 20:09:12.544526
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    pass

# Generated at 2022-06-20 20:09:14.566005
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert isinstance(user_fact_collector, UserFactCollector)

# Generated at 2022-06-20 20:09:19.319763
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fact_collector = UserFactCollector()
    fact_collector.collect()
    assert sorted(fact_collector.collect()) == sorted(['user_id', 'user_uid', 'user_gid',
                     'user_gecos', 'user_dir', 'user_shell',
                     'real_user_id', 'effective_user_id',
                     'real_group_id', 'effective_group_id'])

# Generated at 2022-06-20 20:09:24.909309
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    from ansible.module_utils.facts.collector import BaseFactCollector
    userfact = UserFactCollector()
    assert isinstance(userfact, BaseFactCollector)
    assert userfact.name == 'user'
    assert userfact._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                     'user_gecos', 'user_dir', 'user_shell',
                     'real_user_id', 'effective_user_id',
                     'effective_group_ids'])

# Generated at 2022-06-20 20:09:32.911842
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    obj = UserFactCollector()
    ans = obj.collect()
    assert ans == {'effective_group_id': 1000, 'effective_user_id': 1000, 'real_group_id': 1000, 'real_user_id': 1000, 'user_dir': '/home/eggelbus', 'user_gecos': 'foo,', 'user_gid': 1000, 'user_id': 'eggelbus', 'user_shell': '/bin/bash', 'user_uid': 1000}

# Generated at 2022-06-20 20:10:35.803754
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ufc = UserFactCollector()
    assert ufc.name == 'user'
    assert ufc._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                 'user_gecos', 'user_dir', 'user_shell',
                                 'real_user_id', 'effective_user_id',
                                 'effective_group_ids'])


# Generated at 2022-06-20 20:10:44.912565
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    from ansible.module_utils.facts import fact_cache
    from ansible.module_utils.facts.collector import FactCollector

    fact_cache.FACT_CACHE['has_user_collector'] = True
    fact_cache.FACT_CACHE['user_collector'] = UserFactCollector()
    facts = FactCollector().collect(module=None,
                                    collected_facts=fact_cache.FACT_CACHE)

    assert 'user_id' in facts
    assert 'user_uid' in facts
    assert 'user_gid' in facts
    assert 'user_gecos' in facts
    assert 'user_dir' in facts
    assert 'user_shell' in facts
    assert 'real_user_id' in facts
    assert 'effective_user_id' in facts

# Generated at 2022-06-20 20:10:48.333472
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    """
    Test collecting user facts.
    """
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()

    # Test facts are collected.
    assert user_facts is not None
    assert len(user_facts) > 0


# Generated at 2022-06-20 20:10:52.871974
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():

    ufc = UserFactCollector()
    assert ufc.name == 'user'
    assert ufc._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                     'user_gecos', 'user_dir', 'user_shell',
                     'real_user_id', 'effective_user_id',
                     'effective_group_ids'])


# Generated at 2022-06-20 20:11:00.067904
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    user_facts = ufc.collect()
    assert user_facts['user_id'] == getpass.getuser()
    assert 'user_uid' in user_facts
    assert 'user_gid' in user_facts
    assert 'user_gecos' in user_facts
    assert 'user_dir' in user_facts
    assert 'user_shell' in user_facts
    assert 'real_user_id' in user_facts
    assert 'effective_user_id' in user_facts
    assert 'real_group_id' in user_facts
    assert 'real_group_id' in user_facts

# Generated at 2022-06-20 20:11:08.987763
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    assert ufc.collect() == {'user_id': 'root',
                             'user_uid': 0,
                             'user_gid': 0,
                             'user_gecos': 'root',
                             'user_dir': '/root',
                             'user_shell': '/bin/bash',
                             'real_user_id': 0,
                             'effective_user_id': 0,
                             'real_group_id': 0,
                             'effective_group_id': 0}

# Generated at 2022-06-20 20:11:11.763042
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ufc = UserFactCollector()
    assert ufc.name == 'user'
    assert isinstance(ufc._fact_ids, set)
    assert len(ufc._fact_ids) == 9



# Generated at 2022-06-20 20:11:19.657584
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Assert that empty facts are returned if the pseudo-class pwd is not mocked
    collector = UserFactCollector()
    facts = collector.collect()

    assert(facts == {'user_id': os.environ['USER'],
                     'user_uid': 0,
                     'user_gid': 0,
                     'user_gecos': '',
                     'user_dir': '',
                     'user_shell': '',
                     'real_user_id': os.getuid(),
                     'effective_user_id': os.geteuid(),
                     'real_group_id': os.getgid(),
                     'effective_group_id': os.getgid()})

# Generated at 2022-06-20 20:11:25.608170
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    user_fact_collector_name = user_fact_collector.name
    user_fact_collector_fact_ids = user_fact_collector._fact_ids

    assert user_fact_collector_name == 'user'
    assert user_fact_collector_fact_ids == set(['user_id', 'user_uid',
        'user_gid', 'user_gecos', 'user_dir', 'user_shell',
        'real_user_id', 'effective_user_id', 'effective_group_ids'])

# Generated at 2022-06-20 20:11:31.079115
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    c = UserFactCollector()
    res = c.collect()
    assert isinstance(res, dict)
    assert 'user_id' in res
    assert 'user_uid' in res
    assert 'user_gid' in res
    assert 'user_gecos' in res
    assert 'user_dir' in res
    assert 'user_shell' in res
    assert 'real_user_id' in res
    assert 'effective_user_id' in res
    assert 'effective_group_ids' in res