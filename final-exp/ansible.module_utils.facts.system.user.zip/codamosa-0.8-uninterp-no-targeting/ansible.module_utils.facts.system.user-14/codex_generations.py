

# Generated at 2022-06-20 20:03:42.997690
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert user_fact_collector.name == 'user'
    assert len(user_fact_collector._fact_ids) == 9

# Generated at 2022-06-20 20:03:50.886085
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact = UserFactCollector
    user_fact_result = user_fact.collect()

    assert isinstance(user_fact_result, dict)
    assert isinstance(user_fact_result['user_id'], str)
    assert isinstance(user_fact_result['user_uid'], int)
    assert isinstance(user_fact_result['user_gid'], int)
    assert isinstance(user_fact_result['user_gecos'], str)
    assert isinstance(user_fact_result['user_dir'], str)
    assert isinstance(user_fact_result['user_shell'], str)
    assert isinstance(user_fact_result['real_user_id'], int)
    assert isinstance(user_fact_result['effective_user_id'], int)

# Generated at 2022-06-20 20:03:55.492704
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    u = UserFactCollector()
    assert u.name == 'user'
    assert set(u._fact_ids) == set(['user_id', 'user_uid', 'user_gid',
                                    'user_gecos', 'user_dir', 'user_shell',
                                    'real_user_id', 'effective_user_id',
                                    'effective_group_ids'])


# Generated at 2022-06-20 20:04:01.386540
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    # expected keys
    expected_keys = {'user_id', 'user_uid', 'user_gid',
                     'user_gecos', 'user_dir', 'user_shell',
                     'real_user_id', 'effective_user_id',
                     'real_group_id', 'effective_group_id'}

    # instantiate class
    user_fact_collector = UserFactCollector()
    user_fact_collector_keys = user_fact_collector.collect().keys()

    # assert test_keys is subset of collector_keys
    assert expected_keys.issubset(user_fact_collector_keys)

# Generated at 2022-06-20 20:04:07.871324
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    userfact = UserFactCollector()
    assert userfact.name == 'user'
    assert _fact_ids == set(['user_id', 'user_uid', 'user_gid',
                     'user_gecos', 'user_dir', 'user_shell',
                     'real_user_id', 'effective_user_id',
                     'effective_group_ids'])


# Generated at 2022-06-20 20:04:17.191676
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # This is a unittest for the collect method of class UserFactCollector
    test_facts = {'user_id': 'ansible', 'user_uid': 501, 'user_gid': 20,
                  'user_gecos': 'ansible,,,', 'user_dir': '/Users/ansible',
                  'user_shell': '/bin/bash', 'real_user_id': 501,
                  'effective_user_id': 501, 'real_group_id': 20,
                  'effective_group_id': 20}
    user_fact_collector = UserFactCollector()
    user_fact_collector.collect()

    assert user_fact_collector.collect() == test_facts


# Generated at 2022-06-20 20:04:24.488920
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_info = UserFactCollector().collect()

    assert user_info['user_id']
    assert user_info['user_uid']
    assert user_info['user_gid']
    assert user_info['user_gecos']
    assert user_info['user_dir']
    assert user_info['user_shell']
    assert user_info['real_user_id']
    assert user_info['effective_user_id']
    assert user_info['real_group_id']
    assert user_info['effective_group_id']

# Generated at 2022-06-20 20:04:29.824248
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = {'user_id': 'vagrant',
                  'user_uid': 1000,
                  'user_gid': 1000,
                  'user_gecos': 'vagrant,,,',
                  'user_dir': '/home/vagrant',
                  'user_shell': '/bin/bash',
                  'real_user_id': 1000,
                  'effective_user_id': 1000,
                  'real_group_id': 1000,
                  'effective_group_id': 1000}
    collector = UserFactCollector()
    assert user_facts == collector.collect()

# Generated at 2022-06-20 20:04:36.423406
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    test_fact_collector = UserFactCollector()
    facts = test_fact_collector.collect()
    assert 'user_id' in facts
    assert 'user_uid' in facts
    assert 'user_gid' in facts
    assert 'user_gecos' in facts
    assert 'user_dir' in facts
    assert 'user_shell' in facts
    assert 'real_user_id' in facts
    assert 'effective_user_id' in facts
    assert 'effective_group_ids' in facts

# Generated at 2022-06-20 20:04:39.112964
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_facts = UserFactCollector()
    assert user_facts is not None


# Generated at 2022-06-20 20:04:52.332662
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector().collect()

    assert isinstance(user_facts, dict)
    assert 'user_id' in user_facts
    assert 'user_uid' in user_facts
    assert 'user_gid' in user_facts
    assert 'user_gecos' in user_facts
    assert 'user_dir' in user_facts
    assert 'user_shell' in user_facts
    assert 'real_user_id' in user_facts
    assert 'effective_user_id' in user_facts
    assert 'real_group_id' in user_facts
    assert 'effective_group_id' in user_facts


# Generated at 2022-06-20 20:04:59.514755
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    factCollector = UserFactCollector()
    assert factCollector.name == 'user'
    assert factCollector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                           'user_gecos', 'user_dir', 'user_shell',
                                           'real_user_id', 'effective_user_id',
                                           'effective_group_ids'])


# Generated at 2022-06-20 20:05:00.395170
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    obj = UserFactCollector()
    assert obj

# Generated at 2022-06-20 20:05:02.860267
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    obj = UserFactCollector()
    assert isinstance(obj, UserFactCollector)
    assert isinstance(obj, BaseFactCollector)
    assert isinstance(obj, object)


# Generated at 2022-06-20 20:05:15.245989
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    input_user=UserFactCollector()
    user_facts = {}

    user_facts['user_id'] = getpass.getuser()
    try:
        pwent = pwd.getpwnam(getpass.getuser())
    except KeyError:
        pwent = pwd.getpwuid(os.getuid())

    user_facts['user_uid'] = pwent.pw_uid
    user_facts['user_gid'] = pwent.pw_gid
    user_facts['user_gecos'] = pwent.pw_gecos
    user_facts['user_dir'] = pwent.pw_dir
    user_facts['user_shell'] = pwent.pw_shell
    user_facts['real_user_id'] = os.getuid()

# Generated at 2022-06-20 20:05:25.471819
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.user import UserFactCollector

    # arrange

    # act
    user_fact_collector = UserFactCollector()
    user_fact = user_fact_collector.collect()

    # assert
    assert isinstance(user_fact_collector, UserFactCollector)
    assert isinstance(user_fact_collector, BaseFactCollector)
    assert isinstance(user_fact_collector, Collector)
    assert user_fact is not None
    assert type(user_fact) == dict
    assert len(user_fact) == 8

# Generated at 2022-06-20 20:05:32.046359
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    
    user_facts = ufc.collect()
    assert isinstance(user_facts, dict)

    # The user_id key is mandatory
    assert 'user_id' in user_facts

    def is_int_and_positive(value):
        return isinstance(value, int) and (value > 0)

    # The user_uid, user_gid, real_user_id and effective_user_id keys
    # are mandatory and should be integer > 0.
    assert 'user_uid' in user_facts
    assert is_int_and_positive(user_facts['user_uid'])
    assert 'user_gid' in user_facts
    assert is_int_and_positive(user_facts['user_gid'])

# Generated at 2022-06-20 20:05:43.087038
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # create test insatnce of UserFactCollector
    c = UserFactCollector

    import ansible.module_utils.facts.collector

    facts_module = ansible.module_utils.facts.collector

    # create an instance of LocalRPCConnection
    # we need it to create an instance of AnsibleModule
    connection = facts_module.LocalRPCConnection

    # create test instance of AnsibleModule
    test_module = facts_module.AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True,
        connection = connection
    )

    # test collect
    user_facts = c().collect(module=test_module)
    assert type(user_facts) is dict
    assert 'user_id' in user_facts
    assert 'user_uid' in user_facts

# Generated at 2022-06-20 20:05:48.439099
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_facts = UserFactCollector()
    assert user_facts.name == 'user'
    assert user_facts._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                     'user_gecos', 'user_dir', 'user_shell',
                     'real_user_id', 'effective_user_id',
                     'effective_group_ids'])
    assert user_facts.collect()['user_id'] == getpass.getuser()

# Generated at 2022-06-20 20:05:55.535603
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collector = UserFactCollector()

    user_facts = collector.collect()

    # we use 'real_user_id' as a test because it's unlikely to change
    # and we can't use 'user_id' since it might be 'root' in the case
    # of running tests in the Vagrant image
    assert isinstance(user_facts, dict)
    assert 'real_user_id' in user_facts.keys()
    assert 'user_gid' in user_facts.keys()
    assert 'user_uid' in user_facts.keys()

# Generated at 2022-06-20 20:06:10.783329
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import tempfile

    temp_file = tempfile.mkstemp()
    os.environ['ANSIBLE_CACHE_PLUGIN'] = 'jsonfile'
    os.environ['ANSIBLE_CACHE_PLUGIN_CONNECTION'] = temp_file[1]

    user_pwent = pwd.getpwnam(getpass.getuser())


# Generated at 2022-06-20 20:06:16.442556
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_facts = UserFactCollector()
    assert user_facts.name == 'user'
    assert user_facts._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                        'user_gecos', 'user_dir',
                                        'user_shell', 'real_user_id',
                                        'effective_user_id',
                                        'effective_group_ids'])


# Generated at 2022-06-20 20:06:23.237351
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    # Run the constructor of class UserFactCollector
    user_instance = UserFactCollector()

    # Run the constructor of super class BaseFactCollector
    BaseFactCollector()

    # Check if the constructor of UserFactCollector is working correctly
    assert user_instance.name == 'user'
    assert user_instance._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                           'user_gecos', 'user_dir', 'user_shell',
                                           'real_user_id', 'effective_user_id',
                                           'effective_group_ids'])


# Generated at 2022-06-20 20:06:24.088978
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_collector = UserFactCollector()
    assert user_collector.collect() != None

# Generated at 2022-06-20 20:06:25.086709
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_collector = UserFactCollector()
    collected_facts = user_collector.collect()
    assert isinstance(collected_facts, dict)

# Generated at 2022-06-20 20:06:28.184260
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import unittest
    import os
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.user import UserFactCollector

    class TestUserFactCollector(unittest.TestCase):
        def setUp(self):
            self.collector_instance = UserFactCollector()

        def test_collect(self):
            try:
                self.collector_instance.collect()
            except Exception as e:
                self.fail("test_collect() raised exception %s" % e)


# Generated at 2022-06-20 20:06:33.422500
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user = UserFactCollector()
    assert user.name == "user"
    assert user._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                  'user_gecos', 'user_dir', 'user_shell',
                                  'real_user_id', 'effective_user_id',
                                  'effective_group_ids'])

# Generated at 2022-06-20 20:06:35.359772
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    collector = UserFactCollector()
    assert collector.name == 'user'


# Generated at 2022-06-20 20:06:41.343368
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()
    assert user_facts['real_user_id'] == os.getuid()
    assert user_facts['effective_user_id'] == os.geteuid()
    assert user_facts['real_group_id'] == os.getgid()
    assert user_facts['effective_group_id'] == os.getgid()
    assert user_facts['user_id'] == getpass.getuser()

# Generated at 2022-06-20 20:06:42.301231
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    obj = UserFactCollector()
    assert isinstance(obj, UserFactCollector)


# Generated at 2022-06-20 20:06:56.891479
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert user_fact_collector.name == 'user'

# Generated at 2022-06-20 20:06:58.188669
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fixture = UserFactCollector()
    assert fixture.collect() is not None

# Generated at 2022-06-20 20:07:02.447310
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user = UserFactCollector()
    user_facts = user.collect()
    assert user_facts['user_id'] == getpass.getuser()
    # TODO: Add more thorough unit tests


# Generated at 2022-06-20 20:07:05.424038
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    test = UserFactCollector()
    assert hasattr(test, 'name')


# Generated at 2022-06-20 20:07:09.593500
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    import sys

    ufc = UserFactCollector()
    assert ufc.name == 'user'
    assert ufc._fact_ids == {'effective_group_ids', 'effective_user_id', 'real_user_id', 'user_dir', 'user_gecos', 'user_id', 'user_gid', 'user_shell', 'user_uid'}

# Generated at 2022-06-20 20:07:19.913540
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Check of user_id
    user_fact_col = UserFactCollector()
    user_fact = user_fact_col.collect()
    assert user_fact['user_id'] == getpass.getuser()

    # Check of user_uid
    try:
        pwent = pwd.getpwnam(getpass.getuser())
    except KeyError:
        pwent = pwd.getpwuid(os.getuid())

    assert user_fact['user_uid'] == pwent.pw_uid

    # Check of user_gid
    assert user_fact['user_gid'] == pwent.pw_gid

    # Check of user_gecos
    assert user_fact['user_gecos'] == pwent.pw_gecos

    # Check of user_dir
    assert user_

# Generated at 2022-06-20 20:07:21.433781
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user = UserFactCollector()
    assert isinstance(user, UserFactCollector)


# Generated at 2022-06-20 20:07:22.801479
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
  test_obj = UserFactCollector()
  assert test_obj is not None

# Generated at 2022-06-20 20:07:26.646545
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    # Test default behaviour
    ufc = UserFactCollector()
    assert len(ufc._fact_ids) == 9
    assert ufc.name == 'user'


# Generated at 2022-06-20 20:07:37.129251
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    # Create an instance of UserFactCollector
    test = UserFactCollector()
    # Check if the returned value of "name" is "user"
    assert test.name == "user"
    # Check if the returned list of "_fact_ids" matches with ["user_id", "user_uid", "user_gid", "user_gecos", "user_dir", "user_shell", "real_user_id", "effective_user_id", "effective_group_ids"]
    assert test._fact_ids == set(['user_id', 'user_uid', 'user_gid', 'user_gecos', 'user_dir', 'user_shell', 'real_user_id', 'effective_user_id', 'effective_group_ids'])


# Generated at 2022-06-20 20:08:14.073312
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import os
    import pwd
    import pytest

    class MockedModule():
        def __init__(self, user_id, user_uid, user_gid, user_gecos, user_dir, user_shell, real_user_id, effective_user_id, effective_group_ids):
            self.user_id = user_id
            self.user_uid = user_uid
            self.user_gid = user_gid
            self.user_gecos = user_gecos
            self.user_dir = user_dir
            self.user_shell = user_shell
            self.real_user_id = real_user_id
            self.effective_user_id = effective_user_id
            self.effective_group_ids = effective_group_ids


# Generated at 2022-06-20 20:08:17.122115
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    pass # TODO implement me

# Generated at 2022-06-20 20:08:22.722186
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert user_fact_collector.name == 'user'
    assert user_fact_collector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                                 'user_gecos', 'user_dir', 'user_shell',
                                                 'real_user_id', 'effective_user_id',
                                                 'effective_group_ids'])


# Generated at 2022-06-20 20:08:26.944942
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    userfact = UserFactCollector()
    name = "user"
    fact_ids = set(['user_id', 'user_uid', 'user_gid',
                    'user_gecos', 'user_dir', 'user_shell',
                    'real_user_id', 'effective_user_id',
                    'effective_group_ids'])

    assert userfact.name == name
    assert userfact._fact_ids == fact_ids

# Generated at 2022-06-20 20:08:34.017008
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ufc = UserFactCollector()
    assert ufc.name == 'user'
    assert ufc._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                 'user_gecos', 'user_dir', 'user_shell',
                                 'real_user_id', 'effective_user_id',
                                 'effective_group_ids'])


# Generated at 2022-06-20 20:08:35.301725
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    collector = UserFactCollector()
    assert collector.name == 'user'

# Generated at 2022-06-20 20:08:39.916290
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    inst = UserFactCollector()
    assert inst.name == 'user'
    assert inst._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                  'user_gecos', 'user_dir', 'user_shell',
                                  'real_user_id', 'effective_user_id',
                                  'effective_group_ids'])



# Generated at 2022-06-20 20:08:47.799370
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert user_fact_collector.name == 'user'
    assert user_fact_collector._fact_ids == \
           set(['user_id', 'user_uid', 'user_gid', 'user_gecos',
                'user_dir', 'user_shell', 'real_user_id',
                'effective_user_id', 'effective_group_ids'])

# Generated at 2022-06-20 20:08:57.061765
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    # Create instance of class UserFactCollector
    fact_collector = UserFactCollector()
    # Get collect method of class UserFactCollector
    collect_method = fact_collector.collect

    # Create empty dictionary named user_facts
    user_facts = {}

    # Call collect_method and store the result in user_facts
    user_facts = collect_method(user_facts)

    # Assertion to check that returned dictionary has the same keys as UserFactCollector._fact_ids
    assert set(user_facts.keys()) == fact_collector._fact_ids

    # Assertion to check value of user_id key of user_facts
    assert user_facts['user_id'] == getpass.getuser()

    # Assertion to check value of user_gecos key of user_facts

# Generated at 2022-06-20 20:09:07.330606
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Create instance
    inst = UserFactCollector()

    # Cleanup old test data in Ansible cache
    inst.clean()

    # Execute method 'collect'
    collected_facts = inst.collect()

    # Test if results are as expected
    assert collected_facts['ansible_facts']['user_gecos'] == 'root,,,root'
    assert collected_facts['ansible_facts']['user_dir'] == '/root'
    assert collected_facts['ansible_facts']['user_shell'] == '/bin/bash'
    assert collected_facts['ansible_facts']['user_uid'] == 0
    assert collected_facts['ansible_facts']['user_gid'] == 0
    assert collected_facts['ansible_facts']['user_id'] == 'root'
    assert collected_

# Generated at 2022-06-20 20:09:42.036329
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    mock_module = MagicMock()
    mock_module_params = MagicMock()

    obj = UserFactCollector()

    result = obj.collect(module=mock_module, collected_facts=mock_module_params)

    assert 'user_id' in result
    assert 'user_uid' in result
    assert 'user_gid' in result
    assert 'user_gecos' in result
    assert 'user_dir' in result
    assert 'user_shell' in result
    assert 'real_user_id' in result
    assert 'effective_user_id' in result
    assert 'real_group_id' in result
    assert 'effective_group_id' in result

# Generated at 2022-06-20 20:09:49.581404
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    def test_function(user_id):
        def getpwnam(uname):
            assert uname == user_id
            return pwd.struct_passwd((
                user_id, 'x', 1000, 1000,
                'user', '/home/user', '/bin/bash'))

        def getpwuid(uid):
            assert uid == 1000
            return pwd.struct_passwd((
                user_id, 'x', 1000, 1000,
                'user', '/home/user', '/bin/bash'))

        def getuid():
            return 1000

        def geteuid():
            return 1000

        def getgid():
            return 1000

        def getegid():
            return 1000

        collector = UserFactCollector(module=None)


# Generated at 2022-06-20 20:09:53.954695
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    x = UserFactCollector()
    assert x.name == 'user'
    assert x._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                               'user_gecos', 'user_dir', 'user_shell',
                               'real_user_id', 'effective_user_id',
                               'effective_group_ids'])


# Generated at 2022-06-20 20:09:59.034755
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    fact_collector = UserFactCollector()
    assert fact_collector.name == 'user'

    fact_ids = set(['user_id', 'user_uid', 'user_gid',
                    'user_gecos', 'user_dir', 'user_shell',
                    'real_user_id', 'effective_user_id',
                    'effective_group_id'])
    assert fact_collector._fact_ids == fact_ids

# Generated at 2022-06-20 20:10:00.345664
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    class_obj = UserFactCollector()
    assert class_obj.collect() == {}

# Generated at 2022-06-20 20:10:05.661086
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert user_fact_collector.name == 'user'
    assert user_fact_collector._fact_ids == {'user_id', 'user_uid', 'user_gid', 'user_gecos', 'user_dir', 'user_shell', 'real_user_id', 'effective_user_id', 'effective_group_ids'}

# Generated at 2022-06-20 20:10:11.753852
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ufc = UserFactCollector()
    assert ufc.name == 'user'
    assert ufc._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                 'user_gecos', 'user_dir', 'user_shell',
                                 'real_user_id', 'effective_user_id',
                                 'effective_group_ids'])

# Generated at 2022-06-20 20:10:23.333124
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    import pwd

    class TestUser():
        def __init__(self, pw_uid, pw_gid, pw_gecos, pw_dir, pw_shell):
            self.pw_uid = pw_uid
            self.pw_gid = pw_gid
            self.pw_gecos = pw_gecos
            self.pw_dir = pw_dir
            self.pw_shell = pw_shell

        def getpwnam(self, name):
            return self

        def getpwuid(self, uid):
            return self

    class TestGetPass():
        def __init__(self, user):
            self.user = user

        def getuser(self):
            return self.user


# Generated at 2022-06-20 20:10:33.726814
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    module_mock = lambda: None
    collected_facts_mock = {
        'user_id': 'test',
        'user_uid': 10000,
        'user_gid': 20000,
        'user_gecos': 'Test',
        'user_dir': '/home/test',
        'user_shell': '/bin/bash',
        'real_user_id': 0,
        'effective_user_id': 10000,
        'real_group_id': 0,
        'effective_group_id': 0
    }
    user_fact_collector = UserFactCollector()


# Generated at 2022-06-20 20:10:38.739754
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert user_fact_collector.name == 'user'
    assert set(user_fact_collector._fact_ids) == set(['user_id', 'user_uid', 'user_gid',
                                                      'user_gecos', 'user_dir', 'user_shell',
                                                      'real_user_id', 'effective_user_id',
                                                      'effective_group_ids'])

# Generated at 2022-06-20 20:11:47.341654
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert user_fact_collector.name == 'user'

# Generated at 2022-06-20 20:11:48.220183
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    fact_collector = UserFactCollector()

# Generated at 2022-06-20 20:11:55.724075
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collector = UserFactCollector()
    facts = collector.collect()

# Generated at 2022-06-20 20:12:06.002522
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user = UserFactCollector()
    assert user.name == 'user'
    assert 'user_id' in user._fact_ids
    assert 'user_gid' in user._fact_ids
    assert 'user_uid' in user._fact_ids
    assert 'user_gecos' in user._fact_ids
    assert 'user_dir' in user._fact_ids
    assert 'user_shell' in user._fact_ids
    assert 'real_user_id' in user._fact_ids
    assert 'effective_user_id' in user._fact_ids
    assert 'effective_group_ids' in user._fact_ids

# Generated at 2022-06-20 20:12:11.656837
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    f = UserFactCollector()
    assert f.name == 'user'
    expected_ids = {'user_id', 'user_uid', 'user_gid',
                    'user_gecos', 'user_dir', 'user_shell',
                    'real_user_id', 'effective_user_id',
                    'effective_group_ids'}
    assert f._fact_ids == expected_ids

# Generated at 2022-06-20 20:12:18.474880
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    collected_facts = {'user_id':'jle-devel'}
    user_fact_collector.collect(collected_facts=collected_facts)
    assert collected_facts['user_id'] == 'jle-devel'
    assert collected_facts['user_uid'] == 1000
    assert collected_facts['user_gid'] == 1000
    assert collected_facts['user_gecos'] == 'jle,,,'
    assert collected_facts['user_dir'] == '/home/jle-devel'
    assert collected_facts['user_shell'] == '/bin/bash'
    assert collected_facts['real_user_id'] == 1000
    assert collected_facts['effective_user_id'] == 1000
    assert collected_facts['real_group_id']

# Generated at 2022-06-20 20:12:22.933419
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    u = UserFactCollector()
    assert u.name == 'user'
    assert u._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                               'user_gecos', 'user_dir', 'user_shell',
                               'real_user_id', 'effective_user_id',
                               'effective_group_ids'])

# Generated at 2022-06-20 20:12:28.783758
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    c = UserFactCollector()
    assert c.name == 'user'
    assert c._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                               'user_gecos', 'user_dir', 'user_shell',
                               'real_user_id', 'effective_user_id',
                               'effective_group_ids'])


# Generated at 2022-06-20 20:12:34.143776
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector()
    result = user_facts.collect()
    assert result == {'effective_user_id': 1000, 'effective_group_id': 1000, 'user_gecos': 'test', 'user_id': 'test', 'real_group_id': 1000, 'user_shell': '/bin/bash', 'user_uid': 1000, 'real_user_id': 1000, 'user_gid': 1000, 'user_dir': '/home/test'}


# Generated at 2022-06-20 20:12:41.013832
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import sys
    import os
    import tempfile
    import copy

    user = os.environ.get("USER", "root")
    user_id = os.environ.get("USER", None)

    if user_id is None:
        user_id = os.environ.get("LOGNAME", None)
        if user_id is None:
            user_id = os.environ.get("SUDO_USER", None)

    (tmpfd, tmpfpath) = tempfile.mkstemp()