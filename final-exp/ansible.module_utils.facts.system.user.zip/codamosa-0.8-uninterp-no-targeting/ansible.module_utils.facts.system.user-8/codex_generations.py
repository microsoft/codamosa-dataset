

# Generated at 2022-06-20 20:03:50.558725
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()

    assert(user_facts['user_id'] == 'johnd')
    assert(user_facts['user_uid'] == 1000)
    assert(user_facts['user_gid'] == 100)
    assert(user_facts['user_gecos'] == 'John Doe,,,')
    assert(user_facts['user_dir'] == '/home/johnd')
    assert(user_facts['user_shell'] == '/bin/bash')
    assert(user_facts['real_user_id'] == 1000)
    assert(user_facts['effective_user_id'] == 1000)
    assert(user_facts['real_group_id'] == 100)

# Generated at 2022-06-20 20:03:56.081107
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fake_module = {}
    fake_collected_facts = {}
    ufact = UserFactCollector()
    facts = ufact.collect(fake_module, fake_collected_facts) 
    assert facts['user_id'] == getpass.getuser()
    assert facts['real_user_id'] == os.getuid()
    assert facts['effective_user_id'] == os.geteuid()
    assert facts['effective_group_id'] == os.getgid()
    assert facts['real_group_id'] == os.getgid()

# Generated at 2022-06-20 20:04:02.753012
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()
    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['user_uid'] == pwd.getpwnam(getpass.getuser()).pw_uid
    assert user_facts['user_gid'] == pwd.getpwnam(getpass.getuser()).pw_gid
    assert user_facts['user_gecos'] == pwd.getpwnam(getpass.getuser()).pw_gecos
    assert user_facts['user_dir'] == pwd.getpwnam(getpass.getuser()).pw_dir

# Generated at 2022-06-20 20:04:12.826583
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    uf = UserFactCollector()
    assert uf.name == 'user'
    assert 'user_id' in uf._fact_ids
    assert 'user_uid' in uf._fact_ids
    assert 'user_gid' in uf._fact_ids
    assert 'user_gecos' in uf._fact_ids
    assert 'user_dir' in uf._fact_ids
    assert 'user_shell' in uf._fact_ids
    assert 'real_user_id' in uf._fact_ids
    assert 'effective_user_id' in uf._fact_ids
    assert 'effective_group_ids' in uf._fact_ids


# Generated at 2022-06-20 20:04:17.955671
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector(None, None).collect()
    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['user_gecos'] == pwd.getpwnam(getpass.getuser()).pw_gecos
    assert user_facts['effective_user_id'] == os.geteuid()

# Generated at 2022-06-20 20:04:20.107257
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fact_collector = UserFactCollector()
    fact_collector.collect()
    assert fact_collector.name == 'user'

# Generated at 2022-06-20 20:04:29.099085
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Test for basic return of facts
    module_mock = {}
    facts_mock  = {}
    user_fact_collector = UserFactCollector()
    result = user_fact_collector.collect(module_mock, facts_mock)

    assert result['user_id'] == getpass.getuser()
    assert type(result['user_id']) == str

    assert result['user_uid'] == os.getuid()
    assert type(result['user_uid']) == int

    assert result['user_gid'] == os.getgid()
    assert type(result['user_gid']) == int

    assert result['user_gecos'] == pwd.getpwuid(os.getuid()).pw_gecos
    assert type(result['user_gecos']) == str



# Generated at 2022-06-20 20:04:34.989589
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Instantiate class UserFactCollector
    ufc = UserFactCollector()

    # Get the facts
    facts = ufc.collect()

    # Assert that the method returns a dictionary
    assert type(facts) == dict

    # Assert all keys in the dictionary
    assert set(facts) == ufc._fact_ids

    # Assert that keys 'user_id' and 'user_shell' are not empty
    assert facts['user_id']
    assert facts['user_shell']

# Generated at 2022-06-20 20:04:43.748563
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    # Generate an instance of the UserFactCollector class
    ufc = UserFactCollector()

    # Get user facts
    user_facts = ufc.collect()

    # Check if user ID is defined
    assert 'user_id' in user_facts
    assert isinstance(user_facts['user_id'], unicode)

    # Check if user UID is defined
    assert 'user_uid' in user_facts
    assert isinstance(user_facts['user_uid'], int)

    # Check if user GID is defined
    assert 'user_gid' in user_facts
    assert isinstance(user_facts['user_gid'], int)

    # Check if user GECOS is defined
    assert 'user_gecos' in user_facts

# Generated at 2022-06-20 20:04:54.527813
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    from ansible.module_utils.facts.collector import FactCollector

    # Test class UserFactCollector.
    # Because this method is using the module_utils library,
    # mock functions can not be used.

    # Get the instance of UserFactCollector
    class_user = FactCollector.__fact_classes__[UserFactCollector.name]()
    # Collect facts
    facts_user = class_user.collect()
    # Assert
    assert 'user_id' in facts_user.keys()
    assert 'user_uid' in facts_user.keys()
    assert 'user_gid' in facts_user.keys()
    assert 'user_gecos' in facts_user.keys()
    assert 'user_dir' in facts_user.keys()
    assert 'user_shell' in facts_user.keys

# Generated at 2022-06-20 20:04:58.992460
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_fact_collector.collect()


# Generated at 2022-06-20 20:05:02.710920
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fact_collector = UserFactCollector()
    fact_collector.collect()
    try:
        getpass.getuser()
        pwd.getpwuid(os.getuid())
    except KeyError:
        pwd.getpwuid(os.getuid())
    os.getuid()
    os.geteuid()
    os.getgid()
    os.getgid()


# Generated at 2022-06-20 20:05:03.763553
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    pass

# Generated at 2022-06-20 20:05:15.741667
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import os
    import pwd

    test_object = UserFactCollector()
    os.geteuid = lambda: 1000
    os.getuid = lambda: 1000
    getpass.getuser = lambda: "test_user"

    pwent = pwd.struct_passwd(("test_user", "x", 1000, 1000, "test_user", "", "/home/test_user", ""))
    pwd.getpwnam = lambda u: pwent
    pwd.getpwuid = lambda i: pwent

    user_facts = test_object.collect()
    assert user_facts["user_id"] == "test_user"
    assert user_facts["user_gecos"] == "test_user"
    assert user_facts["user_uid"] == 1000

# Generated at 2022-06-20 20:05:26.554939
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    userfact = UserFactCollector()
    collected_facts = userfact.collect()
    assert collected_facts['user_id'] == getpass.getuser()
    assert collected_facts['user_uid'] == os.getuid()
    assert collected_facts['user_gid'] == os.getgid()
    assert collected_facts['user_gecos'] != None
    assert collected_facts['user_dir'] != None
    assert collected_facts['user_shell'] != None
    assert collected_facts['real_user_id'] == os.getuid()
    assert collected_facts['real_group_id'] == os.getgid()
    assert collected_facts['effective_user_id'] == os.geteuid()
    assert collected_facts['effective_group_id'] == os.getegid()

# Generated at 2022-06-20 20:05:32.581995
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    ufc = UserFactCollector()
    result = ufc.collect()

    # Test if the user_id is returned
    assert 'user_id' in result

    # Test if the user_uid is returned
    assert 'user_uid' in result

    # Test if the user_gid is returned
    assert 'user_gid' in result

    # Test if the user_gecos is returned
    assert 'user_gecos' in result

    # Test if the user_dir is returned
    assert 'user_dir' in result

    # Test if the user_shell is returned
    assert 'user_shell' in result

    # Test if the real_user_id is returned
    assert 'real_user_id' in result

    # Test if the effective_user_id is returned
    assert 'effective_user_id' in result



# Generated at 2022-06-20 20:05:36.690825
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
  ufc = UserFactCollector()
  ret = ufc.collect()

  assert type(ret) is dict
  assert set(ret.keys()) == ufc._fact_ids

# Generated at 2022-06-20 20:05:41.722766
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collector = UserFactCollector()
    user_facts = collector.collect()
    assert user_facts['user_id'] == getpass.getuser()
    user_name = getpass.getuser()
    # Test if the fact 'user_uid' is same as that returned by function pwd.getpwnam()
    assert user_facts['user_uid'] == pwd.getpwnam(user_name).pw_uid


# Generated at 2022-06-20 20:05:46.432442
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    facts = UserFactCollector()
    assert facts.name == 'user'
    assert facts._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                   'user_gecos', 'user_dir', 'user_shell',
                                   'real_user_id', 'effective_user_id',
                                   'effective_group_ids'])

# Generated at 2022-06-20 20:05:56.616642
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    class MockUserFactCollector(UserFactCollector):
        def get_user_id(self):
            return 'userid'

        def get_user_uid(self):
            return 'useruid'

        def get_user_gid(self):
            return 'usergid'

        def get_user_gecos(self):
            return 'usergecos'

        def get_user_dir(self):
            return 'userdir'

        def get_user_shell(self):
            return 'usershell'

        def get_real_user_id(self):
            return 'realuserid'

        def get_effective_user_id(self):
            return 'effectiveuserid'

        def get_effective_group_ids(self):
            return 'effectivegroupids'


    user_facts = MockUserFactCollect

# Generated at 2022-06-20 20:06:09.835682
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import os
    import unittest

    from ansible.module_utils.facts.collector import BaseFactCollector

    class TestUserFactCollector(unittest.TestCase):
        def test_UserFactCollector(self):
            my_user_fact_collector = UserFactCollector()
            user_facts = my_user_fact_collector.collect()
            self.assertIsInstance(my_user_fact_collector, BaseFactCollector)
            self.assertIsInstance(user_facts, dict)

    my_test = TestUserFactCollector()
    my_test.test_UserFactCollector()

if __name__ == "__main__":
    import sys
    import platform
    import unittest


# Generated at 2022-06-20 20:06:14.920851
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ufc = UserFactCollector()
    assert ufc.name == 'user'
    assert sorted(ufc._fact_ids) == sorted(['user_id', 'user_uid', 'user_gid', 'user_gecos', 'user_dir', 'user_shell', 'real_user_id', 'effective_user_id', 'effective_group_ids'])

# Generated at 2022-06-20 20:06:15.460329
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    pass

# Generated at 2022-06-20 20:06:23.237258
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector().collect()

    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['user_uid'] == pwd.getpwnam(getpass.getuser()).pw_uid
    assert user_facts['user_gid'] == pwd.getpwnam(getpass.getuser()).pw_gid
    assert user_facts['user_gecos'] == pwd.getpwnam(getpass.getuser()).pw_gecos
    assert user_facts['user_dir'] == pwd.getpwnam(getpass.getuser()).pw_dir
    assert user_facts['user_shell'] == pwd.getpwnam(getpass.getuser()).pw_shell

# Generated at 2022-06-20 20:06:23.845916
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    pass

# Generated at 2022-06-20 20:06:34.048534
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    usr_obj = UserFactCollector()
    if sys.version_info[0] == 2:
        expected_dict = {'effective_group_id': 20,
                         'user_gecos': 'vagrant,,,',
                         'user_gid': 1000,
                         'user_dir': '/home/vagrant',
                         'real_group_id': 20,
                         'user_id': 'vagrant',
                         'effective_user_id': 1000,
                         'user_shell': '/bin/bash',
                         'user_uid': 1000,
                         'real_user_id': 1000}

# Generated at 2022-06-20 20:06:34.564153
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    UserFactCollector()

# Generated at 2022-06-20 20:06:39.639562
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    u_fc = UserFactCollector()
    assert u_fc.name == 'user'
    assert u_fc._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                 'user_gecos', 'user_dir', 'user_shell',
                                 'real_user_id', 'effective_user_id',
                                 'effective_group_ids'])

# Generated at 2022-06-20 20:06:47.195704
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    class FakeOsModule():

        def geteuid():
            return os.geteuid()

        def getuid():
            return os.getuid()

        def getegid():
            return os.getegid()

        def getgid():
            return os.getgid()

    class FakePwdModule():

        def getpwuid(uid):
            pwent = pwd.getpwuid(uid)
            return pwent

        def getpwnam(name):
            pwent = pwd.getpwnam(name)
            return pwent

    class FakeGetPassModule():

        def getuser():
            getpass.getuser()
            return os.getlogin()


# Generated at 2022-06-20 20:06:54.783799
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert user_fact_collector
    assert user_fact_collector.name == 'user'
    assert user_fact_collector._fact_ids == {'user_id', 'user_uid', 'user_gid',
                                             'user_gecos', 'user_dir', 'user_shell',
                                             'real_user_id', 'effective_user_id',
                                             'real_group_id', 'effective_group_id'}


# Generated at 2022-06-20 20:07:03.290595
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert user_fact_collector.name == 'user'
    assert 'user_id' in user_fact_collector._fact_ids

# Generated at 2022-06-20 20:07:08.329348
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    userfact = UserFactCollector()
    assert userfact.name == 'user'
    assert userfact._fact_ids == set(['user_id', 'user_uid', 'user_gid', 'user_gecos', 'user_dir',
        'user_shell', 'real_user_id', 'effective_user_id', 'effective_group_ids'])



# Generated at 2022-06-20 20:07:09.212825
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    pass

# Generated at 2022-06-20 20:07:19.833630
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    # Test variables
    user_id = 'root'
    user_uid = 0
    user_gid = 0
    user_gecos = 'root'
    user_dir = '/root'
    user_shell = '/bin/sh'
    real_user_id = 0
    effective_user_id = 0
    real_group_id = 0
    effective_group_id = 0

    # Instantiate the class UserFactCollector
    user_fact_collector = UserFactCollector()

    # Test method collect of class UserFactCollector
    user_facts = user_fact_collector.collect()

    # Test the returned value
    assert user_facts['user_id'] == user_id
    assert user_facts['user_uid'] == user_uid
    assert user_facts['user_gid'] == user_g

# Generated at 2022-06-20 20:07:24.403897
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user = UserFactCollector()
    assert user.name == "user"
    assert user._fact_ids == set(['user_id', 'user_uid', 'user_gid', 'user_gecos',
                                  'user_dir', 'user_shell', 'real_user_id',
                                  'effective_user_id', 'effective_group_ids'])


# Generated at 2022-06-20 20:07:26.423024
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    pass

# Generated at 2022-06-20 20:07:31.579485
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    assert UserFactCollector.name == 'user'
    assert UserFactCollector._fact_ids == set(['user_id', 'user_uid',
        'user_gid', 'user_gecos', 'user_dir', 'user_shell', 'real_user_id',
        'effective_user_id', 'effective_group_ids'])


# Generated at 2022-06-20 20:07:33.846866
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fact = UserFactCollector()
    result = fact.collect()

    for key in fact._fact_ids:
        assert key in result

# Generated at 2022-06-20 20:07:39.624896
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
  u = UserFactCollector()
  assert isinstance(u, UserFactCollector)
  assert u.name == 'user'
  assert u._fact_ids == {'user_id', 'user_uid', 'user_gid', 'user_gecos', 'user_dir', 'user_shell', 'real_user_id', 'effective_user_id', 'effective_group_ids'}


# Generated at 2022-06-20 20:07:45.383835
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    factCollector = UserFactCollector()
    assert factCollector.name == 'user'
    assert factCollector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                           'user_gecos', 'user_dir', 'user_shell',
                                           'real_user_id', 'effective_user_id',
                                           'effective_group_ids'])


# Generated at 2022-06-20 20:08:04.549606
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user = UserFactCollector()
    assert user._collector_name == 'user'
    assert user._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                     'user_gecos', 'user_dir', 'user_shell',
                     'real_user_id', 'effective_user_id',
                     'effective_group_ids'])

# Generated at 2022-06-20 20:08:12.860060
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector().collect()

    assert 'user_id' in user_facts
    assert 'user_uid' in user_facts
    assert 'user_gid' in user_facts
    assert 'user_gecos' in user_facts
    assert 'user_dir' in user_facts
    assert 'user_shell' in user_facts
    assert 'real_user_id' in user_facts
    assert 'effective_user_id' in user_facts
    assert 'real_group_id' in user_facts
    assert 'effective_group_id' in user_facts

# Generated at 2022-06-20 20:08:20.652868
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ufc = UserFactCollector()
    assert ufc is not None
    assert ufc.name == 'user'
    assert ufc._fact_ids == {'user_id', 'user_uid', 'user_gid',
                             'user_gecos', 'user_dir', 'user_shell',
                             'real_user_id', 'effective_user_id',
                             'effective_group_ids'}

# Generated at 2022-06-20 20:08:26.311861
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    fact_collector_obj = UserFactCollector()
    assert fact_collector_obj.name == 'user'
    assert fact_collector_obj._fact_ids == set(['user_id', 'user_uid', 'user_gid', 'user_gecos', 'user_dir', 'user_shell', 'real_user_id', 'effective_user_id', 'effective_group_ids'])


# Generated at 2022-06-20 20:08:34.972337
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    from ansible.module_utils.facts.collectors.user import UserFactCollector

    c = UserFactCollector()
    result = c.collect()

    assert result['user_id'] == getpass.getuser()
    assert result['real_user_id'] == os.getuid()
    assert result['effective_user_id'] == os.geteuid()
    assert result['real_group_id'] == os.getgid()
    assert result['effective_group_id'] == os.getgid()

# Generated at 2022-06-20 20:08:36.531277
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_collector = UserFactCollector()
    assert user_collector.name == 'user'

# Generated at 2022-06-20 20:08:44.134959
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    # Instantiate an instance of the UserFactCollector class
    user_fact_collector = UserFactCollector()

    # Unit test the get_fact_ids() method
    # assert user_fact_collector.get_fact_ids() == set(['user_id', 'user_uid', 'user_gid',
    #                                                 'user_gecos', 'user_dir', 'user_shell',
    #                                                 'real_user_id', 'effective_user_id',
    #                                                 'effective_group_ids'])
    # Make sure the fact names are the same as the names of the attributes that store the facts
    # assert user_fact_collector.get_fact_ids() == set(user_fact_collector.__dict__.keys())

    # Unit test the collect() method
    # Gener

# Generated at 2022-06-20 20:08:46.064079
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    x = UserFactCollector()
    assert x.name == 'user'
    assert x._fact_ids

# Generated at 2022-06-20 20:08:47.439580
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()


# Generated at 2022-06-20 20:08:56.814287
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fact_collector = UserFactCollector()

    result = fact_collector.collect()

    assert result['user_id'] == getpass.getuser()
    assert result['user_uid'] == os.getuid()
    assert result['user_gid'] == os.getgid()
    assert result['user_gecos'] == pwd.getpwnam(getpass.getuser()).pw_gecos
    assert result['user_dir'] == pwd.getpwnam(getpass.getuser()).pw_dir
    assert result['user_shell'] == pwd.getpwnam(getpass.getuser()).pw_shell
    assert result['effective_user_id'] == os.geteuid()
    assert result['real_user_id'] == os.getuid()

# Generated at 2022-06-20 20:09:23.934650
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    pass

# Generated at 2022-06-20 20:09:32.432916
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_collector = UserFactCollector()
    ans = user_collector.collect()

    for key in ['user_id', 'user_uid', 'user_gid', 'user_gecos', 'user_dir', 'user_shell',
                'real_user_id', 'effective_user_id', 'real_group_id', 'effective_group_id']:
        assert(key in ans)

    return ans

if __name__ == '__main__':
    test_UserFactCollector_collect()

# Generated at 2022-06-20 20:09:34.545930
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    print("Starting method test_UserFactCollector")
    
    user_test=UserFactCollector()
    assert isinstance(user_test, UserFactCollector)



# Generated at 2022-06-20 20:09:37.336536
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    userFactCollector = UserFactCollector()
    assert userFactCollector.name == "user"
    assert 'user_id' in userFactCollector._fact_ids


# Generated at 2022-06-20 20:09:43.515955
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    obj = UserFactCollector()
    assert obj.user_id == 'root'
    assert obj.user_uid == 0
    assert obj.user_gid == 0
    assert obj.user_gecos == 'root'
    assert obj.user_dir == '/root'
    assert obj.user_shell == '/root'


if __name__ == '__main__':
    test_UserFactCollector()

# Generated at 2022-06-20 20:09:52.356686
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    input_paras = {}
    user1 = UserFactCollector()
    user_facts = user1.collect(input_paras)

    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['user_uid'] == pwd.getpwnam(getpass.getuser()).pw_uid
    assert user_facts['user_gid'] == pwd.getpwnam(getpass.getuser()).pw_gid
    assert user_facts['user_gecos'] == pwd.getpwnam(getpass.getuser()).pw_gecos
    assert user_facts['user_dir'] == pwd.getpwnam(getpass.getuser()).pw_dir

# Generated at 2022-06-20 20:09:54.383431
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    x = UserFactCollector()
    assert x is not None


# Generated at 2022-06-20 20:10:04.170759
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    class args:
        def __init__(self):
            self.user_id = None
            self.user_uid = None
            self.user_gid = None
            self.user_gecos = None
            self.user_dir = None
            self.user_shell = None
            self.real_user_id = None
            self.effective_user_id = None
            self.effective_group_ids = None

    args = args()

    user = UserFactCollector()

    test_dict = user.collect()

    assert test_dict['user_id'] == args.user_id
    assert test_dict['user_uid'] == args.user_uid
    assert test_dict['user_gid'] == args.user_gid
    assert test_dict['user_gecos'] == args.user_gecos

# Generated at 2022-06-20 20:10:13.601475
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact = UserFactCollector()
    assert user_fact.name == 'user'
    assert user_fact._fact_ids == {'user_id', 'user_uid', 'user_gid',
                                   'user_gecos', 'user_dir', 'user_shell',
                                   'real_user_id', 'effective_user_id',
                                   'real_group_id', 'effective_group_id'}
    collected_facts = user_fact.collect()
    assert collected_facts['user_id'] == getpass.getuser()
    try:
        pwent = pwd.getpwnam(getpass.getuser())
    except KeyError:
        pwent = pwd.getpwuid(os.getuid())
    assert collected_facts['user_uid'] == pwent.pw_

# Generated at 2022-06-20 20:10:17.500843
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    userFacts = UserFactCollector()
    assert userFacts.name == 'user'
    assert len(userFacts._fact_ids) == 9

# Generated at 2022-06-20 20:11:23.291250
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import subprocess
    import platform
    from ansible.module_utils.facts.collector.user import UserFactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import collector

    if not platform.system() == 'Windows':
        fct_collector = UserFactCollector()
        subprocess.call(["sudo", "python", "./UserFactCollector_collect.py"])
        # Check that the right collector class has been instantiated.
        assert isinstance(fct_collector, BaseFactCollector)
        assert isinstance(fct_collector, UserFactCollector)
        # Check that the right collector name has been set.
        assert fct_collector.name == 'user'
        # Check that the right set of fact ids exists

# Generated at 2022-06-20 20:11:29.535114
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import mock

    module = mock.MagicMock()
    module.get_bin_path.return_value = '/usr/bin/whoami'

    r = UserFactCollector().collect(module)


# Generated at 2022-06-20 20:11:33.699909
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
  assert UserFactCollector.name == 'user'
  assert UserFactCollector._fact_ids == set(['user_id', 'user_uid', 'user_gid', 'user_gecos', 'user_dir', 'user_shell', 'real_user_id', 'effective_user_id', 'effective_group_ids'])


# Generated at 2022-06-20 20:11:34.221537
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    pass

# Generated at 2022-06-20 20:11:37.547172
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Get a UserFactCollector object
    user_fact_collector = UserFactCollector()

    # Test UserFactCollector.collect
    user_facts = user_fact_collector.collect()
    assert user_facts['user_id'] != ''

# Generated at 2022-06-20 20:11:48.010079
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    module = mock.MagicMock()

    # Test with empty set of collected facts
    collector = UserFactCollector()
    ansible_facts = collector.collect(module=module, collected_facts=None)
    assert ansible_facts['user_id'] == getpass.getuser()
    assert ansible_facts['user_uid'] == pwd.getpwuid(os.getuid()).pw_uid
    assert ansible_facts['user_gid'] == pwd.getpwuid(os.getuid()).pw_gid
    assert ansible_facts['user_gecos'] == pwd.getpwuid(os.getuid()).pw_gecos
    assert ansible_facts['user_dir'] == pwd.getpwuid(os.getuid()).pw_dir

# Generated at 2022-06-20 20:11:52.147207
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert user_fact_collector._fact_ids == {'user_id', 'user_uid',
                                             'user_gid', 'user_gecos',
                                             'user_dir', 'user_shell',
                                             'real_user_id',
                                             'effective_user_id',
                                             'effective_group_ids'}

# Generated at 2022-06-20 20:11:56.660663
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    # UserFactCollector(BaseFactCollector) instance
    uf = UserFactCollector()

    assert uf.name == 'user'
    assert (
        uf._fact_ids ==
        set(['user_id', 'user_uid', 'user_gid', 'user_gecos',
             'user_dir', 'user_shell', 'real_user_id',
             'effective_user_id', 'effective_group_ids'])
    )


# Generated at 2022-06-20 20:11:59.657311
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    pass

# Generated at 2022-06-20 20:12:09.256489
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.user import UserFactCollector
    from ansible.module_utils.facts.system import SystemFactCollector

    fact_collector = FactCollector(
        [UserFactCollector()]
    )

    collected_facts = fact_collector.collect()

    assert 'user_id' in collected_facts
    assert 'user_uid' in collected_facts
    assert 'user_gid' in collected_facts
    assert 'user_gecos' in collected_facts
    assert 'user_dir' in collected_facts
    assert 'user_shell' in collected_facts
    assert 'real_user_id' in collected_facts
    assert 'effective_user_id' in collected_facts