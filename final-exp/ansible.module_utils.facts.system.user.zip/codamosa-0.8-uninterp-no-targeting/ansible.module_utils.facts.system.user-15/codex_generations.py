

# Generated at 2022-06-20 20:03:56.590525
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    """
    UserFactCollector.collect() returns a dictionary with salient
    details of the current user
    """
    expected_facts = {
        "user_id": getpass.getuser(),
        "user_uid": os.getuid(),
        "user_gid": os.getgid(),
        "real_user_id": os.getuid(),
        "effective_user_id": os.geteuid(),
        "real_group_id": os.getgid(),
        "effective_group_id": os.getgid()
    }

    user_facts = UserFactCollector().collect()


# Generated at 2022-06-20 20:03:57.684604
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    fact_collector = UserFactCollector("test_name")
    assert fact_collector.name == "test_name"


# Generated at 2022-06-20 20:04:02.157943
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    expected_fact_ids = set(['user_id', 'user_uid', 'user_gid',
                           'user_gecos', 'user_dir', 'user_shell',
                           'real_user_id', 'effective_user_id',
                           'real_group_id', 'effective_group_id'])
    user_fact_collector = UserFactCollector()
    assert user_fact_collector.name == "user"
    assert user_fact_collector._fact_ids == expected_fact_ids


# Generated at 2022-06-20 20:04:02.935960
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    obj = UserFactCollector()
    assert isinstance(obj, UserFactCollector)

# Generated at 2022-06-20 20:04:11.487944
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector().collect()

    assert 'user_id' in user_facts
    assert 'user_uid' in user_facts
    assert 'user_gid' in user_facts
    assert 'user_gecos' in user_facts
    assert 'user_dir' in user_facts
    assert 'user_shell' in user_facts
    assert 'real_user_id' in user_facts
    assert 'effective_user_id' in user_facts
    assert 'real_group_id' in user_facts
    assert 'effective_group_id' in user_facts

# Generated at 2022-06-20 20:04:12.826419
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ufc = UserFactCollector()
    assert ufc.name == 'user'

# Generated at 2022-06-20 20:04:22.056536
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    _collector = UserFactCollector()
    _collected_facts = _collector.collect()
    assert 'user_id' in _collected_facts
    assert 'user_uid' in _collected_facts
    assert 'user_gid' in _collected_facts
    assert 'user_gecos' in _collected_facts
    assert 'user_dir' in _collected_facts
    assert 'user_shell' in _collected_facts
    assert 'real_user_id' in _collected_facts
    assert 'effective_user_id' in _collected_facts
    assert 'real_group_id' in _collected_facts
    assert 'effective_group_id' in _collected_facts

# Generated at 2022-06-20 20:04:30.084037
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector().collect()
    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['user_uid'] == pwd.getpwnam(getpass.getuser()).pw_uid
    assert user_facts['user_gid'] == pwd.getpwnam(getpass.getuser()).pw_gid
    assert user_facts['user_gecos'] == pwd.getpwnam(getpass.getuser()).pw_gecos
    assert user_facts['user_dir'] == pwd.getpwnam(getpass.getuser()).pw_dir
    assert user_facts['user_shell'] == pwd.getpwnam(getpass.getuser()).pw_shell

# Generated at 2022-06-20 20:04:39.995582
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Test UserFactCollector class
    user_fact_collector = UserFactCollector()

    # Test method collect when a failure occurs
    facts = user_fact_collector.collect()
    assert facts is not None

    # Test returned values
    assert facts['user_id'] is not None
    assert facts['user_id'] is not ""
    assert facts['user_uid'] is not None
    assert facts['user_gid'] is not None
    assert facts['user_gecos'] is not None
    assert facts['user_gecos'] is not ""
    assert facts['user_dir'] is not None
    assert facts['user_dir'] is not ""
    assert facts['user_shell'] is not None
    assert facts['user_shell'] is not ""
    assert facts['real_user_id'] is not None
    assert facts

# Generated at 2022-06-20 20:04:41.110222
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ua = UserFactCollector()

    assert ua is not None


# Generated at 2022-06-20 20:04:50.825407
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert user_fact_collector.name == 'user'
    assert user_fact_collector._fact_ids == set(['user_id', 'real_user_id', 'effective_user_id',
                                       'user_gid', 'real_group_id', 'effective_group_id',
                                       'user_uid', 'user_gecos',
                                       'user_dir', 'user_shell'])

# Generated at 2022-06-20 20:05:01.403840
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Create the instance of UserFactCollector
    userFactCollector = UserFactCollector()

    # Call method collect on the collector.
    result = userFactCollector.collect()

    # Assert that result is not none
    assert result

    # Assert that result is not empty
    assert result != {}

    # Assert that all the items are there in the result
    for eachItem in ['user_id', 'user_uid', 'user_gid',
                     'user_gecos', 'user_dir', 'user_shell',
                     'real_user_id', 'effective_user_id',
                     'effective_group_ids', 'real_group_id']:
        assert eachItem in result

# Generated at 2022-06-20 20:05:02.888661
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user = UserFactCollector()
    assert 'user' == user.name
    assert user._fact_ids

# Generated at 2022-06-20 20:05:07.081498
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Set up test
    user_facts = UserFactCollector()

    # Execute test
    user_facts.collect()

    # Assert result
    assert 'user_shell' in user_facts
    assert len(user_facts.keys()) == 8

# Generated at 2022-06-20 20:05:10.988879
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector().collect()
    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['user_uid'] == pwd.getpwnam(user_facts['user_id']).pw_uid
    assert user_facts['user_gid'] == pwd.getpwnam(user_facts['user_id']).pw_gid
    assert user_facts['user_gecos'] == pwd.getpwnam(user_facts['user_id']).pw_gecos
    assert user_facts['user_dir'] == pwd.getpwnam(user_facts['user_id']).pw_dir
    assert user_facts['user_shell'] == pwd.getpwnam(user_facts['user_id']).pw_shell

# Generated at 2022-06-20 20:05:17.714204
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    assert ufc.collect() == {'effective_user_id': 1001,
                'effective_group_ids': [1001, 1002, 1003],
                'real_group_id': 1001, 'user_uid': 1001,
                'user_id': 'test', 'user_shell': '/bin/bash',
                'user_dir': '/home/test', 'user_gid': 1001,
                'user_gecos': 'Test User', 'real_user_id': 1001}

# Generated at 2022-06-20 20:05:23.905849
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fact_collector = UserFactCollector()
    user_facts = fact_collector.collect()

    # Print the collected facts to stdout for testing
    for key in list(user_facts.keys()):
        print(key, "=", user_facts[key])


if __name__ == '__main__':
    test_UserFactCollector_collect()

# Generated at 2022-06-20 20:05:27.689645
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    obj = UserFactCollector()
    assert obj.name == 'user'
    assert obj._fact_ids == set(['user_id', 'user_uid', 'user_gid', 'user_gecos', 'user_dir', 'user_shell', 'real_user_id', 'effective_user_id', 'effective_group_ids'])

# Generated at 2022-06-20 20:05:29.274575
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    UserFactCollector().collect()


# Generated at 2022-06-20 20:05:37.716469
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    expected_fact_ids = {'effective_group_ids',
                         'effective_user_id',
                         'real_user_id',
                         'user_dir',
                         'user_gid',
                         'user_gecos',
                         'user_id',
                         'user_shell',
                         'user_uid'}
    user_fact_collector = UserFactCollector()
    fact_ids = user_fact_collector.fact_ids()
    assert fact_ids == expected_fact_ids


# Generated at 2022-06-20 20:05:53.394058
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    # Arrange
    collector = UserFactCollector()
    expected_result = {'effective_group_id': 0, 'effective_user_id': 0, 'real_group_id': 0,
                       'real_user_id': 0, 'user_dir': '/root', 'user_gid': 0, 'user_gecos': 'root',
                       'user_id': 'root', 'user_shell': '/bin/bash', 'user_uid': 0}

    # Act
    result = collector.collect()

    # Assert
    assert expected_result == result



# Generated at 2022-06-20 20:06:03.918150
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # testing the UserFactCollector class.
    ufc = UserFactCollector()
    # testing the collect function of class UserFactCollector
    user_facts = ufc.collect()
    assert user_facts is not None, \
            "user_facts is None."
    assert user_facts, "user_facts is empty."
    assert len(user_facts) != 0, \
            "user_facts is empty."
    assert isinstance(user_facts, dict), \
            "user_facts is not of type dict."

# Generated at 2022-06-20 20:06:08.156776
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # create test object
    user_collector = UserFactCollector()

    # set test input
    module_input = None
    collected_facts_input = None

    # run collect with inputs
    result = user_collector.collect(module=module_input, collected_facts=collected_facts_input)

    # assert results
    assert result

# Generated at 2022-06-20 20:06:18.125225
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    facts = UserFactCollector().collect()
    assert facts['user_id'] == getpass.getuser()
    assert facts['user_uid'] == pwd.getpwnam(getpass.getuser()).pw_uid
    assert facts['user_gid'] == pwd.getpwnam(getpass.getuser()).pw_gid
    assert facts['user_gecos'] == pwd.getpwnam(getpass.getuser()).pw_gecos
    assert facts['user_dir'] == pwd.getpwnam(getpass.getuser()).pw_dir
    assert facts['user_shell'] == pwd.getpwnam(getpass.getuser()).pw_shell
    assert facts['real_user_id'] == os.getuid()

# Generated at 2022-06-20 20:06:28.986593
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collector_obj = UserFactCollector()
    assert 'user_id' in collector_obj.collect()
    assert 'user_uid' in collector_obj.collect()
    assert 'user_gid' in collector_obj.collect()
    assert 'user_gecos' in collector_obj.collect()
    assert 'user_dir' in collector_obj.collect()
    assert 'user_shell' in collector_obj.collect()
    assert 'real_user_id' in collector_obj.collect()
    assert 'effective_user_id' in collector_obj.collect()
    assert 'real_group_id' in collector_obj.collect()
    assert 'effective_group_id' in collector_obj.collect()

# Generated at 2022-06-20 20:06:38.620513
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import pwd
    import os

    test_user = pwd.getpwuid(os.getuid())

    test_user_facts = {
        'user_id': test_user.pw_name,
        'user_uid': test_user.pw_uid,
        'user_gid': test_user.pw_gid,
        'user_gecos': test_user.pw_gecos,
        'user_dir': test_user.pw_dir,
        'user_shell': test_user.pw_shell,
        'real_user_id': os.getuid(),
        'effective_user_id': os.geteuid(),
        'real_group_id': os.getgid(),
        'effective_group_id': os.getgid()
    }



# Generated at 2022-06-20 20:06:43.438269
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ufc = UserFactCollector()
    assert ufc.name == 'user'
    assert ufc._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                 'user_gecos', 'user_dir', 'user_shell',
                                 'real_user_id', 'effective_user_id',
                                 'effective_group_ids'])

# Generated at 2022-06-20 20:06:44.528061
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ufc = UserFactCollector()
    assert ufc.name == 'user'

# Generated at 2022-06-20 20:06:54.910754
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    ufc = UserFactCollector()
    user_facts = ufc.collect()

    # did we get a dict?
    assert isinstance(user_facts, dict)

    # the root test user should have an uid and gid of 0
    if user_facts:
        assert user_facts['user_id'] == 'root'
        assert user_facts['user_uid'] == 0
        assert user_facts['user_gid'] == 0
        assert user_facts['user_gecos'] == 'root'
        assert user_facts['user_dir'] == '/root'
        assert user_facts['user_shell'] == '/bin/bash'
        assert user_facts['real_user_id'] == 0
        assert user_facts['effective_user_id'] == 0

# Generated at 2022-06-20 20:07:00.098636
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collector = UserFactCollector()
    facts = collector.collect()

    assert isinstance(facts, dict)
    assert 'user_id' in facts
    assert 'user_gecos' in facts
    assert 'user_dir' in facts
    assert 'user_shell' in facts
    assert 'real_user_id' in facts
    assert 'effective_user_id' in facts
    assert 'effective_group_ids' in facts

# Generated at 2022-06-20 20:07:24.950637
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    class MockPwd:

        class MockPwdGecos:
            return_value = 'Mock User'

        def getpwnam(self, user):
            return self
        def getpwuid(self, uid):
            return self
        def getgrgid(self, gid):
            return self

        pw_uid = 'mock uid'
        pw_gid = 'mock gid'
        pw_gecos = MockPwdGecos
        pw_dir = 'mock home directory'
        pw_shell = None

    def getpwuid(uid):
        return uid

    def getuid():
        return 'mock os getuser'

    def geteuid():
        return 'mock os geteuid'


# Generated at 2022-06-20 20:07:26.467961
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    assert True

# Generated at 2022-06-20 20:07:31.620619
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user = UserFactCollector()
    assert user.name == 'user'
    assert set(user.collect().keys()) == set(['user_id', 'user_uid', 'user_gid', 'user_gecos', 'user_dir', 'user_shell', 'real_user_id', 'effective_user_id', 'real_group_id', 'effective_group_id'])

# Generated at 2022-06-20 20:07:37.171926
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    result = user_fact_collector.collect()
    assert sorted(result) == sorted(['user_id', 'user_uid', 'user_gid', 'user_gecos', 'user_dir', 'user_shell', 'real_user_id', 'effective_user_id', 'effective_group_ids'])

# Generated at 2022-06-20 20:07:44.015389
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import sys
    python_major_version = int(sys.version_info.major)
    u1 = UserFactCollector()
    res = u1.collect()

    if python_major_version < 3:
        assert 'user_id' in res
        assert res['user_id'] == getpass.getuser()
        assert len(res) == 8
    else:
        assert 'user_id' in res
        assert res['user_id'] == getpass.getuser()
        assert len(res) == 9

# Generated at 2022-06-20 20:07:50.163821
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():

    ufc = UserFactCollector()

    # test name
    assert ufc.name == 'user'

    # test fact_ids
    assert ufc._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                     'user_gecos', 'user_dir', 'user_shell',
                     'real_user_id', 'effective_user_id',
                     'effective_group_ids'])

# Generated at 2022-06-20 20:07:53.429365
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    result = ufc.collect()
    assert result['user_id'] == getpass.getuser()


# Generated at 2022-06-20 20:07:55.150548
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    test_obj = UserFactCollector()
    assert type(test_obj) == UserFactCollector


# Generated at 2022-06-20 20:08:01.223160
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_collector = UserFactCollector()
    assert user_collector.name == 'user'
    assert user_collector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                            'user_gecos', 'user_dir', 'user_shell',
                                            'real_user_id', 'effective_user_id',
                                            'effective_group_ids'])

# Generated at 2022-06-20 20:08:08.306204
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_collector = UserFactCollector()
    assert user_collector.name == 'user'
    assert set(user_collector._fact_ids) == set(['user_id', 'user_uid', 'user_gid',
                                                 'user_gecos', 'user_dir', 'user_shell',
                                                 'real_user_id', 'effective_user_id',
                                                 'effective_group_ids'])

# Generated at 2022-06-20 20:08:27.977777
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    fact_names = [ 'user_id', 'user_uid', 'user_gid', 'user_gecos',
                   'user_dir', 'user_shell', 'real_user_id',
                   'effective_user_id', 'real_group_id',
                   'effective_group_id']
    fact = UserFactCollector()
    assert isinstance(fact, UserFactCollector)
    assert fact.name == 'user'
    assert set(fact._fact_ids) == set(fact_names)
    return

# Generated at 2022-06-20 20:08:30.387954
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    #print(ufc.collect())
    assert(ufc.collect()['user_id'] == getpass.getuser())

# Generated at 2022-06-20 20:08:39.146485
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector_object = UserFactCollector()
    class_name = user_fact_collector_object.name
    assert class_name == "user"
    fact_ids = user_fact_collector_object._fact_ids
    assert fact_ids == {'user_id', 'user_uid', 'user_gid',
                        'user_gecos', 'user_dir', 'user_shell',
                        'real_user_id', 'effective_user_id',
                        'effective_group_ids'}

# Generated at 2022-06-20 20:08:46.959742
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    assert UserFactCollector.name == 'user'
    assert UserFactCollector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                               'user_gecos', 'user_dir', 'user_shell',
                                               'real_user_id', 'effective_user_id',
                                               'effective_group_ids'])
    assert UserFactCollector.collect()["user_id"] == getpass.getuser()

# Generated at 2022-06-20 20:08:51.955429
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    class_instance = UserFactCollector()
    assert class_instance.name == "user"
    assert class_instance._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                     'user_gecos', 'user_dir', 'user_shell',
                     'real_user_id', 'effective_user_id',
                     'effective_group_ids'])

# Generated at 2022-06-20 20:08:55.275097
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()

    # TODO: Compare results of user_fact_collector.collect()
    #       with real data
    assert user_fact_collector.collect() == {}

# Generated at 2022-06-20 20:09:02.320723
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()

    assert user_fact_collector.name == 'user'
    assert user_fact_collector._fact_ids == set(['user_id', 'user_uid', 'user_gid', 'user_gecos', 'user_dir', 'user_shell', 'real_user_id', 'effective_user_id', 'effective_group_ids'])


# Generated at 2022-06-20 20:09:03.191973
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    assert UserFactCollector().name == 'user'

# Generated at 2022-06-20 20:09:04.644443
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    obj = UserFactCollector
    assert type(obj) == type(UserFactCollector)


# Generated at 2022-06-20 20:09:08.138855
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    x = UserFactCollector()
    assert x.name == 'user'
    assert x._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                               'user_gecos', 'user_dir', 'user_shell',
                               'real_user_id', 'effective_user_id',
                               'effective_group_ids'])

# Generated at 2022-06-20 20:09:42.211481
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    userfactcollector = UserFactCollector()
    userfactcollector.collect()

# Generated at 2022-06-20 20:09:43.977006
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert isinstance(user_fact_collector, UserFactCollector)

# Generated at 2022-06-20 20:09:48.034860
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    m = UserFactCollector()
    assert m.name == 'user'
    assert m._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                               'user_gecos', 'user_dir', 'user_shell',
                               'real_user_id', 'effective_user_id',
                               'effective_group_ids'])


# Generated at 2022-06-20 20:09:57.640689
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collected_facts = {}
    user_facts = UserFactCollector().collect(collected_facts=collected_facts)
    assert set(collected_facts.keys()) == (UserFactCollector()._fact_ids | {'ansible_facts'})
    assert isinstance(collected_facts['ansible_facts'], dict)
    assert isinstance(collected_facts['ansible_facts']['user'], dict)
    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['user_uid'] == pwd.getpwuid(os.getuid()).pw_uid
    assert user_facts['user_gid'] == pwd.getpwuid(os.getuid()).pw_gid

# Generated at 2022-06-20 20:09:59.733828
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert isinstance(user_fact_collector, UserFactCollector)

# Generated at 2022-06-20 20:10:05.209868
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    collector = UserFactCollector()
    assert collector.name == 'user'
    assert collector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                       'user_gecos', 'user_dir', 'user_shell',
                                       'real_user_id', 'effective_user_id',
                                       'effective_group_ids'])



# Generated at 2022-06-20 20:10:09.375071
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    """
    Unit test for constructor of class UserFactCollector
    """

    user_fact_collector = UserFactCollector()
    assert isinstance(user_fact_collector._fact_ids, set)
    assert user_fact_collector.name == 'user'

# Generated at 2022-06-20 20:10:16.475221
# Unit test for constructor of class UserFactCollector

# Generated at 2022-06-20 20:10:25.643976
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fact_collector = UserFactCollector()
    facts = fact_collector.collect()

    assert facts['user_id'] == getpass.getuser()
    assert facts['user_uid'] == pwd.getpwnam(getpass.getuser()).pw_uid
    assert facts['user_gid'] == pwd.getpwnam(getpass.getuser()).pw_gid
    assert facts['user_gecos'] == pwd.getpwnam(getpass.getuser()).pw_gecos
    assert facts['user_dir'] == pwd.getpwnam(getpass.getuser()).pw_dir
    assert facts['user_shell'] == pwd.getpwnam(getpass.getuser()).pw_shell

# Generated at 2022-06-20 20:10:29.667552
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    f = UserFactCollector()
    result = f.collect()

    assert result['ansible_user_id'] == getpass.getuser()
    assert result['ansible_user_dir'] == pwd.getpwuid(os.getuid()).pw_dir

# Generated at 2022-06-20 20:11:37.458457
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    user_fact_collector.collect()

# Generated at 2022-06-20 20:11:39.656852
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    ufc = UserFactCollector()
    assert isinstance(ufc, BaseFactCollector)

# Generated at 2022-06-20 20:11:44.111784
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    a = UserFactCollector()
    assert a.name == 'user'
    assert a._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                               'user_gecos', 'user_dir', 'user_shell',
                               'real_user_id', 'effective_user_id',
                               'effective_group_ids'])

# Generated at 2022-06-20 20:11:44.769646
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    pass

# Generated at 2022-06-20 20:11:50.128259
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ufc = UserFactCollector()
    assert ufc.name == 'user'
    assert ufc._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                     'user_gecos', 'user_dir', 'user_shell',
                     'real_user_id', 'effective_user_id',
                     'effective_group_ids'])

# Generated at 2022-06-20 20:11:54.678739
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():

    collector = UserFactCollector()
    assert collector.name == 'user'
    assert collector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                       'user_gecos', 'user_dir', 'user_shell',
                                       'real_user_id', 'effective_user_id',
                                       'real_group_id', 'effective_group_id'])


# Generated at 2022-06-20 20:11:58.456064
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    # Call the constructor
    userFactCollector = UserFactCollector()

    # Check the values of some class properties
    assert userFactCollector.name == 'user'
    assert userFactCollector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                               'user_gecos', 'user_dir', 'user_shell',
                                               'real_user_id', 'effective_user_id',
                                               'effective_group_ids'])



# Generated at 2022-06-20 20:12:02.085408
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_facts = UserFactCollector()

    assert user_facts is not None

# This is the main application program.
if __name__ == '__main__':
    test_UserFactCollector()

# Generated at 2022-06-20 20:12:07.888837
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ufc = UserFactCollector()
    assert ufc.name == 'user'
    assert len(ufc._fact_ids) == 9
    assert ufc._fact_ids.issuperset(set(
        ['user_id', 'user_uid', 'user_gid', 'user_gecos',
         'user_dir', 'user_shell', 'real_user_id',
         'effective_user_id', 'effective_group_ids']
    ))

# Generated at 2022-06-20 20:12:09.415017
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    assert isinstance(ufc.collect(), dict)
    assert 'user_id' in ufc.collect()