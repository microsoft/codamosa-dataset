

# Generated at 2022-06-20 20:03:53.429407
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact = UserFactCollector()
    assert user_fact.name == 'user'
    assert user_fact._fact_ids == {'real_group_id', 'effective_group_ids', 'effective_user_id', 'user_shell', 'user_gecos', 'user_gid', 'user_dir', 'user_uid', 'user_id', 'real_user_id'}

# Generated at 2022-06-20 20:04:01.085020
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    from ansible.module_utils.facts.collector.user import UserFactCollector
    ufc = UserFactCollector()

    # test1: unprivileged user
    facts = ufc.collect()
    assert facts['user_id'] == 'TEST1'
    assert facts['user_uid'] == 1001
    assert facts['user_gid'] == 1001
    assert facts['user_gecos'] == 'test1,,11111,,test1@localhost'
    assert facts['user_dir'] == '/home/test1'
    assert facts['user_shell'] == '/bin/bash'
    assert facts['real_user_id'] == 1001
    assert facts['effective_user_id'] == 1001
    assert facts['real_group_id'] == 1001
    assert facts['effective_group_id'] == 1001

# Generated at 2022-06-20 20:04:06.326943
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import mock

    instance = UserFactCollector()

    user_facts = {
        'user_id': 'test',
        'user_uid': 1000,
        'user_gid': 1000,
        'user_gecos': 'Test',
        'user_dir': '/home/test',
        'user_shell': '/bin/bash',
        'real_user_id': 1000,
        'effective_user_id': 1000,
        'real_group_id': 1000,
        'effective_group_id': 1000,
    }

    with mock.patch('ansible.module_utils.facts.collector.getpass') as getpass_mock:
        getpass_mock.getuser.return_value = user_facts['user_id']

# Generated at 2022-06-20 20:04:17.339133
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    from ansible.module_utils.facts import collector
    import os

    collector.collectors.pop('user', None)
    user_fact_collector = UserFactCollector()
    user_fact_collector._collect_platform_facts = lambda: {}
    user_facts = user_fact_collector.collect()
    assert user_facts['user_id'] == os.environ['USER']
    assert user_facts['user_uid'] == os.getuid()
    assert user_facts['user_gid'] == os.getgid()
    assert user_facts['user_gecos'] == pwd.getpwuid(os.getuid()).pw_gecos
    assert user_facts['user_dir'] == pwd.getpwuid(os.getuid()).pw_dir
    assert user_facts

# Generated at 2022-06-20 20:04:23.207813
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ufc = UserFactCollector()
    assert ufc.name == 'user'
    assert ufc._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                     'user_gecos', 'user_dir', 'user_shell',
                     'real_user_id', 'effective_user_id',
                     'effective_group_ids'])


# Generated at 2022-06-20 20:04:24.499834
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
        x = UserFactCollector()
        assert x
        assert x.name == 'user'

# Generated at 2022-06-20 20:04:25.589330
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    assert UserFactCollector.name == 'user'

# Generated at 2022-06-20 20:04:36.423837
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ''' Unit test for method collect of class UserFactCollector '''

    ufc = UserFactCollector()
    data = ufc.collect()

    assert data['user_id'] == getpass.getuser()

    try:
        pwent = pwd.getpwnam(getpass.getuser())
    except KeyError:
        pwent = pwd.getpwuid(os.getuid())

    assert data['user_uid'] == pwent.pw_uid
    assert data['user_gid'] == pwent.pw_gid
    assert data['user_gecos'] == pwent.pw_gecos
    assert data['user_dir'] == pwent.pw_dir
    assert data['user_shell'] == pwent.pw_shell

# Generated at 2022-06-20 20:04:40.552244
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    content = UserFactCollector().collect()
    assert content['user_id'] == 'travis'
    assert content['user_uid'] == 500
    assert content['user_gid'] == 500
    assert content['user_shell'] == "/bin/bash"
    assert content['user_dir'] == "/home/travis"
    assert content['real_user_id'] == 500

# Generated at 2022-06-20 20:04:44.326128
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    uf = UserFactCollector()
    result = uf.collect()
    assert set(result.keys()) == uf._fact_ids


# Generated at 2022-06-20 20:04:50.587814
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    userfc = UserFactCollector()
    assert userfc.name == "user"
    assert userfc._fact_ids == {'effective_user_id', 'effective_group_ids', 'user_dir', 'real_user_id', 'user_uid', 'user_id', 'user_gid', 'user_shell', 'user_gecos'}

# Generated at 2022-06-20 20:05:00.480256
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact = UserFactCollector()
    assert user_fact.name == 'user'
    assert 'user_id' in user_fact._fact_ids
    assert 'user_uid' in user_fact._fact_ids
    assert 'user_gid' in user_fact._fact_ids
    assert 'user_gecos' in user_fact._fact_ids
    assert 'user_dir' in user_fact._fact_ids
    assert 'user_shell' in user_fact._fact_ids
    assert 'real_user_id' in user_fact._fact_ids
    assert 'effective_user_id' in user_fact._fact_ids
    assert 'effective_group_ids' in user_fact._fact_ids

# Generated at 2022-06-20 20:05:07.152576
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collector = UserFactCollector()
    result = collector.collect()
    assert result['user_id'] == pwd.getpwuid(os.getuid()).pw_name
    assert result['user_uid'] == os.getuid()
    assert result['user_gid'] == os.getgid()
    assert result['user_gecos'] == pwd.getpwuid(os.getuid()).pw_gecos
    assert result['user_dir'] == pwd.getpwuid(os.getuid()).pw_dir
    assert result['user_shell'] == pwd.getpwuid(os.getuid()).pw_shell
    assert result['real_user_id'] == os.getuid()
    assert result['effective_user_id'] == os.geteuid()
   

# Generated at 2022-06-20 20:05:13.663532
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user = UserFactCollector()
    assert user.name == 'user'
    assert user._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                     'user_gecos', 'user_dir', 'user_shell',
                     'real_user_id', 'effective_user_id',
                     'effective_group_ids'])


# Generated at 2022-06-20 20:05:14.233869
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    pass

# Generated at 2022-06-20 20:05:19.337493
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()

    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['user_uid'] == pwd.getpwnam(getpass.getuser()).pw_uid
    assert user_facts['user_gid'] == pwd.getpwnam(getpass.getuser()).pw_gid
    assert user_facts['user_gecos'] == pwd.getpwnam(getpass.getuser()).pw_gecos
    assert user_facts['user_dir'] == pwd.getpwnam(getpass.getuser()).pw_dir

# Generated at 2022-06-20 20:05:26.998836
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fact_module = UserFactCollector()
    facts = fact_module.collect()
    assert facts['user_id'] is not None
    assert facts['user_uid'] >= 0
    assert facts['user_gid'] >= 0
    assert facts['user_gecos'] is not None
    assert facts['user_dir'] is not None
    assert facts['user_shell'] is not None
    assert facts['real_user_id'] >= 0
    assert facts['real_group_id'] >= 0
    assert facts['effective_user_id'] >= 0
    assert facts['effective_group_id'] >= 0

# Generated at 2022-06-20 20:05:37.950088
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    #Dummy Ansible module, need to do this unit test as an actual Ansible module
    module = type('', (), {})()
    module.params = {}
    
    # Test that the set of collected facts is identical to the expected output
    expected_facts = test_UserFactCollector_collect_output()
    collected_facts = UserFactCollector().collect(module)
    assert collected_facts.keys() == expected_facts.keys()

    # Test that all the values in the collected facts are equal to the expected
    # output
    for key in expected_facts.keys():
        assert collected_facts[key] == expected_facts[key]

# Expected output to be returned for test_UserFactCollector_collect

# Generated at 2022-06-20 20:05:45.624597
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user = UserFactCollector()
    assert user.name == 'user'
    assert user._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                  'user_gecos', 'user_dir', 'user_shell',
                                  'real_user_id', 'effective_user_id',
                                  'effective_group_ids'])



# Generated at 2022-06-20 20:05:52.118814
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_facts = UserFactCollector()
    assert isinstance(user_facts, BaseFactCollector)
    assert user_facts.name == 'user'
    assert user_facts._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                     'user_gecos', 'user_dir', 'user_shell',
                     'real_user_id', 'effective_user_id',
                     'effective_group_ids'])


# Generated at 2022-06-20 20:05:59.564733
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Instantiate an instance of class UserFactCollector
    ufc = UserFactCollector(None)

    # Instantiate an instance of class HostInfo
    collected_facts = {}

    # Call method collect of the object ufc
    user_facts = ufc.collect(collected_facts=collected_facts)

    assert user_facts['user_id'] == getpass.getuser()

# Generated at 2022-06-20 20:06:09.564159
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    from ansible.module_utils.facts.collectors.user import UserFactCollector
    # testing by comparing the keys of return value with attributes of pwd.struct_passwd
    ufc = UserFactCollector()
    pwent = pwd.getpwuid(os.getuid())
    assert set(ufc.collect().keys()) == set(['user_id', 'user_uid', 'user_gid',
                                             'user_gecos', 'user_dir', 'user_shell',
                                             'real_user_id', 'effective_user_id',
                                             'effective_group_id', 'real_group_id'])
    # testing by comparing the return value with attributes of pwd.struct_passwd
    ufc = UserFactCollector()

# Generated at 2022-06-20 20:06:18.877702
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector('user').collect()
    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['user_uid'] == pwd.getpwnam(getpass.getuser()).pw_uid
    assert user_facts['user_gid'] == pwd.getpwnam(getpass.getuser()).pw_gid
    assert user_facts['user_gecos'] == pwd.getpwnam(getpass.getuser()).pw_gecos
    assert user_facts['user_dir'] == pwd.getpwnam(getpass.getuser()).pw_dir
    assert user_facts['user_shell'] == pwd.getpwnam(getpass.getuser()).pw_shell

# Generated at 2022-06-20 20:06:26.516868
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    userFactCollector = UserFactCollector()
    assert userFactCollector.name == 'user'
    assert userFactCollector._fact_ids == set(['user_id', 'user_uid', 'user_gid', 'user_gecos',
                                               'user_dir', 'user_shell', 'real_user_id',
                                               'effective_user_id', 'real_group_id',
                                               'effective_group_id'])


# Generated at 2022-06-20 20:06:28.063530
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    result = UserFactCollector().collect()
    assert result['user_id'] is not None

# Generated at 2022-06-20 20:06:37.929599
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.collector import Collector

    user_facts = ansible_facts(Collector())['user']

    # Checking if user facts are populated correctly
    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['user_uid'] == pwd.getpwnam(getpass.getuser()).pw_uid
    assert user_facts['user_gid'] == pwd.getpwnam(getpass.getuser()).pw_gid
    assert user_facts['user_gecos'] == pwd.getpwnam(getpass.getuser()).pw_gecos

# Generated at 2022-06-20 20:06:46.783902
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_collector = UserFactCollector()

    # Test case 1: get user id, uid, gid, etc. with no exception
    user_facts = user_collector.collect()
    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['user_uid'] == os.getuid()
    assert user_facts['user_gid'] == os.getgid()
    assert user_facts['real_user_id'] == os.getuid()
    assert user_facts['effective_user_id'] == os.geteuid()
    assert user_facts['real_group_id'] == os.getgid()
    assert user_facts['effective_group_id'] == os.getegid()

# Generated at 2022-06-20 20:06:54.083489
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert user_fact_collector is not None
    assert user_fact_collector.name == 'user'
    assert user_fact_collector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                                 'user_gecos', 'user_dir', 'user_shell',
                                                 'real_user_id', 'effective_user_id',
                                                 'effective_group_ids'])


# Generated at 2022-06-20 20:06:56.508882
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()

    collected_facts = user_fact_collector.collect()

    print(collected_facts)

if __name__ == '__main__':
    test_UserFactCollector_collect()

# Generated at 2022-06-20 20:07:00.754877
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    u = UserFactCollector()
    assert u.name == 'user'
    assert u._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                               'user_gecos', 'user_dir', 'user_shell',
                               'real_user_id', 'effective_user_id',
                               'effective_group_ids'])

# Generated at 2022-06-20 20:07:18.365368
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    obj = UserFactCollector()
    user_facts = obj.collect()

    assert user_facts['user_id'] == getpass.getuser()
    try:
        pwent = pwd.getpwnam(getpass.getuser())
    except KeyError:
        pwent = pwd.getpwuid(os.getuid())
    assert user_facts['user_uid'] == pwent.pw_uid
    assert user_facts['user_gid'] == pwent.pw_gid
    assert user_facts['user_gecos'] == pwent.pw_gecos
    assert user_facts['user_dir'] == pwent.pw_dir
    assert user_facts['user_shell'] == pwent.pw_shell
    assert user_facts['real_user_id'] == os.get

# Generated at 2022-06-20 20:07:28.639172
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    """Unit test for method collect of class UserFactCollector"""
    collected_facts = dict()
    fact_collector = UserFactCollector()
    fact_collector.collect(collected_facts=collected_facts)

    assert collected_facts == dict()
    assert fact_collector.name == 'user'
    assert fact_collector.collect_fn == fact_collector.collect
    assert fact_collector._fact_ids == {'effective_group_ids', 'effective_user_id', 'real_group_id', 'real_user_id', 'user_dir', 'user_gid', 'user_gecos', 'user_id', 'user_shell', 'user_uid'}

# Generated at 2022-06-20 20:07:29.436971
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ufc = UserFactCollector()
    assert ufc
    assert ufc.name
    assert ufc._fact_ids

# Generated at 2022-06-20 20:07:33.943473
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ufc = UserFactCollector()
    assert ufc.name == 'user'
    assert ufc._fact_ids == set(['user_id', 'user_uid', 'user_gid', 'user_gecos', 'user_dir', 'user_shell', 'real_user_id', 'effective_user_id', 'effective_group_ids'])

# Generated at 2022-06-20 20:07:36.619421
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    test_collector = UserFactCollector()
    result = test_collector.collect()

    assert result['user_id'] == getpass.getuser()

# Generated at 2022-06-20 20:07:42.558858
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fc = UserFactCollector()
    assert user_fc.name == 'user'
    assert user_fc._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                     'user_gecos', 'user_dir', 'user_shell',
                                     'real_user_id', 'effective_user_id',
                                     'effective_group_ids'])

# Generated at 2022-06-20 20:07:46.678887
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    collector = UserFactCollector()
    assert collector.name == 'user'
    assert collector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                       'user_gecos', 'user_dir', 'user_shell',
                                       'real_user_id', 'effective_user_id',
                                       'effective_group_ids'])


# Generated at 2022-06-20 20:07:54.009401
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector_obj = UserFactCollector()
    assert user_fact_collector_obj.name == 'user'
    assert user_fact_collector_obj._fact_ids == set(['user_id', 'user_uid', 'user_gid',
         'user_gecos', 'user_dir', 'user_shell', 'real_user_id',
         'effective_user_id', 'effective_group_ids'])


# Generated at 2022-06-20 20:07:57.562180
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    module = []
    collected_facts = {}
    collector = UserFactCollector(module, collected_facts)
    result = collector.collect()
    assert result['user_id'] == 'root'

# Generated at 2022-06-20 20:08:05.780863
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert(user_fact_collector.name == 'user')
    assert(user_fact_collector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                                 'user_gecos', 'user_dir', 'user_shell',
                                                 'real_user_id', 'effective_user_id',
                                                 'effective_group_ids']))

# Generated at 2022-06-20 20:08:22.569160
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ufc = UserFactCollector()

    print('UserFactCollector is created: %s' % ufc)



# Generated at 2022-06-20 20:08:26.824707
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    obj = UserFactCollector()
    assert isinstance(obj, BaseFactCollector)
    assert obj.name == 'user'
    assert obj._fact_ids == {'user_id', 'user_uid', 'user_gid',
                             'user_gecos', 'user_dir', 'user_shell',
                             'real_user_id', 'effective_user_id',
                             'effective_group_ids'}


# Generated at 2022-06-20 20:08:38.193710
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fact_collector = UserFactCollector()
    collected_facts = fact_collector.collect()

    assert collected_facts['user_id'] == getpass.getuser()
    assert collected_facts['user_uid'] == pwd.getpwnam(getpass.getuser()).pw_uid
    assert collected_facts['user_gid'] == pwd.getpwnam(getpass.getuser()).pw_gid
    assert collected_facts['user_gecos'] == pwd.getpwnam(getpass.getuser()).pw_gecos
    assert collected_facts['user_dir'] == pwd.getpwnam(getpass.getuser()).pw_dir
    assert collected_facts['user_shell'] == pwd.getpwnam(getpass.getuser()).pw

# Generated at 2022-06-20 20:08:45.162612
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    test_collector = UserFactCollector()
    result = test_collector.collect()
    real_user_id = pwd.getpwnam(getpass.getuser()).pw_uid
    assert result['user_id'] == getpass.getuser()
    assert result['user_uid'] == real_user_id
    assert result['user_gid'] == pwd.getpwnam(getpass.getuser()).pw_gid
    assert result['user_gecos'] == pwd.getpwnam(getpass.getuser()).pw_gecos
    assert result['user_dir'] == pwd.getpwnam(getpass.getuser()).pw_dir
    assert result['user_shell'] == pwd.getpwnam(getpass.getuser()).pw_

# Generated at 2022-06-20 20:08:51.697909
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():

    # Construct test instance of UserFactCollector class
    ufc_instance = UserFactCollector()

    # Assert that UserFactCollector instance is of type UserFactCollector
    assert(isinstance(ufc_instance, UserFactCollector))

    # Assert that class UserFactCollector has name
    assert(hasattr(ufc_instance, 'name'))

    # Assert that class UserFactCollector has _fact_ids
    assert(hasattr(ufc_instance, '_fact_ids'))

# Generated at 2022-06-20 20:08:59.323831
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    userFactCollector = UserFactCollector()
    assert userFactCollector.name == 'user'
    assert 'user_id' in userFactCollector._fact_ids
    assert 'user_uid' in userFactCollector._fact_ids
    assert 'user_gid' in userFactCollector._fact_ids
    assert 'user_gecos' in userFactCollector._fact_ids
    assert 'user_dir' in userFactCollector._fact_ids
    assert 'user_shell' in userFactCollector._fact_ids
    assert 'real_user_id' in userFactCollector._fact_ids
    assert 'effective_user_id' in userFactCollector._fact_ids
    assert 'real_group_id' in userFactCollector._fact_ids
    assert 'effective_group_id' in userFactCollect

# Generated at 2022-06-20 20:09:04.293141
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    assert (UserFactCollector.name == 'user')
    assert (UserFactCollector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                     'user_gecos', 'user_dir', 'user_shell',
                     'real_user_id', 'effective_user_id',
                     'effective_group_ids']))


# Generated at 2022-06-20 20:09:09.740934
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collector = UserFactCollector()
    collected_facts = {}
    collector.collect(collected_facts=collected_facts)

# Generated at 2022-06-20 20:09:19.357562
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collector = UserFactCollector({})
    returned_facts = collector.collect()

    assert isinstance(returned_facts, dict)
    for key in ['user_id', 'user_gid', 'user_gecos',
                'user_dir', 'user_shell', 'real_user_id',
                'effective_user_id', 'real_group_id',
                'effective_group_id']:
        assert key in returned_facts
    assert isinstance(returned_facts['user_uid'], int)
    assert isinstance(returned_facts['user_gid'], int)
    assert isinstance(returned_facts['real_user_id'], int)
    assert isinstance(returned_facts['effective_user_id'], int)

# Generated at 2022-06-20 20:09:22.417979
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    
    test_passed = False

    try:
        user_facts = UserFactCollector.collect()
    except:
        user_facts = None

    if user_facts is not None:
        test_passed = True

    return test_passed


# Generated at 2022-06-20 20:09:59.520016
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():

    userFactCollector = UserFactCollector()

    assert userFactCollector.name == 'user'
    assert userFactCollector._fact_ids == {'user_id', 'user_uid', 'user_gid',
                                          'user_gecos', 'user_dir', 'user_shell',
                                          'real_user_id', 'effective_user_id',
                                          'real_group_id', 'effective_group_id'}

# Generated at 2022-06-20 20:10:01.527786
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    u = UserFactCollector()
    assert u.name == 'user'

# Generated at 2022-06-20 20:10:11.666015
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector.collect()
    user_id = getpass.getuser()
    pwent = pwd.getpwnam(getpass.getuser())

    assert 'user_id' in user_facts
    assert user_facts['user_id'] == user_id
    assert 'user_uid' in user_facts
    assert user_facts['user_uid'] == pwent.pw_uid
    assert 'user_gid' in user_facts
    assert user_facts['user_gid'] == pwent.pw_gid
    assert 'user_gecos' in user_facts
    assert user_facts['user_gecos'] == pwent.pw_gecos
    assert 'user_dir' in user_facts
    assert user_facts['user_dir'] == pwent.pw_

# Generated at 2022-06-20 20:10:24.770284
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    from ansible.module_utils.facts.collector import CachingFactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import UserFactCollector
    from ansible.module_utils.facts.collector import DictFactCollector
    import json

    # Create a nested facts collector for user facts
    cachingFactCollector = CachingFactCollector()
    baseFactCollector = BaseFactCollector()
    baseFactCollector.collectors.update({'user': UserFactCollector()})
    cachingFactCollector.collectors.update({'dict': DictFactCollector(),
                                            'base': baseFactCollector})

    # Run the caching fact collector

# Generated at 2022-06-20 20:10:30.098931
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    s = ufc.collect()
    assert s.get('user_id') == getpass.getuser()
    assert s.get('user_uid') == pwd.getpwuid(os.getuid()).pw_uid
    assert s.get('user_gid') == pwd.getpwuid(os.getuid()).pw_gid

# Generated at 2022-06-20 20:10:35.768009
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    '''
    Unit test for constructor of class UserFactCollector
    '''
    u = UserFactCollector()

    assert u.name == 'user'
    assert u._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                               'user_gecos', 'user_dir', 'user_shell',
                               'real_user_id', 'effective_user_id',
                               'effective_group_ids'])

# Generated at 2022-06-20 20:10:44.870375
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user = UserFactCollector()
    assert user.name == 'user'
    assert sorted(user._fact_ids) == ['effective_group_ids', 'effective_user_id', 'real_user_id', 'user_dir', 'user_gecos', 'user_gid', 'user_id', 'user_shell', 'user_uid']
    assert len(user._fact_ids) == 9
    assert sorted(user.collect().keys()) == ['effective_group_ids', 'effective_user_id', 'real_user_id', 'user_dir', 'user_gecos', 'user_gid', 'user_id', 'user_shell', 'user_uid']
    assert len(user.collect()) == 9


if __name__ == "__main__":
    test_UserFactCollector()

# Generated at 2022-06-20 20:10:49.180256
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_facts = UserFactCollector()

    assert user_facts.name == 'user'
    assert user_facts._fact_ids == {'effective_group_ids', 'effective_user_id', 'real_group_id', 'real_user_id', 'user_dir', 'user_gecos', 'user_gid', 'user_id', 'user_shell', 'user_uid'}

# Generated at 2022-06-20 20:10:49.988583
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    UserFactCollector()


# Generated at 2022-06-20 20:10:59.119449
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    user_facts = ufc.collect(module=None, collected_facts=None)

    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['user_uid'] == pwd.getpwnam(getpass.getuser()).pw_uid
    assert user_facts['user_gid'] == pwd.getpwnam(getpass.getuser()).pw_gid
    assert user_facts['user_gecos'] == pwd.getpwnam(getpass.getuser()).pw_gecos
    assert user_facts['user_dir'] == pwd.getpwnam(getpass.getuser()).pw_dir

# Generated at 2022-06-20 20:12:24.863791
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()
    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['user_uid'] == pwd.getpwuid(os.geteuid()).pw_uid
    assert user_facts['user_gid'] == pwd.getpwuid(os.geteuid()).pw_gid
    assert user_facts['user_gecos'] == pwd.getpwuid(os.geteuid()).pw_gecos
    assert user_facts['user_dir'] == pwd.getpwuid(os.geteuid()).pw_dir

# Generated at 2022-06-20 20:12:30.790958
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fc = UserFactCollector()
    assert user_fc.name == 'user'
    assert user_fc.fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                    'user_gecos', 'user_dir', 'user_shell',
                                    'effective_user_id', 'effective_group_ids',
                                    'real_user_id'])

# Generated at 2022-06-20 20:12:35.468153
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    userFactCollector = UserFactCollector()
    assert userFactCollector.name == 'user'
    assert userFactCollector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                               'user_gecos', 'user_dir', 'user_shell',
                                               'real_user_id', 'effective_user_id',
                                               'effective_group_ids'])



# Generated at 2022-06-20 20:12:41.793212
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    class AnsibleModuleMock(object):
        def __init__(self):
            self.exit_json = lambda x: x
        def fail_json(x, *args):
            return args
    class AnsibleModuleMockWithFail(object):
        def __init__(self):
            self.fail_json = lambda x: x
    from ansible.module_utils.facts import ansible_facts

    # basic test
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect(AnsibleModuleMock())
    ansible_facts['ansible_user_id'] = user_facts['user_id']
    ansible_facts['ansible_user_uid'] = user_facts['user_uid']
    ansible_facts['ansible_user_gid']

# Generated at 2022-06-20 20:12:43.127712
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    userFactCollector = UserFactCollector()
    assert userFactCollector.name == 'user'


# Generated at 2022-06-20 20:12:46.299819
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    obj = UserFactCollector()
    values = obj.collect(collected_facts=None)
    assert values['user_id'] == getpass.getuser()
    assert values['user_uid'] == pwd.getpwnam(getpass.getuser()).pw_uid

# Generated at 2022-06-20 20:12:51.382763
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    factCollector = UserFactCollector()
    facts = factCollector.collect()
    print(facts)
    assert facts['user_id'] == getpass.getuser()
    assert facts['user_uid'] == os.getuid()
    assert facts['user_gid'] == os.getgid()

# Generated at 2022-06-20 20:12:55.738733
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert set(user_fact_collector._fact_ids) ==\
           set(['user_id', 'user_uid', 'user_gid',
                'user_gecos', 'user_dir', 'user_shell',
                'real_user_id', 'effective_user_id',
                'effective_group_ids'])


# Generated at 2022-06-20 20:13:00.718519
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user = UserFactCollector()
    assert user.name == 'user'
    assert user._fact_ids == set(['user_id', 'user_uid', 'user_gid', 'user_gecos',
                       'user_dir', 'user_shell', 'real_user_id',
                       'effective_user_id', 'effective_group_ids'])


# Generated at 2022-06-20 20:13:04.783746
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    collected_facts = {}
    collected_facts = ufc.collect(None, collected_facts)
    assert isinstance(collected_facts, dict)