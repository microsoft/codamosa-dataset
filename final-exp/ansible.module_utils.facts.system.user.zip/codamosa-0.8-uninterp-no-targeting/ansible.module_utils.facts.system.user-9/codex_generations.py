

# Generated at 2022-06-20 20:03:50.528162
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user = UserFactCollector()
    assert user.name == 'user'
    assert 'user_id' in user._fact_ids
    assert 'user_uid' in user._fact_ids
    assert 'user_gid' in user._fact_ids
    assert 'user_gecos' in user._fact_ids
    assert 'user_dir' in user._fact_ids
    assert 'user_shell' in user._fact_ids
    assert 'real_user_id' in user._fact_ids
    assert 'effective_user_id' in user._fact_ids
    assert 'effective_group_ids' in user._fact_ids



# Generated at 2022-06-20 20:03:55.780049
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collector = UserFactCollector()

# Generated at 2022-06-20 20:03:56.281047
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    pass

# Generated at 2022-06-20 20:04:01.073095
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    x = UserFactCollector()
    assert UserFactCollector.name == "user"
    assert UserFactCollector.name == x.name
    assert UserFactCollector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                            'user_gecos', 'user_dir', 'user_shell',
                                            'real_user_id', 'effective_user_id',
                                            'effective_group_ids'])
    assert UserFactCollector._fact_ids == x._fact_ids


# Generated at 2022-06-20 20:04:10.239473
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fact_class = UserFactCollector()
    test_facts = fact_class.collect()
    assert test_facts['user_id'] == getpass.getuser()
    assert test_facts['user_uid'] == pwd.getpwnam(getpass.getuser()).pw_uid
    assert test_facts['real_user_id'] == os.getuid()
    assert test_facts['effective_user_id'] == os.geteuid()
    assert test_facts['real_group_id'] == os.getgid()
    assert test_facts['effective_group_id'] == os.getegid()

# Generated at 2022-06-20 20:04:16.212513
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    userFactCollector = UserFactCollector()
    assert userFactCollector.name == 'user'
    assert userFactCollector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                     'user_gecos', 'user_dir', 'user_shell',
                     'real_user_id', 'effective_user_id',
                     'effective_group_ids'])


# Generated at 2022-06-20 20:04:23.189329
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    expected_fact_ids = set(['user_id', 'user_uid', 'user_gid',
                             'user_gecos', 'user_dir', 'user_shell',
                             'real_user_id', 'effective_user_id',
                             'effective_group_ids', 'real_group_id'])
    ufc = UserFactCollector()
    assert ufc.name == 'user'
    assert ufc._fact_ids == expected_fact_ids

# Generated at 2022-06-20 20:04:28.934094
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    obj = UserFactCollector()
    assert obj.name == 'user'
    assert obj._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                 'user_gecos', 'user_dir', 'user_shell',
                                 'real_user_id', 'effective_user_id',
                                 'effective_group_ids'])

# Generated at 2022-06-20 20:04:36.937962
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_collector = UserFactCollector()
    user_facts = user_collector.collect()

    assert 'user_id' in user_facts
    assert 'user_uid' in user_facts
    assert 'user_gid' in user_facts
    assert 'user_gecos' in user_facts
    assert 'user_dir' in user_facts
    assert 'user_shell' in user_facts
    assert 'real_user_id' in user_facts
    assert 'effective_user_id' in user_facts
    assert 'real_group_id' in user_facts
    assert 'effective_group_id' in user_facts

# Generated at 2022-06-20 20:04:43.346297
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    test_collector = UserFactCollector()
    collected_facts = test_collector.collect()
    assert collected_facts['user_id']
    assert collected_facts['user_uid']
    assert collected_facts['user_gid']
    assert collected_facts['user_gecos']
    assert collected_facts['user_dir']
    assert collected_facts['user_shell']
    assert collected_facts['real_user_id']
    assert collected_facts['effective_user_id']
    assert collected_facts['real_group_id']
    assert collected_facts['effective_group_id']

# Generated at 2022-06-20 20:04:55.284633
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    import platform

    import os
    import pwd

    import unittest
    import tempfile
    import shutil

    import ansible.module_utils.facts.collector

    class TestUserFactCollector(object):
        def __init__(self, test_case):
            self._test_case = test_case
            self._test_dir = tempfile.mkdtemp()
            self._gid = os.getgid()

            self._old_geteuid = os.geteuid
            self._old_getuid = os.getuid
            self._old_getgid = os.getgid
            self._old_getegid = os.getegid
            self._old_getpwuid = pwd.getpwuid
            self._old_getpwnam = pwd.getpwnam

# Generated at 2022-06-20 20:04:56.882642
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
  collector = UserFactCollector()
  assert collector.name == "user"

# Generated at 2022-06-20 20:05:04.843899
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    '''
    Without any arguments, will return a dictionary containing user facts.
    '''
    user_rec = {'user_id': 'testuser', 'user_uid': 1001,
                'user_gid': 1001, 'user_gecos': 'Test User',
                'user_dir': '/home/testuser', 'user_shell': '/bin/bash',
                'real_user_id': 1001, 'effective_user_id': 1001,
                'real_group_id': 1001, 'effective_group_id': 1001}
    collector = UserFactCollector()
    user_dict = collector.collect()
    assert user_dict == user_rec

# Generated at 2022-06-20 20:05:13.481291
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector('foo', 'bar')
    assert user_fact_collector is not None
    assert user_fact_collector._name == 'user'
    assert user_fact_collector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                                 'user_gecos', 'user_dir', 'user_shell',
                                                 'real_user_id', 'effective_user_id',
                                                 'effective_group_ids'])


# Generated at 2022-06-20 20:05:15.203088
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    try:
        u = UserFactCollector()
    except Exception:
        assert False

    assert u is not None

# Generated at 2022-06-20 20:05:15.830521
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    UserFactCollector()

# Generated at 2022-06-20 20:05:26.594735
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    # Test class instantiation and collection of all facts
    user_fact_collector = UserFactCollector()
    collected_facts = user_fact_collector.collect()

    # Test collected facts
    assert collected_facts['ansible_user_id'] == os.environ['USER']
    assert collected_facts['ansible_user_uid'] == os.getuid()
    assert collected_facts['ansible_user_gid'] == os.getgid()
    assert collected_facts['ansible_user_gecos'] == pwd.getpwuid(os.getuid()).pw_gecos
    assert collected_facts['ansible_user_dir'] == pwd.getpwuid(os.getuid()).pw_dir
    assert collected_facts['ansible_user_shell'] == pwd.getpw

# Generated at 2022-06-20 20:05:30.581113
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert user_fact_collector.name == 'user'
    assert user_fact_collector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                     'user_gecos', 'user_dir', 'user_shell',
                     'real_user_id', 'effective_user_id',
                     'effective_group_ids'])

# Generated at 2022-06-20 20:05:37.669431
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user = UserFactCollector()
    assert user.name == 'user'
    assert user._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                  'user_gecos', 'user_dir', 'user_shell',
                                  'real_user_id', 'effective_user_id',
                                  'effective_group_ids'])

# Generated at 2022-06-20 20:05:49.131485
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    user_facts = ufc.collect()
    assert 'user_id' in sorted(user_facts.keys())
    assert 'user_gid' in sorted(user_facts.keys())
    assert 'user_gecos' in sorted(user_facts.keys())
    assert 'user_shell' in sorted(user_facts.keys())
    assert 'user_uid' in sorted(user_facts.keys())
    assert 'user_dir' in sorted(user_facts.keys())
    assert 'real_user_id' in sorted(user_facts.keys())
    assert 'effective_user_id' in sorted(user_facts.keys())
    assert 'real_group_id' in sorted(user_facts.keys())

# Generated at 2022-06-20 20:05:57.697897
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ufc = UserFactCollector()
    assert ufc.name == 'user'
    assert ufc._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                 'user_gecos', 'user_dir', 'user_shell',
                                 'real_user_id', 'effective_user_id',
                                 'effective_group_ids'])


# Generated at 2022-06-20 20:05:58.206816
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    pass

# Generated at 2022-06-20 20:06:08.342393
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    User = UserFactCollector()
    facts = User.collect()
    assert isinstance(facts, dict)
    assert facts['user_id'] != ''
    assert isinstance(facts['user_uid'], int)
    assert isinstance(facts['user_gid'], int)
    assert isinstance(facts['user_gecos'], str)
    assert isinstance(facts['user_dir'], str)
    assert isinstance(facts['user_shell'], str)
    assert isinstance(facts['real_user_id'], int)
    assert isinstance(facts['effective_user_id'], int)
    assert isinstance(facts['real_group_id'], int)
    assert isinstance(facts['effective_group_id'], int)


# Generated at 2022-06-20 20:06:18.162257
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    """
    Unit test for UserFactCollector
    """

    from ansible.module_utils.facts.facts import Facts
    from ansible.module_utils.facts import default_collectors

    # Create facts object
    facts = Facts()

    # Create user fact collector object
    ufc = UserFactCollector(default_collectors, facts)
    assert isinstance(ufc, UserFactCollector)

    # Collect user facts
    user_facts = ufc.collect()

    # Assert user facts are collected
    assert isinstance(user_facts, dict)

    # Assert user facts has user_id
    assert 'user_id' in user_facts

    # Assert user facts has user_uid
    assert 'user_uid' in user_facts

    # Assert user facts has user_gid

# Generated at 2022-06-20 20:06:30.241495
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    from ansible.module_utils.facts import facts
    user_module_utils = facts.UserFactCollector()
    user_facts = user_module_utils.collect()

    assert 'user_id' in user_facts
    assert 'user_uid' in user_facts
    assert 'user_gid' in user_facts
    assert 'user_gecos' in user_facts
    assert 'user_dir' in user_facts
    assert 'user_shell' in user_facts
    assert 'real_user_id' in user_facts
    assert 'effective_user_id' in user_facts
    assert 'real_group_id' in user_facts
    assert 'effective_group_id' in user_facts

    assert user_facts['user_uid'] > 0
    assert user_facts['user_gid'] > 0


# Generated at 2022-06-20 20:06:39.719453
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    # This test verifies that the user fact collector
    # collect method returns the expected data.
    #
    # Patching getpwuid and getpwnam as follows ensures that
    # the user_facts dictionary will contain the expected data.

    with patch('ansible.module_utils.facts.collector.user.pwd.getpwuid') as pwd_getpwuid:
        with patch('ansible.module_utils.facts.collector.user.pwd.getpwnam') as pwd_getpwnam:

            test_user_id = 'test user id'
            test_user_uid = 100
            test_user_gid = 200
            test_user_gecos = 'test user gecos'
            test_user_dir = '/test home dir'

# Generated at 2022-06-20 20:06:44.599914
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_f = UserFactCollector()
    assert user_f.name == 'user'
    assert user_f._fact_ids == set(['user_id', 'user_uid', 'user_gid', 'user_gecos', 'user_dir', 'user_shell', 'real_user_id', 'effective_user_id', 'effective_group_ids']), "_fact_ids should be a set of names of fields to collect"


# Generated at 2022-06-20 20:06:51.118000
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ufc = UserFactCollector()
    assert ufc.name == 'user'
    assert set(ufc._fact_ids) == set(['user_id', 'user_uid', 'user_gid',
                                     'user_gecos', 'user_dir', 'user_shell',
                                     'real_user_id', 'effective_user_id',
                                     'effective_group_ids'])


# Generated at 2022-06-20 20:06:53.350198
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    try:
        user = UserFactCollector()
        user_facts = user.collect()
    except Exception as exc:
        print(exc)
        assert False


# Generated at 2022-06-20 20:07:01.336848
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ufc = UserFactCollector()
    assert ufc.name == 'user'
    assert 'user_id' in ufc._fact_ids
    assert 'user_uid' in ufc._fact_ids
    assert 'user_gid' in ufc._fact_ids
    assert 'user_gecos' in ufc._fact_ids
    assert 'user_dir' in ufc._fact_ids
    assert 'user_shell' in ufc._fact_ids
    assert 'real_user_id' in ufc._fact_ids
    assert 'effective_user_id' in ufc._fact_ids
    assert 'effective_group_ids' in ufc._fact_ids


# Generated at 2022-06-20 20:07:10.965612
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_fact_collector.collect()

# Generated at 2022-06-20 20:07:14.799680
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    facts_inst = UserFactCollector()
    assert facts_inst.name == 'user'
    user_shell = facts_inst.collect()['user_shell']
    assert isinstance(user_shell, str)
    assert isinstance(facts_inst._fact_ids, set)

# Generated at 2022-06-20 20:07:24.950509
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    class TestModule(object):
        def __init__(self):
            self.params = {
                'name': 'ansible'
            }

    class TestFacts(object):
        def __init__(self):
            self.user_id = 'ansible'

    ansible_module = TestModule()
    ansible_facts = TestFacts()

    def getuser():
        return 'ansible'

    def getpwuid(uid):
        class TestPWUID(object):
            def __init__(self):
                self.pw_dir = '/home/ansible'
                self.pw_uid = 1000
                self.pw_gecos = 'Ansible'
                self.pw_shell = '/bin/bash'
                self.pw_gid = 1000
        return TestPW

# Generated at 2022-06-20 20:07:29.528267
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    # Create an instance of UserFactCollector
    user_fact_collector = UserFactCollector()

    assert user_fact_collector is not None
    assert user_fact_collector.name == 'user'


# Generated at 2022-06-20 20:07:40.744318
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fact_collector = UserFactCollector()
    result = fact_collector.collect()
    try:
        pwent = pwd.getpwnam(getpass.getuser())
    except KeyError:
        pwent = pwd.getpwuid(os.getuid())
    assert result['user_uid'] == pwent.pw_uid
    assert result['user_gid'] == pwent.pw_gid
    assert result['user_gecos'] == pwent.pw_gecos
    assert result['user_dir'] == pwent.pw_dir
    assert result['user_shell'] == pwent.pw_shell
    assert result['real_user_id'] == os.getuid()
    assert result['effective_user_id'] == os.geteuid()

# Generated at 2022-06-20 20:07:48.130681
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    if not os.path.exists("/etc/passwd"):
        skip("No access to /etc/passwd")

# Generated at 2022-06-20 20:07:50.626723
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    from ansible.module_utils.facts.collector import FactCollector
    facts_d = {}
    fact_collector = FactCollector(facts=facts_d,
                                   cache=dict(),
                                   collectors=['user'])
    assert fact_collector
    assert fact_collector.collectors[0].name == 'user'


# Generated at 2022-06-20 20:07:55.761685
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    a = UserFactCollector()
    assert a.name == 'user'
    assert a._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                               'user_gecos', 'user_dir', 'user_shell',
                               'real_user_id', 'effective_user_id',
                               'effective_group_ids'])

# Generated at 2022-06-20 20:07:58.131059
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    assert UserFactCollector.name == 'user'


# Generated at 2022-06-20 20:08:04.934666
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    result = UserFactCollector()
    assert result.name == 'user'
    assert result._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                    'user_gecos', 'user_dir', 'user_shell',
                                    'real_user_id', 'effective_user_id',
                                    'effective_group_ids'])

# Generated at 2022-06-20 20:08:27.626671
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector().collect()
    # Unit test for method collect of class UserFactCollector
    assert isinstance(user_facts, dict)
    assert isinstance(user_facts['user_id'], str)
    assert isinstance(user_facts['user_uid'], int)
    assert isinstance(user_facts['user_gid'], int)
    assert isinstance(user_facts['user_gecos'], str)
    assert isinstance(user_facts['user_dir'], str)
    assert isinstance(user_facts['user_shell'], str)
    assert isinstance(user_facts['real_user_id'], int)
    assert isinstance(user_facts['effective_user_id'], int)
    assert isinstance(user_facts['real_group_id'], int)

# Generated at 2022-06-20 20:08:39.156130
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_result = UserFactCollector().collect()
    assert isinstance(user_result, dict)

# Generated at 2022-06-20 20:08:50.777425
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import cache

    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.system import SystemFactCollector


# Generated at 2022-06-20 20:09:00.439423
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    from ansible.module_utils.facts.collector import collector_registry

    collector = collector_registry.get_collector("UserFactCollector")
    collected_facts = collector.collect()
    assert 'user_id' in collected_facts
    assert 'user_uid' in collected_facts
    assert 'user_gid' in collected_facts
    assert 'user_gecos' in collected_facts
    assert 'user_dir' in collected_facts
    assert 'user_shell' in collected_facts
    assert 'real_user_id' in collected_facts
    assert 'effective_user_id' in collected_facts
    assert 'effective_group_ids' in collected_facts

# Generated at 2022-06-20 20:09:08.138925
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collect = UserFactCollector()
    data = collect.collect()
    assert data['user_id'] == getpass.getuser()
    assert type(data['user_uid']) == int
    assert type(data['user_gid']) == int
    assert type(data['user_gecos']) == str
    assert type(data['user_dir']) == str
    assert type(data['user_shell']) == str
    assert type(data['real_user_id']) == int
    assert type(data['effective_user_id']) == int
    assert type(data['effective_group_ids'][0]) == int

# Generated at 2022-06-20 20:09:17.563755
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    test_data = {}
    ufc = UserFactCollector()
    test_data = ufc.collect()

    # Check if the test_data has all required fields.
    assert 'user_id' in test_data
    assert 'user_uid' in test_data
    assert 'user_gid' in test_data
    assert 'user_gecos' in test_data
    assert 'user_dir' in test_data
    assert 'user_shell' in test_data
    assert 'real_user_id' in test_data
    assert 'effective_user_id' in test_data
    assert 'effective_group_ids' in test_data


# Generated at 2022-06-20 20:09:18.350435
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    x = UserFactCollector()


# Generated at 2022-06-20 20:09:20.267777
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    name_fact_collector = user_fact_collector.name
    assert name_fact_collector == "user"

# Generated at 2022-06-20 20:09:24.910046
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ufc = UserFactCollector()

    assert ufc.name == 'user'
    assert ufc._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                 'user_gecos', 'user_dir', 'user_shell',
                                 'real_user_id', 'effective_user_id'])



# Generated at 2022-06-20 20:09:28.966377
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    instance = UserFactCollector()
    assert instance.name == 'user'


# Generated at 2022-06-20 20:10:08.930365
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    import os
    import pwd
    # Check if the constructor correctly creates an object of type UserFactCollector
    myuser = UserFactCollector()
    # Check if the type of the object created is UserFactCollector
    assert(isinstance(myuser, UserFactCollector))


# Generated at 2022-06-20 20:10:16.455931
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    class mock_getpass(object):
        """Mock of getpass module"""
        @staticmethod
        def getuser():
            return 'test_user'

    class mock_pwd(object):
        """Mock of pwd module"""

        pwent = type('pwent', (object,), {
                     'pw_uid': 1001,
                     'pw_gid': 1003,
                     'pw_gecos': 'test user',
                     'pw_dir': '/home/test_user',
                     'pw_shell': '/bin/bash'
                     })()

        @staticmethod
        def getpwnam(username):
            return mock_pwd.pwent

        @staticmethod
        def getpwuid(uid):
            return mock_pwd.pwent


# Generated at 2022-06-20 20:10:22.463691
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    assert UserFactCollector.name == 'user'
    user_ids = set(['user_id', 'user_uid', 'user_gid',
                    'user_gecos', 'user_dir', 'user_shell',
                    'real_user_id', 'effective_user_id',
                    'effective_group_ids'])
    assert UserFactCollector._fact_ids == user_ids


# Generated at 2022-06-20 20:10:24.354037
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    assert UserFactCollector().name == 'user'

# Generated at 2022-06-20 20:10:29.414593
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    a = UserFactCollector()
    assert a.name == 'user'
    assert a._fact_ids == set(['user_id', 'user_uid', 'user_gid', 'user_gecos',
                               'user_dir', 'user_shell', 'real_user_id', 'effective_user_id',
                               'effective_group_ids'])

# Generated at 2022-06-20 20:10:32.616725
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_collector = UserFactCollector()
    result = {}
    user_collector.collect(collected_facts=result)
    assert result['user_id'] == getpass.getuser()

# Generated at 2022-06-20 20:10:37.664485
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    test_class = UserFactCollector()
    assert type(test_class) == UserFactCollector
    assert test_class.name == 'user'
    assert test_class._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                        'user_gecos', 'user_dir', 'user_shell',
                                        'real_user_id', 'effective_user_id',
                                        'effective_group_ids'])


# Generated at 2022-06-20 20:10:45.265656
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    # create instance of class UserFactCollector
    user_fact_collector = UserFactCollector()

    # test collect method of class UserFactCollector
    user_data = user_fact_collector.collect()
    assert isinstance(user_data, dict)
    assert user_data['user_id']
    assert isinstance(user_data['user_id'], str)
    assert user_data['user_uid']
    assert isinstance(user_data['user_uid'], int)
    assert user_data['user_gid']
    assert isinstance(user_data['user_gid'], int)
    assert user_data['user_gecos']
    assert isinstance(user_data['user_gecos'], str)
    assert user_data['user_dir']

# Generated at 2022-06-20 20:10:52.030126
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()
    assert 'user_id' in user_facts
    assert 'user_uid' in user_facts
    assert 'user_gid' in user_facts
    assert 'user_gecos' in user_facts
    assert 'user_dir' in user_facts
    assert 'user_shell' in user_facts
    assert 'real_user_id' in user_facts
    assert 'real_group_id' in user_facts
    assert 'effective_user_id' in user_facts
    assert 'effective_group_id' in user_facts

# Generated at 2022-06-20 20:10:57.430416
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ufc = UserFactCollector()
    assert ufc.name == 'user'
    assert set(ufc._fact_ids) == set(['user_id', 'user_uid', 'user_gid',
                                      'user_gecos', 'user_dir', 'user_shell',
                                      'real_user_id', 'effective_user_id',
                                      'real_group_id', 'effective_group_id'])



# Generated at 2022-06-20 20:12:17.379639
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    test = UserFactCollector()
    assert test
    assert test.name == 'user'

# Generated at 2022-06-20 20:12:24.461529
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    '''
    test_UserFactCollector_collect: Test return of UserFactCollector.collect method
    '''
    user_fact_collector = UserFactCollector()
    collected_facts = user_fact_collector.collect()

    assert collected_facts['user_id'] == getpass.getuser()
    assert collected_facts['real_user_id'] == os.getuid()
    assert collected_facts['effective_user_id'] == os.geteuid()
    assert collected_facts['real_group_id'] == os.getgid()
    assert collected_facts['effective_group_id'] == os.getgid()

# Generated at 2022-06-20 20:12:30.378588
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    # Test with no module parameter
    fc = UserFactCollector()
    assert fc.name == 'user'
    assert fc._fact_ids == set(['user_id', 'user_uid', 'user_gid', 'user_gecos',
                                'user_dir', 'user_shell', 'real_user_id',
                                'effective_user_id', 'effective_group_ids'])

# Generated at 2022-06-20 20:12:34.144418
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector().collect()
    assert(user_facts['user_id'] == getpass.getuser())
    assert(user_facts['user_shell'] == pwd.getpwuid(os.getuid()).pw_shell)
    assert(user_facts['real_user_id'] == os.getuid())

# Generated at 2022-06-20 20:12:40.856490
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
	user_fact_collector = UserFactCollector()
	assert user_fact_collector is not None

	assert user_fact_collector.name == 'user'
	assert user_fact_collector._fact_ids == {'user_id', 'user_uid', 'user_gid',
                     'user_gecos', 'user_dir', 'user_shell',
                     'real_user_id', 'effective_user_id',
                     'effective_group_ids'}

test_UserFactCollector()


# Generated at 2022-06-20 20:12:47.577839
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    assert UserFactCollector.name == 'user'
    assert 'user_id' in UserFactCollector._fact_ids
    assert 'user_uid' in UserFactCollector._fact_ids
    assert 'user_gid' in UserFactCollector._fact_ids
    assert 'user_gecos' in UserFactCollector._fact_ids
    assert 'user_dir' in UserFactCollector._fact_ids
    assert 'user_shell' in UserFactCollector._fact_ids
    assert 'real_user_id' in UserFactCollector._fact_ids
    assert 'effective_user_id' in UserFactCollector._fact_ids
    assert 'real_group_id' in UserFactCollector._fact_ids
    assert 'effective_group_id' in UserFactCollector._fact_ids


# Generated at 2022-06-20 20:12:53.606057
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    assert UserFactCollector.name == 'user'
    assert UserFactCollector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                              'user_gecos', 'user_dir', 'user_shell',
                                              'real_user_id', 'effective_user_id',
                                              'real_group_id', 'effective_group_id'])
    assert isinstance(UserFactCollector().collect(), dict)

# Generated at 2022-06-20 20:13:04.590328
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import os

    module = type('', (), {})()
    user = UserFactCollector()
    facts = user.collect(module, {})
    # tests for user id
    assert facts['user_id'] == os.environ['SUDO_USER']
    assert facts['user_id'] == os.getlogin()
    assert facts['user_id'] == os.getenv('USER')
    # tests for uid and gid
    # use getlogin because sudo_user is not defined when not using sudo
    assert facts['user_uid'] == os.getpwnam(os.getlogin()).pw_uid
    assert facts['user_gid'] == os.getpwnam(os.getlogin()).pw_gid
    # tests for /etc/passwd information
    assert facts['user_gecos']

# Generated at 2022-06-20 20:13:13.761258
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    result = ufc.collect()
    expected = {'effective_user_id': 1000, 'user_dir': '/home/user', 'user_gid': 1000, 'user_shell': '/bin/bash', 'user_id': 'user', 'user_gecos': 'test user,,,', 'effective_group_id': 1000, 'user_uid': 1000, 'real_group_id': 1000, 'real_user_id': 1000}
    assert result == expected, "Method UserFactCollector.collect returns incorrect data: %s, expected %s" % (result, expected)

# Generated at 2022-06-20 20:13:15.440353
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    test_collector = UserFactCollector()
    test_collector.collect()