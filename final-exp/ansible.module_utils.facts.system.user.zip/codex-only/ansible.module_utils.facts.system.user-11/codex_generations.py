

# Generated at 2022-06-23 01:50:19.374478
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ufc = UserFactCollector()
    assert ufc.name == 'user', 'name should be user'

# Generated at 2022-06-23 01:50:26.881219
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    ufc._module = {}
    ufc._module['gather_subset'] = {}
    user_facts = ufc.collect()
    assert 'user_id' in user_facts
    assert 'user_uid' in user_facts
    assert 'user_gid' in user_facts
    assert 'user_gecos' in user_facts
    assert 'user_dir' in user_facts
    assert 'user_shell' in user_facts
    assert 'real_user_id' in user_facts
    assert 'effective_user_id' in user_facts
    assert 'real_group_id' in user_facts
    assert 'effective_group_id' in user_facts

# Generated at 2022-06-23 01:50:32.729582
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert user_fact_collector.name == 'user'
    assert user_fact_collector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                                 'user_gecos', 'user_dir', 'user_shell',
                                                 'real_user_id', 'effective_user_id',
                                                 'effective_group_ids'])


# Generated at 2022-06-23 01:50:41.373402
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import platform
    import pwd
    uname = platform.uname()
    if uname[0] != "Darwin":
        pw = pwd.getpwuid(os.getuid())
    user = UserFactCollector()
    user_facts = user.collect()

    assert (user_facts['user_id'] == getpass.getuser())
    if uname[0] == "Darwin":
        assert (user_facts['user_uid'] == os.getuid())
    else:
        assert (user_facts['user_uid'] == pw[2])
    assert (user_facts['user_gid'] == pw[3])
    assert (user_facts['user_gecos'] == pw[4])
    assert (user_facts['user_dir'] == pw[5])

# Generated at 2022-06-23 01:50:47.536116
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    """
    Unit test for constructor of class UserFactCollector
    """
    ufc = UserFactCollector()
    assert ufc.name == 'user'
    assert ufc._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                 'user_gecos', 'user_dir', 'user_shell',
                                 'real_user_id', 'effective_user_id',
                                 'effective_group_ids'])

# Generated at 2022-06-23 01:50:48.566366
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
  assert UserFactCollector == type(UserFactCollector())

# Generated at 2022-06-23 01:50:58.812867
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Unit test for method collect of class UserFactCollector

    # Generate test facts
    import time
    t_ts = int(time.time())
    t_str = time.strftime("%a %b %d %H:%M:%S %Z %Y", time.localtime())

    test_facts = {
        "user_id": "testuser",
        "user_uid": 1000,
        "user_gid": 1000,
        "user_gecos": "Test User",
        "user_dir": "/home/testuser",
        "user_shell": "/bin/bash",
        "real_user_id": 1000,
        "effective_user_id": 1000,
        "real_group_id": 1000,
        "effective_group_id": 1000
    }

    # Init and populate instance


# Generated at 2022-06-23 01:51:05.346419
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    fc = UserFactCollector()
    assert fc is not None
    assert fc.name == 'user'
    assert fc._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                'user_gecos', 'user_dir', 'user_shell',
                                'real_user_id', 'effective_user_id',
                                'real_group_ids', 'effective_group_ids'])

# Generated at 2022-06-23 01:51:08.841685
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector()
    collected_facts = user_facts.collect()
    assert collected_facts['user_uid'] == os.geteuid()
    assert collected_facts['user_gid'] == os.getegid()

# Generated at 2022-06-23 01:51:19.422282
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_facts = UserFactCollector().collect()
    try:
        assert getpass.getuser() == user_facts['user_id']
        assert os.getuid() == user_facts['user_uid']
        assert os.getgid() == user_facts['user_gid']
        assert os.getuid() == user_facts['real_user_id']
        assert os.geteuid() == user_facts['effective_user_id']
        assert os.getgid() == user_facts['real_group_id']
        assert os.getgid() == user_facts['effective_group_id']
    except Exception as e:
        raise e

# Generated at 2022-06-23 01:51:21.332219
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    fact_collector = UserFactCollector()
    assert fact_collector.name == "user"


# Generated at 2022-06-23 01:51:25.565911
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    test_instance = UserFactCollector()
    assert test_instance.name == 'user'
    assert test_instance._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                           'user_gecos', 'user_dir', 'user_shell',
                                           'real_user_id', 'effective_user_id',
                                           'effective_group_ids'])

# Generated at 2022-06-23 01:51:27.405926
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    c = UserFactCollector()
    assert c.name == 'user'

# Generated at 2022-06-23 01:51:31.494526
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Instantiate class object
    ufc = UserFactCollector()

    # Because method collect doesn't take any parameter ensure that the
    # parameter passed when method is called is None
    assert ufc.collect() is not None


# Generated at 2022-06-23 01:51:37.792939
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_obj = UserFactCollector()
    assert user_obj.name == "user"
    assert user_obj._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                      'user_gecos', 'user_dir', 'user_shell',
                                      'real_user_id', 'effective_user_id',
                                      'effective_group_ids'])


# Generated at 2022-06-23 01:51:43.020696
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    # Instantiate UserFactCollector object and try to populate its attributes
    user_fact_collector_obj = UserFactCollector()
    user_fact_collector_obj.name
    user_fact_collector_obj._fact_ids
    # UserFactCollector class always returns a dictionary
    assert isinstance(user_fact_collector_obj.collect(), dict)


# Generated at 2022-06-23 01:51:48.440501
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user = UserFactCollector()
    assert user.name == 'user'
    assert user._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                  'user_gecos', 'user_dir', 'user_shell',
                                  'real_user_id', 'effective_user_id',
                                  'effective_group_ids'])


# Generated at 2022-06-23 01:51:54.705030
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    collector = UserFactCollector()
    assert collector.name == 'user'
    assert set(collector._fact_ids) == {'user_id', 'user_uid', 'user_gid',
                                        'user_gecos', 'user_dir', 'user_shell',
                                        'real_user_id', 'effective_user_id',
                                        'effective_group_ids'}



# Generated at 2022-06-23 01:52:02.359206
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    def geteuid():
        return 1
    def getgid():
        return 100
    def getuid():
        return 1
    def getpwuid(uid):
        return {'pw_uid':uid,
                'pw_gid': 100,
                'pw_gecos': 'gecos',
                'pw_dir': '/home/username',
                'pw_shell': '/bin/bash'}
    def getpwnam(name):
        return {'pw_uid': 1,
                'pw_gid': 100,
                'pw_gecos': 'gecos',
                'pw_dir': '/home/username',
                'pw_shell': '/bin/bash'}
    def getpass_getuser():
        return 'someone'

    pwd_mock

# Generated at 2022-06-23 01:52:12.144615
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fact_collection = {
        'system_information': {
            'distribution': {
                'name': 'Ubuntu',
                'major_release': '16'
            }
        }
    }
    collector = UserFactCollector()
    result = collector.collect(collected_facts=fact_collection)

    assert result['user_id'] == getpass.getuser()
    assert result['user_uid'] == pwd.getpwnam(getpass.getuser()).pw_uid
    assert result['user_gid'] == pwd.getpwnam(getpass.getuser()).pw_gid
    assert result['user_gecos'] == pwd.getpwnam(getpass.getuser()).pw_gecos
    assert result['user_dir'] == pwd.getpwnam

# Generated at 2022-06-23 01:52:24.034361
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    collected_facts = {}
    module = None
    user_facts = ufc.collect(collected_facts=collected_facts, module=module)
    expected_facts = {}
    expected_facts['user_id'] = getpass.getuser()
    expected_facts['user_uid'] = pwd.getpwuid(os.getuid()).pw_uid
    expected_facts['user_gid'] = pwd.getpwuid(os.getuid()).pw_gid
    expected_facts['user_gecos'] = pwd.getpwuid(os.getuid()).pw_gecos
    expected_facts['user_dir'] = pwd.getpwuid(os.getuid()).pw_dir

# Generated at 2022-06-23 01:52:26.922567
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    print("testing UserFactCollector class constructor")
    user = UserFactCollector()
    assert user.name == 'user'
    assert user._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                     'user_gecos', 'user_dir', 'user_shell',
                     'real_user_id', 'effective_user_id',
                     'effective_group_ids'])


# Generated at 2022-06-23 01:52:32.636126
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    u = UserFactCollector()
    assert u.name == 'user'
    assert u._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                               'user_gecos', 'user_dir', 'user_shell',
                               'real_user_id', 'effective_user_id',
                               'effective_group_ids'])


# Generated at 2022-06-23 01:52:39.038995
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    collector = UserFactCollector()
    assert collector.name == 'user'
    assert collector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                       'user_gecos', 'user_dir', 'user_shell',
                                       'real_user_id', 'effective_user_id',
                                       'effective_group_ids'])


# Generated at 2022-06-23 01:52:42.729806
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    obj = UserFactCollector()
    if (not obj.collect()):
        raise AssertionError("Expected user facts not collected")
    return True

# Generated at 2022-06-23 01:52:45.814242
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    assert UserFactCollector.name == 'user'
    assert len(UserFactCollector._fact_ids) == 9


# Generated at 2022-06-23 01:52:49.197081
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    test_user = UserFactCollector()
    assert test_user.name == 'user'
    assert test_user._fact_ids == {'user_id', 'user_uid', 'user_gid',
                                   'user_gecos', 'user_dir', 'user_shell',
                                   'real_user_id', 'effective_user_id',
                                   'effective_group_ids'}


# Generated at 2022-06-23 01:52:51.395598
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user = UserFactCollector()
    assert user.name == 'user'

    pass


# Generated at 2022-06-23 01:53:00.860032
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    result = UserFactCollector().collect()
    assert(result['user_id'] == getpass.getuser())
    assert(result['user_uid'] == pwd.getpwuid(os.getuid())[2])
    assert(result['user_gid'] == pwd.getpwuid(os.getuid())[3])
    assert(result['user_gecos'] == pwd.getpwuid(os.getuid())[4])
    assert(result['user_dir'] == pwd.getpwuid(os.getuid())[5])
    assert(result['user_shell'] == pwd.getpwuid(os.getuid())[6])
    assert(result['real_user_id'] == os.getuid())

# Generated at 2022-06-23 01:53:05.834270
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Create collector object
    user_fact_collector = UserFactCollector()

    # Call method and compare result
    result = user_fact_collector.collect()
    assert len(result) > 0
    for key, value in result.iteritems():
        assert key in user_fact_collector._fact_ids
        assert value is not None

# Generated at 2022-06-23 01:53:11.889475
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user = UserFactCollector()
    assert user.name == 'user'
    assert user._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                     'user_gecos', 'user_dir', 'user_shell',
                     'real_user_id', 'effective_user_id',
                     'effective_group_ids'])

# Generated at 2022-06-23 01:53:19.106150
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ufc = UserFactCollector()
    print("Checking constructor of UserFactCollector")
    assert ufc.name == 'user'
    assert ufc._fact_ids == {'user_id', 'user_uid', 'user_gid', 'user_gecos', 'user_dir', 'user_shell', 'real_user_id', 'effective_user_id', 'effective_group_ids'}


# Generated at 2022-06-23 01:53:28.325801
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_collector = UserFactCollector()
    user_facts = user_collector.collect()
    user_ids = user_facts.keys()
    assert 'user_id' in user_ids
    assert 'user_uid' in user_ids
    assert 'user_gid' in user_ids
    assert 'user_gecos' in user_ids
    assert 'user_dir' in user_ids
    assert 'user_shell' in user_ids
    assert 'real_user_id' in user_ids
    assert 'effective_user_id' in user_ids
    assert 'real_group_id' in user_ids
    assert 'effective_group_id' in user_ids

# Generated at 2022-06-23 01:53:33.731462
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ufc = UserFactCollector()

    assert ufc.name == 'user'
    assert ufc._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                 'user_gecos', 'user_dir', 'user_shell',
                                 'real_user_id', 'effective_user_id',
                                 'effective_group_ids'])


# Generated at 2022-06-23 01:53:37.166467
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    input_facts = {}
    user_fact_collector = UserFactCollector()
    output_facts = user_fact_collector.collect(collected_facts=input_facts)

    assert isinstance(output_facts, dict)

# Generated at 2022-06-23 01:53:41.283783
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()

    # test collect method
    assert isinstance(user_fact_collector.collect(), dict)

# Generated at 2022-06-23 01:53:47.321075
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    x = UserFactCollector()
    assert x
    assert x.name == 'user'
    assert x._fact_ids == frozenset(['user_id', 'user_uid', 'user_gid',
                                     'user_gecos', 'user_dir', 'user_shell',
                                     'real_user_id', 'effective_user_id',
                                     'effective_group_ids'])

# Generated at 2022-06-23 01:53:48.330588
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    obj = UserFactCollector()
    assert obj.name == 'user'

# Generated at 2022-06-23 01:53:59.219361
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    if os.geteuid() != 0: # Don't run as root
        collect = UserFactCollector()
        assert collect
        user = getpass.getuser()
        user_uid = pwd.getpwnam(user).pw_uid
        assert collect.collect() == {'user_id': user, 'user_uid': user_uid, 'user_gid': user_uid, 'user_gecos': '', 'user_dir': '/home/{0}'.format(user), 'user_shell': '/bin/false', 'real_user_id': user_uid, 'effective_user_id': user_uid, 'effective_group_id': user_uid}

# vim: set expandtab ts=4 sw=4:

# Generated at 2022-06-23 01:54:02.059082
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    U = UserFactCollector()

# Generated at 2022-06-23 01:54:02.676465
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    UserFactCollector()

# Generated at 2022-06-23 01:54:12.478928
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector().collect()
    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['user_uid'] == pwd.getpwnam(getpass.getuser()).pw_uid
    assert user_facts['user_gid'] == pwd.getpwnam(getpass.getuser()).pw_gid
    assert user_facts['user_gecos'] == pwd.getpwnam(getpass.getuser()).pw_gecos
    assert user_facts['user_dir'] == pwd.getpwnam(getpass.getuser()).pw_dir
    assert user_facts['user_shell'] == pwd.getpwnam(getpass.getuser()).pw_shell

# Generated at 2022-06-23 01:54:18.734755
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()

    assert user_fact_collector.name == 'user'
    assert user_fact_collector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                                 'user_gecos', 'user_dir', 'user_shell',
                                                 'real_user_id', 'effective_user_id',
                                                 'effective_group_ids'])

# Generated at 2022-06-23 01:54:22.068552
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user = UserFactCollector()
    result = user.collect()
    assert result['user_id'] == getpass.getuser()
    assert result['effective_group_id'] == os.getegid()

# Generated at 2022-06-23 01:54:30.682146
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    res = UserFactCollector().collect(collected_facts=None)
    gecos = pwd.getpwuid(os.getuid()).pw_gecos
    assert res['user_gecos'] == gecos
    shell = pwd.getpwuid(os.getuid()).pw_shell
    assert res['user_shell'] == shell

# Generated at 2022-06-23 01:54:32.994745
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert user_fact_collector is not None

# Generated at 2022-06-23 01:54:35.306297
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert user_fact_collector.name == 'user'


# Generated at 2022-06-23 01:54:37.380604
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collector = UserFactCollector()
    collected_facts = collector.collect()

# Generated at 2022-06-23 01:54:38.923152
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fc = UserFactCollector()
    user_fc.collect()

# Generated at 2022-06-23 01:54:49.450737
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert user_fact_collector.name == 'user'
    assert user_fact_collector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                                 'user_gecos', 'user_dir', 'user_shell',
                                                 'real_user_id', 'effective_user_id',
                                                 'effective_group_ids'])



# Generated at 2022-06-23 01:55:00.923018
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ufc = UserFactCollector()
    # Validate the name property.
    assert ufc.name == 'user'
    # Validate the _fact_ids property.
    assert 'user_id' in ufc._fact_ids
    assert 'user_uid' in ufc._fact_ids
    assert 'user_gid' in ufc._fact_ids
    assert 'user_gecos' in ufc._fact_ids
    assert 'user_dir' in ufc._fact_ids
    assert 'user_shell' in ufc._fact_ids
    assert 'real_user_id' in ufc._fact_ids
    assert 'effective_user_id' in ufc._fact_ids
    assert 'real_group_id' in ufc._fact_ids
    assert 'effective_group_id' in ufc._fact

# Generated at 2022-06-23 01:55:12.610147
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fake_user = 'fakeuser'
    fake_uid = 1000
    fake_gid = 1000
    fake_gecos = 'fakeuser'
    fake_dir = '/home/fakeuser'
    fake_shell = '/bin/bash'
    fake_real_uid = 1000
    fake_effective_uid = 1000
    fake_real_gid = 1000
    fake_effective_gid = 1000

# Generated at 2022-06-23 01:55:23.211860
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    class TestModule(object):
        pass

    test_module = TestModule()
    test_module.params = {}

    collected_facts = {}

    user_fact_collector = UserFactCollector(None, test_module, collected_facts)
    user_facts = user_fact_collector.collect()
    assert user_facts is not None
    assert 'user_id' in user_facts
    assert 'user_uid' in user_facts
    assert 'user_gid' in user_facts
    assert 'user_gecos' in user_facts
    assert 'user_dir' in user_facts
    assert 'user_shell' in user_facts
    assert 'real_user_id' in user_facts
    assert 'effective_user_id' in user_facts
    assert 'real_group_id' in user_facts

# Generated at 2022-06-23 01:55:34.131341
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()
    assert isinstance(user_facts, dict)
    assert set(user_facts.keys()) == set(['user_id', 'user_uid', 'user_gid',
                                          'user_gecos', 'user_dir', 'user_shell',
                                          'real_user_id', 'effective_user_id',
                                          'real_group_id', 'effective_group_id'])
    assert user_facts['user_id'] == getpass.getuser()
    pwent = pwd.getpwnam(getpass.getuser())
    # Compare user_id with user_uid, user_gid and user_dir

# Generated at 2022-06-23 01:55:44.153437
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user = UserFactCollector()
    user_facts = user.collect()
    assert user_facts.get('user_id') is not None
    assert user_facts.get('user_uid') is not None
    assert user_facts.get('user_gid') is not None
    assert user_facts.get('user_gecos') is not None
    assert user_facts.get('user_dir') is not None
    assert user_facts.get('user_shell') is not None
    assert user_facts.get('real_user_id') is not None
    assert user_facts.get('effective_user_id') is not None
    assert user_facts.get('real_group_id') is not None
    assert user_facts.get('effective_group_ids') is not None

# Generated at 2022-06-23 01:55:47.152263
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    um = UserFactCollector()
    assert(um.name == 'user')
    assert(_fact_ids.size() == 8)

# Generated at 2022-06-23 01:55:53.892475
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    module = None
    collected_facts = None
    ufc_object = UserFactCollector()
    assert ufc_object.name == 'user'
    assert ufc_object._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                     'user_gecos', 'user_dir', 'user_shell',
                     'real_user_id', 'effective_user_id',
                     'real_group_id', 'effective_group_id'])


# Generated at 2022-06-23 01:56:00.353452
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    userFactCollector = UserFactCollector()
    assert userFactCollector.name == 'user'
    assert userFactCollector._fact_ids == set(['user_id', 'user_uid', 'user_gid', 'user_gecos',
                                               'user_dir', 'user_shell', 'real_user_id',
                                               'effective_user_id', 'effective_group_ids'])

# Generated at 2022-06-23 01:56:01.776594
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
     collector = UserFactCollector()
     assert collector is not None
     assert collector.name == 'user'

# Generated at 2022-06-23 01:56:09.093520
# Unit test for constructor of class UserFactCollector

# Generated at 2022-06-23 01:56:21.044251
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import os
    import pwd
    import getpass
    result = {}
    test_UserFactCollector_collect = UserFactCollector()
    # getpwnam will get user details
    result_getpwnam = pwd.getpwnam(getpass.getuser())
    # getpwuid will get user details
    result_getpwuid = pwd.getpwuid(os.getuid())

    # UserFactCollector.collect() returns a dictionary
    result = test_UserFactCollector_collect.collect()

    assert result['user_id'] == getpass.getuser()
    assert result['user_uid'] == result_getpwnam.pw_uid
    assert result['user_gid'] == result_getpwnam.pw_gid
    assert result['user_gecos']

# Generated at 2022-06-23 01:56:30.675773
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    collected_facts = {}
    ufc.collect(collected_facts=collected_facts)
    assert type(collected_facts) == dict
    assert 'user_uid' in collected_facts['ansible_user_id']
    assert 'user_dir' in collected_facts['ansible_user_id']
    assert 'real_user_id' in collected_facts['ansible_user_id']
    assert 'effective_user_id' in collected_facts['ansible_user_id']
    assert 'effective_group_ids' in collected_facts['ansible_user_id']
    assert 'user_uid' in collected_facts['ansible_user_id']['user_uid']

# Generated at 2022-06-23 01:56:38.687889
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_collector = UserFactCollector()
    user_facts = user_collector.collect()

    assert user_facts['user_id'] == getpass.getuser()

    pwent = pwd.getpwnam(getpass.getuser())

    assert user_facts['user_uid'] == pwent.pw_uid
    assert user_facts['user_gid'] == pwent.pw_gid
    assert user_facts['user_gecos'] == pwent.pw_gecos
    assert user_facts['user_dir'] == pwent.pw_dir
    assert user_facts['user_shell'] == pwent.pw_shell
    assert user_facts['real_user_id'] == os.getuid()
    assert user_facts['effective_user_id'] == os.geteuid()

# Generated at 2022-06-23 01:56:44.407196
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user = UserFactCollector()
    assert user.name == 'user'
    assert user._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                  'user_gecos', 'user_dir', 'user_shell',
                                  'real_user_id', 'effective_user_id',
                                  'effective_group_ids'])

# Generated at 2022-06-23 01:56:52.105278
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    """UserFactCollector: Tests the collect() method"""

# Generated at 2022-06-23 01:56:53.107516
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    pass


# Generated at 2022-06-23 01:56:59.474688
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_obj = UserFactCollector()
    assert isinstance(user_obj, UserFactCollector)
    assert user_obj.name == "user"
    assert user_obj._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                      'user_gecos', 'user_dir', 'user_shell',
                                      'real_user_id', 'effective_user_id',
                                      'effective_group_ids'])


# Generated at 2022-06-23 01:57:07.472962
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    # Test presence of some keys in the method result
    result = UserFactCollector().collect()
    assert 'user_id' in result
    assert 'user_uid' in result
    assert 'user_gid' in result
    assert 'user_gecos' in result
    assert 'user_dir' in result
    assert 'user_shell' in result
    assert 'real_user_id' in result
    assert 'effective_user_id' in result
    assert 'real_group_id' in result
    assert 'effective_group_id' in result

# Generated at 2022-06-23 01:57:14.036186
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    fact_subclass_instance = UserFactCollector()
    assert isinstance(fact_subclass_instance, UserFactCollector)
    assert hasattr(fact_subclass_instance, 'name')
    assert fact_subclass_instance.name == 'user'
    assert hasattr(fact_subclass_instance, '_fact_ids')
    assert isinstance(fact_subclass_instance._fact_ids, set)

# Generated at 2022-06-23 01:57:26.117641
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import os
    import pwd
    test_uid = 1000
    test_euid = 1002
    test_gid = 500
    test_egid = 600
    test_dir = '/home/ansible'
    test_shell = '/bin/bash'
    test_gecos = 'Ansible User'
    test_user_id = 'ansible'

    class MockOsModule():
        def getuid(self):
            return test_uid
        def geteuid(self):
            return test_euid
        def getgid(self):
            return test_egid
        def getegid(self):
            return test_egid

    class MockPwdModule():
        class MockPwEntry():
            pass
        def getpwnam(self, uname):
            pwent = MockPwEntry()

# Generated at 2022-06-23 01:57:31.972241
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    x = UserFactCollector()
    assert x.name == 'user'
    assert x._fact_ids == set(['user_id', 'user_uid', 'user_gid', 'user_gecos', 'user_dir', 'user_shell', 'real_user_id',
                               'effective_user_id', 'effective_group_ids'])



# Generated at 2022-06-23 01:57:37.944554
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ac = UserFactCollector()
    assert ac.name == 'user'
    assert sorted(ac._fact_ids) == [
        'effective_group_ids',
        'effective_user_id',
        'real_user_id',
        'user_dir',
        'user_gecos',
        'user_gid',
        'user_id',
        'user_shell',
        'user_uid'
    ]

# Generated at 2022-06-23 01:57:41.974841
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector_instance = UserFactCollector()
    assert user_fact_collector_instance is not None

# Generated at 2022-06-23 01:57:47.401660
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    usr_fct = UserFactCollector()
    usr_fct_ids = usr_fct.collect()
    assert type(usr_fct_ids) is dict
    assert len(usr_fct_ids) > 0

# Generated at 2022-06-23 01:57:56.617548
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Get actual value
    ufc = UserFactCollector()
    actual = ufc.collect()
    
    # Get expected value

# Generated at 2022-06-23 01:58:05.986170
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_collector = UserFactCollector()

    # Test user_id
    assert user_collector.collect(collected_facts = {'ansible_user_id': 'test'}) == {
        'user_id': 'test',
        'user_uid': None,
        'user_gid': None,
        'user_gecos': None,
        'user_dir': None,
        'user_shell': None,
        'real_user_id': None,
        'effective_user_id': None,
        'real_group_id': None,
        'effective_group_id': None
    }


if __name__ == '__main__':
    test_UserFactCollector()

# Generated at 2022-06-23 01:58:16.054383
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collector = UserFactCollector()
    result = collector.collect()
    assert result['user_id'] == getpass.getuser()
    assert result['user_uid'] == pwd.getpwuid(os.getuid()).pw_uid
    assert result['user_gid'] == pwd.getpwuid(os.getuid()).pw_gid
    assert result['user_gecos'] == pwd.getpwuid(os.getuid()).pw_gecos
    assert result['user_dir'] == pwd.getpwuid(os.getuid()).pw_dir
    assert result['user_shell'] == pwd.getpwuid(os.getuid()).pw_shell
    assert result['real_user_id'] == os.getuid()

# Generated at 2022-06-23 01:58:21.672374
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    val_1 = UserFactCollector()

    assert val_1.name == 'user'
    assert val_1._fact_ids == {'user_id', 'user_uid', 'user_gid',
                               'user_gecos', 'user_dir', 'user_shell',
                               'real_user_id', 'effective_user_id',
                               'effective_group_ids'}


# Generated at 2022-06-23 01:58:27.440831
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts_dict = {}
    user_facts_dict = user_fact_collector.collect()
    assert user_facts_dict['user_id'] == getpass.getuser()

# Generated at 2022-06-23 01:58:30.966910
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    collector = UserFactCollector()
    assert collector.name == 'user'
    assert collector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                     'user_gecos', 'user_dir', 'user_shell',
                     'real_user_id', 'effective_user_id',
                     'effective_group_ids'])

# Generated at 2022-06-23 01:58:36.137191
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    userFactCollector = UserFactCollector()
    result = userFactCollector.collect()
    assert result['real_user_id'] == os.getuid()
    assert result['effective_user_id'] == os.geteuid()
    assert result['real_group_id'] == os.getgid()
    assert result['effective_group_id'] == os.getgid()

# Generated at 2022-06-23 01:58:46.836512
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import getpass
    import os
    import pwd

    # Declare test class variables
    user_uid = 1001
    user_gid = 1002
    user_gecos = "Test User"
    user_shell = "/bin/bash"
    user_dir = "/home/testuser"
    user_id = "testuser"
    real_user_id = 1001
    effective_user_id = 1001
    real_group_id = 1002
    effective_group_id = 1002

    # Create test class instance
    test_instance = UserFactCollector()

    # Mock method getuser from getpass
    getpass.getuser = lambda: user_id

    # Mock method getpwnam from pwd

# Generated at 2022-06-23 01:58:54.054919
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_facts = UserFactCollector()
    assert 'user_id' in user_facts._fact_ids 
    assert 'user_uid' in user_facts._fact_ids
    assert 'user_gid' in user_facts._fact_ids
    assert 'user_gecos' in user_facts._fact_ids
    assert 'user_dir' in user_facts._fact_ids
    assert 'user_shell' in user_facts._fact_ids
    assert 'real_user_id' in user_facts._fact_ids
    assert 'effective_user_id' in user_facts._fact_ids

# Generated at 2022-06-23 01:58:56.092450
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fc = UserFactCollector()
    assert user_fc.collect()['user_id'] == getpass.getuser()

# Generated at 2022-06-23 01:59:09.566665
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_collector = UserFactCollector()
    assert user_collector.name == 'user'
    assert isinstance(user_collector._fact_ids, set)
    assert 'user_id' in user_collector._fact_ids
    assert 'user_uid' in user_collector._fact_ids
    assert 'user_gid' in user_collector._fact_ids
    assert 'user_gecos' in user_collector._fact_ids
    assert 'user_dir' in user_collector._fact_ids
    assert 'user_shell' in user_collector._fact_ids
    assert 'real_user_id' in user_collector._fact_ids
    assert 'effective_user_id' in user_collector._fact_ids
    assert 'effective_group_ids' in user_collector._

# Generated at 2022-06-23 01:59:11.741160
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user = UserFactCollector()
    print('User is ', user)
    assert user.name == 'user'


# Generated at 2022-06-23 01:59:18.479365
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Arrange
    from ansible.module_utils.facts.user import UserFactCollector
    ufc = UserFactCollector()
    expected_result = {'user_id': None, 'user_uid': None, 'user_gid': None, 'user_gecos': None, 'user_dir': None, 'user_shell': None, 'real_user_id': None, 'effective_user_id': None, 'effective_group_ids': None, 'real_group_id': None}
    # Act
    result = ufc.collect()
    # Assert
    assert expected_result == result


# Generated at 2022-06-23 01:59:23.899579
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    U = UserFactCollector()
    assert U.name == 'user'
    assert U._fact_ids == {'user_id', 'user_uid', 'user_gid',
                           'user_gecos', 'user_dir', 'user_shell',
                           'real_user_id', 'effective_user_id',
                           'effective_group_ids'}

# Generated at 2022-06-23 01:59:30.533511
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    u = UserFactCollector()
    assert u.name == 'user'
    assert u._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                               'user_gecos', 'user_dir', 'user_shell',
                               'real_user_id', 'effective_user_id',
                               'effective_group_ids'])

# Generated at 2022-06-23 01:59:31.722209
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    obj = UserFactCollector()
    assert obj.name == 'user'

# Generated at 2022-06-23 01:59:38.804569
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    collected_facts = {}
    # collect() does not take any parameters
    facts = ufc.collect(collected_facts=collected_facts)

    assert isinstance(facts, dict)
    assert 'user_id' in facts
    assert isinstance(facts['user_id'], str) or isinstance(facts['user_id'], unicode)
    assert 'user_uid' in facts
    assert isinstance(facts['user_uid'], int)
    assert 'user_gid' in facts
    assert isinstance(facts['user_gid'], int)
    assert 'user_gecos' in facts
    assert isinstance(facts['user_gecos'], str) or isinstance(facts['user_gecos'], unicode)
    assert 'user_dir' in facts


# Generated at 2022-06-23 01:59:39.572328
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    fact_collector = UserFactCollector()
    assert fact_collector is not None

# Generated at 2022-06-23 01:59:44.760922
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    """ Unit test for: test_UserFactCollector_collect. """

    # Getting current user
    user = os.getenv("USER")

    # Getting user's home directory
    homeDir = os.getenv("HOME")

    # Getting user's gid
    gid = os.getegid()

    # Getting user's uid
    uid = os.geteuid()

    # Getting user's shell
    shell = os.getenv("SHELL")

    # Checking if class UserFactCollector exists
    assert UserFactCollector

    # Creating user fact collector object
    test = UserFactCollector()

    # Calling collect method
    response = test.collect()

    # Testing if user_id is user
    assert response['user_id'] == user

    # Testing if user_dir is user's home directory

# Generated at 2022-06-23 01:59:53.335974
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    """
    Test method collect of UserFactCollector
    """

    user = UserFactCollector()
    user_facts = user.collect()

    assert 'user_id' in user_facts
    assert 'user_uid' in user_facts
    assert 'user_gid' in user_facts
    assert 'user_gecos' in user_facts
    assert 'user_dir' in user_facts
    assert 'user_shell' in user_facts
    assert 'real_user_id' in user_facts
    assert 'effective_user_id' in user_facts
    assert 'real_group_id' in user_facts
    assert 'effective_group_id' in user_facts

# Generated at 2022-06-23 01:59:57.740301
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collector = UserFactCollector()
    facts = collector.collect()
    assert facts['user_id'] == getpass.getuser()
    assert facts['real_group_id'] == os.getgid()

# Generated at 2022-06-23 02:00:09.149185
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    # arrange
    expected_user_facts = {
        'user_id': getpass.getuser(),
        'user_uid': os.getuid(),
        'user_gid': os.getgid(),
        'user_gecos': pwd.getpwuid(os.getuid()).pw_gecos,
        'user_dir': pwd.getpwuid(os.getuid()).pw_dir,
        'user_shell': pwd.getpwuid(os.getuid()).pw_shell,
        'real_user_id': os.getuid(),
        'effective_user_id': os.geteuid(),
        'real_group_id': os.getgid(),
        'effective_group_id': os.getegid()
    }

    # act
   

# Generated at 2022-06-23 02:00:20.994330
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    mock_module = "mock_module"
    mock_collected_facts = {"some_fact":"some_fact_value"}
    mock_user_facts = {
         "user_id": "test_user_id",
         "user_uid": 1001,
         "user_gid": 1002,
         "user_gecos": "test_user_gecos",
         "user_dir": "/home/test_user_id",
         "user_shell": "/bin/sh",
         "real_user_id": 1001,
         "effective_user_id": 1001,
         "real_group_id": 1002,
         "effective_group_id": 1002
    }
    uf_collector=UserFactCollector()   # constructor call is tested in test_user.py

    # mock_