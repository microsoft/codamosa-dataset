

# Generated at 2022-06-23 01:50:23.446334
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_facts = UserFactCollector()
    assert user_facts.name == 'user'
    assert user_facts._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                        'user_gecos', 'user_dir', 'user_shell',
                                        'real_user_id', 'effective_user_id',
                                        'effective_group_ids'])

# Generated at 2022-06-23 01:50:31.156710
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert user_fact_collector.name == 'user'
    assert user_fact_collector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                                 'user_gecos', 'user_dir', 'user_shell',
                                                 'real_user_id', 'effective_user_id',
                                                 'effective_group_ids'])


# Generated at 2022-06-23 01:50:39.513934
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    UserFactCollectorInstance = UserFactCollector()

# Generated at 2022-06-23 01:50:48.158382
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collector = UserFactCollector()

    user_facts = collector.collect()

    assert user_facts['user_id'] == getpass.getuser()
    assert 'user_uid' in user_facts
    assert 'user_gid' in user_facts
    assert 'user_gecos' in user_facts
    assert 'user_dir' in user_facts
    assert 'user_shell' in user_facts
    assert 'real_user_id' in user_facts
    assert 'effective_user_id' in user_facts
    assert 'real_group_id' in user_facts
    assert 'effective_group_id' in user_facts

# Generated at 2022-06-23 01:50:58.731552
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    """ test omitting a file """
    # Given
    usr_fact_collect  = UserFactCollector()
    # When
    user_facts = usr_fact_collect.collect()
    # Then
    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['user_uid'] == pwd.getpwnam(getpass.getuser()).pw_uid
    assert user_facts['user_gid'] == pwd.getpwnam(getpass.getuser()).pw_gid
    assert user_facts['user_gecos'] == pwd.getpwnam(getpass.getuser()).pw_gecos
    assert user_facts['user_dir'] == pwd.getpwnam(getpass.getuser()).pw_dir

# Generated at 2022-06-23 01:51:03.219428
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    assert UserFactCollector.name == 'user'
    assert UserFactCollector._fact_ids == \
        set(['user_id', 'user_uid', 'user_gid',
             'user_gecos', 'user_dir', 'user_shell',
             'real_user_id', 'effective_user_id',
             'effective_group_ids'])


# Generated at 2022-06-23 01:51:07.919584
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()

    assert type(user_facts) is dict
    assert user_facts["user_id"] == os.getenv("USER")

# Generated at 2022-06-23 01:51:16.731917
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fact_module = UserFactCollector()
    result = fact_module.collect()

    assert result
    assert result['user_id']
    assert result['user_uid']
    assert result['user_gid']
    assert result['user_gecos']
    assert result['user_dir']
    assert result['user_shell']
    assert result['real_user_id']
    assert result['effective_user_id']
    assert result['real_group_id']
    assert result['effective_group_id']

# Generated at 2022-06-23 01:51:18.493528
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert user_fact_collector.name == 'user'

# Generated at 2022-06-23 01:51:31.475063
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector().collect()
    assert user_facts.keys() == {'user_id', 'user_uid', 'user_gid',
                                 'user_gecos', 'user_dir', 'user_shell',
                                 'real_user_id', 'effective_user_id',
                                 'real_group_id', 'effective_group_id'}
    assert getpass.getuser() == user_facts['user_id']
    assert pwd.getpwuid(os.getuid()) == pwd.getpwnam(getpass.getuser())
    assert os.getuid() == user_facts['real_user_id']
    assert os.geteuid() == user_facts['effective_user_id']

# Generated at 2022-06-23 01:51:38.285199
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    results = UserFactCollector().collect()

    assert type(results['user_id']) == str
    assert type(results['user_uid']) == int
    assert type(results['user_gid']) == int
    assert type(results['user_gecos']) == str
    assert type(results['user_dir']) == str
    assert type(results['user_shell']) == str
    assert type(results['real_user_id']) == int
    assert type(results['effective_user_id']) == int

# Generated at 2022-06-23 01:51:48.657372
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    test_UserFactCollector = UserFactCollector()
    user_facts = test_UserFactCollector.collect()
    assert 'user_id' in user_facts
    assert 'user_uid' in user_facts
    assert 'user_gid' in user_facts
    assert 'user_gecos' in user_facts
    assert 'user_dir' in user_facts
    assert 'user_shell' in user_facts
    assert 'real_user_id' in user_facts
    assert 'effective_user_id' in user_facts
    assert 'real_group_id' in user_facts
    assert 'effective_group_id' in user_facts
    assert isinstance(user_facts['user_id'], str)
    assert isinstance(user_facts['user_uid'], int)

# Generated at 2022-06-23 01:51:54.009791
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    tf = UserFactCollector()
    assert tf.name == 'user'
    assert tf._fact_ids == set(['user_id', 'user_uid', 'user_gid', 'user_gecos', 'user_dir', 'user_shell', 'real_user_id', 'effective_user_id', 'effective_group_ids'])

# Generated at 2022-06-23 01:51:56.510749
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collector = UserFactCollector()
    result = collector.collect()
    assert(result['effective_user_id'] == os.geteuid())

# Generated at 2022-06-23 01:51:58.885925
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    u = UserFactCollector()
    assert u.collect()

# Generated at 2022-06-23 01:52:00.285324
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
  userFactCollector = UserFactCollector()


# Generated at 2022-06-23 01:52:06.248423
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    collector = UserFactCollector()
    assert collector.name == 'user'
    assert collector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                       'user_gecos', 'user_dir', 'user_shell',
                                       'real_user_id', 'effective_user_id',
                                       'effective_group_ids'])


# Generated at 2022-06-23 01:52:09.690489
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    fact_collector = UserFactCollector()
    assert fact_collector
    assert fact_collector.name == 'user'

# Generated at 2022-06-23 01:52:16.837522
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts_collector = UserFactCollector()
    user_facts = user_facts_collector.collect()

    assert isinstance(user_facts, dict)
    assert 'user_id' in user_facts
    assert 'user_uid' in user_facts
    assert 'user_gid' in user_facts
    assert 'user_gecos' in user_facts
    assert 'user_dir' in user_facts
    assert 'user_shell' in user_facts
    assert 'real_user_id' in user_facts
    assert 'effective_user_id' in user_facts
    assert 'real_group_id' in user_facts
    assert 'effective_group_id' in user_facts

# Generated at 2022-06-23 01:52:24.034198
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    c = UserFactCollector()
    assert 'user_id' in c.collect()
    assert 'user_uid' in c.collect()
    assert 'user_gid' in c.collect()
    assert 'user_gecos' in c.collect()
    assert 'user_dir' in c.collect()
    assert 'user_shell' in c.collect()
    assert 'real_user_id' in c.collect()
    assert 'effective_user_id' in c.collect()
    assert 'effective_group_ids' in c.collect()

# Generated at 2022-06-23 01:52:26.555531
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_collector = UserFactCollector()
    user_facts = user_collector.collect()

    assert isinstance(user_facts, dict)

# Generated at 2022-06-23 01:52:31.843356
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    u = UserFactCollector()
    assert u.name == 'user'
    assert u._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                               'user_gecos', 'user_dir', 'user_shell',
                               'real_user_id', 'effective_user_id',
                               'effective_group_ids'])

# Generated at 2022-06-23 01:52:33.991946
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    collector = UserFactCollector()

    # confirm that we have all the methods that we expect
    assert(hasattr(collector, 'collect'))

# Generated at 2022-06-23 01:52:37.909024
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts_collector = UserFactCollector()
    facts = user_facts_collector.collect()
    user_id = getpass.getuser()
    assert facts['user_id'] == user_id


# Generated at 2022-06-23 01:52:43.016577
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector().collect()
    assert isinstance(user_facts, dict)
    for key in ('user_id', 'user_uid', 'user_gid',
                'user_gecos', 'user_dir', 'user_shell',
                'real_user_id', 'effective_user_id',
                'real_group_id', 'effective_group_id'):
        assert key in user_facts

# Generated at 2022-06-23 01:52:49.440083
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact = UserFactCollector()
    assert set(user_fact._fact_ids) == set(['user_id', 'user_uid', 'user_gid',
                                            'user_gecos', 'user_dir', 'user_shell',
                                            'real_user_id', 'effective_user_id',
                                            'effective_group_ids'])

# Generated at 2022-06-23 01:52:59.580195
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    '''Unit test for method collect of class UserFactCollector.
    '''

    import mock
    import unittest

    import ansible.module_utils.facts.collectors.user

    class MockPwd:
        def __init__(self, **kwargs):
            self.pw_uid = kwargs['pw_uid']
            self.pw_gid = kwargs['pw_gid']
            self.pw_gecos = kwargs['pw_gecos']
            self.pw_dir = kwargs['pw_dir']
            self.pw_shell = kwargs['pw_shell']

    class MockGetuid:
        def __init__(self):
            self.uid = 1234

        def getuid(self):
            return self.uid

   

# Generated at 2022-06-23 01:53:06.985490
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    collector = UserFactCollector()
    assert collector.name == 'user'
    assert 'user_id' in collector._fact_ids
    assert 'user_uid' in collector._fact_ids
    assert 'user_gid' in collector._fact_ids
    assert 'user_gecos' in collector._fact_ids
    assert 'user_dir' in collector._fact_ids
    assert 'user_shell' in collector._fact_ids
    assert 'real_user_id' in collector._fact_ids
    assert 'effective_user_id' in collector._fact_ids
    assert 'effective_group_ids' in collector._fact_ids

# Generated at 2022-06-23 01:53:14.900204
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    test = UserFactCollector()
    result = test.collect()
    assert result == {
        'user_id': 'ansible',
        'user_uid': 1000,
        'user_gid': 1000,
        'user_gecos': '',
        'user_dir': '/home/ansible',
        'user_shell': '/bin/sh',
        'real_user_id': 1000,
        'effective_user_id': 1000,
        'real_group_id': 1000,
        'effective_group_id': 1000,
    }

# Generated at 2022-06-23 01:53:24.868233
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    result = UserFactCollector.collect()
    assert result['user_id'] == getpass.getuser(), "User Fact Collector - collect() returned {0}".format(result)
    assert result['user_uid'] == pwd.getpwnam(getpass.getuser()).pw_uid, "User Fact Collector - collect() returned {0}".format(result)
    assert result['user_gid'] == pwd.getpwnam(getpass.getuser()).pw_gid, "User Fact Collector - collect() returned {0}".format(result)
    assert result['user_gecos'] == pwd.getpwnam(getpass.getuser()).pw_gecos, "User Fact Collector - collect() returned {0}".format(result)
    assert result['user_dir'] == pwd.getp

# Generated at 2022-06-23 01:53:35.851018
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    dummy_module = None
    dummy_collected_facts = None
    ufc = UserFactCollector()
    expected_result = {'user_id': getpass.getuser(),
                       'user_uid': os.getuid(),
                       'user_gid': os.getgid(),
                       'user_dir': pwd.getpwuid(os.getuid())[5],
                       'user_shell': pwd.getpwuid(os.getuid())[6],
                       'user_gecos': pwd.getpwuid(os.getuid())[4],
                       'effective_user_id': os.geteuid(),
                       'effective_group_ids': os.getgroups(),
                       'real_user_id': os.getuid(),
                       'real_group_id': os.getgid()}

# Generated at 2022-06-23 01:53:42.541127
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    assert(
        UserFactCollector().collect() == {
        'effective_group_ids': [1000],
        'effective_user_id': 1000,
        'real_group_id': 1000,
        'real_user_id': 1000,
        'user_dir': '/home/jenkins',
        'user_gecos': 'Jenkins,,,',
        'user_gid': 1000,
        'user_id': 'jenkins',
        'user_shell': '/bin/bash',
        'user_uid': 1000
    })

# Generated at 2022-06-23 01:53:45.123003
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    test_object = UserFactCollector()
    ret = test_object.collect()
    assert isinstance(ret,dict)

# Generated at 2022-06-23 01:53:54.080077
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import os
    import pwd
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import collector

    def getpwnam(name):
        return pwd.struct_passwd((
            'test_user_id',
            'x',
            'test_user_id',
            'test_user_gid',
            'test_user_gecos',
            'test_user_dir',
            'test_user_shell')
        )


# Generated at 2022-06-23 01:54:02.617255
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()
    assert 'user_id' in user_facts, "user_id fact not in facts"
    assert 'user_uid' in user_facts, "user_uid fact not in facts"
    assert 'user_gid' in user_facts, "user_gid fact not in facts"
    assert 'user_gecos' in user_facts, "user_gecos fact not in facts"
    assert 'user_dir' in user_facts, "user_dir fact not in facts"
    assert 'user_shell' in user_facts, "user_shell fact not in facts"
    assert 'real_user_id' in user_facts, "real_user_id fact not in facts"

# Generated at 2022-06-23 01:54:04.830661
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector().collect()
    assert user_facts['user_id'] == getpass.getuser()

# Generated at 2022-06-23 01:54:09.806838
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    c = UserFactCollector()
    assert c.name == 'user'
    assert c._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                               'user_gecos', 'user_dir', 'user_shell',
                               'real_user_id', 'effective_user_id',
                               'real_group_id', 'effective_group_id'])

# Generated at 2022-06-23 01:54:19.924651
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    module = None
    collected_facts = {}

    userfactcollector = UserFactCollector(module=module, collected_facts=collected_facts)
    user_facts = userfactcollector.collect()

    assert 'user_id' in user_facts
    assert 'user_uid' in user_facts
    assert 'user_gid' in user_facts
    assert 'user_gecos' in user_facts
    assert 'user_dir' in user_facts
    assert 'user_shell' in user_facts
    assert 'real_user_id' in user_facts
    assert 'effective_user_id' in user_facts
    assert 'real_group_id' in user_facts
    assert 'effective_group_id' in user_facts

# Generated at 2022-06-23 01:54:27.406495
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collector = UserFactCollector()
    collection = collector.collect()

    # Assert user_id and real_user_id are equal
    assert collection['user_id'] == collection['real_user_id']
    assert collection['user_id'] == collection['effective_user_id']

    # Assert user_gid and real_group_id are equal
    assert collection['user_gid'] == collection['real_group_id']
    assert collection['user_gid'] == collection['effective_group_id']

    # Assert user_uid is an int
    assert isinstance(collection['user_uid'], int)
    assert isinstance(collection['user_gid'], int)
    assert isinstance(collection['real_user_id'], int)
    assert isinstance(collection['effective_user_id'], int)

# Generated at 2022-06-23 01:54:36.928216
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = {}
    ufc = UserFactCollector()
    collected_facts = ufc.collect(collected_facts=user_facts)
    # Check collected facts
    assert collected_facts['user_id'] == getpass.getuser()
    assert collected_facts['real_user_id'] == os.getuid()
    assert collected_facts['effective_user_id'] == os.geteuid()
    assert collected_facts['real_group_id'] == os.getgid()
    assert collected_facts['effective_group_id'] == os.getgid()
    try:
        pwent = pwd.getpwnam(getpass.getuser())
    except KeyError:
        pwent = pwd.getpwuid(os.getuid())
    assert collected_facts['user_uid'] == p

# Generated at 2022-06-23 01:54:42.955899
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user = UserFactCollector()
    assert user._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                  'user_gecos', 'user_dir', 'user_shell',
                                  'real_user_id', 'effective_user_id',
                                  'effective_group_ids']), user._fact_ids

# Generated at 2022-06-23 01:54:45.135345
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    result = user_fact_collector.collect()
    print(result)

# Run the unit test
test_UserFactCollector_collect()

# Generated at 2022-06-23 01:54:50.034990
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    test_UserFactCollector = UserFactCollector()
    # True test
    user_list = ['user_id','user_uid','user_gid','user_gecos','user_dir','user_shell','real_user_id','effective_user_id','effective_group_ids']
    assert user_list == test_UserFactCollector.collect().keys()

# Generated at 2022-06-23 01:55:01.040792
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    output = dict(user_id="test", user_uid=1000, user_gid=1000,
                  user_gecos="/bin/test", user_dir="/test",
                  user_shell="/test/test", real_user_id=1000,
                  effective_user_id=1000, real_group_id=1000,
                  effective_group_id=1000)

    def test_getpass(get_user=None):
        return "test"

    def test_pwd_getpwnam(name=None):
        assert name == "test"
        return pwd.struct_passwd((name, "x", 1000, 1000, "test", "/test", "/test/test"))

    def test_os_getuid():
        return 1000

    def test_os_geteuid():
        return 1000


# Generated at 2022-06-23 01:55:03.833166
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    member = UserFactCollector

    assert hasattr(member, 'collect')
    assert callable(member.collect)


# Generated at 2022-06-23 01:55:11.253737
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    """Test class constructor."""
    assert UserFactCollector().name == "user"
    assert UserFactCollector()._fact_ids == set(['user_id', 'user_uid',
                                                 'user_gid', 'user_gecos',
                                                 'user_dir', 'user_shell',
                                                 'real_user_id',
                                                 'effective_user_id',
                                                 'effective_group_ids'])



# Generated at 2022-06-23 01:55:18.119041
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    collector = UserFactCollector()

    assert collector.name == 'user'
    assert collector._fact_ids == {'user_id', 'user_uid', 'user_gid',
                                   'user_gecos', 'user_dir', 'user_shell',
                                   'real_user_id', 'effective_user_id',
                                   'real_group_id', 'effective_group_id'}

# Generated at 2022-06-23 01:55:24.626542
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    assert UserFactCollector.name == 'user'
    assert UserFactCollector._fact_ids == {'user_id', 'user_uid', 'user_gid',
                                           'user_gecos', 'user_dir', 'user_shell',
                                           'real_user_id', 'effective_user_id',
                                           'effective_group_ids'}
    assert UserFactCollector.collect.__name__ == 'collect'

# Generated at 2022-06-23 01:55:34.937435
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import os
    import sys

    from ansible.module_utils.facts import collector

    user_fact_collector = collector.get_collector('user')

    # Gather facts
    facts = user_fact_collector.collect()

    # Test facts
    assert facts['user_id'] == os.getlogin()
    assert facts['user_uid'] == os.getuid()
    assert facts['user_gid'] == os.getgid()
    assert facts['real_user_id'] == os.getuid()
    assert facts['real_group_id'] == os.getgid()
    assert facts['effective_user_id'] == os.geteuid()
    assert facts['effective_group_id'] == os.getegid()

# Generated at 2022-06-23 01:55:41.386835
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    facts = ufc.collect()

    expected_keys = set(['user_id', 'user_uid', 'user_gid',
                         'user_gecos', 'user_dir', 'user_shell',
                         'real_user_id', 'effective_user_id',
                         'real_group_id', 'effective_group_id'])

    assert(expected_keys == set(facts.keys()))

# Generated at 2022-06-23 01:55:45.914197
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    fact_collector = UserFactCollector()
    assert set(fact_collector._fact_ids) == set(['user_id', 'user_uid', 'user_gid',
                                                 'user_gecos', 'user_dir', 'user_shell',
                                                 'real_user_id', 'effective_user_id',
                                                 'effective_group_ids'])


# Generated at 2022-06-23 01:55:56.349728
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    from ansible.module_utils.facts import collector
    from ansible.module_utils._text import to_bytes
    import mock

    # setup test
    collected_facts = {}

# Generated at 2022-06-23 01:56:03.603316
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    userfact = UserFactCollector()
    userfact_result = userfact.collect()
    assert 'user_gecos' in userfact_result.keys()
    assert 'user_id' in userfact_result.keys()
    assert 'user_shell' in userfact_result.keys()
    assert 'user_dir' in userfact_result.keys()
    assert 'user_uid' in userfact_result.keys()
    assert 'user_gid' in userfact_result.keys()

# Generated at 2022-06-23 01:56:08.390365
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    c = UserFactCollector()
    user_facts = c.collect(module=None, collected_facts=None)
    assert isinstance(user_facts, dict)
    # TODO: test to check if the keys are present in the resulting dict
    for key in c._fact_ids:
        assert key in user_facts


# Generated at 2022-06-23 01:56:14.061231
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()

    assert user_facts['real_user_id'] == os.getuid()
    assert user_facts['effective_user_id'] == os.geteuid()
    assert user_facts['effective_group_ids'] == os.getgroups()

# Generated at 2022-06-23 01:56:22.118672
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    fc = UserFactCollector()
    assert fc.name == "user"
    assert fc._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                'user_gecos', 'user_dir', 'user_shell',
                                'real_user_id', 'effective_user_id',
                                'effective_group_ids'])
    #  fc.collect()

# Generated at 2022-06-23 01:56:25.478850
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fact_module = UserFactCollector()
    result = fact_module.collect()

    assert isinstance(result, dict)
    assert result['user_id'] == os.getenv('USER')

# Generated at 2022-06-23 01:56:31.734818
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    # Create object of class UserFactCollector
    fact_subclass = UserFactCollector()
    # Test if object is a subclass of BaseFactCollector
    assert issubclass(UserFactCollector, BaseFactCollector)
    # Test if object is instance of BaseFactCollector
    assert isinstance(fact_subclass, BaseFactCollector)
    # Test if object is instance of UserFactCollector
    assert isinstance(fact_subclass, UserFactCollector)
    # Assert if the value of name variable is 'user'
    assert fact_subclass.name == 'user'
    # Assert if the value of name variable is 'user'
    assert 'user' == fact_subclass.name

# Generated at 2022-06-23 01:56:38.726103
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ufc = UserFactCollector()
    assert isinstance(ufc.name, str)
    for elem in ['user_id', 'user_uid',
                 'user_gid', 'user_gecos',
                 'user_dir', 'user_shell',
                 'real_user_id', 'effective_user_id',
                 'effective_group_ids']:
        assert elem in ufc._fact_ids


# Generated at 2022-06-23 01:56:49.712463
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector()
    user_facts.collect()
    assert isinstance(user_facts.facter, dict) == True
    assert user_facts.facter['user_facts.user_id'] == getpass.getuser()
    assert user_facts.facter['user_facts.user_uid'] == pwd.getpwnam(user_facts.facter['user_facts.user_id']).pw_uid
    assert user_facts.facter['user_facts.user_gid'] == pwd.getpwnam(user_facts.facter['user_facts.user_id']).pw_gid

# Generated at 2022-06-23 01:56:56.313761
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_facts = UserFactCollector()
    assert user_facts.name == 'user'
    assert user_facts._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                        'user_gecos', 'user_dir', 'user_shell',
                                        'real_user_id', 'effective_user_id',
                                        'effective_group_ids'])


# Generated at 2022-06-23 01:56:58.870315
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector().collect()
    assert isinstance(user_facts, dict)
    assert 'user_id' in user_facts



# Generated at 2022-06-23 01:57:05.357566
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_facts = UserFactCollector()
    assert user_facts.name == 'user'
    assert user_facts._fact_ids == {'user_id', 'user_uid', 'user_gid',
                                    'user_gecos', 'user_dir', 'user_shell',
                                    'real_user_id', 'effective_user_id',
                                    'effective_group_ids'}

# Generated at 2022-06-23 01:57:11.443091
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    collector = UserFactCollector()
    # test methods
    assert collector.name == 'user'
    assert collector._fact_ids == {'effective_group_ids', 'effective_group_id', 'effective_user_id', 'real_user_id', 'user_shell', 'user_gid', 'user_uid', 'user_gecos', 'user_id', 'real_group_id', 'user_dir'}

# Generated at 2022-06-23 01:57:23.429791
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fact = UserFactCollector()
    user_facts = fact.collect()
    assert user_facts['user_id'] == getpass.getuser()
    assert isinstance(user_facts['user_uid'], int)
    assert isinstance(user_facts['user_gid'], int)
    assert isinstance(user_facts['user_gecos'], str)
    assert isinstance(user_facts['user_dir'], str)
    assert isinstance(user_facts['user_shell'], str)
    assert isinstance(user_facts['real_user_id'], int)
    assert isinstance(user_facts['effective_user_id'], int)
    assert isinstance(user_facts['real_group_id'], int)
    assert isinstance(user_facts['effective_group_id'], int)

# Generated at 2022-06-23 01:57:29.244007
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    result = UserFactCollector().collect(collected_facts={})
    assert isinstance(result, dict)
    assert 'user_id' in result
    assert 'user_uid' in result
    assert 'user_gid' in result
    assert 'user_gecos' in result
    assert 'user_dir' in result
    assert 'user_shell' in result
    assert 'real_user_id' in result
    assert 'effective_user_id' in result
    assert 'effective_group_ids' in result

# Generated at 2022-06-23 01:57:39.856979
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    collector = ansible_collector.get_collector('UserFactCollector')

# Generated at 2022-06-23 01:57:42.891830
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    UserFactCollector()


# Generated at 2022-06-23 01:57:50.338972
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    coll = UserFactCollector()
    assert coll.name == 'user'
    assert 'user_id' in coll.fact_ids
    assert 'user_uid' in coll.fact_ids
    assert 'user_gid' in coll.fact_ids
    assert 'user_gecos' in coll.fact_ids
    assert 'user_dir' in coll.fact_ids
    assert 'user_shell' in coll.fact_ids
    assert 'real_user_id' in coll.fact_ids
    assert 'effective_user_id' in coll.fact_ids
    assert 'effective_group_ids' in coll.fact_ids


# Generated at 2022-06-23 01:57:52.999535
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    u=UserFactCollector()
    assert u.name == 'user'
    assert 'user_id' in u._fact_ids


# Generated at 2022-06-23 01:57:55.800449
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user = UserFactCollector()
    results = user.collect()

    assert type(results) is dict
    assert results['effective_user_id'] != 0


# Generated at 2022-06-23 01:58:06.400097
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    uid = os.getuid()
    gid = os.getgid()

    ufc = UserFactCollector()
    assert ufc.name == 'user'

    # check user_id
    user_id = ufc.collect()['user_id']
    assert user_id == os.getlogin()

    # check user_uid
    user_uid = ufc.collect()['user_uid']
    assert user_uid == uid

    # check user_gid
    user_gid = ufc.collect()['user_gid']
    assert user_gid == gid

    # check user_gecos
    user_gecos = ufc.collect()['user_gecos']
    assert user_gecos == pwd.getpwuid(uid).pw_gecos

    # check user_

# Generated at 2022-06-23 01:58:07.237230
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    pass

# Generated at 2022-06-23 01:58:16.904407
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    """ Unit test for method collect of class UserFactCollector """

    user_facts = UserFactCollector()

    collected_facts = {}
    user_facts.collect(collected_facts=collected_facts)

    assert collected_facts['user_id'] == getpass.getuser()
    assert isinstance(collected_facts['user_id'], str)
    assert collected_facts['user_uid'] == os.getuid()
    assert isinstance(collected_facts['user_uid'], int)
    assert collected_facts['user_gid'] == os.getgid()
    assert isinstance(collected_facts['user_gid'], int)
    assert collected_facts['user_gecos'] != None
    assert isinstance(collected_facts['user_gecos'], str)

# Generated at 2022-06-23 01:58:23.178239
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ufc = UserFactCollector()
    assert ufc.name == 'user'
    assert ufc._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                 'user_gecos', 'user_dir', 'user_shell',
                                 'real_user_id', 'effective_user_id',
                                 'real_group_id', 'effective_group_id'])
    assert not ufc.plugin_specific_opts

# Generated at 2022-06-23 01:58:25.349961
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    _ = UserFactCollector(None)

# Generated at 2022-06-23 01:58:33.294254
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # set up
    test_class = UserFactCollector()
    collected_facts = {}

    # execute
    user_facts = test_class.collect(collected_facts=collected_facts)

    # verify
    assert len(user_facts) == 6
    assert 'user_id' in user_facts
    assert 'user_uid' in user_facts
    assert 'user_gid' in user_facts
    assert 'user_gecos' in user_facts
    assert 'user_dir' in user_facts
    assert 'user_shell' in user_facts

# Generated at 2022-06-23 01:58:36.445982
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    obj = UserFactCollector()
    obj.collect()

# Generated at 2022-06-23 01:58:37.562510
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    UserFactCollector.collect()

# Generated at 2022-06-23 01:58:45.378344
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fact_collector = UserFactCollector()
    fact_result = fact_collector.collect()

    assert fact_result['user_id'] is not None
    assert fact_result['user_uid'] is not None
    assert fact_result['user_gid'] is not None
    assert fact_result['user_gecos'] is not None
    assert fact_result['user_dir'] is not None
    assert fact_result['user_shell'] is not None
    assert fact_result['real_user_id'] is not None
    assert fact_result['effective_user_id'] is not None
    assert fact_result['real_group_id'] is not None
    assert fact_result['effective_group_id'] is not None

# Generated at 2022-06-23 01:58:55.222138
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_collector = UserFactCollector()
    assert user_collector is not None
    assert user_collector.name == 'user'
    assert user_collector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                            'user_gecos', 'user_dir', 'user_shell',
                                            'real_user_id', 'effective_user_id',
                                            'effective_group_ids'])
    # Try to convert class UserFactCollector instance to a string
    assert str(user_collector) == '<UserFactCollector()>'

# Generated at 2022-06-23 01:59:02.630881
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    userFactCollector = UserFactCollector()
    assert userFactCollector is not None
    assert userFactCollector.name == 'user'


# Generated at 2022-06-23 01:59:07.817165
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()
    assert user_facts is not None
    assert user_facts['user_id'] == 'root'
    assert user_facts['user_uid'] == 0
    assert user_facts['user_gid'] == 0
    assert user_facts['user_gecos'] == 'root'

# Generated at 2022-06-23 01:59:15.239573
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Testing with default value
    x = UserFactCollector()
    result = x.collect()
    assert result == {'user_id': 'vagrant', 'user_uid': 1000, 'user_gid': 1000, 'user_gecos': ',,,', 'user_dir': '/home/vagrant', 'user_shell': '/bin/bash', 'real_user_id': 1000, 'effective_user_id': 1000, 'real_group_id': 1000, 'effective_group_id': 1000}

# Generated at 2022-06-23 01:59:20.909770
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    assert UserFactCollector.name == 'user'
    assert UserFactCollector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                     'user_gecos', 'user_dir', 'user_shell',
                     'real_user_id', 'effective_user_id',
                     'effective_group_ids'])


# Generated at 2022-06-23 01:59:22.731490
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    obj = UserFactCollector()
    assert obj.name == 'user'

# Generated at 2022-06-23 01:59:29.570691
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_id = "ansible"
    user_uid = "1000"
    user_gid = "1000"
    user_gecos = "unit test"
    user_dir = "/home/unit/test"
    user_shell = "/bin/bash"
    real_user_id = "1000"
    effective_user_id = "1000"
    real_group_id = "1000"
    effective_group_id = "1000"

    def run_collect(module=None, collected_facts=None):
        uf = UserFactCollector()
        return uf.collect(module, collected_facts)

    m_getuid = MagicMock(return_value=real_user_id)
    m_geteuid = MagicMock(return_value=effective_user_id)

# Generated at 2022-06-23 01:59:38.745854
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collector = UserFactCollector()
    facts = collector.collect()
    assert 'user_id' in facts
    assert 'user_uid' in facts
    assert 'user_gid' in facts
    assert 'user_gecos' in facts
    assert 'user_dir' in facts
    assert 'user_shell' in facts
    assert 'real_user_id' in facts
    assert 'effective_user_id' in facts
    assert 'real_group_id' in facts
    assert 'effective_group_id' in facts

# Generated at 2022-06-23 01:59:44.701501
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ufc = UserFactCollector()
    assert isinstance(ufc, UserFactCollector)
    assert ufc.name == 'user'
    assert ufc._fact_ids == set(['user_id','user_uid','user_gid','user_gecos','user_dir','user_shell',
                                 'real_user_id','effective_user_id','effective_group_ids'])


# Generated at 2022-06-23 01:59:51.886526
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():

    # test object creation
    u = UserFactCollector()

    # test 'name' attribute
    assert u.name == 'user'

    # test '_fact_ids' attribute
    assert u._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                               'user_gecos', 'user_dir', 'user_shell',
                               'real_user_id', 'effective_user_id',
                               'effective_group_ids'])


# Generated at 2022-06-23 02:00:02.660917
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    '''
    UserFactCollector - class method collect
    '''

    # Create an instance of UserFactCollector
    ufc = UserFactCollector()

    # Call method collect
    user_facts = ufc.collect()

    # Assert that default return is non-empty dictionary

# Generated at 2022-06-23 02:00:07.504666
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    x = UserFactCollector()
    assert x.name == "user"
    assert x._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                               'user_gecos', 'user_dir', 'user_shell',
                               'real_user_id', 'effective_user_id',
                               'effective_group_ids'])

# Generated at 2022-06-23 02:00:08.318114
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    pass

# Generated at 2022-06-23 02:00:10.637411
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_collector = UserFactCollector()
    user_collector.collect()
    assert len(user_collector._fact_ids) == 8

# Generated at 2022-06-23 02:00:12.667174
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    f=UserFactCollector()
    assert f.name == 'user'

# Unit test to check ids of UserFactCollector

# Generated at 2022-06-23 02:00:20.910904
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    assert UserFactCollector.name == 'user'
    assert UserFactCollector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                               'user_gecos', 'user_dir', 'user_shell',
                                               'real_user_id', 'effective_user_id',
                                               'effective_group_ids'])

    assert isinstance(UserFactCollector(), UserFactCollector)
