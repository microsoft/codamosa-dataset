

# Generated at 2022-06-23 01:50:19.870787
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    assert UserFactCollector.name == 'user'
    assert UserFactCollector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                              'user_gecos', 'user_dir', 'user_shell',
                                              'real_user_id', 'effective_user_id',
                                              'effective_group_ids'])

# Generated at 2022-06-23 01:50:28.317704
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    import os
    import pwd

    import ansible.module_utils.facts.collectors.user as user_collector
    import ansible.module_utils.facts.system.user as user_system

    test_user = "ansible_test_user"
    test_dir = "/tmp"
    test_shell = "/bin/sh"

    # Create test user
    if os.geteuid() == 0:
        os.system("groupadd -f {0}".format(test_user))
        os.system("useradd -g {0} -d {1} -m -s {2} {0}".format(test_user,
                                                               test_dir,
                                                               test_shell))

    # Test collect
    user_facts_collector = user_collector.UserFactCollector()
   

# Generated at 2022-06-23 01:50:32.912466
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    userObject = UserFactCollector()
    assert userObject
    assert userObject.name == 'user'
    assert userObject._fact_ids == set(['user_id', 'user_uid', 'user_gid', 'user_gecos', 'user_dir', 'user_shell', 'real_user_id', 'effective_user_id', 'effective_group_ids'])

# Generated at 2022-06-23 01:50:42.422133
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector(None)
    facts = ufc.collect()
    print(facts)
    assert facts['effective_user_id'] == os.geteuid()
    assert facts['user_id'] == getpass.getuser()
    assert facts['user_gecos'] == pwd.getpwuid(os.getuid())[4]


# Generated at 2022-06-23 01:50:49.250675
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()
    assert 'user_id' in user_facts
    assert 'user_uid' in user_facts
    assert 'user_gid' in user_facts
    assert 'user_gecos' in user_facts
    assert 'user_dir' in user_facts
    assert 'user_shell' in user_facts
    assert 'real_user_id' in user_facts
    assert 'effective_user_id' in user_facts
    assert 'effective_group_ids' in user_facts

# Generated at 2022-06-23 01:50:50.897680
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    x = UserFactCollector()
    assert x


# Generated at 2022-06-23 01:50:54.475785
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert user_fact_collector is not None
    assert user_fact_collector.name == 'user'
    assert user_fact_collector._fact_ids is not None

# Generated at 2022-06-23 01:50:59.817615
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    userfc = UserFactCollector()
    assert userfc.name == 'user'
    assert userfc._fact_ids == set(['user_id', 'user_uid', 'user_gid', 'user_gecos',
                                    'user_dir', 'user_shell', 'real_user_id',
                                    'effective_user_id', 'real_group_id',
                                    'effective_group_id'])


# Generated at 2022-06-23 01:51:01.206859
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    assert ufc.collect().keys() == ufc._fact_ids

# Generated at 2022-06-23 01:51:11.869568
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()
    assert isinstance(user_facts, dict)
    assert 'user_id' in user_facts
    assert isinstance(user_facts['user_id'], basestring)
    assert 'user_uid' in user_facts
    assert isinstance(user_facts['user_uid'], int)
    assert 'user_gid' in user_facts
    assert isinstance(user_facts['user_gid'], int)
    assert 'user_gecos' in user_facts
    assert isinstance(user_facts['user_gecos'], basestring)
    assert 'user_dir' in user_facts
    assert isinstance(user_facts['user_dir'], basestring)

# Generated at 2022-06-23 01:51:13.466346
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    c = UserFactCollector()
    assert isinstance(c, UserFactCollector)

# Generated at 2022-06-23 01:51:21.422830
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collector = UserFactCollector(None)
    user_facts = collector.collect()
    assert 'user_id' in user_facts
    assert 'user_uid' in user_facts
    assert 'user_gid' in user_facts
    assert 'user_gecos' in user_facts
    assert 'user_dir' in user_facts
    assert 'user_shell' in user_facts
    assert 'real_user_id' in user_facts
    assert 'effective_user_id' in user_facts
    assert 'real_group_id' in user_facts
    assert 'effective_group_id' in user_facts

# Generated at 2022-06-23 01:51:22.807930
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_facts = UserFactCollector()
    assert user_facts.name == 'user'

# Generated at 2022-06-23 01:51:28.701755
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():

    c = UserFactCollector()
    assert c.name == 'user'
    assert c._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                               'user_gecos', 'user_dir', 'user_shell',
                               'real_user_id', 'effective_user_id',
                               'effective_group_ids'])


# Generated at 2022-06-23 01:51:34.435938
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    obj = UserFactCollector()
    assert obj.name == 'user'
    assert obj._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                 'user_gecos', 'user_dir', 'user_shell',
                                 'real_user_id', 'effective_user_id',
                                 'effective_group_ids'])

# Generated at 2022-06-23 01:51:42.402022
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import pwd
    user_id = pwd.getpwuid(os.getuid()).pw_name
    user_gecos = pwd.getpwuid(os.getuid()).pw_gecos
    user_dir = pwd.getpwuid(os.getuid()).pw_dir
    user_shell = pwd.getpwuid(os.getuid()).pw_shell

    collected_facts = UserFactCollector.collect()
    assert collected_facts['user_id'] == user_id
    assert collected_facts['user_gecos'] == user_gecos
    assert collected_facts['user_dir'] == user_dir
    assert collected_facts['user_shell'] == user_shell

# Generated at 2022-06-23 01:51:51.864516
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collector = UserFactCollector()
    facts = collector.collect()
    assert facts['user_id'] ==  getpass.getuser()
    assert facts['user_uid'] == pwd.getpwnam(facts['user_id']).pw_uid
    assert facts['user_gid'] == pwd.getpwnam(facts['user_id']).pw_gid
    assert facts['user_gecos'] == pwd.getpwnam(facts['user_id']).pw_gecos
    assert facts['user_dir'] == pwd.getpwnam(facts['user_id']).pw_dir
    assert facts['user_shell'] == pwd.getpwnam(facts['user_id']).pw_shell
    assert facts['real_user_id'] == os.getuid()

# Generated at 2022-06-23 01:52:01.391638
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = {}
    try:
        import pwd
        user_facts = pwd.getpwnam(getpass.getuser())
    except KeyError:
        user_facts = pwd.getpwuid(os.getuid())

    ufc = UserFactCollector()
    user_facts_collected = ufc.collect()

    assert user_facts_collected['user_id'] == getpass.getuser()
    assert user_facts_collected['user_uid'] == user_facts.pw_uid
    assert user_facts_collected['user_gid'] == user_facts.pw_gid
    assert user_facts_collected['user_gecos'] == user_facts.pw_gecos
    assert user_facts_collected['user_dir'] == user_facts.pw

# Generated at 2022-06-23 01:52:07.279623
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    # Test with non-default arguments
    c = UserFactCollector()
    assert c.name == 'user'
    assert c._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                               'user_gecos', 'user_dir', 'user_shell',
                               'real_user_id', 'effective_user_id',
                               'effective_group_ids'])

# Generated at 2022-06-23 01:52:13.489147
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()

    assert(user_fact_collector.name == 'user')
    assert(user_fact_collector._fact_ids == set(['user_id',
           'user_uid', 'user_gid', 'user_gecos', 'user_dir',
           'user_shell', 'real_user_id', 'effective_user_id', 'effective_group_ids',
           'real_group_id']))
    return True


# Generated at 2022-06-23 01:52:14.750646
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    result = UserFactCollector()
    assert result is not None

# Generated at 2022-06-23 01:52:20.803366
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    assert UserFactCollector.name == 'user'
    assert UserFactCollector._fact_ids == {
        'effective_group_ids',
        'effective_user_id',
        'real_group_id',
        'real_user_id',
        'user_dir',
        'user_gecos',
        'user_gid',
        'user_id',
        'user_shell',
        'user_uid'
    }

# Generated at 2022-06-23 01:52:27.987273
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert user_fact_collector.name == 'user'
    assert user_fact_collector._fact_ids == set(['user_id', 'user_uid', 'user_gid', 'user_gecos', 'user_dir', 'user_shell', 'real_user_id', 'effective_user_id', 'effective_group_ids'])


# Generated at 2022-06-23 01:52:29.033423
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    collector = UserFactCollector()


# Generated at 2022-06-23 01:52:30.091153
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    assert UserFactCollector.collect()

# Generated at 2022-06-23 01:52:38.896148
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    facts = ufc.collect()

    assert 'user_id' in facts
    assert isinstance(facts['user_id'], str)

    assert 'user_uid' in facts
    assert isinstance(facts['user_uid'], int)

    assert 'user_gid' in facts
    assert isinstance(facts['user_gid'], int)

    assert 'user_gecos' in facts
    assert isinstance(facts['user_gecos'], str)

    assert 'user_dir' in facts
    assert isinstance(facts['user_dir'], str)

    assert 'user_shell' in facts
    assert isinstance(facts['user_shell'], str)

    assert 'real_user_id' in facts

# Generated at 2022-06-23 01:52:44.860484
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    fact_collector = UserFactCollector()
    assert fact_collector.fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                           'user_gecos', 'user_dir', 'user_shell',
                                           'real_user_id', 'effective_user_id',
                                           'effective_group_ids'])

# Generated at 2022-06-23 01:52:46.467999
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user = UserFactCollector()

    assert user is not None


# Generated at 2022-06-23 01:52:53.611158
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    '''Unit test for constructor of class UserFactCollector'''
    _fact_ids = set(['user_id', 'user_uid', 'user_gid',
                     'user_gecos', 'user_dir', 'user_shell',
                     'real_user_id', 'effective_user_id',
                     'effective_group_ids'])
    obj = UserFactCollector()
    assert obj.name == 'user'
    assert obj._fact_ids == _fact_ids


# Generated at 2022-06-23 01:53:01.687261
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    """
    Unit test of method collect of class UserFactCollector
    """
    # Create UserFactCollector object
    user_fact_collector = UserFactCollector()
    user_fact_collector.collect()

    assert user_fact_collector.name == 'user'
    assert type(user_fact_collector._fact_ids) == set
    assert user_fact_collector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                                 'user_gecos', 'user_dir', 'user_shell',
                                                 'real_user_id', 'effective_user_id',
                                                 'effective_group_ids'])

# Generated at 2022-06-23 01:53:06.868698
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    expected_attr = {
        'name': 'user',
        '_fact_ids': set(['user_id', 'user_uid', 'user_gid',
                          'user_gecos', 'user_dir', 'user_shell',
                          'real_user_id', 'effective_user_id',
                          'effective_group_ids'])
    }

    user_fact_collector = UserFactCollector()

    for key in expected_attr:
        assert user_fact_collector.__dict__[key] == expected_attr[key]


# Generated at 2022-06-23 01:53:10.674916
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fc = UserFactCollector()
    assert user_fc.name == 'user' and user_fc.collect()['user_id'] == getpass.getuser() and len(user_fc._fact_ids) == 9

# Generated at 2022-06-23 01:53:19.541292
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collector = UserFactCollector()
    collected_facts = collector.collect()
    assert collected_facts['user_id'] == getpass.getuser()
    try:
        pwent = pwd.getpwnam(getpass.getuser())
    except KeyError:
        pwent = pwd.getpwuid(os.getuid())
    assert collected_facts['user_uid'] == pwent.pw_uid
    assert collected_facts['user_gid'] == pwent.pw_gid
    assert collected_facts['user_gecos'] == pwent.pw_gecos
    assert collected_facts['user_dir'] == pwent.pw_dir
    assert collected_facts['user_shell'] == pwent.pw_shell
    assert collected_facts['real_user_id'] == os.get

# Generated at 2022-06-23 01:53:21.610582
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    assert ufc.collect() is not None

# Generated at 2022-06-23 01:53:31.033085
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fact_collector_obj = UserFactCollector()
    user_facts = fact_collector_obj.collect()

    assert user_facts['user_id'] == 'root'
    assert user_facts['user_uid'] == 0
    assert user_facts['user_gid'] == 0
    assert user_facts['user_gecos'] == 'root'
    assert user_facts['user_dir'] == '/root'
    assert user_facts['user_shell'] == '/bin/bash'
    assert user_facts['real_user_id'] == 0
    assert user_facts['effective_user_id'] == 0
    assert user_facts['real_group_id'] == 0
    assert user_facts['effective_group_id'] == 0

# Generated at 2022-06-23 01:53:42.261019
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()
    assert(user_facts['user_id'] == getpass.getuser())
    assert(user_facts['user_uid'] == os.getuid())
    assert(user_facts['user_gid'] == os.getgid())
    assert(user_facts['user_gecos'] == pwd.getpwuid(os.getuid()).pw_gecos)
    assert(user_facts['user_dir'] == pwd.getpwuid(os.getuid()).pw_dir)
    assert(user_facts['user_shell'] == pwd.getpwuid(os.getuid()).pw_shell)

# Generated at 2022-06-23 01:53:45.266856
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_collector = UserFactCollector()
    user_facts = user_collector.collect()
    assert isinstance(user_facts, dict)

# Generated at 2022-06-23 01:53:54.241757
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import json
    import os
    import tempfile

    from ansible.module_utils.facts.collector import collect_facts

    # create temporary file
    tmpfile = tempfile.mktemp()
    f = open(tmpfile, 'w')
    f.write('''{
    "ansible_python_version": "2.7.9",
    "ansible_kernel": "Linux",
    "ansible_os_family": "RedHat"
}''')
    f.close()

    # set environment variable ANSIBLE_LOCAL_TEMP
    os.environ['ANSIBLE_LOCAL_TEMP'] = tempfile.mkdtemp()

    # create collected facts
    collected_facts = {
        'ansible_local': {
            'facts_cache': tmpfile
        }
    }

    #

# Generated at 2022-06-23 01:53:57.482365
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    fact_collector = UserFactCollector()

    user_facts = fact_collector.collect()

    # To add checks for other facts collected by this class.
    assert user_facts.get('user_id') is not None

# Generated at 2022-06-23 01:54:04.454382
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    result = UserFactCollector().collect()

    assert result['user_id'] == os.getenv('USER')
    assert result['real_user_id'] == os.getuid()
    assert result['effective_user_id'] == os.geteuid()
    assert result['real_group_id'] == os.getgid()
    assert result['effective_group_id'] == os.getegid()

# Generated at 2022-06-23 01:54:13.490234
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    f = UserFactCollector()

    """
    Case 1: user_id, user_uid, user_gid, user_gecos, user_dir, user_shell, 
            real_user_id, real_group_id, effective_user_id, effective_group_id
            are collected successfully.
    """

    # Execute collect method
    ret = f.collect()

    assert ret != None
    assert len(ret) == 10

    """
    Case 2: user_id, user_uid, user_gid, user_gecos, user_dir, user_shell, 
            real_user_id, real_group_id, effective_user_id, effective_group_id
            are collected successfully and written to collected_facts
    """

    # Execute collect method
    collected_facts = {}

# Generated at 2022-06-23 01:54:21.329288
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    c = UserFactCollector()
    data = c.collect()
    assert data == {'user_id': 'root',
                    'user_uid': 0,
                    'user_gid': 0,
                    'user_gecos': 'root',
                    'user_dir': '/root',
                    'user_shell': '/bin/bash',
                    'real_user_id': 0,
                    'effective_user_id': 0,
                    'real_group_id': 0,
                    'effective_group_id': 0}



# Generated at 2022-06-23 01:54:23.369895
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()

    assert user_fact_collector
    assert user_fact_collector.name == 'user'

# Generated at 2022-06-23 01:54:24.578690
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():

    collector = UserFactCollector()
    assert collector.name == 'user'

# Generated at 2022-06-23 01:54:25.746975
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user = UserFactCollector()
    assert isinstance(user._fact_ids, set)

# Generated at 2022-06-23 01:54:31.526822
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()
    assert (user_facts['user_id'] == getpass.getuser())
    assert (user_facts['user_shell'] == pwd.getpwnam(user_facts['user_id']).pw_shell)
    assert (user_facts['real_user_id'] == os.getuid())
    assert (user_facts['effective_user_id'] == os.geteuid())
    assert (user_facts['real_group_id'] == os.getgid())
    assert (user_facts['effective_group_id'] == os.getegid())

# Generated at 2022-06-23 01:54:41.823339
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collector = UserFactCollector()

    def fake_getuser():
        return 'fake_username'

    def fake_getpwnam(username):
        return pwd.struct_passwd((
            'fake_name',
            'fake_passwd',
            1000,
            1000,
            'Fake Name',
            '/home/fake_name',
            '/bin/bash'
        ))

    def fake_getuid():
        return 1000

    def fake_geteuid():
        return 1001

    def fake_getgid():
        return 1000

    def fake_getegid():
        return 1001

    def fake_getgroups():
        return [1000, 1001]

    fake_module = None
    fake_collect_facts = None

    getpass.getuser = fake_getuser
    pwd.get

# Generated at 2022-06-23 01:54:49.821827
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user = UserFactCollector()
    user_facts = user.collect()
    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['user_uid'] == pwd.getpwnam(getpass.getuser()).pw_uid
    assert user_facts['user_gid'] == pwd.getpwnam(getpass.getuser()).pw_gid
    assert user_facts['user_gecos'] == pwd.getpwnam(getpass.getuser()).pw_gecos
    assert user_facts['user_dir'] == pwd.getpwnam(getpass.getuser()).pw_dir
    assert user_facts['user_shell'] == pwd.getpwnam(getpass.getuser()).pw_shell
    assert user

# Generated at 2022-06-23 01:54:50.554488
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    pass

# Generated at 2022-06-23 01:55:01.428224
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    # Prepare Mocks
    pwent = {
        'pw_uid': 1001,
        'pw_gid': 1001,
        'pw_gecos': 'mock_user',
        'pw_dir': '/home/mock_user',
        'pw_shell': '/bin/bash'
    }
    pwd_mock = Mock(pwd)
    pwd_mock.getpwnam.return_value = pwent
    pwd_mock.getpwuid.return_value = pwent
    getpass_mock = Mock(getpass)
    getpass_mock.getuser.return_value = 'mock_username'

    os_mock = Mock(os)
    os_mock.getuid.return_value = 1001
    os_mock

# Generated at 2022-06-23 01:55:06.780822
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    myCollector = UserFactCollector()
    assert myCollector.name == 'user'
    assert myCollector._fact_ids == {'user_id', 'user_uid', 'user_gid',
                                     'user_gecos', 'user_dir', 'user_shell',
                                     'real_user_id', 'effective_user_id',
                                     'effective_group_ids'}


# Generated at 2022-06-23 01:55:17.839695
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import utils
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collectors import user

    # get a validated ansible_facts
    # set to None by default, because we need to create a new instance of the class
    # each time we run this test
    ansible_facts = ansible_collector.AnsibleCollector(None, basic.AnsibleModule(
    ))
    utils.validate_facts(ansible_facts)

    # create a real instance of the class
    ufc = user.UserFactCollector()

    # get the list of fact names that it returns
    fact_ids = ufc.collect()

    # make sure it is not empty

# Generated at 2022-06-23 01:55:24.037736
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    collector = UserFactCollector()
    assert collector.name == 'user'
    assert collector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                       'user_gecos', 'user_dir', 'user_shell',
                                       'real_user_id', 'effective_user_id',
                                       'effective_group_ids'])


# Generated at 2022-06-23 01:55:33.353264
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    from ansible.module_utils.facts.collector.user import UserFactCollector

    user_facts = {'user_id': 'root',
                  'user_uid': 0,
                  'user_gid': 0,
                  'user_gecos': 'root',
                  'user_dir': '/root',
                  'user_shell': '/bin/bash',
                  'real_user_id': 0,
                  'effective_user_id': 0,
                  'real_group_id': 0,
                  'effective_group_id': 0
                  }

    collector = UserFactCollector()

    assert user_facts == collector.collect()

# Generated at 2022-06-23 01:55:41.104499
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    # Create test fixture
    user_collector = UserFactCollector()

    # Exercise SUT
    result = user_collector.collect()

    # Verify results
    assert 'user_id' in result
    assert 'user_uid' in result
    assert 'user_gid' in result
    assert 'user_gecos' in result
    assert 'user_dir' in result
    assert 'user_shell' in result
    assert 'real_user_id' in result
    assert 'effective_user_id' in result
    assert 'effective_group_ids' in result

# Generated at 2022-06-23 01:55:48.016264
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collector = UserFactCollector()
    user_facts = collector.collect()
    assert type(user_facts) == dict
    assert 'user_id' in user_facts
    assert type(user_facts['user_id']) == str
    assert 'user_uid' in user_facts
    assert type(user_facts['user_uid']) == int
    assert 'user_gid' in user_facts
    assert type(user_facts['user_gid']) == int
    assert 'user_gecos' in user_facts
    assert type(user_facts['user_gecos']) == str
    assert 'user_dir' in user_facts
    assert type(user_facts['user_dir']) == str
    assert 'user_shell' in user_facts
    assert type(user_facts['user_shell'])

# Generated at 2022-06-23 01:55:51.646409
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    user_fact_collector.collect()
    assert isinstance(user_fact_collector._fact_ids, set)
    assert isinstance(user_fact_collector.collect(), dict)

# Generated at 2022-06-23 01:55:53.453641
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    """
    test collect method of UserFactCollector
    """
    UserFactCollector().collect()

# Generated at 2022-06-23 01:55:57.408298
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    user_facts = UserFactCollector()
    user_facts1 = UserFactCollector()
    print("returned facts:")
    print(user_facts.collect())
    print(user_facts1.collect())

# Generated at 2022-06-23 01:55:59.086700
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    collector = UserFactCollector()
    assert collector.name == 'user'

# Generated at 2022-06-23 01:56:00.397516
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    fc = UserFactCollector()
    assert fc.name == 'user'

# Generated at 2022-06-23 01:56:04.895887
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    FACTS = UserFactCollector()
    assert FACTS.name == 'user'
    assert FACTS.priority == 100
    assert FACTS._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                   'user_gecos', 'user_dir', 'user_shell',
                                   'real_user_id', 'effective_user_id',
                                   'effective_group_ids'])


# Generated at 2022-06-23 01:56:08.437568
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ufc = UserFactCollector()
    assert ufc
    assert isinstance(ufc, UserFactCollector)
    assert ufc.name == 'user'
    assert ufc.collect()


# Generated at 2022-06-23 01:56:15.593702
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    u = UserFactCollector()
    assert u.name == 'user'
    assert isinstance(u._fact_ids, set)
    assert u._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                               'user_gecos', 'user_dir', 'user_shell',
                               'real_user_id', 'effective_user_id',
                               'effective_group_ids'])

# Generated at 2022-06-23 01:56:25.455329
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    # Create object and Get Results
    UserFactCollector_Instance = UserFactCollector()
    res = UserFactCollector_Instance.collect()

    # Verify Results
    assert res != None
    assert isinstance(res, dict)
    assert 'user_id' in res
    assert isinstance(res['user_id'], str)
    assert res['user_id'] != None
    assert 'user_uid' in res
    assert isinstance(res['user_uid'], int)
    assert res['user_uid'] != None
    assert 'user_gid' in res
    assert isinstance(res['user_gid'], int)
    assert res['user_gid'] != None
    assert 'user_gecos' in res
    assert isinstance(res['user_gecos'], str)

# Generated at 2022-06-23 01:56:32.636379
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_collector = UserFactCollector()
    assert isinstance(user_collector.collect()['user_id'], str)
    assert isinstance(user_collector.collect()['user_uid'], int)
    assert isinstance(user_collector.collect()['user_gid'], int)
    assert isinstance(user_collector.collect()['user_gecos'], str)
    assert isinstance(user_collector.collect()['user_dir'], str)
    assert isinstance(user_collector.collect()['user_shell'], str)
    assert isinstance(user_collector.collect()['real_user_id'], int)
    assert isinstance(user_collector.collect()['effective_user_id'], int)

# Generated at 2022-06-23 01:56:33.953984
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    testobj = UserFactCollector()
    assert testobj.collect()

# Generated at 2022-06-23 01:56:43.185794
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()
    assert(user_facts['user_id'] == getpass.getuser())
    assert(user_facts['user_uid'] == pwd.getpwuid(os.getuid()).pw_uid)
    assert(user_facts['user_gid'] == pwd.getpwuid(os.getuid()).pw_gid)
    assert(user_facts['user_gecos'] == pwd.getpwuid(os.getuid()).pw_gecos)
    assert(user_facts['user_dir'] == pwd.getpwuid(os.getuid()).pw_dir)

# Generated at 2022-06-23 01:56:51.707616
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    user_facts = ufc.collect()

    assert isinstance(user_facts, dict)
    assert isinstance(user_facts['user_id'], str)
    assert isinstance(user_facts['user_uid'], int)
    assert isinstance(user_facts['user_gid'], int)
    assert isinstance(user_facts['user_gecos'], str)
    assert isinstance(user_facts['user_dir'], str)
    assert isinstance(user_facts['user_shell'], str)
    assert isinstance(user_facts['real_user_id'], int)
    assert isinstance(user_facts['effective_user_id'], int)
    assert isinstance(user_facts['real_group_id'], int)

# Generated at 2022-06-23 01:57:02.117279
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()
    assert type(user_facts) is dict
    assert 'user_id' in user_fact_collector._fact_ids
    assert 'user_uid' in user_fact_collector._fact_ids
    assert 'user_gid' in user_fact_collector._fact_ids
    assert 'user_gecos' in user_fact_collector._fact_ids
    assert 'user_dir' in user_fact_collector._fact_ids
    assert 'user_shell' in user_fact_collector._fact_ids
    assert 'real_user_id' in user_fact_collector._fact_ids
    assert 'effective_user_id' in user_fact_collector._fact_ids
   

# Generated at 2022-06-23 01:57:06.063624
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    # Test case:
    # - Default constructor

    ufc = UserFactCollector()
    assert "user" == ufc.name
    assert "_fact_ids" in dir(ufc)  # "_fact_ids" private variable is defined
    assert 6 == len(ufc._fact_ids)



# Generated at 2022-06-23 01:57:09.891865
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fact_collector = UserFactCollector()
    fact_collector.collect()


# Generated at 2022-06-23 01:57:17.940260
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_facts = UserFactCollector().collect()
    assert len(user_facts) == 8
    assert 'user_id' in user_facts
    assert 'user_uid' in user_facts
    assert 'user_gid' in user_facts
    assert 'user_gecos' in user_facts
    assert 'user_dir' in user_facts
    assert 'user_shell' in user_facts
    assert 'real_user_id' in user_facts
    assert 'effective_user_id' in user_facts

# Generated at 2022-06-23 01:57:24.823051
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ufc = UserFactCollector()
    assert ufc.name == 'user'
    assert ufc._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                 'user_gecos', 'user_dir', 'user_shell',
                                 'real_user_id', 'effective_user_id',
                                 'effective_group_ids'])


# Generated at 2022-06-23 01:57:36.662019
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    test_obj = UserFactCollector()
    test_getuser = 'test_user'
    test_getuid = 'test_uid'
    test_getgid = 'test_gid'
    test_getgecos = 'test_gecos'
    test_getdir = 'test_dir'
    test_getshell = 'test_shell'
    setattr(getpass, 'getuser', lambda : test_getuser)
    setattr(pwd, 'getpwnam', lambda x: pwd.struct_passwd(test_getuser,
                                                         test_getuid,
                                                         test_getgid,
                                                         test_getgecos,
                                                         test_getdir,
                                                         test_getshell))

# Generated at 2022-06-23 01:57:42.391631
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector_inst = UserFactCollector()
    assert user_fact_collector_inst.name == 'user'
    assert user_fact_collector_inst._fact_ids == {
        'user_id', 'user_uid', 'user_gid', 'user_gecos', 'user_dir', 'user_shell', 'real_user_id', 'effective_user_id', 'effective_group_ids'}
    assert isinstance(user_fact_collector_inst.collect(), dict)

# Generated at 2022-06-23 01:57:54.359581
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    fake_module = object()
    fake_collected_facts = {'ansible_facts': {}}

    user_facts = UserFactCollector().collect(fake_module, fake_collected_facts)


# Generated at 2022-06-23 01:58:00.992722
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    """It is expected that the UserFactCollector.name == 'user'
    and UserFactCollector._fact_ids == set([
      'user_id', 'user_uid', 'user_gid',
      'user_gecos', 'user_dir', 'user_shell',
      'real_user_id', 'effective_user_id',
      'effective_group_ids'])"""
    user_fact_collector = UserFactCollector()
    assert user_fact_collector.name == 'user'

# Generated at 2022-06-23 01:58:06.262121
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    collector = UserFactCollector()
    assert collector.name == 'user'
    assert collector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                     'user_gecos', 'user_dir', 'user_shell',
                     'real_user_id', 'effective_user_id',
                     'effective_group_ids'])


# Generated at 2022-06-23 01:58:12.740221
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    from ansible.module_utils.facts import collector
    x = collector.UserFactCollector()
    assert x.name == "user"
    assert x._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                     'user_gecos', 'user_dir', 'user_shell',
                     'real_user_id', 'effective_user_id',
                     'real_group_id', 'effective_group_id'])

# Generated at 2022-06-23 01:58:23.675356
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fact = UserFactCollector()
    result = fact.collect()
    assert result['user_id'] == getpass.getuser()
    assert result['user_uid'] == pwd.getpwnam(getpass.getuser()).pw_uid
    assert result['user_gid'] == pwd.getpwnam(getpass.getuser()).pw_gid
    assert result['user_gecos'] == pwd.getpwnam(getpass.getuser()).pw_gecos
    assert result['user_dir'] == pwd.getpwnam(getpass.getuser()).pw_dir
    assert result['user_shell'] == pwd.getpwnam(getpass.getuser()).pw_shell
    assert result['real_user_id'] == os.getuid()


# Generated at 2022-06-23 01:58:30.385559
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ufc = UserFactCollector()
    assert ufc.name == 'user'
    assert ufc._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                     'user_gecos', 'user_dir', 'user_shell',
                     'real_user_id', 'effective_user_id',
                     'effective_group_ids'])


# Generated at 2022-06-23 01:58:35.033232
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ufc = UserFactCollector()
    assert ufc.name == 'user'
    for fact in ['user_id', 'user_uid', 'user_gid',
                 'user_gecos', 'user_dir', 'user_shell',
                 'real_user_id', 'effective_user_id',
                 'effective_group_ids']:
        assert fact in ufc._fact_ids

# Generated at 2022-06-23 01:58:40.699558
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import pwd

    mock_module = type('', (object, ), {})()
    mock_module.params = {}

    # Scenario 1: User info is available through pwd.getpwuid and pwd.getpwnam
    #             functions
    mock_getpwuid = lambda: type('', (object, ), {
        'pw_uid': 1000,
        'pw_gid': 100,
        'pw_gecos': 'gecos',
        'pw_dir': '/tmp',
        'pw_shell': '/bin/bash'
    })()

# Generated at 2022-06-23 01:58:45.378183
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ufc = UserFactCollector()
    assert ufc.name == "user"
    assert ufc._fact_ids == {'user_id', 'user_uid', 'user_gid', 'user_gecos',
                             'user_dir', 'user_shell', 'real_user_id',
                             'effective_user_id', 'effective_group_ids'}


# Generated at 2022-06-23 01:58:54.629663
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    test_helper = TestHelper(UserFactCollector)
    test_helper.test_collect({'user': {'effective_user_id': 1000,
                                       'real_user_id': 1000,
                                       'real_group_id': 1000,
                                       'effective_group_id': 1000,
                                       'user_id': 'test',
                                       'user_uid': 1000,
                                       'user_gid': 1000,
                                       'user_gecos': 'Test User',
                                       'user_dir': '/home/test',
                                       'user_shell': '/bin/bash'}})

# Generated at 2022-06-23 01:58:56.111121
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    test_obj = UserFactCollector()
    result = test_obj.collect()
    assert result

# Generated at 2022-06-23 01:59:02.090259
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    assert UserFactCollector.name == 'user'
    assert UserFactCollector._fact_ids == set(['user_id', 'user_uid',
                                               'user_gid', 'user_gecos',
                                               'user_dir', 'user_shell',
                                               'real_user_id',
                                               'effective_user_id',
                                               'effective_group_ids'])

# Generated at 2022-06-23 01:59:07.221670
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert sorted(user_fact_collector._fact_ids) == sorted(['user_id', 'user_uid', 'user_gid',
                     'user_gecos', 'user_dir', 'user_shell',
                     'real_user_id', 'effective_user_id',
                     'effective_group_ids'])

# Generated at 2022-06-23 01:59:09.082252
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    user_facts = ufc.collect()
    assert set(user_facts) == ufc._fact_ids

# Generated at 2022-06-23 01:59:14.805667
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    """
    Unit test for class UserFactCollector
    """
    from ansible.module_utils.facts.collector import get_collector_instance

    # Test for get_collector_instance
    user_fact_collector = get_collector_instance(UserFactCollector)
    user_facts = user_fact_collector.collect()
    assert user_facts
    assert user_facts['user_id']

# Generated at 2022-06-23 01:59:25.202207
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    results = ufc.collect()
    assert isinstance(results['user_id'], str)
    assert isinstance(results['user_uid'], int)
    assert isinstance(results['user_gid'], int)
    assert isinstance(results['user_gecos'], str)
    assert isinstance(results['user_dir'], str)
    assert isinstance(results['user_shell'], str)
    assert isinstance(results['real_user_id'], int)
    assert isinstance(results['effective_user_id'], int)
    assert isinstance(results['real_group_id'], int)
    assert isinstance(results['effective_group_id'], int)

# Generated at 2022-06-23 01:59:36.323705
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.system.user import UserFactCollector

    # Create an instance of the UserFactCollector class
    ufc = UserFactCollector(collector, ansible_collector)

    # Assert the name
    assert ufc.name == 'user'

    # Assert the fact_ids
    assert ufc._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                 'user_gecos', 'user_dir', 'user_shell',
                                 'real_user_id', 'effective_user_id',
                                 'effective_group_ids'])

# Unit tests for the collect method of class UserFactCollector


# Generated at 2022-06-23 01:59:40.684876
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import sys
    sys.path.append('/home/automation/lib/python2.7/dist-packages')
    from ansible.module_utils.facts import collector

    ufc = UserFactCollector()
    ufc.collect()
    print(ufc)
    
if __name__ == '__main__':
    test_UserFactCollector_collect()

# Generated at 2022-06-23 01:59:41.211936
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    pass

# Generated at 2022-06-23 01:59:46.827010
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_facts = UserFactCollector()
    assert user_facts.name == "user"

    # Check if correct set of facts is returned
    user_facts_result = user_facts.collect()
    assert type(user_facts_result) is dict
    assert set(user_facts_result.keys()) == user_facts._fact_ids

# Generated at 2022-06-23 01:59:55.106978
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert user_fact_collector.name == 'user'
    assert len(user_fact_collector._fact_ids) == 10
    assert 'user_id' in user_fact_collector._fact_ids
    assert 'user_uid' in user_fact_collector._fact_ids
    assert 'user_gid' in user_fact_collector._fact_ids
    assert 'user_gecos' in user_fact_collector._fact_ids
    assert 'user_dir' in user_fact_collector._fact_ids
    assert 'user_shell' in user_fact_collector._fact_ids
    assert 'real_user_id' in user_fact_collector._fact_ids
    assert 'effective_user_id' in user_fact_collect

# Generated at 2022-06-23 02:00:06.863539
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector().collect()
    # expected result for testing

# Generated at 2022-06-23 02:00:12.763823
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    Ufc = UserFactCollector()
    assert Ufc.name == "user"
    assert Ufc._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                 'user_gecos', 'user_dir', 'user_shell',
                                 'real_user_id', 'effective_user_id',
                                 'effective_group_ids'])

# Generated at 2022-06-23 02:00:23.865756
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    import os
    import pwd
    import grp
    import pytest
    from ansible.module_utils.facts.collector import UserFactCollector

    user = UserFactCollector()

    uid = os.getuid()
    gid = os.getgid()

    pwent = pwd.getpwuid(uid)
    grent = grp.getgrgid(gid)

    userid = pwent.pw_name
    uid = pwent.pw_uid
    gid = pwent.pw_gid
    gecos = pwent.pw_gecos
    dir = pwent.pw_dir
    shell = pwent.pw_shell

    real_uid = os.getuid()
    effective_uid = os.geteuid()
    real_g