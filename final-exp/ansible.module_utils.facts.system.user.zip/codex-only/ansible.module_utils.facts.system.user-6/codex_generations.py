

# Generated at 2022-06-23 01:50:19.950753
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    f = UserFactCollector()
    assert f.name == 'user'
    assert len(f._fact_ids) == 9

# Generated at 2022-06-23 01:50:23.899186
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    x = UserFactCollector()
    assert x.name == "user"
    assert x._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                               'user_gecos', 'user_dir', 'user_shell',
                               'real_user_id', 'effective_user_id',
                               'effective_group_ids'])

# Generated at 2022-06-23 01:50:35.317691
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    if os.geteuid() == 0:
        return

    import pwd
    my_uid = os.getuid()
    my_egid = os.getegid()
    my_effective_gids = os.getgroups()
    my_name = pwd.getpwuid(my_uid)[0]
    my_gid = pwd.getpwnam(my_name).pw_gid

    ufc = UserFactCollector()
    user_facts = ufc.collect()

    assert 'user_id' in user_facts
    assert user_facts['user_id'] == my_name

    assert 'user_gecos' in user_facts
    assert user_facts['user_gecos'] == pwd.getpwuid(my_uid).pw_gecos


# Generated at 2022-06-23 01:50:36.863209
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    assert UserFactCollector()


if __name__ == '__main__':
    test_UserFactCollector()

# Generated at 2022-06-23 01:50:38.283862
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user = UserFactCollector()
    user_facts = user.collect()
    assert user_facts is not None

# Generated at 2022-06-23 01:50:42.678448
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    u = UserFactCollector()
    assert u.name == 'user'
    assert set(u._fact_ids) == set(['user_id', 'user_uid', 'user_gid',
                                    'user_gecos', 'user_dir', 'user_shell',
                                    'real_user_id', 'effective_user_id',
                                    'effective_group_ids'])
    assert u.collect()['user_id'] == getpass.getuser()

# Generated at 2022-06-23 01:50:47.156850
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    assert UserFactCollector().name == "user"
    assert UserFactCollector()._fact_ids == set(['user_id', 'user_uid', 'user_gid', 'user_gecos', 'user_dir', 'user_shell', 'real_user_id', 'effective_user_id', 'effective_group_ids'])



# Generated at 2022-06-23 01:50:56.949131
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import platform

    from ansible.module_utils.facts.collector import UserFactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector

    from six import PY3

    # Create an instance of UserFactCollector
    ufc = UserFactCollector()

    # Check that ufc is an instance of UserFactCollector
    assert isinstance(ufc, UserFactCollector)

    # Check that ufc is an instance of BaseFactCollector
    assert isinstance(ufc, BaseFactCollector)

    # Check that ufc._fact_ids is set to the appropriate value

# Generated at 2022-06-23 01:50:58.264615
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    # Test simple instantiation
    UserFactCollector()

# Generated at 2022-06-23 01:51:05.796640
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    def getpwnam(*kwargs):
        pwent = {'pw_name':'testuser', 'pw_uid':1000, 'pw_gid':1001,
                 'pw_gecos': 'testuser,,,', 'pw_dir':'/home/testuser',
                 'pw_shell':'/bin/bash'}
        return pwent

    def getpwuid(*kwargs):
        pwent = {'pw_name':'testuser', 'pw_uid':1000, 'pw_gid':1001,
                 'pw_gecos': 'testuser,,,', 'pw_dir':'/home/testuser',
                 'pw_shell':'/bin/bash'}
        return pwent


# Generated at 2022-06-23 01:51:14.021537
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    user_facts = ufc.collect()
    assert isinstance(user_facts, dict)
    assert user_facts['user_id'] == getpass.getuser()
    try:
        pwent = pwd.getpwnam(getpass.getuser())
    except KeyError:
        pwent = pwd.getpwuid(os.getuid())
    assert user_facts['user_uid'] == pwent.pw_uid
    assert user_facts['user_gid'] == pwent.pw_gid
    assert user_facts['user_gecos'] == pwent.pw_gecos
    assert user_facts['user_dir'] == pwent.pw_dir
    assert user_facts['user_shell'] == pwent.pw_shell

# Generated at 2022-06-23 01:51:19.914205
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():

    user_facts = UserFactCollector()

    assert user_facts is not None
    assert user_facts.name == 'user'
    assert user_facts._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                        'user_gecos', 'user_dir', 'user_shell',
                                        'real_user_id', 'effective_user_id',
                                        'effective_group_ids'])

# Generated at 2022-06-23 01:51:29.607626
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    """
    Test collect method of UserFactCollector
    """
    ff = UserFactCollector()
    facts = ff.collect()
    assert 'user_id' in facts.keys()
    assert 'user_uid' in facts.keys()
    assert 'user_gid' in facts.keys()
    assert 'user_gecos' in facts.keys()
    assert 'user_dir' in facts.keys()
    assert 'user_shell' in facts.keys()
    assert 'real_user_id' in facts.keys()
    assert 'effective_user_id' in facts.keys()
    assert 'real_group_id' in facts.keys()
    assert 'effective_group_id' in facts.keys()
    assert os.getuid() == facts['real_user_id']

# Generated at 2022-06-23 01:51:31.746518
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    collector = UserFactCollector()

    assert collector is not None

# Generated at 2022-06-23 01:51:39.764629
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    obj = UserFactCollector()
    assert obj is not None
    assert obj.name == 'user'
    assert 'user_id' in obj._fact_ids
    assert 'user_uid' in obj._fact_ids
    assert 'user_gid' in obj._fact_ids
    assert 'user_gecos' in obj._fact_ids
    assert 'user_dir' in obj._fact_ids
    assert 'user_shell' in obj._fact_ids
    assert 'real_user_id' in obj._fact_ids
    assert 'effective_user_id' in obj._fact_ids
    assert 'effective_group_ids' in obj._fact_ids

# Generated at 2022-06-23 01:51:46.538225
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert user_fact_collector
    assert user_fact_collector.name == 'user'
    assert user_fact_collector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                                 'user_gecos', 'user_dir', 'user_shell',
                                                 'real_user_id', 'effective_user_id',
                                                 'effective_group_ids'])

# Generated at 2022-06-23 01:51:54.662888
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert user_fact_collector.name == 'user'
    assert user_fact_collector._fact_ids == set(['user_id', 'user_uid', 'user_gid', 'user_gecos', 'user_dir', 'user_shell', 'real_user_id', 'effective_user_id', 'effective_group_ids'])
    assert user_fact_collector._safe_to_cache is True


# Generated at 2022-06-23 01:51:59.362462
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    fact_collection = UserFactCollector()
    assert fact_collection.name == 'user'
    assert fact_collection._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                             'user_gecos', 'user_dir', 'user_shell',
                                             'real_user_id', 'effective_user_id',
                                             'effective_group_ids'])


# Generated at 2022-06-23 01:52:09.752909
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    '''
    Collect user facts, mock os module.
    '''

    # pass
    def mock_get_user():
        return 'admin'
    print(mock_get_user())

    # fail
    def mock_getpwnam(user):
        raise KeyError()
    print(mock_getpwnam(user))

    # pass
    def mock_getuid():
        return 0
    def mock_geteuid():
        return 0
    def mock_getgid():
        return 0

    def mock_getegid():
        return 0
    print(mock_getegid())

    # pass
    def mock_getpwuid(uid):
        pwent = pwd.getpwuid(os.getuid())
        return pwent

# Generated at 2022-06-23 01:52:16.015668
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_facts = UserFactCollector()
    assert user_facts.name == 'user'
    assert user_facts._fact_ids == set(['user_id', 'user_uid', 'user_gid', 'user_gecos', 'user_dir', 'user_shell', 'real_user_id', 'effective_user_id', 'effective_group_ids'])


# Generated at 2022-06-23 01:52:23.493930
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ''' Unit test for the UserFactCollector class. '''
    # Get UserFactCollector object
    collector = UserFactCollector()

    # Check the name and the _fact_ids attribute are correct.
    assert collector.name == 'user'
    assert collector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                       'user_gecos', 'user_dir', 'user_shell',
                                       'real_user_id', 'effective_user_id',
                                       'real_group_id', 'effective_group_id'])

# Generated at 2022-06-23 01:52:34.259276
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    obj = UserFactCollector()

# Generated at 2022-06-23 01:52:34.941560
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    UserFactCollector()

# Generated at 2022-06-23 01:52:41.007140
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    userFactCollector = UserFactCollector()
    assert userFactCollector.name == 'user'
    assert len(userFactCollector._fact_ids) == 9
    assert userFactCollector._fact_ids.issuperset(set(['user_id', 'user_uid', 'user_gid',
                                                       'user_gecos', 'user_dir', 'user_shell',
                                                       'real_user_id', 'effective_user_id',
                                                       'effective_group_ids']))

# Generated at 2022-06-23 01:52:52.185683
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector()
    facts = user_facts.collect()
    assert facts['user_id'] == getpass.getuser()
    assert facts['user_uid'] == os.getuid()
    assert facts['user_gid'] == os.getgid()
    assert facts['user_gecos'] == '(),,,,'
    assert facts['user_dir'] == '/home/vagrant'
    assert facts['user_shell'] == '/bin/bash'
    assert facts['real_user_id'] == os.getuid()
    assert facts['effective_user_id'] == os.geteuid()
    assert facts['effective_group_id'] == os.getgid()

# Generated at 2022-06-23 01:53:02.131852
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    """Unit test for method collect of class UserFactCollector"""
    print("testing method collect")

    ufc = UserFactCollector()

    # run the collect method
    result = ufc.collect()

    # ensure result is a dictionary
    assert isinstance(result, dict)
    assert 'user_id' in result
    assert result['user_id'] is not None
    assert 'user_uid' in result
    assert result['user_uid'] is not None
    assert 'user_gid' in result
    assert result['user_gid'] is not None
    assert 'user_gecos' in result
    assert result['user_gecos'] is not None
    assert 'user_dir' in result
    assert result['user_dir'] is not None
    assert 'user_shell' in result
    assert result['user_shell']

# Generated at 2022-06-23 01:53:05.760135
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_facts = UserFactCollector()
    assert user_facts.name == 'user'
    assert set(user_facts._fact_ids) == set(['user_id', 'user_uid', 'user_gid', 'user_gecos', 'user_dir', 'user_shell', 'real_user_id', 'effective_user_id', 'effective_group_ids'])

# Generated at 2022-06-23 01:53:12.589975
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    userFactCollector = UserFactCollector()
    assert userFactCollector.name == "user"
    assert userFactCollector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                               'user_gecos', 'user_dir', 'user_shell',
                                               'real_user_id', 'effective_user_id',
                                               'effective_group_ids'])


# Generated at 2022-06-23 01:53:22.029618
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    ufc_result = ufc.collect()
    assert 'user_id' in ufc_result
    assert 'user_uid' in ufc_result
    assert 'user_gid' in ufc_result
    assert 'user_gecos' in ufc_result
    assert 'user_dir' in ufc_result
    assert 'user_shell' in ufc_result
    assert 'real_user_id' in ufc_result
    assert 'effective_user_id' in ufc_result
    assert 'real_group_id' in ufc_result
    assert 'effective_group_id' in ufc_result

# Generated at 2022-06-23 01:53:27.762643
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_collector = UserFactCollector()
    assert user_collector.name == 'user'
    assert user_collector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                            'user_gecos', 'user_dir', 'user_shell',
                                            'real_user_id', 'effective_user_id',
                                            'effective_group_ids'])


# Generated at 2022-06-23 01:53:36.282674
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    userCollector = UserFactCollector()
    userFacts = userCollector.collect()
    uid = userFacts.get('user_uid')
    gid = userFacts.get('user_gid')
    ruid = userFacts.get('real_user_id')
    egid = userFacts.get('effective_group_id')
    print('User: {0}, UID: {1}, GID: {2}, Real UID: {3}, Effective GID: {4}'.format(userFacts.get('user_id'), uid, gid, ruid, egid))
    assert(uid >= 0)
    assert(gid >= 0)
    assert(ruid >= 0)
    assert(egid >= 0)

# -----------------------------------------------------------------------------
# Unit test execution
#

# Generated at 2022-06-23 01:53:47.976864
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_info = UserFactCollector().collect()
    assert "user_id" in user_info.keys()
    assert "user_uid" in user_info.keys()
    assert "user_gid" in user_info.keys()
    assert "user_gecos" in user_info.keys()
    assert "user_dir" in user_info.keys()
    assert "user_shell" in user_info.keys()
    assert "real_user_id" in user_info.keys()
    assert "effective_user_id" in user_info.keys()
    assert "real_group_id" in user_info.keys()
    assert "effective_group_id" in user_info.keys()
    assert user_info['user_id'] != None
    assert user_info['user_uid'] != None


# Generated at 2022-06-23 01:53:57.321293
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    import ansible.module_utils.facts.collector
    collector = ansible.module_utils.facts.collector.BaseFactCollector.get_collector('user_facts')
    assert collector.name == 'user'
    assert collector.internal_facts == ['orphan_key_counter']
    assert collector._fact_ids == {'user_id','user_uid','user_gid','user_gecos','user_dir','user_shell','real_user_id','effective_user_id','effective_group_ids'}
    assert isinstance(collector, UserFactCollector)

# Generated at 2022-06-23 01:54:03.377110
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    obj = UserFactCollector()
    assert obj.name == 'user'
    assert obj._fact_ids == set(['user_id', 'user_uid', 'user_gid', 'user_gecos', 'user_dir', 'user_shell', 'real_user_id', 'effective_user_id', 'effective_group_ids'])

# Generated at 2022-06-23 01:54:12.874000
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    module = {}

    data = UserFactCollector.collect(module)

    assert data['user_id'] == getpass.getuser()
    assert type(data['user_gecos']) == type('')
    assert type(data['user_dir']) == type('')
    assert type(data['user_shell']) == type('')
    assert type(data['user_uid']) == type(1)
    assert type(data['user_gid']) == type(1)
    assert type(data['effective_group_id']) == type(1)
    assert type(data['real_group_id']) == type(1)
    assert type(data['real_user_id']) == type(1)
    assert type(data['effective_user_id']) == type(1)

# Generated at 2022-06-23 01:54:22.359055
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    uf = UserFactCollector()
    user_facts = uf.collect()
    assert len(user_facts) == 8
    assert 'user_id' in user_facts
    assert 'user_uid' in user_facts
    assert 'user_gid' in user_facts
    assert 'user_gecos' in user_facts
    assert 'user_dir' in user_facts
    assert 'user_shell' in user_facts
    assert 'real_user_id' in user_facts
    assert 'effective_user_id' in user_facts
    assert 'real_group_id' in user_facts
    assert 'effective_group_id' in user_facts

# Generated at 2022-06-23 01:54:29.899372
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    ufc = UserFactCollector()
    # Load user facts
    user_facts = ufc.collect()

    # Check if real user facts have been loaded correctly
    assert user_facts['user_id'] == getpass.getuser()
    try:
        pwent = pwd.getpwnam(getpass.getuser())
    except KeyError:
        pwent = pwd.getpwuid(os.getuid())

    assert user_facts['user_uid'] == pwent.pw_uid
    assert user_facts['user_gid'] == pwent.pw_gid
    assert user_facts['user_gecos'] == pwent.pw_gecos
    assert user_facts['user_dir'] == pwent.pw_dir
    assert user_facts['user_shell'] == pwent.p

# Generated at 2022-06-23 01:54:39.941469
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    facts_collector = FactsCollector()
    mod_user_facts = UserFactCollector(facts_collector)
    user_facts = mod_user_facts.collect()
    assert 'user_id' in user_facts
    assert 'user_uid' in user_facts
    assert 'user_gid' in user_facts
    assert 'user_gecos' in user_facts
    assert 'user_dir' in user_facts
    assert 'user_shell' in user_facts
    assert 'real_user_id' in user_facts
    assert 'effective_user_id' in user_facts
    assert 'effective_group_ids' in user_facts

# Generated at 2022-06-23 01:54:45.788299
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    usr = UserFactCollector()
    assert usr.name == 'user'
    assert usr._fact_ids == set(['user_id', 'user_uid', 'user_gid', 'user_gecos',
                                 'user_dir', 'user_shell',
                                 'real_user_id', 'effective_user_id',
                                 'real_group_id', 'effective_group_id'])

# Generated at 2022-06-23 01:54:52.609609
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector().collect()
    assert 'user_id' in user_facts
    assert 'user_uid' in user_facts
    assert 'user_gid' in user_facts
    assert 'user_gecos' in user_facts
    assert 'user_dir' in user_facts
    assert 'user_shell' in user_facts
    assert 'real_user_id' in user_facts
    assert 'real_group_id' in user_facts
    assert 'effective_user_id' in user_facts
    assert 'effective_group_id' in user_facts

# Generated at 2022-06-23 01:54:53.246315
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    UserFactCollector()

# Generated at 2022-06-23 01:54:59.257889
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Create a mock object of ansible.module_utils.facts.collector.BaseFactCollector
    mock_BaseFactCollector = 'This is a mock BaseFactCollector object'

    # Create an instance of UserFactCollector
    user_fc = UserFactCollector()

    # Test method collect of class UserFactCollector
    user_fc.collect(module=mock_BaseFactCollector, collected_facts=mock_BaseFactCollector)

# Generated at 2022-06-23 01:55:07.690881
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    assert hasattr(UserFactCollector, 'name')
    assert UserFactCollector.name == 'user'
    assert hasattr(UserFactCollector, '_fact_ids')
    assert UserFactCollector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                               'user_gecos', 'user_dir', 'user_shell',
                                               'real_user_id', 'effective_user_id',
                                               'effective_group_ids'])

# Generated at 2022-06-23 01:55:13.667279
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_info = UserFactCollector().collect()
    assert 'user_facts' in user_info
    assert user_info['user_facts']['user_id'] == getpass.getuser()
    assert user_info['user_facts']['user_uid'] == pwd.getpwuid(os.getuid()).pw_uid
    assert user_info['user_facts']['user_gid'] == pwd.getpwuid(os.getuid()).pw_gid
    assert user_info['user_facts']['user_gecos'] == pwd.getpwuid(os.getuid()).pw_gecos
    assert user_info['user_facts']['user_dir'] == pwd.getpwuid(os.getuid()).pw_dir

# Generated at 2022-06-23 01:55:21.070068
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    """Test case for the UserFactCollector's collect method.  When called, the
    collect method should ensure that the following keys are returned by
    the collector:

        - user_id
        - user_uid
        - user_gid
        - user_gecos
        - user_dir
        - user_shell
        - real_user_id
        - effective_user_id
        - effective_group_ids

    :return: None
    """
    facts_obj = UserFactCollector()

    assert True # TODO: replace this placeholder test with a real test

# Generated at 2022-06-23 01:55:23.137157
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Unit test for UserFactCollector.collect()
    ufc = UserFactCollector()
    assert isinstance(ufc.collect(), dict)

# Generated at 2022-06-23 01:55:32.954917
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collector = UserFactCollector()

    facts = collector.collect()

    assert isinstance(facts, dict)
    assert len(facts) == 8
    assert isinstance(facts['user_id'], str)
    assert isinstance(facts['user_uid'], int)
    assert isinstance(facts['user_gid'], int)
    assert isinstance(facts['user_gecos'], str)
    assert isinstance(facts['user_dir'], str)
    assert isinstance(facts['user_shell'], str)
    assert isinstance(facts['real_user_id'], int)
    assert isinstance(facts['effective_user_id'], int)

# Generated at 2022-06-23 01:55:43.277538
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collector = UserFactCollector()
    result = collector.collect()

# Generated at 2022-06-23 01:55:48.433284
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    from ansible.module_utils.facts.collector import FactCollector

    # test UserFactCollector is sub class of FactCollector
    assert issubclass(UserFactCollector, FactCollector)

    # test UserFactCollector is instance of FactCollector
    assert isinstance(UserFactCollector(), FactCollector)

# Generated at 2022-06-23 01:55:56.430514
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert user_fact_collector.name == 'user'
    assert user_fact_collector.default_collect_whitelist == []
    assert user_fact_collector.default_collect_exclusionlist == []
    assert user_fact_collector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                                 'user_gecos', 'user_dir', 'user_shell',
                                                 'real_user_id', 'effective_user_id',
                                                 'effective_group_ids'])


# Generated at 2022-06-23 01:56:03.721006
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    f = UserFactCollector()
    test_facts = {}
    test_facts = f.collect(True, test_facts)

    assert test_facts['user_id'] == getpass.getuser()
    assert test_facts['real_user_id'] == os.getuid()
    assert test_facts['effective_user_id'] == os.geteuid()
    assert test_facts['real_group_id'] == os.getgid()
    assert test_facts['effective_group_id'] == os.getgid()

# Generated at 2022-06-23 01:56:06.607318
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert user_fact_collector is not None

# test for collector() of class UserFactCollector()

# Generated at 2022-06-23 01:56:09.415767
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user = UserFactCollector()
    print(user)
    assert(user)
    assert(user.name == 'user')
    assert('user_id' in user._fact_ids)


# Generated at 2022-06-23 01:56:13.364212
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts_collector = UserFactCollector()

    user_facts = user_facts_collector.collect()

    assert user_facts
    assert None not in user_facts.values()

# Generated at 2022-06-23 01:56:19.052103
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    obj = UserFactCollector()
    assert obj.name == 'user'
    assert obj._fact_ids == set(
        ['user_id', 'user_uid', 'user_gid', 'user_gecos',
         'user_dir', 'user_shell', 'real_user_id', 'effective_user_id',
         'effective_group_ids'])


# Generated at 2022-06-23 01:56:25.249932
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ufc = UserFactCollector()
    assert ufc.name == 'user'
    assert ufc._fact_ids == set(['user_id', 'user_uid', 'user_gid', 'user_gecos',
                                 'user_dir', 'user_shell', 'real_user_id', 'real_group_id',
                                 'effective_user_id', 'effective_group_id'])

# Generated at 2022-06-23 01:56:32.295211
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fact_collector = UserFactCollector()
    fact_collector.collect()
    assert isinstance(fact_collector.collect()['user_id'], str)
    assert isinstance(fact_collector.collect()['user_uid'], int)
    assert isinstance(fact_collector.collect()['user_gid'], int)
    assert isinstance(fact_collector.collect()['user_gecos'], str)
    assert isinstance(fact_collector.collect()['user_dir'], str)
    assert isinstance(fact_collector.collect()['user_shell'], str)
    assert isinstance(fact_collector.collect()['real_user_id'], int)
    assert isinstance(fact_collector.collect()['effective_user_id'], int)
    assert isinstance

# Generated at 2022-06-23 01:56:39.301765
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert user_fact_collector.name == 'user'
    keys = set(['user_id', 'user_uid', 'user_gid', 'user_gecos',
                'user_dir', 'user_shell', 'real_user_id',
                'effective_user_id', 'effective_group_ids'])
    assert user_fact_collector._fact_ids == keys


# Generated at 2022-06-23 01:56:48.811475
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    test_module = os.path.dirname(os.path.dirname(__file__)) + '/ansible_test_mocks/module_utils/basic.py'
    test_methods = [('collect', None)]
    test_class = UserFactCollector(module=test_module, collected_facts={})

    assert test_class.collect() == {'user_id': 'root', 'user_uid': 0, 'user_gid': 0, 'user_gecos': 'root', 'user_dir': '/root', 'user_shell': '/bin/bash', 'real_user_id': 0, 'effective_user_id': 0, 'real_group_id': 0, 'effective_group_id': 0}

# Generated at 2022-06-23 01:56:50.024823
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    u = UserFactCollector()
    assert u.name == 'user'


# Generated at 2022-06-23 01:56:58.891033
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    # Test with default parameters
    ufc = UserFactCollector()
    assert ufc.name == 'user'
    assert ufc._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                 'user_gecos', 'user_dir', 'user_shell',
                                 'real_user_id', 'effective_user_id',
                                 'effective_group_ids'])
    ufc = None

    # Test with custom parameters
    ufc = UserFactCollector()
    assert ufc.name == 'user'

# Generated at 2022-06-23 01:57:08.397569
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.user import UserFactCollector

    testUserFactCollector = UserFactCollector()
    testFactCollector = FactCollector()

    testFactCollector.collector['user'] = testUserFactCollector

    assert testFactCollector.collector['user'].name == 'user'
    assert testFactCollector.collector['user']._fact_ids == \
           set(['user_id', 'user_uid', 'user_gid', 'user_gecos',
                'user_dir', 'user_shell', 'real_user_id',
                'effective_user_id', 'effective_group_ids'])

    userFacts = testFactCollector.collector['user'].collect()

    assert userF

# Generated at 2022-06-23 01:57:16.268309
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    c = UserFactCollector()
    assert c.collect() == {'effective_group_id': 1000, 'effective_user_id': 1000, 'real_group_id': 1000, 'real_user_id': 1000, 'user_dir': '/Users/rwilson', 'user_gecos': 'Rich Wilson,,,', 'user_gid': 1000, 'user_id': 'rwilson', 'user_shell': '/bin/bash', 'user_uid': 1000}

# Generated at 2022-06-23 01:57:24.123451
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    real_user_id=os.getuid()
    real_group_id=os.getgid()
    effective_user_id=os.geteuid()
    try:
        pwent=pwd.getpwnam(getpass.getuser())
    except KeyError:
        pwent=pwd.getpwuid(os.getuid())
    user_id=getpass.getuser()
    user_uid=pwent.pw_uid
    user_gid=pwent.pw_gid
    user_gecos=pwent.pw_gecos
    user_dir=pwent.pw_dir
    user_shell=pwent.pw_shell
    user_fact_collector=UserFactCollector()
    result=user_fact_collector.collect()
    assert result

# Generated at 2022-06-23 01:57:26.838808
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    assert UserFactCollector().collect()

# Generated at 2022-06-23 01:57:34.008570
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    usr_fact_collector = UserFactCollector()

    usr_facts = usr_fact_collector.collect()

    assert usr_facts['user_id'] == getpass.getuser()
    assert usr_facts['user_uid'] == pwd.getpwuid(os.getuid()).pw_uid
    assert usr_facts['user_gid'] == pwd.getpwuid(os.getuid()).pw_gid
    assert usr_facts['user_gecos'] == pwd.getpwuid(os.getuid()).pw_gecos
    assert usr_facts['user_dir'] == pwd.getpwuid(os.getuid()).pw_dir

# Generated at 2022-06-23 01:57:39.119945
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ufc = UserFactCollector()
    assert ufc.name == 'user'
    assert ufc._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                 'user_gecos', 'user_dir', 'user_shell',
                                 'real_user_id', 'effective_user_id',
                                 'effective_group_id'])


# Generated at 2022-06-23 01:57:50.702015
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    obj = UserFactCollector()

    assert obj.name == 'user'
    assert obj._fact_ids == set(['user_id', 'user_uid', 'user_gid', 'user_gecos',
                                 'user_dir', 'user_shell', 'real_user_id',
                                 'effective_user_id', 'effective_group_ids'])

# Generated at 2022-06-23 01:58:00.831986
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    U = UserFactCollector()
    F = U.collect()
    assert F['user_id'] == getpass.getuser()
    assert F['user_uid'] == os.getuid()
    assert F['user_gid'] == os.getgid()
    assert F['user_dir'] == os.path.expanduser('~')
    assert F['user_shell'] == os.path.expanduser('~/.bashrc')
    assert F['real_user_id'] == os.getuid()
    assert F['effective_user_id'] == os.geteuid()
    assert F['real_group_id'] == os.getgid()
    assert F['effective_group_id'] == os.getegid()

# Generated at 2022-06-23 01:58:07.430461
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():

    user_fact_collector = UserFactCollector()
    assert user_fact_collector.name == 'user'
    assert set(user_fact_collector._fact_ids) == set(['user_id', 'user_uid', 'user_gid',
                                                      'user_gecos', 'user_dir', 'user_shell',
                                                      'real_user_id', 'effective_user_id',
                                                      'effective_group_ids'])


# Generated at 2022-06-23 01:58:09.272381
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact = UserFactCollector()
    assert isinstance(user_fact, UserFactCollector)

# Generated at 2022-06-23 01:58:11.492077
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert(user_fact_collector != None)


# Generated at 2022-06-23 01:58:16.405313
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ufc = UserFactCollector
    assert ufc.name == 'user'
    assert set(ufc._fact_ids) == set(['user_id', 'user_uid', 'user_gid',
                                      'user_gecos', 'user_dir', 'user_shell',
                                      'real_user_id', 'effective_user_id',
                                      'effective_group_ids'])

# Generated at 2022-06-23 01:58:21.620902
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
	u = UserFactCollector()
	assert u.name == 'user'
	assert u._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                     'user_gecos', 'user_dir', 'user_shell',
                     'real_user_id', 'effective_user_id',
                     'effective_group_ids'])

# Generated at 2022-06-23 01:58:29.866918
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()
    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['effective_user_id'] == os.geteuid()
    assert user_facts['real_user_id'] == os.getuid()


# Generated at 2022-06-23 01:58:32.660858
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    userFactCollector = UserFactCollector()
    userFactCollector.collect()


# Generated at 2022-06-23 01:58:40.535560
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user = UserFactCollector()
    assert user.name == 'user'
    assert user._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                  'user_gecos', 'user_dir', 'user_shell',
                                  'real_user_id', 'effective_user_id',
                                  'effective_group_ids'])


# Generated at 2022-06-23 01:58:43.874153
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    result = ufc.collect()
    assert isinstance(result, dict)
    assert result is not None

# Generated at 2022-06-23 01:58:46.125152
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    aff_obj = UserFactCollector()
    assert isinstance(aff_obj, UserFactCollector)

if __name__ == '__main__':
    test_UserFactCollector()

# Generated at 2022-06-23 01:58:48.722965
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_facts = UserFactCollector()
    assert isinstance(user_facts, UserFactCollector)
    assert user_facts.name == 'user'
    assert type(user_facts._fact_ids) is set

# Generated at 2022-06-23 01:58:57.597282
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Initialize UserFactCollector object
    c = UserFactCollector()

    # Call collect method and get back a dictionary
    collected_facts = c.collect()

    # Verify that all items in _fact_ids are present in the return dictionary
    for item in c._fact_ids:
        assert item in collected_facts

    # Verify that the values returned for each item are the expected values
    assert collected_facts["user_id"] == getpass.getuser()
    assert collected_facts["user_uid"] == os.getuid()
    assert collected_facts["user_gid"] == os.getgid()
    assert collected_facts["user_gecos"] == "Test McTesterson"
    assert collected_facts["user_dir"] == "/home/test"
    assert collected_facts["user_shell"] == "/bin/bash"

# Generated at 2022-06-23 01:59:05.540623
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_facts = UserFactCollector()
    assert user_facts.name == 'user'
    assert user_facts._fact_ids == {'user_id', 'user_uid', 'user_gid',
                                    'user_gecos', 'user_dir', 'user_shell',
                                    'real_user_id', 'effective_user_id',
                                    'effective_group_ids'}


# Generated at 2022-06-23 01:59:08.237650
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    collected_facts = {}
    userfact = UserFactCollector(None, collected_facts)
    assert userfact.name == 'user'
    assert isinstance(userfact._fact_ids, set)


# Generated at 2022-06-23 01:59:10.726528
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    result = user_fact_collector.collect()
    assert result == 'Success'


# Generated at 2022-06-23 01:59:12.374585
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact = UserFactCollector()
    assert True == isinstance(user_fact, UserFactCollector)

# Generated at 2022-06-23 01:59:16.930246
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():

    obj = UserFactCollector()

    assert obj._fact_ids == set(['user_id', 'user_uid', 'user_gid', 'user_gecos', 'user_dir', 'user_shell', 'real_user_id', 'effective_user_id', 'effective_group_ids'])
    assert obj.name == 'user'


# Generated at 2022-06-23 01:59:21.896290
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ufc = UserFactCollector()
    assert ufc.name == 'user'
    assert ufc._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                 'user_gecos', 'user_dir', 'user_shell',
                                 'real_user_id', 'effective_user_id'])

# Generated at 2022-06-23 01:59:26.040940
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector().collect()

    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['effective_group_id'] == os.getgid()


# vim: set expandtab ts=4 sw=4:

# Generated at 2022-06-23 01:59:32.012686
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    x = UserFactCollector()
    assert x.name == 'user'
    assert x._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                               'user_gecos', 'user_dir', 'user_shell',
                               'real_user_id', 'effective_user_id',
                               'effective_group_ids'])


# Generated at 2022-06-23 01:59:37.589753
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    assert UserFactCollector.name == 'user'
    assert UserFactCollector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                     'user_gecos', 'user_dir', 'user_shell',
                     'real_user_id', 'effective_user_id',
                     'effective_group_ids'])


# Generated at 2022-06-23 01:59:40.847627
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    # Constructor test
    user_fact_collector = UserFactCollector()
    assert user_fact_collector is not None
    assert isinstance(user_fact_collector, UserFactCollector)

# vim: set et sw=4 ts=4:

# Generated at 2022-06-23 01:59:43.540835
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    assert UserFactCollector().name == 'user'
    assert UserFactCollector()._fact_ids == {'user_id', 'user_uid', 'user_gid',
                                             'user_gecos', 'user_dir', 'user_shell',
                                             'real_user_id', 'effective_user_id',
                                             'effective_group_ids'}

# Generated at 2022-06-23 01:59:53.561817
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import collections

    user_facts = collections.OrderedDict()
    user_facts['user_dir'] = '/home/testuser'
    user_facts['user_gecos'] = 'testuser,,,'
    user_facts['user_gid'] = 1000
    user_facts['user_id'] = 'testuser'
    user_facts['user_shell'] = '/bin/bash'
    user_facts['user_uid'] = 1000
    user_facts['effective_group_id'] = 1000
    user_facts['effective_user_id'] = 1000
    user_facts['real_group_id'] = 1000
    user_facts['real_user_id'] = 1000

    actual = UserFactCollector().collect()
    assert actual == user_facts

# Generated at 2022-06-23 01:59:54.655825
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    collector = UserFactCollector()


# Generated at 2022-06-23 02:00:06.484481
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    """ Unit test for method collect of class UserFactCollector """

    # Init an instance of class UserFactCollector()
    user_fact = UserFactCollector()

    # Get the list of facts that can be collected by this class
    fact_ids = user_fact.get_fact_ids()

    # Create a new 'ansible_facts' dictionary for collecting facts
    ansible_facts = {}

    # Collect facts
    ansible_facts.update(user_fact.collect())

    # Test if collected facts are correct
    assert set(ansible_facts) == set(fact_ids)
    assert isinstance(ansible_facts['user_id'], str)
    assert isinstance(ansible_facts['user_uid'], int)
    assert isinstance(ansible_facts['user_gid'], int)
    assert isinstance

# Generated at 2022-06-23 02:00:13.821867
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    test_collector = UserFactCollector()
    result = test_collector.collect()

    # Check for keys
    assert result['user_id']
    assert result['user_uid']
    assert result['user_gid']
    assert result['user_gecos']
    assert result['user_dir']
    assert result['user_shell']
    assert result['real_user_id']
    assert result['effective_user_id']
    assert result['real_group_id']
    assert result['effective_group_id']

# Generated at 2022-06-23 02:00:16.017506
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    c = UserFactCollector()
    result = c.collect()
    assert "user_id" in result

# Generated at 2022-06-23 02:00:25.227305
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.user import UserFactCollector
    from ansible.module_utils.facts.utils import get_file_lines

    fake_export_facts = get_file_lines(os.path.join('tests','resources','fake_export_facts.txt'))

    Collector.add_collector(UserFactCollector())

    user_facts = Collector().collect(module=None)
