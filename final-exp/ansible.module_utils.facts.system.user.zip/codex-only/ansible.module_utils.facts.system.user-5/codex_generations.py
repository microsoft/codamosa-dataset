

# Generated at 2022-06-23 01:50:27.258134
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import inspect
    import sys

    from ansible.module_utils.facts.collector import BaseFactCollector

    # Mock out dependencies
    import UserFactCollector
    UserFactCollector.getpass.getuser = lambda: 'user'
    UserFactCollector.os.getuid = lambda: 1
    UserFactCollector.os.geteuid = lambda: 2
    UserFactCollector.os.getgid = lambda: 3
    UserFactCollector.os.getegid = lambda: 4
    UserFactCollector.pwd.getpwnam = lambda user: (1, 2, 3, 4, 5, '/path', '/shell')

    # Instantiate and call method
    collector = UserFactCollector()
    curframe = inspect.currentframe()
    calframe = inspect.getouterframes(curframe, 2)



# Generated at 2022-06-23 01:50:35.438444
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    expected_user_facts = {'user_id': 'test_user',
                           'user_gid': 5000,
                           'user_shell': '/bin/bash',
                           'real_user_id': 5000,
                           'user_gecos': 'test user,,,',
                           'effective_group_id': 5000,
                           'effective_user_id': 5000,
                           'user_dir': '/home/test_user',
                           'real_group_id': 5000,
                           'user_uid': 5000}

    ufc = UserFactCollector()

    actual_user_facts = ufc.collect()

    assert actual_user_facts == expected_user_facts

# Generated at 2022-06-23 01:50:43.337722
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = {u'user_uid': int(os.getuid()),
     u'user_id': getpass.getuser(),
     u'user_gid': int(os.getgid()),
     u'user_gecos': u'(null)',
     u'user_dir': os.environ['HOME'],
     u'user_shell': u'/bin/bash',
     u'real_user_id': int(os.getuid()),
     u'effective_user_id': int(os.geteuid()),
     u'real_group_id': int(os.getgid()),
     u'effective_group_id': int(os.getgid())
    }

    u = UserFactCollector()
    assert u.collect() == user_facts

# Generated at 2022-06-23 01:50:49.151162
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ufc = UserFactCollector()
    assert ufc._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                 'user_gecos', 'user_dir', 'user_shell',
                                 'real_user_id', 'effective_user_id',
                                 'effective_group_ids'])

# Generated at 2022-06-23 01:50:57.589567
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    """This is a unit test for constructor of class UserFactCollector"""
    print("Testing construction of UserFactCollector object")
    user_collector = UserFactCollector()
    assert user_collector.name == 'user'
    assert user_collector._fact_ids == set(['user_id', 'user_uid',
                                            'user_gid', 'user_gecos',
                                            'user_dir', 'user_shell',
                                            'real_user_id',
                                            'effective_user_id',
                                            'effective_group_ids'])
    print("Testing completed successfully")


# Generated at 2022-06-23 01:51:01.926671
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    userfc = UserFactCollector()
    assert userfc.name == 'user'
    assert userfc._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                     'user_gecos', 'user_dir', 'user_shell',
                     'real_user_id', 'effective_user_id',
                     'effective_group_ids'])


# Generated at 2022-06-23 01:51:12.409806
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    from ansible.module_utils.facts.fact_collector import FactCollector
    import pwd

    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()

    user_name = getpass.getuser()
    try:
        pwent = pwd.getpwnam(user_name)
    except KeyError:
        pwent = pwd.getpwuid(os.getuid())

    assert user_name == user_facts['user_id']
    assert pwent.pw_uid == user_facts['user_uid']
    assert pwent.pw_gid == user_facts['user_gid']
    assert pwent.pw_gecos == user_facts['user_gecos']
    assert pwent.pw_dir == user_

# Generated at 2022-06-23 01:51:22.708533
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    # set the test's user_id to a known value
    test_user_id = 'test_user_id'
    getpass.getuser_original = getpass.getuser
    pwd.getpwnam_original = pwd.getpwnam
    os.getuid_original = os.getuid
    os.geteuid_original = os.geteuid
    os.getgid_original = os.getgid
    os.getegid_original = os.getegid

    getpass.getuser = lambda: test_user_id

# Generated at 2022-06-23 01:51:24.938616
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
	user = UserFactCollector()
	assert user

# Generated at 2022-06-23 01:51:29.971450
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collector = UserFactCollector()
    collected_facts = {}
    # Test collect when user is not root
    result = collector.collect(module=None, collected_facts=collected_facts)
    assert 'user_id' in result
    assert result['user_id'] == os.getlogin()
    assert 'user_uid' in result
    assert 'user_gid' in result
    assert 'user_gecos' in result
    assert 'user_dir' in result
    assert 'user_shell' in result
    assert 'real_user_id' in result
    assert result['real_user_id'] == os.getuid()
    assert 'effective_user_id' in result
    assert result['effective_user_id'] == os.geteuid()
    assert 'real_group_id' in result

# Generated at 2022-06-23 01:51:36.497097
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert user_fact_collector.name == 'user'
    assert user_fact_collector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                     'user_gecos', 'user_dir', 'user_shell',
                     'real_user_id', 'effective_user_id',
                     'effective_group_ids'])

# Generated at 2022-06-23 01:51:42.464019
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    user_facts = ufc.collect()
    assert isinstance(user_facts, dict), "UserFactCollector.collect should return a dictionary"
    assert 'user_id' in user_facts, "UserFactCollector.collect should have returned the key 'user_id'"
    assert user_facts['user_id'] == getpass.getuser(), "UserFactCollector.collect should return the current user"

# Generated at 2022-06-23 01:51:47.952759
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    collector = UserFactCollector()
    assert collector.name == 'user'
    assert collector._fact_ids == set(['user_id', 'user_uid',
                                       'user_gid', 'user_gecos',
                                       'user_dir', 'user_shell',
                                       'real_user_id',
                                       'effective_user_id',
                                       'effective_group_ids'])

# Generated at 2022-06-23 01:51:56.077993
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ufc = UserFactCollector()

    assert(ufc.name == 'user')

    assert(ufc._fact_ids == set(['real_group_id',
                                 'effective_group_id',
                                 'effective_user_id',
                                 'real_user_id',
                                 'user_gecos',
                                 'user_shell',
                                 'user_dir',
                                 'user_gid',
                                 'user_uid',
                                 'user_id']))


# Generated at 2022-06-23 01:51:59.895448
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    u = UserFactCollector()
    assert u
    # TODO: Add assertions to confirm that the expected values are present
    # in the results of u.collect()

# Generated at 2022-06-23 01:52:02.474958
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Create an instance of class UserFactCollector
    user_fact_collector = UserFactCollector()

    # Test the method with all test cases
    user_fact_collector.collect()

# Generated at 2022-06-23 01:52:03.037693
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    UserFactCollector()

# Generated at 2022-06-23 01:52:10.668912
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    facts_dict = ufc.collect()
    assert 'user_id' in facts_dict
    assert 'user_uid' in facts_dict
    assert 'user_gid' in facts_dict
    assert 'user_gecos' in facts_dict
    assert 'user_dir' in facts_dict
    assert 'user_shell' in facts_dict
    assert 'real_user_id' in facts_dict
    assert 'real_group_id' in facts_dict
    assert 'effective_user_id' in facts_dict
    assert 'effective_group_id' in facts_dict

# Generated at 2022-06-23 01:52:17.505576
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    collector = UserFactCollector()
    assert collector.name == "user"
    assert collector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                       'user_gecos', 'user_dir', 'user_shell',
                                       'real_user_id', 'effective_user_id',
                                       'effective_group_ids'])


# Generated at 2022-06-23 01:52:22.080063
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    values = ['user_id', 'user_uid', 'user_gid', 'user_gecos', 'user_dir', 'user_shell', 'real_user_id', 'effective_user_id', 'effective_group_id']
    assert UserFactCollector._fact_ids == set(values)
    assert UserFactCollector.name == 'user'

# Generated at 2022-06-23 01:52:33.380748
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = {}
    user_facts['user_id'] = getpass.getuser()
    try:
        pwent = pwd.getpwnam(getpass.getuser())
    except KeyError:
        pwent = pwd.getpwuid(os.getuid())

    user_facts['user_uid'] = pwent.pw_uid
    user_facts['user_gid'] = pwent.pw_gid
    user_facts['user_gecos'] = pwent.pw_gecos
    user_facts['user_dir'] = pwent.pw_dir
    user_facts['user_shell'] = pwent.pw_shell
    user_facts['real_user_id'] = os.getuid()
    user_facts['effective_user_id'] = os.geteu

# Generated at 2022-06-23 01:52:42.139332
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    test_collector = UserFactCollector()
    facts_dict = test_collector.collect()

    assert type(facts_dict) == dict
    assert 'user_id' in facts_dict
    assert 'user_uid' in facts_dict
    assert 'user_gid' in facts_dict
    assert 'user_gecos' in facts_dict
    assert 'user_dir' in facts_dict
    assert 'user_shell' in facts_dict
    assert 'real_user_id' in facts_dict
    assert 'effective_user_id' in facts_dict
    assert 'effective_group_ids' in facts_dict

# Generated at 2022-06-23 01:52:45.278837
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    t = UserFactCollector()
    assert t.name == 'user'

# Generated at 2022-06-23 01:52:56.252748
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    #Test data
    user_id = 'ansible'
    user_uid = 1000
    user_gid = 1000
    user_gecos = 'ansible,,, '
    user_dir = '/home/ansible'
    user_shell = '/bin/bash'

    # Create instance of UserFactCollector class
    user_fact_collector_instance = UserFactCollector()
    # Declare collected_facts variable
    collected_facts = {}
    # Call collect method
    user_facts = user_fact_collector_instance.collect(collected_facts)

    # Assert user_id fact with data from test method(method should return)
    assert user_facts['user_id'] == user_id

    # Assert user_uid fact with data from test method(method should return)

# Generated at 2022-06-23 01:53:05.490308
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    facts = UserFactCollector()
    assert facts.name == 'user'
    assert facts.fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                  'user_gecos', 'user_dir', 'user_shell',
                                  'real_user_id', 'effective_user_id',
                                  'effective_group_ids'])


# Generated at 2022-06-23 01:53:16.411403
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # define the test object
    test_obj = UserFactCollector()
    # test if result is right

# Generated at 2022-06-23 01:53:20.873824
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector().collect()

    # results if run on travis-ci
    assert user_facts['user_id'] == 'travis'
    assert user_facts['user_uid'] == 2000
    assert user_facts['effective_user_id'] == 2000
    assert user_facts['user_dir'] == '/home/travis'

# Generated at 2022-06-23 01:53:23.130432
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    l_user_fact_collector = UserFactCollector()
    l_user_fact_collector.collect()

# Generated at 2022-06-23 01:53:26.106772
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    facts = user_fact_collector.collect(collected_facts=None)
    assert isinstance(facts, dict)



# Generated at 2022-06-23 01:53:32.365752
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import ansible.module_utils.facts.system.user as UserFactCollector
    user_facts = UserFactCollector.collect()
    assert user_facts.get('user_id') == getpass.getuser()
    assert user_facts.get('real_group_id') == os.getgid()
    assert user_facts.get('effective_group_id') == os.getgid()

# Generated at 2022-06-23 01:53:34.709081
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_fact_collector.collect()

# Generated at 2022-06-23 01:53:47.350876
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():

    ufc = UserFactCollector()

    assert ufc.name == 'user'
    assert len(ufc._fact_ids) == 9
    assert 'user_id' in ufc._fact_ids
    assert 'user_uid' in ufc._fact_ids
    assert 'user_gid' in ufc._fact_ids
    assert 'user_gecos' in ufc._fact_ids
    assert 'user_dir' in ufc._fact_ids
    assert 'user_shell' in ufc._fact_ids
    assert 'real_user_id' in ufc._fact_ids
    assert 'effective_user_id' in ufc._fact_ids
    assert 'effective_group_ids' in ufc._fact_ids


# Generated at 2022-06-23 01:53:58.777162
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    window_user_id = '1002'
    user_id = '1002'
    user_uid = '1002'
    user_gid = '1002'
    user_gecos = '1002'
    user_dir = '1002'
    user_shell = '1002'
    real_user_id = '1002'
    effective_user_id = '1002'
    real_group_id = '1002'
    effective_group_id = '1002'


# Generated at 2022-06-23 01:54:06.634076
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_fact_collector.collect()
    assert user_fact_collector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                     'user_gecos', 'user_dir', 'user_shell',
                     'real_user_id', 'effective_user_id',
                     'effective_group_ids'])

# Generated at 2022-06-23 01:54:07.224564
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    UserFactCollector()

# Generated at 2022-06-23 01:54:12.748106
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    collector = UserFactCollector()
    assert collector.name == 'user'
    assert collector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                       'user_gecos', 'user_dir', 'user_shell',
                                       'real_user_id', 'effective_user_id',
                                       'effective_group_ids'])


if __name__ == '__main__':
    test_UserFactCollector()

# Generated at 2022-06-23 01:54:16.588201
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    ret = ufc.collect()
    # Ensures that all keys of the dictionary are facts.
    assert ufc._fact_ids.intersection(ret.keys()) == ufc._fact_ids

# Generated at 2022-06-23 01:54:19.717569
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ufc = UserFactCollector()
    assert ufc.name == 'user'
    assert isinstance(ufc._fact_ids, set)
    assert isinstance(ufc.collect(), dict)



# Generated at 2022-06-23 01:54:28.466345
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    from ansible.module_utils.facts.collector import \
        BaseFactCollector
    from ansible.module_utils.facts.collector.user import \
        UserFactCollector
    from ansible.module_utils._text import to_text

    try:
        from __main__ import display
    except ImportError:
        from ansible.utils.display import Display
        display = Display()

    display.verbosity = 3

    user = UserFactCollector()

    fact_id_set = set(user._fact_ids)
    fact_id_set.add(BaseFactCollector.ALL_FACT_ID)
    fact_id_set.add('non_existing_fact_id')

    result_dict = user.collect()

    assert type(result_dict) is dict

    # check if all keys are in result

# Generated at 2022-06-23 01:54:39.010824
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    a = UserFactCollector()
    b = a.collect()
    assert type(b) == dict
    assert b.has_key('user_id')
    assert b.has_key('user_uid')
    assert b.has_key('user_gid')
    assert b.has_key('user_gecos')
    assert b.has_key('user_dir')
    assert b.has_key('user_shell')
    assert b.has_key('effective_group_id')
    assert b.has_key('effective_user_id')
    assert b.has_key('real_group_id')
    assert b.has_key('real_user_id')


# Generated at 2022-06-23 01:54:49.686452
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user = UserFactCollector()
    result = user.collect()
    assert result['user_id'] == getpass.getuser()
    assert result['user_uid'] == pwd.getpwnam(getpass.getuser()).pw_uid
    assert result['user_gid'] == pwd.getpwnam(getpass.getuser()).pw_gid
    assert result['user_gecos'] == pwd.getpwnam(getpass.getuser()).pw_gecos
    assert result['user_dir'] == pwd.getpwnam(getpass.getuser()).pw_dir
    assert result['user_shell'] == pwd.getpwnam(getpass.getuser()).pw_shell
    assert result['real_user_id'] == os.getuid()


# Generated at 2022-06-23 01:55:00.975387
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import sys
    import os

    collector = UserFactCollector()
    user_facts = collector.collect()

    # user_id
    assert(user_facts['user_id'] == getpass.getuser())

    # user_uid
    try:
        pwent = pwd.getpwnam(getpass.getuser())
    except KeyError:
        pwent = pwd.getpwuid(os.getuid())

    assert(user_facts['user_uid'] == pwent.pw_uid)

    # user_gid
    assert(user_facts['user_gid'] == pwent.pw_gid)

    # user_gecos
    assert(user_facts['user_gecos'] == pwent.pw_gecos)

    # user_dir

# Generated at 2022-06-23 01:55:10.136226
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    m_module = mock.MagicMock()
    m_module.params = {}
    m_collected_facts = {}

    m_collector = mock.MagicMock(spec=ansible.module_utils.facts.collectors.user.UserFactCollector)
    m_collector.collect = ansible.module_utils.facts.collectors.user.UserFactCollector.collect
    m_collector.collect(m_module, m_collected_facts)

    assert m_module.fail_json.called == 0

# Generated at 2022-06-23 01:55:11.641185
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert user_fact_collector.name == 'user'

# Generated at 2022-06-23 01:55:19.088932
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts=user_fact_collector.collect()
    assert set(user_facts.keys()) == set(['user_id', 'user_uid', 'user_gid',
                     'user_gecos', 'user_dir', 'user_shell',
                     'real_user_id', 'effective_user_id',
                     'real_group_id', 'effective_group_id'])

# Generated at 2022-06-23 01:55:28.943855
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Initialize class
    ufc = UserFactCollector()
    assert isinstance(ufc, UserFactCollector)
    # Construct expected result
    user_facts = {}
    user_facts['user_id'] = getpass.getuser()
    try:
        pwent = pwd.getpwnam(getpass.getuser())
    except KeyError:
        pwent = pwd.getpwuid(os.getuid())
    user_facts['user_uid'] = pwent.pw_uid
    user_facts['user_gid'] = pwent.pw_gid
    user_facts['user_gecos'] = pwent.pw_gecos
    user_facts['user_dir'] = pwent.pw_dir
    user_facts['user_shell'] = pwent.pw_

# Generated at 2022-06-23 01:55:30.873846
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector().collect()
    assert user_facts['user_id'] == getpass.getuser()

# Generated at 2022-06-23 01:55:40.358781
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector().collect()

    assert user_facts['user_id'] == getpass.getuser()
    try:
        pwent = pwd.getpwnam(getpass.getuser())
    except KeyError:
        pwent = pwd.getpwuid(os.getuid())

    assert user_facts['user_uid'] == pwent.pw_uid
    assert user_facts['user_gid'] == pwent.pw_gid
    assert user_facts['user_gecos'] == pwent.pw_gecos
    assert user_facts['user_dir'] == pwent.pw_dir
    assert user_facts['user_shell'] == pwent.pw_shell
    assert user_facts['real_user_id'] == os.getuid()
    assert user

# Generated at 2022-06-23 01:55:42.482020
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    fact_collector = UserFactCollector()
    fact_collector.collect()
    assert fact_collector.name == 'user'

# Generated at 2022-06-23 01:55:53.499397
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    """Unit test for method collect of class UserFactCollector."""
    # Collect facts
    UserFactCollector.collect()
    # Get facts
    user_id = UserFactCollector.get_fact('user_id')
    user_uid = UserFactCollector.get_fact('user_uid')
    user_gid = UserFactCollector.get_fact('user_gid')
    user_gecos = UserFactCollector.get_fact('user_gecos')
    user_dir = UserFactCollector.get_fact('user_dir')
    user_shell = UserFactCollector.get_fact('user_shell')
    real_user_id = UserFactCollector.get_fact('real_user_id')
    effective_user_id = UserFactCollector.get_fact('effective_user_id')


# Generated at 2022-06-23 01:56:04.037318
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_collector = UserFactCollector()
    user_fact = user_collector.collect()
    try:
        assert user_fact == {'user_id': 'root',
            'user_uid': 0,
            'user_gid': 0,
            'user_gecos': 'root',
            'user_dir': '/root',
            'user_shell': '/bin/bash',
            'real_user_id': 0,
            'effective_user_id': 0,
            'real_group_id': 0,
            'effective_group_id': 0}
    except AssertionError:
        print("The assertion failed.  However, this assertion should have passed.  Please investigate further.")
        exit(1)

# Generated at 2022-06-23 01:56:07.433751
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    # Create collector object and verify name attribute
    user_fact_collector = UserFactCollector()
    user_facts_name = user_fact_collector.name
    assert user_facts_name == 'user'

# Generated at 2022-06-23 01:56:15.061509
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    """
    Unit test for the class: UserFactCollector's function: collect

    Arguments:
        none

    Return:
        none

    Raises:
        none
    """
    print("\n#####################################\n")
    print("Testing method collect of class UserFactCollector\n")
    collector = UserFactCollector()
    collected_facts = collector.collect()

    print("Collected facts: ")
    for fact in collected_facts:
        print(fact)

# Generated at 2022-06-23 01:56:27.219173
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    user_facts = ufc.collect()

    assert isinstance(user_facts, dict)
    assert 'user_id' in user_facts
    assert 'user_uid' in user_facts
    assert 'user_gid' in user_facts
    assert 'user_gecos' in user_facts
    assert 'user_dir' in user_facts
    assert 'user_shell' in user_facts
    assert 'real_user_id' in user_facts
    assert 'effective_user_id' in user_facts
    assert 'real_group_id' in user_facts
    assert 'effective_group_id' in user_facts

    # test if the user_id is the same as the one returned by the getuser function
    # the getuser function returns the result of the getlogin function if

# Generated at 2022-06-23 01:56:31.386111
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    # Test for constructor with no arguments
    UserFactCollector()


if __name__ == '__main__':
    test_UserFactCollector()

# Generated at 2022-06-23 01:56:38.288586
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    collector = UserFactCollector()
    assert collector.name == 'user'
    assert collector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                       'user_gecos', 'user_dir', 'user_shell',
                                       'real_user_id', 'effective_user_id',
                                       'effective_group_ids'])


# Generated at 2022-06-23 01:56:42.052556
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # init
    ufc = UserFactCollector()

    # run
    fact = ufc.collect()

    # test
    assert fact['real_user_id'] == os.getuid()

# Generated at 2022-06-23 01:56:48.350134
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    uc = UserFactCollector()
    assert uc.name == 'user'
    assert uc._fact_ids == {'user_id', 'user_uid', 'user_gid',
                            'user_gecos', 'user_dir', 'user_shell',
                            'real_user_id', 'effective_user_id',
                            'effective_group_ids'}


# Generated at 2022-06-23 01:56:57.554422
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    test_user_facts = ufc.collect()

    assert type(test_user_facts) is dict
    assert 'user_id' in test_user_facts.keys()
    assert 'user_uid' in test_user_facts.keys()
    assert 'user_gid' in test_user_facts.keys()
    assert 'user_shell' in test_user_facts.keys()
    assert 'user_gecos' in test_user_facts.keys()
    assert 'user_dir' in test_user_facts.keys()
    assert 'real_user_id' in test_user_facts.keys()
    assert 'effective_user_id' in test_user_facts.keys()
    assert 'real_group_id' in test_user_facts.keys()

# Generated at 2022-06-23 01:56:59.373093
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert user_fact_collector.name == 'user'

# Generated at 2022-06-23 01:57:02.359009
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    # test whether constructor of UserFactCollector is properly
    # initialization or not
    collector = UserFactCollector()
    assert collector.name == 'user'
    assert collector._fact_ids == collector._fact_ids

# Generated at 2022-06-23 01:57:05.943294
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user = UserFactCollector()
    expected = ('getpwnam', 'getpwuid', 'getuid', 'geteuid', 'getgid', 'getegid')
    actual = user.collect().keys()
    assert actual == expected

# Generated at 2022-06-23 01:57:07.494659
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fact_collector = UserFactCollector()
    fact_collector.collect()


# Generated at 2022-06-23 01:57:12.248935
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_facts = UserFactCollector()
    assert user_facts.name == 'user'
    assert len(user_facts.priority) == 1
    assert user_facts.priority[0] == 0

# Generated at 2022-06-23 01:57:17.622199
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    userFactCollector = UserFactCollector()
    assert userFactCollector.name == 'user'
    assert len(userFactCollector._fact_ids) == 9

# Generated at 2022-06-23 01:57:25.703813
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    class Arguments(object):
        def __init__(self):
            self.hostname = None
            self.supports_check_mode = False
            self.connection = None

    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect(Arguments())
    assert(user_facts['user_id'] == getpass.getuser())
    assert(user_facts['user_dir'] == pwd.getpwuid(os.getuid()).pw_dir)

# Generated at 2022-06-23 01:57:29.497900
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    ansible_facts = user_fact_collector.collect(module=None, collected_facts=None)
    assert isinstance(ansible_facts, dict)



# Generated at 2022-06-23 01:57:36.754588
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fc = UserFactCollector()
    assert user_fc.name == 'user'
    assert user_fc._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                     'user_gecos', 'user_dir', 'user_shell',
                     'real_user_id', 'effective_user_id',
                     'effective_group_ids'])
    assert isinstance(user_fc.collect(), dict)


# Generated at 2022-06-23 01:57:41.570497
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    obj = UserFactCollector()
    assert obj.name == 'user'
    assert obj._fact_ids == {'user_id', 'user_uid', 'user_gid',
                            'user_gecos', 'user_dir', 'user_shell',
                            'real_user_id', 'effective_user_id',
                            'effective_group_ids'}


# Generated at 2022-06-23 01:57:48.635996
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import mock
    mock_module = mock.Mock()
    mock_module.user_id = "root"
    mock_module.user_uid = "0"
    mock_module.user_gid = "0"
    mock_module.user_gecos = "root"
    mock_module.user_dir = "/root"
    mock_module.user_shell = "/bin/bash"
    mock_module.real_user_id = "0"
    mock_module.effective_user_id = "0"
    mock_module.real_group_id = "0"
    mock_module.effective_group_id = "0"
    collected_facts = UserFactCollector.collect(mock_module)
    assert collected_facts == mock_module

# Generated at 2022-06-23 01:57:59.919294
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    """
    Verify the UserFactCollector can collect several
    user facts correctly.
    """

    # Collect the user facts
    fact_collector = UserFactCollector()
    user_facts = fact_collector.collect()

    # Verify the collected facts
    assert 'user_id' in user_facts
    assert 'user_uid' in user_facts
    assert 'user_gid' in user_facts
    assert 'user_gecos' in user_facts
    assert 'user_dir' in user_facts
    assert 'user_shell' in user_facts
    assert 'real_user_id' in user_facts
    assert 'effective_user_id' in user_facts
    assert 'real_group_id' in user_facts
    assert 'effective_group_id' in user_facts

# Generated at 2022-06-23 01:58:06.399206
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    # Tested method call
    # Create UserFactCollector instance
    user_fact_collector = UserFactCollector()

    # Get user facts
    facts =  user_fact_collector.collect()

    # Check that returned facts is a dictionary
    assert isinstance(facts, dict)

    # Check the content of returned facts
    for expected_fact in user_fact_collector._fact_ids:
        assert expected_fact in facts
        assert facts.get(expected_fact) is not None

# Generated at 2022-06-23 01:58:08.826561
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collector = UserFactCollector()
    user_facts = collector.collect()
    assert isinstance(user_facts, dict)


# Generated at 2022-06-23 01:58:14.236610
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    obj = UserFactCollector()
    assert obj.name == 'user'
    assert obj._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                 'user_gecos', 'user_dir', 'user_shell',
                                 'real_user_id', 'effective_user_id',
                                 'effective_group_ids'])


# Generated at 2022-06-23 01:58:24.970296
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_collector = UserFactCollector()
    collected_facts = user_collector.collect()

    assert collected_facts['user_id'] == getpass.getuser()
    assert collected_facts['user_uid'] == pwd.getpwnam(getpass.getuser()).pw_uid
    assert collected_facts['user_gid'] == pwd.getpwnam(getpass.getuser()).pw_gid
    assert collected_facts['user_gecos'] == pwd.getpwnam(getpass.getuser()).pw_gecos
    assert collected_facts['user_dir'] == pwd.getpwnam(getpass.getuser()).pw_dir
    assert collected_facts['user_shell'] == pwd.getpwnam(getpass.getuser()).pw

# Generated at 2022-06-23 01:58:34.673983
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector()

# Generated at 2022-06-23 01:58:38.642742
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    # getpass.getuser should return something
    assert getpass.getuser()

    # pwent should return something
    assert pwd.getpwnam(getpass.getuser())

    try:
        UserFactCollector()
    except TypeError:
        assert False, "UserFactCollector() failed"
    except:
        assert True, "UserFactCollector() failed due to unexpected exception, should throw TypeError"

# Generated at 2022-06-23 01:58:41.884706
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    test_user_fact_collector = UserFactCollector()
    test_user_fact_collector = test_user_fact_collector.collect()
    assert type(test_user_fact_collector) is dict
    assert test_user_fact_collector != {}

# Generated at 2022-06-23 01:58:44.201775
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    """
    UserFactCollector.collect is tested indirectly through the inclusion
    of the user fact module in a playbook run. There is no explicit test for
    this class.
    """
    pass

# Generated at 2022-06-23 01:58:48.427759
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    obj = UserFactCollector()
    assert obj.name == 'user'
    assert obj._fact_ids == set(['user_id', 'user_uid', 'user_gid', 'user_gecos',
                                 'user_dir', 'user_shell', 'real_user_id',
                                 'effective_user_id', 'effective_group_ids'])


# Generated at 2022-06-23 01:58:57.364017
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    class FakeModule():
        def __init__(self):
            self.params = {}

        def exit_json(self, **kwargs):
            self.exit_json_args = kwargs
            return

        def fail_json(self, **kwargs):
            self.fail_json_args = kwargs
            return

    class FakeCollector():
        def __init__(self):
            return

        def collect(self, module=None, collected_facts=None):
            self.collected_facts = collected_facts
            return {}

    module = FakeModule()
    user_fact_collector = UserFactCollector()
    user_fact_collector.collect(module=module, collected_facts="")
    assert user_fact_collector.name == 'user'
    assert user_fact_collector._fact_

# Generated at 2022-06-23 01:59:05.931890
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    constructor_test = UserFactCollector()
    assert constructor_test.name == "user"
    assert constructor_test._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                              'user_gecos', 'user_dir', 'user_shell',
                                              'real_user_id', 'effective_user_id',
                                              'effective_group_ids'])


# Generated at 2022-06-23 01:59:10.046814
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    x = UserFactCollector()
    assert x.name == 'user'
    assert x._fact_ids == {'user_id', 'user_uid', 'user_gid',
                           'user_gecos', 'user_dir', 'user_shell',
                           'real_user_id', 'effective_user_id',
                           'effective_group_ids'}

# Generated at 2022-06-23 01:59:20.315462
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    # Create collector without parameters
    factCollector = UserFactCollector()

    # Copy of all user data
    user = pwd.getpwnam(getpass.getuser())

    # Create a copy of user data with changed values for testing
    wrong_user = pwd.getpwnam(getpass.getuser())
    wrong_user = list(wrong_user)
    wrong_user[0] = 'Wrong user'
    wrong_user[2] = 'Wrong uid'
    wrong_user[3] = 'Wrong gid'
    wrong_user[4] = 'Wrong gecos'
    wrong_user[5] = 'Wrong dir'
    wrong_user[6] = 'Wrong shell'

    # Check for correct user data
    assert factCollector.collect()['user_id']

# Generated at 2022-06-23 01:59:23.755927
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    t_UserFactCollector = UserFactCollector()
    assert t_UserFactCollector.name == 'user'
    assert len(t_UserFactCollector._fact_ids) == 9


# Generated at 2022-06-23 01:59:31.099456
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert user_fact_collector.name == 'user'
    assert user_fact_collector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                                 'user_gecos', 'user_dir', 'user_shell',
                                                 'real_user_id', 'effective_user_id',
                                                 'effective_group_ids'])


# Generated at 2022-06-23 01:59:31.643750
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    pass

# Generated at 2022-06-23 01:59:38.147446
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ufc = UserFactCollector()

    assert ufc.name == 'user'
    assert isinstance(ufc._fact_ids, set)
    assert 'user_id' in ufc._fact_ids
    assert 'user_uid' in ufc._fact_ids
    assert 'user_gid' in ufc._fact_ids
    assert 'user_gecos' in ufc._fact_ids
    assert 'user_dir' in ufc._fact_ids
    assert 'user_shell' in ufc._fact_ids
    assert 'effective_user_id' in ufc._fact_ids
    assert 'effective_group_ids' in ufc._fact_ids


# Generated at 2022-06-23 01:59:43.447379
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector().collect()
    assert user_facts['user_id'] == getpass.getuser()
    try:
        pwent = pwd.getpwnam(getpass.getuser())
    except KeyError:
        pwent = pwd.getpwuid(os.getuid())

    assert user_facts['user_uid'] == pwent.pw_uid
    assert user_facts['user_gid'] == pwent.pw_gid
    assert user_facts['user_gecos'] == pwent.pw_gecos
    assert user_facts['user_dir'] == pwent.pw_dir
    assert user_facts['user_shell'] == pwent.pw_shell
    assert user_facts['real_user_id'] == os.getuid()
    assert user

# Generated at 2022-06-23 01:59:50.657514
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    userfacts = UserFactCollector()
    assert userfacts.name == 'user'
    assert userfacts._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                       'user_gecos', 'user_dir', 'user_shell',
                                       'real_user_id', 'effective_user_id',
                                       'effective_group_ids'])

# Generated at 2022-06-23 01:59:58.682190
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert user_fact_collector.name == 'user'
    assert user_fact_collector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                                 'user_gecos', 'user_dir', 'user_shell',
                                                 'real_user_id', 'effective_user_id',
                                                 'effective_group_ids'])

# Generated at 2022-06-23 02:00:01.404418
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_facts = UserFactCollector()
    print(user_facts)
    print(user_facts.name)
    print(user_facts._fact_ids)

# Generated at 2022-06-23 02:00:03.299618
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    collector = UserFactCollector()
    assert collector is not None


# Generated at 2022-06-23 02:00:10.150711
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    fake_module = False
    fake_facts = False

    ufc = UserFactCollector(fake_module, {}, fake_facts)
    assert ufc.name == 'user'
    assert ufc._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                 'user_gecos', 'user_dir', 'user_shell',
                                 'real_user_id', 'effective_user_id',
                                 'effective_group_ids'])

# Generated at 2022-06-23 02:00:11.452302
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    print(ufc.collect())

# Generated at 2022-06-23 02:00:23.013972
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    user_facts = ufc.collect()
    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['user_uid'] == pwd.getpwnam(getpass.getuser()).pw_uid
    assert user_facts['user_gid'] == pwd.getpwnam(getpass.getuser()).pw_gid
    assert user_facts['user_gecos'] == pwd.getpwnam(getpass.getuser()).pw_gecos
    assert user_facts['user_dir'] == pwd.getpwnam(getpass.getuser()).pw_dir
    assert user_facts['user_shell'] == pwd.getpwnam(getpass.getuser()).pw_shell
   