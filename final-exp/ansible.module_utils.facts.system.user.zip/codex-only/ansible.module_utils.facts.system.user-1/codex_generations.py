

# Generated at 2022-06-23 01:50:24.631004
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    x = UserFactCollector()
    collected_facts = x.collect()

    assert 'user_id' in collected_facts

    assert 'user_uid' in collected_facts

    assert 'user_gid' in collected_facts

    assert 'user_gecos' in collected_facts

    assert 'user_dir' in collected_facts

    assert 'user_shell' in collected_facts

    assert 'real_user_id' in collected_facts

    assert 'effective_user_id' in collected_facts

    assert 'effective_group_ids' in collected_facts

# Generated at 2022-06-23 01:50:32.188309
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert user_fact_collector.name == 'user'
    assert user_fact_collector.priority == 80
    assert user_fact_collector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                                 'user_gecos', 'user_dir', 'user_shell',
                                                 'real_user_id', 'effective_user_id',
                                                 'effective_group_ids'])


# Generated at 2022-06-23 01:50:37.677014
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    result = UserFactCollector().collect(collected_facts=None)
    assert sorted(result.keys()) == sorted(['user_id', 'user_uid', 'user_gid',
                                            'user_gecos', 'user_dir',
                                            'user_shell', 'real_user_id',
                                            'effective_user_id', 'real_group_id',
                                            'effective_group_id'])
    assert getpass.getuser() == result['user_id']

# Generated at 2022-06-23 01:50:41.654044
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    c = UserFactCollector()
    assert c.name == 'user'
    assert c._fact_ids == set(['user_id', 'user_uid', 'user_gid', 'user_gecos',
                               'user_dir', 'user_shell', 'real_user_id',
                               'effective_user_id', 'effective_group_ids'])


# Generated at 2022-06-23 01:50:50.249668
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = {}
    user_facts['user_id'] = getpass.getuser()
    try:
        pwent = pwd.getpwnam(getpass.getuser())
    except KeyError:
        pwent = pwd.getpwuid(os.getuid())

    user_facts['user_uid'] = pwent.pw_uid
    user_facts['user_gid'] = pwent.pw_gid
    user_facts['user_gecos'] = pwent.pw_gecos
    user_facts['user_dir'] = pwent.pw_dir
    user_facts['user_shell'] = pwent.pw_shell
    user_facts['real_user_id'] = os.getuid()
    user_facts['effective_user_id'] = os.geteu

# Generated at 2022-06-23 01:50:51.853934
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_collector = UserFactCollector()
    assert user_collector.name == 'user'

# Generated at 2022-06-23 01:50:56.832174
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    assert UserFactCollector.name == 'user'

    assert UserFactCollector._fact_ids == {
        'user_id', 'user_uid', 'user_gid',
        'user_gecos', 'user_dir', 'user_shell',
        'real_user_id', 'effective_user_id',
        'effective_group_ids'}

# Generated at 2022-06-23 01:50:58.452836
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    assert type(user_fact_collector.collect()) is dict

# Generated at 2022-06-23 01:51:04.717667
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact = UserFactCollector()
    collected_facts = user_fact.collect()

    assert len(collected_facts) > 0
    assert 'user_id' in collected_facts
    assert 'user_uid' in collected_facts
    assert 'user_gid' in collected_facts
    assert 'user_gecos' in collected_facts
    assert 'user_dir' in collected_facts
    assert 'user_shell' in collected_facts
    assert 'real_user_id' in collected_facts
    assert 'effective_user_id' in collected_facts
    assert 'real_group_id' in collected_facts
    assert 'effective_group_id' in collected_facts

# Generated at 2022-06-23 01:51:09.718675
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    x = UserFactCollector()
    assert x
    assert x.name == "user"
    assert x._fact_ids == set(['user_id', 'user_uid', 'user_gid', 'user_gecos', 'user_dir', 'user_shell', 'real_user_id', 'effective_user_id', 'effective_group_ids'])



# Generated at 2022-06-23 01:51:13.097128
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ufc = UserFactCollector()
    assert ufc.name == 'user'
    # facts collected by user
    asse

# Generated at 2022-06-23 01:51:21.881573
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    pwd_mock = {
        'pw_uid': 'test_uid',
        'pw_gid': 'test_gid',
        'pw_gecos': 'test_gecos',
        'pw_dir': 'test_dir',
        'pw_shell': 'test_shell'
    }
    getpwnam_mock = MagicMock(return_value=pwd_mock)
    getpwuid_mock = MagicMock(return_value=pwd_mock)


# Generated at 2022-06-23 01:51:28.270350
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user = UserFactCollector()
    result = user.collect()

    assert isinstance(result, dict)
    assert 'user_id' in result
    assert 'user_uid' in result
    assert 'user_gid' in result
    assert 'user_gecos' in result
    assert 'user_dir' in result
    assert 'user_shell' in result
    assert 'real_user_id' in result
    assert 'effective_user_id' in result
    assert 'effective_group_ids' in result

# Generated at 2022-06-23 01:51:29.617505
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    userFactCollector = UserFactCollector()
    assert userFactCollector is not None

# Generated at 2022-06-23 01:51:36.330534
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import collect_subset

    # UserFactCollector inherits from BaseFactCollector
    isinstance(UserFactCollector(), BaseFactCollector)

    # UserFactCollector has a method 'collect'
    hasattr(UserFactCollector, "collect")

    # Create an UserFactCollector object
    user_fact_collector = UserFactCollector()

    # Create an empty dict, to be used to pass collected_facts to collect_subset
    collected_facts = {}

    # Create some test facts

# Generated at 2022-06-23 01:51:43.122636
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert user_fact_collector
    assert user_fact_collector.name == 'user'
    assert user_fact_collector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                                 'user_gecos', 'user_dir', 'user_shell',
                                                 'real_user_id', 'effective_user_id',
                                                 'effective_group_ids'])


# Generated at 2022-06-23 01:51:45.969164
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    facts = ufc.collect()
    assert facts['user_id'] == getpass.getuser()

# Generated at 2022-06-23 01:51:52.638499
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    obj = UserFactCollector()
    assert obj.name == "user"
    assert obj._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                 'user_gecos', 'user_dir', 'user_shell',
                                 'real_user_id', 'effective_user_id',
                                 'effective_group_ids'])

# Generated at 2022-06-23 01:52:04.313412
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()
    if not user_facts['user_id']:
        raise AssertionError('user_id must be non-empty')
    if not user_facts['user_uid']:
        raise AssertionError('user_uid must be non-empty')
    if not user_facts['user_gid']:
        raise AssertionError('user_gid must be non-empty')
    if not user_facts['user_gecos']:
        raise AssertionError('user_gecos must be non-empty')
    if not user_facts['user_dir']:
        raise AssertionError('user_dir must be non-empty')
    if not user_facts['user_shell']:
        raise Ass

# Generated at 2022-06-23 01:52:09.734004
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    obj = UserFactCollector()
    assert obj.name == 'user'
    assert obj._fact_ids == {'user_id', 'user_uid', 'user_gid',
                             'user_gecos', 'user_dir', 'user_shell',
                             'real_user_id', 'effective_user_id',
                             'effective_group_ids'}


# Generated at 2022-06-23 01:52:21.313413
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    collected_facts = user_fact_collector.collect()
    assert type(collected_facts) == dict
    assert collected_facts['user_uid'] == pwd.getpwuid(os.getuid()).pw_uid
    assert collected_facts['user_id'] == getpass.getuser()
    assert collected_facts['user_gid'] == pwd.getpwuid(os.getuid()).pw_gid
    assert collected_facts['user_gecos'] == pwd.getpwuid(os.getuid()).pw_gecos
    assert collected_facts['user_dir'] == pwd.getpwuid(os.getuid()).pw_dir
    assert collected_facts['user_shell'] == pwd.getp

# Generated at 2022-06-23 01:52:31.747602
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
  # test instantiation of collector with no params
  ufc = UserFactCollector()
  assert ufc.name == 'user'
  assert ufc.fact_ids == {'user_id', 'user_uid', 'user_gid',
                     'user_gecos', 'user_dir', 'user_shell',
                     'real_user_id', 'effective_user_id',
                     'effective_group_ids'}
  # test instantiation of collector with params
  ufc = UserFactCollector(['name', 'user_uid'])
  assert ufc.name == 'user'
  assert ufc.fact_ids == {'name', 'user_uid'}


# Generated at 2022-06-23 01:52:32.333972
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    pass

# Generated at 2022-06-23 01:52:32.925680
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    pass

# Generated at 2022-06-23 01:52:39.368996
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_facts = UserFactCollector()

    assert user_facts.name == 'user'
    assert user_facts._fact_ids == set(['user_id', 'user_uid', 'user_gid', 
        'user_gecos', 'user_dir', 'user_shell', 'real_user_id', 
        'effective_user_id', 'effective_group_ids'])


# Generated at 2022-06-23 01:52:47.990605
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Create an object of class UserFactCollector
    ufc = UserFactCollector().collect()

    # Assert that the value of user_gid is a number
    assert isinstance(ufc['user_gid'], int)

    # Assert that the value of user_uid is a number
    assert isinstance(ufc['user_uid'], int)

    # Assert that the value of real_user_id is a number
    assert isinstance(ufc['real_user_id'], int)

    # Assert that the value of effective_user_id is a number
    assert isinstance(ufc['effective_user_id'], int)

    # Assert that the value of effective_group_id is a number
    assert isinstance(ufc['effective_group_id'], int)

    # Assert that the

# Generated at 2022-06-23 01:52:51.014518
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    result_dic = user_fact_collector.collect()
    #print(result_dic)


# Generated at 2022-06-23 01:52:52.898471
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    x = UserFactCollector()
    assert x.name == 'user'


# Generated at 2022-06-23 01:53:01.052764
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_collector = UserFactCollector()
    facts_dictionary = user_collector.collect()
    assert type(facts_dictionary) is dict
    assert facts_dictionary["user_id"]
    assert facts_dictionary["user_uid"]
    assert facts_dictionary["user_gid"]
    assert facts_dictionary["user_gecos"]
    assert facts_dictionary["user_dir"]
    assert facts_dictionary["user_shell"]
    assert facts_dictionary["real_user_id"]
    assert facts_dictionary["effective_user_id"]
    assert facts_dictionary["real_group_id"]
    assert facts_dictionary["effective_group_id"]


# Generated at 2022-06-23 01:53:05.438884
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    fact_collector = UserFactCollector()
    assert fact_collector.name == 'user'
    assert fact_collector._fact_ids == {'user_id', 'user_uid', 'user_gid',
                                        'user_gecos', 'user_dir', 'user_shell',
                                        'real_user_id', 'effective_user_id',
                                        'effective_group_ids'}

# Generated at 2022-06-23 01:53:15.728496
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    test_obj = UserFactCollector()
    test_obj._module = None
    test_obj._collect_subset = []
    test_obj._collected_facts = {}

    # Test idempotence
    result = test_obj.collect()
    assert result == {'user_id': 'user1',
                      'user_uid': 1000,
                      'user_gid': 1000,
                      'user_gecos': 'user1,,,',
                      'user_dir': '/var/lib/user1',
                      'user_shell': '/bin/bash',
                      'real_user_id': 1000,
                      'effective_user_id': 1000,
                      'real_group_id': 1000,
                      'effective_group_id': 1000}

# Generated at 2022-06-23 01:53:25.272242
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.system import linux

    facts_dict = {
        'distribution': {
            'distribution': 'Linux'
        }
    }

    def get_distribution_facts(module=None, collected_facts=None):
        return facts_dict['distribution']

    linux.LinuxDistribution.collect = get_distribution_facts

    def get_system_facts(module=None, collected_facts=None):
        return facts_dict['system']

    linux.LinuxSystem.collect = get_system_facts

    user_facts = UserFactCollector()

    result = user_facts.collect(None, facts_dict)

    assert(result['user_id'] == getpass.getuser())

# Generated at 2022-06-23 01:53:35.879436
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    """ Unit test for UserFactCollector.collect() """

    class MockUserFactCollector(UserFactCollector):
        def __init__(self):
            self.test_fact_ids = set([])
            self.test_facts = dict()

        def collect(self, module_name=None, collected_facts=None):
            self.test_fact_ids = self._fact_ids
            self.test_facts = super(MockUserFactCollector, self).collect()

    # Create mock object
    user_fact_collector = MockUserFactCollector()

    # Test collect method
    # Check if the proper set of fact names are returned
    user_fact_collector.collect()

# Generated at 2022-06-23 01:53:41.429578
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    fact_collector = UserFactCollector()
    assert fact_collector.name == 'user'
    assert fact_collector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                            'user_gecos', 'user_dir', 'user_shell',
                                            'real_user_id', 'effective_user_id',
                                            'effective_group_ids'])


# Generated at 2022-06-23 01:53:50.350269
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils._text import to_bytes
    fake_fact_cache = {u'os_key': u'os_value',
                       u'user_id': u'test_user'}
    facts = Facts(fake_fact_cache)
    collect_func = UserFactCollector.collect
    result = collect_func(collector=UserFactCollector(),
                          module=None, collected_facts=facts)
    assert isinstance(result, dict)
    assert isinstance(result['user_id'], to_bytes)
    assert result['user_id'] == u'test_user'

# Generated at 2022-06-23 01:53:53.705924
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    x = UserFactCollector()
    assert x.name == 'user'
    assert len(x._fact_ids) == 9

# Generated at 2022-06-23 01:53:55.818399
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    print(user_fact_collector.collect())

# Generated at 2022-06-23 01:54:03.339217
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    facts = ufc.collect()

    assert isinstance(facts,dict)
    assert 'user_id' in facts
    assert 'user_uid' in facts
    assert 'user_gid' in facts
    assert 'user_gecos' in facts
    assert 'user_dir' in facts
    assert 'user_shell' in facts
    assert 'real_user_id' in facts
    assert 'effective_user_id' in facts
    assert 'real_group_id' in facts
    assert 'effective_group_id' in facts

# Generated at 2022-06-23 01:54:09.795418
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ufc = UserFactCollector()

    assert ufc.name == 'user'
    assert isinstance(ufc._fact_ids, set)
    assert ufc._fact_ids == {'user_id', 'user_uid', 'user_gid',
                             'user_gecos', 'user_dir', 'user_shell',
                             'real_user_id', 'effective_user_id',
                             'effective_group_ids'}


# Generated at 2022-06-23 01:54:12.622005
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
  assert UserFactCollector(None).name == 'user'
  assert isinstance(UserFactCollector(None)._fact_ids, set)



# Generated at 2022-06-23 01:54:23.498239
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fact_collector = UserFactCollector()
    fact_collector.collect()
    user_facts = fact_collector.collect()

    assert user_facts['user_id'] is not None
    assert user_facts['user_uid'] is not None
    assert user_facts['user_gid'] is not None
    assert user_facts['user_gecos'] is not None
    assert user_facts['user_dir'] is not None
    assert user_facts['user_shell'] is not None
    assert user_facts['real_user_id'] is not None
    assert user_facts['effective_user_id'] is not None
    assert user_facts['effective_group_ids'] is not None

    assert(user_facts['user_uid'] == os.getuid())

# Generated at 2022-06-23 01:54:26.857545
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    assert UserFactCollector.name == 'user'
    assert UserFactCollector.priority == 80


# Generated at 2022-06-23 01:54:36.533747
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    actual = Collector().collect(module=None, collected_facts=None)
    assert 'ansible_user_id' in actual, actual
    assert 'ansible_user_uid' in actual, actual
    assert 'ansible_user_gid' in actual, actual
    assert 'ansible_user_gecos' in actual, actual
    assert 'ansible_user_dir' in actual, actual
    assert 'ansible_user_shell' in actual, actual
    assert 'ansible_real_user_id' in actual, actual
    assert 'ansible_effective_user_id' in actual, actual
    assert 'ansible_real_group_id' in actual, actual
    assert 'ansible_effective_group_id' in actual, actual

# Generated at 2022-06-23 01:54:40.931530
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_facts_collector = UserFactCollector()
    assert user_facts_collector.name == 'user'
    assert user_facts_collector.filename == 'user'
    assert user_facts_collector.priority == 10

# Generated at 2022-06-23 01:54:45.872213
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector_ins = UserFactCollector()
    assert user_fact_collector_ins.name == 'user'
    assert user_fact_collector_ins._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                     'user_gecos', 'user_dir', 'user_shell',
                     'real_user_id', 'effective_user_id',
                     'effective_group_ids'])

# Generated at 2022-06-23 01:54:54.969278
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    from ansible.module_utils.facts.collector import Collector

    # Get instance of UserFactCollector class
    user_facts_collector = UserFactCollector()

    # Check class of user_facts_collector
    assert(isinstance(user_facts_collector, Collector))

    # Check public attribute name
    assert(user_facts_collector.name == 'user')

    # Check private attribute _fact_ids
    assert(user_facts_collector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                                  'user_gecos', 'user_dir', 'user_shell',
                                                  'real_user_id', 'effective_user_id',
                                                  'effective_group_ids']))

# Generated at 2022-06-23 01:55:00.583178
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    assert UserFactCollector.name == 'user'
    assert UserFactCollector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                               'user_gecos', 'user_dir', 'user_shell',
                                               'real_user_id', 'effective_user_id',
                                               'effective_group_ids'])


# Generated at 2022-06-23 01:55:07.520283
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user = UserFactCollector()

    # Testing return type
    facts = user.collect()
    assert isinstance(facts, dict)

    # Testing return value
    assert facts['user_id']
    assert facts['user_uid']
    assert facts['user_gid']
    assert facts['user_gecos']
    assert facts['user_dir']
    assert facts['user_shell']
    assert facts['real_user_id']
    assert facts['effective_user_id']
    assert facts['effective_group_id']

# Generated at 2022-06-23 01:55:16.794367
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import platform
    import getpass

    # Create a new instance of UserFactCollector
    user_fact_collector = UserFactCollector()

    # Collect Facts
    facts = user_fact_collector.collect()

    # Parse the facts
    user_id = facts['user_id']
    user_uid = facts['user_uid']
    user_gid = facts['user_gid']
    user_gecos = facts['user_gecos']
    user_dir = facts['user_dir']
    user_shell = facts['user_shell']
    real_user_id = facts['real_user_id']
    effective_user_id = facts['effective_user_id']
    effective_group_ids = facts['effective_group_ids']

    #########
    # Tests #
    #########

    #

# Generated at 2022-06-23 01:55:23.854635
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    fact_collector = UserFactCollector()
    assert fact_collector.name == 'user'
    assert fact_collector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                            'user_gecos', 'user_dir', 'user_shell',
                                            'real_user_id', 'effective_user_id',
                                            'effective_group_ids'])


# Generated at 2022-06-23 01:55:25.480756
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    fact_collector = UserFactCollector()
    assert fact_collector.name == 'user'


# Generated at 2022-06-23 01:55:34.665845
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    """Return a set of facts from the UserFactCollector class."""
    user_facts = UserFactCollector().collect()
    assert user_facts['user_id'] is not None
    assert user_facts['user_uid'] is not None
    assert user_facts['user_gid'] is not None
    assert user_facts['user_gecos'] is not None
    assert user_facts['user_dir'] is not None
    assert user_facts['user_shell'] is not None
    assert user_facts['real_user_id'] is not None
    assert user_facts['effective_user_id'] is not None
    assert user_facts['real_group_id'] is not None
    assert user_facts['effective_group_id'] is not None

# Generated at 2022-06-23 01:55:40.723065
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    test_instance = UserFactCollector()

    assert test_instance.name == 'user'
    assert test_instance._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                     'user_gecos', 'user_dir', 'user_shell',
                     'real_user_id', 'effective_user_id',
                     'effective_group_ids'])



# Generated at 2022-06-23 01:55:43.112760
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    x = UserFactCollector()
    assert x
    assert x.name == 'user'
    assert 'user_id' in x._fact_ids

# Generated at 2022-06-23 01:55:54.365767
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()

# Generated at 2022-06-23 01:56:04.127167
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    mod = UserFactCollector()
    result = mod.collect()
    assert result is not None
    assert result['user_id'] is not None
    assert result['user_uid'] is not None
    assert result['user_gid'] is not None
    assert result['user_gecos'] is not None
    assert result['user_dir'] is not None
    assert result['user_shell'] is not None
    assert result['real_user_id'] is not None
    assert result['effective_user_id'] is not None
    assert result['effective_group_ids'] is not None

# Generated at 2022-06-23 01:56:09.373742
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    collector = UserFactCollector()

    assert collector.name == 'user'
    assert collector.fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                      'user_gecos', 'user_dir', 'user_shell',
                                      'real_user_id', 'effective_user_id',
                                      'effective_group_ids'])

# Generated at 2022-06-23 01:56:12.352524
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    usrFactColl = UserFactCollector()
    print(usrFactColl.collect())


# Generated at 2022-06-23 01:56:22.758408
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_collector = UserFactCollector()
    user_facts = user_collector.collect()

    assert type(user_facts) == dict
    assert user_facts['user_id'] == getpass.getuser()
    assert type(user_facts['user_uid']) == int
    assert type(user_facts['user_gid']) == int
    assert type(user_facts['user_gecos']) == str
    assert type(user_facts['user_dir']) == str
    assert type(user_facts['user_shell']) == str
    assert type(user_facts['real_user_id']) == int
    assert type(user_facts['effective_user_id']) == int
    assert type(user_facts['real_group_id']) == int

# Generated at 2022-06-23 01:56:29.188090
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    collector = UserFactCollector()
    assert collector.name == 'user'
    assert collector.collect() == {
        'user_id': 'root',
        'user_uid': 0,
        'user_gid': 0,
        'user_gecos': 'root',
        'user_dir': '/root',
        'user_shell': '/bin/bash',
        'real_user_id': 0,
        'effective_user_id': 0,
        'real_group_id': 0,
        'effective_group_id': 0,
    }

# Generated at 2022-06-23 01:56:29.869609
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    assert True

# Generated at 2022-06-23 01:56:35.156138
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    fact = UserFactCollector()
    assert fact.name == 'user'
    assert fact._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                     'user_gecos', 'user_dir', 'user_shell',
                     'real_user_id', 'effective_user_id',
                     'effective_group_ids'])


# Generated at 2022-06-23 01:56:36.553126
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    obj = UserFactCollector()
    assert obj


# Generated at 2022-06-23 01:56:48.262465
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    """
    Unit test to collect user facts by calling class UserFactCollector.
    """
    user_facts = {}
    user_info = {}
    ufc = UserFactCollector()
    user_facts = ufc.collect()
    assert user_facts is not None
    assert type(user_facts) is dict
    assert 'real_user_id' in user_facts
    assert type(user_facts['real_user_id']) is int
    assert 'effective_user_id' in user_facts
    assert type(user_facts['effective_user_id']) is int
    assert 'real_group_id' in user_facts
    assert type(user_facts['real_group_id']) is int
    assert 'effective_group_id' in user_facts

# Generated at 2022-06-23 01:56:57.472858
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector()
    test_dict = user_facts.collect()
    assert test_dict.get('effective_group_id') == os.getgid()
    assert test_dict.get('effective_user_id') == os.geteuid()
    assert test_dict.get('real_group_id') == os.getgid()
    assert test_dict.get('real_user_id') == os.getuid()
    assert test_dict.get('user_dir') == pwd.getpwuid(os.getuid()).pw_dir
    assert test_dict.get('user_gecos') == pwd.getpwuid(os.getuid()).pw_gecos

# Generated at 2022-06-23 01:57:02.841355
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_collector = UserFactCollector()
    assert 'user' == user_collector.name
    assert set(['user_id', 'user_uid', 'user_gid', 'user_gecos', 'user_dir',
                'user_shell', 'real_user_id', 'effective_user_id',
                'effective_group_ids']) == user_collector._fact_ids

# Generated at 2022-06-23 01:57:05.994528
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()

    assert set(user_facts) == user_fact_collector._fact_ids

# Generated at 2022-06-23 01:57:10.807317
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    collected_facts = user_fact_collector.collect()
    assert(collected_facts['user_id'] == getpass.getuser())

# Generated at 2022-06-23 01:57:17.507216
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import os
    import sys

    # fake the presence of a system user
    os.environ['USER'] = 'n'
    os.environ['LOGNAME'] = 'n'

    collector = UserFactCollector()
    facts = collector.collect(collected_facts={})

    assert type(facts) == dict
    assert facts['user_id'] == 'n'
    assert facts['user_uid'] == os.getuid()
    assert facts['user_gid'] == os.getgid()
    assert facts['user_gecos'] == pwd.getpwuid(os.getuid()).pw_gecos
    assert facts['user_dir'] == pwd.getpwuid(os.getuid()).pw_dir

# Generated at 2022-06-23 01:57:23.995439
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
  v = UserFactCollector()
  assert v.name == 'user'
  assert v._fact_ids == {'user_id', 'user_uid', 'user_gid',
                     'user_gecos', 'user_dir', 'user_shell',
                     'real_user_id', 'effective_user_id',
                     'effective_group_ids'}

# Generated at 2022-06-23 01:57:27.644343
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    assert('ansible' in ufc.collect().get('user_id'))

# Generated at 2022-06-23 01:57:35.347204
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    UserFactCollector = UserFactCollector()
    UserFactCollector.collect()
    assert UserFactCollector.user_id
    assert UserFactCollector.user_uid
    assert UserFactCollector.user_gid
    assert UserFactCollector.user_gecos
    assert UserFactCollector.user_dir
    assert UserFactCollector.user_shell
    assert UserFactCollector.real_user_id
    assert UserFactCollector.effective_user_id
    assert UserFactCollector.effective_group_ids

# Generated at 2022-06-23 01:57:42.850608
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    """ Test collect method of user fact collector
    """

    # Test collect method
    collector = UserFactCollector()
    user_facts = collector.collect(collected_facts=None)
    assert 'user_id' in user_facts
    assert 'user_uid' in user_facts
    assert 'user_gid' in user_facts
    assert 'user_gecos' in user_facts
    assert 'user_dir' in user_facts
    assert 'user_shell' in user_facts
    assert 'real_user_id' in user_facts
    assert 'effective_user_id' in user_facts
    assert 'effective_group_ids' in user_facts

# Generated at 2022-06-23 01:57:44.421000
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    UserFactCollector()


# Generated at 2022-06-23 01:57:52.915448
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()

    user_facts = ufc.collect()

    assert 'user_id' in user_facts
    assert 'user_uid' in user_facts
    assert 'user_gid' in user_facts
    assert 'user_gecos' in user_facts
    assert 'user_dir' in user_facts
    assert 'user_shell' in user_facts
    assert 'real_user_id' in user_facts
    assert 'effective_user_id' in user_facts
    assert 'real_group_id' in user_facts
    assert 'effective_group_id' in user_facts

# Generated at 2022-06-23 01:57:58.940878
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()

    assert user_facts['user_id']
    assert user_facts['user_uid']
    assert user_facts['user_gid']
    assert user_facts['user_gecos']
    assert user_facts['user_dir']
    assert user_facts['user_shell']
    assert user_facts['real_user_id']
    assert user_facts['effective_user_id']
    assert user_facts['real_group_id']
    assert user_facts['effective_group_id']

# Generated at 2022-06-23 01:58:03.480416
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    c = UserFactCollector()
    assert c.name == 'user'
    assert c._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                     'user_gecos', 'user_dir', 'user_shell',
                     'real_user_id', 'effective_user_id',
                     'effective_group_ids']), c._fact_ids


# Generated at 2022-06-23 01:58:09.950234
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user = UserFactCollector()
    assert user.name == 'user'
    assert user._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                  'user_gecos', 'user_dir', 'user_shell',
                                  'real_user_id', 'effective_user_id',
                                  'effective_group_ids'])

# Generated at 2022-06-23 01:58:16.030188
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    u = UserFactCollector()
    real_uid = os.getuid()
    facts = u.collect()
    # test facts are dict with expected keys
    assert all([k in facts for k in ('user_id', 'user_uid', 'user_gid',
                                     'user_gecos', 'user_shell',
                                     'real_user_id', 'real_group_id',
                                     'effective_user_id', 'effective_group_id',
                                     'user_dir')])
    # test facts are true and not empty

# Generated at 2022-06-23 01:58:20.875004
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    from ansible.module_utils.facts import FactCollector

    ufc = UserFactCollector()
    facts = ufc.collect(None, None)

    assert isinstance(facts, dict)
    assert isinstance(facts['user_id'], (str, unicode))
    assert isinstance(facts['user_uid'], int)

# Generated at 2022-06-23 01:58:28.807082
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    module = None
    collected_facts = None
    user_fact_collector = UserFactCollector()
    res = user_fact_collector.collect()
    assert(res['user_id'])
    assert(res['user_uid'])
    assert(res['user_gid'])
    assert(res['user_gecos'])
    assert(res['user_dir'])
    assert(res['user_shell'])
    assert(res['real_user_id'])
    assert(res['effective_user_id'])
    assert(res['real_group_id'])
    assert(res['effective_group_id'])

# Generated at 2022-06-23 01:58:34.602655
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    userFactCollector = UserFactCollector()
    assert userFactCollector.name == 'user'
    assert userFactCollector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                     'user_gecos', 'user_dir', 'user_shell',
                     'real_user_id', 'effective_user_id',
                     'effective_group_ids'])


# Generated at 2022-06-23 01:58:37.147892
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    """
    Unit test for constructor of class UserFactCollector
    """
    # Test the constructor
    UserFactCollector()
    # Expected
    # Should no throw exception


# Generated at 2022-06-23 01:58:46.185868
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect(collected_facts={})
    assert user_fact_collector.name in user_facts
    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['user_uid'] == os.getuid()
    assert user_facts['user_gid'] == os.getgid()
    assert user_facts['user_gecos'] is not None
    assert user_facts['user_dir'] is not None
    assert user_facts['user_shell'] is not None
    assert user_facts['real_user_id'] == os.getuid()
    assert user_facts['effective_user_id'] == os.geteuid()

# Generated at 2022-06-23 01:58:48.082007
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert user_fact_collector.name == 'user' # Test __init__()

# Generated at 2022-06-23 01:58:54.641669
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():

    # Create a UserFactCollector object
    user_cl = UserFactCollector()

    # Check the name
    assert user_cl.name == 'user', "name should be 'user'"

    # Check the _fact_ids
    assert set(user_cl._fact_ids) == {'user_id', 'user_uid', 'user_gid',
                                      'user_gecos', 'user_dir', 'user_shell',
                                      'real_user_id', 'effective_user_id',
                                      'effective_group_ids'}

# Generated at 2022-06-23 01:59:00.905321
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector

    try:
        user_name = getpass.getuser()
        user_id = pwd.getpwnam(getpass.getuser()).pw_uid
        user_gid = pwd.getpwnam(getpass.getuser()).pw_gid
    except KeyError:
        user_name = pwd.getpwuid(os.getuid()).pw_name
        user_id = os.getuid()
        user_gid = os.getgid()

    user_dir = pwd.getpwnam(getpass.getuser()).pw_dir
    user_shell = pwd.getpwnam(getpass.getuser()).pw_shell


# Generated at 2022-06-23 01:59:02.880551
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    fact = UserFactCollector()
    assert fact.name == 'user'

# Generated at 2022-06-23 01:59:05.838088
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    collected_facts = user_fact_collector.collect()

    for fact in user_fact_collector._fact_ids:
        assert fact in collected_facts

# Generated at 2022-06-23 01:59:12.200360
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()
    assert user_facts is not None
    assert 'user_gid' in user_facts
    assert 'user_gecos' in user_facts
    assert 'user_uid' in user_facts
    assert 'user_shell' in user_facts
    assert 'real_group_id' in user_facts
    assert 'real_user_id' in user_facts
    assert 'effective_group_id' in user_facts
    assert 'effective_user_id' in user_facts
    assert 'user_id' in user_facts

# Generated at 2022-06-23 01:59:12.926333
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    UserFactCollector()


# Generated at 2022-06-23 01:59:15.311832
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collector = UserFactCollector()
    assert collector.collect()['user_id'] == getpass.getuser()

# Generated at 2022-06-23 01:59:26.831581
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    user_facts = ufc.collect()

    assert len(user_facts) == 8
    assert user_facts['user_id'] == getpass.getuser()
    assert type(user_facts['user_uid']) is int
    assert type(user_facts['user_gid']) is int
    assert type(user_facts['user_gecos']) is str
    assert type(user_facts['user_dir']) is str
    assert type(user_facts['user_shell']) is str
    assert type(user_facts['real_user_id']) is int
    assert type(user_facts['effective_user_id']) is int
    assert type(user_facts['real_group_id']) is int

# Generated at 2022-06-23 01:59:30.437595
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ufc = UserFactCollector()
    assert isinstance(ufc, UserFactCollector)
    assert ufc.name == 'user'


# Generated at 2022-06-23 01:59:36.703247
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    module_name = "AnsibleModule"
    argument_spec = {}
    user_fact_collector = UserFactCollector(module_name, argument_spec)
    assert user_fact_collector.name == "user"
    assert user_fact_collector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                     'user_gecos', 'user_dir', 'user_shell',
                     'real_user_id', 'effective_user_id',
                     'effective_group_ids'])

# Generated at 2022-06-23 01:59:42.148207
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user = UserFactCollector()
    assert user.name == 'user'
    assert set(user._fact_ids) == {'user_id', 'user_uid', 'user_gid',
                                   'user_gecos', 'user_dir', 'user_shell',
                                   'real_user_id', 'effective_user_id',
                                   'effective_group_ids'},\
        'member variable "_fact_ids" does not have the right value'

# Generated at 2022-06-23 01:59:53.366273
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Run method `collected_facts` of `UserFactCollector` class
    collector = UserFactCollector()
    collected_facts = collector.collect()

    # If facts were collected successfully, then description of collected facts
    # should be equal to expected description
    expected_facts = """user_id: <user_id>
user_uid: <user_uid>
user_gid: <user_gid>
user_gecos: <user_gecos>
user_dir: <user_dir>
user_shell: <user_shell>
real_user_id: <real_user_id>
effective_user_id: <effective_user_id>
real_group_id: <real_group_id>
effective_group_id: <effective_group_id>"""

    # Get description of collected facts
    collected_

# Generated at 2022-06-23 02:00:05.545286
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    userFactsCollectorObj = UserFactCollector()
    assert userFactsCollectorObj.name == 'user'
    assert 'user_id' in userFactsCollectorObj._fact_ids
    assert 'user_uid' in userFactsCollectorObj._fact_ids
    assert 'user_gid' in userFactsCollectorObj._fact_ids
    assert 'user_gecos' in userFactsCollectorObj._fact_ids
    assert 'user_dir' in userFactsCollectorObj._fact_ids
    assert 'user_shell' in userFactsCollectorObj._fact_ids
    assert 'real_user_id' in userFactsCollectorObj._fact_ids
    assert 'effective_user_id' in userFactsCollectorObj._fact_ids
    assert 'effective_group_ids' in userF

# Generated at 2022-06-23 02:00:11.369166
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    import six
    import os
    import tempfile
    import json

    facts = UserFactCollector().collect(None)
    assert facts['user_id'] == getpass.getuser(), "Failed to set user_id"
    
    # User FactCollector inherits from BaseFactCollector and
    # collect method returns a dictionary of facts.
    assert isinstance(facts, dict), "UserFactCollector collect failed"
    assert not isinstance(facts, list), "UserFactCollector collect failed"
    assert not isinstance(facts, six.string_types), "UserFactCollector collect failed"
    
    #TODO: Add more unit tests for other fact keys

# Generated at 2022-06-23 02:00:22.950855
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    "UserFactCollector.collect() returns a dictionary that has all the user facts."

    import ansible.module_utils.facts.collectors.user as user_collector
    import ansible.module_utils.facts.collectors.system as system_collector

    result = user_collector.UserFactCollector().collect()
