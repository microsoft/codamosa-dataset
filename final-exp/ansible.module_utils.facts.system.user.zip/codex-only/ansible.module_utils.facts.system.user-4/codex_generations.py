

# Generated at 2022-06-23 01:50:22.408710
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ufc = UserFactCollector()
    assert ufc.name == 'user'
    assert ufc._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                 'user_gecos', 'user_dir', 'user_shell',
                                 'real_user_id', 'effective_user_id',
                                 'effective_group_ids'])


# Generated at 2022-06-23 01:50:27.886073
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    # Make sure user_fact_collector.collect() returns a dictionary
    assert isinstance(user_fact_collector.collect(), dict)

# Generated at 2022-06-23 01:50:32.501443
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    fact_list = ['user_id', 'user_uid', 'user_gid',
                 'user_gecos', 'user_dir', 'user_shell',
                 'real_user_id', 'effective_user_id',
                 'effective_group_ids']
    ufc = UserFactCollector()

    assert sorted(ufc._fact_ids) == sorted(fact_list)

# Generated at 2022-06-23 01:50:38.547615
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    def getuid_mock():
        return 'testuid'

    getpass.getuser = getuid_mock
    user = UserFactCollector()
    assert user != None
    assert user.name == 'user'
    assert set(user._fact_ids) == set(['user_id', 'user_uid', 'user_gid',
                                       'user_gecos', 'user_dir', 'user_shell',
                                       'real_user_id', 'effective_user_id',
                                       'effective_group_ids'])


# Generated at 2022-06-23 01:50:42.395048
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ufc = UserFactCollector()
    assert ufc.name == 'user'
    assert ufc._fact_ids == { 'user_id', 'user_uid', 'user_gid', 'user_gecos',
                              'user_dir', 'user_shell', 'real_user_id',
                              'effective_user_id', 'effective_group_ids'}


# Generated at 2022-06-23 01:50:50.669240
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    from ansible.module_utils.facts.collector import FactCollector
    from ansible.module_utils._text import to_bytes

    # UserFactCollector initialization
    user_fact_collector = UserFactCollector()

    # Method collect called to retrieve facts
    user_facts = user_fact_collector.collect()

    # Fail if result is None
    assert user_facts != None

    assert user_facts["user_id"] == getpass.getuser()

    assert "user_uid" in user_facts
    assert isinstance(user_facts["user_uid"], (int, long))

    assert "user_gid" in user_facts
    assert isinstance(user_facts["user_gid"], (int, long))

    assert "user_gecos" in user_facts

# Generated at 2022-06-23 01:50:53.062387
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    result = UserFactCollector().collect()
    assert result is not None
    assert result['user_id'] == getpass.getuser()

# Generated at 2022-06-23 01:50:56.305077
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    class args(object):
        module = None
        collected_facts = None

    # test with args not containing module and collected_facts
    ret = UserFactCollector(args)
    assert isinstance(ret, UserFactCollector)

# Generated at 2022-06-23 01:51:02.356408
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    u = UserFactCollector()

    # Test the name of class
    assert u.name == "user"

    # Test the fact ids
    assert u._fact_ids == {'effective_group_ids',
                           'effective_group_id',
                           'effective_user_id',
                           'real_user_id',
                           'real_group_id',
                           'user_id',
                           'user_gid',
                           'user_uid',
                           'user_gecos',
                           'user_dir',
                           'user_shell'}

# Generated at 2022-06-23 01:51:12.726339
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    myTest = UserFactCollector()
    myTestFacts = myTest.collect()
    assert myTestFacts['user_id'] == getpass.getuser()
    assert myTestFacts['user_uid'] == pwd.getpwuid(os.getuid()).pw_uid
    assert myTestFacts['user_gid'] == pwd.getpwuid(os.getuid()).pw_gid
    assert myTestFacts['user_gecos'] == pwd.getpwuid(os.getuid()).pw_gecos
    assert myTestFacts['user_dir'] == pwd.getpwuid(os.getuid()).pw_dir
    assert myTestFacts['user_shell'] == pwd.getpwuid(os.getuid()).pw_shell

# Generated at 2022-06-23 01:51:16.224555
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    """
    Unit test for method collect of class UserFactCollector
    """
    user_fact_collector = UserFactCollector()
    user_fact_collector.collect()
    assert user_fact_collector.name == 'user'

# Generated at 2022-06-23 01:51:21.284298
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user = UserFactCollector()
    assert set(user._fact_ids) == set(['user_id', 'user_uid', 'user_gid',
                     'user_gecos', 'user_dir', 'user_shell',
                     'real_user_id', 'effective_user_id',
                     'effective_group_ids'])


# Generated at 2022-06-23 01:51:25.533630
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    obj = UserFactCollector()
    assert obj.name == 'user'
    assert obj._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                 'user_gecos', 'user_dir', 'user_shell',
                                 'real_user_id', 'effective_user_id',
                                 'effective_group_ids'])


# Generated at 2022-06-23 01:51:27.405673
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    output = UserFactCollector()
    assert (isinstance(output.collect(), dict))

# Generated at 2022-06-23 01:51:38.119131
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    module = None
    collected_facts = {}
    user_fact_collector = UserFactCollector()

    user_facts = user_fact_collector.collect(module, collected_facts)
    # Verifying if the collected facts are right
    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['user_uid'] == os.getuid()
    assert type(user_facts['user_uid']) == int
    assert user_facts['user_gid'] == os.getgid()
    assert type(user_facts['user_gid']) == int
    assert user_facts['user_gecos'] == pwd.getpwuid(os.getuid()).pw_gecos
    assert 'user_dir' in user_facts
    assert user_facts['user_shell']

# Generated at 2022-06-23 01:51:46.637127
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    """Test method UserFactCollector.collect"""
    collector = UserFactCollector()
    assert collector.collect() == {'user_id': 'ansible',
                                   'user_uid': 1000,
                                   'user_gid': 1000,
                                   'user_gecos': 'Ansible User,,,',
                                   'user_dir': '/home/ansible',
                                   'user_shell': '/bin/bash',
                                   'real_user_id': 1000,
                                   'effective_user_id': 1000,
                                   'real_group_id': 1000,
                                   'effective_group_id': 1000,
                                   }

# Generated at 2022-06-23 01:51:56.536317
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collector = UserFactCollector()
    collected_facts = collector.collect()

    assert isinstance(collected_facts, dict)
    assert 'user_id' in collected_facts
    assert 'user_uid' in collected_facts
    assert 'user_gid' in collected_facts
    assert 'user_gecos' in collected_facts
    assert 'user_dir' in collected_facts
    assert 'user_shell' in collected_facts
    assert 'real_user_id' in collected_facts
    assert 'effective_user_id' in collected_facts
    assert 'effective_group_ids' in collected_facts

# vim: set et ts=4 sw=4 :

# Generated at 2022-06-23 01:52:00.482478
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()

    # test normal case
    try:
        user_fact_collector.collect()
    except:
        assert False



# Generated at 2022-06-23 01:52:10.669160
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import json
    import sys

    try:
        from unittest.mock import patch, Mock
    except ImportError:
        from mock import patch, Mock

    fake_path = os.path.join(os.getcwd(), 'tests/unit/module_utils/facts/json/user.json')
    mock_open = Mock(return_value=open(fake_path))


# Generated at 2022-06-23 01:52:19.194527
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    import sys

    user_obj = UserFactCollector()
    user_obj.collect(None, None)
    ufc_dict = user_obj.collect(None, None)

    assert isinstance(ufc_dict, dict)

    for k in ufc_dict:
        if k == 'effective_group_ids':
            assert isinstance(ufc_dict[k], list)
        else:
            assert isinstance(ufc_dict[k], int) or isinstance(ufc_dict[k], str)



# Generated at 2022-06-23 01:52:21.055684
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    ufc.collect()

# Generated at 2022-06-23 01:52:32.689522
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Test for existence of ansible module for testing
    try:
        from ansible.modules.system import getent
    except:
        print("ansible module for testing module for fact UserFactCollector is missing")
        return

    # Load the required external module
    global getent

    # Setup the module arguments required for the tests
    user_getent_args = {'database': 'passwd', 'key': getpass.getuser()}

    # Test 1
    # Pass a valid value
    test_user_return = getent.main(user_getent_args)
    # Test if a valid return was received
    if test_user_return['cmd']:
        print(test_user_return['cmd'])
    else:
        print(test_user_return['msg'])
    assert test_user_return['ret']

# Generated at 2022-06-23 01:52:43.288507
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    with open('/tmp/ansible_facts.json', 'r') as f:
        ansible_facts = json.load(f)

    user_facts_collector = UserFactCollector()
    user_facts = user_facts_collector.collect(collected_facts=ansible_facts)
    # Make assertions
    assert 'user_id' in user_facts
    assert 'user_uid' in user_facts
    assert 'user_gid' in user_facts
    assert 'user_gecos' in user_facts
    assert 'user_dir' in user_facts
    assert 'user_shell' in user_facts
    assert 'real_user_id' in user_facts
    assert 'effective_user_id' in user_facts
    assert 'real_group_id' in user_facts

# Generated at 2022-06-23 01:52:43.884611
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    pass

# Generated at 2022-06-23 01:52:52.596647
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    from ansible.module_utils.facts import fact_collector
    ufc = UserFactCollector(fact_collector)
    result = ufc.collect()
    assert type(result) is dict
    assert 'user_id' in result
    assert 'user_uid' in result
    assert 'user_gecos' in result
    assert 'user_dir' in result
    assert 'user_shell' in result
    assert 'real_user_id' in result
    assert 'effective_user_id' in result
    assert 'effective_group_ids' in result

# Generated at 2022-06-23 01:53:02.130084
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Test for no existing user.  This is not expected in a
    # working system.
    user_fact_collector = UserFactCollector()
    result1 = user_fact_collector.collect()
    assert result1['user_id'] == 'nobody'

    result2 = user_fact_collector.collect()
    assert result1 != result2

    assert result1 != result2

    # Test for no existing user.  This is not expected in a
    # working system.
    assert result1['user_gecos'] == None
    assert result1['user_dir'] == '/'
    assert result1['user_shell'] == '/sbin/nologin'
    assert result1['user_uid'] == 65534
    assert result1['user_gid'] == 65534

# Generated at 2022-06-23 01:53:04.032717
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fact_collect = UserFactCollector()
    ret = fact_collect.collect()
    print (ret)


# Generated at 2022-06-23 01:53:12.041862
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    '''Unit test for UserFactCollector.collect
       - Mocking 'getpass.getuser'
       - Mocking 'pwd.getpwnam'
       - Mocking 'pwd.getpwuid'
       - Mocking 'os.getuid'
       - Mocking 'os.geteuid'
       - Mocking 'os.getgid'
       - Mocking 'os.getegid'
    '''

    # Mocking 'getpass.getuser'

    getpass_getuser_response = 'ansible'
    # ansible.module_utils.facts.collector.getpass.getuser = lambda: getpass_getuser_response

    # Mocking 'pwd.getpwnam'


# Generated at 2022-06-23 01:53:14.272318
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    fact_collector = UserFactCollector()
    fact_collector.collect()

# Generated at 2022-06-23 01:53:18.570505
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    """Test instantiation of class UserFactCollector"""
    # Test with module argument
    user = UserFactCollector(module=object())
    assert user._module == object()
    # Test without module argument
    user = UserFactCollector()
    assert user._module is None

# Generated at 2022-06-23 01:53:26.303159
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    self = UserFactCollector()
    # Test normal use
    # Returned value available to caller via 'result' key
    assert 'user_id' in self.collect().get('result')
    # Test abnormal use
    # Returned value available to caller via 'result' key, empty dict
    # when exception pwd.getpwnam('') KeyError raised
    assert self.collect(getpass.getuser()).get('result') == {}
    assert self.collect(pwd.getpwuid(os.getuid())).get('result') == {}

# Generated at 2022-06-23 01:53:30.100910
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    obj = UserFactCollector()
    assert obj.name == 'user'


if __name__ == '__main__':
    test_UserFactCollector()

# Generated at 2022-06-23 01:53:37.574387
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    '''
    Unit test for method collect of class UserFactCollector
    '''
    # Given a UserFactCollector instance
    collector = UserFactCollector()

    # When a method collect is invoked
    collected_facts = collector.collect()

    # Then try to get the real and effective user and group ids
    assert collected_facts['effective_group_id'] == os.getegid()
    assert collected_facts['effective_user_id'] == os.geteuid()
    assert collected_facts['real_group_id'] == os.getgid()
    assert collected_facts['real_user_id'] == os.getuid()

# Generated at 2022-06-23 01:53:46.934310
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    """ Unit test for method collect of class UserFactCollector
    """

    uid = os.getuid()
    uname = pwd.getpwuid(uid).pw_name
    ugid = pwd.getpwuid(uid).pw_gid
    ugecos = pwd.getpwuid(uid).pw_gecos
    udir = pwd.getpwuid(uid).pw_dir
    ushell = pwd.getpwuid(uid).pw_shell

    user_facts = {}
    user_facts['user_id'] = uname
    user_facts['user_uid'] = uid
    user_facts['user_gid'] = ugid
    user_facts['user_gecos'] = ugecos

# Generated at 2022-06-23 01:53:47.997015
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    fact = UserFactCollector()
    assert fact.name == 'user'

# Generated at 2022-06-23 01:53:59.455255
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    '''
    Test the collect method.
    '''

    # Setup test
    username = os.getenv('USER')
    module = None
    collected_facts = None

    fake_base_fact_collector_class = type('FakeBaseFactCollector', (), {})

    test_obj = UserFactCollector(fake_base_fact_collector_class)

    # Execute code to be tested
    result = test_obj.collect()

    # Check results
    assert 'user_id' in result
    assert result['user_id'] == username
    assert 'user_uid' in result
    assert isinstance(result['user_uid'], int)
    assert 'user_gid' in result
    assert isinstance(result['user_gid'], int)
    assert 'user_gecos' in result

# Generated at 2022-06-23 01:54:06.314409
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_facts = UserFactCollector()
    assert user_facts.name == 'user'
    assert sorted(user_facts._fact_ids) == ['effective_group_ids','effective_user_id',
                                            'real_user_id','user_dir','user_gecos','user_gid',
                                            'user_id','user_shell','user_uid']

# Generated at 2022-06-23 01:54:11.258676
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    fact = UserFactCollector()
    assert fact.name == 'user'
    assert fact._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                  'user_gecos', 'user_dir', 'user_shell',
                                  'real_user_id', 'effective_user_id',
                                  'effective_group_ids'])


# Generated at 2022-06-23 01:54:22.314325
# Unit test for method collect of class UserFactCollector

# Generated at 2022-06-23 01:54:24.578691
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    module = None
    collected_facts = {}
    user_facts = UserFactCollector().collect(module, collected_facts)
    assert isinstance(user_facts, dict)

# Generated at 2022-06-23 01:54:29.156087
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collector = UserFactCollector()
    result = collector.collect()
    assert result['user_id'] is not None
    assert result['user_uid'] is not None
    assert result['user_gid'] is not None
    assert result['user_gecos'] is not None
    assert result['user_dir'] is not None
    assert result['user_shell'] is not None
    assert result['real_user_id'] is not None
    assert result['effective_user_id'] is not None
    assert result['real_group_id'] is not None
    assert result['effective_group_id'] is not None


# Generated at 2022-06-23 01:54:31.153793
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    uid = UserFactCollector()
    assert uid.name == "user"



# Generated at 2022-06-23 01:54:33.288394
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user = UserFactCollector()
    assert user.name == 'user'

# Generated at 2022-06-23 01:54:40.147385
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert isinstance(user_fact_collector, UserFactCollector)
    assert user_fact_collector.name == "user"
    assert user_fact_collector._fact_ids == {'user_id', 'user_uid', 'user_gid', 'user_gecos', 'user_dir', 'user_shell', 'real_user_id', 'effective_user_id', 'effective_group_ids'}
    assert user_fact_collector._platform == 'All'

# Generated at 2022-06-23 01:54:42.044469
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    assert isinstance(UserFactCollector(), UserFactCollector)


# Generated at 2022-06-23 01:54:51.709202
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Create instance without any mandatory arguments
    user_fc = UserFactCollector()

    user_facts = user_fc.collect()

    assert type(user_facts) is dict
    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['user_uid'] == pwd.getpwuid(os.getuid()).pw_uid
    assert user_facts['user_gid'] == pwd.getpwuid(os.getuid()).pw_gid
    assert user_facts['user_gecos'] == pwd.getpwuid(os.getuid()).pw_gecos
    assert user_facts['user_dir'] == pwd.getpwuid(os.getuid()).pw_dir

# Generated at 2022-06-23 01:55:01.997949
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert user_fact_collector.name == 'user'
    assert len(user_fact_collector._fact_ids) == 9
    assert 'user_id' in user_fact_collector._fact_ids
    assert 'user_uid' in user_fact_collector._fact_ids
    assert 'user_gid' in user_fact_collector._fact_ids
    assert 'user_gecos' in user_fact_collector._fact_ids
    assert 'user_dir' in user_fact_collector._fact_ids
    assert 'user_shell' in user_fact_collector._fact_ids
    assert 'real_user_id' in user_fact_collector._fact_ids
    assert 'effective_user_id' in user_fact_collect

# Generated at 2022-06-23 01:55:13.856009
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    def mock_getuser():
        return 'root'

    def mock_getpwnam(user_name):
        return ('root', 'x', 0, 0, 'System Administrator', '/var/root', '/bin/sh')

    def mock_getuid():
        return 0

    def mock_geteuid():
        return 0

    def mock_getgid():
        return 0

    def mock_getegid():
        return 0

    ufc = UserFactCollector()

    getpass.getuser = mock_getuser
    pwd.getpwnam = mock_getpwnam
    os.getuid = mock_getuid
    os.geteuid = mock_geteuid
    os.getgid = mock_getgid
    os.getegid = mock_getegid


# Generated at 2022-06-23 01:55:23.691943
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    output = UserFactCollector().collect()

    assert len(output) > 0

    assert 'user_id' in output.keys()
    assert output['user_id'] == 'root'
    assert 'user_uid' in output.keys()
    assert 'user_gid' in output.keys()
    assert 'user_gecos' in output.keys()
    assert 'user_dir' in output.keys()
    assert output['user_dir'] == '/root'
    assert 'user_shell' in output.keys()
    assert output['user_shell'] == '/bin/bash'
    assert 'real_user_id' in output.keys()
    assert 'effective_user_id' in output.keys()
    assert 'real_group_id' in output.keys()
    assert 'effective_group_id' in output.keys

# Generated at 2022-06-23 01:55:29.025862
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    collector = UserFactCollector()

    facts = collector.collect()

    assert 'user_id' in facts
    assert 'user_uid' in facts
    assert 'user_gid' in facts
    assert 'user_gecos' in facts
    assert 'user_dir' in facts
    assert 'user_shell' in facts
    assert 'real_user_id' in facts
    assert 'effective_user_id' in facts
    assert 'real_group_id' in facts
    assert 'effective_group_id' in facts

# Generated at 2022-06-23 01:55:38.971881
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    import collections
    import os
    import pwd
    import sys

    import ansible.module_utils.facts.collectors.user

    _imported_modules = list(sys.modules.keys())

    ansible.module_utils.facts.collectors.user.os = None

    # For some reason, the name of the UserFactCollector in
    # Ansible 2.2 is user_info and in Ansible 2.3+ it is user
    if 'ansible_facts.collectors.user_info' in _imported_modules:
        from ansible.module_utils.facts.collectors import user_info
        user_fact_collector = user_info.UserFactCollector()

# Generated at 2022-06-23 01:55:47.428413
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import fudge
    collector = UserFactCollector()
    # Verify getuser() is called
    (fudge.clear_expectations()
        .expect('getpass.getuser')
        .with_args()
        .times_called(1))
    # Verify getpwnam() is called
    (fudge.clear_expectations()
        .expect('pwd.getpwnam')
        .with_args(fudge.ANY)
        .times_called(1))
    # Verify getpwuid() is called
    (fudge.clear_expectations()
        .expect('pwd.getpwuid')
        .with_args(fudge.ANY)
        .returns(fudge.Fake())
        .times_called(1))
    # Verify getuid() is called


# Generated at 2022-06-23 01:55:57.149914
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fact_collector = UserFactCollector()
    collected_facts = fact_collector.collect()
    assert collected_facts['user_id'] == getpass.getuser()
    assert collected_facts['user_uid'] == collected_facts['real_user_id']
    assert collected_facts['user_gid'] == collected_facts['real_group_id']
    assert type(collected_facts['user_dir']) == str
    assert type(collected_facts['user_shell']) == str
    assert type(collected_facts['user_gecos']) == str
    assert type(collected_facts['effective_group_id']) == int
    assert type(collected_facts['real_group_id']) == int
    assert type(collected_facts['effective_user_id']) == int

# Generated at 2022-06-23 01:56:06.133726
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_info_dict = { 'user_id': 'ansible',
                       'user_uid': '1000',
                       'user_gid': '100',
                       'user_gecos': 'ansible',
                       'user_dir': '/home/ansible',
                       'user_shell': '/bin/bash',
                       'real_user_id': '1000',
                       'effective_user_id': '1000',
                       'real_group_id': '100',
                       'effective_group_id': '100',
                    }

    fact_collector = UserFactCollector()
    fact_collector_dict = fact_collector.collect()

    assert fact_collector_dict == user_info_dict

# Generated at 2022-06-23 01:56:17.237620
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert 'user_id' in user_fact_collector._fact_ids
    assert 'user_uid' in user_fact_collector._fact_ids
    assert 'user_gid' in user_fact_collector._fact_ids
    assert 'user_gecos' in user_fact_collector._fact_ids
    assert 'user_dir' in user_fact_collector._fact_ids
    assert 'user_shell' in user_fact_collector._fact_ids
    assert 'real_user_id' in user_fact_collector._fact_ids
    assert 'effective_user_id' in user_fact_collector._fact_ids
    assert 'effective_group_ids' in user_fact_collector._fact_ids

# Generated at 2022-06-23 01:56:26.782833
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collector = UserFactCollector()
    facts = collector.collect(None)
    assert isinstance(facts, dict)
    assert facts['user_id'] == 'root'
    assert facts['user_uid'] == 0
    assert facts['user_gid'] == 0
    assert facts['user_gecos'] == 'root'
    assert facts['user_dir'] == '/root'
    assert facts['user_shell'] == '/bin/bash'
    assert facts['real_user_id'] == 0
    assert facts['effective_user_id'] == 0
    assert facts['real_group_id'] == 0
    assert facts['effective_group_id'] == 0

# Generated at 2022-06-23 01:56:28.568628
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector().collect()
    assert user_facts['user_id'] == getpass.getuser()


# Generated at 2022-06-23 01:56:37.803240
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # arrange
    user_fact_collector = UserFactCollector()

    # act
    fact_result = user_fact_collector.collect()

    # assert
    assert fact_result['user_id'] is not None
    assert fact_result['user_uid'] is not None
    assert fact_result['user_gid'] is not None
    assert fact_result['user_gecos'] is not None
    assert fact_result['user_dir'] is not None
    assert fact_result['user_shell'] is not None
    assert fact_result['real_user_id'] is not None
    assert fact_result['effective_user_id'] is not None
    assert fact_result['real_group_id'] is not None
    assert fact_result['effective_group_id'] is not None

# Generated at 2022-06-23 01:56:48.953436
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    from ansible.module_utils.facts.collector import UserFactCollector

    uid = os.getuid()
    euid = os.geteuid()
    gid = os.getgid()
    egid = os.getegid()
    user = getpass.getuser()
    home = os.path.expanduser("~")

    user_facts = UserFactCollector.collect() # collect without any arguments

    assert user_facts['user_id'] == user
    assert user_facts['user_uid'] == uid
    assert user_facts['user_gid'] == gid
    assert user_facts['user_gecos'] == ''
    assert user_facts['user_dir'] == home
    assert user_facts['user_shell'] == '/bin/bash'

# Generated at 2022-06-23 01:56:54.281261
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    logger = None
    sut = UserFactCollector(logger)
    assert sut.name == 'user'
    assert sut._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                 'user_gecos', 'user_dir', 'user_shell',
                                 'real_user_id', 'effective_user_id',
                                 'real_group_id', 'effective_group_id'])

# Generated at 2022-06-23 01:56:59.423997
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    fact = UserFactCollector()
    assert fact.name == 'user'
    assert fact._fact_ids == {'user_id', 'user_uid', 'user_gid', 'user_gecos', 'user_dir', 'user_shell', 'real_user_id', 'effective_user_id', 'effective_group_ids'}


# Generated at 2022-06-23 01:57:00.076008
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    pass

# Generated at 2022-06-23 01:57:01.472389
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    fm = UserFactCollector()
    assert fm.name == 'user'

# Generated at 2022-06-23 01:57:12.896157
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    class MockModule(object):
        def __init__(self, real_user_id, effective_user_id, real_group_id, effective_group_id):
            self.real_user_id = real_user_id
            self.effective_user_id = effective_user_id
            self.real_group_id = real_group_id
            self.effective_group_id = effective_group_id

        def get_tmp_path(self):
            # Unused by UserFactCollector.collect
            return ""

    module = MockModule(real_user_id=10, effective_user_id=11, real_group_id=12, effective_group_id=13)

    collector = UserFactCollector(module=module)
    result = collector.collect(module=module, collected_facts={})


# Generated at 2022-06-23 01:57:17.114652
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user = UserFactCollector()
    module = None
    collected_facts = None
    assert user.collect(module, collected_facts)

# Generated at 2022-06-23 01:57:19.116247
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    _test_UserFactCollector = UserFactCollector()
    assert _test_UserFactCollector.name == 'user'



# Generated at 2022-06-23 01:57:29.683835
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = {}
    user_facts['user_id'] = getpass.getuser()
    try:
        pwent = pwd.getpwnam(getpass.getuser())
    except KeyError:
        pwent = pwd.getpwuid(os.getuid())

    user_facts['user_uid'] = pwent.pw_uid
    user_facts['user_gid'] = pwent.pw_gid
    user_facts['user_gecos'] = pwent.pw_gecos
    user_facts['user_dir'] = pwent.pw_dir
    user_facts['user_shell'] = pwent.pw_shell
    user_facts['real_user_id'] = os.getuid()
    user_facts['effective_user_id'] = os.geteu

# Generated at 2022-06-23 01:57:37.879506
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    u = UserFactCollector()
    assert isinstance(u, BaseFactCollector) # Check for inheritance
    assert set(u._fact_ids) == set(['user_id', 'user_uid', 'user_gid', 'user_gecos', 'user_dir', 'user_shell',
                                    'real_user_id', 'effective_user_id', 'effective_group_ids']), "Mismatch in _fact_ids"
    assert u.name == 'user', "Mismatch in name"


# Generated at 2022-06-23 01:57:42.874738
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_collector = UserFactCollector()
    result = user_collector.collect()
    assert result['user_id'] == getpass.getuser()


# Generated at 2022-06-23 01:57:49.417766
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert user_fact_collector.name == "user"
    assert user_fact_collector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                                 'user_gecos', 'user_dir', 'user_shell',
                                                 'real_user_id', 'effective_user_id',
                                                 'effective_group_ids'])


# Generated at 2022-06-23 01:57:51.597390
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert user_fact_collector is not None

# Generated at 2022-06-23 01:58:02.819496
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import cache
    import os
    import pwd

    os.setuid = lambda x: True
    os.setgid = lambda x: True
    os.seteuid = lambda x: True
    os.setegid = lambda x: True
    os.getuid = lambda: 0
    os.getgid = lambda: 0
    os.geteuid = lambda: 0
    os.getegid = lambda: 0

    pwd.getpwnam = lambda x: True
    pwd.getpwuid = lambda x: True

    fact_cache = cache.FactCache()

# Generated at 2022-06-23 01:58:03.549687
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    pass

# Generated at 2022-06-23 01:58:11.198422
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_collector = UserFactCollector()
    collected_facts =  user_collector.collect()
    assert collected_facts is not None
    assert collected_facts['user_id'] != None
    assert collected_facts['user_uid'] != None
    assert collected_facts['user_gid'] != None
    assert collected_facts['user_gecos'] != None
    assert collected_facts['user_dir'] != None
    assert collected_facts['user_shell'] != None

# Generated at 2022-06-23 01:58:19.236349
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    #example data assumed to be in collected_facts
    data = {
        'ansible_distribution': 'CentOS',
        'ansible_distribution_major_version': '6',
        'ansible_distribution_release': 'Final',
        'ansible_distribution_version': '6.7',
        'ansible_os_family': 'RedHat',
        'ansible_pkg_mgr': 'yum',
        'ansible_processor_count': 8,
        'ansible_processor_cores': 4,
        'ansible_processor_threads_per_core': 2,
    }

    #example data assumed to be in module for module_args

# Generated at 2022-06-23 01:58:24.443369
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    result = user_fact_collector.collect()

    assert result is not None
    assert result['user_id'] is not None
    assert result['user_uid'] is not None
    assert result['user_gid'] is not None
    assert result['user_gecos'] is not None
    assert result['user_dir'] is not None
    assert result['user_shell'] is not None

# Generated at 2022-06-23 01:58:30.194881
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    collector = UserFactCollector()
    assert collector.name == 'user'
    assert collector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                       'user_gecos', 'user_dir', 'user_shell',
                                       'real_user_id', 'effective_user_id',
                                       'effective_group_ids'])

# Generated at 2022-06-23 01:58:36.648226
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_facts = UserFactCollector()
    assert user_facts.name == 'user'
    assert user_facts._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                        'user_gecos', 'user_dir', 'user_shell',
                                        'real_user_id', 'effective_user_id',
                                        'effective_group_ids'])


# Generated at 2022-06-23 01:58:38.943304
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()

    user_facts = ufc.collect()

    assert isinstance(user_facts, dict)

# Generated at 2022-06-23 01:58:47.869524
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector().collect()
    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['user_uid'] == pwd.getpwuid(os.getuid()).pw_uid
    assert user_facts['user_gid'] == pwd.getpwuid(os.getuid()).pw_gid
    assert user_facts['user_gecos'] == pwd.getpwuid(os.getuid()).pw_gecos
    assert user_facts['user_dir'] == pwd.getpwuid(os.getuid()).pw_dir
    assert user_facts['user_shell'] == pwd.getpwuid(os.getuid()).pw_shell
    assert user_facts['real_user_id'] == os

# Generated at 2022-06-23 01:58:55.451799
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    from ansible.module_utils.facts.collector import MockModule
    m = MockModule()
    f = UserFactCollector(module=m)
    facts = f.collect()
    assert 'user_id' in facts
    assert 'user_uid' in facts
    assert 'user_gid' in facts
    assert 'user_gecos' in facts
    assert 'user_dir' in facts
    assert 'user_shell' in facts
    assert 'real_user_id' in facts
    assert 'effective_user_id' in facts
    assert 'real_group_id' in facts
    assert 'effective_group_id' in facts

# Generated at 2022-06-23 01:59:07.307064
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert user_fact_collector.name == 'user'
    assert user_fact_collector._fact_ids == {'user_id', 'user_uid',
                                             'user_gid', 'user_gecos',
                                             'user_dir', 'user_shell',
                                             'real_user_id',
                                             'effective_user_id',
                                             'effective_group_ids'}

if __name__ == "__main__":
    test_UserFactCollector()

# Generated at 2022-06-23 01:59:11.669523
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import os

    ufc = UserFactCollector()

    # test case 1: Authentication success
    module = MagicMock(return_value=None)
    ufc.collect(module)

    # test case 2: Authentication failure
    module_fail = MagicMock(return_value=None)
    module_fail.getpass.getuser.side_effect = Exception("Authentication exception")
    ufc.collect(module_fail)


# Generated at 2022-06-23 01:59:16.868487
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
   Collector = UserFactCollector()

# Generated at 2022-06-23 01:59:25.430744
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    UserFactCollector = UserFactCollector()
    user_facts = UserFactCollector.collect()

    assert 'user_id' in user_facts
    assert 'user_uid' in user_facts
    assert 'user_gid' in user_facts
    assert 'user_gecos' in user_facts
    assert 'user_dir' in user_facts
    assert 'user_shell' in user_facts
    assert 'real_user_id' in user_facts
    assert 'effective_user_id' in user_facts
    assert 'real_group_id' in user_facts
    assert 'effective_group_id' in user_facts

# Generated at 2022-06-23 01:59:33.264695
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_collector = UserFactCollector()
    assert user_collector.name == 'user'
    assert user_collector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                            'user_gecos', 'user_dir', 'user_shell',
                                            'real_user_id', 'effective_user_id',
                                            'real_group_id', 'effective_group_id'])


# Generated at 2022-06-23 01:59:34.757993
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    assert UserFactCollector().name == 'user'


# Generated at 2022-06-23 01:59:39.169645
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
   assert UserFactCollector().name == 'user'
   assert UserFactCollector()._fact_ids == set(['user_id', 'user_uid', 'user_gid', 'user_gecos', 'user_dir', 'user_shell', 'real_user_id', 'effective_user_id', 'effective_group_ids'])


# Generated at 2022-06-23 01:59:44.435812
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    assert UserFactCollector.name == 'user'
    assert type(UserFactCollector._fact_ids) == set
    assert 'user_id' in UserFactCollector._fact_ids
    assert 'user_uid' in UserFactCollector._fact_ids
    assert 'user_gid' in UserFactCollector._fact_ids
    assert 'user_gecos' in UserFactCollector._fact_ids
    assert 'user_dir' in UserFactCollector._fact_ids
    assert 'user_shell' in UserFactCollector._fact_ids
    assert 'real_user_id' in UserFactCollector._fact_ids
    assert 'effective_user_id' in UserFactCollector._fact_ids
    assert 'effective_group_ids' in UserFactCollector._fact_ids

# Generated at 2022-06-23 01:59:54.039597
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    # Test the constructor of UserFactCollector
    assert user_fact_collector.name == 'user'
    assert 'user_id' in user_fact_collector._fact_ids
    assert 'user_uid' in user_fact_collector._fact_ids
    assert 'user_gid' in user_fact_collector._fact_ids
    assert 'user_gecos' in user_fact_collector._fact_ids
    assert 'user_dir' in user_fact_collector._fact_ids
    assert 'user_shell' in user_fact_collector._fact_ids
    assert 'real_user_id' in user_fact_collector._fact_ids
    assert 'effective_user_id' in user_fact_collector._fact_ids

# Generated at 2022-06-23 02:00:06.016784
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    module = None
    collected_facts = { 'user_id': '', 'user_uid': '', 'user_gid': '',
                     'user_gecos': '', 'user_dir': '', 'user_shell': '',
                     'real_user_id': '', 'effective_user_id': '',
                     'real_group_id': '', 'effective_group_id': '' }

    test_collector = UserFactCollector()

    new_facts = test_collector.collect(module, collected_facts)

    assert isinstance(new_facts, dict)
    assert len(new_facts) > 0
    assert len(new_facts) == 10
    assert new_facts['user_id'] == getpass.getuser()
    assert new_facts['effective_user_id'] == os.geteuid

# Generated at 2022-06-23 02:00:08.981716
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    assert ufc.collect()['user_id'] == getpass.getuser()



# Generated at 2022-06-23 02:00:20.800380
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import sys, os
    import unittest
    from ansible.module_utils.facts.collector.user import UserFactCollector
    import pwd

    if sys.version_info[0] == 2:
        from cStringIO import StringIO
    else:
        from io import StringIO

    saved_stdout = sys.stdout