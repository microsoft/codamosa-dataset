

# Generated at 2022-06-23 01:50:18.222052
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    pass

# Generated at 2022-06-23 01:50:27.038330
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ''' Test UserFactCollector.collect method '''
    # Create UserFactCollector instance
    ufc = UserFactCollector()

    # Call method and populate dictionary
    user_facts = ufc.collect()

    # Verify that all required keys are present in dictionary
    assert 'user_id' in user_facts
    assert 'user_uid' in user_facts
    assert 'user_gid' in user_facts
    assert 'user_gecos' in user_facts
    assert 'user_dir' in user_facts
    assert 'user_shell' in user_facts
    assert 'real_user_id' in user_facts
    assert 'effective_user_id' in user_facts
    assert 'real_group_id' in user_facts
    assert 'effective_group_id' in user_facts

# Generated at 2022-06-23 01:50:36.187442
# Unit test for method collect of class UserFactCollector

# Generated at 2022-06-23 01:50:39.280384
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    from ansible.module_utils.facts import ansible_facts
    user_obj = UserFactCollector()
    result = user_obj.collect(ansible_facts)
    user_id = result[list(result)[0]]
    assert(user_id == getpass.getuser())

# Generated at 2022-06-23 01:50:43.308653
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    collector = UserFactCollector()
    assert collector.name == 'user'
    assert collector._fact_ids == {'user_id', 'user_uid', 'user_gid',
                                   'user_gecos', 'user_dir', 'user_shell',
                                   'real_user_id', 'effective_user_id',
                                   'effective_group_ids'}


# Generated at 2022-06-23 01:50:50.753498
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    u = UserFactCollector()
    user_facts = u.collect(collected_facts=dict())
    assert 'user_id' in user_facts
    assert 'user_uid' in user_facts
    assert 'user_gid' in user_facts
    assert 'user_gecos' in user_facts
    assert 'user_dir' in user_facts
    assert 'user_shell' in user_facts
    assert 'real_user_id' in user_facts
    assert 'effective_user_id' in user_facts
    assert 'effective_group_id' in user_facts

# Generated at 2022-06-23 01:50:56.160775
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ufc = UserFactCollector()
    assert ufc.name == 'user'
    assert ufc._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                 'user_gecos', 'user_dir', 'user_shell',
                                 'real_user_id', 'effective_user_id',
                                 'effective_group_ids'])

# Generated at 2022-06-23 01:51:02.426781
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    fact_collector = UserFactCollector()
    assert fact_collector.name == 'user'
    assert fact_collector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                            'user_gecos', 'user_dir', 'user_shell',
                                            'real_user_id', 'effective_user_id',
                                            'effective_group_ids'])

# Generated at 2022-06-23 01:51:12.789213
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    from ansible.module_utils._text import to_bytes
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()
    assert len(user_fact_collector._fact_ids) == len(user_facts), "Not all necessary facts were collected"
    assert to_bytes(user_facts['user_id']) == to_bytes(getpass.getuser()), "wrong user id was collected"
    assert to_bytes(user_facts['user_uid']) == to_bytes(pwd.getpwnam(getpass.getuser()).pw_uid), "wrong user uid was collected"

# Generated at 2022-06-23 01:51:18.251908
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    pass
    #user_facts_collector = UserFactCollector()
    #return_value = user_facts_collector.collect()
    #assert user_facts_collector._fact_ids == return_value.keys()
    #for key in user_facts_collector._fact_ids:
    #    assert key in return_value.keys()

# Generated at 2022-06-23 01:51:23.712111
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert 'user' == user_fact_collector.name
    assert set(['user_id', 'user_uid', 'user_gid',
                'user_gecos', 'user_dir', 'user_shell',
                'real_user_id', 'effective_user_id',
                'effective_group_ids']) == user_fact_collector._fact_ids

# Generated at 2022-06-23 01:51:32.630498
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    test_user = 'azure'
    cur_dir = os.path.dirname(__file__)
    test_data_dir = 'test/unit/module_utils/facts/user/'
    test_data_path = os.path.join(cur_dir, test_data_dir)
    with open(test_data_path + 'pwd_info.data', 'r') as f:
        pwent = f.readlines()

    with open(test_data_path + 'user_info.data', 'r') as f:
        user_info = f.readlines()

    with open(test_data_path + 'group_info.data', 'r') as f:
        group_info = f.readlines()


# Generated at 2022-06-23 01:51:40.732970
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    facts = ufc.collect()
    assert 'user_id' in facts
    assert 'user_uid' in facts
    assert 'user_gid' in facts
    assert 'user_gecos' in facts
    assert 'user_dir' in facts
    assert 'user_shell' in facts
    assert 'real_user_id' in facts
    assert 'effective_user_id' in facts
    assert 'real_group_id' in facts
    assert 'effective_group_id' in facts

# Generated at 2022-06-23 01:51:46.290668
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fact_collector = UserFactCollector()
    fact_collector.collect()

    assert fact_collector.fact_ids == set(['user_id', 'user_uid','user_gid',
                                           'user_gecos', 'user_dir', 'user_shell',
                                           'real_user_id', 'effective_user_id',
                                           'effective_group_ids'])

# Generated at 2022-06-23 01:51:49.715911
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    result = UserFactCollector()
    assert result.name == 'user'
    assert set(result.collect().keys()) == UserFactCollector._fact_ids

# Generated at 2022-06-23 01:51:51.760123
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    assert getpass.getuser() == UserFactCollector().collect()['user_id']

# Generated at 2022-06-23 01:52:01.391397
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector().collect()
    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['user_uid'] == os.getuid()
    assert user_facts['user_gid'] == os.getgid()
    assert isinstance(user_facts['user_gecos'], str)
    assert user_facts['user_dir'] == os.path.expanduser('~')
    assert user_facts['user_shell'] == os.environ.get('SHELL')
    assert user_facts['real_user_id'] == os.getuid()
    assert user_facts['effective_user_id'] == os.geteuid()
    assert user_facts['real_group_id'] == os.getgid()

# Generated at 2022-06-23 01:52:11.421265
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collector = UserFactCollector()
    # We create a user to test the module:
    user_name = 'user_test_ansible'
    with open('/etc/passwd') as file_read:
        for line in file_read:
            if line.split(':')[0] == user_name:
                break
        else:
            os.system("useradd {}".format(user_name))
    # Pass the user that we just created.
    dict_facts = {'user_id': user_name}
    user_facts = collector.collect(collected_facts=dict_facts)
    # We test that the dictionnary contains user_id, user_uid, user_gid,
    # user_gecos, user_dir, user_shell, real_user_id, effective_user_id and
   

# Generated at 2022-06-23 01:52:18.776522
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    test = UserFactCollector()
    name = test.name
    facts = test._fact_ids
    assert name == 'user', name
    assert facts == set(['user_id', 'user_uid', 'user_gid',
                     'user_gecos', 'user_dir', 'user_shell',
                     'real_user_id', 'effective_user_id',
                     'real_group_id', 'effective_group_id']), facts

# Generated at 2022-06-23 01:52:23.520660
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()

    assert isinstance(user_facts, dict)
    assert set(user_facts.keys()) == set(['user_id', 'user_uid',
                                          'user_gid', 'user_gecos',
                                          'user_dir', 'user_shell',
                                          'real_user_id',
                                          'effective_user_id',
                                          'real_group_id',
                                          'effective_group_id'])

# Generated at 2022-06-23 01:52:34.303069
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector

    collector = Collector()
    facts = collector.collect()

    assert set(facts.keys()) == {'all', 'user'}
    assert set(facts['user'].keys()) == {'effective_user_id', 'effective_group_id', 'user_dir', 'real_group_id', 'user_id', 'real_user_id', 'user_uid', 'user_gid', 'user_shell', 'user_gecos'}

    assert isinstance(collector.get_collector('user'), UserFactCollector)
    assert isinstance(collector.get_fact_collector('user_id'), UserFactCollector)

# Generated at 2022-06-23 01:52:34.990489
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    pass

# Generated at 2022-06-23 01:52:44.262734
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Given
    test_instance = UserFactCollector()

    # When
    result = test_instance.collect()

    # Then
    assert type(result) is dict
    assert result['user_id'] == getpass.getuser()
    assert result['user_uid'] == pwd.getpwnam(getpass.getuser()).pw_uid
    assert result['user_gid'] == pwd.getpwnam(getpass.getuser()).pw_gid
    assert result['user_gecos'] == pwd.getpwnam(getpass.getuser()).pw_gecos
    assert result['user_dir'] == pwd.getpwnam(getpass.getuser()).pw_dir

# Generated at 2022-06-23 01:52:55.744178
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    userFactCollector = UserFactCollector()
    assert ('user_id' in userFactCollector._fact_ids)
    assert ('user_uid' in userFactCollector._fact_ids)
    assert ('user_gid' in userFactCollector._fact_ids)
    assert ('user_gecos' in userFactCollector._fact_ids)
    assert ('user_dir' in userFactCollector._fact_ids)
    assert ('user_shell' in userFactCollector._fact_ids)
    assert ('real_user_id' in userFactCollector._fact_ids)
    assert ('effective_user_id' in userFactCollector._fact_ids)
    assert ('real_group_id' in userFactCollector._fact_ids)

# Generated at 2022-06-23 01:53:01.390397
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    collector = UserFactCollector()

    assert collector.name == 'user'
    assert collector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                       'user_gecos', 'user_dir', 'user_shell',
                                       'real_user_id', 'effective_user_id',
                                       'effective_group_ids'])

# Generated at 2022-06-23 01:53:03.599146
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert user_fact_collector.name == 'user'



# Generated at 2022-06-23 01:53:04.193477
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
   pass

# Generated at 2022-06-23 01:53:10.029286
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    from ansible.module_utils.facts.collector import BaseFactCollector

    obj = UserFactCollector()
    assert isinstance(obj, BaseFactCollector)
    assert obj.name == 'user'
    assert set(obj._fact_ids) == set(['user_id', 'user_uid', 'user_gid',
                                      'user_gecos', 'user_dir', 'user_shell',
                                      'real_user_id', 'effective_user_id',
                                      'effective_group_ids'])

# Generated at 2022-06-23 01:53:17.178523
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user = UserFactCollector()
    assert user.name == 'user'
    assert 'user_id' in user._fact_ids
    assert 'user_uid' in user._fact_ids
    assert 'user_gid' in user._fact_ids
    assert 'user_dir' in user._fact_ids
    assert 'user_shell' in user._fact_ids
    assert 'real_user_id' in user._fact_ids
    assert 'effective_user_id' in user._fact_ids
    assert 'effective_group_ids' in user._fact_ids


# Generated at 2022-06-23 01:53:19.982312
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert user_fact_collector is not None


# Generated at 2022-06-23 01:53:28.681165
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_col = UserFactCollector()
    user_facts = user_fact_col.collect()

    assert user_facts['user_id'] is not None
    assert user_facts['user_uid'] is not None
    assert user_facts['user_gid'] is not None
    assert user_facts['user_gecos'] is not None
    assert user_facts['user_dir'] is not None
    assert user_facts['user_shell'] is not None
    assert user_facts['real_user_id'] is not None
    assert user_facts['effective_user_id'] is not None
    assert user_facts['effective_group_ids'] is not None

# Generated at 2022-06-23 01:53:36.316973
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    """Return user facts

    Return user facts on the system.

    :returns: user facts
    :rtype: dict
    """
    c = UserFactCollector()
    facts = c.collect()
    assert 'user_id' in facts
    assert 'user_uid' in facts
    assert 'user_gid' in facts
    assert 'user_gecos' in facts
    assert 'user_dir' in facts
    assert 'user_shell' in facts
    assert 'real_user_id' in facts
    assert 'effective_user_id' in facts
    assert 'effective_group_ids' in facts

# Generated at 2022-06-23 01:53:45.840463
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector().collect()
    assert(user_facts['user_id'] == getpass.getuser())
    assert(user_facts['user_uid'] == os.getuid())
    assert(user_facts['user_gid'] == os.getgid())
    assert(user_facts['user_gecos'] == pwd.getpwuid(os.getuid()).pw_gecos)
    assert(user_facts['user_dir'] == pwd.getpwuid(os.getuid()).pw_dir)
    assert(user_facts['user_shell'] == pwd.getpwuid(os.getuid()).pw_shell)
    assert(user_facts['real_user_id'] == os.getuid())

# Generated at 2022-06-23 01:53:47.182568
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector().collect()
    return user_facts

# Generated at 2022-06-23 01:53:55.842992
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()

# Generated at 2022-06-23 01:54:00.927392
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_facts = UserFactCollector()

    assert user_facts.name == 'user'
    assert user_facts._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                        'user_gecos', 'user_dir', 'user_shell',
                                        'real_user_id', 'effective_user_id',
                                        'real_group_id', 'effective_group_id'])


# Generated at 2022-06-23 01:54:10.576267
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Arrange
    module = MagicMock()
    test_object = UserFactCollector()

    # Act
    user_facts = test_object.collect(module)

    # Assert
    assert 'user_id' in user_facts
    assert 'user_uid' in user_facts
    assert 'user_gid' in user_facts
    assert 'user_gecos' in user_facts
    assert 'user_dir' in user_facts
    assert 'user_shell' in user_facts
    assert 'real_user_id' in user_facts
    assert 'effective_user_id' in user_facts
    assert 'real_group_id' in user_facts
    assert 'effective_group_id' in user_facts

# Generated at 2022-06-23 01:54:15.192609
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    fact_collector = UserFactCollector()
    assert fact_collector.name == 'user'
    assert fact_collector._fact_ids == set([
        'user_id', 'user_uid', 'user_gid', 'user_gecos',
        'user_dir', 'user_shell', 'real_user_id',
        'effective_user_id', 'effective_group_ids'])



# Generated at 2022-06-23 01:54:24.618621
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import sys
    collector = UserFactCollector(0)
    result = collector.collect()
    assert result['effective_user_id'] == os.geteuid()
    assert result['real_user_id'] == os.getuid()
    assert result['user_id'] == getpass.getuser()
    assert result['user_gid'] == pwd.getpwnam(getpass.getuser()).pw_gid
    assert result['user_uid'] == pwd.getpwnam(getpass.getuser()).pw_uid
    assert result['real_group_id'] == os.getgid()
    assert result['effective_group_id'] == os.getegid()

# Generated at 2022-06-23 01:54:28.277294
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    # Set up local state for unit test
    user_fact_collector_obj = UserFactCollector()
    # Assert that correct name is set
    assert user_fact_collector_obj.name == 'user'
    # Assert that correct ids are set
    assert user_fact_collector_obj._fact_ids == {'user_id', 'user_uid', 'user_gid', 'user_gecos', 'user_dir', 'user_shell'}


# Generated at 2022-06-23 01:54:31.439703
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collector = UserFactCollector()
    result = collector.collect()
    assert result['user_id'] == getpass.getuser()

# Generated at 2022-06-23 01:54:37.153311
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    collector = UserFactCollector()
    assert collector.name == 'user'
    assert collector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                     'user_gecos', 'user_dir', 'user_shell',
                     'real_user_id', 'effective_user_id',
                     'effective_group_ids'])


# Generated at 2022-06-23 01:54:42.808507
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.collectors import UserFactCollector

    user = UserFactCollector()
    assert user.collect(collected_facts=None) == user.collect(collected_facts=None)

# Generated at 2022-06-23 01:54:49.561300
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user = UserFactCollector()
    assert user.name == 'user'
    assert user._fact_ids == {'user_id', 'user_uid', 'user_gid',
                              'user_gecos', 'user_dir', 'user_shell',
                              'real_user_id', 'effective_user_id',
                              'effective_group_ids'}


# Generated at 2022-06-23 01:54:56.453502
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_facts = UserFactCollector()
    assert user_facts._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                        'user_gecos', 'user_dir', 'user_shell',
                                        'real_user_id', 'effective_user_id',
                                        'effective_group_ids'])
    assert user_facts.name == 'user'


# Generated at 2022-06-23 01:54:57.655664
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    assert UserFactCollector.name == 'user'

# Generated at 2022-06-23 01:55:00.186785
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    assert True


# Generated at 2022-06-23 01:55:06.432595
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():

    user_fact = UserFactCollector()
    assert user_fact.name == 'user'
    assert set(user_fact._fact_ids) == set(['user_id', 'user_uid', 'user_gid',
                                            'user_gecos', 'user_dir', 'user_shell',
                                            'real_user_id', 'effective_user_id',
                                            'effective_group_ids'])



# Generated at 2022-06-23 01:55:11.907815
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    assert UserFactCollector.name == 'user'
    assert UserFactCollector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                               'user_gecos', 'user_dir', 'user_shell',
                                               'real_user_id', 'effective_user_id',
                                               'effective_group_ids'])


# Generated at 2022-06-23 01:55:22.924328
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    import pwd

    # When platform is linux and user is root
    pwd.getpwnam = lambda x: pwd.struct_passwd(('root', 'x', 0, 0, 'root', '/root', '/bin/bash'))
    os.getuid = lambda: 0

    # When platform is linux and user is not root
    pwd.getpwnam = lambda x: pwd.struct_passwd(('ansible', 'x', 1000, 1000, 'ansible user', '/home/ansible', '/bin/bash'))
    os.getuid = lambda: 1000

    # When platform is darwin
    pwd.getpwnam = lambda x: pwd.struct_passwd(('ansible', '*', 1000, 1000, 'Ansible User', '/Users/ansible', '/bin/bash'))


# Generated at 2022-06-23 01:55:23.495739
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    UserFactCollector()

# Generated at 2022-06-23 01:55:31.380970
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    # Test with a user named "test"
    os.environ["USER"] = "test"
    os.environ["LOGNAME"] = "test"

    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect(None, None)

    assert user_facts['user_id'] == 'test'
    assert user_facts['user_uid'] == 1000
    assert user_facts['user_gid'] == 1000
    assert user_facts['user_gecos'] == ',,,'
    assert user_facts['user_dir'] == '/home/test'
    assert user_facts['user_shell'] == '/bin/bash'
    assert user_facts['real_user_id'] == 1000
    assert user_facts['effective_user_id'] == 1000

# Generated at 2022-06-23 01:55:32.108248
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    pass

# Generated at 2022-06-23 01:55:38.352438
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    l_obj = UserFactCollector()
    assert l_obj.name == 'user'
    assert l_obj._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                   'user_gecos', 'user_dir', 'user_shell',
                                   'real_user_id', 'effective_user_id',
                                   'effective_group_ids'])

# Generated at 2022-06-23 01:55:44.150231
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user = UserFactCollector()
    assert user.name == 'user'
    assert user._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                     'user_gecos', 'user_dir', 'user_shell',
                     'real_user_id', 'effective_user_id',
                     'effective_group_ids'])

# Generated at 2022-06-23 01:55:49.996980
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    assert UserFactCollector.name == 'user'
    assert UserFactCollector._fact_ids == set([
        'user_id', 'user_uid', 'user_gid', 'user_gecos',
        'user_dir', 'user_shell', 'real_user_id',
        'effective_user_id', 'effective_group_ids'])


# Generated at 2022-06-23 01:55:52.321266
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    test_user = UserFactCollector()
    assert test_user
    assert test_user.name == 'user'
    assert test_user._fact_ids

# Generated at 2022-06-23 01:56:00.183671
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_facts_collector = UserFactCollector()
    assert user_facts_collector.facts == set(['user_id', 'user_uid', 'user_gid', 'user_gecos', 'user_dir',
                                              'user_shell', 'real_user_id', 'effective_user_id', 'real_group_id',
                                              'effective_group_id'])
    assert type(user_facts_collector.collect()) is dict

# Generated at 2022-06-23 01:56:01.280419
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact = UserFactCollector()
    assert user_fact.name == 'user'

# Generated at 2022-06-23 01:56:05.748778
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import inspect

    import ansible.module_utils.facts.collectors.user as user
    u = user.UserFactCollector()

    assert inspect.ismethod(u.collect)
    assert inspect.getargspec(u.collect).args == ['self', 'module', 'collected_facts']

    # Test case with only the required parameters
    u.collect()



# Generated at 2022-06-23 01:56:08.064049
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fc = UserFactCollector()
    assert fc.collect().get('effective_user_id') == os.geteuid()



# Generated at 2022-06-23 01:56:17.171669
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    fact_coll = UserFactCollector()
    expected_result = 'user'
    assert fact_coll.name == expected_result, \
        "name attribute value has been changed, which should not happen"
    expected_result = set(['user_id', 'user_uid', 'user_gid',
                           'user_gecos', 'user_dir', 'user_shell',
                           'real_user_id', 'effective_user_id',
                           'effective_group_ids'])
    assert fact_coll._fact_ids == expected_result, \
        "_fact_ids attribute value has been changed, which should not happen"


# Generated at 2022-06-23 01:56:28.383000
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.user import UserFactCollector
    from ansible.module_utils.facts.facts import Facts
    import sys

    # create an instance of UserFactCollector
    user_fact_collector = UserFactCollector()

    # create an instance of BaseFactCollector
    base_fact_collector = BaseFactCollector()

    # create an instance of Facts
    facts = Facts(None)

    # create an instance of Collector
    collector = Collector()

    # add the collector to the list of active collectors of Ansible
    BaseFactCollector._fact_collectors[UserFactCollector.name] = user_fact_collector

    # call

# Generated at 2022-06-23 01:56:33.482316
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fact_obj = UserFactCollector()

    val_user_uid = fact_obj.collect(collected_facts={})['ansible_facts']['user_uid']
    assert val_user_uid is not None
    assert type(val_user_uid) is int


# Generated at 2022-06-23 01:56:42.876059
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_collector = UserFactCollector()
    ansible_facts = {}
    facts = user_collector.collect(collected_facts=ansible_facts)
    expected_keys = ['effective_group_ids', 'effective_user_id', 'real_group_id', 'real_user_id', 'user_dir', 'user_gecos', 'user_gid', 'user_id', 'user_shell', 'user_uid']
    assert set(facts.keys()) == set(expected_keys)
    assert facts['user_id'] == getpass.getuser()

    pwent = pwd.getpwnam(getpass.getuser())
    assert facts['user_uid'] == pwent.pw_uid
    assert facts['user_gid'] == pwent.pw_gid

# Generated at 2022-06-23 01:56:51.559357
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # create UserFactCollector object
    fact_collector = UserFactCollector()
    
    # execute collect method
    fact_collector.collect()
    #unit test for collect function
    def test_UserFactCollector_collect():
        # create UserFactCollector object
        fact_collector = UserFactCollector()
        # execute collect method
        fact_collector.collect()

    #Unit test for method get_fact_names of class UserFactCollector
    def test_UserFactCollector_get_fact_names():
        fact_collector = UserFactCollector()
        fact = fact_collector.get_fact_names()
        assert fact == {'user_dir', 'user_gecos', 'user_id', 'user_shell', 'user_uid', 'user_gid'}

# Generated at 2022-06-23 01:56:57.143861
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    assert UserFactCollector.name == 'user'
    assert UserFactCollector._fact_ids == set(['user_id', 'user_uid',
                                               'user_gid', 'user_gecos',
                                               'user_dir', 'user_shell',
                                               'real_user_id',
                                               'effective_user_id',
                                               'effective_group_ids'])

# Generated at 2022-06-23 01:57:04.763938
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    controller = UserFactCollector()
    collected_facts = controller.collect()
    collected_ids = collected_facts.keys()
    assert 'user_id' in collected_ids
    assert 'user_uid' in collected_ids
    assert 'user_gid' in collected_ids
    assert 'user_gecos' in collected_ids
    assert 'user_dir' in collected_ids
    assert 'user_shell' in collected_ids
    assert 'real_user_id' in collected_ids
    assert 'effective_user_id' in collected_ids
    assert 'effective_group_ids' in collected_ids

# Generated at 2022-06-23 01:57:15.122028
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    userCollector = UserFactCollector()
    result = userCollector.collect()

    assert 'user_id' in result.keys()
    assert 'user_uid' in result.keys()
    assert 'user_gid' in result.keys()
    assert 'user_gecos' in result.keys()
    assert 'user_dir' in result.keys()
    assert 'user_shell' in result.keys()
    assert 'real_user_id' in result.keys()
    assert 'effective_user_id' in result.keys()
    assert 'real_group_id' in result.keys()
    assert 'effective_group_id' in result.keys()

# Generated at 2022-06-23 01:57:19.294532
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    user_facts = ufc.collect()

    assert user_facts['user_id'] is not None
    assert type(user_facts['user_id']) == str
    assert user_facts['user_uid'] is not None
    assert type(user_facts['user_uid']) == int
    assert user_facts['user_gid'] is not None
    assert type(user_facts['user_gid']) == int
    assert user_facts['user_gecos'] is not None
    assert type(user_facts['user_gecos']) == str
    assert user_facts['user_dir'] is not None
    assert type(user_facts['user_dir']) == str
    assert user_facts['user_shell'] is not None

# Generated at 2022-06-23 01:57:25.214454
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    user = UserFactCollector()

    userFacts = user.collect()

    assert(userFacts['user_id'] == getpass.getuser())

# If you add a new method, please write test cases.
# If you modify an existing method, please add test cases.
# If you add or modify an new OptionalFact, please write test cases.

# Generated at 2022-06-23 01:57:27.371187
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    testobj = UserFactCollector()
    assert isinstance(testobj.collect(), dict)

# Generated at 2022-06-23 01:57:38.302102
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import ansible.module_utils.facts.collector
    import tempfile
    tempdir = tempfile.gettempdir()
    import os

    class module:
        def __init__(self, params):
            self.params = params

    params = {'collected_facts': {}, 'fact_path': [tempdir]}

    user = UserFactCollector()
    result = user.collect(module(params), params['collected_facts'])
    assert result['user_id'] == getpass.getuser()
    assert result['user_uid'] == pwd.getpwnam(getpass.getuser()).pw_uid
    assert result['user_gid'] == pwd.getpwnam(getpass.getuser()).pw_gid
    assert result['user_gecos'] == pwd.get

# Generated at 2022-06-23 01:57:42.014577
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    a = UserFactCollector()
    assert a.name == 'user'
    assert a._fact_ids == set(['user_id', 'user_uid', 'user_gid', 'user_gecos', 'user_dir', 'user_shell', 'real_user_id', 'effective_user_id', 'effective_group_ids'])

# Generated at 2022-06-23 01:57:42.719383
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    pass

# Generated at 2022-06-23 01:57:54.645072
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()

    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['user_uid'] == pwd.getpwuid(os.getuid()).pw_uid
    assert user_facts['user_gid'] == pwd.getpwuid(os.getuid()).pw_gid
    assert user_facts['user_gecos'] == pwd.getpwuid(os.getuid()).pw_gecos
    assert user_facts['real_user_id'] == os.getuid()
    assert user_facts['effective_user_id'] == os.geteuid()
    assert user_facts['effective_group_id'] == os.getgid()

# Generated at 2022-06-23 01:57:57.130951
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    ufc.collect()
    for fact in ufc._fact_ids:
        assert fact in ufc.facts

# Generated at 2022-06-23 01:58:07.859602
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()

# Generated at 2022-06-23 01:58:13.700701
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    from ansible.module_utils.facts import Collector
    collector = Collector()
    fact_collector = UserFactCollector(collector)
    assert fact_collector.name == 'user'
    assert fact_collector._fact_ids == {'user_id',
                                        'user_uid',
                                        'user_gid',
                                        'user_gecos',
                                        'user_dir',
                                        'user_shell',
                                        'real_user_id',
                                        'effective_user_id',
                                        'effective_group_ids'}



# Generated at 2022-06-23 01:58:19.154158
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    userFactCollector = UserFactCollector()
    assert userFactCollector.name == 'user'
    assert userFactCollector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                     'user_gecos', 'user_dir', 'user_shell',
                     'real_user_id', 'effective_user_id',
                     'effective_group_ids'])

# Generated at 2022-06-23 01:58:20.675942
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ufc = UserFactCollector()
    assert ufc is not None


# Generated at 2022-06-23 01:58:26.591186
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    tester = UserFactCollector()
    assert tester is not None
    assert tester.name == 'user'
    assert set(tester._fact_ids) == set(['user_id', 'user_uid', 'user_gid',
                                         'user_gecos', 'user_dir', 'user_shell',
                                         'real_user_id', 'effective_user_id',
                                         'effective_group_ids'])


# Generated at 2022-06-23 01:58:34.761691
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    test_user = UserFactCollector()
    test_facts = test_user.collect()

    assert test_facts['user_id'] != ''
    assert test_facts['user_uid'] != ''
    assert test_facts['user_gid'] != ''
    assert test_facts['user_gecos'] != ''
    assert test_facts['user_dir'] != ''
    assert test_facts['user_shell'] != ''
    assert test_facts['real_user_id'] != ''
    assert test_facts['effective_user_id'] != ''
    assert test_facts['real_group_id'] != ''
    assert test_facts['effective_group_id'] != ''

# Generated at 2022-06-23 01:58:38.696697
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    u = UserFactCollector()
    assert u.name == 'user'
    assert u._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                               'user_gecos', 'user_dir', 'user_shell',
                               'real_user_id', 'effective_user_id',
                               'effective_group_ids'])


# Generated at 2022-06-23 01:58:47.621658
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Prepare test
    collector = UserFactCollector()
    # Execute method
    facts = collector.collect()
    # Verify results
    assert facts['ansible_facts']['user_id'] == getpass.getuser()
    try:
        pwent = pwd.getpwnam(getpass.getuser())
    except KeyError:
        pwent = pwd.getpwuid(os.getuid())
    assert facts['ansible_facts']['user_uid'] == pwent.pw_uid
    assert facts['ansible_facts']['user_gid'] == pwent.pw_gid
    assert facts['ansible_facts']['user_gecos'] == pwent.pw_gecos
    assert facts['ansible_facts']['user_dir'] == pwent.p

# Generated at 2022-06-23 01:58:49.490125
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    obj = UserFactCollector()
    assert isinstance(obj, UserFactCollector)


# Generated at 2022-06-23 01:58:54.723125
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector().collect()
    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['real_user_id'] == os.getuid()
    assert user_facts['effective_user_id'] == os.geteuid()
    assert user_facts['real_group_id'] == os.getgid()
    assert user_facts['effective_group_id'] == os.getgid()

# Generated at 2022-06-23 01:59:01.446695
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collector = UserFactCollector()
    user_facts = collector.collect()
    print(user_facts)

# Generated at 2022-06-23 01:59:02.167018
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    pass

# Generated at 2022-06-23 01:59:10.688080
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    facts = ufc.collect()
    assert "user_id" in facts
    assert "user_uid" in facts
    assert "user_gid" in facts
    assert "user_gecos" in facts
    assert "user_dir" in facts
    assert "user_shell" in facts
    assert "real_user_id" in facts
    assert "effective_user_id" in facts
    assert "real_group_id" in facts
    assert "effective_group_id" in facts

# Generated at 2022-06-23 01:59:11.203117
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    assert True

# Generated at 2022-06-23 01:59:14.326238
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    from ansible.module_utils.facts import user

    collector = user.UserFactCollector()

    user_facts = collector.collect()

    print(user_facts)


# Generated at 2022-06-23 01:59:18.696045
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert user_fact_collector.name == 'user'
    assert len(user_fact_collector._fact_ids) == 10
    assert user_fact_collector.collect() == user_fact_collector.collect()

# Generated at 2022-06-23 01:59:26.831832
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collector = UserFactCollector()
    data = collector.collect()
    assert('user_id' in data)
    assert('user_uid' in data)
    assert('user_gid' in data)
    assert('user_gecos' in data)
    assert('user_dir' in data)
    assert('user_shell' in data)
    assert('real_user_id' in data)
    assert('effective_user_id' in data)
    assert('real_group_id' in data)
    assert('effective_group_id' in data)

# Generated at 2022-06-23 01:59:36.984185
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    fact_collector = UserFactCollector()

    assert fact_collector.name == 'user'
    assert isinstance(fact_collector._fact_ids, set)
    assert 'user_id' in fact_collector._fact_ids
    assert 'user_uid' in fact_collector._fact_ids
    assert 'user_gid' in fact_collector._fact_ids
    assert 'user_gecos' in fact_collector._fact_ids
    assert 'user_dir' in fact_collector._fact_ids
    assert 'user_shell' in fact_collector._fact_ids
    assert 'real_user_id' in fact_collector._fact_ids
    assert 'effective_user_id' in fact_collector._fact_ids
    assert 'real_group_id' in fact_collector._

# Generated at 2022-06-23 01:59:45.396331
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_collector = UserFactCollector()
    user_facts = user_collector.collect()
    assert 'user_id' in user_facts
    assert 'user_uid' in user_facts
    assert 'user_gid' in user_facts
    assert 'user_gecos' in user_facts
    assert 'user_dir' in user_facts
    assert 'user_shell' in user_facts
    assert 'real_user_id' in user_facts
    assert 'effective_user_id' in user_facts
    assert 'real_group_id' in user_facts
    assert 'effective_group_id' in user_facts

# Generated at 2022-06-23 01:59:49.010171
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    collected_facts = user_fact_collector.collect()

    assert "user_id" in collected_facts

# Generated at 2022-06-23 01:59:57.905350
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector().collect()
    assert sorted(user_facts.keys()) == sorted(UserFactCollector._fact_ids)
    assert isinstance(user_facts['user_id'], basestring)
    assert isinstance(user_facts['user_uid'], int)
    assert isinstance(user_facts['user_gid'], int)
    assert isinstance(user_facts['user_gecos'], basestring)
    assert isinstance(user_facts['user_dir'], basestring)
    assert isinstance(user_facts['user_shell'], basestring)
    assert isinstance(user_facts['real_user_id'], int)
    assert isinstance(user_facts['effective_user_id'], int)

# Generated at 2022-06-23 02:00:01.541921
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    obj = UserFactCollector()
    assert obj.name == 'user'
    assert obj._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                 'user_gecos', 'user_dir', 'user_shell',
                                 'real_user_id', 'effective_user_id',
                                 'effective_group_ids'])

# Generated at 2022-06-23 02:00:12.264515
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector().collect()

    assert user_facts['user_id'] == getpass.getuser()
    pwent = pwd.getpwnam(getpass.getuser())
    assert user_facts['user_uid'] == pwent.pw_uid
    assert user_facts['user_gid'] == pwent.pw_gid
    assert user_facts['user_gecos'] == pwent.pw_gecos
    assert user_facts['user_dir'] == pwent.pw_dir
    assert user_facts['user_shell'] == pwent.pw_shell
    assert user_facts['real_user_id'] == os.getuid()
    assert user_facts['effective_user_id'] == os.geteuid()

# Generated at 2022-06-23 02:00:13.953373
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_fact_collector.collect()

# Generated at 2022-06-23 02:00:23.917108
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Prepare test data
    test_dict = {'user_id': 'user',
                 'user_uid': 1000,
                 'user_gid': 1000,
                 'user_gecos': 'user,,,',
                 'user_dir': '/home/user',
                 'user_shell': '/bin/bash',
                 'real_user_id': 1000,
                 'effective_user_id': 1000,
                 'real_group_id': 1000,
                 'effective_group_id': 1000}

    # Initialize UserFactCollector instance
    ufc = UserFactCollector()
    # Run collection
    test_dict_actual = ufc.collect()

    assert test_dict == test_dict_actual