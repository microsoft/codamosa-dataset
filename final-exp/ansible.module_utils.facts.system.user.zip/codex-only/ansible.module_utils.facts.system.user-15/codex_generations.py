

# Generated at 2022-06-23 01:50:23.034619
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    U = UserFactCollector()
    assert U.name == 'user'
    assert U._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                               'user_gecos', 'user_dir', 'user_shell',
                               'real_user_id', 'effective_user_id',
                               'effective_group_ids'])

# Generated at 2022-06-23 01:50:30.427581
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    assert UserFactCollector.name == 'user'
    assert UserFactCollector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                               'user_gecos', 'user_dir', 'user_shell',
                                               'real_user_id', 'effective_user_id',
                                               'effective_group_ids'])


# Generated at 2022-06-23 01:50:32.095994
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    # UserFactCollector tests
    obj = UserFactCollector()
    assert obj.name == "user"

# Generated at 2022-06-23 01:50:34.429225
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector()
    ansible_facts = {}

    ansible_facts.update(user_facts.collect())
    assert 'user_id' in ansible_facts

# Generated at 2022-06-23 01:50:35.691930
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_facts = UserFactCollector()
    assert user_facts.name == 'user'

# Generated at 2022-06-23 01:50:43.585233
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    module = AnsibleModule(argument_spec = dict())
    result = UserFactCollector().collect(module=module)
    assert result['user_id'] == getpass.getuser()
    assert result['user_uid'] == pwd.getpwnam(getpass.getuser()).pw_uid
    assert result['user_gid'] == pwd.getpwnam(getpass.getuser()).pw_gid
    assert result['user_gecos'] == pwd.getpwnam(getpass.getuser()).pw_gecos
    assert result['user_dir'] == pwd.getpwnam(getpass.getuser()).pw_dir
    assert result['user_shell'] == pwd.getpwnam(getpass.getuser()).pw_shell

# Generated at 2022-06-23 01:50:47.293592
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    test_UserFactCollector = UserFactCollector()
    test_UserFactCollector.collect()


# Generated at 2022-06-23 01:50:55.546539
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()

    assert 'user_id' in user_facts
    assert 'user_uid' in user_facts
    assert 'user_gid' in user_facts
    assert 'user_gecos' in user_facts
    assert 'user_dir' in user_facts
    assert 'user_shell' in user_facts
    assert 'real_user_id' in user_facts
    assert 'effective_user_id' in user_facts
    assert 'real_group_id' in user_facts
    assert 'effective_group_id' in user_facts

# Generated at 2022-06-23 01:50:56.926371
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    UserFactCollectorInstance = UserFactCollector()


# Generated at 2022-06-23 01:51:01.605666
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ut = UserFactCollector()
    assert isinstance(ut, UserFactCollector)
    assert type(ut) == UserFactCollector
    assert ut.name == 'user'
    assert len(ut._fact_ids) == 9


# Generated at 2022-06-23 01:51:02.908769
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_collector = UserFactCollector()
    assert user_collector is not None

# Generated at 2022-06-23 01:51:13.110782
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    user_facts = ufc.collect()

    assert isinstance(user_facts['user_id'], str)
    assert isinstance(user_facts['user_uid'], int)
    assert isinstance(user_facts['user_gid'], int)
    assert isinstance(user_facts['user_gecos'], str)
    assert isinstance(user_facts['user_dir'], str)
    assert isinstance(user_facts['user_shell'], str)
    assert isinstance(user_facts['real_user_id'], int)
    assert isinstance(user_facts['effective_user_id'], int)
    assert isinstance(user_facts['real_group_id'], int)

# Generated at 2022-06-23 01:51:18.592185
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    f = UserFactCollector()
    assert f.name == 'user'
    assert f._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                               'user_gecos', 'user_dir', 'user_shell',
                               'real_user_id', 'effective_user_id',
                               'effective_group_ids'])


# Generated at 2022-06-23 01:51:22.708810
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    assert hasattr(UserFactCollector, 'name')  # if collector has name
    assert hasattr(UserFactCollector, 'collect')  # if collector implements 'collect' method
    assert hasattr(UserFactCollector, '_fact_ids')  # if collector has _fact_ids


# Generated at 2022-06-23 01:51:27.429528
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # test empty/disabled
    assert UserFactCollector().collect() == {}

    # test standard case
    from ansible.module_utils.facts import Facts
    test_f = Facts()
    test_fc = UserFactCollector()
    test_fc.collect(test_f, test_f.all)
    assert test_f.all['user_id'] == getpass.getuser()

# Generated at 2022-06-23 01:51:38.202943
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect(collected_facts={})
    assert user_facts.get('user_id'), "Failed to collect user_id fact"
    assert user_facts.get('user_uid'), "Failed to collect user_uid fact"
    assert user_facts.get('user_gid'), "Failed to collect user_gid fact"
    assert user_facts.get('user_gecos'), "Failed to collect user_gecos fact"
    assert user_facts.get('user_dir'), "Failed to collect user_dir fact"
    assert user_facts.get('user_shell'), "Failed to collect user_shell fact"

# Generated at 2022-06-23 01:51:43.805915
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    test_obj = UserFactCollector()
    assert test_obj.name == 'user'

    assert test_obj._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                      'user_gecos', 'user_dir', 'user_shell',
                                      'real_user_id', 'effective_user_id',
                                      'effective_group_ids'])

# Generated at 2022-06-23 01:51:48.740563
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    test_obj = UserFactCollector()
    test_obj.collect()
    assert test_obj._fact_ids == set([u'user_id', u'user_uid', u'user_gid', u'user_gecos', u'user_dir', u'user_shell', u'real_user_id', u'effective_user_id', u'effective_group_ids'])

# Generated at 2022-06-23 01:51:58.826436
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    module_name = 'user'
    data = {}
    data['ansible_local'] = {'user': UserFactCollector()}
    result = UserFactCollector.collect([module_name], data)
    assert result['user_id'] == data['ansible_local']['user'].collect()['user_id']
    assert result['user_uid'] == data['ansible_local']['user'].collect()['user_uid']
    assert result['user_gid'] == data['ansible_local']['user'].collect()['user_gid']
    assert result['user_gecos'] == data['ansible_local']['user'].collect()['user_gecos']

# Generated at 2022-06-23 01:52:09.305040
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Create instances of FactCollector and UserFactCollector
    fact_collector = BaseFactCollector()
    collector = UserFactCollector()

    # Create a list to store collected facts
    collected_facts = dict()

    facts = dict()
    facts['user_id'] = getpass.getuser()
    try:
        pwent = pwd.getpwnam(getpass.getuser())
    except KeyError:
        pwent = pwd.getpwuid(os.getuid())

    facts['user_uid'] = pwent.pw_uid
    facts['user_gid'] = pwent.pw_gid
    facts['user_gecos'] = pwent.pw_gecos
    facts['user_dir'] = pwent.pw_dir
    facts['user_shell'] = pwent

# Generated at 2022-06-23 01:52:10.868360
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    assert ufc.collect().get('user_id') == getpass.getuser()

# Generated at 2022-06-23 01:52:20.655435
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    print("Testing")
    user_facts = UserFactCollector.collect()
    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['user_uid'] == os.getuid()
    assert user_facts['user_gid'] == os.getegid()
    assert user_facts['real_user_id'] == os.getuid()
    assert user_facts['effective_user_id'] == os.geteuid()
    assert user_facts['real_group_id'] == os.getgid()
    assert user_facts['effective_group_id'] == os.getegid()


# Generated at 2022-06-23 01:52:29.138230
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    # Create instance of UserFactCollector
    ufc = UserFactCollector()

    # Check if the name of the collector is correct
    assert "user" == ufc.name

    # Check the fact_ids
    assert {"user_id", "user_uid", "user_gid", "user_gecos",
            "user_dir", "user_shell", "real_user_id", "effective_user_id",
            "real_group_id", "effective_group_id"
           } == ufc._fact_ids

# Generated at 2022-06-23 01:52:29.742400
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    pass

# Generated at 2022-06-23 01:52:34.989538
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ufc = UserFactCollector()
    assert ufc.name == 'user'
    assert ufc._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                 'user_gecos', 'user_dir', 'user_shell',
                                 'real_user_id', 'effective_user_id',
                                 'real_group_id', 'effective_group_id'])

# Generated at 2022-06-23 01:52:38.460086
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert user_fact_collector.name == 'user'
    for fact_id in user_fact_collector._fact_ids:
        assert fact_id in user_fact_collector.collect()

# Generated at 2022-06-23 01:52:43.210712
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_facts = UserFactCollector()
    assert user_facts.name == 'user'
    assert user_facts._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                     'user_gecos', 'user_dir', 'user_shell',
                     'real_user_id', 'effective_user_id',
                     'effective_group_ids'])

# Generated at 2022-06-23 01:52:49.491276
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    collected_facts = user_fact_collector.collect()

    # check that all expected facts are returned
    expected_facts = set(user_fact_collector._fact_ids)
    print(collected_facts)
    assert expected_facts.issubset(set(collected_facts))
    assert collected_facts['user_id'] == 'sonu'

# Generated at 2022-06-23 01:52:51.656418
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert user_fact_collector.name == "user"

# Generated at 2022-06-23 01:52:55.077961
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ufc = UserFactCollector()

    assert not ufc.collected_facts
    assert ufc.name == 'user'
    assert ufc._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                 'user_gecos', 'user_dir', 'user_shell',
                                 'real_user_id', 'effective_user_id',
                                 'effective_group_ids'])


# Generated at 2022-06-23 01:53:01.400916
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    x = UserFactCollector()
    assert x.name == 'user'
    assert x._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                               'user_gecos', 'user_dir', 'user_shell',
                               'real_user_id', 'effective_user_id',
                               'effective_group_ids'])

# Generated at 2022-06-23 01:53:03.610886
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_facts = UserFactCollector()
    assert user_facts.name == 'user'


# Generated at 2022-06-23 01:53:08.633957
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    expected_keys = set(['user_id', 'user_uid', 'user_gid',
                     'user_gecos', 'user_dir', 'user_shell',
                     'real_user_id', 'effective_user_id',
                     'effective_group_ids'])

    user = UserFactCollector()
    assert user._fact_ids == expected_keys
    assert user.name == 'user'


# Generated at 2022-06-23 01:53:18.717052
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user = UserFactCollector()

    assert getpass.getuser() == user.collect()['user_id'], "user_id is not equal to result of getpass"
    try:
        pwent = pwd.getpwnam(getpass.getuser())
    except KeyError:
        pwent = pwd.getpwuid(os.getuid())

    assert pwent.pw_uid == user.collect()['user_uid'], "user_uid is not equal to pwent.pw_uid"
    assert pwent.pw_gid == user.collect()['user_gid'], "user_gid is not equal to pwent.pw_gid"

# Generated at 2022-06-23 01:53:25.351750
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    userFactCollector = UserFactCollector()
    assert userFactCollector.name == 'user'
    assert userFactCollector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                               'user_gecos', 'user_dir', 'user_shell',
                                               'real_user_id', 'effective_user_id',
                                               'effective_group_ids'])



# Generated at 2022-06-23 01:53:33.043845
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    fact_collector = UserFactCollector()
    assert fact_collector.name == 'user'
    assert fact_collector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                            'user_gecos', 'user_dir', 'user_shell',
                                            'real_user_id', 'effective_user_id',
                                            'effective_group_ids'])
    assert not fact_collector.cacheable


# Generated at 2022-06-23 01:53:38.946610
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_collector = UserFactCollector()
    assert user_collector.name == "user"
    assert user_collector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                            'user_gecos', 'user_dir', 'user_shell',
                                            'real_user_id', 'effective_user_id',
                                            'effective_group_ids'])



# Generated at 2022-06-23 01:53:48.049499
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    from ansible.module_utils.facts.collector import ModuleFactsCollector
    from ansible.module_utils import basic
    import ansible.module_utils.facts.collector
    new_user_fact_collector = UserFactCollector()
    assert new_user_fact_collector.name == 'user'
    assert ansible.module_utils.facts.collector.collectors['user'] == UserFactCollector
    assert new_user_fact_collector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                                     'user_gecos', 'user_dir', 'user_shell',
                                                     'real_user_id', 'effective_user_id',
                                                     'effective_group_ids'])
    assert new_user_fact_collector.collect

# Generated at 2022-06-23 01:53:54.365695
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ufc = UserFactCollector()
    assert ufc.name == "user"
    assert ufc._fact_ids == {"user_id", "user_uid", "user_gecos",
                             "user_dir", "user_shell", "real_user_id",
                             "effective_user_id", "effective_group_ids"}

# Generated at 2022-06-23 01:54:01.944939
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    facts_dict = ufc.collect()

    # If the getpass.getuser() method was not able to collect any information,
    # this test will fail.
    assert 'user_id' in facts_dict
    assert 'user_uid' in facts_dict
    assert 'user_gid' in facts_dict
    assert 'user_gecos' in facts_dict
    assert 'user_dir' in facts_dict
    assert 'user_shell' in facts_dict
    assert 'real_user_id' in facts_dict
    assert 'effective_user_id' in facts_dict
    assert 'real_group_id' in facts_dict
    assert 'effective_group_id' in facts_dict

# Generated at 2022-06-23 01:54:08.337396
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    facts = ufc.collect()
    
    assert facts['user_id']
    assert facts['user_uid']
    assert facts['user_gid']
    assert facts['user_gecos']
    assert facts['user_dir']
    assert facts['user_shell']
    assert facts['real_user_id']
    assert facts['effective_user_id']
    assert facts['effective_group_ids']

# Generated at 2022-06-23 01:54:14.710405
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert user_fact_collector.name == 'user'
    assert user_fact_collector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                     'user_gecos', 'user_dir', 'user_shell',
                     'real_user_id', 'effective_user_id',
                     'effective_group_ids'])


# Generated at 2022-06-23 01:54:19.924317
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    facts = ufc.collect()

    # make sure all the keys are present in the facts
    assert ufc._fact_ids - set(facts.keys()) == set()
    # make sure no unexpected keys are present in the facts
    assert ufc._fact_ids == set(facts.keys())

# Generated at 2022-06-23 01:54:21.628349
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
  userFactCollector = UserFactCollector()

  assert userFactCollector != None

# Generated at 2022-06-23 01:54:27.167817
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    o_c_f = UserFactCollector(module=None, collected_facts=None)
    o_c_f._collect()

# Generated at 2022-06-23 01:54:29.664983
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    assert UserFactCollector.name == "user"
    assert isinstance(UserFactCollector._fact_ids, set)

# Generated at 2022-06-23 01:54:38.034435
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    # If it's not possible to get information about current user (with
    # getpwnam or getpwuid functions), keyerror is raised
    if getpass.getuser() != 'root':
        try:
            pwd.getpwnam('non-existent-user')
        except KeyError:
            pass

    # If it's not possible to get information about current user (with
    # getpwnam or getpwuid functions), keyerror is raised
    else:
        try:
            pwd.getpwuid(0)
        except KeyError:
            pass

# Generated at 2022-06-23 01:54:45.703462
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user = UserFactCollector()
    result = user.collect()
    assert 'user_id' in result
    assert 'user_uid' in result
    assert 'user_gid' in result
    assert 'user_gecos' in result
    assert 'user_dir' in result
    assert 'user_shell' in result
    assert 'real_user_id' in result
    assert 'effective_user_id' in result
    assert 'real_group_id' in result
    assert 'effective_group_id' in result

# Generated at 2022-06-23 01:54:50.857421
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    y = UserFactCollector()
    assert y.name == 'user'
    assert y._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                               'user_gecos', 'user_dir', 'user_shell',
                               'real_user_id', 'effective_user_id',
                               'effective_group_ids'])


# Generated at 2022-06-23 01:54:57.915087
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    obj = UserFactCollector()
    assert type(obj).__name__ == 'UserFactCollector'
    assert obj.name == 'user'
    assert obj._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                 'user_gecos', 'user_dir', 'user_shell',
                                 'real_user_id', 'effective_user_id',
                                 'effective_group_ids'])


# Generated at 2022-06-23 01:55:05.408781
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    assert UserFactCollector.name == 'user'
    assert UserFactCollector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                               'user_gecos', 'user_dir', 'user_shell',
                                               'real_user_id', 'effective_user_id',
                                               'effective_group_ids'])

# Generated at 2022-06-23 01:55:12.247500
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Create a UserFactCollector object
    ufc = UserFactCollector()

    # Create a dictionary to check the result

# Generated at 2022-06-23 01:55:15.352039
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    testcollector = UserFactCollector()
    testcollector.collect()


# Generated at 2022-06-23 01:55:24.594069
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fact_collector = UserFactCollector()
    fact = fact_collector.collect()
    assert fact != None
    assert fact['user_id'] == getpass.getuser()
    try:
        pwent = pwd.getpwnam(getpass.getuser())
    except KeyError:
        pwent = pwd.getpwuid(os.getuid())
    assert fact['user_uid'] == pwent.pw_uid
    assert fact['user_gid'] == pwent.pw_gid
    assert fact['user_gecos'] == pwent.pw_gecos
    assert fact['user_dir'] == pwent.pw_dir
    assert fact['user_shell'] == pwent.pw_shell
    assert fact['real_user_id'] == os.getuid()
   

# Generated at 2022-06-23 01:55:31.644816
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    collector = UserFactCollector()
    assert collector.name == 'user'
    assert collector._fact_ids == {'user_id', 'user_uid', 'user_gid',
                                   'user_gecos', 'user_dir', 'user_shell',
                                   'real_user_id', 'effective_user_id',
                                   'effective_group_ids'}



# Generated at 2022-06-23 01:55:35.752446
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ufobj = UserFactCollector()
    assert ufobj.name == 'user'
    assert ufobj._fact_ids == {'user_id', 'user_uid', 'user_gid',
                               'user_gecos', 'user_dir', 'user_shell',
                               'real_user_id', 'effective_user_id',
                               'effective_group_ids'}


# Generated at 2022-06-23 01:55:41.091251
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    u = UserFactCollector()
    assert isinstance(u, UserFactCollector)

# Generated at 2022-06-23 01:55:41.658416
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    pass

# Generated at 2022-06-23 01:55:46.642303
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collector = UserFactCollector()
    facts = collector.collect()

    assert 'user_id' in facts
    assert 'user_gid' in facts
    assert 'user_gecos' in facts
    assert 'user_dir' in facts
    assert 'user_shell' in facts
    assert 'real_user_id' in facts
    assert 'effective_user_id' in facts
    assert 'real_group_id' in facts
    assert 'effective_group_id' in facts

# Generated at 2022-06-23 01:55:56.594465
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import pytest

    user_facts = {
        'user_id': getpass.getuser(),
        'user_uid': os.getuid(),
        'user_gid': os.getgid(),
        'user_gecos': '',
        'user_dir': os.path.expanduser('~'),
        'user_shell': os.getenv('SHELL'),
        'real_user_id': os.getuid(),
        'effective_user_id': os.getuid(),
        'real_group_id': os.getgid(),
        'effective_group_id': os.getgid()
    }

    ufc = UserFactCollector()
    collected_facts = ufc.collect()

    for key in collected_facts:
        assert collected_facts[key] == user_facts[key]

# Generated at 2022-06-23 01:56:02.317430
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fac = UserFactCollector()
    assert user_fac.name == 'user'
    assert user_fac._fact_ids == {'user_id', 'user_uid', 'user_gid',
                           'user_gecos', 'user_dir', 'user_shell',
                           'real_user_id', 'effective_user_id',
                           'effective_group_ids'}

# Generated at 2022-06-23 01:56:08.740641
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    """
    Unit test for method collect of class UserFactCollector
    """
    class_user = UserFactCollector()

    # Unit test - Check if method collect return values are correct
    assert class_user.collect() == {'user_id': 'root', 'user_uid': 0, 'user_gid': 0, 'user_gecos': 'root',
                                    'user_dir': '/root', 'user_shell': '/bin/bash', 'real_user_id': 0,
                                    'effective_user_id': 0, 'real_group_id': 0, 'effective_group_id': 0}

# Generated at 2022-06-23 01:56:15.593389
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ufc = UserFactCollector()
    assert ufc.name == "user"
    assert ufc._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                 'user_gecos', 'user_dir', 'user_shell',
                                 'real_user_id', 'effective_user_id',
                                 'effective_group_ids'])

# Generated at 2022-06-23 01:56:22.282106
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    collector = UserFactCollector()
    assert collector.name == 'user'
    assert collector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                       'user_gecos', 'user_dir', 'user_shell',
                                       'real_user_id', 'effective_user_id',
                                       'effective_group_ids'])


# Generated at 2022-06-23 01:56:27.467156
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    uf = UserFactCollector()
    assert uf.name == 'user'
    assert uf._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                'user_gecos', 'user_dir', 'user_shell',
                                'real_user_id', 'effective_user_id',
                                'effective_group_ids'])



# Generated at 2022-06-23 01:56:30.837614
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()

    # returns {} if called with no parameters
    assert {} == ufc.collect()

# Generated at 2022-06-23 01:56:38.011300
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ufc = UserFactCollector()
    assert ufc.name == 'user'
    assert ufc._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                 'user_gecos', 'user_dir', 'user_shell',
                                 'real_user_id', 'effective_user_id',
                                 'effective_group_ids'])


# Generated at 2022-06-23 01:56:41.335524
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fact_collector = UserFactCollector()

    collected_facts = fact_collector.collect()

    assert collected_facts['user_id'] == getpass.getuser()

# Generated at 2022-06-23 01:56:50.366866
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector()
    user_facts = user_facts.collect()
    assert (user_facts['user_id'] == getpass.getuser())
    assert (user_facts['user_uid'] == os.getuid())
    assert (user_facts['user_gid'] == os.getgid())
    assert (user_facts['real_user_id'] == os.getuid())
    assert (user_facts['effective_user_id'] == os.geteuid())
    assert (user_facts['real_group_id'] == os.getgid())
    assert (user_facts['effective_group_id'] == os.getgid())

# Generated at 2022-06-23 01:56:55.864119
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    o = UserFactCollector()
    assert o._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                               'user_gecos', 'user_dir', 'user_shell',
                               'real_user_id', 'effective_user_id',
                               'effective_group_ids'])
    assert o.name == 'user'

# Generated at 2022-06-23 01:57:02.068759
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    # UserFactCollector constructor takes no arguments
    # and sets name and _fact_ids
    userFactCollector = UserFactCollector()
    assert userFactCollector.name == 'user'
    assert userFactCollector._fact_ids == set(['user_id', 'user_uid',
        'user_gid', 'user_gecos', 'user_dir', 'user_shell', 'real_user_id',
        'effective_user_id', 'effective_group_ids'])

# Generated at 2022-06-23 01:57:07.522924
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
	collector = UserFactCollector()
	assert collector.name == 'user'
	assert collector._fact_ids == set(['user_id', 'user_uid', 'user_gid', 'user_gecos', 'user_dir', 'user_shell', 'real_user_id', 'effective_user_id', 'effective_group_ids'])


# Generated at 2022-06-23 01:57:12.039426
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Create basic instance of UserFactCollector
    inst = UserFactCollector()
    
    # Test user information collected
    user_facts = inst.collect()
    assert isinstance(user_facts, dict)
    for fact in inst._fact_ids:
        assert fact in user_facts

# Generated at 2022-06-23 01:57:22.093100
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert user_fact_collector.name == 'user'
    assert user_fact_collector.collect()
    assert user_fact_collector._fact_ids == {'effective_group_ids',
                                             'user_id',
                                             'user_uid',
                                             'effective_user_id',
                                             'user_gid',
                                             'user_gecos',
                                             'user_shell',
                                             'user_dir',
                                             'real_user_id'}

# Generated at 2022-06-23 01:57:26.982272
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    collector = UserFactCollector()
    assert collector.name == 'user'
    assert collector._fact_ids == set([
        'user_id', 'user_uid', 'user_gid',
        'user_gecos', 'user_dir', 'user_shell',
        'real_user_id', 'effective_user_id',
        'effective_group_ids'])

# Generated at 2022-06-23 01:57:34.834071
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    # Create an object for testing
    user_facts = UserFactCollector()

    # Test the name variable
    assert user_facts.name == "user"
    # Test the _fact_ids variable
    assert user_facts._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                        'user_gecos', 'user_dir', 'user_shell',
                                        'real_user_id', 'effective_user_id',
                                        'effective_group_ids'])


# Generated at 2022-06-23 01:57:40.478206
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    '''UserFactCollector() constructor'''
    user_facts = UserFactCollector()
    assert user_facts.name == 'user'
    assert user_facts._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                     'user_gecos', 'user_dir', 'user_shell',
                     'real_user_id', 'effective_user_id',
                     'effective_group_ids'])


# Generated at 2022-06-23 01:57:44.784636
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    c = UserFactCollector()
    assert c.name == 'user'
    assert c._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                               'user_gecos', 'user_dir', 'user_shell',
                               'real_user_id', 'effective_user_id',
                               'effective_group_ids'])


# Generated at 2022-06-23 01:57:50.708548
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    assert UserFactCollector.name == 'user'
    assert UserFactCollector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                               'user_gecos', 'user_dir', 'user_shell',
                                               'real_user_id', 'effective_user_id',
                                               'effective_group_ids'])

# Generated at 2022-06-23 01:57:56.360041
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact = UserFactCollector()
    assert user_fact._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                     'user_gecos', 'user_dir', 'user_shell',
                     'real_user_id', 'effective_user_id',
                     'effective_group_ids'])


# Generated at 2022-06-23 01:58:04.345908
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    f = UserFactCollector()
    test_dict = f.collect()
    assert test_dict == {
        'effective_group_id': 1000,
        'effective_user_id': 1000,
        'real_group_id': 1000,
        'real_user_id': 1000,
        'user_dir': '/home/ansible',
        'user_gecos': 'ansible,,,',
        'user_gid': 1000,
        'user_id': 'ansible',
        'user_shell': '/bin/zsh',
        'user_uid': 1000
    }

# Generated at 2022-06-23 01:58:06.991981
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    obj = UserFactCollector()
    assert obj.name == "user"


# Generated at 2022-06-23 01:58:08.772364
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ufc_obj = UserFactCollector()
    assert ufc_obj.name == 'user'


# Generated at 2022-06-23 01:58:14.572959
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    collected_facts = {}

    test_object = UserFactCollector()
    result = test_object.collect(collected_facts=collected_facts)
    assert 'user_id' in result
    assert 'user_uid' in result
    assert 'user_gid' in result
    assert 'user_gecos' in result
    assert 'user_dir' in result
    assert 'user_shell' in result
    assert 'real_user_id' in result
    assert 'effective_user_id' in result
    assert 'real_group_id' in result
    assert 'effective_group_id' in result

# Generated at 2022-06-23 01:58:23.514133
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    fact_collector = UserFactCollector()
    assert fact_collector.name == 'user'
    assert fact_collector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                            'user_gecos', 'user_dir', 'user_shell',
                                            'real_user_id', 'effective_user_id',
                                            'effective_group_ids'])
    assert isinstance(fact_collector.collect(), dict)

if __name__ == "__main__":
    fact_collector = UserFactCollector()
    print(fact_collector.collect())

# Generated at 2022-06-23 01:58:25.246194
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user = UserFactCollector()
    result = user.collect()
    assert 'user_id' in result

# Generated at 2022-06-23 01:58:32.249665
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    """Unit test for method collect of class UserFactCollector."""

    obj = UserFactCollector()

    user_facts = obj.collect()
    assert user_facts.get('user_id') == obj.name
    assert user_facts.get('user_uid') == obj.name
    assert user_facts.get('user_gid') == obj.name
    assert user_facts.get('user_gecos') == obj.name
    assert user_facts.get('user_dir') == obj.name
    assert user_facts.get('user_shell') == obj.name

# Generated at 2022-06-23 01:58:33.585123
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    assert UserFactCollector()

# Generated at 2022-06-23 01:58:40.962400
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fc = UserFactCollector()
    assert user_fc._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                     'user_gecos', 'user_dir', 'user_shell',
                                     'real_user_id', 'effective_user_id',
                                     'effective_group_ids'])
    assert user_fc.name == 'user'


# Generated at 2022-06-23 01:58:43.646110
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    x = UserFactCollector()
    assert x.name == 'user'
    assert x.collect()['user_id'] == getpass.getuser()
    assert 'user_id' in x._fact_ids

# Generated at 2022-06-23 01:58:50.312768
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    expected_data = {'user_id': 'bob',
                     'user_uid': '1001',
                     'user_gid': '1001',
                     'user_gecos': None,
                     'user_dir': '/home/bob',
                     'user_shell': '/bin/bash',
                     'real_user_id': '1001',
                     'effective_user_id': '1001',
                     'effective_group_id': '1001'}
    ufc = UserFactCollector()
    test_data = ufc.collect()
    assert test_data == expected_data

# Generated at 2022-06-23 01:58:55.129174
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    fact_collector = UserFactCollector()

    assert fact_collector.name == 'user'
    assert fact_collector._fact_ids == {
        'real_user_id', 'effective_user_id', 'effective_group_ids',
        'user_gid', 'user_shell', 'user_gecos', 'user_id', 'user_dir', 'user_uid'}




# Generated at 2022-06-23 01:59:09.566260
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Method collect of class UserFactCollector
    # Test: no args
    ufc = UserFactCollector()
    result = ufc.collect()

    # Test: validate result
    assert(isinstance(result, dict))
    assert(len(result) > 0)
    assert('user_id' in result['ansible_user_id'])
    assert('user_uid' in result['ansible_user_uid'])
    assert('user_gid' in result['ansible_user_gid'])
    assert('user_gecos' in result['ansible_user_gecos'])
    assert('user_dir' in result['ansible_user_dir'])
    assert('user_shell' in result['ansible_user_shell'])

# Generated at 2022-06-23 01:59:17.007121
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Arrange
    fac = UserFactCollector()
    # Act
    result = fac.collect()
    # Assert
    assert result['user_id'] == 'test'
    assert result['user_gid'] == 1000
    assert result['user_gecos'] == 'test,,,amt'
    assert result['user_dir'] == '/home/test'
    assert result['user_shell'] == '/bin/bash'
    assert result['real_user_id'] == 1000
    assert result['effective_user_id'] == 1000
    assert result['real_group_id'] == 1000
    assert result['effective_group_id'] == 1000

# Generated at 2022-06-23 01:59:24.427474
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector().collect()
    assert user_facts == {
        'user_id': 'test',
        'user_uid': 2000,
        'user_gid': 2000,
        'user_gecos': 'test',
        'user_dir': '/tmp',
        'user_shell': '/bin/bash',
        'real_user_id': 2000,
        'effective_user_id': 2000,
        'real_group_id': 2000,
        'effective_group_id': 2000,
    }

# Generated at 2022-06-23 01:59:32.622833
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fact_module = UserFactCollector(None)
    facts = fact_module.collect()
    assert 'user_id' in facts
    assert 'user_uid' in facts
    assert 'user_gid' in facts
    assert 'user_gecos' in facts
    assert 'user_dir' in facts
    assert 'user_shell' in facts
    assert 'real_user_id' in facts
    assert 'effective_user_id' in facts
    assert 'real_group_id' in facts
    assert 'effective_group_id' in facts

# Generated at 2022-06-23 01:59:37.926394
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_collector = UserFactCollector()
    assert user_collector.name == 'user'

    _fact_ids = set(['user_id', 'user_uid', 'user_gid',
                     'user_gecos', 'user_dir', 'user_shell',
                     'real_user_id', 'effective_user_id',
                     'effective_group_ids'])

    assert user_collector._fact_ids == _fact_ids

# Generated at 2022-06-23 01:59:49.589503
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    fact_collector = UserFactCollector()
    assert fact_collector is not None
    assert fact_collector._fact_ids is not None
    assert len(fact_collector._fact_ids) == 9
    assert 'user_id' in fact_collector._fact_ids
    assert 'user_uid' in fact_collector._fact_ids
    assert 'user_gid' in fact_collector._fact_ids
    assert 'user_gecos' in fact_collector._fact_ids
    assert 'user_dir' in fact_collector._fact_ids
    assert 'user_shell' in fact_collector._fact_ids
    assert 'real_user_id' in fact_collector._fact_ids
    assert 'effective_user_id' in fact_collector._fact_ids

# Generated at 2022-06-23 01:59:52.693603
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
	pass

# Generated at 2022-06-23 01:59:56.029109
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    assert UserFactCollector.name == 'user'
    assert UserFactCollector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                     'user_gecos', 'user_dir', 'user_shell',
                     'real_user_id', 'effective_user_id',
                     'effective_group_ids'])




# Generated at 2022-06-23 02:00:04.568155
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    obj = UserFactCollector()
    assert isinstance(obj, UserFactCollector)

    expected_name = 'user'
    assert obj.name == expected_name

    expected_fact_ids = set(['user_id', 'user_uid', 'user_gid',
                             'user_gecos', 'user_dir', 'user_shell',
                             'real_user_id', 'effective_user_id',
                             'effective_group_ids'])
    assert obj._fact_ids == expected_fact_ids



# Generated at 2022-06-23 02:00:11.814978
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert isinstance(user_fact_collector, BaseFactCollector)
    assert user_fact_collector.name == 'user'
    assert user_fact_collector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                                 'user_gecos', 'user_dir', 'user_shell',
                                                 'real_user_id', 'effective_user_id',
                                                 'effective_group_ids'])


# Generated at 2022-06-23 02:00:22.600656
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fact_collector = UserFactCollector()
    fact_collector.collect()
    assert fact_collector.collect()["user_dir"]
    assert fact_collector.collect()["user_id"]
    assert fact_collector.collect()["effective_user_id"]
    assert fact_collector.collect()["real_user_id"]
    assert fact_collector.collect()["user_uid"]
    assert fact_collector.collect()["user_gecos"]
    assert fact_collector.collect()["user_gid"]
    assert fact_collector.collect()["user_shell"]
    assert fact_collector.collect()["real_group_id"]
    assert fact_collector.collect()["effective_group_id"]