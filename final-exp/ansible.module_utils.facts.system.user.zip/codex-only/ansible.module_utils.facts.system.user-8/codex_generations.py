

# Generated at 2022-06-23 01:50:27.213857
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    """Unit test for method collect of class UserFactCollector."""

    user_facts = {}
    user_facts['user_id'] = getpass.getuser()

    try:
        pwent = pwd.getpwnam(getpass.getuser())
    except KeyError:
        pwent = pwd.getpwuid(os.getuid())

    user_facts['user_uid'] = pwent.pw_uid
    user_facts['user_gid'] = pwent.pw_gid
    user_facts['user_gecos'] = pwent.pw_gecos
    user_facts['user_dir'] = pwent.pw_dir
    user_facts['user_shell'] = pwent.pw_shell
    user_facts['real_user_id'] = os.getuid()


# Generated at 2022-06-23 01:50:29.471240
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()
    assert user_facts != None

# Generated at 2022-06-23 01:50:38.095358
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Prepare test data
    user_id = os.getenv('USER')
    user_uid = os.getuid()
    user_gid = os.getgid()
    user_gecos = os.getlogin()
    user_dir = os.path.expanduser("~")
    user_shell = os.getenv('SHELL')

    # Test collect()
    fact_collector = UserFactCollector()
    user_facts = fact_collector.collect()

    assert isinstance(user_facts, dict)
    assert 'user_id' in user_facts
    assert user_id == user_facts['user_id']
    assert 'user_uid' in user_facts
    assert user_uid == user_facts['user_uid']
    assert 'user_gid' in user_facts
    assert user_

# Generated at 2022-06-23 01:50:42.027478
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    userfact = UserFactCollector()
    user_facts = userfact.collect()
    print("user_facts: {}".format(user_facts))

if __name__ == "__main__":
    test_UserFactCollector_collect()

# Generated at 2022-06-23 01:50:50.448337
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    user_facts = ufc.collect()

    assert (user_facts['user_id'] in [p.pw_name for p in pwd.getpwall()] )
    assert (user_facts['user_uid'] in [p.pw_uid for p in pwd.getpwall()] )
    assert (user_facts['user_gid'] in [p.pw_gid for p in pwd.getpwall()] )
    assert (user_facts['user_gecos'] in [p.pw_gecos for p in pwd.getpwall()] )
    assert (user_facts['user_dir'] in [p.pw_dir for p in pwd.getpwall()] )

# Generated at 2022-06-23 01:51:00.130278
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user  = UserFactCollector()
    facts = user.collect()

    assert facts is not None, "No facts returned"
    assert facts.get('user_id') and \
           facts.get('user_id') != 'nobody', "user_id is incorrect"
    assert facts.get('user_uid') and \
           facts.get('user_uid') != 0, "user_uid is incorrect"
    assert facts.get('user_gid') and \
           facts.get('user_gid') != 0, "user_gid is incorrect"
    assert facts.get('user_gecos') and \
           facts.get('user_gecos') != '', "user_gecos is incorrect"

# Generated at 2022-06-23 01:51:11.252303
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    '''Test for method UserFactCollector.collect'''
    passwd = {'name': getpass.getuser(), 'dir': '/tmp'}

    try:
        user = pwd.getpwnam(getpass.getuser())
        passwd['uid'] = user.pw_uid
    except KeyError:
        user = pwd.getpwuid(os.getuid())
        passwd['uid'] = user.pw_uid

    test = UserFactCollector()
    res = test.collect()

    assert(res['user_id'] == passwd['name'])
    assert(res['user_uid'] == passwd['uid'])
    assert(res['user_dir'] == passwd['dir'])
    assert(res['real_user_id'] == passwd['uid'])

# Generated at 2022-06-23 01:51:19.423186
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fact_collector = UserFactCollector()
    assert fact_collector.collect() ==  {
        'user_id': 'test_user',
        'user_uid': 1000,
        'user_gid': 1000,
        'real_user_id': 1000,
        'effective_user_id': 1000,
        'real_group_id': 1000,
        'effective_group_id': 1000,
        'user_gecos': 'Test User',
        'user_shell': '/bin/bash',
        'user_dir': '/home/test_user'
    }

# Generated at 2022-06-23 01:51:23.590769
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_facts = UserFactCollector()

    assert user_facts.name == 'user'
    assert user_facts._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                        'user_gecos', 'user_dir', 'user_shell',
                                        'real_user_id', 'effective_user_id',
                                        'effective_group_ids'])


# Generated at 2022-06-23 01:51:25.527880
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    UserFactColl = UserFactCollector()
    assert  UserFactColl.name == "user"


# Generated at 2022-06-23 01:51:31.698269
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    obj = UserFactCollector()
    assert obj.name == 'user'
    assert obj._fact_ids == set(['user_id', 'user_uid', 'user_gid',
        'user_gecos', 'user_dir', 'user_shell', 'real_user_id',
        'effective_user_id', 'effective_group_ids'])


# Generated at 2022-06-23 01:51:36.252628
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    assert UserFactCollector._fact_ids == {'user_id', 'user_uid', 'user_gid', 'user_gecos', 'user_dir', 'user_shell', 'real_user_id', 'effective_user_id', 'effective_group_ids'}
    assert UserFactCollector.name == 'user'

# Generated at 2022-06-23 01:51:44.354634
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()

    user_facts = user_fact_collector.collect()

    assert isinstance(user_facts, dict)
    assert user_facts['user_id'] == getpass.getuser()
    assert isinstance(user_facts['user_id'], str)

    assert user_facts['user_uid'] == os.getuid()
    assert isinstance(user_facts['user_uid'], int)

    assert user_facts['user_gid'] == os.getgid()
    assert isinstance(user_facts['user_gid'], int)

    assert isinstance(user_facts['user_gecos'], str)

    assert isinstance(user_facts['user_dir'], str)

    assert isinstance(user_facts['user_shell'], str)



# Generated at 2022-06-23 01:51:49.811441
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user = UserFactCollector()
    assert user.name == 'user'
    assert user._fact_ids == {'user_id', 'user_uid', 'user_gid',
                              'user_gecos', 'user_dir', 'user_shell',
                              'real_user_id', 'effective_user_id',
                              'effective_group_ids'}
    assert 'user_id' in user.collect()

# Generated at 2022-06-23 01:51:51.421612
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    # Constructor test
    my_obj = UserFactCollector()
    assert my_obj

# Generated at 2022-06-23 01:52:00.649817
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Create instance and two dictionaries, one empty and one with sample values
    u = UserFactCollector()
    a = {}
    b = {'user_id': 'testuser', 'user_uid': 1010, 'user_gid': 1010, 'user_gecos': 'Test User', 'user_dir': '/home/testuser', 'user_shell': '/bin/bash', 'real_user_id': 1010, 'effective_user_id': 1010, 'real_group_id': 1010, 'effective_group_id': 1010}
    # Call collect method
    c = u.collect()
    # Test that the output of the method collect is as expected
    assert c == b

# Generated at 2022-06-23 01:52:05.419728
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert user_fact_collector
    assert user_fact_collector.name == "user"
    assert user_fact_collector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                                 'user_gecos', 'user_dir', 'user_shell',
                                                 'real_user_id', 'effective_user_id',
                                                 'effective_group_ids'])

# Generated at 2022-06-23 01:52:08.221404
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user = UserFactCollector()
    facts = user.collect()
    assert len(facts.keys()) == 9
    for fact in user._fact_ids:
        assert fact in facts.keys()

# Generated at 2022-06-23 01:52:16.626144
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user = UserFactCollector()
    user_facts = user.collect()

    assert 'user_id' in user_facts
    assert type(user_facts['user_id']) == str

    assert 'user_uid' in user_facts
    assert type(user_facts['user_uid']) == int

    assert 'user_gid' in user_facts
    assert type(user_facts['user_gid']) == int

    assert 'user_gecos' in user_facts
    assert type(user_facts['user_gecos']) == str

    assert 'user_dir' in user_facts
    assert type(user_facts['user_dir']) == str

    assert 'user_shell' in user_facts
    assert type(user_facts['user_shell']) == str


# Generated at 2022-06-23 01:52:22.343178
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    # Test constructor of UserFactCollector
    user_fact_collector = UserFactCollector()
    assert isinstance(user_fact_collector, UserFactCollector)
    assert 'user' == user_fact_collector.name
    assert isinstance(user_fact_collector._fact_ids, set)
    assert set(['user_id',
                'user_uid',
                'user_gid',
                'user_gecos',
                'user_dir',
                'user_shell',
                'real_user_id',
                'effective_user_id',
                'effective_group_ids']) == user_fact_collector._fact_ids


# Generated at 2022-06-23 01:52:28.723772
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_facts = UserFactCollector()
    assert user_facts.name == 'user'
    assert user_facts._fact_ids == set(['user_id', 'user_uid', 'user_gid', 'user_gecos',
                                        'user_dir', 'user_shell', 'real_user_id',
                                        'effective_user_id', 'effective_group_ids'])


# Generated at 2022-06-23 01:52:33.762657
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    assert UserFactCollector.name == "user"
    assert UserFactCollector._fact_ids == set(["user_id", "user_uid", "user_gid", "user_gecos", "user_dir", "user_shell",
                                               "real_user_id", "effective_user_id", "effective_group_ids"])
    

# Generated at 2022-06-23 01:52:40.181103
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert user_fact_collector.name == 'user'
    assert user_fact_collector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                                 'user_gecos', 'user_dir', 'user_shell',
                                                 'real_user_id', 'effective_user_id',
                                                 'effective_group_ids'])


# Generated at 2022-06-23 01:52:52.394885
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    obj = UserFactCollector()
    assert obj.name == 'user'
    assert obj._fact_ids == {'user_id', 'user_uid', 'user_gid', 'user_gecos', 'user_dir', 'user_shell', 'real_user_id', 'effective_user_id', 'effective_group_ids'}

    assert obj.collect()

    obj2 = UserFactCollector()
    assert obj.name == 'user'
    assert obj._fact_ids == {'user_id', 'user_uid', 'user_gid', 'user_gecos', 'user_dir', 'user_shell', 'real_user_id', 'effective_user_id', 'effective_group_ids'}

    assert obj2.collect()

# Generated at 2022-06-23 01:53:00.220922
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_facts = UserFactCollector()
    assert user_facts.name == 'user'
    assert user_facts._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                        'user_gecos', 'user_dir', 'user_shell',
                                        'real_user_id', 'effective_user_id',
                                        'effective_group_ids'])

# Generated at 2022-06-23 01:53:02.088848
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    userFactCollector = UserFactCollector()
    assert userFactCollector.name == "user"

# Generated at 2022-06-23 01:53:09.279191
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()

    user_fact_collector.collect(collected_facts={})

    assert "user_id" in user_fact_collector.collected_facts
    assert "user_uid" in user_fact_collector.collected_facts
    assert "user_gid" in user_fact_collector.collected_facts
    assert "user_gecos" in user_fact_collector.collected_facts
    assert "user_dir" in user_fact_collector.collected_facts
    assert "user_shell" in user_fact_collector.collected_facts
    assert "real_user_id" in user_fact_collector.collected_facts
    assert "effective_user_id" in user_fact_collector.collected_facts

# Generated at 2022-06-23 01:53:17.022704
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert user_fact_collector.name == 'user'
    assert set(user_fact_collector._fact_ids) == set(['user_id', 'user_uid', 'user_gid',
                                                      'user_gecos', 'user_dir', 'user_shell',
                                                      'real_user_id', 'effective_user_id',
                                                      'effective_group_ids'])



# Generated at 2022-06-23 01:53:19.239106
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
   assert UserFactCollector.name == 'user'


# Generated at 2022-06-23 01:53:21.885798
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    test_user_collector = UserFactCollector()
    assert test_user_collector is not None

# Generated at 2022-06-23 01:53:28.285322
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_facts = UserFactCollector()
    assert user_facts.name == 'user'
    user_facts_ids = set(user_facts._fact_ids)
    assert user_facts_ids == set(['user_id', 'user_uid', 'user_gid',
                                  'user_gecos', 'user_dir', 'user_shell',
                                  'real_user_id', 'effective_user_id',
                                  'effective_group_ids'])


# Generated at 2022-06-23 01:53:33.675693
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ufc = UserFactCollector()
    assert ufc.name == 'user'
    assert ufc._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                 'user_gecos', 'user_dir', 'user_shell',
                                 'real_user_id', 'effective_user_id',
                                 'effective_group_ids'])

# Generated at 2022-06-23 01:53:39.044220
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ufc1 = UserFactCollector()
    assert ufc1.name == 'user'
    assert ufc1._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                     'user_gecos', 'user_dir', 'user_shell',
                     'real_user_id', 'effective_user_id',
                     'effective_group_ids'])

# Generated at 2022-06-23 01:53:43.823667
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    assert UserFactCollector().name == 'user'
    assert UserFactCollector()._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                                 'user_gecos', 'user_dir', 'user_shell',
                                                 'real_user_id', 'effective_user_id',
                                                 'effective_group_ids'])

# Generated at 2022-06-23 01:53:45.139545
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    obj = UserFactCollector()
    assert  obj.name == 'user'

# Generated at 2022-06-23 01:53:45.722439
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    pass

# Generated at 2022-06-23 01:53:48.154490
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    test_obj = UserFactCollector()
    result = test_obj.collect()
    assert result.get('user_id') == 'root'


# Generated at 2022-06-23 01:53:56.616050
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_collector = UserFactCollector()
    user_facts = user_collector.collect()

    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['user_uid'] == pwd.getpwuid(os.getuid()).pw_uid
    assert user_facts['real_user_id'] == os.getuid()
    assert user_facts['effective_user_id'] == os.geteuid()
    assert user_facts['real_group_id'] == os.getgid()
    assert user_facts['effective_group_id'] == os.getegid()
    assert user_facts['user_gid'] == pwd.getpwuid(os.getuid()).pw_gid

# Generated at 2022-06-23 01:54:00.285686
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    assert set(UserFactCollector()._fact_ids) == set([
        'user_id', 'user_uid', 'user_gid', 'user_gecos', 'user_dir', 'user_shell',
        'real_user_id', 'effective_user_id', 'effective_group_ids'
    ])

# Generated at 2022-06-23 01:54:10.646752
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    """
    AnsibleModule context test for Platform fact class.
    """
    user_facts = UserFactCollector().collect()

    #Tests for following keys of dictionary 'user_facts'
    assert 'user_id' in user_facts, "user fact not found"

    #Tests for keys 'user_id' of dictionary 'user_facts'
    assert user_facts['user_id'] is not None, "user_facts['user_id'] is None"

    #Tests for keys 'user_uid' of dictionary 'user_facts'
    assert user_facts['user_uid'] is not None, "user_facts['user_uid'] is None"

    #Tests for keys 'user_gid' of dictionary 'user_facts'

# Generated at 2022-06-23 01:54:16.639460
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    userCollector = UserFactCollector()
    assert userCollector.name == 'user'
    assert userCollector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                           'user_gecos', 'user_dir', 'user_shell',
                                           'real_user_id', 'effective_user_id',
                                           'effective_group_ids'])

# Generated at 2022-06-23 01:54:26.065307
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    f = UserFactCollector()
    assert f
    assert f.name == 'user'

    assert f._fact_ids is not None
    assert isinstance(f._fact_ids, set)
    assert 'user_id' in f._fact_ids
    assert 'user_uid' in f._fact_ids
    assert 'user_gid' in f._fact_ids
    assert 'user_gecos' in f._fact_ids
    assert 'user_dir' in f._fact_ids
    assert 'user_shell' in f._fact_ids
    assert 'real_user_id' in f._fact_ids
    assert 'effective_user_id' in f._fact_ids
    assert 'effective_group_ids' in f._fact_ids


# Generated at 2022-06-23 01:54:36.010905
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    class MockPwd():

        def __init__(self, pw_name, pw_uid, pw_gid, pw_gecos, pw_dir, pw_shell):
                self.pw_name = pw_name
                self.pw_uid  = pw_uid
                self.pw_gid  = pw_gid
                self.pw_gecos= pw_gecos
                self.pw_dir  = pw_dir
                self.pw_shell= pw_shell
                pass

        def getpwnam(self, getpass_getuser):
                return self

        def getpwuid(self, os_getuid):
                return self

    # Define a class function getuser to return a fixed name

# Generated at 2022-06-23 01:54:38.997827
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user = UserFactCollector()
    print("User Fact Collector data is : {}".format(user))

test_UserFactCollector()

# Generated at 2022-06-23 01:54:46.525444
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    fact_collector = UserFactCollector()
    assert type(fact_collector) == UserFactCollector
    assert fact_collector.name == 'user'
    assert type(fact_collector._fact_ids) == set
    assert {'user_id', 'user_uid', 'user_gid',
            'user_gecos', 'user_dir', 'user_shell',
            'real_user_id', 'effective_user_id',
            'effective_group_ids'} == fact_collector._fact_ids


# Generated at 2022-06-23 01:54:55.851615
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    # Stub the getpwnam method
    def stub_getpwnam():
        from collections import namedtuple
        pw = namedtuple('pw', ['pw_uid', 'pw_gid', 'pw_gecos', 'pw_dir', 'pw_shell'])
        return pw(1, 2, 3, 4, 5)

    # Stub the getpwuid method
    def stub_getpwuid():
        from collections import namedtuple
        pw = namedtuple('pw', ['pw_uid', 'pw_gid', 'pw_gecos', 'pw_dir', 'pw_shell'])
        return pw(1, 2, 3, 4, 5)

    # Stub os.getuid() and os.geteuid() methods

# Generated at 2022-06-23 01:55:05.906036
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector().collect()

    assert 'user_id' in user_facts
    assert 'user_uid' in user_facts
    assert 'user_gid' in user_facts
    assert 'user_gecos' in user_facts
    assert 'user_dir' in user_facts
    assert 'user_shell' in user_facts
    assert 'real_user_id' in user_facts
    assert 'effective_user_id' in user_facts
    assert 'effective_group_ids' in user_facts

# Generated at 2022-06-23 01:55:11.174206
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    assert UserFactCollector().name == 'user'
    assert UserFactCollector()._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                                 'user_gecos', 'user_dir', 'user_shell',
                                                 'real_user_id', 'effective_user_id',
                                                 'effective_group_ids'])

# Generated at 2022-06-23 01:55:14.111260
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    assert UserFactCollector.name == 'user'
    assert UserFactCollector._fact_ids == \
           set(['user_id', 'user_uid', 'user_gid',
                'user_gecos', 'user_dir', 'user_shell',
                'real_user_id', 'effective_user_id',
                'effective_group_ids'])


# Generated at 2022-06-23 01:55:14.912058
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    UserFactCollector()

# Generated at 2022-06-23 01:55:23.997527
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_obs = UserFactCollector()
    user_obs.collect()
    assert 'user_id' in user_obs.fact_ids
    assert 'user_uid' in user_obs.fact_ids
    assert 'user_gid' in user_obs.fact_ids
    assert 'user_gecos' in user_obs.fact_ids
    assert 'user_dir' in user_obs.fact_ids
    assert 'user_shell' in user_obs.fact_ids
    assert 'real_user_id' in user_obs.fact_ids
    assert 'effective_user_id' in user_obs.fact_ids
    assert 'real_group_id' in user_obs.fact_ids
    assert 'effective_group_id' in user_obs.fact_ids

# Generated at 2022-06-23 01:55:34.166321
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fc = UserFactCollector
    facts = fc.collect(None, None)
    assert facts['user_id'] == getpass.getuser()
    assert facts['user_uid'] == os.getuid()
    assert facts['user_gid'] == os.getgid()
    assert facts['user_dir'] == os.getenv("HOME")
    assert facts['user_shell'] == os.getenv("SHELL")
    assert facts['real_user_id'] == os.getuid()
    assert facts['effective_user_id'] == os.geteuid()
    assert facts['real_group_id'] == os.getgid()
    assert facts['effective_group_id'] == os.getgid()

# Generated at 2022-06-23 01:55:44.516270
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    u = UserFactCollector()
    result = u.collect()
    assert result['user_id'] == getpass.getuser()
    assert result['user_uid'] == os.getuid()
    assert result['user_gid'] == os.getgid()
    assert result['user_gecos'] == pwd.getpwuid(os.getuid())[4]
    assert result['user_dir'] == pwd.getpwuid(os.getuid())[5]
    assert result['user_shell'] == pwd.getpwuid(os.getuid())[6]
    assert result['real_user_id'] == os.getuid()
    assert result['effective_user_id'] == os.geteuid()
    assert result['effective_group_ids'] == os.getgroups()

# Unit

# Generated at 2022-06-23 01:55:51.285222
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ufc = UserFactCollector()
    assert ufc.name == 'user'
    assert ufc._fact_ids == {'user_id', 'user_uid', 'user_gid',
                             'user_gecos', 'user_dir',
                             'user_shell', 'real_user_id',
                             'effective_user_id', 'effective_group_ids'}
    assert ufc.collect()['user_id'] == getpass.getuser()

# Generated at 2022-06-23 01:55:57.800414
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    from ansible.module_utils.facts import FactCollector

    user_fact = UserFactCollector()
    fact_collector = FactCollector(user_fact)
    facts = fact_collector.collect(module=None, collected_facts=None)

    assert facts['user_id'] == getpass.getuser()
    assert facts['user_uid'] == pwd.getpwnam(getpass.getuser()).pw_uid
    assert facts['user_gid'] == pwd.getpwnam(getpass.getuser()).pw_gid

# Generated at 2022-06-23 01:56:02.994619
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    result = ufc.collect()
    # Only checking few of the values.
    assert result['user_id'] == getpass.getuser()
    assert int(result['effective_group_id']) == os.getegid()
    assert result['user_dir'] == pwd.getpwuid(os.getuid())[5]

# Generated at 2022-06-23 01:56:06.696745
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ufc = UserFactCollector()
    assert set(ufc._fact_ids) == set(['user_id', 'user_uid', 'user_gid',
                                      'user_gecos', 'user_dir', 'user_shell',
                                      'real_user_id', 'effective_user_id',
                                      'effective_group_ids'])

# Generated at 2022-06-23 01:56:09.169466
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    print("Testing constructor of UserFactCollector")
    user_fact_collector = UserFactCollector()
    assert user_fact_collector.name == 'user'

# Generated at 2022-06-23 01:56:16.678398
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    c = UserFactCollector()
    assert c.name == 'user'
    assert c.priority == 40
    assert c._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                               'user_gecos', 'user_dir', 'user_shell',
                               'real_user_id', 'effective_user_id',
                               'effective_group_ids'])

# Generated at 2022-06-23 01:56:19.415587
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    foo = UserFactCollector()
    assert foo.name == 'user', foo.name


# Generated at 2022-06-23 01:56:29.402325
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector().collect()["ansible_facts"]

    assert(user_facts['user_id'] == getpass.getuser())
    assert(user_facts['user_uid'] == os.getuid())
    assert(user_facts['user_gid'] == os.getgid())
    assert(user_facts['user_gecos'] == pwd.getpwuid(os.getuid()).pw_gecos)
    assert(user_facts['user_dir'] == pwd.getpwuid(os.getuid()).pw_dir)
    assert(user_facts['user_shell'] == pwd.getpwuid(os.getuid()).pw_shell)
    assert(user_facts['real_user_id'] == os.getuid())

# Generated at 2022-06-23 01:56:30.165882
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    pass

# Generated at 2022-06-23 01:56:35.962414
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    fct_collector = UserFactCollector()
    assert(fct_collector.name == 'user')
    assert(fct_collector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                           'user_gecos', 'user_dir', 'user_shell',
                                           'real_user_id', 'effective_user_id',
                                           'effective_group_ids']))

# Generated at 2022-06-23 01:56:44.037012
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_obj = UserFactCollector()
    assert user_obj.name == 'user'
    assert isinstance(user_obj._fact_ids, set)
    assert user_obj._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                      'user_gecos', 'user_dir', 'user_shell',
                                      'real_user_id', 'effective_user_id',
                                      'effective_group_ids'])



# Generated at 2022-06-23 01:56:50.615076
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_facts = UserFactCollector.collect()
    assert 'user_id' in user_facts
    assert 'user_uid' in user_facts
    assert 'user_gid' in user_facts
    assert 'user_gecos' in user_facts
    assert 'user_dir' in user_facts
    assert 'user_shell' in user_facts
    assert 'real_user_id' in user_facts
    assert 'effective_user_id' in user_facts
    assert 'real_group_id' in user_facts
    assert 'effective_group_id' in user_facts

# Generated at 2022-06-23 01:56:55.086245
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_ids = {'user_id', 'user_uid', 'user_gid',
                'user_gecos', 'user_dir', 'user_shell',
                'real_user_id', 'effective_user_id'}
    assert UserFactCollector()._fact_ids == user_ids

# Generated at 2022-06-23 01:57:01.733770
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Get test fixture
    user1_facts = UserFactCollector().collect()

    # Check some facts are gathered
    if not user1_facts:
        return False

    # Check gathered facts
    if user1_facts['user_id'] != 'test_user':
        return False

    if user1_facts['user_uid'] != 1000:
        return False

    if user1_facts['user_gid'] != 1000:
        return False

    if user1_facts['user_gecos'] != 'Test User':
        return False

    if user1_facts['user_dir'] != '/home/test_user':
        return False

    if user1_facts['user_shell'] != '/bin/bash':
        return False

    if user1_facts['real_user_id'] != 1000:
        return False


# Generated at 2022-06-23 01:57:07.224534
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    obj = UserFactCollector()
    assert obj.name == 'user'
    assert obj._fact_ids == {'user_id', 'user_uid', 'user_gid',
                     'user_gecos', 'user_dir', 'user_shell',
                     'real_user_id', 'effective_user_id',
                     'effective_group_ids'}


# Generated at 2022-06-23 01:57:14.263690
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import ansible.module_utils.facts.collectors.user as BaseFactCollector
    fact = BaseFactCollector.UserFactCollector()
    user_facts = fact.collect()
    assert 'user_id' in user_facts
    assert 'user_uid' in user_facts
    assert 'user_gid' in user_facts
    assert 'user_gecos' in user_facts
    assert 'user_dir' in user_facts
    assert 'user_shell' in user_facts
    assert 'real_user_id' in user_facts
    assert 'effective_user_id' in user_facts
    assert 'real_group_id' in user_facts
    assert 'effective_group_id' in user_facts

# Generated at 2022-06-23 01:57:19.737327
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    collector = UserFactCollector()
    assert collector.name == 'user'
    assert collector._fact_ids == {'effective_group_ids', 'effective_user_id', 'real_group_id', 'user_uid', 'user_id', 'user_shell', 'user_gid', 'real_user_id', 'user_gecos', 'user_dir'}

# Generated at 2022-06-23 01:57:23.241464
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert user_fact_collector.name == 'user'

# Generated at 2022-06-23 01:57:29.451110
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    ufc = UserFactCollector()

    assert ufc.name == 'user'
    assert 'user_id' in ufc._fact_ids
    assert 'user_gecos' in ufc._fact_ids
    assert 'real_user_id' in ufc._fact_ids

# Generated at 2022-06-23 01:57:40.040073
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    def __getattr__(self, attr):
        return attr

    module_mock = type('module_mock', (object,), {'__getattr__': __getattr__})()
    module_mock.params = {}
    module_mock.ansible_facts = {}
    module_mock.run_command = lambda x: (0, '', '')
    user_fact_collector = UserFactCollector(module_mock)
    user_fact_collector.collect()
    assert module_mock.ansible_facts['user_id'] == 'root'
    assert module_mock.ansible_facts['user_dir'] == '/root'
    assert module_mock.ansible_facts['real_user_id'] == 0

# Generated at 2022-06-23 01:57:43.680274
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    testCollector = UserFactCollector()
    assert type(testCollector) == UserFactCollector

# Generated at 2022-06-23 01:57:55.208152
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Create a fake module
    class FakeModule(object):
        def __init__(self):
            self.params = { 'collect_user_id': True,
                            'collect_user_uid': True,
                            'collect_user_gid': True,
                            'collect_user_gecos': True,
                            'collect_user_dir': True,
                            'collect_user_shell': True,
                            'collect_real_user_id': True,
                            'collect_effective_user_id': True,
                            'collect_real_group_id': True,
                            'collect_effective_group_id': True }

    ufc = UserFactCollector()
    facts = ufc.collect(module=FakeModule())
    print(facts)
    assert 'user_id' in facts
   

# Generated at 2022-06-23 01:58:02.123450
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    c = UserFactCollector()
    assert c.name == 'user'
    assert c._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                     'user_gecos', 'user_dir', 'user_shell',
                     'real_user_id', 'effective_user_id',
                     'effective_group_ids'])

# Generated at 2022-06-23 01:58:08.464900
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    # Instantiate UserFactCollector
    ufc = UserFactCollector()

    # Check UserFactCollector parameters
    assert ufc.name == "user"
    assert ufc._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                 'user_gecos', 'user_dir', 'user_shell',
                                 'real_user_id', 'effective_user_id',
                                 'effective_group_ids'])

# Generated at 2022-06-23 01:58:17.890601
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    import unittest

    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    def mock_getpwnam(_):
        pwent = pwd.struct_passwd()
        pwent.pw_uid = 1000
        pwent.pw_gid = 1000
        pwent.pw_gecos = "root"
        pwent.pw_dir = "/root"
        pwent.pw_shell = "/bin/bash"
        return pwent


# Generated at 2022-06-23 01:58:21.469985
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    print("Constructor test of class UserFactCollector")
    ufc = UserFactCollector()

    if type(ufc) == UserFactCollector:
        print('PASS')
    else:
        print('FAIL')


# Generated at 2022-06-23 01:58:30.242325
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    f = UserFactCollector()
    assert f.name == 'user'
    assert f._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                               'user_gecos', 'user_dir', 'user_shell',
                               'real_user_id', 'effective_user_id',
                               'effective_group_ids'])


# Generated at 2022-06-23 01:58:36.312712
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    test_obj = UserFactCollector()
    result = test_obj.collect(collect_default=False)
    assert result == {
        'user_dir': '/home/ansible',
        'user_gecos': 'ansible',
        'user_gid': 1000,
        'user_id': 'ansible',
        'user_shell': '/bin/bash',
        'user_uid': 1000,
        'real_user_id': 1000,
        'effective_user_id': 1000,
        'real_group_id': 1000,
        'effective_group_id': 1000
    }

# Generated at 2022-06-23 01:58:46.959903
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    dummy_module = None
    dummy_collected_facts = None

    user_fact_collector_object = UserFactCollector()

    user_facts = user_fact_collector_object.collect(dummy_module, dummy_collected_facts)

    cur_user = getpass.getuser()
    pwent = pwd.getpwnam(getpass.getuser())

    assert user_facts['user_id'] == cur_user
    assert user_facts['user_uid'] == pwent.pw_uid
    assert user_facts['user_gid'] == pwent.pw_gid
    assert user_facts['user_gecos'] == pwent.pw_gecos
    assert user_facts['user_dir'] == pwent.pw_dir

# Generated at 2022-06-23 01:58:55.491342
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    collected_facts = {}
    collected_facts = user_fact_collector.collect(collected_facts)
    assert "user_id" in collected_facts
    assert "user_uid" in collected_facts
    assert "user_gid" in collected_facts
    assert "user_gecos" in collected_facts
    assert "user_dir" in collected_facts
    assert "user_shell" in collected_facts
    assert "real_user_id" in collected_facts
    assert "effective_user_id" in collected_facts
    assert "real_group_id" in collected_facts
    assert "effective_group_id" in collected_facts


# Generated at 2022-06-23 01:59:07.987583
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fact_collector = UserFactCollector()
    facts = fact_collector.collect()

    user_facts = {
        'user_id'         : '',
        'user_uid'        : 0,
        'user_gid'        : 0,
        'user_gecos'      : '',
        'user_dir'        : '',
        'user_shell'      : '',
        'real_user_id'    : 0,
        'effective_user_id': 0,
        'real_group_id'   : 0,
        'effective_group_id' : 0,
    }

    assert facts == user_facts

# Generated at 2022-06-23 01:59:10.687335
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert isinstance(user_fact_collector, UserFactCollector)


# Generated at 2022-06-23 01:59:12.645153
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fact_collector = UserFactCollector()
    fact_collector.collect()
    assert fact_collector._collected_facts 


# Generated at 2022-06-23 01:59:24.527151
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    os.getuid = lambda: 0
    os.geteuid = lambda: 0
    os.getgid = lambda: 0

    pwent = pwd.struct_passwd((
        'root',
        '',
        0,
        0,
        '',
        '/root',
        '/bin/bash'
    ))

    pwd.getpwnam = lambda x: pwent
    pwd.getpwuid = lambda x: pwent

    getpass.getuser = lambda: 'root'

    fac = UserFactCollector()


# Generated at 2022-06-23 01:59:31.758181
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    user_fact_collector = UserFactCollector()
    assert user_fact_collector.name == "user"
    assert user_fact_collector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                     'user_gecos', 'user_dir', 'user_shell',
                     'real_user_id', 'effective_user_id',
                     'effective_group_ids'])
    # TODO: test collect()

# Generated at 2022-06-23 01:59:37.856848
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collector = UserFactCollector()
    facts = collector.collect()
    assert facts["user_dir"] == "/home/buildbot"
    assert facts["user_gid"] == 1000
    assert facts["user_gecos"] == "buildbot,,,"
    assert facts["user_id"] == "buildbot"
    assert facts["user_shell"] == "/bin/sh"
    assert facts["user_uid"] == 1000
    assert facts["effective_group_ids"] == [1000]
    assert facts["effective_user_id"] == 1000
    assert facts["real_user_id"] == 1000

# Generated at 2022-06-23 01:59:40.112173
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user = UserFactCollector()
    user_facts = user.collect()
    assert set(user_facts.keys()).issubset(user._fact_ids)

# Generated at 2022-06-23 01:59:47.252588
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    obj = UserFactCollector()
    assert obj.name == 'user'
    assert obj._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                 'user_gecos', 'user_dir', 'user_shell',
                                 'real_user_id', 'effective_user_id',
                                 'effective_group_ids'])
    assert obj.collect()['user_id'] == getpass.getuser()

# Generated at 2022-06-23 01:59:52.155627
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    from ansible.module_utils.facts.collector.user import UserFactCollector
    from ansible.module_utils.facts import get_all_facts
    result = get_all_facts(['user'])
    assert result['ansible_user_id'] == UserFactCollector().collect()['user_id']


# Generated at 2022-06-23 02:00:01.230927
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    facts_collector = UserFactCollector()
    assert facts_collector.name == 'user'
    assert facts_collector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                             'user_gecos', 'user_dir', 'user_shell',
                                             'real_user_id', 'effective_user_id',
                                             'real_group_id', 'effective_group_id'])



# Generated at 2022-06-23 02:00:11.997951
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    from ansible.module_utils.facts import FactCache
    from ansible.module_utils.facts.collector import FactCollector
    collected_facts = FactCache()
    module = None
    fact_collector = FactCollector()
    fact_collector._fact_collectors = [UserFactCollector()]
    collected_facts = fact_collector.collect(module=module, collected_facts=collected_facts)
    assert set(collected_facts.keys()) == {
        'user_id',
        'user_uid',
        'user_gid',
        'user_gecos',
        'user_dir',
        'user_shell',
        'real_user_id',
        'effective_user_id',
        'real_group_id',
        'effective_group_id'
    }

# Generated at 2022-06-23 02:00:14.049160
# Unit test for constructor of class UserFactCollector
def test_UserFactCollector():
    u = UserFactCollector()

    assert u.name == 'user'
    assert len(u._fact_ids) == 9


# Generated at 2022-06-23 02:00:21.797892
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    temp = UserFactCollector()
    result = temp.collect()
    assert result == {'user_id': 'root', 'user_uid': 0, 'user_gid': 0, 'user_gecos': 'root', 'user_dir': '/root', 'user_shell': '/bin/bash', 'real_user_id': 0, 'effective_user_id': 0, 'real_group_id': 0, 'effective_group_id': 0}