

# Generated at 2022-06-11 05:20:57.379873
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    import os
    import pwd

    test_user = 'test_user'
    test_user_gecos = 'test user,this is a test'

    if test_user not in pwd.getpwall():
        os.system('useradd %s -c \'%s\'' % (test_user, test_user_gecos))

    from ansible.module_utils.facts.collector import BaseFactCollector

    class UserFactCollector(BaseFactCollector):

        name = 'user'
        _fact_ids = set(['user_id', 'user_uid', 'user_gid',
                         'user_gecos', 'user_dir', 'user_shell',
                         'real_user_id', 'effective_user_id',
                         'effective_group_ids'])


# Generated at 2022-06-11 05:21:04.653857
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    collected_facts = {'random_fact': "A_RANDOM_FACT",
                       'user_id': "A_USER_FACT"}
    user_facts = ufc.collect(collected_facts=collected_facts)
    assert collected_facts == {'random_fact': "A_RANDOM_FACT",
                               'user_id': "A_USER_FACT"}
    assert user_facts['user_id'] == getpass.getuser()

# Generated at 2022-06-11 05:21:07.962736
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts_dic = user_fact_collector.collect()
    assert type(user_facts_dic) == dict
    assert len(user_facts_dic) == 9

# Generated at 2022-06-11 05:21:13.322183
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Test UserFactCollector.collect(module=None, collected_facts=None)
    # Input parameters:
    #   module:
    #   collected_facts:
    # Expected results:
    #   An empty dictionary
    user_collector = UserFactCollector()
    result = user_collector.collect()
    assert type(result) is dict
    assert len(result) == 0


# Generated at 2022-06-11 05:21:23.045069
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()

    # test if user_id is equal to the current user
    assert(user_facts['user_id'] == getpass.getuser())

    # test if real_user_id is equal to os.getuid()
    assert(user_facts['real_user_id'] == os.getuid())

    # test if effective_user_id is equal to os.geteuid()
    assert(user_facts['effective_user_id'] == os.geteuid())

    # test if real_group_id is equal to os.getgid()
    assert(user_facts['real_group_id'] == os.getgid())

    # test if effective_group_id is equal to os.getegid()


# Generated at 2022-06-11 05:21:33.179499
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Check UserFactCollector class can collect from user fact
    user = UserFactCollector()
    collected_facts = user.collect()
    assert collected_facts['user_id'] == getpass.getuser()

    # Check UserFactCollector class can collect from user fact
    user = UserFactCollector()
    collected_facts = user.collect()

    # Check UserFactCollector return correct facts
    assert 'user_id' in collected_facts
    assert 'user_uid' in collected_facts
    assert 'user_gid' in collected_facts
    assert 'user_gecos' in collected_facts
    assert 'user_dir' in collected_facts
    assert 'user_shell' in collected_facts
    assert 'real_user_id' in collected_facts
    assert 'effective_user_id' in collected_facts

# Generated at 2022-06-11 05:21:43.309871
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    # Create an instance of class UserFactCollector
    user_fact_collector = UserFactCollector()

    user_facts = user_fact_collector.collect()

    if isinstance(user_facts['user_id'], type('')):
        pass
    else:
        raise Exception("user_facts['user_id'] is not a string: %r" % user_facts['user_id'])

    # Test that user_facts['user_uid'] is a string
    if isinstance(user_facts['user_uid'], type(0)):
        pass
    else:
        raise Exception("user_facts['user_uid'] is not an integer: %r" % user_facts['user_uid'])

    if isinstance(user_facts['user_gid'], type(0)):
        pass

# Generated at 2022-06-11 05:21:51.318666
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fact_collector = UserFactCollector()
    facts = fact_collector.collect()
    assert isinstance(facts, dict)
    assert 'user_id' in facts
    assert 'user_uid' in facts
    assert 'user_gid' in facts
    assert 'user_gecos' in facts
    assert 'user_dir' in facts
    assert 'user_shell' in facts
    assert 'real_user_id' in facts
    assert 'effective_user_id' in facts
    assert 'effective_group_id' in facts



# Generated at 2022-06-11 05:22:00.586275
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import pwd
    test_pwd = pwd.getpwuid(os.getuid())
    ufc = UserFactCollector()
    result = ufc.collect()

    assert result['user_id'] == getpass.getuser()
    assert result['user_uid'] == test_pwd.pw_uid
    assert result['user_gid'] == test_pwd.pw_gid
    assert result['user_gecos'] == test_pwd.pw_gecos
    assert result['user_dir'] == test_pwd.pw_dir
    assert result['user_shell'] == test_pwd.pw_shell
    assert result['real_user_id'] == os.getuid()
    assert result['effective_user_id'] == os.geteuid()

# Generated at 2022-06-11 05:22:08.524534
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector()
    assert user_facts.collect() == {
        'effective_user_id': 1000,
        'effective_group_ids': [1000],
        'real_user_id': 1000,
        'real_group_id': 1000,
        'user_dir': '/home/test',
        'user_gecos': 'Test User',
        'user_gid': 1000,
        'user_id': 'test',
        'user_shell': '/bin/bash',
        'user_uid': 1000,
    }

# Generated at 2022-06-11 05:22:12.813217
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector()
    print(user_facts.collect())


if __name__ == "__main__":
    test_UserFactCollector_collect()

# Generated at 2022-06-11 05:22:23.032231
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    test_user_id = 'test'

    test_user_shell = '/bin/sh'
    test_user_home = '/home'
    test_user_gecos = 'test'
    test_user_gid = 1000
    test_user_uid = 1000
    test_effective_user_id = 1000

    # Arrange
    import pwd
    from unittest.mock import patch
    from ansible.module_utils.facts.collector.user import UserFactCollector

    target = UserFactCollector()

    result = pwd.struct_passwd(('', '*', test_user_uid, test_user_gid, '',
                                test_user_home, test_user_shell))


# Generated at 2022-06-11 05:22:29.693160
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    """ Unit test for method collect of class UserFactCollector """

    fact_collector = UserFactCollector()

    expected_facts_result = {'user_id': getpass.getuser(),
                             'user_uid': os.getuid(),
                             'user_gid': os.getgid(),
                             'user_gecos': '',
                             'user_dir': '',
                             'user_shell': '/bin/false',
                             'real_user_id': os.getuid(),
                             'effective_user_id': os.geteuid()}

    # Test normal behavior
    facts_result = fact_collector.collect()
    assert facts_result == expected_facts_result

# Generated at 2022-06-11 05:22:39.718780
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    userFactCollector = UserFactCollector()
    # Test collect returned data
    userFactCollector.collect()
    assert 'user_id' in userFactCollector.collect()
    assert 'user_uid' in userFactCollector.collect()
    assert 'user_gid' in userFactCollector.collect()
    assert 'user_gecos' in userFactCollector.collect()
    assert 'user_dir' in userFactCollector.collect()
    assert 'user_shell' in userFactCollector.collect()
    assert 'real_user_id' in userFactCollector.collect()
    assert 'effective_user_id' in userFactCollector.collect()
    assert 'real_group_id' in userFactCollector.collect()
    assert 'effective_group_id' in userFactCollector.collect()

# Generated at 2022-06-11 05:22:49.718439
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    real_user_id = os.getuid()
    effective_user_id = os.geteuid()
    assert(effective_user_id == real_user_id)
    fact_collector = UserFactCollector()
    fact_collector.collect()
    collected_facts = fact_collector.get_facts()
    assert(collected_facts['user_id'] == getpass.getuser())
    assert(collected_facts['user_uid'] == os.getuid())
    assert(collected_facts['user_gid'] == os.getgid())
    assert(collected_facts['user_gecos'] == pwd.getpwuid(os.getuid()).pw_gecos)

# Generated at 2022-06-11 05:22:57.834888
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user = UserFactCollector()
    facts = user.collect()
    assert facts['user_id'] == getpass.getuser()
    pwent = pwd.getpwnam(getpass.getuser())
    assert facts['user_uid'] == pwent.pw_uid
    assert facts['user_gid'] == pwent.pw_gid
    assert facts['user_gecos'] == pwent.pw_gecos
    assert facts['user_dir'] == pwent.pw_dir
    assert facts['user_shell'] == pwent.pw_shell
    assert facts['real_user_id'] == os.getuid()
    assert facts['effective_user_id'] == os.geteuid()
    assert facts['real_group_id'] == os.getgid()

# Generated at 2022-06-11 05:23:00.129128
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    test_obj = UserFactCollector()
    test_obj._module = object()
    test_obj.collect()

# vim: set et ts=4 sw=4 :

# Generated at 2022-06-11 05:23:09.957357
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    userFactCollector = UserFactCollector()

# Generated at 2022-06-11 05:23:19.041564
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector.collect()

    assert type(user_facts) == dict
    assert len(user_facts) == 9
    assert user_facts['user_id'] == getpass.getuser()

    try:
        pwent = pwd.getpwnam(getpass.getuser())
    except KeyError:
        pwent = pwd.getpwuid(os.getuid())

    assert user_facts['user_uid'] == pwent.pw_uid
    assert user_facts['user_gid'] == pwent.pw_gid
    assert user_facts['user_gecos'] == pwent.pw_gecos
    assert user_facts['user_dir'] == pwent.pw_dir
    assert user_facts['user_shell'] == pwent.pw_shell


# Generated at 2022-06-11 05:23:23.559740
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    u = UserFactCollector()
    results = u.collect()
    assert results['real_user_id'] == os.getuid()
    assert results['effective_user_id'] == os.geteuid()
    assert results['user_id'] == getpass.getuser()
    assert isinstance(results['effective_group_ids'], list)

# Generated at 2022-06-11 05:23:28.665144
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

   col = UserFactCollector()
   res = col.collect()
   assert res['user_id'] == getpass.getuser()
   assert res['user_uid'] == os.getuid()
   assert res['user_gid'] == os.getgid()

# Generated at 2022-06-11 05:23:34.754479
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    uf = ufc.collect()


# Generated at 2022-06-11 05:23:42.534185
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector().collect()

    assert 'user_id' in user_facts
    assert 'user_uid' in user_facts
    assert 'user_gid' in user_facts
    assert 'user_gecos' in user_facts
    assert 'user_dir' in user_facts
    assert 'user_shell' in user_facts
    assert 'real_user_id' in user_facts
    assert 'effective_user_id' in user_facts
    assert 'real_group_id' in user_facts
    assert 'effective_group_id' in user_facts

# Generated at 2022-06-11 05:23:47.877012
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector().collect()

    assert user_facts['user_id'] == user_facts['real_user_id']
    assert user_facts['user_id'] == user_facts['effective_user_id']
    assert user_facts['user_id'] == user_facts['real_group_id']
    assert user_facts['user_id'] == user_facts['effective_group_id']

# Generated at 2022-06-11 05:23:55.149886
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import Collectors

    module = Collectors._init_module()

    user_fact_collector = UserFactCollector()
    facts_dict = user_fact_collector.collect(module)

    assert Collector.get_fact('user_id', facts_dict) == getpass.getuser()
    assert Collector.get_fact('user_uid', facts_dict) >= 0
    assert Collector.get_fact('user_gid', facts_dict) >= 0
    assert Collector.get_fact('user_gecos', facts_dict) == pwd.getpwnam(getpass.getuser()).pw_gecos

# Generated at 2022-06-11 05:23:56.891786
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    instance = UserFactCollector()
    assert instance.collect()['user_id'] == getpass.getuser()

# Generated at 2022-06-11 05:24:06.186587
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector().collect()
    assert user_facts['user_id'] is not None
    assert user_facts['user_uid'] is not None
    assert user_facts['user_gid'] is not None
    assert user_facts['user_gecos'] is not None
    assert user_facts['user_dir'] is not None
    assert user_facts['user_shell'] is not None
    assert user_facts['real_user_id'] is not None
    assert user_facts['effective_user_id'] is not None
    assert user_facts['real_group_id'] is not None
    assert user_facts['effective_group_id'] is not None

# Generated at 2022-06-11 05:24:15.369500
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    '''
    unit test fonction collect de la classe UserFactCollector.
    test si les differentes clef sont présentes dans les facts.
    '''
    a = UserFactCollector()
    b = a.collect()

    assert 'user_id' in b
    assert 'user_uid' in b
    assert 'user_gid' in b
    assert 'user_gecos' in b
    assert 'user_dir' in b
    assert 'user_shell' in b
    assert 'real_user_id' in b
    assert 'effective_user_id' in b
    assert 'real_group_id' in b
    assert 'effective_group_id' in b

# Generated at 2022-06-11 05:24:22.990863
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    
    collector = UserFactCollector()
    facts_dictionary = collector.collect(module=None, collected_facts=None)
    assert 'user_id' in facts_dictionary.keys()
    assert 'user_uid' in facts_dictionary.keys()
    assert 'user_gid' in facts_dictionary.keys()
    assert 'user_gecos' in facts_dictionary.keys()
    assert 'user_dir' in facts_dictionary.keys()
    assert 'user_shell' in facts_dictionary.keys()
    assert 'real_user_id' in facts_dictionary.keys()
    assert 'effective_user_id' in facts_dictionary.keys()
    assert 'real_group_id' in facts_dictionary.keys()

# Generated at 2022-06-11 05:24:34.058533
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # set up object and mocks
    obj = UserFactCollector()
    m = UserFactCollector()

    mock_getuser = m.getuser
    mock_getuser.return_value = 'user'

    mock_getpwnam = m.getpwnam
    mock_getpwnam.return_value = 'user'

    mock_getuid = m.getuid
    mock_getuid.return_value = 'user'

    mock_geteuid = m.geteuid
    mock_geteuid.return_value = 'user'

    mock_getgid = m.getgid
    mock_getgid.return_value = 'user'

    mock_getegid = m.getegid
    mock_getegid.return_value = 'user'

    # call method and assert


# Generated at 2022-06-11 05:24:47.178535
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector().collect()

    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['real_user_id'] == os.getuid()
    assert user_facts['effective_user_id'] == os.geteuid()
    assert user_facts['real_group_id'] == os.getgid()
    assert user_facts['effective_group_id'] == os.getgid()
    assert user_facts['user_uid'] == pwd.getpwuid(os.getuid()).pw_uid
    assert user_facts['user_gid'] == pwd.getpwuid(os.getuid()).pw_gid
    assert user_facts['user_gecos'] == pwd.getpwuid(os.getuid()).p

# Generated at 2022-06-11 05:24:57.050625
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector().collect()
    assert(user_facts['user_id'] == getpass.getuser())
    assert(user_facts['effective_user_id'] == os.geteuid())
    assert(user_facts['user_gecos'] == pwd.getpwnam(getpass.getuser()).pw_gecos)
    assert(user_facts['user_gid'] == pwd.getpwnam(getpass.getuser()).pw_gid)
    assert(user_facts['user_dir'] == pwd.getpwnam(getpass.getuser()).pw_dir)
    assert(user_facts['user_shell'] == pwd.getpwnam(getpass.getuser()).pw_shell)

# Generated at 2022-06-11 05:24:59.372007
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fc = UserFactCollector()
    result = fc.collect()

    assert result['user_id'] == getpass.getuser()


# Generated at 2022-06-11 05:25:08.262947
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    u_fc = UserFactCollector()

    def pwd_getpwnam_mock(x):
        class pwent:
            pw_uid = 500
            pw_gid = 500
            pw_gecos = "Test User"
            pw_dir = "/tmp"
            pw_shell = "/bin/bash"
        return pwent()

    import __builtin__
    original_pwd_getpwnam = __builtin__.getpwnam

    __builtin__.getpwnam = pwd_getpwnam_mock

    try:
        user_facts = u_fc.collect()
    finally:
        __builtin__.getpwnam = original_pwd_getpwnam

    assert user_facts['user_uid'] == 500
    assert user_facts

# Generated at 2022-06-11 05:25:16.709568
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import sys
    sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
    from ansible.module_utils.facts import FactCollector
    fact_collector = FactCollector()
    user_fact_collector = UserFactCollector(fact_collector)
    user_facts = user_fact_collector.collect()
    assert user_facts['user_id'] == 'root'
    assert user_facts['user_uid'] == 0
    assert user_facts['user_gid'] == 0
    assert user_facts['user_gecos'] == 'root'
    assert user_facts['user_dir'] == '/root'
    assert user_facts['user_shell'] == '/bin/bash'
    assert user_facts['real_user_id'] == 0

# Generated at 2022-06-11 05:25:21.940947
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import ansible.module_utils.facts.system.user as user
    from ansible.module_utils.facts.collector import BaseFactCollector
    user_collector = user.UserFactCollector()
    # Test if we doing inheritance of BaseFactCollector
    assert issubclass(user.UserFactCollector, BaseFactCollector)

    # Test if collect method return dictionary
    assert isinstance(user_collector.collect(), dict)

# Generated at 2022-06-11 05:25:31.829838
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    uc = UserFactCollector()
    user_facts = uc.collect()
    assert type(user_facts) is dict
    assert type(user_facts['user_id']) is str
    assert type(user_facts['user_uid']) is int
    assert type(user_facts['user_gid']) is int
    assert type(user_facts['user_gecos']) is str
    assert type(user_facts['user_dir']) is str
    assert type(user_facts['user_shell']) is str
    assert type(user_facts['real_user_id']) is int
    assert type(user_facts['effective_user_id']) is int
    assert type(user_facts['real_group_id']) is int
    assert type(user_facts['effective_group_id'])

# Generated at 2022-06-11 05:25:38.724808
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector().collect()
    assert user_facts['user_id']
    assert user_facts['user_uid']
    assert user_facts['user_gid']
    assert user_facts['user_gecos']
    assert user_facts['user_dir']
    assert user_facts['user_shell']
    assert user_facts['real_user_id']
    assert user_facts['real_group_id']
    assert user_facts['effective_user_id']
    assert user_facts['effective_group_id']

# Generated at 2022-06-11 05:25:49.417061
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collector = UserFactCollector()
    user = pwd.getpwnam(getpass.getuser())
    facts = collector.collect()
    assert user.pw_gecos == facts['user_gecos']
    assert user.pw_uid == facts['user_uid']
    assert user.pw_gid == facts['user_gid']
    assert user.pw_dir == facts['user_dir']
    assert user.pw_shell == facts['user_shell']
    assert user.pw_uid == facts['real_user_id']
    assert user.pw_uid == facts['effective_user_id']
    assert user.pw_gid == facts['real_group_id']
    assert user.pw_gid == facts['effective_group_id']
    assert user.pw

# Generated at 2022-06-11 05:25:57.633242
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    collected_facts = user_fact_collector.collect()
    assert collected_facts['user_id'] == getpass.getuser()
    assert collected_facts['user_id'] == collected_facts['real_user_id']
    assert collected_facts['user_id'] == collected_facts['effective_user_id']
    assert collected_facts['user_id'] == collected_facts['real_group_id']
    assert collected_facts['user_id'] == collected_facts['effective_group_id']
    assert collected_facts['user_uid'] == pwd.getpwuid(collected_facts['user_id']).pw_uid

# Generated at 2022-06-11 05:26:13.640438
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    class UserFactCollectorTest(object):
        user_id = 'john'

        def getpwnam(self, user):
            if user == 'john':
                return type('test', (object,), {
                    'pw_uid': 1000,
                    'pw_gid': 1000,
                    'pw_gecos': 'John Doe',
                    'pw_dir': '/home/john',
                    'pw_shell': '/bin/bash'
                })
            else:
                raise KeyError('No such user: %s' % user)


# Generated at 2022-06-11 05:26:22.936553
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    class MockPW(object):
        pw_uid = 42
        pw_gid = 43
        pw_gecos = 'test user'
        pw_dir = '/tmp'
        pw_shell = '/bin/sh'

    collector = UserFactCollector()


# Generated at 2022-06-11 05:26:30.875462
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    '''
    Ensure that we correctly return a dictionary of facts about the
    current user
    '''
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collectors.system import UserFactCollector
    import subprocess

    # Ensure that UserFactCollector is one of the default facts collectors
    assert UserFactCollector in default_collectors

    # Create a FactsCollector
    facts_collector = FactsCollector()

    # Generate some fake facts
    fake_facts = { 'a_fake_fact' : 'fake_value' }

    # Get the current user
    whoami = subprocess.check_output(['/usr/bin/whoami'], universal_newlines=True)

    #

# Generated at 2022-06-11 05:26:33.077291
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    facts = ufc.collect()
    for fact in ufc._fact_ids:
        assert fact in facts

# Generated at 2022-06-11 05:26:36.079241
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    real_user_id = os.getuid()
    user_facts = UserFactCollector()
    user_facts.collect()
    assert user_facts.get_facts()['real_user_id'] == real_user_id

# Generated at 2022-06-11 05:26:43.528084
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector.collect()
    assert 'user_id' in user_facts
    assert 'user_uid' in user_facts
    assert 'user_gid' in user_facts
    assert 'user_gecos' in user_facts
    assert 'user_dir' in user_facts
    assert 'user_shell' in user_facts
    assert 'real_user_id' in user_facts
    assert 'effective_user_id' in user_facts
    assert 'effective_group_ids' in user_facts


if __name__ == '__main__':
    test_UserFactCollector_collect()

# Generated at 2022-06-11 05:26:52.493730
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    """ Return a bool for the test result """

    # Create a UserFactCollector object
    fact_collector = UserFactCollector()

    # Check the facts collected are correct
    facts_collected = fact_collector.collect()
    assert facts_collected['user_id'] == getpass.getuser()
    assert facts_collected['real_user_id'] == os.getuid()
    assert facts_collected['effective_user_id'] == os.geteuid()
    assert facts_collected['real_group_id'] == os.getgid()
    assert facts_collected['effective_group_id'] == os.getgid()

# Generated at 2022-06-11 05:26:57.350081
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    module = None
    collected_facts = {}
    collector = UserFactCollector()
    result = collector.collect(module, collected_facts)

    assert result['user_id'] == getpass.getuser()
    assert result['real_user_id'] == os.getuid()
    assert result['effective_user_id'] == os.geteuid()
    assert 'real_group_id' in result

# Generated at 2022-06-11 05:27:05.305422
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    res = ufc.collect()

    # check result
    assert isinstance(res, dict)
    assert (('user_id' in res) and isinstance(res['user_id'], str))
    assert (('user_uid' in res) and isinstance(res['user_uid'], int))
    assert (('user_gid' in res) and isinstance(res['user_gid'], int))
    assert (('user_gecos' in res) and isinstance(res['user_gecos'], str))
    assert (('user_dir' in res) and isinstance(res['user_dir'], str))
    assert (('user_shell' in res) and isinstance(res['user_shell'], str))

# Generated at 2022-06-11 05:27:11.153823
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect(): # pylint: disable=too-many-locals
    fact_defs = {'user_shell':False, 'user_gecos':False, 'real_user_id':False}
    fact_collector = UserFactCollector(fact_defs)

    collected_facts = None

    collected_facts = fact_collector.collect()

    assert collected_facts != None
    assert collected_facts != {}

    for fact in fact_defs:
        assert fact in collected_facts


# Generated at 2022-06-11 05:27:24.189115
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Create instance of UserFactCollector
    use = UserFactCollector()
    # Test method
    assert use.collect() == {
            'user_id': 'test',
            'user_uid': 1000,
            'user_gid': 1000,
            'user_gecos': 'test,,,',
            'user_dir': '/home/test',
            'user_shell': '/bin/bash',
            'real_user_id': 1000,
            'effective_user_id': 1000,
            'real_group_id': 1000,
            'effective_group_id': 1000,
            }

# Generated at 2022-06-11 05:27:31.579504
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = {}
    user_facts['user_id'] = getpass.getuser()
    user_facts['user_uid'] = os.getuid()
    user_facts['user_gid'] = os.getgid()
    user_facts['real_user_id'] = os.getuid()
    user_facts['effective_user_id'] = os.geteuid()
    user_facts['real_group_id'] = os.getgid()
    user_facts['effective_group_id'] = os.getgid()

    ufc = UserFactCollector()
    res = ufc.collect()
    assert(user_facts == res)

# Generated at 2022-06-11 05:27:40.480847
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import os
    import pwd
    import unittest

    class mock(object):
        @staticmethod
        def getuser():
            return 'root'

        @staticmethod
        def getuid():
            return 0

        @staticmethod
        def geteuid():
            return 0

        @staticmethod
        def getgid():
            return 0

        @staticmethod
        def getegid():
            return 0

    class mockpw(object):
        @staticmethod
        def getpwnam(n):
            return 'root'

        @staticmethod
        def getpwuid(n):
            return '0'

    class mockos(object):
        @staticmethod
        def getuid():
            return 0

        @staticmethod
        def geteuid():
            return 0


# Generated at 2022-06-11 05:27:47.629798
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    u_collec = UserFactCollector()
    fake_fact = {'user_id': 'ccvincello',
                 'user_gid': 1000,
                 'user_gecos': 'Cristian Vincello,,,',
                 'user_shell': '/bin/bash',
                 'user_uid': 1000,
                 'user_dir': '/home/ccvincello',
                 'effective_group_id': 1000,
                 'effective_user_id': 1000,
                 'real_group_id': 1000,
                 'real_user_id': 1000}
    assert fake_fact == u_collec.collect()

# Generated at 2022-06-11 05:27:49.609896
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    facts = ufc.collect()
 
    assert set(facts.keys()) == ufc._fact_ids

# Generated at 2022-06-11 05:27:54.112888
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    collected_facts = user_fact_collector.collect()
    assert collected_facts['user_id'] == 'root'
    assert collected_facts['user_uid'] == 0
    assert collected_facts['user_gid'] == 0
    assert collected_facts['user_gecos'] == 'root'
    assert collected_facts['user_dir'] == '/root'
    assert collected_facts['user_shell'] == '/bin/bash'
    assert collected_facts['real_user_id'] == 0
    assert collected_facts['effective_user_id'] == 0
    assert collected_facts['real_group_id'] == 0
    assert collected_facts['effective_group_id'] == 0


# Generated at 2022-06-11 05:27:55.867555
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user = UserFactCollector()

    assert 'user_id' in user.collect()


# Generated at 2022-06-11 05:28:05.584075
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collector = UserFactCollector()
    user_facts = collector.collect()
    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['user_uid'] == os.getuid()
    assert user_facts['user_gid'] == os.getgid()
    assert user_facts['user_gecos'] == pwd.getpwuid(os.getuid()).pw_gecos
    assert user_facts['user_dir'] == os.path.expanduser("~")
    assert user_facts['user_shell'] == pwd.getpwuid(os.getuid()).pw_shell
    assert user_facts['real_user_id'] == os.getuid()
    assert user_facts['effective_user_id'] == os.geteuid()

# Generated at 2022-06-11 05:28:11.577100
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    """
    Test the UserFactCollector and its collect function
    """
    user_facts_collector = UserFactCollector()
    facts = user_facts_collector.collect()
    assert len(facts) > 0
    assert isinstance(facts, dict)
    assert 'user_id' in facts
    assert 'user_uid' in facts
    assert 'user_gid' in facts
    assert 'user_gecos' in facts
    assert 'user_dir' in facts
    assert 'user_shell' in facts
    assert 'real_user_id' in facts
    assert 'effective_user_id' in facts
    assert 'real_group_id' in facts
    assert 'effective_group_id' in facts

# Generated at 2022-06-11 05:28:13.330178
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fc = UserFactCollector()
    result = user_fc.collect()
    print(result)

# Generated at 2022-06-11 05:28:27.366288
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    '''Testing UserFactCollector.collect'''
    collector = UserFactCollector()
    user_facts = collector.collect()

    # Test if the user dicts are the same
    assert_user_facts = dict([('user_id', getpass.getuser()),
                              ('user_dir', pwd.getpwnam(getpass.getuser()).pw_dir),
                              ('real_user_id', os.getuid()),
                              ('effective_user_id', os.geteuid())])

    assert user_facts == assert_user_facts

# Generated at 2022-06-11 05:28:35.169249
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    """Test collect method of class UserFactCollector"""
    user_facts = UserFactCollector().collect()
    assert isinstance(user_facts, dict)
    assert 'user_id' in user_facts
    assert 'user_uid' in user_facts
    assert 'user_gid' in user_facts
    assert 'user_gecos' in user_facts
    assert 'user_dir' in user_facts
    assert 'user_shell' in user_facts
    assert 'real_user_id' in user_facts
    assert 'effective_user_id' in user_facts
    assert 'real_group_id' in user_facts
    assert 'effective_group_id' in user_facts

# Generated at 2022-06-11 05:28:39.118471
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    userfactcollector = UserFactCollector()
    result = userfactcollector.collect()
    with open('/etc/passwd', 'r') as f:
        for line in f:
            for part in line.split(':'):
                if part == result['user_uid']:
                    assert True


# Generated at 2022-06-11 05:28:46.158687
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fact_collector = UserFactCollector()
    fact_collector.collect()
    assert fact_collector.atoms == {'user_id': 'user',
                                    'user_uid': "uid",
                                    'user_gid': "gid",
                                    'user_gecos': "gecos",
                                    'user_dir': "dir",
                                    'user_shell': "shell",
                                    'real_user_id': "uid",
                                    'effective_user_id': "uid",
                                    'real_group_id': "gid",
                                    'effective_group_id': "gid"}

# Generated at 2022-06-11 05:28:54.906852
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    try:
        import pwd
    except ImportError:
        return

    from ansible.module_utils.facts import FactCollector
    import inspect

    module = None
    collected_facts = None

    # Instantiation of UserFactCollector class
    userfactcollector = FactCollector['user']()

    # Method collect call
    collected_facts = userfactcollector.collect(module, collected_facts)

    real_user_id = pwd.getpwnam(getpass.getuser()).pw_uid
    effective_user_id = os.geteuid()
    real_group_id = os.getgid()
    effective_group_id = os.getegid()

    # Unit tests
    assert (collected_facts['user_id'] == getpass.getuser())

# Generated at 2022-06-11 05:29:02.408968
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user = UserFactCollector()
    user_facts = user.collect()
    assert user_facts['user_id']
    assert user_facts['user_uid']
    assert user_facts['user_gid']
    assert user_facts['user_gecos']
    assert user_facts['user_dir']
    assert user_facts['user_shell']
    assert user_facts['real_user_id']
    assert user_facts['effective_user_id']

if __name__ == '__main__':
    test_UserFactCollector_collect()

# Generated at 2022-06-11 05:29:11.672397
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    user_facts = ufc.collect()
    # Get the user name
    user = getpass.getuser()
    # Get the user info
    pwent = pwd.getpwnam(getpass.getuser())
    # Test the user_id facts
    assert user == user_facts['user_id']
    # Test the user_uid facts
    assert pwent.pw_uid == user_facts['user_uid']
    # Test the user_gid facts
    assert pwent.pw_gid == user_facts['user_gid']
    # Test the user_gecos facts
    assert pwent.pw_gecos == user_facts['user_gecos']
    # Test the user_dir facts

# Generated at 2022-06-11 05:29:13.227230
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    
    user_fact_collector = UserFactCollector()
    user_fact_collector.collect()

# Generated at 2022-06-11 05:29:22.713240
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    from ansible.module_utils.facts.collector.user import UserFactCollector
    from ansible.module_utils.facts.facts import Facts
    from ansible.module_utils.facts.collector import BaseFactCollector

    fact_collector = UserFactCollector(BaseFactCollector())
    # Test the function returned by BaseFactCollector.collect
    collected_facts = Facts(BaseFactCollector())
    # In the following statement, replaced 'local' by 'remo'
    # since code 'getpass.getuser()' returns 'local'

# Generated at 2022-06-11 05:29:31.941363
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Initialize the UserFactCollector
    get_user = UserFactCollector()

    # Variable to store the collected user facts
    user_facts = {}

    # Collect user facts
    user_facts = get_user.collect()

    # Verify the user facts are collected
    assert user_facts['user_id'] != 'None'
    assert user_facts['user_uid'] != 'None'
    assert user_facts['user_gid'] != 'None'
    assert user_facts['user_gecos'] != 'None'
    assert user_facts['user_dir'] != 'None'
    assert user_facts['user_shell'] != 'None'
    assert user_facts['real_user_id'] != 'None'
    assert user_facts['effective_user_id'] != 'None'

# Generated at 2022-06-11 05:29:53.212974
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collector = UserFactCollector()
    user_facts = collector.collect()

    assert user_facts['user_id'] is not None
    assert user_facts['user_uid'] is not None
    assert user_facts['user_gid'] is not None
    assert user_facts['user_gecos'] is not None
    assert user_facts['user_dir'] is not None
    assert user_facts['user_shell'] is not None
    assert user_facts['real_user_id'] is not None
    assert user_facts['effective_user_id'] is not None
    assert user_facts['real_group_id'] is not None
    assert user_facts['effective_group_id'] is not None



# Generated at 2022-06-11 05:29:55.009375
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    fact_result = ufc.collect()
    assert fact_result['user_id'] == getpass.getuser()

# Generated at 2022-06-11 05:29:56.682331
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    user_facts = ufc.collect()
    assert user_facts.has_key('user_id')

# Generated at 2022-06-11 05:30:05.633132
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Create object of UserFactCollector class
    ufc = UserFactCollector()

    # Call collect method of UserFactCollector class
    result = ufc.collect()

    # Test returned value
    assert type(result) is dict
    assert set(result.keys()) == set(['user_id', 'user_uid', 'user_gid', 'user_gecos', 'user_dir', 'user_shell', 'real_user_id', 'effective_user_id', 'real_group_id', 'effective_group_id'])

    # Test returned values
    for key in result.keys():
        assert type(result[key]) is str or type(result[key]) is int


# Generated at 2022-06-11 05:30:14.319193
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collector = UserFactCollector(None)
    facts_dict = {}
    facts = collector.collect(facts_dict=facts_dict)
    # Check size of returned dictionary
    assert len(facts) == len(collector._fact_ids)
    # Check keys of returned dictionary
    assert set(facts.keys()) == collector._fact_ids
    # Check some facts
    assert isinstance(facts['user_id'], basestring)
    assert isinstance(facts['user_uid'], (int, long))
    assert isinstance(facts['user_gid'], (int, long))
    assert isinstance(facts['user_gecos'], basestring)
    assert isinstance(facts['user_dir'], basestring)
    assert isinstance(facts['user_shell'], basestring)

# Generated at 2022-06-11 05:30:16.398345
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fact_collector = UserFactCollector(None, None)

    fact_collector.collect()
    assert getpass._raw_input == 'getpass.getuser'

# Generated at 2022-06-11 05:30:25.039323
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    collected_facts = user_fact_collector.collect()
    # Since we are testing with different userid on unit test,
    # hence we will not be able to assert on user_id 
    #assert collected_facts['user_id'] == 'vagrant'
    assert collected_facts['user_gid'] == 1000
    assert collected_facts['user_gecos'] == 'Vagrant'
    assert collected_facts['user_dir'] == '/home/vagrant'
    assert collected_facts['user_shell'] == '/bin/bash'
    assert collected_facts['real_user_id'] == 1000
    assert collected_facts['effective_user_id'] == 1000
    assert collected_facts['real_group_id'] == 1000

# Generated at 2022-06-11 05:30:33.003211
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fact_collector = UserFactCollector()
    facts = fact_collector.collect()
    assert facts['user_id'] == getpass.getuser()
    assert facts['user_uid'] == os.getuid()
    assert facts['user_gid'] == os.getgid()
    assert facts['user_gecos'] == pwd.getpwnam(getpass.getuser()).pw_gecos
    assert facts['user_dir'] == pwd.getpwnam(getpass.getuser()).pw_dir
    assert facts['user_shell'] == pwd.getpwnam(getpass.getuser()).pw_shell
    assert facts['real_user_id'] == os.getuid()
    assert facts['effective_user_id'] == os.geteuid()

# Generated at 2022-06-11 05:30:38.612676
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import os
    import pytest
    from sys import version_info
    from types import ModuleType
    from types import FunctionType
    from types import MethodType
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import collector

    assert os.path.isdir('/')
    assert os.path.isdir('/etc')
    assert os.path.isdir('/etc/ansible')
    assert os.path.isdir('/etc/ansible/facts.d')
    if 'redhat' in platform.dist():
        assert os.path.isfile('/etc/redhat-release')
    elif 'SuSE' in platform.dist():
        assert os.path.isfile('/etc/SuSE-release')

# Generated at 2022-06-11 05:30:45.356653
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()

    assert('user_id' in user_facts.keys())
    assert('user_uid' in user_facts.keys())
    assert('user_gid' in user_facts.keys())
    assert('user_gecos' in user_facts.keys())
    assert('user_dir' in user_facts.keys())
    assert('user_shell' in user_facts.keys())
    assert('real_user_id' in user_facts.keys())
    assert('effective_user_id' in user_facts.keys())
    assert('effective_group_ids' in user_facts.keys())