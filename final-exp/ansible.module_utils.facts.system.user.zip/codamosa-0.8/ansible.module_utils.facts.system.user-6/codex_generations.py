

# Generated at 2022-06-11 05:20:53.318861
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    data = ufc.collect()
    assert data['user_id'] == getpass.getuser()

    assert 'user_uid' in data
    assert 'user_gid' in data
    assert 'user_gecos' in data
    assert 'user_dir' in data
    assert 'user_shell' in data
    assert 'real_user_id' in data
    assert 'effective_user_id' in data
    assert 'real_group_id' in data
    assert 'effective_group_id' in data

# Generated at 2022-06-11 05:21:04.185890
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import mock
    import facts
    from facts.collectors.user import UserFactCollector
    from facts.utils.module import FakeModule

    mock_module = FakeModule(name='ansible.module_utils.facts.collectors.user')
    mock_module.collect_facts = mock.MagicMock()
    mock_module.collect_facts.return_value = {}

    fact_collector = UserFactCollector(module=mock_module)

    # Test with no parameters
    fact_collector.collect()
    mock_module.collect_facts.assert_called_with()

    # Test with parameter
    mock_module.collect_facts.reset_mock()
    mock_module.collect_facts.return_value = {}
    fact_collector.collect(module=mock_module)
    mock_module.collect_

# Generated at 2022-06-11 05:21:06.292232
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    c = UserFactCollector()
    facts = c.collect()

    assert facts['user_id']

# Generated at 2022-06-11 05:21:07.637664
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fact_collector = UserFactCollector()
    fact_collector.collect()

# Generated at 2022-06-11 05:21:09.991879
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    facts_collector = UserFactCollector()
    results = facts_collector.collect()
    # TODO: Write the testing code here


# Generated at 2022-06-11 05:21:18.316697
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    """
    Test case for method 'collect' of class 'UserFactCollector'
    """
    this_mod = sys.modules[__name__]
    user_fact_collector = UserFactCollector()

    # Test if 'user_id' is correctly set
    user_fact_collector.collect()
    user_id = getattr(this_mod, 'user_id')
    assert user_id == getpass.getuser()

    # Test if 'user_uid' is correctly set
    user_fact_collector.collect()
    user_uid = getattr(this_mod, 'user_uid')
    try:
        pwent = pwd.getpwnam(getpass.getuser())
    except KeyError:
        pwent = pwd.getpwuid(os.getuid())

    assert user_

# Generated at 2022-06-11 05:21:29.631174
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector().collect()

# Generated at 2022-06-11 05:21:32.558381
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_collector = UserFactCollector()
    user_facts = user_collector.collect()

    assert isinstance(user_facts, dict)
    assert 'user_id' in user_facts
    assert isinstance(user_facts['user_id'], str)

# Generated at 2022-06-11 05:21:33.502434
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    pass


# Generated at 2022-06-11 05:21:42.476027
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collecter = UserFactCollector()
    # execute and check it ran ok
    assert collecter.collect()
    user_facts = collecter.collect()

    assert 'user_id' in user_facts
    assert 'user_uid' in user_facts
    assert 'user_gid' in user_facts
    assert 'user_gecos' in user_facts
    assert 'user_dir' in user_facts
    assert 'user_shell' in user_facts
    assert 'real_user_id' in user_facts
    assert 'effective_user_id' in user_facts
    assert 'real_group_id' in user_facts
    assert 'effective_group_id' in user_facts

# Generated at 2022-06-11 05:21:55.094176
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import pwd
    from ansible.module_utils.facts.collector import BaseFactCollector

    test_obj = UserFactCollector()
    test_obj._name = 'user'
    test_obj._fact_ids = set(['user_id', 'user_uid', 'user_gid',
                     'user_gecos', 'user_dir', 'user_shell',
                     'real_user_id', 'effective_user_id',
                     'effective_group_ids'])

    getpass.getuser = lambda: 'test_user'

    pwent = pwd.getpwnam('test_user')
    pwd.getpwnam = lambda x: pwent

    os.getuid = lambda: 10
    os.geteuid = lambda: 11
    os.getgid = lambda: 12

    output

# Generated at 2022-06-11 05:21:56.614798
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Unit: test_UserFactCollector_collect
    # Setup:
    user_fact_collector = UserFactCollector()
    # Expect:
    assert user_fact_collector is not None

# Generated at 2022-06-11 05:21:58.495931
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ''' unit test for test_UserFactCollector_collect'''

    fc = UserFactCollector()
    assert not fc.is_valid

# Generated at 2022-06-11 05:22:04.945101
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector().collect()
    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['user_uid'] == os.getuid()
    assert user_facts['user_gid'] == os.getgid()
    assert user_facts['user_gecos'] == pwd.getpwuid(os.getuid()).pw_gecos
    assert user_facts['user_dir'] == pwd.getpwuid(os.getuid()).pw_dir
    assert user_facts['user_shell'] == pwd.getpwuid(os.getuid()).pw_shell
    assert user_facts['real_user_id'] == os.getuid()
    assert user_facts['effective_user_id'] == os.geteuid()
   

# Generated at 2022-06-11 05:22:16.371543
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Test case 1 - Simple user_id, user_uid, user_gid and user_shell.
    pwent = pwd.struct_passwd(('tester', 'x', '1000', '1000', 'Tester', '/home/tester', '/bin/bash'))
    pwd.getpwnam = lambda x : pwent
    pwd.getpwuid = lambda x : pwent
    user = UserFactCollector()
    result = user.collect()
    assert result.get('user_id') == 'tester'
    assert result.get('user_uid') == 1000
    assert result.get('user_gid') == 1000
    assert result.get('user_shell') == '/bin/bash'

    # Test case 2 - Real and effective user_id
    # Case 2.1 - Real user_id


# Generated at 2022-06-11 05:22:22.558712
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    assert ufc.collect() == {'effective_group_id': 1011, 'effective_user_id': 1011, 'real_group_id': 1011, 'real_user_id': 1011, 'user_dir': '/Users/boren', 'user_gid': 1011, 'user_gecos': 'Boren Zhang', 'user_id': 'boren', 'user_shell': '/bin/zsh', 'user_uid': 1011}

# Generated at 2022-06-11 05:22:25.750399
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    user_facts = ufc.collect()

    assert(set(user_facts.keys()) == ufc._fact_ids)

    for key in user_facts.keys():
        assert(user_facts[key] is not None)

# Generated at 2022-06-11 05:22:28.178975
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fact_collector = UserFactCollector()
    fact_collector.collect()
    user_facts = fact_collector.collect()
    assert user_facts['user_id'] == getpass.getuser()

# Generated at 2022-06-11 05:22:34.279014
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector()
    test_result = user_facts.collect()
    assert test_result['user_id'] == getpass.getuser()
    assert 'user_gid' in test_result
    assert 'user_gecos' in test_result
    assert 'user_dir' in test_result
    assert 'user_shell' in test_result
    assert 'user_uid' in test_result
    assert test_result['real_user_id'] == os.getuid()

# Generated at 2022-06-11 05:22:36.720543
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    factCollector = UserFactCollector()
    assert factCollector.collect()['user_id'] == factCollector.collect()['real_user_id']

# Generated at 2022-06-11 05:22:49.756652
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    '''Test collect on UserFactCollector'''
    import tempfile
    import os
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.system.user import UserFactCollector

    obj = UserFactCollector()

    # Test user is root

# Generated at 2022-06-11 05:22:57.874619
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user = UserFactCollector()
    facts = user.collect()
    assert 'user_id' in facts
    assert type(facts['user_id']) is str
    assert 'user_uid' in facts
    assert type(facts['user_uid']) is int
    assert 'user_gid' in facts
    assert type(facts['user_gid']) is int
    assert 'user_gecos' in facts
    assert type(facts['user_gecos']) is str
    assert 'user_dir' in facts
    assert type(facts['user_dir']) is str
    assert 'user_shell' in facts
    assert type(facts['user_shell']) is str
    assert 'real_user_id' in facts
    assert type(facts['real_user_id']) is int

# Generated at 2022-06-11 05:23:07.355674
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    """Unit test for method collect of class UserFactCollector

    1. Test if called without parameters.
       Expected:
       UserFactCollector.collect should return dictionary of facts.

    2. Test if called with additional collected facts.
       Expected:
       UserFactCollector.collect should return dictionary of extended
       collected facts.

    """
    # Unit test 1.
    # Test if called without parameters.
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()
    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['real_user_id'] == os.getuid()

    # Unit test 2.
    # Test if called with additional collected facts.

# Generated at 2022-06-11 05:23:15.757964
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collector = UserFactCollector()

    # Call collect method
    collected_facts = collector.collect()

    # Check collected facts
    assert isinstance(collected_facts, dict)
    assert 'real_user_id' in collected_facts
    assert 'effective_user_id' in collected_facts
    assert 'real_group_id' in collected_facts
    assert 'effective_group_id' in collected_facts
    assert 'user_id' in collected_facts
    assert 'user_uid' in collected_facts
    assert 'user_gid' in collected_facts
    assert 'user_gecos' in collected_facts
    assert 'user_dir' in collected_facts
    assert 'user_shell' in collected_facts

# Generated at 2022-06-11 05:23:21.608904
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import ansible.module_utils.facts.collectors.user as user_collector
    user_fac = user_collector.UserFactCollector()

    facts = user_fac.collect()

    assert facts['real_user_id'] == os.getuid()
    assert facts['effective_user_id'] == os.geteuid()
    assert facts['real_group_id'] == os.getgid()
    assert facts['effective_group_id'] == os.getgid()

# Generated at 2022-06-11 05:23:25.469934
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    module = None
    collected_facts = {}
    fact_collector = UserFactCollector()
    fact_collector.collect(module, collected_facts)
    user_facts = fact_collector.collect(module, collected_facts)

    assert user_facts['user_id'] == getpass.getuser()

# Generated at 2022-06-11 05:23:28.272960
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_fact_collector.collect()

# Generated at 2022-06-11 05:23:28.885926
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    c = UserFactCollector()
    assert c.collect() == {}

# Generated at 2022-06-11 05:23:37.082219
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()

    assert(user_facts['user_id'] == getpass.getuser())

    assert(user_facts['user_uid'] == pwd.getpwnam(getpass.getuser()).pw_uid)
    assert(user_facts['user_gid'] == pwd.getpwnam(getpass.getuser()).pw_gid)
    assert(user_facts['user_gecos'] == pwd.getpwnam(getpass.getuser()).pw_gecos)
    assert(user_facts['user_dir'] == pwd.getpwnam(getpass.getuser()).pw_dir)

# Generated at 2022-06-11 05:23:40.265641
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Test UserFactCollector.collect() method with a valid username
    f = UserFactCollector()
    assert len(f.collect()['user_id']) > 0


# Generated at 2022-06-11 05:23:50.384648
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    from ansible.module_utils.facts.collectors.user import UserFactCollector
    from ansible.module_utils._text import to_text

    user = UserFactCollector()

    # Test user == root
    results = user.collect()
    assert 'user_id' in results
    assert results['user_id'] == 'root'

    # Test user != root
    results = user.collect()
    assert 'user_id' in results
    assert results['user_id'] != 'root'

# Generated at 2022-06-11 05:23:59.534437
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    """Unit test for method collect of class UserFactCollector"""
    import os
    import pwd

    user_facts = {}

    user_facts['user_id'] = getpass.getuser()

    try:
        pwent = pwd.getpwnam(getpass.getuser())
    except KeyError:
        pwent = pwd.getpwuid(os.getuid())

    user_facts['user_uid'] = pwent.pw_uid
    user_facts['user_gid'] = pwent.pw_gid
    user_facts['user_gecos'] = pwent.pw_gecos
    user_facts['user_dir'] = pwent.pw_dir
    user_facts['user_shell'] = pwent.pw_shell

# Generated at 2022-06-11 05:24:09.446482
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    from ansible.module_utils.facts import get_collector_instance
    user_collector = get_collector_instance('UserFactCollector')

    collected_facts = user_collector.collect({}, {})

    assert 'user_id' in collected_facts
    assert 'user_uid' in collected_facts
    assert 'user_gid' in collected_facts
    assert 'user_gecos' in collected_facts
    assert 'user_dir' in collected_facts
    assert 'user_shell' in collected_facts
    assert 'real_user_id' in collected_facts
    assert 'effective_user_id' in collected_facts
    assert 'real_group_id' in collected_facts
    assert 'effective_group_id' in collected_facts

# Generated at 2022-06-11 05:24:19.287990
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector().collect()

    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['user_uid'] == pwd.getpwnam(getpass.getuser()).pw_uid
    assert user_facts['user_gid'] == pwd.getpwnam(getpass.getuser()).pw_gid
    assert user_facts['user_gecos'] == pwd.getpwnam(getpass.getuser()).pw_gecos
    assert user_facts['user_dir'] == pwd.getpwnam(getpass.getuser()).pw_dir
    assert user_facts['user_shell'] == pwd.getpwnam(getpass.getuser()).pw_shell

# Generated at 2022-06-11 05:24:29.012704
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()
    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['user_uid'] == pwd.getpwuid(os.getuid()).pw_uid
    assert user_facts['user_gid'] == pwd.getpwuid(os.getuid()).pw_gid
    assert user_facts['user_gecos'] == pwd.getpwuid(os.getuid()).pw_gecos
    assert user_facts['user_dir'] == pwd.getpwuid(os.getuid()).pw_dir
    assert user_facts['user_shell'] == pwd.getpwuid(os.getuid()).pw_

# Generated at 2022-06-11 05:24:36.314827
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    result = UserFactCollector().collect()

    assert 'user_id' in result
    assert 'user_uid' in result
    assert 'user_gid' in result
    assert 'user_gecos' in result
    assert 'user_dir' in result
    assert 'user_shell' in result
    assert 'real_user_id' in result
    assert 'effective_user_id' in result
    assert 'real_group_id' in result
    assert 'effective_group_id' in result


# Generated at 2022-06-11 05:24:42.618786
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector().collect()
    assert(user_facts['user_id'] == getpass.getuser())
    assert(user_facts['user_uid'] == pwd.getpwuid(os.getuid()).pw_uid)
    assert(user_facts['user_gid'] == pwd.getpwuid(os.getuid()).pw_gid)
    assert(user_facts['user_gecos'] == pwd.getpwuid(os.getuid()).pw_gecos)
    assert(user_facts['user_dir'] == pwd.getpwuid(os.getuid()).pw_dir)
    assert(user_facts['user_shell'] == pwd.getpwuid(os.getuid()).pw_shell)

# Generated at 2022-06-11 05:24:47.025245
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    from ansible.module_utils.facts import FactCollector
    user = UserFactCollector()
    user.collect()

    collector = FactCollector()
    found = collector.collect(["user"])

    if not found:
        print("test_UserFactCollector_collect: could not collect facts")
        assert False

    print(found)
    assert True

# Generated at 2022-06-11 05:24:55.321884
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    # create object of class UserFactCollector
    test_obj = UserFactCollector()

    # call method collect() of object test_obj
    result = test_obj.collect()

    # assert result
    assert 'user_id' in result
    assert 'user_uid' in result
    assert 'user_gid' in result
    assert 'user_gecos' in result
    assert 'user_dir' in result
    assert 'user_shell' in result
    assert 'real_user_id' in result
    assert 'effective_user_id' in result
    assert 'real_group_id' in result
    assert 'effective_group_id' in result

# Generated at 2022-06-11 05:25:04.489592
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collector = UserFactCollector()
    result = collector.collect()
    assert isinstance(result, dict)
    assert 'user_id' in result
    assert isinstance(result['user_id'], str)
    assert 'user_uid' in result
    assert isinstance(result['user_uid'], int)
    assert 'user_gid' in result
    assert isinstance(result['user_gid'], int)
    assert 'user_gecos' in result
    assert isinstance(result['user_gecos'], str)
    assert 'user_dir' in result
    assert isinstance(result['user_dir'], str)
    assert 'user_shell' in result
    assert isinstance(result['user_shell'], str)
    assert 'real_user_id' in result

# Generated at 2022-06-11 05:25:26.332753
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()

    user_facts = ufc.collect()

    assert isinstance(user_facts, dict)
    assert 'user_id' in user_facts
    assert isinstance(user_facts['user_id'], str)
    assert 'user_uid' in user_facts
    assert isinstance(user_facts['user_uid'], int)
    assert 'user_gid' in user_facts
    assert isinstance(user_facts['user_gid'], int)
    assert 'user_gecos' in user_facts
    assert isinstance(user_facts['user_gecos'], str)
    assert 'user_dir' in user_facts
    assert isinstance(user_facts['user_dir'], str)
    assert 'user_shell' in user_facts

# Generated at 2022-06-11 05:25:36.433839
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fact_collector = UserFactCollector()
    assert fact_collector.collect()["user_id"] == getpass.getuser()
    assert fact_collector.collect()["real_user_id"] == os.getuid()
    assert fact_collector.collect()["effective_user_id"] == os.geteuid()
    assert fact_collector.collect()["user_uid"] == pwd.getpwnam(getpass.getuser()).pw_uid
    assert fact_collector.collect()["user_gid"] == pwd.getpwnam(getpass.getuser()).pw_gid
    assert fact_collector.collect()["user_shell"] == pwd.getpwnam(getpass.getuser()).pw_shell

# Generated at 2022-06-11 05:25:42.922690
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    collected_facts = {'os_version': 'foo'}
    user_facts = ufc.collect(collected_facts)

    assert 'user_uid' not in collected_facts
    assert 'user_uid' in user_facts

    collected_facts = ufc.post_process(collected_facts, user_facts) 
    assert 'user_uid' not in user_facts
    assert 'user_uid' in collected_facts

# Generated at 2022-06-11 05:25:53.112015
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import ansible.module_utils.facts.collectors.user

    user_facts = UserFactCollector().collect()
    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['user_uid'] == os.getuid()
    assert user_facts['user_gid'] == os.getgid()
    assert user_facts['user_gecos'] == pwd.getpwuid(os.getuid()).pw_gecos
    assert user_facts['user_dir'] == pwd.getpwuid(os.getuid()).pw_dir
    assert user_facts['user_shell'] == pwd.getpwuid(os.getuid()).pw_shell
    assert user_facts['real_user_id'] == os.getuid()
    assert user_facts

# Generated at 2022-06-11 05:25:58.420628
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    from ansible.module_utils.facts import FactsCollector
    fc = FactsCollector()
    fc.collectors.append(UserFactCollector())
    facts = fc.collect(module=None, collected_facts=None)
    assert facts['user_id'] == getpass.getuser()
    assert facts['user_uid'] == os.getuid()
    assert facts['user_gid'] == os.getgid()
    assert facts['effective_user_id'] == os.geteuid()
    assert facts['effective_group_id'] == os.getegid()


# Generated at 2022-06-11 05:26:08.423266
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    """ This is a test for the method collect in the UserFactCollector class """
    user_facts = UserFactCollector()
    user_facts_collected = user_facts.collect()

    assert isinstance(user_facts_collected, dict)
    assert 'user_id' in user_facts_collected
    assert 'user_uid' in user_facts_collected
    assert 'user_gid' in user_facts_collected
    assert 'user_gecos' in user_facts_collected
    assert 'user_dir' in user_facts_collected
    assert 'user_shell' in user_facts_collected
    assert 'real_user_id' in user_facts_collected
    assert 'effective_user_id' in user_facts_collected
    assert 'real_group_id' in user_facts

# Generated at 2022-06-11 05:26:17.517989
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    from ansible.module_utils.facts import FactCollector

    user_fact_collector = UserFactCollector()

    if user_fact_collector.enabled():
        user_facts = user_fact_collector.collect()
        assert user_facts.keys() == user_fact_collector._fact_ids
        assert type(user_facts['user_id']) == str
        assert type(user_facts['user_uid']) == int
        assert type(user_facts['user_gid']) == int
        assert type(user_facts['user_gecos']) == str
        assert type(user_facts['user_dir']) == str
        assert type(user_facts['user_shell']) == str
        assert type(user_facts['real_user_id']) == int

# Generated at 2022-06-11 05:26:22.143212
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    class_ = UserFactCollector()
    assert list(class_.collect().keys()) == ['user_id', 'user_uid', 'user_gid', 'user_gecos',
                                             'user_dir', 'user_shell', 'real_user_id',
                                             'effective_user_id', 'real_group_id', 'effective_group_id']

# Generated at 2022-06-11 05:26:30.418680
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector().collect()

    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['user_uid'] == pwd.getpwnam(getpass.getuser()).pw_uid
    assert user_facts['user_gid'] == pwd.getpwnam(getpass.getuser()).pw_gid
    assert user_facts['user_gecos'] == pwd.getpwnam(getpass.getuser()).pw_gecos
    assert user_facts['user_dir'] == pwd.getpwnam(getpass.getuser()).pw_dir
    assert user_facts['user_shell'] == pwd.getpwnam(getpass.getuser()).pw_shell

# Generated at 2022-06-11 05:26:31.053943
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    pass

# Generated at 2022-06-11 05:27:02.806760
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.facts import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector

    collector = get_collector_instance(UserFactCollector)
    if not isinstance(collector, BaseFactCollector):
        raise AssertionError("collector instance should be an instance of BaseFactCollector")

    collected_facts = collector.collect(None, None)
    if not isinstance(collected_facts, dict):
        raise AssertionError("collected_facts is not a dictionary type")

    user_facts = collected_facts.get('ansible_user_id')
    if not isinstance(user_facts, dict):
        raise AssertionError("user_facts is not a dictionary type")



# Generated at 2022-06-11 05:27:11.809380
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    """
    This is a test function for UserFactCollector class collect method.
    It will test the collect method and return a tuple of passed and failed parameters.
    ex:
        (bool(passed), str(failure_message))
    """

    # Importing ansible.module_utils.facts.collectors.user
    from ansible.module_utils.facts.collectors.user import UserFactCollector

    # Initializing a instance of UserFactCollector
    test_collector = UserFactCollector()

    # Call collect method using a dummy module
    test_result = test_collector.collect()

    # Initializing test parameters
    passed = True
    message = 'UserFactCollector: collect method works as expected'

    # Validating results
    if isinstance(test_result, dict) is False:
        passed = False


# Generated at 2022-06-11 05:27:13.303281
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector().collect()
    assert user_facts['user_id'] == getpass.getuser()

# Generated at 2022-06-11 05:27:20.689666
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()

    assert 'user_id' in user_facts
    assert 'user_uid' in user_facts
    assert 'user_gid' in user_facts
    assert 'user_gecos' in user_facts
    assert 'user_dir' in user_facts
    assert 'user_shell' in user_facts
    assert 'real_user_id' in user_facts
    assert 'effective_user_id' in user_facts
    assert 'effective_group_ids' in user_facts

# Generated at 2022-06-11 05:27:26.946450
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # We want to test with a test Class
    # The class UserFactCollector has the get_pwd_entry that
    # need to be mocked. So we will create a class that inherit
    # of UserFactCollector to mock this method.
    class UserFactCollectorTest(UserFactCollector):
        def test_get_pwd_entry(self, user_id):
            pwentry = {'pw_uid': 1000, 'pw_gid': 1000,
                       'pw_gecos': 'test', 'pw_dir': '/home/test', 'pw_shell': '/bin/bash'}
            return pwentry

    user_fact_collector = UserFactCollectorTest()

    result = user_fact_collector.collect()

    assert isinstance(result, dict)

# Generated at 2022-06-11 05:27:36.188204
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_id = getpass.getuser()
    try:
        pwent = pwd.getpwnam(getpass.getuser())
    except KeyError:
        pwent = pwd.getpwuid(os.getuid())
    user_uid = pwent.pw_uid
    user_gid = pwent.pw_gid
    user_gecos = pwent.pw_gecos
    user_dir = pwent.pw_dir
    user_shell = pwent.pw_shell
    real_user_id = os.getuid()
    effective_user_id = os.geteuid()
    real_group_id = os.getgid()
    effective_group_id = os.getgid()

# Generated at 2022-06-11 05:27:45.063522
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    """UserFactCollector - collect()

    Verify expected dictionary is returned by UserFactCollector.collect()
    method.

    """

    import sys
    import os
    import pytest
    import mock

    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.user.user import UserFactCollector

    # setup test values
    user_id = 'mockuser'
    user_uid = 1042
    user_gid = 10
    user_gecos = 'mockuser,acme'
    user_dir = 'mockdir'
    user_shell = 'mockshell'
    real_user_id = 1000
    effective_user_id = 1042
    effective_group_ids = [1, 2, 3]

# Generated at 2022-06-11 05:27:54.145319
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    test_obj = UserFactCollector()
    result = test_obj.collect(None, None)

    pwent = pwd.getpwuid(os.getuid())

    assert result['user_id'] == pwent.pw_name
    assert result['user_uid'] == pwent.pw_uid
    assert result['user_gid'] == pwent.pw_gid
    assert result['user_gecos'] == pwent.pw_gecos
    assert result['user_dir'] == pwent.pw_dir
    assert result['user_shell'] == pwent.pw_shell
    assert result['real_user_id'] == pwent.pw_uid
    assert result['effective_user_id'] == pwent.pw_uid
    assert result['real_group_id'] == p

# Generated at 2022-06-11 05:28:04.016395
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact = UserFactCollector()
    user_facts = user_fact.collect()
#    for key in user_facts:
#        print key + "=" + str(user_facts[key])
    assert isinstance(user_facts, dict)
    assert 'user_id' in user_facts and isinstance(user_facts['user_id'], unicode)
    assert 'user_uid' in user_facts and isinstance(user_facts['user_uid'], int)
    assert 'user_gid' in user_facts and isinstance(user_facts['user_gid'], int)
    assert 'user_gecos' in user_facts and isinstance(user_facts['user_gecos'], unicode)

# Generated at 2022-06-11 05:28:06.220369
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact = UserFactCollector()
    test_facts = user_fact.collect()
    assert set(test_facts) == user_fact._fact_ids

# Generated at 2022-06-11 05:29:07.100152
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fact_collector = UserFactCollector()
    fact_collector._module = None
    fact_collector._collected_facts = {}
    facts = fact_collector.collect()
    assert facts.keys() == fact_collector._fact_ids
    for id in facts:
        assert facts[id]

# Generated at 2022-06-11 05:29:15.748991
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Test data
    test_data = {
        'user_id': getpass.getuser(),
        'user_uid': 0,
        'user_gid': 0,
        'user_gecos': 'Root',
        'user_dir': '/root',
        'user_shell': '/bin/sh',
        'real_user_id': 0,
        'effective_user_id': 0,
        'real_group_id': 0,
        'effective_group_id': 0
    }

    # Unit test
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()
    assert user_facts == test_data

    return user_facts

# Generated at 2022-06-11 05:29:23.451160
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fact_collector = UserFactCollector()
    key_facts = fact_collector.collect()
    assert key_facts['user_id'] == getpass.getuser()
    assert key_facts['user_uid'] == os.getuid()
    assert key_facts['user_gid'] == os.getgid()
    assert key_facts['real_user_id'] == os.getuid()
    assert key_facts['effective_user_id'] == os.getuid()
    assert 'user_gecos' in key_facts
    assert 'user_dir' in key_facts
    assert 'user_shell' in key_facts

# Generated at 2022-06-11 05:29:32.768492
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    assert isinstance(get_collector_instance('UserFactCollector'), UserFactCollector)
    assert isinstance(get_collector_instance('UserFactCollector').collect(), dict)
    assert get_collector_instance('UserFactCollector').collect().get('user_id') == getpass.getuser()
    assert get_collector_instance('UserFactCollector').collect().get('user_uid') == pwd.getpwnam(getpass.getuser()).pw_uid
    assert get_collector_instance('UserFactCollector').collect().get('user_gid') == pwd.getpwnam(getpass.getuser()).pw_gid
    assert get_collector_instance('UserFactCollector').collect

# Generated at 2022-06-11 05:29:37.326120
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()

    ansible_facts = {}
    facts = user_fact_collector.collect(module=None,
                                        collected_facts=ansible_facts)
    assert 'user_id' in facts
    assert 'user_uid' in facts
    assert 'user_gid' in facts
    assert 'user_gecos' in facts
    assert 'user_dir' in facts
    assert 'user_shell' in facts
    assert 'real_user_id' in facts
    assert 'effective_user_id' in facts
    assert 'real_group_id' in facts
    assert 'effective_group_id' in facts

# Generated at 2022-06-11 05:29:43.927541
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user = UserFactCollector()
    assert user.collect() == {'user_id': 'root', 'user_uid': 0, 'user_gid': 0, 'user_gecos': 'root', 
                              'user_dir': '/root', 'user_shell': '/bin/bash', 'real_user_id': 0, 
                              'effective_user_id': 0, 'real_group_id': 0, 'effective_group_id': 0}

# Generated at 2022-06-11 05:29:53.018833
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collector = UserFactCollector()
    ansible_facts = {}
    result = collector.collect(collected_facts=ansible_facts)

# Generated at 2022-06-11 05:29:58.159002
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()

    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['real_user_id'] == os.getuid()
    assert user_facts['effective_user_id'] == os.geteuid()
    assert user_facts['real_group_id'] == os.getgid()
    assert user_facts['effective_group_id'] == os.getgid()

# Generated at 2022-06-11 05:29:59.747061
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector().collect()
    assert user_facts['user_id'] == getpass.getuser()

# Generated at 2022-06-11 05:30:09.864987
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import os
    
    # Testcase 1 : Check whether output of collect method is as expected when
    # the user_id is set to root
    os.environ['USER'] = 'root'
    user_profile_dict = UserFactCollector().collect()
    expected_profile_dict = {'user_id': 'root',
                             'user_gid': 0,
                             'user_uid': 0,
                             'user_gecos': 'root',
                             'user_dir': '/root',
                             'user_shell': '/bin/bash',
                             'real_user_id': 0,
                             'effective_user_id': 0,
                             'real_group_id': 0,
                             'effective_group_id': 0}
    assert expected_profile_dict == user_profile_dict
    