

# Generated at 2022-06-11 05:20:47.919607
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    pass

# Generated at 2022-06-11 05:20:55.616487
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    facts = ufc.collect()['ansible_facts']
    assert type(facts) == dict
    assert 'user_id' in facts
    assert 'user_uid' in facts
    assert 'user_gid' in facts
    assert 'user_gecos' in facts
    assert 'user_dir' in facts
    assert 'user_shell' in facts
    assert 'real_user_id' in facts
    assert 'effective_user_id' in facts
    assert 'real_group_id' in facts
    assert 'effective_group_id' in facts

# Generated at 2022-06-11 05:21:05.205943
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Create the instance of UserFactCollector
    user_facts = UserFactCollector()

    # Call the method collect
    result = user_facts.collect()

    # Check the result
    assert isinstance(result, dict)
    assert result['user_id'] != ''
    assert result['user_uid'] != ''
    assert result['user_gid'] != ''
    assert result['user_gecos'] != ''
    assert result['user_dir'] != ''
    assert result['user_shell'] != ''
    assert result['real_user_id'] != ''
    assert result['effective_user_id'] != ''
    assert result['real_group_id'] != ''
    assert result['effective_group_id'] != ''

# Generated at 2022-06-11 05:21:14.962082
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()

    assert(user_facts['user_id'] == getpass.getuser())
    assert(user_facts['real_user_id'] == os.getuid())
    assert(user_facts['effective_user_id'] == os.geteuid())
    assert(user_facts['real_group_id'] == os.getgid())
    assert(user_facts['effective_group_id'] == os.getgid())

    try:
        pwent = pwd.getpwnam(getpass.getuser())
    except KeyError:
        pwent = pwd.getpwuid(os.getuid())

    assert(user_facts['user_uid'] == pwent.pw_uid)


# Generated at 2022-06-11 05:21:20.911269
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collector = UserFactCollector()
    facts = collector.collect()

    assert 'user_id' in facts
    assert 'user_uid' in facts
    assert 'user_gid' in facts
    assert 'user_gecos' in facts
    assert 'user_dir' in facts
    assert 'user_shell' in facts
    assert 'real_user_id' in facts
    assert 'effective_user_id' in facts
    assert 'real_group_id' in facts
    assert 'effective_group_ids' in facts

    assert type(facts['user_id']) is str
    assert type(facts['user_uid']) is int
    assert type(facts['user_gid']) is int
    assert type(facts['user_gecos']) is str
    assert type(facts['user_dir']) is str


# Generated at 2022-06-11 05:21:31.674488
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    from ansible.module_utils.facts import FactCollector

    '''
    This class collects the following facts about a host:
    - user_id
    - user_uid
    - user_gid
    - user_gecos
    - user_dir
    - user_shell
    - real_user_id
    - effective_user_id
    - real_group_id
    - effective_group_id
    '''

    # Create an instance of UserFactCollector
    user_fact_collector = UserFactCollector()

    # Invoke collect of UserFactCollector to collect facts about user
    user_facts = user_fact_collector.collect()

    # Get an instance of FactCollector
    fact_collector = FactCollector()

    # Invoke collect method of FactCollector to collect all the facts about


# Generated at 2022-06-11 05:21:41.698894
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    mytest = UserFactCollector()
    mytestfacts = mytest.collect()
    assert mytestfacts['user_id'] == getpass.getuser()
    assert mytestfacts['user_uid'] == pwd.getpwuid(os.getuid()).pw_uid
    assert mytestfacts['user_gid'] == pwd.getpwuid(os.getuid()).pw_gid
    assert mytestfacts['user_gecos'] == pwd.getpwuid(os.getuid()).pw_gecos
    assert mytestfacts['user_dir'] == pwd.getpwuid(os.getuid()).pw_dir
    assert mytestfacts['user_shell'] == pwd.getpwuid(os.getuid()).pw_shell

# Generated at 2022-06-11 05:21:47.277230
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # make sure that the collector does not modify the collected facts
    # unless it gets called
    # TODO: actually, this test does not test the scenario outlined above
    # as it is not possible to create an instance of a class derived from
    # BaseFactCollector without calling collect()
    collected_facts = {}
    fc = UserFactCollector()
    assert fc.collect(collected_facts=collected_facts) == {}

# Generated at 2022-06-11 05:21:57.837296
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fc = UserFactCollector()
    # Test default (no parameter)
    result = user_fc.collect()
    assert result['real_user_id'] == os.getuid()
    assert result['effective_user_id'] == os.geteuid()
    assert result['user_id'] == getpass.getuser()
    pwent = pwd.getpwnam(getpass.getuser())
    assert result['user_uid'] == pwent.pw_uid
    assert result['user_gid'] == pwent.pw_gid
    assert result['user_gecos'] == pwent.pw_gecos
    assert result['user_dir'] == pwent.pw_dir
    assert result['user_shell'] == pwent.pw_shell
    assert result['real_group_id']

# Generated at 2022-06-11 05:22:07.490290
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    from ansible.module_utils.facts.collectors import UserFactCollector
    # Making object for UserFactCollector class
    fact_collector = UserFactCollector
    # Calling collect method of UserFactCollector class
    facts = fact_collector.collect()
    # Verifying the result
    assert isinstance(facts, dict)
    user_facts = {
        'user_id': u'root',
        'user_gecos': u'root',
        'user_dir': u'/root',
        'user_uid': 0,
        'user_gid': 0,
        'user_shell': u'/bin/sh',
        'real_user_id': 0,
        'effective_user_id': 0,
        'real_group_id': 0,
        'effective_group_id': 0
    }

# Generated at 2022-06-11 05:22:19.305427
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    user_facts = ufc.collect()
    assert type(user_facts['user_id']) == str
    assert type(user_facts['user_uid']) == int
    assert type(user_facts['user_gid']) == int
    assert type(user_facts['user_gecos']) == str
    assert type(user_facts['user_dir']) == str
    assert type(user_facts['user_shell']) == str
    assert type(user_facts['real_user_id']) == int
    assert type(user_facts['effective_user_id']) == int
    assert type(user_facts['real_group_id']) == int
    assert type(user_facts['effective_group_id']) == int

# Generated at 2022-06-11 05:22:21.150682
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_fact_collector.collect()

# Generated at 2022-06-11 05:22:29.096276
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    passwd_data = '''
    root:x:0:0:root:/root:/bin/bash
    nobody:x:65534:65534:nobody:/nonexistant:/usr/sbin/nologin
    '''

    import os
    import tempfile


# Generated at 2022-06-11 05:22:38.065443
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fact_collector = UserFactCollector()
    user_facts_dict = fact_collector.collect()

    assert 'user_id' in user_facts_dict
    assert 'user_uid' in user_facts_dict
    assert 'user_gid' in user_facts_dict
    assert 'user_gecos' in user_facts_dict
    assert 'user_dir' in user_facts_dict
    assert 'user_shell' in user_facts_dict
    assert 'real_user_id' in user_facts_dict
    assert 'effective_user_id' in user_facts_dict
    assert 'real_group_id' in user_facts_dict
    assert 'effective_group_id' in user_facts_dict

# Generated at 2022-06-11 05:22:48.565688
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import platform

    # Setup Facts
    fact_collector = UserFactCollector.fetch_fact_collector()
    fact_collector.collect()
    collected_facts = fact_collector.get_facts()

    # Assert gathered fact keys
    fact_names = fact_collector.get_fact_names()
    assert "user_id" in fact_names
    assert "user_uid" in fact_names
    assert "user_gid" in fact_names
    assert "user_gecos" in fact_names
    assert "user_dir" in fact_names
    assert "user_shell" in fact_names
    assert "real_user_id" in fact_names
    assert "effective_user_id" in fact_names
    assert "real_group_id" in fact_names

# Generated at 2022-06-11 05:22:56.301643
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    expected_facts = {
        'user_id': 'test',
        'user_uid': 12345,
        'user_gid': 12345,
        'user_gecos': 'Test',
        'user_dir': '/home/test',
        'user_shell': '/bin/false',
        'real_user_id': 12345,
        'effective_user_id': 12345,
        'real_group_id': 12345,
        'effective_group_id': 12345
    }

    UserFactCollector._getpwuid = lambda self, uid: pwd.struct_passwd((
        'test', '*', 12345, 12345, 'Test', '/home/test', '/bin/false')
    )
    UserFactCollector._getuid = lambda self: 12345

    user_fact_

# Generated at 2022-06-11 05:22:58.856202
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    '''
    Unit test for method collect of class UserFactCollector
    '''
    col = UserFactCollector()
    res = col.collect()
    assert res['user_id'] == getpass.getuser()

# Generated at 2022-06-11 05:23:03.119063
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    module = None
    collected_facts = {}
    user_obj = UserFactCollector()
    result = user_obj.collect(module=module, collected_facts=collected_facts)
    realname = result['user_gecos'].split(',')[0]
    assert result['user_id'] == realname


# Generated at 2022-06-11 05:23:12.994709
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()

    user_fact_collector_result = user_fact_collector.collect(None, None)

    assert 'user_id' in user_fact_collector_result
    assert 'user_uid' in user_fact_collector_result
    assert 'user_gid' in user_fact_collector_result
    assert 'user_gecos' in user_fact_collector_result
    assert 'user_dir' in user_fact_collector_result
    assert 'user_shell' in user_fact_collector_result
    assert 'real_user_id' in user_fact_collector_result
    assert 'effective_user_id' in user_fact_collector_result
    assert 'real_group_id' in user_fact_collector_result


# Generated at 2022-06-11 05:23:22.371508
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()

    user_facts = user_fact_collector.collect()

    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['user_uid'] == pwd.getpwnam(getpass.getuser()).pw_uid
    assert user_facts['user_gid'] == pwd.getpwnam(getpass.getuser()).pw_gid
    assert user_facts['user_gecos'] == pwd.getpwnam(getpass.getuser()).pw_gecos
    assert user_facts['user_dir'] == pwd.getpwnam(getpass.getuser()).pw_dir

# Generated at 2022-06-11 05:23:35.880201
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    # Mock getpwnam, getpwuid and getpass
    getpwnam_mock = {'some_user': pwd.struct_passwd(('some_user', '****', 1000, 1000, '', '/home/some_user', '/bin/bash'))}
    pwd.getpwnam = mock.MagicMock(side_effect=lambda x: getpwnam_mock[x])

    getpwuid_mock = {1000: pwd.struct_passwd(('some_user', '****', 1000, 1000, '', '/home/some_user', '/bin/bash'))}
    pwd.getpwuid = mock.MagicMock(side_effect=lambda x: getpwuid_mock[x])


# Generated at 2022-06-11 05:23:46.676272
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fact_collector = UserFactCollector()
    fact_collector.collect()

    assert fact_collector.collect()['user_id'] == getpass.getuser()
    assert fact_collector.collect()['user_uid'] == pwd.getpwnam(getpass.getuser()).pw_uid
    assert fact_collector.collect()['user_gid'] == pwd.getpwnam(getpass.getuser()).pw_gid
    assert fact_collector.collect()['user_gecos'] == pwd.getpwnam(getpass.getuser()).pw_gecos
    assert fact_collector.collect()['user_dir'] == pwd.getpwnam(getpass.getuser()).pw_dir

# Generated at 2022-06-11 05:23:54.339593
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    # get the current user
    user_id = getpass.getuser()

    # get the current uid
    uid = pwd.getpwnam(getpass.getuser()).pw_uid

    # get the current gid
    gid = pwd.getpwnam(getpass.getuser()).pw_gid

    # get the current gecos
    gecos = pwd.getpwnam(getpass.getuser()).pw_gecos

    # get the current user_dir
    user_dir = pwd.getpwnam(getpass.getuser()).pw_dir

    # get the current user_shell
    user_shell = pwd.getpwnam(getpass.getuser()).pw_shell

    # get the current real user id
    real_

# Generated at 2022-06-11 05:24:04.862851
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    u = UserFactCollector()
    facts = u.collect()
    assert isinstance(facts, dict)
    assert facts['user_id'] == getpass.getuser()
    assert facts['user_uid'] == pwd.getpwuid(os.getuid()).pw_uid
    assert facts['user_gid'] == pwd.getpwuid(os.getuid()).pw_gid
    assert facts['user_gecos'] == pwd.getpwuid(os.getuid()).pw_gecos
    assert facts['user_dir'] == pwd.getpwuid(os.getuid()).pw_dir
    assert facts['user_shell'] == pwd.getpwuid(os.getuid()).pw_shell
    assert facts['real_user_id'] == os

# Generated at 2022-06-11 05:24:14.458144
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector.collect(None)
    assert len(user_facts) == 9
    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['user_uid'] == os.getuid()
    assert user_facts['user_gid'] == os.getgid()
    assert user_facts['user_gecos'] != ''
    assert user_facts['user_dir'] != ''
    assert user_facts['user_shell'] != ''
    assert user_facts['real_user_id'] == os.getuid()
    assert user_facts['effective_user_id'] == os.geteuid()
    assert user_facts['effective_group_ids'] == os.getgroups()

# Generated at 2022-06-11 05:24:21.548418
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()
    
    assert 'user_id' in user_facts
    assert 'user_uid' in user_facts
    assert 'user_gid' in user_facts
    assert 'user_gecos' in user_facts
    assert 'user_dir' in user_facts
    assert 'user_shell' in user_facts
    assert 'real_user_id' in user_facts
    assert 'effective_user_id' in user_facts
    assert 'real_group_id' in user_facts
    assert 'effective_group_id' in user_facts

# Generated at 2022-06-11 05:24:32.069678
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    module = None
    collected_facts = None
    user_facts = user_fact_collector.collect(module, collected_facts)
    assert isinstance(user_facts['user_id'], str)
    assert isinstance(user_facts['user_uid'], int)
    assert isinstance(user_facts['user_gid'], int)
    assert isinstance(user_facts['user_gecos'], str)
    assert isinstance(user_facts['user_dir'], str)
    assert isinstance(user_facts['user_shell'], str)
    assert isinstance(user_facts['real_user_id'], int)
    assert isinstance(user_facts['effective_user_id'], int)

# Generated at 2022-06-11 05:24:39.577578
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    factCollector = UserFactCollector()
    fc = factCollector.collect()
    assert fc['user_id']
    assert fc['user_uid']
    assert fc['user_gid']
    assert fc['user_gecos']
    assert fc['user_dir']
    assert fc['user_shell']
    assert fc['real_user_id']
    assert fc['effective_user_id']
    assert fc['real_group_id']
    assert fc['effective_group_id']

# Generated at 2022-06-11 05:24:41.052378
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    assert ufc.collect()['user_id'] == getpass.getuser()

# Generated at 2022-06-11 05:24:42.529232
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    c = UserFactCollector()
    assert(c.collect()['user_id'] == getpass.getuser())

# Generated at 2022-06-11 05:24:52.067076
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    a = UserFactCollector()
    facts = a.collect()

    assert facts['real_group_id'] > 0


# Generated at 2022-06-11 05:24:56.730767
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    lst = ['user_id',
           'user_uid',
           'user_gid',
           'user_gecos',
           'user_dir',
           'user_shell',
           'real_user_id',
           'effective_user_id',
           'effective_group_ids']
    collector = UserFactCollector()
    assert set(lst).issubset(collector.collect().keys())

# Generated at 2022-06-11 05:25:05.852188
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_fact_collector_facts = user_fact_collector.collect()

    assert user_fact_collector_facts['user_id'] == getpass.getuser()
    assert user_fact_collector_facts['user_uid'] == os.getuid()
    assert user_fact_collector_facts['user_gid'] == os.getgid()
    assert user_fact_collector_facts['user_gecos'] == pwd.getpwuid(os.geteuid()).pw_gecos
    assert user_fact_collector_facts['user_dir'] == pwd.getpwuid(os.geteuid()).pw_dir
    assert user_fact_collector_facts['user_shell'] == pwd.getpw

# Generated at 2022-06-11 05:25:11.990279
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector().collect()

    assert 'user_id' in user_facts.keys()
    assert 'user_uid' in user_facts.keys()
    assert 'user_gid' in user_facts.keys()
    assert 'user_gecos' in user_facts.keys()
    assert 'user_dir' in user_facts.keys()
    assert 'user_shell' in user_facts.keys()
    assert 'real_user_id' in user_facts.keys()
    assert 'effective_user_id' in user_facts.keys()
    assert 'real_group_id' in user_facts.keys()
    assert 'effective_group_id' in user_facts.keys()


# Generated at 2022-06-11 05:25:12.609849
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    pass

# Generated at 2022-06-11 05:25:21.307900
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    facts = ufc.collect()
    assert isinstance(facts['user_id'], str)
    assert isinstance(facts['user_uid'], int)
    assert isinstance(facts['user_gid'], int)
    assert isinstance(facts['user_gecos'], str)
    assert isinstance(facts['user_dir'], str)
    assert isinstance(facts['user_shell'], str)
    assert isinstance(facts['real_user_id'], int)
    assert isinstance(facts['effective_user_id'], int)
    assert isinstance(facts['real_group_id'], int)
    assert isinstance(facts['effective_group_id'], int)

# Generated at 2022-06-11 05:25:28.946374
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    class MockModule(object):
        def __init__(self):
            self.params = {}

    class MockFactsCollector(object):
        def __init__(self):
            self.collected_facts = {}


    module = MockModule()
    collected_facts = MockFactsCollector()

    user_fact_collector = UserFactCollector()
    user_fact_collector.collect(module, collected_facts)

    expected_keys = UserFactCollector._fact_ids
    assert set(user_fact_collector.get_facts(module, collected_facts).keys()) == expected_keys

# Generated at 2022-06-11 05:25:39.032548
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    mock_module = MockModule()
    mock_module.params = {}
    mock_module.get_bin_path = lambda *args, **kwargs: ''

    user_fact_collector = UserFactCollector()
    actual_user_facts = user_fact_collector.collect(module=mock_module, collected_facts={})

    assert isinstance(actual_user_facts, dict)
    assert 'user_id' in actual_user_facts
    assert 'user_uid' in actual_user_facts
    assert 'user_gid' in actual_user_facts
    assert 'user_gecos' in actual_user_facts
    assert 'user_dir' in actual_user_facts
    assert 'user_shell' in actual_user_facts
    assert 'real_user_id' in actual_user_facts
   

# Generated at 2022-06-11 05:25:49.691187
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    # patch for getpwnam and getpwuid
    def getpwnam(user):
        class Pwent:
            pw_uid = 1
            pw_gid = 2
            pw_gecos = 'foo'
            pw_dir = 'bar'
            pw_shell = 'baz'
        return Pwent()

    def getpwuid(uid):
        class Pwent:
            pw_uid = 3
            pw_gid = 4
            pw_gecos = 'qix'
            pw_dir = 'qux'
            pw_shell = 'quux'
        return Pwent()

    # patch getpass.getuser
    def getuser():
        return 'user'

    # patch os.getuid, os.geteuid, os.getgid,

# Generated at 2022-06-11 05:25:51.424019
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    userFactCollector = UserFactCollector()
    assert userFactCollector.collect()


# Generated at 2022-06-11 05:26:12.910242
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collector = UserFactCollector()
    collected_facts = collector.collect()
    assert type(collected_facts) is dict
    assert 'user_id' in collected_facts
    assert 'user_uid' in collected_facts
    assert 'user_gid' in collected_facts
    assert 'user_gecos' in collected_facts
    assert 'user_dir' in collected_facts
    assert 'user_shell' in collected_facts
    assert 'real_user_id' in collected_facts
    assert 'effective_user_id' in collected_facts
    assert 'real_group_id' in collected_facts
    assert 'effective_group_id' in collected_facts

# Generated at 2022-06-11 05:26:13.928823
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    assert 1 == 1, "Test not implemented"

# Generated at 2022-06-11 05:26:23.259115
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()
    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['real_user_id'] == os.getuid()
    assert user_facts['effective_user_id'] == os.geteuid()
    assert user_facts['real_group_id'] == os.getgid()
    assert user_facts['effective_group_id'] == os.getgid()
    assert user_facts['user_gid'] == pwd.getpwnam(getpass.getuser()).pw_gid
    assert user_facts['user_uid'] == pwd.getpwnam(getpass.getuser()).pw_uid

# Generated at 2022-06-11 05:26:31.065040
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()
    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['user_uid'] == pwd.getpwuid(os.getuid()).pw_uid
    assert user_facts['user_gid'] == pwd.getpwuid(os.getuid()).pw_gid
    assert user_facts['user_gecos'] == pwd.getpwuid(os.getuid()).pw_gecos
    assert user_facts['user_dir'] == pwd.getpwuid(os.getuid()).pw_dir
    assert user_facts['user_shell'] == pwd.getpwuid(os.getuid()).pw_

# Generated at 2022-06-11 05:26:38.659408
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()
    assert 'user_id' in user_facts
    assert 'user_uid' in user_facts
    assert 'user_gid' in user_facts
    assert 'user_gecos' in user_facts
    assert 'user_dir' in user_facts
    assert 'user_shell' in user_facts
    assert 'real_user_id' in user_facts
    assert 'effective_user_id' in user_facts
    assert 'real_group_id' in user_facts
    assert 'effective_group_id' in user_facts

# Generated at 2022-06-11 05:26:45.584138
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector().collect()

    assert 'user_id' in user_facts
    assert 'user_uid' in user_facts
    assert 'user_gid' in user_facts
    assert 'user_gecos' in user_facts
    assert 'user_dir' in user_facts
    assert 'user_shell' in user_facts
    assert 'real_user_id' in user_facts
    assert 'effective_user_id' in user_facts
    assert 'real_group_id' in user_facts
    assert 'effective_group_id' in user_facts


# Generated at 2022-06-11 05:26:56.485996
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    coll = UserFactCollector()
    facts = coll.collect()
    assert facts['user_id'] == getpass.getuser()
    assert facts['user_uid'] == os.getuid()
    assert facts['user_gid'] == os.getgid()
    assert facts['user_gecos'] == pwd.getpwuid(os.getuid())[4]
    assert facts['user_dir'] == os.path.expanduser("~")
    assert facts['user_shell'] == pwd.getpwuid(os.getuid())[6]
    assert facts['real_user_id'] == os.getuid()
    assert facts['effective_user_id'] == os.geteuid()
    assert facts['real_group_id'] == os.getgid()

# Generated at 2022-06-11 05:27:03.114339
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    """
    Test collect() method of UserFactCollector class
    """
    import os
    import pwd
    import getpass
    from ansible.module_utils.facts.collector import BaseFactCollector
    import pytest

    # Create a dummy UserFactCollector class
    class DummyUserFactCollector(UserFactCollector):
        def __init__(self, module=None, collected_facts=None):
            super(DummyUserFactCollector, self).__init__(module, collected_facts)

    # Create a dummy instance of UserFactCollector class
    dummy_user_fact_collector_instance = DummyUserFactCollector()

    # Create a dummy collected_facts
    collected_facts = {}

    # Create a dummy return from method collect()
    return_from_collect = dummy_user_fact_collector

# Generated at 2022-06-11 05:27:12.128738
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import platform
    import getpass
    user_id = getpass.getuser()

    ufc = UserFactCollector()
    user_facts = ufc.collect()

    assert user_facts['user_id'] == user_id
    assert isinstance(user_facts['user_uid'], int)
    assert isinstance(user_facts['user_gid'], int)
    assert isinstance(user_facts['user_gecos'], str)
    assert isinstance(user_facts['user_dir'], str)
    assert isinstance(user_facts['user_shell'], str)
    assert isinstance(user_facts['real_user_id'], int)
    assert isinstance(user_facts['effective_user_id'], int)

# Generated at 2022-06-11 05:27:20.479543
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fact_collector = UserFactCollector()
    collected_facts = fact_collector.collect()
    assert collected_facts['user_id'] == getpass.getuser()
    assert collected_facts['user_uid'] > 0
    assert collected_facts['user_gid'] > 0
    assert collected_facts['user_dir'] != ''
    assert collected_facts['user_shell'] != ''
    assert collected_facts['real_user_id'] == os.getuid()
    assert collected_facts['effective_user_id'] == os.geteuid()
    assert collected_facts['real_group_id'] == os.getgid()
    assert collected_facts['effective_group_id'] == os.getgid()

# Generated at 2022-06-11 05:27:52.812231
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    Collector = UserFactCollector()
    assert Collector.collect().get('user_id') == getpass.getuser()
    assert Collector.collect().get('real_user_id') == os.getuid()
    assert Collector.collect().get('effective_user_id') == os.geteuid()
    assert Collector.collect().get('effective_group_id') == os.getgid()

# Generated at 2022-06-11 05:28:02.665683
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fc = UserFactCollector()

    uid_num = os.getuid()
    uname_str = pwd.getpwuid(os.getuid()).pw_name
    gid_num = os.getgid()
    gname_str = pwd.getpwuid(os.getuid()).pw_name
    user_gecos = pwd.getpwuid(os.getuid()).pw_gecos
    user_dir = pwd.getpwuid(os.getuid()).pw_dir
    user_shell = pwd.getpwuid(os.getuid()).pw_shell


# Generated at 2022-06-11 05:28:09.406896
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector().collect()
    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['user_uid'] > -1
    assert user_facts['user_gid'] > -1
    assert user_facts['user_gecos'] is not None
    assert user_facts['user_dir'] is not None
    assert user_facts['user_shell'] is not None
    assert user_facts['real_user_id'] > -1
    assert user_facts['effective_user_id'] > -1
    assert user_facts['real_group_id'] > -1
    assert user_facts['effective_group_id'] > -1

# Generated at 2022-06-11 05:28:15.448283
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    userfact_collector = UserFactCollector()
    userfact_collector.collect()
    assert userfact_collector._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                                'user_gecos', 'user_dir', 'user_shell',
                                                'real_user_id', 'effective_user_id',
                                                'effective_group_ids'])

# Generated at 2022-06-11 05:28:21.422008
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    result = ufc.collect()
    assert isinstance(result, dict)
    assert 'user_id' in result
    assert 'user_uid' in result
    assert 'user_gid' in result
    assert 'user_gecos' in result
    assert 'user_dir' in result
    assert 'user_shell' in result
    assert 'real_user_id' in result
    assert 'effective_user_id' in result
    assert 'real_group_id' in result
    assert 'effective_group_id' in result

# Generated at 2022-06-11 05:28:23.696343
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    test_instance = UserFactCollector()
    data = test_instance.collect()
    assert data['user_id'] == getpass.getuser()

# Generated at 2022-06-11 05:28:32.707412
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    usercollector = UserFactCollector()
    facts = usercollector.collect()

    assert facts['user_id'] == getpass.getuser()
    assert facts['user_uid'] == os.getuid()
    assert facts['user_gid'] == os.getgid()
    assert facts['user_gecos'] == pwd.getpwuid(os.getuid()).pw_gecos
    assert facts['user_dir'] == pwd.getpwuid(os.getuid()).pw_dir
    assert facts['user_shell'] == pwd.getpwuid(os.getuid()).pw_shell
    assert facts['real_user_id'] == os.getuid()
    assert facts['effective_user_id'] == os.geteuid()

# Generated at 2022-06-11 05:28:41.429710
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    """Test that UserFactCollector.collect() returns the proper set of facts"""
    # Given a UserFactCollector
    ufc = UserFactCollector()
    # When I call the collect method
    facts = ufc.collect()
    # Then I should get back a dict with the proper values filled in

# Generated at 2022-06-11 05:28:43.107708
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Arrange

    # Act
    x = UserFactCollector()

    # Assert
    assert isinstance(x, UserFactCollector)

# Generated at 2022-06-11 05:28:51.583420
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    user_facts = {'effective_user_id': 1000,
                  'real_user_id': 1000,
                  'user_dir': '/home/admin1',
                  'user_gecos': 'adm1,Test,User,,',
                  'user_gid': 1000,
                  'user_id': 'admin1',
                  'user_shell': '/bin/bash',
                  'user_uid': 1000,
                  'effective_group_id': 1000,
                  'real_group_id': 1000}

    fact_collector = UserFactCollector(None)

    user_facts_output = fact_collector.collect()

    for key in user_facts.keys():
        assert user_facts_output[key] == user_facts[key]

# Generated at 2022-06-11 05:29:57.080142
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    os.environ['USER'] = 'root'
    os.environ['HOME'] = '/root'
    os.environ['SHELL'] = '/bin/bash'
    os.environ['LOGNAME'] = 'root'

    # Run collect method of UserFactCollector class
    fact_collector = UserFactCollector()
    result = fact_collector.collect()

    assert result['user_id'] == 'root'
    assert result['user_uid'] == 0
    assert result['user_gid'] == 0
    assert result['user_shell'] == '/bin/bash'
    assert result['user_dir'] == '/root'
    assert result['user_gecos'] is None
    assert result['real_user_id'] == 0
    assert result['real_group_id'] == 0

# Generated at 2022-06-11 05:29:57.903199
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    UserFactCollector().collect()

# Generated at 2022-06-11 05:30:08.078598
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector().collect()

    pwent = pwd.getpwuid(os.getuid())

    assert user_facts['user_id'] == pwent.pw_name

    assert user_facts['user_uid'] == pwent.pw_uid
    assert user_facts['user_gid'] == pwent.pw_gid
    assert user_facts['user_dir'] == pwent.pw_dir
    assert user_facts['user_shell'] == pwent.pw_shell

    assert user_facts['real_user_id'] == os.getuid()
    assert user_facts['effective_user_id'] == os.geteuid()
    assert user_facts['real_group_id'] == os.getgid()
    assert user_facts['effective_group_id']

# Generated at 2022-06-11 05:30:16.095795
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import os
    os.environ['USER'] = 'root'
    user = UserFactCollector()
    collected_facts = user.collect()
    assert collected_facts['user_id'] == 'root'
    assert collected_facts['user_uid'] == 0
    assert collected_facts['user_gid'] == 0
    assert collected_facts['user_gecos'] == 'root'
    assert collected_facts['user_dir'] == '/root'
    assert collected_facts['user_shell'] == '/bin/bash'
    assert collected_facts['real_user_id'] == 0
    assert collected_facts['real_group_id'] == 0
    assert collected_facts['effective_user_id'] == 0
    assert collected_facts['effective_group_id'] == 0

# Generated at 2022-06-11 05:30:21.704566
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    module = type("obj", (object,), {})
    setattr(module, 'params', {})
    setattr(module, 'get_bin_path', lambda _: "")

    # test UserFactCollector().collect(module)

    ufc = UserFactCollector()
    user_facts = ufc.collect(module)

    assert user_facts != None
    assert isinstance(user_facts, dict)
    assert user_facts['user_id'] != None

if __name__ == '__main__':
    test_UserFactCollector_collect()

# Generated at 2022-06-11 05:30:30.515675
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    uuid = 'test_user'

    class FakePwd:
        def getpwnam(self, arg):
            pwent = FakePwent(uuid, 1002, 1002, 'My GECOS', '/home/test_user', '/bin/bash')
            return pwent

        def getpwuid(self, arg):
            pwent = FakePwent(uuid, 1002, 1002, 'My GECOS', '/home/test_user', '/bin/bash')
            return pwent

    class FakePwent:
        def __init__ (self, pw_name, pw_uid, pw_gid, pw_gecos, pw_dir, pw_shell):
            self.pw_name = pw_name
            self.pw_uid = pw_uid
            self

# Generated at 2022-06-11 05:30:37.261882
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector(None)
    user_facts_dict = user_fact_collector.collect()
    assert user_facts_dict['user_id'] == getpass.getuser()
    assert user_facts_dict['user_uid'] == pwd.getpwnam(getpass.getuser()).pw_uid
    assert user_facts_dict['user_gid'] == pwd.getpwnam(getpass.getuser()).pw_gid
    assert user_facts_dict['user_gecos'] == pwd.getpwnam(getpass.getuser()).pw_gecos
    assert user_facts_dict['user_dir'] == pwd.getpwnam(getpass.getuser()).pw_dir

# Generated at 2022-06-11 05:30:38.268037
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collector = UserFactCollector()
    assert collector.collect() is not None

# Generated at 2022-06-11 05:30:40.739047
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    module_mock = None
    collected_facts_mock = None

    ufc = UserFactCollector()
    ufc.collect(module = module_mock, collected_facts = collected_facts_mock)


# Generated at 2022-06-11 05:30:48.513958
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import pytest
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors import UserFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    import sys
    reload(sys)
    sys.setdefaultencoding('utf8')

    filename = '/etc/passwd'
    file_content = '/etc/passwd'
    user_facts = {}
    user_facts['user_id'] = 'root'
    user_facts['user_uid'] = 0
    user_facts['user_gid'] = 0
    user_facts['user_gecos']