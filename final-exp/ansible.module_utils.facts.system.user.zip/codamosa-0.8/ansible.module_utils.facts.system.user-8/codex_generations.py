

# Generated at 2022-06-11 05:20:58.950521
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    """Ensure that UserFactCollector.collect() works."""
    user_facts = UserFactCollector().collect()

    assert 'user_id' in user_facts
    assert 'user_uid' in user_facts
    assert 'user_gid' in user_facts
    assert 'user_gecos' in user_facts
    assert 'user_dir' in user_facts
    assert 'user_shell' in user_facts
    assert 'real_user_id' in user_facts
    assert 'effective_user_id' in user_facts
    assert 'real_group_id' in user_facts
    assert 'effective_group_id' in user_facts

    assert not isinstance(user_facts['user_id'], unicode)
    assert not isinstance(user_facts['user_uid'], unicode)

# Generated at 2022-06-11 05:21:00.903685
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fcol = UserFactCollector()
    assert fcol.collect() is not None


# Generated at 2022-06-11 05:21:03.984944
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact = UserFactCollector()
    results = user_fact.collect()
    for result in results:
        assert result in user_fact._fact_ids


# Generated at 2022-06-11 05:21:08.008373
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()
    for fact_id in UserFactCollector._fact_ids:
        assert fact_id in user_facts
        # Check if values are not None
        assert user_facts[fact_id] is not None

# Generated at 2022-06-11 05:21:17.082470
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import pwd
    ufc = UserFactCollector()
    result = ufc.collect()

# Generated at 2022-06-11 05:21:24.226557
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_collector = UserFactCollector()
    facts = user_collector.collect(None, None)

    assert facts['user_id']
    assert facts['user_uid']
    assert facts['user_gid']
    assert facts['user_gecos']
    assert facts['user_dir']
    assert facts['user_shell']
    assert facts['real_user_id']
    assert facts['effective_user_id']
    assert facts['real_group_id']
    assert facts['effective_group_id']

# Generated at 2022-06-11 05:21:32.478799
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts_collector = UserFactCollector()
    user_facts = user_facts_collector.collect()
    
    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['user_uid']
    assert user_facts['user_gid']
    assert user_facts['user_gecos']
    assert user_facts['user_dir']
    assert user_facts['user_shell']
    assert user_facts['real_user_id']
    assert user_facts['effective_user_id']
    assert user_facts['real_group_id']
    assert user_facts['effective_group_id']

# Generated at 2022-06-11 05:21:42.476373
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    result = UserFactCollector.collect(None)
    assert isinstance(result, dict)
    assert 'user_id' in result
    assert isinstance(result['user_id'], str)
    assert 'user_uid' in result
    assert isinstance(result['user_uid'], int)
    assert 'user_gid' in result
    assert isinstance(result['user_gid'], int)
    assert 'user_gecos' in result
    assert isinstance(result['user_gecos'], str)
    assert 'user_dir' in result
    assert isinstance(result['user_dir'], str)
    assert 'user_shell' in result
    assert isinstance(result['user_shell'], str)
    assert 'real_user_id' in result

# Generated at 2022-06-11 05:21:53.399192
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fact_collector = UserFactCollector()
    facts = fact_collector.collect()
    assert type(facts) is dict
    assert 'user_id' in facts
    assert 'user_uid' in facts
    assert 'user_gid' in facts
    assert 'user_gecos' in facts
    assert 'user_dir' in facts
    assert 'user_shell' in facts
    assert 'real_user_id' in facts
    assert 'effective_user_id' in facts
    assert 'effective_group_ids' in facts
    assert facts['real_user_id'] == os.getuid()
    assert facts['effective_user_id'] == os.geteuid()
    assert facts['real_group_id'] == os.getgid()
    assert facts['effective_group_id'] == os.getgid

# Generated at 2022-06-11 05:21:58.046561
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    class test_module(object):
        @staticmethod
        def fail_json(*args, **kwargs):
            print(kwargs)
            return 1
        @staticmethod
        def exit_json(*args, **kwargs):
            print(kwargs)
            return 0
    collected_facts = {}
    UserFactCollector().collect(test_module(), collected_facts)

# Generated at 2022-06-11 05:22:08.828885
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    facts = user_fact_collector.collect()

    # Verify the facts collected
    assert facts['user_id']
    assert facts['user_uid']
    assert facts['user_gid']
    assert facts['user_gecos']
    assert facts['user_dir']
    assert facts['user_shell']
    assert facts['real_user_id']
    assert facts['effective_user_id']
    assert facts['real_group_id']
    assert facts['effective_group_id']

# Generated at 2022-06-11 05:22:10.232627
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_collector = UserFactCollector()
    user_collector.collect()

# Generated at 2022-06-11 05:22:20.742028
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    from ansible.module_utils.facts import ansible_facts
    test_object = UserFactCollector()
    result = test_object.collect()

    # Testing user_id
    assert 'user_id' in result
    assert type(result['user_id']) == str
    assert result['user_id'] == ansible_facts['user_name']

    # Testing user_uid
    assert 'user_uid' in result
    assert type(result['user_uid']) == int

    # Testing user_gid
    assert 'user_gid' in result
    assert type(result['user_gid']) == int

    # Testing user_gecos
    assert 'user_gecos' in result
    assert type(result['user_gecos']) == str

    # Testing user_dir

# Generated at 2022-06-11 05:22:28.832633
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import os

    import pytest

    from ansible.module_utils.facts.collector import BaseFactCollector

    from ansible.module_utils.facts import user


# Generated at 2022-06-11 05:22:38.539547
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Create instance of UserFactCollector class
    user_facts = UserFactCollector()

    # Call collect method of UserFactCollector class
    user_fact_dict = user_facts.collect()

    assert(user_fact_dict['user_id'] == getpass.getuser())

    try:
        pwent = pwd.getpwnam(getpass.getuser())
    except KeyError:
        pwent = pwd.getpwuid(os.getuid())

    assert(user_fact_dict['user_uid'] == pwent.pw_uid)
    assert(user_fact_dict['user_gid'] == pwent.pw_gid)
    assert(user_fact_dict['user_gecos'] == pwent.pw_gecos)

# Generated at 2022-06-11 05:22:47.469013
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector().collect(collected_facts=dict())
    assert user_facts["user_id"] == getpass.getuser()
    assert user_facts["user_uid"] >= 0
    assert user_facts["user_gid"] >= 0
    assert not user_facts["user_gecos"]
    assert user_facts["user_dir"]
    assert user_facts["user_shell"]
    assert user_facts["real_user_id"] >= 0
    assert user_facts["real_group_id"] >= 0
    assert user_facts["effective_user_id"] >= 0
    assert user_facts["effective_group_id"] >= 0

# Generated at 2022-06-11 05:22:54.542269
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user = UserFactCollector()
    collected_facts = {}
    facts = user.collect(collected_facts=collected_facts)
    assert len(facts) == 8
    assert facts['user_id'] == collected_facts['user_id'] == getpass.getuser()

    assert facts['user_uid'] == pwd.getpwnam(getpass.getuser()).pw_uid
    assert facts['user_gid'] == pwd.getpwnam(getpass.getuser()).pw_gid
    assert facts['user_gecos'] == pwd.getpwnam(getpass.getuser()).pw_gecos
    assert facts['user_dir'] == pwd.getpwnam(getpass.getuser()).pw_dir
    assert facts['user_shell'] == pwd

# Generated at 2022-06-11 05:22:56.897130
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_collector = UserFactCollector()
    collected_facts = user_collector.collect()
    assert collected_facts['user_id'] == getpass.getuser()

# Generated at 2022-06-11 05:22:59.883919
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()
    assert isinstance(user_facts, dict)
    assert set(user_facts.keys()) == user_fact_collector._fact_ids

# Generated at 2022-06-11 05:23:00.411366
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    pass

# Generated at 2022-06-11 05:23:13.390978
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
# get the id associated to the current user
    user_id = getpass.getuser()
# Since there is no way to predict the current user, let's assume it is the
# first one in the list of users
    for pwent in pwd.getpwall():
        if pwent.pw_name == user_id:
            break

    user_uid = pwent.pw_uid
    user_gid = pwent.pw_gid
    user_gecos = pwent.pw_gecos
    user_dir = pwent.pw_dir
    user_shell = pwent.pw_shell
    real_user_id = os.getuid()
    effective_user_id = os.geteuid()
    effective_group_id = os.getgid()

# create a UserFactCollector

# Generated at 2022-06-11 05:23:14.923013
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fc = UserFactCollector()
    assert('user_id' in fc.collect())

# Generated at 2022-06-11 05:23:24.464438
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Arrange
    from ansible.module_utils.facts.collector import Collector
    import platform
    import sys
    # set the platform and python version for the test
    # to the current platform and python version
    my_platform = platform.system().lower()
    my_python_version = sys.version_info[0]
    UserFactCollector.PLATFORM = my_platform
    UserFactCollector.PYTHON_VERSION = my_python_version
    collector = Collector()

    # Act
    # Execute method
    facts = collector.collect(collect_subset=['user'])

    # Assert
    # Check if the user_facts have been
    # collected in facts['ansible_facts']
    user_facts = facts['ansible_facts']['user']
    assert 'user_id' in user

# Generated at 2022-06-11 05:23:30.386995
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_collector = UserFactCollector()
    import pwd
    expected_user_facts = dict(pwd.getpwnam(getpass.getuser()))

    user_facts = user_collector.collect()

    for key in user_facts:
        assert user_facts[key] == expected_user_facts[key]

# Generated at 2022-06-11 05:23:37.818886
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import pytest
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import user

    # instantiate from module
    Ufc = user.UserFactCollector()

    # test if a function exists
    assert hasattr(Ufc, 'collect')

    # test if function is callable
    assert callable(Ufc.collect)

    # test if function exists
    assert hasattr(Ufc, '_fact_ids')

    # test if function returns a dict
    assert isinstance(Ufc.collect(), dict)

    # test if class is inherited from BaseFactCollector
    assert issubclass(user.UserFactCollector, BaseFactCollector)

    # test if _fact_ids attribute is of type SET
    assert type(Ufc._fact_ids) is set

# Generated at 2022-06-11 05:23:48.496482
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector().collect()

    # Validate the complex data types
    assert isinstance(user_facts, dict)

    # Validate that user_id is not an empty string
    assert user_facts['user_id'] != ''

    # Validate that user_id is not None
    assert user_facts['user_id'] != None

    # Validate that user_uid is an integer
    assert isinstance(user_facts['user_uid'], int)

    # Validate that user_gid is an integer
    assert isinstance(user_facts['user_gid'], int)

    # Validate that user_gecos is a string
    assert isinstance(user_facts['user_gecos'], str)

    # Validate that user_dir is not None
    assert user_facts['user_dir']

# Generated at 2022-06-11 05:23:53.192587
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    """Return facts about users."""
    # sut is system under test:
    sut = UserFactCollector()
    collected_facts = {}
    user_facts = sut.collect(collected_facts=collected_facts)
    assert isinstance(user_facts, dict)
    assert user_facts
    assert 'user_uid' in user_facts
    assert user_facts['user_uid'] == pwd.getpwnam(getpass.getuser()).pw_uid

# Generated at 2022-06-11 05:24:03.312281
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    test_facts = {}

    # Instantiate UserFactCollector object
    user_collector = UserFactCollector()

    # Collect facts
    user_fact = user_collector.collect(collected_facts=test_facts)

    # Check if user has root privileges
    assert user_fact['real_user_id'] == 0
    assert user_fact['effective_user_id'] == 0
    assert user_fact['real_group_id'] == 0
    assert user_fact['effective_group_id'] == 0

    # Check output of fact user_uid
    assert isinstance(user_fact['user_uid'], int)
    assert user_fact['user_uid'] > 0

    # Check output of fact user_gid
    assert isinstance(user_fact['user_gid'], int)
    assert user_fact

# Generated at 2022-06-11 05:24:07.059373
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collected_facts = {}
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect(collected_facts=collected_facts)
    assert isinstance(user_facts, dict)

# Generated at 2022-06-11 05:24:17.404906
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    from ansible.module_utils.facts.collectors.user import UserFactCollector

    u = UserFactCollector()
    result = u.collect()

    assert result['user_id'] == getpass.getuser()
    assert result['user_uid'] == pwd.getpwnam(getpass.getuser()).pw_uid
    assert result['user_gid'] == pwd.getpwnam(getpass.getuser()).pw_gid
    assert result['user_gecos'] == pwd.getpwnam(getpass.getuser()).pw_gecos
    assert result['user_dir'] == pwd.getpwnam(getpass.getuser()).pw_dir
    assert result['user_shell'] == pwd.getpwnam(getpass.getuser()).p

# Generated at 2022-06-11 05:24:34.690553
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    from ansible.module_utils.facts import get_module_args, get_collected_facts
    from ansible.module_utils.facts.collectors.user import UserFactCollector

    uid = getpass.getuser()
    args = get_module_args("", facts_type='user')
    facts = get_collected_facts(None, None, UserFactCollector, args)

    assert facts['user_id'] == uid
    assert facts['user_uid'] == pwd.getpwnam(uid).pw_uid
    assert facts['user_gid'] == pwd.getpwnam(uid).pw_gid
    assert facts['user_gecos'] == pwd.getpwnam(uid).pw_gecos
    assert facts['user_dir'] != ''

# Generated at 2022-06-11 05:24:43.865117
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import0 = __import__('0')
    import0.sys = __import__('sys')
    import0.pwd = __import__('pwd')
    import0.grp = __import__('grp')
    import0.os = __import__('os')
    import0.getpass = __import__('getpass')
    import0.pwd.getpwuid = mock_getpwuid
    import0.pwd.getpwnam = mock_getpwnam
    import0.os.getuid = mock_getuid
    import0.os.geteuid = mock_geteuid
    import0.os.getgid = mock_getgid
    import0.getpass.getuser = mock_getuser


# Generated at 2022-06-11 05:24:54.920383
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts_obj = UserFactCollector()
    user_facts = user_facts_obj.collect()
    assert user_facts["user_id"] == getpass.getuser()
    assert int(user_facts["user_uid"]) == int(pwd.getpwuid(os.getuid()).pw_uid)
    assert int(user_facts["user_gid"]) == int(pwd.getpwuid(os.getuid()).pw_gid)
    assert user_facts["user_gecos"] == pwd.getpwuid(os.getuid()).pw_gecos
    assert user_facts["user_dir"] == pwd.getpwuid(os.getuid()).pw_dir
    assert user_facts["user_shell"] == pwd.getpwuid

# Generated at 2022-06-11 05:25:04.091304
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    # Test run
    user_facts = UserFactCollector().collect()

    # Test assertions
    # Keys
    assert 'user_id' in user_facts
    assert 'user_uid' in user_facts
    assert 'user_gid' in user_facts
    assert 'user_gecos' in user_facts
    assert 'user_dir' in user_facts
    assert 'user_shell' in user_facts
    assert 'real_user_id' in user_facts
    assert 'effective_user_id' in user_facts
    assert 'real_group_id' in user_facts
    assert 'effective_group_id' in user_facts

    # Values
    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['user_uid'] == os.getuid()
    assert user

# Generated at 2022-06-11 05:25:10.335941
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    
    # Test with valid parameters
    test_UserFactCollector = UserFactCollector()
    result = test_UserFactCollector.collect()

    assert type(result) is dict
    assert 'user_id' in result
    assert 'user_uid' in result
    assert 'user_gid' in result
    assert 'user_gecos' in result
    assert 'user_dir' in result
    assert 'user_shell' in result
    assert 'real_user_id' in result
    assert 'effective_user_id' in result
    assert 'real_group_id' in result
    assert 'effective_group_id' in result

# Generated at 2022-06-11 05:25:19.497426
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    assert user_fact_collector.collect()['user_id'] == getpass.getuser()
    assert user_fact_collector.collect()['user_uid'] == pwd.getpwnam(getpass.getuser()).pw_uid
    assert user_fact_collector.collect()['user_gid'] == pwd.getpwnam(getpass.getuser()).pw_gid
    assert user_fact_collector.collect()['user_gecos'] == pwd.getpwnam(getpass.getuser()).pw_gecos
    assert user_fact_collector.collect()['user_dir'] == pwd.getpwnam(getpass.getuser()).pw_dir

# Generated at 2022-06-11 05:25:29.411780
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Test data
    #
    # Test data is not used in any way.
    # This is to cover code without any
    # real data.

    # initalize
    userfact = UserFactCollector()

    # execute test
    fact = userfact.collect()

    # assert
    assert len(fact) > 0
    assert 'user_id' in fact
    assert 'user_uid' in fact
    assert 'user_gid' in fact
    assert 'user_gecos' in fact
    assert 'user_dir' in fact
    assert 'user_shell' in fact
    assert 'real_user_id' in fact
    assert 'effective_user_id' in fact
    assert 'real_group_id' in fact
    assert 'effective_group_id' in fact

# vim: set et ts=4 sw

# Generated at 2022-06-11 05:25:36.246482
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    uc = UserFactCollector()
    result = uc.collect()

    assert 'user_id' in result
    assert 'user_uid' in result
    assert 'user_gid' in result
    assert 'user_gecos' in result
    assert 'user_dir' in result
    assert 'user_shell' in result
    assert 'real_user_id' in result
    assert 'effective_user_id' in result
    assert 'real_group_id' in result
    assert 'effective_group_id' in result



# Generated at 2022-06-11 05:25:39.219398
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector().collect()
    assert 'user_id' in user_facts
    assert user_facts['user_id'] == getpass.getuser()

# vim: set noexpandtab:

# Generated at 2022-06-11 05:25:47.897350
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    collected_facts = user_fact_collector.collect()

    assert 'user_uid' in collected_facts
    assert 'user_gid' in collected_facts
    assert 'user_gecos' in collected_facts
    assert 'user_dir' in collected_facts
    assert 'user_shell' in collected_facts
    assert 'real_user_id' in collected_facts
    assert 'user_id' in collected_facts
    assert 'effective_user_id' in collected_facts
    assert 'real_group_id' in collected_facts
    assert 'effective_group_id' in collected_facts

# Generated at 2022-06-11 05:26:09.948278
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    from ansible.module_utils._text import to_bytes
    import pprint
    # Module test
    user_facts = UserFactCollector().collect()

    pprint.pprint(user_facts)

    assert user_facts['user_id'] == to_bytes(getpass.getuser())
    assert user_facts['real_user_id'] == os.getuid()
    assert user_facts['effective_user_id'] == os.geteuid()
    assert user_facts['real_group_id'] == os.getgid()
    assert user_facts['effective_group_id'] == os.getgid()

    assert user_facts['user_uid'] == pwd.getpwnam(getpass.getuser()).pw_uid
    assert user_facts['user_gid'] == pwd.getp

# Generated at 2022-06-11 05:26:12.242694
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector().collect(collected_facts=None)
    assert user_facts['user_id'] == getpass.getuser()

# Generated at 2022-06-11 05:26:21.455013
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import pytest
    from ansible.module_utils.facts.collector import Collector

    collected_facts = dict()
    facts_collected = dict()
    expected_results = dict()

    expected_results['user_id'] = getpass.getuser()

    try:
        pwent = pwd.getpwnam(getpass.getuser())
    except KeyError:
        pwent = pwd.getpwuid(os.getuid())

    expected_results['user_uid'] = pwent.pw_uid
    expected_results['user_gid'] = pwent.pw_gid
    expected_results['user_gecos'] = pwent.pw_gecos
    expected_results['user_dir'] = pwent.pw_dir

# Generated at 2022-06-11 05:26:29.957575
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    # Test parameters
    module = None
    collected_facts = None
    return_value = None

    # Test no.1 - user_id
    class UserFactCollector_user_id(UserFactCollector):
        def collect(self, module=module, collected_facts=collected_facts):
            return_value = super(UserFactCollector_user_id, self).collect()

            return_value['user_id'] = 'test_value_user_id'

            return return_value

    # Test no.2 - user_uid
    class UserFactCollector_user_uid(UserFactCollector):
        def collect(self, module=module, collected_facts=collected_facts):
            return_value = super(UserFactCollector_user_uid, self).collect()


# Generated at 2022-06-11 05:26:38.875922
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    #get a UserFactCollector object
    userfact = UserFactCollector()

    #get collected facts
    userfacts = userfact.collect()

    assert 'user_id' in userfacts.keys()
    assert 'user_uid' in userfacts.keys()
    assert 'user_gid' in userfacts.keys()
    assert 'user_gecos' in userfacts.keys()
    assert 'user_dir' in userfacts.keys()
    assert 'user_shell' in userfacts.keys()
    assert 'real_user_id' in userfacts.keys()
    assert 'effective_user_id' in userfacts.keys()
    assert 'real_group_id' in userfacts.keys()
    assert 'effective_group_id' in userfacts.keys()

# Generated at 2022-06-11 05:26:48.649027
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import os
    import pwd
    from ansible.module_utils.facts.collectors.user import UserFactCollector

    user_facts = {}

    user_facts['user_id'] = pwd.getpwuid(os.getuid())[0]

    try:
        pwent = pwd.getpwnam(getpass.getuser())
    except KeyError:
        pwent = pwd.getpwuid(os.getuid())

    user_facts['user_uid'] = pwent.pw_uid
    user_facts['user_gid'] = pwent.pw_gid
    user_facts['user_gecos'] = pwent.pw_gecos
    user_facts['user_dir'] = pwent.pw_dir
    user_facts['user_shell'] = pwent

# Generated at 2022-06-11 05:26:58.564757
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    obj = UserFactCollector()

    user_facts = obj.collect()

    _user_id = user_facts['user_id']
    _user_uid = user_facts['user_uid']
    _user_gid = user_facts['user_gid']
    _user_gecos = user_facts['user_gecos']
    _user_dir = user_facts['user_dir']
    _user_shell = user_facts['user_shell']
    _real_user_id = user_facts['real_user_id']
    _effective_user_id = user_facts['effective_user_id']
    _effective_group_ids = user_facts['effective_group_ids']

    print('user_id is {user_id}'.format(user_id = _user_id))

# Generated at 2022-06-11 05:27:02.840309
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    with open('test_UserFactCollector_collect.txt', 'w') as f:
        # UserFactCollector.collect method test
        user_fc = UserFactCollector()
        f.write('u_fc = UserFactCollector()\n')
        u_fc = UserFactCollector()
        # Unit test execution
        f.write('user_fc.collect()\n')
        u_fc.collect()

# Generated at 2022-06-11 05:27:11.848730
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    unit = UserFactCollector()
    user_facts = unit.collect()

    # expected values
    user_id = getpass.getuser()
    pwent = pwd.getpwnam(user_id)
    user_uid = pwent.pw_uid
    user_gid = pwent.pw_gid
    user_gecos = pwent.pw_gecos
    user_dir = pwent.pw_dir
    user_shell = pwent.pw_shell
    real_user_id = os.getuid()
    effective_user_id = os.geteuid()
    real_group_id = os.getgid()
    effective_group_id = os.geteuid()


# Generated at 2022-06-11 05:27:21.225469
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()

    assert ufc.fact_ids == set(['user_id', 'user_uid', 'user_gid',
                     'user_gecos', 'user_dir', 'user_shell',
                     'real_user_id', 'effective_user_id',
                     'effective_group_ids'])

    current_user = getpass.getuser()
    ufc_facts = ufc.collect()

    assert ufc_facts['user_id'] == current_user
    assert ufc_facts['real_user_id'] == os.getuid()
    assert ufc_facts['effective_user_id'] == os.geteuid()


# Generated at 2022-06-11 05:27:51.649949
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    test_user = UserFactCollector()

    #call collect method of class UserFactCollector
    result = test_user.collect()

    #test result is expected
    assert result['user_id'] == getpass.getuser()
    assert result['user_uid'] == pwd.getpwnam(getpass.getuser()).pw_uid
    assert result['real_user_id'] == os.getuid()

# Generated at 2022-06-11 05:28:01.567477
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    test_UserFactCollector = UserFactCollector()
    collected_facts = {}
    collected_facts = test_UserFactCollector.collect(None, collected_facts)
    assert collected_facts['user_id'] == getpass.getuser()
    assert collected_facts['user_uid'] != None
    assert collected_facts['user_gid'] != None
    assert collected_facts['user_gecos'] != None
    assert collected_facts['user_dir'] != None
    assert collected_facts['user_shell'] != None
    assert collected_facts['real_user_id'] == os.getuid()
    assert collected_facts['effective_user_id'] == os.geteuid()
    assert collected_facts['real_group_ids'] == os.getgid()

# Generated at 2022-06-11 05:28:09.708544
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    collected_facts = ufc.collect()

    assert collected_facts['user_id'] == getpass.getuser()

    try:
        pwent = pwd.getpwnam(getpass.getuser())
    except KeyError:
        pwent = pwd.getpwuid(os.getuid())

    assert collected_facts['user_uid'] == pwent.pw_uid
    assert collected_facts['user_gid'] == pwent.pw_gid
    assert collected_facts['user_gecos'] == pwent.pw_gecos
    assert collected_facts['user_dir'] == pwent.pw_dir
    assert collected_facts['user_shell'] == pwent.pw_shell
    assert collected_facts['real_user_id'] == os

# Generated at 2022-06-11 05:28:19.323316
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector, Facts
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.user import UserFactCollector

    m_class_base_fact_collector1 = BaseFactCollector
    m_class_base_fact_collector2 = UserFactCollector
    m_class_base_fact_collector2._fact_ids = set(['user_id', 'user_uid', 'user_gid',
                                            'user_gecos', 'user_dir', 'user_shell',
                                            'real_user_id', 'effective_user_id',
                                            'effective_group_ids'])
    m_class_base_fact_collector2.name = 'user'


# Generated at 2022-06-11 05:28:26.699008
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    mock_module = None
    mock_collected_facts = None
    ufc = UserFactCollector()

    expected_keys = {'user_id', 'user_uid', 'user_gid',
                     'user_gecos', 'user_dir', 'user_shell',
                     'real_user_id', 'effective_user_id',
                     'effective_group_id'}

    user_facts_dict = ufc.collect(mock_module, mock_collected_facts)

    assert len(user_facts_dict) == 9

    keys_in_my_dict = set(user_facts_dict.keys())

    assert keys_in_my_dict == expected_keys

# Generated at 2022-06-11 05:28:35.467963
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # test input and expected result
    user_collector = UserFactCollector()
    expected_user_facts = {}
    expected_user_facts['user_id'] = getpass.getuser()
    try:
        pwent = pwd.getpwnam(getpass.getuser())
    except KeyError:
        pwent = pwd.getpwuid(os.getuid())

    expected_user_facts['user_uid'] = pwent.pw_uid
    expected_user_facts['user_gid'] = pwent.pw_gid
    expected_user_facts['user_gecos'] = pwent.pw_gecos
    expected_user_facts['user_dir'] = pwent.pw_dir
    expected_user_facts['user_shell'] = pwent.pw_shell


# Generated at 2022-06-11 05:28:42.925697
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    class TestModule:
        version = 1.0
    collector = UserFactCollector(TestModule)
    collected_facts = collector.collect()
    assert('user_id' in collected_facts)
    assert('user_uid' in collected_facts)
    assert('user_gid' in collected_facts)
    assert('user_gecos' in collected_facts)
    assert('user_dir' in collected_facts)
    assert('user_shell' in collected_facts)
    assert('real_user_id' in collected_facts)
    assert('effective_user_id' in collected_facts)
    assert('real_group_id' in collected_facts)
    assert('effective_group_id' in collected_facts)

# Generated at 2022-06-11 05:28:44.461824
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collector = UserFactCollector()
    assert collector.collect()['user_id'] == getpass.getuser()

# Generated at 2022-06-11 05:28:48.006310
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Create a UserFactCollector object and assign it to user_fact_collector
    user_fact_collector = UserFactCollector()

    # Assert the name of user_fact_collector is equal to user
    assert user_fact_collector.name == 'user'

# Generated at 2022-06-11 05:28:54.325677
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector()
    collected_facts = user_facts.collect()
    assert collected_facts['user_id']
    assert collected_facts['user_uid']
    assert collected_facts['user_gid']
    assert collected_facts['user_gecos']
    assert collected_facts['user_dir']
    assert collected_facts['user_shell']
    assert collected_facts['real_user_id']
    assert collected_facts['effective_user_id']
    assert collected_facts['real_group_id']
    assert collected_facts['effective_group_id']

# Generated at 2022-06-11 05:29:55.570309
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import sys
    import tempfile
    import shutil
    import pwd
    import subprocess
    import stat
    # Get a temp home directory to work with
    temp_home = tempfile.mkdtemp()
    temp_home_parent = os.path.dirname(temp_home)
    test_gid = os.stat(temp_home_parent).st_gid
    test_gecos = 'test-gecos'
    test_shell = '/bin/sh'
    test_uid = os.geteuid()
    test_user = 'test-user'

    # Create temp password file
    temp_passwd = tempfile.NamedTemporaryFile()
    # Change the mode and move it to get the mode in effect
    os.chmod(temp_passwd.name, stat.S_IRUSR)


# Generated at 2022-06-11 05:30:02.367107
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fact_collector = UserFactCollector()
    facts = fact_collector.collect()
    assert 'user_id' in facts
    assert 'user_uid' in facts
    assert 'user_gid' in facts
    assert 'user_gecos' in facts
    assert 'user_dir' in facts
    assert 'user_shell' in facts
    assert 'real_user_id' in facts
    assert 'effective_user_id' in facts
    assert 'real_group_id' in facts
    assert 'effective_group_id' in facts

# Generated at 2022-06-11 05:30:10.829491
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import platform
    import os

    test_user_fact_collector = UserFactCollector()
    # Should not raise any exception
    test_user_fact_collector.collect()

    if platform.system() != 'Windows':
        # Test the user facts
        result = test_user_fact_collector.collect()
        assert result['user_id'] == getpass.getuser()
        assert result['real_user_id'] == os.getuid()
        assert result['effective_user_id'] == os.geteuid()
        assert result['real_group_id'] == os.getgid()
        assert result['effective_group_id'] == os.getegid()
        assert result['effective_group_ids'] == os.getgroups()

# Generated at 2022-06-11 05:30:18.764941
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()
    # Verify
    assert isinstance(user_facts, dict)
    assert user_facts.has_key('user_id')
    assert user_facts.has_key('user_uid')
    assert user_facts.has_key('user_gid')
    assert user_facts.has_key('user_gecos')
    assert user_facts.has_key('user_dir')
    assert user_facts.has_key('user_shell')
    assert user_facts.has_key('real_user_id')
    assert user_facts.has_key('effective_user_id')
    assert user_facts.has_key('real_group_id')

# Generated at 2022-06-11 05:30:27.660090
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import pwd
    collector = UserFactCollector()
    user_facts = collector.collect()
    assert user_facts['user_id'] == pwd.getpwuid(os.getuid()).pw_name
    assert user_facts['user_uid'] == pwd.getpwuid(os.getuid()).pw_uid
    assert user_facts['user_gid'] == pwd.getpwuid(os.getuid()).pw_gid
    assert user_facts['user_gecos'] == pwd.getpwuid(os.getuid()).pw_gecos
    assert user_facts['user_dir'] == pwd.getpwuid(os.getuid()).pw_dir

# Generated at 2022-06-11 05:30:29.132502
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_object = UserFactCollector()
    # test if method collect works
    assert user_object.collect() == {}

# Generated at 2022-06-11 05:30:34.794347
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts={'user_id': 'root',
                'user_uid': 0,
                'user_gid': 0,
                'user_gecos': 'root',
                'user_dir': '/root',
                'user_shell': '/bin/bash',
                'real_user_id': 0,
                'effective_user_id': 0,
                'real_group_id': 0,
                'effective_group_id': 0}
    userfact_collector = UserFactCollector()
    userfact_collector.collect()
    assert(user_facts == userfact_collector.collect())

# Generated at 2022-06-11 05:30:40.109699
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Create an instance of the UserFactCollector Class
    collector = UserFactCollector()

    # call method of the UserFactCollector instance
    user_dict = collector.collect()

    # Test if the user_dict variable is a dictionary
    assert isinstance(user_dict, dict)

    # Test if the user_dict contains the key user_id
    assert 'user_id' in user_dict
    # Test that the value returned from the
    # user_dict for the key user_id is a string
    assert isinstance(user_dict['user_id'], str)

    # Test if the user_dict contains the key user_uid
    assert 'user_uid' in user_dict
    # Test that the value returned from the
    # user_dict for the key user_uid is a  integer

# Generated at 2022-06-11 05:30:44.111546
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collector = UserFactCollector()
    # test for non-root user
    if collector.collect(collected_facts={})['user_id'] == 'root':
        assert False, 'Non-root user expected'
    # test for root user
    if collector.collect(collected_facts={})['real_user_id'] != 0:
        assert False, 'Root user expected'

# Generated at 2022-06-11 05:30:47.026402
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector.collect()
    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['user_gecos'] == pwd.getpwuid(os.getuid()).pw_gecos
