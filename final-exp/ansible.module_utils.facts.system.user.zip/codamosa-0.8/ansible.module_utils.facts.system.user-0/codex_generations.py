

# Generated at 2022-06-11 05:20:53.039719
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_collector = UserFactCollector()
    user_collector_facts = user_collector.collect()
    assert set(['user_id', 'user_uid', 'user_gid',
                'user_gecos', 'user_dir', 'user_shell',
                'real_user_id', 'effective_user_id',
                'real_group_id', 'effective_group_id']) == set(user_collector_facts)



if __name__ == '__main__':
    ansible_test_facts = UserFactCollector()
    ansible_test_facts_collected = ansible_test_facts.collect()
    print(ansible_test_facts_collected)

# Generated at 2022-06-11 05:21:03.847510
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Create an instance of class UserFactCollector
    user_fact_collector = UserFactCollector()

    # Call method collect of class UserFactCollector
    result = user_fact_collector.collect()

    # Assert type of result
    assert isinstance(result, dict)

    # Assert return values of method collect
    assert getpass.getuser() == result['user_id']
    assert isinstance(result['user_id'], str)
    assert os.getuid() == result['real_user_id']
    assert isinstance(result['real_user_id'], int)
    assert os.geteuid() == result['effective_user_id']
    assert isinstance(result['effective_user_id'], int)
    assert os.getgid() == result['real_group_id']

# Generated at 2022-06-11 05:21:09.083221
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    m = UserFactCollector()
    result = m.collect()
    assert type(result) is dict
    assert 'user_id' and 'user_uid' and 'user_gid' and 'user_gecos' and \
           'user_dir' and 'user_shell' and 'real_user_id' and \
           'effective_user_id' and 'effective_group_ids' in result

# Generated at 2022-06-11 05:21:17.871578
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    module = None
    collected_facts = None
    user_facts = UserFactCollector().collect(module, collected_facts)
    assert isinstance(user_facts['user_id'], str)
    assert isinstance(user_facts['user_uid'], int)
    assert isinstance(user_facts['user_gid'], int)
    assert isinstance(user_facts['user_dir'], str)
    assert isinstance(user_facts['user_shell'], str)
    assert isinstance(user_facts['real_user_id'], int)
    assert isinstance(user_facts['effective_user_id'], int)
    assert isinstance(user_facts['real_group_id'], int)
    assert isinstance(user_facts['effective_group_id'], int)

# Generated at 2022-06-11 05:21:26.188606
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Create instance of class UserFactCollector
    fact_collector = UserFactCollector()

    # Create instance of class FactsCollector
    facts_collector = FactsCollector()

    # Create instance of class AnsibleModule
    ansible_module = AnsibleModule

    # Create variable collected_facts which contains value None
    collected_facts = None

    # Run method collect of class UserFactCollector
    actual_result = fact_collector.collect(ansible_module, collected_facts)

    # Check the result for the module collect of class UserFactCollector
    assert actual_result

# Generated at 2022-06-11 05:21:32.914921
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collector = UserFactCollector()
    collected_facts = collector.collect()
    assert 'user_id' in collected_facts
    assert 'user_uid' in collected_facts
    assert 'user_gid' in collected_facts
    assert 'user_gecos' in collected_facts
    assert 'user_dir' in collected_facts
    assert 'user_shell' in collected_facts
    assert 'real_user_id' in collected_facts
    assert 'effective_user_id' in collected_facts
    assert 'effective_group_ids' in collected_facts

# Generated at 2022-06-11 05:21:34.998028
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector()
    assert user_facts.collect()['user_id'] == getpass.getuser()

# Generated at 2022-06-11 05:21:45.162856
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fact_collector = UserFactCollector(None)
    result = fact_collector.collect()
    assert result['user_id'] == getpass.getuser()
    assert result['user_uid'] == pwd.getpwuid(os.getuid()).pw_uid
    assert result['user_gid'] == pwd.getpwuid(os.getuid()).pw_gid
    assert result['user_gecos'] == pwd.getpwuid(os.getuid()).pw_gecos
    assert result['user_dir'] == pwd.getpwuid(os.getuid()).pw_dir
    assert result['user_shell'] == pwd.getpwuid(os.getuid()).pw_shell
    assert result['real_user_id'] == os.get

# Generated at 2022-06-11 05:21:54.790215
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collected_facts = {}
    test_obj = UserFactCollector()
    collected_facts = test_obj.collect(None, collected_facts)

    assert "user_id" in collected_facts
    assert "user_uid" in collected_facts
    assert "user_gid" in collected_facts
    assert "user_gecos" in collected_facts
    assert "user_dir" in collected_facts
    assert "user_shell" in collected_facts
    assert "real_user_id" in collected_facts
    assert "effective_user_id" in collected_facts
    assert "real_group_id" in collected_facts
    assert "effective_group_id" in collected_facts

# Generated at 2022-06-11 05:22:02.777170
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    import os

    import pytest

    import ansible.module_utils.facts.collector.user as UserFactCollector
    reload(UserFactCollector)

    def getpwnam_side_effect(user_id):
        class Pwd:
            pw_uid = user_id
            pw_gid = 1111
            pw_gecos = 'user_gecos'
            pw_dir = '/user_dir'
            pw_shell = '/user_shell'
        return Pwd

    def geteuid_side_effect():
        return 2222

    def getuid_side_effect():
        return 3333

    def getegid_side_effect():
        return 4444

    def getgid_side_effect():
        return 5555

    mock_module = pytest.Mock()


# Generated at 2022-06-11 05:22:14.198863
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    coll = UserFactCollector()
    user_facts = coll.collect()
    assert 'user_id' in user_facts
    assert 'user_uid' in user_facts
    assert 'user_gid' in user_facts
    assert 'user_gecos' in user_facts
    assert 'user_dir' in user_facts
    assert 'user_shell' in user_facts
    assert 'real_user_id' in user_facts
    assert 'effective_user_id' in user_facts
    assert 'effective_group_ids' in user_facts


# Generated at 2022-06-11 05:22:23.459357
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector().collect()
    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['user_uid'] == os.getuid()
    assert user_facts['user_gid'] == os.getgid()
    assert user_facts['user_gecos']
    assert user_facts['user_dir']
    assert user_facts['user_shell']
    assert isinstance(user_facts['real_user_id'], int)
    assert isinstance(user_facts['effective_user_id'], int)
    assert isinstance(user_facts['real_group_id'], int)
    assert isinstance(user_facts['effective_group_id'], int)

# Generated at 2022-06-11 05:22:28.571529
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fact_collector = UserFactCollector()
    fact_collector.collect()
    keys = fact_collector.get_facts().keys()
    assert 'user_id' in keys
    assert 'user_gid' in keys
    assert 'user_gecos' in keys
    assert 'user_shell' in keys
    assert 'user_uid' in keys
    assert 'user_dir' in keys
    assert 'real_user_id' in keys
    assert 'effective_user_id' in keys
    assert 'effective_group_ids' in keys

# Generated at 2022-06-11 05:22:38.272588
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    class Mock_pwd:
        class Mock_pwent:
            def __init__(self):
                self.pw_uid = 0
                self.pw_gid = 0
                self.pw_gecos = "my_gecos"
                self.pw_dir = "my_dir"
                self.pw_shell = "my_shell"

        def getpwnam(self, user_id):
            return Mock_pwent()

    class Mock_getpass:
        def getuser(self):
            return "my_user_id"

    class Mock_os:
        def getuid(self):
            return 0
        def geteuid(self):
            return 0
        def getgid(self):
            return 0

    import __builtin__

# Generated at 2022-06-11 05:22:48.777102
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import unittest

    class TestFactsModule(object):
        def __init__(self):
            self.func = None

    pwd_getpwnam_called = 0
    pwd_getpwuid_called = 0

    class TestPwdGetPwNam(object):
        def __init__(self):
            self.pw_uid = '123'
            self.pw_gid = '456'
            self.pw_gecos = 'gecos'
            self.pw_dir = '/home/user'
            self.pw_shell = '/bin/sh'

        def getpwnam(self, user):
            self.user = user
            nonlocal pwd_getpwnam_called
            pwd_getpwnam_called = pwd_getpwnam_

# Generated at 2022-06-11 05:22:56.551870
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import ansible.utils.pycompat
    from ansible.module_utils.facts import collector

    # Create mock object of class BaseFactCollector
    mock_BaseFactCollector = collector.BaseFactCollector()

    # Create object of class UserFactCollector
    user_collector = UserFactCollector()

    # Test collect method
    returned_user_facts = user_collector.collect(collected_facts=mock_BaseFactCollector)
    
    # Verify returned value
    assert 'user_id' in returned_user_facts
    assert 'user_uid' in returned_user_facts
    assert 'user_gid' in returned_user_facts
    assert 'user_gecos' in returned_user_facts
    assert 'user_dir' in returned_user_facts
    assert 'user_shell' in returned_

# Generated at 2022-06-11 05:22:58.769147
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # test class UserFactCollector exists
    assert hasattr(UserFactCollector, "collect")
    # test returned dictionary exists
    assert UserFactCollector.collect()

# Generated at 2022-06-11 05:23:08.354956
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    def context():
        module = AnsibleModuleHelper(argument_spec={})
        setattr(getpass, 'getuser', lambda: 'user_id')
        return module

    mod = context()
    user_facts = UserFactCollector().collect(module=mod)

    assert user_facts == {
        'user_id': 'user_id',
        'user_uid': 10001,
        'user_gid': 1001,
        'user_gecos': 'Alice Developer,,,',
        'user_dir': '/home/alice',
        'user_shell': '/bin/bash',
        'real_user_id': 10001,
        'effective_user_id': 10001,
        'real_group_id': 1001,
        'effective_group_id': 1001
    }

# Generated at 2022-06-11 05:23:17.120224
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()

    assert user_facts['user_dir'].endswith('/ansible')
    assert user_facts['user_gid'] == 1000
    assert user_facts['user_gecos'] == 'Ansible'
    assert user_facts['user_id'] == 'ansible'
    assert user_facts['user_shell'].endswith('/bash')
    assert user_facts['user_uid'] == 1000

    assert user_facts['effective_group_id'] == user_facts['real_group_id']
    assert user_facts['effective_user_id'] == user_facts['real_user_id']

# Generated at 2022-06-11 05:23:27.310272
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector().collect()
    assert user_facts['user_id'] == getpass.getuser()
    try:
        pwent = pwd.getpwnam(getpass.getuser())
    except KeyError:
        pwent = pwd.getpwuid(os.getuid())
    assert user_facts['user_uid'] == pwent.pw_uid
    assert user_facts['user_gid'] == pwent.pw_gid
    assert user_facts['user_gecos'] == pwent.pw_gecos
    assert user_facts['user_dir'] == pwent.pw_dir
    assert user_facts['user_shell'] == pwent.pw_shell
    assert user_facts['real_user_id'] == os.getuid()
    assert user

# Generated at 2022-06-11 05:23:37.798784
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    # Test with no optional parameters
    result = UserFactCollector.collect()

    assert result['user_id'] == getpass.getuser()
    assert result['user_uid'] == pwd.getpwnam(getpass.getuser()).pw_uid
    assert result['user_gid'] == pwd.getpwnam(getpass.getuser()).pw_gid
    assert result['user_gecos'] == pwd.getpwnam(getpass.getuser()).pw_gecos
    assert result['user_dir'] == pwd.getpwnam(getpass.getuser()).pw_dir
    assert result['user_shell'] == pwd.getpwnam(getpass.getuser()).pw_shell
    assert result['real_user_id'] == os.getuid

# Generated at 2022-06-11 05:23:48.496004
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Create an instance of UserFactCollector and test the collect method
    user_collector = UserFactCollector()
    facts = user_collector.collect()

    assert facts is not None
    assert type(facts) is dict
    assert facts['user_id'] is not None
    assert type(facts['user_id']) is str
    assert facts['user_uid'] is not None
    assert type(facts['user_uid']) is int
    assert facts['user_gid'] is not None
    assert type(facts['user_gid']) is int
    assert facts['user_gecos'] is not None
    assert type(facts['user_gecos']) is str
    assert facts['user_dir'] is not None
    assert type(facts['user_dir']) is str

# Generated at 2022-06-11 05:23:54.195539
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fact_collector = UserFactCollector()
    collected_facts = fact_collector.collect()
    assert 'user_id' in collected_facts
    assert 'user_uid' in collected_facts
    assert 'user_gid' in collected_facts
    assert 'user_gecos' in collected_facts
    assert 'user_dir' in collected_facts
    assert 'user_shell' in collected_facts
    assert 'real_user_id' in collected_facts
    assert 'effective_user_id' in collected_facts
    assert 'effective_group_ids' in collected_facts

# Generated at 2022-06-11 05:24:04.725704
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collected_facts = {}
    expected_facts = {
        'user_id': 'test_user_id',
        'user_uid': 'test_user_uid',
        'user_gid': 'test_user_gid',
        'user_gecos': 'test_user_gecos',
        'user_dir': 'test_user_dir',
        'user_shell': 'test_user_shell',
        'real_user_id': 'test_real_user_id',
        'effective_user_id': 'test_effective_user_id',
        'real_group_id': 'test_real_group_id',
        'effective_group_id': 'test_effective_group_id'
    }

    def mock_collect(module=None, collected_facts=None):
        return expected_facts

# Generated at 2022-06-11 05:24:15.276820
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    expected_facts = {'effective_group_id': os.getgid(),
                      'effective_user_id': os.geteuid(),
                      'real_group_id': os.getgid(),
                      'real_user_id': os.getuid(),
                      'user_dir': os.getcwd(),
                      'user_gecos': pwd.getpwuid(os.getuid()).pw_gecos,
                      'user_gid': pwd.getpwnam(os.getlogin()).pw_gid,
                      'user_id': os.getlogin(),
                      'user_shell': pwd.getpwuid(os.getuid()).pw_shell,
                      'user_uid': pwd.getpwnam(os.getlogin()).pw_uid}

# Generated at 2022-06-11 05:24:22.934469
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import os

    class MockModule:
        def __init__(self):
            self.exit_json = lambda x: True

    user_collector = UserFactCollector()
    assert 'user_id' in user_collector._fact_ids
    assert 'user_uid' in user_collector._fact_ids
    assert 'user_gid' in user_collector._fact_ids
    assert 'user_gecos' in user_collector._fact_ids
    assert 'user_dir' in user_collector._fact_ids
    assert 'user_shell' in user_collector._fact_ids
    assert 'real_user_id' in user_collector._fact_ids
    assert 'effective_user_id' in user_collector._fact_ids
    assert 'effective_group_ids' in user_collector

# Generated at 2022-06-11 05:24:24.925859
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fac_collector = UserFactCollector()
    user_fac_collector.collect()

# Generated at 2022-06-11 05:24:36.101339
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    # Create instance of class UserFactCollector
    user_fact_collector = UserFactCollector()

    # Run method collect
    facts = user_fact_collector.collect()

    # Assert facts
    assert isinstance(facts, dict)
    assert isinstance(facts['user_id'], str)
    assert isinstance(facts['user_uid'], int)
    assert isinstance(facts['user_gid'], int)
    assert isinstance(facts['user_gecos'], str)
    assert isinstance(facts['user_dir'], str)
    assert isinstance(facts['user_shell'], str)
    assert isinstance(facts['real_user_id'], int)
    assert isinstance(facts['effective_user_id'], int)

# Generated at 2022-06-11 05:24:43.509763
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collector = UserFactCollector()
    ansible_facts = {}
    collected_facts = collector.collect(ansible_facts)
    assert 'user_id' in collected_facts
    assert 'user_uid' in collected_facts
    assert 'user_gid' in collected_facts
    assert 'user_gecos' in collected_facts
    assert 'user_dir' in collected_facts
    assert 'user_shell' in collected_facts
    assert 'real_user_id' in collected_facts
    assert 'effective_user_id' in collected_facts
    assert 'real_group_id' in collected_facts
    assert 'effective_group_id' in collected_facts

# Generated at 2022-06-11 05:24:54.467247
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    test = UserFactCollector()
    user_facts = test.collect()

    assert 'user_id' in user_facts
    assert 'user_uid' in user_facts
    assert 'user_gid' in user_facts
    assert 'user_gecos' in user_facts
    assert 'user_dir' in user_facts
    assert 'user_shell' in user_facts
    assert 'real_user_id' in user_facts
    assert 'effective_user_id' in user_facts
    assert 'effective_group_ids' in user_facts

    assert isinstance(user_facts['user_id'], str)
    assert isinstance(user_facts['user_uid'], int)
    assert isinstance(user_facts['user_gid'], int)

# Generated at 2022-06-11 05:25:08.967342
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import platform  # module required by test
    test_file = 'ansible/module_utils/facts/collectors/user.py'
    __import__(get_module_path(test_file, 'ansible'))
    import ansible.module_utils.facts.collectors.user as test_file
    class_name = 'UserFactCollector'
    class_obj = list(filter(lambda x: x.__name__ == class_name,
                            map(lambda x: x[1], list(vars(test_file).items()))))[0]
    obj = class_obj()
    user_facts = obj.collect()
    assert 'user_id' in user_facts.keys(), 'test_UserFactCollector_collect #1 failed'

# Generated at 2022-06-11 05:25:17.820647
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    ufc._facts['user_id'] = 'ansible'
    ufc._facts['real_user_id'] = 'ansible'
    ufc._facts['effective_user_id'] = 'ansible'
    ufc._facts['real_group_id'] = 'ansible'
    ufc._facts['effective_group_id'] = 'ansible'
    ufc._facts['user_uid'] = 1000
    ufc._facts['user_gid'] = 1000
    ufc._facts['user_gecos'] = 'ansible'
    ufc._facts['user_dir'] = '/home/ansible'
    ufc._facts['user_shell'] = '/bin/bash'


# Generated at 2022-06-11 05:25:19.091185
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    facts = ufc.collect()

# Generated at 2022-06-11 05:25:26.097136
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # pylint: disable=protected-access
    user_fact_collector = UserFactCollector()

    # Test regular User Fact Collector
    collected_facts = user_fact_collector.collect()
    assert isinstance(collected_facts, dict)
    assert len(collected_facts) == len(user_fact_collector._fact_ids)

    for fact in user_fact_collector._fact_ids:
        assert fact in collected_facts.keys()
        assert isinstance(collected_facts[fact], int) or isinstance(collected_facts[fact], str)

# Generated at 2022-06-11 05:25:36.202147
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    def mocked_getpwuid(uid):
        pwent = ["myuser", "x", "1001", "1001", "myuser,,,", "/home/myuser", "/bin/bash"]
        return pwent
    def mocked_getuid():
        return 0
    def mocked_geteuid():
        return 0
    def mocked_getgid():
        return 0
    def mocked_getegid():
        return 0
    pwd.getpwuid = mocked_getpwuid
    os.getuid = mocked_getuid
    os.geteuid = mocked_geteuid
    os.getgid = mocked_getgid
    os.getegid = mocked_getegid

    user_fact_collector = UserFactCollector()
    fact_data = user_fact_collector.collect()
   

# Generated at 2022-06-11 05:25:37.992524
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    u = UserFactCollector()
    facts = u.collect()
    assert isinstance(facts, dict)

# Generated at 2022-06-11 05:25:45.297103
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    facts = user_fact_collector.collect()
    assert('user_id' in facts)
    assert('user_uid' in facts)
    assert('user_gid' in facts)
    assert('user_gecos' in facts)
    assert('user_dir' in facts)
    assert('user_shell' in facts)
    assert('real_user_id' in facts)
    assert('effective_user_id' in facts)
    assert('effective_group_ids' in facts)

# Generated at 2022-06-11 05:25:55.030224
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact = UserFactCollector()
    user_facts = user_fact.collect()

    assert 'user_id' in user_facts
    assert isinstance(user_facts['user_id'], str)

    assert 'user_uid' in user_facts
    assert isinstance(user_facts['user_uid'], int)

    assert 'user_gid' in user_facts
    assert isinstance(user_facts['user_gid'], int)

    assert 'user_gecos' in user_facts
    assert isinstance(user_facts['user_gecos'], str)

    assert 'user_dir' in user_facts
    assert isinstance(user_facts['user_dir'], str)

    assert 'user_shell' in user_facts

# Generated at 2022-06-11 05:26:04.734452
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import platform
    collector = UserFactCollector()
    facts = collector.collect()
    assert facts is not None
    assert 'user_id' in facts
    assert facts['user_id'] == getpass.getuser()
    assert 'user_uid' in facts
    assert facts['user_uid'] == pwd.getpwuid(os.getuid()).pw_uid
    assert 'user_gid' in facts
    assert facts['user_gid'] == pwd.getpwuid(os.getuid()).pw_gid
    assert 'user_gecos' in facts
    assert facts['user_gecos'] == pwd.getpwuid(os.getuid()).pw_gecos
    assert 'user_dir' in facts
    assert facts['user_dir'] == pwd.getpw

# Generated at 2022-06-11 05:26:14.072262
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    real_userid = getpass.getuser()

    fact_collector = UserFactCollector()
    fact_collector.collect()

    assert fact_collector.fact_ids == set(['user_id', 'user_uid', 'user_gid', 'user_gecos',
                                           'user_dir', 'user_shell',
                                           'real_user_id', 'effective_user_id',
                                           'real_group_id', 'effective_group_id'])

    assert fact_collector.user_id == real_userid
    assert fact_collector.user_uid != 0
    assert fact_collector.user_gid != 0
    assert fact_collector.user_gecos != ''
    assert fact_collector.user_dir != ''
    assert fact_collector.user

# Generated at 2022-06-11 05:26:27.628488
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    pass

# Generated at 2022-06-11 05:26:31.443798
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Arrange
    from ansible.module_utils.facts import collector
    collector.collectors['user'] = UserFactCollector()

    module = None
    collected_facts = None

    # Act
    result = collector.collectors['user'].collect(collected_facts)

    # Assert
    assert 'user_id' in result

# Generated at 2022-06-11 05:26:34.618273
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    factCollector = UserFactCollector()

    # Test UserFactCollector._collect()
    user_facts = factCollector.collect()
    assert user_facts['user_id'] == getpass.getuser()


# Generated at 2022-06-11 05:26:35.940556
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    assert ufc.collect() is not None

# Generated at 2022-06-11 05:26:45.142160
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # set up some test values
    expected_user_id = 'root'
    expected_user_uid = 0
    expected_user_gid = 0
    expected_user_gecos = 'root'
    expected_user_dir = '/root'
    expected_user_shell = '/bin/bash'
    expected_real_user_id = 0
    expected_real_group_id = 0

    # instantiate UserFactCollector class
    user_collector = UserFactCollector()

    # make the collect method call
    user_facts = user_collector.collect()

    # get the values for a few keys
    got_user_id = user_facts.get('user_id')
    got_user_uid = user_facts.get('user_uid')

# Generated at 2022-06-11 05:26:53.169879
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    assert ufc.collect() == {
        'user_id': 'vagrant',
        'user_uid': 1000,
        'user_gid': 1000,
        'user_gecos': 'vagrant,,,',
        'user_dir': '/home/vagrant',
        'user_shell': '/bin/bash',
        'real_user_id': 1000,
        'effective_user_id': 1000,
        'real_group_id': 1000,
        'effective_group_id': 1000
    }

# Generated at 2022-06-11 05:26:54.529873
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact = UserFactCollector()
    user_fact.collect()

# Generated at 2022-06-11 05:26:59.600363
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collector = UserFactCollector()
    assert collector.collect() == {'effective_group_id': 1000, 'effective_user_id': 1000, 'real_user_id': 1000, 'user_id': u'default', 'user_gid': 1000, 'user_uid': 1000, 'real_group_id': 1000, 'user_dir': u'/home/default', 'user_gecos': u'default', 'user_shell': u'/bin/bash'}

# Generated at 2022-06-11 05:27:08.666785
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    """
    The following code tests that UserFactCollector.collect() works properly
    when executed with a valid set of arguments and returns expected results.
    """

    # define UserFactCollector instance
    collector = UserFactCollector()

    # define modules.module_utils.facts.collector.BaseFactCollector.module
    # attribute obtained by UserFactCollector.collect()
    module = object()

    # define modules.module_utils.facts.collector.BaseFactCollector.collected_facts
    # attribute obtained by UserFactCollector.collect()
    collected_facts = {}

    # define expected results for UserFactCollector.collect()
    user_facts = collector.collect(module, collected_facts)

    # check if expected results for UserFactCollector.collect()
    # are the same as the obtained ones

# Generated at 2022-06-11 05:27:09.206881
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    pass

# Generated at 2022-06-11 05:27:37.322043
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fact_collector = UserFactCollector()
    fact_collector.collect()
    for fact_id in fact_collector._fact_ids:
        assert fact_id in fact_collector.collect()

# Generated at 2022-06-11 05:27:46.126657
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fact_collector = UserFactCollector()
    user_facts = fact_collector.collect()
    assert type(user_facts) == dict
    assert user_facts.get('real_user_id') == os.getuid()
    assert type(user_facts.get('real_user_id')) == int
    assert user_facts.get('effective_user_id') == os.geteuid()
    assert type(user_facts.get('effective_user_id')) == int
    assert user_facts.get('user_id') == getpass.getuser()
    assert type(user_facts.get('user_id')) == str
    pwent = pwd.getpwuid(os.getuid())
    assert user_facts.get('user_uid') == pwent.pw_uid
    assert type

# Generated at 2022-06-11 05:27:53.471609
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fact_collector = UserFactCollector()
    fact_collection = fact_collector.collect()

    assert 'user_id' in fact_collection
    assert 'user_uid' in fact_collection
    assert 'user_gid' in fact_collection
    assert 'user_gecos' in fact_collection
    assert 'user_dir' in fact_collection
    assert 'user_shell' in fact_collection
    assert 'real_user_id' in fact_collection
    assert 'effective_user_id' in fact_collection
    assert 'real_group_id' in fact_collection
    assert 'effective_group_id' in fact_collection

# Generated at 2022-06-11 05:28:03.299302
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import unittest
    import sys

    class TestUserFactCollector_collect(unittest.TestCase):
        """
        Test the collect method of UserFactCollector class.
        """

        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test_user_collect(self):
            """
            Test of user collect method.
            """
            user_facts_collector = UserFactCollector()
            result = user_facts_collector.collect()
            self.assertIsInstance(result, dict)
            self.assertEqual(user_facts_collector.name, 'user')
            self.assertTrue(user_facts_collector._fact_ids.issubset(result.keys()))

    # Load the tests
    module = sys.modules[__name__]
   

# Generated at 2022-06-11 05:28:10.784032
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()

# Generated at 2022-06-11 05:28:19.213490
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    c = UserFactCollector()
    result = c.collect()

    assert 'user_id' in result
    assert result['user_id'] == getpass.getuser()

    assert 'user_uid' in result

    assert 'user_gid' in result

    assert 'user_gecos' in result

    assert 'user_dir' in result

    assert 'user_shell' in result

    assert 'real_user_id' in result
    assert result['real_user_id'] == os.getuid()

    assert 'effective_user_id' in result
    assert result['effective_user_id'] == os.geteuid()

    assert 'real_group_id' in result

    assert 'effective_group_id' in result

# Generated at 2022-06-11 05:28:27.956177
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fc = UserFactCollector()
    fact_list = fc.collect()
    assert fact_list['user_id'] == getpass.getuser()
    assert fact_list['user_uid'] == pwd.getpwnam(getpass.getuser()).pw_uid
    assert fact_list['user_gid'] == pwd.getpwnam(getpass.getuser()).pw_gid
    assert fact_list['user_gecos'] == pwd.getpwnam(getpass.getuser()).pw_gecos
    assert fact_list['user_dir'] == pwd.getpwnam(getpass.getuser()).pw_dir
    assert fact_list['user_shell'] == pwd.getpwnam(getpass.getuser()).pw_shell
   

# Generated at 2022-06-11 05:28:28.506433
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    pass

# Generated at 2022-06-11 05:28:36.897541
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    user_facts = ufc.collect()
    assert type(user_facts['user_id']) is str
    assert type(user_facts['user_uid']) is int
    assert type(user_facts['user_gid']) is int
    assert type(user_facts['user_gecos']) is str
    assert type(user_facts['user_dir']) is str
    assert type(user_facts['user_shell']) is str
    assert type(user_facts['real_user_id']) is int
    assert type(user_facts['effective_user_id']) is int
    assert type(user_facts['real_group_id']) is int
    assert type(user_facts['effective_group_id']) is int

# Generated at 2022-06-11 05:28:38.711507
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollecto()
    user_facts = ufc.collect()
    assert set(user_facts.keys()) == ufc._fact_ids

# Generated at 2022-06-11 05:29:37.055395
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    c = UserFactCollector()
    assert isinstance(c, BaseFactCollector)
    assert set(c._fact_ids) == set(['user_id', 'user_uid', 'user_gid', 'user_gecos', 'user_dir', 'user_shell', 'real_user_id', 'effective_user_id', 'effective_group_ids'])
    assert isinstance(c.collect(), dict)

# Generated at 2022-06-11 05:29:47.093859
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Given
    module = {'getpass.getuser': lambda : 'test_user'}
    obj = UserFactCollector()
    obj._module = module
    fake_pwent = type('obj', (object,), dict(pw_uid='100', pw_gid='100', pw_gecos='Test User', pw_dir='/home/test_user', pw_shell='/bin/bash'))

    # When
    getpwnam_mock = lambda x: fake_pwent
    pwd.getpwnam = getpwnam_mock

    os.getuid = lambda : '100'
    os.geteuid = lambda : '100'
    os.getgid = lambda : 100
    os.getegid = lambda : 100


# Generated at 2022-06-11 05:29:53.360516
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    # create the object
    userFactCollector = UserFactCollector()
    user_facts = userFactCollector.collect()
    # test if type of result is dict
    if not isinstance(user_facts, dict):
        raise Exception('UserFactCollector.collect returned type '
                        + str(type(user_facts)))

    # test if keys in result
    for key in user_facts:
        if key not in userFactCollector._fact_ids:
            raise Exception('UserFactCollector.collect returned wrong'
                            + ' key ' + key)

# Generated at 2022-06-11 05:30:02.716414
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Given
    instance = UserFactCollector()

    # When
    result = instance.collect()

    # Then
    assert result['user_id'] == getpass.getuser()
    assert result['user_uid'] == os.getuid()
    assert result['user_gid'] == os.getgid()
    assert result['user_gecos'] == pwd.getpwuid(os.getuid()).pw_gecos
    assert result['user_shell'] == pwd.getpwuid(os.getuid()).pw_shell
    assert result['real_user_id'] == os.getuid()
    assert result['effective_user_id'] == os.geteuid()
    assert result['real_group_id'] == os.getgid()

# Generated at 2022-06-11 05:30:05.872479
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    fact_collector = FactsCollector()
    assert fact_collector.collect()['system']['user']['user_id'] == 'ansible'

# Generated at 2022-06-11 05:30:12.301102
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector()
    fact = user_facts.collect()

    assert fact == {
        'effective_group_id': 20,
        'effective_user_id': 1000,
        'real_group_id': 20,
        'real_user_id': 1000,
        'user_dir': '/home/test/',
        'user_gid': 20,
        'user_gecos': 'test,,,',
        'user_id': 'test',
        'user_shell': '/bin/bash',
        'user_uid': 1000,
    }

# Generated at 2022-06-11 05:30:13.796323
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    '''Test the collect method of UserFactCollector'''
    unittest.main()


# Generated at 2022-06-11 05:30:21.313059
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()

    # Unit test with no parameter
    user_facts = user_fact_collector.collect()
    assert user_facts['user_id'] is not None
    assert user_facts['user_uid'] is not None
    assert user_facts['user_gid'] is not None
    assert user_facts['user_gecos'] is not None
    assert user_facts['user_dir'] is not None
    assert user_facts['user_shell'] is not None
    assert user_facts['real_user_id'] is not None
    assert user_facts['effective_user_id'] is not None
    assert user_facts['real_group_id'] is not None
    assert user_facts['effective_group_id'] is not None

# Generated at 2022-06-11 05:30:24.764419
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    instance = UserFactCollector()
    facts_result = instance.collect()
    print(facts_result)
    assert facts_result is not None

if __name__ == '__main__':
    test_UserFactCollector_collect()

# Generated at 2022-06-11 05:30:32.765641
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    my_obj = UserFactCollector()
    my_obj_result = my_obj.collect(module=None, collected_facts=None)
    assert my_obj_result['user_id'] == getpass.getuser()
    assert my_obj_result['user_uid'] == pwd.getpwnam(getpass.getuser()).pw_uid
    assert my_obj_result['user_gid'] == pwd.getpwnam(getpass.getuser()).pw_gid
    assert my_obj_result['user_gecos'] == pwd.getpwnam(getpass.getuser()).pw_gecos
    assert my_obj_result['user_dir'] == pwd.getpwnam(getpass.getuser()).pw_dir