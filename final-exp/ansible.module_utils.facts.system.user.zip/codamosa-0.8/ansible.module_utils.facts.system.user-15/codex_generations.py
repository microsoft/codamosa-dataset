

# Generated at 2022-06-11 05:20:57.717202
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ''' test that correct values are returned by UserFactCollector#collect '''
    c = UserFactCollector()
    facts = c.collect()
    assert facts['user_id'] == getpass.getuser(), \
        'incorrect user_id returned by UserFactCollector#collect (expected {0}, got {1})'.format(getpass.getuser(), facts['user_id'])
    assert facts['real_user_id'] == os.getuid(), \
        'incorrect real_user_id returned by UserFactCollector#collect (expected {0}, got {1})'.format(os.getuid(), facts['real_user_id'])

# Generated at 2022-06-11 05:21:00.205628
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    myUserFactCollector = UserFactCollector()
    myUserFactCollector.collect()
    print("test_UserFactCollector_collect() passed")


# Generated at 2022-06-11 05:21:11.096038
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector().collect()
    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['user_group_id'] == pwd.getpwuid(os.getuid()).pw_gid
    assert user_facts['user_gecos'] == pwd.getpwuid(os.getuid()).pw_gecos
    assert user_facts['user_dir'] == pwd.getpwuid(os.getuid()).pw_dir
    assert user_facts['user_shell'] == pwd.getpwuid(os.getuid()).pw_shell
    assert user_facts['real_user_id'] == os.getuid()
    assert user_facts['effective_user_id'] == os.geteuid()

# Generated at 2022-06-11 05:21:13.267983
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Test UserFactCollector_collect.
    tester = UserFactCollector()

    # Test exception.
    try:
        tester.collect()
    except KeyError:
        assert True

# Generated at 2022-06-11 05:21:19.565211
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user = UserFactCollector()
    result = user.collect()
    assert isinstance(result, dict)
    assert result['user_id'] == 'root'
    assert result['user_uid'] == 0
    assert result['user_gid'] == 0
    assert result['user_gecos'] == 'root'
    assert result['user_dir'] == '/root'
    assert result['user_shell'] == '/bin/bash'
    assert result['real_user_id'] == 0
    assert result['effective_user_id'] == 0
    assert result['real_group_id'] == 0
    assert result['effective_group_id'] == 0
    assert result['effective_group_ids'] == [0]

# Generated at 2022-06-11 05:21:26.037038
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    facts = {'user_id': 'root', 'user_uid': 0, 'user_gid': 0, 'user_gecos': 'root', 'user_dir': '/root', 'user_shell': '/bin/bash',
    'real_user_id': 0, 'effective_user_id': 0, 'real_group_id': 0, 'effective_group_id': 0}
    UserFactCollector().collect() == facts

# Generated at 2022-06-11 05:21:30.459622
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collector = UserFactCollector()
    user_facts = collector.collect()
    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['user_uid'] == os.getuid()
    assert user_facts['user_gid'] == os.getgid()

# Generated at 2022-06-11 05:21:36.502581
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector().collect()
    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['real_user_id'] == os.getuid()
    assert user_facts['effective_user_id'] == os.geteuid()
    assert user_facts['real_group_id'] == os.getgid()
    assert user_facts['effective_group_id'] == os.getegid()
    assert isinstance(user_facts['effective_group_ids'], list)
    assert isinstance(user_facts['user_gecos'], str)
    assert isinstance(user_facts['user_dir'], str)
    assert isinstance(user_facts['user_shell'], str)

# Generated at 2022-06-11 05:21:41.418440
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_collector = UserFactCollector()
    user_facts = user_collector.collect()
    assert len(user_facts.keys()) >= 8
    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['user_uid'] == os.getuid()
    assert user_facts['user_gid'] == os.getgid()

# Generated at 2022-06-11 05:21:52.212382
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts_collector = UserFactCollector()
    user_facts = user_facts_collector.collect()
    assert isinstance(user_facts, dict)
    assert isinstance(user_facts['user_id'], str)
    assert isinstance(user_facts['user_uid'], int)
    assert isinstance(user_facts['user_gid'], int)
    assert isinstance(user_facts['user_gecos'], str)
    assert isinstance(user_facts['user_dir'], str)
    assert isinstance(user_facts['user_shell'], str)
    assert isinstance(user_facts['real_user_id'], int)
    assert isinstance(user_facts['effective_user_id'], int)

# Generated at 2022-06-11 05:21:56.791474
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fact_collector = UserFactCollector()
    fact_collector.collect()

# Generated at 2022-06-11 05:22:00.250497
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # this is a method of the generated class UserFactCollector
    # following test ensures that the method collect exists for
    # this generated class
    # this method is also called in the base class
    # FactCollector, which is called in the main function.
    c = UserFactCollector()
    assert c.collect() is not None

# Generated at 2022-06-11 05:22:01.338893
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    pass

# Generated at 2022-06-11 05:22:10.738749
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collector = UserFactCollector()
    user_facts = collector.collect()

    assert user_facts['user_id'] == getpass.getuser()
    assert type(user_facts['user_uid']) == int
    assert type(user_facts['user_gid']) == int
    assert type(user_facts['user_gecos']) == str
    assert type(user_facts['user_dir']) == str
    assert type(user_facts['user_shell']) == str
    assert type(user_facts['real_user_id']) == int
    assert type(user_facts['effective_user_id']) == int


# Generated at 2022-06-11 05:22:21.241554
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    from ansible.module_utils.facts import index

    base_index = index.BaseFactIndex()
    user_index = index.UserFactIndex()
    base_index.add_index(user_index)

    module = object()
    collected_facts = object()

    base_index.collect_indexes(module, collected_facts)

    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect(module, collected_facts)

    # Check all user facts exist.
    for fact_id in UserFactCollector._fact_ids:
        assert fact_id in user_facts

    # Check user facts are all string.
    for fact_id in UserFactCollector._fact_ids:
        assert isinstance(user_facts[fact_id], str)

# Generated at 2022-06-11 05:22:29.147629
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import os
    import re
    import test
    real_user_id = os.getuid()
    real_group_id = os.getgid()
    effective_user_id = os.geteuid()
    effective_group_id = os.getegid()
    user_gecos = pwd.getpwuid(real_user_id).pw_gecos
    user_id = pwd.getpwuid(real_user_id).pw_name
    user_gid = pwd.getpwuid(real_user_id).pw_gid
    user_shell = pwd.getpwuid(real_user_id).pw_shell
    user_uid = pwd.getpwuid(real_user_id).pw_uid

# Generated at 2022-06-11 05:22:39.174441
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    getpass.getuser = lambda: 'dwagner'
    pwd.getpwnam = lambda x: type('pwent', (object,), {'pw_uid': 10, 'pw_gid': 10, 'pw_gecos': 'David Wagner', 'pw_dir': '/home/dwagner', 'pw_shell': '/bin/bash'})()
    pwd.getpwuid = lambda x: type('pwent', (object,), {'pw_uid': 10, 'pw_gid': 10, 'pw_gecos': 'David Wagner', 'pw_dir': '/home/dwagner', 'pw_shell': '/bin/bash'})()
    os.getuid = lambda: 10
    os.geteuid = lambda: 10
    os.getgid

# Generated at 2022-06-11 05:22:49.264354
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    # Create a user fact collector
    collector = UserFactCollector()

    # collect facts
    facts = collector.collect()

    # check that the user_id fact is present and is a string
    assert 'user_id' in facts
    assert isinstance(facts['user_id'], str)
    assert len(facts['user_id']) > 0

    # check that the user_uid fact is present and is an integer
    assert 'user_uid' in facts
    assert isinstance(facts['user_uid'], int)
    assert facts['user_uid'] > 0

    # check that the user_gid fact is present and is an integer
    assert 'user_gid' in facts
    assert isinstance(facts['user_gid'], int)
    assert facts['user_gid'] > 0

    # check that the user

# Generated at 2022-06-11 05:22:50.534256
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    #TODO


# Generated at 2022-06-11 05:22:56.852914
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    collected_facts = user_fact_collector.collect()
    assert collected_facts == {
        'effective_user_id': 0,
        'effective_group_id': 0,
        'real_user_id': 0,
        'real_group_id': 0,
        'user_uid': 0,
        'user_gid': 0,
        'user_id': "root",
        'user_gecos': "root",
        'user_dir': '/root',
        'user_shell': '/bin/bash',
    }

# Generated at 2022-06-11 05:23:07.932123
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()

    collected_facts = user_fact_collector.collect()

    assert collected_facts["user_id"] == getpass.getuser()
    assert collected_facts["real_user_id"] == os.getuid()
    assert collected_facts["effective_user_id"] == os.geteuid()
    assert collected_facts["real_group_id"] == os.getgid()
    assert collected_facts["effective_group_id"] == os.getgid()
    assert collected_facts["user_dir"] == os.path.expanduser("~")


# Generated at 2022-06-11 05:23:17.388867
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    test_user_facts = user_fact_collector.collect()
    pwent = pwd.getpwnam(getpass.getuser())
    assert test_user_facts['user_id'] == getpass.getuser()
    assert test_user_facts['user_uid'] == pwent.pw_uid
    assert test_user_facts['user_gid'] == pwent.pw_gid
    assert test_user_facts['user_gecos'] == pwent.pw_gecos
    assert test_user_facts['user_dir'] == pwent.pw_dir
    assert test_user_facts['user_shell'] == pwent.pw_shell
    assert test_user_facts['real_user_id'] == os.getuid()

# Generated at 2022-06-11 05:23:27.990365
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    user_facts = ufc.collect()
    assert type(user_facts) is dict
    assert "user_id" in user_facts
    assert "user_uid" in user_facts
    assert "user_gid" in user_facts
    assert "user_gecos" in user_facts
    assert "user_dir" in user_facts
    assert "user_shell" in user_facts
    assert "real_user_id" in user_facts
    assert "effective_user_id" in user_facts
    assert "effective_group_id" in user_facts
    assert user_facts['user_id'] == getpass.getuser()

# Generated at 2022-06-11 05:23:36.253544
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fact_collector = UserFactCollector()

    facts = fact_collector.collect()

    assert facts['user_id'] is not None
    # assert facts['user_uid'] is not None
    # assert facts['user_gid'] is not None
    # assert facts['user_gecos'] is not None
    # assert facts['user_dir'] is not None
    # assert facts['user_shell'] is not None
    assert facts['real_user_id'] == os.getuid()
    assert facts['effective_user_id'] == os.geteuid()
    assert facts['real_group_id'] == os.getgid()
    assert facts['effective_group_id'] == os.getegid()



# Generated at 2022-06-11 05:23:47.068784
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    user_facts = ufc.collect()
    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['user_uid'] == pwd.getpwuid(os.getuid()).pw_uid
    assert user_facts['user_gid'] == pwd.getpwuid(os.getuid()).pw_gid
    assert user_facts['user_gecos'] == pwd.getpwuid(os.getuid()).pw_gecos
    assert user_facts['user_dir'] == pwd.getpwuid(os.getuid()).pw_dir
    assert user_facts['user_shell'] == pwd.getpwuid(os.getuid()).pw_shell

# Generated at 2022-06-11 05:23:53.381661
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector().collect()
    assert user_facts['user_id'] is not None
    assert user_facts['user_uid'] > 0
    assert user_facts['user_gid'] > 0
    assert user_facts['user_gecos'] is not None
    assert user_facts['user_dir'] is not None
    assert user_facts['user_shell'] is not None
    assert user_facts['real_user_id'] > 0
    assert user_facts['effective_user_id'] > 0
    assert user_facts['real_group_id'] > 0
    assert user_facts['effective_group_id'] > 0

# Generated at 2022-06-11 05:23:59.815186
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    testFacts = {'user_id': getpass.getuser()}
    testUserFacts = UserFactCollector()

    collected_facts = {'ansible_local': {'user': []},
                       'ansible_facts': {}}

    # Collecting facts with UserFactCollector
    testUserFacts.collect(collected_facts=collected_facts)
    assert(collected_facts['ansible_facts']['user_id'] == testFacts['user_id'])

# Generated at 2022-06-11 05:24:10.329257
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
	from ansible.module_utils.facts.collector import BaseFactCollector
	args = {}
	obj = BaseFactCollector.collect(args,None)
	assert obj['ansible_user_id'] == 'root'
	assert obj['user_id'] == 'root'
	assert obj['user_gecos'] == 'root'
	assert obj['effective_user_id'] == 0
	assert obj['effective_group_id'] == 0
	assert obj['real_user_id'] == 0
	assert obj['real_group_id'] == 0
	assert obj['user_shell'] == '/bin/bash'
	assert obj['user_dir'] == '/root'
	assert obj['user_uid'] == 0
	assert obj['user_gid'] == 0

# Generated at 2022-06-11 05:24:19.754631
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    tmp = UserFactCollector()
    data = tmp.collect()
    assert('user_id' in data)
    assert('user_uid' in data)
    assert('user_gid' in data)
    assert('user_gecos' in data)
    assert('user_dir' in data)
    assert('user_shell' in data)
    assert('real_user_id' in data)
    assert('effective_user_id' in data)
    assert('real_group_id' in data)
    assert('effective_group_id' in data)
    assert(type(data['user_id']) == type(''))
    assert(type(data['user_uid']) == type(1))
    assert(type(data['user_gid']) == type(1))

# Generated at 2022-06-11 05:24:27.630172
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    c = UserFactCollector()
    actual_facts = c.collect()

    assert (actual_facts['user_id'] == getpass.getuser())
    assert (actual_facts['user_uid'] == os.getuid())
    assert (actual_facts['user_gid'] == os.getgid())
    assert (actual_facts['real_user_id'] == os.getuid())
    assert (actual_facts['effective_user_id'] == os.geteuid())
    assert (actual_facts['real_group_id'] == os.getgid())
    assert (actual_facts['effective_group_id'] == os.getegid())

# Generated at 2022-06-11 05:24:36.527121
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    import sys
    import pwd

    try:
        UserFactCollector().collect()
    except KeyError:
        pass

# Generated at 2022-06-11 05:24:42.528710
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collector = UserFactCollector()
    expected_output = {'user_id': 'root',
                       'user_uid': 0,
                       'user_gid': 0,
                       'user_gecos': 'root',
                       'user_dir': '/root',
                       'user_shell': '/bin/bash',
                       'real_user_id': 0,
                       'effective_user_id': 0,
                       'real_group_id': 0,
                       'effective_group_id': 0}

    assert collector.collect() == expected_output

# Generated at 2022-06-11 05:24:43.439610
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    userFactCollector = UserFactCollector()
    userFactCollector.collect()
    del userFactCollector

# Generated at 2022-06-11 05:24:47.253315
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    # Since we can't guarantee the state of the user facts outside a
    # container, we will verify that the dictionary is not empty.
    assert user_fact_collector.collect()

# Generated at 2022-06-11 05:24:49.796275
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    userfactcollector = UserFactCollector()
    result = userfactcollector.collect()
    assert result["user_id"]

# Generated at 2022-06-11 05:24:52.477770
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector()

    # Unit test for the payload
    assert user_facts.collect() is not None, "Failed to collect the payload"


# Generated at 2022-06-11 05:25:01.776419
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    user_fact_collector = UserFactCollector()
    collected_facts = user_fact_collector.collect()
    user_id = collected_facts['user_id']
    user_uid = collected_facts['user_uid']
    user_gid = collected_facts['user_gid']
    user_gecos = collected_facts['user_gecos']
    user_dir = collected_facts['user_dir']
    user_shell = collected_facts['user_shell']
    real_user_id = collected_facts['real_user_id']
    effective_user_id = collected_facts['effective_user_id']
    real_group_id = collected_facts['real_group_id']
    effective_group_id = collected_facts['effective_group_id']


# Generated at 2022-06-11 05:25:09.885606
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector().collect()
    assert isinstance(user_facts, dict)
    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['user_uid'] == pwd.getpwuid(os.getuid()).pw_uid
    assert user_facts['user_gid'] == pwd.getpwuid(os.getuid()).pw_gid
    assert user_facts['user_gecos'] == pwd.getpwuid(os.getuid()).pw_gecos
    assert user_facts['user_dir'] == pwd.getpwuid(os.getuid()).pw_dir
    assert user_facts['user_shell'] == pwd.getpwuid(os.getuid()).pw_shell

# Generated at 2022-06-11 05:25:15.882475
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
  import platform, os
  from ansible.module_utils._text import to_bytes
  
  # prepare the inputs
  tmp_dir = '/tmp/ansible_test_module_utils_facts_user'
  tmp_file = tmp_dir + '/UserFactCollector.py'
  try:
    os.makedirs(tmp_dir)
  except:
    pass
  fd = open(tmp_file, 'w')

# Generated at 2022-06-11 05:25:25.094096
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ans_result = UserFactCollector().collect()
    assert ans_result['user_id'] == getpass.getuser()
    assert ans_result['user_uid'] == pwd.getpwuid(os.getuid()).pw_uid
    assert ans_result['user_gid'] == pwd.getpwuid(os.getuid()).pw_gid
    assert ans_result['user_gecos'] == pwd.getpwuid(os.getuid()).pw_gecos
    assert ans_result['user_dir'] == pwd.getpwuid(os.getuid()).pw_dir
    assert ans_result['user_shell'] == pwd.getpwuid(os.getuid()).pw_shell
    assert ans_result['real_user_id'] == os

# Generated at 2022-06-11 05:25:43.489947
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    real_user_id = os.getuid()

    collected_facts = UserFactCollector().collect()

    assert real_user_id == collected_facts['real_user_id']
    assert real_user_id == collected_facts['effective_user_id']
    assert '' != collected_facts['user_dir']


# Generated at 2022-06-11 05:25:51.105520
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collector = UserFactCollector()
    user_facts = collector.collect()

    assert user_facts['user_id']
    assert user_facts['user_uid']
    assert user_facts['user_gid']
    assert user_facts['user_gecos']
    assert user_facts['user_dir']
    assert user_facts['user_shell']
    assert user_facts['real_user_id']
    assert user_facts['effective_user_id']
    assert user_facts['real_group_id']
    assert user_facts['effective_group_id']

# Generated at 2022-06-11 05:25:58.104941
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    with open('tests/unit/output/UserFactCollector_collect.txt') as test_input:
        with open('tests/unit/output/UserFactCollector_collect.ansible_facts') as test_output:
            user_fact_collector = UserFactCollector()
            result = user_fact_collector.collect()
            print('\n===TEST===\n')
            print(result)
            print('\n===OUTPUT===\n')
            print(test_input.read())
            print('\n===ANSIBLE_FACTS===\n')
            print(test_output.read())
            print('\n===END===\n')
            assert result == json.loads(test_output.read())

# Generated at 2022-06-11 05:26:08.091907
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Create instance
    ufc = UserFactCollector()

    # Collect facts
    result = ufc.collect()

    # Check result
    assert 'user_id' in result
    assert isinstance(result['user_id'], str)
    assert 'user_uid' in result
    assert isinstance(result['user_uid'], int)
    assert 'user_gid' in result
    assert isinstance(result['user_gid'], int)
    assert 'user_gecos' in result
    assert isinstance(result['user_gecos'], str)
    assert 'user_dir' in result
    assert isinstance(result['user_dir'], str)
    assert 'user_shell' in result
    assert isinstance(result['user_shell'], str)
    assert 'real_user_id' in result

# Generated at 2022-06-11 05:26:17.238223
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    module = None
    collected_facts = None

    user_facts = UserFactCollector().collect(module, collected_facts)

    assert user_facts is not None
    assert isinstance(user_facts, dict)
    assert isinstance(user_facts['user_id'], str)
    assert isinstance(user_facts['user_uid'], int)
    assert isinstance(user_facts['user_gid'], int)
    assert isinstance(user_facts['user_gecos'], str)
    assert isinstance(user_facts['user_dir'], str)
    assert isinstance(user_facts['user_shell'], str)
    assert isinstance(user_facts['real_user_id'], int)
    assert isinstance(user_facts['effective_user_id'], int)

# Generated at 2022-06-11 05:26:26.568423
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector

    loader = FakeLoader()
    collector = Collector(loader, module=None)

    ufc = UserFactCollector(collector, loader)

    # Unit test for method collect of class UserFactCollector
    def test_collect(self, module=None, collected_facts=None):
        user_facts = {}

        user_facts['user_id'] = getpass.getuser()

        try:
            pwent = pwd.getpwnam(getpass.getuser())
        except KeyError:
            pwent = pwd.getpwuid(os.getuid())

        user_facts['user_uid'] = pwent.pw_uid
        user_facts['user_gid'] = pwent.pw_gid

# Generated at 2022-06-11 05:26:35.803765
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    mod = UserFactCollector()

# Generated at 2022-06-11 05:26:38.191430
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    a = UserFactCollector()
    res = a.collect()
    assert isinstance(res, dict)
    assert 'user_id' in res


# Generated at 2022-06-11 05:26:40.943000
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    """
    Return fact user data from fact collector
    """
    fake_module = "no"
    fact_collector = UserFactCollector()
    fact_collector.collect(fake_module)

# Generated at 2022-06-11 05:26:51.737104
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    usr = UserFactCollector()
    usr_facts = usr.collect()
    assert usr_facts['user_id'] == getpass.getuser()
    assert usr_facts['user_uid'] == pwd.getpwuid(os.getuid()).pw_uid
    assert usr_facts['user_gid'] == pwd.getpwgid(os.getgid()).pw_gid
    assert usr_facts['user_gecos'] == pwd.getpwuid(os.getuid()).pw_gecos
    assert usr_facts['user_dir'] == pwd.getpwuid(os.getuid()).pw_dir
    assert usr_facts['user_shell'] == pwd.getpwuid(os.getuid()).pw

# Generated at 2022-06-11 05:27:26.036125
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import sys
    from ansible.module_utils.facts import user_collector
    collector = user_collector.UserFactCollector()
    user_facts = collector.collect(sys.modules[__name__])
    if 'user_id' not in user_facts:
        return False
    if 'user_uid' not in user_facts:
        return False
    if 'user_gid' not in user_facts:
        return False
    if 'user_gecos' not in user_facts:
        return False
    if 'user_dir' not in user_facts:
        return False
    if 'user_shell' not in user_facts:
        return False
    if 'real_user_id' not in user_facts:
        return False

# Generated at 2022-06-11 05:27:35.120596
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    usr_fact_collector = UserFactCollector()
    usr_facts = usr_fact_collector.collect()


# Generated at 2022-06-11 05:27:43.971994
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts_collector = UserFactCollector()
    user_facts = user_facts_collector.collect()
    assert(user_facts['user_id'] == getpass.getuser())
    assert(user_facts['user_uid'] == pwd.getpwnam(getpass.getuser()).pw_uid)
    assert(user_facts['user_gid'] == pwd.getpwnam(getpass.getuser()).pw_gid)
    assert(user_facts['user_gecos'] == pwd.getpwnam(getpass.getuser()).pw_gecos)
    assert(user_facts['user_dir'] == pwd.getpwnam(getpass.getuser()).pw_dir)

# Generated at 2022-06-11 05:27:50.145516
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    collect_res = user_fact_collector.collect()
    assert collect_res == {'real_group_id': 0, 'real_user_id': 0, 'effective_user_id': 0, 'user_gecos': 'root', 'user_uid': 0, 'user_id': 'root', 'effective_group_ids': [0], 'user_dir': '/root', 'user_gid': 0, 'user_shell': '/bin/bash'}


# Generated at 2022-06-11 05:27:51.782978
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fact_collector = UserFactCollector()
    fact_collector.collect()


# Generated at 2022-06-11 05:28:01.717497
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    l = UserFactCollector()
    fact_ids = l.collect_fact_ids()

    assert l.name == 'user'
    assert fact_ids == {'user_id', 'user_uid', 'user_gid', 'user_gecos',
                        'user_dir', 'user_shell', 'real_user_id',
                        'effective_user_id', 'effective_group_ids'}

# Generated at 2022-06-11 05:28:02.316593
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    pass

# Generated at 2022-06-11 05:28:06.566881
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    facts = ufc.collect()

    assert isinstance(facts, dict), "'facts' is not dictionary"
    for fact in ufc._fact_ids:
        assert fact in facts, "'facts' does not contain user fact '%s'" % fact
        assert isinstance(facts[fact], int), "user fact '%s' is not integer" % fact

# Generated at 2022-06-11 05:28:08.513175
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    # Creating object of class UserFactCollector
    test_obj = UserFactCollector()

    # Testing method collect
    assert test_obj.collect() is not None

# Generated at 2022-06-11 05:28:09.909267
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    UserFactCollector().collect()

# Generated at 2022-06-11 05:29:17.700474
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector().collect()
    assert(user_facts['user_id'])
    assert(user_facts['user_uid'])
    assert(user_facts['user_gid'])
    assert(user_facts['user_gecos'])
    assert(user_facts['user_dir'])
    assert(user_facts['user_shell'])
    assert(user_facts['real_user_id'])
    assert(user_facts['effective_user_id'])
    assert(user_facts['real_group_id'])
    assert(user_facts['effective_group_id'])


# Generated at 2022-06-11 05:29:27.293818
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    collector = UserFactCollector()
    collected_facts = collector.collect(module=None, collected_facts=None)

    assert collected_facts['user_id'] == getpass.getuser()
    assert len(collected_facts['user_id']) > 0

    assert collected_facts['user_uid'] == pwd.getpwnam(getpass.getuser()).pw_uid
    assert len(collected_facts['user_uid']) > 0

    assert collected_facts['user_gid'] == pwd.getpwnam(getpass.getuser()).pw_gid
    assert len(collected_facts['user_gid']) > 0

    assert collected_facts['user_gecos'] == pwd.getpwnam(getpass.getuser()).pw_gecos
    assert len

# Generated at 2022-06-11 05:29:36.635211
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import pytest
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.utils import FactsDict
    from ansible.module_utils.facts.user.user import UserFactCollector

    collector = Collector()
    collector.collectors = [UserFactCollector()]
    result = FactsDict((k, v) for k, v in collector.collect().items() if v is not None)

    assert 'user_id' in result
    assert 'user_uid' in result
    assert 'user_gid' in result
    assert 'user_gecos' in result
    assert 'user_dir' in result
    assert 'user_shell' in result
    assert 'real_user_id' in result
    assert 'effective_user_id' in result

# Generated at 2022-06-11 05:29:37.592176
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collector = UserFactCollector()
    collector.collect()

# Generated at 2022-06-11 05:29:47.572067
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import FactCollector

    # create an instance of Collector
    collector = Collector()

    # create an instance of UserFactCollector and register it with Collector
    fact_collector = UserFactCollector()
    collector.register_collector(fact_collector)

    # create a FactCollector which uses Collector
    fact_collector = FactCollector(collector=collector)

    # collect facts and assert whether the collected facts include user facts
    collected_facts = fact_collector.collect(module=None,
                                             collected_facts=None)
    assert 'user_id' in collected_facts
    assert 'user_uid' in collected_facts
    assert 'user_gid' in collected_facts

# Generated at 2022-06-11 05:29:55.679681
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()
    assert user_facts['user_id'] == 'root'
    assert user_facts['user_uid'] == 0
    assert user_facts['user_gid'] == 0
    assert user_facts['user_gecos'] == 'root'
    assert user_facts['user_dir'] == '/root'
    assert user_facts['user_shell'] == '/bin/bash'
    assert user_facts['real_user_id'] == 0
    assert user_facts['effective_user_id'] == 0
    assert user_facts['real_group_id'] == 0
    assert user_facts['effective_group_id'] == 0

# Generated at 2022-06-11 05:30:05.476127
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user = UserFactCollector()
    user_facts = user.collect()

    assert 'user_id' in user_facts
    assert 'user_uid' in user_facts
    assert 'user_gid' in user_facts
    assert 'user_gecos' in user_facts
    assert 'user_dir' in user_facts
    assert 'user_shell' in user_facts
    assert 'real_user_id' in user_facts
    assert 'effective_user_id' in user_facts
    assert 'real_group_id' in user_facts
    assert 'effective_group_id' in user_facts

    try:
        pwent = pwd.getpwnam(getpass.getuser())
    except KeyError:
        pwent = pwd.getpwuid(os.getuid())

    assert p

# Generated at 2022-06-11 05:30:14.150515
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    import pwd

    #Test data
    pwent = pwd.getpwuid(os.getuid())
    user_id = getpass.getuser()

    #Test method
    userFactCollector = UserFactCollector()
    user_facts = userFactCollector.collect()

    # Assertions
    assert user_facts['user_id'] == user_id
    assert user_facts['user_uid'] == pwent.pw_uid
    assert user_facts['user_gid'] == pwent.pw_gid
    assert user_facts['user_gecos'] == pwent.pw_gecos
    assert user_facts['user_dir'] == pwent.pw_dir
    assert user_facts['user_shell'] == pwent.pw_shell

# Generated at 2022-06-11 05:30:17.975267
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector().collect()
    for fact in ['user_id', 'user_uid', 'user_gid',
                 'user_gecos', 'user_dir', 'user_shell',
                 'real_user_id', 'effective_user_id',
                 'real_group_id', 'effective_group_id']:
        assert fact in user_facts

# Generated at 2022-06-11 05:30:24.410357
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collector = UserFactCollector()
    module = None
    collected_facts = None
    assert collector.collect(module, collected_facts) == {'effective_group_id': 1879, 'effective_user_id': 1879, 'real_group_id': 1879, 'real_user_id': 1879, 'user_dir': '/home/smattoo', 'user_gid': 1879, 'user_gecos': 'Someshwar Mattoo,,,', 'user_id': 'smattoo', 'user_shell': '/bin/bash', 'user_uid': 1879}