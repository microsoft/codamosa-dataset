

# Generated at 2022-06-11 05:20:54.199212
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import subprocess

    test_user = None
    with open("/etc/passwd", "r") as f:
        for line in f.readlines():
            if line.startswith("ansible"):
                test_user = line.split(":")[0]
                break
    if test_user is None:
        raise Exception("no user 'ansible' on this system, cannot run tests.")

    test_gid = None
    with open("/etc/group", "r") as f:
        for line in f.readlines():
            if line.startswith("ansible"):
                test_gid = line.split(":")[2]
                break
    if test_gid is None:
        raise Exception("no group 'ansible' on this system, cannot run tests.")

    p = subprocess.Popen

# Generated at 2022-06-11 05:20:55.188416
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    test = UserFactCollector()
    assert test

# Generated at 2022-06-11 05:21:02.770752
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fact = UserFactCollector()

# Generated at 2022-06-11 05:21:09.551199
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector().collect()

    assert user_facts['user_id']
    assert user_facts['user_uid']
    assert user_facts['user_gid']
    assert user_facts['user_gecos']
    assert user_facts['user_dir']
    assert user_facts['user_shell']
    assert user_facts['real_user_id']
    assert user_facts['effective_user_id']
    assert user_facts['real_group_id']
    assert user_facts['effective_group_id']

# Generated at 2022-06-11 05:21:16.265036
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts_collector = UserFactCollector()
    user_facts = user_facts_collector.collect()
    assert(user_facts.get('user_id') is not None)
    assert(user_facts.get('user_uid') is not None)
    assert(user_facts.get('user_gid') is not None)
    assert(user_facts.get('user_gecos') is not None)
    assert(user_facts.get('user_dir') is not None)
    assert(user_facts.get('user_shell') is not None)
    asser

# Generated at 2022-06-11 05:21:18.349870
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fact_collector = UserFactCollector()
    fact_collector.collect()

    assert fact_collector.name == 'user'

# Generated at 2022-06-11 05:21:24.379417
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    try:
        from ansible.module_utils.facts import collector
    except:
        import ansible.module_utils.facts.collector as collector
    ufc = UserFactCollector()
    assert ufc is not None
    facts = ufc.collect()
    assert facts is not None
    assert len(facts) > 0
    assert type(facts) == dict
    


# Generated at 2022-06-11 05:21:30.298319
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    collector = UserFactCollector()

    # Test with no facts
    collected_facts = {}
    facts = collector.collect(collected_facts=collected_facts)
    assert len(facts) == 7

    # Test with facts supplied
    collected_facts = {'test': 'value'}
    facts = collector.collect(collected_facts=collected_facts)
    assert len(facts) == 7

# Generated at 2022-06-11 05:21:32.481988
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts_collector = UserFactCollector()
    user_facts = user_facts_collector.collect()
    assert isinstance(user_facts, dict)



# Generated at 2022-06-11 05:21:34.911256
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()
    assert user_facts['user_id'] == getpass.getuser()

# Generated at 2022-06-11 05:21:39.478483
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fact_collector = UserFactCollector()
    fact_collector.collect()

# Generated at 2022-06-11 05:21:47.277503
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    userFactCollector = UserFactCollector()
    assert userFactCollector.collect() == {'user_shell': '/bin/bash', 'user_gid': 1000, 'user_gecos': 'Llllllllllllllllllllllllllllllllllllllllllllllllllllllll,Ll,Llllllllll', 'user_id': 'ec2-user', 'effective_user_id': 1000, 'user_dir': '/home/ec2-user', 'effective_group_id': 1000, 'real_user_id': 1000, 'user_uid': 1000}

# Generated at 2022-06-11 05:21:50.957706
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # This method tests the code of method collect
    # Isolating the code to be tested
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()
    # Testing
    assert type(user_facts) is dict
    # Testing the return of method collect
    user_fact_ids = set(['user_id', 'user_uid', 'user_gid',
                         'user_gecos', 'user_dir', 'user_shell',
                         'real_user_id', 'effective_user_id',
                         'real_group_id', 'effective_group_id'])
    assert set(user_facts.keys()) == user_fact_ids

# Generated at 2022-06-11 05:21:59.800879
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    user_facts = ufc.collect()

    # test a few known values
    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['user_gid'] == pwd.getpwnam(getpass.getuser()).pw_gid
    assert user_facts['user_uid'] == pwd.getpwnam(getpass.getuser()).pw_uid
    # test for a few different values
    assert user_facts['user_id'] != pwd.getpwnam(getpass.getuser()).pw_uid
    assert user_facts['user_uid'] != pwd.getpwnam(getpass.getuser()).pw_gid

# Generated at 2022-06-11 05:22:11.195122
# Unit test for method collect of class UserFactCollector

# Generated at 2022-06-11 05:22:21.653026
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import sys
    import __builtin__
    import socket

    # This method uses the current user associated with the process. The
    # testing framework executes tests using a dedicated user. The method
    # would fail as the current user is not associated with any entry in
    # /etc/passwd.
    # The workaround is to mock the function getpass.getuser to return the
    # user associated with the first entry in /etc/passwd.

    class MockGetpass:
        @staticmethod
        def getuser():
            return 'root'

    UserFactCollector._old_getpass = getpass.getuser
    getpass.getuser = MockGetpass.getuser

    # Unit test
    my_obj = UserFactCollector()
    my_user_facts = my_obj.collect(module=None, collected_facts=None)
   

# Generated at 2022-06-11 05:22:25.715729
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    test_list = [(0, {'effective_group_id': 0, 'effective_user_id': 0, 'real_group_id': 0, 'real_user_id': 0, 'user_dir': '', 'user_gecos': 'root', 'user_gid': 0, 'user_id': 'root', 'user_shell': '/bin/bash', 'user_uid': 0})]

    user_fc = UserFactCollector()
    for test_input, expected_result in test_list:
        assert user_fc.collect() == expected_result

# Generated at 2022-06-11 05:22:33.617918
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    test_facts = {'effective_user_id': 1000,
                  'effective_group_id': 1000,
                  'real_user_id': 1000,
                  'real_group_id': 1000,
                  'user_dir': '/home/ansible',
                  'user_gid': 1000,
                  'user_gecos': 'ansible',
                  'user_id': 'ansible',
                  'user_shell': '/bin/bash',
                  'user_uid': 1000}
    ufc = UserFactCollector()
    collected_facts = ufc.collect()
    assert collected_facts == test_facts, \
        'UserFactCollector.collect() did not return the ' + \
        'expected fact data'

# Generated at 2022-06-11 05:22:37.106121
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fact_collector_obj = UserFactCollector()
    result = fact_collector_obj.collect()
    assert result['user_id'] == getpass.getuser(), 'Expected user name is not same as actual'


# Generated at 2022-06-11 05:22:45.204756
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fact_collector = UserFactCollector()
    user_facts = fact_collector.collect()
    assert user_facts['user_id']
    assert user_facts['user_uid']
    assert user_facts['user_gid']
    assert user_facts['user_gecos']
    assert user_facts['user_dir']
    assert user_facts['user_shell']
    assert user_facts['real_user_id']
    assert user_facts['effective_user_id']
    assert user_facts['real_group_id']
    assert user_facts['effective_group_id']

# Generated at 2022-06-11 05:22:59.180657
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    ufc._module = None
    ufc._collected_facts = {}

    collected_facts = ufc.collect()

    assert(len(collected_facts) == 8)
    assert(collected_facts.get('user_id') == getpass.getuser())
    assert(collected_facts.get('effective_user_id') == os.geteuid())
    assert(collected_facts.get('real_user_id') == os.getuid())
    assert(collected_facts.get('effective_group_id') == os.getegid())
    assert(collected_facts.get('real_group_id') == os.getgid())

# Generated at 2022-06-11 05:23:00.532862
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    userFactCollector = UserFactCollector()
    userFactCollector.collect()

# Generated at 2022-06-11 05:23:05.562117
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector

    testing_collector = Collector('user', UserFactCollector, {})

    testing_collector.collect()

    assert type(testing_collector.collected_facts) is dict
    assert 'user' in testing_collector.collected_facts
    assert 'real_user_id' in testing_collector.collected_facts['user']

# Generated at 2022-06-11 05:23:11.415720
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collector = UserFactCollector()

    user_facts = collector.collect()

    assert user_facts['user_id'] == getpass.getuser()
    assert type(user_facts['user_uid']) == int and user_facts['user_uid'] > 0
    assert type(user_facts['user_gid']) == int and user_facts['user_gid'] > 0
    assert type(user_facts['user_dir']) == str

# Generated at 2022-06-11 05:23:12.387212
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    assert UserFactCollector.collect() != None

# Generated at 2022-06-11 05:23:21.649354
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    facts = ufc.collect()
    print(facts)
    assert facts['user_id'] == getpass.getuser()
    assert facts['user_uid'] == pwd.getpwnam(getpass.getuser()).pw_uid
    assert facts['user_gid'] == pwd.getpwnam(getpass.getuser()).pw_gid
    assert facts['user_gecos'] == pwd.getpwnam(getpass.getuser()).pw_gecos
    assert facts['user_dir'] == pwd.getpwnam(getpass.getuser()).pw_dir
    assert facts['user_shell'] == pwd.getpwnam(getpass.getuser()).pw_shell

# Generated at 2022-06-11 05:23:31.556295
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    """
    Return collected facts.

    Return a hash of the collected facts.
    """
    user_facts = UserFactCollector()
    collected_facts = user_facts.collect()
    assert collected_facts == {
        'user_id': 'test',
        'user_uid': 1001,
        'user_gid': 1001,
        'user_gecos': 'test,,,',
        'user_dir': '/home/test',
        'user_shell': '/bin/bash',
        'real_user_id': 1001,
        'effective_user_id': 1001,
        'real_group_id': 1001,
        'effective_group_id': 1001,
    }

# Generated at 2022-06-11 05:23:40.624938
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collector = UserFactCollector()
    result = collector.collect()
    assert 'user_id' in result
    assert result['user_id'] == getpass.getuser()
    assert 'user_uid' in result
    assert 'user_gid' in result
    assert 'user_gecos' in result
    assert 'user_dir' in result
    assert 'user_shell' in result
    assert 'real_user_id' in result
    assert result['real_user_id'] == os.getuid()
    assert 'effective_user_id' in result
    assert result['effective_user_id'] == os.geteuid()
    assert 'real_group_id' in result
    assert result['real_group_id'] == os.getgid()
    assert 'effective_group_id' in result
    assert result

# Generated at 2022-06-11 05:23:46.985301
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_dict = {}
    user_dict_keys = ['user_id','user_uid','user_gid','user_gecos','user_dir','user_shell','real_user_id','effective_user_id','real_group_id','effective_group_id']
    user_dict = UserFactCollector().collect()
    assert set(user_dict_keys).issubset(user_dict)

#Unit test for method _fact_ids of class UserFactCollector

# Generated at 2022-06-11 05:23:52.470960
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    test_obj = UserFactCollector()
    expected_result = {'user_uid': 1000, 'user_id': 'user', 'effective_group_ids': [1000],
                       'user_dir': '/home/user', 'real_user_id': 1000, 'user_gid': 1000,
                       'effective_user_id': 1000, 'user_gecos': 'User,,,',
                       'real_group_id': 1000, 'user_shell': '/bin/bash'}
    assert test_obj.collect() == expected_result

# Generated at 2022-06-11 05:24:12.357737
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fc = UserFactCollector()
    res = fc.collect()
    assert 'user_id' in res
    assert 'user_uid' in res
    assert 'user_gid' in res
    assert 'user_gecos' in res
    assert 'user_dir' in res
    assert 'user_shell' in res
    assert 'real_user_id' in res
    assert 'real_group_id' in res
    assert 'effective_user_id' in res
    assert 'effective_group_id' in res

# Generated at 2022-06-11 05:24:18.566829
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    module = AnsibleModule(
        argument_spec=dict(
        )
    )

    result = UserFactCollector().collect(module=module)
    assert (result['user_id'] == 'ansible')
    assert (result['user_uid'] == 1000)
    assert (result['real_user_id'] == 1000)
    assert (result['effective_user_id'] == 1000)
    assert (result['real_group_id'] == 1000)
    assert (result['effective_group_id'] == 1000)

# Generated at 2022-06-11 05:24:26.557633
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector().collect()
    assert user_facts['user_id'] == 'root'
    assert user_facts['user_uid'] == 0
    assert user_facts['user_gid'] == 0
    assert user_facts['user_gecos'] == 'root'
    assert user_facts['user_dir'] == '/root'
    assert user_facts['user_shell'] == '/bin/bash'
    assert user_facts['real_user_id'] == 0
    assert user_facts['effective_user_id'] == 0
    assert user_facts['real_group_id'] == 0
    assert user_facts['effective_group_id'] == 0

# Generated at 2022-06-11 05:24:36.407622
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fake_module = object()
    fake_facts = object()
    facts_collector = UserFactCollector()

    # Run test
    result = facts_collector.collect(fake_module, fake_facts)

    assert isinstance(result, dict)
    assert 'user_id' in result
    assert 'user_uid' in result
    assert 'user_gid' in result
    assert 'user_gecos' in result
    assert 'user_dir' in result
    assert 'user_shell' in result
    assert 'real_user_id' in result
    assert 'effective_user_id' in result
    assert 'real_group_id' in result
    assert 'effective_group_id' in result

# Generated at 2022-06-11 05:24:42.715708
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fact_collector = UserFactCollector()
    ansible_facts = fact_collector.collect()
    fact = 'user_id'
    value = ansible_facts[fact]
    user = getpass.getuser()
    assert value == user

    fact = 'effective_user_id'
    value = ansible_facts[fact]
    assert value == os.geteuid()

    fact = 'real_user_id'
    value = ansible_facts[fact]
    assert value == os.getuid()

    fact = 'user_gid'
    value = ansible_facts[fact]
    try:
        pwent = pwd.getpwnam(getpass.getuser())
    except KeyError:
        pwent = pwd.getpwuid(os.getuid())

# Generated at 2022-06-11 05:24:43.082848
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    pass

# Generated at 2022-06-11 05:24:45.568394
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    f = UserFactCollector()
    ret = f.collect()
    assert ret['user_id'] == getpass.getuser()

    ret = f.collect({'ansible_user_id': 'common'})
    assert ret['user_id'] == 'common'

# Generated at 2022-06-11 05:24:56.314713
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    #
    #  Testing UserFactCollector.collect()
    #
    try:
        #
        #  Testing UserFactCollector.collect() method with default arguments
        #
        user_fact_collector = UserFactCollector()
        result = user_fact_collector.collect()

        assert 'user_id' in result
        assert result['user_id'] == getpass.getuser()
        #
        #  Testing UserFactCollector.collect() method with args
        #
        module = None
        collected_facts = None
        result = user_fact_collector.collect(module, collected_facts)
        assert 'user_id' in result
        assert result['user_id'] == getpass.getuser()
    except Exception as err:
        assert False, "Caught exception: {0}".format(err)

# Generated at 2022-06-11 05:24:57.483114
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    assert isinstance(ufc.collect(), dict)

# Generated at 2022-06-11 05:25:06.660555
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    real_user_id = os.getuid()
    effective_user_id = os.geteuid()
    real_group_id = os.getgid()
    effective_group_id = os.getegid()
    user_id = getpass.getuser()
    user_gid = None
    user_gecos = None
    user_dir = None
    user_shell = None
    user_uid = None
    try:
        pwent = pwd.getpwnam(getpass.getuser())
    except KeyError:
        pwent = pwd.getpwuid(os.getuid())
    user_uid = pwent.pw_uid
    user_gid = pwent.pw_gid
    user_gecos = pwent.pw_gecos

# Generated at 2022-06-11 05:25:29.555002
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import pytest
    from ansible.module_utils.facts.collector.user import UserFactCollector as TU
    t = TU()
    res = t.collect()
    real_user_id = res.get('real_user_id')
    assert type(real_user_id) is int
    assert real_user_id > -1
    real_group_id = res.get('real_group_id')
    assert type(real_group_id) is int
    assert real_group_id > -1
    effective_user_id = res.get('effective_user_id')
    assert type(effective_user_id) is int
    assert effective_user_id > -1
    effective_group_id = res.get('effective_group_id')

# Generated at 2022-06-11 05:25:37.625492
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_collector = UserFactCollector()

    res = user_collector.collect()

    assert res['user_id'] == 'root'
    assert res['user_uid'] == 0
    assert res['user_gid'] == 0
    assert res['user_gecos'] == 'root'
    assert res['user_dir'] == '/root'
    assert res['user_shell'] == '/bin/bash'
    assert res['real_user_id'] == 0
    assert res['effective_user_id'] == 0
    assert res['real_group_id'] == 0
    assert res['effective_group_id'] == 0

# Generated at 2022-06-11 05:25:48.383332
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    def mock_getuser():
        return 'foobar'

    def mock_getpwnam():
        pwent = pwd.struct_passwd(('root', 'x', 0, 0, '', '', '/root'))
        return pwent

    def mock_getpwuid():
        pwent = pwd.struct_passwd(('root', 'x', 0, 0, '', '', '/root'))
        return pwent

    def mock_getuid():
        return 0

    def mock_geteuid():
        return 0

    def mock_getgid():
        return 0

    user_facts = {}
    module_mock = {}
    collected_facts_mock = {}
    ufc = UserFactCollector()

    # Restore original implementation
    UserFactCollector.getuser = getpass.get

# Generated at 2022-06-11 05:25:52.363910
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Get the UserFactCollector instance
    user_fact_collector = UserFactCollector()

    # Get the user facts
    user_facts = user_fact_collector.collect()

    # Check if the user_id fact is present
    assert 'user_id' in user_facts


# Generated at 2022-06-11 05:25:57.391056
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    res = ufc.collect()
    assert res['user_id'] == getpass.getuser()
    assert res['user_shell'] == '/bin/bash'
    assert res['real_user_id'] == os.getuid()
    assert res['effective_user_id'] == os.geteuid()
    assert res['real_group_id'] == os.getgid()
    assert res['effective_group_id'] == os.getgid()



# Generated at 2022-06-11 05:25:57.903105
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    pass

# Generated at 2022-06-11 05:26:06.366589
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collector = UserFactCollector()
    assert collector.collect() is not None, "UserFactCollector collect method returns none"

    # Check the keys returned by user collector
    keys = collector.collect().keys()
    assert len(keys) == 9, "UserFactCollector collect method returns incorrect number of keys"
    assert 'user_id' in keys and 'user_uid' in keys and 'user_gid' in keys and 'user_gecos' in keys \
    and 'user_dir' in keys and 'user_shell' in keys and 'real_user_id' in keys \
    and 'effective_user_id' in keys and 'effective_group_ids' in keys

# Generated at 2022-06-11 05:26:15.677409
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import json

    testing = UserFactCollector()

    # Testing with a "good" user (i.e. one that is in the passwd db)
    good_user_facts = testing.collect()
    with open('/tmp/test_ansible_fact_user_good.json', 'w') as f:
        f.write(json.dumps(good_user_facts, sort_keys=True, indent=4, separators=(',', ': ')))

    # Testing with a "bad" user (i.e. one that is not in the passwd db)
    os.setuid(1234567)
    bad_user_facts = testing.collect()

# Generated at 2022-06-11 05:26:25.019508
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fact_collector = UserFactCollector()
    fact = fact_collector.collect()
    assert fact['user_id'] == getpass.getuser()
    assert fact['effective_user_id'] == os.geteuid()
    assert fact['effective_group_id'] == os.getgid()
    assert fact['user_uid'] == pwd.getpwnam(getpass.getuser()).pw_uid
    assert fact['user_gid'] == pwd.getpwnam(getpass.getuser()).pw_gid
    assert fact['user_gecos'] == pwd.getpwnam(getpass.getuser()).pw_gecos
    assert fact['user_dir'] == pwd.getpwnam(getpass.getuser()).pw_dir
    assert  fact

# Generated at 2022-06-11 05:26:32.047225
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector().collect()
    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['user_uid'] == os.getuid()
    assert user_facts['user_gid'] == os.getgid()
    assert isinstance(user_facts['user_gecos'], str)
    assert user_facts['user_gecos']
    assert user_facts['user_dir'] == os.path.expanduser('~')
    assert user_facts['user_shell']
    assert user_facts['real_user_id'] == os.getuid()
    assert user_facts['effective_user_id'] == os.geteuid()
    assert user_facts['real_group_id'] == os.getgid()

# Generated at 2022-06-11 05:27:07.603003
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    test_UserFactCollector = UserFactCollector()
    user_facts = test_UserFactCollector.collect()
    assert user_facts['real_user_id'] == os.getuid()
    assert user_facts['effective_user_id'] == os.geteuid()
    assert user_facts['real_group_id'] == os.getgid()
    assert user_facts['effective_group_id'] == os.getgid()
    assert user_facts['user_id'] == getpass.getuser()
    try:
        pwent = pwd.getpwnam(getpass.getuser())
    except KeyError:
        pwent = pwd.getpwuid(os.getuid())
    assert user_facts['user_uid'] == pwent.pw_uid

# Generated at 2022-06-11 05:27:16.711451
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import sys
    import platform
    import socket
    import os
    import getpass
    import pwd
    import grp

    user_collector = UserFactCollector()

    # Check default values for user_facts
    user_facts = user_collector.collect()
    if platform.system() == 'AIX':
        group_list = user_facts['real_group_ids']
    else:
        group_list = user_facts['effective_group_ids']

    assert user_facts['real_user_id'] == os.getuid()
    assert user_facts['effective_user_id'] == os.geteuid()
    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['user_uid'] == pwd.getpwuid(os.getuid()).pw_

# Generated at 2022-06-11 05:27:19.077232
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector()
    user_facts_collected = user_facts.collect()
    assert(user_facts_collected)

# Generated at 2022-06-11 05:27:20.770637
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user = UserFactCollector()
    result = user.collect()
    assert result


# Generated at 2022-06-11 05:27:26.963156
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.user import UserFactCollector

    user = UserFactCollector()

    # Test collect with module and collected_facts parameters.
    # We assume that the properties are not empty.
    # We check that the properties are not empty.
    # We assume that they not depend on the run time environment (no mocking).
    assert hasattr(user, 'name') and user.name
    assert hasattr(user, '_fact_ids') and user._fact_ids

    user_facts = user.collect()
    assert hasattr(user_facts, '__iter__')
    assert user_facts

    # Test collect without module and collected_facts parameters.
    # We assume that the properties are not empty.
    # We check that

# Generated at 2022-06-11 05:27:36.235094
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    """Test the UserFactCollector.collect method with an empty results"""
    # create a UserFactCollector
    factCollector = UserFactCollector()
    # create an empty result
    result = {}

    # call the collect method
    result = factCollector.collect(collected_facts=result)

    # Assert the keys that should be present in the result
    for key in factCollector._fact_ids:
        assert key in result
    # Assert the values of some of the keys
    assert type(result['user_id']) is str
    assert type(result['user_uid']) is int
    assert type(result['user_gid']) is int
    assert type(result['user_gecos']) is str
    assert type(result['user_dir']) is str

# Generated at 2022-06-11 05:27:45.107958
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    fact_module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True)

    fact = UserFactCollector()

    result = fact.collect(module=fact_module)

    assert 'user_id' in result
    assert result['user_id'] == getpass.getuser()

    assert 'user_uid' in result
    assert result['user_uid'] == pwd.getpwuid(os.getuid())[2]

    assert 'user_gid' in result
    assert result['user_gid'] == pwd.getpwuid(os.getuid())[3]

    assert 'user_gecos' in result
    assert result['user_gecos'] == pwd.getpwuid(os.getuid())[4]

    assert 'user_dir' in result


# Generated at 2022-06-11 05:27:54.188838
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    mock_module = object()
    mock_collected_facts = {}
    test_obj = UserFactCollector()

    result = test_obj.collect(mock_module, mock_collected_facts)
    assert isinstance(result, dict)
    assert result.get('effective_user_id') is not None
    assert result.get('real_user_id') is not None
    assert result.get('real_group_id') is not None
    assert result.get('effective_group_id') is not None
    assert result.get('user_id') is not None
    assert result.get('user_uid') is not None
    assert result.get('user_dir') is not None
    assert result.get('user_shell') is not None
    assert result.get('user_gecos') is not None
    assert result

# Generated at 2022-06-11 05:27:54.805682
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    pass

# Generated at 2022-06-11 05:28:04.631771
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import tempfile
    tmp_dir = tempfile.mkdtemp()
    os.environ['HOME'] = tmp_dir

# Generated at 2022-06-11 05:29:05.561266
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    pass

# Generated at 2022-06-11 05:29:14.643329
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    userFactCollector = UserFactCollector()
    user_facts = userFactCollector.collect()

    assert user_facts['user_id'] == getpass.getuser()
    assert isinstance(user_facts['user_uid'], int)
    assert isinstance(user_facts['user_gid'], int)
    assert isinstance(user_facts['user_gecos'], str)
    assert isinstance(user_facts['user_dir'], str)
    assert isinstance(user_facts['user_shell'], str)
    assert isinstance(user_facts['real_user_id'], int)
    assert isinstance(user_facts['effective_user_id'], int)
    assert isinstance(user_facts['real_group_id'], int)

# Generated at 2022-06-11 05:29:24.107250
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    uid = 'test'
    real_uid = 300
    gid = 'test'
    real_gid = 300
    u = UserFactCollector()
    pwd.getpwnam = lambda x: pwd.struct_passwd((uid, gid, real_uid, real_gid, 'T.Tester', '/home/test', '/bin/test'))
    getpass.getuser = lambda : uid
    os.getuid = lambda : real_uid
    os.getgid = lambda : real_gid
    os.geteuid = lambda : real_uid
    os.getegid = lambda : real_gid


# Generated at 2022-06-11 05:29:24.975846
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    pass


# Generated at 2022-06-11 05:29:33.312430
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector().collect()
    assert 'user_id' in user_facts.keys()
    assert 'user_uid' in user_facts.keys()
    assert 'user_gid' in user_facts.keys()
    assert 'user_gecos' in user_facts.keys()
    assert 'user_dir' in user_facts.keys()
    assert 'user_shell' in user_facts.keys()
    assert 'real_user_id' in user_facts.keys()
    assert 'effective_user_id' in user_facts.keys()
    assert 'real_group_id' in user_facts.keys()
    assert 'effective_group_id' in user_facts.keys()

# Generated at 2022-06-11 05:29:38.252548
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector, CollectionError
    import os
    import platform
    import collections

    current_platform = platform.system().lower()
    if current_platform == 'darwin':
        import pwd  # pwd module is not available in windows
        userid = pwd.getpwuid(os.getuid())[0]
    else:
        userid = os.getenv('LOGNAME')

# Generated at 2022-06-11 05:29:40.889915
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Initialize the instance
    userFactCollector = UserFactCollector()

    # Gather facts
    userFactCollector.collect()


# Generated at 2022-06-11 05:29:41.587623
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    pass

# Generated at 2022-06-11 05:29:46.193965
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    # Create UserFactCollector object
    # Constraint: Cannot use UserFactCollector(module) in real test
    #             because ansible.module_utils.facts.collector.BaseFactCollector is an abstract class
    user_fact_collector = UserFactCollector()
    user_fact_collector.collect(module=None, collected_facts=None)

# Generated at 2022-06-11 05:29:49.012840
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector()
    assert user_facts.collected_facts is not None
    assert user_facts.collected_facts.get('user_id') == getpass.getuser()
