

# Generated at 2022-06-11 05:20:53.417239
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector().collect()
    assert user_facts['user_id'] == getpass.getuser()
    assert isinstance(user_facts['user_uid'], int)
    assert isinstance(user_facts['user_gid'], int)
    assert isinstance(user_facts['user_gecos'], str)
    assert isinstance(user_facts['user_dir'], str)
    assert isinstance(user_facts['user_shell'], str)

# Generated at 2022-06-11 05:21:04.279254
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import ansible.module_utils.facts.collector

    # Create an object of class UserFactCollector
    user_facts = ansible.module_utils.facts.collector.UserFactCollector()

    # Call the method collect of Class UserFactCollector
    user_facts_dict = user_facts.collect()

    # Check if the fields user_id, user_uid, user_gid, user_gecos, user_dir,
    # user_shell, real_user_id, effective_user_id, effective_group_ids
    # are added to user_facts_dict
    assert user_facts_dict.has_key('user_id')
    assert user_facts_dict.has_key('user_uid')
    assert user_facts_dict.has_key('user_gid')
    assert user_facts_dict

# Generated at 2022-06-11 05:21:14.117621
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import os
    import pwd
    user = pwd.getpwuid(os.getuid())
    ufc = UserFactCollector()
    retrieved_facts = ufc.collect()
    assert retrieved_facts['user_id'] == user.pw_name
    assert retrieved_facts['user_uid'] == user.pw_uid
    assert retrieved_facts['user_gid'] == user.pw_gid
    assert retrieved_facts['user_gecos'] == user.pw_gecos
    assert retrieved_facts['user_dir'] == user.pw_dir
    assert retrieved_facts['user_shell'] == user.pw_shell
    assert retrieved_facts['real_user_id'] == os.getuid()
    assert retrieved_facts['effective_user_id'] == os.geteuid()
   

# Generated at 2022-06-11 05:21:24.275595
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect(module=None, collected_facts=None)
    #print(user_facts)
    assert ('user_id' in user_facts)
    assert ('user_uid' in user_facts)
    assert ('user_gid' in user_facts)
    assert ('user_gecos' in user_facts)
    assert ('user_dir' in user_facts)
    assert ('user_shell' in user_facts)
    assert ('real_user_id' in user_facts)
    assert ('effective_user_id' in user_facts)
    assert ('real_group_id' in user_facts)
    assert ('effective_group_id' in user_facts)

test_UserFactCollector_collect()

# Generated at 2022-06-11 05:21:28.948366
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    u_fc = UserFactCollector()
    collected_facts = {}

    # getuser() and getpass() should return the same user id
    assert u_fc.collect()['user_id'] == getpass.getuser(), \
        'User return by getuser() and getpass() are not the same'

# Generated at 2022-06-11 05:21:35.810988
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collector = UserFactCollector()

    facts = {
        'user_id': 'vagrant',
        'user_uid': 1000,
        'user_gid': 1000,
        'user_gecos': 'Vagrant User,,,',
        'user_dir': '/home/vagrant',
        'user_shell': '/bin/bash',
        'real_user_id': 1000,
        'effective_user_id': 1000,
        'real_group_id': 1000,
        'effective_group_id': 1000
    }

    collected_facts = collector.collect()

    for f in facts:
        assert collected_facts[f] == facts[f]

# Generated at 2022-06-11 05:21:44.744219
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fact_collector = UserFactCollector()
    result = fact_collector.collect()

    # make sure the user_id from getpwnam(getuser()) matches
    # the user_id from getuser() (should be the same for the
    # current user)
    assert result['user_id'] == result['effective_user_id']
    # make sure the real user id matches the effective user id
    # (should be the same)
    assert result['real_user_id'] == result['effective_user_id']
    # make sure the real group id matches the effective group id
    # (should be the same)
    assert result['real_group_id'] == result['effective_group_id']

# Generated at 2022-06-11 05:21:55.753133
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collector = UserFactCollector()

    ret = collector.collect()

    assert ret.get('user_id') == getpass.getuser()
    assert ret.get('user_uid') == pwd.getpwuid(os.getuid()).pw_uid
    assert ret.get('user_gid') == pwd.getpwuid(os.getuid()).pw_gid
    assert ret.get('user_dir') == pwd.getpwuid(os.getuid()).pw_dir
    assert ret.get('user_shell') == pwd.getpwuid(os.getuid()).pw_shell
    assert ret.get('real_user_id') == os.getuid()
    assert ret.get('effective_user_id') == os.geteuid()
    assert ret

# Generated at 2022-06-11 05:22:03.397561
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector().collect()

    assert user_facts.get('user_id')==getpass.getuser()
    assert user_facts.get('user_uid') == pwd.getpwnam(getpass.getuser()).pw_uid
    assert user_facts.get('user_gid') == pwd.getpwnam(getpass.getuser()).pw_gid
    assert user_facts.get('user_gecos') == pwd.getpwnam(getpass.getuser()).pw_gecos
    assert user_facts.get('user_dir') == pwd.getpwnam(getpass.getuser()).pw_dir
    assert user_facts.get('user_shell') == pwd.getpwnam(getpass.getuser()).pw

# Generated at 2022-06-11 05:22:07.334401
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    """Unit test for method collect of class UserFactCollector."""
    ufc = UserFactCollector()
    user_facts = ufc.collect()

    assert 'user_id' in user_facts

# Generated at 2022-06-11 05:22:21.189102
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    with open('/proc/self/status') as fobj:
        status_content = fobj.read()

    uid_line = [s for s in status_content.split('\n') if s.startswith('Uid:')][0]
    uid = [s.strip() for s in uid_line.split(':')][1]
    real_uid = uid.split()[0]
    effective_uid = uid.split()[1]
    saved_uid = uid.split()[2]

    gid_line = [s for s in status_content.split('\n') if s.startswith('Gid:')][0]
    gid = [s.strip() for s in gid_line.split(':')][1]
    real_gid = gid.split

# Generated at 2022-06-11 05:22:26.000619
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user = UserFactCollector()
    ansible_facts = user.collect()
    assert 'user_id' in ansible_facts
    assert 'user_uid' in ansible_facts
    assert 'user_gid' in ansible_facts
    assert 'user_gecos' in ansible_facts
    assert 'user_dir' in ansible_facts
    assert 'user_shell' in ansible_facts
    assert 'real_user_id' in ansible_facts
    assert 'effective_user_id' in ansible_facts
    assert 'real_group_id' in ansible_facts
    assert 'effective_group_id' in ansible_facts

# Generated at 2022-06-11 05:22:35.378507
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
	#
	# Unit test for the method collect of class UserFactCollector
	#
	# Input parameter:
	#	- module : the Ansible module object
	#	- collected_facts : the facts collected by Ansible from the current host
	#
	# Output:
	# 	- user_facts : the facts about the current user
	#

	# Dummy value for class attribute 'name'
	UserFactCollector.name = 'user'

	# Dummy values for input parameters
	module = None
	collected_facts = None

	# Dummy value for the associated output
	#user_facts = {'effective_group_id': 0, 'user_id': pwd.getpwuid(os.getuid()).pw_name, 'user_gid': pwd.getpwuid(os.getuid

# Generated at 2022-06-11 05:22:41.820175
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    f = UserFactCollector()
    assert f.collect() == {'real_user_id': 1000, 'effective_user_id': 1000, 'user_gecos': 'Dusan.Bajic,,,', 'user_shell': '/bin/bash', 'user_id': 'dusan', 'real_group_id': 1000, 'user_uid': 1000, 'user_gid': 1000, 'effective_group_id': 1000, 'user_dir': '/home/dusan'}


# Generated at 2022-06-11 05:22:49.224389
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    user_facts = ufc.collect()

    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['real_user_id'] == os.getuid()
    assert user_facts['effective_user_id'] == os.geteuid()
    assert user_facts['real_group_id'] == os.getgid()
    assert user_facts['effective_group_id'] == os.getgid()
    assert isinstance(user_facts['effective_group_ids'], list)

# Generated at 2022-06-11 05:22:51.031413
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    import pwd

    fact = UserFactCollector()

    assert fact.collect()['user_id'] == pwd.getpwuid(os.getuid()).pw_name

# Generated at 2022-06-11 05:22:59.596598
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_id = getpass.getuser()
    user_gid = os.getuid()
    user_uid = os.geteuid()
    user_gecos = pwd.getpwuid(os.getuid())[4]
    user_dir = pwd.getpwuid(os.getuid())[5]
    user_shell = os.getenv('SHELL')

    facts = UserFactCollector().collect()

    assert facts['user_id'] == user_id
    assert facts['user_gid'] == user_gid
    assert facts['user_uid'] == user_uid
    assert facts['user_gecos'] == user_gecos
    assert facts['user_dir'] == user_dir
    assert facts['user_shell'] == user_shell

# Generated at 2022-06-11 05:23:08.902014
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fact_collector = UserFactCollector()
    collected_facts = fact_collector.collect()

    expected_facts = {
        'user_id': getpass.getuser(),
        'user_uid': os.getuid(),
        'user_gid': os.getgid(),
        'user_gecos': 'John Doe',
        'user_dir': '/home/john.doe',
        'user_shell': '/bin/bash',
        'real_user_id': os.getuid(),
        'effective_user_id': os.geteuid(),
        'real_group_id': os.getgid(),
        'effective_group_id': os.getegid()
    }

    assert collected_facts == expected_facts



# Generated at 2022-06-11 05:23:18.173786
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()

    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['user_uid'] == pwd.getpwuid(os.getuid()).pw_uid
    assert user_facts['user_gid'] == pwd.getpwuid(os.getuid()).pw_gid
    assert user_facts['user_gecos'] == pwd.getpwuid(os.getuid()).pw_gecos
    assert user_facts['user_dir'] == pwd.getpwuid(os.getuid()).pw_dir
    assert user_facts['user_shell'] == pwd.getpwuid(os.getuid()).pw_

# Generated at 2022-06-11 05:23:29.279426
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collector = UserFactCollector()
    result = collector.collect()
    assert isinstance(result, dict)
    assert all(key in collector._fact_ids for key in result.keys())
    assert result['user_id'] == getpass.getuser()
    try:
        pwent = pwd.getpwnam(getpass.getuser())
    except KeyError:
        pwent = pwd.getpwuid(os.getuid())
    assert result['user_uid'] == pwent.pw_uid
    assert result['user_gid'] == pwent.pw_gid
    assert result['user_gecos'] == pwent.pw_gecos
    assert result['user_dir'] == pwent.pw_dir
    assert result['user_shell'] == pwent.pw_shell
   

# Generated at 2022-06-11 05:23:38.714690
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collector = UserFactCollector()

    # Call method collect of class UserFactCollector
    output = collector.collect()

    # Check the output for method collect
    assert(output)

# Generated at 2022-06-11 05:23:41.215686
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fact_collector = UserFactCollector()
    fact_collector.collect()
    assert 'user_id' in fact_collector.collect()

# Generated at 2022-06-11 05:23:48.496325
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    """Unit test for method collect of class UserFactCollector"""
    collector = UserFactCollector()
    facts = collector.collect()
    assert 'user_id' in facts
    assert 'user_uid' in facts
    assert 'user_gid' in facts
    assert 'user_gecos' in facts
    assert 'user_dir' in facts
    assert 'user_shell' in facts
    assert 'real_user_id' in facts
    assert 'effective_user_id' in facts
    assert 'real_group_id' in facts
    assert 'effective_group_id' in facts

# Generated at 2022-06-11 05:23:56.774387
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Mocking a user_id and effective_user_id
    def mocked_getuser():
        return 'jdoe'

    def mocked_geteuid():
        return '1234'


    # Mocking method getpwuid
    class MockedPwd:
        class MockedPwd:
            pw_uid = '1234'
            pw_gecos = 'John Doe'
            pw_dir = '/home/jdoe'
            pw_shell = '/bin/bash'
            pw_gid = '1234'
        
        def getpwuid(uid):
            pw = MockedPwd()
            if uid is not None:
                pw.pw_uid = uid
            return pw
    
    # Mocking the getpass module

# Generated at 2022-06-11 05:24:07.595479
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import pytest
    from ansible.module_utils.facts.collector import FactCollector

    my_user_facts = {'effective_group_id': 1000,
                     'effective_group_ids': [1000, 4, 24, 27, 30, 46, 113],
                     'effective_user_id': 1000,
                     'real_group_id': 1000,
                     'real_user_id': 1000,
                     'user_dir': '/home/myuser',
                     'user_gecos': 'My User,,,',
                     'user_gid': 1000,
                     'user_id': 'myuser',
                     'user_shell': '/bin/bash',
                     'user_uid': 1000}

    fact_collector = FactCollector()
    fact_collector._collectors = [UserFactCollector()]
    fact_collect

# Generated at 2022-06-11 05:24:17.849629
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.collectors.user import UserFactCollector

    # Empty arguments
    args = []
    facts_obj = Facts(args)
    user_collector = UserFactCollector(facts_obj)

    # mock getpass.getuser()
    user_collector.getpass.getuser = lambda: 'ansible'

    # pwent for ansible user
    pwent = pwd.struct_passwd(('ansible', 'x', 1000, 2000, 'Ansible User', '/home/ansible', '/bin/bash'))
    user_collector.pwd.getpwnam = lambda x: pwent

    # mock os.getuid()
    user_collector.os.getuid = lambda: 1000

    # mock os.

# Generated at 2022-06-11 05:24:27.572975
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    """ Test collect() method of UserFactCollector class
    """

    # GIVEN: Initialize a UserFactCollector object
    fc = UserFactCollector()

    # WHEN: Call UserFactCollector.collect()
    user_facts = fc.collect()

    # THEN: UserFactCollector should return the user facts
    assert isinstance(user_facts, dict)
    assert 'real_user_id' in user_facts
    assert 'effective_user_id' in user_facts
    assert 'real_group_id' in user_facts
    assert 'effective_group_id' in user_facts
    assert isinstance(user_facts['real_user_id'], int)
    assert isinstance(user_facts['effective_user_id'], int)

# Generated at 2022-06-11 05:24:34.598527
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    from ansible.module_utils.facts import ansible_collections
    from ansible.module_utils.facts.collectors import UserFactCollector
    from ansible.module_utils.facts import ansible_collections
    from ansible.module_utils.facts.collectors import BaseFactCollector

    my_user = UserFactCollector()
    assert issubclass(UserFactCollector, BaseFactCollector)
    assert my_user.name == 'user'
    assert isinstance(my_user.collect(), dict)

# Generated at 2022-06-11 05:24:43.795925
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    from ansible.module_utils.facts import fact_collector

    fact_collector.add_collector(UserFactCollector())
    facts_dict = fact_collector.collect(module=None, collected_facts=None)

    users_facts = facts_dict['ansible_facts']['user']
    assert ('user_id' in users_facts)
    assert ('user_uid' in users_facts)
    assert ('user_gid' in users_facts)
    assert ('user_gecos' in users_facts)
    assert ('user_dir' in users_facts)
    assert ('user_shell' in users_facts)
    assert ('real_user_id' in users_facts)
    assert ('effective_user_id' in users_facts)
    assert ('effective_group_ids' in users_facts)

# Generated at 2022-06-11 05:24:52.067279
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fc = UserFactCollector()
    user_fc_facts = user_fc.collect()

    expected_user_fc_facts = {
        'user_id': getpass.getuser(),
        'user_uid': os.getuid(),
        'user_gid': os.getgid(),
        'user_gecos': os.getgid(),
        'user_dir': '/',
        'user_shell': '/bin/bash'
    }

    assert user_fc_facts == expected_user_fc_facts

# Generated at 2022-06-11 05:25:11.111210
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user = UserFactCollector()
    all_facts = user.collect()
    assert isinstance(all_facts, dict)
    assert all_facts['user_id'] == getpass.getuser()
    assert all_facts['user_uid'] == pwd.getpwuid(os.getuid()).pw_uid
    assert all_facts['user_gid'] == pwd.getpwuid(os.getuid()).pw_gid
    assert all_facts['user_gecos'] == pwd.getpwuid(os.getuid()).pw_gecos
    assert all_facts['user_dir'] == pwd.getpwuid(os.getuid()).pw_dir
    assert all_facts['user_shell'] == pwd.getpwuid(os.getuid()).p

# Generated at 2022-06-11 05:25:12.710172
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fact_collector = UserFactCollector()
    fact_collector.collect()


# Generated at 2022-06-11 05:25:21.350690
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    collector_instance = UserFactCollector()
    fact_data = collector_instance.collect()

    assert fact_data['user_id'] is not None
    assert fact_data['user_uid'] is not None
    assert fact_data['user_gid'] is not None
    assert fact_data['user_gecos'] is not None
    assert fact_data['user_dir'] is not None
    assert fact_data['user_shell'] is not None
    assert fact_data['real_user_id'] is not None
    assert fact_data['effective_user_id'] is not None
    assert fact_data['real_group_id'] is not None
    assert fact_data['effective_group_id'] is not None


# Generated at 2022-06-11 05:25:28.188978
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    print("test_UserFactCollector_collect: testing UserFactCollector.collect()")
    user_fact_collector = UserFactCollector()
    collected_facts = user_fact_collector.collect()
    for fact_id in UserFactCollector._fact_ids:
        assert(fact_id in collected_facts)
        assert(type(collected_facts[fact_id]) is type(collected_facts['real_group_id']))
    print("test_UserFactCollector_collect: facts of type UserFactCollector were collected")

# Generated at 2022-06-11 05:25:30.027445
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector().collect()
    assert user_facts['user_id'] == getpass.getuser()

# Generated at 2022-06-11 05:25:37.291790
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact = UserFactCollector()
    res = user_fact.collect()
    assert "user_id" in res
    assert "user_uid" in res
    assert "user_gid" in res
    assert "user_gecos" in res
    assert "user_dir" in res
    assert "user_shell" in res
    assert "real_user_id" in res
    assert "effective_user_id" in res
    assert "real_group_id" in res
    assert "effective_group_id" in res


# Generated at 2022-06-11 05:25:48.035348
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()

    assert user_facts is not None
    assert type(user_facts) is dict
    assert 'user_id' in user_facts
    assert type(user_facts['user_id']) is str
    assert len(user_facts['user_id']) >= 1
    assert 'user_uid' in user_facts
    assert type(user_facts['user_uid']) is int
    assert user_facts['user_uid'] >= 0
    assert 'user_gid' in user_facts
    assert type(user_facts['user_gid']) is int
    assert user_facts['user_gid'] >= 0
    assert 'user_gecos' in user_facts

# Generated at 2022-06-11 05:25:54.433198
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector().collect()
    assert isinstance(user_facts, dict)
    assert 'user_id' in user_facts
    assert 'user_uid' in user_facts
    assert 'user_gid' in user_facts
    assert 'user_gecos' in user_facts
    assert 'user_dir' in user_facts
    assert 'user_shell' in user_facts
    assert 'real_user_id' in user_facts
    assert 'effective_user_id' in user_facts



# Generated at 2022-06-11 05:26:03.605202
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    facts = ufc.collect()
    # convert string to int
    facts['user_uid'] = int(facts['user_uid'])
    facts['user_gid'] = int(facts['user_gid'])
    facts['real_user_id'] = int(facts['real_user_id'])
    facts['effective_user_id'] = int(facts['effective_user_id'])


# Generated at 2022-06-11 05:26:12.962627
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    class MockModule(object):
        pass

    import os
    user_id = getpass.getuser()
    uid = os.getuid()
    gid = os.getgid()
    try:
        pwent = pwd.getpwnam(user_id)
    except KeyError:
        pwent = pwd.getpwuid(os.getuid())
    user_uid = pwent.pw_uid
    user_gid = pwent.pw_gid
    user_gecos = pwent.pw_gecos
    user_dir = pwent.pw_dir
    user_shell = pwent.pw_shell

    ufc = UserFactCollector()

    collected_facts = {}

    m = MockModule()

# Generated at 2022-06-11 05:26:51.649238
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    from ansible.module_utils._text import to_bytes

    # Test normal use case
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()
    assert 'user_uid' in user_facts
    assert 'user_gid' in user_facts
    assert 'user_gecos' in user_facts
    assert 'user_dir' in user_facts
    assert 'user_shell' in user_facts
    assert 'real_user_id' in user_facts
    assert 'effective_user_id' in user_facts
    assert 'real_group_id' in user_facts
    assert 'effective_group_id' in user_facts

    # Test on empty user_gid
    user_fact_collector = UserFactCollector()
    user_fact_collect

# Generated at 2022-06-11 05:26:58.828424
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    class Module(object):
        pass

    class Facts(object):
        pass

    module = Module()
    facts = Facts()
    up = UserFactCollector()

    # The order of groups elements is system dependent
    collected_facts = {'user_id': 'root', 'user_uid': 0, 'user_gid': 0, 'user_dir': '/root', 'user_shell': '/bin/bash',
                       'real_user_id': 0, 'effective_user_id': 0, 'real_group_id': 0, 'effective_group_id': 0}
    assert up.collect(module, facts) == collected_facts

# Generated at 2022-06-11 05:27:07.603020
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fact_collector = UserFactCollector()
    fact_collector.collect()

    assert fact_collector.has_data()

    user_facts = fact_collector.data
    assert user_facts is not None
    assert type(user_facts) is dict

    assert 'user_id' in user_facts
    assert type(user_facts['user_id']) is str

    assert 'user_uid' in user_facts
    assert type(user_facts['user_uid']) is int

    assert 'user_gid' in user_facts
    assert type(user_facts['user_gid']) is int

    assert 'user_gecos' in user_facts
    assert type(user_facts['user_gecos']) is str

    assert 'user_dir' in user_facts

# Generated at 2022-06-11 05:27:16.712615
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    o = UserFactCollector()
    user_facts = o.collect()

    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['user_uid'] == pwd.getpwuid(os.getuid()).pw_uid
    assert user_facts['user_gid'] == pwd.getpwuid(os.getuid()).pw_gid
    assert user_facts['user_gecos'] == pwd.getpwuid(os.getuid()).pw_gecos
    assert user_facts['user_dir'] == pwd.getpwuid(os.getuid()).pw_dir
    assert user_facts['user_shell'] == pwd.getpwuid(os.getuid()).pw_shell

# Generated at 2022-06-11 05:27:20.229158
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_collector = UserFactCollector()
    user_facts = user_collector.collect()
    assert user_facts['real_user_id'] == os.getuid()
    assert user_facts['effective_group_id'] == os.getgid()

# Generated at 2022-06-11 05:27:26.732551
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    c = UserFactCollector()
    facts = c.collect()

    assert facts['user_id'] == getpass.getuser()
    assert facts['user_uid'] == pwd.getpwuid(os.getuid()).pw_uid
    assert facts['user_gid'] == pwd.getpwuid(os.getuid()).pw_gid
    assert facts['user_gecos'] == pwd.getpwuid(os.getuid()).pw_gecos
    assert facts['user_dir'] == pwd.getpwuid(os.getuid()).pw_dir
    assert facts['user_shell'] == pwd.getpwuid(os.getuid()).pw_shell
    assert facts['real_user_id'] == os.getuid()

# Generated at 2022-06-11 05:27:35.958559
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    from ansible.module_utils.facts import Collector

    output = Collector(UserFactCollector, None).collect()

    assert 'user_id' in output
    assert output['user_id'] == getpass.getuser()

    assert 'user_uid' in output
    assert output['user_uid'] == pwent.pw_uid
    assert type(output['user_uid']) == int

    assert 'user_gid' in output
    assert output['user_gid'] == pwent.pw_gid
    assert type(output['user_uid']) == int

    assert 'user_gecos' in output
    assert output['user_gecos'] == pwent.pw_gecos
    assert type(output['user_gecos']) == str

    assert 'user_dir' in output

# Generated at 2022-06-11 05:27:43.432890
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collector = UserFactCollector()

    # If pwd.getpwnam or pwd.getpwuid fails, this just returns an empty dict
    # and that's fine
    facts = collector.collect()
    assert 'user_id' in facts
    assert 'user_uid' in facts
    assert 'user_gid' in facts
    assert 'user_gecos' in facts
    assert 'user_dir' in facts
    assert 'user_shell' in facts
    assert 'real_user_id' in facts
    assert 'effective_user_id' in facts
    assert 'real_group_id' in facts
    assert 'effective_group_id' in facts

# Generated at 2022-06-11 05:27:52.494226
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collector = UserFactCollector()

    facts = collector.collect(None, None)

    assert facts['user_id'] == getpass.getuser()
    assert facts['user_uid'] == pwd.getpwnam(getpass.getuser()).pw_uid
    assert facts['user_gid'] == pwd.getpwnam(getpass.getuser()).pw_gid
    assert facts['user_gecos'] == pwd.getpwnam(getpass.getuser()).pw_gecos
    assert facts['user_dir'] == pwd.getpwnam(getpass.getuser()).pw_dir
    assert facts['user_shell'] == pwd.getpwnam(getpass.getuser()).pw_shell

# Generated at 2022-06-11 05:27:55.235768
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    uf = UserFactCollector()
    res = uf.collect()
    keys = set(res.keys())
    assert uf._fact_ids == keys, 'All of user facts are not collected.'

# Generated at 2022-06-11 05:29:04.438724
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    u = UserFactCollector()

    assert u.collect()['user_id']
    assert u.collect()['user_uid']
    assert u.collect()['user_gid']
    assert u.collect()['user_gecos']
    assert u.collect()['user_dir']
    assert u.collect()['user_shell']
    assert u.collect()['real_user_id']
    assert u.collect()['effective_user_id']
    assert u.collect()['real_group_id']
    assert u.collect()['effective_group_id']


# Generated at 2022-06-11 05:29:11.074302
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()

    user_facts = ufc.collect()

    assert 'user_id' in user_facts
    assert 'user_uid' in user_facts
    assert 'user_gid' in user_facts
    assert 'user_gecos' in user_facts
    assert 'user_dir' in user_facts
    assert 'user_shell' in user_facts
    assert 'real_user_id' in user_facts
    assert 'effective_user_id' in user_facts
    assert 'effective_group_ids' in user_facts

# Generated at 2022-06-11 05:29:12.684048
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # This test only checks if the method runs without errors
    UserFactCollector().collect()

# Generated at 2022-06-11 05:29:22.174855
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    from ansible.module_utils.facts.collector import FactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector

    fact_collector = FactCollector()
    base_fact_collector = BaseFactCollector()

    # Override method collect from BaseFactCollector class
    def dummy_collect(self):
        return 'dummy_collect'

    BaseFactCollector.collect = dummy_collect

    base_fact_collector_collect = BaseFactCollector.collect
    assert base_fact_collector_collect(base_fact_collector) == 'dummy_collect'

    user_fact_collector_collect = UserFactCollector.collect
    dummy_collect_class = user_fact_collector_collect(UserFactCollector)

    # Check if returned values are not empty
    #

# Generated at 2022-06-11 05:29:31.337735
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    from ansible.module_utils.facts.collector import CollectorsRunner
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.collectors import user
    import collections
    import json

    user1 = {
        "user_id": "root",
        "user_uid": 0,
        "user_gid": 0,
        "user_gecos": "root",
        "user_dir": "/root",
        "user_shell": "/bin/bash",
        "real_user_id": 0,
        "effective_user_id": 0,
        "effective_group_ids": [
            0
        ]
    }

    # Note: To create a new class for test, we need to inherit from the
    # class to test, and override the collect method to return hard

# Generated at 2022-06-11 05:29:32.326421
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

	# Tests collect method
    pass

# Generated at 2022-06-11 05:29:42.434085
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    """ Unit test for method collect of class UserFactCollector """
    obj = UserFactCollector()
    result = obj.collect()
    assert result['user_id'] == getpass.getuser()
    assert result['user_uid'] == pwd.getpwnam(getpass.getuser()).pw_uid
    assert result['user_gid'] == pwd.getpwnam(getpass.getuser()).pw_gid
    assert result['user_dir'] == pwd.getpwnam(getpass.getuser()).pw_dir
    assert result['user_shell'] == pwd.getpwnam(getpass.getuser()).pw_shell
    assert result['real_user_id'] == os.getuid()
    assert result['effective_user_id'] == os.geteuid

# Generated at 2022-06-11 05:29:44.918164
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    test_user_facts = UserFactCollector()
    user_facts = test_user_facts.collect()
    print(user_facts)



# Generated at 2022-06-11 05:29:53.894562
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    userFactCollector = UserFactCollector()
    methodOutput = userFactCollector.collect()

# Generated at 2022-06-11 05:29:57.757511
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()
    expected_facts = {'user_id': 'root', 'real_user_id': 0, 'effective_user_id': 0, 'real_group_id': 0, 'effective_group_id': 0}
    assert user_facts == expected_facts
