

# Generated at 2022-06-25 00:44:18.517862
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()


# Generated at 2022-06-25 00:44:25.202213
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_fact_collector_collect = user_fact_collector.collect()
    # Output:
    # {u'user_id': u'root', u'effective_user_id': 0, u'real_user_id': 0,
    #  u'user_gid': 0, u'user_gecos': u'root', u'effective_group_ids': [0],
    #  u'user_uid': 0, u'user_shell': u'/bin/bash',
    #  u'real_group_id': 0, u'user_dir': u'/root'}
    #print(user_fact_collector_collect)


# Generated at 2022-06-25 00:44:35.013238
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    sys_user_name = getpass.getuser()
    sys_user_gecos = pwd.getpwnam(sys_user_name).pw_gecos
    try:
        pwent = pwd.getpwnam(getpass.getuser())
        sys_user_uid = pwent.pw_uid
        sys_user_gid = pwent.pw_gid
        sys_user_dir = pwent.pw_dir
        sys_user_shell = pwent.pw_shell
    except KeyError:
        pwent = pwd.getpwuid(os.getuid())
        sys_user_uid = pwent.pw_uid
        sys_user_gid = pwent.pw_gid
        sys_user_dir = pwent.pw_dir
       

# Generated at 2022-06-25 00:44:43.844231
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts_dict = user_fact_collector.collect()
    assert 'user_id' in user_facts_dict.keys()
    assert 'user_gid' in user_facts_dict.keys()
    assert 'user_shell' in user_facts_dict.keys()
    assert 'effective_user_id' in user_facts_dict.keys()
    assert 'user_gecos' in user_facts_dict.keys()
    assert 'user_uid' in user_facts_dict.keys()
    assert 'user_dir' in user_facts_dict.keys()
    assert 'effective_group_id' in user_facts_dict.keys()
    assert 'real_user_id' in user_facts_dict.keys()

# Generated at 2022-06-25 00:44:47.766584
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    retrieved_facts = user_fact_collector_1.collect()
    assert isinstance(retrieved_facts, dict)

# Generated at 2022-06-25 00:44:53.819423
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    result = user_fact_collector_0.collect()
    assert type(result) is dict
    assert 'effective_group_id' in result
    assert result['effective_group_id'] == os.getgid()
    assert 'effective_user_id' in result
    assert result['effective_user_id'] == os.geteuid()
    assert 'real_group_id' in result
    assert result['real_group_id'] == os.getgid()
    assert 'real_user_id' in result
    assert result['real_user_id'] == os.getuid()
    assert 'user_dir' in result
    assert 'user_gecos' in result

# Generated at 2022-06-25 00:45:00.101331
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()

    real_user_id = os.getuid()
    effective_user_id = os.geteuid()

    user_id = getpass.getuser()

    result = user_fact_collector_0.collect()

    assert result['user_id'] == user_id
    assert result['user_uid'] == real_user_id
    assert result['user_gid'] == effective_user_id
    assert result['real_user_id'] == real_user_id
    assert result['effective_user_id'] == effective_user_id



# Generated at 2022-06-25 00:45:03.251042
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    collected_facts = {}
    user_fact_collector_1.collect(collected_facts=collected_facts)

if __name__ == '__main__':
    # Test to check the result of the unit tests
    print(UserFactCollector())
    test_case_0()
    test_UserFactCollector_collect()

# Generated at 2022-06-25 00:45:09.890742
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    # Setup test case
    user_fact_collector = UserFactCollector()

    # Exercise code
    user_facts = user_fact_collector.collect()

    # Verify
    assert 'user_id' in user_facts
    assert 'user_uid' in user_facts
    assert 'user_gid' in user_facts
    assert 'user_gecos' in user_facts
    assert 'user_dir' in user_facts
    assert 'user_shell' in user_facts
    assert 'real_user_id' in user_facts
    assert 'effective_user_id' in user_facts
    assert 'effective_group_ids' in user_facts
    assert 'user_id' in user_facts
    assert 'user_id' in user_facts
    assert 'user_id' in user_facts

# Generated at 2022-06-25 00:45:13.239217
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_collect_0 = UserFactCollector()
    assert user_fact_collector_collect_0.collect() is not None

# Generated at 2022-06-25 00:45:17.935144
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # UserFactCollector.collect() not implemented yet
    pass


# Generated at 2022-06-25 00:45:28.204853
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector().collect()
    assert user_facts is not None
    assert isinstance(user_facts, dict)
    assert isinstance(user_facts['user_id'], str)
    assert isinstance(user_facts['user_uid'], int)
    assert isinstance(user_facts['user_gid'], int)
    assert isinstance(user_facts['user_gecos'], str)
    assert isinstance(user_facts['user_dir'], str)
    assert isinstance(user_facts['user_shell'], str)
    assert isinstance(user_facts['effective_user_id'], int)
    assert isinstance(user_facts['effective_group_id'], int)
    assert isinstance(user_facts['effective_group_ids'], list)

# Generated at 2022-06-25 00:45:37.158670
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    assertions = user_fact_collector_0.collect()
    if not assertions['user_id'] == getpass.getuser():
        raise AssertionError("Assertion failure for 'user_id'")
    if not assertions['user_uid'] == pwd.getpwnam(getpass.getuser()).pw_uid:
        raise AssertionError("Assertion failure for 'user_uid'")
    if not assertions['user_gid'] == pwd.getpwnam(getpass.getuser()).pw_gid:
        raise AssertionError("Assertion failure for 'user_gid'")

# Generated at 2022-06-25 00:45:39.138851
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    assert user_fact_collector_0.collect() is not None


# Generated at 2022-06-25 00:45:41.184355
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()


# Generated at 2022-06-25 00:45:48.887370
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    input_data = {u'user_dir': u'/home/some_user', u'effective_user_id': 1000, u'user_uid': 1000, u'real_user_id': 1000, u'real_group_id': 1000, u'user_gid': 1000, u'effective_group_id': 1000, u'user_shell': u'/bin/bash', u'user_gecos': u'', u'user_id': u'some_user'}

    user_fact_collector_1 = UserFactCollector()

    output = user_fact_collector_1.collect(None, None)

    assert(output == input_data)

# Generated at 2022-06-25 00:45:57.230181
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    ret_val_0 = user_fact_collector_0.collect()
    assert ret_val_0 == {'effective_group_id': os.getgid(),
                        'effective_group_ids': [],
                        'effective_user_id': os.geteuid(),
                        'real_group_id': os.getgid(),
                        'real_user_id': os.getuid(),
                        'user_dir': '',
                        'user_gecos': '',
                        'user_gid': os.getgid(),
                        'user_id': getpass.getuser(),
                        'user_shell': '',
                        'user_uid': os.getuid()}


# Generated at 2022-06-25 00:45:59.051666
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()



# Generated at 2022-06-25 00:46:09.320286
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_collect_0 = UserFactCollector()
    user_facts_collect_0 = user_fact_collector_collect_0.collect()
    assert 'user_id' in user_facts_collect_0
    assert 'user_uid' in user_facts_collect_0
    assert 'user_gid' in user_facts_collect_0
    assert 'user_gecos' in user_facts_collect_0
    assert 'user_dir' in user_facts_collect_0
    assert 'user_shell' in user_facts_collect_0
    assert 'real_user_id' in user_facts_collect_0
    assert 'effective_user_id' in user_facts_collect_0
    assert 'effective_group_ids' in user_facts_collect_0


# Generated at 2022-06-25 00:46:13.311618
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collect_dict_0 = {}

    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect({'name': 'pavan'}, collect_dict_0)


# Generated at 2022-06-25 00:46:22.277454
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    dict_0 = {}
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect(dict_0)
    assert(user_fact_collector_0.name == 'user')
    assert(len(user_fact_collector_0._fact_ids) == 9)
    assert(user_fact_collector_0._fact_ids.issubset({'user_uid', 'effective_user_id', 'user_gid', 'effective_group_ids', 'user_gecos', 'user_id', 'real_user_id', 'user_shell', 'user_dir'}))

# Generated at 2022-06-25 00:46:24.411852
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    dict_0 = {}
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect(dict_0)

# Generated at 2022-06-25 00:46:27.254417
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    dict_1 = {}
    user_fact_collector_1 = UserFactCollector()
    var_1 = user_fact_collector_1.collect(dict_1)
    assert not var_1


# Generated at 2022-06-25 00:46:28.180350
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    assert callable(UserFactCollector.collect)

# Generated at 2022-06-25 00:46:32.175673
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    dict_0 = {}
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect(dict_0)
    if var_0 is not None:
        assert isinstance(var_0, dict)
    else:
        assert var_0 is None


# Generated at 2022-06-25 00:46:34.292101
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    dict_0 = {}
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect(dict_0)


# Generated at 2022-06-25 00:46:39.850701
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    log('Test Case 0')
    # SystemExit:
    try:
        dict_0 = {}
        user_fact_collector_0 = UserFactCollector()
        user_fact_collector_0.collect(dict_0)
    except SystemExit:
        log(traceback.format_exc())
    else:
        raise Exception('Wrong exception raised!')
    log('Test Case 1')
    # SystemExit:
    try:
        dict_0 = {'A': 'B'}
        user_fact_collector_0 = UserFactCollector()
        user_fact_collector_0.collect(dict_0)
    except SystemExit:
        log(traceback.format_exc())
    else:
        raise Exception('Wrong exception raised!')
    log('Test Case 2')
    # SystemExit

# Generated at 2022-06-25 00:46:44.203031
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    dict_0 = {}
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect(dict_0)
    assert var_0 == {'effective_group_id': 1000, 'effective_user_id': 1000, 'real_group_id': 1000, 'real_user_id': 1000, 'user_dir': '/home/saltboi', 'user_gid': 1000, 'user_gecos': 'saltboi', 'user_id': 'saltboi', 'user_shell': '/bin/bash', 'user_uid': 1000}



# Generated at 2022-06-25 00:46:48.376675
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    dict_0 = {}
    user_fact_collector_0 = UserFactCollector()
    assert user_fact_collector_0.collect(dict_0) == {
        'real_group_id': 1000, 'effective_user_id': 1000, 'user_uid': 1000, 'user_gecos': 'vagrant,,,', 'user_gid': 1000, 'effective_group_id': 1000, 'user_id': 'vagrant', 'user_shell': '/bin/bash', 'real_user_id': 1000, 'effective_user_ids': [1000], 'user_dir': '/home/vagrant'
   } 


# Generated at 2022-06-25 00:46:50.802435
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    dict_1 = {}
    user_fact_collector_1 = UserFactCollector()
    # needs to be at least 0
    var_1 = len(user_fact_collector_1.collect(dict_1))

# Generated at 2022-06-25 00:47:01.997910
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    dict_0 = {}
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect(dict_0)
    print("\nprinting facts")
    print(var_0)

test_UserFactCollector_collect()

# Generated at 2022-06-25 00:47:04.264894
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    dict_0 = {}
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect(dict_0)


# Generated at 2022-06-25 00:47:06.581848
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    dict_0 = {}
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect(dict_0)



# Generated at 2022-06-25 00:47:12.523406
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    dict_0 = {}
    user_fact_collector_0 = UserFactCollector()
    collector_0 = user_fact_collector_0.collect(dict_0)
    assert collector_0 == {'effective_user_id': 1000, 'user_id': 'test_user', 'user_dir': '/tmp', 'real_group_id': 1000, 'user_gecos': 'test_user,,,', 'effective_group_id': 1000, 'user_uid': 1000, 'real_user_id': 1000, 'user_gid': 1000, 'user_shell': '/bin/bash'}

# Generated at 2022-06-25 00:47:22.621803
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    dict_0 = dict()
    dict_0['ansible_facts'] = dict()
    dict_1 = dict()
    dict_2 = dict()
    dict_2['user_id'] = 'user_id_0'
    dict_1['user_id'] = 'user_id_0'
    dict_0['ansible_facts']['user_id'] = 'user_id_0'
    dict_2['user_uid'] = 'user_uid_0'
    dict_1['user_uid'] = 'user_uid_0'
    dict_0['ansible_facts']['user_uid'] = 'user_uid_0'
    dict_2['user_gid'] = 'user_gid_0'
    dict_1['user_gid'] = 'user_gid_0'

# Generated at 2022-06-25 00:47:24.728637
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    dict_0 = {}
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect(dict_0)

# Generated at 2022-06-25 00:47:34.378071
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import types
    import tempfile
    module_name = 'ansible.module_utils.facts.collector.user'
    pwd_getpwuid = 'pwd.getpwuid'
    pwd_getpwnam = 'pwd.getpwnam'
    os_geteuid = 'os.geteuid'
    os_getuid = 'os.getuid'
    getpass_getuser = 'getpass.getuser'
    os_getgid = 'os.getgid'
    os_getegid = 'os.getegid'
    dict_0 = {}
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect(dict_0)
    assert var_0 is not None
    modules_mock

# Generated at 2022-06-25 00:47:44.155389
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # This test will only pass on systems where the test user does exist
    # This test will only pass on systems where the test user does exist
    # This test will only pass on systems where the test user does exist
    assert UserFactCollector.collect() == {
        "elasticsearch_version": "2.2.0",
        "user_gid": 20,
        "user_id": "test_user",
        "user_shell": "/bin/bash",
        "user_uid": 495,
        "real_user_id": 495,
        "user_gecos": "Test User,,,",
        "effective_user_id": 495,
        "user_dir": "/home/test_user",
        "real_group_id": 20,
        "effective_group_id": 20
    }


# Generated at 2022-06-25 00:47:46.553295
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_fact_collector.collect()

# Generated at 2022-06-25 00:47:47.197418
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    pass

# Generated at 2022-06-25 00:48:02.360812
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    assert True


# Generated at 2022-06-25 00:48:05.185987
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    dict_0 = {}
    var_0 = user_fact_collector_0.collect(dict_0)
    assert var_0 == {}



# Generated at 2022-06-25 00:48:08.825411
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    dict_1 = {}
    user_fact_collector_1 = UserFactCollector()
    assert user_fact_collector_1.collect(dict_1)

if __name__ == '__main__':
    test_case_0()
    test_UserFactCollector_collect()

# Generated at 2022-06-25 00:48:11.168105
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    dict_0 = {}
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect(dict_0)


# Generated at 2022-06-25 00:48:13.810047
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    try:
        dict_0 = {}
        user_fact_collector_0 = UserFactCollector()
        dict_1 = user_fact_collector_0.collect()
    except:
        assert False


# Generated at 2022-06-25 00:48:17.354951
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    dict_0 = {}
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect(dict_0)

# Generated at 2022-06-25 00:48:23.026569
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    dict_0 = { }
    user_fact_collector_0 = UserFactCollector()
    var_1 = user_fact_collector_0.collect(dict_0)
    assert var_1['user_id'] == getpass.getuser(), 'var_1["user_id"] == getpass.getuser() is False'
    assert var_1['user_shell'] == pwd.getpwnam(getpass.getuser()).pw_shell, 'var_1["user_shell"] == pwd.getpwnam(getpass.getuser()).pw_shell is False'

# Generated at 2022-06-25 00:48:23.881549
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    test_case_0()

# Generated at 2022-06-25 00:48:28.149351
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    dict_0 = {}
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect(dict_0)


# Generated at 2022-06-25 00:48:34.549365
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    dict_0 = {}
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect(dict_0)
    assert 'user_id' in var_0
    assert 'user_uid' in var_0
    assert 'user_gid' in var_0
    assert 'user_gecos' in var_0
    assert 'user_dir' in var_0
    assert 'user_shell' in var_0
    assert 'real_user_id' in var_0
    assert 'effective_user_id' in var_0
    assert 'effective_group_ids' in var_0

# Generated at 2022-06-25 00:49:11.994055
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    dict_1 = {
        'effective_user_id': os.geteuid(),
        'effective_group_id': os.getegid(),
        'real_user_id': os.getuid(),
        'real_group_id': os.getgid(),
        'user_id': getpass.getuser(),
    }
    user_fact_collector_1 = UserFactCollector()
    assert user_fact_collector_1.collect() == dict_1


if __name__ == '__main__':
    test_UserFactCollector_collect()

# Generated at 2022-06-25 00:49:18.004704
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    # We create an instance of UserFactCollector
    user_fact_collector = UserFactCollector()

    # We call the method with an empty dict and we check that the result
    # is an empty dict
    assert user_fact_collector.collect() == {}


# Generated at 2022-06-25 00:49:23.794427
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    dict_0 = {}
    user_fact_collector_0 = UserFactCollector()
    assert isinstance(user_fact_collector_0.collect(dict_0), dict)


# Generated at 2022-06-25 00:49:27.110262
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    dict_0 = {}
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect(dict_0)


# Generated at 2022-06-25 00:49:29.796250
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    dict_0 = {}
    user_fact_collector_0 = UserFactCollector()
    assert user_fact_collector_0.collect(dict_0) is not None



# Generated at 2022-06-25 00:49:31.354980
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    dict_0 = {}
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect(dict_0)

# Unit tes for class UserFactCollector

# Generated at 2022-06-25 00:49:41.280252
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    dict_1 = {}
    user_fact_collector_1 = UserFactCollector()

# Generated at 2022-06-25 00:49:50.387513
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    try:
        assert "user_id" in var_0
    except NameError:
        pass
    try:
        assert "user_uid" in var_0
    except NameError:
        pass
    try:
        assert "user_gid" in var_0
    except NameError:
        pass
    try:
        assert "user_gecos" in var_0
    except NameError:
        pass
    try:
        assert "user_dir" in var_0
    except NameError:
        pass
    try:
        assert "user_shell" in var_0
    except NameError:
        pass
    try:
        assert "real_user_id" in var_0
    except NameError:
        pass

# Generated at 2022-06-25 00:49:51.966207
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    dict = {}
    user_fact_collector = UserFactCollector()
    user_fact_collector.collect(dict)

# Generated at 2022-06-25 00:49:55.578624
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Test with an empty dict for arg1, and an empty dict for arg2
    dict_0 = {}
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect(dict_0)

# unit tests end here.

if __name__ == '__main__':
    test_case_0()
    test_UserFactCollector_collect()

# Generated at 2022-06-25 00:51:19.588143
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    # Test with correct return type
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect(dict_0)
    assert isinstance(var_0, dict)

    try:
        # Test with incorrect return type
        user_fact_collector_1 = UserFactCollector()
        var_0 = user_fact_collector_1.collect(dict_0)
        assert isinstance(var_0, str)
    except AssertionError:
        raise

# Generated at 2022-06-25 00:51:22.446495
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    dict_0 = {}
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect(dict_0)
    var_0 = user_fact_collector_0.collect()



# Generated at 2022-06-25 00:51:25.931048
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    pass


# Generated at 2022-06-25 00:51:33.839624
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    dict_1 = {}
    user_fact_collector_1 = UserFactCollector()
    var_1 = user_fact_collector_1.collect(dict_1)
    assert type(var_1) is dict
    assert var_1['effective_group_id'] == os.getgid()
    assert var_1['effective_user_id'] == os.geteuid()
    assert var_1['real_group_id'] == os.getgid()
    assert var_1['user_gid'] == pwd.getpwnam(getpass.getuser()).pw_gid
    assert var_1['real_user_id'] == os.getuid()
    assert var_1['user_gecos'] == pwd.getpwnam(getpass.getuser()).pw_gecos

# Generated at 2022-06-25 00:51:36.170040
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    dict_0 = {}
    user_fact_collector_0 = UserFactCollector()
    assert user_fact_collector_0.collect(dict_0) == None


# Generated at 2022-06-25 00:51:38.796988
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    ufc = UserFactCollector()
    facts = ufc.collect()
    assert hasattr(facts, 'get')
    assert ufc.name in facts
    assert hasattr(facts[ufc.name], 'get')
    assert all(key in facts[ufc.name] for key in ufc._fact_ids)

# Generated at 2022-06-25 00:51:40.266207
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    dict_0 = {}
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect(dict_0)

# Generated at 2022-06-25 00:51:46.307358
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # user_facts_from_module is an object of class UserFactCollector
    user_facts_from_module = UserFactCollector()

    # user_facts_from_module.collect() is dictionary of the user facts
    user_facts = user_facts_from_module.collect()

    # user_facts.keys() is dictionary keys so it should be same as _fact_ids
    assert user_facts.keys() == UserFactCollector._fact_ids

# Generated at 2022-06-25 00:51:48.122600
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import os
    euid = os.geteuid()
    uid = os.getuid()

    assert euid != 0

# Generated at 2022-06-25 00:51:49.759716
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    dict_0 = {}
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect(dict_0)