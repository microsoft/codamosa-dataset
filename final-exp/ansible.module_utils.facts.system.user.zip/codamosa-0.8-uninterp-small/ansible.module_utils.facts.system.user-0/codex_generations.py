

# Generated at 2022-06-25 00:44:18.601710
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()


# Generated at 2022-06-25 00:44:21.097121
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    collected_facts_1 = {}
    user_facts_1 = user_fact_collector_1.collect(collected_facts=collected_facts_1)
    assert userna

# Generated at 2022-06-25 00:44:31.793908
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()

    assert user_facts['user_id'] == getpass.getuser()
    try:
        pwent = pwd.getpwnam(getpass.getuser())
    except KeyError:
        pwent = pwd.getpwuid(os.getuid())
    assert user_facts['user_uid'] == pwent.pw_uid
    assert user_facts['user_gid'] == pwent.pw_gid
    assert user_facts['user_gecos'] == pwent.pw_gecos
    assert user_facts['user_dir'] == pwent.pw_dir
    assert user_facts['user_shell'] == pwent.pw_shell

# Generated at 2022-06-25 00:44:35.642226
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()

# Generated at 2022-06-25 00:44:38.577829
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    assert user_fact_collector_1.collect()

# Generated at 2022-06-25 00:44:42.971590
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_fact_collector_collect = user_fact_collector.collect()

    for key in user_fact_collector_collect:
        assert isinstance(user_fact_collector_collect[key], (int, str))

# Generated at 2022-06-25 00:44:52.956704
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    collected_facts = {}
    actual_facts = {'effective_group_id': 1000,
                    'effective_group_ids': [1000],
                    'effective_user_id': 1000,
                    'real_group_id': 1000,
                    'real_user_id': 1000,
                    'user_dir': '/home/ansible',
                    'user_gid': 1000,
                    'user_gecos': 'ansible',
                    'user_id': 'ansible',
                    'user_shell': '/bin/bash',
                    'user_uid': 1000}
    user_fact_collector_1.collect(collected_facts=collected_facts)
    assert(collected_facts == actual_facts)


# Generated at 2022-06-25 00:44:54.898154
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    coll_facts = {}

    user_fact_collector_1 = UserFactCollector()
    user_fact_collector_1.collect(collected_facts=coll_facts)

# Generated at 2022-06-25 00:45:04.875812
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    assert(user_fact_collector_1.collected_facts is None)
    user_fact_collector_1.collect()
    assert(user_fact_collector_1.collected_facts is not None)
    assert('user_id' in user_fact_collector_1.collected_facts)
    assert('real_user_id' in user_fact_collector_1.collected_facts)
    assert('effective_user_id' in user_fact_collector_1.collected_facts)
    assert('real_group_id' in user_fact_collector_1.collected_facts)
    assert('effective_group_id' in user_fact_collector_1.collected_facts)


# Generated at 2022-06-25 00:45:10.826745
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    collected_facts = dict()
    user_facts = dict()

    result = user_fact_collector_1.collect(collected_facts=collected_facts)
    assert result == user_facts

# Generated at 2022-06-25 00:45:25.114572
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    mytest = ufc.collect()
    assert mytest['user_id'] == pwd.getpwuid(os.getuid())[0]
    assert mytest['user_uid'] == os.getuid()
    assert mytest['user_gid'] == os.getgid()
    assert mytest['user_gecos'] == pwd.getpwuid(os.getuid())[4]
    assert mytest['user_dir'] == pwd.getpwuid(os.getuid())[5]
    assert mytest['user_shell'] == pwd.getpwuid(os.getuid())[6]
    assert mytest['real_user_id'] == os.getuid()
    assert mytest['real_group_id'] == os.getgid()

# Generated at 2022-06-25 00:45:27.011387
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()

    user_fact_collector_1.collect()


# Generated at 2022-06-25 00:45:28.477321
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_fact_collector_1.collect()

# Generated at 2022-06-25 00:45:37.185050
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ret = UserFactCollector.collect()
    assert 'user_id' in ret
    assert 'user_uid' in ret
    assert 'user_gid' in ret
    assert 'user_gecos' in ret
    assert 'user_dir' in ret
    assert 'user_shell' in ret
    assert 'real_user_id' in ret
    assert 'effective_user_id' in ret
    assert 'effective_group_ids' in ret

    user_fact_collector_0 = UserFactCollector()
    ret = user_fact_collector_0.collect()
    assert 'user_id' in ret
    assert 'user_uid' in ret
    assert 'user_gid' in ret
    assert 'user_gecos' in ret
    assert 'user_dir' in ret
    assert 'user_shell'

# Generated at 2022-06-25 00:45:43.042474
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    assert user_fact_collector_0.collect() == {'user_dir': '/home/vagrant', 'user_id': 'vagrant', 'user_gid': 1000, 'user_gecos': 'vagrant,,,', 'user_shell': '/bin/bash', 'user_uid': 1000, 'effective_group_id': 1000, 'effective_user_id': 1000, 'real_user_id': 1000, 'real_group_id': 1000}

# Generated at 2022-06-25 00:45:45.164447
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    collected_facts = {}
    facts = ufc.collect(collected_facts)
    for fact in ufc.get_fact_ids():
        assert fact in facts

# Generated at 2022-06-25 00:45:49.892908
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    test_case_0()
    user_fact_collector = UserFactCollector()
    user_fact_collector.collect()
    assert user_fact_collector._fact_ids == set(['user_id', 'user_uid',
                                                 'user_gid', 'user_gecos',
                                                 'user_dir', 'user_shell',
                                                 'real_user_id',
                                                 'effective_user_id',
                                                 'effective_group_ids'])

# Generated at 2022-06-25 00:45:53.216766
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()

if __name__ == "__main__":
    test_UserFactCollector_collect()

# Generated at 2022-06-25 00:46:00.386816
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()

    # Call function collect of class UserFactCollector
    collected_facts = user_fact_collector.collect()

    # Asserts the result
    assert collected_facts['user_id'] == getpass.getuser()
    try:
        pwent = pwd.getpwnam(getpass.getuser())
    except KeyError:
        pwent = pwd.getpwuid(os.getuid())

    assert collected_facts['user_uid'] == pwent.pw_uid
    assert collected_facts['user_gid'] == pwent.pw_gid
    assert collected_facts['user_gecos'] == pwent.pw_gecos
    assert collected_facts['user_dir'] == pwent.pw_dir
    assert collected_facts

# Generated at 2022-06-25 00:46:01.619381
# Unit test for method collect of class UserFactCollector

# Generated at 2022-06-25 00:46:10.755402
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fact_collector = UserFactCollector()
    fact_collector.collect()


# Generated at 2022-06-25 00:46:19.495585
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_collect = UserFactCollector()
    user_facts_dict = {}
    user_facts_dict = user_fact_collector_collect.collect(module=None, collected_facts={})

# Generated at 2022-06-25 00:46:21.975931
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_fact_collector.collect()

# Generated at 2022-06-25 00:46:23.799166
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_1 = UserFactCollector()


# Generated at 2022-06-25 00:46:30.886094
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()

    user_facts = user_fact_collector.collect()

    assert 'user_id' in user_facts
    assert 'user_uid' in user_facts
    assert 'user_gid' in user_facts
    assert 'user_gecos' in user_facts
    assert 'user_dir' in user_facts
    assert 'user_shell' in user_facts
    assert 'real_user_id' in user_facts
    assert 'effective_user_id' in user_facts
    assert 'real_group_id' in user_facts
    assert 'effective_group_id' in user_facts

# Generated at 2022-06-25 00:46:36.145259
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_facts = user_fact_collector_0.collect()
    assert user_facts['user_id'] == 'vagrant'
    assert user_facts['user_uid'] == 1000
    assert user_facts['user_gid'] == 1000
    assert user_facts['user_gecos'] == 'vagrant,,,,'
    assert user_facts['user_dir'] == '/home/vagrant'
    assert user_facts['user_shell'] == '/bin/bash'
    assert user_facts['real_user_id'] == 1000
    assert user_facts['effective_user_id'] == 1000
    assert user_facts['real_group_id'] == 1000
    assert user_facts['effective_group_id'] == 1000

# Generated at 2022-06-25 00:46:39.557547
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collector = UserFactCollector()
    facts = collector.collect()

    assert 'user_id' in facts
    assert 'user_uid' in facts
    assert 'user_gid' in facts
    assert 'user_gecos' in facts
    assert 'user_dir' in facts
    assert 'user_shell' in facts
    assert 'real_user_id' in facts
    assert 'effective_user_id' in facts
    assert 'real_group_id' in facts
    assert 'effective_group_id' in facts

# Generated at 2022-06-25 00:46:44.794045
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Function referenced by unit test
    def getpass_getuser(): return 'north'
    def os_getuid(): return '0'
    def os_geteuid(): return '0'
    def pwd_getpwnam_exception(): raise KeyError
    def pwd_getpwuid(): return pwd.struct_passwd(pw_name='north',
                                                 pw_passwd='x',
                                                 pw_uid='0',
                                                 pw_gid='0',
                                                 pw_gecos='North Pole',
                                                 pw_dir='/',
                                                 pw_shell='/bin/bash')
    def os_getgid(): return '0'
    def os_getegid(): return '0'

    # Replace module functions with our mock functions


# Generated at 2022-06-25 00:46:49.929392
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    collected_facts = {}
    collected_facts['linux_distribution'] = []
    user_facts = user_fact_collector_0.collect(collected_facts = collected_facts)
    assert type(user_facts) == dict
    assert 'user_id' in user_facts
    assert 'user_uid' in user_facts
    assert 'user_gid' in user_facts
    assert 'user_gecos' in user_facts
    assert 'user_dir' in user_facts
    assert 'user_shell' in user_facts
    assert 'real_user_id' in user_facts
    assert 'effective_user_id' in user_facts
    assert 'real_group_id' in user_facts

# Generated at 2022-06-25 00:46:55.946207
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    assert user_fact_collector_1.collect() == {'effective_group_ids': [], 'user_id': 'root', 'effective_user_id': 0, 'user_uid': 0, 'user_gid': 0, 'user_gecos': 'root', 'user_shell': '/bin/bash', 'user_dir': '/root', 'real_user_id': 0}

# Generated at 2022-06-25 00:47:11.419392
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    bool_0 = False
    user_fact_collector_0 = UserFactCollector(bool_0)
    var_0 = user_fact_collector_0.collect()

    assert var_0['user_id'] is not None, 'user_id should not be None'
    assert var_0['user_uid'] is not None, 'user_uid should not be None'
    assert var_0['user_gid'] is not None, 'user_gid should not be None'
    assert var_0['user_gecos'] is not None, 'user_gecos should not be None'
    assert var_0['user_dir'] is not None, 'user_dir should not be None'
    assert var_0['user_shell'] is not None, 'user_shell should not be None'

# Generated at 2022-06-25 00:47:12.203207
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    test_case_0()

# Generated at 2022-06-25 00:47:15.874073
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    bool_0 = False
    user_fact_collector_0 = UserFactCollector(bool_0)
    # TODO:
    #var_0 = user_fact_collector_0.collect()



# Generated at 2022-06-25 00:47:18.559412
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    bool_0 = False
    user_fact_collector_0 = UserFactCollector(bool_0)
    var_0 = user_fact_collector_0.collect()

# Generated at 2022-06-25 00:47:21.260333
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    bool_0 = False
    user_fact_collector_0 = UserFactCollector(bool_0)
    var_0 = user_fact_collector_0.collect()
    print(var_0)

# Generated at 2022-06-25 00:47:22.112611
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    assert False


# Generated at 2022-06-25 00:47:25.797344
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    bool_0 = False
    user_fact_collector_0 = UserFactCollector(bool_0)
    user_fact_collector_0.collect()
    bool_1 = False
    user_fact_collector_1 = UserFactCollector(bool_1)
    user_fact_collector_1.collect()

# Generated at 2022-06-25 00:47:27.656578
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    bool_0 = True
    user_fact_collector_0 = UserFactCollector(bool_0)
    var_0 = user_fact_collector_0.collect()

# Generated at 2022-06-25 00:47:31.520730
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    module = AnsibleModule(
        argument_spec={}
    )
    bool_0 = True
    user_fact_collector_0 = UserFactCollector(bool_0)
    var_0 = user_fact_collector_0.collect(None, None)
# vim: expandtab:tabstop=4:shiftwidth=4

# Generated at 2022-06-25 00:47:34.231137
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    bool_0 = False
    user_fact_collector_0 = UserFactCollector(bool_0)
    var_0 = user_fact_collector_0.collect()


# Generated at 2022-06-25 00:47:53.536795
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0._fact_ids

# Generated at 2022-06-25 00:47:57.272677
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    bool_0 = True
    user_fact_collector_0 = UserFactCollector(bool_0)
    user_fact_collector_0.collect()


# Generated at 2022-06-25 00:48:03.712945
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    bool_0 = False
    user_fact_collector_0 = UserFactCollector(bool_0)
    var_0 = user_fact_collector_0.collect()
    assert (var_0 == dict({u'real_user_id': 1000, u'user_dir': u'/home/staffan', u'effective_group_id': 1000, u'user_gid': 1000, u'real_group_id': 1000, u'user_gecos': u'Staffan', u'effective_user_id': 1000, u'user_shell': u'/bin/bash', u'user_uid': 1000, u'user_id': u'staffan'}))


# Generated at 2022-06-25 00:48:06.088414
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector(True)
    bool_0 = user_fact_collector_1.collect()


# Generated at 2022-06-25 00:48:08.709118
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    bool_0 = False
    user_fact_collector_0 = UserFactCollector(bool_0)
    var_0 = user_fact_collector_0.collect()


# Generated at 2022-06-25 00:48:15.669933
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts_0 = UserFactCollector(False)
    var_1 = user_facts_0.collect()
    assert type(var_1) == dict
    assert var_1['user_id'] == getpass.getuser()
    pwent = pwd.getpwnam(getpass.getuser())
    assert var_1['user_uid'] == pwent.pw_uid
    assert var_1['user_gid'] == pwent.pw_gid
    assert var_1['user_gecos'] == pwent.pw_gecos
    assert var_1['user_dir'] == pwent.pw_dir
    assert var_1['user_shell'] == pwent.pw_shell
    assert var_1['real_user_id'] == os.getuid()
    assert var_

# Generated at 2022-06-25 00:48:19.814883
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    bool_0 = True
    user_fact_collector_0 = UserFactCollector(bool_0)
    user_fact_collector_0.collect_now = False
    var_0 = user_fact_collector_0.collect()


# Generated at 2022-06-25 00:48:22.450954
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    bool_0 = False
    user_fact_collector_0 = UserFactCollector(bool_0)
    

# Generated at 2022-06-25 00:48:26.846159
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    bool_0 = False
    user_fact_collector_0 = UserFactCollector(bool_0)
    var_0 = user_fact_collector_0.collect()


# Generated at 2022-06-25 00:48:34.431689
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Initialize the class object
    bool_0 = True
    user_fact_collector_0 = UserFactCollector(bool_0)
    # Call the method
    # Get the test name
    test_name = test_UserFactCollector_collect.__name__
    # Initialize the output file
    out_file = open(test_name + ".out", "wb")
    # Print the output
    err_file = open(test_name + ".err", "wb")
    # Print the output
    print("%s" %(user_fact_collector_0.collect()), file = out_file )
    # Close the output file
    out_file.close()
    err_file.close()
    # Do the diff between the expected and the output file

# Generated at 2022-06-25 00:49:10.103566
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    bool_0 = False
    user_fact_collector_0 = UserFactCollector(bool_0)
    var_0 = user_fact_collector_0.collect()

    user_fact_collector_0.collect(module=None, collected_facts=None)


# Generated at 2022-06-25 00:49:12.529651
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    bool_0 = False
    user_fact_collector_0 = UserFactCollector(bool_0)
    user_fact_collector_0.collect()

# Generated at 2022-06-25 00:49:18.369231
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    bool_0 = False
    user_fact_collector_0 = UserFactCollector(bool_0)
    int_0 = 0
    dict_0 = {int_0: int_0}
    var_0 = user_fact_collector_0.collect(dict_0, dict_0)

# Generated at 2022-06-25 00:49:19.962497
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # calling instance of method collect
    user_fact_collector_0 = UserFactCollector(None)
    var_0 = user_fact_collector_0.collect()



# Generated at 2022-06-25 00:49:21.808425
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    bool_0 = False
    user_fact_collector_0 = UserFactCollector(bool_0)
    var_0 = user_fact_collector_0.collect()
    assert isinstance(var_0, dict)


# Generated at 2022-06-25 00:49:31.956678
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    bool_0 = False
    user_fact_collector_0 = UserFactCollector(bool_0)
    var_0 = user_fact_collector_0.collect()
    assert var_0['user_id'] == 'root'
    assert var_0['user_uid'] == 0
    assert var_0['user_gid'] == 0
    assert var_0['user_gecos'] == 'root'
    assert var_0['user_dir'] == '/root'
    assert var_0['user_shell'] == '/bin/bash'
    assert var_0['real_user_id'] == 0
    assert var_0['effective_user_id'] == 0
    assert var_0['real_group_id'] == 0
    assert var_0['effective_group_id'] == 0

# Generated at 2022-06-25 00:49:37.208703
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
  # Setup
  bool_0 = False
  user_fact_collector_0 = UserFactCollector(bool_0)
  
  # Invocation
  var_0 = user_fact_collector_0.collect()
  
  # Verification
  assert var_0 is not None


# Generated at 2022-06-25 00:49:40.692416
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    bool_0 = False
    user_fact_collector_0 = UserFactCollector(bool_0)
    # Test case with no arguments and expected result
    var_0 = user_fact_collector_0.collect()
    assert var_0 is not None, 'Var: var_0 is None'



# Generated at 2022-06-25 00:49:44.794616
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector(False)
    var_1 = user_fact_collector.collect()


# Generated at 2022-06-25 00:49:54.824614
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    bool_0 = True
    user_fact_collector_0 = UserFactCollector(bool_0)
    var_0 = user_fact_collector_0.collect()
    assert var_0['user_id'] == 'user_id'
    assert var_0['user_uid'] == 'user_uid'
    assert var_0['user_gid'] == 'user_gid'
    assert var_0['user_gecos'] == 'user_gecos'
    assert var_0['user_dir'] == 'user_dir'
    assert var_0['user_shell'] == 'user_shell'
    assert var_0['real_user_id'] == 'real_user_id'
    assert var_0['effective_user_id'] == 'effective_user_id'

# Generated at 2022-06-25 00:51:17.996580
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector(None)
    user_fact_collector_0.collect(collected_facts=None)

# Generated at 2022-06-25 00:51:19.835980
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # This test does not attempt to validate the data that is returned but only tests the method does not cause an exception.
    bool_0 = False
    user_fact_collector_0 = UserFactCollector(bool_0)
    var_0 = user_fact_collector_0.collect()


# Generated at 2022-06-25 00:51:21.152055
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    bool_0 = False
    user_fact_collector_0 = UserFactCollector(bool_0)
    # Test execution
    assert (isinstance(user_fact_collector_0.collect(), dict))

# Generated at 2022-06-25 00:51:25.103819
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    bool_0 = False
    user_fact_collector_0 = UserFactCollector(bool_0)
    var_0 = user_fact_collector_0.collect()
    bool_1 = True
    user_fact_collector_1 = UserFactCollector(bool_1)
    var_1 = user_fact_collector_1.collect()
    bool_2 = False
    user_fact_collector_2 = UserFactCollector(bool_2)
    var_2 = user_fact_collector_2.collect()
    bool_3 = True
    user_fact_collector_3 = UserFactCollector(bool_3)
    var_3 = user_fact_collector_3.collect()

# Generated at 2022-06-25 00:51:27.636977
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Instantiating the class
    var_1 = UserFactCollector()
    # Calling method collect of the class
    var_2 = var_1.collect()
    pass

# Generated at 2022-06-25 00:51:32.139958
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    expected_0 = {'real_group_id': 0, 'effective_user_id': 0, 'real_user_id': 0, 'effective_group_id': 0, 'user_dir': '/root', 'user_shell': '/bin/bash', 'user_gid': 0, 'user_uid': 0, 'user_gecos': 'root', 'user_id': 'root'}
    test_0 = UserFactCollector()
    true = test_0.collect()

    assert true == expected_0

# Generated at 2022-06-25 00:51:38.694979
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    user_fact_collector_0 = UserFactCollector(0)
    user_fact_collector_1 = UserFactCollector(0)
    user_fact_collector_2 = UserFactCollector(0)
    user_fact_collector_3 = UserFactCollector(0)
    user_fact_collector_4 = UserFactCollector(0)
    user_fact_collector_5 = UserFactCollector(0)
    user_fact_collector_6 = UserFactCollector(0)
    user_fact_collector_7 = UserFactCollector(0)
    user_fact_collector_8 = UserFactCollector(0)

    # Test with invalid value of module.
    # Expect an AttributeError.
    #var_0 = user_fact_collector_0.collect()

# Generated at 2022-06-25 00:51:40.361424
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    bool_0 = True
    user_fact_collector_0 = UserFactCollector(bool_0)
    var_0 = user_fact_collector_0.collect()
    assert var_0 == {}

# Generated at 2022-06-25 00:51:50.150552
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # all_facts = gather_subset
    bool_0 = False
    user_fact_collector_0 = UserFactCollector(bool_0)

    all_facts = user_fact_collector_0.collect()
    assert (all_facts['user_id']  == getpass.getuser())

    # all_facts = gather_subset
    bool_0 = False
    user_fact_collector_0 = UserFactCollector(bool_0)
    all_facts = user_fact_collector_0.collect()

    # Test not in gather_subset
    bool_0 = False
    user_fact_collector_0 = UserFactCollector(bool_0)
    all_facts = user_fact_collector_0.collect()

# Generated at 2022-06-25 00:51:52.879177
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    bool_0 = False
    user_fact_collector_0 = UserFactCollector(bool_0)
    var_0 = user_fact_collector_0.collect()
    assert isinstance(var_0, dict)
