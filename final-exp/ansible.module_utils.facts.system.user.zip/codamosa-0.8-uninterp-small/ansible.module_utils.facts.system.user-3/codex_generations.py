

# Generated at 2022-06-25 00:44:14.953243
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    # UserFactCollector.collect should return a dictionary
    user_fact_collector = UserFactCollector()
    output = user_fact_collector.collect()
    assert isinstance(output, dict)


# Generated at 2022-06-25 00:44:18.728126
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()


# Generated at 2022-06-25 00:44:28.560914
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    """Return facts about the current user."""
    user_fact_collector_0 = UserFactCollector()
    return_value_0 = user_fact_collector_0.collect()
    assert isinstance(return_value_0, dict)
    assert return_value_0['user_dir'] == '/home/vagrant'
    assert return_value_0['user_gid'] == 1000
    assert return_value_0['user_id'] == 'vagrant'
    assert return_value_0['user_uid'] == 1000
    assert return_value_0['user_gecos'] == 'vagrant,,,,'
    assert return_value_0['real_user_id'] == 1000
    assert return_value_0['effective_group_id'] == 1000

# Generated at 2022-06-25 00:44:29.972697
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    fact_result = user_fact_collector.collect()
    assert fact_result is not None, 'UserFactCollector.collect failed!'


# Generated at 2022-06-25 00:44:38.509220
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_facts = {'effective_group_ids': [0, 1000, 1001],
                  'effective_user_id': 1000,
                  'real_user_id': 1000,
                  'user_dir': '/home/stack',
                  'user_gid': 1000,
                  'user_gecos': 'stack,,,',
                  'user_id': 'stack',
                  'user_shell': '/bin/bash',
                  'user_uid': 1000}
    assert user_fact_collector_0.collect() == user_facts


# Generated at 2022-06-25 00:44:42.435926
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 00:44:47.736352
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()
    assert user_facts['user_id']
    assert user_facts['user_uid']
    assert user_facts['user_gid']
    assert user_facts['user_gecos']
    assert user_facts['user_dir']
    assert user_facts['user_shell']
    assert user_facts['real_user_id']
    assert user_facts['effective_user_id']

# Generated at 2022-06-25 00:44:55.045775
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Test collect method with valid data
    collector = UserFactCollector()
    module = AnsibleModule(
        argument_spec=dict()
    )
    valid_data = dict()
    collected_facts = dict()
    valid_data['user_id'] = getpass.getuser()
    valid_data['user_uid'] = valid_data['user_gid'] = 0
    valid_data['user_gecos'] = 'root'
    valid_data['user_dir'] = '/root'
    valid_data['user_shell'] = '/bin/bash'
    valid_data['real_user_id'] = 0
    valid_data['effective_user_id'] = 0
    valid_data['effective_group_ids'] = [0]

# Generated at 2022-06-25 00:45:00.448215
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # necessary to avoid errors due to running in a separate process
    try:
        pwd.getpwnam('test_user_0')
    except:
        pwd.getpwnam(os.getlogin())

    UserFactCollector_collect()

# Generated at 2022-06-25 00:45:05.535280
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    assert user_fact_collector_1.collect()

# Generated at 2022-06-25 00:45:15.495896
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()

    collected_facts = {}
    user_fact_collector_1.collect(collected_facts=collected_facts)

    assert collected_facts['user_id'] == getpass.getuser()
    assert collected_facts['real_user_id'] == os.getuid()
    assert collected_facts['effective_user_id'] == os.geteuid()
    assert collected_facts['real_group_id'] == os.getgid()
    assert collected_facts['effective_group_id'] == os.getgid()
    assert collected_facts['user_uid'] != None
    assert collected_facts['user_gid'] != None
    assert collected_facts['user_gecos'] != None
    assert collected_facts['user_dir'] != None

# Generated at 2022-06-25 00:45:17.717523
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    result_0 = user_fact_collector_0.collect()
    assert isinstance(result_0, dict)

# Generated at 2022-06-25 00:45:21.562576
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()
    user_fact_collector.collect(collector_facts=user_facts)


# Generated at 2022-06-25 00:45:30.316968
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Initialize a UserFactCollector object
    user_fact_collector = UserFactCollector()

    user_collect_result = {}

    user_collect_result['user_id'] = getpass.getuser()

    try:
        pwent = pwd.getpwnam(getpass.getuser())
    except KeyError:
        pwent = pwd.getpwuid(os.getuid())

    user_collect_result['user_uid'] = pwent.pw_uid
    user_collect_result['user_gid'] = pwent.pw_gid
    user_collect_result['user_gecos'] = pwent.pw_gecos
    user_collect_result['user_dir'] = pwent.pw_dir

# Generated at 2022-06-25 00:45:32.380135
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()

    user_fact_collector_0.collect()

# vim: set et ts=4 sw=4 :

# Generated at 2022-06-25 00:45:33.943097
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()

# Generated at 2022-06-25 00:45:39.047103
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_facts_dict = user_fact_collector_0.collect(module=None, collected_facts=None)
    return user_facts_dict


# Generated at 2022-06-25 00:45:41.098323
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_fact_collector.collect()

test_case_0()

# Generated at 2022-06-25 00:45:50.180295
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()

    user_facts = user_fact_collector.collect()
    assert type(user_facts) is dict
    assert 'user_id' in user_facts
    assert type(user_facts['user_id']) is str
    assert 'user_uid' in user_facts
    assert type(user_facts['user_uid']) is int
    assert 'user_gid' in user_facts
    assert type(user_facts['user_gid']) is int
    assert 'user_gecos' in user_facts
    assert type(user_facts['user_gecos']) is str
    assert 'user_dir' in user_facts
    assert type(user_facts['user_dir']) is str
    assert 'user_shell' in user_facts
    assert type

# Generated at 2022-06-25 00:45:52.951392
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_collect=UserFactCollector()
    user_fact_collector_collect.collect()


# Generated at 2022-06-25 00:46:02.885456
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_facts = user_fact_collector_1.collect(module=None, collected_facts=None)

    assert user_facts['user_id'] == 'root'
    assert user_facts['user_uid'] == 0
    assert user_facts['user_gid'] == 0
    assert user_facts['user_gecos'] == 'root'
    assert user_facts['user_dir'] == '/root'
    assert user_facts['user_shell'] == '/bin/bash'
    assert user_facts['real_user_id'] == 0
    assert user_facts['effective_user_id'] == 0
    assert user_facts['real_group_id'] == 0
    assert user_facts['effective_group_id'] == 0

# Generated at 2022-06-25 00:46:04.904054
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    try:
        assert os.getuid()
    except NotImplementedError:
        assert os.getuid() >= 0

# Generated at 2022-06-25 00:46:07.708907
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_fact_collector_1.collect()


# Generated at 2022-06-25 00:46:16.808142
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    # Setting up a mock of function getuser
    user_fact_collector_1 = UserFactCollector()
    getuser_method_body_1 = getpass.getuser()
    getuser_method_1 = getpass.getuser
    getuser_method_1 = getuser_method_1.__func__
    def getuser_mock_1():
        return getuser_method_body_1
    getpass.getuser = getuser_mock_1

    # Calling method collect
    user_fact_collector_1.collect()

    # Restoring getuser to original method
    getpass.getuser = getuser_method_1


# Generated at 2022-06-25 00:46:23.353179
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()
    assert(user_facts['user_id'] != None)
    assert(user_facts['user_uid'] != None)
    assert(user_facts['user_gid'] != None)
    assert(user_facts['user_gecos'] != None)
    assert(user_facts['user_dir'] != None)
    assert(user_facts['user_shell'] != None)
    assert(user_facts['real_user_id'] != None)
    assert(user_facts['effective_user_id'] != None)
    assert(user_facts['real_group_id'] != None)
    assert(user_facts['effective_group_id'] != None)

# Generated at 2022-06-25 00:46:25.208010
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()


# Generated at 2022-06-25 00:46:32.211245
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    assert user_fact_collector_1.collect() == {
        'effective_group_ids': [1000],
        'effective_user_id': 1000,
        'real_group_id': 1000,
        'real_user_id': 1000,
        'user_dir': '/home/vagrant',
        'user_gecos': 'vagrant,,,',
        'user_gid': 1000,
        'user_id': 'vagrant',
        'user_shell': '/bin/bash',
        'user_uid': 1000,
    }


# Generated at 2022-06-25 00:46:38.470076
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    collected_facts = {}

    user_facts = user_fact_collector_0.collect(collected_facts=collected_facts)

    user_id = user_facts['user_id']
    user_uid = user_facts['user_uid']
    user_gid = user_facts['user_gid']
    user_gecos = user_facts['user_gecos']
    user_dir = user_facts['user_dir']
    user_shell = user_facts['user_shell']
    real_user_id = user_facts['real_user_id']
    effective_user_id = user_facts['effective_user_id']
    real_group_id = user_facts['real_group_id']

# Generated at 2022-06-25 00:46:40.080349
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_fact_collector.collect()

# Generated at 2022-06-25 00:46:42.174100
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    assert isinstance(user_fact_collector_1.collect(), dict)


# Generated at 2022-06-25 00:46:58.430240
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = {}

    user_facts['user_id'] = getpass.getuser()

    try:
        pwent = pwd.getpwnam(getpass.getuser())
    except KeyError:
        pwent = pwd.getpwuid(os.getuid())

    user_facts['user_uid'] = pwent.pw_uid
    user_facts['user_gid'] = pwent.pw_gid
    user_facts['user_gecos'] = pwent.pw_gecos
    user_facts['user_dir'] = pwent.pw_dir
    user_facts['user_shell'] = pwent.pw_shell
    user_facts['real_user_id'] = os.getuid()
    user_facts['effective_user_id'] = os.geteu

# Generated at 2022-06-25 00:47:02.249893
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    try:
        test_case_0()
    except AttributeError as e:
        assert False and "The method 'test_UserFactCollector_collect' has failed"
    else:
        assert True


# Generated at 2022-06-25 00:47:04.193699
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Call the method to be tested
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()



# Generated at 2022-06-25 00:47:09.377354
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    test_case = UserFactCollector()
    result = test_case.collect()
    assert type(result) is dict
    assert result['user_id'] != ''
    assert type(result['user_uid']) is int
    assert type(result['user_gid']) is int
    assert result['user_dir'] != ''
    assert result['user_shell'] != ''
    assert type(result['real_user_id']) is int
    assert type(result['effective_user_id']) is int

# Generated at 2022-06-25 00:47:11.136017
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()


# Generated at 2022-06-25 00:47:12.484069
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_fact_collector.collect()

# Generated at 2022-06-25 00:47:16.269357
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()

    result = None

    try:
        result = user_fact_collector_0.collect()
    except:
        pass

    assert result is None


# Generated at 2022-06-25 00:47:19.133343
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fact_collector = UserFactCollector()
    fact_collector.collect()

if __name__ == '__main__':
    test_case_0()
    test_UserFactCollector_collect()

# Generated at 2022-06-25 00:47:22.152940
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    facts = {}
    test_fixture = UserFactCollector()
    test_fixture.collect(collected_facts=facts)
    assert test_fixture.name == 'user'
    assert user_fact_collector_0.name == 'user'

# Generated at 2022-06-25 00:47:26.422237
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    output_1 = set(['user_id', 'user_uid', 'user_gid',
                    'user_gecos', 'user_dir', 'user_shell',
                    'real_user_id', 'effective_user_id',
                    'effective_group_ids'])
    assert output_1 == user_fact_collector_1._fact_ids

# Generated at 2022-06-25 00:47:43.143481
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_facts_1 = user_fact_collector_1.collect()
    assert type(user_facts_1) == dict


# Generated at 2022-06-25 00:47:52.048096
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_facts = user_fact_collector_1.collect()
    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['user_uid'] == pwd.getpwnam(getpass.getuser()).pw_uid
    assert user_facts['user_gid'] == pwd.getpwnam(getpass.getuser()).pw_gid
    assert user_facts['user_gecos'] == pwd.getpwnam(getpass.getuser()).pw_gecos
    assert user_facts['user_dir'] == pwd.getpwnam(getpass.getuser()).pw_dir

# Generated at 2022-06-25 00:47:54.016561
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()


# Generated at 2022-06-25 00:48:02.287662
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    output = user_fact_collector.collect()
    expected_output =  {
        'real_group_id': 1000,
        'user_uid': 1000,
        'user_gecos': 'Administrator,,,',
        'effective_group_id': 1000,
        'user_shell': '/bin/bash',
        'user_id': 'root',
        'effective_user_id': 0,
        'user_gid': 1000,
        'real_user_id': 0,
        'user_dir': '/root'
    }
    assert(expected_output == output)


# Generated at 2022-06-25 00:48:07.154374
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()

    # Invalid type for the input parameter "collected_facts"
    try:
        user_fact_collector_1.collect(collected_facts = 1)
    except TypeError as result:
        print('Expected:', "unsupported operand type(s) for +=: 'dict' and 'int'")
        print('Actual  :', result)


# Generated at 2022-06-25 00:48:12.730058
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    collected_facts_0 = {'user_id': 'vagrant', 'user_uid': 1000, 'user_gecos': 'vagrant,,,', 'user_dir': '/home/vagrant', 'user_shell': '/bin/bash', 'effective_user_id': 1000, 'user_gid': 1000, 'real_user_id': 1000, 'effective_group_ids': [1000]}
    assert user_fact_collector_0.collect() == collected_facts_0


# Generated at 2022-06-25 00:48:19.815145
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()
    returned_keys = set(user_facts.keys())
    expected_keys = set(['effective_user_id', 'effective_group_id',
                         'user_uid', 'user_id', 'user_gecos', 'user_shell',
                         'user_gid', 'user_dir', 'real_user_id', 'real_group_id'])
    assert returned_keys == expected_keys


# Generated at 2022-06-25 00:48:22.078603
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_fact_collector.collect()


# Generated at 2022-06-25 00:48:30.142649
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    expected_dict = dict(user='root', user_id='root', user_uid=0, user_gid=0,
                         user_gecos='root', user_dir='/root',
                         user_shell='/bin/bash',
                         effective_user_id=0, real_user_id=0,
                         effective_group_id=0, real_group_id=0)
    user_fact_collector_1 = UserFactCollector()
    user_fact_collector_1.collect() == expected_dict
    assert type(user_fact_collector_1.collect()) is dict

# Generated at 2022-06-25 00:48:31.493707
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()

# Generated at 2022-06-25 00:49:05.269799
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_fact_collector_1.collect()

# Generated at 2022-06-25 00:49:06.187957
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    target = UserFactCollector(None, None)
    target.collect()

# Generated at 2022-06-25 00:49:12.941466
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    result_1 = user_fact_collector_1.collect()
    assert result_1['user_id'] == getpass.getuser()
    assert result_1['user_uid'] == os.getuid()
    assert result_1['user_gid'] == os.getgid()
    assert result_1['user_gecos'] == os.getlogin()
    assert result_1['user_dir'] == os.getcwd()
    assert result_1['user_shell'] == os.getenv('SHELL')
    assert result_1['real_user_id'] == os.getuid()
    assert result_1['effective_user_id'] == os.geteuid()
    assert result_1['real_group_id'] == os.getg

# Generated at 2022-06-25 00:49:14.433426
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()


# Generated at 2022-06-25 00:49:22.680914
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_facts = user_fact_collector_1.collect()
    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['user_uid'] == pwd.getpwnam(getpass.getuser()).pw_uid
    assert user_facts['user_gid'] == pwd.getpwnam(getpass.getuser()).pw_gid
    assert user_facts['user_gecos'] == pwd.getpwnam(getpass.getuser()).pw_gecos
    assert user_facts['user_dir'] == pwd.getpwnam(getpass.getuser()).pw_dir

# Generated at 2022-06-25 00:49:26.426675
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_fact_collector_1.collect()

# Generated at 2022-06-25 00:49:31.357207
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_facts_1 = user_fact_collector_1.collect(module=None, collected_facts=None)
    assert isinstance(user_facts_1, dict)
    assert 'effective_user_id' in user_facts_1
    assert 'user_gid' in user_facts_1
    assert 'real_user_id' in user_facts_1


# Generated at 2022-06-25 00:49:39.609022
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Check if UserFactCollector.collect return result
    # while UserFactCollector.name is set
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.name = 'user'

    assert(isinstance(user_fact_collector_0.collect(), dict))
    assert(user_fact_collector_0.collect()['user_id'] == user_fact_collector_0.collect()['real_user_id'])
    assert(user_fact_collector_0.collect()['user_id'] == user_fact_collector_0.collect()['effective_user_id'])

# Generated at 2022-06-25 00:49:41.189821
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()

# Generated at 2022-06-25 00:49:44.821137
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_facts = user_fact_collector_0.collect()


# Generated at 2022-06-25 00:51:00.584385
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()

# Generated at 2022-06-25 00:51:06.137896
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_collect = UserFactCollector()
    user_fact_collector_collect_out = user_fact_collector_collect.collect()
    return user_fact_collector_collect_out


# Generated at 2022-06-25 00:51:07.455082
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()

# Generated at 2022-06-25 00:51:11.677967
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    assert user_fact_collector_0.collect() != {}

# Generated at 2022-06-25 00:51:16.818856
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()


# Generated at 2022-06-25 00:51:22.900538
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    facts = user_fact_collector_0.collect()
    assert isinstance(facts, dict)
    assert set(facts.keys()) == set(['user_id', 'user_uid', 'user_gid', 'user_gecos', 'user_dir', 'user_shell', 'real_user_id', 'effective_user_id', 'real_group_id', 'effective_group_id'])

# Generated at 2022-06-25 00:51:27.671315
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    assert user_fact_collector_0.collect(module=None, collected_facts=None) is not None


# Generated at 2022-06-25 00:51:34.706493
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    result_fact_collector_1 = user_fact_collector_1.collect()
    assert result_fact_collector_1['user_id'] is not None
    assert isinstance(result_fact_collector_1['user_id'], str)
    assert result_fact_collector_1['user_uid'] is not None
    assert isinstance(result_fact_collector_1['user_uid'], int)
    assert result_fact_collector_1['user_gid'] is not None
    assert isinstance(result_fact_collector_1['user_gid'], int)
    assert result_fact_collector_1['user_gecos'] is not None

# Generated at 2022-06-25 00:51:36.199957
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()


# Generated at 2022-06-25 00:51:37.719564
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    user_fact_collector_0 = UserFactCollector()

    user_fact_collector_0.collect()
