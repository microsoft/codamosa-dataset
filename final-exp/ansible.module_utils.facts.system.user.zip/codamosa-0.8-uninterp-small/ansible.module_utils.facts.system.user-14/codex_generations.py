

# Generated at 2022-06-25 00:44:10.928428
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_fact_collector_1.collect()


# Generated at 2022-06-25 00:44:18.728690
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    try:
        # collect user facts and verify
        user_fact_collector_0 = UserFactCollector()
        user_facts = user_fact_collector_0.collect()
        assert user_facts['user_id'] is not None
        assert user_facts['user_uid'] is not None
        assert user_facts['user_gid'] is not None
        assert user_facts['user_gecos'] is not None
        assert user_facts['user_dir'] is not None
        assert user_facts['user_shell'] is not None
        assert user_facts['real_user_id'] is not None
        assert user_facts['effective_user_id'] is not None
        assert user_facts['effective_group_ids'] is not None
    except Exception as ex:
        pytest.PytestAssumeFailure(ex)


# Generated at 2022-06-25 00:44:27.824013
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    collected_facts = {}
    user_fact_collector.collect(collected_facts)
    assert 'user_id' in collected_facts
    assert 'user_uid' in collected_facts
    assert 'user_gid' in collected_facts
    assert 'user_gecos' in collected_facts
    assert 'user_dir' in collected_facts
    assert 'user_shell' in collected_facts
    assert 'real_user_id' in collected_facts
    assert 'effective_user_id' in collected_facts
    assert 'effective_group_ids' in collected_facts
    #print(collected_facts)

# Generated at 2022-06-25 00:44:34.548720
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_facts_0 = user_fact_collector_1.collect()
    assert user_facts_0['user_id'] == getpass.getuser()
    assert user_facts_0['user_id'] != ''
    assert user_facts_0['user_uid'] == pwent.pw_uid
    assert user_facts_0['user_uid'] != ''
    assert user_facts_0['user_gid'] == pwent.pw_gid
    assert user_facts_0['user_gid'] != ''
    assert user_facts_0['user_gecos'] == pwent.pw_gecos
    assert user_facts_0['user_gecos'] != ''
    assert user_facts_0['user_dir'] == pwent

# Generated at 2022-06-25 00:44:43.221550
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    set_var = user_fact_collector_0.collect()
    assert set_var['user_id'] == 'root'
    assert set_var['user_uid'] == 0
    assert set_var['user_gid'] == 0
    assert set_var['user_gecos'] == 'root'
    assert set_var['user_dir'] == '/root'
    assert set_var['user_shell'] == '/bin/bash'
    assert set_var['real_user_id'] == 0
    assert set_var['effective_user_id'] == 0
    assert set_var['real_group_id'] == 0
    assert set_var['effective_group_id'] == 0

# Generated at 2022-06-25 00:44:47.876758
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # create UserFactCollector object
    user_fact_collector_1 = UserFactCollector()

    # call collect()
    dict_1 = user_fact_collector_1.collect()
    print(dict_1)


# Generated at 2022-06-25 00:44:48.950804
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()

# Generated at 2022-06-25 00:44:50.642729
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_fact_collector_1.collect()


# Generated at 2022-06-25 00:44:54.682445
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_facts = user_fact_collector_0.collect()
    assert user_facts is not None, "Failed to collect user facts."

# Generated at 2022-06-25 00:45:00.102584
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    """ Unit test for method collect of class UserFactCollector """

    user_fact_collector = UserFactCollector()

    collected_facts = {}

    user_facts = user_fact_collector.collect(collected_facts=collected_facts)

    assert 'user_id' in user_facts
    assert 'user_uid' in user_facts
    assert 'user_gid' in user_facts
    assert 'user_gecos' in user_facts
    assert 'user_dir' in user_facts
    assert 'user_shell' in user_facts

# Generated at 2022-06-25 00:45:04.908088
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    assert 'user_gecos' in user_fact_collector_0.collect().keys()
#

# Generated at 2022-06-25 00:45:14.802852
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Arrange
    user_fact_collector = UserFactCollector()

    # Act
    result = user_fact_collector.collect()

    # Assert
    assert result['effective_group_id'] == os.getgid()
    assert result['effective_user_id'] == os.geteuid()
    assert result['real_group_id'] == os.getgid()
    assert result['real_user_id'] == os.getuid()
    assert result['user_dir'] == pwd.getpwuid(os.getuid()).pw_dir
    assert result['user_gecos'] == pwd.getpwuid(os.getuid()).pw_gecos
    assert result['user_gid'] == pwd.getpwuid(os.getuid()).pw_gid

# Generated at 2022-06-25 00:45:17.418496
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_facts = user_fact_collector_0.collect()
    assert user_facts['effective_user_id'] == 0

# Generated at 2022-06-25 00:45:26.808665
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    """Test collect() of UserFactCollector"""
    user_fact_collector = UserFactCollector()
    collected_facts = user_fact_collector.collect()
    expected_facts = {
        'effective_group_id': 1,
        'effective_user_id': 1,
        'real_group_id': 1,
        'real_user_id': 1,
        'user_dir': '/root',
        'user_gecos': 'root',
        'user_gid': 0,
        'user_id': 'root',
        'user_shell': '/bin/bash',
        'user_uid': 0
    }
    assert collected_facts == expected_facts

# Generated at 2022-06-25 00:45:28.900267
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    assert set(user_fact_collector.collect().keys()) == UserFactCollector._fact_ids


# Generated at 2022-06-25 00:45:31.226967
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_fact_collector_1.collect()

# Generated at 2022-06-25 00:45:33.411814
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()
    assert user_facts is not None


# Generated at 2022-06-25 00:45:35.925403
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    user_fact_collector_0 = UserFactCollector()

    collected_facts = {}

    user_fact_collector_0.collect(collected_facts=collected_facts)

    assert collected_facts.get('user')

# Generated at 2022-06-25 00:45:43.976688
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    user_fact_collector_0 = UserFactCollector()
    facts_dict = user_fact_collector_0.collect()

    assert not facts_dict == {}
    assert 'user_id' in facts_dict
    assert 'user_uid' in facts_dict
    assert 'user_gid' in facts_dict
    assert 'user_gecos' in facts_dict
    assert 'user_dir' in facts_dict
    assert 'user_shell' in facts_dict
    assert 'real_user_id' in facts_dict
    assert 'effective_user_id' in facts_dict
    assert 'effective_group_ids' in facts_dict



# Generated at 2022-06-25 00:45:50.207084
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_fact_collector.collect()
    # real_user_id of type int
    assert isinstance(user_fact_collector.collect().get('real_user_id'), int)
    assert isinstance(user_fact_collector.collect().get('effective_user_id'), int)
    # effective_group_ids of type list
    assert isinstance(user_fact_collector.collect().get('effective_group_ids'), list)
    assert isinstance(user_fact_collector.collect().get('user_shell'), str)

# Generated at 2022-06-25 00:45:59.032221
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()


# Generated at 2022-06-25 00:46:00.413947
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_fact_collector_1.collect()


# Generated at 2022-06-25 00:46:01.698139
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()

    user_fact_collector_0.collect()


# Generated at 2022-06-25 00:46:05.568540
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = {}
    user_fact_collector_1 = UserFactCollector()
    user_facts=user_fact_collector_1.collect()
    assert isinstance(user_facts,dict)

# Generated at 2022-06-25 00:46:09.980340
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()

    user_facts = user_fact_collector_0.collect()

    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['user_uid'] == os.getuid()
    assert user_facts['user_gid'] == os.getgid()


# Generated at 2022-06-25 00:46:18.334015
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_facts_1 = user_fact_collector_1.collect()
    assert type(user_facts_1) is dict
    assert 'user_id' in user_facts_1
    assert 'user_uid' in user_facts_1
    assert 'user_gid' in user_facts_1
    assert 'user_gecos' in user_facts_1
    assert 'user_dir' in user_facts_1
    assert 'user_shell' in user_facts_1
    assert 'real_user_id' in user_facts_1
    assert 'effective_user_id' in user_facts_1
    assert 'effective_group_ids' in user_facts_1

# Generated at 2022-06-25 00:46:22.895478
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_facts = user_fact_collector_1.collect()
    user_fact_collector_1.clear_deprecation_warnings()
    assert user_facts['real_user_id'] == os.getuid()


# Generated at 2022-06-25 00:46:23.719766
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    test_UserFactCollector_collect()

# Generated at 2022-06-25 00:46:32.356207
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()

    collected_facts = {}

    user_facts_1 = user_fact_collector_1.collect(collected_facts=collected_facts)

    assert 'user_id' in user_facts_1
    assert 'user_uid' in user_facts_1
    assert 'user_gid' in user_facts_1
    assert 'user_gecos' in user_facts_1
    assert 'user_dir' in user_facts_1
    assert 'user_shell' in user_facts_1
    assert 'real_user_id' in user_facts_1
    assert 'effective_user_id' in user_facts_1
    assert 'real_group_id' in user_facts_1
    assert 'effective_group_id' in user_facts

# Generated at 2022-06-25 00:46:33.358702
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()

# Generated at 2022-06-25 00:46:50.323971
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    tc_name = 'TestCase_0'
    fact_collector_name = 'user'
    fact_collector_obj = UserFactCollector()
    assert fact_collector_name == fact_collector_obj.name


# Generated at 2022-06-25 00:46:54.034798
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_collect_0 = UserFactCollector()

    try:
        user_fact_collector_collect_0.collect()
    except Exception as exception:
        assert False



# Generated at 2022-06-25 00:46:55.587268
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc_obj = UserFactCollector()
    assert isinstance(ufc_obj.collect(), dict)

# Generated at 2022-06-25 00:46:58.041049
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_collect_0 = UserFactCollector()
    user_fact_collector_collect_0.collect()


# Generated at 2022-06-25 00:47:03.653644
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_1 = UserFactCollector()
    user_fact_collector_0.collect()
    user_facts_0 = user_fact_collector_0.collect()
    user_facts_1 = user_fact_collector_1.collect()
    assert user_facts_0['user_id'] == user_facts_1['user_id']


# Generated at 2022-06-25 00:47:05.511681
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    assert user_fact_collector_0.collect() is not None



# Generated at 2022-06-25 00:47:13.135889
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_facts_collect = user_fact_collector_1.collect()
    assert user_facts_collect.has_key('user_id')
    assert user_facts_collect.has_key('user_uid')
    assert user_facts_collect.has_key('user_gid')
    assert user_facts_collect.has_key('user_gecos')
    assert user_facts_collect.has_key('user_dir')
    assert user_facts_collect.has_key('user_shell')
    assert user_facts_collect.has_key('real_user_id')
    assert user_facts_collect.has_key('effective_user_id')
    assert user_facts_collect.has_key('real_group_id')
    assert user

# Generated at 2022-06-25 00:47:23.261033
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    ansible_collected_facts = {}
    ansible_collected_facts['user_id'] = getpass.getuser()

    try:
        pwent = pwd.getpwnam(getpass.getuser())
    except KeyError:
        pwent = pwd.getpwuid(os.getuid())

    user_fact_collector.collect(ansible_collected_facts)
    assert ansible_collected_facts['user_uid'] == pwent.pw_uid
    assert ansible_collected_facts['user_gid'] == pwent.pw_gid
    assert ansible_collected_facts['user_gecos'] == pwent.pw_gecos
    assert ansible_collected_facts['user_dir']

# Generated at 2022-06-25 00:47:26.532282
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    '''
    Test method collect of module UserFactCollector
    '''

    user_fact_collector = UserFactCollector()
    result = user_fact_collector.collect()

    print("<result>\n%s\n</result>" % repr(result))


# Generated at 2022-06-25 00:47:32.973049
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_facts = user_fact_collector_1.collect()

    assert user_facts['user_id'] == getpass.getuser()

    try:
        pwent = pwd.getpwnam(getpass.getuser())
    except KeyError:
        pwent = pwd.getpwuid(os.getuid())

    assert user_facts['user_uid'] == pwent.pw_uid
    assert user_facts['user_gid'] == pwent.pw_gid
    assert user_facts['user_gecos'] == pwent.pw_gecos
    assert user_facts['user_dir'] == pwent.pw_dir
    assert user_facts['user_shell'] == pwent.pw_shell

# Generated at 2022-06-25 00:48:11.022499
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    print("\nTest collect")
    user_fact_collector_0 = UserFactCollector()
    user_facts = user_fact_collector_0.collect()
    print("Effective real  user id: " + str(user_facts["real_user_id"]) + " Effective user id: " + str(user_facts["effective_user_id"]) + " Effective real group id: " + str(user_facts["real_group_id"]) + " Effective group id: " + str(user_facts["effective_group_id"]))

# Main function
if __name__ == "__main__":
    print("\nTest UserFactCollector")
    test_case_0()
    test_UserFactCollector_collect()

# Generated at 2022-06-25 00:48:13.456080
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_facts = user_fact_collector_0.collect()
    assert isinstance(user_facts, dict)

# Generated at 2022-06-25 00:48:22.408995
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    returned_facts = user_fact_collector_0.collect()
    assert (getpass.getuser() == returned_facts['user_id'])
    assert returned_facts['user_uid'] >= 0
    assert returned_facts['user_gid'] >= 0
    assert returned_facts['user_gecos'] != ""
    assert returned_facts['user_dir'] != ""
    assert returned_facts['user_shell'] != ""
    assert returned_facts['real_user_id'] >= 0
    assert returned_facts['effective_user_id'] >= 0
    assert returned_facts['real_group_id'] >= 0
    assert returned_facts['effective_group_id'] >= 0


# Generated at 2022-06-25 00:48:32.107611
# Unit test for method collect of class UserFactCollector

# Generated at 2022-06-25 00:48:37.227768
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    collected_facts = user_fact_collector.collect()
    assert collected_facts['real_user_id'] == pwd.getpwnam(getpass.getuser()).pw_uid
    assert collected_facts['effective_user_id'] == os.geteuid()
    assert collected_facts['real_group_id'] == os.getgid()
    assert collected_facts['effective_group_id'] == os.getgid()
    assert collected_facts['user_shell'] == pwd.getpwnam(getpass.getuser()).pw_shell

# Generated at 2022-06-25 00:48:43.320494
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # init the class
    user_fact_collector_0 = UserFactCollector()

    # return data
    assert user_fact_collector_0.collect() == {
        'effective_group_ids': [0],
        'effective_user_id': 0,
        'real_group_id': 0,
        'real_user_id': 0,
        'user_dir': '/root',
        'user_gecos': 'root',
        'user_gid': 0,
        'user_id': 'root',
        'user_shell': '/bin/bash',
        'user_uid': 0
    }

# Generated at 2022-06-25 00:48:45.409672
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_name = getpass.getuser()
    facts = {}
    facts = user_fact_collector_1.collect(collected_facts=facts)
    assert facts['user_id'] == user_name

# Generated at 2022-06-25 00:48:50.249537
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()

    # If collect method of class UserFactCollector is invoked, then dictionary having key-value
    # pairs is returned
    assert type(user_fact_collector_0.collect()) is dict

# Generated at 2022-06-25 00:48:51.734817
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()



# Generated at 2022-06-25 00:48:57.395745
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()

    user_fact_collector_0.collect(module=None,
                                  collected_facts=None)

    # Testing variable user_id of type string
    assert isinstance(user_fact_collector_0.fact_subset['user_id'], str)
    # Testing variable user_uid of type int
    assert isinstance(user_fact_collector_0.fact_subset['user_uid'], int)
    # Testing variable user_gid of type int
    assert isinstance(user_fact_collector_0.fact_subset['user_gid'], int)
    # Testing variable user_gecos of type string
    assert isinstance(user_fact_collector_0.fact_subset['user_gecos'],
                      str)

# Generated at 2022-06-25 00:50:07.153249
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # TODO: implement unit test for UserFactCollector.collect
    assert True

# Generated at 2022-06-25 00:50:12.010353
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    # Input parameter for the method
    user_fact_collector_1 = UserFactCollector()
    collected_facts = {}

    # Invoke method
    user_fact_collector_1.collect(collected_facts)

    # Assert the return value
    assert(user_fact_collector_1.collect(collected_facts) == {'effective_group_ids': [0, 1], 'effective_user_id': 1234, 'real_user_id': 1234, 'user_gid': 0, 'user_gecos': 'root', 'user_shell': '/bin/bash', 'user_id': 'user1', 'user_uid': 1234, 'user_dir': '/root'})

# Generated at 2022-06-25 00:50:20.415528
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_facts = user_fact_collector_0.collect()
    assert 'user_id' in user_facts
    assert 'user_uid' in user_facts
    assert 'user_gid' in user_facts
    assert 'user_gecos' in user_facts
    assert 'user_dir' in user_facts
    assert 'user_shell' in user_facts
    assert 'real_user_id' in user_facts
    assert 'effective_user_id' in user_facts
    assert 'real_group_id' in user_facts
    assert 'effective_group_id' in user_facts
    return user_facts['user_id']


# Generated at 2022-06-25 00:50:22.178137
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()


test_case_0()
test_UserFactCollector_collect()

# Generated at 2022-06-25 00:50:22.883943
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    UserFactCollector.collect()

# Generated at 2022-06-25 00:50:26.636301
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    try:
        user_fact_collector_1 = UserFactCollector()
    except NameError:
        user_fact_collector_1 = None

    rval = False
    if (user_fact_collector_1 is not None):
        user_fact_collector_1.collect()
        rval = True

    assert rval == True


# Generated at 2022-06-25 00:50:33.600919
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Test UserFactCollector.collect()
    user_fact_collector_0 = UserFactCollector()
    user_fact_result_0 = user_fact_collector_0.collect()
    assert user_fact_result_0['user_id'] == getpass.getuser()
    assert user_fact_result_0['real_user_id'] == os.getuid()
    assert user_fact_result_0['effective_user_id'] == os.geteuid()
    assert user_fact_result_0['real_group_id'] == os.getgid()
    assert user_fact_result_0['effective_group_id'] == os.getgid()
    assert 'user_uid' in user_fact_result_0
    assert 'user_gid' in user_fact_result_0
   

# Generated at 2022-06-25 00:50:37.911844
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_fact_collector_1.collect()

# Generated at 2022-06-25 00:50:41.503472
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    collected_facts = user_fact_collector.collect()

    assert collected_facts['user_shell'] is not None, 'expected user shell got nothing'

# Generated at 2022-06-25 00:50:44.562529
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()

# Generated at 2022-06-25 00:52:06.331741
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    """Test the collect method of the UserFactCollector class."""

    # Test case where no module object is provided and
    # the user_id fact is missing from the collected facts.
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0._collected_facts = {}
    var_0 = user_fact_collector_0.collect()

    assert var_0['user_id'] is not None
    assert var_0['user_uid'] is not None
    assert var_0['user_gid'] is not None
    assert var_0['user_gecos'] is not None
    assert var_0['user_dir'] is not None
    assert var_0['user_shell'] is not None
    assert var_0['real_user_id'] is not None
    assert var_

# Generated at 2022-06-25 00:52:11.160727
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    new_user_facts = UserFactCollector()
    new_user_facts.collect()

# Generated at 2022-06-25 00:52:17.582196
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()

    # Invoke method
    var_0 = user_fact_collector_0.collect()
    # Check the output
    assert var_0['effective_group_id'] == os.getgid()
    assert var_0['effective_group_ids'] == []
    assert var_0['effective_user_id'] == os.geteuid()
    assert var_0['real_group_id'] == os.getgid()
    assert var_0['real_user_id'] == os.getuid()
    assert var_0['user_dir'] == pwd.getpwuid(os.getuid()).pw_dir
    assert var_0['user_gecos'] == pwd.getpwuid(os.getuid()).pw_ge

# Generated at 2022-06-25 00:52:20.569193
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    var_1 = user_fact_collector_1.collect()
    assert type(var_1) == dict


# Generated at 2022-06-25 00:52:23.456334
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # TODO: Make a proper test case
    var_1 = UserFactCollector()
    var_1.collect()


# Generated at 2022-06-25 00:52:27.897755
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Call function collect of object user_fact_collector
    test_case_0()


# Generated at 2022-06-25 00:52:30.020277
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    var_1 = UserFactCollector()
    var_2 = var_1.collect()
    if var_2 == {}:
        var_3 = True
    else:
        var_3 = False
    assert var_3


# Generated at 2022-06-25 00:52:35.885567
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect()
    assert var_0 is not False


# Generated at 2022-06-25 00:52:36.232253
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    pass

# Generated at 2022-06-25 00:52:37.107551
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_fact_collector.collect()
