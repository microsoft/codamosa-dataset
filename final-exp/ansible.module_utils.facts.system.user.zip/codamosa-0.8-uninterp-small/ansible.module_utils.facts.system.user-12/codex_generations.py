

# Generated at 2022-06-25 00:44:15.675299
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector

    user_fact_collector_1 = UserFactCollector()
    facts_collector_0 = FactsCollector()
    facts_collector_0.collectors.append(user_fact_collector_1)
    facts_dict = facts_collector_0.collect(module=None, collected_facts=None)
    assert type(facts_dict) is dict

# Generated at 2022-06-25 00:44:24.368407
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_facts_1 = user_fact_collector_1.collect()
    assert(user_facts_1['user_id'] == getpass.getuser())
    assert(user_facts_1['user_uid'] == pwd.getpwuid(os.getuid()).pw_uid)
    assert(user_facts_1['user_gid'] == pwd.getpwuid(os.getuid()).pw_gid)
    assert(user_facts_1['user_gecos'] == pwd.getpwuid(os.getuid()).pw_gecos)
    assert(user_facts_1['user_dir'] == pwd.getpwuid(os.getuid()).pw_dir)

# Generated at 2022-06-25 00:44:33.934026
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_fact_collector_response = user_fact_collector.collect()
    assert isinstance(user_fact_collector_response, dict)
    assert user_fact_collector_response == {'effective_group_ids': [0, 6, 24, 27, 30, 46, 81], 'real_group_id': 0, 'user_gecos': 'User &', 'user_gid': 0, 'user_dir': '/var/empty', 'user_uid': 0, 'user_id': 'root', 'user_shell': '/usr/bin/false', 'effective_user_id': 0, 'real_user_id': 0}

# Generated at 2022-06-25 00:44:36.041791
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_fact_collector_1.collect()


# Generated at 2022-06-25 00:44:43.057601
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    fact = user_fact_collector_1.collect()
    assert fact['user_id'] != ''
    assert fact['user_uid'] != ''
    assert fact['user_gid'] != ''
    assert fact['user_gecos'] != ''
    assert fact['user_dir'] != ''
    assert fact['user_shell'] != ''
    assert fact['real_user_id'] != ''
    assert fact['effective_user_id'] != ''
    assert fact['effective_group_ids'] != ''

# Generated at 2022-06-25 00:44:53.035314
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_fact_collector_collect.user_id = getpass.getuser()
    user_fact_collector_collect.user_uid = pwent.pw_uid
    user_fact_collector_collect.user_gid = pwent.pw_gid
    user_fact_collector_collect.user_gecos = pwent.pw_gecos
    user_fact_collector_collect.user_dir = pwent.pw_dir
    user_fact_collector_collect.user_shell = pwent.pw_shell
    user_fact_collector_collect.real_user_id = os.getuid()
    user_fact_collector_collect.effective_user_id = os.geteuid()
    user_fact_

# Generated at 2022-06-25 00:44:58.076356
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    result = user_fact_collector_1.collect()
    assert set(result.keys()) == set(['user_id', 'user_uid', 'user_gid', 'user_gecos',
                                      'user_dir', 'user_shell', 'real_user_id', 'effective_user_id',
                                      'real_group_id', 'effective_group_id'])

    assert result['user_id'] == getpass.getuser()

# Generated at 2022-06-25 00:45:02.090063
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    response = user_fact_collector_1.collect()
    assert 'user_uid' in response
    assert 'user_gid' in response
    assert 'user_gecos' in response
    assert 'user_dir' in response
    assert 'user_shell' in response

# Generated at 2022-06-25 00:45:02.768860
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    test_case_0()


# Generated at 2022-06-25 00:45:05.979191
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()

# Generated at 2022-06-25 00:45:13.110973
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_collect = UserFactCollector()
    result = user_fact_collector_collect.collect()
    assert type(result) == dict


# Generated at 2022-06-25 00:45:24.367704
# Unit test for method collect of class UserFactCollector

# Generated at 2022-06-25 00:45:32.838239
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_fact_collector_collected_facts = user_fact_collector.collect()
    assert user_fact_collector_collected_facts['real_user_id'] == os.getuid()
    assert user_fact_collector_collected_facts['effective_user_id'] == os.geteuid()
    assert user_fact_collector_collected_facts['real_group_id'] == os.getgid()
    assert user_fact_collector_collected_facts['effective_group_id'] == os.getegid()
    assert user_fact_collector_collected_facts['user_id'] == getpass.getuser()

# Generated at 2022-06-25 00:45:34.538470
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()

# Generated at 2022-06-25 00:45:38.384191
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    assert len(user_fact_collector_1.collect().keys()) is not 0


# Generated at 2022-06-25 00:45:47.781951
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_fact = user_fact_collector_1.collect()

    # Check method collect returns 'dict'
    assert type(user_fact) == dict
    assert 'user_id' in user_fact.keys()
    assert 'user_uid' in user_fact.keys()
    assert 'user_gid' in user_fact.keys()
    assert 'user_gecos' in user_fact.keys()
    assert 'user_dir' in user_fact.keys()
    assert 'user_shell' in user_fact.keys()
    assert 'real_user_id' in user_fact.keys()
    assert 'effective_user_id' in user_fact.keys()
    assert 'effective_group_ids' in user_fact.keys()

# Generated at 2022-06-25 00:45:56.256916
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()

    pwent = pwd.getpwuid(os.getuid())

# Generated at 2022-06-25 00:46:00.659836
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()
    assert user_facts.get('user_id')
    assert user_facts.get('user_uid')
    assert user_facts.get('user_gid')
    assert user_facts.get('user_gecos')
    assert user_facts.get('user_dir')
    assert user_facts.get('user_shell')
    assert user_facts.get('real_user_id')
    assert user_facts.get('effective_user_id')

# Generated at 2022-06-25 00:46:03.206446
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Test case 0:
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0_user_id = user_fact_collector_0.collect()['user_id']
    assert user_fact_collector_0_user_id == getpass.getuser()


# Generated at 2022-06-25 00:46:06.804754
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import pwd
    user_fact_collector_1 = UserFactCollector()
    print(user_fact_collector_1.collect())


# Generated at 2022-06-25 00:46:14.768490
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()


# Generated at 2022-06-25 00:46:19.930300
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    dict_0 = user_fact_collector_0.collect()
    assert dict_0 == {'effective_user_id': 1000, 'user_dir': '/home/ubuntu', 'user_gid': 1000, 'effective_group_id': 1000, 'user_id': 'ubuntu', 'user_uid': 1000, 'real_user_id': 1000, 'user_gecos': 'Ubuntu', 'real_group_id': 1000, 'user_shell': '/bin/bash'}

# Generated at 2022-06-25 00:46:25.280274
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    r"""
    Unit test for method collect of class UserFactCollector
    """
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()
    user_fact_collector_0.collect()
    user_facts_1 = user_fact_collector_0.collect()
    user_facts_1 = user_fact_collector_0.collect()

# Generated at 2022-06-25 00:46:26.228064
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    assert user_fact_collector.collect() is not None

# Generated at 2022-06-25 00:46:30.097679
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    assert user_fact_collector.collect() == {
        'effective_group_id': 0,
        'effective_user_id': 0,
        'real_group_id': 0,
        'real_user_id': 0,
        'user_dir': '/root',
        'user_gid': 0,
        'user_gecos': 'root',
        'user_id': 'root',
        'user_shell': '/bin/bash',
        'user_uid': 0
    }

# Generated at 2022-06-25 00:46:37.429464
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    assert user_fact_collector_0.collect() == {'user_id': 'pwalsh', 'user_uid': 1000, 'user_gid': 1000, 'user_gecos': 'Peter Walsh', 'user_dir': '/home/pwalsh', 'user_shell': '/bin/bash', 'real_user_id': 1000, 'effective_user_id': 1000, 'real_group_id': 1000, 'effective_group_id': 1000}


# Generated at 2022-06-25 00:46:45.596325
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    test_arg_1 = None
    test_arg_2 = None
    result_1 = user_fact_collector_1.collect(test_arg_1, test_arg_2)
    assert type(result_1) is dict
    assert result_1 == {'effective_user_id': 1000,
                        'effective_group_ids': [1000],
                        'real_group_id': 1000,
                        'real_user_id': 1000,
                        'user_gecos': 'osboxes,,,',
                        'user_gid': 1000,
                        'user_id': 'osboxes',
                        'user_dir': '/home/osboxes',
                        'user_uid': 1000,
                        'user_shell': '/bin/bash'
                    }

# Generated at 2022-06-25 00:46:53.265932
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    result = user_fact_collector.collect()
    assert 'user_id' in result
    assert 'user_gid' in result
    assert 'user_gecos' in result
    assert 'user_dir' in result
    assert 'user_shell' in result
    assert 'real_user_id' in result
    assert 'effective_user_id' in result
    assert 'real_group_id' in result
    assert 'effective_group_id' in result

# Generated at 2022-06-25 00:46:55.176580
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()


# Generated at 2022-06-25 00:47:04.505712
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    expected_user_facts = {
        'user_id': 'ansible',
        'user_uid': 1000,
        'user_gid': 1000,
        'user_gecos': 'ansible',
        'user_dir': '/home/ansible',
        'user_shell': '/bin/bash',
        'real_user_id': 1000,
        'effective_user_id': 1000,
        'real_group_id': 1000,
        'effective_group_id': 1000
    }
    user_fact_collector_1 = UserFactCollector()
    user_fact_collector_1_ansible_user_facts = user_fact_collector_1.collect()
    assert user_fact_collector_1_ansible_user_facts == expected_user_facts


# Generated at 2022-06-25 00:47:25.874123
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    result = user_fact_collector_0.collect(None, None)
    assert result['user_id'] == getpass.getuser()
    assert result['user_uid'] == pwd.getpwuid(os.getuid())[2]
    assert result['user_gid'] == pwd.getpwuid(os.getuid())[3]
    assert result['user_gecos'] == pwd.getpwuid(os.getuid())[4]
    assert result['user_dir'] == pwd.getpwuid(os.getuid())[5]
    assert result['user_shell'] == pwd.getpwuid(os.getuid())[6]
    assert result['real_user_id'] == os.getuid()

# Generated at 2022-06-25 00:47:32.620688
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    collected_facts = {'some_previous_fact': 'some_previous_fact_value'}
    user_facts = user_fact_collector_0.collect(collected_facts=collected_facts)
    assert collected_facts == {'some_previous_fact': 'some_previous_fact_value'}
    assert 'user_id' in user_facts
    assert 'user_uid' in user_facts
    assert 'user_gid' in user_facts
    assert 'user_gecos' in user_facts
    assert 'user_dir' in user_facts
    assert 'user_shell' in user_facts
    assert 'real_user_id' in user_facts
    assert 'effective_user_id' in user_facts
   

# Generated at 2022-06-25 00:47:40.138785
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    facts = user_fact_collector.collect()
    assert facts['user_id'] == getpass.getuser()
    assert 'user_uid' in facts
    assert 'user_gid' in facts
    assert 'user_gecos' in facts
    assert 'user_dir' in facts
    assert 'user_shell' in facts
    assert 'real_user_id' in facts
    assert 'effective_user_id' in facts
    assert 'real_group_id' in facts
    assert 'effective_group_id' in facts

# Generated at 2022-06-25 00:47:47.153941
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_collect_0 = UserFactCollector()
    assert user_fact_collector_collect_0.collect() == {'effective_group_ids': [100, 101, 103], 'user_gid': 100, 'user_uid': 1000, 'user_id': 'ansible', 'user_gecos': 'ansible', 'real_user_id': 1000, 'effective_user_id': 1000, 'real_group_id': 100, 'user_dir': '/home/ansible', 'user_shell': '/bin/bash'}


# Generated at 2022-06-25 00:47:49.548905
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    print(user_fact_collector_1.collect())

test_case_0()
test_UserFactCollector_collect()

# Generated at 2022-06-25 00:47:51.213380
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
#   user_fact_collector_0.collect()

# Generated at 2022-06-25 00:47:52.806011
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    assert user_fact_collector.collect()['user_uid'] == os.getuid()

# Generated at 2022-06-25 00:47:57.149735
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    dict_0 = user_fact_collector_0.collect()
    assert 'user_id' in dict_0.keys()


# Generated at 2022-06-25 00:48:00.216849
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()

    collected_facts = {}
    module = ansible_module_for_test_0
    user_fact_collector_1.collect(module=module, collected_facts=collected_facts)

# Usage example

# Generated at 2022-06-25 00:48:04.495255
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Create an instance of UserFactCollector
    # This will not work for user names with spaces in them
    user_fact_collector_0 = UserFactCollector()
    # Get the facts from UserFactCollector instance
    user_fact = user_fact_collector_0.collect()
    print(user_fact)
    # Validate the value of user_facts['user_dir']
    assert user_fact['user_dir'] == '/home/ansible'

# Generated at 2022-06-25 00:48:35.823369
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    collected_facts_1 = user_fact_collector_1.collect()
    assert (collected_facts_1['user_id'] == getpass.getuser())
    assert (collected_facts_1['user_uid'] == os.getuid())
    assert (collected_facts_1['user_gid'] == os.getgid())
    assert (collected_facts_1['user_gecos'] == pwd.getpwnam(getpass.getuser()).pw_gecos)
    assert (collected_facts_1['user_dir'] == pwd.getpwnam(getpass.getuser()).pw_dir)

# Generated at 2022-06-25 00:48:39.635297
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc0 = UserFactCollector()
    ufc1 = UserFactCollector()
    assert sorted(['user_id', 'user_uid', 'user_gid', 'user_gecos', 'user_dir', 'user_shell', 'real_user_id', 'effective_user_id', 'effective_group_ids']) == sorted(ufc0.collect())
    assert sorted(['user_id', 'user_uid', 'user_gid', 'user_gecos', 'user_dir', 'user_shell', 'real_user_id', 'effective_user_id', 'effective_group_ids']) == sorted(ufc1.collect())


# Generated at 2022-06-25 00:48:42.082104
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_facts = user_fact_collector_0.collect()
    assert user_facts is not None
    assert user_facts['user_id'] == getpass.getuser()


test_case_0()
test_UserFactCollector_collect()

# Generated at 2022-06-25 00:48:43.418417
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_fact_collector_1.collect()


# Generated at 2022-06-25 00:48:44.236395
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_fact_collector_1.collect()

# Generated at 2022-06-25 00:48:49.365538
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()

    return

# Generated at 2022-06-25 00:48:53.915412
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()

# Generated at 2022-06-25 00:48:56.176008
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()
    user_id = user_facts['user_id']

    assert(user_id)
    assert(user_id == getpass.getuser())


# Generated at 2022-06-25 00:49:01.041600
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_fact_collector_collect = user_fact_collector.collect()
    assert 'user_id' in user_fact_collector_collect


# Generated at 2022-06-25 00:49:02.416442
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()


# Generated at 2022-06-25 00:50:07.481280
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()
    assert 'user_id' in user_facts
    assert 'user_uid' in user_facts
    assert 'user_gid' in user_facts
    assert 'user_gecos' in user_facts
    assert 'user_dir' in user_facts
    assert 'user_shell' in user_facts

# Generated at 2022-06-25 00:50:12.826359
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    dict_1 = user_fact_collector_1.collect()
    assert dict_1['user_id'] == getpass.getuser(), 'given command\'s output not matching with output of getuser()'
    assert 'user_uid' in dict_1, 'user_uid fact missing'
    assert 'user_gid' in dict_1, 'user_gid fact missing'
    assert 'user_gecos' in dict_1, 'user_gecos fact missing'
    assert 'user_dir' in dict_1, 'user_dir fact missing'
    assert 'user_shell' in dict_1, 'user_shell fact missing'
    assert 'real_user_id' in dict_1, 'real_user_id fact missing'

# Generated at 2022-06-25 00:50:19.771318
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_facts = user_fact_collector_1.collect()
    assert 'user_id' in user_facts
    assert 'user_uid' in user_facts
    assert 'user_gid' in user_facts
    assert 'user_gecos' in user_facts
    assert 'user_dir' in user_facts
    assert 'user_shell' in user_facts
    assert 'real_user_id' in user_facts
    assert 'effective_user_id' in user_facts

# Generated at 2022-06-25 00:50:26.666659
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    test_user_facts_0 = user_fact_collector.collect()
    assert 'user_id' in test_user_facts_0
    assert 'user_uid' in test_user_facts_0
    assert 'user_gid' in test_user_facts_0
    assert 'user_gecos' in test_user_facts_0
    assert 'user_dir' in test_user_facts_0
    assert 'user_shell' in test_user_facts_0
    assert 'real_user_id' in test_user_facts_0
    assert 'effective_user_id' in test_user_facts_0
    assert 'effective_group_ids' in test_user_facts_0

# Generated at 2022-06-25 00:50:33.634218
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    this_username = getpass.getuser()  # Returns the username of the user
    user_fact_collector = UserFactCollector()
    test_case_1 = user_fact_collector.collect()

    assert test_case_1['user_id'] == this_username
    assert test_case_1['user_uid'] == pwd.getpwnam(this_username).pw_uid
    assert test_case_1['user_gid'] == pwd.getpwnam(this_username).pw_gid
    assert test_case_1['user_gecos'] == pwd.getpwnam(this_username).pw_gecos
    assert test_case_1['user_dir'] == pwd.getpwnam(this_username).pw_dir
    assert test_case_1

# Generated at 2022-06-25 00:50:43.733345
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import pytest

    # Test with mocked module
    user_fact_collector = UserFactCollector()

    # Mock the execute method to control its behavior
    from ansible.module_utils.facts import collector
    collector.exec_command = mock.Mock(return_value=('passwd\n', '', 0))

    # Invoke the method under test
    result = user_fact_collector.collect()

    # Method collect always returns a dict
    assert isinstance(result, dict)

    # Test with mocked module
    user_fact_collector = UserFactCollector()

    # Mock the execute method to control its behavior
    from ansible.module_utils.facts import collector
    collector.exec_command = mock.Mock(return_value=('passwd\n', '', -1))

    # Invoke the method under test

# Generated at 2022-06-25 00:50:45.612840
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_fact_collector.collect()
    assert isinstance(user_fact_collector._facts, dict)


# Generated at 2022-06-25 00:50:49.761192
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_collect_0 = UserFactCollector()

    user_fact_collector_collect_0.collect()

# Generated at 2022-06-25 00:50:56.816121
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Test case 0
    user_fact_collector_0 = UserFactCollector()
    user_facts = user_fact_collector_0.collect()
    assert isinstance(user_facts, dict)
    assert set(user_facts.keys()) == set(['user_id', 'user_uid', 'user_gid',
                                          'user_gecos', 'user_dir', 'user_shell',
                                          'real_user_id', 'effective_user_id',
                                          'real_group_id', 'effective_group_id'])

# Generated at 2022-06-25 00:51:01.488963
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    assert user_fact_collector_0.collect() == {'effective_group_id': 20, 'user_uid': 1000, 'real_user_id': 1000, 'user_id': 'jryans', 'user_gecos': 'John Ryan,,,', 'user_shell': '/bin/zsh', 'real_group_id': 20, 'effective_user_id': 1000, 'user_gid': 20, 'user_dir': '/Users/jryans'}


# Generated at 2022-06-25 00:53:33.077749
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_fact_collector_1.collect()
    user_fact_collector_1.name
    user_fact_collector_1._fact_ids

# Generated at 2022-06-25 00:53:34.626691
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    assert user_fact_collector_1.collect() == user_fact_collector_1.collect()

# Generated at 2022-06-25 00:53:37.694580
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_fact_collector.collect()

# Generated at 2022-06-25 00:53:39.305695
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    # Test the case where the class raises no exceptions
    user_fact_collector_1.collect()



# Generated at 2022-06-25 00:53:48.218143
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    result_1 = user_fact_collector_1.collect()

    assert(result_1['user_id'] == getpass.getuser())
    assert(result_1['user_uid'] == pwd.getpwuid(os.getuid()).pw_uid)
    assert(result_1['user_gid'] == pwd.getpwuid(os.getuid()).pw_gid)
    assert(result_1['user_gecos'] == pwd.getpwuid(os.getuid()).pw_gecos)
    assert(result_1['user_dir'] == pwd.getpwuid(os.getuid()).pw_dir)

# Generated at 2022-06-25 00:53:55.875538
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    # Run the collect() method of UserFactCollector on a UserFactCollector object
    result = user_fact_collector_0.collect()

    # Test the values of the UserFactCollector object attributes
    assert type(result) is dict
    assert len(result.keys()) is 9
    assert result['user_id'] == getpass.getuser()
    assert result['user_uid'] == os.getuid()
    assert result['user_gid'] == os.getgid()
    assert result['user_gecos'] == pwd.getpwuid(os.getuid())[4]
    assert result['user_dir'] == pwd.getpwuid(os.getuid())[5]
    assert result['user_shell'] == pwd.getpwuid(os.getuid())[6]
    assert result

# Generated at 2022-06-25 00:54:01.879128
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    user_fact_collector_0 = UserFactCollector()
    collected_facts = {}
    user_facts = user_fact_collector_0.collect(collected_facts=collected_facts)
    assert type(user_facts) is dict
    assert 'user_id' in user_facts


# Generated at 2022-06-25 00:54:03.246109
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    assert user_fact_collector_1.collect()

# Generated at 2022-06-25 00:54:08.094230
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()


# Generated at 2022-06-25 00:54:14.773969
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    test_cases = [0]
    for test_case in test_cases:
        try:
            if test_case == 0:
                user_fact_collector_0.collect()
        except Exception as exception:
            print('Exception: ' + str(exception))
            raise

