

# Generated at 2022-06-25 00:44:23.652806
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_facts_0 = user_fact_collector_1.collect()
    assert user_facts_0 == {'effective_group_id': 1000, 'effective_group_ids': [1000, 4, 24, 27, 30, 46, 113, 128, 1000], 'effective_user_id': 1000, 'real_group_id': 1000, 'real_user_id': 1000, 'user_dir': '/home/nunabe', 'user_gid': 1000, 'user_gecos': 'Taro Nunabe,,,', 'user_id': 'nunabe', 'user_shell': '/bin/bash', 'user_uid': 1000}
    assert isinstance(user_facts_0, dict)

# Generated at 2022-06-25 00:44:33.572587
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_fact_collector_result_1 = {
        'user_gecos': 'vagrant',
        'user_dir': '/home/vagrant',
        'user_id': 'vagrant',
        'user_gid': 1000,
        'user_uid': 1000,
        'user_shell': '/bin/bash',
        'real_user_id': 1000,
        'effective_group_id': 1000,
        'real_group_id': 1000,
        'effective_user_id': 1000
    }

    assert set(user_fact_collector_1.collect().keys()) == set(user_fact_collector_result_1.keys())

# Generated at 2022-06-25 00:44:43.396517
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    for i in range(0, 2):
        facts_collector = FactsCollector(None, None)
        user_fact_collector_1 = UserFactCollector()
        result = user_fact_collector_1.collect(None, facts_collector)
        assert result.get('user_id') is not None
        assert result.get('user_uid') is not None
        assert result.get('user_gid') is not None
        assert result.get('user_gecos') is not None
        assert result.get('user_dir') is not None
        assert result.get('user_shell') is not None
        assert result.get('real_user_id') is not None
        assert result.get('effective_user_id') is not None

# Generated at 2022-06-25 00:44:53.025023
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_facts = user_fact_collector_1.collect()
    assert isinstance(user_facts, dict)
    assert 'user_id' in user_facts
    assert isinstance(user_facts['user_id'], basestring)
    assert 'user_uid' in user_facts
    assert isinstance(user_facts['user_uid'], int)
    assert 'user_gid' in user_facts
    assert isinstance(user_facts['user_gid'], int)
    assert 'user_gecos' in user_facts
    assert isinstance(user_facts['user_gecos'], basestring)
    assert 'user_dir' in user_facts
    assert isinstance(user_facts['user_dir'], basestring)

# Generated at 2022-06-25 00:44:58.059696
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()
    assert user_facts["user_id"] == "ansible"
    assert user_facts["user_uid"] == 1000
    assert user_facts["user_gid"] == 1000
    assert user_facts["user_gecos"] == "ansible,,,"
    assert user_facts["user_dir"] == "/home/ansible"
    assert user_facts["user_shell"] == "/bin/bash"
    assert user_facts["real_user_id"] == 1000
    assert user_facts["effective_user_id"] == 1000
    assert user_facts["real_group_id"] == 1000
    assert user_facts["effective_group_id"] == 1000

# Generated at 2022-06-25 00:45:02.969516
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    collected_facts = {}
    collected_facts['os'] = {}
    collected_facts['os']['distribution'] = 'CentOS'
    collected_facts['os']['distribution_major_version'] = '7'
    collected_facts['os']['distribution_version'] = '7.2.1511'
    collected_facts['os']['name'] = 'CentOS'
    collected_facts['os']['family'] = 'RedHat'
    collected_facts['os']['release'] = {}
    collected_facts['os']['release']['major'] = '7'
    collected_facts['os']['release']['full'] = '7.2.1511'

# Generated at 2022-06-25 00:45:06.190929
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_facts = user_fact_collector_1.collect()

    assert user_facts
    assert user_facts['user_id']
    assert user_facts['user_uid']
    assert user_facts['user_gid']
    assert user_facts['user_gecos']
    assert user_facts['user_dir']
    assert user_facts['user_shell']
    assert user_facts['real_user_id']
    assert user_facts['effective_user_id']
    assert user_facts['effective_group_ids']

# Generated at 2022-06-25 00:45:13.897442
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    result = user_fact_collector_1.collect()
    assert 'user_id' in result
    assert 'user_uid' in result
    assert 'user_gid' in result
    assert 'user_gecos' in result
    assert 'user_dir' in result
    assert 'user_shell' in result
    assert 'real_user_id' in result
    assert 'effective_user_id' in result
    assert 'effective_group_ids' in result

# Generated at 2022-06-25 00:45:15.663721
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()

# Generated at 2022-06-25 00:45:16.870275
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    assert UserFactCollector().collect() is not None

# Generated at 2022-06-25 00:45:23.002914
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()


handler = UserFactCollector
test_case_0()
test_UserFactCollector_collect()

# Generated at 2022-06-25 00:45:25.114381
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    result = user_fact_collector_1.collect()


# Generated at 2022-06-25 00:45:26.849995
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    assert isinstance(user_fact_collector_1.collect(), dict)


# Generated at 2022-06-25 00:45:29.533525
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()

    user_facts = user_fact_collector_1.collect()

    assert len(user_facts) > 1

if __name__ == '__main__':
    pytest.main()

# Generated at 2022-06-25 00:45:34.206627
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_collector = UserFactCollector()
    user_facts = user_collector.collect()
    keys_to_check = ['user_id', 'user_gid', 'user_dir',
                     'user_shell', 'user_uid']
    for key in keys_to_check:
        assert key in user_facts
        assert isinstance(user_facts[key], (int, str))


# Generated at 2022-06-25 00:45:45.125988
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts = {}

    user_facts['user_id'] = getpass.getuser()
    user_facts['user_uid'] = os.getuid()
    user_facts['user_gid'] = os.getgid()
    user_facts['user_dir'] = os.path.expanduser("~")
    user_facts['user_shell'] = os.getenv("SHELL")
    user_facts['real_user_id'] = os.getuid()
    user_facts['effective_user_id'] = os.geteuid()
    user_facts['real_group_id'] = os.getgid()
    user_facts['effective_group_id'] = os.getegid()


# Generated at 2022-06-25 00:45:47.560634
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_fact_collector_1.collect()


# Generated at 2022-06-25 00:45:48.643329
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()

# Generated at 2022-06-25 00:45:49.905600
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_fact_collector_1.collect()

# Generated at 2022-06-25 00:45:56.000649
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    facts_1 = user_fact_collector_1.collect()
    assert set(facts_1.keys()) == {'user_id', 'user_uid', 'user_gid',
                                   'user_gecos', 'user_dir', 'user_shell',
                                   'real_user_id', 'effective_user_id',
                                   'real_group_id', 'effective_group_id'}


# Generated at 2022-06-25 00:46:06.978349
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    #assert isinstance(user_fact_collector_0.collect(), dict)
    user_fact_collector_0.collect()

#

# Generated at 2022-06-25 00:46:08.750820
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()


# Generated at 2022-06-25 00:46:18.183932
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Test with no optional module argument
    user_fact_collector_1 = UserFactCollector()
    user_facts_1 = user_fact_collector_1.collect()
    assert 'user_id' in user_facts_1
    assert 'user_uid' in user_facts_1
    assert 'user_gid' in user_facts_1
    assert 'user_gecos' in user_facts_1
    assert 'user_dir' in user_facts_1
    assert 'user_shell' in user_facts_1
    assert 'real_user_id' in user_facts_1
    assert 'effective_user_id' in user_facts_1
    assert 'real_group_id' in user_facts_1
    assert 'effective_group_id' in user_facts_1


# Generated at 2022-06-25 00:46:20.158342
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    collected_facts_1 = {}
    collected_facts_1 = user_fact_collector_1.collect()
    assert collected_facts_1 is not None

# Generated at 2022-06-25 00:46:22.934857
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_fact_collector_1.collect(module=1, collected_facts=1)

# Generated at 2022-06-25 00:46:27.048965
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    # Check if the expected user is returned
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()
    assert user_facts['user_id'] == getpass.getuser()

    # Check if one of the expected keys is in the returned dict
    assert 'user_id' in user_fact_collector.collect()

# Generated at 2022-06-25 00:46:28.620358
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()

    user_fact_collector_0.collect()

# Generated at 2022-06-25 00:46:35.293663
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    collected_facts = {}
    user_facts = user_fact_collector_0.collect(collected_facts)

    assert 'user_id' in user_facts
    assert 'user_uid' in user_facts
    assert 'user_gid' in user_facts
    assert 'user_gecos' in user_facts
    assert 'user_dir' in user_facts
    assert 'user_shell' in user_facts
    assert 'real_user_id' in user_facts
    assert 'effective_user_id' in user_facts
    assert 'effective_group_ids' in user_facts

# Generated at 2022-06-25 00:46:38.446318
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    print("Test > UserFactCollector > collect")

    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()

# Generated at 2022-06-25 00:46:40.359215
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_fact_collector_1.collect()


# Generated at 2022-06-25 00:47:00.266222
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
   user_fact_collector_0 = UserFactCollector()
   collected_facts = {}
   collected_facts = user_fact_collector_0.collect(collected_facts=collected_facts)
   assert collected_facts['user_id'] == getpass.getuser()
   assert collected_facts['user_uid'] == os.getuid()
   assert collected_facts['user_gid'] == os.getegid()
   assert collected_facts['user_gecos'] == pwd.getpwuid(os.getuid()).pw_gecos
   assert collected_facts['user_dir'] == pwd.getpwuid(os.getuid()).pw_dir
   assert collected_facts['user_shell'] == pwd.getpwuid(os.getuid()).pw_shell
   assert collected

# Generated at 2022-06-25 00:47:01.819019
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_facts = user_fact_collector_0.collect()

# Generated at 2022-06-25 00:47:07.148333
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_fact_collector.collect() == {
        'user_id': 'root',
        'user_uid': 0,
        'user_gecos': 'root',
        'user_dir': '/root',
        'user_shell': '/bin/bash',
        'real_user_id': 0,
        'effective_user_id': 0,
        'real_group_id': 0,
        'effective_group_id': 0

    }

# Generated at 2022-06-25 00:47:09.263539
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_userids_0 = UserFactCollector().collect()
    assert (user_userids_0['user_id']) == (getpass.getuser())

# Generated at 2022-06-25 00:47:10.099548
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    assert isinstance(UserFactCollector().collect(), dict)

# Generated at 2022-06-25 00:47:11.765262
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()

    user_fact_collector_0.collect()


# Generated at 2022-06-25 00:47:21.707914
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    module_0 = None
    collected_facts_0 = {}
    dict_0 = user_fact_collector_0.collect(module_0, collected_facts_0)
    print(dict_0)
    assert dict_0['user_id'] == 'root'
    assert dict_0['user_uid'] == 0
    assert dict_0['user_gid'] == 0
    assert dict_0['user_gecos'] == 'root'
    assert dict_0['user_dir'] == '/root'
    assert dict_0['user_shell'] == '/bin/bash'
    assert dict_0['real_user_id'] == 0
    assert dict_0['effective_user_id'] == 0
    assert dict_0['real_group_id']

# Generated at 2022-06-25 00:47:29.152827
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect(collected_facts=None)
    print(user_facts)
    print('user_id = %s' % user_facts['user_id'])
    print('user_uid = %s' % user_facts['user_uid'])
    print('user_gid = %s' % user_facts['user_gid'])
    print('user_gecos = %s' % user_facts['user_gecos'])
    print('user_dir = %s' % user_facts['user_dir'])
    print('user_shell = %s' % user_facts['user_shell'])
    print('real_user_id = %s' % user_facts['real_user_id'])


# Generated at 2022-06-25 00:47:36.958409
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    results = user_fact_collector_0.collect()
    assert results['user_id'] == 'root'
    assert results['user_uid'] == 0
    assert results['user_gid'] == 0
    assert results['user_gecos'] == 'root'
    assert results['user_dir'] == '/root'
    assert results['user_shell'] == '/bin/bash'
    assert results['real_user_id'] == 0
    assert results['effective_user_id'] == 0
    assert results['real_group_id'] == 0
    assert results['effective_group_id'] == 0



# Generated at 2022-06-25 00:47:43.998425
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()

    module_0 = None

    # Call method collect of user_fact_collector_0
    try:
        print(dir(user_fact_collector_0))
        collected_facts_0 = user_fact_collector_0.collect(
            module=module_0, collected_facts=None)
    except:
        collected_facts_0 = None

    print(collected_facts_0)


if __name__ == "__main__":
    test_case_0()
    test_UserFactCollector_collect()

# Generated at 2022-06-25 00:48:20.854804
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()

    assert type(user_facts) == dict
    assert type(user_facts['user_id']) == str
    assert type(user_facts['user_uid']) == int
    assert type(user_facts['user_gid']) == int
    assert type(user_facts['user_gecos']) == str
    assert type(user_facts['user_dir']) == str
    assert type(user_facts['user_shell']) == str
    assert type(user_facts['real_user_id']) == int
    assert type(user_facts['effective_user_id']) == int
    assert type(user_facts['real_group_id']) == int

# Generated at 2022-06-25 00:48:22.882313
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    assert user_fact_collector_1.collect() is not None

# Generated at 2022-06-25 00:48:26.610897
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()


# Generated at 2022-06-25 00:48:33.763764
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()
    assert user_facts["user_id"] is not None
    assert user_facts["user_shell"] is not None
    assert user_facts["user_gid"] is not None
    assert user_facts["user_uid"] is not None
    assert user_facts["real_user_id"] is not None
    assert user_facts["real_group_id"] is not None
    assert user_facts["effective_user_id"] is not None
    assert user_facts["effective_group_id"] is not None
    assert user_facts["user_gecos"] is not None
    assert user_facts["user_dir"] is not None

# Generated at 2022-06-25 00:48:40.053544
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    pwd.getpwnam = lambda x: pwd.struct_passwd([(x, None, None, None, None, None, None)])
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()

# Generated at 2022-06-25 00:48:41.982361
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_facts_dict_1 = user_fact_collector_1.collect()
    print("    user_facts_dict_1 : = " + str(user_facts_dict_1))

test_case_0()
test_UserFactCollector_collect()

# Generated at 2022-06-25 00:48:43.757525
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_fact_collector_1.collect()

test_cases = [test_case_0, test_UserFactCollector_collect]


# Generated at 2022-06-25 00:48:49.335311
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_facts = user_fact_collector_0.collect()


# Generated at 2022-06-25 00:48:55.060455
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    module_name = 'module_name'
    test_case_1 = user_fact_collector_0.collect(module_name)
    assert test_case_1 == 'test_case_1'


# Generated at 2022-06-25 00:49:00.497722
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    result = user_fact_collector_1.collect()
    assert result is not None


# Generated at 2022-06-25 00:50:02.664519
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_facts = user_fact_collector_1.collect()
    assert user_facts

# Generated at 2022-06-25 00:50:10.467066
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Initialize a UserFactCollector object
    user_fact_collector = UserFactCollector()
    # method collect returns a fact dict
    fact_dict = user_fact_collector.collect()
    # Checking fact 'user_id'
    assert fact_dict['user_uid'] > 0
    # Checking fact 'user_gid'
    assert fact_dict['user_gid'] > 0
    # Checking fact 'real_user_id'
    assert fact_dict['real_user_id'] > 0
    # Checking fact 'effective_user_id'
    assert fact_dict['effective_user_id'] > 0


# Generated at 2022-06-25 00:50:11.815993
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()

# Generated at 2022-06-25 00:50:19.434336
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    facts = ufc.collect()
    assert isinstance(facts, dict)
    assert len(set(facts.keys())) == 9
    assert facts['user_id'] is not None
    assert facts['user_uid'] is not None
    assert facts['user_gid'] is not None
    assert facts['user_gecos'] is not None
    assert facts['user_dir'] is not None
    assert facts['user_shell'] is not None
    assert facts['real_user_id'] is not None
    assert facts['real_group_id'] is not None
    assert facts['effective_group_id'] is not None

# Generated at 2022-06-25 00:50:23.769080
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_facts_0 = user_fact_collector_0.collect()
    assert(len(user_facts_0) > 0)

# Generated at 2022-06-25 00:50:25.554180
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    assert not user_fact_collector_0.collect()


# Generated at 2022-06-25 00:50:26.995263
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_fact_collector_1.collect()


# Generated at 2022-06-25 00:50:33.980320
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    collected_facts = {}
    user_fact_collector_0.collect(collected_facts=collected_facts)
    assert collected_facts.get('user_id') is not None
    assert collected_facts.get('user_uid') is not None
    assert collected_facts.get('user_gid') is not None
    assert collected_facts.get('user_gecos') is not None
    assert collected_facts.get('user_dir') is not None
    assert collected_facts.get('user_shell') is not None
    assert collected_facts.get('real_user_id') is not None
    assert collected_facts.get('effective_user_id') is not None
    assert collected_facts.get('real_group_id') is not None
   

# Generated at 2022-06-25 00:50:38.811308
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    res = user_fact_collector_0.collect()
    assert res is None


# Generated at 2022-06-25 00:50:45.093963
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    print("Testing UserFactCollector.get_facts()")
    user_fact_collector = UserFactCollector()
    assert 'user_id' in user_fact_collector.collect().keys()


# Generated at 2022-06-25 00:53:18.638231
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_fact_collector_2 = UserFactCollector()
    user_fact_collector_1.collect()
    user_fact_collector_2.collect()

# Generated at 2022-06-25 00:53:21.011406
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    collected_facts = {}
    user_fact_collector_0.collect(collected_facts=collected_facts)

if __name__ == '__main__':
    print('Dummy unit tests')
    test_case_0()
    test_UserFactCollector_collect()

# Generated at 2022-06-25 00:53:22.594536
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    try:
        user_fact_collector_0.collect()
    except Exception as e:
        print(e)


# Generated at 2022-06-25 00:53:27.054027
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    assert user_fact_collector_0.collect()

# Generated at 2022-06-25 00:53:28.016210
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_fact_collector_1.collect()

# Generated at 2022-06-25 00:53:32.917079
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_obj = UserFactCollector()
    assert isinstance(user_fact_collector_obj.collect(), dict)


# Generated at 2022-06-25 00:53:38.921745
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_facts = user_fact_collector_0.collect()
    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['user_uid'] == pwd.getpwuid(os.getuid()).pw_uid
    assert user_facts['user_gecos'] == pwd.getpwuid(os.getuid()).pw_gecos
    assert user_facts['user_dir'] == pwd.getpwuid(os.getuid()).pw_dir
    assert user_facts['user_shell'] == pwd.getpwuid(os.getuid()).pw_shell
    assert user_facts['real_user_id'] == os.getuid()

# Generated at 2022-06-25 00:53:44.830169
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_2 = UserFactCollector()
    result_dict = user_fact_collector_2.collect()
    result_dict.update({'ansible_facts': {'user': {'user_id': 'xyz', 'user_uid': 1212, 'user_gid': 2323, 'user_gecos': 'abc', 'user_dir': '/tmp', 'user_shell': '/tmp/abc', 'real_user_id': 1212, 'effective_user_id': 1212, 'effective_group_ids': [1212]}}})

# Generated at 2022-06-25 00:53:48.060340
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect(module=None, collected_facts=None)

# Generated at 2022-06-25 00:53:55.754709
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_facts = user_fact_collector_1.collect()

    # Collected facts test
    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['user_uid'] == pwd.getpwnam(getpass.getuser()).pw_uid
    assert user_facts['user_gid'] == pwd.getpwnam(getpass.getuser()).pw_gid
    assert user_facts['user_gecos'] == pwd.getpwnam(getpass.getuser()).pw_gecos
    assert user_facts['user_dir'] == pwd.getpwnam(getpass.getuser()).pw_dir
    assert user_facts['user_shell'] == pwd