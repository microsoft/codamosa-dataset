

# Generated at 2022-06-25 00:44:18.642150
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()


# Generated at 2022-06-25 00:44:21.168518
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_1 = UserFactCollector()
    user_fact_collector_0.collect()
    user_fact_collector_1.collect()



# Generated at 2022-06-25 00:44:31.864482
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_facts_0 = {'user_shell': '/bin/bash', 'user_id': 'jdoe', 'user_gid': 100, 'user_dir': '/home/jdoe', 'user_gecos': 'John Doe,,,', 'user_uid': 1000}
    user_facts_1 = user_fact_collector_1.collect()
    assert user_facts_0['user_shell'] == user_facts_1['user_shell']
    assert user_facts_0['user_id'] == user_facts_1['user_id']
    assert user_facts_0['user_gid'] == user_facts_1['user_gid']

# Generated at 2022-06-25 00:44:35.610840
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    print(user_fact_collector.collect())
    assert True is True

# Generated at 2022-06-25 00:44:39.906808
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_fact_collector_1.collect()
    assert set(user_fact_collector_1.collect().keys()) == user_fact_collector_1._fact_ids

# Generated at 2022-06-25 00:44:49.549122
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    collected_facts = {'user_id': 'root', 'user_uid': 0, 'user_gid': 0, 'user_gecos': 'root', 'user_dir': '/root', 'user_shell': '/bin/bash', 'real_user_id': 0, 'effective_user_id': 0, 'real_group_id': 0, 'effective_group_id': 0}
    actual_facts = user_fact_collector.collect()
    if actual_facts == collected_facts:
        print("PASS")
    else:
        print("FAIL")

if __name__ == '__main__':
    test_case_0()
    test_UserFactCollector_collect()

# Generated at 2022-06-25 00:44:55.492498
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_facts = user_fact_collector_0.collect()
    assert 'user_id' in user_facts == True
    assert 'user_uid' in user_facts == True
    assert 'user_gid' in user_facts == True
    assert 'user_gecos' in user_facts == True
    assert 'user_dir' in user_facts == True
    assert 'user_shell' in user_facts == True
    assert 'real_user_id' in user_facts == True
    assert 'effective_user_id' in user_facts == True
    assert 'effective_group_ids' in user_facts == True

# Generated at 2022-06-25 00:45:00.628543
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    for key in UserFactCollector._fact_ids:
        print(key)

    user_fact_collector_1 = UserFactCollector()
    user_fact_collector_1.collect()


# Generated at 2022-06-25 00:45:05.023440
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    #UserFactCollector.collect()
    return 0

# Generated at 2022-06-25 00:45:10.976353
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_1 = UserFactCollector()
    result_0 = user_fact_collector_0.collect
    result_1 = user_fact_collector_1.collect()

# Generated at 2022-06-25 00:45:19.451070
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    print ("Collecting user facts")
    user_fact_collector_0.collect()
    print ("Finished collecting user facts")
    print ("Printing user facts")
    for key in user_fact_collector_0.collect():
        print ("key: ", key, "value: ", user_fact_collector_0.collect()[key])

# Generated at 2022-06-25 00:45:21.254450
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
  user_fact_collector = UserFactCollector()
  user_fact_collector.collect()

# Generated at 2022-06-25 00:45:23.459444
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_fact_collector_1.collect()


# Generated at 2022-06-25 00:45:31.564355
# Unit test for method collect of class UserFactCollector

# Generated at 2022-06-25 00:45:33.864262
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_facts = user_fact_collector_0.collect()
    user_id = user_facts.get('user_id')
    assert user_id == getpass.getuser()



# Generated at 2022-06-25 00:45:39.771963
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()

    # Assert that the 'user_id' key is present in the user_facts returned by the UserFactCollector
    assert user_facts and 'user_id' in user_facts


# Generated at 2022-06-25 00:45:42.465151
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    u = UserFactCollector()
    d = u.collect()
    assert 'user_gecos' in d

# Generated at 2022-06-25 00:45:43.928134
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()

# Generated at 2022-06-25 00:45:44.958206
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_collect = UserFactCollector()

# Generated at 2022-06-25 00:45:47.993895
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()
    assert all(i in user_facts for i in user_fact_collector._fact_ids)

# Generated at 2022-06-25 00:45:59.107518
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_1 = UserFactCollector()
    collected_facts_0 = {'ansible_dev_setup': False,
                         'ansible_env': {},
                         'ansible_facts': {'user_id': 'alice',
                                           'user_uid': 101,
                                           'user_gid': 101,
                                           'user_gecos': 'Alice',
                                           'user_dir': '/home/alice',
                                           'user_shell': '/bin/bash',
                                           'real_user_id': 101,
                                           'effective_user_id': 101,
                                           'real_group_id': 100,
                                           'effective_group_id': 100}}
    user_

# Generated at 2022-06-25 00:46:02.913341
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()

# Running test case 0
test_case_0()

# Running test UserFactCollector.collect
test_UserFactCollector_collect()

# Generated at 2022-06-25 00:46:07.541737
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_collect = UserFactCollector()
    # test collect
    try:
        user_fact_collector_collect.collect()
    except Exception as e:
        assert False, "UserFactCollector.collect threw exception: " + str(e)


# Generated at 2022-06-25 00:46:17.726021
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    collected_facts = user_fact_collector.collect()
    assert collected_facts is not None
    assert collected_facts['user_id'] is not None
    assert collected_facts['user_uid'] is not None
    assert collected_facts['user_gid'] is not None
    assert collected_facts['user_gecos'] is not None
    assert collected_facts['user_dir'] is not None
    assert collected_facts['user_shell'] is not None
    assert collected_facts['real_user_id'] is not None
    assert collected_facts['effective_user_id'] is not None
    assert collected_facts['real_group_id'] is not None
    assert collected_facts['effective_group_id'] is not None

# Generated at 2022-06-25 00:46:19.076296
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()

# Generated at 2022-06-25 00:46:22.984445
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    assert type(user_fact_collector_0) == type(UserFactCollector())
    assert len(user_fact_collector_0.collect().items()) > 0


# Generated at 2022-06-25 00:46:24.821841
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()


# Generated at 2022-06-25 00:46:26.356311
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_fact_collector.collect()

# Generated at 2022-06-25 00:46:33.203198
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_collector = UserFactCollector()
    test_result = user_collector.collect()
    assert 'user_id' in test_result
    assert 'user_uid' in test_result
    assert 'user_gid' in test_result
    assert 'user_gecos' in test_result
    assert 'user_dir' in test_result
    assert 'user_shell' in test_result
    assert 'real_user_id' in test_result
    assert 'effective_user_id' in test_result
    assert 'real_group_id' in test_result
    assert 'effective_group_id' in test_result

# Generated at 2022-06-25 00:46:36.689444
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    uf_collector = UserFactCollector()
    user_facts = uf_collector.collect()
    print('user_facts=',user_facts)

test_UserFactCollector_collect()

# Generated at 2022-06-25 00:46:49.871037
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_facts = user_fact_collector_1.collect()

    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['user_uid'] == os.getuid()
    assert user_facts['user_gid'] == os.getgid()
    assert user_facts['user_gecos'] == pwd.getpwuid(os.getuid())[4]
    assert user_facts['user_dir'] == pwd.getpwuid(os.getuid())[5]
    assert user_facts['user_shell'] == pwd.getpwuid(os.getuid())[6]
    assert user_facts['real_user_id'] == os.getuid()

# Generated at 2022-06-25 00:46:50.397302
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    assert True is not False

# Generated at 2022-06-25 00:46:54.120322
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    test_vars = {}
    test_vars = user_fact_collector.collect(None, test_vars)
    assert test_vars is not None

# Generated at 2022-06-25 00:47:03.406387
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()
    # Test the value of user_shell
    assert user_fact_collector_0.user_shell == '/bin/sh'
    # Test the value of user_dir
    assert user_fact_collector_0.user_dir == '/root'
    # Test the value of user_uid
    assert user_fact_collector_0.user_uid == 0
    # Test the value of effective_group_id
    assert user_fact_collector_0.effective_group_id == 0
    # Test the value of effective_user_id
    assert user_fact_collector_0.effective_user_id == 0
    # Test the value of user_id

# Generated at 2022-06-25 00:47:04.986516
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()

# Generated at 2022-06-25 00:47:08.292139
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()

    user_facts = user_fact_collector_1.collect()
    user_fact_ids = set(user_facts.keys())

    assert user_fact_ids == user_fact_collector_1._fact_ids


# Generated at 2022-06-25 00:47:12.525653
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    # Create an instance of class UserFactCollector
    user_fact_collector_1 = UserFactCollector()

    # Call method collect of UserFactCollector object
    user_fact_collector_1.collect()

    # Test attribute _fact_ids of object user_fact_collector_1
    assert user_fact_collector_1._fact_ids == set(['effective_group_ids', 'real_user_id', 'user_gid', 'user_id', 'effective_user_id', 'user_gecos', 'user_uid', 'user_shell', 'user_dir'])

    # Assert the return value
    assert user_fact_collector_1.collect() == {}

# Generated at 2022-06-25 00:47:14.047196
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_fact_collector.collect()


# Generated at 2022-06-25 00:47:17.067379
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()

    user_fact_collector_0.collect()


# Generated at 2022-06-25 00:47:18.849938
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()

# Generated at 2022-06-25 00:47:29.730395
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # testcase_0
    set_0 = None
    str_0 = None
    list_0 = [str_0, str_0, str_0]
    user_fact_collector_0 = UserFactCollector(list_0)
    var_0 = user_fact_collector_0.collect(set_0)


# Generated at 2022-06-25 00:47:33.905941
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    set_0 = None
    str_0 = None
    list_0 = [str_0, str_0, str_0]
    user_fact_collector_0 = UserFactCollector(list_0)
    var_0 = user_fact_collector_0.collect(set_0)
    assert var_0 == None

# Generated at 2022-06-25 00:47:38.696268
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    set_0 = None
    str_0 = None
    list_0 = [str_0, str_0, str_0]
    user_fact_collector_0 = UserFactCollector(list_0)
    assert isinstance(user_fact_collector_0.collect(set_0), dict) == True



# Generated at 2022-06-25 00:47:42.823137
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    set_1 = None
    str_1 = None
    list_1 = [str_1, str_1, str_1]
    user_fact_collector_1 = UserFactCollector(list_1)
    var_1 = user_fact_collector_1.collect(set_1)

# Generated at 2022-06-25 00:47:47.911079
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Run test_case_0
    test_case_0()

    # Asserts collected facts of test_case_0
    assert user_fact_collector_0._fact_ids == set(['user_id', 'user_uid', 'user_gid'])
    assert user_fact_collector_0.name == 'user'


# Generated at 2022-06-25 00:47:50.830544
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    set_0 = None
    list_0 = [None, None, None]
    user_fact_collector_0 = UserFactCollector(list_0)
    var_0 = user_fact_collector_0.collect(set_0)

# Generated at 2022-06-25 00:47:52.525002
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    list_0 = []
    user_fact_collector_0 = UserFactCollector(list_0)
    set_0 = None
    var_0 = user_fact_collector_0.collect(set_0)

# Generated at 2022-06-25 00:47:54.489139
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    test_case_0()

# Generated at 2022-06-25 00:47:59.602215
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    assert user_fact_collector_0.collect() == {'effective_group_id': os.getgid(), 'effective_user_id': os.geteuid(), 'real_user_id': os.getuid(), 'real_group_id': os.getgid()}


# Generated at 2022-06-25 00:48:04.850230
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    print("\n=== Testing method collect of class UserFactCollector ===")

    for i in range(0, 20):
    	print("\n--Iteration {}--".format(i))
    	test_case_0()
    	print("--End of Iteration {}--".format(i))

# Generated at 2022-06-25 00:48:21.827874
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    set_1 = None
    str_1 = None
    list_1 = [str_1, str_1, str_1]
    user_fact_collector_1 = UserFactCollector(list_1)
    var_1 = user_fact_collector_1.collect(set_1)

# Generated at 2022-06-25 00:48:28.704904
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    try:
        set_0 = None
        str_0 = None
        list_0 = [str_0, str_0, str_0]
        user_fact_collector_0 = UserFactCollector(list_0)
        var_0 = user_fact_collector_0.collect(set_0)
    except Exception as exception_0:
        print(sys.exc_info())
        print(traceback.print_exc())
        print(exception_0)

# Generated at 2022-06-25 00:48:32.141207
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    set_0 = None
    list_0 = [None, None, None]
    user_fact_collector_0 = UserFactCollector(list_0)
    var_0 = user_fact_collector_0.collect(set_0)

if __name__ == "__main__":
    test_UserFactCollector_collect()

# Generated at 2022-06-25 00:48:33.238861
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    current_path_0 = user_fact_collector_0.collect()
    print(current_path_0)

# Generated at 2022-06-25 00:48:40.243438
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    list_0 = [None, None, None]
    void_UserFactCollector_0 = UserFactCollector(list_0)
    void_UserFactCollector_0.collect()

if __name__ == '__main__':
    test_case_0()
    test_UserFactCollector_collect()

# Generated at 2022-06-25 00:48:42.489652
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    assert True

# Generated at 2022-06-25 00:48:46.950360
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    facts = {}
    assert isinstance(facts, dict)
    fact_defs = []
    fact_defs.append(BaseFactCollector("user",
                                       {"user_id", "user_uid", "user_gid",
                                        "user_gecos", "user_dir",
                                        "user_shell", "real_user_id",
                                        "effective_user_id",
                                        "effective_group_ids"}))
    for fact_def in fact_defs:
        facts.update(fact_def.collect())


if __name__ == '__main__':
    test_case_0()
    test_UserFactCollector_collect()

# Generated at 2022-06-25 00:48:49.314426
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    list_0 = [None, None, None]
    user_fact_collector_1 = UserFactCollector(list_0)
    set_0 = {str(None):str(None)}
    str_0 = str(None)
    var_1 = user_fact_collector_1.collect(set_0)
    assert var_1 == set_0


# Generated at 2022-06-25 00:48:57.855895
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    list_1 = ['list', 'list', 'list']
    dict_0 = {}
    TestUserFactCollector_collect_0 = None
    TestUserFactCollector_collect_1 = None
    TestUserFactCollector_collect_2 = None
    TestUserFactCollector_collect_3 = None
    TestUserFactCollector_collect_4 = None
    TestUserFactCollector_collect_5 = None
    TestUserFactCollector_collect_6 = None
    TestUserFactCollector_collect_7 = None
    TestUserFactCollector_collect_8 = None
    TestUserFactCollector_collect_9 = None
    TestUserFactCollector_collect_10 = None
    TestUserFactCollector_collect_11 = None
    TestUserFactCollector_collect_12 = None
    TestUserFactCollector_collect

# Generated at 2022-06-25 00:49:00.342585
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    set_0 = None
    str_0 = None
    list_0 = [str_0, str_0, str_0]
    user_fact_collector_0 = UserFactCollector(list_0)
    var_0 = user_fact_collector_0.collect(set_0)


# Generated at 2022-06-25 00:49:38.016306
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    set_0 = None
    str_0 = None
    list_0 = [str_0, str_0, str_0]
    user_fact_collector_0 = UserFactCollector(list_0)
    set_0 = user_fact_collector_0.collect(set_0)
    assert set_0 is None

if __name__ == "__main__":
    # test_case_0()
    test_UserFactCollector_collect()

# Generated at 2022-06-25 00:49:38.629719
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    assert True

# Generated at 2022-06-25 00:49:41.014943
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    set_0 = None
    str_0 = None
    list_0 = [str_0, str_0, str_0]
    user_fact_collector_0 = UserFactCollector(list_0)
    var_0 = user_fact_collector_0.collect(set_0)




# Generated at 2022-06-25 00:49:46.325265
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    set_0 = None
    str_0 = None
    list_0 = [str_0, str_0, str_0]
    user_fact_collector_0 = UserFactCollector(list_0)
    var_0 = user_fact_collector_0.collect(set_0)

# Generated at 2022-06-25 00:49:49.605881
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector([])
    user_fact_collector_1.collect()


# Generated at 2022-06-25 00:49:55.489887
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    set_0 = None
    str_0 = None
    list_0 = [str_0, str_0, str_0]
    user_fact_collector_0 = UserFactCollector(list_0)
    var_0 = user_fact_collector_0.collect(set_0)
    assert var_0 is not None


# Generated at 2022-06-25 00:50:02.053385
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    set_0 = None
    str_0 = None
    list_0 = [str_0, str_0, str_0]
    user_fact_collector_0 = UserFactCollector(list_0)
    var_0 = user_fact_collector_0.collect(set_0)


# Generated at 2022-06-25 00:50:08.177495
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector([])
    set_0 = None
    dict_0 = {key_0: user_fact_collector_0.collect(set_0) for key_0 in (str_0, set_0, user_fact_collector_0)}

test_UserFactCollector_collect()
test_case_0()

# Generated at 2022-06-25 00:50:09.324994
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    set_0 = None
    user_fact_collector_0.collect(set_0)



# Generated at 2022-06-25 00:50:11.350987
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    set_0 = None
    str_0 = None
    list_1 = [str_0, str_0, str_0]
    user_fact_collector_0 = UserFactCollector(list_1)
    user_fact_collector_0.collect(set_0)

# Generated at 2022-06-25 00:51:29.767246
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    a = UserFactCollector()
    b = ['test']
    a.collect(collect_subset=b)


# Generated at 2022-06-25 00:51:33.911478
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    set_0 = None
    str_0 = None
    list_0 = [str_0, str_0, str_0]
    user_fact_collector_0 = UserFactCollector(list_0)
    var_0 = user_fact_collector_0.collect(set_0)
    assert isinstance(var_0, dict)


# Generated at 2022-06-25 00:51:36.003798
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    assert callable(UserFactCollector.collect)
    assert isinstance(UserFactCollector.collect(), dict)
    assert len(UserFactCollector.collect()) > 0


# Generated at 2022-06-25 00:51:38.668218
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    set_0 = None
    str_0 = None
    list_0 = [str_0, str_0, str_0]
    user_fact_collector_0 = UserFactCollector(list_0)
    var_0 = user_fact_collector_0.collect(set_0)

# Generated at 2022-06-25 00:51:41.189984
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    assert isinstance(user_fact_collector_0, UserFactCollector)
    set_0 = None
    str_0 = None
    list_0 = [str_0, str_0, str_0]
    assert isinstance(user_fact_collector_0.collect(set_0), dict)

# Generated at 2022-06-25 00:51:47.581709
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector(None)
    list_0 = [None, None, None]
    var_0 = user_fact_collector_0.collect(list_0)

    user_fact_collector_1 = UserFactCollector(None)
    str_0 = None
    list_0 = [str_0, str_0, str_0]
    var_1 = user_fact_collector_1.collect(list_0)


# Generated at 2022-06-25 00:51:51.932715
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    set_0 = None
    str_0 = None
    list_0 = [str_0, str_0, str_0]
    user_fact_collector_0 = UserFactCollector(list_0)
    var_0 = user_fact_collector_0.collect(set_0)
    assert isinstance(var_0, dict)

# Generated at 2022-06-25 00:51:55.885979
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    set_0 = None
    str_0 = None
    list_0 = [str_0, str_0, str_0]
    user_fact_collector_0 = UserFactCollector(list_0)
    var_0 = user_fact_collector_0.collect(set_0)

# Generated at 2022-06-25 00:51:59.734008
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    assert True


# Generated at 2022-06-25 00:52:01.572535
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    try:
        UserFactCollector.collect
    except AttributeError:
        pass
    else:
        raise Exception(
            "Expected AttributeError but no exception was raised")
