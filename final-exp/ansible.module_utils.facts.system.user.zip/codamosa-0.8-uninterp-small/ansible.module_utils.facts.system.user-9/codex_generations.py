

# Generated at 2022-06-25 00:44:14.007023
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()

# Generated at 2022-06-25 00:44:18.642229
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    string_0 = user_fact_collector_1.collect()

# Generated at 2022-06-25 00:44:20.015184
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    collected_facts = {}
    user_fact_collector_0.collect(collected_facts=collected_facts)


# Generated at 2022-06-25 00:44:30.438122
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    pwent = pwd.getpwnam(getpass.getuser())
    fact_dct = user_fact_collector.collect()
    assert fact_dct['user_id'] == getpass.getuser()
    assert fact_dct['user_uid'] == pwent.pw_uid
    assert fact_dct['user_gid'] == pwent.pw_gid
    assert fact_dct['user_gecos'] == pwent.pw_gecos
    assert fact_dct['user_dir'] == pwent.pw_dir
    assert fact_dct['user_shell'] == pwent.pw_shell
    assert fact_dct['real_user_id'] == os.getuid()

# Generated at 2022-06-25 00:44:34.166195
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()

    user_fact_collector_0.collect()

# Generated at 2022-06-25 00:44:35.767858
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_fact_collector.collect()


# Generated at 2022-06-25 00:44:44.166736
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()

    keys = ['user_id', 'user_uid', 'user_gid', 'user_gecos', 'user_dir', 'user_shell', 'real_user_id', 'effective_user_id', 'real_group_id', 'effective_group_id']

    # Test collect function with user_id
    result = user_fact_collector_0.collect(module=None, collected_facts=None)
    assert result['user_id'] == getpass.getuser()

    # Test collect function with user_uid
    result = user_fact_collector_0.collect(module=None, collected_facts=None)
    assert result['user_uid'] == pwd.getpwuid(os.getuid()).pw_uid

    # Test collect function

# Generated at 2022-06-25 00:44:53.602600
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    collected_facts = {}
    user_facts = user_fact_collector_0.collect(collected_facts)
    assert isinstance(user_facts, dict)
    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['user_uid'] == pwd.getpwnam(getpass.getuser()).pw_uid
    assert user_facts['user_gid'] == pwd.getpwnam(getpass.getuser()).pw_gid
    assert user_facts['user_gecos'] == pwd.getpwnam(getpass.getuser()).pw_gecos
    assert user_facts['user_dir'] == pwd.getpwnam(getpass.getuser()).p

# Generated at 2022-06-25 00:44:59.628132
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_facts = user_fact_collector_1.collect()
    assert user_facts == {'user_id': 'ansible', 'user_uid': 500, 'user_gid': 500,
                          'user_gecos': 'Ansible Admin,,,', 'user_dir': '/home/ansible',
                          'user_shell': '/bin/sh', 'real_user_id': 500,
                          'effective_user_id': 500, 'real_group_id': 500,
                          'effective_group_id': 500}

# Generated at 2022-06-25 00:45:09.937515
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_facts = user_fact_collector_0.collect()
    assert user_facts is not None
    assert user_facts['user_id'] is not None
    assert user_facts['user_uid'] is not None
    assert user_facts['user_gid'] is not None
    assert user_facts['user_gecos'] is not None
    assert user_facts['user_dir'] is not None
    assert user_facts['user_shell'] is not None
    assert user_facts['real_user_id'] is not None
    assert user_facts['effective_user_id'] is not None
    assert user_facts['real_group_id'] is not None
    assert user_facts['effective_group_id'] is not None

# Generated at 2022-06-25 00:45:24.409799
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()

    user_name = os.getlogin()
    pwent = pwd.getpwnam(getpass.getuser())
    uid = os.getuid()
    gid = os.getgid()

    user_facts = user_fact_collector.collect()

    assert user_facts is not None
    assert user_facts['user_id'] == user_name
    assert user_facts['user_uid'] == pwent.pw_uid
    assert user_facts['user_gid'] == pwent.pw_gid
    assert user_facts['user_gecos'] == pwent.pw_gecos
    assert user_facts['user_dir'] == pwent.pw_dir
    assert user_facts['user_shell'] == pwent.p

# Generated at 2022-06-25 00:45:25.335452
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    UserFactCollector().collect(None, None)

# Generated at 2022-06-25 00:45:27.212035
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()


# Generated at 2022-06-25 00:45:30.680950
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_facts = user_fact_collector_0.collect()
    assert user_facts['user_id'] == getpass.getuser(), "Either user_id was not collected, or it was not collected correctly."

# Unit tests for collection of user_uid

# Generated at 2022-06-25 00:45:34.731527
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    assert user_fact_collector_0.collect() == {'effective_group_id': 1000, 'effective_user_id': 1000, 'real_group_id': 1000, 'real_user_id': 1000, 'user_dir': '/home/vmayoral', 'user_gid': 1000, 'user_gecos': 'Victor Mayoral Villar', 'user_id': 'vmayoral', 'user_shell': '/bin/bash', 'user_uid': 1000}

# Generated at 2022-06-25 00:45:42.004276
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    assert user_fact_collector_0.collect() == {'user_id': 'konjoot', 'user_uid': 1000, 'user_gid': 1000, 'user_gecos': 'Test', 'user_dir': '/home/konjoot', 'user_shell': '/bin/bash', 'real_user_id': 1000, 'effective_user_id': 1000, 'real_group_id': 1000, 'effective_group_id': 1000}

# Generated at 2022-06-25 00:45:43.927952
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_fact_collector_1.collect()


# Generated at 2022-06-25 00:45:51.493822
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_facts_dict = user_fact_collector_0.collect()
    all_keys = list(user_facts_dict.keys())
    print("[{0}]".format(','.join(all_keys)))
    assert'/home/alice' in user_facts_dict['user_dir']
    assert'alice' in user_facts_dict['user_id']
    assert'alice' in user_facts_dict['user_gecos']
    assert'/bin/bash' in user_facts_dict['user_shell']

# Generated at 2022-06-25 00:45:59.766363
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    collected_facts_1 = user_fact_collector_1.collect()
    assert isinstance(collected_facts_1, dict)
    assert collected_facts_1['user_id'] == getpass.getuser()
    assert isinstance(collected_facts_1['user_id'], str)
    assert isinstance(collected_facts_1['user_uid'], int)
    assert isinstance(collected_facts_1['user_gid'], int)
    assert isinstance(collected_facts_1['user_gecos'], str)
    assert isinstance(collected_facts_1['user_dir'], str)
    assert isinstance(collected_facts_1['user_shell'], str)

# Generated at 2022-06-25 00:46:07.411315
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    assert user_fact_collector.collect() == {
        'user_id': 'vagrant',
        'user_uid': 1000,
        'user_gid': 1000,
        'user_gecos': 'vagrant,,,',
        'user_dir': '/home/vagrant',
        'user_shell': '/bin/bash',
        'real_user_id': 1000,
        'effective_user_id': 1000,
    }

# Generated at 2022-06-25 00:46:15.032254
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_fact_collector_1.collect()

# Generated at 2022-06-25 00:46:19.179505
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0._module = None
    user_fact_collector_0._collected_facts = None
    return_value_0 = user_fact_collector_0.collect(collected_facts={'user': 'test_value'})
    assert type(return_value_0).__name__ == 'dict'


# Generated at 2022-06-25 00:46:22.101154
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_fact_collector_1.collect()


# Generated at 2022-06-25 00:46:30.808420
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    print("\nTest 1: Collect user facts")
    user_fact_collector_1 = UserFactCollector()
    user_facts_1 = user_fact_collector_1.collect()
    print("user_id: %s" % user_facts_1['user_id'])
    print("user_uid: %s" % user_facts_1['user_uid'])
    print("user_gid: %s" % user_facts_1['user_gid'])
    print("user_gecos: %s" % user_facts_1['user_gecos'])
    print("user_dir: %s" % user_facts_1['user_dir'])
    print("user_shell: %s" % user_facts_1['user_shell'])

# Generated at 2022-06-25 00:46:36.031478
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_facts_0 = user_fact_collector_0.collect()
    assert user_facts_0 == {'user_id': 'user', 'user_uid': 1000, 'user_shell': '/bin/bash', 'effective_group_ids': [1000], 'effective_user_id': 1000, 'real_group_id': 1000, 'user_gid': 1000, 'user_dir': '/home/user', 'user_gecos': 'user,,,', 'real_user_id': 1000}

# Generated at 2022-06-25 00:46:44.626918
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    # Test for no exception with default arguments
    user_fact_collector_1 = UserFactCollector()

    # Test for no exception with module=dict() and collected_facts=dict()
    user_fact_collector_2 = UserFactCollector()

    # Test for no exception with module=dict()
    user_fact_collector_3 = UserFactCollector()

    # Test for no exception with collected_facts=dict()
    user_fact_collector_4 = UserFactCollector()

    # Test for raises with module=None, collected_facts=None
    user_fact_collector_5 = UserFactCollector()

    # Test for raises with module=None
    user_fact_collector_6 = UserFactCollector()

    # Test for raises with collected_facts=None

# Generated at 2022-06-25 00:46:46.040812
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    collected_facts = user_fact_collector.collect()

# Generated at 2022-06-25 00:46:47.841986
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    collected_facts = {}
    user_facts = user_fact_collector_0.collect(collected_facts)

# Generated at 2022-06-25 00:46:57.422464
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_facts = user_fact_collector_1.collect()
    # Check if user_id is present in collected_facts and is a string
    assert "user_id" in user_facts and isinstance(user_facts["user_id"], str)
    # Check if user_uid is present in collected_facts and is an int
    assert "user_uid" in user_facts and isinstance(user_facts["user_uid"], int)
    # Check if user_gid is present in collected_facts and is an int
    assert "user_gid" in user_facts and isinstance(user_facts["user_gid"], int)
    # Check if user_gecos is present in collected_facts and is a string
    assert "user_gecos" in user_facts

# Generated at 2022-06-25 00:47:05.006374
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    test_obj = UserFactCollector()
    test_obj_collect = test_obj.collect()
    assert isinstance(test_obj_collect, dict)
    assert 'user_id' in test_obj_collect
    assert 'user_uid' in test_obj_collect
    assert 'user_gid' in test_obj_collect
    assert 'user_gecos' in test_obj_collect
    assert 'user_dir' in test_obj_collect
    assert 'user_shell' in test_obj_collect
    assert 'real_user_id' in test_obj_collect
    assert 'effective_user_id' in test_obj_collect
    assert 'effective_group_ids' in test_obj_collect

# Generated at 2022-06-25 00:47:27.122852
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_fact_collector_2 = UserFactCollector()
    user_fact_collector_3 = UserFactCollector()
    user_fact_collector_4 = UserFactCollector()

    # call collect() method with no the optional parameter collected_facts
    user_facts = user_fact_collector_1.collect()
    #assert 0 == len(user_facts.keys())

    # call collect() method with collected_facts as an empty dictionary
    user_facts = user_fact_collector_2.collect(collected_facts={})
    assert 0 == len(user_facts.keys())

    # call collect() method with all optional arguments
    collected_facts = {'collection_type': 'test', 'collected_facts': {}}
    user_facts

# Generated at 2022-06-25 00:47:29.255867
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    assert isinstance(user_fact_collector_0.collect(), dict)


# Generated at 2022-06-25 00:47:31.892765
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    module_0 = None
    collected_facts_0 = None
    user_fact_collector_0.collect(module_0, collected_facts_0)

# Generated at 2022-06-25 00:47:38.878133
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    ans = user_fact_collector_1.collect()
    exp = {'effective_user_id': 1000,
           'effective_group_id': 1000,
           'real_group_id': 1000,
           'real_user_id': 1000,
           'user_gecos': 'Ansible Test User',
           'user_gid': 1000,
           'user_id': 'ansible',
           'user_shell': '/bin/bash',
           'user_dir': '/home/ansible',
           'user_uid': 1000}
    assert ans == exp


# Generated at 2022-06-25 00:47:48.870054
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    _user_id = getpass.getuser()
    _real_user_id = os.getuid()
    _effective_user_id = os.geteuid()
    _user_gid = os.getgid()
    _real_group_id = os.getegid()
    _effective_group_id = os.getgid()


# Generated at 2022-06-25 00:47:52.430694
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    assert user_fact_collector_0.collect() == {'effective_group_id': 1000, 'effective_user_id': 1000, 'real_group_id': 1000, 'real_user_id': 1000, 'user_dir': '/home/ansible', 'user_gecos': 'ansible,,,', 'user_gid': 1000, 'user_id': 'ansible', 'user_shell': '/bin/bash', 'user_uid': 1000}

# Test for class initialization UserFactCollector

# Generated at 2022-06-25 00:47:53.906687
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    result = user_fact_collector.collect()

    assert result is not None


# Generated at 2022-06-25 00:48:03.363433
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    (a, b) = user_fact_collector_1.collect()
    assert a == b
    assert a['user_id'] == b['user_id']
    assert a['user_uid'] == b['user_uid']
    assert a['user_gid'] == b['user_gid']
    assert a['user_gecos'] == b['user_gecos']
    assert a['user_dir'] == b['user_dir']
    assert a['user_shell'] == b['user_shell']
    assert a['real_user_id'] == b['real_user_id']
    assert a['effective_user_id'] == b['effective_user_id']

# Generated at 2022-06-25 00:48:06.002371
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_collector_0_facts = user_fact_collector_0.collect()

# Tests for function collect_user_facts

# Generated at 2022-06-25 00:48:07.470788
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()

# Generated at 2022-06-25 00:48:28.110849
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    test_cases = [test_case_0]
    loader = unittest.TestLoader()
    suite = unittest.TestSuite()
    for test_func in test_cases:
        test_name = test_func.__name__
        test = loader.loadTestsFromTestCase(test_func)
        suite.addTests(test)
    return suite

if __name__ == '__main__':
    unittest.main()

# Generated at 2022-06-25 00:48:35.139568
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    # Test for module_arg_spec_file
    try:
        os.environ['ANSIBLE_USER_COLLECTOR_suser_fact_collector_0_MODULE_ARG_SPEC_FILE'] = 'AnsibleModule_user_collector_0_arg_spec.json'
    except KeyError:
        os.environ['ANSIBLE_USER_COLLECTOR_suser_fact_collector_0_MODULE_ARG_SPEC_FILE'] = '../../module_utils/testing/data/module_utils/AnsibleModule_user_collector_0_arg_spec.json'

    # Test for module_default_arg_spec_file

# Generated at 2022-06-25 00:48:39.103320
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_fact_collector_1.collect()


# Generated at 2022-06-25 00:48:46.446922
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Initialize object
    user_fact_collector = UserFactCollector()

    # Invoke method
    collected_facts = user_fact_collector.collect()
    expected_facts = {
        'effective_group_id': 20,
        'effective_user_id': 1000,
        'real_group_id': 20,
        'real_user_id': 1000,
        'user_dir': '/home/michaelfisher',
        'user_gid': 20,
        'user_gecos': 'Michael Fisher,,,',
        'user_id': 'michaelfisher',
        'user_shell': '/bin/bash',
        'user_uid': 1000
    }
    assert collected_facts == expected_facts

# Generated at 2022-06-25 00:48:50.048770
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    # Test execution with various arguments
    output = [{'user_id': 'dummy_user_name', 'user_uid': 101, 'user_gid': 1000, 'user_gecos': 'dummy_gecos', 'user_dir': '/home/dummy_user_name', 'user_shell': '/bin/bash', 'real_user_id': 101, 'effective_user_id': 101, 'real_group_id': 1000, 'effective_group_id': 1000}]
    fact_collector_instance = UserFactCollector()
    assert fact_collector_instance.collect() == output

# Generated at 2022-06-25 00:48:53.574338
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    collected_facts = {}
    result = user_fact_collector_1.collect(collected_facts=collected_facts)
    assert isinstance(result, dict)
    assert 'user_id' in result
    assert 'user_uid' in result
    assert 'user_gid' in result
    assert 'user_gecos' in result
    assert 'user_dir' in result
    assert 'user_shell' in result
    assert 'real_user_id' in result
    assert 'effective_user_id' in result
    assert 'effective_group_ids' in result

# Generated at 2022-06-25 00:48:55.175831
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()
    assert user_facts['user_id'] == getpass.getuser()

# Generated at 2022-06-25 00:49:04.831365
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    real_user_id = os.getuid()
    effective_user_id = os.getuid()
    real_group_id = os.getgid()
    effective_group_id = os.getgid()

    user_fact_collector_1 = UserFactCollector()
    assert(user_fact_collector_1.collect()['user_id'] == getpass.getuser())
    assert(user_fact_collector_1.collect()['user_uid'] == os.getuid())
    assert(user_fact_collector_1.collect()['user_gid'] == os.getgid())
    assert(user_fact_collector_1.collect()['real_user_id'] == real_user_id)

# Generated at 2022-06-25 00:49:11.068448
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    collected_facts = {'system': {}}
    assert user_fact_collector_1.collect(collected_facts) == {'effective_user_id': os.geteuid(), 'effective_group_ids': sorted(os.getgroups()), 'user_shell': '/bin/bash', 'user_id': 'vagrant', 'user_gecos': '', 'user_uid': 1000, 'real_group_id': os.getgid(), 'user_gid': 1000, 'user_dir': '/home/vagrant', 'real_user_id': os.getuid()}


# Generated at 2022-06-25 00:49:19.777818
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    result = user_fact_collector_0.collect()
    assert isinstance(result, dict)
    assert 'user_id' in result
    assert 'user_uid' in result
    assert 'user_gid' in result
    assert 'user_gecos' in result
    assert 'user_dir' in result
    assert 'user_shell' in result
    assert 'effective_group_ids' in result



# Generated at 2022-06-25 00:49:57.750824
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    real_user_id = os.getuid()
    res_dict = user_fact_collector_1.collect()
    assert res_dict['user_id'] == getpass.getuser()
    assert res_dict['user_uid'] == pwd.getpwuid(real_user_id).pw_uid
    assert res_dict['user_gid'] == pwd.getpwuid(real_user_id).pw_gid
    assert res_dict['user_gecos'] == pwd.getpwuid(real_user_id).pw_gecos
    assert res_dict['user_dir'] == pwd.getpwuid(real_user_id).pw_dir

# Generated at 2022-06-25 00:49:58.936625
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()


# Generated at 2022-06-25 00:50:05.619199
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()

    assert 'user_id' in user_fact_collector_1.collect().keys()
    assert 'user_uid' in user_fact_collector_1.collect().keys()
    assert 'user_gid' in user_fact_collector_1.collect().keys()
    assert 'user_gecos' in user_fact_collector_1.collect().keys()
    assert 'user_dir' in user_fact_collector_1.collect().keys()
    assert 'user_shell' in user_fact_collector_1.collect().keys()
    assert 'real_user_id' in user_fact_collector_1.collect().keys()
    assert 'effective_user_id' in user_fact_collector_1.collect().keys()
   

# Generated at 2022-06-25 00:50:08.703089
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    collected_facts_1 = user_fact_collector_1.collect()
    collected_facts_1.update({'test':'ok'})
    collected_facts_1.update({'foo':'bar'})
    collected_facts_1.update({'foo':'baz'})
    collected_facts_1.update({'user_id':'jdoe'})

# Generated at 2022-06-25 00:50:12.545178
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    test_case_0()
    user_fact_collector_1 = UserFactCollector()

    # The UserFactCollector instance does not have the collect method

    # Call the collect() method to generate the args for a call to the method
    #   collect on the module pytest_ansible.module_utils.facts.collector.
    args_0 = user_fact_collector_1.collect()

    # Assert the args for a call to the collect method of module pytest_ansible.module_utils.facts.collector.
    assert(args_0 == {})

# Generated at 2022-06-25 00:50:15.794192
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.fail_on_missing_facts = False
    user_fact_collector_0.collect()

# Generated at 2022-06-25 00:50:17.799266
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    test_UserFactCollector_collect.user_fact_collector = UserFactCollector()
    assert test_UserFactCollector_collect.user_fact_collector.collect() is not None

# Generated at 2022-06-25 00:50:20.324663
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    collected_facts = {}
    user_fact_collector_0.collect(collected_facts=collected_facts)

# Generated at 2022-06-25 00:50:21.579472
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()

# Generated at 2022-06-25 00:50:24.086209
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()

    user_facts = user_fact_collector_1.collect()
    assert (user_facts['user_id'] == getpass.getuser())


# Generated at 2022-06-25 00:51:47.031262
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = {'user_id': 'root', 'user_uid': 0, 'user_gid': 0, 'user_gecos': 'root', 'user_dir': '/root', 'user_shell': '/bin/bash', 'real_user_id': 0, 'effective_user_id': 0, 'real_group_id': 0, 'effective_group_id': 0}
    user_fact_collector = UserFactCollector()
    assert user_facts == user_fact_collector.collect()

# Generated at 2022-06-25 00:51:49.684327
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    my_module = MagicMock()
    my_collected_facts = MagicMock()
    my_user_fact_collector = UserFactCollector()

    my_user_fact_collector.collect(my_module, my_collected_facts)

# Generated at 2022-06-25 00:51:51.104067
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()

# Generated at 2022-06-25 00:51:53.802768
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()


# Generated at 2022-06-25 00:51:55.198880
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_facts = user_fact_collector_0.collect()


# Generated at 2022-06-25 00:51:56.576897
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()


# Generated at 2022-06-25 00:51:58.881397
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    collected_facts = {}
    user_facts = user_fact_collector.collect(collected_facts)
    assert user_facts['user_id'] == 'root'

# Generated at 2022-06-25 00:51:59.984485
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()

# Generated at 2022-06-25 00:52:01.129990
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    user_fact_collector_1 = UserFactCollector()
    user_fact_collector_1.collect()

# Generated at 2022-06-25 00:52:06.495982
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    a = user_fact_collector_0.collect()
    assert type(a) is dict
