

# Generated at 2022-06-25 00:44:18.683477
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    actual_0 = user_fact_collector_0.collect()


# Generated at 2022-06-25 00:44:28.560896
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    # test case with no arguments
    user_result_dict_1 = user_fact_collector_1.collect()
    assert type(user_result_dict_1) is dict
    assert 'user_id' in user_result_dict_1
    assert 'user_uid' in user_result_dict_1
    assert 'user_gid' in user_result_dict_1
    assert 'user_gecos' in user_result_dict_1
    assert 'user_dir' in user_result_dict_1
    assert 'user_shell' in user_result_dict_1
    assert 'real_user_id' in user_result_dict_1
    assert 'effective_user_id' in user_result_dict_1

# Generated at 2022-06-25 00:44:29.652913
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    assert user_fact_collector_0.collect() is not None

# Generated at 2022-06-25 00:44:31.806526
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()


# Generated at 2022-06-25 00:44:35.850598
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts_test = user_fact_collector.collect()
    assert isinstance(user_facts_test, dict)

# Generated at 2022-06-25 00:44:42.365192
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    result = user_fact_collector_0.collect()
    assert result == {'user_id': 'root', 'real_user_id': 0, 'user_gid': 0, 'effective_group_id': 0, 'effective_user_id': 0, 'user_uid': 0, 'user_gecos': 'root,,,', 'user_dir': '/root', 'user_shell': '/bin/bash', 'real_group_id': 0}

# Generated at 2022-06-25 00:44:43.481774
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    try:
        assert UserFactCollector().collect() is not None
    except Exception:
        assert False

# Generated at 2022-06-25 00:44:48.241902
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    """Test if facts are collected correctly"""
    user_fact_collector = UserFactCollector()

    collected_facts = user_fact_collector.collect()

    assert collected_facts['user_id'] == getpass.getuser()

# Generated at 2022-06-25 00:44:54.011061
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_facts = user_fact_collector_1.collect()
    print("user_facts collected: ")
    print(user_facts)


# Generated at 2022-06-25 00:45:00.856058
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    result = user_fact_collector.collect()
    assert result['user_id'] == 'root'
    assert result['user_uid'] == 0
    assert result['user_gid'] == 0
    assert result['user_gecos'] == 'root'
    assert result['user_dir'] == '/root'
    assert result['user_shell'] == '/bin/bash'
    assert result['real_user_id'] == 0
    assert result['effective_user_id'] == 0
    assert result['real_group_id'] == 0
    assert result['effective_group_id'] == 0



# Generated at 2022-06-25 00:45:04.562031
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
        pass

# Generated at 2022-06-25 00:45:14.833626
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()

    collected_facts = {}

    user_facts = user_fact_collector_0.collect(collected_facts=collected_facts)

    assert isinstance(user_facts, dict)
    assert 'effective_group_ids' in user_facts
    assert 'effective_user_id' in user_facts
    assert 'real_group_id' in user_facts
    assert 'real_user_id' in user_facts
    assert 'user_dir' in user_facts
    assert 'user_gecos' in user_facts
    assert 'user_gid' in user_facts
    assert 'user_id' in user_facts
    assert 'user_shell' in user_facts
    assert 'user_uid' in user_facts


# Generated at 2022-06-25 00:45:17.460218
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    try:
        user_fact_collector_0.collect()
    except Exception:
        assert False
    else:
        assert True



# Generated at 2022-06-25 00:45:27.812887
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()
    assert 'user_id' in user_facts.keys()
    assert 'user_uid' in user_facts.keys()
    assert 'user_gid' in user_facts.keys()
    assert 'user_gecos' in user_facts.keys()
    assert 'user_dir' in user_facts.keys()
    assert 'user_shell' in user_facts.keys()
    assert 'real_user_id' in user_facts.keys()
    assert 'effective_user_id' in user_facts.keys()
    assert 'effective_group_ids' in user_facts.keys()
    assert user_facts['user_id']
    assert user_facts['user_uid']
    assert user_facts

# Generated at 2022-06-25 00:45:31.033490
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()

    user_fact_collector_0.collect()

# Generated at 2022-06-25 00:45:37.991783
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_1 = UserFactCollector()
    user_fact_collector_2 = UserFactCollector()
    user_fact_collector_3 = UserFactCollector()
    user_fact_collector_4 = UserFactCollector()
    user_fact_collector_5 = UserFactCollector()
    user_fact_collector_6 = UserFactCollector()
    user_fact_collector_7 = UserFactCollector()
    user_fact_collector_8 = UserFactCollector()
    user_fact_collector_9 = UserFactCollector()
    user_fact_collector_10 = UserFactCollector()

    user_fact_collector_1.collect()

# Generated at 2022-06-25 00:45:39.077441
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()

# Generated at 2022-06-25 00:45:40.502437
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_facts = user_fact_collector_1.collect()

# Generated at 2022-06-25 00:45:48.870107
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    pwent = pwd.getpwuid(os.getuid())

    user_facts = user_fact_collector_0.collect()
    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['user_uid'] == pwent.pw_uid
    assert user_facts['user_gid'] == pwent.pw_gid
    assert user_facts['user_gecos'] == pwent.pw_gecos
    assert user_facts['user_dir'] == pwent.pw_dir
    assert user_facts['user_shell'] == pwent.pw_shell
    assert user_facts['real_user_id'] == os.getuid()
    assert user_facts['effective_user_id']

# Generated at 2022-06-25 00:45:57.478627
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_facts_1 = user_fact_collector_1.collect()

# Generated at 2022-06-25 00:46:02.364799
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect()
    assert var_0 != None

# Generated at 2022-06-25 00:46:03.913300
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    var_0 = user_fact_collector.collect()
    assert var_0 is not None, "collect() returns none"


# Generated at 2022-06-25 00:46:07.454719
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect()
    var_1 = user_fact_collector_0.collect()

# Generated at 2022-06-25 00:46:09.210748
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    pass

# Generated at 2022-06-25 00:46:10.755537
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    # Call method collect of UserFactCollector
    test_case_0()

# Generated at 2022-06-25 00:46:13.095698
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    var = user_fact_collector.collect()

    assert True

# Generated at 2022-06-25 00:46:15.564847
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect()
    assert(isinstance(var_0, dict))


# Generated at 2022-06-25 00:46:16.388652
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    test_case_0()


# Generated at 2022-06-25 00:46:17.498207
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    result = UserFactCollector.collect()



# Generated at 2022-06-25 00:46:19.143700
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_2 = UserFactCollector()
    var_2 = user_fact_collector_2.collect()


# Generated at 2022-06-25 00:46:27.348575
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    var = user_fact_collector.collect()
    print(var)
    #assert isinstance(var, dict)


# Generated at 2022-06-25 00:46:35.363433
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_2 = UserFactCollector()
    var_2 = user_fact_collector_2.collect()

    # Verify type of the returned value
    assert isinstance(var_2, dict)

    # Verify the content of the returned value
    assert 'user_id' in var_2
    assert 'user_uid' in var_2
    assert 'user_gid' in var_2
    assert 'user_gecos' in var_2
    assert 'user_dir' in var_2
    assert 'user_shell' in var_2
    assert 'real_user_id' in var_2
    assert 'effective_user_id' in var_2
    assert 'real_group_id' in var_2
    assert 'effective_group_id' in var_2



# Generated at 2022-06-25 00:46:39.822527
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect()
    var_1 = user_fact_collector_0.collect()
    assert isinstance(var_0, dict)
    assert isinstance(var_1, dict)



# Generated at 2022-06-25 00:46:47.102362
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect()
    assert var_0 == {'effective_group_id': os.getgid(), 'user_dir': pwnam.pw_dir, 'user_gecos': pwnam.pw_gecos, 'user_uid': pwnam.pw_uid, 'user_shell': pwnam.pw_shell, 'user_gid': pwnam.pw_gid, 'real_group_id': os.getgid(), 'effective_user_id': os.geteuid(), 'user_id': getpass.getuser(), 'real_user_id': os.getuid()}


# Generated at 2022-06-25 00:46:49.466535
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_2 = UserFactCollector()
    assert isinstance(user_fact_collector_2.collect(), dict)


# Generated at 2022-06-25 00:46:53.094965
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect()
    user_fact_collector_1 = UserFactCollector()

# Generated at 2022-06-25 00:46:59.224504
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    # Create an instance of ArgumentSpec
    argument_spec = dict()

    # Create a instance of AnsibleModule
    ansible_module = AnsibleModule(argument_spec=argument_spec, supports_check_mode=True)

    # Check if module has been called
    if ansible_module.check_mode:
        ansible_module.exit_json(changed=False)

    ansible_module.exit_json(ansible_facts=UserFactCollector().collect(ansible_module))
    exit_json(changed=False)


# Import Ansible utilities
from ansible.module_utils.basic import *

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 00:47:05.198098
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect()
    assert var_0 == {'user_id': 'vagrant', 'user_uid': 1000, 'user_gid': 1000, 'user_gecos': 'vagrant,,,', 'user_dir': '/home/vagrant', 'user_shell': '/bin/bash', 'real_user_id': 1000, 'effective_user_id': 1000, 'real_group_id': 1000, 'effective_group_id': 1000}

# Generated at 2022-06-25 00:47:07.532415
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect()
    user_fact_collector_1 = UserFactCollector()


# Generated at 2022-06-25 00:47:10.915369
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Execution
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect()

    # Verification
    assert var_0 is not None

    # Cleans
    user_fact_collector_0 = None
    var_0 = None

# Generated at 2022-06-25 00:47:27.568101
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect()
    assert var_0 is not None and isinstance(var_0, dict)


# Generated at 2022-06-25 00:47:29.184281
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    var_0 = UserFactCollector()
    var_0.collect()


# Generated at 2022-06-25 00:47:31.826704
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_3 = UserFactCollector()
    var_3 = user_fact_collector_3.collect( module=None, collected_facts=None )


# Generated at 2022-06-25 00:47:38.846960
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect()
    user_fact_collector_1 = UserFactCollector()
    user_fact_collector_2 = UserFactCollector()
    var_2 = user_fact_collector_2.collect()
    user_fact_collector_1 = UserFactCollector()
    from ansible.module_utils.facts.collector import BaseFactCollector
    user_fact_collector_3 = BaseFactCollector('user')
    var_3 = user_fact_collector_3.collect()

# Generated at 2022-06-25 00:47:48.793585
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_2 = UserFactCollector()

    var_0 = user_fact_collector_2.collect()

    assert var_0['user_id'] == getpass.getuser()
    assert var_0['user_uid'] == pwd.getpwuid(os.getuid()).pw_uid
    assert var_0['user_gid'] == pwd.getpwuid(os.getuid()).pw_gid
    assert var_0['user_gecos'] == pwd.getpwuid(os.getuid()).pw_gecos
    assert var_0['user_dir'] == pwd.getpwuid(os.getuid()).pw_dir

# Generated at 2022-06-25 00:47:50.475249
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_2 = UserFactCollector()
    var_0 = user_fact_collector_2.collect()


# Generated at 2022-06-25 00:47:56.456159
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect()
    print(var_0)

    # Verify user_id and real_user_id
    assert var_0['user_id'] == var_0['real_user_id']

    import os
    user_id = os.getuid()

    assert var_0['real_user_id'] == user_id


# Generated at 2022-06-25 00:47:57.396699
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    assert UserFactCollector.collect() != None

# Generated at 2022-06-25 00:48:04.046828
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    expected = {
        'effective_group_id': short_group_0,
        'effective_user_id': short_user_0,
        'real_group_id': short_group_0,
        'real_user_id': short_user_0,
        'user_dir': '/home/ansible',
        'user_gid': 1000,
        'user_gecos': 'Ansible User',
        'user_id': short_user_0,
        'user_shell': '/bin/bash',
        'user_uid': 1000,
    }
    assert user_fact_collector_0.collect() == expected

# Generated at 2022-06-25 00:48:06.042540
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect()


# Generated at 2022-06-25 00:48:39.326009
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    var_0 = user_fact_collector.collect()
    assert var_0 is not None


# Generated at 2022-06-25 00:48:43.342268
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_2 = UserFactCollector()
    var_1 = user_fact_collector_2.collect()


# Generated at 2022-06-25 00:48:47.545827
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_2 = UserFactCollector()
    var_2 = user_fact_collector_2.collect()
    assert var_2.keys() == [u'user_id', u'user_shell', u'real_user_id', u'effective_group_ids', u'effective_user_id', u'user_gid', u'user_uid', u'user_gecos', u'real_group_id', u'user_dir']
    assert var_2['user_id'] == 'root'
    assert var_2['real_user_id'] == 0
    assert var_2['user_uid'] == 0
    assert var_2['user_gecos'] == 'root'
    assert var_2['effective_user_id'] == 0
    assert var_2['user_gid']

# Generated at 2022-06-25 00:48:48.717894
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect()

# Generated at 2022-06-25 00:48:49.308332
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    test_case_0()

# Generated at 2022-06-25 00:48:54.110054
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    assert type(user_fact_collector_0.collect()) == dict


# Generated at 2022-06-25 00:48:57.265354
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_2 = UserFactCollector()
    print("  _fact_ids: ", user_fact_collector_2._fact_ids)
    print("  name: ", user_fact_collector_2.name)
    var_0 = UserFactCollector()
    print(var_0.collect())
    assert True

if __name__ == "__main__":
    test_UserFactCollector_collect()

# Generated at 2022-06-25 00:49:01.127292
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect()
    assert var_0 != None
    assert var_0 != False
    assert var_0 != True



# Generated at 2022-06-25 00:49:02.681570
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    input0 = UserFactCollector()
    return_value = input0.collect()
    assert return_value is None


# Generated at 2022-06-25 00:49:06.831703
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    with patch('pwd.getpwnam') as patched_getpwnam:
        patched_getpwnam.return_value = Struct(**{
            'pw_uid': 'test_pw_uid_0',
            'pw_gid': 'test_pw_gid_0',
            'pw_gecos': 'test_pw_gecos_0',
            'pw_dir': 'test_pw_dir_0',
            'pw_shell': 'test_pw_shell_0',
        })

# Generated at 2022-06-25 00:50:11.475246
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    assert user_fact_collector.collect().values() == [getpass.getuser(), pwd.getpwnam(getpass.getuser()).pw_uid, pwd.getpwnam(getpass.getuser()).pw_gid, pwd.getpwnam(getpass.getuser()).pw_gecos, pwd.getpwnam(getpass.getuser()).pw_dir, pwd.getpwnam(getpass.getuser()).pw_shell, os.getuid(), os.geteuid(), os.getgid(), os.getgid()]

test_UserFactCollector_collect()

# Generated at 2022-06-25 00:50:12.301490
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    assert_equals(UserFactCollector().collect(), {})

# Generated at 2022-06-25 00:50:14.228427
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_2 = UserFactCollector()
    var_0 = user_fact_collector_2.collect()


# Generated at 2022-06-25 00:50:16.733729
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect()


# Generated at 2022-06-25 00:50:18.708762
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect()


# Generated at 2022-06-25 00:50:23.229636
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Test cases of method collect
    # Test cases of method collect

    t0 = test_case_0()


# Generated at 2022-06-25 00:50:25.004870
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_2 = UserFactCollector()
    var_1 = user_fact_collector_2.collect()

# Generated at 2022-06-25 00:50:26.965254
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_2 = UserFactCollector()
    var_0 = user_fact_collector_2.collect()
    user_fact_collector_3 = UserFactCollector()


# Generated at 2022-06-25 00:50:33.479413
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect()
    assert var_0['user_uid'] == 501
    assert var_0['user_id'] == 'jdoe'
    assert var_0['effective_user_id'] == 0
    assert var_0['effective_group_ids'] == []
    assert var_0['user_dir'] == '/Users/jdoe'
    assert var_0['user_shell'] == '/bin/bash'
    assert var_0['user_gid'] == 20
    assert var_0['real_user_id'] == 0
    assert var_0['user_gecos'] == 'John Doe,work'

# Generated at 2022-06-25 00:50:38.508271
# Unit test for method collect of class UserFactCollector

# Generated at 2022-06-25 00:53:13.213867
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    var = user_fact_collector.collect()


# Generated at 2022-06-25 00:53:13.588545
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    pass

# Generated at 2022-06-25 00:53:14.950340
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect()


# Generated at 2022-06-25 00:53:22.466072
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    var_6 = user_fact_collector_0.collect()
    assert len(var_6) == 8
    assert var_6['user_id'] == 'vagrant'
    assert var_6['user_uid'] == 1000
    assert var_6['user_gid'] == 1000
    assert var_6['user_gecos'] == 'vagrant,,,::/home/vagrant:/bin/bash'
    assert var_6['user_dir'] == '/home/vagrant'
    assert var_6['user_shell'] == '/bin/bash'
    assert var_6['real_user_id'] == 1000
    assert var_6['effective_user_id'] == 1000


# Generated at 2022-06-25 00:53:23.885422
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
  user_fact_collector_0 = UserFactCollector()
  var_0 = user_fact_collector_0.collect()
  assert isinstance(var_0, dict)


# Generated at 2022-06-25 00:53:26.887827
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_2 = UserFactCollector()



# Generated at 2022-06-25 00:53:29.072472
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect()
    user_fact_collector_1 = UserFactCollector()
    assert user_fact_collector_0.collect() == user_fact_collector_1.collect()


# Generated at 2022-06-25 00:53:35.173267
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    collected_facts = {}
    collected_facts['user'] = user_fact_collector.collect()
    assert collected_facts['user'] == {'user_id': 'ansadmin', 'user_uid': 2, 'user_gid': 2, 'user_gecos': '', 'user_dir': '/home/ansadmin', 'user_shell': '/bin/bash', 'real_user_id': 2, 'effective_user_id': 2, 'real_group_id': 2, 'effective_group_id': 2}


# Generated at 2022-06-25 00:53:36.545087
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()

    var_1 = user_fact_collector.collect()

    assert True is True

# Generated at 2022-06-25 00:53:40.971089
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect()
    assert var_0 == {'effective_group_id': 1000, 'effective_user_id': 1000, 'real_group_id': 1000, 'real_user_id': 1000, 'user_dir': '/home/gozer', 'user_gecos': 'gozer', 'user_gid': 1000, 'user_id': 'gozer', 'user_shell': '/bin/bash', 'user_uid': 1000}
