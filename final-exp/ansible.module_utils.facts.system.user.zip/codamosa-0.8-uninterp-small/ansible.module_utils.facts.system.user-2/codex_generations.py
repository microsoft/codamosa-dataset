

# Generated at 2022-06-25 00:44:17.143608
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()

# Generated at 2022-06-25 00:44:20.993286
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_collect_0 = UserFactCollector()
    user_fact_collector_collect_1 = user_fact_collector_collect_0.collect()
    print(user_fact_collector_collect_1)


# Generated at 2022-06-25 00:44:31.427820
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()

    user_facts = user_fact_collector_1.collect()

    # Assert that the user_id is not empty
    assert user_facts['user_id']
    # Assert that the effective_user_id is not empty
    assert user_facts['effective_user_id']
    # Assert that the real_user_id is not empty
    assert user_facts['real_user_id']
    # Assert that the effective_group_id is not empty
    assert user_facts['effective_group_id']
    # Assert that the real_group_id is not empty
    assert user_facts['real_group_id']
    # Assert that the user_shell is not empty
    assert user_facts['user_shell']
    # Assert that the

# Generated at 2022-06-25 00:44:32.760802
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    fact_collector = UserFactCollector()
    fact_collector.collect()


# Generated at 2022-06-25 00:44:36.353546
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()
    #assertTrue(user_facts['user_id'] == )

# Generated at 2022-06-25 00:44:40.200974
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    collected_facts = dict()
    user_fact_collector_0.collect(collected_facts=collected_facts)


# Generated at 2022-06-25 00:44:49.343853
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_facts = user_fact_collector_0.collect()
    assert isinstance(user_facts, dict)
    assert 'user_id' in user_facts
    assert 'user_uid' in user_facts
    assert 'user_gid' in user_facts
    assert 'user_gecos' in user_facts
    assert 'user_dir' in user_facts
    assert 'user_shell' in user_facts
    assert 'real_user_id' in user_facts
    assert 'effective_user_id' in user_facts
    assert 'real_group_id' in user_facts
    assert 'effective_group_id' in user_facts

# Generated at 2022-06-25 00:44:50.716942
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_fact_collector.collect()

# Generated at 2022-06-25 00:45:00.201056
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    test_user_facts = {}
    test_user_facts['user_id'] = getpass.getuser()
    try:
        pwent = pwd.getpwnam(getpass.getuser())
    except KeyError:
        pwent = pwd.getpwuid(os.getuid())
    test_user_facts['user_uid'] = pwent.pw_uid
    test_user_facts['user_gid'] = pwent.pw_gid
    test_user_facts['user_gecos'] = pwent.pw_gecos
    test_user_facts['user_dir'] = pwent.pw_dir
    test_user_facts['user_shell'] = pwent.pw_shell
    test_user_facts

# Generated at 2022-06-25 00:45:02.279001
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    with pytest.raises(TypeError):
        user_fact_collector_0.collect(module=None, collected_facts=None)

# Generated at 2022-06-25 00:45:15.433575
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts_output = {
        "user_id": getpass.getuser(), "user_uid": os.getuid(), "user_gid": os.getgid(),
        "user_gecos": pwd.getpwuid(os.getuid()).pw_gecos, "user_dir": pwd.getpwuid(os.getuid()).pw_dir,
        "user_shell": pwd.getpwuid(os.getuid()).pw_shell, "real_user_id": os.getuid(),
        "effective_user_id": os.geteuid(), "real_group_id": os.getgid(), "effective_group_id": os.getegid()
    }

# Generated at 2022-06-25 00:45:16.998570
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()

# Generated at 2022-06-25 00:45:19.554906
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_fact_collector_1.collect()

# Generated at 2022-06-25 00:45:28.787075
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    assert(UserFactCollector().collect().get('user_id') == getpass.getuser())
    assert(UserFactCollector().collect().get('user_uid') == pwd.getpwuid(os.getuid()).pw_uid)
    assert(UserFactCollector().collect().get('user_gid') == pwd.getpwuid(os.getuid()).pw_gid)
    assert(UserFactCollector().collect().get('user_gecos') == pwd.getpwuid(os.getuid()).pw_gecos)
    assert(UserFactCollector().collect().get('user_dir') == pwd.getpwuid(os.getuid()).pw_dir)

# Generated at 2022-06-25 00:45:32.457056
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_collect_case_0 = UserFactCollector()
    result_0 = user_fact_collector_collect_case_0.collect()
    assert isinstance(result_0, dict)


# Generated at 2022-06-25 00:45:35.451578
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    try:
        user_fact_collector_1_test = user_fact_collector_1.collect()
        assert True
    except Exception:
        assert False
    else:
        assert True


# Generated at 2022-06-25 00:45:41.708250
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_collect = UserFactCollector()
    user_facts = user_fact_collector_collect.collect()
    assert all(key in user_facts for key in [
        'user_id', 'user_uid', 'user_gid', 'user_gecos', 'user_dir', 'user_shell',
        'effective_user_id', 'effective_group_id', 'real_user_id', 'real_group_id'
    ])

# Generated at 2022-06-25 00:45:44.437691
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_fact_collector_collect = user_fact_collector.collect()
    assert isinstance(user_fact_collector_collect, dict)

# Generated at 2022-06-25 00:45:48.029101
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector2 = UserFactCollector()
    collected_facts = {}
    user_facts = user_fact_collector2.collect(collected_facts)
    print(user_facts)
    print(collected_facts)


test_UserFactCollector_collect()

# Generated at 2022-06-25 00:45:49.268842
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()

# Generated at 2022-06-25 00:46:03.072049
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    # Test function return type
    assert(isinstance(UserFactCollector().collect(), dict))

    # Test length of function return type
    assert(len(UserFactCollector().collect()) > 0)

    # Test function return type
    assert(isinstance(UserFactCollector(module=['user_id']).collect(), dict))

    # Test length of function return type
    assert(len(UserFactCollector(module=['user_id']).collect()) == 1)

    # Test function return type
    assert(isinstance(UserFactCollector(module=['user_gecos']).collect(), dict))

    # Test length of function return type
    assert(len(UserFactCollector(module=['user_gecos']).collect()) == 1)

    # Test function return type

# Generated at 2022-06-25 00:46:11.485890
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    ansible_facts = user_fact_collector_0.collect()
    assert isinstance(ansible_facts, dict)
    assert 'user_id' in ansible_facts
    assert 'user_uid' in ansible_facts
    assert 'user_gid' in ansible_facts
    assert 'user_gecos' in ansible_facts
    assert 'user_dir' in ansible_facts
    assert 'user_shell' in ansible_facts
    assert 'real_user_id' in ansible_facts
    assert 'effective_user_id' in ansible_facts
    assert 'real_group_id' in ansible_facts
    assert 'effective_group_id' in ansible_facts


# Generated at 2022-06-25 00:46:13.721548
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    assert user_fact_collector_0.collect()


# Generated at 2022-06-25 00:46:18.306039
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    collected_facts_0 = dict()
    local_facts_0 = user_fact_collector_0.collect(collected_facts_0)
    local_facts_1 = user_fact_collector_0.collect(collected_facts_0)
    assert local_facts_0 == local_facts_1
    assert local_facts_1 == dict()


# Generated at 2022-06-25 00:46:27.412968
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_facts_1 = user_fact_collector_1.collect()
    assert 'user_id' in user_facts_1
    assert 'user_uid' in user_facts_1
    assert 'user_gid' in user_facts_1
    assert 'user_gecos' in user_facts_1
    assert 'user_dir' in user_facts_1
    assert 'user_shell' in user_facts_1
    assert 'real_user_id' in user_facts_1
    assert 'effective_user_id' in user_facts_1
    assert 'real_group_id' in user_facts_1
    assert 'effective_group_id' in user_facts_1

# Generated at 2022-06-25 00:46:35.426508
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    print ("Starting test_UserFactCollector_collect")
    # UserFactCollector object creation
    user_fact_collector_0 = UserFactCollector()
    #Testing for exception for collect method
    try:
        user_fact_collector_0.collect()
    except NotImplementedError as e:
        print ("Exception message : " + str(e))
    # Creating fake collected_facts
    collected_facts_0 = dict()
    # Testing with collected_facts as dict
    try:
        user_fact_collector_0.collect(collected_facts=collected_facts_0)
        print ("UserFactCollector.collect() works for collected_facts as dict")
    except TypeError as e:
        print ("Exception message : " + str(e))
    # Testing with collected_facts as None

# Generated at 2022-06-25 00:46:38.819613
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_facts = user_fact_collector_0.collect()

    assert 'user_id' in user_facts



# Generated at 2022-06-25 00:46:44.035099
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()

    user_facts_1 = user_fact_collector_1.collect()
    assert(user_facts_1['user_id'] == getpass.getuser())

    try:
        pwent = pwd.getpwnam(getpass.getuser())
    except KeyError:
        pwent = pwd.getpwuid(os.getuid())

    assert(user_facts_1['user_uid'] == pwent.pw_uid)
    assert(user_facts_1['user_gid'] == pwent.pw_gid)
    assert(user_facts_1['user_gecos'] == pwent.pw_gecos)
    assert(user_facts_1['user_dir'] == pwent.pw_dir)


# Generated at 2022-06-25 00:46:49.476667
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()

    user_facts = user_fact_collector_1.collect()

    print(user_facts)
    assert user_facts['user_id']
    assert user_facts['user_uid']
    assert user_facts['user_gid']
    assert user_facts['user_gecos']
    assert user_facts['user_dir']
    assert user_facts['user_shell']
    assert user_facts['real_user_id']
    assert user_facts['effective_user_id']
    assert user_facts['real_group_id']
    assert user_facts['effective_group_id']


# Generated at 2022-06-25 00:46:54.506105
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    found_facts = user_fact_collector_0.collect()
    assert found_facts['user_id'] == getpass.getuser()
    assert found_facts['user_dir'] == pwd.getpwuid(os.getuid()).pw_dir

# Generated at 2022-06-25 00:47:10.977385
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_facts = user_fact_collector_0.collect()
    assert(user_facts['user_id'] == getpass.getuser())
    assert(user_facts['real_user_id'] == os.getuid())

if __name__ == '__main__':
    test_UserFactCollector_collect()

# Generated at 2022-06-25 00:47:20.854825
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()

# Generated at 2022-06-25 00:47:24.337421
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_facts = user_fact_collector_0.collect()
    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['real_user_id'] == os.getuid()


# Generated at 2022-06-25 00:47:28.869752
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    user_fact_collector_1 = UserFactCollector()
    user_facts_test_1 = user_fact_collector_1.collect()

    assert user_facts_test_1['user_id'] == getpass.getuser()

    assert set(user_facts_test_1) == UserFactCollector._fact_ids

# Generated at 2022-06-25 00:47:30.995808
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_fact_collector_1.collect()

test_case_0()
test_UserFactCollector_collect()

# Generated at 2022-06-25 00:47:32.311902
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()


# Generated at 2022-06-25 00:47:40.154891
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    
    user_fact_collector_1_fact_list = ['user_id', 'user_uid', 'user_gid',
                                       'user_gecos', 'user_dir', 'user_shell',
                                       'real_user_id', 'effective_user_id',
                                       'effective_group_ids']


# Generated at 2022-06-25 00:47:41.684554
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()

# Generated at 2022-06-25 00:47:42.499987
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # No tests needed
    pass

# Generated at 2022-06-25 00:47:45.331440
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    collected_facts = {}
    user_fact_collector_1.collect(None, collected_facts)


# Generated at 2022-06-25 00:48:05.181132
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_2 = UserFactCollector(None)
    assert user_fact_collector_2.collect() == {'user_id': 'root',
                                               'user_uid': 0,
                                               'user_gid': 0,
                                               'user_gecos': 'root',
                                               'user_dir': '/root',
                                               'user_shell': '/bin/bash',
                                               'effective_user_id': 0,
                                               'effective_group_id': 0,
                                               'real_user_id': 0,
                                               'real_group_id': 0}


# Generated at 2022-06-25 00:48:08.826029
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    dict_0 = {}
    list_0 = None
    user_fact_collector_0 = UserFactCollector(list_0)
    user_fact_collector_1 = UserFactCollector(dict_0)
    var_0 = user_fact_collector_1.collect()


# Generated at 2022-06-25 00:48:10.057889
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    list_0 = None
    user_fact_collector_0.collect(list_0)


# Generated at 2022-06-25 00:48:12.907554
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    dict_0 = {}
    list_0 = None
    user_fact_collector_0 = UserFactCollector(list_0)
    user_fact_collector_1 = UserFactCollector(dict_0)
    user_fact_collector_0.collect()

# Generated at 2022-06-25 00:48:17.440515
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    dict_0 = {}
    list_0 = None
    user_fact_collector_0 = UserFactCollector(list_0)
    user_fact_collector_1 = UserFactCollector(dict_0)
    var_0 = user_fact_collector_1.collect()

# Generated at 2022-06-25 00:48:19.425900
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    dict_0 = {}
    list_0 = None
    user_fact_collector_0 = UserFactCollector(list_0)
    user_fact_collector_1 = UserFactCollector(dict_0)
    var_0 = user_fact_collector_1.collect()

# Generated at 2022-06-25 00:48:28.111292
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    dict_0 = {}
    list_0 = None
    user_fact_collector_0 = UserFactCollector(list_0)
    user_fact_collector_1 = UserFactCollector(dict_0)
    assert user_fact_collector_0.collect() == user_fact_collector_1.collect()
    print("UserFactCollector.collect returns: " + str(user_fact_collector_1.collect()))

if __name__ == "__main__":
    test_case_0()
    test_UserFactCollector_collect()

# Generated at 2022-06-25 00:48:31.309242
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    dict_0 = {}
    list_0 = None
    user_fact_collector = UserFactCollector(list_0)
    user_fact_collector_1 = UserFactCollector(dict_0)
    var_0 = user_fact_collector_1.collect()


# Generated at 2022-06-25 00:48:33.557160
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    dict_0 = {}
    list_0 = None
    user_fact_collector_0 = UserFactCollector(list_0)
    user_fact_collector_1 = UserFactCollector(dict_0)
    var_0 = user_fact_collector_1.collect()



# Generated at 2022-06-25 00:48:44.268707
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    class_0 = UserFactCollector
    list_0 = None
    user_fact_collector_0 = UserFactCollector(list_0)
    assert isinstance(user_fact_collector_0, class_0)
    list_0 = ['user_uid','effective_group_ids','effective_user_id','user_id','user_gid','user_gecos','real_user_id','user_shell','user_dir']
    dict_0 = user_fact_collector_0.collect(list_0)
    list_0 = ['user_uid','effective_group_ids','effective_user_id','user_id','user_gid','user_gecos','real_user_id','user_shell','user_dir']
    dict_1 = user_fact_collector_0.collect(list_0)

# Generated at 2022-06-25 00:49:18.749333
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Setup test environment
    user_fact_collector_0 = UserFactCollector(None)

    # Invoke method
    result = user_fact_collector_0.collect()

    # Check for expected result
    assert result  == None

# Generated at 2022-06-25 00:49:23.838202
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    for item_for_test in [0]:
        user_fact_collector_0 = UserFactCollector()
        var_0 = user_fact_collector_0.collect()
        return


# Generated at 2022-06-25 00:49:27.731876
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    dict_0 = {}
    list_0 = None
    user_fact_collector_0 = UserFactCollector(list_0)
    user_fact_collector_1 = UserFactCollector(dict_0)
    var_0 = user_fact_collector_1.collect()


# Generated at 2022-06-25 00:49:34.352933
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    dict_0 = {}
    list_0 = None
    user_fact_collector_0 = UserFactCollector(list_0)
    user_fact_collector_1 = UserFactCollector(dict_0)
    var_0 = user_fact_collector_1.collect()
    assert var_0 == {}

# Generated at 2022-06-25 00:49:43.253144
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    dict_0 = {}
    list_0 = None
    user_fact_collector_0 = UserFactCollector(list_0)
    user_fact_collector_1 = UserFactCollector(dict_0)
    var_0 = user_fact_collector_0.collect()
    assert var_0.get('user_id') is not None
    assert var_0.get('user_uid') is not None
    assert var_0.get('user_gid') is not None
    assert var_0.get('user_gecos') is not None
    assert var_0.get('user_dir') is not None
    assert var_0.get('user_shell') is not None
    assert var_0.get('real_user_id') is not None

# Generated at 2022-06-25 00:49:49.365400
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    dict_0 = {}
    list_0 = None
    user_fact_collector_0 = UserFactCollector(list_0)
    user_fact_collector_1 = UserFactCollector(dict_0)
    var_0 = user_fact_collector_1.collect()


# Generated at 2022-06-25 00:49:55.070987
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_1 = UserFactCollector()
    var_0 = user_fact_collector_1.collect()

    assertEqual(user_fact_collector_0.name, 'user')

# Generated at 2022-06-25 00:49:57.174845
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_facts_0 = user_fact_collector_0.collect()

    print("User facts: %s" % user_facts_0)


# Generated at 2022-06-25 00:50:03.168266
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    dict_0 = {}
    list_0 = None
    user_fact_collector_0 = UserFactCollector(list_0)
    var_0 = user_fact_collector_0.collect()
    # TODO: assert something!
    return


# Generated at 2022-06-25 00:50:04.493999
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # This will try to collect facts from the real user
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect()

# Generated at 2022-06-25 00:51:30.986744
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ansible_0 = UserFactCollector()
    ansible_1 = UserFactCollector()
    dict_0 = dict()
    dict_0 = None
    dict_0 = UserFactCollector()
    dict_0 = {'user_id': 'linuxuser', 'user_shell': '/bin/bash', 'user_gecos': '', 'user_gid': 1000, 'effective_user_id': 1000, 'user_uid': 1000, 'effective_group_ids': [], 'user_dir': '/home/linuxuser', 'real_user_id': 1000}
    dict_0 = dict_0.collect()


# Generated at 2022-06-25 00:51:37.897514
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    # Create a new instance of UserFactCollector
    user_fact_collector = UserFactCollector()

    # Retrieve facts
    facts = user_fact_collector.collect()

    # Check that facts match the data we expect
    assert facts['user_id'] == getpass.getuser()
    assert facts['user_uid'] == os.getuid()
    assert facts['user_gid'] == os.getgid()
    assert facts['user_gecos'] == pwd.getpwuid(os.getuid()).pw_gecos
    assert facts['user_dir'] == pwd.getpwuid(os.getuid()).pw_dir
    assert facts['user_shell'] == pwd.getpwuid(os.getuid()).pw_shell

# Generated at 2022-06-25 00:51:42.800624
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    dict_0 = {}
    list_0 = None
    user_fact_collector_0 = UserFactCollector(list_0)
    user_fact_collector_1 = UserFactCollector(dict_0)
    user_fact_collector_0.collect()
    var_0 = user_fact_collector_1.collect()


# Generated at 2022-06-25 00:51:45.241328
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()

# Generated at 2022-06-25 00:51:49.976268
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    dict_0 = {}
    list_0 = None
    user_fact_collector_0 = UserFactCollector(dict_0, list_0)
    user_fact_collector_1 = UserFactCollector(dict_0, list_0)
    dict_1 = user_fact_collector_0.collect()
    assert isinstance(dict_1, dict)


# Generated at 2022-06-25 00:51:56.282231
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    dict_0 = {'chdir': '/', 'gecos': 'Ernest Hemingway,,,', 'pw_dir': '/home/ernie/', 'pw_gid': 1001, 'pw_name': 'ernie', 'pw_shell': '/bin/bash', 'pw_uid': 1001}
    list_0 = None
    user_fact_collector_0 = UserFactCollector(list_0)

# Generated at 2022-06-25 00:52:01.572243
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect()
    assert var_0['effective_user_id'] != None
    assert var_0['user_dir'] != None
    assert var_0['real_user_id'] != None
    assert var_0['user_gid'] != None
    assert var_0['user_gecos'] != None
    assert var_0['user_id'] != None
    assert var_0['user_id'] == getpass.getuser()
    assert var_0['user_shell'] != None
    assert var_0['user_uid'] != None


# Generated at 2022-06-25 00:52:09.061897
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    dict_0 = {}
    list_0 = None
    user_fact_collector_0 = UserFactCollector(list_0)
    user_fact_collector_0.collect()
    var_0 = user_fact_collector_0.collect()
    user_fact_collector_1 = UserFactCollector(dict_0)
    var_0 = user_fact_collector_1.collect()


# Generated at 2022-06-25 00:52:14.506607
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    dict_1 = {}
    list_1 = [dict_1]
    user_fact_collector_2 = UserFactCollector(list_1)
    var_1 = True
    try:
        var_2 = user_fact_collector_2.collect(dict_1)
    except:
        var_1 = False
    assert var_1


# Generated at 2022-06-25 00:52:16.666882
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    pass