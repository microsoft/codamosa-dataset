

# Generated at 2022-06-25 00:44:13.766144
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    if user_fact_collector.collect()['user_id'] != getpass.getuser():
        return 1
    else:
        return 0


# Generated at 2022-06-25 00:44:20.641041
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    user_fact_collector_1 = UserFactCollector()
    collected_facts = {}
    user_facts = user_fact_collector_1.collect(module=None, collected_facts=collected_facts)
    # Some minimal test
    assert len(user_facts['user_id']) > 0
    assert len(user_facts['user_shell']) > 0

# Generated at 2022-06-25 00:44:26.200067
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_facts = user_fact_collector_0.collect()
    assert type(user_facts) is dict
    assert user_facts['user_id'] == getpass.getuser()


# Generated at 2022-06-25 00:44:30.963051
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
  user_fact_collector_0 = UserFactCollector()
  assert isinstance(user_fact_collector_0.collect(), dict)

# Generated at 2022-06-25 00:44:40.184378
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_facts_0 = user_fact_collector_0.collect()
    assert '_fact_ids' in user_facts_0
    assert 'user_id' in user_facts_0
    assert 'user_uid' in user_facts_0
    assert 'user_gid' in user_facts_0
    assert 'user_gecos' in user_facts_0
    assert 'user_dir' in user_facts_0
    assert 'user_shell' in user_facts_0
    assert 'real_user_id' in user_facts_0
    assert 'effective_user_id' in user_facts_0
    assert 'effective_group_ids' in user_facts_0


# Generated at 2022-06-25 00:44:49.936298
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    # Ugly, but I've not found another way to do this
    user_facts = user_fact_collector.collect()

# Generated at 2022-06-25 00:44:58.269937
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_facts_dict_1 = dict({'user_uid': 10, 'user_shell': '/bin/true', 'user_gid': 10, 'effective_user_id': 10, 'real_user_id': 10, 'effective_group_id': 10, 'real_group_id': 10, 'user_id': 'luckydonald', 'user_gecos': 'Lucky Donald', 'user_dir': '/home/luckydonald'})
    assert user_fact_collector_1.collect() == user_facts_dict_1


# Generated at 2022-06-25 00:44:59.763562
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()

    fact_list = user_fact_collector_1.collect()

    assert len(fact_list) == 8
    assert type(fact_list) == dict

# Generated at 2022-06-25 00:45:00.799575
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    UserFactCollector.collect(self=UserFactCollector())

# Generated at 2022-06-25 00:45:06.306585
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    try:
        user_fact_collector_0.collect()
    except Exception as exc:
        print(exc)


# Generated at 2022-06-25 00:45:17.068191
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()

    # Call method collect of UserFactCollector instance user_fact_collector_0
    user_facts = user_fact_collector_0.collect()

    # Assert type of fact user_id of dictionary user_facts is string
    assert isinstance(user_facts['user_id'], str)

    # Assert type of fact user_uid of dictionary user_facts is integer
    assert isinstance(user_facts['user_uid'], int)

    # Assert type of fact user_gid of dictionary user_facts is integer
    assert isinstance(user_facts['user_gid'], int)

    # Assert type of fact user_gecos of dictionary user_facts is string
    assert isinstance(user_facts['user_gecos'], str)

    #

# Generated at 2022-06-25 00:45:23.228408
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    collected_facts = {}

    user_fact_collector.collect(collected_facts=collected_facts)

    assert collected_facts['user_id'] == getpass.getuser()
    assert collected_facts['real_user_id'] == os.getuid()
    assert collected_facts['effective_user_id'] == os.geteuid()

# Generated at 2022-06-25 00:45:30.350270
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    collected_facts = {}
    user_facts = {'effective_user_id': 1000, 'effective_group_id': 1000, 'user_gecos': 'testuser,,,,',
                  'user_shell': '/bin/bash', 'real_user_id': 1000, 'user_id': 'testuser', 'real_group_id': 1000,
                  'user_uid': 1000, 'user_gid': 1000, 'user_dir': '/home/testuser'}
    result = user_fact_collector_1.collect(collected_facts=collected_facts)
    assert result == user_facts


# Generated at 2022-06-25 00:45:33.181316
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    facts_dict_0 = user_fact_collector_0.collect()
    assert not facts_dict_0.keys()[0] == 'user_id'


# Generated at 2022-06-25 00:45:44.066448
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()

    assert user_fact_collector_0.collect() == {'user_id': 'vagrant', 'user_uid': 1000, 'user_gid': 1000, 'user_gecos': 'Vagrant,,,', 'user_dir': '/home/vagrant', 'user_shell': '/bin/bash', 'real_user_id': 1000, 'effective_user_id': 1000, 'real_group_id': 1000, 'effective_group_id': 1000}, "collect_0 failed"


# Test case for the following:
#
# - calling collect() on UserFactCollector object
# - testing _fact_ids of UserFactCollector object

# Generated at 2022-06-25 00:45:48.755173
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # This test method can be used to unit test the method collect() of the
    # class UserFactCollector. The passed test case result (test_case_0) will
    # be used to check if the module executes correctly. If it does, the test
    # script will return a zero exit code, otherwise non-zero.
    test_case_0()
    return 0


# -----------------------------------------------------------------------------

# Generated at 2022-06-25 00:45:57.337979
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    assert 'user_id' in user_fact_collector_1.collect()
    assert 'user_uid' in user_fact_collector_1.collect()
    assert 'user_gid' in user_fact_collector_1.collect()
    assert 'user_gecos' in user_fact_collector_1.collect()
    assert 'user_dir' in user_fact_collector_1.collect()
    assert 'user_shell' in user_fact_collector_1.collect()
    assert 'real_user_id' in user_fact_collector_1.collect()
    assert 'real_group_id' in user_fact_collector_1.collect()

# Generated at 2022-06-25 00:46:07.832919
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    collected_facts = {}
    test_module = None
    collected_facts = user_fact_collector_0.collect(module=test_module, collected_facts=collected_facts)
    assert(collected_facts['user_id'] == getpass.getuser())
    assert(collected_facts['user_gid'] == pwd.getpwuid(os.getuid()).pw_gid)
    assert(collected_facts['user_dir'] == pwd.getpwuid(os.getuid()).pw_dir)
    assert(collected_facts['real_user_id'] == os.getuid())
    assert(collected_facts['effective_user_id'] == os.geteuid())

# Generated at 2022-06-25 00:46:14.004472
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    module = None
    collected_facts = dict()
    result = user_fact_collector_0.collect(module, collected_facts)
    assert isinstance(result, dict)
    for k, v in result.items():
        assert isinstance(k, str)
        assert isinstance(v, (str, int))

# Generated at 2022-06-25 00:46:19.374829
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user = UserFactCollector()

    facts = {"user_id": "tester",
             "user_uid": 1000,
             "user_gid": 1000,
             "user_gecos": "Test, User",
             "user_dir": "/home/tester",
             "user_shell": "/bin/bash",
             "real_user_id": 1000,
             "effective_user_id": 1000,
             "effective_group_ids": [1000]
             }

    output = user.collect()
    assert output == facts


# Generated at 2022-06-25 00:46:28.260990
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    curr_user = getpass.getuser()
    user_fact_collector_0 = UserFactCollector()
    user_facts = user_fact_collector_0.collect()
    if (curr_user != user_facts['user_id']):
        print("Failed to get the User from the system")
        return False
    return True

result = test_case_0()
if result:
    print("UserFactCollector test case passed")
else:
    print("UserFactCollector test case failed")

# Generated at 2022-06-25 00:46:30.023659
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    assert isinstance(user_fact_collector_0.collect(), dict)

# Generated at 2022-06-25 00:46:34.338989
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()

    # Test with a module parameter
    module_1_facts_1 = dict()
    try:
        module_1_facts_1['user_id'] = getpass.getuser()
    except KeyError:
        module_1_facts_1['user_id'] = None

    # Test with a collected facts parameter
    collected_facts_1 = dict()
    collected_facts_1 = user_fact_collector_1.collect()

    # Test with both module and collected facts parameters
    collected_facts_2 = dict()
    collected_facts_2 = user_fact_collector_1.collect(collected_facts=collected_facts_1)

    # Test that the method returns a dict
    assert isinstance(collected_facts_1, dict)

   

# Generated at 2022-06-25 00:46:37.502523
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()


# Generated at 2022-06-25 00:46:45.672380
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Collect user facts
    user_fact_collector_1 = UserFactCollector()
    collected_facts = user_fact_collector_1.collect()
    try:
        assert collected_facts['user_id'] == getpass.getuser()
    except KeyError:
        assert false
    try:
        assert pwd.getpwnam(getpass.getuser()) == pwd.getpwuid(collected_facts['user_uid'])
    except KeyError:
        assert false
    try:
        assert collected_facts['user_gid'] == pwd.getpwnam(getpass.getuser()).pw_gid
    except KeyError:
        assert false

# Generated at 2022-06-25 00:46:53.609605
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect(None, None)
    user_fact_collector_1 = UserFactCollector()
    user_fact_collector_1.collect(None, None)
    user_fact_collector_2 = UserFactCollector()
    user_fact_collector_2.collect(None, None)
    user_fact_collector_3 = UserFactCollector()
    user_fact_collector_3.collect(None, None)

# Generated at 2022-06-25 00:46:55.176294
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    assert not user_fact_collector_1.collect()

# Generated at 2022-06-25 00:46:58.430166
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()

# Generated at 2022-06-25 00:46:59.875241
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()

# Generated at 2022-06-25 00:47:04.191221
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Getting the base class
    user_fact_collector_class_0 = UserFactCollector()
    # Getting the method collect
    method_0 = getattr(user_fact_collector_class_0, "collect")
    # Calling the method
    assert method_0(user_fact_collector_class_0) is None

# Generated at 2022-06-25 00:47:13.286911
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    collected_facts = {}
    facts = user_fact_collector.collect(None, collected_facts)
    assert(isinstance(facts, dict))

# Generated at 2022-06-25 00:47:16.716594
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()
    assert 'user' in user_facts


# Generated at 2022-06-25 00:47:19.169914
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    test_UserFactCollector = UserFactCollector()

    result = test_UserFactCollector.collect()
    result['user_id'] == getpass.getuser()


# Generated at 2022-06-25 00:47:26.021296
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    try:
        os.setuid(0)
        user_fact_collector_0 = UserFactCollector()
        user_fact_collector_0.collect()
        assert  user_fact_collector_0._fact_ids == set(['user_id', 'user_uid', 'user_gid', 'user_gecos', 'user_dir', 'user_shell', 'real_user_id', 'effective_user_id', 'effective_group_ids'])
        print('test_UserFactCollector_collect passed')
    except AssertionError:
        print('test_UserFactCollector_collect failed')
        raise


# Generated at 2022-06-25 00:47:35.488591
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    pwent = pwd.getpwnam(getpass.getuser())
    expected_user_facts = {'user_id': getpass.getuser(), 'user_uid': pwent.pw_uid, 'user_gid': pwent.pw_gid, 'user_gecos': pwent.pw_gecos, 'user_dir': pwent.pw_dir, 'user_shell': pwent.pw_shell, 'real_user_id': os.getuid(), 'effective_user_id': os.geteuid(), 'real_group_id': os.getgid(), 'effective_group_id': os.getgid()}
    actual_user_facts = user_fact_collector_1.collect()
    assert actual_

# Generated at 2022-06-25 00:47:44.376737
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_facts_0 = user_fact_collector_0.collect()
    assert isinstance(user_facts_0, dict)
    assert 'user_uid' in user_facts_0
    assert 'user_id' in user_facts_0
    assert 'user_gid' in user_facts_0
    assert 'user_gecos' in user_facts_0
    assert 'user_dir' in user_facts_0
    assert 'user_shell' in user_facts_0
    assert 'real_user_id' in user_facts_0
    assert 'effective_user_id' in user_facts_0
    assert 'real_group_id' in user_facts_0
    assert 'effective_group_id' in user_facts_0

# Generated at 2022-06-25 00:47:46.784765
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector().collect()
    assert 'real_user_id' in user_facts

# Generated at 2022-06-25 00:47:54.483110
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    ansible_facts = user_fact_collector.collect()

    assert ansible_facts is not None
    assert 'user_id' in ansible_facts
    assert 'user_uid' in ansible_facts
    assert 'user_gid' in ansible_facts
    assert 'user_gecos' in ansible_facts
    assert 'user_dir' in ansible_facts
    assert 'user_shell' in ansible_facts
    assert 'real_user_id' in ansible_facts
    assert 'effective_user_id' in ansible_facts
    assert 'real_group_id' in ansible_facts
    assert 'effective_group_id' in ansible_facts

# Generated at 2022-06-25 00:47:56.627804
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()


# Generated at 2022-06-25 00:48:00.066552
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_facts = user_fact_collector_1.collect()
    assert(user_facts['user_id'] == getpass.getuser())
    assert(user_facts['real_user_id'] == os.getuid())

# Generated at 2022-06-25 00:48:23.054399
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()

    # Check return type
    assert(isinstance(user_facts, dict))

    # Check the keys / values
    assert('user_id' in user_facts)
    assert('user_uid' in user_facts)
    assert('user_gid' in user_facts)
    assert('user_gecos' in user_facts)
    assert('user_dir' in user_facts)
    assert('user_shell' in user_facts)
    assert('real_user_id' in user_facts)
    assert('effective_user_id' in user_facts)
    assert('effective_group_id' in user_facts)

    # Check the types of values

# Generated at 2022-06-25 00:48:31.524905
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    result = user_fact_collector_0.collect()
    assert result == {u'effective_user_id': 501,
                      u'effective_group_ids': [20],
                      u'real_group_id': 20,
                      u'user_gecos': u'',
                      u'user_uid': 501,
                      u'real_user_id': 501,
                      u'user_shell': u'/bin/bash',
                      u'user_gid': 20,
                      u'user_dir': u'/Users/mdlayher',
                      u'user_id': u'mlayher'}


# Generated at 2022-06-25 00:48:36.625588
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    fact_id = "user_id"
    facts_result = {'user_id': "linuxdevops" }
    facts_result.get(fact_id) == "linuxdevops"
    fact_id = "user_uid"
    facts_result = {'user_uid': 1000 }
    facts_result.get(fact_id) == 1000
    fact_id = "user_gid"
    facts_result = {'user_gid': 1000 }
    facts_result.get(fact_id) == 1000
    fact_id = "user_shell"
    facts_result = {'user_shell': "/bin/bash" }
    facts_result.get(fact_id) == "/bin/bash"

# Generated at 2022-06-25 00:48:41.209976
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()

    assert 'user_id' in user_facts
    assert 'user_uid' in user_facts
    assert 'user_gid' in user_facts
    assert 'user_gecos' in user_facts
    assert 'user_dir' in user_facts
    assert 'user_shell' in user_facts
    assert 'real_user_id' in user_facts
    assert 'effective_user_id' in user_facts
    assert 'real_group_id' in user_facts
    assert 'effective_group_id' in user_facts

# Generated at 2022-06-25 00:48:42.754889
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    # TODO: Replace with parameterized test
    user_fact_collector_1.collect()

# Generated at 2022-06-25 00:48:47.182395
# Unit test for method collect of class UserFactCollector

# Generated at 2022-06-25 00:48:53.799624
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    fact_data_0 = user_fact_collector_0.collect()
    assert fact_data_0['real_user_id'] == os.getuid()
    assert fact_data_0['effective_user_id'] == os.geteuid()
    assert fact_data_0['effective_group_id'] == os.getgid()

# Generated at 2022-06-25 00:48:55.240051
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_facts = user_fact_collector_0.collect()

# Generated at 2022-06-25 00:49:04.854150
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    collected_facts = {}
    user_facts_1 = user_fact_collector_1.collect(collected_facts=collected_facts)
    assert 'user_id' in user_facts_1
    assert 'user_uid' in user_facts_1
    assert 'user_gid' in user_facts_1
    assert 'user_gecos' in user_facts_1
    assert 'user_dir' in user_facts_1
    assert 'user_shell' in user_facts_1
    assert 'real_user_id' in user_facts_1
    assert 'effective_user_id' in user_facts_1
    assert 'effective_group_ids' in user_facts_1

    # Test with a non-existent user

# Generated at 2022-06-25 00:49:08.675758
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_facts = user_fact_collector_1.collect()
    assert "user_id" in user_facts
    assert "user_uid" in user_facts
    assert "user_gid" in user_facts
    assert "user_gecos" in user_facts
    assert "user_dir" in user_facts
    assert "user_shell" in user_facts
    assert "real_user_id" in user_facts
    assert "effective_user_id" in user_facts
    assert "real_group_id" in user_facts
    assert "effective_group_id" in user_facts

# Generated at 2022-06-25 00:49:44.000806
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    result_1 = user_fact_collector_1.collect(collected_facts={})
    assert result_1['user_id'] == 'root'
    assert result_1['user_uid'] == 0
    assert result_1['user_gid'] == 0
    assert result_1['user_gecos'] == 'root'
    assert result_1['user_dir'] == '/root'
    assert result_1['user_shell'] == '/bin/bash'
    assert result_1['real_user_id'] == 0
    assert result_1['effective_user_id'] == 0


# Generated at 2022-06-25 00:49:49.055762
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    user_fact_collector_collect_0 = UserFactCollector()
    user_fact_collector_collect_0.collect(module=None, collected_facts=None)


# Generated at 2022-06-25 00:49:50.609358
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    result = user_fact_collector.collect()


# Generated at 2022-06-25 00:49:57.234727
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_fact_collector_collect = user_fact_collector.collect()

    assert type(user_fact_collector_collect) is dict
    assert 'user_id' in user_fact_collector_collect
    assert 'user_uid' in user_fact_collector_collect
    assert 'user_gid' in user_fact_collector_collect
    assert 'user_gecos' in user_fact_collector_collect
    assert 'user_dir' in user_fact_collector_collect
    assert 'user_shell' in user_fact_collector_collect
    assert 'real_user_id' in user_fact_collector_collect
    assert 'effective_user_id' in user_fact_collector_collect

# Generated at 2022-06-25 00:50:00.914298
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    pass

# Generated at 2022-06-25 00:50:02.226568
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()

    user_fact_collector_1.collect()

# Generated at 2022-06-25 00:50:07.643126
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    facts = user_fact_collector.collect()

    print(facts)

if __name__ == '__main__':
    test_case_0()

    test_UserFactCollector_collect()

# Generated at 2022-06-25 00:50:08.957556
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_fact_collector_1.collect()



# Generated at 2022-06-25 00:50:12.922061
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Create a UserFactCollector object
    user_fact_collector_1 = UserFactCollector()

    # Call method collect of UserFactCollector object
    facts = user_fact_collector_1.collect()

    # Check if facts is a dictionary
    assert isinstance(facts, dict)

    # Check if facts has the following keys

# Generated at 2022-06-25 00:50:15.683961
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()


# Generated at 2022-06-25 00:51:01.163616
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    var_1 = user_fact_collector_0.collect()
    assert 'user_id' in var_1
    assert 'user_uid' in var_1
    assert 'user_gid' in var_1
    assert 'user_gecos' in var_1
    assert 'user_dir' in var_1
    assert 'user_shell' in var_1
    assert 'effective_user_id' in var_1
    assert 'effective_group_ids' in var_1


# Generated at 2022-06-25 00:51:09.471962
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect()
    assert var_0 == {'effective_group_id': 1000, 'effective_user_id': 1000, 'real_group_id': 1000, 'real_user_id': 1000, 'user_dir': '/home/jgavin', 'user_gecos': 'Joe Gavin,,,joe@gavin.org', 'user_gid': 1000, 'user_id': 'jgavin', 'user_shell': '/bin/bash', 'user_uid': 1000}


# Generated at 2022-06-25 00:51:17.979192
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    returned_value = user_fact_collector.collect()
    assert returned_value != None
    assert var.user_gecos == 'None'
    assert var.user_gid == 'None'
    assert var.user_id == 'None'
    assert var.user_shell == 'None'
    assert var.user_uid == 'None'
    assert var.effective_group_id == 'None'
    assert var.effective_user_id == 'None'
    assert var.real_group_id == 'None'
    assert var.real_user_id == 'None'


# Generated at 2022-06-25 00:51:25.864866
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    var_1 = user_fact_collector_0.collect()
    assert len(var_1) == 10
    assert 'effective_user_id' in var_1
    assert var_1['effective_user_id'] == os.geteuid()
    assert 'user_gid' in var_1
    assert var_1['user_gid'] == pwd.getpwuid(os.getuid()).pw_gid
    assert 'effective_group_id' in var_1
    assert var_1['effective_group_id'] == os.getgid()
    assert 'real_user_id' in var_1
    assert var_1['real_user_id'] == os.getuid()
    assert 'user_uid' in var

# Generated at 2022-06-25 00:51:33.792424
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    var_1 = user_fact_collector_1.collect()
    assert isinstance(var_1, dict) == True
    assert isinstance(var_1['user_uid'], int) == True
    assert isinstance(var_1['user_gid'], int) == True
    assert isinstance(var_1['user_gecos'], str) == True
    assert isinstance(var_1['user_shell'], str) == True
    assert isinstance(var_1['user_id'], str) == True
    assert isinstance(var_1['effective_user_id'], int) == True
    assert isinstance(var_1['real_user_id'], int) == True

# Generated at 2022-06-25 00:51:36.113381
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    ret = user_fact_collector_0.collect()
    pass

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 00:51:40.237269
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    data = user_fact_collector_1.collect()
    assert 'user_id' in data
    assert 'user_uid' in data
    assert 'user_gid' in data
    assert 'user_gecos' in data
    assert 'user_dir' in data
    assert 'user_shell' in data
    assert 'real_user_id' in data
    assert 'effective_user_id' in data
    assert 'effective_group_ids' in data


# Generated at 2022-06-25 00:51:49.221254
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    collected_facts_0 = {}
    var_0 = user_fact_collector_0.collect(collected_facts=collected_facts_0)
    assert var_0 == {'effective_group_id': 20, 'effective_user_id': 1000, 'real_user_id': 1000, 'user_dir': '/home/ansible', 'user_gid': 20, 'user_id': 'ansible', 'user_shell': '/bin/bash', 'user_uid': 1000, 'user_gecos': 'ansible,,,', 'real_group_id': 20}



# Generated at 2022-06-25 00:51:52.000896
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect()
    assert var_0 is not None

# Generated at 2022-06-25 00:51:57.933422
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    var_1 = {'effective_group_ids': [0, 31, 10, 27, 6], 'effective_user_id': 1000, 'user_shell': '/bin/bash', 'user_gid': 1000, 'user_id': 'ansible', 'user_gecos': '', 'real_user_id': 1000, 'user_uid': 1000, 'user_dir': '/home/ansible'}
    user_fact_collector_1 = UserFactCollector()
    var_0 = user_fact_collector_1.collect()
    assert var_0 == var_1


# Generated at 2022-06-25 00:53:20.663484
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()

    user_fact_collector_0.collect()


# Generated at 2022-06-25 00:53:21.962618
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect()


# Generated at 2022-06-25 00:53:27.089901
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    # Unit test for method collect of class BaseFactCollector
    def test_BaseFactCollector_collect():

        # Unit test for method collect of class BaseFactCollector
        def test_BaseFactCollector_collect():

            # Unit test for method collect of class BaseFactCollector
            def test_BaseFactCollector_collect():

                # Unit test for method collect of class BaseFactCollector
                def test_BaseFactCollector_collect():

                    # Unit test for method collect of class BaseFactCollector
                    def test_BaseFactCollector_collect():
                        pass

                    # Unit test for method collect_from_module of class BaseFactCollector
                    def test_BaseFactCollector_collect_from_module():
                        pass

                    # Unit test for method collect_from_cache of class BaseFactCollector

# Generated at 2022-06-25 00:53:27.682330
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    assert True == True


# Generated at 2022-06-25 00:53:32.533190
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Case 0
    test_case_0()


# Generated at 2022-06-25 00:53:38.479474
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    user_id = getpass.getuser()
    pwent = pwd.getpwnam(user_id)
    tmp_dict = {'user_id': user_id,
                'user_uid': pwent.pw_uid,
                'user_gid': pwent.pw_gid,
                'user_gecos': pwent.pw_gecos,
                'user_dir': pwent.pw_dir,
                'user_shell': pwent.pw_shell,
                'real_user_id': os.getuid(),
                'effective_user_id': os.geteuid(),
                'real_group_id': os.getgid(),
                'effective_group_id': os.getgid()}

# Generated at 2022-06-25 00:53:44.420909
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    var_1 = user_fact_collector_0.collect()
    # Check existence of attribute user_dir
    assert ('user_dir' in var_1)
    # Check attribute type user_dir
    assert(isinstance(var_1['user_dir'], str))
    # Check that attribute user_dir matches the supplied value
    assert (var_1['user_dir'] == '/home/devel')
    # Check existence of attribute user_uid
    assert ('user_uid' in var_1)
    # Check attribute type user_uid
    assert(isinstance(var_1['user_uid'], int))
    # Check that attribute user_uid matches the supplied value
    assert (var_1['user_uid'] == 1000)
    # Check existence of attribute

# Generated at 2022-06-25 00:53:48.289140
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_collect_0 = UserFactCollector()
    var_0 = user_fact_collector_collect_0.collect()

# Generated at 2022-06-25 00:53:51.985574
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect()

# Generated at 2022-06-25 00:53:52.330931
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    assert True