

# Generated at 2022-06-25 00:44:17.662067
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()

# Generated at 2022-06-25 00:44:21.130079
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_facts = user_fact_collector_1.collect()
    assert 'item1' in user_facts
    assert 'item2' in user_facts
    assert 'item3' in user_facts
    assert 'item4' in user_facts
    assert 'item5' in user_facts
    assert 'item6' in user_facts
    assert 'item7' in user_facts
    assert 'item8' in user_facts
    assert 'item9' in user_facts
    assert 'item10' in user_facts

# Generated at 2022-06-25 00:44:23.243064
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_facts = user_fact_collector_0.collect()
    assert isinstance(user_facts, dict)


# Generated at 2022-06-25 00:44:24.876530
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    assert user_fact_collector_0.collect() is not None


# Generated at 2022-06-25 00:44:30.850462
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Create instance of class UserFactCollector
    user_fact_collector = UserFactCollector()

    # Call method collect of class UserFactCollector instance
    user_fact_collector.collect(module=None, collected_facts=None)


# Generated at 2022-06-25 00:44:35.485194
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_collect_0 = UserFactCollector()
    user_fact_collector_collect_0.collect()


# Generated at 2022-06-25 00:44:38.423566
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_fact_collector.collect()

# Generated at 2022-06-25 00:44:47.947352
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()

    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['user_uid'] == pwd.getpwnam(user_facts['user_id']).pw_uid
    assert user_facts['user_gid'] == pwd.getpwnam(user_facts['user_id']).pw_gid
    assert user_facts['user_gecos'] == pwd.getpwnam(user_facts['user_id']).pw_gecos
    assert user_facts['user_dir'] == pwd.getpwnam(user_facts['user_id']).pw_dir
    assert user_facts['user_shell'] == pwd.getp

# Generated at 2022-06-25 00:44:51.598955
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    assert isinstance(user_fact_collector_1.collect(), dict)


# Generated at 2022-06-25 00:44:59.188980
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    # Test if _fact_ids is set properly
    assert user_fact_collector_0._fact_ids == set(['user_id', 'user_uid', 'user_gid',
                                                   'user_gecos', 'user_dir', 'user_shell',
                                                   'real_user_id', 'effective_user_id',
                                                   'effective_group_ids'])
    # Test if the return variable is set properly
    assert isinstance(user_fact_collector_0.collect(), dict)
    assert 'user_id' in user_fact_collector_0.collect()

# Generated at 2022-06-25 00:45:09.654460
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    user_fact_collector = UserFactCollector()
    collected_facts = {}
    user_facts = user_fact_collector.collect(None, collected_facts)

    assert 'user_id' in user_facts
    assert 'user_gid' in user_facts
    assert 'effective_group_id' in user_facts
    assert 'real_group_id' in user_facts
    assert 'real_user_id' in user_facts
    assert 'effective_user_id' in user_facts
    assert 'user_dir' in user_facts
    assert 'user_gecos' in user_facts
    assert 'user_shell' in user_facts
    assert 'user_uid' in user_facts

# Generated at 2022-06-25 00:45:17.032412
# Unit test for method collect of class UserFactCollector

# Generated at 2022-06-25 00:45:27.414857
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    collected_facts = []
    user_facts = user_fact_collector.collect(None, collected_facts)


# Generated at 2022-06-25 00:45:29.165033
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_collect_0 = UserFactCollector()
    user_fact_collector_collect_0.collect()


# Generated at 2022-06-25 00:45:37.234993
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    result = user_fact_collector_1.collect()
    assert 'user_id' in result
    assert result['user_id'] == getpass.getuser()
    assert 'user_uid' in result
    assert 'user_gid' in result
    assert 'user_gecos' in result
    assert 'user_dir' in result
    assert 'user_shell' in result
    assert 'real_user_id' in result
    assert result['real_user_id'] == os.getuid()
    assert 'effective_user_id' in result
    assert result['effective_user_id'] == os.geteuid()
    assert 'real_group_id' in result
    assert result['real_group_id'] == os.getgid()
   

# Generated at 2022-06-25 00:45:41.051393
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()
    assert(user_facts['user_id'] == getpass.getuser())
    assert(user_facts['user_dir'] == os.path.expanduser('~'))

# Generated at 2022-06-25 00:45:45.522501
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    result = user_fact_collector_1.collect()
    assert result["user_id"] == getpass.getuser()

if __name__ == '__main__':
    # Unit test for method collect of class UserFactCollector
    test_UserFactCollector_collect()

# Generated at 2022-06-25 00:45:53.696787
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    # Test case for collect with no facts provided
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()

    assert('user_uid' in user_facts)
    assert('user_id' in user_facts)
    assert('user_uid' in user_facts)
    assert('user_shell' in user_facts)
    assert('user_gecos' in user_facts)
    assert('user_uid' in user_facts)
    assert('effective_user_id' in user_facts)
    assert('effective_group_ids' in user_facts)

    # Test case for collect with all facts provided
    user_fact_collector = UserFactCollector()
    all_facts = {}
    user_facts = user_fact_collector.collect(all_facts)

# Generated at 2022-06-25 00:46:00.743223
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()

    assert 'user' == user_fact_collector.name
    assert 'user_id' in user_facts
    assert 'user_uid' in user_facts
    assert 'user_gid' in user_facts
    assert 'user_gecos' in user_facts
    assert 'user_dir' in user_facts
    assert 'user_shell' in user_facts
    assert 'real_user_id' in user_facts
    assert 'effective_user_id' in user_facts
    assert 'effective_group_ids' in user_facts
    return user_facts

user_facts = test_UserFactCollector_collect()

if __name__ == '__main__':
    import pytest

   

# Generated at 2022-06-25 00:46:05.757817
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    result_user_facts_1 = user_fact_collector_1.collect()
    assert 'user_id' in result_user_facts_1
    assert 'user_uid' in result_user_facts_1
    assert 'user_gid' in result_user_facts_1
    assert 'user_gecos' in result_user_facts_1
    assert 'user_dir' in result_user_facts_1
    assert 'user_shell' in result_user_facts_1
    assert 'real_user_id' in result_user_facts_1
    assert 'effective_user_id' in result_user_facts_1
    assert 'real_group_id' in result_user_facts_1

# Generated at 2022-06-25 00:46:14.929036
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    assert isinstance(user_fact_collector_0.collect(), dict)


# Generated at 2022-06-25 00:46:19.582405
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    assert user_fact_collector_0.collect() == {'user_id': 'vagrant', 'user_uid': 1000, 'user_gid': 1000, 'user_gecos': 'Uyen Nguyen,,,', 'user_dir': '/home/vagrant', 'user_shell': '/bin/bash', 'effective_user_id': 1000, 'real_user_id': 1000, 'effective_group_id': 1000}

# Generated at 2022-06-25 00:46:22.310606
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_fact_collector.collect()
    assert user_fact_collector

# Generated at 2022-06-25 00:46:24.459386
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    result = user_fact_collector_1.collect()
    assert isinstance(result, dict)

# Generated at 2022-06-25 00:46:32.995754
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    pw_name = getpass.getuser()
    pwent = pwd.getpwnam(getpass.getuser())

    user_fact_collector_collect_0 = UserFactCollector()
    actual = user_fact_collector_collect_0.collect()

# Generated at 2022-06-25 00:46:34.301859
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()


# Generated at 2022-06-25 00:46:37.164650
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()

    user_fact_collector_1.collect()

# Generated at 2022-06-25 00:46:45.329106
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()

    user_facts = user_fact_collector_0.collect()

    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['user_uid'] == pwd.getpwnam(
        getpass.getuser()).pw_uid
    assert user_facts['user_gid'] == pwd.getpwnam(
        getpass.getuser()).pw_gid
    assert user_facts['user_gecos'] == pwd.getpwnam(
        getpass.getuser()).pw_gecos
    assert user_facts['user_dir'] == pwd.getpwnam(
        getpass.getuser()).pw_dir
    assert user_facts['user_shell'] == p

# Generated at 2022-06-25 00:46:53.696619
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    test_data = UserFactCollector().collect()
    assert ('user_id' in test_data)
    assert ('user_uid' in test_data)
    assert ('user_gid' in test_data)
    assert ('user_gecos' in test_data)
    assert ('user_dir' in test_data)
    assert ('user_shell' in test_data)
    assert ('real_user_id' in test_data)
    assert ('effective_user_id' in test_data)
    assert ('effective_group_ids' in test_data)

# Generated at 2022-06-25 00:46:54.293449
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    assert UserFactCollector.collect()

# Generated at 2022-06-25 00:47:08.563513
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    pass

# Generated at 2022-06-25 00:47:09.713835
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_fact_collector_1.collect()


# Generated at 2022-06-25 00:47:14.048483
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    # Create a new instance of UserFactCollector
    user_fact_collector = UserFactCollector()

    # Invoke method collect
    result = user_fact_collector.collect()

    assert type(result) == dict
    assert 'user_id' in result
    assert type(result['user_id']) == str
    assert 'user_uid' in result
    assert type(result['user_uid']) == int
    assert 'user_gid' in result
    assert type(result['user_gid']) == int
    assert 'user_gecos' in result
    assert type(result['user_gecos']) == str
    assert 'user_dir' in result
    assert type(result['user_dir']) == str
    assert 'user_shell' in result

# Generated at 2022-06-25 00:47:16.761052
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_fact_collector_1.collect() == None

# Generated at 2022-06-25 00:47:20.742000
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_fact_collector_1.collect()
    for item in user_fact_collector_1.collect():
        print("%s:%s" % (item, user_fact_collector_1.collect()[item]))

# Generated at 2022-06-25 00:47:23.578336
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()

    print("Testing UserFactCollector")
    print("==========================")
    print("Testing collect method")

    user_fact_collector_0.collect()


# Generated at 2022-06-25 00:47:24.570340
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()


# Generated at 2022-06-25 00:47:33.503893
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    #assert 'user_id' in user_fact_collector_0.collect()
    assert 'user_uid' in user_fact_collector_0.collect()
    assert 'user_gid' in user_fact_collector_0.collect()
    assert 'user_gecos' in user_fact_collector_0.collect()
    assert 'user_dir' in user_fact_collector_0.collect()
    assert 'user_shell' in user_fact_collector_0.collect()
    assert 'real_user_id' in user_fact_collector_0.collect()
    assert 'effective_user_id' in user_fact_collector_0.collect()

# Generated at 2022-06-25 00:47:40.678916
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Test typing
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()
    assert isinstance(user_facts, dict)

    # Test user_id
    assert 'user_id' in user_facts
    assert isinstance(user_facts['user_id'], str)

    # Test user_uid
    assert 'user_uid' in user_facts
    assert isinstance(user_facts['user_uid'], int)

    # Test user_gid
    assert 'user_gid' in user_facts
    assert isinstance(user_facts['user_gid'], int)

    # Test user_gecos
    assert 'user_gecos' in user_facts
    assert isinstance(user_facts['user_gecos'], str)

    # Test

# Generated at 2022-06-25 00:47:49.884428
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()

    # Test case #0: Pass a module parameter along with collected_facts and check if the method returns
    # the expected result.
    module_parameter_0 = None
    collected_facts_0 = {}

# Generated at 2022-06-25 00:48:05.878422
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    assert type(user_fact_collector.collect()) == dict


# Generated at 2022-06-25 00:48:07.663955
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect()


# Generated at 2022-06-25 00:48:09.646015
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    assert type(user_fact_collector_0.collect()) is dict

# Generated at 2022-06-25 00:48:12.803098
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fact_collector_0 = UserFactCollector()
    var_0 = fact_collector_0.collect()
    user_fact_collector_0 = UserFactCollector()
    var_1 = user_fact_collector_0.collect()
    assert var_0 == var_1


# Generated at 2022-06-25 00:48:22.168115
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    assert 'effective_user_id' in user_fact_collector.collect()
    assert 'effective_group_id' in user_fact_collector.collect()
    assert 'real_user_id' in user_fact_collector.collect()
    assert 'user_id' in user_fact_collector.collect()
    assert 'user_uid' in user_fact_collector.collect()
    assert 'user_gid' in user_fact_collector.collect()
    assert 'user_gecos' in user_fact_collector.collect()
    assert 'user_dir' in user_fact_collector.collect()
    assert 'user_shell' in user_fact_collector.collect()


if __name__ == '__main__':
    import sys

# Generated at 2022-06-25 00:48:31.664392
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect()
    assert getpass.getuser() == var_0['user_id']
    assert getpass.getuser() == var_0['user_id']
    assert getpass.getuser() == var_0['user_id']
    assert getpass.getuser() == var_0['user_id']
    assert getpass.getuser() == var_0['user_id']
    assert getpass.getuser() == var_0['user_id']
    assert getpass.getuser() == var_0['user_id']
if (__name__ == '__main__'):
    test_case_0()
    test_UserFactCollector_collect()

# Generated at 2022-06-25 00:48:32.919302
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect()

# Generated at 2022-06-25 00:48:39.526219
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect()
    user_fact_collector_1 = UserFactCollector()


# Generated at 2022-06-25 00:48:44.897979
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_1 = UserFactCollector()
    var_0 = user_fact_collector_0.collect()
    var_1 = user_fact_collector_1.collect()
    print(var_0)
    print(var_1)
    assert var_0 == var_1


# Generated at 2022-06-25 00:48:49.190757
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    var_1 = user_fact_collector.collect()

# Generated at 2022-06-25 00:49:23.750909
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    # Test status
    assert user_fact_collector_0.collect()


# Generated at 2022-06-25 00:49:27.161178
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    var_1 = UserFactCollector()
    var_1.collect()



# Generated at 2022-06-25 00:49:29.851894
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_2 = UserFactCollector()
    var_2 = user_fact_collector_2.collect()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 00:49:32.475032
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect()


# Generated at 2022-06-25 00:49:40.922710
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()

    # Setup test case
    var_0 = set(['group_name', 'group_id', 'group_gid'])

    # Expected return
    user_fact_collector.get_group_facts()
    user_fact_collector.get_user_facts()
    var = user_fact_collector.collect(collected_facts=var_0)

    assert var == ('bar')
    assert user_fact_collector.name == ('foo')


# Generated at 2022-06-25 00:49:46.138543
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    print("Testing collect of class UserFactCollector")
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect()
    print("var_0: " + str(var_0) + "\n\n")

# Generated at 2022-06-25 00:49:48.473523
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_2 = UserFactCollector()

    # Test with valid arguments
    var_2 = user_fact_collector_2.collect()

    # Test with invalid arguments
    user_fact_collector_3 = UserFactCollector()
    with pytest.raises(TypeError) as excinfo:
        user_fact_collector_3.collect(1)


# Generated at 2022-06-25 00:49:51.443412
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_2 = UserFactCollector()
    var_2 = user_fact_collector_2.collect()
    from ansible.module_utils.facts import facts
    var_3 = facts.fact_cache()
    var_3.set('user', var_2)

# Generated at 2022-06-25 00:50:00.615980
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect()
    assert var_0['real_user_id'] == os.getuid()
    assert var_0['user_dir'] == pwd.getpwuid(os.getuid()).pw_dir
    assert var_0['user_uid'] == pwd.getpwuid(os.getuid()).pw_uid
    assert var_0['user_gecos'] == pwd.getpwuid(os.getuid()).pw_gecos
    assert var_0['effective_group_ids'] == [os.getgid()]
    assert var_0['user_shell'] == pwd.getpwuid(os.getuid()).pw_shell
    assert var

# Generated at 2022-06-25 00:50:02.425315
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    var_1 = user_fact_collector.collect()
    assert var_1 == {}


# Generated at 2022-06-25 00:51:25.627906
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    var_1 = user_fact_collector_0.collect()

# Generated at 2022-06-25 00:51:26.859215
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    var = user_fact_collector.collect()
    pass

# Generated at 2022-06-25 00:51:28.805790
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()


# Generated at 2022-06-25 00:51:30.718929
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    var = user_fact_collector.collect()
    assert var is not None
    assert var

test_UserFactCollector_collect()

# Generated at 2022-06-25 00:51:37.870220
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect()
    assert var_0['user_id'] == 'dell'
    assert var_0['user_uid'] == 1000
    assert var_0['user_gid'] == 1000
    assert var_0['user_gecos'] == 'Dell XPS 15 9550'
    assert var_0['user_dir'] == '/home/dell'
    assert var_0['user_shell'] == '/bin/bash'
    assert var_0['real_user_id'] == 1000
    assert var_0['effective_user_id'] == 1000
    assert var_0['real_group_id'] == 1000
    assert var_0['effective_group_id'] == 1000



# Generated at 2022-06-25 00:51:39.960319
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect()


# Generated at 2022-06-25 00:51:42.353491
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect()


# Generated at 2022-06-25 00:51:45.355384
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    assert isinstance(user_fact_collector.collect(), dict)


# Generated at 2022-06-25 00:51:49.359005
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # The module should be able to collect facts from all the user
    # parameters associated with the user id
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()
    assert set(user_facts).issubset(user_fact_collector._fact_ids)

# Generated at 2022-06-25 00:51:51.544263
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    var_0 = UserFactCollector()
    var_0.collect()
