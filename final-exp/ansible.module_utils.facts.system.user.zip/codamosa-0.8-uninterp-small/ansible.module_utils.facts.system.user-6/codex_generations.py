

# Generated at 2022-06-25 00:44:18.655733
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    current_user_id = getpass.getuser()

    try:
        pwent = pwd.getpwnam(getpass.getuser())
    except KeyError:
        pwent = pwd.getpwuid(os.getuid())

    user_id = pwent.pw_uid
    user_gid = pwent.pw_gid
    user_gecos = pwent.pw_gecos
    user_dir = pwent.pw_dir
    user_shell = pwent.pw_shell
    real_user_id = os.getuid()
    effective_user_id = os.geteuid()
    real_group_id = os.getgid()
    effective_group_id = os.getgid()

    user_fact_collector_1 = UserFactCollector

# Generated at 2022-06-25 00:44:22.091279
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()

    some_facts = user_fact_collector_0.collect()
    assert type(some_facts) == dict
    assert some_facts

# Generated at 2022-06-25 00:44:31.967395
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    collected_facts = {}
    user_facts = user_fact_collector_1.collect(collected_facts)
    expected_facts = {'user_id': 'ansible',
                      'user_uid': 1000,
                      'user_gid': 1000,
                      'user_gecos': 'Eric Johnson',
                      'user_dir': '/home/ansible',
                      'user_shell': '/bin/bash',
                      'real_user_id': 1000,
                      'effective_user_id': 1000,
                      'real_group_id': 1000,
                      'effective_group_id': 1000}

    assert user_facts == expected_facts

# Generated at 2022-06-25 00:44:41.582502
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    from mock import patch
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import UserFactCollector

    user_fact_collector_0 = UserFactCollector()
    collected_facts = {}
    with patch.object(BaseFactCollector, 'collect', return_value=collected_facts):
        collected_facts = user_fact_collector_0.collect()
        assert isinstance(collected_facts, dict)
    # Clean up
    del user_fact_collector_0, collected_facts


# Generated at 2022-06-25 00:44:51.076658
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_1 = user_fact_collector_0.collect()
    assert user_fact_collector_1['user_id'] == getpass.getuser(), "Failed: expected user_fact_collector_1['user_id'] == getpass.getuser()"
    try:
        pwent = pwd.getpwnam(getpass.getuser())
    except KeyError:
        pwent = pwd.getpwuid(os.getuid())
    assert user_fact_collector_1['user_uid'] == pwent.pw_uid, "Failed: expected user_fact_collector_1['user_uid'] == pwent.pw_uid"

# Generated at 2022-06-25 00:44:54.395266
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collected_facts = dict()

    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()

# Generated at 2022-06-25 00:44:56.512458
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_fact_collector_1.collect()


# Generated at 2022-06-25 00:45:00.660583
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    assert isinstance(user_fact_collector_0.collect(), dict)


# Generated at 2022-06-25 00:45:06.288021
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    # Instantiating an instance of the class UserFactCollector
    user_fact_collector = UserFactCollector()

    # Calling method collect of class UserFactCollector
    user_fact_collector.collect()

# Generated at 2022-06-25 00:45:10.080658
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()

# Generated at 2022-06-25 00:45:15.953763
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_fact_collector_1.collect()


# Generated at 2022-06-25 00:45:26.400897
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_instance = UserFactCollector()
    user_fact_instance_return = user_fact_instance.collect()
    assert isinstance(user_fact_instance_return, dict)

# Generated at 2022-06-25 00:45:33.120804
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    collected_facts_1 = dict()
    collected_facts_1.update({'user_id': 'user_id', 'user_uid': 'user_uid', 'user_gecos': 'user_gecos', 'user_shell': 'user_shell', 'real_group_id': 'real_group_id', 'effective_group_id': 'effective_group_id', 'user_gid': 'user_gid', 'user_dir': 'user_dir', 'effective_user_id': 'effective_user_id', 'real_user_id': 'real_user_id'})
    assert user_fact_collector_1.collect() ==  collected_facts_1


# Generated at 2022-06-25 00:45:34.828492
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_fact_collector_1.collect()


# Generated at 2022-06-25 00:45:45.161678
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    collected_facts_1 = {}
    user_facts_1 = user_fact_collector_1.collect(collected_facts_1)
    assert user_facts_1 is not None
    assert 'user_id' in user_facts_1
    assert user_facts_1['user_id'] is not None
    assert 'user_uid' in user_facts_1
    assert user_facts_1['user_uid'] is not None
    assert 'user_gid' in user_facts_1
    assert user_facts_1['user_gid'] is not None
    assert 'user_gecos' in user_facts_1
    assert user_facts_1['user_gecos'] is not None
    assert 'user_dir' in user_facts_1

# Generated at 2022-06-25 00:45:52.809172
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    fact_ids_current = {'user_id', 'user_uid', 'user_gid', 'user_gecos', 'user_dir', 'user_shell', 'real_user_id', 'effective_user_id', 'real_group_id', 'effective_group_id'}
    user_fact_collector_0._fact_ids = fact_ids_current
    user_fact_collector_0.collect()

    print(user_fact_collector_0.name)
    print(user_fact_collector_0._fact_ids)

if __name__ == '__main__':
    test_UserFactCollector_collect()

# Generated at 2022-06-25 00:45:54.260993
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    assert user_fact_collector_0.collect()

# Generated at 2022-06-25 00:45:57.407342
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    collected_facts = {}
    user_facts = user_fact_collector_0.collect(collected_facts)
    user_id_facts = user_facts['user_id']
    assert user_id_facts == getpass.getuser()

# Generated at 2022-06-25 00:46:07.832008
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Test 1: No arguments
    user_fact_collector_0 = UserFactCollector()
    user_facts = user_fact_collector_0.collect()
    assert user_facts['real_user_id'] == os.getuid()
    assert user_facts['effective_user_id'] == os.geteuid()
    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['user_gecos'] == pwd.getpwnam(getpass.getuser()).pw_gecos
    assert user_facts['user_dir'] == pwd.getpwnam(getpass.getuser()).pw_dir
    assert user_facts['user_shell'] == pwd.getpwnam(getpass.getuser()).pw_shell



# Generated at 2022-06-25 00:46:17.765332
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_facts_dict = user_fact_collector_0.collect()

    # Test if dictionary is not empty
    assert user_facts_dict
    assert 'user_id' in user_facts_dict
    assert 'user_uid' in user_facts_dict
    assert 'user_gid' in user_facts_dict
    assert 'user_gecos' in user_facts_dict
    assert 'user_dir' in user_facts_dict
    assert 'real_user_id' in user_facts_dict
    assert 'effective_user_id' in user_facts_dict
    assert 'real_group_id' in user_facts_dict
    assert 'effective_group_id' in user_facts_dict

# Generated at 2022-06-25 00:46:29.484358
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    assert user_fact_collector_1.collect() == {'user_id': 'root', 'real_group_id': 0, 'effective_group_id': 0, 'user_shell': '/bin/bash', 'user_dir': '/root', 'user_gid': 0, 'effective_user_id': 0, 'user_uid': 0, 'user_gecos': 'root', 'real_user_id': 0}

# Generated at 2022-06-25 00:46:36.909399
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_facts = user_fact_collector_1.collect()

    print("\n")
    print("User Facts:")
    print("\n")
    print("user_id: " + str(user_facts["user_id"]))
    print("user_uid: " + str(user_facts["user_uid"]))
    print("user_gid: " + str(user_facts["user_gid"]))
    print("user_gecos: " + str(user_facts["user_gecos"]))
    print("user_dir: " + str(user_facts["user_dir"]))
    print("user_shell: " + str(user_facts["user_shell"]))

# Generated at 2022-06-25 00:46:38.361419
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_fact_collector_1.collect()

# Generated at 2022-06-25 00:46:43.136751
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    user_fact_collector_1 = UserFactCollector()
    user_facts_1 = user_fact_collector_1.collect()

    user_fact_collector_2 = UserFactCollector()
    user_facts_2 = user_fact_collector_2.collect()

    assert type(user_facts_1) == dict
    assert type(user_facts_2) == dict
    assert user_facts_1 == user_facts_2

# Generated at 2022-06-25 00:46:44.900257
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_2 = UserFactCollector()
    user_fact_collector_2.collect()


# Generated at 2022-06-25 00:46:50.024664
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    user_fact_collector_1 = UserFactCollector()
    user_fact_collector_2 = UserFactCollector()
    user_fact_collector_3 = UserFactCollector()
    user_fact_collector_4 = UserFactCollector()

    assert type(getpass.getuser()) == str
    assert type(os.getuid()) == int and type(os.geteuid()) == int and type(os.getgid()) == int
    assert os.getuid() == os.geteuid() and os.getuid() == os.getgid()

    user_fact_collector_5 = UserFactCollector()
    assert type(getpass.getuser()) == str
    assert type(os.getuid()) == int and type(os.geteuid()) == int and type(os.getgid())

# Generated at 2022-06-25 00:46:58.881380
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()

    user_facts = user_fact_collector.collect()

    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['user_uid'] == pwd.getpwuid(os.getuid()).pw_uid
    assert user_facts['user_gid'] == pwd.getpwuid(os.getuid()).pw_gid
    assert user_facts['user_gecos'] == pwd.getpwuid(os.getuid()).pw_gecos
    assert user_facts['user_dir'] == pwd.getpwuid(os.getuid()).pw_dir
    assert user_facts['user_shell'] == pwd.getpwuid(os.getuid()).pw_

# Generated at 2022-06-25 00:47:01.744090
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    assert isinstance(user_fact_collector_1.collect(), dict)


# Generated at 2022-06-25 00:47:08.077466
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()

    collected_facts_1 = {'ansible_system': 'Linux'}


# Generated at 2022-06-25 00:47:10.538301
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector.collect(UserFactCollector())
    assert isinstance(user_facts, dict)
    assert set(user_facts).issubset(UserFactCollector._fact_ids)

# Generated at 2022-06-25 00:47:32.351679
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    data = UserFactCollector().collect({})

    assert data is not None
    assert data["user_id"] is not None
    assert data["user_gid"] is not None
    assert data["user_gecos"] is not None
    assert data["user_dir"] is not None
    assert data["user_shell"] is not None
    assert data["real_user_id"] is not None
    assert data["effective_user_id"] is not None
    assert data["real_group_id"] is not None
    assert data["effective_group_id"] is not None
    assert data["effective_group_ids"] is None


# Generated at 2022-06-25 00:47:34.338395
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()


# Generated at 2022-06-25 00:47:36.679408
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()

# Generated at 2022-06-25 00:47:46.552928
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    test_user_id = "bhagy"
    test_user_uid = "bhagy"
    test_user_gid = "bhagy"
    test_user_gecos = "bhagy"
    test_user_dir = "/home/bhagy"
    test_user_shell = "/bin/bash"
    test_real_user_id = 1000
    test_effective_user_id = 1000
    test_real_group_id = 1000
    test_effective_group_id = 1000

    user_fact_collector_1 = UserFactCollector()
    user_facts = user_fact_collector_1.collect()

    assert user_facts['user_id'] == test_user_id
    assert user_facts['user_uid'] == test_user_uid
    assert user_facts['user_gid']

# Generated at 2022-06-25 00:47:48.454392
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect(None, None)


# Generated at 2022-06-25 00:47:50.477258
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()

    user_fact_collector_1.collect(module=None, collected_facts=None)


# Generated at 2022-06-25 00:47:59.756563
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()

    collected_facts = user_fact_collector_1.collect(module=None, collected_facts=None)
    assert collected_facts['user_id'] == getpass.getuser()
    assert collected_facts['user_uid'] == pwd.getpwuid(os.getuid()).pw_uid
    assert collected_facts['user_gid'] == pwd.getpwuid(os.getuid()).pw_gid
    assert collected_facts['user_gecos'] == pwd.getpwuid(os.getuid()).pw_gecos
    assert collected_facts['user_dir'] == pwd.getpwuid(os.getuid()).pw_dir

# Generated at 2022-06-25 00:48:05.919444
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    fact_id = user_fact_collector_0._fact_ids

    if fact_id:
        for fact_item in fact_id:
            assert fact_item in user_fact_collector_0.collect()
    else:
        assert 'Real user ID' in user_fact_collector_0.collect()

# Generated at 2022-06-25 00:48:13.789871
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()

    result = user_fact_collector_0.collect()
    assert(isinstance(result, dict))
    assert(isinstance(result['user_id'], basestring))
    assert(isinstance(result['user_uid'], int))
    assert(isinstance(result['user_gid'], int))
    assert(isinstance(result['user_gecos'], basestring))
    assert(isinstance(result['user_dir'], basestring))
    assert(isinstance(result['user_shell'], basestring))
    assert(isinstance(result['real_user_id'], int))
    assert(isinstance(result['effective_user_id'], int))

# Generated at 2022-06-25 00:48:16.826783
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()


# Generated at 2022-06-25 00:48:49.279605
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_fact_collector.collect()


# Generated at 2022-06-25 00:48:52.546877
# Unit test for method collect of class UserFactCollector

# Generated at 2022-06-25 00:48:53.867717
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_fact_collector_1.collect()



# Generated at 2022-06-25 00:48:55.203392
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    assert type(user_fact_collector_1.collect()) == dict


# Generated at 2022-06-25 00:49:04.473286
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_fact_collector_2 = UserFactCollector()
    user_fact_collector_3 = UserFactCollector()

    user_facts_1 = user_fact_collector_1.collect('ansible.builtin.facts', {})
    user_facts_2 = user_fact_collector_2.collect('ansible.builtin.facts', {})
    user_facts_3 = user_fact_collector_3.collect('ansible.builtin.facts', {})

    assert user_facts_1 == user_facts_2
    assert user_facts_1 == user_facts_3
    assert user_facts_2 == user_facts_3


# Generated at 2022-06-25 00:49:06.186003
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    assert user_fact_collector_0.collect()


# Generated at 2022-06-25 00:49:12.975297
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_fact = user_fact_collector_1.collect()

# Generated at 2022-06-25 00:49:16.194734
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_fact_collector.collect()

# Generated at 2022-06-25 00:49:25.434971
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    """Test the functionality of the collect method of the UserFactCollector class"""

    # Create an instance of the class UserFactCollector
    user_fact_collector = UserFactCollector()

    # Call the collect method
    collected_facts = user_fact_collector.collect(collected_facts=None)

    # Test the result
    assert(collected_facts['user_id'] == getpass.getuser())
    assert(collected_facts['user_uid'] == pwd.getpwnam(getpass.getuser()).pw_uid)
    assert(collected_facts['user_gid'] == pwd.getpwnam(getpass.getuser()).pw_gid)

# Generated at 2022-06-25 00:49:25.897161
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    test_case_0()

# Generated at 2022-06-25 00:50:33.120913
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()

# Generated at 2022-06-25 00:50:37.853138
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    try:
        user_fact_collector_0 = UserFactCollector()
        result = user_fact_collector_0.collect(None, None)
        if result is None:
            print("method collect of class UserFactCollector threw exception with message: " + str(e.message) + '\n')
            return False
        else:
            return True
    except Exception as e:
        print("method collect of class UserFactCollector threw exception with message: " + str(e.message) + '\n')
        return False


# Generated at 2022-06-25 00:50:38.871982
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_fact_collector_1.collect()


# Generated at 2022-06-25 00:50:44.574271
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_fact_collector_1.collect()


# Generated at 2022-06-25 00:50:54.285292
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_collect_0 = UserFactCollector()
    collected_facts_0 = user_fact_collector_collect_0.collect(
        collected_facts={})
    assert isinstance(collected_facts_0['ansible_facts'], dict)
    assert 'ansible_user_id' in collected_facts_0['ansible_facts']
    assert isinstance(collected_facts_0['ansible_facts']['ansible_user_id'], str)
    assert 'ansible_user_uid' in collected_facts_0['ansible_facts']
    assert isinstance(collected_facts_0['ansible_facts']['ansible_user_uid'], int)
    assert 'ansible_user_gid' in collected_facts_0['ansible_facts']

# Generated at 2022-06-25 00:50:57.392723
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_fact_collector_1.collect()

# Generated at 2022-06-25 00:51:01.022265
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()

    user_fact_collector_1.collect()

# Generated at 2022-06-25 00:51:04.647798
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_fact_collector_1.collect()

# Generated at 2022-06-25 00:51:09.619435
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    result = user_fact_collector_1.collect()
    assert isinstance(result, dict) is True
    assert {'user_id', 'user_uid', 'user_gid', 'user_gecos', 'user_dir', 'user_shell', 'real_user_id', 'effective_user_id', 'real_group_id', 'effective_group_id'} <= result.keys(), "dict of keys did not match expected values"

# Generated at 2022-06-25 00:51:11.210960
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()

    # Run method collect
    user_fact_collector_1.collect()


# Generated at 2022-06-25 00:53:54.366639
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = UserFactCollector()
    assert user_facts.collect().has_key('user_id')
    assert user_facts.collect().has_key('user_uid')
    assert user_facts.collect().has_key('user_gid')
    assert user_facts.collect().has_key('user_gecos')
    assert user_facts.collect().has_key('user_dir')
    assert user_facts.collect().has_key('user_shell')
    assert user_facts.collect().has_key('real_user_id')
    assert user_facts.collect().has_key('effective_user_id')
    assert user_facts.collect().has_key('effective_group_id')
    assert user_facts.collect().has_key('real_group_id')

# Generated at 2022-06-25 00:53:57.510577
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_fact_collector.collect()


# Generated at 2022-06-25 00:53:58.790488
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()


# Generated at 2022-06-25 00:54:06.702990
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Make sure the following are valid returned values
    user_fact_collector_1 = UserFactCollector()
    user_dict = user_fact_collector_1.collect()
    assert user_dict['user_id'] != None
    assert user_dict['user_uid'] != None
    assert user_dict['user_gid'] != None
    assert user_dict['user_gecos'] != None
    assert user_dict['user_dir'] != None
    assert user_dict['user_shell'] != None
    assert user_dict['real_user_id'] != None
    assert user_dict['effective_user_id'] != None
    assert user_dict['real_group_id'] != None
    assert user_dict['effective_group_id'] != None

# Generated at 2022-06-25 00:54:12.588013
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()
    if not user_facts.has_key('user_id'):
        assert 0, 'Failed to collect user id'
    if not user_facts.has_key('user_uid'):
        assert 0, 'Failed to collect user uid'
    if not user_facts.has_key('user_gid'):
        assert 0, 'Failed to collect user gid'
    if not user_facts.has_key('user_gecos'):
        assert 0, 'Failed to collect user gecos'
    if not user_facts.has_key('user_dir'):
        assert 0, 'Failed to collect user dir'