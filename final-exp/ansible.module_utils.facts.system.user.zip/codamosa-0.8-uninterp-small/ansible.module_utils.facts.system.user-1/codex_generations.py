

# Generated at 2022-06-25 00:44:15.449786
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    collected_facts_1 = {
        'system': {
            'system': 'Linux',
            'distribution': 'CentOS',
            'release': '7.7.1908',
            'distribution_release': 'CentOS Linux 7.7.1908 (Core)'
        }
    }

# Generated at 2022-06-25 00:44:19.409248
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_collect = UserFactCollector()

    user_fact_collector_collect.collect()

    assert user_fact_collector_collect.collect() is not None

# Generated at 2022-06-25 00:44:22.418331
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Test case 0
    user_fact_collector_0 = UserFactCollector()
    user_facts = user_fact_collector_0.collect()
    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['effective_user_id'] == os.geteuid()

# Generated at 2022-06-25 00:44:26.380596
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    collected_facts = {}
    user_fact_collector_0.collect(collected_facts)

# Test Cases for class UserFactCollector

# Generated at 2022-06-25 00:44:30.662146
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector0 = UserFactCollector()
    user_fact_collector0.collect()

# Generated at 2022-06-25 00:44:34.970489
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_fact_collector_1.collect()

# Generated at 2022-06-25 00:44:43.825068
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()

    # Case 1
    user_facts = user_fact_collector_0.collect()
    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['user_uid'] == os.getuid()
    assert user_facts['user_gid'] == os.getgid()
    #assert user_facts['user_gecos'] == pwd.getpwuid(os.getuid()).pw_gecos
    #assert user_facts['user_dir'] == pwd.getpwuid(os.getgid()).pw_dir
    #assert user_facts['user_shell'] == pwd.getpwuid(os.getgid()).pw_shell

# Generated at 2022-06-25 00:44:53.437434
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_collect_obj = UserFactCollector()
    user_facts = user_fact_collector_collect_obj.collect()

    assert type(user_facts) == type({})
    assert user_facts['user_id'] == getpass.getuser()

    try:
        pwent = pwd.getpwnam(getpass.getuser())
    except KeyError:
        pwent = pwd.getpwuid(os.getuid())

    assert user_facts['user_uid'] == pwent.pw_uid
    assert user_facts['user_gid'] == pwent.pw_gid
    assert user_facts['user_gecos'] == pwent.pw_gecos
    assert user_facts['user_dir'] == pwent.pw_dir
    assert user_

# Generated at 2022-06-25 00:44:53.904883
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    pass

# Generated at 2022-06-25 00:44:55.259209
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()

# Generated at 2022-06-25 00:45:04.655073
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect()

    assert var_0 == {
        'user_id': 'vagrant',
        'user_uid': 1000,
        'user_gid': 1000,
        'user_gecos': 'Vagrant',
        'user_dir': '/home/vagrant',
        'user_shell': '/bin/bash',
        'real_user_id': 1000,
        'effective_user_id': 1000,
        'real_group_id': 1000,
        'effective_group_id': 1000
    }


# Generated at 2022-06-25 00:45:14.008931
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()

    # test with a single value
    user_facts_0 = user_fact_collector_0.collect()
    assert user_facts_0.get('user_id')

    # test with a single value
    assert user_facts_0.get('user_uid')

    # test with a single value
    assert user_facts_0.get('user_gid')

    # test with a single value
    assert user_facts_0.get('user_gecos')

    # test with a single value
    assert user_facts_0.get('user_dir')

    # test with a single value
    assert user_facts_0.get('user_shell')

# Generated at 2022-06-25 00:45:24.455543
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    str_0 = 'IwM_wh'
    str_1 = '0UyRDR'
    dict_0 = {}
    dict_0['user_id'] = user_fact_collector_0.collect().get('user_id')
    dict_0['user_uid'] = user_fact_collector_0.collect().get('user_uid')
    dict_0['real_user_id'] = user_fact_collector_0.collect().get('real_user_id')
    dict_0['effective_user_id'] = user_fact_collector_0.collect().get('effective_user_id')
    dict_0['user_gid'] = user_fact_collector_0.collect().get('user_gid')


# Generated at 2022-06-25 00:45:27.374306
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect()
    assert var_0 == user_fact_collector_0.collect()


# Generated at 2022-06-25 00:45:27.895357
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    pass

# Generated at 2022-06-25 00:45:31.418019
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    assert user_fact_collector_0.collect()


# Generated at 2022-06-25 00:45:32.844364
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    print("Testing collect() of class UserFactCollector")

    # Testing empty list
    test_case_0()

test_UserFactCollector_collect()

# Generated at 2022-06-25 00:45:37.463870
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    collected_facts = {}
    user_fact_collector_0 = UserFactCollector()
    ansible_user_0 = getpass.getuser()
    ansible_user_1 = getpass.getuser()
    ansible_user_2 = getpass.getuser()
    ansible_user_3 = getpass.getuser()
    ansible_user_4 = getpass.getuser()
    var_0 = user_fact_collector_0.collect(None, collected_facts)

# Generated at 2022-06-25 00:45:44.497834
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect()
    assert var_0 == {u'effective_group_id': 1000, u'effective_user_id': 1000, u'real_user_id': 1000, u'real_group_id': 1000, u'user_gid': 1000, u'user_id': u'vmadmin', u'user_gecos': u'', u'user_uid': 1000, u'user_dir': u'/home/vmadmin', u'user_shell': u'/bin/bash'}

# Generated at 2022-06-25 00:45:51.294296
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect()
    #assert var_0 == {'vars': {'ansible_user_dir': '/home/test', 'ansible_user_id': 'test', 'ansible_user_shell': '/bin/zsh', 'ansible_user_gecos': 'User,,,', 'ansible_user_gid': 1000, 'ansible_real_group_id': 1000, 'ansible_real_user_id': 1000, 'ansible_effective_user_id': 0, 'ansible_effective_group_id': 0, 'ansible_user_uid': 1000}}


# Generated at 2022-06-25 00:46:00.040503
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    var_1 = user_fact_collector_0.collect()
    assert var_1 == {'user_id': 'root',
                     'user_uid': 0,
                     'user_gid': 0,
                     'user_gecos': 'root',
                     'user_dir': '/root',
                     'user_shell': '/bin/bash',
                     'real_user_id': 0,
                     'effective_user_id': 0,
                     'real_group_id': 0,
                     'effective_group_id': 0}

# Generated at 2022-06-25 00:46:10.087678
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_facts = {}

    user_facts['user_id'] = getpass.getuser()
    var_0 = getpass.getuser()

    try:
        pwent = pwd.getpwnam(getpass.getuser())
    except KeyError:
        pwent = pwd.getpwuid(os.getuid())

    user_facts['user_uid'] = pwent.pw_uid
    var_1 = pwent.pw_uid

    user_facts['user_gid'] = pwent.pw_gid
    var_2 = pwent.pw_gid

    user_facts['user_gecos'] = pwent.pw_gecos
    var_3 = pwent.pw_gecos

    user_facts['user_dir'] = pwent.pw_dir

# Generated at 2022-06-25 00:46:10.963533
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    assert type(test_case_0) == dict

# Generated at 2022-06-25 00:46:17.074156
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    var_1 = user_fact_collector_0.collect()
    assert user_fact_collector_0._fact_ids == set(['user_id', 'user_uid', 'real_group_id', 'user_dir', 'real_user_id', 'user_gecos', 'user_shell', 'user_gid', 'effective_user_id', 'effective_group_id']), var_1



# Generated at 2022-06-25 00:46:18.768933
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    result_0 = test_case_0()

if __name__ == '__main__':
    test_UserFactCollector_collect()

# Generated at 2022-06-25 00:46:23.012590
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect()
    assert var_0 is not False, "Method returns false"
    assert var_0 is not None, "Method returns None"


# Generated at 2022-06-25 00:46:23.840588
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    test_case_0()


# Generated at 2022-06-25 00:46:32.462969
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    user_fact_collector_1 = UserFactCollector()
    var_1 = user_fact_collector_1.collect()

    assert(var_1['user_id']) == (current_user)
    assert(var_1['user_uid']) == (uid)
    assert(var_1['user_gid']) == (gid)
    assert(var_1['user_gecos']) == (gecos)
    assert(var_1['user_dir']) == (homedir)
    assert(var_1['user_shell']) == (shell)
    assert(var_1['real_user_id']) == (os.getuid())
    assert(var_1['effective_user_id']) == (os.geteuid())

# Generated at 2022-06-25 00:46:35.731220
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    v = user_fact_collector_1.collect()
    assert(v == {'user_gid': 501, 'effective_user_id': 501, 'effective_group_id': 501, 'user_uid': 501, 'user_dir': '/Users/sriharshachilakapati', 'user_shell': '/bin/bash', 'real_user_id': 501, 'user_gecos': 'Sriharsha Chilakapati,,,', 'user_id': 'sriharshachilakapati'})


# Generated at 2022-06-25 00:46:37.076554
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect()


# Generated at 2022-06-25 00:46:50.042140
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    # UserFactCollector is instantiated
    # with self.name = 'other_user_collector_name'
    user_fact_collector_0 = UserFactCollector()

    # In case the 'user_id' is not in user_facts['ansible_facts']
    # test for KeyError
    if user_fact_collector_0.name not in var_0['ansible_facts'] \
     or 'user_id' not in var_0['ansible_facts'][user_fact_collector_0.name]:
        raise AssertionError(
            "\nError: {}: facts['ansible_facts'][{}]['user_id'] is not set\n".format(
                user_fact_collector_0.__class__.__name__, user_fact_collector_0.name))

# Generated at 2022-06-25 00:46:57.767629
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect()
    assert var_0 == {'effective_group_id': 1000, 'effective_user_id': 1000, 'real_group_id': 1000, 'real_user_id': 1000, 'user_dir': '/home/fred', 'user_gecos': 'Fred Jones,Some Office,123,555-1234,(123) 555-4321,fred@example.com', 'user_gid': 1000, 'user_id': 'fred', 'user_shell': '/bin/bash', 'user_uid': 1000}

# Generated at 2022-06-25 00:47:04.540082
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Test case with 0 arguments
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect()
    assert var_0 == {'effective_user_id': 1002, 'user_gid': 1002, 'user_gecos': 'User,,,', 'user_id': 'user', 'user_shell': '/bin/bash', 'user_dir': '/home/user', 'effective_group_id': 1002, 'user_uid': 1002, 'real_group_id': 1002, 'real_user_id': 1002}


# Generated at 2022-06-25 00:47:06.232712
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect()

# Generated at 2022-06-25 00:47:07.965987
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    var_1 = user_fact_collector_1.collect()

# Generated at 2022-06-25 00:47:14.960994
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    var_1 = user_fact_collector_1.collect()
    assert var_1['user_id'] == getpass.getuser()
    assert var_1['user_uid'] == pwd.getpwnam(getpass.getuser()).pw_uid
    assert var_1['user_gid'] == pwd.getpwnam(getpass.getuser()).pw_gid
    assert var_1['user_gecos'] == pwd.getpwnam(getpass.getuser()).pw_gecos
    assert var_1['user_dir'] == pwd.getpwnam(getpass.getuser()).pw_dir

# Generated at 2022-06-25 00:47:17.334831
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_fact_collector.collect()

# Generated at 2022-06-25 00:47:19.410742
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    var_1 = user_fact_collector_0.collect()


# Generated at 2022-06-25 00:47:25.986763
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    results = dict(
        ansible_facts=dict(
            user=dict(
                effective_group_id=1000,
                effective_user_id=1000,
                real_user_id=1000,
                user_dir="/home/jdoe",
                user_gid=1000,
                user_gecos="John Doe",
                user_id="jdoe",
                user_shell="/bin/bash",
                user_uid=1000,
                effective_group_ids=[1000],
                real_group_id=1000
            )
        )
    )
    assert results == UserFactCollector().collect()

# Generated at 2022-06-25 00:47:32.691724
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    var_1 = user_fact_collector_0.collect()

# Generated at 2022-06-25 00:47:48.564823
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    assertion_0 = False
    try:
        test_case_0()
        assertion_0 = True
    except:
        pass
    assert assertion_0


# Generated at 2022-06-25 00:47:49.400350
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    print(UserFactCollector().collect())

# Generated at 2022-06-25 00:47:51.039282
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    assert isinstance(user_fact_collector_1.collect(), dict)

# Generated at 2022-06-25 00:47:52.639179
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect()


# Generated at 2022-06-25 00:48:02.537205
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Test if the instance works
    user_fact_collector_0 = UserFactCollector()
    assert isinstance(user_fact_collector_0, UserFactCollector)
    # Test if the instance works
    collected_facts_0 = {}
    collected_facts_0['ansible_user'] = 'ansible_user'
    collected_facts_0['ansible_user_id'] = 'ansible_user_id'
    var_1 = user_fact_collector_0.collect(collected_facts=collected_facts_0)

# Generated at 2022-06-25 00:48:10.941894
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    var_1 = user_fact_collector_1.collect()
    assert isinstance(var_1, dict)
    assert 'user_id' in var_1
    assert isinstance(var_1['user_id'], str)
    assert 'user_uid' in var_1
    assert isinstance(var_1['user_uid'], int)
    assert 'user_gid' in var_1
    assert isinstance(var_1['user_gid'], int)
    assert 'user_gecos' in var_1
    assert isinstance(var_1['user_gecos'], str)
    assert 'user_dir' in var_1
    assert isinstance(var_1['user_dir'], str)

# Generated at 2022-06-25 00:48:12.465975
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    p = UserFactCollector()
    assert p.collect() == None



# Generated at 2022-06-25 00:48:21.897938
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    user_fact_collector_1 = UserFactCollector()
    result_1 = user_fact_collector_1.collect()
    assert result_1['user_id'] == getpass.getuser()
    assert result_1['user_uid'] == pwent.pw_uid
    assert result_1['user_gid'] == pwent.pw_gid
    assert result_1['user_gecos'] == pwent.pw_gecos
    assert result_1['user_dir'] == pwent.pw_dir
    assert result_1['user_shell'] == pwent.pw_shell
    assert result_1['real_user_id'] == os.getuid()

# Generated at 2022-06-25 00:48:23.803518
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    user_fact_collector_1 = UserFactCollector()
    var_1 = user_fact_collector_1.collect(module=None)

# Generated at 2022-06-25 00:48:26.879848
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    pass

# Generated at 2022-06-25 00:48:59.832669
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    known_0 = True
    known_0 = known_0 and 'user_id' in user_fact_collector_0.collect()
    known_0 = known_0 and 'user_shell' in user_fact_collector_0.collect()
    assert known_0


# Generated at 2022-06-25 00:49:03.647506
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    assert isinstance(user_fact_collector.collect(), dict)

# Generated at 2022-06-25 00:49:08.145874
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    assert user_fact_collector_1.collect() == {'effective_group_id': 20, 'user_gid': 20, 'effective_user_id': 1000, 'user_uid': 1000, 'real_user_id': 1000, 'user_shell': '/bin/bash', 'user_id': 'ansible', 'user_dir': '/home/ansible', 'user_gecos': 'ansible,,,', 'real_group_id': 20}

# Generated at 2022-06-25 00:49:14.044298
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect()

# Generated at 2022-06-25 00:49:17.823205
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_2 = UserFactCollector()
    var_1 = user_fact_collector_2.collect()


# Generated at 2022-06-25 00:49:23.467492
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    var_0 = UserFactCollector()
    var_1 = None
    var_2 = None
    var_3 = var_0.collect(var_1, var_2)
    assert isinstance(var_3, dict)
    assert var_3 == {'user_id': 'vagrant', 'user_uid': 1000, 'real_user_id': 1000, 'user_shell': '/bin/bash', 'user_dir': '/home/vagrant', 'user_gecos': 'Vagrant,,,', 'effective_group_ids': [1000], 'effective_user_id': 1000, 'user_gid': 1000}
    var_0 = UserFactCollector()
    var_1 = None
    var_2 = None
    var_3 = var_0.collect(var_1, var_2)

# Generated at 2022-06-25 00:49:33.827772
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect()

# Generated at 2022-06-25 00:49:36.702975
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect()


# Generated at 2022-06-25 00:49:39.194449
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect()


# Generated at 2022-06-25 00:49:44.444114
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    var_1 = user_fact_collector_0.collect()
    assert var_1 is not ''
    assert var_1 == {'effective_group_id': 0, 'user_gecos': '', 'effective_user_id': 0, 'real_user_id': 0, 'user_id': 'root', 'user_uid': 0, 'real_group_id': 0, 'user_gid': 0, 'user_shell': '/bin/sh', 'user_dir': '/root'}


# Generated at 2022-06-25 00:50:57.888651
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect()
    assert var_0 is not None

# Generated at 2022-06-25 00:51:00.173859
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    assert True

# Generated at 2022-06-25 00:51:09.740415
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    import sys
    import pexpect

    exp_out = ['root', '0', '0', 'root', '/root', '/bin/bash', 0, 0, 0]

    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()

    assert user_fact_collector_0.name == "user"
    assert user_fact_collector_0._fact_ids == {
        'effective_group_ids', 'user_uid', 'user_id', 'user_gecos', 'real_user_id', 'user_dir', 'effective_user_id',
        'user_gid', 'user_shell'}

    assert var_0['effective_group_ids'] == [0]
    assert var_0['user_uid'] == 0

# Generated at 2022-06-25 00:51:18.229987
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect()
    assert 'user_id' in var_0
    assert var_0['user_id'] == getpass.getuser()
    assert 'user_uid' in var_0
    assert 'effective_group_ids' in var_0
    assert 'effective_user_id' in var_0
    assert 'real_user_id' in var_0
    assert 'user_gid' in var_0
    assert 'user_gecos' in var_0
    assert 'user_dir' in var_0
    assert 'user_shell' in var_0

# Generated at 2022-06-25 00:51:20.262310
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    test_case_0()


# Generated at 2022-06-25 00:51:21.150176
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    assert user_fact_collector_1.collect() is not None


# Generated at 2022-06-25 00:51:26.682562
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    os.environ['USER'] = 'exit'
    user_fact_collector = UserFactCollector()
    var = user_fact_collector.collect()
    assert var['user_id'] == 'exit'

# Generated at 2022-06-25 00:51:28.625668
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect()


# Generated at 2022-06-25 00:51:30.809578
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    var_1 = UserFactCollector()
    var_2 = UserFactCollector()
    var_1.collect()
    try:
        var_2.collect('var_3', 'var_4')
    except:
        pass

# Generated at 2022-06-25 00:51:33.225115
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect()
