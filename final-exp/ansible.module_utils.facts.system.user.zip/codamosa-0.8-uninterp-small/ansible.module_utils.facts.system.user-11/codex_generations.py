

# Generated at 2022-06-25 00:44:23.209154
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    expected_result = {
        'user_id': 'test-user',
        'user_uid': 1000,
        'user_gid': 1000,
        'user_gecos': 'test-user',
        'user_dir': '/home/test-user',
        'user_shell': '/bin/sh',
        'real_user_id': 1000,
        'effective_user_id': 1000,
        'real_group_id': 1000,
        'effective_group_id': 1000
    }

    user_fact_collector_0 = UserFactCollector()
    actual_result = user_fact_collector_0.collect()

    assert expected_result == actual_result

# Generated at 2022-06-25 00:44:25.420913
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_facts = user_fact_collector_1.collect()

    assert isinstance(user_facts, dict)



# Generated at 2022-06-25 00:44:35.144539
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    fact_ids = user_fact_collector.collect()
    assert fact_ids.get('user_id') is not None
    assert fact_ids.get('user_id') == getpass.getuser()
    assert fact_ids.get('user_uid') == getpass.getuser()
    assert fact_ids.get('user_gid') == getpass.getuser()
    assert fact_ids.get('user_gecos') == getpass.getuser()
    assert fact_ids.get('user_dir') == getpass.getuser()
    assert fact_ids.get('user_shell') == getpass.getuser()
    assert fact_ids.get('real_user_id') == getpass.getuser()

# Generated at 2022-06-25 00:44:36.379637
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    assert isinstance(ufc.collect(), dict)

# Generated at 2022-06-25 00:44:41.521104
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_1 = UserFactCollector()
    res = user_fact_collector_1.collect(collected_facts=user_fact_collector_1.collect(collected_facts=user_fact_collector_0.collect()))
    assert res == {'effective_group_ids': [0, 0], 'effective_user_id': 0, 'real_group_id': 0, 'real_user_id': 0, 'user_dir': '/root', 'user_gecos': 'root', 'user_gid': 0, 'user_id': 'root', 'user_shell': '/bin/bash', 'user_uid': 0}


# Generated at 2022-06-25 00:44:42.802528
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()

# Generated at 2022-06-25 00:44:43.795663
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    pass

# Generated at 2022-06-25 00:44:53.401881
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Arrange
    user_fact_collector_0 = UserFactCollector()
    test_user = getpass.getuser()

    # Act
    user_facts = user_fact_collector_0.collect()

    # Assert
    assert 'user_id' in user_facts
    assert user_facts['user_id'] == test_user
    assert 'user_uid' in user_facts
    assert 'user_gid' in user_facts
    assert 'user_gecos' in user_facts
    assert 'user_dir' in user_facts
    assert 'user_shell' in user_facts
    assert 'real_user_id' in user_facts
    assert 'effective_user_id' in user_facts
    assert 'real_group_id' in user_facts
    assert 'effective_group_id'

# Generated at 2022-06-25 00:44:55.264969
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_facts = user_fact_collector_0.collect()
    assert user_facts['user_id'] == getpass.getuser()

# Generated at 2022-06-25 00:44:59.833001
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()


# Generated at 2022-06-25 00:45:11.868832
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Test case 0
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect()
    assert var_0['user_id'] == getpass.getuser()
    assert var_0['user_uid'] == pwd.getpwuid(os.getuid()).pw_uid
    assert var_0['user_gid'] == pwd.getpwuid(os.getuid()).pw_gid
    assert var_0['user_gecos'] == pwd.getpwuid(os.getuid()).pw_gecos
    assert var_0['user_dir'] == pwd.getpwuid(os.getuid()).pw_dir
    assert var_0['user_shell'] == pwd.getpwuid

# Generated at 2022-06-25 00:45:13.423201
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()

    var_1 = user_fact_collector_1.collect()

    assert var_1 is not None


# Generated at 2022-06-25 00:45:15.624954
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # TODO: add test code for method "UserFactCollector.collect"
    pass


# Generated at 2022-06-25 00:45:17.506016
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect()


# Generated at 2022-06-25 00:45:25.551790
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    var_1 = user_fact_collector_1.collect()
    var_1_keys = frozenset(var_1['user_id'])
    assert var_1_keys == frozenset(['user_id', 'user_uid', 'user_gid',
                                    'user_gecos', 'user_dir', 'user_shell',
                                    'real_user_id', 'effective_user_id',
                                    'real_group_id', 'effective_group_id'])



# Generated at 2022-06-25 00:45:32.965174
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    var_0 = pwd.getpwuid(os.getuid())
    var_1 = var_0.pw_name
    var_2 = var_0.pw_uid
    var_3 = var_0.pw_gid
    var_4 = var_0.pw_gecos
    var_5 = var_0.pw_dir
    var_6 = var_0.pw_shell
    var_7 = os.getuid()
    var_8 = os.geteuid()

    user_fact_collector = UserFactCollector()
    var_9 = user_fact_collector.collect()
    var_10 = var_9.get('user_id')
    var_11 = var_9.get('user_uid')
    var_12 = var_9.get

# Generated at 2022-06-25 00:45:34.391515
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    assert user_fact_collector.collect()


# Generated at 2022-06-25 00:45:38.736225
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect()
    assert var_0['user_id'] == getpass.getuser()

# Generated at 2022-06-25 00:45:40.775342
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    var_1 = user_fact_collector_1.collect()



# Generated at 2022-06-25 00:45:50.179859
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    # Mock users facts
    fake_facts = {
        'user_id': 'ansible',
        'user_uid': 500,
        'user_gid': 500,
        'user_gecos': 'Ansible',
        'user_dir': '/home/ansible',
        'user_shell': '/bin/bash'
    }

    # Instantiate the UserFactCollector class
    user_fact_collector_0 = UserFactCollector()

    # Call method: collect
    result_0 = user_fact_collector_0.collect(collected_facts=fake_facts)

    # AssertionError: {'user_id': 'ansible', 'user_uid': 500, 'user_gid': 500, 'user_gecos': 'Ansible', 'effective_user_id': 500, 'user_

# Generated at 2022-06-25 00:45:55.929487
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fact_collector = UserFactCollector()
    fact_collector.collect()
    assert fact_collector._fact_ids == set(['user_id', 'user_uid', 'user_gid', 'user_gecos', 'user_dir', 'user_shell'])


# Generated at 2022-06-25 00:45:57.547911
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect()



# Generated at 2022-06-25 00:45:59.107098
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect()


# Generated at 2022-06-25 00:46:06.640293
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect()
    assert var_0 == {'effective_group_id': 0, 'effective_user_id': 0, 'real_group_id': 0, 'real_user_id': 0, 'user_dir': '/root', 'user_gecos': 'root', 'user_gid': 0, 'user_id': 'root', 'user_shell': '/bin/bash', 'user_uid': 0}

# Generated at 2022-06-25 00:46:08.179607
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    test_case_0()

# Unit test with valid parameters for class UserFactCollector

# Generated at 2022-06-25 00:46:16.236574
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect()
    assert 'effective_group_ids' in var_0
    assert 'user_gid' in var_0
    assert 'user_shell' in var_0
    assert 'user_id' in var_0
    assert 'user_uid' in var_0
    assert 'user_gecos' in var_0
    assert 'effective_user_id' in var_0
    assert 'real_user_id' in var_0
    assert 'user_dir' in var_0

# Generated at 2022-06-25 00:46:18.416878
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    if not isinstance(UserFactCollector.collect(), dict):
        raise AssertionError()


# Generated at 2022-06-25 00:46:21.396805
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect()

# Generated at 2022-06-25 00:46:24.538860
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    # Setup the mock object
    user_fact_collector_0 = UserFactCollector()

    # Test the method.
    var_0 = user_fact_collector_0.collect()

    # Teardown the mock object
    # Do nothing for now.


# Generated at 2022-06-25 00:46:27.372739
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    module_0 = None
    collected_facts_0 = None
    var_0 = user_fact_collector_0.collect(module_0, collected_facts_0)

# Generated at 2022-06-25 00:46:36.690080
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect()

# Generated at 2022-06-25 00:46:38.819296
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    var_1 = user_fact_collector_1.collect()
    assert not var_1


# Generated at 2022-06-25 00:46:46.836921
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    var_1 = getpass.getuser()
    try:
        var_2 = pwd.getpwnam(getpass.getuser())
    except KeyError:
        var_2 = pwd.getpwuid(os.getuid())
    var_3 = var_2.pw_uid
    var_4 = var_2.pw_gid
    var_5 = var_2.pw_gecos
    var_6 = var_2.pw_dir
    var_7 = var_2.pw_shell
    var_8 = os.getuid()
    var_9 = os.geteuid()
    var_10 = os.getgid()
    var_11 = os.getgid()
    user_fact_collector_1 = UserFactCollector()
    var_

# Generated at 2022-06-25 00:46:56.820283
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    var_0 = UserFactCollector()
    var_1 = var_0.collect()

    assert var_1.get('user_id') is not None, "UserFactCollector.collect() returned an incorrect value for user_id"
    assert var_1.get('user_uid') is not None, "UserFactCollector.collect() returned an incorrect value for user_uid"
    assert var_1.get('user_gid') is not None, "UserFactCollector.collect() returned an incorrect value for user_gid"
    assert var_1.get('user_gecos') is not None, "UserFactCollector.collect() returned an incorrect value for user_gecos"
    assert var_1.get('user_dir') is not None, "UserFactCollector.collect() returned an incorrect value for user_dir"

# Generated at 2022-06-25 00:46:59.604851
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    var_0 = user_fact_collector_1.collect()
    # var_0 should have a type of dict
    assert isinstance(var_0, dict)



# Generated at 2022-06-25 00:47:01.826454
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    var_0 = UserFactCollector()
    assert var_0.collect() is not None



# Generated at 2022-06-25 00:47:04.130863
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    assert isinstance(user_fact_collector_0.collect(), dict)


# Generated at 2022-06-25 00:47:06.772881
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    var_1 = user_fact_collector_1.collect()
    assert var_1 is not None
    assert var_1 == var_1


# Generated at 2022-06-25 00:47:14.115022
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    current_user = os.getlogin()
    user_fact_collector_0 = UserFactCollector()
    assert user_fact_collector_0.collect()['user_id'] == current_user
    assert user_fact_collector_0.collect()['user_uid'] == os.getuid()
    assert user_fact_collector_0.collect()['user_gid'] == os.getgid()
    assert user_fact_collector_0.collect()['user_gecos'] == pwd.getpwnam(current_user).pw_gecos
    assert user_fact_collector_0.collect()['user_dir'] == pwd.getpwnam(current_user).pw_dir
    assert user_fact_collector_0.collect()['user_shell'] == pwd.get

# Generated at 2022-06-25 00:47:15.919206
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    test_case_0()

# Generated at 2022-06-25 00:47:36.807323
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect()
    assert var_0
    assert var_0['effective_group_ids']
    assert var_0['effective_user_id']
    assert var_0['real_group_id']
    assert var_0['real_user_id']
    assert var_0['user_dir']
    assert var_0['user_gecos']
    assert var_0['user_gid']
    assert var_0['user_id']
    assert var_0['user_shell']
    assert var_0['user_uid']

# Generated at 2022-06-25 00:47:39.665795
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect()
#
# Test class UserFactCollector
#

# Generated at 2022-06-25 00:47:49.140510
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    u = UserFactCollector()
    var_1 = u.collect()
    if 'user_id' not in var_1:
        raise AssertionError("Key user_id not in var_1")
    if 'user_uid' not in var_1:
        raise AssertionError("Key user_uid not in var_1")
    if 'user_gid' not in var_1:
        raise AssertionError("Key user_gid not in var_1")
    if 'user_gecos' not in var_1:
        raise AssertionError("Key user_gecos not in var_1")
    if 'user_dir' not in var_1:
        raise AssertionError("Key user_dir not in var_1")
    if 'user_shell' not in var_1:
        raise

# Generated at 2022-06-25 00:47:51.943943
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    # collect method call
    var_0 = user_fact_collector_0.collect()
    assert var_0['user_id'] == pwd.getpwuid(os.getuid())[0]

# Generated at 2022-06-25 00:47:53.423503
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect()

# Generated at 2022-06-25 00:47:55.783066
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    test_case_0()


# Generated at 2022-06-25 00:48:03.651046
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0._fact_ids = None
    user_fact_collector_0._warnings = None
    user_fact_collector_0._warn_if_deprecated = None
    user_fact_collector_0.name = None
    user_fact_collector_0.ansible_collector = None
    user_fact_collector_0.ansible_facts = None
    user_fact_collector_0.ansible_module = None
    user_fact_collector_0.ansible_version = None
    user_fact_collector_0.collection_ignore = None
    user_fact_collector_0.collection_ignore_files = None
    user_fact_collector_0.env = None
    user

# Generated at 2022-06-25 00:48:12.100182
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    # Setup
    # No setup

    # Exercise
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect()

    # Verify
    assert (isinstance(var_0, dict))
    assert ('user_id' in var_0)
    assert ('user_uid' in var_0)
    assert ('user_gid' in var_0)
    assert ('user_gecos' in var_0)
    assert ('user_dir' in var_0)
    assert ('user_shell' in var_0)
    assert ('real_user_id' in var_0)
    assert ('effective_user_id' in var_0)
    assert ('effective_group_ids' in var_0)

    # Cleanup
    # No clean up


# Generated at 2022-06-25 00:48:14.496908
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Test case 0. Get the facts of the current user
    # Should pass
    test_case_0()


if __name__ == "__main__":
    test_UserFactCollector_collect()

# Generated at 2022-06-25 00:48:23.353583
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # get a test object
    user_fact_collector = UserFactCollector()

    # test UserFactCollector.collect()
    # collect should return a dictionary of user facts
    user_facts = user_fact_collector.collect()

    # test the user_id fact
    assert 'user_id' in user_facts
    user_id = user_facts['user_id']

    try:
        pwd.getpwnam(user_id)
        assert True
    except KeyError:
        assert False

    # test the user_uid fact
    assert 'user_uid' in user_facts
    user_uid = user_facts['user_uid']
    assert user_uid == os.getuid()

    # test the user_gid fact
    assert 'user_gid' in user_facts
    user_g

# Generated at 2022-06-25 00:48:55.830485
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect()
    assert var_0 == {'effective_group_id': 0, 'real_group_id': 0, 'effective_user_id': 0, 'real_user_id': 0, 'user_shell': '/bin/sh', 'user_uid': 0, 'user_id': 'root', 'user_gecos': 'root', 'user_gid': 0, 'user_dir': '/root'}


# Generated at 2022-06-25 00:49:04.293326
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect()
    assert var_0 == {u'effective_group_ids': {0},
                     u'effective_group_id': 0,
                     u'user_dir': u'/root',
                     u'user_uid': 0,
                     u'user_shell': u'/bin/bash',
                     u'real_group_id': 0,
                     u'user_gid': 0,
                     u'effective_user_id': 0,
                     u'user_id': u'root',
                     u'user_gecos': u'root',
                     u'real_user_id': 0}

# Generated at 2022-06-25 00:49:05.975094
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect()



# Generated at 2022-06-25 00:49:07.600643
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    var_0 = UserFactCollector()
    var_1 = var_0.collect()
    assert isinstance(var_1, dict)

# Generated at 2022-06-25 00:49:08.057239
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    pass

# Generated at 2022-06-25 00:49:09.512502
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect()



# Generated at 2022-06-25 00:49:11.465452
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect()


# Generated at 2022-06-25 00:49:21.928364
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect()
    assert var_0['user_id'] == getpass.getuser()
    assert var_0['user_uid'] == pwd.getpwnam(getpass.getuser()).pw_uid
    assert var_0['user_gid'] == pwd.getpwnam(getpass.getuser()).pw_gid
    assert var_0['user_gecos'] == pwd.getpwnam(getpass.getuser()).pw_gecos
    assert var_0['user_dir'] == pwd.getpwnam(getpass.getuser()).pw_dir

# Generated at 2022-06-25 00:49:22.909733
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect()


# Generated at 2022-06-25 00:49:26.790038
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect()


# Generated at 2022-06-25 00:50:30.365532
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    pass

# Generated at 2022-06-25 00:50:36.415352
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
  root_user_id = 'root'
  unpriv_user_id = getpass.getuser()

  user_fact_collector_0 = UserFactCollector()
  user_facts = user_fact_collector_0.collect()

  # Check that the user_id fact is set to the current user
  assert user_facts['user_id'] == unpriv_user_id

  # Check that the effective user id is set to the current user
  assert user_facts['effective_user_id'] == pwd.getpwnam(unpriv_user_id).pw_uid

  # Check that the real user id is set to the current user
  assert user_facts['real_user_id'] == pwd.getpwnam(unpriv_user_id).pw_uid

  # Check that the real group id is set

# Generated at 2022-06-25 00:50:43.847159
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Test with correct input
    user_fact_collector_1 = UserFactCollector()
    var_1 = user_fact_collector_1.collect()
    # Expected value

# Generated at 2022-06-25 00:50:47.721235
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    var_1 = 'user_id'
    var_2 = 'user_uid'
    var_3 = 'user_gid'
    var_4 = 'user_gecos'
    var_5 = 'user_dir'
    var_6 = 'user_shell'
    var_7 = 'real_user_id'
    var_8 = 'effective_user_id'
    var_9 = 'effective_group_ids'
    user_fact_collector_0 = UserFactCollector()
    var_10 = user_fact_collector_0.collect()
    assert var_10[var_1] == 'root'
    assert var_10[var_2] == 0
    assert var_10[var_3] == 0
    assert var_10[var_4] == 'root'
    assert var

# Generated at 2022-06-25 00:50:49.533667
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect()
    var_1 = user_fact_collector_0.collect()
    var_1 = user_fact_collector_0.collect()
    assert var_0 != var_1


# Generated at 2022-06-25 00:50:54.158462
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()

    # Test lines to test method collect of class UserFactCollector
    var_1 = user_fact_collector_1.collect()
    assert var_1 == {'user_id': 'root', 'user_uid': 0, 'user_gid': 0, 'user_gecos': 'root', 'user_dir': '/root', 'user_shell': '/bin/bash', 'real_user_id': 0, 'effective_user_id': 0, 'real_group_id': 0, 'effective_group_id': 0}


# Generated at 2022-06-25 00:51:00.169884
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    from ansible.module_utils.facts import collector

    class MockModule(object):
        pass

    module = MockModule()
    module.params = {}
    module.params['gather_subset'] = ['all']
    module.params['filter'] = None

    user_fact_collector.collect(module=module, collected_facts=collector.Facts())


# Generated at 2022-06-25 00:51:06.293621
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Initialize a test collector
    user_fact_collector_0 = UserFactCollector()

    # Call method collect of test collector
    var_0 = user_fact_collector_0.collect()

    print(var_0)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 00:51:11.023883
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    var_1 = user_fact_collector_1.collect()
    assert var_1['user_id'] == getpass.getuser()

# Generated at 2022-06-25 00:51:12.819162
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0._fact_ids = set()
    var_0 = user_fact_collector_0.collect({}, {})
    assert var_0 == {}



# Generated at 2022-06-25 00:53:44.881377
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect()
    # Assert equal
    assert var_0 == {}

# Generated at 2022-06-25 00:53:48.052502
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    var_1 = user_fact_collector_1.collect()


# Generated at 2022-06-25 00:53:52.148863
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect()

    assert var_0['effective_group_id'] == os.getgid()

# Generated at 2022-06-25 00:53:58.054475
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Test case: test_case_0
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect()


# Generated at 2022-06-25 00:53:59.627040
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    fixture_0 = UserFactCollector()
    fixture_1 = UserFactCollector()
    fixture_1.collect()
    var_0 = fixture_0.collect()

    assert var_0


# Generated at 2022-06-25 00:54:01.177488
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    assert True == True

# Generated at 2022-06-25 00:54:04.454343
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    assert user_fact_collector_0.collect() == {'effective_group_id': 0, 'effective_user_id': 0, 'real_group_id': 0, 'user_dir': '/root', 'user_gid': 0, 'user_gecos': 'root', 'user_id': 'root', 'user_shell': '/bin/bash', 'user_uid': 0}

# Generated at 2022-06-25 00:54:08.610490
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()


# Generated at 2022-06-25 00:54:11.582977
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    test_case_0()



# Generated at 2022-06-25 00:54:13.863153
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    var_0 = user_fact_collector_0.collect()
