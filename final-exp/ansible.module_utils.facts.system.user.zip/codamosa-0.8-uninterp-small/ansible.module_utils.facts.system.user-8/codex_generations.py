

# Generated at 2022-06-25 00:44:18.118436
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Test with default param
    user_fact_collector_1 = UserFactCollector()
    user_facts_1 = user_fact_collector_1.collect()

    assert 'user_id' in user_facts_1
    assert 'user_uid' in user_facts_1
    assert 'user_gid' in user_facts_1
    assert 'user_gecos' in user_facts_1
    assert 'user_dir' in user_facts_1
    assert 'user_shell' in user_facts_1
    assert 'real_user_id' in user_facts_1
    assert 'effective_user_id' in user_facts_1
    assert 'effective_group_ids' in user_facts_1

# Generated at 2022-06-25 00:44:25.530433
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    result = user_fact_collector.collect()
    assert result['user_id'] == getpass.getuser()
    assert isinstance(result['user_id'], str)
    assert result['user_uid'] == pwd.getpwnam(getpass.getuser()).pw_uid
    assert isinstance(result['user_uid'], int)
    assert result['user_gid'] == pwd.getpwnam(getpass.getuser()).pw_gid
    assert isinstance(result['user_gid'], int)
    assert result['user_gecos'] == pwd.getpwnam(getpass.getuser()).pw_gecos
    assert isinstance(result['user_gecos'], str)
    assert result

# Generated at 2022-06-25 00:44:30.961942
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_facts_0 = user_fact_collector_0.collect()
    assert isinstance(user_facts_0, dict)

# Generated at 2022-06-25 00:44:35.526787
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_fact_collector_1.collect()


# Generated at 2022-06-25 00:44:39.830764
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    collected_facts_1 = user_fact_collector_1.collect()
    assert collected_facts_1['user_id'] == getpass.getuser()


# Generated at 2022-06-25 00:44:43.995042
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()

# Generated at 2022-06-25 00:44:47.617619
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_fact_collector_1.collect()


# Generated at 2022-06-25 00:44:50.458692
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    collected_facts = {'user_id': 'test_user'}
    user_fact_collector_1.collect(None, collected_facts)
    assert collected_facts['user_id'] == 'test_user'

# Generated at 2022-06-25 00:44:53.830829
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fac_col_obj = UserFactCollector()
    user_fac_col_obj.collect()

# Generated at 2022-06-25 00:45:01.399190
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()

    assert user_fact_collector_0.collect() == {'effective_group_ids': os.getgid(), 'user_uid': os.getuid(), 'effective_user_id': os.geteuid(), 'user_id': getpass.getuser(), 'user_gid': os.getgid(), 'user_shell': pwd.getpwuid(os.getuid()).pw_shell, 'user_gecos': pwd.getpwuid(os.getuid()).pw_gecos, 'real_group_id': os.getgid(), 'real_user_id': os.getuid(), 'user_dir': pwd.getpwuid(os.getuid()).pw_dir}

# Generated at 2022-06-25 00:45:09.772414
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_fact_collector.collect()

# Generated at 2022-06-25 00:45:13.069099
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_collect = UserFactCollector()
    user_fact_collector_collect.collect()


# Generated at 2022-06-25 00:45:24.366881
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_facts_return_value_0 = user_fact_collector_1.collect()
    real_user_id_key_0 = 'real_user_id'
    effective_user_id_key_0 = 'effective_user_id'
    effective_group_ids_key_0 = 'effective_group_ids'
    assert real_user_id_key_0 in user_facts_return_value_0
    assert effective_user_id_key_0 in user_facts_return_value_0
    assert effective_group_ids_key_0 in user_facts_return_value_0
    user_id_key_0 = 'user_id'
    user_uid_key_0 = 'user_uid'
    user_gid_key

# Generated at 2022-06-25 00:45:32.131363
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    fa_col = UserFactCollector()
    pwd_group = pwd.getpwuid(os.getuid())
    fa_col_res = fa_col.collect()

    for key in ['user_id', 'user_uid', 'user_gid', 'user_gecos', 'user_dir', 'user_shell', 'real_user_id', 'effective_user_id', 'real_group_id', 'effective_group_id']:
        assert key in fa_col_res
        assert fa_col_res[key] == getattr(pwd_group, "pw_%s" % key)

    # Test when there is no real user
    os.setuid(0)
    fa_col_res = fa_col.collect()

# Generated at 2022-06-25 00:45:36.900698
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    print('In test_UserFactCollector_collect()')
    user_fact_collector_0 = UserFactCollector()
    print('type(user_fact_collector_0) is {0}'.format(type(user_fact_collector_0)))
    collected_facts = user_fact_collector_0.collect()
    print('type(collected_facts) is {0}'.format(type(collected_facts)))
    print('collected_facts is {0}'.format(collected_facts))

# Generated at 2022-06-25 00:45:38.151527
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()


# Generated at 2022-06-25 00:45:41.275152
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()

    collected_facts = {}

    user_facts = user_fact_collector.collect(collected_facts=collected_facts)

    print(user_facts)


# Generated at 2022-06-25 00:45:49.927300
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    collected_facts = {}
    collected_facts['ansible_env'] = {'HOME': '/tmp/ansible_test_dir'}
    # assert user_fact_collector_1.collect(collected_facts=collected_facts) == {
    #     'user_dir': '/tmp/ansible_test_dir',
    #     'effective_group_ids': [1000],
    #     'user_uid': 1000,
    #     'user_id': 'test',
    #     'real_user_id': 1000,
    #     'user_shell': '/bin/bash',
    #     'effective_user_id': 1000,
    #     'user_gid': 1000
    # }

# Generated at 2022-06-25 00:45:52.677719
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    result = user_fact_collector.collect()
    assert isinstance(result, dict)

# Generated at 2022-06-25 00:45:59.260381
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_facts = user_fact_collector_1.collect(module=None, collected_facts=None)
    assert user_facts['user_id'] != None
    assert user_facts['user_uid'] != None
    assert user_facts['user_gid'] != None
    assert user_facts['user_gecos'] != None
    assert user_facts['user_dir'] != None
    assert user_facts['user_shell'] != None
    assert user_facts['real_user_id'] != None
    assert user_facts['effective_user_id'] != None
    assert user_facts['effective_group_id'] != None

# Generated at 2022-06-25 00:46:07.359361
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()


# Generated at 2022-06-25 00:46:17.650798
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()

    assert user_facts['user_id'] is not None
    assert user_facts['user_uid'] is not None
    assert user_facts['user_gid'] is not None
    assert user_facts['user_gecos'] is not None
    assert user_facts['user_dir'] is not None
    assert user_facts['user_shell'] is not None
    assert user_facts['real_user_id'] is not None
    assert user_facts['effective_user_id'] is not None
    assert user_facts['real_group_id'] is not None
    assert user_facts['effective_group_id'] is not None



# Generated at 2022-06-25 00:46:23.977508
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_fact_collector_1_results = user_fact_collector_1.collect()

    assert user_fact_collector_1_results['user_id'] == getpass.getuser()
    assert user_fact_collector_1_results['user_uid'] == os.getuid()
    assert user_fact_collector_1_results['user_gid'] == os.getgid()
    assert user_fact_collector_1_results['user_dir'] == os.path.expanduser('~')
    assert user_fact_collector_1_results['user_shell'] == os.path.expanduser('~')
    assert user_fact_collector_1_results['real_user_id'] == os.getuid()


# Generated at 2022-06-25 00:46:32.570394
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Test with no argument
    user_fact_collector_0 = UserFactCollector()

# Generated at 2022-06-25 00:46:33.633368
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    assert user_fact_collector_1.collect()


# Generated at 2022-06-25 00:46:36.632600
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_fact_collector_1.collect()

# Generated at 2022-06-25 00:46:38.085626
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    assert user_fact_collector.collect() is not None

# Generated at 2022-06-25 00:46:39.986812
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_facts = user_fact_collector_1.collect()

# Generated at 2022-06-25 00:46:47.723557
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    results = user_fact_collector_0.collect()
    assert results['user_id'] == 'justin'
    assert results['user_uid'] == 501
    assert results['user_gid'] == 20
    assert results['user_gecos'] == 'Justin Hoppensteadt,,,justin@hoppensteadt.cc,justin@hoppensteadt.cc'
    assert results['user_dir'] == '/Users/justin'
    assert results['user_shell'] == '/bin/bash'
    assert results['real_user_id'] == 501
    assert results['effective_user_id'] == 501
    assert results['real_group_id'] == 20
    assert results['effective_group_id'] == 20

# Generated at 2022-06-25 00:46:49.655872
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()


# Generated at 2022-06-25 00:47:11.765580
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()

    # test for user_id
    user_id = getpass.getuser()
    assert user_facts['user_id'] == user_id

    # test for user_uid
    try:
        pwent = pwd.getpwnam(user_id)
    except KeyError:
        pwent = pwd.getpwuid(os.getuid())
    user_uid = pwent.pw_uid
    assert user_facts['user_uid'] == user_uid

    # test for user_gid
    user_gid = pwent.pw_gid
    assert user_facts['user_gid'] == user_gid

    # test for user_dir

# Generated at 2022-06-25 00:47:15.109471
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    user_facts = user_fact_collector.collect()

    assert type(user_facts) == dict
    assert sorted(user_fact_collector._fact_ids) == sorted(user_facts.keys())

# Generated at 2022-06-25 00:47:24.690448
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    facts = ufc.collect()
    assert facts is not None
    assert type(facts) is dict
    assert type(facts['user_id']) is str
    assert facts['user_id'] == getpass.getuser()
    assert type(facts['user_uid']) is int
    assert type(facts['user_gid']) is int
    assert type(facts['user_gecos']) is str
    assert type(facts['user_dir']) is str
    assert type(facts['user_shell']) is str
    assert type(facts['real_user_id']) is int
    assert type(facts['effective_user_id']) is int
    assert type(facts['real_group_id']) is int

# Generated at 2022-06-25 00:47:26.094783
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    facts = user_fact_collector.collect()

# Generated at 2022-06-25 00:47:28.789084
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    collected_facts = {}
    user_fact_collector_1.collect(collected_facts=collected_facts)


# Generated at 2022-06-25 00:47:37.624593
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    uf_1 = user_fact_collector_1.collect()
    assert uf_1['user_id'] == getpass.getuser()
    assert uf_1['user_uid'] == pwd.getpwuid(os.getuid()).pw_uid
    assert uf_1['user_gid'] == pwd.getpwuid(os.getuid()).pw_gid
    assert uf_1['user_gecos'] == pwd.getpwuid(os.getuid()).pw_gecos
    assert uf_1['user_dir'] == pwd.getpwuid(os.getuid()).pw_dir
    assert uf_1['user_shell'] == pwd.getpw

# Generated at 2022-06-25 00:47:46.785752
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    result_1 = user_fact_collector_1.collect()
    expected_1 = """{ 'user_dir': '/home/test', 
                    'user_gecos': 'test user', 
                    'user_gid': '123', 
                    'user_id': 'test', 
                    'user_shell': '/bin/bash', 
                    'user_uid': '123',
                    'effective_group_id': '123',
                    'effective_user_id': '123',
                    'real_group_id': '123',
                    'real_user_id': '123'}"""
    assert result_1 == expected_1


# Generated at 2022-06-25 00:47:51.377627
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()

    try:
        ret = user_fact_collector_0.collect()
    except:
        ret = None

    assert ret.get('user_id', False)
    user_id = ret.get('user_id', None)
    assert user_id is not None
    assert user_id != ""
    assert isinstance(user_id, str)

    assert ret.get('user_uid', False)
    user_uid = ret.get('user_uid', None)
    assert user_uid is not None
    assert user_uid != ""
    assert isinstance(user_uid, int)

    assert ret.get('user_gid', False)
    user_gid = ret.get('user_gid', None)

# Generated at 2022-06-25 00:47:55.053363
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    ufc = UserFactCollector()
    res = ufc.collect()
    assert "user_id" in res
    assert "user_uid" in res
    assert "user_gid" in res
    assert "user_gecos" in res
    assert "user_dir" in res
    assert "user_shell" in res
    assert "real_user_id" in res
    assert "effective_user_id" in res
    assert "effective_group_ids" in res

# Generated at 2022-06-25 00:47:57.398699
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Return a data structure with the collected facts
    user_fact_collector = UserFactCollector()
    user_fact_collector.collect()

# Generated at 2022-06-25 00:48:28.234108
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 00:48:35.518906
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    collected_facts = {'user_id': 'pchukka'}
    collected_facts = user_fact_collector_0.collect(collected_facts=collected_facts)
    assert collected_facts['user_id'] == 'pchukka'
    assert collected_facts['user_uid'] == 'pchukka'
    assert collected_facts['user_gid'] == 'pchukka'
    assert collected_facts['user_gecos'] == 'pchukka'
    assert collected_facts['user_dir'] == '/pchukka'
    assert collected_facts['user_shell'] == '/pchukka'
    assert collected_facts['real_user_id'] == 'pchukka'

# Generated at 2022-06-25 00:48:40.012464
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    # create an instance of the UserFactCollector class
    user_fact_collector_1 = UserFactCollector()

    # collect facts
    user_facts = user_fact_collector_1.collect()

    # assert that user facts are collected
    assert user_facts['user_id'] == getpass.getuser()
    assert user_facts['user_uid'] == pwd.getpwuid(os.getuid()).pw_uid
    assert user_facts['user_gid'] == pwd.getpwuid(os.getuid()).pw_gid
    assert user_facts['user_gecos'] == pwd.getpwuid(os.getuid()).pw_gecos
    assert user_facts['user_dir'] == pwd.getpwuid(os.getuid()).pw

# Generated at 2022-06-25 00:48:45.066956
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()

    try:
        collected_facts = {}
        collected_facts = user_fact_collector_1.collect(collected_facts=collected_facts)
        assert collected_facts['user_id'] == getpass.getuser()
        assert collected_facts['real_user_id'] == os.getuid()
    except:
        assert False


# Generated at 2022-06-25 00:48:49.191196
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_fact_collector_1.collect()

# Generated at 2022-06-25 00:48:56.433824
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    user_fact_collector_1 = UserFactCollector()

    list_of_possible_facts_1 = set(['user_id', 'user_uid', 'user_gid', 'user_gecos', 'user_dir', 'user_shell', 'real_user_id', 'effective_user_id', 'effective_group_ids'])
    expected_1 = list_of_possible_facts_1

    assert user_fact_collector_1.get_fact_ids() == expected_1


# Generated at 2022-06-25 00:49:01.070878
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    if user_fact_collector is not None:
        user_fact_collector.collect()
    else:
        raise Exception("Failed to instantiate UserFactCollector")
    pass

# Generated at 2022-06-25 00:49:02.878072
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    assert isinstance(user_fact_collector_1.collect(), dict) == True


# Generated at 2022-06-25 00:49:05.271467
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    test_case_1 = UserFactCollector()
    collected_facts = dict()
    result = test_case_1.collect(collected_facts)
    # Since there is no clean way to test that a particular user
    # exists, we will simply test the return type here.
    assert isinstance(result, dict)



# Generated at 2022-06-25 00:49:12.729316
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    result_1 = user_fact_collector_1.collect()
    assert result_1 == {'effective_group_id': 0, 'effective_user_id': 0, 'real_user_id': 0, 'user_gid': 0, 'user_id': 'root', 'user_uid': 0, 'user_dir': '/root', 'user_shell': '/bin/bash', 'user_gecos': 'root', 'real_group_id': 0}



# Generated at 2022-06-25 00:50:26.667296
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    ansible_facts = user_fact_collector_0.collect()
    assert ansible_facts['user_id'] == 'root'
    assert ansible_facts['user_uid'] == 0
    assert ansible_facts['user_gid'] == 0
    assert ansible_facts['user_gecos'] == 'root'
    assert ansible_facts['user_dir'] == '/root'
    assert ansible_facts['user_shell'] == '/bin/bash'
    assert ansible_facts['real_user_id'] == 0
    assert ansible_facts['effective_user_id'] == 0
    assert ansible_facts['effective_group_ids'] == [0]

# Generated at 2022-06-25 00:50:28.582983
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_collector_obj = UserFactCollector()
    user_details = user_collector_obj.collect()
    assert user_details.get('user_id') == getpass.getuser()

# Generated at 2022-06-25 00:50:35.285052
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_facts_1 = user_fact_collector_1.collect()
    assert user_facts_1['user_id'] == getpass.getuser()
    assert user_facts_1['user_uid'] == pwd.getpwuid(os.getuid()).pw_uid
    assert user_facts_1['user_gid'] == pwd.getpwuid(os.getuid()).pw_gid
    assert user_facts_1['user_gecos'] == pwd.getpwuid(os.getuid()).pw_gecos
    assert user_facts_1['user_dir'] == pwd.getpwuid(os.getuid()).pw_dir
    assert user_facts_1['user_shell']

# Generated at 2022-06-25 00:50:40.617891
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    # TODO: Add test for collect method of class UserFactCollector here
    # Test state of input args and values returned



# Generated at 2022-06-25 00:50:49.524877
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_1 = UserFactCollector()
    user_facts_dict_1 = user_fact_collector_1.collect()
    expected_dict_1 = {
        "user_id": "maple",
        "user_uid": "1000",
        "user_gid": "1000",
        "user_gecos": "maple",
        "user_dir": "maple",
        "user_shell": "bash",
        "real_user_id": "1000",
        "effective_user_id": "1000",
        "real_group_id": "1000",
        "effective_group_id": "1000",
        "group_ids": ['1000']
    }
    assert user_facts_dict_1 == expected_dict_1

# Generated at 2022-06-25 00:50:56.456248
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector = UserFactCollector()
    res = user_fact_collector.collect()

    assert res['user_id'] == getpass.getuser()
    try:
        pwent = pwd.getpwnam(getpass.getuser())
    except KeyError:
        pwent = pwd.getpwuid(os.getuid())
    assert res['user_uid'] == pwent.pw_uid
    assert res['user_gid'] == pwent.pw_gid
    assert res['user_gecos'] == pwent.pw_gecos
    assert res['user_dir'] == pwent.pw_dir
    assert res['user_shell'] == pwent.pw_shell
    assert res['real_user_id'] == os.getuid()
    assert res

# Generated at 2022-06-25 00:51:02.641977
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # Initialize a instance of UserFactCollector
    user_fact_collector = UserFactCollector()

    # Call method collect of UserFactCollector instance
    collected_facts = user_fact_collector.collect()

    # Check if method collect of UserFactCollector instance returns expected facts
    assert collected_facts['user_id'] == getpass.getuser()
    assert collected_facts['user_uid'] == pwd.getpwnam(getpass.getuser()).pw_uid
    assert collected_facts['user_gid'] == pwd.getpwnam(getpass.getuser()).pw_gid
    assert collected_facts['user_gecos'] == pwd.getpwnam(getpass.getuser()).pw_gecos
    assert collected_facts['user_dir'] == pwd.get

# Generated at 2022-06-25 00:51:06.645111
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    user_fact_collector_0 = UserFactCollector()
    user_fact_collector_0.collect()

# Generated at 2022-06-25 00:51:11.091404
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    print("Testing function collect")

    user_fact_collector_1 = UserFactCollector()
    collected_facts = {}
    result = user_fact_collector_1.collect(collected_facts=collected_facts)
    assert 'user_id' in result
    assert 'user_uid' in result
    assert 'user_gid' in result
    assert 'user_gecos' in result
    assert 'user_dir' in result
    assert 'user_shell' in result
    assert 'real_user_id' in result
    assert 'real_group_id' in result
    assert 'effective_user_id' in result
    assert 'effective_group_id' in result

# Generated at 2022-06-25 00:51:12.255461
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    # To verify the method collect return a dict
    assert isinstance(UserFactCollector().collect(), dict)

# Generated at 2022-06-25 00:54:04.138328
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():

    def test_case_1():
        return ['user_id', 'user_uid', 'user_gid',
                'user_gecos', 'user_dir', 'user_shell',
                'real_user_id', 'effective_user_id',
                'effective_group_ids']

    # verify
    assert UserFactCollector._fact_ids == set(test_case_1()), \
        'Failed to create expected set of fact_ids'

# Generated at 2022-06-25 00:54:06.012215
# Unit test for method collect of class UserFactCollector
def test_UserFactCollector_collect():
    assert UserFactCollector().collect()