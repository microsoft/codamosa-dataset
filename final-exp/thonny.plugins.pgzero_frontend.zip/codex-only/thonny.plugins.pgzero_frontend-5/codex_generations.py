

# Generated at 2022-06-24 07:50:41.194141
# Unit test for function update_environment
def test_update_environment():
    orig_env = os.environ.copy()
    try:
        os.environ.clear()
        assert "PGZERO_MODE" not in os.environ
        get_workbench().set_default(_OPTION_NAME, True)
        update_environment()
        assert os.environ["PGZERO_MODE"] == "True"
        get_workbench().set_default(_OPTION_NAME, False)
        update_environment()
        assert os.environ["PGZERO_MODE"] == "False"
    finally:
        os.environ.clear()
        os.environ.update(orig_env)


if __name__ == "__main__":
    load_plugin()

# Generated at 2022-06-24 07:50:49.701258
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.common import InlineCommand
    
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()
    
    # Get the command.
    toggle_pgzero_mode_command = get_workbench().get_command("toggle_pgzero_mode")
    assert isinstance(toggle_pgzero_mode_mode_command, InlineCommand)
    
    # Get the options.

# Generated at 2022-06-24 07:50:52.669616
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    assert get_workbench().get_variable(_OPTION_NAME) == False

# Generated at 2022-06-24 07:50:55.937346
# Unit test for function update_environment
def test_update_environment():
    del os.environ["PGZERO_MODE"]
    update_environment()
    assert "PGZERO_MODE" not in os.environ
    
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    
    get_workbench().set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:51:05.627106
# Unit test for function load_plugin
def test_load_plugin():
    from test.common import (
        run_test_driver,
        get_test_tk_root,
        start_thonny,
        insert_text,
    )

    def test():
        get_workbench().set_simple_mode(True)
        assert get_workbench().get_option("run.pgzero_mode") is False
        assert os.environ.get("PGZERO_MODE", "") == "auto"

        get_workbench().set_simple_mode(False)
        assert get_workbench().get_option("run.pgzero_mode") is False
        assert os.environ.get("PGZERO_MODE", "") == "False"

        get_workbench().get_variable("run.pgzero_mode").set(True)

# Generated at 2022-06-24 07:51:12.760899
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench

    try:
        os.environ["PGZERO_MODE"]
    except:
        assert True
    else:
        assert False, "PGZERO_MODE exist before Load plugin"

    load_plugin()

    assert get_workbench().get_option(_OPTION_NAME) == False, "Should be False now."
    assert os.environ["PGZERO_MODE"] == "0", "PGZERO_MODE should be 0"

    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True, "Should be True now."
    assert os.environ["PGZERO_MODE"] == "1", "PGZERO_MODE should be 1"
    toggle_variable()


# Generated at 2022-06-24 07:51:21.815939
# Unit test for function toggle_variable
def test_toggle_variable():
    """Tests the pygamezero mode toggle variable"""
    # Set pygame zero mode value to True
    get_workbench().set_default(_OPTION_NAME, True)
    # Change value to False
    toggle_variable()
    # Check value has changed to False
    assert get_workbench().get_option(_OPTION_NAME) == False
    # Change value to True
    toggle_variable()
    # Check value has changed to True
    assert get_workbench().get_option(_OPTION_NAME) == True
    # Set pygame zero mode value to False
    get_workbench().set_default(_OPTION_NAME, False)
    # Change value to True
    toggle_variable()
    # Check value has changed to True
    assert get_workbench().get_option(_OPTION_NAME) == True

# Generated at 2022-06-24 07:51:30.821913
# Unit test for function update_environment
def test_update_environment():
    import os
    import unittest
    import_pgzero()
    import pgzero
    class TestEnv(unittest.TestCase):
        def setUp(self):
            self.initial_pgzero_mode = os.environ["PGZERO_MODE"]
            self.initial_allow_stderr = pgzero.allow_stderr
            self.get_Wb_Mock = get_workbench

            class Wb:
                def __init__(self):
                    self.options = {_OPTION_NAME: False, "general.simple_mode":False}
                def in_simple_mode(self):
                    return self.options["general.simple_mode"]
                def get_option(self, p):
                    return self.options[p]
            self.Wb = Wb

# Generated at 2022-06-24 07:51:34.689068
# Unit test for function load_plugin
def test_load_plugin():
    wb = WorkbenchStub()
    load_plugin()
    
    assert wb.get_variable(_OPTION_NAME).get() is False
    assert wb.get_command("toggle_pgzero_mode")
    assert get_workbench().get_option(_OPTION_NAME) is False



# Generated at 2022-06-24 07:51:41.452065
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:51:50.617521
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench

    wb = Workbench(load_plugins=False)

    wb.set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    wb.set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    wb.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    wb.set_simple_mode(False)
    os.environ["PGZERO_MODE"] = "simple"
    update_environment()
    assert os.environ["PGZERO_MODE"] == "simple"

# Generated at 2022-06-24 07:51:55.980874
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:51:56.509866
# Unit test for function toggle_variable
def test_toggle_variable():
    pass

# Generated at 2022-06-24 07:52:01.561160
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    # Only works under Linux
    # get_workbench().set_simple_mode(True)
    # update_environment()
    # assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:52:10.719716
# Unit test for function update_environment
def test_update_environment():
    wb=thonny.workbench.Workbench()
    # check when false
    wb.set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == '0'
    # check when true
    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == '1'
    # check in simple mode
    wb.set_simple_mode()
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:52:19.889843
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, True)
    assert get_workbench().get_option(_OPTION_NAME)
    assert "PGZERO_MODE" in os.environ and os.environ['PGZERO_MODE'] == "True"

    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert "PGZERO_MODE" in os.environ and os.environ['PGZERO_MODE'] == "False"
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    assert "PGZERO_MODE" in os.environ and os.environ['PGZERO_MODE'] == "True"

# Generated at 2022-06-24 07:52:25.882342
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.misc_utils import running_on_mac_os

    assert os.getenv("PGZERO_MODE") == "false"
    toggle_variable()
    assert os.getenv("PGZERO_MODE") == "true"
    if running_on_mac_os():
        assert get_workbench().get_option(_OPTION_NAME) == True
    else:
        assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert os.getenv("PGZERO_MODE") == "false"
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-24 07:52:36.804478
# Unit test for function update_environment
def test_update_environment():
    import os
    import unittest

    class TestCase(unittest.TestCase):
        def test_asdf(self):
            set_option_value(True)
            update_environment()
            self.assertEqual(os.environ["PGZERO_MODE"], "True")

            set_option_value(False)
            update_environment()
            self.assertEqual(os.environ["PGZERO_MODE"], "False")

        def test_in_simple_mode(self):
            set_workbench_in_simple_mode(True)
            update_environment()
            self.assertEqual(os.environ["PGZERO_MODE"], "auto")

            set_workbench_in_simple_mode(False)
            update_environment()

# Generated at 2022-06-24 07:52:45.543562
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().in_simple_mode = lambda: False
    load_plugin()
    assert get_workbench().get_option("run.pgzero_mode") == False
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert get_workbench().get_option("run.pgzero_mode") == True
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert get_workbench().get_option("run.pgzero_mode") == False
    assert os.environ["PGZERO_MODE"] == "False"

    # in simple mode ...
    get_workbench().in_simple_mode = lambda: True
    load_plugin()

# Generated at 2022-06-24 07:52:51.103612
# Unit test for function toggle_variable
def test_toggle_variable():
    # An update triggered by load_plugin, should initialize PGZERO_MODE
    load_plugin()

    # Toggle the mode from auto to manual
    toggle_variable()
    assert os.environ.get("PGZERO_MODE") == "1"

    # Toggle the mode from manual to auto
    toggle_variable()
    assert os.environ.get("PGZERO_MODE") == "0"

# Generated at 2022-06-24 07:52:54.057160
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:52:58.498686
# Unit test for function update_environment
def test_update_environment():
    import os
    from thonny import get_workbench
    os.environ["PGZERO_MODE"] = "old_value"
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:52:59.025440
# Unit test for function toggle_variable
def test_toggle_variable():
    pass

# Generated at 2022-06-24 07:53:06.054651
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.globals import get_workbench

    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )

    var = get_workbench().get_variable(_OPTION_NAME)

    assert var.get() == False
    toggle_variable()
    assert var.get() == True
    toggle_variable()
    assert var.get() == False

# Generated at 2022-06-24 07:53:10.321650
# Unit test for function toggle_variable
def test_toggle_variable():
    old_mode = os.environ["PGZERO_MODE"]
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == 'True'
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == 'False'
    os.environ["PGZERO_MODE"] = old_mode

# Generated at 2022-06-24 07:53:19.094890
# Unit test for function toggle_variable
def test_toggle_variable():
    from unittest.mock import MagicMock, patch
    from thonny import get_workbench
    from thonny.languages import tr
    
    mock_get_workbench = MagicMock()
    mock_get_workbench.name = "mock_get_workbench"
    mock_get_workbench.get_variable = MagicMock()
    mock_get_workbench.get_option = MagicMock()
    var = mock_get_workbench.get_variable
    var.set = MagicMock()
    options = mock_get_workbench.get_option
    options.get = MagicMock
    update_environment = MagicMock()

    def env_update(opts):
        if opts == True:
            return "auto"

# Generated at 2022-06-24 07:53:29.130501
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.configuration.set("run.pgzero_mode", False)
    load_plugin()
    assert wb.get_variable(_OPTION_NAME).get() == False
    wb.configuration.set("run.pgzero_mode", True)
    load_plugin()
    assert wb.get_variable(_OPTION_NAME).get() == True
    assert os.environ["PGZERO_MODE"] == "1"
    wb.configuration.set("run.pgzero_mode", "whatever")
    load_plugin()
    assert wb.get_variable(_OPTION_NAME).get() == "whatever"
    assert os.environ["PGZERO_MODE"] == "whatever"
    wb.configuration.set("run.pgzero_mode", False)

# Generated at 2022-06-24 07:53:29.859328
# Unit test for function toggle_variable
def test_toggle_variable():
    assert toggle_variable() == None

# Generated at 2022-06-24 07:53:32.864870
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default("run.pgzero_mode", False)
    toggle_variable()
    assert get_workbench().get_variable("run.pgzero_mode").get() is True
    toggle_variable()
    assert get_workbench().get_variable("run.pgzero_mode").get() is False

# Generated at 2022-06-24 07:53:41.004790
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from unittest import mock
    try:
        mock_workbench = mock.create_autospec(Workbench)
        mock_workbench.in_simple_mode.return_value = True
        with mock.patch('thonny.plugins.pgzero.get_workbench', return_value=mock_workbench):
            update_environment()
            assert os.environ.get('PGZERO_MODE', None) == 'auto'
    finally:
        # Restore previous setting
        get_workbench().set_option(_OPTION_NAME, False)
        update_environment()


# Generated at 2022-06-24 07:53:48.893797
# Unit test for function toggle_variable
def test_toggle_variable():
    global _OPTION_NAME
    _OPTION_NAME = "test_run.pgzero_mode"
    wb = get_workbench()

    wb.set_default("test_run.pgzero_mode", False)
    assert wb.get_variable("test_run.pgzero_mode").get() == False
    toggle_variable()
    assert wb.get_variable("test_run.pgzero_mode").get() == True
    toggle_variable()
    assert wb.get_variable("test_run.pgzero_mode").get() == False

# Generated at 2022-06-24 07:53:55.957747
# Unit test for function update_environment
def test_update_environment():
    from thonny.globals import get_workbench

    workbench = get_workbench()
    workbench.reset()

    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().set_simple_mode(True)

    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:54:05.204777
# Unit test for function update_environment
def test_update_environment():
    try:
        del os.environ["PGZERO_MODE"]
    except KeyError:
        pass

    load_plugin()
    wb = get_workbench()

    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    wb.set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    wb.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"


if __name__ == "__main__":
    test_update_environment()

# Generated at 2022-06-24 07:54:10.501836
# Unit test for function load_plugin
def test_load_plugin():
    from test.config_helper import get_workbench_and_shell
    from thonny.shell import Shell

    workbench, shell = get_workbench_and_shell()
    load_plugin()
    assert workbench.get_variable(_OPTION_NAME) == False
    assert shell.runsource("import pgzero") == Shell.RUNCODE_OK

# Generated at 2022-06-24 07:54:13.158332
# Unit test for function load_plugin
def test_load_plugin():
    workbench = get_workbench()
    assert "toggle_pgzero_mode" in workbench.commands



# Generated at 2022-06-24 07:54:15.521480
# Unit test for function load_plugin
def test_load_plugin():
    # the load_plugin() method is the test
    # the test is successful if there is no exception
    get_workbench().unset_default(_OPTION_NAME)
    load_plugin()

# Generated at 2022-06-24 07:54:22.189850
# Unit test for function load_plugin
def test_load_plugin():
    from unittest import mock
    from thonny.workbench import Workbench
    from thonny.misc_utils import running_on_mac_os, running_on_windows

    # Mock functions part of the plugin
    mock_get_workbench = mock.Mock()
    mock_get_option = mock.Mock()
    mock_get_variable = mock.Mock()
    mock_set_default = mock.Mock()
    mock_add_command = mock.Mock()

    mock_get_variable.get.return_value = True
    mock_get_workbench.get_variable.return_value = mock_get_variable
    mock_get_workbench.get_option.return_value = mock_get_option
    

# Generated at 2022-06-24 07:54:32.354851
# Unit test for function toggle_variable
def test_toggle_variable():
    from unittest.mock import MagicMock
    from unittest.mock import patch

    wb_mock = MagicMock()
    wb_mock.in_simple_mode = MagicMock(return_value=False)
    wb_mock.set_option = MagicMock()

    with patch('thonny.plugins.pgzero_mode.get_workbench', return_value=wb_mock):
        toggle_variable()
        _, set_option_args = wb_mock.set_option.call_args_list[0]

        assert 'run.pgzero_mode' == set_option_args['config_option']
        assert False is set_option_args['new_value']


# Generated at 2022-06-24 07:54:34.497131
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert get_workbench().get_variable(_OPTION_NAME).get() is False
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:54:39.625529
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()

# Generated at 2022-06-24 07:54:41.314034
# Unit test for function load_plugin
def test_load_plugin():
    # This function is created only to have a place where
    # to add a breakpoint when debugging in command line
    assert True

# Generated at 2022-06-24 07:54:47.732489
# Unit test for function load_plugin
def test_load_plugin():
    import unittest
    from unittest.mock import Mock
    from thonny import get_workbench

    class Test(unittest.TestCase):

        def setUp(self):
            unittest.TestCase.setUp(self)
            get_workbench().set_default(_OPTION_NAME, False)
            self.real_get_variable = get_workbench().get_variable
            self.real_get_option = get_workbench().get_option
            self.real_set_option = get_workbench().set_option

            self.get_variable_call_count = 0
            self.get_variable_return_values = [False]
            get_workbench().get_variable = Mock(
                side_effect=self.on_get_variable_called
            )

# Generated at 2022-06-24 07:54:54.631482
# Unit test for function update_environment
def test_update_environment():
    # test if runs without error in simple mode
    os.environ["PGZERO_MODE"] = "auto"
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    # test if runs without error in pro mode
    os.environ["PGZERO_MODE"] = "auto"
    get_workbench().set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    # test if runs without error in pro mode with option on
    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, True)
    os.environ["PGZERO_MODE"] = "auto"
   

# Generated at 2022-06-24 07:55:05.271472
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, False)
    get_workbench().set_default(_OPTION_NAME, True)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_simple_mode(True)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "auto"
    
    
if __name__ == "__main__":
    test_toggle_variable()

# Generated at 2022-06-24 07:55:08.398576
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_option(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) is True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) is False

# Generated at 2022-06-24 07:55:11.195974
# Unit test for function toggle_variable
def test_toggle_variable():
    var = get_workbench().get_variable(_OPTION_NAME)
    assert var.get() == True

    toggle_variable()
    assert var.get() == False

    toggle_variable()
    assert var.get() == True

# Generated at 2022-06-24 07:55:18.621883
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().destroy()

# Generated at 2022-06-24 07:55:25.936824
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_simple_mode()
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    os.environ["PGZERO_MODE"] = "1"
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"
    del os.environ["PGZERO_MODE"]

# Generated at 2022-06-24 07:55:31.632214
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import MagicMock
    from unittest.mock import patch

    wb = MagicMock()
    wb.in_simple_mode.return_value = False
    wb.get_option.return_value = False

    with patch("thonny.workbench.Workbench.get_workbench",
               MagicMock(return_value=wb)):
        with patch("thonny.extensions.pygame_zero_mode.update_environment"):
            load_plugin()



# Generated at 2022-06-24 07:55:38.618194
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_simple_mode()
    wb.set_default(_OPTION_NAME, False)
    assert wb.get_option(_OPTION_NAME) == False
    load_plugin()
    assert wb.get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "auto"
    # toggle
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"
    # toggle
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"
    # in simple mode
    wb.set_simple_mode()

# Generated at 2022-06-24 07:55:43.296628
# Unit test for function update_environment
def test_update_environment():
    from unittest import mock
    from thonny import get_workbench

    with mock.patch("os.environ", dict()):
        get_workbench().set_default(_OPTION_NAME, False)
        update_environment()
        assert os.environ["PGZERO_MODE"] == "False"
        get_workbench().set_default(_OPTION_NAME, True)
        update_environment()
        assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:55:48.542264
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME)
    toggle_variable()
    assert not get_workbench().get_option(_OPTION_NAME)

# Unittest for function update_environment

# Generated at 2022-06-24 07:55:53.470854
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import utils
    from thonny.misc_utils import running_on_mac_os, running_on_windows

    if running_on_mac_os() or running_on_windows():
        utils.inject_tk_code(
            """
            tk_setPalette %s
            """
            % (utils.COLOR_SCHEME_NAME.lower())
        )

# Generated at 2022-06-24 07:55:56.594290
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert get_workbench().get_variable(_OPTION_NAME) == "0"
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True

# Generated at 2022-06-24 07:55:59.702972
# Unit test for function toggle_variable
def test_toggle_variable():
    if 'PGZERO_MODE' in os.environ:
        del os.environ['PGZERO_MODE']

    load_plugin()
    assert os.getenv('PGZERO_MODE') == 'False'

    toggle_variable()

    assert os.getenv('PGZERO_MODE') == 'True'

# Generated at 2022-06-24 07:56:08.236408
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()
    var = wb.get_variable(_OPTION_NAME)
    assert var.is_flag()
    assert not var.get()
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    var = wb.get_variable(_OPTION_NAME)
    assert var.get()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:56:14.421989
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_option(_OPTION_NAME, False)
    get_workbench().set_simple_mode()
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:56:22.550772
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_variable("run.pgzero_mode", True)
    assert _OPTION_NAME in wb.get_options()
    assert wb.get_option(_OPTION_NAME)
    assert os.environ["PGZERO_MODE"] == "True"
    load_plugin()
    assert os.environ["PGZERO_MODE"] == "True"
    wb.set_variable("run.pgzero_mode", False)
    assert os.environ["PGZERO_MODE"] == "False"


# Generated at 2022-06-24 07:56:30.605362
# Unit test for function update_environment
def test_update_environment():
    from thonny.globals import get_workbench
    from unittest.mock import MagicMock
    wb = get_workbench()

    wb.in_simple_mode = MagicMock()

    def side_effect():
        pass
    wb.get_option = MagicMock(return_value=False)
    os.environ = {}
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"


    wb.get_option = MagicMock(return_value=True)
    os.environ = {}
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"


    wb.in_simple_mode = MagicMock(return_value=True)
    os.environ = {}
    update_

# Generated at 2022-06-24 07:56:41.504278
# Unit test for function load_plugin
def test_load_plugin():
    class Test(object):
        def in_simple_mode(self):
            return False
        def get_option(self, prop):
            assert prop == _OPTION_NAME
            return True
        def set_default(self, prop, val):
            assert prop == _OPTION_NAME
            assert val == False
        def add_command(self, name, place, label, func, flag_name, group):
            assert name == 'toggle_pgzero_mode'
            assert place == 'run'
            assert label == 'Pygame Zero mode'
            assert func == toggle_variable
            assert flag_name == _OPTION_NAME
            assert group == 40

        def get_variable(self, name):
            class Var:
                def set(self, val):
                    assert val == False
                    self.v = val

# Generated at 2022-06-24 07:56:49.353886
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_option(_OPTION_NAME, True)
    assert get_workbench().get_option(_OPTION_NAME) is True
    assert os.environ["PGZERO_MODE"] == 'True'
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) is False
    assert os.environ["PGZERO_MODE"] == 'False'
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) is True
    assert os.environ["PGZERO_MODE"] == 'True'

# Generated at 2022-06-24 07:56:52.871966
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_option("run.pgzero_mode", False)
    toggle_variable()
    assert get_workbench().get_option("run.pgzero_mode") == True
    toggle_variable()
    assert get_workbench().get_option("run.pgzero_mode") == False

# Generated at 2022-06-24 07:56:58.452512
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    toggle_variable()
    assert wb.get_option(_OPTION_NAME)
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert not wb.get_option(_OPTION_NAME)
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:57:05.584553
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import workbench
    from thonny.commandline import parse_options
    from thonny.languages import english
    from thonny.misc_utils import running_on_mac_os

    parse_options(["--simple-mode"])
    wb = workbench.Workbench()
    wb.create()
    wb.destroy()
    path = "library.zip"
    shutil.rmtree(path, False)
    assert not os.path.isdir(path)
    load_plugin()

    assert len(wb.get_all_commands()) == 15
    assert len(wb.get_all_flags()) == 4

    assert wb.get_variable(_OPTION_NAME).get() == False

    wb.set_option(_OPTION_NAME, True)
    assert w

# Generated at 2022-06-24 07:57:15.583842
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import workbench
    from thonny.misc_utils import running_on_mac_os, running_on_windows
    wb = workbench.Workbench()
    wb.set_default(_OPTION_NAME, True)
    wb.create()

    load_plugin()
    assert wb.get_variable(_OPTION_NAME).get()
    assert os.environ["PGZERO_MODE"] == "True"

    if running_on_mac_os() and running_on_windows():
        raise NotImplementedError
    elif running_on_mac_os():
        wb.go_to_simple_mode()
        assert os.environ["PGZERO_MODE"] == "auto"
    elif running_on_windows():
        wb.go_to_simple_mode()

# Generated at 2022-06-24 07:57:18.562043
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().in_pgzero_mode() == True



# Generated at 2022-06-24 07:57:26.845108
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import Mock

    class WbMock(Mock):
        def in_simple_mode(self):
            return True

        def get_option(self, name):
            return "True"

    os.environ["PGZERO_MODE"] = "true"
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    os.environ["PGZERO_MODE"] = "false"
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    os.environ["PGZERO_MODE"] = "true"
    get_workbench = Mock(return_value=WbMock())
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    os.en

# Generated at 2022-06-24 07:57:34.093200
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    mw = wb.get_main_window()
    assert not mw.get_menu("run").find_command("toggle_pgzero_mode")
    unload_plugin()
    load_plugin()
    assert mw.get_menu("run").find_command("toggle_pgzero_mode")
    assert not wb.get_option(_OPTION_NAME)
    assert os.environ["PGZERO_MODE"] == "False"



# Generated at 2022-06-24 07:57:41.995096
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench, ui_utils
    from thonny.plugins.run_pgzero_mode import _OPTION_NAME
    wb = get_workbench()
    wb.set_option(_OPTION_NAME, True)
    wb.get_variable(_OPTION_NAME).set(False)
    assert wb.get_variable(_OPTION_NAME).get() == False
    assert wb.get_option(_OPTION_NAME) == True
    load_plugin()
    assert wb.get_variable(_OPTION_NAME).get() == False
    assert os.environ["PGZERO_MODE"] == "False"
    wb.get_variable(_OPTION_NAME).set(True)
    assert wb.get_variable(_OPTION_NAME).get() == True

# Generated at 2022-06-24 07:57:51.486833
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import MagicMock

    wb = MagicMock()
    wb.get_option.return_value = True
    wb.in_simple_mode = MagicMock(return_value = False)
    wb.set_default = MagicMock()
    wb.add_command = MagicMock()
    
    os.environ["PGZERO_MODE"] = "0"
    
    load_plugin()
    
    assert os.environ["PGZERO_MODE"] == "True"
    
    wb.in_simple_mode.return_value = True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:57:56.964693
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-24 07:58:01.277675
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == True
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == False

# Generated at 2022-06-24 07:58:06.241555
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, True)
    assert get_workbench().get_option(_OPTION_NAME) is True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) is False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) is True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) is Fa

# Generated at 2022-06-24 07:58:15.482870
# Unit test for function load_plugin
def test_load_plugin():
    from tkinter import Tk

    root = Tk()
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, True)

    load_plugin()

    assert os.environ["PGZERO_MODE"] == "True"

    wb.in_simple_mode = lambda: True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    wb.in_simple_mode = lambda: False
    wb.get_option = lambda x: False
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    root.destroy()

# Generated at 2022-06-24 07:58:24.350788
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny import get_workbench

    if get_workbench().in_simple_mode():
        assert str(get_workbench().get_option(_OPTION_NAME)) != "True"
        assert str(get_workbench().get_option(_OPTION_NAME)) == "False"
        toggle_variable()
        assert str(get_workbench().get_option(_OPTION_NAME)) == "True"
        assert str(get_workbench().get_option(_OPTION_NAME)) != "False"
        toggle_variable()
        assert str(get_workbench().get_option(_OPTION_NAME)) != "True"
        assert str(get_workbench().get_option(_OPTION_NAME)) == "False"


# Generated at 2022-06-24 07:58:29.257670
# Unit test for function update_environment
def test_update_environment():
    assert os.environ["PGZERO_MODE"] == "0"

    get_workbench().set_default(_OPTION_NAME, True)
    get_workbench().add_option(_OPTION_NAME, True)

    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"

# Generated at 2022-06-24 07:58:38.279102
# Unit test for function update_environment
def test_update_environment():
    load_plugin()
    # Test that option can be set to true
    get_workbench().set_option(_OPTION_NAME, True)
    assert os.environ['PGZERO_MODE'] == 'True'
    # Test that option can be set to false
    get_workbench().set_option(_OPTION_NAME, False)
    assert os.environ['PGZERO_MODE'] == 'False'
    # Test that option can be set to true
    get_workbench().set_option(_OPTION_NAME, True)
    assert os.environ['PGZERO_MODE'] == 'True'
    # Test that the variable is set to 'auto' when in simple mode
    get_workbench().enter_simple_mode()
    assert os.environ['PGZERO_MODE'] == 'auto'
    # Test that

# Generated at 2022-06-24 07:58:46.806669
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().set_simple_mode(False)
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:58:55.205702
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_simple_mode(True)
    get_workbench().set_option(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True

    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, True)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False
    toggle_variable()

    get_workbench().set_simple_mode(True)
    get_workbench().set_option(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False
    toggle_variable()


# Generated at 2022-06-24 07:59:02.651654
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_option(_OPTION_NAME, True)
    get_workbench().set_simple_mode()
    load_plugin()
    assert get_workbench().get_variable(_OPTION_NAME).get()
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_option(_OPTION_NAME, False)
    load_plugin()
    assert not get_workbench().get_variable(_OPTION_NAME).get()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:59:09.625977
# Unit test for function update_environment
def test_update_environment():
    from thonny.common import Tester
    from thonny import get_workbench
    from thonny.config import get_runner_configuration

    # Run in simple mode
    Tester.clear_instance_variables()
    assert get_runner_configuration()["PygameZeroMode"] == False # default value
    get_workbench().set_simple_mode(True)
    assert "PGZERO_MODE" not in os.environ
    
    # Set variable to True and run in non-simple mode
    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    os.environ.pop("PGZERO_MODE")
    
   

# Generated at 2022-06-24 07:59:12.761128
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME) == False


# Generated at 2022-06-24 07:59:17.790575
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:59:20.696230
# Unit test for function load_plugin
def test_load_plugin():
    
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == False

    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True


# Generated at 2022-06-24 07:59:25.983814
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import Mock

    wb = Mock()
    wb.in_simple_mode.return_value = False
    wb.get_option.return_value = True
    get_workbench.return_value = wb

    update_environment()
    assert os.getenv("PGZERO_MODE") == "True"

    wb.get_option.return_value = False
    update_environment()
    assert os.getenv("PGZERO_MODE") == "False"

    wb.in_simple_mode.return_value = True
    update_environment()
    asser

# Generated at 2022-06-24 07:59:37.201348
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.plugins.pgzero_mode import _OPTION_NAME

    get_workbench().set_default(_OPTION_NAME, True)
    assert os.environ.get("PGZERO_MODE") == "True"
    assert get_workbench().get_option(_OPTION_NAME) is True
    assert get_workbench().get_variable(_OPTION_NAME).get() is True

    toggle_variable()

    assert get_workbench().get_option(_OPTION_NAME) is False
    assert get_workbench().get_variable(_OPTION_NAME).get() is False
    assert os.environ.get("PGZERO_MODE") == "False"

    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().set_simple_mode(True)
    assert os

# Generated at 2022-06-24 07:59:43.097967
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench


# Generated at 2022-06-24 07:59:45.761126
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, True)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False



# Generated at 2022-06-24 07:59:55.866633
# Unit test for function toggle_variable
def test_toggle_variable():
    from test_utils import BasicTextEditor

    get_workbench().set_default(_OPTION_NAME, False)
    editor = BasicTextEditor()
    # Test V1 and V2
    editor.set_text("from pgzero.builtins import *\n")
    assert get_workbench().get_option(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False
    editor.set_text("import pgzero\n")
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True



# Generated at 2022-06-24 08:00:02.984488
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.plugins.system_menu.easy_mode_settings import toggle_easy_mode
    from thonny import get_workbench

    #  Check that easy mode is not set to True
    easy_mode = get_workbench().get_option("view.easy_mode")
    assert easy_mode == False

    #  Check that the Pygame Zero Mode is not set to True
    pgzero_mode = get_workbench().get_option(_OPTION_NAME)
    assert pgzero_mode == False

    #  Change the Easy Mode to True
    toggle_easy_mode()

    #  Check that easy mode is now set to True
    easy_mode = get_workbench().get_option("view.easy_mode")
    assert easy_mode == True

    #  Check that the Pygame Zero Mode is now set to True


# Generated at 2022-06-24 08:00:04.392877
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert len(get_workbench().commands) == 2

# Generated at 2022-06-24 08:00:10.268761
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    assert(get_workbench().get_variable(_OPTION_NAME).get() == False)
    os.environ["PGZERO_MODE"] = "False"
    toggle_variable()
    assert(get_workbench().get_variable(_OPTION_NAME).get() == True)
    assert(os.environ["PGZERO_MODE"] == "True")
    del os.environ["PGZERO_MODE"]
    toggle_variable()
    assert(get_workbench().get_variable(_OPTION_NAME).get() == False)
    toggle_variable()
    assert(get_workbench().get_variable(_OPTION_NAME).get() == True)

# Generated at 2022-06-24 08:00:12.248466
# Unit test for function load_plugin
def test_load_plugin():
    # Testing that you can access the function without much fail
    import thonny.plugins.pgzero_mode
    thonny.plugins.pgzero_mode.load_plugin()

# Generated at 2022-06-24 08:00:17.108690
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, True)
    toggle_variable()
    assert not get_workbench().get_variable(_OPTION_NAME).get()
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get()

# Generated at 2022-06-24 08:00:24.588039
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.globals import get_workbench, get_runner
    from thonny.languages import tr
    _OPTION_NAME = "run.pgzero_mode"
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-24 08:00:34.683695
# Unit test for function toggle_variable
def test_toggle_variable():
    if os.environ["PGZERO_MODE"] == "auto":
        assert not get_workbench().get_option(_OPTION_NAME)
        toggle_variable()
        assert get_workbench().get_option(_OPTION_NAME)
        toggle_variable()
        assert not get_workbench().get_option(_OPTION_NAME)
    elif os.environ["PGZERO_MODE"] == "0":
        assert not get_workbench().get_option(_OPTION_NAME)
        toggle_variable()
        assert get_workbench().get_option(_OPTION_NAME)
        toggle_variable()
        assert get_workbench().get_option(_OPTION_NAME)
    else:
        assert get_workbench().get_option(_OPTION_NAME)
        toggle_variable()
        assert not get_work

# Generated at 2022-06-24 08:00:40.081374
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, None)
    get_workbench().in_simple_mode = lambda: True
    load_plugin()

    # Test simple mode
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().in_simple_mode = lambda: False
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    # Test environment updating
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"