

# Generated at 2022-06-24 07:51:28.546930
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench

    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)

    assert wb.get_variable(_OPTION_NAME).get() is False
    assert "PGZERO_MODE" not in os.environ

    load_plugin()

    assert wb.get_variable(_OPTION_NAME).get() is False
    assert os.environ["PGZERO_MODE"] == "False"

    toggle_variable()

    assert wb.get_variable(_OPTION_NAME).get() is True
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:51:34.964061
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock
    from thonny.workbench import Workbench

    get_workbench = Mock(return_value=Workbench(None))
    get_workbench().set_default = Mock()
    get_workbench().add_command = Mock()
    load_plugin()

    get_workbench().set_default.assert_called_with(_OPTION_NAME, False)
    get_workbench().add_command.assert_called()
    get_workbench().add_command.assert_any_call(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )

# Generated at 2022-06-24 07:51:43.425394
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_simple_mode(True)
    initial_value = get_workbench().get_variable(_OPTION_NAME).get()
    toggle_variable()

# Generated at 2022-06-24 07:51:49.142673
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    #check the default option value
    var = get_workbench().get_option(_OPTION_NAME)
    assert var == False

    #set option value to True
    toggle_variable()
    var = get_workbench().get_option(_OPTION_NAME)
    assert var == True

    #set option value to False
    toggle_variable()
    var = get_workbench().get_option(_OPTION_NAME)
    assert var == False

# Generated at 2022-06-24 07:51:52.909776
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.config import get_workbench
    load_plugin()
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:52:01.112274
# Unit test for function update_environment
def test_update_environment():
    import os
    from unittest.mock import patch
    from thonny.globals import get_workbench
    from thonny.plugins.pgzero_mode import _OPTION_NAME, update_environment
    
    # Test fails if the _OPTION_NAME is changed in some way
    if "PGZERO_MODE" in os.environ:
        os.environ.pop("PGZERO_MODE")
    
    with patch.object(get_workbench(), "in_simple_mode", return_value=True): 
        update_environment()
        assert os.getenv("PGZERO_MODE") == "auto"
    

# Generated at 2022-06-24 07:52:11.349231
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.languages import english
    from unittest.mock import Mock
    from thonny.misc_utils import swap_locales
    from thonny.workbench import Workbench

    wb = Workbench()
    get_workbench = Mock(return_value=wb)

    with swap_locales(english):
        load_plugin()

    assert wb.get_default(_OPTION_NAME) == False
    assert "Pygame Zero mode" in wb.main_window.get_menu("run").cget("menu")
    assert len(wb.user_options[_OPTION_NAME]) == 1
    assert wb.user_options[_OPTION_NAME][0] == "pgzero_mode"

# Generated at 2022-06-24 07:52:12.269540
# Unit test for function toggle_variable

# Generated at 2022-06-24 07:52:16.398548
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-24 07:52:24.739045
# Unit test for function update_environment
def test_update_environment():
    class TestValues:
        def __init__(self):
            self.test_value = False
            self.simple_mode = False
    test_val = TestValues()
    class DummyWorkbench:
        def in_simple_mode(self):
            return test_val.simple_mode
        def get_option(self, name):
            return test_val.test_value
    test_workbench = DummyWorkbench()
    _real_get_workbench = get_workbench
    get_workbench_backup = get_workbench
    get_workbench = lambda : test_workbench
    old_os_env = os.environ.get("PGZERO_MODE")
    update_environment()
    assert os.environ.get("PGZERO_MODE") == "False"
    test_val.test_

# Generated at 2022-06-24 07:52:35.479139
# Unit test for function update_environment
def test_update_environment():
    from tkinter import Tk

    root = Tk()
    get_workbench().set_default(_OPTION_NAME, False)

    # test when simple mode is on
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    # test when simple mode is off and plugin is off
    get_workbench().set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    # test when simple mode is off and plugin is on
    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"]

# Generated at 2022-06-24 07:52:40.842646
# Unit test for function update_environment
def test_update_environment():
    for in_simple_mode in (True, False):
        for value in (True, False):
            get_workbench().set_option(_OPTION_NAME, value)
            get_workbench().in_simple_mode = in_simple_mode
            update_environment()
            assert os.environ.get("PGZERO_MODE") == ("auto" if in_simple_mode else str(value))

# Generated at 2022-06-24 07:52:43.324263
# Unit test for function toggle_variable
def test_toggle_variable():
    foo = get_workbench().get_variable(_OPTION_NAME)
    toggle_variable()
    bar = get_workbench().get_variable(_OPTION_NAME)
    assert foo != bar

# Generated at 2022-06-24 07:52:53.487107
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.misc_utils import change_available_memory
    from thonny.workbench import Workbench
    from thonny.plugins.run import RunView
    from thonny.memory import _get_memory_variables

    wb = Workbench()
    main_window = wb.get_main_window()

    # Test initial state of plugin
    assert not toggle_variable.flag_name in _get_memory_variables()

    # Create run view
    RunView(main_window)

    # Toggle state
    toggle_variable()
    assert toggle_variable.flag_name in _get_memory_variables()
    assert os.environ["PGZERO_MODE"] == "True"
    assert wb.get_option(toggle_variable.flag_name)

    # Toggle state again
    toggle_variable

# Generated at 2022-06-24 07:52:58.857600
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    load_plugin()

    assert wb.get_default(_OPTION_NAME) is False
    assert wb.get_option(_OPTION_NAME) is False

    cmd_id = "toggle_pgzero_mode"
    assert wb.get_command(cmd_id) is not None
    assert wb.get_command(cmd_id).label == tr("Pygame Zero mode")
    assert wb.get_command(cmd_id).flag_name == _OPTION_NAME

# Generated at 2022-06-24 07:53:02.779161
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"



# Generated at 2022-06-24 07:53:11.737955
# Unit test for function update_environment
def test_update_environment():

    from thonny.misc_utils import running_on_mac_os
    from thonny.misc_utils import running_on_windows
    from thonny import get_workbench

    # Testing in Windows and Linux
    if running_on_windows() or not running_on_mac_os():

        # Testing in not simple mode
        get_workbench().set_simple_mode(False)
        get_workbench().set_option(_OPTION_NAME, False)
        update_environment()
        assert os.environ.get("PGZERO_MODE") == "False"

        get_workbench().set_option(_OPTION_NAME, True)
        update_environment()
        assert os.environ.get("PGZERO_MODE") == "True"

    # Testing in Mac

# Generated at 2022-06-24 07:53:18.171079
# Unit test for function toggle_variable
def test_toggle_variable():
    print("Running unit test for function toggle_variable\n")
    # Will print True if the plugin was loaded successfully
    print("plugin_loaded:", get_workbench().plugin_manager.is_plugin_loaded("pgzero_mode"))
    # Will run the function
    toggle_variable()
    # Will print the value of the PGZERO_MODE environment variable
    print("PGZERO_MODE =", os.environ["PGZERO_MODE"])

# Generated at 2022-06-24 07:53:22.260363
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME) == False

# Generated at 2022-06-24 07:53:28.462295
# Unit test for function toggle_variable
def test_toggle_variable():
    from unittest import mock
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_default = mock.MagicMock()
    wb.add_command = mock.MagicMock()

    toggle_variable()
    assert wb.set_default.called_with('run.pgzero_mode', True)
    toggle_variable()
    assert wb.set_default.called_with('run.pgzero_mode', False)

# Generated at 2022-06-24 07:53:30.417315
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()
    if os.environ["PGZERO_MODE"] == "True":
        toggle_variable()


# Generated at 2022-06-24 07:53:33.721047
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()
    env = os.environ["PGZERO_MODE"]
    if env == "1":
        assert True
    else:
        assert False
    toggle_variable()
    env = os.environ["PGZERO_MODE"]
    if env == "0":
        assert True
    else:
        assert False

# Generated at 2022-06-24 07:53:41.658832
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench

    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.get_variable(_OPTION_NAME).set(True)

    plugin = sys.modules[__name__]
    plugin.load_plugin()

    assert wb.get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"

    plugin.toggle_variable()
    assert wb.get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:53:47.234832
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    wb.set_in_simple_mode(True)
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "auto"
    
    wb.set_in_simple_mode(False)
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"

    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:53:56.019445
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    assert wb
    load_plugin()
    assert wb.default_options.get(_OPTION_NAME) == False
    assert len(wb.get_commands()) >= 1
    assert _OPTION_NAME in wb.get_variable_names()
    wb.in_simple_mode = lambda: False
    update_environment()
    assert "PGZERO_MODE" in os.environ
    assert os.environ["PGZERO_MODE"] == str(wb.get_option(_OPTION_NAME))
    wb.in_simple_mode = lambda: True
    update_environment()
    assert os.environ["PGZERO_MODE"] == str("auto")
    wb.activate_command(_OPTION_NAME)

# Generated at 2022-06-24 07:54:03.570045
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny import get_workbench
    from test_utils import captured_output
    with captured_output("stderr") as (out, err):
        toggle_variable()
        get_workbench().event_generate("Runner.on_finished")
    assert "1" in out.getvalue()
    with captured_output("stderr") as (out, err):
        toggle_variable()
        get_workbench().event_generate("Runner.on_finished")
    assert "0" in out.getvalue()

# Generated at 2022-06-24 07:54:10.613617
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import Mock, patch
    import thonny.globals
    import thonny.plugins.micropython_plugin

    with patch("os.environ.__setitem__", Mock()):
        # Case 1: simple mode, option is True
        thonny.plugins.micropython_plugin.set_simple_mode(True)
        wb = get_workbench()
        wb.set_option(_OPTION_NAME, True)
        update_environment()
        assert os.environ["PGZERO_MODE"] == "auto"

        # Case 2: simple mode, option is False
        wb.set_option(_OPTION_NAME, False)
        update_environment()
        assert os.environ["PGZERO_MODE"] == "auto"

        # Case 3: expert mode,

# Generated at 2022-06-24 07:54:19.809558
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench

    # Test simple mode
    os.environ["PGZERO_MODE"] = "auto"
    show_all_variables(True)
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_option("run.pgzero_mode", False)
    show_all_variables(True)
    assert os.environ["PGZERO_MODE"] == "auto"

    # Test expert mode
    os.environ.pop("PGZERO_MODE")
    show_all_variables(False)
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_option("run.pgzero_mode", True)
    show_all_variables(False)
    assert os.environ

# Generated at 2022-06-24 07:54:25.615408
# Unit test for function update_environment
def test_update_environment():
    from unittest import mock

    get_workbench = mock.Mock(return_value=mock.Mock(in_simple_mode=lambda: False,
                                                     get_option=lambda x: False))
    with mock.patch("thonny.plugins.pgzero_mode.get_workbench", get_workbench):
        update_environment()
        assert os.environ["PGZERO_MODE"] == "False"

    get_workbench.return_value.in_simple_mode.return_value == True
    with mock.patch("thonny.plugins.pgzero_mode.get_workbench", get_workbench):
        update_environment()
        assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:54:34.669346
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.misc_utils import running_on_windows
    from thonny.plugins.run.run_command import Run
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    run_cmd = Run()
    run_cmd._run_args = {}
    wb.set_variable("run.auto_pgz", False)
    wb.set_variable("run.show_cmd", True)

    assert wb.get_option("run.auto_pgz") == False

    toggle_variable() # False -> True
    run_cmd._run_cb()
    if running_on_windows:
        shell_cmd = 'py -m pgzero "%s"' % __file__

# Generated at 2022-06-24 07:54:41.274724
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    _ = tr("Pygame Zero mode")
    assert get_workbench().get_option(_OPTION_NAME) == False
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-24 07:54:47.709740
# Unit test for function load_plugin
def test_load_plugin():
    workbench = get_workbench()
    workbench.set_default(_OPTION_NAME, False)
    load_plugin()
    assert workbench.get_variable(_OPTION_NAME).get() == False
    assert workbench.get_option(_OPTION_NAME) == False
    toggle_variable()
    assert workbench.get_variable(_OPTION_NAME).get() == True
    assert workbench.get_option(_OPTION_NAME) == True
    toggle_variable()
    assert workbench.get_variable(_OPTION_NAME).get() == False
    assert workbench.get_option(_OPTION_NAME) == False
    # clear_option_value will also set default value
    workbench.clear_option_value(_OPTION_NAME)
    assert workbench.get_variable(_OPTION_NAME).get() == False

# Generated at 2022-06-24 07:54:54.280186
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    wb.set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    wb.in_simple_mode = lambda: True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    wb.in_simple_mode = lambda: False
    wb.set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:55:03.586119
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    wb.use_simple_backend(True)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    wb.use_simple_backend(False)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:55:10.314833
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import MagicMock
    from test.config_fixture import config_fixture

    workbench = get_workbench()
    workbench.in_simple_mode = MagicMock(return_value=True)

    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    workbench.in_simple_mode.return_value = False
    workbench.get_variable(_OPTION_NAME).set(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "true"

    workbench.get_variable(_OPTION_NAME).set(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "false"


# Generated at 2022-06-24 07:55:17.186487
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = "1"

    wb = get_workbench()
    wb.set_option("run.pgzero_mode", False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"

    wb.set_option("run.pgzero_mode", True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"

    wb.set_simple_mode()
    os.environ["PGZERO_MODE"] = "1"
    update_environment()
    assert os.environ.get("PGZERO_MODE") == "auto"
    wb.clear_simple_mode()
    assert "PGZERO_MODE" not in os.environ

# Generated at 2022-06-24 07:55:21.768416
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()
    assert (
        get_workbench().get_option(_OPTION_NAME)
    ), "We expect this option to be True (when toggled once)"
    toggle_variable()
    assert (
        not get_workbench().get_option(_OPTION_NAME)
    ), "We expect this option to be False (when toggled twice)"

# Generated at 2022-06-24 07:55:24.696752
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default(_OPTION_NAME, True)
    get_workbench().in_simple_mode = lambda: False
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:55:33.416132
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_shell
    workbench = get_shell().workbench
    load_plugin()

    # Check icons
    get_icon("") == "turtle.png"

    # Check commands
    get_workbench().get_command("toggle_pgzero_mode")

    # Check default
    get_workbench().get_option("run.pgzero_mode") == False

    # Check environment
    os.environ["PGZERO_MODE"] == "auto"

    # Change mode
    workbench.set_simple_mode(False)
    os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_option("run.pgzero_mode", True)
    os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:55:40.800943
# Unit test for function update_environment
def test_update_environment():
    os.environ.pop("PGZERO_MODE", None)
    from thonny import get_workbench
    from thonny.shell import ShellTextWidget
    from unittest import mock

    workbench = get_workbench()
    workbench.set_default(_OPTION_NAME, False)
    workbench.in_simple_mode = mock.MagicMock(return_value=True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    workbench.in_simple_mode.return_value = False
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    workbench.set_option(_OPTION_NAME, True)
    update_environment()

# Generated at 2022-06-24 07:55:49.685742
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert "PGZERO_MODE" in os.environ
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert "PGZERO_MODE" in os.environ
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_simple_mode(True)
    update_environment()
    assert "PGZERO_MODE" in os.environ
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:55:56.745715
# Unit test for function update_environment
def test_update_environment():
    from thonny.globals import get_workbench
    import os

    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:56:01.711004
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny import get_workbench
    get_workbench().set_simple_mode(False)
    assert get_workbench().get_option(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False
    

# Generated at 2022-06-24 07:56:10.464510
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)

    # First, check that the command is present
    # It is not yet added to the test menu, but that is not important right now
    assert get_workbench().get_command("toggle_pgzero_mode") is not None

    # The default value should be False
    assert get_workbench().get_option(_OPTION_NAME) is False

    # The environment variable should be set to False
    assert os.environ["PGZERO_MODE"] == "False"

    # Now flip the option
    get_workbench().set_option(_OPTION_NAME, True)
    assert get_workbench().get_option(_OPTION_NAME) is True
    assert os.environ["PGZERO_MODE"] == "True"



# Generated at 2022-06-24 07:56:15.871588
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench

    wb = Workbench()
    load_plugin()

    assert wb.get_variable(_OPTION_NAME)
    assert not wb.get_variable(_OPTION_NAME).get()

    assert "PGZERO_MODE" in os.environ
    assert os.environ["PGZERO_MODE"] == "False"

    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:56:26.221909
# Unit test for function update_environment
def test_update_environment():
    assert get_workbench().in_simple_mode() == False
    get_workbench().set_default(_OPTION_NAME, True)
    assert get_workbench().get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_default(_OPTION_NAME, False)
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_simple_mode(True)
    assert get_workbench().in_simple_mode() == True
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_simple_mode(False)
    assert get_workbench().in_

# Generated at 2022-06-24 07:56:32.849814
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock
    from thonny import get_workbench, get_runner, get_shell
    from thonny.plugins.pgzero.pgzero_mode import toggle_variable
    from thonny.plugins.pgzero.pgzero_mode import update_environment
    from thonny.plugins.pgzero.pgzero_mode import _OPTION_NAME
    
    workbench = get_workbench()
    workbench.set_default = Mock()
    workbench.add_command = Mock()
    load_plugin()
    assert workbench.set_default.called
    
    assert workbench.add_command.called
    
    
    # Unit test for function toggle_variable
    get_workbench().set_default(_OPTION_NAME, False)
    workbench.get_variable = Mock()


# Generated at 2022-06-24 07:56:42.667752
# Unit test for function load_plugin
def test_load_plugin():
    import unittest
    from unittest.mock import patch

    from thonny import get_workbench, get_shell
    from thonny.shell import ShellTextWidget
    from thonny.ui_utils import confirm, askopenfilenames, askdirectory
    from thonny.languages import tr
    from thonny.common import InlineCommand
    from thonny.running import parse_command_line_variables
    from thonny.plugins.run import _set_python_path
    from thonny import ui_utils

    from test.config_helper import ConfigHelper

    from thonny import THONNY_USER_DIR

    class TkMockup(object):
        def __init__(self):
            self.called = False


# Generated at 2022-06-24 07:56:51.117710
# Unit test for function update_environment
def test_update_environment():
    del os.environ["PGZERO_MODE"]
    get_workbench().set_option("run.pgzero_mode", False)
    get_workbench().set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_option("run.pgzero_mode", True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:57:00.639233
# Unit test for function toggle_variable
def test_toggle_variable():
    """ Tests function toggle_variable in pgzero.py
    
    Assumptions:
        1. the bool value of the option and environment variable are the same 
    """
    load_plugin()
    assert(
        get_workbench().in_simple_mode()
        or get_workbench().get_option(_OPTION_NAME) == (
            os.environ["PGZERO_MODE"] == "True"
        )
    )
    toggle_variable()
    assert(
        get_workbench().in_simple_mode()
        or get_workbench().get_option(_OPTION_NAME) == (
            os.environ["PGZERO_MODE"] == "True"
        )
    )
    
if __name__ == "__main__":
    test_toggle_variable()

# Generated at 2022-06-24 07:57:03.946514
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_option(_OPTION_NAME, False)
    assert not get_workbench().get_option(_OPTION_NAME)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME)
    toggle_variable()
    assert not get_workbench().get_option(_OPTION_NAME)

# Generated at 2022-06-24 07:57:14.304732
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.globals import get_workbench
    from thonny import THONNY_USER_DIR
    from thonny.config import get_config_dir
    from thonny import ui_utils
    from thonny.globals import get_runner
    import os
    import shutil
    from thonny.common import is_string
    from thonny.plugins.run import run_program
    import subprocess
    import json
    import queue
    import textwrap
    import thonny.assistance as assistance

    if os.path.isdir(THONNY_USER_DIR):
        shutil.rmtree(THONNY_USER_DIR)

    get_workbench().destroy()
    get_workbench().setup()
    get_workbench().create()
    get_workbench

# Generated at 2022-06-24 07:57:25.228069
# Unit test for function toggle_variable
def test_toggle_variable():
    print()
    print('==== Unit Test for: toggle_variable ====')
    default_val = get_workbench().get_option(_OPTION_NAME)

# Generated at 2022-06-24 07:57:33.369101
# Unit test for function update_environment
def test_update_environment():
    # GIVEN
    from thonny.plugins.run.backend import ProcessExecutor
    get_workbench().set_option(_OPTION_NAME, False)
    # WHEN
    update_environment()
    # THEN
    assert ProcessExecutor.get_startup_environment()["PGZERO_MODE"] == "0"
    # WHEN
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    # THEN
    assert ProcessExecutor.get_startup_environment()["PGZERO_MODE"] == "1"

# Generated at 2022-06-24 07:57:34.859153
# Unit test for function update_environment
def test_update_environment():
    for mode in ["True", "False", "auto"]:
        get_workbench().set_option(_OPTION_NAME, mode)
        update_environment()
        assert os.environ["PGZERO_MODE"] == mode

# Generated at 2022-06-24 07:57:39.711147
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, True)
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:57:45.861972
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.languages import EnglishLanguage

    wb = Workbench(EnglishLanguage())
    assert _OPTION_NAME not in wb.get_option("options").keys()
    
    load_plugin()
    assert _OPTION_NAME in wb.get_option("options").keys()

# Generated at 2022-06-24 07:57:51.531595
# Unit test for function toggle_variable
def test_toggle_variable():
    # Test part 1: check initial state
    from thonny.globals import get_workbench
    var = get_workbench().get_variable(_OPTION_NAME)
    assert var.get() == False
    # Test part 2: toggle the variable
    toggle_variable()
    assert var.get() == True
    # Test part 3: toggle back
    toggle_variable()
    assert var.get() == False



# Generated at 2022-06-24 07:58:02.178965
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench
    from thonny.workbench import Workbench
    import os

    wb = Workbench()
    wb.set_simple_mode(False)
    wb.set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    wb.set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    wb.set_simple_mode(True)
    wb.set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:58:04.417808
# Unit test for function toggle_variable
def test_toggle_variable():
    option = get_workbench().get_variable(_OPTION_NAME)
    assert option._value == False

    toggle_variable()
    assert option._value == True

    toggle_variable()
    assert option._value == False

# Generated at 2022-06-24 07:58:14.766782
# Unit test for function toggle_variable
def test_toggle_variable():
    """Tests function toggle_variable"""
    
    # Testing when it is False
    get_workbench().set_variable(_OPTION_NAME, False)
    assert get_workbench().get_variable(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"
    
    # Testing when it is True
    get_workbench().set_variable(_OPTION_NAME, True)
    assert get_workbench().get_variable(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"
    

# Generated at 2022-06-24 07:58:22.266964
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench
    workbench = get_workbench()
    workbench._variables = {}  # Hack to clear variables

    get_workbench().set_option(_OPTION_NAME, False)

    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_option(_OPTION_NAME, True)

    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    workbench.set_simple_mode()
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    workbench.set_advanced_mode()
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:58:33.138026
# Unit test for function toggle_variable
def test_toggle_variable():
    try:
        old_env_value = os.environ["PGZERO_MODE"]
    except KeyError:
        old_env_value = None
    
    # Test with autodetection (in simple mode) turned off
    get_workbench().set_simple_mode(False)
    get_workbench().get_variable(_OPTION_NAME).set(False)
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == True
    assert os.environ["PGZERO_MODE"] == "True"
    
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    assert os.environ["PGZERO_MODE"] == "False"
    
    # Test with autodetection (in simple mode) turned

# Generated at 2022-06-24 07:58:39.644856
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.globals import get_workbench
    from thonny.misc_utils import running_on_mac_os
    from thonny.config_ui import ConfigurationPage

    wb = get_workbench()
    toggle_variable()
    assert ConfigurationPage(wb, "General").get_option(_OPTION_NAME) 
    assert os.environ["PGZERO_MODE"] == "True"
    wb.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:58:47.025848
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = "auto"
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"
    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"
    del os.environ["PGZERO_MODE"]

# Generated at 2022-06-24 07:58:55.346042
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from unittest.mock import Mock
    from unittest.mock import patch

    workbench = Workbench()
    workbench.get_variable = Mock(return_value=Mock())
    get_workbench = Mock(return_value=workbench)

    with patch("thonny.plugins.pgzero_mode.get_workbench", get_workbench):
        load_plugin()
        workbench.set_default.assert_called_once_with("run.pgzero_mode", False)
        workbench.add_command.assert_called_once()
        command = workbench.add_command.call_args[0]
        assert command[0] == "toggle_pgzero_mode"
        assert command[1] == "run"

# Generated at 2022-06-24 07:58:59.460046
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.plugins.run_pgzero import toggle_variable
    from thonny import get_workbench
    from thonny.languages import tr


    # Check for get_workbench
    workbench = get_workbench()
    # Check for toggle_variable
    if workbench.get_variable(_OPTION_NAME) == False:
        toggle_variable()
        if workbench.get_variable(_OPTION_NAME) == True:
            print('test_toggle_variable: PASSED')
        else:
            print('test_toggle_variable: FAILED')
    else:
        toggle_variable()
        if workbench.get_variable(_OPTION_NAME) == False:
            print('test_toggle_variable: PASSED')
        else:
            print('test_toggle_variable: FAILED')

# Generated at 2022-06-24 07:59:07.768856
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    get_workbench().in_simple_mode = lambda: False
    assert get_workbench().get_option(_OPTION_NAME) == False

    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"
    assert get_workbench().in_pgzero_mode() == True

    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"
    assert get_workbench().in_pgzero_mode() == False

    get_workbench().in_simple_mode = lambda: True
    assert os.environ["PGZERO_MODE"] == "auto"
    assert get_

# Generated at 2022-06-24 07:59:11.431377
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_option(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME)
    toggle_variable()
    assert not get_workbench().get_option(_OPTION_NAME)

# Generated at 2022-06-24 07:59:17.226441
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, True)
    assert get_workbench().get_option(_OPTION_NAME) is True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) is False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) is True

# Generated at 2022-06-24 07:59:20.491765
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:59:27.372570
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_shell
    from thonny import workbench
    from thonny.workbench import Command

    wb = workbench.Workbench()
    s = get_shell()

    assert not wb.get_variable("run.pgzero_mode")
    assert "PGZERO_MODE" in os.environ and os.environ["PGZERO_MODE"] == "False"
    load_plugin()
    assert wb.get_variable("run.pgzero_mode") == False
    assert "PGZERO_MODE" in os.environ and os.environ["PGZERO_MODE"] == "False"

    wb.set_simple_mode(True)
    update_environment()
    assert "PGZERO_MODE" in os.environ and os.environ["PGZERO_MODE"]

# Generated at 2022-06-24 07:59:37.876192
# Unit test for function toggle_variable
def test_toggle_variable():
    from tests.utils import create_ui
    from thonny import get_workbench
    from thonny.config import BINARY_LOCATION
    from thonny.languages import tr
    import os

    create_ui(prog_path=BINARY_LOCATION)
    wb = get_workbench()

    # Testa funció inicialment
    toggle_variable()
    assert wb.get_variable(_OPTION_NAME).get() == True
    assert os.environ["PGZERO_MODE"] == "True"

    # Testa la funció una segona vegada
    toggle_variable()
    assert wb.get_variable(_OPTION_NAME).get() == False
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:59:39.829204
# Unit test for function update_environment
def test_update_environment():
    assert os.environ["PGZERO_MODE"] == "auto"
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:59:44.833142
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench

    workbench = Workbench()
    load_plugin()

    assert workbench.get_default(_OPTION_NAME) == False
    assert workbench.get_command("toggle_pgzero_mode")
    assert workbench.get_variable(_OPTION_NAME)



# Generated at 2022-06-24 07:59:53.131630
# Unit test for function toggle_variable
def test_toggle_variable():
    from unittest.mock import Mock
    from thonny.workbench import Workbench
    toggle_variable() # this should fall back to default value
    assert os.getenv("PGZERO_MODE") == "False"
    
    wb = Workbench()
    wb.set_variable(_OPTION_NAME, True)
    toggle_variable()
    assert os.getenv("PGZERO_MODE") == "True"
    
    wb.set_variable(_OPTION_NAME, False)
    toggle_variable()
    assert os.getenv("PGZERO_MODE") == "False"

# Generated at 2022-06-24 08:00:01.386670
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.globals import get_workbench, init_workbench
    from thonny.plugins.run import _OPTION_NAME
    from thonny.workbench import Workbench
    from unittest.mock import Mock

    init_workbench()
    get_workbench()._set_test_mode(True)
    get_workbench()._set_test_mode(True)
    get_workbench().get_option = Mock(return_value=False)
    get_workbench().set_default = Mock()
    get_workbench().add_command = Mock()
    load_plugin()
    # check it has been added as a command to the workbench
    assert get_workbench().add_command.call_count == 1
    # check the default option is false
    assert get_workbench().set_

# Generated at 2022-06-24 08:00:04.532477
# Unit test for function toggle_variable
def test_toggle_variable():
    variable = get_workbench().get_variable(_OPTION_NAME)
    variable.set(True)
    assert str(variable.get()) == "True"
    toggle_variable()
    assert str(variable.get()) == "False"
    toggle_variable()
    assert str(variable.get()) == "True"
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 08:00:10.618418
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench

    workbench = Workbench()
    workbench.set_default(_OPTION_NAME, True)
    workbench.set_option("view.in_simple_mode", True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    workbench.set_default(_OPTION_NAME, False)
    workbench.set_option("view.in_simple_mode", True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    workbench.set_default(_OPTION_NAME, True)
    workbench.set_option("view.in_simple_mode", False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    work

# Generated at 2022-06-24 08:00:21.176604
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.misc_utils import running_on_mac_os
    from thonny.workbench import Workbench

    wb = Workbench(None, None)

    load_plugin()

    # Check that PGZERO_MODE is set automatically when in simplified mode
    wb.in_simple_mode = lambda: True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    # Check that PGZERO_MODE is set to the value of the option when not in simplified mode
    wb.in_simple_mode = lambda: False
    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    # Check that the names of the command and flag are correct
    command = wb

# Generated at 2022-06-24 08:00:31.443701
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench

    w = get_workbench()

    assert w.get_default(_OPTION_NAME) == False
    assert w.get_option(_OPTION_NAME) == False
    assert os.environ.get("PGZERO_MODE") == "False"

    w.set_default(_OPTION_NAME, True)
    assert w.get_default(_OPTION_NAME) == True

    w.set_option(_OPTION_NAME, False)
    assert w.get_option(_OPTION_NAME) == False
    assert os.environ.get("PGZERO_MODE") == "False"

    w.set_option(_OPTION_NAME, True)
    assert w.get_option(_OPTION_NAME) == True

# Generated at 2022-06-24 08:00:33.939476
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-24 08:00:39.240724
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    wb.set_simple_mode(False)
    wb.set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    wb.set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 08:00:47.126542
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = "auto"
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 08:00:51.565787
# Unit test for function update_environment
def test_update_environment():
    from thonny.testing import EmptyWorkbench

    wb = EmptyWorkbench()

    wb.set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    wb.set_simple_mode(True)
    wb.set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 08:00:54.773289
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-24 08:01:03.762124
# Unit test for function update_environment
def test_update_environment():
    from importlib import reload
    from thonny import get_workbench, THONNY_USER_DIR
    import os.path
    import os

    os.environ["PGZERO_MODE"] = "True"

    if os.path.exists(os.path.join(THONNY_USER_DIR, "config-v2.json")):
        os.remove(os.path.join(THONNY_USER_DIR, "config-v2.json"))

    reload(get_workbench())
    wb = get_workbench()
    wb.set_simple_mode(False)
    wb.set_default(_OPTION_NAME,False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()

# Generated at 2022-06-24 08:01:15.165305
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.ui_utils import (
        clear_menu,
        get_label,
        get_menu,
        get_menu_item,
        get_menu_items,
    )

    wb = get_workbench()
    clear_menu(wb.get_menu("run"))
    get_menu_items(wb.get_menu("run"))
    load_plugin()

    wb.set_simple_mode()
    assert os.environ["PGZERO_MODE"] == "auto"
    # get_menu(wb.get_menu("run"), "toggle_pgzero_mode").label
    # get_label(get_menu(wb.get_menu("run"), "toggle_pgzero_mode")).get_text()

    # get_menu(wb.get_menu("run"), "toggle_pgzero

# Generated at 2022-06-24 08:01:17.689156
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == True

# Generated at 2022-06-24 08:01:23.011358
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    update_environment()
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "auto"