

# Generated at 2022-06-24 07:51:16.703303
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:51:20.213774
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    assert wb.get_integration().get_command("toggle_pgzero_mode")
    assert wb.get_integration().get_flag_image_path("toggle_pgzero_mode")
    assert wb.get_integration().get_option_help_string("_pgzero_mode")

# Generated at 2022-06-24 07:51:22.561085
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    get_workbench().get_option(_OPTION_NAME)



# Generated at 2022-06-24 07:51:30.460150
# Unit test for function update_environment
def test_update_environment():
    os.environ["THONNY_RUN_MODE"] = "jupyter"
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    
    os.environ["THONNY_RUN_MODE"] = "simple"
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    
    os.environ["THONNY_RUN_MODE"] = "debug"
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    
    os.environ["THONNY_RUN_MODE"] = "run"
    update_environment()
  

# Generated at 2022-06-24 07:51:37.253649
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench, set_simple_mode
    from thonny.common import InlineCommand
    import os

    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:51:45.405003
# Unit test for function toggle_variable
def test_toggle_variable():
    #Tests pgzero_mode is on
    toggle_variable()
    assert _OPTION_NAME == get_workbench().get_variable(_OPTION_NAME)
    #Tests pgzero_mode is off
    toggle_variable()
    assert _OPTION_NAME == get_workbench().get_variable(_OPTION_NAME)


# Generated at 2022-06-24 07:51:47.054789
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    get_workbench().get_plugin("Unittest").run_test(test_load_plugin)

# Generated at 2022-06-24 07:51:51.807587
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    assert toggle_variable() == None
    assert wb.get_option(_OPTION_NAME) == True
    assert toggle_variable() == None
    assert wb.get_option(_OPTION_NAME) == False


# Generated at 2022-06-24 07:51:58.401933
# Unit test for function update_environment
def test_update_environment():

    if os.environ.get("PGZERO_MODE") is None:
        os.environ["PGZERO_MODE"] = "False"
    else:
        pgzero_mode = os.environ["PGZERO_MODE"]

    update_environment()
    if os.environ.get("PGZERO_MODE") is None:
        os.environ["PGZERO_MODE"] = "False"
    else:
        pgzero_mode = os.environ["PGZERO_MODE"]

# Generated at 2022-06-24 07:52:09.699346
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock
    from unittest.mock import patch
    from thonny import get_workbench
    from thonny.workbench import Workbench
    from thonny.plugins.pgzero_mode import get_shell
    from thonny.plugins.pgzero_mode import update_environment
    from thonny.plugins.pgzero_mode import load_plugin
    from thonny.languages import tr
    from pgzero.game import Game
    from pgzero.actor import Actor
    import os

    def mock_get_shell():
        return Mock()

    mock_get_workbench = Mock()
    mock_set_default = Mock()
    mock_ressource_path = Mock()
    mock_add_command = Mock()
    mock_get_option = Mock()

    workbench_

# Generated at 2022-06-24 07:52:10.711878
# Unit test for function toggle_variable
def test_toggle_variable():
    assert get_workbench().in_simple_mode()

# Generated at 2022-06-24 07:52:17.742198
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"

    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().in_simple_mode = lambda: True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().in_simple_mode = lambda: False
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:52:19.973842
# Unit test for function update_environment
def test_update_environment():

    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == 'True'

# Generated at 2022-06-24 07:52:25.246840
# Unit test for function toggle_variable
def test_toggle_variable():
    global _OPTION_NAME
    _OPTION_NAME = "_test_run.pgzero_mode"
    toggle_variable()
    assert (
        get_workbench().get_variable(_OPTION_NAME).get() == False
    ), "toggle_variable() should toggle the variable"
    toggle_variable()
    assert (
        get_workbench().get_variable(_OPTION_NAME).get() == True
    ), "toggle_variable() should toggle the variable"
    _OPTION_NAME = "run.pgzero_mode"
    toggle_variable()

# Generated at 2022-06-24 07:52:28.897876
# Unit test for function toggle_variable
def test_toggle_variable():
    """Test for toggle_variable"""
    for i in range(2):
        before = get_workbench().get_option(_OPTION_NAME)
        toggle_variable()
        assert get_workbench().get_option(_OPTION_NAME) != before

# Generated at 2022-06-24 07:52:35.743735
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_simple_mode(True)
    update_environment()
    assert "PGZERO_MODE" not in os.environ

    get_workbench().set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().get_option(_OPTION_NAME).set(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:52:44.905523
# Unit test for function update_environment
def test_update_environment():
    # Test simple mode.
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    # Test simple mode, with option set.
    get_workbench().set_simple_mode(True)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    # Test not simple mode.
    get_workbench().set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    # Test not simple mode, with option set.
    get_workbench().set_simple_mode(False)
    get_wor

# Generated at 2022-06-24 07:52:54.014383
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench
    from thonny.plugins.run_pgzero import update_environment
    get_workbench().in_simple_mode = False
    get_workbench().get_option = lambda x: False
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().get_option = lambda x: True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().in_simple_mode = True
    get_workbench().get_option = lambda x: False
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:53:01.888994
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock
    from thonny import get_workbench

    wb = get_workbench()
    wb._set_variable = Mock()
    wb._add_command = Mock()
    wb._set_simple_mode = Mock(return_value=False)

    load_plugin()
    assert wb._set_variable.call_args == (('run.pgzero_mode', False), {'persistent': True})
    assert wb._add_command.call_args == (('toggle_pgzero_mode', 'run', 'Pygame Zero mode', toggle_variable),
                                         {'flag_name': 'run.pgzero_mode', 'group': 40})
    assert wb._set_simple_mode.call_count == 1
    assert os.environ["PGZERO_MODE"]

# Generated at 2022-06-24 07:53:05.548092
# Unit test for function toggle_variable
def test_toggle_variable():
    try:
        import pgzero
        pgzero_mode = bool(get_workbench().get_option(_OPTION_NAME))
        toggle_variable()
        assert bool(get_workbench().get_option(_OPTION_NAME)) != pgzero_mode
        update_environment()
    except:
        pass

# Generated at 2022-06-24 07:53:10.521676
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.add_command("toggle_pgzero_mode",
                   "run",
                   tr("Pygame Zero mode"),
                   toggle_variable,
                   flag_name=_OPTION_NAME,
                   group=40)
    assert get_workbench().in_simple_mode() == False

# Generated at 2022-06-24 07:53:14.274115
# Unit test for function load_plugin
def test_load_plugin():
    workbench = get_workbench()
    assert not workbench.get_variable(_OPTION_NAME).get()
    assert not "PGZERO_MODE" in os.environ
    # Test command
 

# Generated at 2022-06-24 07:53:17.315390
# Unit test for function update_environment
def test_update_environment():
    os.environ.pop("PGZERO_MODE", None)
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:53:20.453315
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == False


# Generated at 2022-06-24 07:53:24.079104
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny import get_workbench
    from thonny.languages import tr
    from thonny.plugins.run.pgzero_mode import toggle_variable, _OPTION_NAME
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == True
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == False


# Generated at 2022-06-24 07:53:30.254459
# Unit test for function update_environment
def test_update_environment():
    env_orig = dict(os.environ)
    try:
        get_workbench().set_default(_OPTION_NAME, False)
        update_environment()
        assert os.environ["PGZERO_MODE"] == "False"
        get_workbench().set_default(_OPTION_NAME, True)
        update_environment()
        assert os.environ["PGZERO_MODE"] == "True"
    finally:
        os.environ.clear()
        os.environ.update(env_orig)

# Generated at 2022-06-24 07:53:36.709839
# Unit test for function update_environment
def test_update_environment():
    from thonny.globals import get_workbench
    get_workbench().set_default(_OPTION_NAME, False, "user")
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_option(_OPTION_NAME, True, "user")
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_option(_OPTION_NAME, False, "user")
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"]

# Generated at 2022-06-24 07:53:40.800304
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:53:44.573598
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()
    assert os.environ["PGZERO_MODE"] is "True"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] is "False"

# Generated at 2022-06-24 07:53:53.941772
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import patch, Mock
    from thonny.globals import get_runner
    from thonny.plugins.run.run import run_module
    from thonny import get_workbench
  
    # Unit test for function load_plugin
    
    # Test for file path validation
    with patch('builtins.open', side_effect=FileNotFoundError()):
        assert run_module() == False

    # Test for file path validation
    from io import StringIO
    with patch('sys.stdout', new=StringIO()) as fake_out:
        with patch('builtins.open', side_effect=[Mock(), Mock()]):
            get_workbench().set_option(_OPTION_NAME, False)
            run_module()

# Generated at 2022-06-24 07:54:00.682891
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import Mock
    from thonny.workbench import Workbench

    # pylint: disable=unused-variable

    wb = Mock(Workbench)
    wb.get_option.return_value = "True"
    wb.in_simple_mode = Mock(return_value = False)
    wb.in_advanced_mode = Mock(return_value = True)

    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    wb.get_option.return_value = "False"

    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    wb.in_simple_mode.return_value = True
    wb.in_advanced_mode.return_value = False

   

# Generated at 2022-06-24 07:54:05.520352
# Unit test for function toggle_variable
def test_toggle_variable():
    old_variable = get_workbench().get_variable(_OPTION_NAME).get()
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() != old_variable
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == old_variable

# Generated at 2022-06-24 07:54:10.148082
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import workbench

    workbench.update_view = lambda: None
    workbench.reset_workbench()
    load_plugin()

    assert get_workbench().get_option(_OPTION_NAME) is False


if __name__ == "__main__":
    test_load_plugin()

# Generated at 2022-06-24 07:54:16.329112
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()

# Generated at 2022-06-24 07:54:23.056440
# Unit test for function load_plugin
def test_load_plugin():
    from tests.utils import is_in_menu
    from thonny.workbench import Workbench

    workbench = Workbench()
    workbench.create()
    load_plugin()

    if is_in_menu(workbench, workbench.get_variable(_OPTION_NAME).get_label()):
        label = "Disable " + workbench.get_variable(_OPTION_NAME).get_label()
    else:
        label = workbench.get_variable(_OPTION_NAME).get_label()

    assert (
        is_in_menu(workbench, label)
    ), "Option '{}' should be there.".format(_OPTION_NAME)

# Generated at 2022-06-24 07:54:29.848228
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    assert get_workbench().get_option(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True

# Generated at 2022-06-24 07:54:31.993584
# Unit test for function load_plugin
def test_load_plugin():
    wb = Tk()
    wb.createcommand("tk::mac::ShowPreferences", lambda: None)
    load_plugin()
    wb.destroy()



# Generated at 2022-06-24 07:54:35.847184
# Unit test for function toggle_variable
def test_toggle_variable():
    assert get_workbench().get_option(_OPTION_NAME) is False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) is True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) is False

# Generated at 2022-06-24 07:54:42.895420
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.globals import get_workbench
    from thonny.ui_utils import ask_for_bool
    get_workbench().set_variable("run.pgzero_mode", True)
    toggle_variable()
    if ask_for_bool("Is Pygame Zero mode now off?"):
        print("Test passed")
    else:
        print("Test failed")
    
    get_workbench().set_variable("run.pgzero_mode", False)
    toggle_variable()
    if ask_for_bool("Is Pygame Zero mode now on?"):
        print("Test passed")
    else:
        print("Test failed")

# Generated at 2022-06-24 07:54:44.923562
# Unit test for function toggle_variable
def test_toggle_variable():
   toggle_variable()
   assert get_workbench().get_variable(_OPTION_NAME).get() == True
   toggle_variable()
   assert get_workbench().get_variable(_OPTION_NAME).get() == False

# Generated at 2022-06-24 07:54:52.556935
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.globals import get_workbench
    from unittest import mock
    from thonny.plugins.pgzero_mode import toggle_variable

    test_workbench = get_workbench()
    test_var = test_workbench.get_variable(_OPTION_NAME)
    var_value = test_var.get()
    with mock.patch("thonny.plugins.pgzero_mode.get_workbench") as m_get_workbench:
        m_get_workbench.return_value = test_workbench
        toggle_variable()
        assert test_var.get() != var_value
        toggle_variable()
        assert test_var.get() == var_value

# Generated at 2022-06-24 07:55:00.967542
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:55:09.228993
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    load_plugin()
    assert _OPTION_NAME in wb._variable_names
    assert wb._variable_names.index(_OPTION_NAME) < wb._variable_names.index("run.command")
    assert wb.get_option(_OPTION_NAME) == False
    assert "PGZERO_MODE" in os.environ
    assert os.environ["PGZERO_MODE"] == "False"
    wb.set_option(_OPTION_NAME, True)
    assert wb.get_option(_OPTION_NAME) == True
    assert "PGZERO_MODE" in os.environ
    assert os.environ["PGZERO_MODE"] == "True"
    wb.set

# Generated at 2022-06-24 07:55:16.547630
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import patch

    with patch.dict(os.environ, {}, clear=True):
        obj = get_workbench()
        obj.set_simple_mode(True)
        get_workbench().set_option(_OPTION_NAME, False)
        update_environment()
        assert os.environ["PGZERO_MODE"] == "auto"

    with patch.dict(os.environ, {}, clear=True):
        obj = get_workbench()
        obj.set_simple_mode(True)
        get_workbench().set_option(_OPTION_NAME, True)
        update_environment()
        assert os.environ["PGZERO_MODE"] == "auto"

    with patch.dict(os.environ, {}, clear=True):
        obj = get_workbench()

# Generated at 2022-06-24 07:55:25.707342
# Unit test for function load_plugin
def test_load_plugin():
    from unittest import mock

    from thonny.workbench import Workbench
    from thonny.languages import tr
    from thonny.running import get_runner
    from thonny.config import get_config_dir

    with mock.patch.object(Workbench, "set_default") as set_default_mock:
        with mock.patch.object(Workbench, "add_command") as add_command_mock:
            with mock.patch.object(get_config_dir, "get_cache_dir"):
                from thonny.plugins.pgzero import load_plugin

                load_plugin()
    set_default_mock.assert_called_with("run.pgzero_mode", False)

# Generated at 2022-06-24 07:55:27.083160
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert get_workbench().get_option("run.pgzero_mode") == False

# Generated at 2022-06-24 07:55:32.148047
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import MagicMock
    from thonny.workbench import Workbench

    wb = MagicMock(spec=Workbench)
    wb.get_variable.return_value = True
    wb.set_option.return_value = True
    load_plugin()
    assert os.environ.get("PGZERO_MODE") == None
    os.environ["PGZERO_MODE"] = ""

# Generated at 2022-06-24 07:55:38.095936
# Unit test for function toggle_variable
def test_toggle_variable():

    # When pgzero_mode is False, toggle_variable sets it to True
    get_workbench().set_option(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) is True
    assert os.environ["PGZERO_MODE"] == "1"

    # When pgzero_mode is True, toggle_variable sets it to False
    get_workbench().set_option(_OPTION_NAME, True)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) is False
    assert os.environ["PGZERO_MODE"] == "0"



# Generated at 2022-06-24 07:55:39.919419
# Unit test for function toggle_variable
def test_toggle_variable():
    state = get_workbench().get_option(_OPTION_NAME)
    toggle_variable()
    assert state != get_workbench().get_option(_OPTION_NAME)

# Generated at 2022-06-24 07:55:44.562371
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    get_workbench().set_option("run.pgzero_mode", True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_simple_mode()
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:55:55.041137
# Unit test for function load_plugin
def test_load_plugin():
    os.environ["PGZERO_MODE"] = "auto"
    get_workbench().set_default(_OPTION_NAME, False)
    previous_default = get_workbench().get_default(_OPTION_NAME)
    assert get_workbench().get_variable(_OPTION_NAME).get() == previous_default
    assert os.environ["PGZERO_MODE"] == previous_default
    get_workbench().set_default(_OPTION_NAME, True)
    previous_default = get_workbench().get_default(_OPTION_NAME)
    assert get_workbench().get_variable(_OPTION_NAME).get() == previous_default
    assert os.environ["PGZERO_MODE"] == previous_default

    get_workbench().in_simple_mode = lambda: True
    get_workbench().set_

# Generated at 2022-06-24 07:56:02.497201
# Unit test for function update_environment
def test_update_environment():
    del os.environ["PGZERO_MODE"]

    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"

    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"

# Generated at 2022-06-24 07:56:07.256724
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_simple_mode(True)
    os.environ["PGZERO_MODE"] = "true"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "false"
    get_workbench().set_simple_mode(False)
    toggle_variable()

# Generated at 2022-06-24 07:56:14.735538
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench
    from thonny.languages import tr
    _OPTION_NAME = "test.test_pgzero_mode"
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    os.environ["PGZERO_MODE"] = "auto"

# Generated at 2022-06-24 07:56:21.994484
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.in_simple_mode = lambda: True
    os.environ = {}
    load_plugin()
    assert wb.get_default(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "auto"
    assert len(wb.get_commands()) == 1
    assert ("toggle_pgzero_mode", "run", "Pygame Zero mode", toggle_variable) in wb.get_commands()

# Generated at 2022-06-24 07:56:26.341543
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.test_utils import run_test_subprocess
    from thonny.plugins.pgzero_mode import toggle_variable

    run_test_subprocess(toggle_variable, expected_output_regex=r"PGZERO_MODE: auto")
    assert os.environ.pop("PGZERO_MODE") == "auto"

# Generated at 2022-06-24 07:56:31.559396
# Unit test for function update_environment
def test_update_environment():
    workbench = get_workbench()
    workbench.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    
    workbench.set_simple_mode(False)
    workbench.set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"
    
    workbench.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"

# Generated at 2022-06-24 07:56:36.302078
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    assert wb.get_variable(_OPTION_NAME).get() == False
    toggle_variable()
    assert wb.get_variable(_OPTION_NAME).get() == True
    toggle_variable()
    assert wb.get_variable(_OPTION_NAME).get() == False

# Generated at 2022-06-24 07:56:41.271159
# Unit test for function update_environment
def test_update_environment():

    os.environ["PGZERO_MODE"] = "auto"
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"



# Generated at 2022-06-24 07:56:48.300482
# Unit test for function update_environment
def test_update_environment():
    from thonny.globals import get_workbench
    from unittest.mock import patch

    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:56:52.058637
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    wb.get_variable(_OPTION_NAME).set(False)
    toggle_variable()
    assert wb.get_variable(_OPTION_NAME).get()
    toggle_variable()
    assert not wb.get_variable(_OPTION_NAME).get()

# Generated at 2022-06-24 07:56:54.933887
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().reset()
    assert not get_workbench().get_option(_OPTION_NAME)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME)
    toggle_variable()
    assert not get_workbench().get_option(_OPTION_NAME)

# Generated at 2022-06-24 07:56:59.331519
# Unit test for function update_environment
def test_update_environment():
    from unittest import mock
    from thonny.globals import get_workbench

    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"



# Generated at 2022-06-24 07:57:03.219342
# Unit test for function toggle_variable
def test_toggle_variable():
    # GIVEN - default option
    var = get_workbench().get_variable(_OPTION_NAME)

    # WHEN - toggling
    toggle_variable()

    # THEN - new value
    assert var.get() == True

    # WHEN - toggling again
    toggle_variable()

    # THEN - back to default value
    assert var.get() == False

# Generated at 2022-06-24 07:57:07.032762
# Unit test for function toggle_variable
def test_toggle_variable():
    wb=get_workbench()
    wb.set_simple_mode(True)
    toggle_variable()
    assert os.environ["PGZERO_MODE"]=="auto"
    toggle_variable()
    assert os.environ["PGZERO_MODE"]=="auto"

# Generated at 2022-06-24 07:57:12.497613
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, True)
    assert(bool(wb.get_option(_OPTION_NAME)))

    toggle_variable()
    assert(not bool(wb.get_option(_OPTION_NAME)))

    toggle_variable()
    assert(bool(wb.get_option(_OPTION_NAME)))

# Generated at 2022-06-24 07:57:24.044700
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny import get_workbench
    from thonny.ui_utils import confirm

    def test_toggle_variable_helper_commands(commands):
        opening = True

        for command in commands:
            if command[0] == "confirm":
                confirm(command[1], command[2])
            elif command[0] == "toggle_pgzero_mode":
                if opening and confirm(command[1], command[2]):
                    toggle_variable()
                    opening = False
            else:
                raise AssertionError("Invalid command")

    def test_toggle_variable_helper_options(commands):
        assert(get_workbench().get_option(_OPTION_NAME)) == commands[0]


# Generated at 2022-06-24 07:57:28.466079
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_option(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-24 07:57:29.414503
# Unit test for function load_plugin
def test_load_plugin():
    assert load_plugin() is None



# Generated at 2022-06-24 07:57:38.198392
# Unit test for function load_plugin
def test_load_plugin():
    class MockWorkbench:
        def set_default(self, name, value):
            pass

        def add_command(
            self, command_name, category, label, handler, flag_name=None, group=None
        ):
            pass

    workbench = MockWorkbench()
    MockWorkbench.get_variable = lambda self, name: bool(int(os.environ.get("PGZERO_MODE", 0)))
    MockWorkbench.in_simple_mode = lambda self: True
    load_plugin()
    assert not get_workbench().get_variable(_OPTION_NAME)
    assert os.environ.get("PGZERO_MODE", 0) == "auto"

# Generated at 2022-06-24 07:57:42.308497
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, True)
    wb.in_simple_mode = lambda: False
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:57:49.563754
# Unit test for function update_environment
def test_update_environment():
    os.environ.pop("PGZERO_MODE", None)
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:57:59.146681
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    wb.invoke_command("toggle_pgzero_mode")
    assert wb.get_variable(_OPTION_NAME)
    wb.invoke_command("toggle_pgzero_mode")
    assert not wb.get_variable(_OPTION_NAME)

# Generated at 2022-06-24 07:58:03.370205
# Unit test for function update_environment
def test_update_environment():
    try:
        del os.environ["PGZERO_MODE"]
        get_workbench().set_simple_mode(False)
        get_workbench().set_option(_OPTION_NAME, False)
        update_environment()
        assert os.environ["PGZERO_MODE"] == "0"
    finally:
        del os.environ["PGZERO_MODE"]

# Generated at 2022-06-24 07:58:03.833246
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()

# Generated at 2022-06-24 07:58:10.594419
# Unit test for function update_environment
def test_update_environment():
    os.environ.pop("PGZERO_MODE", None)

    os.environ["PGZERO_MODE"] = ""
    update_environment()
    assert os.environ["PGZERO_MODE"] == str(get_workbench().get_option(_OPTION_NAME))

    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == str(get_workbench().get_option(_OPTION_NAME))

# Generated at 2022-06-24 07:58:13.905624
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default(_OPTION_NAME, True)
    env = dict(os.environ)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    os.environ = env

# Generated at 2022-06-24 07:58:17.662424
# Unit test for function toggle_variable
def test_toggle_variable():
    load_plugin()
    from thonny.globals import get_workbench
    wb = get_workbench()
    var = wb.get_variable(_OPTION_NAME)
    assert var.get() == False
    toggle_variable()
    assert var.get() == True
    toggle_variable()
    assert var.get() == False

# Generated at 2022-06-24 07:58:23.981666
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:58:33.260450
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny import get_workbench
    from thonny.workbench import Workbench
    from thonny import Tester

    workbench = Workbench(Tester())
    workbench.set_default(_OPTION_NAME, True)
    assert get_workbench().in_simple_mode() is False
    get_workbench().update_view()
    # click variable button
    get_workbench().event_generate("<<FlipVariable>>", when="tail")
    assert get_workbench().in_simple_mode() is True
    # click variable button again
    get_workbench().event_generate("<<FlipVariable>>", when="tail")
    assert get_workbench().in_simple_mode() is False

# Generated at 2022-06-24 07:58:41.772673
# Unit test for function load_plugin
def test_load_plugin():
    if "PGZERO_MODE" in os.environ:
        del os.environ["PGZERO_MODE"]
        
    from thonny.common import get_workbench
    from thonny.workbench import Workbench
    from thonny import plugins
    from unittest.mock import Mock, patch
    from thonny.options_page import GeneralOptionsPage
    get_workbench.get_workbench = Mock(return_value=Workbench())
    get_workbench().in_simple_mode = Mock(return_value=False)
    get_workbench().in_running_mode = Mock(return_value=False)
    get_workbench().is_command_bound_to_key = Mock(return_value=False)

# Generated at 2022-06-24 07:58:49.377083
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:58:55.288324
# Unit test for function update_environment
def test_update_environment():
    os.environ.pop("PGZERO_MODE", None)
    get_workbench().set_simple_mode(True)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    os.environ.pop("PGZERO_MODE", None)
    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:58:56.976380
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_option(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME)
    toggle_variable()
    assert not get_workbench().get_option(_OPTION_NAME)

# Generated at 2022-06-24 07:59:00.694410
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-24 07:59:04.047094
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, True)
    load_plugin()
    assert get_workbench().get_variable(_OPTION_NAME).get() == True
    assert os.environ["PGZERO_MODE"] == "True"



# Generated at 2022-06-24 07:59:09.153562
# Unit test for function toggle_variable
def test_toggle_variable():
    load_plugin()
    get_workbench().set_option(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True

    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False


# Generated at 2022-06-24 07:59:12.854761
# Unit test for function toggle_variable
def test_toggle_variable():
    var = get_workbench().get_variable(_OPTION_NAME)
    var.set(False)
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:59:19.627541
# Unit test for function load_plugin
def test_load_plugin():
    root = Tk()
    root.withdraw()
    wb = Workbench(root)
    wb.set_default(_OPTION_NAME, False)
    assert wb.get_option(_OPTION_NAME) == False
    load_plugin()
    assert _OPTION_NAME in wb.get_variable_names()
    assert os.environ["PGZERO_MODE"] == "False"
    os.environ["PGZERO_MODE"] = ""
    
    

# Generated at 2022-06-24 07:59:22.083549
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME) == False

# Generated at 2022-06-24 07:59:25.308160
# Unit test for function update_environment
def test_update_environment():
    assert 'PGZERO_MODE' not in os.environ
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ['PGZERO_MODE'] == 'True'
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ['PGZERO_MODE'] == 'False'
    del os.environ['PGZERO_MODE']

# Generated at 2022-06-24 07:59:29.941627
# Unit test for function update_environment
def test_update_environment():
    assert os.environ["PGZERO_MODE"] == 'False'
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == 'True'
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == 'False'

# Generated at 2022-06-24 07:59:36.959067
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from unittest.mock import Mock

    workbench = Workbench("Mock backend")
    workbench.get_variable = Mock(return_value=True)
    workbench.in_simple_mode = Mock(return_value=False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    workbench.in_simple_mode.return_value = True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:59:42.981737
# Unit test for function update_environment
def test_update_environment():
    from unittest import mock
    from thonny import get_workbench
    from thonny.languages import tr
    from thonny.globals import get_workbench
    from thonny.globals import get_runner
    from thonny.globals import get_shell
    from thonny.config import get_workbench_configuration

    mock_workbench = mock.MagicMock()
    mock_runner = mock.MagicMock()
    mock_shell = mock.MagicMock()


    # Check that this function works when Pygame Zero mode is on
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"

    # Check that this function works when Pygame Zero mode is off


# Generated at 2022-06-24 07:59:46.909573
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(
        _OPTION_NAME, True
    )  # so that the pre-conditions are not satisfied and the plugin will run
    load_plugin()
    get_workbench().get_option(_OPTION_NAME)  # check that it's there
    get_workbench().destroy()

# Generated at 2022-06-24 07:59:57.503681
# Unit test for function toggle_variable

# Generated at 2022-06-24 08:00:06.507920
# Unit test for function toggle_variable
def test_toggle_variable():
    assert int(os.environ["PGZERO_MODE"]) == 0
    toggle_variable()
    assert int(os.environ["PGZERO_MODE"]) == 1
    toggle_variable()
    assert int(os.environ["PGZERO_MODE"]) == 0
    # Check that it doesn't change environment if in simple mode
    get_workbench().set_simple_mode(True)
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_simple_mode(False)
    assert int(os.environ["PGZERO_MODE"]) == 0

# Generated at 2022-06-24 08:00:13.469891
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"

# Generated at 2022-06-24 08:00:17.945243
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench

    workbench = Workbench()
    load_plugin()
    cmd = workbench.get_command("toggle_pgzero_mode")
    assert cmd.label == "Pygame Zero mode"
    assert cmd.default_binding == None

# Generated at 2022-06-24 08:00:21.792358
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    wb.set_option(_OPTION_NAME, False)

    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == True

    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == False

# Generated at 2022-06-24 08:00:31.002392
# Unit test for function update_environment
def test_update_environment():
    # WHen workbench is in simple mode
    # os.environ["PGZERO_MODE"] should be 'auto'
    get_workbench().set_simple_mode()
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    # When workbench is not in simple mode
    # os.environ["PGZERO_MODE"] should be "False"
    get_workbench().set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 08:00:34.461271
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()

# Generated at 2022-06-24 08:00:39.200955
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, True)
    wb.in_simple_mode = False
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    wb.set_default(_OPTION_NAME, True)
    wb.in_simple_mode = True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"


if __name__ == "__main__":
    load_plugin()

# Generated at 2022-06-24 08:00:44.630122
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default("run.pgzero_mode", True)
    load_plugin()
    assert get_workbench().get_variable(_OPTION_NAME).get()
    
    get_workbench().set_default("run.pgzero_mode", False)
    load_plugin()
    assert not get_workbench().get_variable(_OPTION_NAME).get()


# Generated at 2022-06-24 08:00:45.185777
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()

# Generated at 2022-06-24 08:00:48.961471
# Unit test for function toggle_variable
def test_toggle_variable():
    assert get_workbench().get_option(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-24 08:00:52.374349
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = "false"
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "true"

# Generated at 2022-06-24 08:00:57.695266
# Unit test for function load_plugin
def test_load_plugin():
    workbench = get_workbench()
    plugin = Plugin()
    plugin.load()
    assert workbench.get_variable(_OPTION_NAME).get() == False
    assert "PGZERO_MODE" in os.environ
    assert os.environ["PGZERO_MODE"] == "False"
    workbench.get_variable(_OPTION_NAME).set(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 08:01:05.495602
# Unit test for function update_environment
def test_update_environment():
    # Test in simple mode
    from thonny.globals import get_workbench
    from unittest.mock import MagicMock
    import os

    wb = get_workbench()
    wb.in_simple_mode = MagicMock(return_value=True)
    update_environment()
    set_pgzero = os.environ["PGZERO_MODE"]
    assert set_pgzero == "auto"

    # Test out of simple mode
    wb = get_workbench()
    wb.in_simple_mode = MagicMock(return_value=False)
    wb.set_option(_OPTION_NAME, True)
    update_environment()
    set_pgzero = os.environ["PGZERO_MODE"]
    assert set_pgzero == "True"

# Generated at 2022-06-24 08:01:13.284071
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    get_workbench().in_simple_mode()
    update_environment()
    var = get_workbench().get_variable(_OPTION_NAME)
    var.set(True)
    update_environment()

# Generated at 2022-06-24 08:01:17.144070
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_simple_mode()
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_default(_OPTION_NAME, False)