

# Generated at 2022-06-24 07:51:20.319555
# Unit test for function update_environment
def test_update_environment():
    # clear up environ definition PGZERO_MODE, otherwise the test will fail.
    os.environ.pop("PGZERO_MODE", None)
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:51:29.796159
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()

    assert get_workbench().get_option(_OPTION_NAME) == False
    assert "-pgzero" not in get_workbench().get_command("run").get_flags()
    assert "-nopgzero" not in get_workbench().get_command("run").get_flags()
    assert "-pgzero" not in get_workbench().get_command("step").get_flags()
    assert "-nopgzero" not in get_workbench().get_command("step").get_flags()

    get_workbench().set_default(_OPTION_NAME, True)
    load_plugin()

    assert get_workbench().get_option(_OPTION_NAME) == True
    assert "-pgzero" in get_workbench().get

# Generated at 2022-06-24 07:51:33.220917
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()

# Generated at 2022-06-24 07:51:34.099759
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert 0

# Generated at 2022-06-24 07:51:35.175118
# Unit test for function toggle_variable
def test_toggle_variable():
    pass
    

# Generated at 2022-06-24 07:51:40.998183
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, True)
    assert get_workbench().get_option(_OPTION_NAME) is True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) is False
    toggle_variable()
    get_workbench().set_default(_OPTION_NAME, "test")
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) is "test"

# Generated at 2022-06-24 07:51:45.506236
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    assert get_workbench().get_default(_OPTION_NAME) == False
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-24 07:51:50.007484
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, True)
    load_plugin()
    assert wb.get_option(_OPTION_NAME) == True
    assert wb.get_variable(_OPTION_NAME).get() == True
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == False
    assert wb.get_variable(_OPTION_NAME).get() == False

# Generated at 2022-06-24 07:51:51.768887
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()
    assert get_workbench().in_simple_mode()
    toggle_variable()
    assert not get_workbench().in_simple_mode()

# Generated at 2022-06-24 07:51:56.341683
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench
    from thonny.languages import tr
    import os

    try:
        old_PGZERO_MODE = os.environ["PGZERO_MODE"]
    except:
        old_PGZERO_MODE = "auto"

    old_simple_mode = get_workbench().in_simple_mode()

    # Change PGZERO to false
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    # Change PGZERO to true
    get_workbench().set_default(_OPTION_NAME, True)
    get_workbench().set_simple_mode(False)
    update_environment

# Generated at 2022-06-24 07:52:05.490598
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny import get_workbench

    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)

    toggle_variable()
    assert wb.get_variable(_OPTION_NAME).get() == True

    toggle_variable()
    assert wb.get_variable(_OPTION_NAME).get() == False


if __name__ == "__main__":
    load_plugin()
    get_workbench().invoke_command("toggle_pgzero_mode")
    get_workbench().invoke_command("toggle_pgzero_mode")

# Generated at 2022-06-24 07:52:06.872492
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()

# Generated at 2022-06-24 07:52:14.061782
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench()
    # variables are empty at the start
    assert get_workbench().get_variable(_OPTION_NAME) == False
    get_workbench().set_option(_OPTION_NAME, True)
    assert get_workbench().get_option(_OPTION_NAME) == True

    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME) == False
    assert get_workbench().get_option(_OPTION_NAME) == False

    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME) == True
    assert get_workbench().get_option(_OPTION_NAME) == True

# Generated at 2022-06-24 07:52:18.041413
# Unit test for function toggle_variable
def test_toggle_variable():
    # this will test the environent update (even if the option is not currently shown)
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"

    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:52:25.769540
# Unit test for function load_plugin
def test_load_plugin():
    # test for _OPTION_NAME
    original_value = None
    if _OPTION_NAME in list(get_workbench().get_variable_names()):
        original_value = get_workbench().get_option(_OPTION_NAME)
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == False
    get_workbench().set_option(_OPTION_NAME, not get_workbench().get_option(_OPTION_NAME))
    assert get_workbench().get_option(_OPTION_NAME) == True
    if original_value is not None:
        get_workbench().set_option(_OPTION_NAME, original_value)
    # test for toggle_variable
    # test for update_environment
    original_value = None

# Generated at 2022-06-24 07:52:31.951550
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    toggle_variable()
    assert wb.get_variable(_OPTION_NAME).get() == True
    toggle_variable()
    assert wb.get_variable(_OPTION_NAME).get() == False
    assert os.environ["PGZERO_MODE"] == "False"
    

# Generated at 2022-06-24 07:52:36.142331
# Unit test for function update_environment
def test_update_environment():
    if get_workbench().in_simple_mode():
        assert os.environ["PGZERO_MODE"] == "auto"
    else:
        assert os.environ["PGZERO_MODE"] == str(get_workbench().get_option(_OPTION_NAME))


# Generated at 2022-06-24 07:52:39.829401
# Unit test for function toggle_variable
def test_toggle_variable():
    assert get_workbench().get_option(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-24 07:52:43.076455
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().debug_wait_for_main_window()
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"


# Generated at 2022-06-24 07:52:49.127860
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench
    from thonny.languages import tr
    from thonny.plugins.memory_checker import _OPTION_NAME
    
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    assert get_workbench().set_default(_OPTION_NAME, False)
    assert wb.get_variable(_OPTION_NAME) == False
    assert get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:52:55.443594
# Unit test for function update_environment
def test_update_environment():
    from unittest import mock

    get_workbench().set_option(_OPTION_NAME, True)
    with mock.patch.dict(os.environ, {}):
        update_environment()
        assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_option(_OPTION_NAME, False)
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:53:04.586759
# Unit test for function toggle_variable
def test_toggle_variable():
    # Test the main plugin funtion
    from unittest.mock import MagicMock
    from unittest.mock import patch
    from tkinter import Tk

    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    tk_root = Tk()
    tb = MagicMock()
    tb.in_simple_mode = False
    tb.get_option = MagicMock()
    tb.get_option.side_effect = False
    tb.set_option = MagicMock()
    tb.set_option.side_effect = True

# Generated at 2022-06-24 07:53:10.244287
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.in_simple_mode = Mock(return_value=False)
    load_plugin()
    assert os.environ.get("PGZERO_MODE") == "False"

    wb.in_simple_mode = Mock(return_value=True)
    load_plugin()
    assert os.environ.get("PGZERO_MODE") == "auto"

# Generated at 2022-06-24 07:53:13.072699
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-24 07:53:20.367953
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:53:26.082153
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, True)
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get()==False
    assert os.environ["PGZERO_MODE"] == "False"
    
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get()==True
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:53:33.195594
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = "not_boolean"
    get_workbench().set_default(_OPTION_NAME, True)
    get_workbench().in_simple_mode = lambda: True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().in_simple_mode = lambda: False
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:53:38.619354
# Unit test for function toggle_variable
def test_toggle_variable():
    from unittest.mock import Mock
    from pytest import approx
    from thonny.globals import get_workbench
    wb = get_workbench()
    wb.get_option = Mock(_OPTION_NAME=None)
    toggle_variable()
    assert _OPTION_NAME.get() == approx(True)


# Generated at 2022-06-24 07:53:39.740522
# Unit test for function load_plugin
def test_load_plugin():
    # TODO
    pass

# Generated at 2022-06-24 07:53:50.566883
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import patch
    from thonny.workbench import Workbench

    get_workbench().set_variable(_OPTION_NAME, True)
    with patch.object(os, "environ") as mocked_env:
        update_environment()
        mocked_env.__setitem__.assert_called_once_with("PGZERO_MODE", "True")

    get_workbench().set_variable(_OPTION_NAME, False)
    with patch.object(os, "environ") as mocked_env:
        get_workbench().get_variable(_OPTION_NAME).set(not get_workbench().get_variable(_OPTION_NAME).get())
        update_environment()
        mocked_env.__setitem__.assert_called_once_with("PGZERO_MODE", "False")

# Generated at 2022-06-24 07:53:57.870533
# Unit test for function toggle_variable
def test_toggle_variable():
    workbench = get_workbench()
    workbench.set_simple_mode(False)
    var = workbench.get_variable(_OPTION_NAME)
    var.set(False)
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert var.get() == True
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert var.get() == False
    assert os.environ["PGZERO_MODE"] == "False"

    workbench.set_simple_mode(True)
    assert workbench.in_simple_mode() == True
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:54:05.165294
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench

    wb = Workbench(load_plugins_at_startup=False)
    try:
        wb.create()
        wb.set_default(_OPTION_NAME, False)
        wb.add_command(
            "toggle_pgzero_mode",
            "run",
            tr("Pygame Zero mode"),
            toggle_variable,
            flag_name=_OPTION_NAME,
            group=40,
        )
        update_environment()
    finally:
        wb.destroy()

# Generated at 2022-06-24 07:54:07.325998
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()

# Generated at 2022-06-24 07:54:17.488528
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = "auto"

    from thonny import get_workbench
    from unittest.mock import MagicMock

    wb = get_workbench()
    wb.in_simple_mode = MagicMock(return_value=True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    wb.in_simple_mode = MagicMock(return_value=False)
    wb.get_option = MagicMock(return_value=True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"

    wb.get_option = MagicMock(return_value=False)
    update_environment()

# Generated at 2022-06-24 07:54:23.689904
# Unit test for function load_plugin
def test_load_plugin():
    global_workbench = get_workbench()
    global_workbench._set_default(_OPTION_NAME, True)
    assert not global_workbench.simple_mode
    load_plugin()

    # Check the default value
    assert getattr(global_workbench.get_option(_OPTION_NAME), "get")() == False

    # Check the update environment functionality
    global_workbench.in_simple_mode._set(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    global_workbench.in_simple_mode._set(False)
    update_environment()
    assert "PGZERO_MODE" in os.environ

# Generated at 2022-06-24 07:54:28.641449
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = str(get_workbench().get_option(_OPTION_NAME))
    update_environment()
    # Assert that the option is not changed
    assert os.environ["PGZERO_MODE"] == str(get_workbench().get_option(_OPTION_NAME))

# Generated at 2022-06-24 07:54:35.812894
# Unit test for function toggle_variable
def test_toggle_variable():
    from unittest.mock import MagicMock
    from unittest.mock import patch

    mock_workbench = MagicMock()
    mock_variable = MagicMock()
    mock_variable.get = MagicMock(return_value=False)
    mock_variable.set = MagicMock(return_value=None)
    mock_workbench.get_variable = MagicMock(return_value=mock_variable)
    mock_workbench.in_simple_mode = MagicMock(return_value=True)
    mock_workbench.set_default = MagicMock(return_value=None)
    mock_workbench.add_command = MagicMock(return_value=None)


# Generated at 2022-06-24 07:54:36.363200
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()

# Generated at 2022-06-24 07:54:44.654073
# Unit test for function update_environment
def test_update_environment():
    from thonny.misc_utils import running_on_windows
    workbench = get_workbench()
    workbench.set_simple_mode()
    if running_on_windows():
        assert os.environ.get("PGZERO_MODE") is None
    else:
        assert os.environ.get("PGZERO_MODE") == "auto"

    workbench.set_simple_mode(False)
    workbench.get_option(_OPTION_NAME).set(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    workbench.get_option(_OPTION_NAME).set(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    # Cleanup

# Generated at 2022-06-24 07:54:51.001212
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    assert str(get_workbench().get_option(_OPTION_NAME)) == "False"
    assert os.environ.get("PGZERO_MODE", None) == "False"
    toggle_variable()
    assert str(get_workbench().get_option(_OPTION_NAME)) == "True"
    assert os.environ.get("PGZERO_MODE", None) == "True"

# Generated at 2022-06-24 07:55:02.142885
# Unit test for function update_environment
def test_update_environment():
    from test.test_runner import MockWorkbench
    from unittest.mock import patch

    wb = MockWorkbench()
    wb.set_option(_OPTION_NAME, True)
    
    with patch.dict(os.environ, {}, clear=True):
        update_environment()
        assert os.environ["PGZERO_MODE"] == "True"

    # If a mode is already present in the environment then the
    # update should not be done
    with patch.dict(os.environ, {}, clear=True):
        os.environ["PGZERO_MODE"] = "False"
        update_environment()
        assert os.environ["PGZERO_MODE"] == "False"
        
    # If we are in simple mode then PGZERO_MODE should be 'auto'

# Generated at 2022-06-24 07:55:03.404699
# Unit test for function toggle_variable
def test_toggle_variable():
    assert toggle_variable() == None

# Generated at 2022-06-24 07:55:10.423635
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny import get_shell
    from thonny.shell import Shell

    get_workbench().set_default(_OPTION_NAME, False)
    assert not get_workbench().get_variable(_OPTION_NAME).get()

    toggle_variable()

    assert get_workbench().get_variable(_OPTION_NAME).get()
    assert os.environ["PGZERO_MODE"] == "True"

    toggle_variable()
    assert not get_workbench().get_variable(_OPTION_NAME).get()
    assert os.environ["PGZERO_MODE"] == "False"

    # Testing if pygamezero mode is enabled when in Simple mode
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().set_simple_mode()

# Generated at 2022-06-24 07:55:17.364802
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_option(_OPTION_NAME, False)
    assert get_workbench().get_option(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True

# Generated at 2022-06-24 07:55:20.408500
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"]="0"
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"
    os.environ["PGZERO_MODE"]="1"
    update_environment()

# Generated at 2022-06-24 07:55:28.633317
# Unit test for function update_environment
def test_update_environment():
    from unittest import mock
    from thonny.common import InlineCommand

    os.environ.pop("PGZERO_MODE", None)
    # Initial state
    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, False)

    # entering simple mode
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ.get("PGZERO_MODE") == "auto"

    # leaving simple mode
    get_workbench().set_simple_mode(False)
    update_environment()
    assert os.environ.get("PGZERO_MODE") == "auto"

    # entering simple mode again
    get_workbench().set_simple_mode(True)
    update_environment()

# Generated at 2022-06-24 07:55:36.388575
# Unit test for function update_environment
def test_update_environment():
    plugin = get_workbench().get_plugin("thonny.plugins.pgzero_mode")
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_simple_mode()
    plugin.update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_normal_mode()
    get_workbench().get_option(_OPTION_NAME).set(True)
    plugin.update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_simple_mode()
    plugin.update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:55:37.225680
# Unit test for function load_plugin
def test_load_plugin():
    # load_plugin is called by the workbench when loading the plugin
    pass

# Generated at 2022-06-24 07:55:42.642638
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.register_editor("py", wb.CodeViewText)
    wb.connect("show-simple-code-editor", lambda evt: evt.widget.set_text("# %s = TRUE" % _OPTION_NAME))

    assert wb.get_option("run.pgzero_mode") == False

    toggle_variable()
    assert wb.get_option("run.pgzero_mode") == True

    toggle_variable()
    assert wb.get_option("run.pgzero_mode") == False

# Generated at 2022-06-24 07:55:53.142767
# Unit test for function update_environment
def test_update_environment():
    from thonny.misc_utils import running_on_ci_server
    from thonny.misc_utils import running_on_windows
    import sys
    from unittest import mock
    from thonny import get_runner
    from test.test_runner import MockTextTag

    if running_on_ci_server() or running_on_windows():
        # update_environment only works on Mac and Linux
        return

    def get_pgzero_version():
        return sys.version_info.minor <= 8

    # Test PGZero mode
    with mock.patch("thonny.runner.get_pgzero_version", get_pgzero_version):
        get_workbench().set_option(_OPTION_NAME, False)
        update_environment()

# Generated at 2022-06-24 07:56:02.317827
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench, get_shell
    from thonny.shell import ToplevelCommand

    get_workbench().unload_plugin("pgzero")
    get_workbench().unload_plugin("builtins")
    get_workbench().unload_plugin("shell")

    get_workbench().load_plugin("pgzero")
    load_plugin()

    assert not get_workbench().get_variable(_OPTION_NAME).get()

    get_workbench().event_generate("ShellViewShown")
    shell = get_shell()

    shell.run_command("import pgzero")
    assert shell.globals["pgzero_mode"] == False

    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get()


# Generated at 2022-06-24 07:56:07.388699
# Unit test for function update_environment
def test_update_environment():
    c = get_workbench().get_option(_OPTION_NAME)
    c.set(True)
    assert os.environ["PGZERO_MODE"] == "True"
    c.set(False)
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().in_simple_mode.set(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:56:15.748984
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    
    get_workbench().set_simple_mode(True)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    
    get_workbench().set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:56:26.097537
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock
    from thonny.plugins.pgzero_mode import load_plugin
    from thonny.workbench import Workbench
    from thonny.misc_utils import Configuration
    from thonny import get_workbench

    MockTk = Mock()
    wb = Workbench(MockTk)
    wb.set_option = Mock()
    wb.add_command = Mock()
    wb.set_default = Mock()
    get_workbench = Mock(return_value=wb)
    os.environ = {}
    cfg = Configuration(load_defaults=False)
    get_workbench().get_option = cfg.get
    get_workbench().set_default = cfg.set
    load_plugin()

# Generated at 2022-06-24 07:56:32.760175
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ.get("PGZERO_MODE") == "auto"

    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    assert os.environ.get("PGZERO_MODE") == "True"

    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ.get("PGZERO_MODE") == "auto"
    
    get_workbench().in_simple_mode = lambda: True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    assert os

# Generated at 2022-06-24 07:56:40.625869
# Unit test for function update_environment
def test_update_environment():
    assert type(os.environ["PGZERO_MODE"]) is str
    assert len(os.environ["PGZERO_MODE"]) > 0
    os.environ["PGZERO_MODE"] = ""
    test_get_workbench = get_workbench()
    test_get_workbench.set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    test_get_workbench.set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:56:44.144410
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) is False
    assert os.getenv("PGZERO_MODE", "") == "False"



# Generated at 2022-06-24 07:56:49.489665
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:56:54.404247
# Unit test for function toggle_variable
def test_toggle_variable():
    orig_val=get_workbench().get_variable(_OPTION_NAME)
    toggle_variable()
    new_val=get_workbench().get_variable(_OPTION_NAME)
    assert orig_val != new_val
    toggle_variable()
    orig_val=get_workbench().get_variable(_OPTION_NAME)
    toggle_variable()
    new_val=get_workbench().get_variable(_OPTION_NAME)
    assert orig_val != new_val

# Generated at 2022-06-24 07:56:58.709757
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, True)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True

# Generated at 2022-06-24 07:57:02.704426
# Unit test for function toggle_variable
def test_toggle_variable():
    try:
        del os.environ["PGZERO_MODE"]
    except KeyError:
        pass
    get_workbench().set_option(_OPTION_NAME, False)
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:57:04.327580
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()

    load_plugin()
    assert wb.in_simple_mode() is True

# Generated at 2022-06-24 07:57:14.047720
# Unit test for function update_environment
def test_update_environment():
    """
    Check that update_environment sets the environment variable PGZERO_MODE to the value of
    the option named in _OPTION_NAME.
    """
    wb = get_workbench()
    wb.set_simple_mode(False)
    wb.set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    wb.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:57:25.231209
# Unit test for function load_plugin
def test_load_plugin():
    class Wb:
        def __init__(self):
            self.simple_mode = False
            self.vars = {}

        def in_simple_mode(self):
            return self.simple_mode

        def set_default(self, name, value):
            self.vars[name] = value

        def get_variable(self, key):
            return self.vars[key]

        def set_option(self, key, value):
            self.vars[key] = value

        def get_option(self, key):
            return self.vars[key]

        def add_command(self, cmd_id, cmd_name, label, handler, flag_name=None, group=0):
            if not flag_name:
                raise ValueError("Flag name is missing")

    wb = Wb()


# Generated at 2022-06-24 07:57:36.349900
# Unit test for function update_environment
def test_update_environment():
    # TODO: This test is not exact, as it uses get_workbench but the plugin
    # is not loaded.
    from thonny import get_workbench

    get_workbench().set_simple_mode(True)
    get_workbench().set_option(_OPTION_NAME, False)
    assert os.environ[_OPTION_NAME] == "False"

    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, False)
    assert os.environ[_OPTION_NAME] == "False"

    get_workbench().set_simple_mode(True)
    get_workbench().set_option(_OPTION_NAME, True)
    assert os.environ[_OPTION_NAME] == "False"

    get_workbench().set_simple

# Generated at 2022-06-24 07:57:39.368610
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = "123"
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:57:46.903943
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.globals import get_runner

    get_workbench().set_user_option(_OPTION_NAME, True)
    assert get_workbench().get_user_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_user_option(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_user_option(_OPTION_NAME) == True


# Generated at 2022-06-24 07:57:51.939496
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, True)
    load_plugin()
    assert wb.get_variable(_OPTION_NAME).get()
    assert get_active_flag()
    toggle_variable()
    assert not wb.get_variable(_OPTION_NAME).get()
    assert not get_active_flag()



# Generated at 2022-06-24 07:58:03.000673
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import MagicMock
    from unittest.mock import patch
    import os

    # Mocking the workbench
    workbench = MagicMock()
    workbench.in_simple_mode.return_value = False
    workbench.get_option.return_value = True
    variable = MagicMock()
    variable.get.return_value = True
    workbench.get_variable.return_value = variable
    get_workbench.return_value = workbench

    # Checking with pgzero mode enabled
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    # Checking with pgzero mode disabled
    workbench.get_option.return_value = False
    update_environment()

# Generated at 2022-06-24 07:58:11.485934
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.test import get_runner
    from thonny import get_workbench, get_shell, ui_utils
    from thonny.ui_utils import checkbox_handler
    from thonny.workbench import Workbench
    from thonny.globals import get_workbench
    import tkinter
    import unittest

    class Test(unittest.TestCase):
        TEST_EXAMPLE_NAME = "example.py"

# Generated at 2022-06-24 07:58:17.561560
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"

    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().in_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"


# Generated at 2022-06-24 07:58:23.417074
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)

    load_plugin()

    assert _OPTION_NAME in get_workbench().default_options
    assert not get_workbench().default_options[_OPTION_NAME]

    assert "toggle_pgzero_mode" in get_workbench().commands
    assert _OPTION_NAME in get_workbench().commands["toggle_pgzero_mode"].active_flag
    
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:58:28.544098
# Unit test for function toggle_variable
def test_toggle_variable():
    if not hasattr(toggle_variable, "toggled"):
        toggle_variable.toggled = False
    toggle_variable()
    assert toggle_variable.toggled is True
    toggle_variable()
    assert toggle_variable.toggled is False



# Generated at 2022-06-24 07:58:37.643410
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench
    from unittest.mock import Mock
    import sys
    import os

    # Test for successful import
    # Mock the Command class
    sys.modules["thonny.ui_utils.Command"] = Mock()
    # Load plugin
    load_plugin()
    # Check that the plugin has set a default
    assert get_workbench().get_option("run.pgzero_mode") == False
    # Check that the plugin has added a command
    assert get_workbench().commands["toggle_pgzero_mode"] != None
    # Run the command
    command = get_workbench().commands["toggle_pgzero_mode"]
    command.proceed()
    # Check that the command has changed the working environment
    assert os.environ["PGZERO_MODE"] == "True"



# Generated at 2022-06-24 07:58:48.286216
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    import os
    import sys

    workbench = Workbench()
    workbench.set_default(_OPTION_NAME, False)

    # Make sure that thonny and sys.path does not contain any pygame zero
    sys.path = list(filter(lambda x: not "pygame_zero" in x, sys.path))
    workbench.quit()

    # Check that environment variable has been set to "auto"
    if os.environ.get("PGZERO_MODE") != "auto":
        raise Exception("Environment variable PGZERO_MODE should be auto")

    # Check that pygame_zero and pgzero folders have been added to sys.path

# Generated at 2022-06-24 07:58:55.878444
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from unittest.mock import Mock

    workbench = Workbench()
    workbench.in_simple_mode = Mock()
    workbench._option_values = {}

    workbench.in_simple_mode.return_value = False
    workbench._option_values[_OPTION_NAME] = True
    update_environment()

    assert os.environ["PGZERO_MODE"] == "True"

    workbench.in_simple_mode.return_value = True
    update_environment()

    assert os.environ["PGZERO_MODE"] == "auto"

    workbench.in_simple_mode.return_value = False
    workbench._option_values[_OPTION_NAME] = False
    update_environment()


# Generated at 2022-06-24 07:59:05.374929
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny import get_workbench
    from thonny import get_shell

    # Function toggle_variable does not toggle the variable in simple mode.
    get_workbench().unset_variable(_OPTION_NAME)
    get_workbench().set_simple_mode(True)
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME) is None

    # Function toggle_variable toggles the variable.
    get_workbench().unset_variable(_OPTION_NAME)
    get_workbench().set_simple_mode(False)
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME) == True

    # Function toggle_variable toggles the variable.
    get_workbench().set_variable(_OPTION_NAME, True)
    toggle_variable()


# Generated at 2022-06-24 07:59:14.584933
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import MagicMock

    wb = get_workbench()
    wb.get_option = MagicMock(return_value=False)
    wb.set_default = MagicMock()
    wb.add_command = MagicMock()
    load_plugin()
    assert wb.set_default.call_args == (("run.pgzero_mode", False),)
    assert wb.add_command.call_args == (
        (
            "toggle_pgzero_mode",
            "run",
            "Pygame Zero mode",
            toggle_variable,
            {"flag_name": "run.pgzero_mode", "group": 40},
        ),
    )
    assert os.environ["PGZERO_MODE"] == "auto"



# Generated at 2022-06-24 07:59:23.412886
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.memory import MemoryFrame
    from thonny.plugins.run import RunPlugin
    from thonny import get_workbench
    from thonny.languages import tr

    test_workbench = get_workbench()
    test_workbench.set_default(_OPTION_NAME, False)
    test_workbench.add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )

    try:
        os.environ["PGZERO_MODE"]
    except KeyError:
        assert True
    else:
        assert False

    update_environment()

# Generated at 2022-06-24 07:59:26.208327
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) is False
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_simple_mode(True)
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_option(_OPTION_NAME, True)
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:59:32.799870
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    old_value = wb.get_option(_OPTION_NAME)
    with wb.config_update():
        toggle_variable()
        assert wb.get_option(_OPTION_NAME) != old_value
        toggle_variable()
        assert wb.get_option(_OPTION_NAME) == old_value

# Generated at 2022-06-24 07:59:38.087391
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    
    get_workbench().set_simple_mode(False)
    toggle_variable()
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    
    toggle_variable()
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:59:48.370571
# Unit test for function update_environment
def test_update_environment():
    # Test the case when simple_mode is on
    get_workbench().set_default(_OPTION_NAME, True)
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    # Test the case when simple_mode is off
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"

    # Test the case when simple_mode is off
    get_workbench().set_default(_OPTION_NAME, True)
    get_workbench().set_simple_mode(False)
    update_environment()

# Generated at 2022-06-24 07:59:57.109536
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().set_simple_mode(False)
    os.environ[_OPTION_NAME] = "True"
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 08:00:01.166301
# Unit test for function load_plugin
def test_load_plugin():
    _load_plugin()
    assert _OPTION_NAME in get_workbench().get_defaults()
    assert get_workbench().get_option(_OPTION_NAME, None) == False
    assert get_workbench().get_command("toggle_pgzero_mode") != None



# Generated at 2022-06-24 08:00:12.463561
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import MagicMock
    from thonny import get_workbench

    workbench = get_workbench()
    workbench.in_simple_mode = MagicMock(return_value=False)
    workbench.get_option = MagicMock(return_value=True)
    workbench.set_default = MagicMock()
    workbench.add_command = MagicMock()

    load_plugin()
    assert workbench.set_default.called
    assert workbench.add_command.called

    workbench.in_simple_mode = MagicMock(return_value=True)
    workbench.get_option = MagicMock(return_value=False)
    load_plugin()
    assert workbench.set_default.called
    assert workbench.add_command.called

# Generated at 2022-06-24 08:00:22.929278
# Unit test for function update_environment
def test_update_environment():
    # Test function when running in normal mode and option is False
    os.environ["PGZERO_MODE"] = ""
    test_get_workbench = GetWorkbench()
    test_get_workbench.set_option(_OPTION_NAME, False)
    test_get_workbench.set_option("view.simple_mode", False)
    test_update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    # Test function when running in normal mode and option is True
    os.environ["PGZERO_MODE"] = ""
    test_get_workbench.set_option(_OPTION_NAME, True)
    test_update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    # Test function when running in simple mode
    os.environ

# Generated at 2022-06-24 08:00:33.296371
# Unit test for function toggle_variable
def test_toggle_variable():
    # switch to pgzero mode
    var1 = get_workbench().get_variable(_OPTION_NAME)
    if var1.get()==True:
        get_workbench().set_option(_OPTION_NAME, 0)
    assert get_workbench().get_option(_OPTION_NAME) == 0
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == 1
    var2 = get_workbench().get_variable(_OPTION_NAME)
    assert var1.get()==False and var2.get()==True
    # switch back to default mode
    toggle_variable()
    var3 = get_workbench().get_variable(_OPTION_NAME)
    assert get_workbench().get_option(_OPTION_NAME) == 0

# Generated at 2022-06-24 08:00:39.202639
# Unit test for function update_environment
def test_update_environment():
    new_env = {
        "xxx": "yyy",
    }
    get_workbench().set_default(_OPTION_NAME, True)
    get_workbench().set_option(_OPTION_NAME, False)

    get_workbench().get_simple_mode_env = lambda: new_env
    get_workbench().in_simple_mode = lambda: True
    update_environment()
    assert os.environ == dict(new_env, PGZERO_MODE="auto")

    get_workbench().in_simple_mode = lambda: False
    update_environment()
    assert os.environ == dict(new_env, PGZERO_MODE="False")

# Generated at 2022-06-24 08:00:48.039806
# Unit test for function update_environment
def test_update_environment():
    del os.environ["PGZERO_MODE"]
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    os.environ["THONNY_SIMPLE_MODE"] = "True"
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    
    del os.environ["THONNY_SIMPLE_MODE"]

# Generated at 2022-06-24 08:00:51.696441
# Unit test for function update_environment
def test_update_environment():
    with get_workbench():
        toggle_variable()
        update_environment()
        assert os.environ["PGZERO_MODE"] == "True"
        toggle_variable()
        update_environment()
        assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 08:01:01.223687
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock
    from thonny.workbench import Workbench
    from thonny.memory import MemoryFrame
    from thonny.plugins.backend_options import BackendOption
    

    wb = Workbench()
    mf = MemoryFrame()
    opt = BackendOption("run.pgzero_mode", "False", "boolean")
    opt.set = Mock()
    opt.get = Mock()
    opt.get.return_value = False
    mf.add_variable(opt)
    wb.set_memory_frame(mf)

    wb.in_simple_mode = Mock()
    wb._simple_mode = True
    wb.get_command("toggle_pgzero_mode").invoke()
    assert opt.get.called == False
    assert os.en

# Generated at 2022-06-24 08:01:12.698291
# Unit test for function toggle_variable
def test_toggle_variable():
    from unittest.mock import patch
    from thonny import get_workbench
    from thonny.workbench import Workbench
    from thonny.plugins.environment import EnvironmentPlugin
    from thonny.languages import tr
    from collections import namedtuple

    wb = Workbench()
    wb.create()
    wb.register_plugin(EnvironmentPlugin)
    # Create instance of the plugin in question (otherwise the toggle_variable function can't be called)
    plugin = Main(wb)
    plugin.load()

    # Test that the value of variable is True
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == True

    # Test that the value of variable is False
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == False

   

# Generated at 2022-06-24 08:01:18.064348
# Unit test for function update_environment
def test_update_environment():
    import os
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    
    var = wb.get_variable(_OPTION_NAME)
    var.set(False)
    update_environment()
    assert os.environ['PGZERO_MODE'] == "False" 

    var.set(True)
    update_environment()
    assert os.environ['PGZERO_MODE'] == "True"