

# Generated at 2022-06-24 07:51:11.327378
# Unit test for function toggle_variable
def test_toggle_variable():
    var = get_workbench().get_variable(_OPTION_NAME)
    assert var.get() == False
    toggle_variable()
    assert var.get() == True
    toggle_variable()
    assert var.get() == False

# Generated at 2022-06-24 07:51:17.116534
# Unit test for function toggle_variable
def test_toggle_variable():
    # toggle Pygame Zero mode
    os.environ["PGZERO_MODE"] = "off"
    if os.environ["PGZERO_MODE"] == "auto":
        toggle_variable()
    assert os.environ["PGZERO_MODE"] == "on"
    # toggle Pygame Zero mode
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "off"

# Generated at 2022-06-24 07:51:23.744865
# Unit test for function update_environment
def test_update_environment():
    from unittest import mock
    from thonny import get_runner

    # Test 1:
    # Thonny simple mode is enabled --
    # assuming simple mode is always enabled in unit test environment.
    os.environ.pop("PGZERO_MODE", None)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    # Test 2:
    # Thonny simple mode is disabled,
    # and pgzero mode is set to True.
    get_workbench().set_option(_OPTION_NAME, True)
    os.environ.pop("PGZERO_MODE", None)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    # Test 3:
    # Thonny simple mode is disabled,
    # and pg

# Generated at 2022-06-24 07:51:30.201430
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.workbench import Workbench
    workbench = Workbench()
    workbench.set_default(_OPTION_NAME, False)
    assert workbench.get_option(_OPTION_NAME) == False
    toggle_variable()
    assert workbench.get_option(_OPTION_NAME) == True
    toggle_variable()
    assert workbench.get_option(_OPTION_NAME) == False

# Generated at 2022-06-24 07:51:35.223774
# Unit test for function toggle_variable
def test_toggle_variable():
    """Tests the toggle_variable script in the gui.toolbar_buttons module"""
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:51:43.930190
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.globals import get_runner
    from thonny import THONNY_USER_DIR
    import os
    import shutil

    wb = Workbench()
    wb.init_interface_commands_and_options()
    shutil.rmtree(THONNY_USER_DIR, ignore_errors=True)

    # in_simple_mode == False and run.pgzero_mode == False
    wb.set_option("view.simple_interface", False)
    wb.set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    # in_simple_mode == False and run.pgzero_mode == True

# Generated at 2022-06-24 07:51:44.975519
# Unit test for function load_plugin
def test_load_plugin():
    try:
        load_plugin()
    except:
        failed = True
    assert not failed

# Generated at 2022-06-24 07:51:52.001796
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench

    # pylint: disable=eval-used
    old_wb = get_workbench()
    get_workbench.wb = None  # clear global singleton
    # pylint: enable=eval-used
    try:
        load_plugin()
        # Check the command has been added
        cmd = get_workbench().get_command("toggle_pgzero_mode")
        assert cmd
        wb = get_workbench()
        assert wb.get_variable(_OPTION_NAME)
        assert "PGZERO_MODE" in os.environ
        assert os.environ["PGZERO_MODE"] == str(wb.get_option(_OPTION_NAME))
    finally:
        # pylint: disable=eval-used
        get_workbench.wb = old_

# Generated at 2022-06-24 07:51:56.430892
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    wb = get_workbench()

    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == True
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == False

# Generated at 2022-06-24 07:52:00.320167
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    wb.set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"
    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"

# Generated at 2022-06-24 07:52:07.126308
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny import get_workbench
    workbench = get_workbench()
    workbench._initialize()

    var = workbench.get_variable(_OPTION_NAME)
    var.set(True)
    assert os.environ["PGZERO_MODE"] == "True"

    var.set(False)
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:52:13.278678
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_in_simple_mode(True)
    load_plugin()
    var = wb.get_variable(_OPTION_NAME)
    assert var.get() is False
    assert os.environ["PGZERO_MODE"] == "auto"
    wb.set_in_simple_mode(False)
    assert var.get() is False
    assert os.environ["PGZERO_MODE"] == "False"
    var.set(True)
    assert var.get() is True
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:52:22.738367
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, True)
    assert os.getenv("PGZERO_MODE", "auto") == "True"
    
    get_workbench().set_simple_mode(True)
    assert os.getenv("PGZERO_MODE", "auto") == "auto"
    get_workbench().set_simple_mode(False)
    assert os.getenv("PGZERO_MODE", "auto") == "True"
    
    get_workbench().set_option(_OPTION_NAME, False)
    assert os.getenv("PGZERO_MODE", "auto") == "False"
    
    get_workbench().set_simple_mode(True)

# Generated at 2022-06-24 07:52:28.944791
# Unit test for function toggle_variable
def test_toggle_variable():
    # When the default is True then toggling it should make it False.
    get_workbench().set_default(_OPTION_NAME, True)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False
    # When the default is False then toggling it should make it True.
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True

# Generated at 2022-06-24 07:52:39.290953
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    assert wb.get_option(_OPTION_NAME) == False
    assert "PGZERO_MODE" not in os.environ
    os.environ["PGZERO_MODE"] = "0"
    load_plugin()
    assert wb.get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "0"

    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "1"

    os.environ["PGZERO_MODE"] = "0"
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == False
   

# Generated at 2022-06-24 07:52:43.780181
# Unit test for function toggle_variable
def test_toggle_variable():
    # Test number 1
    # Test 1: Test if toggling the boolean variable once displays the required output

    var = get_workbench().get_variable(_OPTION_NAME)
    var.set(False)

    toggle_variable()
    assert var.get() == True

    # Test number 2
    # Test 2: Test if toggling the boolean variable twice displays the required output

    var = get_workbench().get_variable(_OPTION_NAME)
    var.set(True)

    toggle_variable()
    print(os.environ["PGZERO_MODE"])
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:52:47.117405
# Unit test for function update_environment
def test_update_environment():
    del os.environ["PGZERO_MODE"]
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:52:54.756579
# Unit test for function update_environment
def test_update_environment():
    res = os.environ.get("PGZERO_MODE", "")

    get_workbench().set_option(_OPTION_NAME, True)
    get_workbench().set_simple_mode(False)
    update_environment()

    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_option(_OPTION_NAME, False)
    get_workbench().set_simple_mode(True)
    update_environment()

    assert os.environ["PGZERO_MODE"] == "auto"

    os.environ["PGZERO_MODE"] = res

# Generated at 2022-06-24 07:53:03.940849
# Unit test for function update_environment
def test_update_environment():
    import os
    from thonny.misc_utils import RunningInIDLE

    def prepare_environment():
        if "PGZERO_MODE" in os.environ:
            del os.environ["PGZERO_MODE"]

    prepare_environment()

# Generated at 2022-06-24 07:53:10.601262
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    wb.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    wb.set_simple_mode(False)
    wb.set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"
    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"

# Generated at 2022-06-24 07:53:18.581871
# Unit test for function update_environment
def test_update_environment():
    # Given
    import thonny
    from thonny.workbench import Workbench

    # When
    wb = Workbench()
    wb.in_simple_mode = lambda: True
    wb.get_option = lambda x: True
    thonny.workbench = wb
    update_environment()
    # Then
    assert os.environ["PGZERO_MODE"] == "auto"

    # When
    wb.in_simple_mode = lambda: False
    update_environment()
    # Then
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:53:26.295589
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_fake_workbench()
    load_plugin()
    wb.set_default = MagicMock(return_value=True)
    wb.add_command = MagicMock(return_value=True)
    wb.set_default(_OPTION_NAME, False)
    wb.add_command.assert_called_with(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )

# Generated at 2022-06-24 07:53:31.372670
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    toggle_variable()
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:53:34.675198
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    assert(get_workbench().get_option(_OPTION_NAME) == False)
    toggle_variable()
    assert(get_workbench().get_option(_OPTION_NAME) == True)
    toggle_variable()
    assert(get_workbench().get_option(_OPTION_NAME) == False)

# Generated at 2022-06-24 07:53:43.756689
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import Mock
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    wb.set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    wb.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    wb.set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

   

# Generated at 2022-06-24 07:53:45.674109
# Unit test for function update_environment
def test_update_environment():
    assert os.environ["PGZERO_MODE"] == str(get_workbench().get_option(_OPTION_NAME))

# Generated at 2022-06-24 07:53:53.526848
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    
    wb.set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    
    wb.set_simple_mode(True)
    wb.set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"


if __name__ == "__main__":
    test_update_environment()

# Generated at 2022-06-24 07:53:58.115788
# Unit test for function update_environment
def test_update_environment():
    assert os.environ["PGZERO_MODE"] != "auto"
    get_workbench().in_simple_mode = lambda: True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().in_simple_mode = lambda: False
    update_environment()
    assert os.environ["PGZERO_MODE"] != "auto"


# Generated at 2022-06-24 07:54:07.192415
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    del os.environ["PGZERO_MODE"]
    get_workbench().set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:54:14.109887
# Unit test for function load_plugin
def test_load_plugin():
    wb = FakeWorkbench()
    load_plugin()

    assert wb.in_simple_mode()
    assert wb.get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"

    wb.set_simple_mode(False)
    assert wb.get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"



# Generated at 2022-06-24 07:54:19.268071
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, True)
    assert "PGZERO_MODE" not in os.environ
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) is True
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) is False
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:54:22.143834
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    get_workbench().set_default(_OPTION_NAME, True)
    load_plugin()
    assert get_workbench().get_variable(_OPTION_NAME).get() == True



# Generated at 2022-06-24 07:54:25.157853
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    old_command = wb.get_command("toggle_pgzero_mode")
    try:
        if old_command:
            wb.unregister_command("toggle_pgzero_mode")
        load_plugin()
        assert wb.get_command("toggle_pgzero_mode") is not None
        assert wb.get_option(_OPTION_NAME) == False
    finally:
        if old_command:
            wb.register_command("toggle_pgzero_mode", old_command)

# Generated at 2022-06-24 07:54:32.107914
# Unit test for function toggle_variable
def test_toggle_variable():
    from unittest.mock import MagicMock
    from unittest import mock

    get_workbench = MagicMock(return_value=MagicMock())
    with mock.patch("thonny.plugins.pgz_mode.get_workbench", get_workbench):
        toggle_variable()
        assert get_workbench().get_variable.called_once_with(_OPTION_NAME)
        assert get_workbench().setVariable.called_once_with(_OPTION_NAME, False)



# Generated at 2022-06-24 07:54:36.037156
# Unit test for function toggle_variable
def test_toggle_variable():

    from thonny import get_workbench
    from thonny.languages import tr
    from thonny.plugins.pgzero_mode import (
        get_option,
        load_plugin,
        set_option,
        toggle_variable,
        update_environment,
    )

    set_option(_OPTION_NAME, True)
    toggle_variable()
    assert get_option(_OPTION_NAME) == False
    toggle_variable()
    assert get_option(_OPTION_NAME) == True

# Generated at 2022-06-24 07:54:43.885593
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench

    workbench = Workbench()
    workbench.set_default(_OPTION_NAME, False)

    load_plugin()
    assert workbench.get_variable(_OPTION_NAME).get() == False
    assert os.environ["PGZERO_MODE"] == "False"

    toggle_variable()
    assert workbench.get_variable(_OPTION_NAME).get() == True
    assert os.environ["PGZERO_MODE"] == "True"

    workbench.in_simple_mode = lambda: True
    update_environment()
    assert workbench.get_variable(_OPTION_NAME).get() == True
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:54:44.789668
# Unit test for function load_plugin
def test_load_plugin():
    pass

# Generated at 2022-06-24 07:54:51.568682
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.plugins.pgzero_mode import _OPTION_NAME
    from thonny import get_workbench

    get_workbench().clear_all_variables()
    get_workbench().clear_all_commands()
    load_plugin()
    assert get_workbench().get_default(_OPTION_NAME) == False
    assert get_workbench().in_simple_mode() == False
    assert get_workbench().has_command("toggle_pgzero_mode")
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-24 07:55:02.946625
# Unit test for function update_environment
def test_update_environment():
    from thonny.globals import get_workbench

    os.environ["PGZERO_MODE"] = ""

    wb = get_workbench()
    wb._simple_mode = False
    wb.set_option("run.pgzero_mode", False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    wb._simple_mode = False
    wb.set_option("run.pgzero_mode", True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    wb._simple_mode = True
    wb.set_option("run.pgzero_mode", False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    wb

# Generated at 2022-06-24 07:55:09.374277
# Unit test for function toggle_variable
def test_toggle_variable():
    assert get_workbench().in_simple_mode() == False, "Not in simple mode"
    assert get_workbench().get_option(_OPTION_NAME) == False, "PGZERO_MODE is not active"
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True, "PGZERO_MODE is active"
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True", "PGZERO_MODE is in auto mode"
    toggle_variable()
    toggle_variable()


if __name__ == "__main__":
    test_toggle_variable()
    print("Tests done")

# Generated at 2022-06-24 07:55:19.364072
# Unit test for function update_environment
def test_update_environment():
    from thonny.misc_utils import running_on_mac_os
    from test.test_runner import get_runner
    from test.thonny_unittest import get_workbench_in_blank_state

    orig_mode = os.environ.get("PGZERO_MODE", None)

# Generated at 2022-06-24 07:55:21.170067
# Unit test for function load_plugin
def test_load_plugin():
    pass


if __name__ == "__main__":
    load_plugin()
    toggle_variable()

# Generated at 2022-06-24 07:55:24.862425
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    old_val = wb.get_option(_OPTION_NAME)
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) != old_val
    toggle_variable()
    assert old_val == wb.get_option(_OPTION_NAME)

# Generated at 2022-06-24 07:55:31.461210
# Unit test for function load_plugin
def test_load_plugin():
    global get_workbench
    orig_get_workbench = get_workbench

    def mock_get_workbench():
        return FakeWorkbench()

    get_workbench = mock_get_workbench
    load_plugin()

    assert FakeWorkbench.set_default_args == {
        "name": "run.pgzero_mode",
        "value": False,
    }

    assert FakeWorkbench.add_command_args == {
        "name": "toggle_pgzero_mode",
        "menu_name": "run",
        "label": "Pygame Zero mode",
        "handler": toggle_variable,
        "flag_name": _OPTION_NAME,
        "group": 40,
    }
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench = orig_

# Generated at 2022-06-24 07:55:37.426199
# Unit test for function load_plugin
def test_load_plugin():
    wb = Workbench()
    wb.set_simple_mode(True)
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert wb.get_variable(_OPTION_NAME).get() == False
    assert os.environ["PGZERO_MODE"] == "auto"
    wb.set_simple_mode(False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    assert wb.get_variable(_OPTION_NAME).get() == True
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:55:44.445151
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
    )
    if get_workbench().get_option(_OPTION_NAME) == False:
        print("Pygame Zero mode is disabled")
    else:
        print("Pygame Zero mode is enabled")

    get_workbench().set_option(_OPTION_NAME, True)
    if get_workbench().get_option(_OPTION_NAME) == False:
        print("Pygame Zero mode is disabled")
    else:
        print("Pygame Zero mode is enabled")

# Unit tests for function toggle_variable

# Generated at 2022-06-24 07:55:46.350596
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()
    assert os.environ['PGZERO_MODE'] == "True"
    toggle_variable()
    assert os.environ['PGZERO_MODE'] == "False"

# Generated at 2022-06-24 07:55:47.496879
# Unit test for function toggle_variable
def test_toggle_variable():
    # Just check that nothing fails
    toggle_variable()

# Generated at 2022-06-24 07:55:49.874676
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench

    wb = Workbench()
    load_plugin()
    assert wb.get_option(_OPTION_NAME) is False

# Generated at 2022-06-24 07:55:53.886384
# Unit test for function update_environment
def test_update_environment():
    from unittest import mock
    from thonny.workbench import Workbench

    workbench = Workbench()
    workbench.set_default(_OPTION_NAME, False)

    with mock.patch(" os.environ") as env:
        update_environment()
        env["PGZERO_MODE"].should.equal("False")

# Generated at 2022-06-24 07:56:01.024292
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock
    from thonny import get_runner

    wb = get_workbench()
    wb.set_default("run.pgzero_mode", False)
    assert get_runner().is_pgzero_mode() == False
    assert os.environ["PGZERO_MODE"] == "False"
    
    wb.set_default("run.pgzero_mode", True)
    wb.set_option("run.pgzero_mode", True)
    assert get_runner().is_pgzero_mode() == True
    assert os.environ["PGZERO_MODE"] == "True"
    wb.set_default("run.pgzero_mode", False)
    wb.set_option("run.pgzero_mode", False)
    assert get_runner().is_

# Generated at 2022-06-24 07:56:09.902646
# Unit test for function toggle_variable
def test_toggle_variable():
    # Clean env.
    os.environ.pop("PGZERO_MODE", None)
    get_workbench().set_option(_OPTION_NAME, False)

    # Initial state: not set.
    with get_workbench().config_changed():
        assert "PGZERO_MODE" not in os.environ
        assert not get_workbench().get_option(_OPTION_NAME)

        # Simple mode (pgzero mode should be 'auto').
        get_workbench().set_simple_mode(True)
        update_environment()
        assert os.environ["PGZERO_MODE"] == "auto"
        assert not get_workbench().get_option(_OPTION_NAME)

        # Toggle pgzero mode: should not be supported in simple mode.
        toggle_variable()
        update_environment()

# Generated at 2022-06-24 07:56:15.148818
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_simple_mode(True)

    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:56:23.351389
# Unit test for function update_environment
def test_update_environment():
    # Since this function accesses options and variables, we will mock them here
    # We need to use a fresh workbench and variables, otherwise the env var would stay set
    import thonny.workbench
    wb = thonny.workbench.get_workbench()
    thonny.workbench.get_workbench = lambda: wb
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().add_variable(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:56:28.020464
# Unit test for function update_environment
def test_update_environment():
    from unittest import mock
    from thonny import get_workbench

    with mock.patch("thonny.plugins.pgzero_mode.os") as mock_os:
        get_workbench().set_option("run.pgzero_mode", True)
        update_environment()
        mock_os.environ.__setitem__.assert_called_with("PGZERO_MODE", "True")

# Generated at 2022-06-24 07:56:34.339729
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.misc_utils import running_on_mac_os, running_on_windows

    get_workbench().set_option(_OPTION_NAME, False)
    get_workbench().set_simple_mode(False)

    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get()
    if running_on_mac_os():
        assert os.environ["PGZERO_MODE"] == "1"
    else:
        assert os.environ["PGZERO_MODE"] == "auto"

    toggle_variable()
    assert not get_workbench().get_variable(_OPTION_NAME).get()
    assert os.environ["PGZERO_MODE"] == "0"

    get_workbench().set_simple_mode(True)
    toggle_variable()
   

# Generated at 2022-06-24 07:56:39.175210
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.globals import get_workbench
    from thonny import get_workbench

    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-24 07:56:41.745135
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default(_OPTION_NAME, True)
    get_workbench().in_simple_mode = lambda *args: False
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().in_simple_mode = lambda *args: True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:56:47.710299
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import Mock
    from thonny.plugins.run import RunCommand

    workbench = Mock()

    workbench.get_variable = Mock(return_value='True')
    workbench.in_simple_mode = Mock(return_value=False)

    RunCommand.update_environment(workbench)

    assert os.environ["PGZERO_MODE"] == 'True'

# Generated at 2022-06-24 07:56:52.179982
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.misc_utils import running_on_mac_os

    if running_on_mac_os():
        return

    from thonny.workbench import Workbench

    workbench = Workbench()
    toggle_variable()

    print(_OPTION_NAME, "=", workbench.get_option(_OPTION_NAME))
    assert workbench.get_option(_OPTION_NAME)

    toggle_variable()

    print(_OPTION_NAME, "=", workbench.get_option(_OPTION_NAME))
    assert not workbench.get_option(_OPTION_NAME)

# Generated at 2022-06-24 07:56:58.547637
# Unit test for function update_environment
def test_update_environment():
    os.environ.pop("PGZERO_MODE", None)
    old_in_simple_mode = get_workbench().in_simple_mode

    # In simple mode
    get_workbench().in_simple_mode = lambda: True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    # Not in simple mode, but disabled
    get_workbench().in_simple_mode = lambda: False
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    # Not in simple mode, but enabled
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()

# Generated at 2022-06-24 07:57:05.435911
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    os.environ.pop("PGZERO_MODE", None)
    try:
        var = wb.get_variable(_OPTION_NAME)
        # Snapshot state and reset
        saved_value = var.get()
        var.set(False)
        assert os.environ.get("PGZERO_MODE") == "False"
        # Test
        toggle_variable()
        assert var.get()
        assert os.environ.get("PGZERO_MODE") == "True"
        toggle_variable()
        assert not var.get()
        assert os.environ.get("PGZERO_MODE") == "False"
    finally:
        var.set(saved_value)


# Generated at 2022-06-24 07:57:13.215779
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock
    from thonny.workbench import Workbench

    workbench = Workbench()
    workbench.set_default = Mock()
    workbench.add_command = Mock()
    load_plugin()
    assert workbench.set_default.call_args[0] == (_OPTION_NAME, False)
    workbench.set_default.assert_called_once_with(_OPTION_NAME, False)


if __name__ == "__main__":
    toggle_variable()
else:
    load_plugin()

# Generated at 2022-06-24 07:57:15.399205
# Unit test for function load_plugin
def test_load_plugin():
    workbench = get_workbench()
    workbench.set_default(_OPTION_NAME, False)
    assert not workbench.get_option(_OPTION_NAME)
    workbench.destroy()

# Generated at 2022-06-24 07:57:25.411356
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench
    from thonny.plugins.pgzero_mode import _OPTION_NAME, load_plugin
    from thonny.languages import tr

    load_plugin()

    # Test option added
    assert _OPTION_NAME in get_workbench().get_default("user_options")
    assert (
        get_workbench().get_option("run.pgzero_mode") is False
    ), "Option not added with correct value."

    # Test command added
    assert "toggle_pgzero_mode" in get_workbench().commands
    assert get_workbench().commands["toggle_pgzero_mode"][0] == "run"
    assert get_workbench().commands["toggle_pgzero_mode"][1] == tr("Pygame Zero mode")
    assert get_workbench

# Generated at 2022-06-24 07:57:29.415202
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    wb.set_option(_OPTION_NAME, False)
    toggle_variable()
    assert wb.get_option(_OPTION_NAME)
    toggle_variable()
    assert not wb.get_option(_OPTION_NAME)

# Generated at 2022-06-24 07:57:39.101739
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    assert "PGZERO_MODE" not in os.environ

    wb.set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    os.environ.pop("PGZERO_MODE")

    wb.set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    os.environ.pop("PGZERO_MODE")

    wb.in_simple_mode = lambda: True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    os.environ.pop("PGZERO_MODE")

# Generated at 2022-06-24 07:57:44.153380
# Unit test for function update_environment
def test_update_environment():
    try:
        import builtins
        builtins.__dict__["get_workbench"] = lambda: FakeWorkbench()
        builtins.__dict__["os"] = FakeOS()
        update_environment()
        assert os.environ["PGZERO_MODE"] == "True"
        FakeWorkbench.in_simple_mode = False
        FakeWorkbench.get_option = lambda self, name: False
        update_environment()
        assert os.environ["PGZERO_MODE"] == "False"
    finally:
        del builtins.__dict__["get_workbench"]
        del builtins.__dict__["os"]



# Generated at 2022-06-24 07:57:51.668236
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench
    assert not get_workbench().get_variable(_OPTION_NAME)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().in_simple_mode = True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().in_simple_mode = False

# Generated at 2022-06-24 07:58:02.888304
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.misc_utils import running_on_windows

    wb = Workbench()
    orig_in_simple_mode = wb.in_simple_mode

    def dummy_in_simple_mode():
        return False

    wb.in_simple_mode = dummy_in_simple_mode

    load_plugin()
    assert wb.get_default(_OPTION_NAME) is False
    assert wb.get_variable(_OPTION_NAME).get() is False
    assert get_workbench().get_option(_OPTION_NAME) is False
    assert os.environ.get("PGZERO_MODE") == "False"


# Generated at 2022-06-24 07:58:06.351857
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()

# Generated at 2022-06-24 07:58:13.117971
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import patch, MagicMock

    wb = MagicMock()
    wb.get_option.return_value = False
    wb.in_simple_mode.return_value = False
    with patch.object(thonny.globals, "get_workbench", return_value=wb):
        update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:58:16.442380
# Unit test for function load_plugin
def test_load_plugin():
    from unittest import mock

    wb = mock.MagicMock()
    wb.set_default = mock.MagicMock()
    wb.add_command = mock.MagicMock()
    wb.get_option = mock.MagicMock()
    load_plugin()

# Generated at 2022-06-24 07:58:24.457951
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench

    workbench = Workbench()
    workbench.set_simple_mode(True)
    assert os.environ["PGZERO_MODE"] == "auto"

    os.environ["PGZERO_MODE"] = "auto"

    workbench.set_simple_mode(False)
    workbench.set_option(_OPTION_NAME, False)
    assert os.environ["PGZERO_MODE"] == "False"

    os.environ["PGZERO_MODE"] = "auto"

    workbench.set_simple_mode(False)
    workbench.set_option(_OPTION_NAME, True)
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:58:29.779591
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:58:35.726648
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    assert get_workbench().get_option(_OPTION_NAME) == False

    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "1"
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "0"


# Generated at 2022-06-24 07:58:39.925010
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.globals import get_workbench
    from thonny.languages import tr
    workbench = get_workbench()
    assert workbench.get_variable("run.pgzero_mode") == None
    toggle_variable()
    assert workbench.get_variable("run.pgzero_mode") == True
    toggle_variable()
    assert workbench.get_variable("run.pgzero_mode") == False
    assert workbench.get_command("toggle_pgzero_mode").flag_name == "run.pgzero_mode"
    assert workbench.get_command("toggle_pgzero_mode").label == tr("Pygame Zero mode")
test_toggle_variable()

# Generated at 2022-06-24 07:58:50.126566
# Unit test for function update_environment
def test_update_environment():
    from thonny.running import BackendProxy
    
    del os.environ["PGZERO_MODE"]
    assert not BackendProxy._is_pgzero_mode()

    # pgzero mode is ignored in simple mode
    get_workbench().set_default(_OPTION_NAME, True)
    get_workbench().set_simple_mode(True)
    update_environment()
    assert not BackendProxy._is_pgzero_mode()

    get_workbench().set_simple_mode(False)
    update_environment()
    assert BackendProxy._is_pgzero_mode()

    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert not BackendProxy._is_pgzero_mode()

# Generated at 2022-06-24 07:58:52.914201
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-24 07:59:03.463596
# Unit test for function load_plugin
def test_load_plugin():
    # my import
    from thonny.workbench import Workbench

    # Clean up
    if "PGZERO_MODE" in os.environ:
        del os.environ["PGZERO_MODE"]

    # Create a dummy workbench
    wb = Workbench()

    # Dummy function to be able to use wb.run_command
    def dummy_cmd(cmd_name):
        pass

    # The plugin will add a PGZERO_MODE command to the run menu
    wb.run_command = dummy_cmd

    # Now call the plugin loader
    load_plugin()

    # Check that the environment variable is set
    assert os.environ["PGZERO_MODE"] == "True"

    # Clean up so this test can be run multiple times
    del os.environ["PGZERO_MODE"]

# Generated at 2022-06-24 07:59:08.339410
# Unit test for function toggle_variable
def test_toggle_variable():
    assert get_workbench().get_option("run.pgzero_mode") == False
    toggle_variable()
    assert get_workbench().get_option("run.pgzero_mode") == True
    toggle_variable()
    assert get_workbench().get_option("run.pgzero_mode") == False


# Generated at 2022-06-24 07:59:16.215705
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.misc_utils import running_on_linux
    from thonny.misc_utils import running_on_mac_os
    from thonny.misc_utils import running_on_raspi
    if not (running_on_linux() or running_on_mac_os() or running_on_raspi()):
        print("\n===== Testing pgzero_mode.py ===== ")

        from thonny.plugins.pgzero_mode import toggle_variable
        from thonny.languages import tr
        from thonny import get_workbench
        from thonny.globals import get_runner

        # Load plugin, get workbench, option and runner
        load_plugin()
        workbench = get_workbench()
        option = workbench.get_variable(_OPTION_NAME)
       

# Generated at 2022-06-24 07:59:24.690480
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny import get_workbench
    from thonny.misc_utils import running_on_mac_os
    from thonny.plugins.pgzeroconfig.pgzeroconfig import toggle_variable
    from thonny.plugins.pgzeroconfig.pgzeroconfig import update_environment
    from unittest.mock import patch

    # Only run these tests if not on Mac OS
    if not running_on_mac_os():
        toggle_variable()
        var = get_workbench().get_variable(_OPTION_NAME)
        assert var.get() == True

        toggle_variable()
        var = get_workbench().get_variable(_OPTION_NAME)
        assert var.get() == False

        toggle_variable()
        var = get_workbench().get_variable(_OPTION_NAME)
       

# Generated at 2022-06-24 07:59:29.896039
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:59:34.324775
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME)
    toggle_variable()
    assert not get_workbench().get_option(_OPTION_NAME)



# Generated at 2022-06-24 07:59:36.840171
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == True
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == False

# Generated at 2022-06-24 07:59:43.177955
# Unit test for function load_plugin
def test_load_plugin():
    import tkinter
    from unittest.mock import Mock
    from test.test_environment import get_test_config_dir

    workbench = Mock(spec=tkinter.Tk)
    workbench.get_option = Mock(return_value=1)
    workbench.set_option = Mock()
    workbench.set_default = Mock()
    workbench.get_variable = Mock()
    setattr(workbench, "in_simple_mode", Mock(return_value=True))
    setattr(workbench, "get_local_cwd", Mock(return_value=get_test_config_dir()))
    setattr(workbench, "get_variable", Mock(return_value=True))
    setattr(workbench, "add_command", Mock())
    load_plugin()

# Generated at 2022-06-24 07:59:50.743554
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"



# Generated at 2022-06-24 07:59:57.068965
# Unit test for function toggle_variable
def test_toggle_variable():
    from unittest.mock import MagicMock
    from thonny.workbench import Workbench
    wb = Workbench()
    wb.set_variable = MagicMock()
    toggle_variable()
    wb.set_variable.assert_called_with("run.pgzero_mode", True)
    toggle_variable()
    wb.set_variable.assert_called_with("run.pgzero_mode", False)


# Generated at 2022-06-24 08:00:02.237847
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    assert get_workbench().get_option(_OPTION_NAME) == False

    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True

    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-24 08:00:06.800626
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_option(_OPTION_NAME, True)
    toggle_variable()
    assert get_workbench().get_option("run.pgzero_mode") == False
    toggle_variable()
    assert get_workbench().get_option("run.pgzero_mode") == True

# Generated at 2022-06-24 08:00:07.787187
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()
    pass

# Generated at 2022-06-24 08:00:14.680035
# Unit test for function update_environment
def test_update_environment():
    from unittest import TestCase
    from unittest.mock import Mock, patch

    get_workbench = Mock()
    get_workbench.get_option = Mock(return_value=True)
    test_base = TestCase()
    with patch("thonny.plugins.pgzmode.get_workbench", Mock(return_value=get_workbench)):
        update_environment()
        test_base.assertTrue(os.environ["PGZERO_MODE"])
        get_workbench.get_option = Mock(return_value=False)
        update_environment()
        test_base.assertFalse(os.environ["PGZERO_MODE"])

# Generated at 2022-06-24 08:00:17.803158
# Unit test for function update_environment
def test_update_environment():
    for option in [True, False]:
        get_workbench().set_option(_OPTION_NAME, option)
        update_environment()
        assert os.environ["PGZERO_MODE"] == str(option)

# Generated at 2022-06-24 08:00:18.394669
# Unit test for function load_plugin
def test_load_plugin():
    pass

# Generated at 2022-06-24 08:00:24.886890
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    wb.set_option(_OPTION_NAME, False)

    # Ensure default is False
    assert wb.get_option(_OPTION_NAME) == False

    toggle_variable()

    # Ensure toggling works
    assert wb.get_option(_OPTION_NAME) == True

    toggle_variable()

    # Ensure it toggles back
    assert wb.get_option(_OPTION_NAME) == False

    # Cleanup
    wb.set_option(_OPTION_NAME, False)

# Generated at 2022-06-24 08:00:32.032138
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_simple_mode(True)
    assert os.environ.get("PGZERO_MODE") is None
    toggle_variable()
    assert os.environ.get("PGZERO_MODE") == "1"
    toggle_variable()
    assert os.environ.get("PGZERO_MODE") == "0"
    get_workbench().set_simple_mode(False)
    toggle_variable()
    assert os.environ.get("PGZERO_MODE") == "1"

# Generated at 2022-06-24 08:00:35.867100
# Unit test for function toggle_variable
def test_toggle_variable():
    #Testing to toggle the variable
    assert get_workbench().get_variable(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME) == True

# Generated at 2022-06-24 08:00:41.131850
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench

    workbench = Workbench()
    workbench.set_default(_OPTION_NAME, False)
    assert workbench.get_variable(_OPTION_NAME) is False
    load_plugin()
    assert workbench.get_variable(_OPTION_NAME) is False
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert workbench.get_variable(_OPTION_NAME) is True
    assert os.environ["PGZERO_MODE"] == "True"
    workbench.destroy()

if __name__ == "__main__":
    test_load_plugin()

# Generated at 2022-06-24 08:00:51.524405
# Unit test for function update_environment
def test_update_environment():
    import thonny.workbench
    workbench = thonny.workbench.get_workbench()

    workbench.set_default(_OPTION_NAME, False)
    workbench.set_default("view.simple_mode", False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    workbench.set_default(_OPTION_NAME, True)
    workbench.set_default("view.simple_mode", False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    workbench.set_default(_OPTION_NAME, False)
    workbench.set_default("view.simple_mode", True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 08:00:54.730204
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.workbench import Workbench
    workbench = Workbench()
    var = workbench.get_variable(_OPTION_NAME)
    var.set(True)
    toggle_variable()
    assert var.get() == False


# Generated at 2022-06-24 08:00:58.654745
# Unit test for function toggle_variable
def test_toggle_variable():
    
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True

# Generated at 2022-06-24 08:01:02.039301
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    print(get_workbench().get_option(_OPTION_NAME))


if __name__ == "__main__":
    test_load_plugin()

# Generated at 2022-06-24 08:01:13.660371
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench
    from unittest.mock import patch
    from thonny.globals import get_workbench

    wb = get_workbench()
    wb.set_simple_mode(True)
    wb.set_default(_OPTION_NAME, False)

    with patch.dict("os.environ", {"THONNY_PGZERO_MODE": "test"}, clear=True):
        assert "test" in os.environ
        update_environment()
        assert "PGZERO_MODE" in os.environ
        assert os.environ["PGZERO_MODE"] == "auto"
        wb.set_simple_mode(False)
        wb.set_option(_OPTION_NAME, True)
        update_environment()