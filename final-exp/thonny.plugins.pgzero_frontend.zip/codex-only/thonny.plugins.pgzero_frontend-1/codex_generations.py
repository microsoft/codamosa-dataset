

# Generated at 2022-06-24 07:51:22.267574
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_runner
    from thonny import get_workbench

    # in_simple_mode == False, _OPTION_NAME == False
    get_workbench().in_simple_mode = lambda: False
    get_workbench()._OPTION_NAME = False
    expect = os.environ["PGZERO_MODE"]
    update_environment()
    actual = os.environ["PGZERO_MODE"]
    assert actual == expect

    # in_simple_mode == True, _OPTION_NAME == True
    get_workbench().in_simple_mode = lambda: True
    get_workbench()._OPTION_NAME = True
    update_environment()
    actual = os.environ["PGZERO_MODE"]
    expect = "auto"
    assert actual == expect

    # in_simple_

# Generated at 2022-06-24 07:51:30.822140
# Unit test for function load_plugin
def test_load_plugin():
    import unittest.mock as mock

    get_workbench = mock.Mock()
    get_workbench.in_simple_mode.return_value = False
    get_workbench.get_option.return_value = False

    with mock.patch("thonny.plugins.pgzero.load_plugin.get_workbench", get_workbench):
        load_plugin()

    assert get_workbench.get_option.call_args == mock.call("run.pgzero_mode")
    assert get_workbench.set_default.call_args == mock.call("run.pgzero_mode", False)

    assert get_workbench.add_command.call_count == 1
    assert get_workbench.add_command.call_args[0][0] == "toggle_pgzero_mode"
    assert get_

# Generated at 2022-06-24 07:51:34.839479
# Unit test for function toggle_variable
def test_toggle_variable():
    pgzero_mode = get_workbench().get_variable(_OPTION_NAME)
    pgzero_mode.set(False)
    toggle_variable()
    assert pgzero_mode.get()

    pgzero_mode.set(True)
    toggle_variable()
    assert not pgzero_mode.get()

test_toggle_variable()

# Generated at 2022-06-24 07:51:40.999634
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_in_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:51:50.568487
# Unit test for function load_plugin
def test_load_plugin():
    from test.test_runner import get_runner
    from thonny.workbench import Workbench

    runner = get_runner()
    runner.log_assertion("plugin_manager.plugin_loaded", "pgzrun_plugin")

    runner.invoke_command("Run current script")
    runner.log_assertion("program_output", "Hello world!")
    runner.log_assertion("pgzero_mode", "False")

    runner.invoke_command("Toggle pygame zero mode")
    runner.log_assertion("pgzero_mode", "True")

    runner.invoke_command("Reset Thonny")
    runner.invoke_command("Toggle simple mode")

    runner.log_assertion("plugin_manager.plugin_loaded", "pgzrun_plugin")

    runner.invoke_command("Run current script")
   

# Generated at 2022-06-24 07:51:58.244784
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    wb = get_workbench()
    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    wb._in_simple_mode = True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_default(_OPTION_NAME, False)

# Generated at 2022-06-24 07:52:09.699526
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config import get_runner_command, get_interpreter
    from thonny.common import ToplevelCommand
    from thonny import get_runner
    from thonny.ui_utils import select_or_create_interpreter
    import os

    workbench = Workbench()
    workbench.set_default(_OPTION_NAME, False)
    update_environment()
    print(os.getenv("PGZERO_MODE"))
    assert "PGZERO_MODE" in os.environ.keys()

    workbench.set_default(_OPTION_NAME, True)
    update_environment()
    print(os.getenv("PGZERO_MODE"))
    assert os.getenv("PGZERO_MODE") == "true"

    work

# Generated at 2022-06-24 07:52:19.807527
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock, patch

    wb = Mock()

    wb.get_variable = lambda optname: Mock()
    wb.get_option = lambda optname: Mock()
    wb.set_default = Mock()
    wb.add_command = Mock()
    wb.in_simple_mode = Mock()

    with patch("thonny.plugins.pgzero.get_workbench", lambda : wb):
        load_plugin()
        wb.get_variable.assert_called_with(_OPTION_NAME)
        wb.set_default.assert_called_with(_OPTION_NAME, False)

# Generated at 2022-06-24 07:52:26.837420
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.load_plugins_as_needed()
    assert get_workbench().default_config["run"][_OPTION_NAME] == False
    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"

    wb.in_simple_mode = lambda: True
    update_environment()
    assert get_workbench().default_config["run"][_OPTION_NAME] == False
    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-24 07:52:28.404677
# Unit test for function load_plugin
def test_load_plugin():
    # import thonny
    # thonny.test()
    pass

# Generated at 2022-06-24 07:52:37.808191
# Unit test for function toggle_variable
def test_toggle_variable():
    from unittest.mock import Mock

    MockTk = Mock()
    MockTk.BooleanVar = Mock()
    MockTk.BooleanVar.get = Mock(return_value=False)
    MockTk.BooleanVar.set = Mock()
    MockWorkbench = Mock()
    MockWorkbench.get_variable = Mock(return_value=MockTk.BooleanVar)
    MockWorkbench.get_option = Mock(return_value=False)
    get_workbench.set_result(MockWorkbench)
    toggle_variable()
    assert MockTk.BooleanVar.set.called


if __name__ == "__main__":
    load_plugin()

# Generated at 2022-06-24 07:52:41.434109
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-24 07:52:50.527072
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import patch
    from thonny import get_workbench

    with patch.dict("os.environ", clear=True):
        assert "PGZERO_MODE" not in os.environ
        get_workbench().in_simple_mode = lambda: True
        update_environment()
        assert os.environ["PGZERO_MODE"] == "auto"

    with patch.dict("os.environ", clear=True):
        assert "PGZERO_MODE" not in os.environ
        get_workbench().in_simple_mode = lambda: False
        get_workbench().get_option(_OPTION_NAME) == False
        update_environment()
        assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:52:56.934034
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert not get_workbench().get_variable(_OPTION_NAME).get()
    assert os.environ["PGZERO_MODE"] == "False"

    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get()
    assert os.environ["PGZERO_MODE"] == "True"

    toggle_variable()
    assert not get_workbench().get_variable(_OPTION_NAME).get()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:53:02.999124
# Unit test for function load_plugin
def test_load_plugin():
    """
    Test that it doesn't fail.
    """
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    assert not wb.get_option(_OPTION_NAME)
    load_plugin()
    assert wb.get_variable(_OPTION_NAME).get()
    assert os.environ["PGZERO_MODE"] == str(wb.get_option(_OPTION_NAME))

# Generated at 2022-06-24 07:53:11.921204
# Unit test for function update_environment
def test_update_environment():
    from thonny.misc_utils import running_on_mac_os
    from thonny import get_workbench

    if running_on_mac_os():
        print("Skipping test for update_environment on Mac")
    else:
        get_workbench().set_default(_OPTION_NAME, False)
        update_environment()
        assert os.environ["PGZERO_MODE"] == "False"
        get_workbench().set_option(_OPTION_NAME, True)
        update_environment()
        assert os.environ["PGZERO_MODE"] == "True"
        get_workbench().in_simple_mode = lambda: True
        update_environment()
        assert os.environ["PGZERO_MODE"] == "auto"
        get_workbench().in_simple_mode = lambda: False


# Generated at 2022-06-24 07:53:22.758575
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.globals import get_runner
    from thonny.globals import get_workbench
    from thonny.plugins.run.run_backend import get_run_commands
    load_plugin()
    assert get_workbench().get_default(_OPTION_NAME) is False
    assert get_workbench().get_option(_OPTION_NAME) is False
    # Test toggle_variable
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) is True
    # Test update_environment
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    # Test load_plugin again
    load_plugin()
    assert get_workbench().get_default(_OPTION_NAME) is False
    assert get_workbench().get

# Generated at 2022-06-24 07:53:30.498598
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    toggle_variable()
    t1 = get_workbench().get_option(_OPTION_NAME)
    t2 = get_workbench().get_option(_OPTION_NAME)
    if t1 == t2:
        assert t1 == True
    else:
        assert t2 == False


# Generated at 2022-06-24 07:53:33.803789
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    assert wb.in_simple_mode() == False
    assert wb.get_variable(_OPTION_NAME).get() == False
    load_plugin()
    assert wb.in_simple_mode() == False
    assert wb.get_variable(_OPTION_NAME).get() == False

# Generated at 2022-06-24 07:53:42.045083
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock
    from thonny import get_workbench
    get_workbench().set_default = Mock()
    get_workbench().add_command = Mock()
    get_workbench().in_simple_mode = lambda: True
    load_plugin()
    get_workbench().set_default.assert_called_once_with(_OPTION_NAME, False)
    get_workbench().add_command.assert_called_once_with(
        "toggle_pgzero_mode",
        "run",
        "Pygame Zero mode",
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )

# Generated at 2022-06-24 07:53:51.829296
# Unit test for function update_environment
def test_update_environment():
    from test.common import run_in_fresh_process
    from thonny import get_workbench

    def change_mode_and_check_environment():
        get_workbench().set_simple_mode(True)
        update_environment()
        assert os.environ["PGZERO_MODE"] == "auto"

        get_workbench().set_simple_mode(False)
        update_environment()
        assert os.environ["PGZERO_MODE"] == "False"

        get_workbench().set_simple_mode(True)
        update_environment()
        assert os.environ["PGZERO_MODE"] == "auto"

        get_workbench().set_simple_mode(False)
        update_environment()
        assert os.environ["PGZERO_MODE"] == "False"

    run_in_

# Generated at 2022-06-24 07:53:56.166648
# Unit test for function toggle_variable
def test_toggle_variable():
    try:
        assert get_workbench().get_variable(_OPTION_NAME).get() == False
        toggle_variable()
        assert get_workbench().get_variable(_OPTION_NAME).get() == True
        toggle_variable()
        assert get_workbench().get_variable(_OPTION_NAME).get() == False
    except:
        get_workbench().set_default(_OPTION_NAME, False)

# Generated at 2022-06-24 07:54:06.433244
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import Mock

    mw = Mock()
    get_workbench = lambda: mw
    mw.get_option.side_effect = lambda name: False
    mw.in_simple_mode.return_value = False

    update_environment()
    assert os.environ.get("PGZERO_MODE") == "False"

    mw.reset_mock()
    mw.in_simple_mode.return_value = True
    update_environment()
    assert os.environ.get("PGZERO_MODE") == "auto"

    mw.reset_mock()
    mw.get_option.side_effect = lambda name: True
    update_environment()
    assert os.environ.get("PGZERO_MODE") == "True"

# Generated at 2022-06-24 07:54:10.308789
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.plugins.run import get_backend_name

    # Check default value
    get_workbench().set_default(_OPTION_NAME, False)
    assert not get_workbench().get_option(_OPTION_NAME)

    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME)

    toggle_variable()
    assert not get_workbench().get_option(_OPTION_NAME)



# Generated at 2022-06-24 07:54:17.375494
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_in_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"].lower() == "auto"
    get_workbench().set_in_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"].lower() == "false"
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"].lower() == "true"

# Generated at 2022-06-24 07:54:21.360279
# Unit test for function load_plugin
def test_load_plugin():
    # Setup
    get_workbench().set_default(_OPTION_NAME, False)
    
    # Execution
    load_plugin()
    _options = get_workbench().get_options()
    
    # Verification
    assert _options.get(_OPTION_NAME) == False
    assert _options.get("_OPTION_NAME") == None
    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    
    

# Generated at 2022-06-24 07:54:31.882354
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench

    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    assert (
        get_workbench().get_option(_OPTION_NAME) == False
    ), "Default value for the plugin not set"
    assert (
        get_workbench().commands["toggle_pgzero_mode"].flag_name == _OPTION_NAME
    ), "Command not set properly"
    assert "PGZERO_MODE" in os.environ, "Environment variable PGZERO_MODE not set"
    assert (
        os.environ["PGZERO_MODE"] == "False"
    ), "Environment variable PGZERO_MODE not set properly"
    get_workbench().set_simple_mode(True)
    update_environment()

# Generated at 2022-06-24 07:54:41.520208
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    var = get_workbench().get_variable(_OPTION_NAME)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    print(get_workbench().get_variable(_OPTION_NAME))
    # Update environment:
    update_environment()
    # Toggle it:
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    assert get_workbench().get_option(_OPTION_NAME) == True
    # Toggle it again:

# Generated at 2022-06-24 07:54:50.849385
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    wb.set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    # Test that PGZERO_MODE is set to auto when in_simple_mode()
    wb.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    wb.set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:55:01.927113
# Unit test for function update_environment
def test_update_environment():
    import test
    from thonny.common import ToplevelCommand
    from thonny import get_workbench
    from thonny.misc_utils import running_on_mac_os

    test.create_workbench()
    test.initialize_workbench_variables()
    get_workbench().register_command(
        ToplevelCommand("toggle_pgzero_mode")
    )  # Otherwise function get_workbench().in_simple_mode() is False
                                                            # for the case of running on MacOS
    # Get initial value of the env. variable PGZERO_MODE
    orig_PGZERO_MODE = os.environ['PGZERO_MODE']

    if running_on_mac_os():
        get_workbench().set_option(_OPTION_NAME, False)
        update_environment()


# Generated at 2022-06-24 07:55:08.890380
# Unit test for function update_environment
def test_update_environment():
    global os

    import os
    import thonny
    from thonny.languages import DEFAULT_LANGUAGE
    from thonny import get_workbench

    os.environ["PGZERO_MODE"] = "auto"
    get_workbench().set_default(_OPTION_NAME, True)
    get_workbench().set_default("view.language", DEFAULT_LANGUAGE)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_default("view.language", "tr")
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"

# Generated at 2022-06-24 07:55:16.323033
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = "auto"
    orig_vals = (get_workbench().in_simple_mode(), get_workbench().get_option(_OPTION_NAME))
    get_workbench().set_simple_mode(True)
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"
    get_workbench().set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"

# Generated at 2022-06-24 07:55:22.658192
# Unit test for function update_environment
def test_update_environment():
    os.environ.pop("PGZERO_MODE", None)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    g = get_workbench()
    g.set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    g.enter_simple_mode()
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:55:26.163186
# Unit test for function load_plugin
def test_load_plugin():
    # Just to make sure that loading the plugin works
    get_workbench().set_default(_OPTION_NAME, True)
    load_plugin()

    assert get_workbench().get_default(_OPTION_NAME) is False
    assert get_workbench().get_option(_OPTION_NAME) is False



# Generated at 2022-06-24 07:55:26.641400
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()

# Generated at 2022-06-24 07:55:35.004590
# Unit test for function load_plugin
def test_load_plugin():
    # Create dummy environment and workbench
    class Env:

        class Options:
            pass

        def in_simple_mode(self):
            return False

    env = Env()
    env.simple_mode_active = False
    env.get_option = lambda opt: getattr(env.Options, opt)
    env.set_default = lambda opt, val: setattr(env.Options, opt, val)
    env.get_variable = lambda opt: env.Options

    class WB:
        def get_variable(self, v):
            return getattr(env.Options, v)

        def add_command(self, name, menu_name, label, handler, flag_name=None, group=None):
            setattr(env, name, label)


# Generated at 2022-06-24 07:55:37.253053
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.misc_utils import running_on_mac_os

    if running_on_mac_os():
        return

    from thonny.workbench import Workbench

    w = Workbench()
    w.load_plugin(__name__)
    w.destroy()

# Generated at 2022-06-24 07:55:43.446208
# Unit test for function update_environment
def test_update_environment():
    # for testing I will temporarily mess up with sys.path
    try:
        old_env = dict(os.environ)
        for mode in [True, False]:
            get_workbench().set_option(_OPTION_NAME, mode)
            update_environment()
            assert os.environ["PGZERO_MODE"] == str(mode)
        # test that in simple mode simple GUI is always active
        get_workbench().set_simple_mode(True)
        update_environment()
        assert os.environ["PGZERO_MODE"] == "auto"
    finally:
        os.environ.clear()
        os.environ.update(old_env)
    assert True

# Generated at 2022-06-24 07:55:51.534825
# Unit test for function update_environment
def test_update_environment():
    import sys
    import thonny.backend

    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"

    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"

    get_workbench().set_option("view.simple_mode", True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:55:57.558094
# Unit test for function toggle_variable
def test_toggle_variable():
    global _OPTION_NAME

    def get_value():
        return get_workbench().get_option(_OPTION_NAME)

    def set_value(value):
        get_workbench().set_option(_OPTION_NAME, value)

    try:
        _OPTION_NAME = "test_toggle_variable"
        load_plugin()

        set_value(False)
        toggle_variable()
        assert get_value() is True
        toggle_variable()
        assert get_value() is False
    finally:
        _OPTION_NAME = "run.pgzero_mode"

# Generated at 2022-06-24 07:56:02.545342
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME)
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert not get_workbench().get_option(_OPTION_NAME)
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:56:06.203215
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ.get("PGZERO_MODE") == "True"
    
    wb.set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ.get("PGZERO_MODE") == "False"
    
    wb.set_simple_mode(True)
    update_environment()
    assert os.environ.get("PGZERO_MODE") == "auto"

# Generated at 2022-06-24 07:56:12.923681
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    assert _OPTION_NAME in wb.get_defaults()
    assert not wb.get_option(_OPTION_NAME)
    assert "PGZERO_MODE" not in os.environ
    load_plugin()
    assert _OPTION_NAME in wb.get_defaults()
    assert not wb.get_option(_OPTION_NAME)
    assert "PGZERO_MODE" in os.environ


# Generated at 2022-06-24 07:56:19.546780
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    
    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"
    
    wb.set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"
    
    wb.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    
    wb.set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"
    
    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os

# Generated at 2022-06-24 07:56:28.420854
# Unit test for function update_environment
def test_update_environment():
    test_env = {"PGZERO_MODE": "auto"}
    get_workbench().user_options = {"run.pgzero_mode": False}
    update_environment(test_env)
    assert test_env["PGZERO_MODE"] == "0"

    get_workbench().user_options = {"run.pgzero_mode": True}
    update_environment(test_env)
    assert test_env["PGZERO_MODE"] == "1"

    get_workbench().user_options = {"run.pgzero_mode": None}
    update_environment(test_env)
    assert test_env["PGZERO_MODE"] == "0"


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 07:56:35.096096
# Unit test for function update_environment
def test_update_environment():
    assert os.environ.get("PGZERO_MODE") == "auto"
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ.get("PGZERO_MODE") == "True"
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ.get("PGZERO_MODE") == "False"

# Generated at 2022-06-24 07:56:39.993719
# Unit test for function toggle_variable
def test_toggle_variable():
    # testing the initial condition
    assert get_workbench().get_option(_OPTION_NAME) == False
    # perform the toggle
    toggle_variable()
    # testing the result of the toggle
    assert get_workbench().get_option(_OPTION_NAME) == True
    # reset the workbench
    get_workbench().set_default(_OPTION_NAME, False)

# Generated at 2022-06-24 07:56:47.077663
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.workbench import Workbench
    from thonny.config_ui import ConfigurationPage

    workbench = Workbench()
    page = ConfigurationPage(workbench, workbench.get_option_view("run"))
    workbench.get_variable(_OPTION_NAME).set(True)
    toggle_variable()
    assert workbench.get_variable(_OPTION_NAME).get() is False
    toggle_variable()
    assert workbench.get_variable(_OPTION_NAME).get() is True

# Generated at 2022-06-24 07:56:55.357438
# Unit test for function load_plugin
def test_load_plugin():
    from tkinter import Tk
    from thonny import get_workbench
    from thonny.config import get_configuration
    from thonny.plugins.runpgzero_mode import toggle_variable
    from thonny.plugins.runpgzero_mode import update_environment

    window = Tk()
    window.withdraw()

    get_workbench().set_default("run.pgzero_mode", False)
    get_workbench().in_simple_mode = lambda: True
    update_environment()
    assert "PGZERO_MODE" in os.environ
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().in_simple_mode = lambda: False
    update_environment()
    assert "PGZERO_MODE" in os.environ

# Generated at 2022-06-24 07:57:00.715416
# Unit test for function toggle_variable
def test_toggle_variable():
    """
    Test that setting the PGZERO_MODE variable
    is done correctly
    """
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:57:05.137281
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:57:14.750650
# Unit test for function toggle_variable
def test_toggle_variable():
    # Assumes Pygame Zero is already installed
    backup = os.environ.get("PGZERO_MODE")
    try:
        import pygame_zero
        del pygame_zero
    except ImportError:
        pytest.skip("pygame_zero not installed")
        
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "auto"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"
    if backup is None:
        del os.environ["PGZERO_MODE"]
    else:
        os.environ["PGZERO_MODE"] = backup

# Generated at 2022-06-24 07:57:23.148101
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock

    wb = Mock()
    wb.get_variable.return_value.get.return_value = False
    wb.get_variable.return_value.set.return_value = None
    wb.get_option.return_value = False
    wb.in_simple_mode.return_value = False

    load_plugin()

    assert wb.in_simple_mode.called
    assert wb.set_default.called
    assert wb.add_command.called
    assert wb.get_variable.called

# Generated at 2022-06-24 07:57:26.119929
# Unit test for function load_plugin
def test_load_plugin():
    config = {_OPTION_NAME: True}
    wb = get_workbench()
    wb.set_configuration(config)
    load_plugin()
    assert wb.get_variable(_OPTION_NAME) == True
    assert wb.get_option(_OPTION_NAME) == True

# Generated at 2022-06-24 07:57:30.553657
# Unit test for function load_plugin
def test_load_plugin():
    from tests.utils import run_in_shell

    run_in_shell("load_plugin(thonny.plugins.pgzeromode)")
    run_in_shell("toggle_pgzero_mode()")
    run_in_shell("assert get_option('run.pgzero_mode')")

# Generated at 2022-06-24 07:57:37.919584
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(
        _OPTION_NAME, False
    )  # plugin should not destroy other defaults
    load_plugin()
    assert wb.get_variable(_OPTION_NAME).get() == False
    assert "PGZERO_MODE" not in os.environ
    wb.get_variable(_OPTION_NAME).set(True)
    assert wb.get_option(_OPTION_NAME) == True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:57:40.956173
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    toggle_variable()
    assert wb.get_variable(_OPTION_NAME).get() == True
    toggle_variable()
    assert wb.get_variable(_OPTION_NAME).get() == False

# Generated at 2022-06-24 07:57:46.766427
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"
    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"

# Generated at 2022-06-24 07:57:49.189515
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert get_workbench().get_default("run.pgzero_mode") is False
    assert get_workbench().get_command("toggle_pgzero_mode")

# Generated at 2022-06-24 07:57:59.597779
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    load_plugin()

    assert hasattr(wb, "toggle_pgzero_mode")
    assert hasattr(wb, "pgzero_mode")
    assert callable(wb.toggle_pgzero_mode)
    assert callable(wb.pgzero_mode)
    assert wb.get_option(_OPTION_NAME) == False
    assert os.environ.get("PGZERO_MODE") == "auto"
    wb.toggle_pgzero_mode()
    assert wb.get_option(_OPTION_NAME) == True
    assert os.environ.get("PGZERO_MODE") == "True"

# Generated at 2022-06-24 07:58:03.150518
# Unit test for function toggle_variable
def test_toggle_variable():
    for i in range(4):
        print(get_workbench().get_variable(_OPTION_NAME).get())
        toggle_variable()
        assert get_workbench().get_variable(_OPTION_NAME).get() == (
            i % 2 == 0
        ), "i=%d" % i

# Generated at 2022-06-24 07:58:05.230927
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == True

# Generated at 2022-06-24 07:58:06.960004
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert not get_workbench().get_option(_OPTION_NAME)

# Generated at 2022-06-24 07:58:17.066122
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.globals import get_runner, get_workbench, get_shell

    get_workbench().set_simple_mode(True)
    get_workbench().get_option(_OPTION_NAME).set(False)
    get_workbench().set_variable(_OPTION_NAME, "hello")
    assert get_workbench().get_variable(_OPTION_NAME) == "hello"
    assert get_workbench().in_simple_mode()

    get_shell().clear()
    toggle_variable()
    get_shell().clear()
    assert get_workbench().get_variable(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME) == True

    get_workbench().set_simple_mode(False)

# Generated at 2022-06-24 07:58:19.992575
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:58:20.409752
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()

# Generated at 2022-06-24 07:58:24.810855
# Unit test for function toggle_variable
def test_toggle_variable():
    tests = [
        ("1", "0", "value changes from 1 to 0"),
        ("0", "1", "value changes from 0 to 1"),
        ("", "1", "value changes from empty to 1"),
        ("0", "1", "value changes from 0 to 1"),
    ]
    for test in tests:
        yield check_toggle_variable, test[0], test[1], test[2]



# Generated at 2022-06-24 07:58:35.182627
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.plugins.runner import RunnerPlugin

    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.register_plugin(RunnerPlugin)
    wb.get_option("run.run_current_file_and_keep_running_mode").set(False)
    wb.get_option("run.run_current_file_mode").set(False)

    update_environment()

    assert os.environ["PGZERO_MODE"] == "False"

    wb.set_default(_OPTION_NAME, True)
    wb.get_option("run.run_current_file_and_keep_running_mode").set(True)

# Generated at 2022-06-24 07:58:36.137645
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()



# Generated at 2022-06-24 07:58:42.913004
# Unit test for function toggle_variable
def test_toggle_variable():
    from unittest import mock

    get_workbench().set_option(_OPTION_NAME, True)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) is False

    with mock.patch.dict(os.environ, {}):
        update_environment()
        assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_in_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().set_in_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:58:47.393551
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    assert get_workbench().get_option(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-24 07:58:55.518941
# Unit test for function load_plugin
def test_load_plugin():
    from tkinter import Tk, Checkbutton, IntVar
    from thonny import get_workbench
    from thonny.languages import tr
    from thonny.misc_utils import running_on_mac_os, running_on_windows

    root = Tk()
    root.withdraw()

    workbench = get_workbench()
    workbench.create()

    elem = workbench.get_variable(_OPTION_NAME)
    elem.set(False)

    load_plugin()
    if running_on_windows():
        assert os.environ["PGZERO_MODE"] == "False"
    else:
        assert os.environ["PGZERO_MODE"] == "0"

    # Toggle the state of the checkbox and make sure the env var is set to 0 or 1.
    # The

# Generated at 2022-06-24 07:59:00.695927
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench, get_runner
    from thonny.config import Configuration

    Configuration.instance().set_use_default_values(True)
    get_workbench().clear_all_options()
    load_plugin()
    # Test runner
    from thonny.plugins.pgz.pgz_mode import get_current_value, toggl

# Generated at 2022-06-24 07:59:01.294175
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()

# Generated at 2022-06-24 07:59:02.361983
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:59:09.440465
# Unit test for function load_plugin
def test_load_plugin():
    # Basic mock objects
    import unittest.mock as mock

    mock_wb = mock.MagicMock()

    # Mocks for the two calls to get_workbench.set_default
    mock_get_workbench_set_default_1 = mock.Mock()
    type(mock_wb).set_default = mock_get_workbench_set_default_1

    # Mocks for the two calls to get_workbench.set_default
    mock_get_workbench_add_command = mock.Mock()
    type(mock_wb).add_command = mock_get_workbench_add_command
    mock_wb.in_simple_mode.return_value = False

    # Replace the global mock to enable the unit test
    get_workbench.get_workbench = lambda: mock_wb

    #

# Generated at 2022-06-24 07:59:11.889113
# Unit test for function toggle_variable
def test_toggle_variable():
    assert not get_workbench().get_variable(_OPTION_NAME).get()
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get()

# Generated at 2022-06-24 07:59:15.818090
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_runner
    from thonny.languages import rus
    get_workbench().set_simple_mode(False)
    load_plugin()
    assert hasattr(get_runner(), "toggle_pgzero_mode")

# Generated at 2022-06-24 07:59:19.544035
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert bool(get_workbench().get_option(_OPTION_NAME))
    toggle_variable()
    assert not bool(get_workbench().get_option(_OPTION_NAME))

# Generated at 2022-06-24 07:59:26.648856
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.reset_commands()

    wb.set_default(_OPTION_NAME, False)
    load_plugin()
    var = wb.get_variable(_OPTION_NAME)
    assert var.get() is False
    assert "PGZERO_MODE" in os.environ
    assert os.environ["PGZERO_MODE"] == "False"
    wb.languages["Python"].set_mode("Thonny")
    assert "PGZERO_MODE" not in os.environ
    wb.languages["Python"].set_mode("Simple")
    assert os.environ["PGZERO_MODE"] == "auto"


# Generated at 2022-06-24 07:59:33.678296
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    wb.set_simple_mode_on()
    toggle_variable()
    assert not wb.get_option(_OPTION_NAME)
    assert os.environ["PGZERO_MODE"] == "auto"
    toggle_variable()
    assert wb.get_option(_OPTION_NAME)
    assert os.environ["PGZERO_MODE"] == "1"

# Generated at 2022-06-24 07:59:39.473817
# Unit test for function toggle_variable
def test_toggle_variable():
    try:
        del os.environ["PGZERO_MODE"]
    except KeyError:
        pass

    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"

    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"

    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"

    os.environ["PGZERO_MODE"] = "some rubbish"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:59:45.132750
# Unit test for function toggle_variable
def test_toggle_variable():
    popup = Toplevel()
    popup.protocol("WM_DELETE_WINDOW", popup.withdraw)
    wb = Workbench(popup)
    toggle_variable()
    assert bool(wb.get_option(_OPTION_NAME)) == False

    toggle_variable()
    assert bool(wb.get_option(_OPTION_NAME)) == True

# Generated at 2022-06-24 07:59:54.707778
# Unit test for function toggle_variable
def test_toggle_variable():
    # Given:
    from unittest import mock

    wb = mock.Mock()
    wb.get_variable.return_value = False
    wb.get_option.return_value = False

    wb.add_variable.return_value = True
    wb.add_command.return_value = True
    with mock.patch("thonny.plugins.pgzero_mode.get_workbench", return_value=wb):
        # When:
        toggle_variable()

        # Then:
        wb.get_variable.assert_called_once_with(_OPTION_NAME)
        wb.get_variable.return_value.set.assert_called_once_with(True)

# Generated at 2022-06-24 08:00:01.078404
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"
    get_workbench().set_simple_mode(True)
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 08:00:12.400001
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    assert not wb.get_option(_OPTION_NAME)

    var = get_workbench().get_variable(_OPTION_NAME)

    load_plugin()
    assert wb.get_option(_OPTION_NAME) is False
    assert var.get() is False
    assert os.environ["PGZERO_MODE"] == "False"

    toggle_variable()
    assert wb.get_option(_OPTION_NAME) is True
    assert var.get() is True
    assert os.environ["PGZERO_MODE"] == "True"

    # Simple mode
    wb.set_in_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    load_plugin()

# Generated at 2022-06-24 08:00:22.897699
# Unit test for function load_plugin
def test_load_plugin():
    # noinspection PyTypeChecker
    wb = get_workbench()
    load_plugin()
    assert wb.default(_OPTION_NAME) is False
    assert wb.get_option(_OPTION_NAME) is False

    assert "toggle_pgzero_mode" in wb.application.commands
    assert {
        "name": "toggle_pgzero_mode",
        "label": tr("Pygame Zero mode"),
        "command": toggle_variable,
        "accelerator": "Alt-F1",
        "group": 40,
        "flag_name": _OPTION_NAME,
    } in wb.application.commands["toggle_pgzero_mode"].get_bindings()

    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    #

# Generated at 2022-06-24 08:00:33.252036
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.codeview import CodeViewText

    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == True
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()

# Generated at 2022-06-24 08:00:40.108149
# Unit test for function toggle_variable
def test_toggle_variable():
    """Tests that toggle_variable() works as expected."""

    # The "run" menu should not exist before loading the plugin, as this is
    # first run and it must be reloaded afterwards.
    if get_workbench().get_menu("run"):
        return ("The 'run' menu exists before loading the plugin, but it should "
                "not")

    # Load the plugin, so that a new "run" menu is created.
    load_plugin()

    # Find the toggle_pgzero_mode submenu in the "run" menu.
    for item in get_workbench().get_menu("run").get_children():
        if item.get_label() == "toggle_pgzero_mode":
            menu_item = item

    # Check that the menu item is initially set to False.

# Generated at 2022-06-24 08:00:49.235291
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny import get_workbench

    workbench = get_workbench()
    workbench.set_simple_mode(False)
    assert workbench.get_option(_OPTION_NAME) is False
    toggle_variable()
    assert workbench.get_option(_OPTION_NAME) is True
    toggle_variable()
    assert workbench.get_option(_OPTION_NAME) is False
    workbench.set_simple_mode(True)
    assert workbench.get_option(_OPTION_NAME) is False
    toggle_variable()
    assert workbench.get_option(_OPTION_NAME) is False
    workbench.set_simple_mode(False)
    assert workbench.get_option(_OPTION_NAME) is True

# Generated at 2022-06-24 08:00:54.011311
# Unit test for function load_plugin
def test_load_plugin():
	load_plugin()
	assert get_workbench().set_default(_OPTION_NAME, False)
	assert get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )

# Generated at 2022-06-24 08:00:54.538190
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()

# Generated at 2022-06-24 08:00:59.797330
# Unit test for function load_plugin
def test_load_plugin():
    workbench = thonny.workbench.TesterWorkbench()
    thonny.plugins.load_plugin_module("thonny_pgzero")
    workbench.post_init()

    workbench.set_default(_OPTION_NAME, False)
    assert workbench.get_option(_OPTION_NAME) == False

    workbench.execute("toggle_pgzero_mode")
    assert workbench.get_option(_OPTION_NAME) == True

# Generated at 2022-06-24 08:01:06.193255
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench
    from unittest.mock import Mock
    from thonny.plugins.pgzero.pgzero_mode import (
        toggle_variable,
        update_environment,
        load_plugin,
    )

    workbench = get_workbench()
    workbench.bind = Mock()
    workbench.set_default = Mock()
    workbench.add_command = Mock()
    workbench.in_simple_mode = Mock(return_value=True)
    workbench.get_option = Mock(return_value=True)
    load_plugin()
    assert workbench.set_default.call_count == 1
    assert workbench.add_command.call_count == 1


# Generated at 2022-06-24 08:01:16.564221
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny import THONNY_USER_DIR, get_runner
    from thonny.workbench import Workbench
    from thonny.workbench import _WorkbenchUI
    from thonny.globals import get_workbench
    from thonny.misc_utils import running_on_linux
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().events.create("ApplicationStartup")
    get_workbench().set_variable(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME) == True
    get_workbench().set_variable(_OPTION_NAME, True)
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME) == False
    # cleanup
   