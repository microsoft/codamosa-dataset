

# Generated at 2022-06-24 07:51:02.491264
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    var = wb.get_variable(_OPTION_NAME)
    var.set(False)
    toggle_variable()
    assert var.get() == True
    toggle_variable()
    assert var.get() == False

# Generated at 2022-06-24 07:51:10.675608
# Unit test for function update_environment
def test_update_environment():
    import os
    import os.path
    import tempfile
    import shutil

    path = tempfile.mkdtemp()
    os.makedirs(os.path.join(path, "thonny"))
    os.environ["THONNY_USER_DIR"] = path
    os.environ["PGZERO_MODE"] = "this will be overwritten"

    from unittest.mock import MagicMock
    from thonny.globals import get_workbench

    workbench = MagicMock()
    workbench.get_option = MagicMock()
    workbench.get_option.return_value = False
    workbench.in_simple_mode = True
    workbench.get_variable = MagicMock()
    workbench.get_variable.return_value = False

    get_workbench._

# Generated at 2022-06-24 07:51:17.036936
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_defaults(None)
    wb.set_defaults(
        {"run.pgzero_mode": False, "run.run_current_file": lambda: None, "ui.simple_mode": False}
    )
    load_plugin()
    assert not wb.get_option(_OPTION_NAME)
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:51:17.544883
# Unit test for function toggle_variable
def test_toggle_variable():
    pass

# Generated at 2022-06-24 07:51:23.967737
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.unregister_command("toggle_pgzero_mode")
    wb.set_option(_OPTION_NAME, False)
    del os.environ["PGZERO_MODE"]
    load_plugin()
    assert wb.get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"

    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    wb.set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    wb.in_simple_mode = lambda: True
    update_environment()
   

# Generated at 2022-06-24 07:51:28.669238
# Unit test for function toggle_variable
def test_toggle_variable():
    # Save current value of the variable
    current_value = get_workbench().get_variable(_OPTION_NAME).get()
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() != current_value
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == current_value

# Generated at 2022-06-24 07:51:34.933115
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    assert wb.get_variable(_OPTION_NAME).get() == False
    update_environment()
    toggle_variable()
    assert wb.get_variable(_OPTION_NAME).get() == True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert wb.get_variable(_OPTION_NAME).get() == False
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    wb.in_simple_mode = True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:51:41.075142
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.misc_utils import running_on_windows
    from thonny.misc_utils import running_on_mac_os
    from thonny.languages import DEFAULT_LANGUAGE
    from thonny import get_workbench
    from unittest.mock import patch

    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) is True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) is False

# Generated at 2022-06-24 07:51:50.387695
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.in_simple_mode = lambda: False

    # test simple mode
    wb.in_simple_mode = lambda: True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    # test non-simple mode
    wb.in_simple_mode = lambda: False
    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    wb.set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:51:54.829068
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-24 07:52:00.048217
# Unit test for function update_environment
def test_update_environment():
    set_option_in_prefs(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    set_option_in_prefs(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:52:11.355199
# Unit test for function load_plugin
def test_load_plugin():
    # The command should be added to the main menu
    assert "toggle_pgzero_mode" in get_workbench().get_commands()
    assert get_workbench().get_command("toggle_pgzero_mode") is not None

    # The variable should be changed after running it
    assert not get_workbench().get_option(_OPTION_NAME)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME)
    toggle_variable()
    assert not get_workbench().get_option(_OPTION_NAME)

    # TODO: should be tested in simple mode with a different plugin
    # Environment variable should be changed according to the variable
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()

# Generated at 2022-06-24 07:52:19.468370
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default(_OPTION_NAME, True)
    get_workbench().in_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().in_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().in_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:52:26.653593
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench
    from unittest.mock import Mock
    from thonny.codeview import CodeViewText
    from thonny.shell import ShellText
    from thonny.ui_utils import CommonDialog

    wb = get_workbench()
    wb.get_option = Mock(return_value=False) # pgzero_mode=off
    wb.get_editor_notebook = Mock(return_value=CodeViewText())
    wb.get_editor_notebook = Mock(return_value=ShellText())
    wb.in_simple_mode = Mock(return_value=False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"

    wb.get_option = Mock(return_value=True) # pgzero_

# Generated at 2022-06-24 07:52:32.772282
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()

# Generated at 2022-06-24 07:52:40.051001
# Unit test for function load_plugin
def test_load_plugin():
    test_wb = Mock(spec_set=Workbench)
    test_qvar = Mock()
    test_wb.get_option.return_value = True
    test_wb.get_variable.return_value = test_qvar
    test_wb.in_simple_mode.return_value = False
    test_wb.set_default.assert_called_once_with(_OPTION_NAME, False)
    test_wb.add_command.assert_called_once()
    assert os.environ["PGZERO_MODE"] == "True"



# Generated at 2022-06-24 07:52:43.605185
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    assert wb.get_option(_OPTION_NAME) == False
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == True
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == False

# Generated at 2022-06-24 07:52:46.620080
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True



# Generated at 2022-06-24 07:52:50.333684
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench

    workbench = Workbench()
    workbench._internal_commands = {}
    workbench._internal_flags = {}
    load_plugin()
    assert workbench._internal_commands != {}
    assert workbench._internal_flags != {}

# Generated at 2022-06-24 07:52:57.422769
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench
    from thonny.workbench import Workbench

    workbench = Workbench()
    workbench.set_default(_OPTION_NAME, True)
    workbench.add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    assert get_workbench().get_variable(_OPTION_NAME) is not None

if __name__ == "__main__":
    test_load_plugin()

# Generated at 2022-06-24 07:53:07.198133
# Unit test for function toggle_variable
def test_toggle_variable():
    from unittest.mock import patch

    from PyQt5.QtWidgets import QApplication

    from thonny import get_workbench
    from thonny.languages import tr
    from thonny.plugins.pgzero import toggle_variable

    app = QApplication([])

    # mock get_workbench() to return a mock object
    def mock_get_workbench():
        return MockWorkbench()

    def mock_set_option(var, val):
        MockWorkbench.options[var] = val

    # patch functions

# Generated at 2022-06-24 07:53:11.360741
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_option(_OPTION_NAME, False)
    assert get_workbench().get_option(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False



# Generated at 2022-06-24 07:53:16.456701
# Unit test for function toggle_variable
def test_toggle_variable():
    assert not get_workbench().get_variable(_OPTION_NAME).get()
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get()
    toggle_variable()
    assert not get_workbench().get_variable(_OPTION_NAME).get()

# Generated at 2022-06-24 07:53:20.748499
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = "auto"
    get_workbench().in_simple_mode = lambda: False
    get_workbench().get_option = lambda name: False
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"

# Generated at 2022-06-24 07:53:22.950050
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    load_plugin()
    assert "Pygame Zero mode" in wb.get_menu("run").get_children()[0].label

# Generated at 2022-06-24 07:53:31.025055
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = "auto"
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_option(_OPTION_NAME, False)
    get_workbench().set_simple_mode_for_tests()
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:53:34.422182
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_option(_OPTION_NAME, False)
    assert(get_workbench().get_option(_OPTION_NAME) == False)
    toggle_variable()
    assert(get_workbench().get_option(_OPTION_NAME) == True)
    toggle_variable()
    assert(get_workbench().get_option(_OPTION_NAME) == False)

# Generated at 2022-06-24 07:53:43.095292
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.ui_utils import toggle_checkbox
    from thonny import get_workbench
    from thonny.languages import tr

    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )

    assert os.environ["PGZERO_MODE"] == "auto"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:53:51.374681
# Unit test for function toggle_variable
def test_toggle_variable():
    from unittest.mock import Mock
    from thonny.workbench import Workbench

    get_workbench = Mock()
    get_workbench.get_variable = Mock(
        return_value=Mock(get=False, set=Mock(return_value=None))
    )
    get_workbench.in_simple_mode = Mock(return_value=False)
    get_workbench.get_option = Mock(return_value=True)
    Workbench.get_instance = Mock(return_value=get_workbench)

    toggle_variable()
    get_workbench.get_variable().set.assert_called_once_with(True)



# Generated at 2022-06-24 07:53:56.057746
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, True)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:54:00.906325
# Unit test for function update_environment
def test_update_environment():
    assert os.environ.get("PGZERO_MODE") is None
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"



# Generated at 2022-06-24 07:54:09.672126
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.misc_utils import running_on_mac_os
    from thonny.misc_utils import running_on_windows

    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)

    assert wb.get_option(_OPTION_NAME) == False
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == True
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == False
    if running_on_mac_os:
        assert os.environ["PGZERO_MODE"] == "auto"
    else:
        assert os.environ["PGZERO_MODE"] == "False"
    wb.set_simple_mode(True)
    update

# Generated at 2022-06-24 07:54:19.134488
# Unit test for function update_environment
def test_update_environment():
    from thonny.plugins.pgzero_mode_plugin import _OPTION_NAME
    from thonny import get_workbench
    from unittest.mock import MagicMock
    get_workbench().set_default(_OPTION_NAME, True)
    get_workbench().set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_simple_mode(False)

# Generated at 2022-06-24 07:54:22.747495
# Unit test for function update_environment
def test_update_environment():
    assert os.environ.get("PGZERO_MODE", "") == "False"
    update_environment()
    assert os.environ.get("PGZERO_MODE", "") == "False"

# Generated at 2022-06-24 07:54:29.523893
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ['PGZERO_MODE'] == 'True'

    get_workbench().set_simple_mode(True)
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ['PGZERO_MODE'] == 'auto'

# Generated at 2022-06-24 07:54:36.557926
# Unit test for function toggle_variable
def test_toggle_variable():
    from unittest.mock import Mock

    wb=Mock()
    init_var = False
    wb.get_variable=lambda x, y=None: init_var
    wb.get_option=lambda x, y=None: init_var
    wb.in_simple_mode = lambda : False
    set_var = lambda x: (wb.get_variable.return_value.set(x), {})

    wb.set_default=lambda name, val: set_var(val)
    wb.add_command=lambda cmd, cat, name, handler, accel="", flag_name=None, group=10, default_sequence="", **kwargs: (
        handler(), {}
    )

    # Test that toggle_variable toggles variable
    get_workbench.return_value = wb
   

# Generated at 2022-06-24 07:54:40.314625
# Unit test for function update_environment
def test_update_environment():
    from thonny.ui_utils import ask_for_string
    from thonny import workbench

    workbench.set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    workbench.set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:54:44.394145
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    var = wb.get_variable(_OPTION_NAME)
    var.set(False)
    
    # Test 1
    toggle_variable()
    assert var.get() == True
    
    # Test 2
    toggle_variable()
    assert var.get() == False
    
    # Test 3
    toggle_variable()
    assert var.get() == True

# Generated at 2022-06-24 07:54:53.193771
# Unit test for function toggle_variable
def test_toggle_variable():
    from unittest.mock import Mock
    from pytest import raises

    os.environ["PGZERO_MODE"] = "auto"
    wb = Mock()
    wb.in_simple_mode.return_value = True
    get_workbench.cache_clear()
    get_workbench.cache_by(lambda: wb)

    # toggle variable to True
    toggle_variable()

    assert os.environ["PGZERO_MODE"] == "True"

    # toggle variable to False
    toggle_variable()

    assert os.environ["PGZERO_MODE"] == "False"

    # toggle variable to True
    toggle_variable()

    assert os.environ["PGZERO_MODE"] == "True"

    # toggle variable to True

# Generated at 2022-06-24 07:55:03.085714
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    var = wb.get_variable(_OPTION_NAME)
    var.set(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    var.set(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    # simple mode
    wb.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    wb.set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:55:03.925597
# Unit test for function update_environment
def test_update_environment():
    # No-op as an optional extension
    pass

# Generated at 2022-06-24 07:55:10.924938
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock

    get_workbench = Mock()

    testee = Mock()
    testee.set_default = Mock()
    testee.add_command = Mock()

    get_workbench.return_value = testee

    load_plugin()

    get_workbench.assert_called_with()
    testee.set_default.assert_called_with(_OPTION_NAME, False)
    testee.add_command.assert_called_with(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )

# Generated at 2022-06-24 07:55:15.307423
# Unit test for function toggle_variable
def test_toggle_variable():
    from unittest.mock import Mock

    get_workbench = Mock()
    get_workbench.get_variable.return_value.get.return_value = False

    toggle_variable()

    get_workbench.get_variable.return_value.set.assert_called_with(True)

# Generated at 2022-06-24 07:55:18.501489
# Unit test for function toggle_variable
def test_toggle_variable():
    var = get_workbench().get_variable(_OPTION_NAME)
    get_workbench().set_default(_OPTION_NAME, True)
    toggle_variable()
    assert var.get() == False

# Generated at 2022-06-24 07:55:27.012623
# Unit test for function update_environment
def test_update_environment():
    # As pygamezero is loaded dynamically, it has to be imported here
    import pygamezero as pgz
    # Need to import backend to set simple mode
    import thonny.backend
    get_workbench().set_option(_OPTION_NAME, False)
    get_workbench().in_simple_mode = lambda: False
    update_environment()
    assert os.environ["PGZERO_MODE"] == str(False)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == str(True)
    get_workbench().in_simple_mode = lambda: True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:55:33.679869
# Unit test for function load_plugin
def test_load_plugin():
    try:
        import tkinter as tk
    except:
        import Tkinter as tk

    root = tk.Tk()
    root.withdraw()
    workbench = get_workbench()
    workbench.create_window(root)
    load_plugin()
    assert workbench.get_default(_OPTION_NAME) == False
    assert workbench.get_option(_OPTION_NAME) == False

    toggle_variable()
    assert workbench.get_option(_OPTION_NAME) == True
    assert os.getenv("PGZERO_MODE") == "True"

# Generated at 2022-06-24 07:55:38.917792
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_default(_OPTION_NAME, True)
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:55:41.349779
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:55:44.854548
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    assert wb.get_option(_OPTION_NAME) == False
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == True
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == False

# Generated at 2022-06-24 07:55:54.049961
# Unit test for function update_environment
def test_update_environment():
    get_workbench().in_simple_mode = lambda: False
    get_workbench().get_variable = lambda x: x
    get_workbench().get_option = lambda x: True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"

    get_workbench().get_option = lambda x: False
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"

    get_workbench().in_simple_mode = lambda: True
    get_workbench().get_option = lambda x: True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:56:00.401023
# Unit test for function update_environment
def test_update_environment():
    from thonny.shell import Shell

    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().set_simple_mode(False)

    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:56:05.347350
# Unit test for function toggle_variable
def test_toggle_variable():
    kb_event_string("::Alt+R", {"::Alt"})
    find_in_tree("Toggle Pygame Zero mode")
    assert get_workbench().get_option(_OPTION_NAME) == True
    kb_event_string("::Alt+R", {"::Alt"})
    assert get_workbench().get_option(_OPTION_NAME) == False


# Generated at 2022-06-24 07:56:14.875372
# Unit test for function toggle_variable

# Generated at 2022-06-24 07:56:18.184313
# Unit test for function load_plugin
def test_load_plugin():
    # pylint: disable=unused-variable
    # This is here just to test if loading the plugin is successful
    b = get_workbench().get_variable(_OPTION_NAME)

# Generated at 2022-06-24 07:56:23.836660
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = "auto"
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"

    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] 

# Generated at 2022-06-24 07:56:26.221117
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME)

# Generated at 2022-06-24 07:56:32.715857
# Unit test for function toggle_variable
def test_toggle_variable():
    old_value = os.environ['PGZERO_MODE']
    toggle_variable()
    assert(os.environ['PGZERO_MODE'] == 'True')
    toggle_variable()
    assert(os.environ['PGZERO_MODE'] == 'False')
    toggle_variable()
    assert(os.environ['PGZERO_MODE'] == 'True')
    toggle_variable()
    assert(os.environ['PGZERO_MODE'] == 'False')
    toggle_variable()
    assert(os.environ['PGZERO_MODE'] == 'True')
    os.environ['PGZERO_MODE'] = old_value
    tmb = get_workbench()
    old_value_var = tmb.get_variable("run.pgzero_mode")
    toggle_variable()

# Generated at 2022-06-24 07:56:38.149831
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import patch
    from thonny.globals import get_workbench
    from thonny.config import get_config_dir
    get_workbench().set_default(_OPTION_NAME, True)

    with patch.dict(os.environ, {}):
        update_environment()
        assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:56:48.517376
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import Mock, patch

    workbench = Mock()

    workbench.get_option.return_value = True
    with patch.dict("os.environ", {"PGZERO_MODE": ""}, clear=True):
        update_environment()
        assert os.environ["PGZERO_MODE"] == "True"

    workbench.get_option.return_value = False
    with patch.dict("os.environ", {"PGZERO_MODE": ""}, clear=True):
        update_environment()
        assert os.environ["PGZERO_MODE"] == "False"

    workbench.in_simple_mode.return_value = True
    with patch.dict("os.environ", {"PGZERO_MODE": ""}, clear=True):
        update_environment()
        assert os.environ

# Generated at 2022-06-24 07:56:52.833578
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    assert wb.get_option(_OPTION_NAME) == False
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == True
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == False

# Generated at 2022-06-24 07:56:56.878235
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import MagicMock
    
    workbench = MagicMock()
    workbench.get_default.return_value = False
    workbench.get_option.return_value = False
    workbench.in_simple_mode.return_value = False
    get_workbench.return_value = workbench
    
    os.environ = {}
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:56:57.947549
# Unit test for function toggle_variable
def test_toggle_variable():
    assert toggle_variable() is None


# Generated at 2022-06-24 07:57:05.281957
# Unit test for function toggle_variable
def test_toggle_variable():
    gui_mock = get_runner().get_runner(
        os.path.join(os.path.dirname(__file__), "..", ".."), ["python", "run_tests.py", "test_pgzero_mode"]
    )
    gui_mock.text_insert = lambda dummy, text: print(text)
    assert get_workbench().in_simple_mode()
    toggle_variable()
    assert not get_workbench().get_option(_OPTION_NAME)
    assert "PGZERO_MODE=False" in gui_mock.test_output
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME)
    assert "PGZERO_MODE=True" in gui_mock.test_output
    assert get_workbench().in_simple_mode()
   

# Generated at 2022-06-24 07:57:14.340578
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:57:19.678704
# Unit test for function toggle_variable
def test_toggle_variable():
    #Tests the most importent part of the function
    var = get_workbench().get_variable(_OPTION_NAME)
    var.set(True)
    toggle_variable()
    assert var.get() == False
    toggle_variable()
    assert var.get() == True


# Generated at 2022-06-24 07:57:25.124669
# Unit test for function toggle_variable
def test_toggle_variable():
    if _OPTION_NAME in get_workbench().config:
        del get_workbench().config[_OPTION_NAME]
    get_workbench().config.save()
    assert get_workbench().get_variable(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME) == False

# Generated at 2022-06-24 07:57:29.900447
# Unit test for function toggle_variable
def test_toggle_variable():
    assert get_workbench().in_simple_mode()
    assert not get_workbench().get_option(_OPTION_NAME)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME)
    toggle_variable()
    assert not get_workbench().get_option(_OPTION_NAME)

# Generated at 2022-06-24 07:57:35.384824
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)

    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:57:45.210814
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.plugins.pgzero_mode import _OPTION_NAME, load_plugin
    import unittest.mock
    from thonny.workbench import Workbench
    from unittest.mock import MagicMock

    wb = Workbench()
    wb.set_default = MagicMock()
    wb.add_command = MagicMock()
    load_plugin()

    # Check that option is created
    wb.set_default.assert_called_once_with(_OPTION_NAME, False)

    # Check that toggle button is created

# Generated at 2022-06-24 07:57:49.468549
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, True)

    assert os.environ["PGZERO_MODE"] == "True"

    toggle_variable()

    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:57:54.027439
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-24 07:57:58.909233
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().unset_default("view.interpreter_name")
    load_plugin()
    assert len(get_workbench().default_config["run"]) == 1 # no old commands
    assert "pgzero_mode" in get_workbench().default_config

# Generated at 2022-06-24 07:58:01.205064
# Unit test for function update_environment
def test_update_environment():
    assert os.getenv("PGZERO_MODE") == "auto"
    os.environ["PGZERO_MODE"] = ""
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.getenv("PGZERO_MODE") == "False"

# Generated at 2022-06-24 07:58:03.621094
# Unit test for function update_environment
def test_update_environment():
    expected_env = os.environ.copy()
    expected_env["PGZERO_MODE"] = "False"
    assert update_environment() == expected_env



print("imported pgzero_mode_checkbox")

# Generated at 2022-06-24 07:58:09.949740
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_in_simple_mode(True)
    load_plugin()
    assert wb.get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "auto"
    wb.set_in_simple_mode(False)
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"
    wb.set_in_simple_mode(True)
    assert wb.get_option(_OPTION_NAME) == False

# Generated at 2022-06-24 07:58:13.951316
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == False


if __name__ == "__main__":
    # print(test_load_plugin())
    load_plugin()

# Generated at 2022-06-24 07:58:18.723231
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_simple_mode(True)
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:58:20.922433
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert "pgzero_mode" in get_workbench().get_variable(_OPTION_NAME).get()

# Generated at 2022-06-24 07:58:22.303823
# Unit test for function load_plugin
def test_load_plugin():
    assert "toggle_pgzero_mode" in get_workbench().commands


# Generated at 2022-06-24 07:58:31.476339
# Unit test for function update_environment
def test_update_environment():
    # Test simple mode
    wb = get_workbench()
    wb._set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    # Test normal mode
    wb._set_simple_mode(False)
    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    wb.set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:58:32.800415
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.misccommands import reset_workbench
    reset_workbench()
    load_plugin()

# Generated at 2022-06-24 07:58:34.911423
# Unit test for function update_environment
def test_update_environment():
    try:
        get_workbench().in_simple_mode = lambda: True
        update_environment()
        assert os.environ["PGZERO_MODE"] == "auto"
    finally:
        get_workbench().in_simple_mode = lambda: False

# Generated at 2022-06-24 07:58:42.599899
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.workbench import Workbench
    from thonny import get_shell
    from thonny.shell import ShellTextWidget

    # open a shell
    get_workbench().event_generate("<<NewWindow>>", window_type="Shell")
    shell = [w for w in get_workbench().children if isinstance(w, ShellTextWidget)][0]

    # set PGZERO env. var.
    os.environ["PGZERO_MODE"] = "True"

    # test if env. var. is set
    assert os.environ["PGZERO_MODE"] == "True"

    # run the test function
    toggle_variable()

    # test if env. var. is changed
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:58:47.853186
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, True)
    assert get_workbench().get_variable(_OPTION_NAME).get()
    toggle_variable()
    assert not get_workbench().get_variable(_OPTION_NAME).get()
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get()

# Generated at 2022-06-24 07:58:53.698977
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    var = wb.get_variable(_OPTION_NAME)
    assert var.get() == 0
    get_workbench().in_simple_mode = True
    toggle_variable()
    assert var.get() == 1
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().in_simple_mode = False
    toggle_variable()
    assert var.get() == 0
    assert os.environ["PGZERO_MODE"] == "0"

# Generated at 2022-06-24 07:58:59.287050
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench
    from thonny.misc_utils import running_on_mac_os
    load_plugin()
    assert "PGZERO_MODE" in os.environ
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"
    assert not running_on_mac_os()


# Generated at 2022-06-24 07:59:06.648055
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.set_variable(_OPTION_NAME, False)
    toggle_variable()
    assert wb.get_variable(_OPTION_NAME) is True
    toggle_variable()
    assert wb.get_variable(_OPTION_NAME) is False
    os.environ["PGZERO_MODE"] = "False"
    toggle_variable()
    assert wb.get_variable(_OPTION_NAME) is True
    assert os.environ["PGZERO_MODE"] == "True"
    wb.destroy()



# Generated at 2022-06-24 07:59:15.343002
# Unit test for function load_plugin
def test_load_plugin():
    try:
        del os.environ["PGZERO_MODE"]
    except KeyError:
        pass

    # Test if Pygame Zero mode is enabled by default
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_default(_OPTION_NAME, True)
    load_plugin()
    assert "PGZERO_MODE" in os.environ
    assert os.environ["PGZERO_MODE"] == "True"

    # Test if Pygame Zero mode gets disabled if the workbench is in simple mode
    wb.set_default(_OPTION_NAME, False)
    wb.set_in_simple_mode(True)
    load_plugin()
    assert "PGZERO_MODE" in os.environ
    assert os.environ["PGZERO_MODE"]

# Generated at 2022-06-24 07:59:22.867201
# Unit test for function update_environment
def test_update_environment():
    from thonny.globals import get_runner, get_shell
    from thonny import get_workbench
    from thonny.globals import get_runner, get_shell

    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"


if __name__ == "__main__":
    test

# Generated at 2022-06-24 07:59:25.488972
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny import get_workbench

    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) is True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) is False



# Generated at 2022-06-24 07:59:31.820601
# Unit test for function toggle_variable
def test_toggle_variable():
    try:
        if "PGZERO_MODE" in os.environ:
            del os.environ["PGZERO_MODE"]

        toggle_variable()
        assert os.environ["PGZERO_MODE"] == "True"

        toggle_variable()
        assert os.environ["PGZERO_MODE"] == "False"
    finally:
        del os.environ["PGZERO_MODE"]

# Generated at 2022-06-24 07:59:33.474757
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()



# Generated at 2022-06-24 07:59:38.530680
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench
    from thonny.workbench import Workbench
    wb = Workbench()
    assert wb.get_option(_OPTION_NAME) == False
    update_environment()
    assert os.environ.get("PGZERO_MODE") == "False"
    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ.get("PGZERO_MODE") == "True"

# Generated at 2022-06-24 07:59:46.120252
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:59:48.102842
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    
    
if __name__ == "__main__":
    test_load_plugin()

# Generated at 2022-06-24 07:59:54.049868
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()
    assert get_workbench().get_option('run.pgzero_mode') == True

    toggle_variable()
    assert get_workbench().get_option('run.pgzero_mode') == False

    get_workbench().set_option('run.pgzero_mode', True)
    assert get_workbench().get_option('run.pgzero_mode') == True


# Generated at 2022-06-24 07:59:55.122017
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().add_command
    assert True

# Generated at 2022-06-24 08:00:00.351949
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import Mock
    workbench = Mock()
    workbench.in_simple_mode = Mock(return_value=False)
    workbench.get_option = Mock(return_value=False)
    get_workbench = Mock(return_value=workbench)
    with patch("thonny.plugins.pgzero_mode.get_workbench", get_workbench):
        update_environment()
        assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 08:00:05.417501
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    assert get_workbench().get_option(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-24 08:00:14.004732
# Unit test for function update_environment
def test_update_environment():
    os.environ.pop("PGZERO_MODE", None)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 08:00:20.466133
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert not os.environ["PGZERO_MODE"]

    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"]

    get_workbench().in_simple_mode(True)
    update_environment()
    assert not os.environ["PGZERO_MODE"]

# Generated at 2022-06-24 08:00:28.244613
# Unit test for function update_environment
def test_update_environment():
    # function should set environment variable PGZERO_MODE to on
    os.environ["PGZERO_MODE"] = None
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "on"

    # function should set environment variable PGZERO_MODE to off
    os.environ["PGZERO_MODE"] = None
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "off"



# Generated at 2022-06-24 08:00:32.071072
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_option(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME)
    toggle_variable()
    assert not get_workbench().get_option(_OPTION_NAME)

# Generated at 2022-06-24 08:00:35.624164
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_option("run.pgzero_mode", False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_option("run.pgzero_mode", True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 08:00:42.831831
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = "False"
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"]== "auto"
    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"]== "True"

# Generated at 2022-06-24 08:00:45.067128
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_option(_OPTION_NAME, True)
    toggle_variable()
    assert not get_workbench().get_option(_OPTION_NAME)

# Generated at 2022-06-24 08:00:49.781615
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == str(get_workbench().get_option(_OPTION_NAME))

# Generated at 2022-06-24 08:00:55.518644
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = "something"
    get_workbench().in_simple_mode = lambda: False
    get_workbench().get_option = lambda x: True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().in_simple_mode = lambda: True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 08:00:59.840169
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    assert get_workbench().get_option(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False