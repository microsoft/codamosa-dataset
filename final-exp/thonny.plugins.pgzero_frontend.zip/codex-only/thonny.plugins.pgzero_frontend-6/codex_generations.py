

# Generated at 2022-06-24 07:51:14.743405
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    wb.set_simple_mode(True)
    wb.set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    wb.set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"

    wb.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:51:19.500219
# Unit test for function toggle_variable
def test_toggle_variable():
    # No function testing needed since it just calls a setter.
    # However, it is needed to test when toggle_variable is called from Thonny.
    wb = get_workbench()
    var = wb.get_variable(_OPTION_NAME)
    toggle_variable()
    var.set(True)
    toggle_variable()

# Generated at 2022-06-24 07:51:27.966120
# Unit test for function load_plugin
def test_load_plugin():
    class Mock:
        def in_simple_mode(self):
            return True

        def get_option(self, *args, **kwargs):
            return False

        def set_default(self, *args, **kwargs):
            pass

        def get_variable(self, *args, **kwargs):
            return Mock()

        def get(self):
            return True

        def set(self, *args, **kwargs):
            pass

        def add_command(self, *args, **kwargs):
            pass

    load_plugin()

if __name__ == "__main__":
    test_load_plugin()

# Generated at 2022-06-24 07:51:38.682244
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    wb.set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    wb.in_simple_mode = lambda: True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    wb.in_simple_mode = lambda: False
    wb.set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:51:47.873756
# Unit test for function toggle_variable
def test_toggle_variable():
    try:
        import pygame
    except:
        pygame = None
    if pygame is not None:
        pygame.init()
        import pgzero
        pgzero.PGZeroGame.update_screen = lambda self: None
        get_workbench().set_simple_mode(False)
        toggle_variable()
        assert get_workbench().in_simple_mode()
        toggle_variable()
        assert not get_workbench().in_simple_mode()
        pgzero.screen = None


if __name__ == "__main__":
    test_toggle_variable()

# Generated at 2022-06-24 07:51:48.777298
# Unit test for function toggle_variable
def test_toggle_variable():
	toggle_variable()

# Generated at 2022-06-24 07:51:55.622485
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == False
    get_workbench().set_default(_OPTION_NAME, 'test')
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == 'test'

# Generated at 2022-06-24 07:51:58.439217
# Unit test for function update_environment
def test_update_environment():
    for value in (True, False, "auto"):
        get_workbench().set_option(_OPTION_NAME, value)
        update_environment()
        assert os.environ["PGZERO_MODE"] == str(value)

# Generated at 2022-06-24 07:52:05.686903
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    
    load_plugin()
    
    assert wb.get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"
    
    wb.set_option(_OPTION_NAME, True)
    
    assert wb.get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:52:12.169820
# Unit test for function load_plugin
def test_load_plugin():
    # Check resetting environment to 'off'
    os.environ["PGZERO_MODE"] = "true"
    load_plugin()
    assert os.environ["PGZERO_MODE"] == "False"
    # Check resetting environment to 'on'
    os.environ["PGZERO_MODE"] = "false"
    get_workbench().set_option(_OPTION_NAME, True)
    load_plugin()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:52:21.843539
# Unit test for function toggle_variable

# Generated at 2022-06-24 07:52:31.193825
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.globals import get_workbench, get_runner
    from thonny.common import InlineCommand

    def get_pgz_cmd(cmd):
        assert len(cmd.subprocess_args) > 0
        pgz_cmd = None
        for x in cmd.subprocess_args:
            if x == "pgzrun":
                pgz_cmd = x
            elif x.endswith("pgzrun"):
                pgz_cmd = x
        return pgz_cmd

    def check_pgz_cmd(cmd, expected_value):
        if expected_value:
            assert get_pgz_cmd(cmd) is not None
        else:
            assert get_pgz_cmd(cmd) is None

    get_workbench().set_option(_OPTION_NAME, False)


# Generated at 2022-06-24 07:52:41.307710
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import Mock
    from thonny import get_workbench, ui_utils
    from thonny.languages import tr
    from thonny.ui_utils import CommonDialog
    from tkinter import Tk

    class Util:
        def get_option(self, key):
            return self.options.get(key)

        def set_option(self, key, val):
            self.options[key] = val

        def __init__(self):
            self.options={}

    class Observer:
        def __init__(self):
            self.changes = []

        def trace(self, frame, event, arg):
            if event != "call":
                return
            co = frame.f_code
            func_name = co.co_name

# Generated at 2022-06-24 07:52:44.326612
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-24 07:52:52.713920
# Unit test for function update_environment
def test_update_environment():
    del os.environ["PGZERO_MODE"]
    get_workbench().set_in_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert "PGZERO_MODE" not in os.environ

    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True" # string, not boolean

    get_workbench().set_in_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:52:59.314713
# Unit test for function toggle_variable
def test_toggle_variable():
    import unittest.mock
    my_wb = get_workbench()
    my_wb.add_variable(_OPTION_NAME, False)

    with unittest.mock.patch.dict(os.environ, {"PGZERO_MODE": "auto"}):
        toggle_variable()
        assert my_wb.get_variable(_OPTION_NAME).get() is True
        assert os.environ["PGZERO_MODE"] == "True"
        toggle_variable()
        assert my_wb.get_variable(_OPTION_NAME).get() is False
        assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:53:08.459152
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import workbench
    from thonny.config import get_workbench_configuration
    from thonny.common import TCONFIG

    # Mock workbench configuration
    workbench.get_workbench_configuration = lambda: get_workbench_configuration()
    # Mock TCONFIG
    TCONFIG = {
        "theme": "default",
        "autostart_shell_upon_startup": True,
        "show_startup_time": False,
        "scale_factor": 1.0,
        "ui_language": None,
        "simple_mode": False,
        "auto_save": True,
        "auto_save_interval": 5,
    }

    load_plugin()

# Generated at 2022-06-24 07:53:10.011304
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == True

# Generated at 2022-06-24 07:53:12.871673
# Unit test for function update_environment
def test_update_environment():
    from mock import Mock

    wb = Mock()
    wb.get_option.return_value = False
    wb.in_simple_mode.return_value = False
    
    os.environ["PGZERO_MODE"] = "auto"
    update_envir

# Generated at 2022-06-24 07:53:16.335062
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.unset_option(_OPTION_NAME)
    load_plugin()
    assert wb.get_option(_OPTION_NAME) == False
    assert "PGZERO_MODE" in os.environ

# Generated at 2022-06-24 07:53:20.980773
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:53:23.610011
# Unit test for function toggle_variable
def test_toggle_variable():
    assert get_workbench().get_variable(_OPTION_NAME) == False

    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME) == True

    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME) == False


# Generated at 2022-06-24 07:53:29.539364
# Unit test for function load_plugin
def test_load_plugin():
    wb = MockWorkbench()
    wb.set_default(_OPTION_NAME, False)

    load_plugin()

    wb.get_option(_OPTION_NAME)
    wb.add_command.assert_called_once_with(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )

# Generated at 2022-06-24 07:53:35.933803
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    wb.set_in_simple_mode(True)
    
    assert 'PGZERO_MODE' in os.environ
    os.environ["PGZERO_MODE"] = "auto"
    assert os.environ["PGZERO_MODE"] == "auto"

    wb.set_in_simple_mode(False)
    assert not wb.get_option(_OPTION_NAME)
    toggle_variable()
    assert wb.get_option(_OPTION_NAME)
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert wb.get_option(_OPTION_NAME)
    assert os.environ["PGZERO_MODE"] == "False"


# Generated at 2022-06-24 07:53:36.822341
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = "auto"
    update_environment()

# Generated at 2022-06-24 07:53:45.002301
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import MagicMock, call
    from thonny import get_workbench
    
    wb = MagicMock()
    wb.in_simple_mode.return_value = False
    wb.get_option.return_value = True
    
    get_workbench.return_value = wb
    update_environment()
    os.environ["PGZERO_MODE"] = "True"

    wb.assert_has_calls([call.in_simple_mode(), call.get_option(_OPTION_NAME)])
    assert wb.mock_calls == wb.get_option.mock_calls == wb.in_simple_mode.mock_calls
    
    wb.reset_mock()

# Generated at 2022-06-24 07:53:54.294398
# Unit test for function update_environment
def test_update_environment():
    from thonny.ui_utils import show_dialog
    from thonny import get_workbench

    def restore_defaults():
        get_workbench().set_default(_OPTION_NAME, False)

    def test_case(in_simple_mode, option_value, expected_env_value):
        get_workbench().set_simple_mode(in_simple_mode)
        get_workbench().set_option(_OPTION_NAME, option_value)
        update_environment()
        assert os.environ["PGZERO_MODE"] == expected_env_value, (
            "Wrong value read from environment."
        )

    # Part 1: Simple mode
    for option in [True, False]:
        test_case(True, option, "auto")

    # Part 2: Not in simple mode

# Generated at 2022-06-24 07:53:59.533033
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    load_plugin()

    assert _OPTION_NAME in wb
    assert wb.get_option(_OPTION_NAME) is False
    assert "PGZERO_MODE" in os.environ
    os.environ.pop("PGZERO_MODE")


if __name__ == "__main__":
    test_load_plugin()

# Generated at 2022-06-24 07:54:03.693871
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-24 07:54:08.977369
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    assert not get_workbench().get_option(_OPTION_NAME)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME)
    toggle_variable()
    assert not get_workbench().get_option(_OPTION_NAME)


load_plugin()

# Generated at 2022-06-24 07:54:18.324506
# Unit test for function load_plugin
def test_load_plugin():
    print(get_workbench().get_option(_OPTION_NAME))
    assert not get_workbench().get_option(_OPTION_NAME)
    assert "false" == os.environ["PGZERO_MODE"]
    
    get_workbench().set_default(_OPTION_NAME, True)
    
    load_plugin()
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME)
    assert "false" == os.environ["PGZERO_MODE"]
    
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    toggle_variable()
    assert not get_workbench().get_option(_OPTION_NAME)
    assert "false" == os.environ["PGZERO_MODE"]

# Generated at 2022-06-24 07:54:24.142979
# Unit test for function update_environment
def test_update_environment():
    os.environ.pop("PGZERO_MODE", None)
    del os.environ["PGZERO_MODE"]
    assert "PGZERO_MODE" not in os.environ
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"


if __name__ == "__main__":
    load_plugin()
    get_workbench().run_command("toggle_pgzero_mode")

# Generated at 2022-06-24 07:54:33.751149
# Unit test for function update_environment
def test_update_environment():
    from unittest import mock
    import os
    import builtins
    from thonny import get_workbench, THONNY_USER_DIR
    from test.test_config_page import deactivate_gettext
    from thonny.plugins.pgzero_mode import update_environment

    os.environ.pop("PGZERO_MODE", None)
    with mock.patch.object(builtins, "input", return_value="y"):
        get_workbench().set_option(_OPTION_NAME, True)
        update_environment()
        assert os.environ["PGZERO_MODE"] == "auto"
        get_workbench().set_option(_OPTION_NAME, False)
        update_environment()
        assert os.environ["PGZERO_MODE"] == "0"

    get_workbench().set

# Generated at 2022-06-24 07:54:39.928284
# Unit test for function toggle_variable
def test_toggle_variable():
    def dummy_get_variable(name):
        return True
    
    def dummy_set_variable(name, value):
        if value:
            dummy_get_variable.result = "True"
        else: 
            dummy_get_variable.result = "False"
    
    get_workbench.result = {'get_variable': dummy_get_variable, 'set_variable': dummy_set_variable}
    toggle_variable()
    assert dummy_get_variable.result == "False"



# Generated at 2022-06-24 07:54:43.885103
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    assert _OPTION_NAME in get_workbench().get_default_options()
    assert not get_workbench().get_option(_OPTION_NAME)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME)
    toggle_variable()


# Generated at 2022-06-24 07:54:52.019939
# Unit test for function update_environment
def test_update_environment():
    global os
    os = get_runner().get_virtual_os()
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"


load_plugin()

# Generated at 2022-06-24 07:54:58.679439
# Unit test for function load_plugin
def test_load_plugin():
    # Inside the unit test any existing plugin is unloaded.
    wb = get_workbench()
    wb.unload_plugin("thonny.plugins.pgzero_mode")
    wb.unload_plugin("thonny.plugins.pgzero_mode.pgzero_mode")
    assert not wb.in_simple_mode()
    load_plugin()
    assert wb.get_command("toggle_pgzero_mode")

# Generated at 2022-06-24 07:55:07.046856
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"

    # !EEW - get_workbench().set_default(_OPTION_NAME, True)
    # !EEW - update_environment()
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().enter_simple_mode()
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:55:10.521687
# Unit test for function toggle_variable
def test_toggle_variable():
    
    workbench = get_workbench()
    var = workbench.get_variable(_OPTION_NAME)
    assert var.get() == False

    toggle_variable()

    assert var.get() == True

    toggle_variable()

    assert var.get() == False


# Generated at 2022-06-24 07:55:13.168501
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.set_option(_OPTION_NAME, True)
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:55:18.653734
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert get_workbench().get_default("run.pgzero_mode", False) == False
    assert get_workbench().get_option("run.pgzero_mode", False) == False
    assert get_workbench().get_default("run.pgzero_mode", True) == True
    assert get_workbench().get_option("run.pgzero_mode", True) == True
    assert os.environ["PGZERO_MODE"] == "False"
    load_plugin()
    assert get_workbench().get_default("run.pgzero_mode", False) == False
    assert get_workbench().get_option("run.pgzero_mode", False) == False
    assert get_workbench().get_default("run.pgzero_mode", True) == True
    assert get_workbench().get

# Generated at 2022-06-24 07:55:27.160224
# Unit test for function toggle_variable
def test_toggle_variable():
    # test for default value
    os.environ["PGZERO_MODE"] = "auto"
    var = get_workbench().get_variable(_OPTION_NAME)
    var.set(False)
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "auto"
    # test for True
    os.environ["PGZERO_MODE"] = "auto"
    var.set(True)
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "1"
    # test for False
    os.environ["PGZERO_MODE"] = "auto"
    var.set(False)
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:55:28.477597
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert get_workbench().get_variable(_OPTION_NAME)



# Generated at 2022-06-24 07:55:36.770637
# Unit test for function update_environment
def test_update_environment():
    class WB():
        def __init__(self):
            self._variables = {}

        def get_option(self, name):
            return self._variables[name]

        def get_variable(self, name):
            return self._variables[name]

        def in_simple_mode(self):
            return False

        def set_default(self, name, default):
            self._variables[name] = default

    wb = WB()
    wb._variables[_OPTION_NAME] = True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    wb._variables[_OPTION_NAME] = False
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"


# Generated at 2022-06-24 07:55:39.837261
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == True

    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == False

# Generated at 2022-06-24 07:55:46.209669
# Unit test for function update_environment
def test_update_environment():
    run_bgi = get_workbench().get_option("run.bgi")
    get_workbench().set_option("run.bgi", False)
    update_environment()
    assert os.environ.get("PGZERO_MODE", "auto") == "auto"

    toggle_variable()
    update_environment()
    assert os.environ.get("PGZERO_MODE", "auto") == "True"

    get_workbench().set_option("run.bgi", True)
    update_environment()
    assert os.environ.get("PGZERO_MODE", "auto") == "False"

    get_workbench().set_option("run.bgi", run_bgi)

# Generated at 2022-06-24 07:55:51.061881
# Unit test for function toggle_variable
def test_toggle_variable():
    workbench = get_workbench()
    assert workbench.in_simple_mode()
    assert not workbench.get_variable(_OPTION_NAME).get()
    toggle_variable()  # toggle ON
    assert workbench.get_variable(_OPTION_NAME).get()
    toggle_variable()  # toggle OFF
    assert not workbench.get_variable(_OPTION_NAME).get()

# Generated at 2022-06-24 07:55:58.845795
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock

    wb = Mock()
    wb.in_simple_mode.return_value = False
    wb.get_variable.side_effect = lambda x: Mock(get=lambda: False)
    wb.get_option.return_value = False
    wb.add_command = Mock()
    load_plugin()
    wb.add_command.assert_called_with(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    # Should not call update_environment
    assert os.environ.get("PGZERO_MODE") is None



# Generated at 2022-06-24 07:56:07.159049
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import patch

    from thonny import get_workbench

    mock_env = {}
    with patch.dict(os.environ, mock_env):
        # Test default (off)
        update_environment()
        assert os.environ["PGZERO_MODE"] == "0"
        # Test toggle on
        get_workbench().get_option(_OPTION_NAME).set(True)
        update_environment()
        assert os.environ["PGZERO_MODE"] == "auto"
        # Test toggle off
        get_workbench().get_option(_OPTION_NAME).set(False)
        update_environment()
        assert os.environ["PGZERO_MODE"] == "0"

# Generated at 2022-06-24 07:56:12.583015
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_simple_mode(False)
    assert not get_workbench().get_variable(_OPTION_NAME).get()
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get()
    toggle_variable()
    assert not get_workbench().get_variable(_OPTION_NAME).get()

# Generated at 2022-06-24 07:56:18.677184
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench
    from thonny.misc_utils import running_on_mac_os

    workbench = get_workbench()

    workbench.set_default(_OPTION_NAME, True)
    workbench.set_option("general.simple_mode", False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    workbench.set_option("general.simple_mode", True)
    if running_on_mac_os():
        import sys
        if sys.version_info[:3] >= (3, 8, 0):
            update_environment()
            assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:56:28.061228
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from unittest.mock import Mock, patch
    from thonny import THONNY_USER_DIR
    from thonny.globals import get_runner, get_workbench
    import shutil
    import os
    
    WB = Workbench()
    WB.set_default(_OPTION_NAME, True)
    get_workbench().set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    WB.set_default(_OPTION_NAME, False)
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    WB.destroy()


# Generated at 2022-06-24 07:56:32.380374
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = "auto"
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    os.environ["PGZERO_MODE"] = "auto"
    get_workbench().set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    os.environ["PGZERO_MODE"] = "auto"
    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:56:42.201545
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    wb.set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    wb.set_default(_OPTION_NAME, False)
    wb.enter_simple_mode()
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    wb.exit_simple_mode()
    wb.set_default(_OPTION_NAME, True)
    wb.enter_simple_mode()
    update_environment()

# Generated at 2022-06-24 07:56:51.076051
# Unit test for function update_environment
def test_update_environment():
    class FakeWorkbench:
        def in_simple_mode(self):
            return False
        
        def get_option(self, option):
            if option == _OPTION_NAME:
                return True
            assert False
    
    original_environ = os.environ.copy()
    original_workbench = get_workbench()

    try:
        os.environ["PGZERO_MODE"] = "auto"
        get_workbench = lambda: FakeWorkbench()
        update_environment()
        assert os.environ["PGZERO_MODE"] == "True"
    finally:
        os.environ = original_environ
        get_workbench = original_workbench

# Generated at 2022-06-24 07:56:56.443429
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    toggle_variable()
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:56:57.521765
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()


# Generated at 2022-06-24 07:57:01.787381
# Unit test for function toggle_variable
def test_toggle_variable():
    try:
        os.environ["PGZERO_MODE"] = "False"
        toggle_variable()
        assert os.environ["PGZERO_MODE"] == "True"
        toggle_variable()
        assert os.environ["PGZERO_MODE"] == "False"
    finally:
        os.environ.pop("PGZERO_MODE")

# Generated at 2022-06-24 07:57:04.564570
# Unit test for function update_environment
def test_update_environment():
    workbench = get_workbench()
    workbench.set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"



# Generated at 2022-06-24 07:57:14.818494
# Unit test for function update_environment
def test_update_environment():
    # Not in simple mode
    class TestWorkbench:
        def __init__(self):
            pass

        @property
        def in_simple_mode(self):
            return False

        def get_option(self, option_name):
            assert option_name == _OPTION_NAME
            return True

    os.environ = {}
    get_workbench = lambda: TestWorkbench()
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    # In simple mode
    class TestSimpleWorkbench:
        def __init__(self):
            pass

        @property
        def in_simple_mode(self):
            return True

        def get_option(self, option_name):
            assert option_name == _OPTION_NAME
            return True


# Generated at 2022-06-24 07:57:22.483180
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench
    from thonny.plugins.pgzero_mode import load_plugin
    from unittest.mock import Mock
    import thonny.workbench

    wb = Mock()
    wb.get_variable = lambda var: None
    thonny.workbench.get_workbench = lambda: wb

    load_plugin()
    assert wb.set_default.call_count == 1
    assert wb.add_command.call_count == 1

# Generated at 2022-06-24 07:57:26.886307
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    assert not wb.get_option(_OPTION_NAME)
    assert "PGZERO_MODE" not in os.environ
    load_plugin()
    assert wb.get_option(_OPTION_NAME)
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert not wb.get_option(_OPTION_NAME)
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:57:31.787976
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    assert wb.get_variable(_OPTION_NAME).get() == False
    wb.set_default(_OPTION_NAME, True)
    assert wb.get_variable(_OPTION_NAME).get() == True

# Generated at 2022-06-24 07:57:40.498797
# Unit test for function toggle_variable
def test_toggle_variable():
    try:
        from unittest.mock import Mock
        from unittest.mock import patch
    except ImportError:
        from unittest.mock import Mock
        from unittest.mock import patch
    get_workbench = Mock()
    os = Mock()

    test_value = [False, True]

    toggle_variable()
    assert get_workbench.set_default.called == True
    assert get_workbench.add_command.called == True
    assert os.environ.get("PGZERO_MODE") == "False"
    toggle_variable()
    assert os.environ.get("PGZERO_MODE") == "True"
    toggle_variable()
    assert os.environ.get("PGZERO_MODE") == "False"



# Generated at 2022-06-24 07:57:44.216764
# Unit test for function toggle_variable
def test_toggle_variable():
    var = get_workbench().get_variable(_OPTION_NAME)
    assert var.get() == False
    toggle_variable()
    assert var.get() == True



# Generated at 2022-06-24 07:57:48.239461
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_option(_OPTION_NAME, 'True')
    update_environment()
    
    assert os.environ["PGZERO_MODE"] == 'True'
    get_workbench().set_option(_OPTION_NAME, 'False')
    update_environment()
    
    assert os.environ["PGZERO_MODE"] == 'False'
    get_workbench().set_in_simple_mode(True)
    update_environment()
    
    assert os.environ["PGZERO_MODE"] == 'auto'
    
    
    
load_plugin()

# Generated at 2022-06-24 07:57:59.725990
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    load_plugin()
    assert wb.get_variable(_OPTION_NAME).get() is False
    assert os.environ.get("PGZERO_MODE") == "False"

    toggle_variable()
    assert wb.get_variable(_OPTION_NAME).get() is True
    assert os.environ.get("PGZERO_MODE") == "True"

    wb.in_simple_mode = lambda: True
    update_environment()
    assert os.environ.get("PGZERO_MODE") == "auto"

    wb.in_simple_mode = lambda: False
    update_environment()
    assert os.environ.get("PGZERO_MODE") == "True"


# Generated at 2022-06-24 07:58:05.654502
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench, set_simple_mode

    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:58:14.809497
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import Mock

    wb = Mock()
    wb.in_simple_mode.return_value = False
    wb.get_option.return_value = True
    
    class_names = [
        "run.OptionsPane",
        "thonny.shell.ShellView",
        "thonny.simple_mode.SimpleMode",
        "thonny.ui.MenuTree",
    ]
    for class_name in class_names:
        sys.modules[class_name].get_workbench = lambda: wb

    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:58:22.303060
# Unit test for function toggle_variable
def test_toggle_variable():
    if get_workbench().in_simple_mode():
        get_workbench().set_simple_mode(False)
    toggle_variable()
    get_workbench().set_simple_mode(True)
    assert os.environ["PGZERO_MODE"] == "auto"
    toggle_variable()
    get_workbench().set_simple_mode(False)
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_simple_mode(True)
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:58:33.178751
# Unit test for function load_plugin
def test_load_plugin():

    get_workbench().set_default = lambda key, value: None
    get_workbench().add_command = lambda cmd_id, view, label, func, flag_name=None, group=None, shortcut=None, extra_bindings=None, extra_classes=None, read_only=False, default_sequence=None: None
    fake_env = {}
    
    def fake_set_env(key, value):
        fake_env[key] = str(value)
        
    def fake_get_env(key):
        return fake_env.get(key)
        
    def fake_execute_script(path):
        pass
    
    def fake_get_script_path():
        return None
    
    get_workbench().set_variable(_OPTION_NAME, True)
    get_workbench().in_

# Generated at 2022-06-24 07:58:37.395834
# Unit test for function update_environment
def test_update_environment():
    var = get_workbench().get_variable(_OPTION_NAME)
    var.set(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    var.set(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:58:41.038379
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    assert get_workbench().get_option(_OPTION_NAME) == False

    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True

    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-24 07:58:51.272745
# Unit test for function load_plugin
def test_load_plugin():
    original = get_workbench()
    from thonny import workbench
    from unittest.mock import Mock

    wb = Mock(name="workbench")
    wb.get_variable = Mock(name="variable")
    wb.in_simple_mode = Mock(name="simple_mode")
    wb.get_option = Mock(name="option")
    workbench.Workbench.INSTANCE = wb

    assert not hasattr(wb, "toggle_pgzero_mode"), "toggle_pgzero_mode should not exist"
    load_plugin()
    assert hasattr(wb, "toggle_pgzero_mode"), "toggle_pgzero_mode should exist"
    wb.toggle_pgzero_mode = Mock(name="toggle_pgzero_mode")

# Generated at 2022-06-24 07:59:02.776639
# Unit test for function toggle_variable
def test_toggle_variable():
    import unittest.mock
    workbench = unittest.mock.Mock()

    option = unittest.mock.Mock()
    option.get.side_effect = [False, True, False]

    def get_variable_mock(name):
        if name == _OPTION_NAME:
            return option
        else:
            raise KeyError(name)

    workbench.get_variable.side_effect = get_variable_mock
    workbench.get_option.side_effect = get_variable_mock

    with unittest.mock.patch("os.environ", {}, create=True):
        toggle_variable()
        toggle_variable()
        toggle_variable()

    assert workbench.get_variable.call_count == 3
    assert workbench.get_option.call_

# Generated at 2022-06-24 07:59:05.512217
# Unit test for function toggle_variable
def test_toggle_variable():
    if not get_workbench().in_simple_mode():
        toggle_variable()
        assert os.environ["PGZERO_MODE"] == 'True'
        toggle_variable()
        assert os.environ["PGZERO_MODE"] == 'False'

# Generated at 2022-06-24 07:59:11.558697
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    os.environ["PGZERO_MODE"] = "auto"
    assert wb.get_option(_OPTION_NAME) == False
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "auto"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "auto"
    assert wb.get_option(_OPTION_NAME) == True

# Generated at 2022-06-24 07:59:19.961417
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default(_OPTION_NAME, False)
    if get_workbench().in_simple_mode():
        assert os.environ["PGZERO_MODE"] == "auto"
    else:
        assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_option(_OPTION_NAME, True)
    if get_workbench().in_simple_mode():
        assert os.environ["PGZERO_MODE"] == "auto"
    else:
        assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:59:21.989086
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import workbench

    workbench.unload_plugin("thonny.standard_plugins.initialize_default_variables")

    load_plugin()
    assert workbench.get_default(_OPTION_NAME) == False
    load_plugin()
    assert workbench.get_default(_OPTION_NAME) == True

# Generated at 2022-06-24 07:59:28.376480
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench, get_runner
    from thonny.plugins.micropython import MicroPythonProxy
    from thonny.plugins.micropython.backend import MPyBackend
    from subprocess import Popen, PIPE, STDOUT

    get_workbench().set_default(_OPTION_NAME, False)

    # Test with simple mode (auto)
    get_workbench().set_option("view.simple_mode", True)
    update_environment()
    # Check environment variable is set to auto
    assert os.environ["PGZERO_MODE"] == "auto"

    # Test with non-simple mode (Off)
    get_workbench().set_option("view.simple_mode", False)
    update_environment()
    # Check environment variable is set to off
    assert os.en

# Generated at 2022-06-24 07:59:38.228708
# Unit test for function toggle_variable
def test_toggle_variable():
    env = dict(os.environ)
    with tempfile.TemporaryDirectory() as tmp_dir:
        os.chdir(tmp_dir)
        get_workbench().set_option("path.thonny_user_dir", tmp_dir)
        # test that the mode is initially 'auto'
        toggle_variable()
        assert get_workbench().get_variable(_OPTION_NAME).get() is True
        assert os.environ['PGZERO_MODE'] == 'True'
        toggle_variable()
        assert get_workbench().get_variable(_OPTION_NAME).get() is False
        assert os.environ['PGZERO_MODE'] == 'False'
        get_workbench().set_simple_mode(True)
        assert os.environ['PGZERO_MODE'] == 'auto'
        update

# Generated at 2022-06-24 07:59:44.334878
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import workbench

    wb = workbench.init_workbench()
    load_plugin()

    wb.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    wb.set_simple_mode(False)
    toggle_variable()
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:59:49.620156
# Unit test for function toggle_variable
def test_toggle_variable():
    try:
        del os.environ["PGZERO_MODE"]
    except KeyError:
        pass
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:59:57.809079
# Unit test for function update_environment
def test_update_environment():
    old_var = os.environ.get("PGZERO_MODE")
    wb = get_workbench()
    wb.set_simple_mode(True)
    update_environment()
    assert os.environ.get("PGZERO_MODE") == "auto"
    wb.set_simple_mode(False)
    update_environment()
    assert os.environ.get("PGZERO_MODE") == "False"
    wb.set_variable(_OPTION_NAME, True)
    update_environment()

# Generated at 2022-06-24 08:00:01.945390
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_option(_OPTION_NAME, True)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True

# Generated at 2022-06-24 08:00:06.553983
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, True)
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == True

# Generated at 2022-06-24 08:00:13.900612
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    load_plugin()

    assert wb.get_option(_OPTION_NAME) == False
    assert wb.get_variable(_OPTION_NAME).get() == False
    assert os.environ.get("PGZERO_MODE", "") == "False"
    get_workbench().get_variable(_OPTION_NAME).set(True)
    update_environment()
    assert wb.get_option(_OPTION_NAME) == True
    assert wb.get_variable(_OPTION_NAME).get() == True
    assert os.environ.get("PGZERO_MODE", "") == "True"

# Generated at 2022-06-24 08:00:21.425716
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) is True
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) is False
    wb.set_default(_OPTION_NAME, True)
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) is False
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) is True



# Generated at 2022-06-24 08:00:31.680006
# Unit test for function update_environment
def test_update_environment():
    import os
    import unittest

    class TestEnvironment(unittest.TestCase):
        workbench = None
        var = None

        def setUp(self):
            self.workbench = get_workbench()
            self.var = self.workbench.get_variable(_OPTION_NAME)
            self.var.set(True)

        def tearDown(self):
            self.var.set(False)

        def test_update_environment_in_simple_mode(self):
            self.workbench.enter_simple_mode()
            update_environment()
            self.assertEqual(os.environ["PGZERO_MODE"], "auto")

        def test_update_environment_in_thonny_mode(self):
            self.workbench.leave_simple_mode()
            update_environment()
           

# Generated at 2022-06-24 08:00:38.613326
# Unit test for function update_environment
def test_update_environment():
    assert os.environ["PGZERO_MODE"] == "auto"

    wb = get_workbench()
    wb.set_simple_mode(False)
    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    
    wb.set_simple_mode(False)
    wb.set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"

    wb.set_simple_mode(True)
    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"


# Generated at 2022-06-24 08:00:46.958522
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock

    get_workbench().in_simple_mode = Mock(return_value=False)
    get_workbench().get_option = Mock(return_value=False)
    update_environment()
    assert get_workbench().get_option.call_args == call(_OPTION_NAME)
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().in_simple_mode = Mock(return_value=True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"



# Generated at 2022-06-24 08:00:49.351221
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) is True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) is False



# Generated at 2022-06-24 08:00:53.101831
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_option(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME) == False

# Generated at 2022-06-24 08:00:58.376573
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()

    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 08:01:04.818655
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.test_utils import get_test_config_dir, create_test_config_dir
    from thonny import get_workbench
    from thonny.misc_utils import running_on_linux

    if running_on_linux():
        return

    get_workbench().set_option(_OPTION_NAME, False)
    assert get_workbench().get_option(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-24 08:01:07.581666
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().add_command = MagicMock()
    load_plugin()
    get_workbench().add_command.assert_called()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-24 08:01:13.706984
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock

    workbench = Mock()
    workbench.get_variable = Mock(return_value=False)
    workbench.add_command = Mock()
    workbench.set_default = Mock()

    load_plugin()

    workbench.get_variable.assert_called_once()
    workbench.add_command.assert_called_once()
    workbench.set_default.assert_called_once()