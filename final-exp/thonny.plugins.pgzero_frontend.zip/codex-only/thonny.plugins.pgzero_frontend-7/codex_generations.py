

# Generated at 2022-06-24 07:50:47.839123
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.languages import _

    assert get_workbench().in_simple_mode() == False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    #User cannot toggle the variable in simple mode
    get_workbench().set_simple_mode(True)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    #User cannot toggle the variable in simple mode
    get_workbench().set_simple_mode(False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-24 07:50:48.301790
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()

# Generated at 2022-06-24 07:50:52.804172
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ.get("PGZERO_MODE") == "True"

    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ.get("PGZERO_MODE") == "False"

    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ.get("PGZERO_MODE") == "auto"

# Generated at 2022-06-24 07:50:57.519900
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import Mock
    from unittest.mock import patch
    from unittest import TestCase
    import os

    class MockOptions:
        def __init__(self):
            pass

        def get(self, name):
            return AUTO_MODE

    class MockWorkbench:
        def __init__(self):
            pass

        def in_simple_mode(self):
            return SIMPLE_MODE

        def get_option(self, name):
            return getattr(self.options, name)

        def set_default(self, name, value):
            setattr(MockWorkbench.options, name, value)

    def mock_environment(envkey, envvalue):
        os.environ[envkey] = envvalue


# Generated at 2022-06-24 07:51:02.557954
# Unit test for function toggle_variable
def test_toggle_variable():
    set_simple_mode(True)
    assert not get_option(_OPTION_NAME)
    toggle_variable()
    assert get_option(_OPTION_NAME)
    toggle_variable()
    assert not get_option(_OPTION_NAME)
    get_option(_OPTION_NAME).set(True)
    toggle_variable()
    assert not get_option(_OPTION_NAME)
    
    

# Generated at 2022-06-24 07:51:05.751358
# Unit test for function toggle_variable
def test_toggle_variable():
    var = get_workbench().get_variable(_OPTION_NAME)
    var.set(False)
    assert var.get() == False
    toggle_variable()
    assert var.get() == True
    toggle_variable()
    assert var.get() == False


# Generated at 2022-06-24 07:51:07.997531
# Unit test for function toggle_variable
def test_toggle_variable():
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:51:10.035264
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True

# Generated at 2022-06-24 07:51:20.144132
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.plugins.run.pgzero_mode_plugin import _OPTION_NAME
    from thonny import get_workbench
    from thonny.config_ui import ConfigurationPage
    from tkinter import Tk, PhotoImage
    from tkinter.ttk import Checkbutton

    root = Tk()
    get_workbench().set_default(_OPTION_NAME, False)  # Default value
    # Creating and initializing checkbutton
    checkbtn_pgzero_mode = Checkbutton(root, text="Pygame Zero mode")
    get_workbench().bind("TogglePGZeroMode", checkbtn_pgzero_mode, "invoke")
    get_workbench().create_image("TogglePGZeroMode", PhotoImage(width=1, height=1))
    checkbtn_pgzero_mode.pack()

    #

# Generated at 2022-06-24 07:51:26.347978
# Unit test for function update_environment
def test_update_environment():
    get_workbench().in_simple_mode()
    os.environ["PGZERO_MODE"] = "not_auto"
       
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:51:30.460395
# Unit test for function toggle_variable
def test_toggle_variable():
    global _OPTION_NAME
    _OPTION_NAME = "TEST_OPTION"
    from unittest import mock
    from thonny.workbench import Workbench

    get_workbench = mock.MagicMock()
    get_workbench.return_value = Workbench()
    toggle_variable()
    
    get_workbench.assert_called()

# Generated at 2022-06-24 07:51:35.931684
# Unit test for function toggle_variable
def test_toggle_variable():
    print("test_toggle_variable")
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:51:39.767359
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    toggle_variable()
    assert(wb.get_option(_OPTION_NAME))
    toggle_variable()
    assert (not wb.get_option(_OPTION_NAME))

# Generated at 2022-06-24 07:51:50.161418
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, True)
    assert wb.get_option(_OPTION_NAME)
    assert os.environ["PGZERO_MODE"] == "True"

    toggle_variable()
    assert not wb.get_option(_OPTION_NAME)
    assert os.environ["PGZERO_MODE"] == "False"

    wb.in_simple_mode = lambda: True
    toggle_variable()
    assert not wb.get_option(_OPTION_NAME)
    assert os.environ["PGZERO_MODE"] == "auto"
    wb.in_simple_mode = lambda: False
    toggle_variable()
    assert not wb.get_option(_OPTION_NAME)

# Generated at 2022-06-24 07:51:59.738991
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import workbench
    from thonny.workbench import Workbench
    from thonny.misc_utils import running_on_mac_os

    wb = Workbench()
    wb.create()
    wb.save_default_configuration()
    load_plugin()

    # Check existence of menu entry
    assert workbench.get_option('run.pgzero_mode') == False
    assert workbench.get_option('view.show_status_bar') == True
    assert workbench.get_variable(_OPTION_NAME).get() == False

    # Toggle menu entry
    toggle_variable()
    assert workbench.get_option('run.pgzero_mode') == True
    assert workbench.get_option('view.show_status_bar') == True

# Generated at 2022-06-24 07:52:05.127547
# Unit test for function toggle_variable
def test_toggle_variable():
    from unittest import mock

    assert get_workbench().get_option(_OPTION_NAME) == False

    # Ensure that the value of the associated option is flipped when the command is executed
    with mock.patch.object(get_workbench(), "in_simple_mode", return_value=False):
        toggle_variable()
        assert get_workbench().get_option(_OPTION_NAME) == True
        assert os.environ["PGZERO_MODE"] == 'True'

    # Ensure that the value of the associated option is flipped when the command is executed
    with mock.patch.object(get_workbench(), "in_simple_mode", return_value=False):
        toggle_variable()
        assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-24 07:52:08.142169
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, True)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-24 07:52:10.632293
# Unit test for function update_environment
def test_update_environment():
    # get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:52:15.241376
# Unit test for function toggle_variable
def test_toggle_variable():
    var = get_workbench().get_variable(_OPTION_NAME)
    #Test 1
    get_workbench().set_default(_OPTION_NAME, "foo")
    toggle_variable()
    assert(var.get() == True)
    #Test 2
    toggle_variable()
    assert(var.get() == False)

# Generated at 2022-06-24 07:52:24.111984
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, "0")
    old_env = os.environ.copy()
    load_plugin()

# Generated at 2022-06-24 07:52:28.597286
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    assert wb.get_variable(_OPTION_NAME).get() == False
    toggle_variable()
    assert wb.get_variable(_OPTION_NAME).get() == True
    toggle_variable()
    assert wb.get_variable(_OPTION_NAME).get() == False

# Generated at 2022-06-24 07:52:38.627718
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = ""
    original_get_option = get_workbench().get_option

    try:
        get_workbench().get_option = lambda x: True
        get_workbench().in_simple_mode = lambda: False
        update_environment()
        assert os.environ["PGZERO_MODE"] == "True"

        get_workbench().get_option = lambda x: False
        update_environment()
        assert os.environ["PGZERO_MODE"] == "False"

        get_workbench().in_simple_mode = lambda: True
        update_environment()
        assert os.environ["PGZERO_MODE"] == "auto"
    finally:
        get_workbench().get_option = original_get_option

# Generated at 2022-06-24 07:52:46.816867
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock

    wb = Mock()
    wb.set_default = lambda x, y: None
    wb.in_simple_mode = lambda: False
    wb.get_variable = lambda x: None
    wb.get_option = lambda x: True
    wb.add_command = lambda a, b, c, d, flag_name, group: None
    wb.in_simple_mode = lambda: False

    os.environ["PGZERO_MODE"] = "0"
    load_plugin()
    load_plugin()
    assert os.environ["PGZERO_MODE"] == "1"
    load_plugin()
    assert os.environ["PGZERO_MODE"] == "0"

    wb.in_simple_mode = lambda: True
    os

# Generated at 2022-06-24 07:52:56.485516
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.ui_utils import check_texts

    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == True
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == True
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get

# Generated at 2022-06-24 07:53:03.383466
# Unit test for function toggle_variable
def test_toggle_variable():
    try:
        get_workbench().set_simple_mode(False)
        assert not get_workbench().get_variable(_OPTION_NAME).get()
        assert "PGZERO_MODE" not in os.environ
        toggle_variable()
        assert get_workbench().get_variable(_OPTION_NAME).get()
        assert os.environ["PGZERO_MODE"] == "True"
        toggle_variable()
        assert not get_workbench().get_variable(_OPTION_NAME).get()
        assert os.environ["PGZERO_MODE"] == "False"
    finally:
        get_workbench().set_simple_mode(True)
        assert not get_workbench().get_variable(_OPTION_NAME).get()
        assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:53:07.779345
# Unit test for function toggle_variable
def test_toggle_variable():
    old_mode = os.environ["PGZERO_MODE"]
    assert toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    assert toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"
    os.environ["PGZERO_MODE"] = old_mode

# Generated at 2022-06-24 07:53:09.528710
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True

# Generated at 2022-06-24 07:53:13.135912
# Unit test for function toggle_variable
def test_toggle_variable():
    var = get_workbench().get_variable(_OPTION_NAME)
    # Test for True
    var.set(True)
    update_environment()
    if os.environ["PGZERO_MODE"] == "True":
        test_result = True
    else:
        test_result = False
    var.set(False)
    assert test_result

    # Test for False
    var.set(False)
    update_environment()
    if os.environ["PGZERO_MODE"] == "False":
        test_result = True
    else:
        test_result = False
    var.set(True)
    assert test_result

# Generated at 2022-06-24 07:53:20.933358
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import patch, MagicMock
    wb = MagicMock()
    wb.get_variable.return_value.get.return_value = True
    with patch.dict(os.environ, {}, clear=True):
        update_environment()
        assert os.environ["PGZERO_MODE"] == "True"
    with patch.dict(os.environ, {}, clear=True):
        wb.get_variable.return_value.get.return_value = False
        update_environment()
        assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:53:24.024999
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"


# Generated at 2022-06-24 07:53:26.295479
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == False
    get_workbench().destroy()

# Generated at 2022-06-24 07:53:30.703056
# Unit test for function toggle_variable
def test_toggle_variable():
    # toggle_variable function should change the pgzero_mode variable in the
    # workbench variable dictionary from 0 to 1 or 1 to 0.
    wb = get_workbench()
    assert wb.get_variable("run.pgzero_mode") == False
    toggle_variable()
    assert wb.get_variable("run.pgzero_mode") == True



# Generated at 2022-06-24 07:53:36.846349
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny import get_workbench
    from thonny.misc_utils import running_on_windows

    # Test that toggle_variable changes the value to True
    var = get_workbench().get_variable(_OPTION_NAME)
    var.set(False)
    toggle_variable()
    assert var.get() == True, "toggle_variable doesn't change the variable value to true"
    if not running_on_windows():
        assert os.getenv("PGZERO_MODE") == "True", "toggle_variable didn't set os.getenv to True"
    
    # Test that toggle variable changes the value to False
    var = get_workbench().get_variable(_OPTION_NAME)
    var.set(True)
    toggle_variable()

# Generated at 2022-06-24 07:53:38.034650
# Unit test for function toggle_variable
def test_toggle_variable():
    # reset to initial state
    toggle_variable()
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-24 07:53:41.657324
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

test_toggle_variable()

# Generated at 2022-06-24 07:53:50.441049
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_simple_mode(True)
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:53:55.871758
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = "1"
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    os.environ["THONNY_SIMPLE_MODE"] = "1"
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:53:56.620513
# Unit test for function load_plugin
def test_load_plugin():
    # TODO: fix test
    assert False

# Generated at 2022-06-24 07:53:59.098234
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, True)
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME)
    assert os.environ["PGZERO_MODE"] == "True"


# Generated at 2022-06-24 07:54:08.693684
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.in_simple_mode = lambda: True
    wb.in_debug_mode = lambda: False
    wb.get_editor_notebook = lambda: None
    var = wb.get_variable(_OPTION_NAME)
    assert var.get() == False
    load_plugin()
    var = wb.get_variable(_OPTION_NAME)
    assert var.get() == False
    assert "PGZERO_MODE" in os.environ
    assert os.environ["PGZERO_MODE"] == "auto"

    wb.in_simple_mode = lambda: False
    wb.in_debug_mode = lambda: True
    load_plugin()
    assert var.get() == False

# Generated at 2022-06-24 07:54:14.647749
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.workbench import Workbench
    from unittest.mock import MagicMock, patch

    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)

    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == True

    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == False


# Generated at 2022-06-24 07:54:17.743849
# Unit test for function load_plugin
def test_load_plugin():
    """
    This unit test checks if plugin is installed and enabled properly.
    """
    from thonny import get_workbench

    assert get_workbench().get_plugin("pgzero_mode")
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-24 07:54:20.231610
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.misc_utils import running_on_windows

    wb = get_workbench()
    load_plugin()
    assert not running_on_windows() or ("PGZERO_MODE" in os.environ)


# Generated at 2022-06-24 07:54:26.310108
# Unit test for function toggle_variable
def test_toggle_variable():
    list = []
    def my(x):
        list.append(x)
    get_workbench().in_simple_mode = lambda: True
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().get_variable(_OPTION_NAME).trace("w", my)
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == True
    assert list == [True]
    assert os.environ["PGZERO_MODE"] == "auto"

    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    assert list == [True, False]
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().in_simple_mode = lambda: False

# Generated at 2022-06-24 07:54:32.248525
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_simple_mode(False)
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:54:38.395070
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = "True"
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    os.environ["PGZERO_MODE"] = "False"
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    os.environ["PGZERO_MODE"] = "auto"
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:54:43.543909
# Unit test for function toggle_variable
def test_toggle_variable():
    old_variable = get_workbench().get_variable(_OPTION_NAME)
    assert type(old_variable) == bool
    # Toggle variable
    toggle_variable()
    variable = get_workbench().get_variable(_OPTION_NAME)
    assert type(variable) == bool
    variable_new = variable == old_variable
    # Set variable back to default
    get_workbench().set_default(_OPTION_NAME, not variable_new)
    assert variable_new

# Generated at 2022-06-24 07:54:48.182931
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_simple_mode(True)
    toggle_variable()
    assert wb.in_simple_mode() == False
    toggle_variable()
    assert wb.in_simple_mode() == True

# Generated at 2022-06-24 07:54:51.666400
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == True
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == False

# Generated at 2022-06-24 07:54:57.538511
# Unit test for function toggle_variable
def test_toggle_variable():
    #Testcase: True -> False -> True
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME) == True


# Generated at 2022-06-24 07:55:01.842704
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.workbench import Workbench

    workbench = Workbench()
    workbench.set_default(_OPTION_NAME, False)

    assert not workbench.get_option(_OPTION_NAME)

    toggle_variable()

    assert workbench.get_option(_OPTION_NAME)

# Generated at 2022-06-24 07:55:04.884552
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, True)
    toggle_variable()
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()

# Generated at 2022-06-24 07:55:12.988401
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = "auto"
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    os.environ.pop("PGZERO_MODE")

# Generated at 2022-06-24 07:55:14.546500
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    
    assert type(get_workbench().get_option(_OPTION_NAME)) == bool

# Generated at 2022-06-24 07:55:17.534484
# Unit test for function toggle_variable
def test_toggle_variable():
    os.environ["PGZERO_MODE"]="false"
    toggle_variable()
    assert os.environ["PGZERO_MODE"]=="true"

# Generated at 2022-06-24 07:55:18.060804
# Unit test for function toggle_variable
def test_toggle_variable():
    pass

# Generated at 2022-06-24 07:55:20.820314
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default("run.pgzero_mode", True)
    load_plugin()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:55:26.200007
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    # Check that the variable is not in the list
    assert _OPTION_NAME not in wb.get_variable_names()
    # Set the variable to True
    toggle_variable()
    # Check that the variable is in the list
    assert _OPTION_NAME in wb.get_variable_names()
    # Check the value of the variable
    assert wb.get_variable(_OPTION_NAME).get() == True

# Generated at 2022-06-24 07:55:26.646906
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()

# Generated at 2022-06-24 07:55:35.003715
# Unit test for function toggle_variable
def test_toggle_variable():
	wb = get_workbench()
	config_dir = wb.get_config_dir()
	config_file = os.path.join(config_dir, 'thonny.ini')
	config = configparser.ConfigParser()
	config.read(config_file)
	os.environ['PGZERO_MODE'] = ''
	toggle_variable()
	if config['run']['pgzero_mode'] == 'False':
		toggle_variable()
		if config['run']['pgzero_mode'] == 'True':
			toggle_variable()
			if config['run']['pgzero_mode'] == 'False':
				if os.environ['PGZERO_MODE'] == 'False':
					toggle_variable()

# Generated at 2022-06-24 07:55:41.414957
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_shell
    from thonny.common import toggle_pgzero_mode_flag
    from thonny.languages import tr
    from thonny.plugins.run import toggle_pgzero_mode
    # Test Loading
    load_plugin()
    # Test default value
    assert get_workbench().get_option(_OPTION_NAME) is False
    # Test Command
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) is True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) is False

    # Test Env Var
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    update_environment()

# Generated at 2022-06-24 07:55:43.725760
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default("subprocess.run_in_shell", True)
    load_plugin()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:55:54.288566
# Unit test for function load_plugin
def test_load_plugin():
    import unittest.mock
    wb = unittest.mock.Mock()
    wb.get_variable = unittest.mock.Mock(return_value=True)

    unit = unittest.mock.Mock()
    unit.in_simple_mode = unittest.mock.Mock(return_value=True)
    unit.get_option = unittest.mock.Mock(return_value=True)
    wb.get_ui_mode = unittest.mock.Mock(return_value=unit)
    wb.in_simple_mode.return_value = True

    with unittest.mock.patch("thonny.plugins.pgzero_mode.get_workbench", return_value=wb):
        load_plugin()

        assert os

# Generated at 2022-06-24 07:56:02.820367
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.basic_mode()

    load_plugin()
    assert not wb.get_default(_OPTION_NAME)
    assert "PGZERO_MODE" not in os.environ

    wb.set_default(_OPTION_NAME, True)
    update_environment()
    assert wb.get_default(_OPTION_NAME)
    assert os.environ["PGZERO_MODE"] == "True"

    wb.simple_mode()
    assert os.environ["PGZERO_MODE"] == "auto"

    toggle_variable()
    assert not wb.get_default(_OPTION_NAME)
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:56:03.258155
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()

# Generated at 2022-06-24 07:56:11.769525
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.misc_utils import running_on_mac_os
    from unittest.mock import Mock

    wb = Mock()
    wb.get_variable = Mock()
    wb.get_variable.return_value = False
    wb.set_default = Mock()
    wb.add_command = Mock()
    if running_on_mac_os():
        wb.in_simple_mode = Mock()
        wb.in_simple_mode.return_value = False

    global get_workbench
    get_workbench = Mock()
    get_workbench.return_value = wb

    load_plugin()

    assert get_workbench.called
    assert wb.set_default.called
    assert wb.add_command.called



# Generated at 2022-06-24 07:56:18.737660
# Unit test for function toggle_variable
def test_toggle_variable():
    from unittest.mock import Mock

    _get_workbench = get_workbench

    class Workbench:
        in_simple_mode = Mock()
        get_variable = Mock()

    var = Mock()
    var.get = Mock()
    var.set = Mock()
    wb = Workbench()
    wb.get_variable.return_value = var

    def get_workbench():
        return wb

    wb.in_simple_mode.return_value = True
    toggle_variable()
    os.environ["PGZERO_MODE"] = "auto"
    assert not var.set.called
    wb.in_simple_mode.return_value = False
    toggle_variable()
    assert var.set.called
    var.get.return_value = True
    toggle_variable()


# Generated at 2022-06-24 07:56:25.170875
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_option("run.pgzero_mode", False)
    get_workbench().set_default("run.pgzero_mode", True)
    toggle_variable()
    assert get_workbench().get_variable("run.pgzero_mode").get() == True
    toggle_variable()
    assert get_workbench().get_variable("run.pgzero_mode").get() == False
    toggle_variable()
    assert get_workbench().get_variable("run.pgzero_mode").get() == True

# Generated at 2022-06-24 07:56:28.277433
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from tkinter import Tk
    test_tk = Tk()
    test_workbench = Workbench(master=test_tk, load_ui=False)
    load_plugin()
    test_tk.destroy()


# Generated at 2022-06-24 07:56:31.231852
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_variable(_OPTION_NAME, True)
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME) == False

# Generated at 2022-06-24 07:56:36.603000
# Unit test for function toggle_variable
def test_toggle_variable():
    pw=get_workbench()
    toggle_variable()
    assert pw.get_option(_OPTION_NAME) == True
    toggle_variable()
    assert pw.get_option(_OPTION_NAME) == False
    toggle_variable()
    assert pw.get_option(_OPTION_NAME) == True



# Generated at 2022-06-24 07:56:42.716431
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_custom_option(_OPTION_NAME, 1)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"

    get_workbench().set_custom_option(_OPTION_NAME, 0)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"

    get_workbench().in_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:56:48.609188
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench

    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().get_variable(_OPTION_NAME).set(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:56:56.078823
# Unit test for function load_plugin
def test_load_plugin():
    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    # assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"
    # get_workbench().add_command(
    #     "toggle_pgzero_mode",
    #     "run",
    #     tr("Pygame Zero mode"),
    #     toggle_variable,
    #     flag_name=_OPTION_NAME,
    #     group=40,
    # )
    # toggle_variable()
    # assert get_workbench().get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"



# Generated at 2022-06-24 07:56:59.564861
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = "auto"
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:57:02.845479
# Unit test for function load_plugin
def test_load_plugin():
    assert get_workbench().get_option(_OPTION_NAME) == False


if __name__ == "__main__":
    # print(get_workbench().get_option(_OPTION_NAME))
    test_load_plugin()
    # print(get_workbench().get_option(_OPTION_NAME))

# Generated at 2022-06-24 07:57:09.172769
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_default(_OPTION_NAME, True)
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().in_simple_mode()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:57:16.550769
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_simple_mode(True)
    load_plugin()
    var = wb.get_variable(_OPTION_NAME)
    assert not var.get()
    assert var.get_label() == tr("Pygame Zero mode")
    assert os.environ["PGZERO_MODE"] == "auto"
    toggle_variable()
    assert var.get() == True
    assert os.environ["PGZERO_MODE"] == "1"
    wb.set_simple_mode(False)
    toggle_variable()
    assert var.get() == False
    assert os.environ["PGZERO_MODE"] == "0"

# Generated at 2022-06-24 07:57:26.008477
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.config_ui import ConfigurationPage

    workbench = Workbench()
    load_plugin()

    # Check Menu
    assert workbench.get_menu("run").find_submenu_with_command("toggle_pgzero_mode") is not None

    # Check Configuration Page
    page = ConfigurationPage(workbench)
    page.load_from_config()
    page.main_groupbox.set_selected_by_name(_OPTION_NAME)
    page.save_to_config()

    # Check Environment Variable
    workbench.in_simple_mode = lambda: False
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"


# Generated at 2022-06-24 07:57:31.416087
# Unit test for function toggle_variable
def test_toggle_variable():
    # Check if the default value is False
    assert get_workbench().get_option(_OPTION_NAME) is False

    # Test that False -> True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) is True

    # Test that True -> False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) is False

# Generated at 2022-06-24 07:57:35.884870
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) is True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) is False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) is True

# Generated at 2022-06-24 07:57:38.496096
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().unload_plugin_by_name("thonny.plugins.pgzero_mode")
    get_workbench().load_plugin("thonny.plugins.pgzero_mode")
    assert get_workbench().in_simple_mode() == False


# Generated at 2022-06-24 07:57:49.327295
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import MagicMock
    from unittest.mock import Mock
    from thonny.workbench import Workbench
    from thonny.options import Options
    from thonny.config import get_config_dir
    test_config_file_name = "test_config_file_name"

    config_dir = get_config_dir()
    test_config_file_name = os.path.join(config_dir, test_config_file_name)
    if os.path.exists(test_config_file_name):
        os.remove(test_config_file_name)
    Options.create_config(test_config_file_name)
    workbench = Workbench(config_file_name=test_config_file_name)

    workbench.bind_variable = Mock()

# Generated at 2022-06-24 07:58:01.068146
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import Mock
    from thonny import get_workbench

    get_workbench().in_simple_mode = Mock(return_value=True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().in_simple_mode = Mock(return_value=False)
    get_workbench().get_option = Mock(return_value=True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().in_simple_mode = Mock(return_value=False)
    get_workbench().get_option = Mock(return_value=False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"


# Unit test

# Generated at 2022-06-24 07:58:06.576280
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default("foo", False)
    wb.add_command("bar", "run", "bar", "baz", flag_name="bar", group=1)
    wb.add_command("bar", "run", "bar", "baz", flag_name="bar", group=1)
    # TODO: how to verify that add_command is called?


if __name__ == "__main__":
    test_load_plugin()
    print("Unit test OK")

# Generated at 2022-06-24 07:58:16.991748
# Unit test for function update_environment
def test_update_environment():
    import os
    import unittest
    from unittest.mock import MagicMock
    # Mock the workbench
    mock_workbench = MagicMock()
    mock_workbench.in_simple_mode.return_value = False
    mock_workbench.get_option.return_value = True
    # Save the original workbench
    original_workbench = get_workbench()
    # Load the plugin with the mocked workbench
    get_workbench = MagicMock(return_value=mock_workbench)
    update_environment()
    get_workbench.assert_called_once()
    mock_workbench.get_option.assert_called_once_with(_OPTION_NAME)
    # Assert that the value of the environment variable is set to True
    assert os.environ["PGZERO_MODE"]

# Generated at 2022-06-24 07:58:25.314454
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default("run.pgzero_mode", False)
    get_workbench().add_command("toggle_pgzero_mode", "run", "Pygame Zero mode", toggle_variable)
    assert get_workbench()._commands["toggle_pgzero_mode"][1] == 40
    assert get_workbench()._commands["toggle_pgzero_mode"][2] is flag_name
    assert get_workbench()._commands["toggle_pgzero_mode"][3] is not None
    assert get_workbench()._commands["toggle_pgzero_mode"][4]
    assert get_workbench().get_variable("run.pgzero_mode") is not None
    assert isinstance(get_workbench().get_variable("run.pgzero_mode"), BooleanVar)



# Generated at 2022-06-24 07:58:32.342772
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import MagicMock
    from thonny.workbench import Workbench

    workbench = Workbench(MagicMock())
    assert workbench.get_option(_OPTION_NAME) == False
    workbench.clear_commands()
    load_plugin()
    assert workbench.get_option(_OPTION_NAME) == False
    assert len(workbench.commands) == 1
    assert workbench.commands[0].name == "toggle_pgzero_mode"
    assert workbench.commands[0].group == 40

# Generated at 2022-06-24 07:58:38.935078
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.set_simple_mode(True)
    load_plugin()
    assert wb.get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "auto"
    wb.set_simple_mode(False)
    load_plugin()
    assert wb.get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"


# Generated at 2022-06-24 07:58:45.094754
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.config_ui import ConfigurationPage
    from tkinter import IntVar
    wb = Workbench()
    load_plugin()
    assert wb.get_default(_OPTION_NAME) is False
    assert ConfigurationPage.get_variable(wb, _OPTION_NAME) is None
    assert wb.get_variable(_OPTION_NAME) is not None
    assert isinstance(wb.get_variable(_OPTION_NAME), IntVar)
    assert wb.get_option(_OPTION_NAME) is False
    
    wb.set_default(_OPTION_NAME, True)
    assert wb.get_default(_OPTION_NAME) is True
    assert wb.get_variable(_OPTION_NAME).get() is False

# Generated at 2022-06-24 07:58:46.486455
# Unit test for function toggle_variable
def test_toggle_variable():
    assert isinstance(toggle_variable, object) == True


# Generated at 2022-06-24 07:58:53.527097
# Unit test for function toggle_variable
def test_toggle_variable():
    local_root = Tk()
    local_root.withdraw()
    get_workbench().set_default(_OPTION_NAME, True)
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().in_simple_mode = True
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().in_simple_mode = False
    local_root.destroy()

# Generated at 2022-06-24 07:58:56.730225
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, True)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-24 07:59:00.834170
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == True
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == False

# Generated at 2022-06-24 07:59:04.790643
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    assert get_workbench().get_option(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True


if __name__ == "__main__":
    test_toggle_variable()

# Generated at 2022-06-24 07:59:07.372654
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert os.environ["PGZERO_MODE"] == "False"


load_plugin()

# Generated at 2022-06-24 07:59:15.688836
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock
    from thonny.globals import get_workbench

    wb = Mock()
    get_workbench.return_value = wb

    load_plugin()
    
    wb.set_default.assert_called_once_with(_OPTION_NAME, False)
    wb.add_command.assert_called_once()
    wb.get_variable.assert_called_once_with(_OPTION_NAME)
    
    os.environ["PGZERO_MODE"] = ""
    wb.in_simple_mode.return_value = True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    
    os.environ["PGZERO_MODE"] = ""

# Generated at 2022-06-24 07:59:22.408171
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock
    from thonny import get_workbench
    from thonny.config import get_config_dir, CONFIG_DIR_NAME

    get_workbench().clear_all()
    get_workbench().destroy()

    get_workbench().create()
    load_plugin()
    assert os.path.exists(CONFIG_DIR_NAME)
    assert os.path.isdir(CONFIG_DIR_NAME)
    assert os.path.exists(get_config_dir())
    assert os.path.isdir(get_config_dir())
    assert os.path.exists(os.path.join(get_config_dir(), "config-v2.json"))

# Generated at 2022-06-24 07:59:25.057842
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.dummy_mode = True
    wb.in_simple_mode = lambda: False
    wb.get_editor_notebook = lambda: None
    load_plugin()
    assert hasattr(wb, "toggle_pgzero_mode")
    assert wb.options.get(_OPTION_NAME) == False



# Generated at 2022-06-24 07:59:26.575233
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:59:29.842899
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, True)
    update_envir

# Generated at 2022-06-24 07:59:36.559514
# Unit test for function toggle_variable
def test_toggle_variable():
    
    get_workbench().set_default(_OPTION_NAME, False)
    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == True
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == True

# Generated at 2022-06-24 07:59:38.017292
# Unit test for function toggle_variable
def test_toggle_variable():
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert os.enviro

# Generated at 2022-06-24 07:59:45.759805
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_simple_mode()
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:59:54.611145
# Unit test for function load_plugin
def test_load_plugin():
    from unittest import mock
    from thonny import WORKBENCH, ui_utils
    
    plugin_dir = os.path.dirname(__file__)
    # Mock the input file
    with mock.patch("os.path.dirname", return_value=plugin_dir):
        # Test loading the plugin
        load_plugin()
        # Test the toggle pgzero mode menu is added and the default value is false
        assert WORKBENCH.get_variable(_OPTION_NAME).get() == False
        assert ui_utils.get_menu_item(WORKBENCH.get_menu("run"), "toggle_pgzero_mode")

# Generated at 2022-06-24 07:59:58.395877
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().destroy()

# Generated at 2022-06-24 08:00:10.278665
# Unit test for function toggle_variable
def test_toggle_variable():
    from unittest.mock import Mock
    from thonny.globals import get_workbench
    from thonny import ToplevelCommand
    from thonny.globals import get_runner
    from thonny.globals import get_workbench

    m = Mock()
    m.get = lambda x: False
    m.set = lambda x: m.get(x)
    m.get_option = lambda x: m.get(x)
    m.get_variable = lambda x: m.get(x)
    m.in_simple_mode = lambda x: False
    m.add_command = lambda *x: None
    m.set_default = lambda *x: None
    get_workbench = Mock(return_value=m)
    get_runner = Mock()

# Generated at 2022-06-24 08:00:18.035687
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_simple_mode(False)
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == ""

    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"

    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 08:00:23.541814
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    assert os.environ["PGZERO_MODE"] == "False"
    wb.set_simple_mode(True)
    assert os.environ["PGZERO_MODE"] == "auto"
    wb.set_simple_mode(False)
    wb.set_default(_OPTION_NAME, True)
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 08:00:34.016062
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.globals import get_workbench
    from thonny.config_ui import ConfigurationPage

    # test default configuration
    get_workbench().set_default(_OPTION_NAME, False)
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    # test configuration in simple mode
    get_workbench().set_default(_OPTION_NAME, True)
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 08:00:37.474970
# Unit test for function update_environment
def test_update_environment():
    print("get_workbench().get_option(_OPTION_NAME)", get_workbench().get_option(_OPTION_NAME))
    update_environment()
    print("get_workbench().get_option(_OPTION_NAME)", os.environ["PGZERO_MODE"])

# Generated at 2022-06-24 08:00:48.157009
# Unit test for function update_environment
def test_update_environment():
    from collections import namedtuple
    from thonny.misc_utils import running_on_windows
    from unittest.mock import MagicMock

    workbench = MagicMock()
    workbench.in_simple_mode.return_value = False
    workbench.get_option.return_value = True
    get_workbench.return_value = workbench
    original_os_environ = os.environ
    dummy_env = namedtuple("Environment", "get set")
    os.environ = dummy_env(lambda *args, **kwargs: original_os_environ.get(*args, **kwargs),
                           lambda *args, **kwargs: original_os_environ.__setitem__(*args, **kwargs))
    update_environment()
    # assert_equal(os.environ.get