

# Generated at 2022-06-24 07:51:39.354810
# Unit test for function update_environment
def test_update_environment():
    from thonny.environment import update_environment as ue
    from thonny.globals import get_runner
    from thonny.plugins.run import RunBackend

    # Disable auto mode
    os.environ["PGZERO_MODE"] = "none"
    ue()
    assert get_runner().runner_name == "Subprocess"

    # Enable auto mode
    os.environ["PGZERO_MODE"] = "auto"
    ue()
    assert get_runner().runner_name == RunBackend.name

    # Try enabling auto mode with run backend disabled and simple mode enabled
    get_workbench().set_simple_mode(True)
    ue()
    assert get_runner().runner_name == "Subprocess"

    # Try enabling auto mode with run backend disabled and simple mode disabled
    get_work

# Generated at 2022-06-24 07:51:45.059020
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_simple_mode()
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:51:50.851721
# Unit test for function toggle_variable
def test_toggle_variable():
    # Initialize workbench
    from thonny.workbench import Workbench

    get_workbench().destroy()
    get_workbench().__init__()

    # Check variable value
    assert get_workbench().get_variable(
        _OPTION_NAME
    ).get() == get_workbench().get_default(_OPTION_NAME) == False

    # Perform toggle_variable function
    toggle_variable()

    # Check variable value
    assert get_workbench().get_variable(
        _OPTION_NAME
    ).get() == get_workbench().get_default(_OPTION_NAME) == True

# Generated at 2022-06-24 07:51:55.504943
# Unit test for function update_environment
def test_update_environment():
    from thonny.misc_utils import running_on_mac_os
    if running_on_mac_os():
        assert os.environ["PGZERO_MODE"] == "auto"
    else:
        assert os.environ["PGZERO_MODE"] == "False"



# Generated at 2022-06-24 07:51:58.921493
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench

    assert not get_workbench().get_option(_OPTION_NAME)
    load_plugin()

    assert get_workbench().get_option(_OPTION_NAME)

    toggle_variable()
    assert not get_workbench().get_option(_OPTION_NAME)

# Generated at 2022-06-24 07:52:04.617686
# Unit test for function toggle_variable
def test_toggle_variable():
    # Run Tests toggle_variable
    # Create a workbench test
    workbench = WorkbenchTest()

    # Run toggle_variable() with a value of False
    workbench.in_simple_mode = False
    workbench.set_option(_OPTION_NAME, False)
    toggle_variable()
    assert workbench.get_option(_OPTION_NAME) == True
    # Run toggle_variable() with a value of True
    toggle_variable()
    assert workbench.get_option(_OPTION_NAME) == False
    # Run toggle_variable() with a value of True when in simple_mode
    workbench.in_simple_mode = True
    get_workbench().set_option(_OPTION_NAME, True)
    toggle_variable()
    assert workbench.get_option(_OPTION_NAME) == False

# Generated at 2022-06-24 07:52:12.020256
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default("run.pgzero_mode", False)
    _OPTION_NAME= "run.pgzero_mode"
    get_workbench().in_simple_mode=lambda: True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().in_simple_mode=lambda: False
    get_workbench().get_option=lambda x: True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"



# Generated at 2022-06-24 07:52:20.767678
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ.get("PGZERO_MODE", "") == "False"

    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ.get("PGZERO_MODE", "") == "True"
    wb.set_option(_OPTION_NAME, False)

    wb.set_simple_mode(True)
    update_environment()
    assert os.environ.get("PGZERO_MODE", "") == "auto"
    wb.set_simple_mode(False)

# Generated at 2022-06-24 07:52:25.797591
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench

    wb = get_workbench()
    wb._pass_command_line_options = True
    wb._load_plugins_and_start = True
    wb.run_command = lambda cmd: print(cmd)
    wb.start(prog_name="thonny", arg_options={"configdir": "images"})
    # load_plugin()
    # import pdb; pdb.set_trace()
    # wb.run_command('toggle_pgzero_mode')

# Generated at 2022-06-24 07:52:30.925568
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()

# Generated at 2022-06-24 07:52:37.298750
# Unit test for function update_environment
def test_update_environment():
    from unittest import mock
    from thonny.workbench import Workbench

    update_environment()
    assert os.getenv("PGZERO_MODE") == "False"

    wb = Workbench()
    wb._simple_mode = True
    with mock.patch("thonny.workbench.Workbench", return_value=wb) as wb:
        update_environment()
        assert os.getenv("PGZERO_MODE") == "auto"

# Generated at 2022-06-24 07:52:43.875189
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    wb.disable_simple_mode()
    wb.set_option("run.pgzero_mode", True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    wb.set_option("run.pgzero_mode", False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    wb.enable_simple_mode()
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:52:53.616491
# Unit test for function update_environment
def test_update_environment():
    import os
    class MockWorkbench:
        def in_simple_mode(self):
            return True
        
        def get_option(self, name):
            return True
    MockWorkbench.set_default = MockWorkbench.get_option
    
    os.environ["PGZERO_MODE"] = "0"
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    
    MockWorkbench.in_simple_mode = lambda self: False
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"
    
    MockWorkbench.get_option = lambda self, name: False
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"

# Generated at 2022-06-24 07:53:00.472500
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import Mock
    import sys

    if sys.platform == "darwin":
        return

    group = Mock()
    get_workbench = lambda: group
    group.in_simple_mode.return_value = False
    group.get_option.return_value = True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    group.get_option.return_value = False
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    group.in_simple_mode.return_value = True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:53:05.745405
# Unit test for function update_environment
def test_update_environment():
    from unittest import mock

    get_workbench().set_option(_OPTION_NAME, True)
    with mock.patch.dict(os.environ, clear=True):
        update_environment()
        assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_option(_OPTION_NAME, False)
    with mock.patch.dict(os.environ, clear=True):
        update_environment()
        assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_option(_OPTION_NAME, False)
    with mock.patch.dict(os.environ, clear=True):
        get_workbench().set_simple_mode(True)
        update_environment()

# Generated at 2022-06-24 07:53:10.361687
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    assert wb.get_variable(_OPTION_NAME) == False
    toggle_variable()
    assert wb.get_variable(_OPTION_NAME) == True
    toggle_variable()
    assert wb.get_variable(_OPTION_NAME) == False

# Generated at 2022-06-24 07:53:15.477568
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, True)
    assert os.environ["PGZERO_MODE"] == "True"
    wb.set_default(_OPTION_NAME, False)
    assert os.environ["PGZERO_MODE"] == "False"


# Generated at 2022-06-24 07:53:25.267239
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.unload_plugin("thonny.plugins.pgzero_mode")
    assert not wb.get_variable(_OPTION_NAME).get()
    assert os.environ.get("PGZERO_MODE") is None
    wb.unload_plugin("thonny.plugins.pgzero_mode")
    assert not wb.get_variable(_OPTION_NAME).get()
    assert "auto" == os.environ.get("PGZERO_MODE")
    wb.set_default(_OPTION_NAME, True)
    assert wb.get_variable(_OPTION_NAME).get()
    wb.unload_plugin("thonny.plugins.pgzero_mode")
    assert wb.get_variable(_OPTION_NAME).get()

# Generated at 2022-06-24 07:53:32.966601
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert get_workbench().default(_OPTION_NAME) == False

    # When the option is set to False
    get_workbench().set_option(_OPTION_NAME, False)
    os.environ["PGZERO_MODE"] = str(get_workbench().get_option(_OPTION_NAME))
    assert os.environ["PGZERO_MODE"] == "False"

    # When the option is set to True
    get_workbench().set_option(_OPTION_NAME, True)
    os.environ["PGZERO_MODE"] = str(get_workbench().get_option(_OPTION_NAME))
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:53:41.776675
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_simple_mode(True)
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:53:47.937755
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.simple_mode = True
    load_plugin()
    assert wb.get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "auto"
    wb.simple_mode = False
    load_plugin()
    assert wb.get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == 'False'

# Generated at 2022-06-24 07:53:52.798161
# Unit test for function toggle_variable
def test_toggle_variable():
    # Check by default pgzero_mode is off
    assert get_workbench().get_option(_OPTION_NAME) == False
    toggle_variable()
    # after toggle pgzero_mode is on
    assert get_workbench().get_option(_OPTION_NAME) == True
    # after toggle again it is back to off
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-24 07:53:56.955247
# Unit test for function toggle_variable
def test_toggle_variable():
    assert get_workbench().get_option(_OPTION_NAME) == False, "Single_file is set as false"
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True, "Single_file is set as true"
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False, "Single_file is set as false"

# Generated at 2022-06-24 07:54:01.819498
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    wb.in_simple_mode_ = lambda: True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:54:09.462284
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default("run.exit_button", True)
    get_workbench().set_default("run.show_call_tips", True)
    test_workbench = Workbench()
    test_workbench.set_default("run.exit_button", True)
    assert test_workbench.get_option("run.exit_button") == True
    assert test_workbench.get_option("run.show_call_tips") == True
    load_plugin()
    assert test_workbench.get_option("run.exit_button") == True
    assert test_workbench.get_option("run.show_call_tips") == True
    assert test_workbench.get_option("run.pgzero_mode") == False

# Generated at 2022-06-24 07:54:14.986194
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    assert not get_workbench().get_variable(_OPTION_NAME).get()

    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get()

    toggle_variable()
    assert not get_workbench().get_variable(_OPTION_NAME).get()

# Generated at 2022-06-24 07:54:22.647404
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    wb.set_simple_mode(True)
    os.environ.pop("PGZERO_MODE", None)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    
    os.environ.pop("PGZERO_MODE", None)
    wb.set_simple_mode(False)
    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    
    os.environ.pop("PGZERO_MODE", None)
    wb.set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:54:32.656219
# Unit test for function update_environment
def test_update_environment():
    """Test whether toggle_variable works"""
    # Arrange
    assert os.environ.get("PGZERO_MODE") == None
    from unittest.mock import Mock
    get_workbench_backup = get_workbench
    get_workbench = Mock()
    get_workbench.in_simple_mode = lambda: False

    # Act 1
    get_workbench.return_value = False
    update_environment()

    # Assert 1
    assert os.environ.get("PGZERO_MODE") == "False"

    # Act 2
    get_workbench.return_value = True
    update_environment()
    # Assert 2
    assert os.environ.get("PGZERO_MODE") == "True"
    # Act 3

# Generated at 2022-06-24 07:54:39.369790
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = "auto"
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    os.environ["PGZERO_MODE"] = "auto"
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    # restore environment variable
    del os.environ["PGZERO_MODE"]
    assert "PGZERO_MODE" not in os.environ

# Generated at 2022-06-24 07:54:45.822263
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_simple_mode(True)
    os.environ["PGZERO_MODE"] = "1"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "0"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "1"

    get_workbench().set_simple_mode(False)
    os.environ["PGZERO_MODE"] = "1"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "0"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "1"


# Generated at 2022-06-24 07:54:53.676805
# Unit test for function toggle_variable
def test_toggle_variable():
    from unittest.mock import Mock
    import tkinter as tk
    from thonny.globals import get_workbench
    from thonny.shell import ShellText
    import thonny.common
    from thonny.tktextext import TextFrame

    wb = get_workbench()
    wb.in_simple_mode = Mock(return_value=False)
    wb.get_variable = Mock(return_value=True)
    wb.set_option = Mock()

    wb.add_command = Mock()
    wb.add_command.side_effect = lambda a, b, c, d, e, f, flag_name=None, group=None: print(flag_name)
    wb.get_variable = Mock(return_value=False)

    #test_toggle

# Generated at 2022-06-24 07:55:04.504515
# Unit test for function update_environment
def test_update_environment():

    from thonny.globals import get_workbench
    from thonny import get_runner
    from thonny.common import set_workbench_option
    from thonny.workflow import SimpleWorkflow
    from pytest import fixture

    @fixture(autouse=True)
    def restore_default_options(request):
        old_options = SimpleWorkflow._default_options
        SimpleWorkflow._default_options = SimpleWorkflow._default_options.copy()
        request.addfinalizer(lambda: SimpleWorkflow._default_options.update(old_options))

    set_workbench_option("run.pgzero_mode", False)
    assert os.environ.get("PGZERO_MODE") is None
    get_workbench().in_simple_mode = False
    update_environment()

# Generated at 2022-06-24 07:55:12.655207
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_shell
    from thonny import get_workbench
    test_environment = os.environ.copy()

    # Checks that environment is set to auto if in simple mode
    get_shell().clear()
    get_shell().destroy()
    get_shell().create()
    get_workbench().in_simple_mode = lambda: True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    # Checks that environment is set to True if pgzero_mode is set to True
    get_workbench().in_simple_mode = lambda: False
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    # Checks that environment is set to False if

# Generated at 2022-06-24 07:55:20.466070
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    assert os.environ.get("PGZERO_MODE") == "False"
    toggle_variable()
    assert os.environ.get("PGZERO_MODE") == "True"
    toggle_variable()
    assert os.environ.get("PGZERO_MODE") == "False"

# Generated at 2022-06-24 07:55:28.695357
# Unit test for function update_environment
def test_update_environment():
    global os
    os = mock.Mock()

    update_environment()
    os.environ.__setitem__.assert_called_with("PGZERO_MODE", "False")
    os.environ.__setitem__.reset_mock()

    get_workbench().in_simple_mode = lambda: True
    update_environment()
    os.environ.__setitem__.assert_called_with("PGZERO_MODE", "auto")
    os.environ.__setitem__.reset_mock()

    get_workbench().in_simple_mode = lambda: False
    get_workbench().get_option = lambda name: True
    update_environment()
    os.environ.__setitem__.assert_called_with("PGZERO_MODE", "True")

# Generated at 2022-06-24 07:55:35.356698
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench

    wb = Workbench()
    load_plugin()

    var = wb.get_variable(_OPTION_NAME)
    assert var is not None
    assert var.get() == False
    assert os.environ["PGZERO_MODE"] == "False"

    toggle_variable()
    assert var.get() == True
    assert os.environ["PGZERO_MODE"] == "True"

    toggle_variable()
    assert var.get() == False
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:55:35.732194
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()

# Generated at 2022-06-24 07:55:40.038954
# Unit test for function load_plugin
def test_load_plugin():
    assert "PGZERO_MODE" not in os.environ
    load_plugin()
    assert os.environ.get("PGZERO_MODE") == "False"
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ.get("PGZERO_MODE") == "True"
    get_workbench().set_simple_mode()
    update_environment()
    assert os.environ.get("PGZERO_MODE") == "auto"

# Generated at 2022-06-24 07:55:46.380959
# Unit test for function update_environment
def test_update_environment():
    from test.test_runner_backend import BackendTestCase
    
    with BackendTestCase():
        get_workbench().set_simple_mode(True)
        update_environment()
        assert os.environ["PGZERO_MODE"] == "auto"
    
        get_workbench().set_simple_mode(False)
        get_workbench().set_option(_OPTION_NAME, False)
        update_environment()
        assert os.environ["PGZERO_MODE"] == "0"
    
        get_workbench().set_option(_OPTION_NAME, True)
        update_environment()
        assert os.environ["PGZERO_MODE"] == "1"

# Generated at 2022-06-24 07:55:52.389857
# Unit test for function update_environment
def test_update_environment():
    load_plugin()
    if get_workbench().get_option(_OPTION_NAME):
        assert os.environ["PGZERO_MODE"] == "True"
    else:
        assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    if get_workbench().get_option(_OPTION_NAME):
        assert os.environ["PGZERO_MODE"] =="True"
    else:
        assert os.environ["PGZERO_MODE"] =="False"

# Generated at 2022-06-24 07:55:57.061850
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock

    get_workbench().add_command = Mock()
    load_plugin()
    get_workbench().add_command.assert_called_with(
        "toggle_pgzero_mode",
        "run",
        "Pygame Zero mode",
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )

# Generated at 2022-06-24 07:56:02.034862
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = "auto"
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"

# Generated at 2022-06-24 07:56:08.349573
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench
    from thonny.globals import get_runner
    from thonny.plugins.simple_mode import mode_change_handler
    
    get_workbench().set_option("run.pgzero_mode", True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    get_runner().cancel_execution()
    mode_change_handler("EditorMode", "SimpleMode")
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:56:13.682267
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.globals import get_workbench

    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:56:24.622073
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    if wb.get_variable(_OPTION_NAME):
        raise AssertionError("Expected default to be False before loading plugin")
    var = get_workbench().get_variable(_OPTION_NAME)
    load_plugin()
    if not wb.get_variable(_OPTION_NAME):
        raise AssertionError("Expected default to be True after loading plugin")
    if not wb.get_option(_OPTION_NAME):
        raise AssertionError("Expected default to be True after loading plugin")

    check_cmd = wb.get_command("toggle_pgzero_mode")
    if not check_cmd.get_label():
        raise AssertionError("Command name is empty")

# Generated at 2022-06-24 07:56:31.801771
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    original_option_value = wb.get_option(_OPTION_NAME, False)

# Generated at 2022-06-24 07:56:41.836684
# Unit test for function update_environment
def test_update_environment():
    old_value = os.environ.get("PGZERO_MODE", None)

# Generated at 2022-06-24 07:56:50.360501
# Unit test for function update_environment
def test_update_environment():
    import os
    from thonny.workbench import Workbench
    from thonny.config import get_user_config_dir
    get_user_config_dir()
    os.environ["PGZERO_MODE"] = "auto"
    workbench = Workbench()
    workbench.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    workbench.set_simple_mode(False)
    workbench.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:56:55.339229
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    wb.set_simple_mode(False)
    wb.set_default(_OPTION_NAME, False)
    assert not wb.get_option(_OPTION_NAME)
    toggle_variable()
    assert wb.get_option(_OPTION_NAME)

    toggle_variable()
    assert not wb.get_option(_OPTION_NAME)
    wb.set_simple_mode(False)
    update_environment()

# Generated at 2022-06-24 07:57:00.073316
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench

    wb = Workbench()
    try:
        global update_environment
        old_ue = update_environment
        update_environment = lambda: None
        load_plugin()
    finally:
        update_environment = old_ue
        wb.destroy()

# Generated at 2022-06-24 07:57:03.761691
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.getenv("PGZERO_MODE") == "1"
    
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.getenv("PGZERO_MODE") == "0"


# Generated at 2022-06-24 07:57:05.252723
# Unit test for function update_environment
def test_update_environment():
    # I have no idea how to test this, Thonny is not a testable package
    pass

# Generated at 2022-06-24 07:57:13.051210
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    wb.set_in_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:57:24.578731
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, True)
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"
    os.environ["PGZERO_MODE"] = "auto"
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_in_simple_mode(True)
    update_environment()

# Generated at 2022-06-24 07:57:33.012429
# Unit test for function toggle_variable
def test_toggle_variable():
    # Test initial state
    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    assert os.environ["PGZERO_MODE"] == "False"
    # Test after toggling
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == True
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:57:41.510239
# Unit test for function toggle_variable
def test_toggle_variable():
    import thonny
    thonny.running_in_test_mode = True
    thonny.TkUI.TkUI.create_instance()
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    assert wb.get_variable(_OPTION_NAME).get() == False
    toggle_variable()
    assert wb.get_variable(_OPTION_NAME).get() == True
    toggle_variable()
    assert wb.get_variable(_OPTION_NAME).get() == False
    wb.set_default(_OPTION_NAME, True)
    assert wb.get_variable(_OPTION_NAME).get() == True
    toggle_variable()
    assert wb.get_variable(_OPTION_NAME).get() == False
    toggle_variable()

# Generated at 2022-06-24 07:57:46.676406
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    assert _OPTION_NAME in wb.get_default_options()
    assert wb.get_option(_OPTION_NAME) == False
    command_ids = [command.command_id for command in wb.get_commands()]
    assert "toggle_pgzero_mode" in command_ids

# Generated at 2022-06-24 07:57:55.407391
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.globals import get_workbench
    import os

    w = get_workbench()
    w.set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert w.get_option(_OPTION_NAME) is True
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert w.get_option(_OPTION_NAME) is False
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:58:01.890669
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    assert not hasattr(wb, "toggle_pgzero_mode")
    load_plugin()
    assert wb.get_option(_OPTION_NAME) == False
    wb.set_option(_OPTION_NAME, True)
    assert wb.get_option(_OPTION_NAME) == True
    assert hasattr(wb, "toggle_pgzero_mode")
    assert "PGZERO_MODE" not in os.environ

# Generated at 2022-06-24 07:58:07.101651
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()


if __name__ == "__main__":
    test_load_plugin()

# Generated at 2022-06-24 07:58:17.104011
# Unit test for function update_environment
def test_update_environment():
    del os.environ["PGZERO_MODE"]
    get_workbench().set_default(_OPTION_NAME, False)

    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"

    get_workbench().set_default(_OPTION_NAME, True)

    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"

    get_workbench().set_default(_OPTION_NAME, 1)

    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"

    get_workbench().set_default(_OPTION_NAME, "auto")

    get_workbench().enter_simple_mode()
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    get_

# Generated at 2022-06-24 07:58:22.518831
# Unit test for function update_environment
def test_update_environment():
    with get_runner().isolated_filesystem():
        get_workbench().set_simple_mode(False)
        get_workbench().set_option(_OPTION_NAME, True)
        update_environment()
        os.environ["PGZERO_MODE"] = "True"
        get_workbench().set_simple_mode(True)
        update_environment()
        os.environ["PGZERO_MODE"] = "auto"

# Generated at 2022-06-24 07:58:28.304528
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:58:37.492655
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench

    new_env = {key: value for (key, value) in os.environ.items() if key != "PGZERO_MODE"}
    wb = Workbench(load_plugins=False)
    wb.load_configuration()
    wb.set_default(_OPTION_NAME, True)


# Generated at 2022-06-24 07:58:48.283315
# Unit test for function update_environment
def test_update_environment():
    from unittest import mock
    from thonny import get_workbench, get_runner
    import tempfile
    from thonny.ui_utils import open_config_dialog
    from tkinter.constants import DISABLED

    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().set_option(_OPTION_NAME, False)
    os.environ["PGZERO_MODE"] = ""
    update_environment()
    assert os.environ["PGZERO_MODE"] == ""

    os.environ["PGZERO_MODE"] = ""
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"


# Generated at 2022-06-24 07:58:54.811038
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench
    from thonny.misc_utils import running_on_mac_os

    if running_on_mac_os():
        # Skip this test on MacOS
        return

    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ.get("PGZERO_MODE") == "False"

    # check that changes are reflected
    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ.get("PGZERO_MODE") == "True"

# Generated at 2022-06-24 07:59:02.298884
# Unit test for function load_plugin
def test_load_plugin():
    import unittest.mock
    from thonny.config import get_workbench_config
    from thonny.workbench import Workbench

    wb = Workbench(unittest.mock.MagicMock())
    wb.set_default("run.pgzero_mode", False)
    load_plugin()
    assert wb.get_variable("run.pgzero_mode") == False
    assert wb.get_option("run.pgzero_mode") == False
    assert get_workbench_config().get("run.pgzero_mode") == False

# Generated at 2022-06-24 07:59:07.814311
# Unit test for function update_environment
def test_update_environment():
    os.environ.pop("PGZERO_MODE", None)
    get_workbench().set_option(_OPTION_NAME, True)
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_option(_OPTION_NAME, False)
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_simple_mode(True)
    assert ("PGZERO_MODE" not in os.environ) or os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:59:15.881829
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import MagicMock
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.get_configuration = MagicMock()
    wb.get_configuration.return_value.has_section = lambda x: False

    wb.in_simple_mode = lambda: False
    wb.get_option = MagicMock()
    wb.get_option.return_value = False
    os.environ["PGZERO_MODE"] = "true"
    
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"
    os.environ.clear()

    wb.in_simple_mode = lambda: True
    wb.get_option = MagicMock()
    wb.get_option.return_

# Generated at 2022-06-24 07:59:24.441193
# Unit test for function update_environment
def test_update_environment():
    old_env = os.environ.copy()

    os.environ.pop("PGZERO_MODE", None)
    get_workbench().set_option(_OPTION_NAME, False)
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    os.environ.pop("PGZERO_MODE", None)
    get_workbench().set_option(_OPTION_NAME, False)
    get_workbench().set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "off"

    os.environ.pop("PGZERO_MODE", None)
    get_workbench().set_option(_OPTION_NAME, True)
    get_

# Generated at 2022-06-24 07:59:26.497089
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_option("run.pgzero_mode", True)
    update_environment()

    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:59:33.145602
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, True)

    load_plugin()

    assert len(wb.get_command("toggle_pgzero_mode")) == 6
    assert wb.get_variable(_OPTION_NAME).get() is True
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:59:38.597883
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_option(_OPTION_NAME, True)
    os.environ["PGZERO_MODE"] = "1"
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ.get("PGZERO_MODE") == "0"
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    assert os.environ.get("PGZERO_MODE") == "1"

# Generated at 2022-06-24 07:59:48.010644
# Unit test for function load_plugin
def test_load_plugin():
    old_env = os.environ.copy()
    get_workbench().destroy()
    load_plugin()
    assert get_workbench().get_variable(_OPTION_NAME) == False
    assert "PGZERO_MODE" in os.environ
    assert os.environ["PGZERO_MODE"] == "0"

    # get_workbench().set_option(_OPTION_NAME, True)
    # assert os.environ["PGZERO_MODE"] == "1"

    get_workbench().in_simple_mode = lambda: True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    os.environ = old_env

# Generated at 2022-06-24 07:59:55.170362
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_simple_mode()
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"

    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"

# Generated at 2022-06-24 08:00:01.126499
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.plugins.run.pgzero_mode import load_plugin
    from thonny.workbench import Workbench
    from test.test_utils import captured_output
    wb = Workbench()
    with captured_output("stderr"):
        load_plugin()
    assert wb.get_variable("run.pgzero_mode").get()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 08:00:07.236625
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import MagicMock
    from thonny.misc_utils import running_on_windows
    
    get_workbench().get_variable = MagicMock()
    get_workbench().get_variable.return_value.get.return_value = "False"
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"



# Generated at 2022-06-24 08:00:11.759033
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == True

# Generated at 2022-06-24 08:00:18.449357
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().add_command("toggle_pgzero_mode",
                                "run",
                                None,
                                toggle_variable,
                                flag_name=_OPTION_NAME,
                                group=40)

    assert get_workbench().get_option("run.pgzero_mode") == False

    toggle_variable()
    assert get_workbench().get_option("run.pgzero_mode") == True

# Generated at 2022-06-24 08:00:27.827764
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench

    wb = Workbench()
    load_plugin()

    assert "PGZERO_MODE" in os.environ
    assert os.environ["PGZERO_MODE"] == "False"

    assert wb.get_command("toggle_pgzero_mode")

    toggle_variable()
    assert "PGZERO_MODE" in os.environ
    assert os.environ["PGZERO_MODE"] == "True"
    assert wb.get_variable(_OPTION_NAME) == True

    toggle_variable()
    assert "PGZERO_MODE" in os.environ
    assert os.environ["PGZERO_MODE"] == "False"
    assert wb.get_variable(_OPTION_NAME) == False

# Generated at 2022-06-24 08:00:33.655318
# Unit test for function toggle_variable
def test_toggle_variable():
    from unittest import mock
    from thonny import get_workbench

    with mock.patch("thonny.ui_utils.confirm") as confirm:
        confirm.return_value = True
        toggle_variable()
        assert get_workbench().get_variable("run.pgzero_mode").get() == True

        toggle_variable()
        assert get_workbench().get_variable("run.pgzero_mode").get() == False

# Generated at 2022-06-24 08:00:36.689236
# Unit test for function toggle_variable
def test_toggle_variable():
    assert get_workbench() is not None
    var = get_workbench().get_variable(_OPTION_NAME)
    var.set(False)
    toggle_variable()
    assert var.get() == True
    toggle_variable()
    assert var.get() == False



# Generated at 2022-06-24 08:00:47.569715
# Unit test for function toggle_variable
def test_toggle_variable():
    class TestVar:
        def __init__(self):
            self.value = False

        def get(self):
            return self.value

        def set(self, new_value):
            self.value = new_value

    class TestWorkbench:
        def get_variable(self, option_name):
            return TestVar()

        def get_option(self, option_name):
            return self.t.get()

        def get_option_or_default(self, option_name, default_value):
            if option_name == self.name:
                return self.t.get()
            else:
                return default_value

        def in_simple_mode(self):
            return False

        def set_default(self, option_name, value):
            return None


# Generated at 2022-06-24 08:00:52.539275
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, 0)
    wb.add_command(
        "toggle_pgzero_mode",
        "run",
        "Pygame Zero mode",
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()


# Generated at 2022-06-24 08:00:55.046262
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == True
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == False

# Generated at 2022-06-24 08:01:00.317059
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench

    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 08:01:05.519350
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()
    if get_workbench().in_simple_mode():
        assert os.environ["PGZERO_MODE"] == "auto"
    else:
        assert os.environ["PGZERO_MODE"] == "false"

# Generated at 2022-06-24 08:01:15.121558
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_option("run.auto_cd", True)
    load_plugin()
    assert "PGZERO_MODE" in os.environ
    get_workbench().set_option("run.pgzero_mode", True)
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_option("run.pgzero_mode", False)
    assert os.environ["PGZERO_MODE"] == "False"
    
    get_workbench().set_simple_mode(True)
    get_workbench().set_option("run.pgzero_mode", True)
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 08:01:19.150453
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default('run.pgzero_mode', True)
    assert get_workbench().get_option('run.pgzero_mode') == True
    toggle_variable()
    assert get_workbench().get_option('run.pgzero_mode') == False
    toggle_variable()
    assert get_workbench().get_option('run.pgzero_mode') == True

# Generated at 2022-06-24 08:01:27.833785
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    
    get_workbench().set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"