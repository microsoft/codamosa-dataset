

# Generated at 2022-06-24 07:51:33.321450
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.create_variable = Mock()
    assert not wb.in_simple_mode()

    load_plugin()

    wb.create_variable.assert_called_once_with(_OPTION_NAME, False)


if __name__ == "__main__":
    load_plugin()

# Generated at 2022-06-24 07:51:41.002097
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = "auto"
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "yes"
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "no"

# Generated at 2022-06-24 07:51:48.513980
# Unit test for function update_environment
def test_update_environment():
    # Get the configuration
    config = get_workbench().get_option(_OPTION_NAME)

    # For each possible state of the configuration
    for new_value in [True, False]:
        # Update the configuration
        get_workbench().set_option(_OPTION_NAME, new_value)

        # Check that the env is updated correctly
        update_environment()
        assert os.environ["PGZERO_MODE"] == str(new_value)

    # Restore the old value
    get_workbench().set_option(_OPTION_NAME, config)

# Generated at 2022-06-24 07:51:51.896704
# Unit test for function update_environment
def test_update_environment():
    assert os.environ.get("PGZERO_MODE") is None
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:52:00.930251
# Unit test for function update_environment
def test_update_environment():
    import os
    import tempfile
    # prepare workbench
    workbench = get_workbench()
    workbench.set_default("run.pgzero_mode", False)
    workbench.set_default("view.simple_mode", False)
    # save environment variables
    env_backup = os.environ.copy()
    # switch to temporary directory
    cwd_backup = os.getcwd()
    tmp_dir = tempfile.TemporaryDirectory()
    os.chdir(tmp_dir.name)
    # prepare tmp file
    tmp_file = open(".tst",  "w")
    # test update environment
    update_environment()
    tmp_file.write(os.environ["PGZERO_MODE"])
    # restore environment
    os.environ = env_backup
    os

# Generated at 2022-06-24 07:52:12.094592
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default("run.pygame_zero_mode", True)
    wb.set_default("view.simple_mode", True)
    load_plugin()
    assert "PGZERO_MODE" in os.environ
    assert os.environ["PGZERO_MODE"] == "auto"
    wb.set_option("view.simple_mode", False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    wb.set_option("view.simple_mode", True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    wb.set_option("run.pygame_zero_mode", False)
    update_environment()
    assert os.en

# Generated at 2022-06-24 07:52:18.839159
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().set_simple_mode(False)
    toggle_variable()
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:52:21.999983
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-24 07:52:25.425503
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == True
    
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    # TODO: update_environment

# Generated at 2022-06-24 07:52:29.419192
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_option(_OPTION_NAME, True)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True

# Generated at 2022-06-24 07:52:37.670102
# Unit test for function update_environment
def test_update_environment():
    assert os.environ["PGZERO_MODE"] == "auto"
    prev_value = get_workbench().get_option(_OPTION_NAME)
    try:
        get_workbench().set_option(_OPTION_NAME, True)
        update_environment()
        assert os.environ["PGZERO_MODE"] == "1"

        get_workbench().set_option(_OPTION_NAME, False)
        update_environment()
        assert os.environ["PGZERO_MODE"] == "0"
    finally:
        get_workbench().set_option(_OPTION_NAME, prev_value)

# Generated at 2022-06-24 07:52:46.174580
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, None)
    load_plugin()
    assert wb.get_option(_OPTION_NAME) == False
    assert wb.get_variable(_OPTION_NAME) is not None
    assert wb.get_command("toggle_pgzero_mode") is not None

    # in_simple_mode()
    wb.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    wb.set_simple_mode(False)

    # toggle_variable()
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    assert wb.get_option(_OPTION_NAME) == True

    # set_simple

# Generated at 2022-06-24 07:52:49.809500
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_option(_OPTION_NAME, True)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) is False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) is True



# Generated at 2022-06-24 07:52:54.627288
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_variable(_OPTION_NAME, False)
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"
    


# Generated at 2022-06-24 07:53:02.061890
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = "0"
    get_workbench().options["run.pgzero_mode"] = True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"

    os.environ["PGZERO_MODE"] = "1"
    get_workbench().options["run.pgzero_mode"] = False
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"

    # in simple mode
    os.environ["PGZERO_MODE"] = "0"
    get_workbench().in_simple_mode = lambda: True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:53:09.840234
# Unit test for function update_environment
def test_update_environment():
    from thonny.globals import get_runner
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == str(True)

    get_workbench().set_option(_OPTION_NAME, False)
    get_workbench().set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == str(False)

    get_workbench().set_simple_mode(True)
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:53:11.640333
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.options = {}
    load_plugin()
    assert wb.options["run.pgzero_mode"] == False
    assert os.environ["PGZERO_MODE"] == "False"

# Unit tests for function toggle_variable

# Generated at 2022-06-24 07:53:22.706780
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.set_option(_OPTION_NAME, False)
    wb.in_simple_mode = lambda : False
    load_plugin()
    cmd = wb.get_command("toggle_pgzero_mode")
    assert not cmd.get_flag_value()
    assert cmd.label == tr("Pygame Zero mode")
    assert os.environ["PGZERO_MODE"] == "False"

    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    cmd.action()
    assert not cmd.get_flag_value()
    assert wb.get_option(_OPTION_NAME) is False



# Generated at 2022-06-24 07:53:32.018634
# Unit test for function load_plugin
def test_load_plugin():
    from unittest import mock
    from thonny.workbench import Workbench
    from thonny.misc_utils import running_on_mac_os
    from thonny import get_workbench
    
    mw = mock.Mock(Workbench)
    mw.get_variable = mock.Mock()
    mw.in_simple_mode = mock.Mock(return_value=False)

    mw.get_variable.return_value = mock.Mock
    mw.get_variable.return_value.get = mock.Mock(return_value=False)
    mw.get_option = mock.Mock(return_value=False)
    
    load_plugin()
    update_environment()
    
    get_workbench().set_default(_OPTION_NAME, False)
    get

# Generated at 2022-06-24 07:53:35.299849
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench().get_variable(_OPTION_NAME)
    wb.set(False)
    assert (wb.get() == False)
    toggle_variable()
    assert (wb.get() == True)

# Generated at 2022-06-24 07:53:39.664769
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = "auto"
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().set_simple_mode(False)
    update_environment()
    assert os.environ[_OPTION_NAME] == "False"



# Generated at 2022-06-24 07:53:50.525636
# Unit test for function load_plugin
def test_load_plugin():
    wb = MagicMock()
    wb.get_option = lambda x: False
    wb.in_simple_mode.return_value = False
    wb.set_default = MagicMock()
    wb.add_command = MagicMock()

    with patch.dict("sys.modules", {"thonny": MagicMock(workbench=wb)}):
        import thonnycontrib.pgzero_mode
        thonnycontrib.pgzero_mode.load_plugin()

        assert "auto" == os.environ["PGZERO_MODE"]
        wb.set_default.assert_called_once()

# Generated at 2022-06-24 07:53:57.320377
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.languages import tr
    from thonny.workbench import Workbench

    workbench = Workbench()
    workbench.set_default(_OPTION_NAME, False)
    assert not workbench.get_option(_OPTION_NAME)
    assert "PGZERO_MODE" not in os.environ

    toggle_variable()
    assert workbench.get_option(_OPTION_NAME)
    assert os.environ["PGZERO_MODE"] == "True"

    toggle_variable()
    assert not workbench.get_option(_OPTION_NAME)
    assert os.environ["PGZERO_MODE"] == "False"



# Generated at 2022-06-24 07:54:02.695727
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()

# Generated at 2022-06-24 07:54:05.558772
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    load_plugin()
    assert get_workbench().get_default(_OPTION_NAME) == False



# Generated at 2022-06-24 07:54:14.813596
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench

    workbench = Workbench()
    workbench.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto" 
    
    workbench.set_simple_mode(False)
    workbench.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True" 
    
    workbench.set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:54:21.833668
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench
    from thonny.globals import get_runner
    from unittest.mock import patch
    from unittest.mock import MagicMock

    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()

    with patch.object(get_runner(), "update_environment") as mock_update_env:
        get_workbench().set_option(_OPTION_NAME, True)

# Generated at 2022-06-24 07:54:32.074548
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.running import get_interpreter
    from thonny import ui_utils
    from thonny.shell import ShellTextWidget
    from thonny.globals import get_workbench
    from thonny.languages import tr
    import os
    import sys

    get_workbench().in_simple_mode = lambda: False
    os.environ = dict(os.environ, PGZERO_MODE="False")
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == False
    os.environ = dict(os.environ, PGZERO_MODE="True")
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == True
    get_workbench().in_simple_mode = lambda: True
    load

# Generated at 2022-06-24 07:54:37.205800
# Unit test for function toggle_variable
def test_toggle_variable():
    # get_workbench().set_default(_OPTION_NAME, False)
    # assert get_workbench().get_option(_OPTION_NAME) == False
    # toggle_variable()
    # assert get_workbench().get_option(_OPTION_NAME) == True
    # toggle_variable()
    # assert get_workbench().get_option(_OPTION_NAME) == False
    pass

# Generated at 2022-06-24 07:54:45.185717
# Unit test for function toggle_variable
def test_toggle_variable():
    class Workbench:
        def __init__(self):
            self.variable_table = {}

    class Variable:
        def __init__(self):
            self._value = False

        def get(self):
            return self._value

        def set(self, value):
            self._value = value

    wb = Workbench()
    # Test Variable not in variable table
    try:
        wb.get_variable(_OPTION_NAME)
    except KeyError:
        toggle_variable()
        assert wb.get_variable(_OPTION_NAME).get() == True
    # Test Variable in variable table
    variable = Variable()
    variable.set(True)
    wb.variable_table[_OPTION_NAME] = variable
    toggle_variable()
    assert wb.get_variable(_OPTION_NAME).get

# Generated at 2022-06-24 07:54:53.323667
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import Mock
    from thonny.workbench import Workbench
    from thonny.config import Configuration
    from thonny.config_ui import ConfigurationPage
    get_workbench = Mock()
    get_workbench.side_effect = Workbench
    Workbench.get_option = Mock()
    Configuration.get_option = Mock()
    ConfigurationPage.get_option = Mock()

    import thonnycontrib.pgzeromode
    thonnycontrib.pgzeromode.get_workbench = get_workbench
    Workbench.get_option.return_value = True
    update_environment()

    assert os.environ["PGZERO_MODE"] == "1"

    get_workbench.side_effect = None
    get_workbench.return_value = None

# Generated at 2022-06-24 07:54:55.572745
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    wb = get_workbench()
    assert wb.get_command("toggle_pgzero_mode")



# Generated at 2022-06-24 07:55:00.063562
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock

    get_workbench().add_command = Mock()
    get_workbench().set_default = Mock()

    load_plugin()

    assert get_workbench().get_option(_OPTION_NAME) == False
    get_workbench().add_command.assert_called_with(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )



# Generated at 2022-06-24 07:55:06.419469
# Unit test for function update_environment
def test_update_environment():
    old_value = os.getenv('PGZERO_MODE')
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.getenv('PGZERO_MODE') == 'false'
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.getenv('PGZERO_MODE') == 'true'
    if old_value is not None:
        os.environ['PGZERO_MODE'] = old_value

# Generated at 2022-06-24 07:55:14.441203
# Unit test for function toggle_variable
def test_toggle_variable():
    old_workbench = get_workbench()
    from unittest.mock import MagicMock
    from thonny import workbench
    from collections import namedtuple

    class FakeWorkbench(object):
        my_variable = MagicMock()

    class FakeVar(object):
        def get(self):
            return False

        def set(self, value):
            return

    _orig_wb = workbench.Workbench.get_instance
    _orig_env = os.environ
    os.environ = {}

    wb = FakeWorkbench()
    wb.get_variable = MagicMock(return_value=FakeVar())

    workbench.Workbench.get_instance = MagicMock(return_value=wb)

    # Call the function to test
    toggle_variable()

    wb.get_variable

# Generated at 2022-06-24 07:55:20.558844
# Unit test for function load_plugin
def test_load_plugin():
    wb = MagicMock()
    wb.add_command = MagicMock()

    with patch("thonny.plugins.pgzero.get_workbench", return_value=wb):
        load_plugin()

    assert wb.set_default.call_args == call(_OPTION_NAME, False)
    assert "Pygame Zero mode" in str(wb.add_command.call_args)
    assert _OPTION_NAME in str(wb.add_command.call_args)

# Generated at 2022-06-24 07:55:23.333120
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench

    w = Workbench()
    w.set_default("pgzrun.auto_run", False)
    load_plugin()



# Generated at 2022-06-24 07:55:26.459136
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_option(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-24 07:55:29.737221
# Unit test for function toggle_variable
def test_toggle_variable():
    os.environ["PGZERO_MODE"] = "True"
    toggle_variable()
    os.environ["PGZERO_MODE"] = "False"
    toggle_variable()
    os.environ["PGZERO_MODE"] = "auto"
    toggle_variable()
    os.environ["PGZERO_MODE"] = "False"
    toggle_variable()

# Generated at 2022-06-24 07:55:32.442082
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == True
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == False
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == True
    wb.set_option(_OPTION_NAME, True)
    assert wb.get_option(_OPTION_NAME) == True


# Generated at 2022-06-24 07:55:36.158147
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_option("run.pgzero_mode", False)
    assert not get_workbench().get_option("run.pgzero_mode")

    toggle_variable()
    assert get_workbench().get_option("run.pgzero_mode")

    toggle_variable()
    assert not get_workbench().get_option("run.pgzero_mode")

# Generated at 2022-06-24 07:55:37.807011
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-24 07:55:41.818369
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = ""
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto", "PGZERO_MODE is not auto"
    get_workbench().set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:55:49.465387
# Unit test for function toggle_variable
def test_toggle_variable():
    # Activate the plug-in
    load_plugin()
    
    # It should be off by default
    assert get_workbench().get_option(_OPTION_NAME) == False

    # Simulate the button toggle
    toggle_variable()

    # Check that it is now on
    assert get_workbench().get_option(_OPTION_NAME) == True

    # Simulate the button toggle
    toggle_variable()

    # Check that it is now back off
    assert get_workbench().get_option(_OPTION_NAME) == False


# Generated at 2022-06-24 07:55:52.953530
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert os.getenv("PGZERO_MODE") == "1"

    toggle_variable()
    assert os.getenv("PGZERO_MODE") == "0"



# Generated at 2022-06-24 07:55:57.660032
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.globals import get_workbench

    get_workbench().set_option(_OPTION_NAME, True)
    assert toggle_variable() == True
    get_workbench().set_option(_OPTION_NAME, False)
    assert toggle_variable() == False
    get_workbench().set_option(_OPTION_NAME, True)
    assert toggle_variable() == True

# Generated at 2022-06-24 07:56:06.885372
# Unit test for function update_environment
def test_update_environment():
    # pylint: disable=protected-access
    wb = get_workbench()

    # in_simple_mode=True
    wb._in_simple_mode = True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    wb._in_simple_mode = False
    update_environment()

    # in_simple_mode=False
    # option = True
    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    # in_simple_mode=False
    # option = False
    wb.set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:56:14.445907
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"

    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"

# Generated at 2022-06-24 07:56:23.836602
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    wb.set_simple_mode()
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    wb.set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    wb.set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    wb.set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:56:27.167098
# Unit test for function toggle_variable
def test_toggle_variable():
    os.environ["PGZERO_MODE"] = "auto"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:56:32.313878
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.load_plugin(__name__)

    assert wb.get_variable(_OPTION_NAME).get() == False
    assert os.environ['PGZERO_MODE'] == 'False'
    wb.set_option(_OPTION_NAME, True)
    assert wb.get_variable(_OPTION_NAME).get() == True
    assert os.environ['PGZERO_MODE'] == 'True'
    wb.set_simple_mode(True)
    assert os.environ['PGZERO_MODE'] == 'auto'

# Generated at 2022-06-24 07:56:34.926778
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert get_workbench().get_command(
        "toggle_pgzero_mode"
    )._flag_name == _OPTION_NAME

# Generated at 2022-06-24 07:56:38.066400
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    assert get_workbench().get_variable(_OPTION_NAME).get() == False



# Generated at 2022-06-24 07:56:40.796571
# Unit test for function toggle_variable
def test_toggle_variable():
    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == True

# Generated at 2022-06-24 07:56:43.051444
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME,False)
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == True

# Generated at 2022-06-24 07:56:46.344215
# Unit test for function update_environment
def test_update_environment():
    return get_workbench().in_simple_mode()
    # update_environment()
    # assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:56:54.882433
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench

    wb = get_workbench()
    original_env = os.environ.copy()

# Generated at 2022-06-24 07:56:59.615252
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_option(_OPTION_NAME, True)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True



# Generated at 2022-06-24 07:57:06.197728
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default(_OPTION_NAME, True)
    get_workbench().set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"

    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"

    get_workbench().set_default(_OPTION_NAME, True)
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().set_simple_

# Generated at 2022-06-24 07:57:09.687817
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    assert not wb.get_option(_OPTION_NAME)

    toggle_variable()
    
    assert wb.get_option(_OPTION_NAME)

# Generated at 2022-06-24 07:57:12.591532
# Unit test for function toggle_variable
def test_toggle_variable():
    print("Unit test for function toggle_variable")
    get_workbench().set_default(_OPTION_NAME, True)
    assert toggle_variable() == None

# Generated at 2022-06-24 07:57:16.225447
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True

# Generated at 2022-06-24 07:57:23.925827
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = "false"
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    os.environ["PGZERO_MODE"] = "false"
    get_workbench().set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"


if __name__ == "__main__":
    import unittest

    unittest.main()

# Generated at 2022-06-24 07:57:35.168206
# Unit test for function update_environment
def test_update_environment():
    workbench = type("", (), {})()
    workbench.get_option = lambda option_name: True
    workbench.set_option = lambda option_name, value: None
    workbench.in_simple_mode = lambda: False

    with patch.object(sys, "platform", "posix"):
        if "PGZERO_MODE" in os.environ:
            del os.environ["PGZERO_MODE"]

        assert "PGZERO_MODE" not in os.environ
        update_environment()
        assert "PGZERO_MODE" in os.environ
        assert os.environ["PGZERO_MODE"] == "True"

    with patch.object(sys, "platform", "posix"):
        if "PGZERO_MODE" in os.environ:
            del os.environ

# Generated at 2022-06-24 07:57:39.955482
# Unit test for function load_plugin
def test_load_plugin():
    # Clearing up
    if _OPTION_NAME in get_workbench().get_variables():
        get_workbench().unset_variable(_OPTION_NAME)
    # Running load_plugin
    load_plugin()

    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    assert get_workbench().in_simple_mode() == False
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:57:51.486056
# Unit test for function toggle_variable
def test_toggle_variable():
    # For testing purpose, you need to set a variable name
    # _OPTION_NAME = "thonny_variable_name"
    # with value = False, variable_value = False
    # with value = True, variable_value = True
    
    if get_workbench().get_variable(_OPTION_NAME).get() == True:
        get_workbench().get_variable(_OPTION_NAME).set(False)
        assert get_workbench().get_variable(_OPTION_NAME).get() == False
        update_environment()
        # Test for state of value being False
        toggle_variable()
    else:
        # Test for state of value being True
        get_workbench().get_variable(_OPTION_NAME).set(True)
        assert get_workbench().get_variable(_OPTION_NAME).get() == True

# Generated at 2022-06-24 07:58:02.773420
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import patch
    from thonny import get_workbench
    from thonny.ui_utils import (
        show_dialog,
        ask_for_string,
        ask_for_bool,
        ask_for_integer,
        ask_for_float,
        ask_for_color,
    )


# Generated at 2022-06-24 07:58:07.961832
# Unit test for function load_plugin
def test_load_plugin():
    mw = get_workbench()
    mw.clear_message_log()

    load_plugin()
    assert "auto" == os.environ["PGZERO_MODE"]
    var = mw.get_variable(_OPTION_NAME)
    assert var.get() == False
    toggle_variable()
    assert var.get() == True
    assert "auto" == os.environ["PGZERO_MODE"]

# Generated at 2022-06-24 07:58:13.628293
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock
    from thonny.workbench import Workbench

    mock_workbench = Mock(spec=Workbench)
    mock_workbench.get_option.return_value = False
    mock_workbench.set_default.return_value = None
    mock_workbench.add_command.return_value = None

    old_workbench = get_workbench()

# Generated at 2022-06-24 07:58:15.275831
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()
    assert str(get_workbench().get_variable(_OPTION_NAME)) == "True"

# Generated at 2022-06-24 07:58:24.270322
# Unit test for function update_environment
def test_update_environment():
    process_env = {}
    process_env.update(os.environ)
    wb = get_workbench()

# Generated at 2022-06-24 07:58:34.166990
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    assert get_workbench().in_simple_mode()
    os.environ.pop("PGZERO_MODE", None)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    wb.set_simple_mode(False)
    assert not get_workbench().in_simple_mode()
    os.environ.pop("PGZERO_MODE", None)
    wb.set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"

    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"

# Generated at 2022-06-24 07:58:42.358009
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.in_simple_mode = lambda: False
    wb.get_variable = Mock(return_value=0)
    load_plugin()
    wb.add_command.assert_called_once_with(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    assert os.environ["PGZERO_MODE"] == "0"


if __name__ == "__main__":
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)

# Generated at 2022-06-24 07:58:52.340119
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench

    wb = get_workbench()
    wb.set_simple_mode(True)
    load_plugin()
    assert wb.get_variable(_OPTION_NAME).get() == False
    assert "PGZERO_MODE" in os.environ
    toggle_variable()
    assert wb.get_variable(_OPTION_NAME).get() == True
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert wb.get_variable(_OPTION_NAME).get() == False
    assert os.environ["PGZERO_MODE"] == "False"
    wb.set_simple_mode(False)
    update_environment()
    assert "PGZERO_MODE" in os.environ
    assert os.en

# Generated at 2022-06-24 07:59:02.909240
# Unit test for function load_plugin
def test_load_plugin():
    try:
        load_plugin()
        assert len(get_workbench().get_commands()) == 1
        assert get_workbench().get_default(_OPTION_NAME) == False
        assert get_workbench().get_option(_OPTION_NAME) == False
        assert os.environ["PGZERO_MODE"] == "False"
        # Test toggle_variable() via toggle_pgzero_mode
        get_workbench().get_command("toggle_pgzero_mode").execute()
        assert get_workbench().get_default(_OPTION_NAME) == False
        assert get_workbench().get_option(_OPTION_NAME) == True
        assert os.environ["PGZERO_MODE"] == "True"
    finally:
        get_workbench().unregister_command("toggle_pgzero_mode")

# Generated at 2022-06-24 07:59:09.766748
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.common import ConfigOption
    from thonny.globals import get_workbench
    workbench = Workbench()
    assert not workbench.in_simple_mode()
    assert not _OPTION_NAME in workbench.get_variable_names()

    load_plugin()
    assert _OPTION_NAME in workbench.get_variable_names()
    opt = workbench.get_variable(_OPTION_NAME)
    assert isinstance(opt, ConfigOption)
    assert not opt.get()
    assert os.environ["PGZERO_MODE"] == str(False)
    assert '{0}="false"'.format(_OPTION_NAME) in workbench.get_option("view.environment_variables")

# Generated at 2022-06-24 07:59:11.042942
# Unit test for function update_environment
def test_update_environment():
    assert os.environ["PGZERO_MODE"] == "0"

# Generated at 2022-06-24 07:59:17.616089
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_option("run.pgzero_mode", True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    wb.set_option("run.pgzero_mode", False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    wb.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    wb.set_option("run.pgzero_mode", True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:59:23.265097
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    wb.set_default(_OPTION_NAME, True)
    wb.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:59:27.170807
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.plugins.run import RunPlugin
    get_workbench().set_default("run.pgzero_mode", True)
    load_plugin()

    assert get_workbench().get_default("run.pgzero_mode") == True

    assert get_workbench().get_variable("run.pgzero_mode").get() == True
    toggle_variable()
    assert get_workbench().get_variable("run.pgzero_mode").get() == False

# Generated at 2022-06-24 07:59:35.626307
# Unit test for function update_environment
def test_update_environment():
    if get_workbench().in_simple_mode():
        os.environ["PGZERO_MODE"] = "auto"
    if get_workbench().get_option(_OPTION_NAME):
        os.environ["PGZERO_MODE"] = "True"
    else:
        os.environ["PGZERO_MODE"] = "False"
    assert os.environ["PGZERO_MODE"] == "False" or os.environ["PGZERO_MODE"] == "True" or os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:59:42.202291
# Unit test for function update_environment
def test_update_environment():
    # First without mocking os.environ
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"

    # Now mocking os.environ

# Generated at 2022-06-24 07:59:43.128783
# Unit test for function load_plugin
def test_load_plugin():
    pass # TODO: implement this test

# Generated at 2022-06-24 07:59:50.189994
# Unit test for function update_environment
def test_update_environment():

    def assert_pgzero_mode(expected):
        assert os.environ["PGZERO_MODE"] == str(expected)

    assert_pgzero_mode(False)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert_pgzero_mode(True)
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert_pgzero_mode(False)
    get_workbench().set_simple_mode()
    update_environment()
    assert_pgzero_mode("auto")

# Generated at 2022-06-24 07:59:54.173430
# Unit test for function update_environment
def test_update_environment():
    get_workbench().in_simple_mode = lambda : False
    get_workbench().get_option = lambda x : False
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().in_simple_mode = lambda : False
    get_workbench().get_option = lambda x : True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().in_simple_mode = lambda : True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 08:00:02.033630
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import workbench, ui_utils
    from thonny.ui_utils import Tester
    from thonny.misc_utils import running_on_mac_os
    from thonny.languages import ui_language

    wb = workbench.Workbench()
    wb._user_dir = None
    ui_utils.root = Tk()
    ui_utils.root.withdraw()

# Generated at 2022-06-24 08:00:12.271032
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.add_command = Mock()
    env = os.environ
    try:
        os.environ = {}
        load_plugin()
        assert not wb.get_variable(_OPTION_NAME).get()
        assert os.environ["PGZERO_MODE"] == "False"

        wb.in_simple_mode = lambda: True
        wb.set_variable(_OPTION_NAME, True)
        update_environment()
        wb.in_simple_mode = lambda: False

        assert wb.get_variable(_OPTION_NAME).get()
        assert os.environ["PGZERO_MODE"] == "True"
    finally:
        os.environ = env

# Generated at 2022-06-24 08:00:22.202428
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench

    wb = get_workbench()
    global_config = wb.load_global_config()
    wb.set_option("run.pgzero_mode", False)
    assert os.getenv("PGZERO_MODE") == "False"
    wb.set_option("run.pgzero_mode", True)
    assert os.getenv("PGZERO_MODE") == "True"
    wb.set_simple_mode()
    update_environment()
    assert os.getenv("PGZERO_MODE") == "auto"
    wb.set_advanced_mode()
    update_environment()
    assert os.getenv("PGZERO_MODE") == "True"

# Generated at 2022-06-24 08:00:32.792735
# Unit test for function load_plugin
def test_load_plugin():
    from unittest import mock
    from thonny import get_workbench
    from thonny.workbench import Workbench

    wb = Workbench()

    with mock.patch("thonny.workbench.Workbench.add_command") as mocked_add_command:
        with mock.patch("thonny.workbench.Workbench.register_variable") as mocked_register_var:
            with mock.patch("thonny.workbench.Workbench.set_option") as mocked_set_option:
                load_plugin()

    mocked_add_command.assert_called_with("toggle_pgzero_mode", "run", "Pygame Zero mode", toggle_variable, flag_name="run.pgzero_mode", group=40)
    mocked_register_var.assert_called_with("run.pgzero_mode")


# Generated at 2022-06-24 08:00:36.656539
# Unit test for function toggle_variable
def test_toggle_variable():
    var = get_workbench().get_variable(_OPTION_NAME)
    var.set(False)
    toggle_variable()
    assert var.get() == True
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert var.get() == False
    assert os.environ["PGZERO_MODE"] == "False"


# Generated at 2022-06-24 08:00:40.927421
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import Mock

    wb = Mock()
    wb.get_option = lambda key: False
    get_workbench.cache_clear()
    get_workbench.cache = lambda: wb

    os.environ["PGZERO_MODE"] = None
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    wb.get_option = lambda key: True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 08:00:43.209962
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()

# Generated at 2022-06-24 08:00:46.140711
# Unit test for function update_environment
def test_update_environment():
    get_workbench().in_simple_mode = lambda: False
    get_workbench().get_option = lambda key: True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"



# Generated at 2022-06-24 08:00:48.803776
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    assert not get_workbench().get_option(_OPTION_NAME)
    
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME)
    
    toggle_variable()
    assert not get_workbench().get_option(_OPTION_NAME)

# Generated at 2022-06-24 08:00:49.314420
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()

# Generated at 2022-06-24 08:00:58.772744
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.testing import run_test_driver
    from thonny.plugins.pgzero_mode.pgzero_mode import toggle_variable
    from thonny.workbench import Workbench
    from thonny import get_runner
    from unittest.mock import Mock
    from thonny.testing import get_runner, TkTestRunner
    from thonny.tktextext import CustomizedPythonText
    get_runner().edit_source("", "")
    run_test_driver(toggle_variable)
    assert "PGZERO_MODE" in os.environ
    assert os.environ["PGZERO_MODE"] == "False"
    run_test_driver(toggle_variable)
    assert "PGZERO_MODE" in os.environ
    assert os.environ["PGZERO_MODE"]

# Generated at 2022-06-24 08:01:02.118440
# Unit test for function toggle_variable
def test_toggle_variable():
    var = get_workbench().get_variable(_OPTION_NAME)
    var.set(True)
    toggle_variable()
    assert var.get() == False
    toggle_variable()
    assert var.get() == True

# Generated at 2022-06-24 08:01:13.800549
# Unit test for function toggle_variable
def test_toggle_variable():
    from unittest.mock import Mock
    from thonny.workbench import Workbench
    from thonny.shell import ShellView

    get_workbench = Mock(Workbench)
    get_workbench.get_variable.return_value.get.return_value = False
    get_workbench.get_option.return_value = False
    mock_shell = Mock(ShellView)
    get_workbench.get_view.return_value = mock_shell

    toggle_variable()
    assert get_workbench.get_variable.call_count == 1
    assert get_workbench.get_variable._mock_call_args_list[0][0] == (_OPTION_NAME)
    assert get_workbench.get_variable.return_value.set.call_count == 1
    assert get_workbench.get

# Generated at 2022-06-24 08:01:18.397870
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import Mock
    from thonny.workbench import Workbench
    wb = Workbench()
    wb.get_option = Mock(return_value=False)
    wb.in_simple_mode = Mock(return_value=True)
    update_environment()
    wb.get_option.assert_called_once_with(_OPTION_NAME)
    assert os.environ["PGZERO_MODE"] == "auto"


if __name__ == "__main__":
    import unittest
    from thonny.globals import init_basic_configuration
    from thonny.workbench import Workbench

    init_basic_configuration()
    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)

# Generated at 2022-06-24 08:01:25.452982
# Unit test for function toggle_variable
def test_toggle_variable():
    from unittest.mock import Mock
    import logging
    import os
    import tempfile
    import tkinter as tk
    import traceback
    from thonny.plugins.micropython import MicroPythonProxy, MicroPythonBackend, MicroPythonProxyHandler, set_active_backend, get_active_backend, get_option
    from thonny.plugins.micropython import get_running_interpreter_info, is_interpreter_running
    import thonny.running
    import thonny.plugins.micropython as micropython
    import thonny.plugins.micropython as mp
    import thonny.plugins.micropython as mp
    from thonny.codeview import CodeViewText
    from thonny.tktextext import TextEditor
    from thonny import get_work

# Generated at 2022-06-24 08:01:29.207741
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, True)
    load_plugin()

    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()

    assert os.environ["PGZERO_MODE"] == "False"