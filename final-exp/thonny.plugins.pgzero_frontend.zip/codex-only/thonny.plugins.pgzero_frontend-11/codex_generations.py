

# Generated at 2022-06-24 07:51:32.815289
# Unit test for function toggle_variable
def test_toggle_variable():
    from unittest.mock import Mock
    from thonny.config import ConfigurationProxy
    from thonny.workbench import Workbench

    # Create mock objects
    config_proxy = Mock(spec=ConfigurationProxy)
    workbench = Mock(spec=Workbench)
    configuration_proxy = Mock(spec=ConfigurationProxy)

    # Start with the option turned off
    config_proxy.get_option.return_value = False
    workbench.get_option.return_value = False
    os.environ["PGZERO_MODE"] = "False"
    toggle_variable()

    # The option should be turned on now
    assert workbench.get_option.return_value == True
    assert os.environ["PGZERO_MODE"] == "True"

    # Try turning it off

# Generated at 2022-06-24 07:51:37.876090
# Unit test for function toggle_variable
def test_toggle_variable():
    old = get_workbench().in_simple_mode()
    toggle_variable()
    assert old == get_workbench().in_simple_mode()
    toggle_variable()
    assert old != get_workbench().in_simple_mode()
    toggle_variable()
    assert old == get_workbench().in_simple_mode()


# Unit tests for function update_environment

# Generated at 2022-06-24 07:51:43.905612
# Unit test for function toggle_variable
def test_toggle_variable():
    config = get_workbench().get_variable(_OPTION_NAME)
    toggle_variable()
    assert config.get() != get_workbench().get_variable(_OPTION_NAME).get()

# Generated at 2022-06-24 07:51:46.197153
# Unit test for function toggle_variable
def test_toggle_variable():
    original_value = get_workbench().get_variable(_OPTION_NAME).get()
    toggle_variable()
    new_value = get_workbench().get_variable(_OPTION_NAME).get()
    assert new_value != original_value
    toggle_variable()
    assert new_value == original_value

# Generated at 2022-06-24 07:51:51.312409
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    wb.set_simple_mode(False)
    wb.set_variable(_OPTION_NAME, True)
    assert os.environ["PGZERO_MODE"] == str(True)
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == str(False)
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == str(True)
    wb.set_simple_mode(True)
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:51:57.765775
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"
    print("Tested: toggle_variable")

# Generated at 2022-06-24 07:51:58.250667
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()

# Generated at 2022-06-24 07:52:06.334019
# Unit test for function toggle_variable
def test_toggle_variable():
    command_manager = get_workbench().get_command_manager()
    command = command_manager.commands['toggle_pgzero_mode']
    get_workbench().set_option(_OPTION_NAME, True)
    toggle_variable()
    assert False == get_workbench().get_option(_OPTION_NAME)
    assert 'checkbutton' == command.bitmap_name
    toggle_variable()
    assert True == get_workbench().get_option(_OPTION_NAME)
    assert 'checkbutton_checked' == command.bitmap_name

# Generated at 2022-06-24 07:52:11.594896
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    assert wb.get_option(_OPTION_NAME) == False

# Generated at 2022-06-24 07:52:18.252916
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.plugins.run import RunPlugin
    from thonny.languages import english
    from thonny import get_workbench

    get_workbench().set_default(_OPTION_NAME, True)
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True

# Generated at 2022-06-24 07:52:25.914344
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock

    load_plugin()
    assert "run.pgzero_mode" in get_workbench().get_defaults()
    assert not get_workbench().get_variable(_OPTION_NAME).get()
    assert get_workbench().get_option(_OPTION_NAME)

    old_get_defaults = get_workbench().get_defaults
    old_set_default = get_workbench().set_default
    old_get_variable = get_workbench().get_variable
    old_add_command = get_workbench().add_command
    get_workbench().get_defaults = Mock()
    get_workbench().set_default = Mock()
    get_workbench().get_variable = Mock()
    get_workbench().add_command = Mock()
    get_work

# Generated at 2022-06-24 07:52:30.236711
# Unit test for function toggle_variable
def test_toggle_variable():
    var = get_workbench().get_variable(_OPTION_NAME)
    # Start with var False
    assert var.get() == False
    toggle_variable()
    assert var.get() == True
    toggle_variable()
    assert var.get() == False

# Generated at 2022-06-24 07:52:40.494471
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.globals import get_runner
    from thonny.workbench import Workbench
    from thonny.plugins.run import run
    import thonny.languages.rst2html

    # original value of the variable
    var_value = "test value"

    # mock the variable so only _OPTION_NAME is used in tesing
    class MockVar(object):
        def __init__(self):
            self._value = var_value

        def get(self):
            return self._value

        def set(self, new_value):
            self._value = new_value

    # mock a simple_mode class
    class MockWorkbench(object):
        def __init__(self):
            self._simple_mode = False

        def in_simple_mode(self):
            return self._

# Generated at 2022-06-24 07:52:42.094835
# Unit test for function load_plugin
def test_load_plugin():
    # pylint: disable=unused-variable
    import thonnycontrib.pgzero



# Generated at 2022-06-24 07:52:49.306801
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    assert os.environ["PGZERO_MODE"] == str(False)
    get_workbench().set_default(_OPTION_NAME, True)
    load_plugin()
    assert os.environ["PGZERO_MODE"] == str(True)
    get_workbench().set_simple_mode(True)
    load_plugin()
    assert os.environ["PGZERO_MODE"] == str("auto")


if __name__ == "__main__":
    test_load_plugin()

# Generated at 2022-06-24 07:52:58.464706
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    assert wb.get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"
    wb.set_simple_mode()
    assert wb.in_simple_mode() == True
    assert os.environ["PGZERO_MODE"] == "auto"
    toggle_variable()
    assert wb.get_

# Generated at 2022-06-24 07:53:07.584146
# Unit test for function load_plugin
def test_load_plugin():
    from unittest import mock
    from thonny import get_workbench, get_runner

    mock_set_default = mock.Mock()
    mock_add_command = mock.Mock()
    mock_get_runner = mock.Mock()

    with mock.patch('thonny.plugins.pgzero_mode.get_workbench',
                    return_value=mock.Mock()), \
         mock.patch('thonny.plugins.pgzero_mode.get_runner',
                    return_value=mock_get_runner):
        mock_get_workbench = get_workbench()
        mock_get_workbench.set_default = mock_set_default
        mock_get_workbench.add_command = mock_add_command

        load_plugin()
        mock_set_default.assert_called

# Generated at 2022-06-24 07:53:08.123559
# Unit test for function load_plugin
def test_load_plugin():
    # TODO: finish unit test
    pass

# Generated at 2022-06-24 07:53:12.137037
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.common import InlineCommand
    from unittest.mock import patch

    with patch("thonny.plugins.pgzero_mode.get_workbench", return_value=get_workbench()):
        toggle_variable()
        cmd = InlineCommand("toggle_pgzero_mode")
        assert cmd.get_flag_state() == True



# Generated at 2022-06-24 07:53:21.435621
# Unit test for function update_environment
def test_update_environment():
    import os
    dummy_workbench = type("DummyWorkbench", (), {"in_simple_mode": False})
    dummy_workbench.get_option = lambda self, name, default=None: True
    dummy_workbench.set_option = lambda self, name, value: None
    get_workbench.cache_clear()
    get_workbench.cache[None] = dummy_workbench()
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    dummy_workbench.in_simple_mode = lambda self: True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:53:27.350107
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    workbench = get_workbench()
    assert workbench.get_default(_OPTION_NAME) == False
    assert workbench.get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"
    assert toggle_variable() == None
    assert workbench.get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:53:30.090245
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True

    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-24 07:53:36.567231
# Unit test for function load_plugin
def test_load_plugin():
    w = get_workbench()
    change_dir_to_thonny_root()
    # Test get_option and set_default
    w.set_option(_OPTION_NAME, "false")
    w.set_default(_OPTION_NAME, False)
    assert w.get_option(_OPTION_NAME) == False
    w.set_default(_OPTION_NAME, True)
    assert w.get_option(_OPTION_NAME) == False
    # Test add_command
    w.set_option(_OPTION_NAME, "true")
    toggle_variable()
    assert w.get_option(_OPTION_NAME) == False
    os.environ["PGZERO_MODE"] = "auto"
    w.set_option(_OPTION_NAME, True)
    toggle_variable()

# Generated at 2022-06-24 07:53:37.125067
# Unit test for function load_plugin
def test_load_plugin():
    # TODO: Create tests
    pass

# Generated at 2022-06-24 07:53:44.622575
# Unit test for function toggle_variable
def test_toggle_variable():
    set_default_flag = get_workbench().set_default
    set_default_flag(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME)
    toggle_variable()
    assert not get_workbench().get_option(_OPTION_NAME)
    set_default_flag(_OPTION_NAME, True)
    toggle_variable()
    assert not get_workbench().get_option(_OPTION_NAME)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME)

# Generated at 2022-06-24 07:53:46.820130
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, True)
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"



# Generated at 2022-06-24 07:53:50.135676
# Unit test for function toggle_variable
def test_toggle_variable():
    var = get_workbench().get_variable(_OPTION_NAME)
    var.set(False)
    toggle_variable()
    assert var.get()
    toggle_variable()
    assert not var.get()


# Generated at 2022-06-24 07:53:55.910091
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, True)
    load_plugin()

    assert "PGZERO_MODE" in os.environ

    command = wb.get_command("toggle_pgzero_mode")

    assert command.flag_name == _OPTION_NAME
    assert command.label == tr("Pygame Zero mode")
    assert wb.get_option("run.pgzero_mode")


if __name__ == "__main__":
    test_load_plugin()

# Generated at 2022-06-24 07:54:04.560714
# Unit test for function update_environment
def test_update_environment():
    import os
    from thonny import get_workbench

    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    from thonny.workbench import _in_simple_mode
    _in_simple_mode = True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:54:08.719090
# Unit test for function toggle_variable
def test_toggle_variable():
    # setUp
    get_workbench().set_option(_OPTION_NAME, False)
    assert not (get_workbench().get_option(_OPTION_NAME))
    # Test
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME)

# Generated at 2022-06-24 07:54:18.428614
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.plugins.run import run_backend
    from thonny.common import InlineCommand

    # Refresh backend to run unit tests
    run_backend.terminate_backend()
    assert run_backend.backend_process is None
    run_backend._set_up_backend_process()

    # Assign get_workbench() to global variable wb
    wb = get_workbench()

    # Assign option name to global variable option_name
    option_name = "run.pgzero_mode"

    # Get current value of option_name
    option_value_before_toggle = wb.get_option(option_name)

    # Toggle option_name
    toggle_variable()

    # Get new value of option_name
    option_value_after_toggle = wb.get_

# Generated at 2022-06-24 07:54:29.477856
# Unit test for function load_plugin
def test_load_plugin():
    from unittest import mock
    from thonny.workbench import Workbench

    get_workbench().set_default(_OPTION_NAME, True)
    # os.environ["PGZERO_MODE"] = "1"
    wb = Workbench()
    with mock.patch.object(wb, "get_variable") as mock_get_variable, mock.patch.object(
        wb, "add_command"
    ) as mock_add_command:
        load_plugin()
        # assert mock_get_variable.called
        assert mock_add_command.called
        # assert os.environ["PGZERO_MODE"] == "0"
    # os.environ["PGZERO_MODE"] = "1"
    get_workbench().set_default(_OPTION_NAME, False)

# Generated at 2022-06-24 07:54:34.337376
# Unit test for function update_environment
def test_update_environment():
    # Test in simple mode and verifying that PGZERO_MODE is set to 'auto'
    get_workbench().set_in_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    # Test in normal mode and verifying that PGZERO_MODE is set to 'False'
    get_workbench().set_in_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:54:40.666983
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import patch

    with patch("thonny.ui_utils.is_mac_app_bundle"):
        get_workbench().allow_non_simple_mode("TEST")
        update_environment()
        os.environ["PGZERO_MODE"].should.equal("False")

        get_workbench().disallow_non_simple_mode("TEST")
        update_environment()
        os.environ["PGZERO_MODE"].should.equal("auto")

# Generated at 2022-06-24 07:54:48.876672
# Unit test for function update_environment
def test_update_environment():
    from os import unsetenv
    from unittest.mock import Mock
    from thonny.workbench import Workbench

    workbench = Workbench()
    workbench.in_simple_mode = Mock(return_value=True)
    update_environment()
    assert os.getenv("PGZERO_MODE") == "auto"

    workbench.in_simple_mode.return_value = False
    workbench.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.getenv("PGZERO_MODE") == "True"

    workbench.set_option(_OPTION_NAME, False)
    update_environment()
    assert os.getenv("PGZERO_MODE") == "False"

# Generated at 2022-06-24 07:55:00.365579
# Unit test for function load_plugin
def test_load_plugin():
    WB = Workbench()
    load_plugin()

    # Checking if "Pygame Zero mode" is added.
    WB.set_default(_OPTION_NAME, True)
    command = WB.get_command("toggle_pgzero_mode")
    assert command is not None
    assert command.get_label() == "Pygame Zero mode"

    # Checking if the variable (set to true) is present in the environment.
    WB.set_default(_OPTION_NAME, True)
    assert os.environ.get("PGZERO_MODE", "auto") == "True"

    # Checking if the variable (set to false) is present in the environment.
    WB.set_default(_OPTION_NAME, False)
    assert os.environ.get("PGZERO_MODE", "auto") == "False"

    # Checking if the

# Generated at 2022-06-24 07:55:08.825854
# Unit test for function update_environment
def test_update_environment():
    from thonny.misc_utils import running_on_mac_os
    from unittest.mock import patch

    # This makes a separate workbench for testing,
    # so that we can change _OPTION_NAME safely
    _ = get_workbench()

    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_default(_OPTION_NAME, True)
    # not in simple mode
    assert not wb.in_simple_mode()

    # run in pygame zero mode
    with patch.dict("os.environ", {}):
        update_environment()
        assert os.environ["PGZERO_MODE"] == "True"

    # don't run in pygame zero mode
    wb.set_option(_OPTION_NAME, False)

# Generated at 2022-06-24 07:55:18.662317
# Unit test for function toggle_variable
def test_toggle_variable():
    global _variable_value
    _variable_value = False
    def _get_variable_value():
        return _variable_value
    def _set_variable_value(value):
        global _variable_value
        _variable_value = value
    old_var = get_workbench().get_variable
    def _get_variable(name):
        class Variable:
            def get(self):
                return _variable_value
            def set(self, value):
                global _variable_value
                _variable_value = value
        return Variable()
    get_workbench().get_variable = _get_variable
    toggle_variable()
    assert(_variable_value == True)
    toggle_variable()
    assert(_variable_value == False)
    get_workbench().get_variable = old_var

# Generated at 2022-06-24 07:55:21.957036
# Unit test for function update_environment
def test_update_environment():
    try:
        del os.environ["PGZERO_MODE"]
        update_environment()
        assert os.environ["PGZERO_MODE"] == "False"
    except:
        assert False, "cannot update PGZERO_MODE"

# Generated at 2022-06-24 07:55:24.904249
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    get_workbench().delete_command("toggle_pgzero_mode")
    assert not get_workbench().get_default(_OPTION_NAME)

# Generated at 2022-06-24 07:55:29.508962
# Unit test for function load_plugin
def test_load_plugin():
    wb = MockWorkbench()
    load_plugin()
    assert wb.get_variable(name=_OPTION_NAME).get() == False
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"
    del wb
    del os.environ["PGZERO_MODE"]


# Generated at 2022-06-24 07:55:33.754638
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    wb.set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:55:39.847055
# Unit test for function update_environment
def test_update_environment():
    for simple in [True, False]:
        for pygamezero in [True, False]:
            # Call update_environment()
            get_workbench().set_option(_OPTION_NAME, pygamezero)
            get_workbench().set_simple_mode(simple)
            update_environment()

            # Check results
            assert os.environ["PGZERO_MODE"] == str(
                simple or pygamezero
            ), "Simple mode: " + str(simple) + ", Pygame Zero mode: " + str(pygamezero)
            assert get_workbench().get_option(_OPTION_NAME) == pygamezero
            assert get_workbench().in_simple_mode() == simple

# Generated at 2022-06-24 07:55:42.846165
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import create_runner
    from thonny.misc_utils import running_on_windows

    runner = create_runner()
    runner.execute_source("EPPGZERO_MODE")
    runner.execute_source("EPPZERO_MODE")


# Generated at 2022-06-24 07:55:51.746522
# Unit test for function toggle_variable
def test_toggle_variable():
    from unittest import mock

    toggle_variable()
    get_workbench().set_variable(_OPTION_NAME, True)
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME) is False

    with mock.patch.dict("os.environ", {"PGZERO_MODE": "auto"}):
        toggle_variable()
        assert os.environ["PGZERO_MODE"] == "True"

    with mock.patch.dict("os.environ", {"PGZERO_MODE": "False"}):
        toggle_variable()
        assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:55:56.627594
# Unit test for function toggle_variable
def test_toggle_variable():
    global _OPTION_NAME
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert (os.environ["PGZERO_MODE"] == "True")
    toggle_variable()
    assert (os.environ["PGZERO_MODE"] == "False")
    _OPTION_NAME = "test.test"
    toggle_variable()
    assert (os.environ["PGZERO_MODE"] == "False")

# Generated at 2022-06-24 07:56:02.492681
# Unit test for function update_environment
def test_update_environment():
    env_key = "PGZERO_MODE"
    try:
        del os.environ[env_key]
        assert env_key not in os.environ
    except KeyError:
        pass

    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ[env_key] == "auto"

    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ[env_key] == "True"

    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ[env_key] == "False"

    get_workbench().set_simple_mode(True)
    update

# Generated at 2022-06-24 07:56:05.760165
# Unit test for function update_environment
def test_update_environment():
    workbench = get_workbench()
    var = workbench.get_variable(_OPTION_NAME)
    var.set(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    var.set(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    workbench.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:56:08.305599
# Unit test for function toggle_variable
def test_toggle_variable():
    initial_value = get_workbench().get_option(_OPTION_NAME)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) != initial_value


# Generated at 2022-06-24 07:56:16.857043
# Unit test for function update_environment
def test_update_environment():
    # test 1: in_simple_mode == False, PGZERO_MODE_OPTION == False
    get_workbench().set_option(_OPTION_NAME, False, persist=False)
    get_workbench().set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    # test 2: in_simple_mode == True, PGZERO_MODE_OPTION == False
    get_workbench().set_option(_OPTION_NAME, False, persist=False)
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    # test 3: in_simple_mode == False, PGZERO_MODE_OPTION == True
    get_workbench

# Generated at 2022-06-24 07:56:21.084790
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    assert not wb.get_variable(_OPTION_NAME).get()
    load_plugin()
    assert wb.get_variable(_OPTION_NAME).get()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:56:28.062100
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_simple_mode(False)
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    assert "PGZERO_MODE" in os.environ
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    # Test that it's not set if we're in simple mode
    get_workbench().set_simple_mode(True)
    load_plugin()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:56:30.742166
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    assert int(get_workbench().get_variable(_OPTION_NAME)) == False
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert int(get_workbench().get_variable(_OPTION_NAME)) == True
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:56:32.631128
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()


# Generated at 2022-06-24 07:56:34.842594
# Unit test for function toggle_variable

# Generated at 2022-06-24 07:56:38.661647
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_option(_OPTION_NAME, True)
    toggle_variable()
    assert not get_workbench().get_option(_OPTION_NAME)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME)

# Generated at 2022-06-24 07:56:49.132113
# Unit test for function load_plugin
def test_load_plugin():
    # pylint: disable=protected-access
    from unittest.mock import Mock
    from thonny.workbench import Workbench
    from thonny.options_page import OptionsPage

    workbench = Workbench()
    get_workbench = Mock(return_value=workbench)
    set_default = Mock()
    add_command = Mock()
    workbench.add_command = add_command
    workbench.set_default = set_default

    globals()["get_workbench"] = get_workbench
    globals()["set_default"] = set_default

    load_plugin()

    workbench.set_default.assert_any_call(_OPTION_NAME, False)
    assert isinstance(workbench.get_command("toggle_pgzero_mode"), OptionsPage)

# Generated at 2022-06-24 07:56:52.985672
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()
    assert "PGZERO_MODE" in os.environ
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert "PGZERO_MODE" in os.environ
    assert os.environ["PGZERO_MODE"] == "False"


# Generated at 2022-06-24 07:57:00.319566
# Unit test for function toggle_variable
def test_toggle_variable():
    # Sets the value of the variable to True.
    if(get_workbench().get_variable(_OPTION_NAME) == False):
        toggle_variable()
        # Checks to see if the variable has been set to true
        assert(get_workbench().get_variable(_OPTION_NAME) == True)
    # Sets the value of the variable to False.
    elif(get_workbench().get_variable(_OPTION_NAME) == True):
        toggle_variable()
        # Checks to see if the variable has been set to false
        assert(get_workbench().get_variable(_OPTION_NAME) == False)

# Generated at 2022-06-24 07:57:03.168674
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:57:11.824944
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    wb.set_simple_mode(True)
    wb.set_option(_OPTION_NAME, True)
    assert wb.in_simple_mode()
    assert wb.get_option(_OPTION_NAME)

    toggle_variable()
    assert not wb.in_simple_mode()
    assert not wb.get_option(_OPTION_NAME)

    toggle_variable()
    assert not wb.in_simple_mode()
    assert not wb.get_option(_OPTION_NAME)


if __name__ == "__main__":
    test_toggle_variable()

# Generated at 2022-06-24 07:57:17.025806
# Unit test for function update_environment
def test_update_environment():
    # only testing the effect on the environment variable
    env = {
        "VAR1": "ABC",
        "VAR2": 1234,
    }
    get_workbench().set_default(_OPTION_NAME, False)
    assert env["PGZERO_MODE"] == "auto"

    get_workbench().set_default(_OPTION_NAME, True)
    assert env["PGZERO_MODE"] == "True"

    get_workbench().set_default(_OPTION_NAME, False)
    assert env["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:57:26.256299
# Unit test for function load_plugin
def test_load_plugin():
    import thonny.workbench as wb
    import os

    get_workbench().__class__ = wb.WorkbenchMockup

    for btn in get_workbench().add_command_buttons:
        if btn.label == "Pygame Zero mode":
            btn.destroy()

    get_workbench().set_default(_OPTION_NAME, False)

    assert get_workbench().get_option(_OPTION_NAME) == False

    load_plugin()

    for btn in get_workbench().add_command_buttons:
        if btn.label == "Pygame Zero mode":
            btn.invoke()

    assert get_workbench().get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"


# Generated at 2022-06-24 07:57:34.382090
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench

    wb = Workbench()
    load_plugin()
    assert wb.in_simple_mode() == False
    assert wb.get_default(_OPTION_NAME) == False

    toggle_variable()
    assert wb.get_variable(_OPTION_NAME).get() == True
    assert wb.get_default(_OPTION_NAME) == False

    wb.set_simple_mode()
    update_environment()
    os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:57:39.355148
# Unit test for function toggle_variable
def test_toggle_variable():
    try:
        del os.environ["PGZERO_MODE"]
    except KeyError:
        print("PGZERO_MODE not defined")

    assert os.environ.get("PGZERO_MODE") is None
    toggle_variable()
    assert os.environ.get("PGZERO_MODE") == "True"
    toggle_variable()
    assert os.environ.get("PGZERO_MODE") == "False"

# Generated at 2022-06-24 07:57:39.885247
# Unit test for function toggle_variable
def test_toggle_variable():
    pass

# Generated at 2022-06-24 07:57:48.954534
# Unit test for function toggle_variable
def test_toggle_variable():
    from unittest.mock import patch, Mock
    import thonny
    from thonny.config import get_workbench
    from thonny.globals import get_runner
    import os

    thonny.create_and_setup_workbench()

    assert get_workbench().get_option("run.pgzero_mode") == False
    assert os.environ["PGZERO_MODE"] == "False"

    toggle_variable()

    assert get_workbench().get_option("run.pgzero_mode") == True
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:57:54.280686
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_variable(_OPTION_NAME, False)
    assert get_workbench().get_variable(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME) == False

# Generated at 2022-06-24 07:58:01.574550
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.register_editor_notebook(MockEditorNotebook())
    load_plugin()
    assert wb.get_option(_OPTION_NAME) == False
    assert wb.get_command("toggle_pgzero_mode").flag_name == _OPTION_NAME
    assert wb.get_command("toggle_pgzero_mode").group == 40
    assert wb.get_command("toggle_pgzero_mode").label == tr("Pygame Zero mode")



# Generated at 2022-06-24 07:58:11.801820
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.languages import English
    from thonny.misc_utils import running_on_mac_os
    from thonny.workbench import Workbench
    from unittest import TestCase

    class Tester(TestCase):
        def setUp(self):
            self.original_language = get_workbench().get_language()
            get_workbench().set_language(English)

        def tearDown(self):
            get_workbench().set_language(self.original_language)
            get_workbench().set_default(_OPTION_NAME, False)

        def test_menu_mac(self):
            if not running_on_mac_os():
                return

            wb = Workbench()
            wb.set_default("run.show_debug_variables", True)

# Generated at 2022-06-24 07:58:17.176960
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    load_plugin()
    assert "toggle_pgzero_mode" in set(c.get_id() for c in wb.get_commands())
    assert "run.pgzero_mode" in wb.get_option_names()
    assert not wb.get_option("run.pgzero_mode")
    assert "PGZERO_MODE=False" in os.environ["THONNY_USER_DIR"]

# Generated at 2022-06-24 07:58:22.595732
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    
    # set option and env
    toggle_variable()
    assert wb.in_simple_mode() == False
    assert os.environ["PGZERO_MODE"] == "True"
    
    # unset option and env
    toggle_variable()
    assert wb.in_simple_mode() == True
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:58:32.930641
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import MagicMock
    from thonny.globals import get_workbench
    
    workbench = MagicMock(name="Workbench")
    workbench.in_simple_mode.return_value = False
    workbench.get_option.return_value = False
    
    get_workbench.return_value = workbench
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"
    workbench.get_option.return_value = True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"
    workbench.in_simple_mode.return_value = True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:58:38.067062
# Unit test for function update_environment
def test_update_environment():
    from thonny.globals import get_runner
    from thonny.misc_utils import running_on_windows, TemporaryDirectory
    from thonny.workbench import Workbench
    from thonny.plugins.run import SimpleScriptRunner
    from unittest.mock import Mock

    workbench = Workbench()
    workbench.set_default(_OPTION_NAME, True)

    # Test that the tool is configured correctly
    assert get_workbench().get_option(_OPTION_NAME)

    # Ensure that the environment is empty
    assert not os.environ.get("PGZERO_MODE")

    # Test, that the environment value is set correctly
    update_environment()
    assert os.environ.get("PGZERO_MODE")

    # Test, that the environment value is reset correctly
    workbench.set_

# Generated at 2022-06-24 07:58:45.775299
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_runner
    from thonny.plugins.micropython_plugin import MicroPythonProxy

    for option in options:
        get_workbench().set_option(_OPTION_NAME, option)
        update_environment()
        assert os.environ["PGZERO_MODE"] == str(option)

    get_workbench().set_option(_OPTION_NAME, True)
    get_runner().set_backend_class(MicroPythonProxy)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"

# Generated at 2022-06-24 07:58:52.708913
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    wb.set_simple_mode(True)
    assert wb.get_option(_OPTION_NAME) == False
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == False

    wb.set_simple_mode(False)
    assert wb.get_option(_OPTION_NAME) == False
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == True
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == False

# Generated at 2022-06-24 07:59:03.297541
# Unit test for function toggle_variable
def test_toggle_variable():
    old_PGZERO_MODE = os.environ.get("PGZERO_MODE")
    try:
        os.environ["PGZERO_MODE"] = ""
        get_workbench().set_option("run.pgzero_mode", False)
        toggle_variable()
        assert get_workbench().get_option("run.pgzero_mode") == True
        assert os.environ["PGZERO_MODE"] == "1"
        toggle_variable()
        assert get_workbench().get_option("run.pgzero_mode") == False
        assert os.environ["PGZERO_MODE"] == "0"
    finally:
        if old_PGZERO_MODE is None:
            del(os.environ["PGZERO_MODE"])

# Generated at 2022-06-24 07:59:09.955095
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    assert "PGZERO_MODE" not in os.environ
    wb.set_simple_mode(True)
    wb.set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    wb.set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    wb.set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    del os.environ["PGZERO_MODE"]
    assert "PGZERO_MODE" not in os.environ
    update_environment()

# Generated at 2022-06-24 07:59:12.527728
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench

    get_workbench().in_simple_mode = lambda: True
    update_environment()
    get_workbench().in_simple_mode = lambda: False
    update_environment()

# Generated at 2022-06-24 07:59:15.385055
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:59:21.098580
# Unit test for function update_environment
def test_update_environment():
    from thonny.common import InlineCommand

    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    os.environ['PGZERO_MODE'] = "foo"

    update_environment()
    assert os.environ['PGZERO_MODE'] == "False"

    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ['PGZERO_MODE'] == "True"

# Generated at 2022-06-24 07:59:25.687994
# Unit test for function toggle_variable
def test_toggle_variable():
    assert (
        get_workbench().get_option("run.pgzero_mode") is False
    ), "run.pgzero_mode is False"
    toggle_variable()
    assert (
        get_workbench().get_option("run.pgzero_mode") is True
    ), "run.pgzero_mode is True"
    toggle_variable()
    assert (
        get_workbench().get_option("run.pgzero_mode") is False
    ), "run.pgzero_mode is False"

# Generated at 2022-06-24 07:59:29.517872
# Unit test for function update_environment
def test_update_environment():
    # GIVEN
    os.environ["PGZERO_MODE"] = ""
    get_workbench().set_simple_mode(True)
    get_workbench().set_option(_OPTION_NAME, True)

    # WHEN
    update_environment()

    # THEN
    assert os.environ["PGZERO_MODE"] == "auto"

    # WHEN
    get_workbench().set_simple_mode(False)
    update_environment()

    # THEN
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:59:38.996407
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock

    from thonny.workbench import Workbench

    mock_workbench = Mock(spec=Workbench)
    get_workbench = lambda: mock_workbench

    mock_workbench.in_simple_mode.return_value = False
    mock_workbench.get_option.return_value = True

    load_plugin()

    mock_workbench.set_default.assert_called_once_with(_OPTION_NAME, False)
    mock_workbench.add_command.assert_called_once()
    mock_workbench.get_option.assert_called_once_with(_OPTION_NAME)
    assert os.environ["PGZERO_MODE"] == "True"

    toggle_variable()


# Generated at 2022-06-24 07:59:42.172471
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    assert len(get_workbench().get_variable(_OPTION_NAME).get()) > 0
    get_workbench().set_default(_OPTION_NAME, True)
    load_plugin()
    assert len(get_workbench().get_variable(_OPTION_NAME).get()) > 0

# Generated at 2022-06-24 07:59:49.620477
# Unit test for function update_environment
def test_update_environment():
    # Imports required for function to run
    import os
    from thonny.workflow import SimpleWorkflowController
    from thonny.config_ui import ConfigurationPage
    from thonny.globals import get_workbench
    from thonny.plugins.run import RunConfigurationPage
    from thonny.running import get_interpreter_for_subprocess
    
    # Updates environment based on options
    update_environment()
    
    # Check correct environment added
    assert os.environ["PGZERO_MODE"] == str(get_workbench().get_option(_OPTION_NAME))
    

# Generated at 2022-06-24 07:59:59.522044
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench
    from unittest.mock import patch
    from thonny.shell import Shell

    bt = get_workbench()
    bt.set_default(_OPTION_NAME, False)
    from thonny.plugins.pgzeromode import load_plugin
    load_plugin()

    def _new_create_shell():
        return Shell(west=False)

    with patch("thonny.ui_utils.create_shell",sideeffect=_new_create_shell):
        bt.emulate_command("toggle_pgzero_mode")
        assert bt.get_option(_OPTION_NAME) == True
        bt.emulate_command("toggle_pgzero_mode")
        assert bt.get_option(_OPTION_NAME) == False

# Generated at 2022-06-24 08:00:11.053246
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench
    from unittest.mock import patch
    from thonny.config import get_workbench_contribution
    from thonny.plugins.run_pgzero import load_plugin, _OPTION_NAME

    with patch.object(get_workbench_contribution("Run"), "add_command", autospec=True) as mocked_meth:
        load_plugin()
        mocked_meth.assert_called_with(
            "toggle_pgzero_mode",
            "run",
            "Pygame Zero mode",
            "Toggles the Pygame Zero mode.",
            group=40, # Just above the "run" command
            flag_name=_OPTION_NAME,
            default_sequence="F5",
            needs_stop=False,
        )

    assert get_workbench

# Generated at 2022-06-24 08:00:19.134996
# Unit test for function update_environment
def test_update_environment():
    # get_workbench().in_simple_mode() should return False,
    # because we're running in special test mode
    # and we won't really initialize the workbench.
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().in_simple_mode = lambda: True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 08:00:21.655408
# Unit test for function update_environment
def test_update_environment():
    os.environ.pop("PGZERO_MODE", None)
    load_plugin()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 08:00:29.269037
# Unit test for function load_plugin
def test_load_plugin():
    from unittest import mock

    from thonny import get_workbench
    from thonny.plugins.run.pgzero_mode import (
        _OPTION_NAME,
        load_plugin,
        update_environment,
    )

    with mock.patch.dict(os.environ, {}):
        load_plugin()
        assert os.environ["PGZERO_MODE"] == "False"
        get_workbench().set_option(_OPTION_NAME, True)
        update_environment()
        assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 08:00:33.936350
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    load_plugin()
    assert os.environ["PGZERO_MODE"] == "False"
    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 08:00:40.565576
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import MagicMock
    wb = MagicMock()
    wb.get_option.side_effect = lambda oid: oid == _OPTION_NAME
    wb.set_default.side_effect = None
    wb.add_command.side_effect = None
    wb.set_option.side_effect = None
    old_wb = get_workbench()

# Generated at 2022-06-24 08:00:45.185425
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    origin_value = wb.get_variable(_OPTION_NAME)
    toggle_variable()

# Generated at 2022-06-24 08:00:48.658640
# Unit test for function toggle_variable
def test_toggle_variable():
    old_environment  = os.environ["PGZERO_MODE"]
    toggle_variable()
    new_environment  = os.environ["PGZERO_MODE"]
    assert old_environment != new_environment, "PGZERO_MODE has not changed"

# Generated at 2022-06-24 08:00:56.945922
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().unset_option(_OPTION_NAME)
    load_plugin()
    
    assert get_workbench().get_default(_OPTION_NAME) == False
    assert get_workbench().get_option(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().enter_simple_mode()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 08:01:05.253503
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.invoke_command("reset_test_data")
    assert not wb.get_option(_OPTION_NAME)
    assert os.environ.get("PGZERO_MODE") == "0"

    # Test state when pgzero_mode is available in simple_mode
    wb.set_simple_mode(True)
    load_plugin()
    assert wb.get_option(_OPTION_NAME)
    assert os.environ.get("PGZERO_MODE") == "auto"

    # Test state when pgzero_mode is not available in simple_mode
    wb.set_simple_mode(False)
    load_plugin()
    assert not wb.get_option(_OPTION_NAME)

# Generated at 2022-06-24 08:01:13.804305
# Unit test for function toggle_variable
def test_toggle_variable():
    # Test with pgzero_mode off 
    get_workbench().set_option(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"
    
    # Test with pgzero_mode on 
    get_workbench().set_option(_OPTION_NAME, True)
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 08:01:17.132839
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME)
    toggle_variable()
    assert not get_workbench().get_option(_OPTION_NAME)

# Generated at 2022-06-24 08:01:19.989809
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, True)
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME) == True

# Generated at 2022-06-24 08:01:22.778736
# Unit test for function load_plugin
def test_load_plugin():
    # this fails if any PGZERO setting has been set before
    get_workbench().set_simple_mode(False)
    load_plugin()
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"