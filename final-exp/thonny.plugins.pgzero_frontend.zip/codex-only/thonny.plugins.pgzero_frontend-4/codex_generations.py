

# Generated at 2022-06-24 07:51:34.101239
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_simple_mode(True)
    update_environment()
    assert "PGZERO_MODE" in os.environ
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert "PGZERO_MODE" in os.environ
    assert os.environ["PGZERO_MODE"] == "1"

# Generated at 2022-06-24 07:51:37.427017
# Unit test for function toggle_variable
def test_toggle_variable():
    print("\n test_toggle_variable")
    test_toggle_variable_1()
    test_toggle_variable_2()
    print("\n test_toggle_variable ok")



# Generated at 2022-06-24 07:51:42.373580
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) is False

# Generated at 2022-06-24 07:51:50.218096
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, True)
    wb.set_simple_mode(False)
    load_plugin()
    assert wb.get_variable(_OPTION_NAME).get() == True
    assert "PGZERO_MODE" in os.environ
    assert os.environ["PGZERO_MODE"] == "True"
    
    wb.set_simple_mode(True)
    load_plugin()
    assert wb.get_variable(_OPTION_NAME).get() == True
    assert "PGZERO_MODE" in os.environ
    assert os.environ["PGZERO_MODE"] == "auto"


# Generated at 2022-06-24 07:51:55.028979
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    os.environ["PGZERO_MODE"] = "auto"
    toggle_variable()
    assert get_workbench().get_value(_OPTION_NAME)
    assert os.environ["PGZERO_MODE"] == "1"

# Generated at 2022-06-24 07:51:57.202783
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME)

# Generated at 2022-06-24 07:51:59.838964
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.languages import english
    workbench = get_workbench()
    workbench._set_language(english)
    load_plugin()


if __name__ == "__main__":
    test_load_plugin()

# Generated at 2022-06-24 07:52:10.807838
# Unit test for function update_environment
def test_update_environment():
    if "PGZERO_MODE" in os.environ:
        del os.environ["PGZERO_MODE"]

    from thonny.globals import get_workbench

    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_option(_OPTION_NAME, False)
    get_workbench().set_simple_mode()
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:52:11.342300
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()

# Generated at 2022-06-24 07:52:16.867220
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, 1)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"

# Generated at 2022-06-24 07:52:25.095490
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench
    from thonny.misc_utils import running_on_mac_os, running_on_windows
    from thonny.config import get_runner, get_python_executable_path

    wb = get_workbench()
    old_pyexec_path = get_python_executable_path()

# Generated at 2022-06-24 07:52:25.992690
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    print("lol")

# Generated at 2022-06-24 07:52:28.946832
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = "auto"
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:52:39.290977
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.load_plugin(load_plugin)

    assert wb.get_variable(_OPTION_NAME).get() is False
    assert wb.get_option(_OPTION_NAME) is False
    wb.set_option(_OPTION_NAME, True)
    assert wb.get_option(_OPTION_NAME) is True
    assert wb.get_variable(_OPTION_NAME).get() is True
    wb.set_option(_OPTION_NAME, False)

    assert os.environ["PGZERO_MODE"] == "auto"
    wb.set_option(_OPTION_NAME, True)
    assert os.environ["PGZERO_MODE"] == "1"

    wb.destroy()



# Generated at 2022-06-24 07:52:45.260410
# Unit test for function update_environment
def test_update_environment():
    get_workbench().in_simple_mode = lambda: False
    get_workbench().get_option = lambda name: True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().get_option = lambda name: False
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().in_simple_mode = lambda: True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:52:49.305431
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import workbench
    workbench.create_workbench()
    load_plugin()

    assert workbench.get_variable("run.pgzero_mode").get() == False
    assert os.environ["PGZERO_MODE"] == "0"


# Generated at 2022-06-24 07:52:56.892435
# Unit test for function toggle_variable
def test_toggle_variable():
    debug_print("Running test suite on function toggle_variable")
    debug_print("Test 1: Test that the Pygame Zero mode is toggled on")
    toggle_variable()
    if os.environ["PGZERO_MODE"] == "True":
        debug_print("Test 1: Passed")
    else:
        debug_print("Test 1: Failed")
    debug_print("Test 2: Test that the Pygame Zero mode is toggled off")
    toggle_variable()
    if os.environ["PGZERO_MODE"] == "False":
        debug_print("Test 2: Passed")
    else:
        debug_print("Test 2: Failed")

# Generated at 2022-06-24 07:53:01.029617
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    command_id = "toggle_pgzero_mode"
    # check that load_plugin is correct
    assert command_id in get_workbench().commands
    # check that command is ok
    get_workbench().trigger_command(command_id)
    assert get_workbench().in_simple_mode()
    # now get back
    get_workbench().trigger_command(command_id)

# Generated at 2022-06-24 07:53:10.124143
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.plugins.cwd import cd_to_thonny_user_dir
    from thonny import get_workbench
    from thonny.config import set_option
    from thonny.config_ui import ConfigurationPage
    from thonny.misc_utils import running_on_mac_os
    from thonny.ui_utils import confirm_configuration
    cd_to_thonny_user_dir()
    set_option("run.pgzero_mode", True)
    set_option("view.show_environment_in_run", True)
    get_workbench().event_generate("StartupWindowCreated")
    get_workbench().event_generate("PluginActivated")
    get_workbench().event_generate("PluginActivated")
    

# Generated at 2022-06-24 07:53:16.088185
# Unit test for function load_plugin
def test_load_plugin():
    """
    Tests that load_plugin function runs without an error.
    """
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()

# Generated at 2022-06-24 07:53:21.482547
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    wb.set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:53:27.060278
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from unittest.mock import MagicMock

    mock_workbench = MagicMock(spec=Workbench)
    mock_workbench.in_simple_mode.return_value = False
    get_workbench.mock_return_value = mock_workbench
    os.environ = {}
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:53:30.781586
# Unit test for function toggle_variable
def test_toggle_variable():
    assert get_workbench().get_variable(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME) == False

# Generated at 2022-06-24 07:53:35.797746
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench
    
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ.get("PGZERO_MODE") == "False"
    
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ.get("PGZERO_MODE") == "True"
    
    get_workbench().set_simple_mode()
    update_environment()
    assert os.environ.get("PGZERO_MODE") == "auto"

# Generated at 2022-06-24 07:53:37.696577
# Unit test for function toggle_variable
def test_toggle_variable():
    expected_values = [False, True, False, True, False]
    workbench = get_workbench()
    var = workbench.get_variable(_OPTION_NAME)
    for x in expected_values:
        toggle_variable()
        assert var.get() == x

# Generated at 2022-06-24 07:53:41.655844
# Unit test for function toggle_variable
def test_toggle_variable():
    workbench = get_workbench()
    workbench.set_simple_mode(True)
    assert workbench.get_option(_OPTION_NAME) is False
    toggle_variable()
    assert workbench.get_option(_OPTION_NAME) is True
    toggle_variable()
    assert workbench.get_option(_OPTION_NAME) is False

# Generated at 2022-06-24 07:53:45.452771
# Unit test for function toggle_variable
def test_toggle_variable():
    initialMode = get_workbench()
    variable = get_workbench().get_variable(_OPTION_NAME)
    if variable.get():
        toggle_variable()
        assert variable.get() == False
    else:
        toggle_variable()
        assert variable.get() == True

# Generated at 2022-06-24 07:53:47.987742
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:53:51.518652
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_variable(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME) == True

    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME) == False

# Generated at 2022-06-24 07:53:53.530913
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    
    get_workbench().set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:53:55.591790
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-24 07:54:02.794101
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = "auto"
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"


# Generated at 2022-06-24 07:54:06.775752
# Unit test for function update_environment
def test_update_environment():
    os.environ.pop("PGZERO_MODE", None)
    get_workbench().set_default(_OPTION_NAME, False)
    assert os.environ["PGZERO_MODE"] == "0"

    get_workbench().set_default(_OPTION_NAME, True)
    assert os.environ["PGZERO_MODE"] == "1"

# Generated at 2022-06-24 07:54:17.073822
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock, patch
    from thonny import get_workbench

    # Mocking
    mock_register_command = Mock()
    mock_register_command.return_value = None
    mock_set_default = Mock()
    mock_set_default.return_value = None
    mock_get_variable = Mock()
    mock_get_variable.return_value = True
    mock_in_simple_mode = Mock()
    mock_in_simple_mode.return_value = False
    mock_get_option = Mock()
    mock_get_option.return_value = False

    # Patching the mocked functions

# Generated at 2022-06-24 07:54:20.719816
# Unit test for function toggle_variable
def test_toggle_variable():
    from unittest import mock

    command_mock = mock.MagicMock()

    with mock.patch(
        "thonny.plugins.pgzero.toggle_variable.get_workbench",
        return_value=mock.MagicMock(
            get_option=mock.MagicMock(return_value=True),
            set_option=mock.MagicMock(),
            get_variable=mock.MagicMock(
                return_value=mock.MagicMock(get=mock.MagicMock(return_value=False), set=command_mock)
            ),
        ),
    ):
        toggle_variable()
    command_mock.assert_called_once_with(True)



# Generated at 2022-06-24 07:54:31.765921
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench, get_runner
    from thonny.misc_utils import running_on_windows
    import os

    wb = get_workbench()
    wb.clear_local_configuration()

    load_plugin()

    wb.get_option(_OPTION_NAME)
    assert wb.get_option(_OPTION_NAME) == False

    # Test the toggle button
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == True
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == False

    # Set it to true
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == True

    # Test that the environment variable has been set.

# Generated at 2022-06-24 07:54:37.165715
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_option(_OPTION_NAME, False)
    assert not get_workbench().get_option(_OPTION_NAME)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME)
    toggle_variable()
    assert not get_workbench().get_option(_OPTION_NAME)


if __name__ == "__main__":
    test_toggle_variable()

# Generated at 2022-06-24 07:54:39.113108
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == True


# Generated at 2022-06-24 07:54:46.553749
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from tkinter import Tk
    import os
    import re


    def get_option(workbench):
        var = workbench.get_variable(_OPTION_NAME)
        return var.get()


    def set_option(workbench):
        var = workbench.get_variable(_OPTION_NAME)
        var.set(True)


    # setup
    if os.path.exists(os.path.join(get_config_dir(),"thonnyconfig")):
        os.remove(os.path.join(get_config_dir(),"thonnyconfig"))
    wb = Workbench()
    wb.load_configuration

# Generated at 2022-06-24 07:54:49.029006
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, True)
    assert get_workbench().get_option(_OPTION_NAME) is True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) is False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) is True

# Generated at 2022-06-24 07:54:56.714162
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    os.environ["PGZERO_MODE"] = "False"
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"


# Generated at 2022-06-24 07:55:04.923549
# Unit test for function toggle_variable
def test_toggle_variable():
    class FakeWorkbench():
        def get_variable(self, name):
            class FakeVar():
                def __init__(self, value=False):
                    self.value = value
                def get(self):
                    return self.value
                def set(self, value):
                    self.value = value

            if name == _OPTION_NAME:
                return FakeVar(True)
            elif name == _OPTION_NAME:
                return FakeVar(False)
            else:
                return None

    workbench = FakeWorkbench()

    toggle_variable()
    assert workbench.get_variable(_OPTION_NAME).get() == False

# Generated at 2022-06-24 07:55:10.284575
# Unit test for function toggle_variable
def test_toggle_variable():
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:55:11.117813
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()



# Generated at 2022-06-24 07:55:16.724212
# Unit test for function update_environment
def test_update_environment():
    os.environ.pop("PGZERO_MODE", None)
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_option(_OPTION_NAME, False)
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:55:17.681501
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:55:26.572650
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.globals import get_runner
    from unittest.mock import Mock
    from thonny.misc_utils import running_on_windows
    wb = get_workbench()
    wb.in_simple_mode = Mock(return_value=True)
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "auto"
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "auto"
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "auto"

    wb.in_

# Generated at 2022-06-24 07:55:32.541731
# Unit test for function load_plugin
def test_load_plugin():
    os.environ["PGZERO_MODE"] = ""

    load_plugin()
    get_workbench().set_option(_OPTION_NAME, True)
    assert os.environ["PGZERO_MODE"] == "True"
    assert get_workbench().get_option(_OPTION_NAME) == True

    get_workbench().set_option(_OPTION_NAME, False)
    assert os.environ["PGZERO_MODE"] == "False"
    assert get_workbench().get_option(_OPTION_NAME) == False

    get_workbench().set_simple_mode(True)
    assert os.environ["PGZERO_MODE"] == "auto"
    assert get_workbench().get_option(_OPTION_NAME) == False
    get_workbench().set_simple_mode(False)
   

# Generated at 2022-06-24 07:55:39.112073
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import workbench

    workbench.unload_plugins()
    workbench.create_main_window()

    load_plugin()
    wb = workbench.get_workbench()
    assert wb.get_option("run.pgzero_mode") == False
    wb.set_option("run.pgzero_mode", True)
    assert wb.get_option("run.pgzero_mode") == True
    # TODO: need to figure out how to test env vars without depending on them
    # TODO: need to figure out what is going on with tests and the default
    # TODO: env given by Thonny and the pygamezero mode environment
    # assert os.environ["PGZERO_MODE"] == "1"

    wb.execute_command("toggle_pgzero_mode")
   

# Generated at 2022-06-24 07:55:41.528237
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)

    load_plugin()
    assert wb.get_command("toggle_pgzero_mode")

# Generated at 2022-06-24 07:55:45.724653
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ.get("PGZERO_MODE") == "False"
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    assert os.environ.get("PGZERO_MODE") == "True"


load_plugin()

# Generated at 2022-06-24 07:55:50.670408
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.create()
    wb.set_default(_OPTION_NAME, True)

    update_environment()
    assert "PGZERO_MODE" in os.environ
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:55:58.878115
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock

    get_workbench().in_simple_mode = Mock()
    get_workbench().in_simple_mode.return_value = True
    os.environ["PGZERO_MODE"] = ""
    load_plugin()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().in_simple_mode.return_value = False

    get_workbench().get_option = Mock()
    get_workbench().get_option.return_value = True
    os.environ["PGZERO_MODE"] = ""
    load_plugin()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().get_option.return_value = False
    os.environ["PGZERO_MODE"] = ""

# Generated at 2022-06-24 07:56:05.216604
# Unit test for function toggle_variable
def test_toggle_variable():
    import time
    # run once to make sure that the value has been set to False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False
    # run again to make sure that the value has been set to True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    # run again to make sure that the value has been set to False again
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-24 07:56:05.696251
# Unit test for function load_plugin
def test_load_plugin():
    pass

# Generated at 2022-06-24 07:56:13.945356
# Unit test for function update_environment
def test_update_environment():
    get_workbench().hard_reset()
    get_workbench().set_option("run.pgzero_mode", False)
    get_workbench().set_simple_mode_enabled(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().set_option("run.pgzero_mode", True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().set_simple_mode_enabled(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:56:18.087427
# Unit test for function toggle_variable
def test_toggle_variable():
    assert get_workbench().in_simple_mode() == False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-24 07:56:27.829749
# Unit test for function load_plugin
def test_load_plugin():
    from test.simple import mock_simple_mode
    wb = get_workbench()

    with mock_simple_mode():
        wb.set_default(_OPTION_NAME, False)
        assert get_workbench().get_variable(_OPTION_NAME).get() is False

        assert os.environ["PGZERO_MODE"] == "auto"

    load_plugin()
    wb.set_default(_OPTION_NAME, False)
    assert get_workbench().get_variable(_OPTION_NAME).get() is False

    # The option is set to False, but simple mode is disabled
    toggle_variable()

    assert get_workbench().get_variable(_OPTION_NAME).get() is True
    assert os.environ["PGZERO_MODE"] == "True"

    toggle_variable()

    assert get_

# Generated at 2022-06-24 07:56:29.668796
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_option("run.pgzero_mode", "False")
    assert os.environ["PGZERO_MODE"] == str("False")

# Generated at 2022-06-24 07:56:32.816471
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench

    assert get_workbench().get_default(_OPTION_NAME) is False



# Generated at 2022-06-24 07:56:34.260880
# Unit test for function load_plugin
def test_load_plugin():
    try:
        load_plugin()
        assert True
    except Exception:
        assert False

# Generated at 2022-06-24 07:56:37.418551
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:56:47.711047
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock
    from thonny import get_workbench

    get_workbench = Mock(name="get_workbench", side_effect=lambda: wb)
    wb = Mock(name="wb")
    var = Mock(name="var", spec=["get", "set"])
    var.get.return_value = False
    var.set.return_value = None
    wb.get_variable.return_value = var
    wb.in_simple_mode.return_value = True
    wb.set_default.return_value = None
    wb.get_option.return_value = False
    wb.add_command.return_value = None

    load_plugin()

    assert wb.get_variable.called is True

# Generated at 2022-06-24 07:56:49.072457
# Unit test for function toggle_variable
def test_toggle_variable():
    root = get_workbench().get_variable(_OPTION_NAME)
    if root.get() == False:
        raise Exception('Expected True')
    elif root.get() == True:
        raise Exception('Expected False')

# Generated at 2022-06-24 07:56:56.569997
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock

    wb = Mock(_OPTION_NAME=None, groupd_commands={})
    wb.set_default = Mock(return_value=None)
    wb.add_command = Mock(return_value=None)
    wb.get_variable = Mock(return_value=None)
    wb.in_simple_mode = Mock(return_value=None)
    wb.get_option = Mock(return_value=None)

    wb._OPTION_NAME = "run.pgzero_mode.test"
    wb.groupd_commands = {}

    load_plugin()

    assert wb.set_default.call_args_list[0] == (("run.pgzero_mode.test", False),)


# Generated at 2022-06-24 07:57:01.332839
# Unit test for function update_environment
def test_update_environment():
    import os
    from thonny import get_workbench
    from thonny.languages import tr
    wb = get_workbench()
    wb.set_simple_mode(360)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    # Restore previous mode
    wb.set_simple_mode(False)



# Generated at 2022-06-24 07:57:07.739859
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_simple_mode()
    assert get_workbench().get_option(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False
    get_workbench().set_expert_mode()
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True

# Generated at 2022-06-24 07:57:13.815844
# Unit test for function update_environment
def test_update_environment():
    # Normal mode
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    # Simple mode
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:57:20.297594
# Unit test for function toggle_variable
def test_toggle_variable():
    import pytest

    load_plugin()
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    load_plugin()
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:57:22.523220
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()


if __name__ == "__main__":
    load_plugin()

# Generated at 2022-06-24 07:57:26.553799
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    # Test if load_plugin worked fine
    assert get_workbench().get_option("run.pgzero_mode") == False
    # Test if toggle_variable works fine
    toggle_variable()
    assert get_workbench().get_option("run.pgzero_mode") == True
    # Invert the value
    toggle_variable()
    assert get_workbench().get_option("run.pgzero_mode") == False

# Generated at 2022-06-24 07:57:31.646505
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:57:40.663814
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    out = wb.get_option(_OPTION_NAME)
    assert out == False
    assert os.environ["PGZERO_MODE"] == "False"
    os.environ.pop("PGZERO_MODE")
    wb.set_default(_OPTION_NAME, True)
    out = wb.get_option(_OPTION_NAME)
    assert out == True
    assert os.environ["PGZERO_MODE"] == "True"
    os.environ.pop("PGZERO_MODE")
    wb.set_default(_OPTION_NAME, False)
    wb.set_simple_mode(True)
    out = wb.get_option(_OPTION_NAME)

# Generated at 2022-06-24 07:57:47.364885
# Unit test for function update_environment
def test_update_environment():
    from thonny.globals import get_workbench
    test_workbench = get_workbench()
    test_workbench.set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ['PGZERO_MODE'] == 'True'
    test_workbench.set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ['PGZERO_MODE'] == 'False'

# Generated at 2022-06-24 07:57:58.863639
# Unit test for function toggle_variable
def test_toggle_variable():
    import unittest
    import sys
    import builtins
    import os

    class MockVariable:
        def get(self):
            return True

    class MockWorkbench:
        def get_variable(self, name):
            return MockVariable()

    class MockSysModule:
        env = {}
       
    builtins.__dict__["REPL_USE_PGZERO_MODE"] = True
    builtins.__dict__["get_workbench"] = lambda: MockWorkbench()
    mock_sys = MockSysModule()
    sys.modules["sys"] = mock_sys

    toggle_variable()   
    assert mock_sys.env["PGZERO_MODE"] == "False"

    toggle_variable()
    assert mock_sys.env["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:58:03.692364
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_simple_mode(True)
    load_plugin()
    assert not get_workbench().get_option(_OPTION_NAME)
    get_workbench().set_simple_mode(False)
    load_plugin()
    assert not get_workbench().get_option(_OPTION_NAME)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME)

# Generated at 2022-06-24 07:58:08.976678
# Unit test for function update_environment
def test_update_environment():
    from collections import namedtuple

    class DummyOption:
        def get(self):
            return True

    env_bak = os.environ.copy()

    try:
        options_bak = get_workbench().get_options()
        options = namedtuple("options", ["get_option"])
        options.get_option = lambda x: DummyOption()
        get_workbench().set_options(options)
        update_environment()
        assert os.environ["PGZERO_MODE"] == "True"
    finally:
        get_workbench().set_options(options_bak)
        os.environ = env_bak

# Generated at 2022-06-24 07:58:17.937581
# Unit test for function toggle_variable
def test_toggle_variable():
    from unittest.mock import Mock

    wb = Mock()
    wb.in_simple_mode = False

    get_option = Mock(return_value=False)
    set_option = Mock()
    wb.get_option = get_option
    wb.set_option = set_option
    wb.get_variable = Mock(return_value=Mock(set=Mock(), get=Mock(return_value=False)))

    get_workbench.set_wb(wb)

    toggle_variable()

    assert get_option.call_args[0][0] == _OPTION_NAME
    assert set_option.call_args[0][0] == _OPTION_NAME
    assert set_option.call_args[0][1] == True

    assert wb.get_variable.call_

# Generated at 2022-06-24 07:58:25.718463
# Unit test for function toggle_variable
def test_toggle_variable():
    from unittest.mock import MagicMock
    from thonny import TkVersion
    import tkinter

    if TkVersion.original < (8, 6, 5):
        # Mock the function where the messagebox is implemented
        tkinter.messagebox.showerror = MagicMock()

    toggle_variable()
    if TkVersion.original < (8, 6, 5):
        assert tkinter.messagebox.showerror.call_count == 1
    else:
        assert tkinter.messagebox.showerror.call_count == 0
    toggle_variable()
    if TkVersion.original < (8, 6, 5):
        assert tkinter.messagebox.showerror.call_count == 1
    else:
        assert tkinter.messagebox.showerror.call_count

# Generated at 2022-06-24 07:58:30.303814
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_option(_OPTION_NAME, True)
    toggle_variable()
    result = get_workbench().get_option(_OPTION_NAME)
    assert result == False
    toggle_variable()
    result = get_workbench().get_option(_OPTION_NAME)
    assert result == True


# Generated at 2022-06-24 07:58:34.446948
# Unit test for function toggle_variable
def test_toggle_variable():
    original = get_workbench().get_option(_OPTION_NAME)
    # Check that it toggles

# Generated at 2022-06-24 07:58:40.335816
# Unit test for function toggle_variable
def test_toggle_variable():
    
    # Checks that the Pygame Zero mode is set to False by default
    assert get_workbench().get_option(_OPTION_NAME) == False
    
    # Toggles the Pygame Zero mode variable and checks that it is set to True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True

    # Toggles the Pygame Zero mode variable and checks that it is set to False again
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-24 07:58:44.407159
# Unit test for function toggle_variable
def test_toggle_variable():
    if get_workbench().in_simple_mode():
        os.environ["PGZERO_MODE"] = "auto"
    else:
        os.environ["PGZERO_MODE"] = str(get_workbench().get_option(_OPTION_NAME))

# Generated at 2022-06-24 07:58:49.110913
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    # update_environment()

# Generated at 2022-06-24 07:58:56.281348
# Unit test for function update_environment
def test_update_environment():
    from thonny.globals import get_runner
    from thonny.workbench import Workbench

    runner = get_runner()
    backup_get_runner_variable = runner.get_variable

# Generated at 2022-06-24 07:58:57.930014
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = "auto"
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.getenv("PGZERO_MODE") == "True"  # @UndefinedVariable

# Generated at 2022-06-24 07:59:02.384901
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:59:05.193561
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    test_command = wb.get_command("toggle_pgzero_mode")
    assert test_command["flag_name"] == _OPTION_NAME

# Generated at 2022-06-24 07:59:13.209686
# Unit test for function load_plugin
def test_load_plugin():
    # Test simple mode
    wb = Workbench()
    wb.set_simple_mode(True)
    load_plugin()
    assert os.environ["PGZERO_MODE"] == "auto"

    # Test default normal mode
    del os.environ["PGZERO_MODE"]
    wb.set_simple_mode(False)
    load_plugin()
    assert os.environ["PGZERO_MODE"] == "False"

    # Test normal mode with True value
    wb.set_option(_OPTION_NAME, True)
    load_plugin()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:59:17.312340
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default(_OPTION_NAME, True)
    get_workbench().set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"



# Generated at 2022-06-24 07:59:24.804527
# Unit test for function update_environment
def test_update_environment():
    from unittest import mock
    import sys
    import os

    wb = get_workbench()

    # Mock out the get_workbench() call
    with mock.patch.object(sys.modules[__name__], "get_workbench") as mock_get_wb:
        mock_get_wb.return_value = wb

        # Mock out the get_workbench().get_option() call
        with mock.patch.object(wb, "get_option") as mock_get_opt:
            mock_get_opt.return_value = True
            update_environment()
            assert os.environ["PGZERO_MODE"] == "True"
            mock_get_opt.return_value = False
            update_environment()
            assert os.environ["PGZERO_MODE"] == "False"

    # Now mock

# Generated at 2022-06-24 07:59:30.423880
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"



# Generated at 2022-06-24 07:59:38.261767
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_option(_OPTION_NAME, False)
    get_workbench().enter_simple_mode()
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().in_simple_mode()

# Generated at 2022-06-24 07:59:44.710868
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) is True
    assert os.environ["PGZERO_MODE"] == "True"

    toggle_variable()
    assert wb.get_option(_OPTION_NAME) is False
    assert os.environ["PGZERO_MODE"] == "False"


# Generated at 2022-06-24 07:59:49.184600
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()

# Generated at 2022-06-24 07:59:55.219340
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_runner
    
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"

    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"

# Generated at 2022-06-24 08:00:05.766539
# Unit test for function load_plugin
def test_load_plugin():
    from unittest import mock
    from thonny import get_workbench
    from thonny.workbench import Workbench

    get_workbench = mock.Mock()
    mock_wb = Workbench()
    get_workbench.return_value = mock_wb

    load_plugin()

    get_workbench.assert_called_once()
    mock_wb.assert_has_calls(
        [
            mock.call.set_default(_OPTION_NAME, False),
            mock.call.add_command(
                "toggle_pgzero_mode",
                "run",
                tr("Pygame Zero mode"),
                toggle_variable,
                flag_name=_OPTION_NAME,
                group=40,
            ),
        ]
    )

# Generated at 2022-06-24 08:00:09.947500
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == True
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == False

# Generated at 2022-06-24 08:00:20.256390
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench
    from thonny.testutil import get_runner
    from unittest import main
    from unittest.mock import patch
    
    get_workbench().set_option(_OPTION_NAME, True)
    
    runner = get_runner()
    runner.run_tests()
    
    assert os.environ["PGZERO_MODE"] == "True"
    
    with patch.dict(os.environ, clear=True):
        update_environment()
        
    assert os.environ["PGZERO_MODE"] == "False"
    
    with patch.dict(os.environ, clear=True):
        get_workbench().set_simple_mode()
        runner.run_tests()

# Generated at 2022-06-24 08:00:22.604461
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench

    wb = Workbench()
    assert "PGZERO_MODE" not in os.environ

# Generated at 2022-06-24 08:00:28.885582
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    toggle_variable()
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 08:00:31.441276
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().unset_default(_OPTION_NAME)
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-24 08:00:32.534637
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-24 08:00:36.112370
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get(), 'PGZERO_MODE should be True'
    toggle_variable()
    assert not get_workbench().get_variable(_OPTION_NAME).get(), 'PGZERO_MODE should be False'



# Generated at 2022-06-24 08:00:40.700697
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, True)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True

# Generated at 2022-06-24 08:00:43.897012
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    assert get_workbench().get_command("toggle_pgzero_mode").func is toggle_variable

# Generated at 2022-06-24 08:00:45.603069
# Unit test for function toggle_variable
def test_toggle_variable():
    load_plugin()
    var = get_workbench().get_variable(_OPTION_NAME)
    assert var.get() == False

    toggle_variable()
    assert var.get() == True

    toggle_variable()
    assert var.get() == False


# Generated at 2022-06-24 08:00:55.161772
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.workbench import Workbench
    from thonny.workbench import WorkbenchEvent
    from unittest.mock import patch
    from thonny import get_workbench
    from thonny.languages import tr

    wb = Workbench()
    wb.init_variable("run.pgzero_mode")
    wb.add_command("toggle_pgzero_mode", "run", tr("Pygame Zero mode"), toggle_variable, flag_name=_OPTION_NAME)

    # Check that pgzero_mode is False
    assert get_workbench().get_option("run.pgzero_mode") == False
    # Mock the toggle_variable function

# Generated at 2022-06-24 08:01:04.058918
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench

    w = Workbench()
    w.load_plugin_manager()
    w.init_user_interface("")
    w.load_plugin(__name__)

    # set pygame zero mode
    w.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    # unset pygame zero mode
    w.set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    # set pygame zero mode again
    w.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 08:01:15.294999
# Unit test for function toggle_variable
def test_toggle_variable():
	# Create a workbench instance:
	wb = get_workbench()	
	
	# Checks if the current option is on or off:
	if wb.get_option(_OPTION_NAME):
		print("Off")
		wb.set_option(_OPTION_NAME, False)
	else:
		print("On")
		wb.set_option(_OPTION_NAME, True)
	
	# Update the environment, i.e. turn the option on or off:		
	update_environment()
	
	# Retrieve the current value for the enviroment variable:
	print(os.environ["PGZERO_MODE"])
	
	# Check if the environment variable is 'On' or 'Off':

# Generated at 2022-06-24 08:01:23.440519
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    assert not get_workbench().get_option(_OPTION_NAME)
    assert os.environ["PGZERO_MODE"] == "0"
    get_workbench().in_simple_mode()
    assert os.environ["PGZERO_MODE"] == "auto"
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME)
    assert os.environ["PGZERO_MODE"] == "1"
    get_workbench().in_simple_mode

# Generated at 2022-06-24 08:01:28.775762
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    wb.set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"