

# Generated at 2022-06-24 07:51:32.816228
# Unit test for function toggle_variable
def test_toggle_variable():
    var = get_workbench().get_variable(_OPTION_NAME)
    var.set(False)
    assert get_workbench().get_option(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-24 07:51:36.702589
# Unit test for function update_environment
def test_update_environment():
    # Changing the option changes the environment
    get_workbench().in_simple_mode = lambda: False
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert not os.environ.get("PGZERO_MODE") == "True"

    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert not os.environ.get("PGZERO_MODE") == "False"

    # In simple mode it's always 'auto'
    get_workbench().in_simple_mode = lambda: True
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ.get("PGZERO_MODE") == "auto"


# Generated at 2022-06-24 07:51:40.124932
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_option(_OPTION_NAME, True)
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False



# Generated at 2022-06-24 07:51:48.403130
# Unit test for function toggle_variable
def test_toggle_variable():
    load_plugin()
    from thonny import get_workbench, get_runner

    assert get_workbench().get_option(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-24 07:51:58.440835
# Unit test for function toggle_variable
def test_toggle_variable():
    # create temporary environment variable
    os.environ["PGZERO_MODE"] = "auto"
    # variable is undefined
    var = get_workbench().get_variable(_OPTION_NAME)
    
    # check toggle variable works as expected
    var.set(True)
    assert (os.environ["PGZERO_MODE"] == "True")
    var.set(False)
    assert (os.environ["PGZERO_MODE"] == "False")
    var.set(True)
    assert (os.environ["PGZERO_MODE"] == "True")
    
    # test for working in simple mode
    get_workbench().set_simple_mode()
    var.set(False)
    assert (os.environ["PGZERO_MODE"] == "auto")
    get_workbench().set_

# Generated at 2022-06-24 07:52:09.699471
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny import get_workbench
    from thonny.config import Option
    # Importing this module is enough for the function to be registered and executed at load time.
    # If the function was not called at load time, the variable would not be initialized during the
    # tests, and test_toggle_variable would crash.
    from thonny.plugins.run_pgzero import load_plugin as load_plugin
    # Test that the Option is created, and is in its initial state.
    assert isinstance(get_workbench().get_variable(_OPTION_NAME), Option)
    assert not bool(get_workbench().get_option(_OPTION_NAME))
    # Test that the function toggle_variable toggles the value of the Option
    toggle_variable()
    assert bool(get_workbench().get_option(_OPTION_NAME))


# Generated at 2022-06-24 07:52:16.165363
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny import get_workbench
    from thonny.workbench import TestWorkbench
    from thonny.plugins.pgzero_mode import toggle_variable
    b = TestWorkbench()
    b.set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-24 07:52:16.727176
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()

# Generated at 2022-06-24 07:52:24.963335
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    default_value = wb.get_variable(_OPTION_NAME).get()

    # New workbench should have PGZERO_MODE set to 'auto'
    old_env = os.environ.get("PGZERO_MODE")
    load_plugin()
    assert old_env is None or old_env == "auto"

    # Here PGZERO_MODE should be set to default value
    assert os.environ["PGZERO_MODE"] == str(default_value)

    # When going to simple mode we should go back to 'auto'
    wb.enter_simple_mode()
    assert os.environ["PGZERO_MODE"] == "auto"

    # Back to normal mode
    wb.leave_simple_mode()

# Generated at 2022-06-24 07:52:31.193777
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_variable(_OPTION_NAME, False)
    assert get_workbench().get_variable(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME) == False

if __name__ == "__main__":
    test_toggle_variable()

# Generated at 2022-06-24 07:52:38.238484
# Unit test for function toggle_variable
def test_toggle_variable():
    from unittest.mock import Mock, patch
    from thonny.workbench import Workbench
    from thonny.shell import ShellTextWidget

    wb = Mock(spec=Workbench)
    wb.get_option = Mock(return_value=True)
    wb.set_option = Mock()
    with patch("thonny.plugins.pgzero_mode_support.update_environment", Mock()):
        toggle_variable()
        wb.set_option.assert_called_once_with(_OPTION_NAME, False)

# Generated at 2022-06-24 07:52:41.852703
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import MockWorkbench

    mock_workbench = MockWorkbench()
    mock_workbench.set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:52:43.152964
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert get_workbench().get_variable(_OPTION_NAME).get() == False



# Generated at 2022-06-24 07:52:46.265377
# Unit test for function toggle_variable
def test_toggle_variable():
    if "PGZERO_MODE" in os.environ:
        del os.environ["PGZERO_MODE"]

    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"

    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:52:52.760936
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().in_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:52:57.731355
# Unit test for function toggle_variable
def test_toggle_variable():
    from unittest.mock import MagicMock
    get_workbench = MagicMock(return_value=MagicMock(get_variable=MagicMock()))
    get_workbench().in_simple_mode = MagicMock(return_value=False)
    os.environ["PGZERO_MODE"] = "0"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "1"

# Generated at 2022-06-24 07:53:01.680031
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_simple_mode(False)
    get_workbench().set_option("run.pgzero_mode", True)
    update_environment()

    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_simple_mode(True)
    update_environment()

    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:53:06.295152
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny import get_workbench
    get_workbench().set_option(_OPTION_NAME, False)
    assert get_workbench().get_option(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    # Unit test for function update_environment
    def test_update_environment():
        get_workbench().set_option(_OPTION_NAME, True)
        update_environment()
        assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:53:11.883487
# Unit test for function load_plugin
def test_load_plugin():
    if "PGZERO_MODE" in os.environ:
        del os.environ["PGZERO_MODE"]

    wb = get_workbench()
    wb.set_default("run.pgzero_mode", False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    wb.set_option("run.pgzero_mode", True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"


# Generated at 2022-06-24 07:53:17.205391
# Unit test for function toggle_variable
def test_toggle_variable():
    os.environ["PGZERO_MODE"] = "auto"
    load_plugin()
    assert os.environ["PGZERO_MODE"] == "auto"
    os.environ["PGZERO_MODE"] = "False"
    load_plugin()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:53:26.647273
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()

    assert get_workbench().get_option(_OPTION_NAME) == False
    assert "PGZERO_MODE" in os.environ
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:53:34.430556
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import MagicMock
    from unittest.mock import patch

    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)

    with patch("thonny.plugins.pgzero_mode.os.environ") as env:
        update_environment()
        env["PGZERO_MODE"].should.equal("False")

    wb.set_option(_OPTION_NAME, True)
    with patch("thonny.plugins.pgzero_mode.os.environ") as env:
        update_environment()
        env["PGZERO_MODE"].should.equal("True")

    # Test that it works in simple mode
    wb.set_option(_OPTION_NAME, False)
    wb.in_simple_mode = MagicMock

# Generated at 2022-06-24 07:53:43.612597
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import patch, MagicMock
    from thonny import get_workbench
    from thonny.config import load_user_configuration, save_user_configuration
    mock_workbench = MagicMock()
    mock_workbench.in_simple_mode.return_value = True
    mock_workbench.get_option.return_value = False
    mock_workbench.get_variable.return_value = "auto"
    with patch("thonny.workbench.Workbench", mock_workbench):
        os.environ.pop("PGZERO_MODE", None)
        get_workbench().__class__ = mock_workbench
        update_environment()
        assert os.environ["PGZERO_MODE"] == "auto"


# Generated at 2022-06-24 07:53:47.826576
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    wb._set_variable(_OPTION_NAME, False)
    assert os.environ["PGZERO_MODE"] == "auto"
    wb._set_variable(_OPTION_NAME, True)
    assert os.environ["PGZERO_MODE"] == "1"

# Generated at 2022-06-24 07:53:51.405361
# Unit test for function load_plugin
def test_load_plugin():
    wb = Tester()
    wb.set_default(_OPTION_NAME, False)

    assert get_workbench().in_simple_mode() == False
    assert "PGZERO_MODE" not in os.environ
    load_plugin()
    assert wb.get_option(_OPTION_NAME) == False
    assert "PGZERO_MODE" in os.environ
    assert os.environ["PGZERO_MODE"] == "False"



# Generated at 2022-06-24 07:53:56.381788
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = "auto"
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:54:06.441669
# Unit test for function toggle_variable

# Generated at 2022-06-24 07:54:10.051639
# Unit test for function update_environment
def test_update_environment():
    for simple_mode, expected in [(False, "False"), (True, "auto")]:
        get_workbench().set_in_simple_mode(simple_mode)
        update_environment()
        assert os.environ["PGZERO_MODE"] == expected

# Generated at 2022-06-24 07:54:17.489094
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.create()
    wb.set_default(_OPTION_NAME, False)
    wb.add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name="pgzero_mode",
        group=40,
    )
    update_environment()
    assert (
        wb.get_option(_OPTION_NAME) == True
    ), "The value of pgzero_mode should be True"

# Generated at 2022-06-24 07:54:19.447990
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_simple_mode(False)
    toggle_variable()
    assert get_workbench().in_simple_mode() == False



# Generated at 2022-06-24 07:54:30.610966
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_shell
    from thonny.ui_utils import get_label_by_text

    get_workbench().set_simple_mode()
    load_plugin()
    get_workbench().event_generate("StartRun")
    assert os.environ.get("PGZERO_MODE") == "auto"
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    assert os.environ.get("PGZERO_MODE") == "True"
    get_shell().run_command("import pgzrun")
    assert not get_label_by_text("Hello, pgzero!").winfo_exists()
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ.get

# Generated at 2022-06-24 07:54:40.870470
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock
    from thonny import get_workbench
    from thonny.plugins.pgzero_mode import load_plugin

    wb = Mock(get_workbench=Mock(return_value=wb))
    wb.in_simple_mode = Mock(return_value=False)
    wb.set_default = Mock()
    wb.add_command = Mock()
    wb.get_option = Mock(return_value=True)

    globals_ = {"get_workbench": Mock(return_value=wb)}

    load_plugin()

    wb.set_default.assert_called_once_with(_OPTION_NAME, False)
    wb.add_command.assert_called_once()
    wb.get_option.assert_called_once()

   

# Generated at 2022-06-24 07:54:43.420789
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    wb.set_option(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_o

# Generated at 2022-06-24 07:54:52.640799
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench
    from unittest.mock import Mock

    if "PGZERO_MODE" in os.environ:
        del os.environ["PGZERO_MODE"]

    # Go to simple mode
    get_workbench().in_simple_mode = lambda: True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    del os.environ["PGZERO_MODE"]

    # Go to normal mode
    get_workbench().in_simple_mode = lambda: False
    # PGZERO mode deactivated
    get_workbench().get_option = Mock(return_value=False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:55:03.906237
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    assert not wb.get_option(_OPTION_NAME)
    assert os.environ["PGZERO_MODE"] == "False"

    toggle_variable()
    assert wb.get_option(_OPTION_NAME)
    assert os.environ["PGZERO_MODE"] == "True"

    toggle_variable()
    assert not wb.get_option(_OPTION_NAME)
    assert os.environ["PGZERO_MODE"] == "False"

    wb.enter_simple_mode()
    assert os.environ["PGZERO_MODE"] == "auto"

    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "auto"
    assert not wb.get

# Generated at 2022-06-24 07:55:10.284388
# Unit test for function toggle_variable
def test_toggle_variable():
    test_menu = tk.Menu()
    test_wb = Workbench(test_menu)
    test_wb.set_default(_OPTION_NAME, False)
    test_wb.add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    var = test_wb.get_variable(_OPTION_NAME)
    assert var.get() == False
    toggle_variable()
    assert var.get() == True
    toggle_variable()
    assert var.get() == False

# Generated at 2022-06-24 07:55:18.823337
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.test.test_pgzero_compat import setup_environment

    setup_environment()
    assert get_workbench().get_option(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

    # Test updating environment
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:55:27.577676
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.globals import get_workbench
    from types import CodeType
    """
    Stub for the get_runner function so it can be unit tested.
    """
    def get_runner(self):
        class RunnerStub(object):
            command = "run"

            @staticmethod
            def get_input():
                return None

        return RunnerStub()

    backend = get_workbench().get_backend()

    def get_pgzero_mode(self):
        return True

    # Save old method and add new
    old_f_get_input = backend.run_command
    old_get_pgzero_mode = backend.get_pgzero_mode
    backend.get_pgzero_mode = get_pgzero_mode
    backend.run_command = get_runner

    # Same code as in

# Generated at 2022-06-24 07:55:35.995875
# Unit test for function toggle_variable
def test_toggle_variable():
    try:
        get_workbench().set_default(_OPTION_NAME, True)
        update_environment()
        assert os.environ["PGZERO_MODE"] == "True"
        toggle_variable()
        assert os.environ["PGZERO_MODE"] == "False"
        toggle_variable()
        assert os.environ["PGZERO_MODE"] == "True"

        get_workbench().set_default(_OPTION_NAME, False)
        update_environment()
        assert os.environ["PGZERO_MODE"] == "False"
        toggle_variable()
        assert os.environ["PGZERO_MODE"] == "True"
        toggle_variable()
        assert os.environ["PGZERO_MODE"] == "False"
    except KeyError:
        assert False

# Generated at 2022-06-24 07:55:38.738944
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:55:42.276799
# Unit test for function toggle_variable
def test_toggle_variable():
    global _OPTION_NAME
    get_workbench().set_default(_OPTION_NAME, True)
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() is False
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() is True

# Generated at 2022-06-24 07:55:48.867786
# Unit test for function update_environment
def test_update_environment():
    import pytest
    from thonny.ui_utils import askstring
    from test.utils import get_runner

    get_workbench().set_default(_OPTION_NAME, True)

    def helpers():
        def check_env(expected_value):
            import os
            assert os.getenv("PGZERO_MODE") == expected_value

        def input_value(expected_value):
            def _input(prompt=None):
                if prompt == expected_value:
                    return "2"
                else:
                    raise Exception("Unexpected prompt: " +prompt)

            return _input

        return locals()

    get_runner().debug("import test_run_pgzero_mode", use_subprocess=True, globals=helpers())
    old_askstring = askstring


# Generated at 2022-06-24 07:55:56.654235
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny import get_workbench

    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    get_workbench().set_simple_mode(True)
    update_environment()
    assert "PGZERO_MODE" in os.environ
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    wb.set_option(_OPTION_NAME, True)
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:56:00.347735
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert get_workbench().get_default(_OPTION_NAME) == False
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"
    assert "Pygame Zero mode" in get_workbench().get_plugin("run").get_menu().get_children()[0].get_label()

# Generated at 2022-06-24 07:56:03.537900
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    assert "PGZERO_MODE" in os.environ
    assert get_workbench().get_variable(_OPTION_NAME) == False

# Generated at 2022-06-24 07:56:11.982371
# Unit test for function update_environment
def test_update_environment():
    from thonny import THONNY_USER_DIR

    os.environ["THONNY_USER_DIR"] = THONNY_USER_DIR
    get_workbench().set_simple_mode(True)
    update_environment()
    os.unsetenv("THONNY_USER_DIR")
    assert os.getenv("PGZERO_MODE") == "auto"
    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.getenv("PGZERO_MODE") == "True"

# Generated at 2022-06-24 07:56:17.309395
# Unit test for function toggle_variable
def test_toggle_variable():
    from unittest.mock import Mock
    from thonny import ui_utils

    wb = Mock()
    wb.get_variable = lambda name : Mock(get=lambda : False, set=lambda new_val: None)
    get_workbench.return_value = wb
    update_environment()

    assert os.environ["PGZERO_MODE"] == "True"

    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"

    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:56:22.220852
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default("run.pgzero_mode", False)
    load_plugin()
    assert "PGZERO_MODE" in os.environ
    assert os.environ["PGZERO_MODE"] == "False"
    assert "PGZERO_MODE" in os.environ

# Generated at 2022-06-24 07:56:29.950831
# Unit test for function update_environment
def test_update_environment():
    old_env = dict(os.environ)
    try:
        get_workbench().set_simple_mode(False)
        get_workbench().set_option(_OPTION_NAME, False)
        update_environment()
        assert os.environ["PGZERO_MODE"] == "0"
        get_workbench().set_option(_OPTION_NAME, True)
        update_environment()
        assert os.environ["PGZERO_MODE"] == "1"
        get_workbench().set_simple_mode(True)
        update_environment()
        assert os.environ["PGZERO_MODE"] == "auto"
    finally:
        for key, value in old_env.items():
            os.environ[key] = value

# Generated at 2022-06-24 07:56:35.786054
# Unit test for function toggle_variable
def test_toggle_variable():
    try:
        get_workbench().set_default(_OPTION_NAME, False)
        toggle_variable()
        assert get_workbench().get_variable(_OPTION_NAME).get()
        toggle_variable()
        assert not get_workbench().get_variable(_OPTION_NAME).get()
    finally:
        toggle_variable()

# Generated at 2022-06-24 07:56:39.648911
# Unit test for function toggle_variable
def test_toggle_variable():
    # Test 1
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) is True

    # Test 2
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) is False

# Generated at 2022-06-24 07:56:44.269227
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench

    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:56:50.317635
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.register_default("run.pgzero_mode", True)
    assert wb.get_option("run.pgzero_mode") == True
    load_plugin()
    assert wb.get_option("run.pgzero_mode") == False
    assert wb.get_variable("run.pgzero_mode") == False


load_plugin()

# Generated at 2022-06-24 07:56:52.487462
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    assert wb.get_variable(_OPTION_NAME).get() == False

# Generated at 2022-06-24 07:56:54.677060
# Unit test for function update_environment
def test_update_environment():
    if get_workbench().in_simple_mode():
        os.environ["PGZERO_MODE"] = "auto"
    else:
        os.environ["PGZERO_MODE"] = "True"

# Generated at 2022-06-24 07:56:55.153347
# Unit test for function load_plugin
def test_load_plugin():
    pass

# Generated at 2022-06-24 07:56:59.564721
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_simple_mode(True)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False


# Generated at 2022-06-24 07:57:02.269328
# Unit test for function toggle_variable
def test_toggle_variable():
    var = get_workbench().get_variable(_OPTION_NAME)
    var.set(True)
    toggle_variable()
    assert var.get() == False

    toggle_variable()
    assert var.get() == True


# Generated at 2022-06-24 07:57:09.263455
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    assert "PGZERO_MODE" in os.environ
    assert os.environ["PGZERO_MODE"] == "0"
    toggle_variable()
    assert "PGZERO_MODE" in os.environ
    assert os.environ["PGZERO_MODE"] == "1"
    toggle_variable()
    assert "PGZERO_MODE" in os.environ
    assert os.environ["PGZERO_MODE"] == "0"

# Generated at 2022-06-24 07:57:14.682262
# Unit test for function toggle_variable
def test_toggle_variable():
    # By default pgzero mode is set to False
    toggle_variable()
    # Then when the function is called pgzero_mode is set to true
    assert get_workbench().get_variable(_OPTION_NAME).get() is True
    toggle_variable()
    # Then when the function is called again pgzero_mode is set to true
    assert get_workbench().get_variable(_OPTION_NAME).get() is False

# Generated at 2022-06-24 07:57:24.122745
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_debug_mode(True)
    get_workbench().set_simple_mode(False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME)
    toggle_variable()
    assert not get_workbench().get_option(_OPTION_NAME)
    get_workbench().set_simple_mode(True)
    toggle_variable()
    # in simple mode the value is not changed
    assert not get_workbench().get_option(_OPTION_NAME)
    get_workbench().set_simple_mode(False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME)

# Generated at 2022-06-24 07:57:29.110628
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_simple_mode(False)
    load_plugin()
    if os.name == "nt":
        assert os.environ['PGZERO_MODE'] == "False"
    else:
        assert os.environ['PGZERO_MODE'] == "0"

# Generated at 2022-06-24 07:57:35.884230
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.misc_utils import running_on_mac_os

    if not running_on_mac_os():
        return

    workbench.set_default(_OPTION_NAME, False)
    assert workbench.get_option(_OPTION_NAME) == False
    toggle_variable()
    assert workbench.get_option(_OPTION_NAME) == True
    toggle_variable()
    assert workbench.get_option(_OPTION_NAME) == False

# Generated at 2022-06-24 07:57:43.069604
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.workbench import Workbench
    from thonny.plugins.run.run_command import RunCommand
    from unittest import mock
    from unittest.mock import MagicMock
    from thonny import get_workbench
    from thonny.misc_utils import running_on_windows
    from thonny.ui_utils import CommonDialog
    from tkinter import messagebox
    from thonny.config import get_python_subprocess_command
    import tkinter

    wb = Workbench()
    wb.set_default("run.pgzero_mode", True)
    assert(get_workbench().get_option("run.pgzero_mode") == True)
    toggle_variable()
    assert(get_workbench().get_option("run.pgzero_mode") == False)

# Generated at 2022-06-24 07:57:47.727008
# Unit test for function update_environment
def test_update_environment():
    from thonny.workflow import ToplevelCommand
    from thonny.misc_utils import running_on_mac_os, running_on_windows

    def mock_get_option(option_name):
        return get_workbench().get_variable(option_name)

    def mock_add_command(name, category, label, command, **kwargs):
        get_workbench().set_command(name, ToplevelCommand(label, command, category, **kwargs))

    def mock_in_simple_mode():
        return False

    def mock_set_default(option_name, default_value):
        get_workbench().set_variable(option_name, default_value)

    def mock_get_variable(var_name):
        return get_workbench().get_variable(var_name)

    original_

# Generated at 2022-06-24 07:57:59.237311
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()
    # check that with the default value the system environment does not have the PGZERO_MODE variable
    assert "PGZERO_MODE" not in os.environ

    # check that with the default value the system environment does not have the PGZERO_MODE variable
    get_workbench().get_variable(_OPTION_NAME).set(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:58:04.601933
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    test_workbench = get_workbench()
    assert test_workbench.get_variable(_OPTION_NAME).get() == False
    # assert test_workbench.get_option(_OPTION_NAMe) == False
    assert os.environ["PGZERO_MODE"] == "False"
    load_plugin()
    assert test_workbench.get_variable(_OPTION_NAME).get() == True
    # assert test_workbench.get_option(_OPTION_NAMe) == True
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:58:06.278042
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert "toggle_pgzero_mode" in get_workbench().find_menu("run").commands



# Generated at 2022-06-24 07:58:08.354360
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()
    toggle_variable()

# Generated at 2022-06-24 07:58:17.528626
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default_program("PGZERO_MODE", "auto")
    try:
        load_plugin()
        assert get_workbench().get_option("run.pgzero_mode") is False
        assert os.environ["PGZERO_MODE"] == "auto"

        toggle_variable()
        assert get_workbench().get_option("run.pgzero_mode") is True
        assert os.environ["PGZERO_MODE"] == "auto"

        get_workbench().enter_simple_mode()
        assert os.environ["PGZERO_MODE"] == "auto"

        get_workbench().leave_simple_mode()
        assert os.environ["PGZERO_MODE"] == "True"
    except:
        raise
    finally:
        get_workbench().unset_default

# Generated at 2022-06-24 07:58:20.801330
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"



# Generated at 2022-06-24 07:58:23.097974
# Unit test for function load_plugin
def test_load_plugin():
    b = get_workbench()
    assert b.get_variable(_OPTION_NAME) is not None
    assert b.get_variable(_OPTION_NAME).get() is False


# Generated at 2022-06-24 07:58:29.662485
# Unit test for function update_environment
def test_update_environment():
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"

# Generated at 2022-06-24 07:58:38.700001
# Unit test for function toggle_variable
def test_toggle_variable():
    from unittest import mock
    from thonny.globals import get_workbench
    from thonny import get_runner
    from thonny import get_shell
    from thonny.config_ui import ConfigurationPage
    import tkinter as tk

    # We are going to test this plugin, so let's make sure it's loaded
    load_plugin()

    # Let's create a fake workbench to use in our tests
    test_workbench = get_workbench()
    test_workbench.in_simple_mode = lambda: True

    # Let's create a fake configuration page to use in our tests
    class MockConf(ConfigurationPage):
        def _create_ui(self):
            self.pgzero_mode_var = tk.IntVar()

    # Let's create a fake event for our tests
    mock_

# Generated at 2022-06-24 07:58:49.595318
# Unit test for function load_plugin
def test_load_plugin():
    # load the plugin
    load_plugin()

    # check that a command 'toggle_pgzero_mode' has been added
    assert get_workbench().has_command("toggle_pgzero_mode")

    # check that the pgzero_mode in the workbench is correct
    assert get_workbench().get_variable("run.pgzero_mode").get() == False

    # check that the environment variable is correct
    assert os.environ["PGZERO_MODE"] == "False"

    # toggle the pgzero mode
    toggle_variable()

    # check that the pgzero_mode in the workbench is correct
    assert get_workbench().get_variable("run.pgzero_mode").get() == True

    # check that the environment variable is correct
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:58:58.776052
# Unit test for function update_environment
def test_update_environment():
    get_workbench().in_simple_mode = lambda: True
    update_environment()
    assert os.environ["PGZERO_MODE"] ==  "auto"

    get_workbench().in_simple_mode = lambda: False
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] ==  "0"

    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] ==  "1"

# Generated at 2022-06-24 07:59:04.866543
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_option(_OPTION_NAME, "no")
    update_environment()
    assert os.environ["PGZERO_MODE"] == "no"

# Generated at 2022-06-24 07:59:09.489903
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == True
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == False

# Generated at 2022-06-24 07:59:12.565752
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_simple_mode(1)
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:59:18.619598
# Unit test for function update_environment
def test_update_environment():
    '''Tests that PGZERO_MODE is apparently set to the expected value'''
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:59:25.765434
# Unit test for function update_environment
def test_update_environment():
    """ Test update_environment() and toggle_variable()
    """
    from unittest.mock import Mock
    from thonny.globals import get_workbench

    # Test that update_environment() updates environment
    wb = Mock()
    wb.in_simple_mode.return_value = False
    wb.get_option.return_value = True
    get_workbench = Mock(return_value=wb)
    update_environment()
    assert "PGZERO_MODE" in os.environ.keys()
    assert os.environ["PGZERO_MODE"] == "True"
    # Test that update_environment() updates environment when in simple mode
    wb.in_simple_mode.return_value = True
    update_environment()

# Generated at 2022-06-24 07:59:30.524294
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_option(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) is True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) is False

# Generated at 2022-06-24 07:59:36.842136
# Unit test for function toggle_variable
def test_toggle_variable():
    test_workbench = get_workbench()
    test_workbench.set_default("run.pgzero_mode", False)
    assert test_workbench.get_variable("run.pgzero_mode").get() == False
    toggle_variable()
    assert test_workbench.get_variable("run.pgzero_mode").get() == True
    toggle_variable()
    assert test_workbench.get_variable("run.pgzero_mode").get() == False

# Generated at 2022-06-24 07:59:42.912050
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.globals import get_workbench, get_runner
    from thonny.shell import Shell
    from thonny.workflow import SimpleResetManager
    from thonny.plugins.micropython import MicroPythonProxy
    from thonny.plugins.micropython import MicroPythonConnection
    from io import StringIO, BytesIO
    from threading import Thread
    from time import sleep

    # Make a dummy workbench
    dummy_workbench = get_workbench()
    dummy_workbench.get_option = lambda x : False
    dummy_workbench.set_default = lambda x, y: None
    dummy_workbench.get_variable = lambda x : False
    dummy_workbench.add_command = lambda x, y, z, m, n, o: None
    dummy_workbench.get_

# Generated at 2022-06-24 07:59:48.797626
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = "false"
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    
    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "false"

# Generated at 2022-06-24 07:59:58.977380
# Unit test for function load_plugin
def test_load_plugin():
    # set simple mode
    get_workbench().set_simple_mode(True)

    # run load_plugin
    load_plugin()

    # check in simple mode
    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    assert os.environ["PGZERO_MODE"] == "auto"

    # set normal mode
    get_workbench().set_simple_mode(False)

    # run load_plugin
    load_plugin()

    # check not in simple mode
    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    assert os.environ["PGZERO_MODE"] == "False"

    # run toggle
    toggle_variable()

    # check toggled
    assert get_workbench().get_variable(_OPTION_NAME).get() == True

# Generated at 2022-06-24 08:00:07.972600
# Unit test for function update_environment
def test_update_environment():
    import unittest.mock
    temp_env = os.environ.copy()
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    os.environ = temp_env

# Generated at 2022-06-24 08:00:11.684760
# Unit test for function load_plugin
def test_load_plugin():
    # Would fail with KeyError if load_plugin was run.
    get_workbench().get_default(_OPTION_NAME)


if __name__ == "__main__":
    load_plugin()

# Generated at 2022-06-24 08:00:16.656419
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    var_run = wb.get_variable("run.pgzero_mode")
    if var_run.get():
        toggle_variable()
        assert var_run.get() is False
    toggle_variable()
    assert var_run.get() is True

# Generated at 2022-06-24 08:00:22.518246
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, True)
    wb.register_event_handler("EnvironmentChanged", update_environment)
    wb.set_option(_OPTION_NAME, False)
    assert os.environ["PGZERO_MODE"] == "False"
    wb.set_option(_OPTION_NAME, True)
    assert os.environment["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 08:00:27.303345
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.globals import get_workbench

    workbench = get_workbench()
    if workbench._command_manager._command_dict["toggle_pgzero_mode"]:
        return True
    else:
        return False


if __name__ == "__main__":
    print(test_load_plugin())

# Generated at 2022-06-24 08:00:34.833769
# Unit test for function update_environment
def test_update_environment():
    workbench = get_workbench()
    workbench.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    workbench.set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 08:00:45.185596
# Unit test for function update_environment
def test_update_environment():
    from unittest import mock
    from thonny import get_workbench

    w = get_workbench()

    with mock.patch('thonny.globals.get_workbench') as get_workbench_mock:
        get_workbench_mock.return_value = w
        os.environ.pop('PGZERO_MODE', None)
        # Test when simple mode
        w._simple_mode = True
        update_environment()
        assert os.environ.get('PGZERO_MODE') == 'auto'

        # Test when not in simple mode
        w._simple_mode = False
        # Test when not in simple mode and option is true
        w._options = {'run.pgzero_mode': True}
        update_environment()

# Generated at 2022-06-24 08:00:48.039911
# Unit test for function load_plugin
def test_load_plugin():
    assert get_workbench().get_option("run.pgzero_mode") is False
    assert os.environ["PGZERO_MODE"] == "False"



# Generated at 2022-06-24 08:00:55.959144
# Unit test for function load_plugin
def test_load_plugin():
    workbench = get_workbench()
    # Check that the option is defined
    assert workbench.get_variable(_OPTION_NAME) is not None
    # Check that the command is defined
    assert workbench.get_command('toggle_pgzero_mode') is not None
    # Check that the environment variable is set
    # assert os.environ["PGZERO_MODE"] == "0"
    # Check that the variable is reset to default value
    workbench.set_option(_OPTION_NAME, True)
    load_plugin()
    assert workbench.get_option(_OPTION_NAME) == False
    # Check that the environment variable is set correctly
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 08:01:03.407855
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    wb.set_simple_mode(True)
    wb.set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    wb.set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    wb.set_simple_mode(True)
    wb.set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 08:01:14.895029
# Unit test for function load_plugin
def test_load_plugin():
    import unittest.mock as mock

    get_workbench().set_default = mock.Mock()
    get_workbench().add_command = mock.Mock()
    os.environ["PGZERO_MODE"] = ""
    load_plugin()
    get_workbench().set_default.assert_called_with("run.pgzero_mode", False)
    get_workbench().add_command.assert_called_with(
        "toggle_pgzero_mode",
        "run",
        "Pygame Zero mode",
        toggle_variable,
        flag_name="run.pgzero_mode",
        group=40,
    )
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().in_simple_mode = lambda: True
    update_environment()
   

# Generated at 2022-06-24 08:01:17.475546
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert(get_workbench().get_option(_OPTION_NAME) == True)
    toggle_variable()
    assert(get_workbench().get_option(_OPTION_NAME) == False)


# Generated at 2022-06-24 08:01:27.065992
# Unit test for function load_plugin
def test_load_plugin():
    import unittest.mock
    from thonny import get_workbench, get_shell
    from thonny.common import ToplevelCommand

    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)

    orig_env = dict(os.environ)
    load_plugin()
    assert len(wb._commands)==1

    assert wb.get_option(_OPTION_NAME)==False
    assert os.environ["PGZERO_MODE"] == "False"

    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    # Unit test for function update_environment
    def test_update_environment():
        import unittest.mock

# Generated at 2022-06-24 08:01:32.484868
# Unit test for function load_plugin
def test_load_plugin():
    # Reset default option
    get_workbench().set_default(_OPTION_NAME, False)
    # Ensure env var is not set
    if "PGZERO_MODE" in os.environ:
        del os.environ["PGZERO_MODE"]
    # Check option is set
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == 0
    # Check env var is set
    update_environment()
    assert os.environ.get("PGZERO_MODE") == "False"
    # Check option is toggled
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == 1
    # Check env var is set
    update_environment()
    assert os.environ.get("PGZERO_MODE") == "True"