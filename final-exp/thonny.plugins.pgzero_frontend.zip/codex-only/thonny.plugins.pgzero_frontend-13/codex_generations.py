

# Generated at 2022-06-24 07:51:15.162297
# Unit test for function update_environment
def test_update_environment():
    try:
        os.environ["PGZERO_MODE"]
    except KeyError:
        os.environ["PGZERO_MODE"] = "auto"
    get_workbench().set_default(_OPTION_NAME, False)
    assert get_workbench().in_simple_mode() == False
    assert os.environ["PGZERO_MODE"] == "0"

    get_workbench().set_default(_OPTION_NAME, True)
    assert get_workbench().in_simple_mode() == False
    assert os.environ["PGZERO_MODE"] == "1"

    get_workbench().set_simple_mode(True)
    assert get_workbench().in_simple_mode() == True
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:51:20.748837
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.globals import get_workbench, in_simple_mode
    set_workbench_mode(False)
    load_plugin()

    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == True
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == False

# Generated at 2022-06-24 07:51:29.834470
# Unit test for function load_plugin
def test_load_plugin():
    workbench = get_workbench()

    assert workbench.default("run.pgzero_mode") == False
    assert workbench.get_option("run.pgzero_mode") == False

    load_plugin()

    assert workbench.get_option("run.pgzero_mode") == False
    assert workbench.get_variable("run.pgzero_mode").get() == False
    assert workbench.get_variable("run.pgzero_mode").default == False
    assert workbench.get_command("toggle_pgzero_mode") is not None
    assert os.environ["PGZERO_MODE"] == "False"
    # assert workbench.get_option("run.pgzero_mode") == False

    # FIXME: enable simulation of simple mode
    # # enable simple mode
    # workbench.set_simple_mode(

# Generated at 2022-06-24 07:51:36.607463
# Unit test for function update_environment
def test_update_environment():
    wb = Mock()
    wb.in_simple_mode.return_value = True
    wb._get_option_storage.__getitem__.side_effect = lambda k: {
        "run.pgzero_mode": True
    }.get(k)

    with patch.object(thonny.workbench, "get_workbench", lambda: wb):
        update_environment()
        assert os.environ["PGZERO_MODE"] == "auto"
        wb._get_option_storage.__getitem__.side_effect = lambda k: {
            "run.pgzero_mode": False
        }.get(k)
        update_environment()
        assert os.environ["PGZERO_MODE"] == "False"



# Generated at 2022-06-24 07:51:40.660332
# Unit test for function update_environment
def test_update_environment():
    # default
    get_workbench().set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"


# Generated at 2022-06-24 07:51:50.467594
# Unit test for function update_environment
def test_update_environment():
    try:
        del os.environ["PGZERO_MODE"]
    except KeyError:
        pass

    get_workbench().in_simple_mode = lambda: True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().in_simple_mode = lambda: False
    get_workbench().get_option = lambda name: True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"

    get_workbench().get_option = lambda name: False
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"

    get_workbench().in_simple_mode = lambda: True
    update_environment()

# Generated at 2022-06-24 07:51:56.183235
# Unit test for function toggle_variable
def test_toggle_variable():
    from unittest.mock import Mock
    var = Mock()
    get_workbench().set_variable(_OPTION_NAME, var)

    toggle_variable()
    assert var.set.call_count == 1
    assert var.set.call_args == ((False,),)

    toggle_variable()
    assert var.set.call_count == 2
    assert var.set.call_args == ((True,),)

# Generated at 2022-06-24 07:52:01.140483
# Unit test for function load_plugin
def test_load_plugin():
    call_load_plugin()
    assert get_workbench().get_command("toggle_pgzero_mode").flag_name == "run.pgzero_mode"
    os.environ["PGZERO_MODE"] = "False"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().get_option(_OPTION_NAME).set(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:52:07.178121
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench

    workbench = Workbench()
    workbench.set_default(_OPTION_NAME, False)
    assert workbench.get_option(_OPTION_NAME) == False
    # load_plugin requires a GUI
    load_plugin()
    assert workbench.get_option(_OPTION_NAME) == False

# Generated at 2022-06-24 07:52:13.756725
# Unit test for function toggle_variable
def test_toggle_variable():
    from mock import Mock
    from thonny.plugins.run.run_configuration import set_run_configuration
    from thonny.languages import ui_language
    from thonny import get_workbench

    get_workbench().set_default(_OPTION_NAME, False)
    set_run_configuration(Mock)
    update_environment()

    toggle_variable()

    assert get_workbench().get_option(_OPTION_NAME)
    assert os.environ["PGZERO_MODE"] == "True"
    print(get_workbench().get_variable(_OPTION_NAME).value)

# Generated at 2022-06-24 07:52:18.589434
# Unit test for function toggle_variable
def test_toggle_variable():
    if get_workbench().get_variable(_OPTION_NAME).get() == False:
        assert os.environ["PGZERO_MODE"] == "False"
    elif get_workbench().get_variable(_OPTION_NAME).get() == True:
        assert os.environ["PGZERO_MODE"] == "True"


# Generated at 2022-06-24 07:52:19.134612
# Unit test for function toggle_variable

# Generated at 2022-06-24 07:52:26.459113
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import create_autospec
    from thonny.workbench import Workbench

    workbench = create_autospec(Workbench(), spec_set=True)
    workbench.get_variable.return_value = workbench
    workbench.get_option.return_value = True
    workbench.in_simple_mode.return_value = False

    def test_env(key):
        if key == "PGZERO_MODE":
            return "True"
        return ""

    os.environ = create_autospec(dict(), spec_set=True)
    os.environ.get.side_effect = test_env

    update_environment()
    workbench.get_option.assert_called_once_with(_OPTION_NAME)

# Generated at 2022-06-24 07:52:34.469864
# Unit test for function update_environment
def test_update_environment():
    del os.environ["PGZERO_MODE"]
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().get_option(_OPTION_NAME).set(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:52:40.984420
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default("run.pgzero_mode2", "")
    assert wb.in_simple_mode() is False
    assert wb.get_option("run.pgzero_mode") is False
    load_plugin()
    assert wb.in_simple_mode() is False
    assert wb.get_option("run.pgzero_mode") is False


if __name__ == "__main__":
    test_load_plugin()

# Generated at 2022-06-24 07:52:48.092961
# Unit test for function update_environment
def test_update_environment():
    import sys
    import os
    import tempfile
    import shutil
    import unittest
    from unittest.mock import patch

    from thonny import get_runner, get_workbench

    class TestWorkbench(object):
        def __init__(self):
            self._config = {}

        def get_option(self, name):
            return self._config.get(name, False)

        def set_default(self, name, default):
            self._config[name] = default

        def in_simple_mode(self):
            return False

    class TestRunner(object):
        def __init__(self):
            self._config = {}

        def get_option(self, name):
            return self._config.get(name, False)


# Generated at 2022-06-24 07:52:57.731208
# Unit test for function update_environment
def test_update_environment():
    import thonny
    import os
    os.environ["PGZERO_MODE"] = "1"
    wb = thonny.Workbench()
    wb.set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"
    wb.set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"
    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"
    wb.set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"


# Generated at 2022-06-24 07:52:59.361539
# Unit test for function toggle_variable
def test_toggle_variable():
    assert (toggle_variable()==None)


# Generated at 2022-06-24 07:53:03.302498
# Unit test for function load_plugin
def test_load_plugin():
    if not get_workbench().in_simple_mode():
        raise AssertionError("In simple mode")
    load_plugin()

    if get_workbench().in_simple_mode():
        raise AssertionError("Not in simple mode")
    get_workbench().unload_plugin("thonnycontrib.pgzero")

# Generated at 2022-06-24 07:53:06.523625
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = ""
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    os.environ["PGZERO_MODE"] = ""
    get_wor

# Generated at 2022-06-24 07:53:12.281451
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = "auto"
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.simple_mode = False
    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"

    wb.set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"



# Generated at 2022-06-24 07:53:16.625824
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    var = wb.get_variable(_OPTION_NAME)
    var.set(False)
    assert not var.get()
    toggle_variable()
    assert var.get()
    toggle_variable()
    assert not var.get()

# Generated at 2022-06-24 07:53:18.826934
# Unit test for function load_plugin
def test_load_plugin():
    assert get_workbench().get_option(_OPTION_NAME) == False


if __name__ == "__main__":
    load_plugin()

else:
    load_plugin()

# Generated at 2022-06-24 07:53:24.510081
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = ""
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    wb = get_workbench()
    wb.set_simple_mode(False)
    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"

# Generated at 2022-06-24 07:53:29.860062
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import MagicMock

    wb = MagicMock()
    wb.get_option = MagicMock(return_value=True)
    wb.in_simple_mode = MagicMock(return_value=False)
    with patch("thonny.plugins.pgzero.update_environment.get_workbench", lambda: wb):
        update_environment()
        assert os.environ["PGZERO_MODE"] == "True"



# Generated at 2022-06-24 07:53:33.915226
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    assert not get_workbench().get_option(_OPTION_NAME)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME)
    toggle_variable()
    assert not get_workbench().get_option(_OPTION_NAME)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME)

# Generated at 2022-06-24 07:53:43.301121
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import MagicMock
    from thonny import get_workbench

    get_workbench().in_simple_mode = MagicMock(return_value=False)
    get_workbench().set_default = MagicMock()
    get_workbench().add_command = MagicMock()
    get_workbench().set_default = MagicMock()
    get_workbench().get_option = MagicMock(return_value=True)
    update_environment = MagicMock()

    load_plugin()

    get_workbench().set_default.assert_called_once_with(_OPTION_NAME, False)
    get_workbench().add_command.assert_called_once()
    get_workbench().get_option.assert_called_once()
    update_environment.assert_called_once

# Generated at 2022-06-24 07:53:48.662757
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().in_simple_mode = Mock(return_value=True)
    wb = get_workbench()
    wb.get_variable.return_value = Mock()
    wb.set_default.return_value = True
    wb.add_command.return_value = True
    load_plugin()
    assert not get_workbench().get_variable(_OPTION_NAME)

# Generated at 2022-06-24 07:53:54.226706
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench
    from thonny.misc_utils import running_on_mac_os

    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"

    get_workbench().set_simple_mode(True)
    update_environment()
    if running_on_mac_os():
        assert os.environ["PGZERO_MODE"] == "1"
    else:
        assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()

# Generated at 2022-06-24 07:53:59.854374
# Unit test for function toggle_variable
def test_toggle_variable():
    # pylint: disable=protected-access
    get_workbench()._set_variable(_OPTION_NAME, True)
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == True
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == False

# Generated at 2022-06-24 07:54:07.310329
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import Mock
    from unittest.mock import patch

    os.environ = {}
    get_workbench = Mock()
    get_workbench.in_simple_mode.return_value = False
    get_workbench.get_option.return_value = True

    with patch("thonny.plugins.pgzero_mode.get_workbench") as get_workbench_mock:
        get_workbench_mock.return_value = get_workbench
        update_environment()
        assert os.environ["PGZERO_MODE"] == "True"



# Generated at 2022-06-24 07:54:17.494644
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.workbench import Workbench
    from unittest.mock import Mock
    import tkinter as tk
    workbench = Workbench(get_workbench())
    workbench.text_editor = Mock()
    workbench.get_editor_notebook = Mock(return_value=Mock(tabs=Mock()))
    workbench.get_editor_notebook().tabs().index = Mock(return_value=True)
    workbench.get_editor_notebook().tabs().select = Mock()
    workbench.get_editor_notebook().tabs().curselection = Mock(return_value=True)
    workbench.get_editor_notebook().tabs().curselection().get = Mock(return_value=True)
    workbench._root = Mock(tk.Tk)
   

# Generated at 2022-06-24 07:54:20.848803
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()

# Generated at 2022-06-24 07:54:31.805119
# Unit test for function update_environment
def test_update_environment():

    class FakeWorkbench():

        def get_option_definitions(self):
            return {_OPTION_NAME: "boolean"}

        def set_option(self, name, value):
            self.options[name] = value

        def get_option(self, name):
            return self.options[name]

        def in_simple_mode(self):
            return False

        def __init__(self):
            self.options = {}

    w = FakeWorkbench()
    w.set_option(_OPTION_NAME, False)
    w.in_simple_mode = lambda: False
    assert (os.environ.get("PGZERO_MODE", "False") == "False")

    w.set_option(_OPTION_NAME, True)
    update_environment()

# Generated at 2022-06-24 07:54:38.989975
# Unit test for function update_environment
def test_update_environment():
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().set_simple_mode(False)
    print(get_workbench().get_variable(_OPTION_NAME))
    get_workbench().set_variable(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_variable(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"


# Generated at 2022-06-24 07:54:45.014253
# Unit test for function update_environment
def test_update_environment():
    workbench = get_workbench()
    workbench.set_simple_mode(False)
    workbench.set_option("run.pgzero_mode", False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    workbench.set_option("run.pgzero_mode", True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    workbench.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:54:53.219986
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.workbench import Workbench
    from thonny.plugins.userinterface import UserInterfacePlugin
    from unittest import mock

    wb = Workbench()
    ui_plugin = UserInterfacePlugin(wb)
    ui_plugin.load()
    load_plugin()

    wb._set_variable(_OPTION_NAME, False)
    with mock.patch("os.environ") as mock_env:
        toggle_variable()
        toggle_variable()
        wb._set_variable(_OPTION_NAME, True)
        assert mock_env["PGZERO_MODE"] == "False"
        toggle_variable()
        assert mock_env["PGZERO_MODE"] == "True"
        toggle_variable()
        assert mock_env["PGZERO_MODE"] == "False"
        wb._

# Generated at 2022-06-24 07:54:59.442308
# Unit test for function load_plugin
def test_load_plugin():
    import unittest.mock

    wb = unittest.mock.Mock()
    wb.set_default.assert_not_called()
    wb.add_command.assert_not_called()

    load_plugin()

    wb.set_default.assert_called_once_with(_OPTION_NAME, False)
    wb.add_command.assert_called()

# Generated at 2022-06-24 07:55:08.182361
# Unit test for function update_environment
def test_update_environment():
    workbench = get_workbench()
    
    workbench.set_default(_OPTION_NAME, False)
    workbench.set_simple_mode(True)
    update_environment()
    assert os.getenv("PGZERO_MODE", "") == "auto"
    
    workbench.set_default(_OPTION_NAME, True)
    update_environment()
    assert os.getenv("PGZERO_MODE", "") == "True"
    
    workbench.set_simple_mode(False)
    update_environment()
    assert os.getenv("PGZERO_MODE", "") == "True"
    
    workbench.set_simple_mode(True)
    update_environment()
    assert os.getenv("PGZERO_MODE", "") == "auto"

# Generated at 2022-06-24 07:55:15.066865
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench

    workbench = Workbench()
    workbench.set_default(_OPTION_NAME, False)
    workbench.in_simple_mode = lambda: False

    assert "PGZERO_MODE" not in os.environ

    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    workbench.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    workbench.in_simple_mode = lambda: True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:55:19.896705
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_option(_OPTION_NAME, True)
    assert os.environ.get("PGZERO_MODE") == "True"
    toggle_variable()
    assert os.environ.get("PGZERO_MODE") == "False"
    toggle_variable()
    assert os.environ.get("PGZERO_MODE") == "True"

# Generated at 2022-06-24 07:55:28.439360
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_simple_mode(True)
    load_plugin()
    assert wb.get_option(_OPTION_NAME) == False
    assert os.getenv("PGZERO_MODE") == "auto"
    toggle_variable()
    assert wb.get_variable(_OPTION_NAME)
    # assert wb.get_option(_OPTION_NAME) == True
    assert os.getenv("PGZERO_MODE") == "1"
    wb.set_simple_mode(False)
    assert wb.get_variable(_OPTION_NAME)
    # assert wb.get_option(_OPTION_NAME) == True
    assert os.getenv("PGZERO_MODE") == "auto"
    toggle_variable()
    assert wb.get_variable

# Generated at 2022-06-24 07:55:32.747218
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default("run.pgzero_mode", True)
    get_workbench().get_editor("Test1.py").set_text("1 + 2")
    get_workbench().execute("Test1.py")
    assert "true" in get_workbench().get_shell().get_debugger_history()

# Generated at 2022-06-24 07:55:37.587262
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    assert wb.get_variable(_OPTION_NAME).get() == False
    wb.set_default(_OPTION_NAME, True)
    assert wb.get_variable(_OPTION_NAME).get() == True
    assert os.environ["PGZERO_MODE"] == "True"
    load_plugin()
    assert wb.get_variable(_OPTION_NAME).get() == False
    assert os.environ["PGZERO_MODE"] == "False"



# Generated at 2022-06-24 07:55:40.960645
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench

    wb = get_workbench()
    wb.set_default(_OPTION_NAME, True)

    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    wb.set_default(_OPTION_NAME, False)
    update_environment()

    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:55:41.590491
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()

# Generated at 2022-06-24 07:55:51.912866
# Unit test for function load_plugin
def test_load_plugin():
    import unittest
    import unittest.mock
    from thonny.misc_utils import get_python_path

    def run_test(expected_shell_env):
        with unittest.mock.patch("thonny.plugins.pgzero.shutil") as mock_shutil:
            with unittest.mock.patch("thonny.plugins.pgzero.sys") as mock_sys:
                with unittest.mock.patch("thonny.plugins.pgzero.os") as mock_os:
                    with unittest.mock.patch("thonny.plugins.pgzero.tkinter"):
                        mock_sys.executable = get_python_path()
                        wb = unittest.mock.MagicMock()
                        wb.execute_script.return_value.c

# Generated at 2022-06-24 07:55:59.649620
# Unit test for function toggle_variable
def test_toggle_variable():
    from pytest import raises
    # Assert that PGZERO_MODE is absent when setting a default value
    get_workbench().set_default(_OPTION_NAME, True)
    assert "PGZERO_MODE" not in os.environ
    # Assert that PGZERO_MODE is set to False at the beginning
    get_workbench().set_default(_OPTION_NAME, False)
    assert os.environ["PGZERO_MODE"] == "False"
    # Assert that PGZERO_MODE is set to True when using the function
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    # Assert that PGZERO_MODE is set to False when using the function again
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:56:05.302959
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, True)
    load_plugin()
    assert get_workbench().get_variable(_OPTION_NAME).get() == True
    assert get_workbench().get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"
    assert get_workbench().in_simple_mode() == False


if __name__ == "__main__":
    test_load_plugin()

# Generated at 2022-06-24 07:56:07.668818
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()
    assert not get_workbench().get_option(_OPTION_NAME)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME)


# Generated at 2022-06-24 07:56:13.368254
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_simple_mode(True)
    update_environment()
    assert len(os.environ) == 1

    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:56:19.834054
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    assert not get_workbench().get_option(_OPTION_NAME)
    assert not os.environ.get("PGZERO_MODE")
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME)
    assert os.environ.get("PGZERO_MODE")

# Generated at 2022-06-24 07:56:28.947895
# Unit test for function toggle_variable
def test_toggle_variable():
    from unittest import TestCase
    from unittest.mock import Mock

    objects = {}

    def get_default(key):
        return Mock(get=Mock(return_value=False))

    def set_default(key, value):
        return Mock(return_value=value)

    def get_variable(key):
        return Mock(get=Mock(return_value=False))

    def get_option(key):
        return Mock(get=Mock(return_value=True))

    def set_variable(key, value):
        return Mock(return_value=value)

    def add_command(
        self, name, category, label, handler, tester=None, default_sequence=None, group=None
    ):
        objects["command"] = Mock(get=Mock(return_value=True))

# Generated at 2022-06-24 07:56:32.588936
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.workbench import Workbench

    get_workbench().destroy()
    get_workbench = Workbench.create
    load_plugin()
    wb = get_workbench()

    # Check if option is disabled
    get_workbench().set_option(_OPTION_NAME, False)
    assert not wb.get_option(_OPTION_NAME)

    # Check if option is toggled
    toggle_variable()
    assert wb.get_option(_OPTION_NAME)

    # Check if option is toggled back
    toggle_variable()
    assert not wb.get_option(_OPTION_NAME)

# Generated at 2022-06-24 07:56:39.089517
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert os.environ["PGZERO_MODE"] == "False"
    load_plugin()
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"
    load_plugin()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:56:44.097441
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_option(_OPTION_NAME, True)
    os.environ["PGZERO_MODE"] = "False"
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:56:51.814094
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import patch
    from thonny.simple_ui import SimpleWorkbench
    
    wb = SimpleWorkbench()
    wb.set_option(_OPTION_NAME, True)
    
    with patch.dict(os.environ, {}):
        update_environment()
        assert os.environ["PGZERO_MODE"] == "True"

    with patch.dict(os.environ, {}):
        wb.enter_simple_mode()
        update_environment()
        assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:56:53.854914
# Unit test for function update_environment
def test_update_environment():
    # Test default value
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"


# Generated at 2022-06-24 07:57:03.087562
# Unit test for function load_plugin
def test_load_plugin():

    def mock_get_workbench():
        return mock_workbench

    mock_workbench = unittest.mock.MagicMock()
    mock_workbench.in_simple_mode = lambda: False
    mock_workbench.get_option = lambda x: False
    mock_workbench.set_default = lambda x, y: None
    mock_workbench.add_command = lambda *x: None
    mock_workbench.get_variable = lambda x: mock_variable
    mock_variable = unittest.mock.MagicMock()
    mock_variable.get = lambda: False
    mock_variable.set = lambda x: None

    with unittest.mock.patch("thonny.plugins.pgzero_mode.get_workbench", new=mock_get_workbench):
        load_plugin()

# Generated at 2022-06-24 07:57:13.500071
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.misc_utils import MockView
    from thonny.workbench import Workbench
    workbench = Workbench(MockView())
    load_plugin()
    assert len(workbench.get_variable_set().get_variables()) == 9
    assert len(workbench.get_bindings()) == 20
    assert len(workbench.get_command_set().get_commands()) == 18
    assert len(workbench.get_menu_definitions()) == 20
    assert len(workbench.get_toolbar_definitions()) == 4
    #assert workbench.get_menu_definitions()[2]['items'][2]['label'] == 'Pygame Zero mode'

# Generated at 2022-06-24 07:57:25.124733
# Unit test for function update_environment
def test_update_environment():

    from thonny import get_workbench, get_runner
    from thonny.plugins.pgzero_mode import update_environment
    get_workbench().set_default("run.pgzero_mode", True)
    update_environment()
    assert "PGZERO_MODE" in os.environ

    get_workbench().set_default("run.pgzero_mode", False)
    update_environment()
    assert "PGZERO_MODE" not in os.environ

    get_workbench().set_default("run.pgzero_mode", True)
    os.environ["PGZERO_MODE"] = "0"
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"

    runner = get_runner()
    runner.stop()
    runner.start()

# Generated at 2022-06-24 07:57:36.350123
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    original = wb.get_plugin("thonnycontrib.pgzero")
    wb.unload_plugin("thonnycontrib.pgzero")
    wb.set_default(_OPTION_NAME, True)
    assert "PGZERO_MODE" not in os.environ

    assert not hasattr(wb, _OPTION_NAME)
    load_plugin()
    assert wb.get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"

    assert wb.get_command("toggle_pgzero_mode")

    wb.unload_plugin("thonnycontrib.pgzero")
    assert not hasattr(wb, _OPTION_NAME)

# Generated at 2022-06-24 07:57:41.044268
# Unit test for function toggle_variable
def test_toggle_variable():
    #checking default
    default_value = get_workbench().get_variable(_OPTION_NAME)
    assert (
        default_value.get() == False
    ), "Pygame Zero Mode has to be off by default"

    #changing value
    toggle_variable()
    default_value = get_workbench().get_variable(_OPTION_NAME)
    assert default_value.get() != False, "Pygame Zero Mode is not working"


# Generated at 2022-06-24 07:57:52.281885
# Unit test for function load_plugin
def test_load_plugin():
    from unittest import mock

    from thonny import get_workbench
    from thonny.workbench import Workbench

    with mock.patch("thonny.plugins.pygame_zero_mode.toggle_variable"):
        with mock.patch("thonny.plugins.pygame_zero_mode.update_environment"):
            wb = Workbench()
            wb.create()
            wb.load_plugin(__name__)


if __name__ == "__main__":
    get_workbench().set_simple_mode(True)
    print(os.environ.get("PGZERO_MODE"))

    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().set_simple_mode(False)

# Generated at 2022-06-24 07:57:56.660943
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)

    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() is True
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:58:02.694744
# Unit test for function update_environment
def test_update_environment():
    from thonny.globals import get_workbench
    from unittest import mock
    import os

    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)

    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:58:03.472660
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()



# Generated at 2022-06-24 07:58:08.325836
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_simple_mode(False)
    get_workbench().set_default(_OPTION_NAME, False)

    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME)

    toggle_variable()
    assert not get_workbench().get_option(_OPTION_NAME)

    get_workbench().set_simple_mode(True)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME)
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:58:10.937158
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True



# Generated at 2022-06-24 07:58:14.892853
# Unit test for function toggle_variable
def test_toggle_variable():
    # Initialise a 'workbench' with a Tk root window to allow tests to run
    get_workbench().tk_root = Tk()
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    get_workbench().tk_root.destroy()

# Generated at 2022-06-24 07:58:17.040497
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    wb = get_workbench()
    assert wb.get_option(_OPTION_NAME) == False


# Generated at 2022-06-24 07:58:23.060173
# Unit test for function toggle_variable
def test_toggle_variable():
    test_workbench = get_workbench()
    test_run_pgzero_mode = test_workbench.get_variable(_OPTION_NAME)
    assert not test_run_pgzero_mode.get(), "Toggle variable should be false in the beginning"
    toggle_variable()
    assert test_run_pgzero_mode.get(), "Toggle variable should be true after toggle"
    toggle_variable()
    assert not test_run_pgzero_mode.get(), "Toggle variable should be false after second toggle"

# Generated at 2022-06-24 07:58:27.637855
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = ""
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"

    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"

# Generated at 2022-06-24 07:58:31.149360
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_var,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()



# Generated at 2022-06-24 07:58:35.881901
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:58:40.631039
# Unit test for function toggle_variable
def test_toggle_variable():
    workbench = get_workbench()

    # It should be off by default
    assert get_workbench().get_option(_OPTION_NAME) is False

    # It should go on after first toggle
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) is True

    # It should go off after second toggle
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) is False

    # It should go on after second toggle
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) is True

    # It should be off when "auto" is set
    workbench.set_simple_mode(True)
    assert os.environ["PGZERO_MODE"] == "auto"
    toggle_variable()
    assert os.environ

# Generated at 2022-06-24 07:58:46.161835
# Unit test for function toggle_variable
def test_toggle_variable():
    if "PGZERO_MODE" in os.environ:
        del os.environ["PGZERO_MODE"]
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:58:54.876821
# Unit test for function toggle_variable
def test_toggle_variable():
    from unittest.mock import Mock
    from thonny.plugins.run import RunConfiguration

    # Mock get_workbench()
    get_workbench = Mock()
    get_workbench.get_option = Mock(return_value=False)
    get_workbench.set_option = Mock()
    get_workbench.in_simple_mode = Mock(return_value=False)
    get_workbench.get_variable = Mock()
    get_workbench.get_variable.return_value = RunConfiguration(_OPTION_NAME, False)

    with patch("thonny.plugins.run.pgzero.get_workbench", get_workbench):
        toggle_variable()
        assert get_workbench.set_option.call_count == 1
        assert get_workbench.get_option.call_count == 1



# Generated at 2022-06-24 07:59:04.675471
# Unit test for function update_environment
def test_update_environment():
    from unittest import mock
    import os
    import os.path
    from thonny.misc_utils import running_on_mac_os

    get_workbench = mock.Mock()
    get_workbench.return_value = get_workbench

    get_workbench.get_option.return_value = "True"
    get_workbench.in_simple_mode = False
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench.get_option.return_value = "False"
    get_workbench.in_simple_mode = False
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"


    get_workbench.in_simple_mode = True
    update_environment()
    assert os

# Generated at 2022-06-24 07:59:08.774298
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.register_editor_window(Tk.Text())
    wb.emulate_command_shortcut("toggle_pgzero_mode")
    assert wb.get_option(_OPTION_NAME) == True

# Generated at 2022-06-24 07:59:10.528248
# Unit test for function toggle_variable
def test_toggle_variable():
    load_plugin()
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == str(True)

# Generated at 2022-06-24 07:59:13.279704
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    load_plugin()
    assert os.environ["PGZERO_MODE"] == "False"
    update_environment()


# Generated at 2022-06-24 07:59:21.682932
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import Mock
    from thonny import get_workbench

    workbench = Mock()
    workbench.get_option = Mock(return_value=False)
    get_workbench = Mock(return_value=workbench)
    os.environ["PGZERO_MODE"] = str(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"
    workbench.get_option = Mock(return_value=True)
    get_workbench = Mock(return_value=workbench)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"

# Generated at 2022-06-24 07:59:24.770924
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()

    # Fresh instance
    wb.destroy()
    wb.reload_workbench()
    assert wb.get_option(_OPTION_NAME) is False

    # Plugin is disabled by default
    load_plugin()
    assert wb.get_option(_OPTION_NAME) is False


# Generated at 2022-06-24 07:59:34.533233
# Unit test for function update_environment
def test_update_environment():
    assert os.environ.get("PGZERO_MODE") == "False"
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ.get("PGZERO_MODE") == "True"
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ.get("PGZERO_MODE") == "False"
    get_workbench().set_option(_OPTION_NAME, True)
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ.get("PGZERO_MODE") == "auto"

# Generated at 2022-06-24 07:59:36.893657
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True

# Generated at 2022-06-24 07:59:39.166251
# Unit test for function update_environment
def test_update_environment():
    print(os.environ)
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()

# Generated at 2022-06-24 07:59:47.198925
# Unit test for function toggle_variable
def test_toggle_variable():
    try:
        get_workbench().set_option(_OPTION_NAME, True)
        assert os.environ["PGZERO_MODE"] == "True"
        assert get_workbench().get_option(_OPTION_NAME) == True
    except Exception as e:
        pass
    try:
        get_workbench().set_option(_OPTION_NAME, False)
        assert os.environ["PGZERO_MODE"] == "False"
        assert get_workbench().get_option(_OPTION_NAME) == False
    except Exception as e:
        pass

# Generated at 2022-06-24 07:59:57.733730
# Unit test for function toggle_variable
def test_toggle_variable():
    from unittest.mock import Mock
    from thonny.plugins.run import toggle_variable
    from thonny.workbench import Workbench
    my_workbench = Workbench()
    my_workbench.get_variable = Mock(
        side_effect=lambda name, default: Mock(get=lambda: name == _OPTION_NAME)
    )
    my_workbench.add_command = Mock()
    my_workbench.in_simple_mode = Mock(return_value=False)
    my_workbench.set_default = Mock()
    my_workbench.get_option = Mock(return_value=True)
    my_workbench.set_option = Mock()
    toggle_variable()
    my_workbench.set_option.assert_called_with(_OPTION_NAME, False)
    #

# Generated at 2022-06-24 08:00:09.650512
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import Mock
    del os.environ["PGZERO_MODE"]
    wb = Mock()
    wb.in_simple_mode = Mock(return_value = True)

    with contextlib.ExitStack() as stack:
        stack.enter_context(patch("thonny.globals.get_workbench", return_value=wb))
        update_environment()
        assert os.environ["PGZERO_MODE"] == "auto"

    wb.in_simple_mode = Mock(return_value = False)
    wb.get_option = Mock(return_value = 1)

    with contextlib.ExitStack() as stack:
        stack.enter_context(patch("thonny.globals.get_workbench", return_value=wb))
        update_environment()


# Generated at 2022-06-24 08:00:16.349417
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().in_simple_mode()
    get_workbench().set_default(_OPTION_NAME, False)
    # Test initial state of variable, which should be false
    var = get_workbench().get_variable(_OPTION_NAME)
    assert var.get() is False
    # Test that variable is set to true after toggle
    toggle_variable()
    assert var.get() is True
    # Test that variable is set to false after toggle
    toggle_variable()
    assert var.get() is False


# Generated at 2022-06-24 08:00:24.725024
# Unit test for function update_environment
def test_update_environment():
    wb = MockWorkbench()
    wb.set_default("run.pgzero_mode", False)
    wb.set_simple_mode(False)
    update_environment()
    assert "PGZERO_MODE" in os.environ
    assert os.environ["PGZERO_MODE"] == "False"

    wb.set_option("run.pgzero_mode", True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    # Auto mode - pgzero mode
    wb.set_simple_mode(True)
    wb.set_option("run.pgzero_mode", False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    # Auto mode - non-pgzero mode
    wb

# Generated at 2022-06-24 08:00:34.796847
# Unit test for function toggle_variable
def test_toggle_variable():
    # Unit test for function toggle_variable
        def my_assert(expected_pgzero_mode):
            assert get_workbench().get_option(_OPTION_NAME) == expected_pgzero_mode
            assert os.environ["PGZERO_MODE"] == str(get_workbench().get_option(_OPTION_NAME))

        my_assert(False)
        toggle_variable()
        my_assert(True)
        toggle_variable()
        my_assert(False)
        toggle_variable()
        my_assert(True)
        get_workbench().enter_simple_mode()
        my_assert(False)
        toggle_variable()
        my_assert(True)
        get_workbench().leave_simple_mode()
        my_assert(True)
        toggle_variable()
        my_assert(False)

# Generated at 2022-06-24 08:00:40.064030
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"



# Generated at 2022-06-24 08:00:47.000140
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = "auto"

    load_plugin()
    update_environment()
    os.environ["PGZERO_MODE"] = "bla"
    update_environment()

    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()

    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()

    get_workbench().set_option("general.simple_mode", True)
    update_environment()

# Generated at 2022-06-24 08:00:52.570286
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.clear_variables()
    load_plugin()
    assert wb.in_simple_mode() is False
    assert wb.get_variable(_OPTION_NAME).get() is False
    assert os.environ["PGZERO_MODE"] == "False"

    toggle_variable()
    assert wb.get_variable(_OPTION_NAME).get() is True
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()

    wb.set_simple_mode(True)
    load_plugin()
    assert wb.in_simple_mode() is True
    assert wb.get_variable(_OPTION_NAME).get() is False
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 08:01:02.003157
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import Mock

    wb = Mock()
    wb.in_simple_mode.return_value = True
    wb.get_option.return_value = True

    wb.get_variable = Mock()
    var = Mock()
    var.get.return_value = True
    wb.get_variable.return_value = var
    wb.declare_variable(_OPTION_NAME, False)

    wb.add_command = Mock()
    wb.set_default = Mock()

    load_plugin(wb)

    #assert_equals("auto", os.environ["PGZERO_MODE"])
    assert_equals("True", os.environ["PGZERO_MODE"])

    var.set(False)


# Generated at 2022-06-24 08:01:13.613905
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock, patch
    from thonny import get_workbench

    get_workbench().set_default = Mock()
    get_workbench().add_command = Mock()

    with patch.dict("os.environ", {"PGZERO_MODE": "auto"}):
        load_plugin()
    get_workbench().set_default.assert_called_with(_OPTION_NAME, False)
    get_workbench().add_command.assert_called_with(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    assert os.environ.get("PGZERO_MODE") == "False"
