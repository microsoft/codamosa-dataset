

# Generated at 2022-06-24 07:50:49.122957
# Unit test for function update_environment
def test_update_environment():
    from unittest import mock
    import thonny
    from thonny.globals import get_workbench

    # Monkey patch the workbench with a mock
    plugin_manager = mock.create_autospec(thonny.plugin_manager.PluginManager, spec_set=True)
    plugin_manager.is_simple_mode.__get__ = lambda self: True
    plugin_manager._get_option.__get__ = lambda self, key: False
    wb = mock.create_autospec(thonny.workbench.Workbench, spec_set=True)
    wb.pm = plugin_manager
    thonny.globals.get_workbench = lambda: wb

    # Test that PGZERO_MODE is set to auto in simple mode.
    update_environment()
    assert os.environ

# Generated at 2022-06-24 07:50:55.190731
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.languages import EnglishLanguage
    from thonny.plugins.run.run import RunConfigurationDialog
    from thonny import get_runner
    from thonny.config import get_workbench
    from thonny import THONNY_USER_DIR
    import shutil
    import os
    from thonny.common import TkVersion
    import tkinter
    import sys

    if sys.platform != "darwin":  # running pgzero with display causes errors on mac os
        if "DISPLAY" in os.environ:
            del os.environ["DISPLAY"]

# Generated at 2022-06-24 07:51:01.203836
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.commands import Command

    Workbench().load_plugin(load_plugin)

    cmd = Workbench().get_command("toggle_pgzero_mode")

    assert cmd is not None
    assert isinstance(cmd, Command)

    assert Workbench().get_option(_OPTION_NAME) == False
    Workbench().get_option(_OPTION_NAME).set(True)
    assert Workbench().get_option(_OPTION_NAME) == True

# Generated at 2022-06-24 07:51:10.171873
# Unit test for function update_environment
def test_update_environment():
    # Stub get_workbench
    def get_workbench_stub():
        class WorkbenchStub:
            def __init__(self):
                self._in_simple_mode_value = False
                self._get_option_value = False

            def in_simple_mode(self):
                return self._in_simple_mode_value

            def get_option(self, option_name):
                if option_name == _OPTION_NAME:
                    return self._get_option_value

        return WorkbenchStub()

    old_get_workbench = get_workbench
    get_workbench = get_workbench_stub

    def set_in_simple_mode(value):
        get_workbench()._in_simple_mode_value = value


# Generated at 2022-06-24 07:51:20.249112
# Unit test for function load_plugin
def test_load_plugin():
    from unittest import mock
    from thonny.globals import get_workbench

    mock_workbench = mock.Mock(spec=get_workbench())
    mock_workbench.get_variable.return_value.get.return_value = False
    with mock.patch("thonny.plugins.pgzero_mode.get_workbench", return_value=mock_workbench):
        load_plugin()
        mock_workbench.set_default.assert_called_once_with("run.pgzero_mode", False)
        mock_workbench.get_variable.return_value.set.assert_called_once_with(False)

# Generated at 2022-06-24 07:51:21.928163
# Unit test for function update_environment
def test_update_environment():
    # TODO: write unit tests
    pass

# Generated at 2022-06-24 07:51:29.678869
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = "auto"
    from thonny.workbench import Workbench
    wb = Workbench()
    
    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "true"
    
    wb.set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "false"
    
    wb.set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:51:34.370545
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, True)
    get_workbench().get_option(_OPTION_NAME)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-24 07:51:39.494509
# Unit test for function toggle_variable
def test_toggle_variable():
    # Test if the value given by the user when test is run is correct
    # Create a mock workbench
    from unittest.mock import Mock
    mock_workbench = Mock()
    options = {"run.pgzero_mode": False}
    mock_workbench.get_variable = Mock(side_effect=lambda k: options[k])
    mock_workbench.get_option = Mock(side_effect=lambda k: options[k])
    mock_workbench.in_simple_mode = Mock(return_value=False)
    toggle_variable()
    assert options["run.pgzero_mode"] == True



# Generated at 2022-06-24 07:51:49.945238
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock
    from thonny.workbench import Workbench
    from thonny.common import ToplevelCommand
    from thonny.tktextext import TextFrame
    from thonny.languages import tr

    mock_workbench = Mock(spec=Workbench)
    workbench = Workbench()
    workbench.get_variable = mock_workbench.get_variable
    workbench.add_command = mock_workbench.add_command
    workbench.set_default = mock_workbench.set_default

    load_plugin(workbench)

    mock_workbench.get_variable.assert_called_once_with("run.pgzero_mode")
    mock_workbench.set_default.assert_called_once_with("run.pgzero_mode", False)
    mock_

# Generated at 2022-06-24 07:51:56.635329
# Unit test for function update_environment
def test_update_environment():
    # create mock if required
    try:
        get_workbench
    except NameError:
        from unittest.mock import MagicMock

        get_workbench = MagicMock()
        get_workbench.get_option = lambda x: True
        get_workbench.in_simple_mode = lambda: False

    # test the function
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"



# Generated at 2022-06-24 07:52:03.212821
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import workbench
    workbench.unregister_default("PGZERO_MODE")
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"


if __name__ == "__main__":
    test_load_plugin()

# Generated at 2022-06-24 07:52:13.056618
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()
    assert "PGZERO_MODE" in os.environ
    assert os.environ["PGZERO_MODE"] == "False"
    assert "toggle_pgzero_mode" in get_workbench().commands
    assert get_workbench().commands["toggle_pgzero_mode"]["label"] == "Pygame Zero mode"
    assert get_workbench().commands["toggle_pgzero_mode"]["flag_name"] == "run.pgzero_mode"

# Generated at 2022-06-24 07:52:17.198894
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-24 07:52:21.211100
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_simple_mode(False)
    assert not get_workbench().get_option(_OPTION_NAME)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME)
    toggle_variable()
    assert not get_workbench().get_option(_OPTION_NAME)

# Generated at 2022-06-24 07:52:22.379624
# Unit test for function update_environment
def test_update_environment():
    print(os.environ["PGZERO_MODE"])


# Generated at 2022-06-24 07:52:22.891962
# Unit test for function toggle_variable
def test_toggle_variable():
    assert False

# Generated at 2022-06-24 07:52:33.208328
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    assert get_workbench().get_variable(_OPTION_NAME).get() is False
    
    assert get_workbench().get_variable(_OPTION_NAME).get() is False
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    # get_workbench().set_default(_OPTION_NAME, True)
    assert get_workbench().get_variable(_OPTION_NAME).get() is False

    assert get_workbench().get_variable(_OPTION_NAME).get() is False
    toggle_variable()
    assert get_workbench().get

# Generated at 2022-06-24 07:52:42.799240
# Unit test for function toggle_variable
def test_toggle_variable():
    workbench = get_workbench()
    
    # Test start with default.
    assert workbench.get_variable(_OPTION_NAME).get() == False
    assert os.environ["PGZERO_MODE"] == "False"
    
    # Test toggle on
    toggle_variable()
    assert workbench.get_variable(_OPTION_NAME).get() == True
    assert os.environ["PGZERO_MODE"] == "True"
    
    # Test toggle off
    toggle_variable()
    assert workbench.get_variable(_OPTION_NAME).get() == False
    assert os.environ["PGZERO_MODE"] == "False"
    
    # Test set to True
    workbench.set_option(_OPTION_NAME, True)
    assert workbench.get_variable(_OPTION_NAME).get

# Generated at 2022-06-24 07:52:49.148999
# Unit test for function update_environment
def test_update_environment():
    from thonny.globals import get_workbench

    # In simple mode, PGZERO_MODE should be "auto"
    get_workbench().in_simple_mode = lambda: True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    # Out of simple mode, PGZERO_MODE should have the same value as run.pgzero_mode
    get_workbench().in_simple_mode = lambda: False
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:52:58.329524
# Unit test for function load_plugin
def test_load_plugin():
    # Tests if configuration variables are set and the command is registered
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)

    assert not wb.get_option(_OPTION_NAME)
    assert _OPTION_NAME in wb.get_defaults_handler().get_configuration_keys()

    if "toggle_pgzero_mode" in wb.get_commands():
        wb.remove_command("toggle_pgzero_mode")

    assert "toggle_pgzero_mode" not in wb.get_commands()
    load_plugin()
    assert "toggle_pgzero_mode" in wb.get_commands()

    toggle_variable()
    assert wb.get_option(_OPTION_NAME)

    assert "PGZERO_MODE" in os.en

# Generated at 2022-06-24 07:53:07.414253
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench

    # save the initial state of the workbench
    mode_save = get_workbench().in_simple_mode()
    option_save = get_workbench().get_option(_OPTION_NAME)
    environment_save = os.environ["PGZERO_MODE"]

    # set states for unit test
    get_workbench().set_simple_mode(True)
    get_workbench().set_option(_OPTION_NAME, True)
    os.environ["PGZERO_MODE"] = "False"

    # update the environment variable
    update_environment()
    # check that the variable is correctly set in simple mode
    assert os.environ["PGZERO_MODE"] == "auto"
    assert get_workbench().get_option(_OPTION_NAME) is True

    #

# Generated at 2022-06-24 07:53:09.340332
# Unit test for function load_plugin
def test_load_plugin():
    assert not get_workbench().get_variable(_OPTION_NAME).get()


if __name__ == "__main__":
    load_plugin()

# Generated at 2022-06-24 07:53:11.028505
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.workbench import Workbench
    
    wb = Workbench()
    wb._set_variable(_OPTION_NAME, True)
    toggle_variable()
    assert not wb.get_variable(_OPTION_NAME).get()
    toggle_variable()
    assert  wb.get_variable(_OPTION_NAME).get()

# Generated at 2022-06-24 07:53:13.620681
# Unit test for function update_environment
def test_update_environment():
    os.environ.pop("PGZERO_MODE", None)

# Generated at 2022-06-24 07:53:23.344618
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench

    from thonny.misc_utils import running_on_mac_os, running_on_windows

    wb = get_workbench()
    wb.reset_to_defaults()

    load_plugin()
    assert wb.get_option("run.pgzero_mode") is False

    wb.set_option("run.pgzero_mode", True)
    assert wb.get_option("run.pgzero_mode") is True

    if running_on_mac_os():
        assert os.environ["PGZERO_MODE"] == "True"
    elif running_on_windows():
        assert os.environ["PGZERO_MODE"] == "True"
    else:
        assert os.environ["PGZERO_MODE"] == "1"

   

# Generated at 2022-06-24 07:53:27.182653
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_option(_OPTION_NAME, True)
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:53:30.902191
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    assert wb.get_option(_OPTION_NAME) == False
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == True
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == False


# Generated at 2022-06-24 07:53:36.180310
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench
    os.environ["PGZERO_MODE"] = "auto"
    simple = get_workbench()
    simple.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    simple.set_simple_mode(False)
    simple.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    simple.set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:53:40.790477
# Unit test for function update_environment
def test_update_environment():
    # Check environment variable is present
    assert os.environ["PGZERO_MODE"]

    # Check environment variable is set to auto for simple mode
    get_workbench().in_simple_mode = lambda: True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    # Check environment variable is set to str of boolean for normal (non simple) mode
    get_workbench().in_simple_mode = lambda: False
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:53:46.525712
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_simple_mode(True)
    assert os.environ["PGZERO_MODE"] == "auto"
    
    get_workbench().set_simple_mode(False)
    get_workbench().get_option(_OPTION_NAME).set(False)
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:53:53.981218
# Unit test for function toggle_variable
def test_toggle_variable():
    for state in [True, False]:
        get_workbench().set_default(_OPTION_NAME, state)
        toggle_variable()
        assert not get_workbench().get_option(_OPTION_NAME)
        toggle_variable()
        assert get_workbench().get_option(_OPTION_NAME)
    get_workbench().set_simple_mode(True)
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_simple_mode(False)
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:54:04.030876
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench

    wb = Workbench()
    load_plugin()

    wb.set_option(_OPTION_NAME, True)
    wb.update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    wb.set_option(_OPTION_NAME, False)
    wb.update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    os.environ.pop("PGZERO_MODE")
    wb.set_simple_mode(True)
    wb.set_option(_OPTION_NAME, False)
    wb.update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    wb.set_option(_OPTION_NAME, True)


# Generated at 2022-06-24 07:54:09.238813
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, True)
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"
    

# Generated at 2022-06-24 07:54:15.145443
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench, options_test
    assert get_workbench().in_simple_mode()
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, True)
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:54:21.455750
# Unit test for function load_plugin
def test_load_plugin():
    
    try:
        del os.environ["PGZERO_MODE"]
    except KeyError:
        pass

    load_plugin()
    
    assert os.environ["PGZERO_MODE"] == "False"
    
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"
    
    get_workbench().in_simple_mode = lambda: True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"


# Generated at 2022-06-24 07:54:31.881790
# Unit test for function update_environment
def test_update_environment():
    from unittest import mock
    wb = mock.Mock()
    wb.get_option = mock.Mock(side_effect=["False", "True"])
    wb.in_simple_mode = mock.Mock(side_effect=[False, True])
    wb.get_variable = mock.Mock()
    wb.get_variable.return_value.set = mock.Mock()
    wb.get_variable.return_value.get = mock.Mock(return_value=False)
    with mock.patch('thonny.plugins.pgzero_mode.get_workbench',
                    return_value=wb):
        update_environment()
        assert os.environ["PGZERO_MODE"] == "False"
        wb.get_variable.return_value.set.assert_called

# Generated at 2022-06-24 07:54:41.519604
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench

    wb = get_workbench()
    assert not wb.get_option("run.pgzero_mode")

    load_plugin()
    assert wb.in_simple_mode()
    assert wb.get_option("run.pgzero_mode")

    # Simulate thonny's initialization
    os.environ.pop("PGZERO_MODE")
    get_workbench().set_default(_OPTION_NAME, False)
    # Simulate toggling option
    toggle_variable()
    # Simulate thonny's initialization
    os.environ.pop("PGZERO_MODE")
    get_workbench().set_default(_OPTION_NAME, True)
    # Simulate toggling option
    toggle_variable()

# Generated at 2022-06-24 07:54:46.443242
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert not os.environ.get("PGZERO_MODE")

    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"



# Generated at 2022-06-24 07:54:55.021459
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.plugins.pgzero import toggle_variable
    from thonny import get_workbench
    from thonny.languages import tr
    from thonny.misc_utils import running_on_mac_os

    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME)
    toggle_variable()
    assert not get_workbench().get_option(_OPTION_NAME)
    
    if running_on_mac_os():
        command = get_workbench().get_command("toggle_pgzero_mode")
        get_workbench().event_generate("<<UpdateMenuBar>>")
        
        assert command.label() == "Run", "Pygame Zero mode"
    else:
        command = get_

# Generated at 2022-06-24 07:54:59.500013
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.plugins.pylib.backend_configuration import get_minimal_backend_configuration
    from thonny import workbench
    workbench._get_backend_configuration = get_minimal_backend_configuration
    load_plugin()

# Generated at 2022-06-24 07:55:04.458904
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    assert not wb.in_simple_mode()

    assert not wb.get_variable(_OPTION_NAME).get()
    toggle_variable()
    assert wb.get_variable(_OPTION_NAME).get()
    toggle_variable()
    assert not wb.get_variable(_OPTION_NAME).get()

# Generated at 2022-06-24 07:55:07.632592
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_option(_OPTION_NAME, True)

    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True


# Generated at 2022-06-24 07:55:15.388802
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench, get_runner

    wb = get_workbench()
    wb.destroy_ui()
    load_plugin()

    opt_menu = wb.get_menu("run").get_submenu("Options")
    pgzero_menu = opt_menu.get_submenu(tr("Pygame Zero mode"))
    assert pgzero_menu.get_command(_OPTION_NAME).var.get() == False
    pgzero_menu.get_command(_OPTION_NAME).execute()
    assert pgzero_menu.get_command(_OPTION_NAME).var.get() == True
    pgzero_menu.get_command(_OPTION_NAME).execute()
    assert pgzero_menu.get_command(_OPTION_NAME).var.get() == False

# Generated at 2022-06-24 07:55:23.678523
# Unit test for function load_plugin
def test_load_plugin():
    workbench = get_workbench()
    orig_value = workbench.get_option("run.pgzero_mode")
    load_plugin()

    assert orig_value == workbench.get_option("run.pgzero_mode")
    assert "PGZERO_MODE" not in os.environ

    # change value and check env var
    workbench.set_option("run.pgzero_mode", True)
    assert "PGZERO_MODE" in os.environ

    workbench.set_option("run.pgzero_mode", False)
    assert "PGZERO_MODE" in os.environ

    os.environ.pop("PGZERO_MODE")

# Generated at 2022-06-24 07:55:30.267344
# Unit test for function toggle_variable
def test_toggle_variable():
    class FakeWorkbench:
        part_names = ["run", "run2"]
        called = 0
        
        def get_variable(self, name):
            class FakeVar:
                def set(self, value):
                    FakeWorkbench.called = value
                    assert value in [True, False]
                def get(self):
                    return FakeWorkbench.called
            return FakeVar()
        
    # Test if variable is changed
    wb = FakeWorkbench()
    toggle_variable(wb)
    assert wb.called == True
    toggle_variable(wb)
    assert wb.called == False
    toggle_variable(wb)
    assert wb.called == True
    toggle_variable(wb) 
    assert wb.called == False

# Generated at 2022-06-24 07:55:30.826972
# Unit test for function toggle_variable
def test_toggle_variable():
    pass

# Generated at 2022-06-24 07:55:38.121875
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, True)
    wb.plugins["Shell"].active_shell = Mock()
    
    load_plugin()
    
    wb.get_variable(_OPTION_NAME)
    assert wb.get_variable(_OPTION_NAME).get() is True
    
    assert "PGZERO_MODE" in os.environ
    assert os.environ["PGZERO_MODE"] == "1"
    
    toggle_variable()
    
    assert wb.get_variable(_OPTION_NAME).get() is False
    assert os.environ["PGZERO_MODE"] == "0"
    
    wb.in_simple_mode = lambda: True
    toggle_variable()

# Generated at 2022-06-24 07:55:45.396843
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_simple_mode(False)
    get_workbench().set_default(_OPTION_NAME, False)
    if _OPTION_NAME in os.environ:
        del os.environ[_OPTION_NAME]

    load_plugin()

    assert get_workbench().get_command("toggle_pgzero_mode").is_checked()
    assert os.environ[_OPTION_NAME] == "False"

    get_workbench().set_default(_OPTION_NAME, True)
    os.environ[_OPTION_NAME] = "True"

    get_workbench().set_simple_mode(False)
    load_plugin()

    assert get_workbench().get_command("toggle_pgzero_mode").is_checked()

# Generated at 2022-06-24 07:55:53.154243
# Unit test for function update_environment
def test_update_environment():
    from pytest import raises
    from thonny.config import Configuration
    from thonny.workbench import Workbench
    from thonny.shell import ShellEditor
    from thonny.plugins.backend_configuration import BackendConfiguration
    from unittest.mock import patch
    
    config = Configuration("", "", "")
    config.set("run.pgzero_mode", False)

    workbench = Workbench(
        config=config,
        frontend_configuration=BackendConfiguration(),
        shell_editor_class=ShellEditor,
    )

    with raises(KeyError):
        os.environ["PGZERO_MODE"]

    with patch("os.environ.__setitem__") as mock_setitem:
        update_environment()

# Generated at 2022-06-24 07:56:02.317888
# Unit test for function update_environment
def test_update_environment():
    from thonny.globals import get_workbench
    from thonny.test.test_config_dialog import create_mock_gui

    gui = create_mock_gui(get_workbench())
    gui.in_simple_mode = True
    gui.get_option = lambda name: False
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    gui.in_simple_mode = False
    gui.get_option = lambda name: True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"

    gui.in_simple_mode = None
    gui.get_option = lambda name: False
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"

# Generated at 2022-06-24 07:56:07.237787
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )

    # Update environment for Pygame Zero mode
    get_workbench().set_default(_OPTION_NAME, True) # Pygame Zero mode is enabled
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    # Disable Pygame Zero mode
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    # Enable Pygame Zero mode
    get

# Generated at 2022-06-24 07:56:10.330031
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)

# Generated at 2022-06-24 07:56:12.449046
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_option("run.pgzero_mode", True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:56:19.303951
# Unit test for function update_environment
def test_update_environment():
    from thonny.misc_utils import running_on_windows  # noqa

    get_workbench().set_in_simple_mode(False)
    old_value = get_workbench().config_parser.get(
        "run", _OPTION_NAME, fallback=None
    )

    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_in_simple_mode(True)
    update_environment()

# Generated at 2022-06-24 07:56:26.699825
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import Mock
    from thonny.workbench import Workbench
    get_workbench().in_simple_mode = Mock()
    get_workbench().in_simple_mode.return_value = False
    get_workbench().get_option = Mock()
    get_workbench().get_option.return_value = True
    os.environ["PGZERO_MODE"] = "0"
    update_environment()
    get_workbench().get_option.assert_called_with(_OPTION_NAME)
    assert os.environ["PGZERO_MODE"] == "True"


# Generated at 2022-06-24 07:56:27.350536
# Unit test for function toggle_variable
def test_toggle_variable():
    
    # toggle_variable()
    pass


# Generated at 2022-06-24 07:56:27.867905
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()

# Generated at 2022-06-24 07:56:31.114552
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()

    # False (default)
    assert bool(wb.get_option(_OPTION_NAME)) is False
    toggle_variable()
    assert bool(wb.get_option(_OPTION_NAME)) is True
    toggle_variable()
    assert bool(wb.get_option(_OPTION_NAME)) is False



# Generated at 2022-06-24 07:56:36.603120
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert get_workbench().get_default("run.pgzero_mode", False) == False
    assert get_workbench().get_option("run.pgzero_mode", False) == False
    toggle_variable()
    assert get_workbench().get_option("run.pgzero_mode", False) == True

# Generated at 2022-06-24 07:56:40.852123
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    assert get_workbench().get_variable(_OPTION_NAME)
    get_workbench().set_default(_OPTION_NAME, True)
    load_plugin()
    assert get_workbench().get_variable(_OPTION_NAME)

# Generated at 2022-06-24 07:56:46.393667
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_option(_OPTION_NAME, False, "user")
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_option(_OPTION_NAME, True, "user")
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"


# Generated at 2022-06-24 07:56:53.245788
# Unit test for function toggle_variable
def test_toggle_variable():
    import unittest.mock
    load_plugin()
    get_workbench().get_plugin("environment")._add_variable(
        _OPTION_NAME, "bool", get_workbench().get_option(_OPTION_NAME)
    )
    with unittest.mock.patch.dict(os.environ, clear=True):
        get_workbench().in_simple_mode = lambda: False
        toggle_variable()
        assert os.environ["PGZERO_MODE"] == "True"
        toggle_variable()
        assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:56:59.204252
# Unit test for function update_environment
def test_update_environment():
    # Reset environment else other tests may have set it
    os.environ["PGZERO_MODE"] = "auto"

    # Test setting PGZERO_MODE in the environment when running with --simple-mode
    get_workbench()._simple_mode = True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    # Test setting PGZERO_MODE in the environment when simple mode is True
    get_workbench()._simple_mode = False
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    # Test setting PGZERO_MODE in the environment when simple mode is False
    get_workbench()._simple_mode = False
    get_workbench().set_default

# Generated at 2022-06-24 07:57:06.009821
# Unit test for function update_environment
def test_update_environment():
    import os
    import unittest

    class TestUpdateEnvironment(unittest.TestCase):
        def test_simple_mode(self):
            os.environ["PGZERO_MODE"] = "auto"
            get_workbench().set_option(_OPTION_NAME, True)
            update_environment()
            self.assertEqual(os.environ["PGZERO_MODE"], "True")

        def test_normal_mode(self):
            os.environ["PGZERO_MODE"] = "auto"
            get_workbench().set_option(_OPTION_NAME, False)
            update_environment()
            self.assertEqual(os.environ["PGZERO_MODE"], "False")


if __name__ == "__main__":
    test_update_environment()

# Generated at 2022-06-24 07:57:13.697391
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_in_simple_mode(True)
    update_environment()
    assert os.getenv("PGZERO_MODE") == "auto"
    get_workbench().set_in_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.getenv("PGZERO_MODE") == "True"
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.getenv("PGZERO_MODE") == "False"

# Generated at 2022-06-24 07:57:17.977889
# Unit test for function update_environment
def test_update_environment():
    get_workbench().in_simple_mode = lambda: True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:57:22.632390
# Unit test for function update_environment
def test_update_environment():
    assert os.environ.get("PGZERO_MODE") is None
    from thonny import get_workbench
    from thonny.misc_utils import running_on_windows
    
    # When not in simple mode
    get_workbench().in_simple_mode = get_workbench().in_normal_mode 

    # On Windows platform
    if running_on_windows():
        os.environ.pop("PGZERO_MODE", None)
        get_workbench().set_default(_OPTION_NAME, True)
        update_environment()
        assert os.environ.get("PGZERO_MODE") == "True"
        get_workbench().set_default(_OPTION_NAME, False)
        update_environment()
        assert os.environ.get("PGZERO_MODE") == "False"


# Generated at 2022-06-24 07:57:27.798303
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from unittest.mock import Mock
    my_backend = Mock()
    my_workbench = Workbench(my_backend)
    my_workbench.set_default(_OPTION_NAME, True)
    my_backend.get_option = Mock(return_value=True)
    update_environment()
    assert "PGZERO_MODE" in os.environ
    assert os.environ["PGZERO_MODE"] == "True"
    my_workbench.set_default(_OPTION_NAME, False)
    update_environment()
    assert "PGZERO_MODE" in os.environ
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:57:29.986212
# Unit test for function load_plugin
def test_load_plugin():
    wb = DummyWorkbench()
    load_plugin()
    assert wb.get_command("toggle_pgzero_mode")



# Generated at 2022-06-24 07:57:38.238713
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_simple_mode(False)
    load_plugin()
    assert "PGZERO_MODE" not in os.environ
    get_workbench().get_variable(_OPTION_NAME).set(True)
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().get_variable(_OPTION_NAME).set(False)
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_simple_mode(True)
    load_plugin()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:57:41.234491
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    assert get_workbench().get_default(_OPTION_NAME) == False


# Generated at 2022-06-24 07:57:52.431955
# Unit test for function update_environment
def test_update_environment():
    from thonny.misc_utils import running_on_mac_os

    if running_on_mac_os():
        # Bug #227. If this test is run manually, it succeeds,
        # but if run via tox, it fails.
        # So we'll just skip the test on Mac for now.
        return
    workbench = get_workbench()

    # pygame module is not necessarily available
    # So we temporarily replace sys.modules to simulate the case where it is not available
    # (in the first use case below) or available (in the second use case)
    import sys
    sys.modules["pygame"] = None


# Generated at 2022-06-24 07:58:03.225543
# Unit test for function update_environment
def test_update_environment():
    import os
    from test.config_helper import load_test_config
    from thonny import get_workbench
    from thonny.workbench import Workbench

    # Clean up OS env for the test
    try:
        del os.environ["PGZERO_MODE"]
    except KeyError:
        pass

    load_test_config()
    get_workbench().set_default(_OPTION_NAME, True)
    get_workbench().set_simple_mode(False)
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_simple_mode(True)
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_simple_mode(False)

# Generated at 2022-06-24 07:58:03.729432
# Unit test for function toggle_variable
def test_toggle_variable():
    pass

# Generated at 2022-06-24 07:58:08.998895
# Unit test for function toggle_variable
def test_toggle_variable():
    var = get_workbench().get_variable(_OPTION_NAME)
    var.set(False)
    assert var.get() == False
    toggle_variable()
    assert var.get() == True
    toggle_variable()
    assert var.get() == False
    assert "PGZERO_MODE" in os.environ
    os.environ.pop("PGZERO_MODE")

# Generated at 2022-06-24 07:58:14.948266
# Unit test for function load_plugin
def test_load_plugin():
    try:
        del os.environ["PGZERO_MODE"]
        get_workbench().set_simple_mode(True)
        load_plugin()
        assert os.environ["PGZERO_MODE"] == "auto"
        get_workbench().set_simple_mode(False)
        load_plugin()
        assert os.environ["PGZERO_MODE"] == "False"

        get_workbench().set_option(_OPTION_NAME, True)
        load_plugin()
        assert os.environ["PGZERO_MODE"] == "True"

    finally:
        if _OPTION_NAME in get_workbench().get_variable_names():
            get_workbench().remove_variable(_OPTION_NAME)
        if "PGZERO_MODE" in os.environ:
            del os.en

# Generated at 2022-06-24 07:58:24.044745
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import workbench
    from thonny.config import get_default_config_dir
    from thonny.config_ui import ConfigurationPage
    import thonny.plugins.pgzero_mode

    thonny.plugins.pgzero_mode.load_plugin()
    wb = workbench.get_workbench()

    # Check configration page
    config_page = ConfigurationPage(wb)
    config_page.load()

    # Check plugin command
    wb.event_generate("<<OpenView>>", {"view_class": "SimpleEditorView"})
    view = wb.get_view_by_name("SimpleEditorView")
    assert view.text is not None
    assert wb.get_menu("run", "toggle_pgzero_mode")

    # Check config file

# Generated at 2022-06-24 07:58:29.067825
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"

    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"
    
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:58:38.125382
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import workbench, TEST_SUBPROCESS_ARGS

    prev_val = os.environ.get("PGZERO_MODE")
    prev_toolbar_image = workbench.get_default(
        "view.toolbar_16x16", {}
    ).get("toggle_pgzero_mode")


# Generated at 2022-06-24 07:58:45.070209
# Unit test for function update_environment
def test_update_environment():
    assert os.environ["PGZERO_MODE"] == "False"
    wb = get_workbench()
    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    wb.set_option(_OPTION_NAME, False)
    wb.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:58:49.067554
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_option(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME)

    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-24 07:58:49.649900
# Unit test for function toggle_variable
def test_toggle_variable():
    assert False

# Generated at 2022-06-24 07:58:57.747405
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.plugins.run import toggle_variable
    from thonny.workbench import Workbench
    workbench = Workbench()
    workbench.set_default(_OPTION_NAME, False)
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 07:58:58.989282
# Unit test for function toggle_variable
def test_toggle_variable():
    print('toggle_variable()')
    toggle_variable()



# Generated at 2022-06-24 07:59:03.464224
# Unit test for function load_plugin
def test_load_plugin():
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:59:09.104942
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    wb.set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-24 07:59:16.716529
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.enable_simple_mode()
    

# Generated at 2022-06-24 07:59:23.945316
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import Mock
    wb = Mock()
    wb.get_option = Mock(return_value = True)
    wb.in_simple_mode = Mock(return_value = False)
    with patch("thonny.plugins.pgzero_mode.get_workbench", new=Mock(return_value=wb)):
        update_environment()
        assert os.environ["PGZERO_MODE"] == "True"
        wb.get_option.return_value = False
        update_environment()
        assert os.environ["PGZERO_MODE"] == "False"
        wb.in_simple_mode.return_value = True
        update_environment()
        assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:59:29.158732
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()

    value = wb.get_option(_OPTION_NAME)
    assert value == False

    toggle_variable()

    value = wb.get_option(_OPTION_NAME)
    assert value == True

    toggle_variable()

    value = wb.get_option(_OPTION_NAME)
    assert value == False

# Generated at 2022-06-24 07:59:31.269404
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-24 07:59:32.898388
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workb

# Generated at 2022-06-24 07:59:40.631416
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    
    load_plugin()
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == True
    assert "PGZERO_MODE" in os.environ
    assert os.environ["PGZERO_MODE"] == "True"
    
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    assert "PGZERO_MODE" in os.environ
    assert os.environ["PGZERO_MODE"] == "False"
    
    get_workbench().in_simple_mode = lambda: True
    update_environment()
    assert os.environ

# Generated at 2022-06-24 07:59:45.089405
# Unit test for function load_plugin
def test_load_plugin():
    # Can't test directly because set_default() is called everytime.
    get_workbench().testing = True
    load_plugin()
    assert get_workbench().in_simple_mode() == False
    get_workbench().testing = False
    load_plugin()

# Generated at 2022-06-24 07:59:55.913839
# Unit test for function toggle_variable
def test_toggle_variable():
    class MockOption(object):
        def __init__(self, init_value):
            self.value = init_value
            self.init_value = init_value

        def set(self, new_value):
            self.value = new_value

        def get(self):
            return self.value

    class MockWorkbench(object):
        def __init__(self):
            self.variable_values = {}

        def get_variable(self, variable_name):
            if variable_name not in self.variable_values:
                self.variable_values[variable_name] = MockOption(
                    False
                )
            return self.variable_values[variable_name]

    workbench = MockWorkbench()
    toggle_variable(workbench)
    assert workbench.get_variable(_OPTION_NAME).get()

   

# Generated at 2022-06-24 08:00:03.009511
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench, RunningBackend
    from thonny.languages import tr
    from thonny.plugins.run.run_configuration import RunConfigurationDialog

    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    btn = get_workbench().get_menu("run").find_command("toggle_pgzero_mode")
    btn.invoke()
    assert get_workbench().get_option(_OPTION_NAME) == True
    btn.invoke()

# Generated at 2022-06-24 08:00:08.075540
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()



# Generated at 2022-06-24 08:00:13.043482
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == True
    assert os.environ["PGZERO_MODE"] == "True"
    
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 08:00:23.279523
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.globals import get_workbench
    from unittest.mock import patch
    from thonny.testutils import create_runner_for_test
    global runner
    runner = create_runner_for_test()

    if get_workbench().get_option(_OPTION_NAME) == True:
        get_workbench().set_option(_OPTION_NAME, False)

    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

    with patch("os.environ") as mock_os_env:
        os.environ["PGZERO_MODE"] = "auto"
    update_environment()


# Generated at 2022-06-24 08:00:25.991776
# Unit test for function update_environment
def test_update_environment():
    os.environ.pop("PGZERO_MODE", None)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-24 08:00:35.709780
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().in_simple_mode = lambda : False
    load_plugin()
    assert get_workbench().get_default(_OPTION_NAME) == False
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert repr(get_workbench().get_variable(_OPTION_NAME)) == ("<BooleanVar name='run.pgzero_mode' value='0'>"
                                                               if int(sys.version[0]) < 3 else
                                                               "<BooleanVar name='run.pgzero_mode' value='False'>")
    assert repr(get_workbench().get_command("toggle_pgzero_mode")) == ("<Command toggle_pgzero_mode(label='Pygame Zero mode', cmd=<function toggle_variable at 0x"), get_workbench().get_bindings()


# Generated at 2022-06-24 08:00:36.168795
# Unit test for function load_plugin
def test_load_plugin():
    pass

# Generated at 2022-06-24 08:00:47.491868
# Unit test for function toggle_variable
def test_toggle_variable():
    # This test is for v.0.4.6
    # It tests that the toggle_variable() function turns off
    # the pgzero_mode run option when it is on and
    # turns on the pgzero_mode run option when it is off
    # It uses Alt-R to access the run menu,
    # but this may change in later versions
    wb = get_workbench()
    
    # assert that the run option is turned off
    result = get_workbench().get_option(_OPTION_NAME)
    assert result == False
    
    # activate the toggle_variable function - run option is on
    toggle_variable()
    result = get_workbench().get_option(_OPTION_NAME)
    assert result == True
    
    # activate the toggle_variable function - run option is off
    toggle_variable()
   