

# Generated at 2022-06-18 09:33:06.925419
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_default = Mock()
    wb.add_command = Mock()
    load_plugin()
    wb.set_default.assert_called_once_with(_OPTION_NAME, False)
    wb.add_command.assert_called_once()
    assert wb.add_command.call_args[0][0] == "toggle_pgzero_mode"
    assert wb.add_command.call_args[1]["flag_name"] == _OPTION_NAME

# Generated at 2022-06-18 09:33:12.885727
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.globals import get_workbench
    from thonny.languages import tr
    from thonny.misc_utils import running_on_mac_os
    from thonny.ui_utils import CommonDialog
    from thonny.ui_utils import askstring
    from thonny.ui_utils import askopenfilename
    from thonny.ui_utils import askopenfilenames
    from thonny.ui_utils import asksaveasfilename
    from thonny.ui_utils import showinfo
    from thonny.ui_utils import showerror
    from thonny.ui_utils import showwarning

# Generated at 2022-06-18 09:33:17.595091
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run import RunView
    from thonny.languages import tr
    from thonny.misc_utils import running_on_mac_os
    from thonny.globals import get_workbench
    from thonny.globals import get_runner
    from thonny.globals import get_shell
    from thonny.globals import get_runner
    from thonny.globals import get_shell
    from thonny.globals import get_workbench
    from thonny.globals import get_workbench
    from thonny.globals import get_workbench
    from thonny.globals import get_workbench
   

# Generated at 2022-06-18 09:33:27.595238
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.globals import get_workbench
    import os

    # Create a dummy workbench
    workbench = Workbench()
    workbench.set_default(_OPTION_NAME, False)
    workbench.set_simple_mode(False)

    # Create a dummy configuration page
    config_page = ConfigurationPage(workbench)
    config_page.create_widgets()
    config_page.load_configuration()

    # Check that the environment variable is set to False
    assert os.environ["PGZERO_MODE"] == "False"

    # Change the option to True
    workbench.set_option(_OPTION_NAME, True)



# Generated at 2022-06-18 09:33:32.228340
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-18 09:33:41.133928
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench

    wb = Workbench()
    load_plugin()
    assert wb.get_variable(_OPTION_NAME) is not None
    assert wb.get_command("toggle_pgzero_mode") is not None
    assert wb.get_option(_OPTION_NAME) is False
    assert os.environ["PGZERO_MODE"] == "False"

    wb.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    wb.set_simple_mode(False)
    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-18 09:33:52.074062
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.globals import get_workbench
    from thonny.languages import tr
    from thonny.plugins.run import toggle_variable
    from thonny.plugins.run import update_environment
    from thonny.plugins.run import _OPTION_NAME
    from thonny.workbench import Workbench
    from thonny.workbench import WorkbenchEvent
    from unittest.mock import Mock
    from unittest.mock import patch
    from unittest.mock import PropertyMock

    # Mock the Workbench class
    workbench = Mock(spec=Workbench)
    type(workbench).in_simple_mode = PropertyMock(return_value=False)
    type(workbench).get_option = Mock(return_value=False)
    type(workbench).get

# Generated at 2022-06-18 09:33:56.756061
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-18 09:34:06.672860
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()
    assert wb.get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == False

# Generated at 2022-06-18 09:34:15.760118
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.misc_utils import running_on_mac_os
    from thonny.globals import get_workbench
    from thonny.languages import tr
    from thonny import THONNY_USER_DIR
    from thonny.running import SubprocessConnection
    from thonny.plugins.backend_debugger import DebuggerProxy
    from thonny.plugins.backend_debugger import DebuggerView
    from thonny.plugins.backend_debugger import DebuggerUICommandHandler
    from thonny.plugins.backend_debugger import DebuggerUICommandHandler

# Generated at 2022-06-18 09:34:29.375705
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench
    from thonny.misc_utils import running_on_mac_os
    from thonny.languages import tr
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run import RunConfigurationPage
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunCommand
    from thonny.plugins.run import RunBackend
    from thonny.plugins.run import RunEventHandler
    from thonny.plugins.run import RunProgramDialog
    from thonny.plugins.run import RunProgramEventHandler
    from thonny.plugins.run import RunSelectionEventHandler

# Generated at 2022-06-18 09:34:38.959219
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = "auto"
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_default(_OPTION_NAME, True)
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-18 09:34:50.417063
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run import RunConfigurationPage
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunCommand
    from thonny.plugins.run import RunBackendEventHandler
    from thonny.plugins.run import RunScriptEventHandler
    from thonny.plugins.run import RunFileEventHandler
    from thonny.plugins.run import RunModuleEventHandler
    from thonny.plugins.run import RunSelectionEventHandler
    from thonny.plugins.run import RunCurrentStatementEventHandler
    from thonny.plugins.run import RunCurrentCellEventHandler
    from thonny.plugins.run import Run

# Generated at 2022-06-18 09:35:00.942205
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.misc_utils import running_on_mac_os
    from thonny.globals import get_workbench
    from thonny.languages import tr
    from thonny.ui_utils import CommonDialog
    from thonny.ui_utils import askstring
    from thonny.ui_utils import askopenfilename
    from thonny.ui_utils import askdirectory
    from thonny.ui_utils import askinteger
    from thonny.ui_utils import askfloat
    from thonny.ui_utils import askcolor
    from thonny.ui_utils import askopenfilenames

# Generated at 2022-06-18 09:35:04.428629
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    assert get_workbench().get_option(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-18 09:35:14.605512
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.workbench import Workbench
    from thonny.config import Configuration
    from thonny.misc_utils import running_on_mac_os
    from thonny.globals import get_workbench
    from thonny.languages import tr
    from thonny.plugins.run.run_command import RunCommand
    from thonny.plugins.run.pgzero_mode import toggle_variable
    from thonny.plugins.run.pgzero_mode import update_environment
    from thonny.plugins.run.pgzero_mode import load_plugin
    from thonny.plugins.run.pgzero_mode import _OPTION_NAME
    from thonny.plugins.run.pgzero_mode import test_toggle_variable
    from thonny.plugins.run.pgzero_mode import get_

# Generated at 2022-06-18 09:35:25.247227
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.misc_utils import running_on_mac_os, running_on_windows
    from thonny.globals import get_workbench
    from thonny.languages import tr
    from thonny.plugins.run.run_commands import run_current_script
    from thonny.plugins.run.run_subprocess import run_backend_command
    from thonny.plugins.run.run_subprocess import run_backend_script
    from thonny.plugins.run.run_subprocess import run_backend_module
    from thonny.plugins.run.run_subprocess import run_backend_module_as_script

# Generated at 2022-06-18 09:35:35.443506
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.misc_utils import running_on_mac_os, running_on_windows
    from unittest.mock import patch
    from thonny.config import get_config_dir

    with patch("thonny.workbench.Workbench.in_simple_mode", return_value=True):
        wb = Workbench()
        wb.set_option(_OPTION_NAME, True)
        update_environment()
        assert os.environ["PGZERO_MODE"] == "auto"

    with patch("thonny.workbench.Workbench.in_simple_mode", return_value=False):
        wb = Workbench()
        wb.set_option(_OPTION_NAME, True)
        update_environment()
        assert os.environ

# Generated at 2022-06-18 09:35:46.767715
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench

    wb = Workbench()
    load_plugin()
    assert wb.get_variable(_OPTION_NAME) == False
    assert wb.get_option(_OPTION_NAME) == False
    assert wb.get_command("toggle_pgzero_mode")
    assert os.environ["PGZERO_MODE"] == "False"

    wb.set_option(_OPTION_NAME, True)
    assert wb.get_variable(_OPTION_NAME) == True
    assert wb.get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"

    wb.set_simple_mode(True)
    assert wb.get_variable(_OPTION_NAME) == True
    assert wb.get

# Generated at 2022-06-18 09:35:53.858403
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-18 09:36:10.040494
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.config_ui import ConfigurationPage
    from thonny.misc_utils import running_on_mac_os
    from thonny.globals import get_workbench
    from thonny.plugins.run.run_config_page import RunConfigurationPage
    from thonny.plugins.run.run_command import RunConfigurationPage
    from thonny.plugins.run.run_command import RunCommand

    wb = Workbench()
    wb.create()
    load_plugin()
    assert wb.get_variable(_OPTION_NAME) == False
    assert wb.get_option(_OPTION_NAME) == False
    assert wb.get_variable(_OPTION_NAME) == False
    assert wb.get_option(_OPTION_NAME)

# Generated at 2022-06-18 09:36:21.738143
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench
    from thonny.languages import tr
    from thonny.misc_utils import running_on_mac_os
    from thonny.plugins.run.run_commands import _get_run_command
    from thonny.plugins.run.run_subprocess import _get_run_subprocess_command
    from thonny.plugins.run.run_subprocess import _get_run_subprocess_command_with_pythonw
    from thonny.plugins.run.run_subprocess import _get_run_subprocess_command_with_pythonw_and_pgzero_mode
    from thonny.plugins.run.run_subprocess import _get_run_subprocess_command_with_pgzero_mode

# Generated at 2022-06-18 09:36:25.727854
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_default = Mock()
    wb.add_command = Mock()
    load_plugin()
    wb.set_default.assert_called_once_with(_OPTION_NAME, False)
    wb.add_command.assert_called_once()

# Generated at 2022-06-18 09:36:36.935636
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_default = Mock()
    wb.add_command = Mock()
    load_plugin()
    wb.set_default.assert_called_once_with(_OPTION_NAME, False)
    wb.add_command.assert_called_once()
    assert wb.add_command.call_args[0][0] == "toggle_pgzero_mode"
    assert wb.add_command.call_args[0][1] == "run"
    assert wb.add_command.call_args[0][2] == "Pygame Zero mode"
    assert wb.add_command.call_args[0][3] == toggle_variable

# Generated at 2022-06-18 09:36:44.423574
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.misc_utils import running_on_mac_os
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.backend_options import BackendOptionsConfigurationPage
    from thonny.languages import EnglishLanguage
    from thonny.shell import ShellTextWidget
    from thonny.ui_utils import CommonDialog
    from thonny.ui_utils import create_toolbar_button
    from thonny.ui_utils import create_toolbutton
    from thonny.ui_utils import create_menu_item
    from thonny.ui_utils import create_menu
    from thonny.ui_utils import create_toolbar

# Generated at 2022-06-18 09:36:54.536754
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.misc_utils import running_on_mac_os, running_on_windows
    from thonny.globals import get_workbench
    import os
    import shutil
    import tempfile
    import unittest

    class TestConfigurationPage(ConfigurationPage):
        def __init__(self, master):
            ConfigurationPage.__init__(self, master, "Test")

    class TestWorkbench(Workbench):
        def create_configuration_page(self, master):
            return TestConfigurationPage(master)

    class Test(unittest.TestCase):
        def setUp(self):
            self.orig_workbench = get_work

# Generated at 2022-06-18 09:36:58.561790
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-18 09:37:01.976432
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-18 09:37:06.133407
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-18 09:37:11.495144
# Unit test for function toggle_variable
def test_toggle_variable():
    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == True
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == False

# Generated at 2022-06-18 09:37:34.162247
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config import Configuration
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run import RunConfigurationPage
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunCommand
    from thonny.plugins.run import RunBackend
    from thonny.plugins.run import RunEventHandler
    from thonny.plugins.run import RunDebugger
    from thonny.plugins.run import RunDebuggerEventHandler
    from thonny.plugins.run import RunDebuggerCommand
    from thonny.plugins.run import RunDebuggerView
    from thonny.plugins.run import RunDebuggerBackend
    from thonny.plugins.run import RunDebuggerConfigurationPage

# Generated at 2022-06-18 09:37:43.524781
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config import Configuration
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run import RunConfigurationPage
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunCommand
    from thonny.plugins.run import RunBackend
    from thonny.plugins.run import RunEventHandler
    from thonny.plugins.run import RunEventHandler
    from thonny.plugins.run import RunEventHandler
    from thonny.plugins.run import RunEventHandler
    from thonny.plugins.run import RunEventHandler
    from thonny.plugins.run import RunEventHandler
    from thonny.plugins.run import RunEventHandler
    from thonny.plugins.run import RunEvent

# Generated at 2022-06-18 09:37:53.849094
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_default = Mock()
    wb.add_command = Mock()
    load_plugin()
    wb.set_default.assert_called_once_with(_OPTION_NAME, False)
    wb.add_command.assert_called_once()
    assert wb.add_command.call_args[0][0] == "toggle_pgzero_mode"
    assert wb.add_command.call_args[0][1] == "run"
    assert wb.add_command.call_args[0][2] == tr("Pygame Zero mode")
    assert wb.add_command.call_args[0][3] == toggle_variable
    assert wb

# Generated at 2022-06-18 09:37:59.041710
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    assert get_workbench().get_option(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-18 09:38:07.079600
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-18 09:38:17.678093
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.globals import get_workbench
    from thonny.languages import tr
    from thonny.misc_utils import running_on_mac_os
    from thonny.plugins.run import RunConfigurationPage
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunViewUpdater
    from thonny.plugins.run import RunViewUpdater
    from thonny.plugins.run import RunViewUpdater
    from thonny.plugins.run import RunViewUpdater
    from thonny.plugins.run import RunViewUpdater

# Generated at 2022-06-18 09:38:26.688418
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.misc_utils import running_on_mac_os
    from thonny.ui_utils import askyesno
    import os
    import shutil
    import tempfile
    import tkinter as tk

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create the configuration directory
    os.makedirs(os.path.join(temp_dir, "thonny"))

    # Create the configuration file
    config_file = os.path.join(temp_dir, "thonny", "config-v2.json")
    with open(config_file, "w") as fp:
        fp

# Generated at 2022-06-18 09:38:34.825666
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.misc_utils import running_on_mac_os
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunBackend
    from thonny.plugins.run import RunCommand
    from thonny.plugins.run import RunProgramCommand
    from thonny.plugins.run import RunSelectionCommand
    from thonny.plugins.run import RunCurrentScriptCommand
    from thonny.plugins.run import RunModuleCommand
    from thonny.plugins.run import RunFileCommand
    from thonny.plugins.run import RunDebuggerCommand
    from thonny.plugins.run import RunDebuggerCommand


# Generated at 2022-06-18 09:38:44.819565
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.misc_utils import running_on_mac_os
    from thonny.misc_utils import running_on_windows
    from thonny.misc_utils import running_on_linux

    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()

    if running_on_mac_os():
        assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-18 09:38:49.722695
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    assert wb.get_option(_OPTION_NAME) == False
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == True
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == False

# Generated at 2022-06-18 09:39:21.840797
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.globals import get_workbench
    from thonny.misc_utils import running_on_mac_os
    from thonny.plugins.run import RunConfigurationPage
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunViewUpdater
    from thonny.plugins.run import RunViewUpdaterThread
    from thonny.plugins.run import RunViewUpdaterThread
    from thonny.plugins.run import RunViewUpdaterThread
    from thonny.plugins.run import RunViewUpdaterThread
    from thonny.plugins.run import RunViewUpdaterThread

# Generated at 2022-06-18 09:39:28.728227
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench

    wb = Workbench()
    load_plugin()
    assert wb.get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"
    wb.set_option(_OPTION_NAME, True)
    assert wb.get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"
    wb.set_simple_mode(True)
    assert wb.get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "auto"
    wb.set_simple_mode(False)
    assert wb.get_option(_OPTION_NAME) == True

# Generated at 2022-06-18 09:39:35.663760
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run import RunConfigurationPage
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunCommand
    from thonny.plugins.run import RunBackend
    from thonny.plugins.run import RunEventHandler
    from thonny.plugins.run import RunDebugger
    from thonny.plugins.run import RunProgramDialog
    from thonny.plugins.run import RunScriptDialog
    from thonny.plugins.run import RunModuleDialog
    from thonny.plugins.run import RunSelectionDialog
    from thonny.plugins.run import RunCurrentScriptDialog

# Generated at 2022-06-18 09:39:44.243375
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.misc_utils import running_on_mac_os
    from thonny.globals import get_workbench
    from thonny.languages import tr
    from thonny.ui_utils import CommonDialog
    from thonny.ui_utils import askstring
    from thonny.ui_utils import askopenfilename
    from thonny.ui_utils import askdirectory
    from thonny.ui_utils import showwarning
    from thonny.ui_utils import showerror
    from thonny.ui_utils import showinfo
    from thonny.ui_utils import askyesno

# Generated at 2022-06-18 09:39:50.344248
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.workbench import Workbench
    from thonny.config import Configuration
    from thonny.misc_utils import running_on_mac_os

    wb = Workbench(Configuration({"run.pgzero_mode": False}))
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == True

    wb = Workbench(Configuration({"run.pgzero_mode": True}))
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == False

# Generated at 2022-06-18 09:39:58.833209
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench
    from thonny.misc_utils import running_on_mac_os, running_on_windows
    from thonny.languages import tr
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    import os
    import shutil
    import sys
    import tempfile
    import unittest

    class Test(unittest.TestCase):
        def setUp(self):
            self.orig_get_workbench = get_workbench
            self.orig_get_config_dir = get_config_dir
            self.orig_running_on_mac_os = running_on_mac_os
            self.orig_running_on_windows = running_on_windows
            self.orig_os_environ = os.en

# Generated at 2022-06-18 09:40:08.538468
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import Mock
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.set_simple_mode(False)
    wb.set_option(_OPTION_NAME, True)
    wb.set_simple_mode(True)
    wb.set_option(_OPTION_NAME, False)
    wb.set_simple_mode(False)
    wb.set_option(_OPTION_NAME, True)
    wb.set_simple_mode(True)
    wb.set_option(_OPTION_NAME, False)
    wb.set_simple_mode(False)
    wb.set_option(_OPTION_NAME, True)
    wb.set_simple

# Generated at 2022-06-18 09:40:18.829193
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.globals import get_workbench
    from thonny.languages import tr
    from thonny.workbench import Workbench
    from unittest.mock import Mock
    from thonny.plugins.run.run_commands import RunCommand
    from thonny.plugins.run.run_subprocess import RunSubprocess

    workbench = Workbench()
    workbench.set_default(_OPTION_NAME, False)
    workbench.add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )

# Generated at 2022-06-18 09:40:23.042247
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-18 09:40:32.167227
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench
    from thonny.misc_utils import running_on_mac_os
    from thonny.languages import tr
    from thonny.workbench import Workbench
    from thonny.ui_utils import CommonDialog
    from tkinter import Tk
    from unittest.mock import patch

    root = Tk()
    root.withdraw()
    wb = Workbench(root)
    wb.set_default(_OPTION_NAME, False)
    wb.add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()

    # Test that the command is added

# Generated at 2022-06-18 09:41:33.914740
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.globals import get_workbench
    from thonny.misc_utils import running_on_mac_os
    from thonny.plugins.run import RunConfigurationPage
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunViewUpdater
    from thonny.plugins.run import RunViewUpdater
    from thonny.plugins.run import RunViewUpdater
    from thonny.plugins.run import RunViewUpdater
    from thonny.plugins.run import RunViewUpdater
    from thonny.plugins.run import RunViewUpdater

# Generated at 2022-06-18 09:41:44.855620
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.misc_utils import running_on_mac_os
    import os
    import shutil
    import tempfile
    import unittest

    class Test(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.config_dir = os.path.join(self.temp_dir, "thonny")
            os.makedirs(self.config_dir)
            self.old_config_dir = get_config_dir()
            os.environ["THONNY_USER_DIR"] = self.config_dir
            self.old_pgzero_mode = os.environ.get("PGZERO_MODE")


# Generated at 2022-06-18 09:41:54.976874
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run import RunConfigurationPage
    from thonny.languages import EnglishLanguage
    from thonny.misc_utils import running_on_mac_os, running_on_windows
    from thonny.globals import get_workbench
    from thonny.ui_utils import CommonDialog
    from thonny.ui_utils import askstring
    from thonny.ui_utils import askopenfilename
    from thonny.ui_utils import askdirectory
    from thonny.ui_utils import askinteger
    from thonny.ui_utils import askfloat
    from thonny.ui_utils import askcolor

# Generated at 2022-06-18 09:42:03.203537
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run import RunConfigurationPage

    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    assert wb.get_option(_OPTION_NAME) == False
    load_plugin()
    assert wb.get_option(_OPTION_NAME) == False
    assert wb.get_variable(_OPTION_NAME).get() == False
    assert os.environ["PGZERO_MODE"] == "False"
    wb.set_option(_OPTION_NAME, True)
    assert wb.get_option(_OPTION_NAME) == True
    assert wb.get_variable(_OPTION_NAME).get() == True

# Generated at 2022-06-18 09:42:06.750649
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench

    wb = Workbench()
    load_plugin()
    assert wb.get_option(_OPTION_NAME) == False
    assert wb.get_variable(_OPTION_NAME) == False
    assert wb.get_command("toggle_pgzero_mode") != None
    assert os.environ["PGZERO_MODE"] == "False"


# Generated at 2022-06-18 09:42:13.471800
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench

    wb = Workbench()
    load_plugin()
    assert wb.get_option(_OPTION_NAME) == False
    assert wb.get_variable(_OPTION_NAME).get() == False
    assert wb.get_command("toggle_pgzero_mode")
    assert wb.get_command("toggle_pgzero_mode").flag_name == _OPTION_NAME
    assert wb.get_command("toggle_pgzero_mode").group == 40
    assert os.environ["PGZERO_MODE"] == "False"

    wb.set_option(_OPTION_NAME, True)
    assert wb.get_option(_OPTION_NAME) == True
    assert wb.get_variable(_OPTION_NAME).get() == True

# Generated at 2022-06-18 09:42:21.874153
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.globals import get_workbench
    from thonny.languages import tr
    from thonny.misc_utils import running_on_mac_os
    from thonny.ui_utils import CommonDialog
    from thonny.workbench import Workbench
    from tkinter import Tk

    root = Tk()
    root.withdraw()
    wb = Workbench(root)
    wb.set_default(_OPTION_NAME, False)
    wb.add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    wb.set_option(_OPTION_NAME, False)
    toggle_variable()

# Generated at 2022-06-18 09:42:30.908396
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import Mock
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.set_option(_OPTION_NAME, True)
    wb.in_simple_mode = Mock(return_value=False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    wb.in_simple_mode = Mock(return_value=True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-18 09:42:37.602421
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench
    from thonny.workbench import Workbench
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run.run_config_page import RunConfigurationPage
    from thonny.languages import tr
    from thonny.misc_utils import running_on_mac_os

    wb = Workbench()
    wb.create()
    wb.set_default(_OPTION_NAME, False)
    wb.add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()


# Generated at 2022-06-18 09:42:45.454042
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config import Configuration
    from thonny.config_ui import ConfigurationPage
    from thonny.misc_utils import running_on_mac_os
    from thonny.plugins.backend_configuration import BackendConfigurationPage
    from thonny.plugins.backend_configuration import BackendConfigurationDialog
    from thonny.plugins.backend_configuration import BackendConfigurationCommand
    from thonny.plugins.backend_configuration import BackendConfigurationDialog
    from thonny.plugins.backend_configuration import BackendConfigurationDialog
    from thonny.plugins.backend_configuration import BackendConfigurationDialog
    from thonny.plugins.backend_configuration import BackendConfigurationDialog