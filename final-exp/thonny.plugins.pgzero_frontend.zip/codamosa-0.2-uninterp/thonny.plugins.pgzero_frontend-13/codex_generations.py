

# Generated at 2022-06-18 09:32:33.563390
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench
    from thonny.plugins.pgzero_mode import load_plugin
    from thonny.plugins.pgzero_mode import toggle_variable
    from thonny.plugins.pgzero_mode import update_environment
    from thonny.plugins.pgzero_mode import _OPTION_NAME
    from thonny.languages import tr
    from thonny.misc_utils import running_on_mac_os
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.globals import get_workbench
    from thonny.globals import get_runner
    from thonny.globals import get_shell

# Generated at 2022-06-18 09:32:37.704796
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-18 09:32:44.982008
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.misc_utils import running_on_mac_os
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.globals import get_workbench
    from thonny.languages import tr
    from thonny.plugins.pgzero_mode import _OPTION_NAME
    from thonny.plugins.pgzero_mode import update_environment
    from thonny.plugins.pgzero_mode import toggle_variable
    from thonny.plugins.pgzero_mode import load_plugin
    from thonny.workbench import Workbench
    from thonny.misc_utils import running_on_mac_os
    from thonny.config import get_config_dir

# Generated at 2022-06-18 09:32:52.995813
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench
    from thonny.misc_utils import running_on_mac_os
    from thonny.languages import tr
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from tkinter import Tk
    from thonny.ui_utils import CommonDialog
    import os
    import shutil
    import tempfile
    import unittest

    class Test(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.orig_config_dir = get_config_dir()
            os.environ["THONNY_USER_DIR"] = self.temp_dir

# Generated at 2022-06-18 09:33:01.099714
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.misc_utils import running_on_mac_os

    wb = Workbench()
    wb.create()
    wb.set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    wb.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"


# Generated at 2022-06-18 09:33:03.532581
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-18 09:33:11.059718
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.misc_utils import running_on_mac_os, running_on_windows

    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    wb.set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    wb.set_option(_OPTION_NAME, True)
    wb.set_simple_mode(True)
    update_

# Generated at 2022-06-18 09:33:19.014020
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    assert wb.get_option(_OPTION_NAME) == False
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == True
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == False

# Generated at 2022-06-18 09:33:23.021896
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-18 09:33:29.823886
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-18 09:33:42.195353
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config_ui import ConfigurationPage
    from unittest.mock import Mock
    from thonny.misc_utils import running_on_mac_os
    from thonny.languages import EnglishLanguage
    from thonny.ui_utils import CommonDialog
    from thonny.ui_utils import askstring
    from thonny.ui_utils import askinteger
    from thonny.ui_utils import askfloat
    from thonny.ui_utils import askopenfilename
    from thonny.ui_utils import asksaveasfilename
    from thonny.ui_utils import askdirectory
    from thonny.ui_utils import showerror
    from thonny.ui_utils import showinfo
    from thonny.ui_utils import showwarning


# Generated at 2022-06-18 09:33:50.717947
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from unittest.mock import Mock
    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    wb.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    wb.set_simple_mode(False)
    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-18 09:34:01.122753
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny import get_runner
    from thonny.misc_utils import running_on_mac_os
    from thonny.languages import tr
    import os
    import shutil
    import tempfile
    import unittest
    from unittest.mock import patch

    class Test(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.config_dir = os.path.join(self.temp_dir, "config")
            os.mkdir(self.config_dir)
            self.orig_config_dir = get_config_dir()
            get_config_dir = lambda: self.config_dir
           

# Generated at 2022-06-18 09:34:06.328656
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    assert wb.get_option(_OPTION_NAME) == False
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == True
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == False

# Generated at 2022-06-18 09:34:15.593414
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.config_ui import ConfigurationPage
    from thonny.misc_utils import running_on_mac_os
    from tkinter import Tk
    from unittest.mock import Mock
    import sys
    import os

    root = Tk()
    root.withdraw()
    wb = Workbench(root)
    wb.set_default(_OPTION_NAME, False)
    wb.add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()

    # Check if the command is added to the Run menu

# Generated at 2022-06-18 09:34:20.784469
# Unit test for function update_environment
def test_update_environment():
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-18 09:34:31.388796
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run import RunConfigurationPage
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunBackend
    from thonny.plugins.run import RunCommand
    from thonny.plugins.run import RunEventHandler
    from thonny.plugins.run import RunViewUpdater
    from thonny.plugins.run import RunViewUpdater
    from thonny.plugins.run import RunViewUpdater
    from thonny.plugins.run import RunViewUpdater
    from thonny.plugins.run import RunViewUpdater
    from thonny.plugins.run import RunView

# Generated at 2022-06-18 09:34:36.024324
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-18 09:34:47.173710
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.misc_utils import running_on_mac_os, running_on_windows
    from thonny.globals import get_workbench
    from thonny.languages import tr
    from thonny.plugins.pgzero_mode import toggle_variable, update_environment
    from thonny.plugins.pgzero_mode import _OPTION_NAME
    import os
    import shutil
    import sys
    import tempfile

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()
    # Create the config dir
    user_conf_dir = get_config_dir()
    os.makedirs(user_conf_dir, exist_ok=True)
    # Create the

# Generated at 2022-06-18 09:34:58.648101
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.misc_utils import running_on_mac_os, running_on_windows
    from thonny.globals import get_workbench
    from thonny.config import get_runner
    from thonny.plugins.backend_pgzero import PgZeroBackend
    from thonny.plugins.backend_tkinter import TkinterBackend
    from thonny.plugins.backend_tkinter_filedialog import TkinterFileDialogBackend
    from thonny.plugins.backend_tkinter_simpledialog import TkinterSimpleDialogBackend
    from thonny.plugins.backend_tkinter_messagebox import TkinterMessageBoxBackend
    from thonny.plugins.backend_tkinter_text import T

# Generated at 2022-06-18 09:35:08.094986
# Unit test for function toggle_variable
def test_toggle_variable():
    # Test 1
    get_workbench().set_option(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    # Test 2
    get_workbench().set_option(_OPTION_NAME, True)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-18 09:35:19.201273
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench
    from thonny.plugins.pgzero_mode import load_plugin
    from thonny.plugins.pgzero_mode import _OPTION_NAME
    from thonny.languages import tr
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.misc_utils import running_on_mac_os
    from thonny.tktextext import TextFrame
    from thonny.ui_utils import CommonDialog
    from thonny.ui_utils import SubprocessDialog
    from thonny.ui_utils import askopenfilename
    from thonny.ui_utils import askdirectory
    from thonny.ui_utils import askopenfilenames
   

# Generated at 2022-06-18 09:35:29.371710
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import Mock
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run import RunConfigurationPage
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunCommand
    from thonny.plugins.run import RunBackend
    from thonny.plugins.run import RunEventHandler
    from thonny.plugins.run import RunCommand
    from thonny.plugins.run import RunBackend
    from thonny.plugins.run import RunEventHandler
    from thonny.plugins.run import RunCommand
    from thonny.plugins.run import RunBackend
    from thonny.plugins.run import RunEventHandler

# Generated at 2022-06-18 09:35:40.215881
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench

    wb = Workbench()
    load_plugin()
    assert wb.get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"
    wb.set_option(_OPTION_NAME, True)
    assert wb.get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"
    wb.set_simple_mode(True)
    assert wb.get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "auto"
    wb.set_simple_mode(False)
    assert wb.get_option(_OPTION_NAME) == True

# Generated at 2022-06-18 09:35:51.080828
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.misc_utils import running_on_mac_os, running_on_windows
    from thonny.globals import get_workbench
    from thonny.languages import tr
    from thonny.plugins.run import RunViewText
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunViewText
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunViewText
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunViewText
    from thonny.plugins.run import RunView

# Generated at 2022-06-18 09:36:01.881169
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import Mock
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run import RunConfigurationPage
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunCommand
    from thonny.plugins.run import RunBackend
    from thonny.plugins.run import RunEventHandler
    from thonny.plugins.run import RunDebugger
    from thonny.plugins.run import RunDebuggerEventHandler
    from thonny.plugins.run import RunDebuggerView
    from thonny.plugins.run import RunDebuggerBackend
    from thonny.plugins.run import RunDebuggerCommand

# Generated at 2022-06-18 09:36:05.927082
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-18 09:36:13.686459
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == True
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-18 09:36:24.902782
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.globals import get_workbench
    from thonny.plugins.run import RunConfigurationPage
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunCommand
    from thonny.plugins.run import RunBackend
    from thonny.plugins.run import RunEventHandler
    from thonny.plugins.run import RunInterpreter
    from thonny.plugins.run import RunInterpreterProxy
    from thonny.plugins.run import RunManager
    from thonny.plugins.run import RunProgramThread
    from thonny.plugins.run import RunProgramDialog

# Generated at 2022-06-18 09:36:29.656674
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-18 09:36:50.648684
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench
    from thonny.misc_utils import running_on_mac_os
    import os

    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-18 09:37:00.858204
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.misc_utils import running_on_mac_os
    from thonny.globals import get_workbench
    from thonny.languages import tr
    from thonny.ui_utils import CommonDialog
    from thonny.tktextext import TextFrame
    from thonny.plugins.backend_configuration import BackendConfigurationPage
    from thonny.plugins.backend_configuration import get_backend_configuration_page
    from thonny.plugins.backend_configuration import get_interpreter_for_subprocess
    from thonny.plugins.backend_configuration import get_interpreter_for_

# Generated at 2022-06-18 09:37:12.930109
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench
    from thonny.workbench import Workbench
    from thonny.config import Configuration
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run import RunView
    from thonny.languages import tr
    import tkinter as tk
    from tkinter import ttk
    from unittest.mock import Mock
    from unittest.mock import patch
    from unittest.mock import MagicMock
    from unittest.mock import PropertyMock
    from unittest.mock import call
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunCommand
    from thonny.plugins.run import RunBackend
    from thonny.plugins.run import RunConfiguration

# Generated at 2022-06-18 09:37:22.386347
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.globals import get_workbench
    from thonny.misc_utils import running_on_windows
    from thonny.tktextext import TextFrame
    from thonny.ui_utils import CommonDialog
    from thonny.workbench import SimpleWorkbench
    from tkinter import TclError
    from tkinter import Tk
    from tkinter.ttk import Button
    from tkinter.ttk import Checkbutton
    from tkinter.ttk import Combobox
    from tkinter.ttk import Entry
    from tkinter.ttk import Frame
    from tkinter.ttk import Label

# Generated at 2022-06-18 09:37:33.747747
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    import os
    import shutil
    import sys
    import tkinter as tk
    from tkinter import ttk
    import traceback
    import unittest
    from unittest.mock import patch

    class TestWorkbench(Workbench):
        def __init__(self):
            super().__init__()
            self.set_default(_OPTION_NAME, False)
            self.add_command(
                "toggle_pgzero_mode",
                "run",
                tr("Pygame Zero mode"),
                toggle_variable,
                flag_name=_OPTION_NAME,
                group=40,
            )


# Generated at 2022-06-18 09:37:39.617653
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench

    wb = Workbench()
    load_plugin()
    assert wb.get_variable(_OPTION_NAME) == False
    assert wb.get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"

    wb.set_option(_OPTION_NAME, True)
    assert wb.get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"

    wb.set_simple_mode(True)
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-18 09:37:50.440448
# Unit test for function update_environment
def test_update_environment():
    from unittest import mock
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.set_option(_OPTION_NAME, True)
    with mock.patch.dict(os.environ, clear=True):
        update_environment()
        assert os.environ["PGZERO_MODE"] == "True"

    wb.set_option(_OPTION_NAME, False)
    with mock.patch.dict(os.environ, clear=True):
        update_environment()
        assert os.environ["PGZERO_MODE"] == "False"

    wb.set_option(_OPTION_NAME, True)
    wb.set_simple_mode(True)

# Generated at 2022-06-18 09:38:01.423933
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.globals import get_runner
    from thonny.misc_utils import running_on_mac_os, running_on_windows
    import os
    import shutil
    import sys
    import tempfile
    import unittest

    class Test(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.config_dir = os.path.join(self.temp_dir, "thonny")
            os.mkdir(self.config_dir)
            get_config_dir.cache_clear()
            get_config_dir.cache_info()
           

# Generated at 2022-06-18 09:38:05.640489
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-18 09:38:10.270257
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-18 09:38:36.062349
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench

    wb = Workbench()
    load_plugin()
    assert wb.get_variable(_OPTION_NAME) == False
    assert wb.get_option(_OPTION_NAME) == False
    assert wb.get_command("toggle_pgzero_mode")
    assert os.environ["PGZERO_MODE"] == "False"
    wb.destroy()

# Generated at 2022-06-18 09:38:40.579547
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-18 09:38:50.409383
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.globals import get_workbench
    from thonny.misc_utils import running_on_mac_os
    from thonny.tktextext import TextFrame
    from thonny.ui_utils import CommonDialog
    from tkinter import TclError
    from tkinter.ttk import Button, Checkbutton, Entry, Frame, Label, LabelFrame
    from tkinter.ttk import Radiobutton, Scrollbar, Separator, Treeview
    from tkinter.ttk import Style
    from tkinter.ttk import Treeview
    from thonny.ui_utils import askopenfilename, askopenfilenames, asks

# Generated at 2022-06-18 09:39:00.945567
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run import RunConfigurationPage
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunCommand
    from thonny.plugins.run import RunBackendEventHandler
    from thonny.plugins.run import RunProgramEventHandler
    from thonny.plugins.run import RunProgramCommand
    from thonny.plugins.run import RunFileCommand
    from thonny.plugins.run import RunModuleCommand
    from thonny.plugins.run import RunSelectionCommand
    from thonny.plugins.run import RunCurrentViewCommand
    from thonny.plugins.run import RunCurrentScriptCommand
    from thonny.plugins.run import RunDebuggerCommand
   

# Generated at 2022-06-18 09:39:10.183966
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from unittest.mock import Mock
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.globals import get_workbench
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunCommand
    from thonny.plugins.run import RunBackendEventHandler
    from thonny.plugins.run import RunBackendProxy
    from thonny.plugins.run import RunBackend
    from thonny.plugins.run import RunBackendThread
    from thonny.plugins.run import RunBackendDialog
    from thonny.plugins.run import RunBackendDialogHandler
    from thonny.plugins.run import RunBackendDialogProxy
   

# Generated at 2022-06-18 09:39:13.752926
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-18 09:39:22.620854
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from unittest.mock import Mock
    from thonny.plugins.run.run_command import RunCommand
    from thonny.plugins.run.run_subprocess import RunSubprocess
    from thonny.plugins.run.run_thread import RunThread
    from thonny.plugins.run.run_debugger import RunDebugger
    from thonny.plugins.run.run_backend import RunBackend
    from thonny.plugins.run.run_pgzero_mode import toggle_variable
    from thonny.plugins.run.run_pgzero_mode import update_environment
    from thonny.plugins.run.run_pgzero_mode import load_plugin
    from thonny.plugins.run.run_pgzero_mode import _OPTION_NAME

# Generated at 2022-06-18 09:39:29.240655
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()
    assert wb.get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == False

# Generated at 2022-06-18 09:39:34.523068
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import Mock
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.set_option(_OPTION_NAME, True)
    wb.in_simple_mode = Mock(return_value=False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    wb.in_simple_mode = Mock(return_value=True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-18 09:39:42.220437
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.misc_utils import running_on_mac_os
    from thonny.globals import get_workbench
    from thonny.languages import tr
    from thonny.plugins.pgzero_mode import update_environment
    from thonny.plugins.pgzero_mode import toggle_variable
    from thonny.plugins.pgzero_mode import _OPTION_NAME

    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)

# Generated at 2022-06-18 09:40:43.724482
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench

    wb = Workbench()
    load_plugin()
    assert wb.get_variable(_OPTION_NAME).get() is False
    assert wb.get_option(_OPTION_NAME) is False
    assert "PGZERO_MODE" not in os.environ

    wb.set_option(_OPTION_NAME, True)
    assert wb.get_variable(_OPTION_NAME).get() is True
    assert wb.get_option(_OPTION_NAME) is True
    assert os.environ["PGZERO_MODE"] == "True"

    wb.set_option(_OPTION_NAME, False)
    assert wb.get_variable(_OPTION_NAME).get() is False
    assert wb.get_option(_OPTION_NAME) is False

# Generated at 2022-06-18 09:40:51.791067
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().in_simple_mode = lambda: True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-18 09:41:02.155225
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()
    assert wb.get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == False

# Generated at 2022-06-18 09:41:04.417436
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-18 09:41:08.285692
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    assert get_workbench().get_option(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-18 09:41:14.847917
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run import RunConfigurationPage
    from thonny.languages import tr
    from thonny.misc_utils import running_on_mac_os
    from thonny.globals import get_workbench
    from thonny.globals import get_runner
    from thonny.globals import get_shell
    from thonny.globals import get_runner
    from thonny.globals import get_shell
    from thonny.globals import get_workbench
    from thonny.globals import get_workbench
    from thonny.globals import get_workbench
    from thonny.globals import get_workbench


# Generated at 2022-06-18 09:41:21.717584
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.misc_utils import running_on_mac_os
    from thonny.plugins.run import RunConfigurationPage
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunCommand
    from thonny.plugins.run import RunBackend
    from thonny.plugins.run import RunEventHandler
    from thonny.plugins.run import RunSubprocessDialog
    from thonny.plugins.run import RunSubprocessDialogHandler
    from thonny.plugins.run import RunSubprocessDialogHandler
    from thonny.plugins.run import RunSubprocessDialogHandler
    from thonny.plugins.run import Run

# Generated at 2022-06-18 09:41:28.493158
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-18 09:41:39.239200
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.misc_utils import running_on_mac_os
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run.run_config_page import RunConfigurationPage
    from thonny.languages import EnglishLanguage
    from thonny.globals import get_runner
    from thonny.plugins.run.run_command import RunCommand
    from thonny.plugins.run.run_subprocess import RunSubprocess
    from thonny.plugins.run.run_file import RunFile
    from thonny.plugins.run.run_module import RunModule
    from thonny.plugins.run.run_selection import RunSelection

# Generated at 2022-06-18 09:41:44.742919
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"