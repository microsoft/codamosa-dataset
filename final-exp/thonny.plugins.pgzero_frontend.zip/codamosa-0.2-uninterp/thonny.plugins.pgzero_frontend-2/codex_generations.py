

# Generated at 2022-06-18 09:33:22.041373
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_default(_OPTION_NAME, True)
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-18 09:33:26.230266
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-18 09:33:37.583824
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.misc_utils import running_on_mac_os, running_on_windows
    from thonny.languages import english
    from thonny.languages import finnish
    from thonny.languages import russian
    from thonny.languages import french
    from thonny.languages import german
    from thonny.languages import spanish
    from thonny.languages import portuguese
    from thonny.languages import dutch
    from thonny.languages import chinese
    from thonny.languages import japanese
    from thonny.languages import korean
    from thonny.languages import italian

# Generated at 2022-06-18 09:33:44.562217
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.globals import get_workbench
    from thonny.misc_utils import running_on_mac_os
    from thonny.languages import tr
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.backend_configuration import BackendConfigurationPage
    from thonny.plugins.backend_configuration import BackendConfigurationDialog
    from thonny.plugins.backend_configuration import BackendConfigurationDialog
    from thonny.plugins.backend_configuration import BackendConfigurationDialog
    from thonny.plugins.backend_configuration import BackendConfigurationDialog
    from thonny.plugins.backend_configuration import BackendConfigurationDialog

# Generated at 2022-06-18 09:33:55.418488
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from unittest.mock import patch

    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)

    with patch.dict(os.environ, clear=True):
        update_environment()
        assert os.environ["PGZERO_MODE"] == "False"

    wb.set_default(_OPTION_NAME, True)
    with patch.dict(os.environ, clear=True):
        update_environment()
        assert os.environ["PGZERO_MODE"] == "True"

    wb.set_default(_OPTION_NAME, False)
    wb.set_simple_mode(True)
    with patch.dict(os.environ, clear=True):
        update_environment()
        assert os.en

# Generated at 2022-06-18 09:34:04.159799
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import Mock
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.set_simple_mode(False)
    wb.set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    wb.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-18 09:34:14.011621
# Unit test for function update_environment
def test_update_environment():
    from thonny.globals import get_workbench
    from thonny.misc_utils import running_on_mac_os
    from thonny.config import get_runner
    from thonny.plugins.backend_options import BackendOptionsDialog
    from thonny.plugins.run import RunConfiguration
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunSubprocess
    from thonny.plugins.run import RunCommand
    from thonny.plugins.run import RunBackendEventHandler
    from thonny.plugins.run import RunBackendProxy
    from thonny.plugins.run import RunBackend
    from thonny.plugins.run import RunBackendProxy
    from thonny.plugins.run import RunBackendEventHandler

# Generated at 2022-06-18 09:34:23.890774
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from unittest.mock import Mock
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run import RunConfigurationPage
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunCommand
    from thonny.plugins.run import RunBackendEventHandler
    from thonny.plugins.run import RunEventHandler
    from thonny.plugins.run import RunMenuUpdater
    from thonny.plugins.run import RunCommand
    from thonny.plugins.run import RunBackendEventHandler
    from thonny.plugins.run import RunEventHandler
    from thonny.plugins.run import RunMenuUpdater

# Generated at 2022-06-18 09:34:35.082393
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.workbench import Workbench
    from unittest.mock import Mock
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.globals import get_workbench
    from thonny.plugins.run import RunConfigurationPage
    from thonny.ui_utils import CommonDialog
    from tkinter import Tk

    root = Tk()
    root.withdraw()
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    get_work

# Generated at 2022-06-18 09:34:44.797108
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()
    assert wb.get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-18 09:34:59.168322
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench

    wb = Workbench()
    load_plugin()
    assert wb.get_variable(_OPTION_NAME).get() == False
    assert wb.get_option(_OPTION_NAME) == False
    assert wb.get_command("toggle_pgzero_mode")
    assert wb.get_command("toggle_pgzero_mode").flag_name == _OPTION_NAME
    assert wb.get_command("toggle_pgzero_mode").group == 40
    assert os.environ["PGZERO_MODE"] == "False"

    wb.set_simple_mode(True)
    assert os.environ["PGZERO_MODE"] == "auto"

    wb.set_simple_mode(False)

# Generated at 2022-06-18 09:35:02.460780
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run.run_config_page import RunConfigurationPage
    from thonny.plugins.run.run_command import RunCommand
    from thonny.plugins.run.run_debugger import RunDebugger
    from thonny.plugins.run.run_subprocess import RunSubprocess
    from thonny.plugins.run.run_file import RunFile
    from thonny.plugins.run.run_module import RunModule
    from thonny.plugins.run.run_selection import RunSelection
    from thonny.plugins.run.run_current_script import RunCurrentScript
    from thonny.plugins.run.run_current_module import RunCurrentModule

# Generated at 2022-06-18 09:35:09.961626
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.misc_utils import running_on_mac_os
    from unittest.mock import patch

    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    wb.set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    wb.set_option(_OPTION_NAME, True)
    wb.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

   

# Generated at 2022-06-18 09:35:14.152008
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-18 09:35:24.802977
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny import get_runner
    from thonny.misc_utils import running_on_mac_os, running_on_windows
    from thonny.languages import get_language
    import os
    import shutil
    import tempfile
    import unittest

    class Test(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.config_dir = os.path.join(self.temp_dir, "thonny")
            os.mkdir(self.config_dir)
            get_config_dir.cache_clear()
            get_config_dir.cache_info()
            get_config_dir.cache_

# Generated at 2022-06-18 09:35:34.993974
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.misc_utils import running_on_mac_os
    from thonny.globals import get_workbench
    from thonny.languages import tr
    from thonny.ui_utils import CommonDialog
    from thonny.ui_utils import askstring
    from thonny.ui_utils import askopenfilename
    from thonny.ui_utils import askdirectory
    from thonny.ui_utils import askinteger
    from thonny.ui_utils import askfloat
    from thonny.ui_utils import askcolor
    from thonny.ui_utils import askopenfilenames

# Generated at 2022-06-18 09:35:44.779705
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()
    assert wb.get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-18 09:35:56.015503
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench

    wb = Workbench()
    load_plugin()
    assert wb.get_variable(_OPTION_NAME) == False
    assert wb.get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"

    wb.set_option(_OPTION_NAME, True)
    assert wb.get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"

    wb.set_simple_mode(True)
    assert os.environ["PGZERO_MODE"] == "auto"
    wb.set_simple_mode(False)
    assert os.environ["PGZERO_MODE"] == "True"


# Generated at 2022-06-18 09:36:00.752469
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-18 09:36:10.685954
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.workbench import Workbench
    from thonny.config_ui import ConfigurationPage
    from tkinter import Tk
    from thonny.globals import get_runner
    from thonny.plugins.run import RunViewText
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunViewText
    from thonny.plugins.run import RunViewText
    from thonny.plugins.run import RunViewText
    from thonny.plugins.run import RunViewText
    from thonny.plugins.run import RunViewText
    from thonny.plugins.run import RunViewText
    from thonny.plugins.run import RunViewText
    from thonny.plugins.run import RunViewText
    from thonny.plugins.run import RunView

# Generated at 2022-06-18 09:36:26.325420
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_default = Mock()
    wb.add_command = Mock()
    load_plugin()
    wb.set_default.assert_called_once_with(_OPTION_NAME, False)
    wb.add_command.assert_called_once()
    assert wb.add_command.call_args[0][0] == "toggle_pgzero_mode"
    assert wb.add_command.call_args[0][1] == "run"
    assert wb.add_command.call_args[0][2] == tr("Pygame Zero mode")
    assert wb.add_command.call_args[0][3] == toggle_variable
    assert wb

# Generated at 2022-06-18 09:36:32.371129
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-18 09:36:41.569344
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from unittest.mock import Mock
    wb = Workbench()
    wb.get_option = Mock(return_value=True)
    wb.in_simple_mode = Mock(return_value=False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    wb.in_simple_mode = Mock(return_value=True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    wb.in_simple_mode = Mock(return_value=False)
    wb.get_option = Mock(return_value=False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-18 09:36:52.303026
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run import RunConfigurationPage
    from thonny.languages import tr
    from thonny.misc_utils import running_on_mac_os
    from thonny.globals import get_workbench
    from thonny.globals import get_runner
    from thonny.globals import get_shell
    from thonny.globals import get_workbench
    from thonny.globals import get_runner
    from thonny.globals import get_shell
    from thonny.globals import get_workbench
    from thonny.globals import get_runner
    from thonny.globals import get_shell

# Generated at 2022-06-18 09:37:01.893302
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench

    wb = Workbench()
    load_plugin()
    assert wb.get_option(_OPTION_NAME) == False
    assert wb.get_variable(_OPTION_NAME).get() == False
    assert wb.get_command("toggle_pgzero_mode")
    assert wb.get_command("toggle_pgzero_mode").flag_name == _OPTION_NAME
    assert wb.get_command("toggle_pgzero_mode").group == 40
    assert os.environ["PGZERO_MODE"] == "False"

    wb.set_option(_OPTION_NAME, True)
    assert wb.get_option(_OPTION_NAME) == True
    assert wb.get_variable(_OPTION_NAME).get() == True

# Generated at 2022-06-18 09:37:14.016582
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from unittest.mock import Mock
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.globals import get_workbench
    from thonny.misc_utils import running_on_mac_os, running_on_windows
    from thonny.plugins.pgzero_mode import _OPTION_NAME

    # Create a mock workbench
    wb = Mock(spec=Workbench)
    wb.get_option = Mock(return_value=True)
    wb.in_simple_mode = Mock(return_value=False)
    wb.get_variable = Mock(return_value=True)

# Generated at 2022-06-18 09:37:21.788334
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    wb.set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    wb.set_default(_OPTION_NAME, False)
    wb.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-18 09:37:33.375304
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from unittest.mock import Mock
    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.set_simple_mode(False)
    wb.set_option(_OPTION_NAME, True)
    wb.set_simple_mode(True)
    wb.set_option(_OPTION_NAME, False)
    wb.set_simple_mode(False)
    wb.set_option(_OPTION_NAME, False)
    wb.set_simple_mode(True)
    wb.set_option(_OPTION_NAME, True)
    wb.set_simple_mode(False)
    wb.set_option(_OPTION_NAME, True)
    wb.set_simple

# Generated at 2022-06-18 09:37:40.283201
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.misc_utils import running_on_mac_os
    from thonny.languages import english_locale
    from thonny.languages import french_locale
    from thonny.languages import german_locale
    from thonny.languages import russian_locale
    from thonny.languages import spanish_locale
    from thonny.languages import swedish_locale
    from thonny.languages import ukrainian_locale
    from thonny.languages import chinese_locale
    from thonny.languages import danish_locale
    from thonny.languages import finnish_locale

# Generated at 2022-06-18 09:37:45.426404
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == True
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == False

# Generated at 2022-06-18 09:38:04.612584
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    wb.set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    wb.set_default(_OPTION_NAME, False)
    wb.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-18 09:38:15.293798
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench
    from thonny.workbench import Workbench
    from thonny.misc_utils import running_on_mac_os
    from thonny.config import get_config_dir
    import os
    import shutil
    import sys
    import tempfile
    import unittest

    class Test(unittest.TestCase):
        def setUp(self):
            self.orig_config_dir = get_config_dir()
            self.temp_dir = tempfile.mkdtemp()
            os.environ["THONNY_USER_DIR"] = self.temp_dir
            get_workbench().set_default(_OPTION_NAME, False)

# Generated at 2022-06-18 09:38:20.359700
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-18 09:38:27.994806
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.globals import get_workbench
    from thonny.plugins.run import RunConfigurationPage
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunCommand
    from thonny.plugins.run import RunBackend
    from thonny.plugins.run import RunProgramDialog
    from thonny.plugins.run import RunProgramCommand
    from thonny.plugins.run import RunSelectionCommand
    from thonny.plugins.run import RunCurrentScriptCommand
    from thonny.plugins.run import RunModuleCommand
    from thonny.plugins.run import RunFileCommand

# Generated at 2022-06-18 09:38:36.029028
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench
    from thonny.languages import tr
    from thonny.misc_utils import running_on_mac_os
    from thonny.workbench import Workbench
    from thonny.workbench import WorkbenchEvent
    from thonny.workbench import WorkbenchEventHandler
    from thonny.workbench import WorkbenchEventHandler
    from thonny.workbench import WorkbenchEventHandler
    from thonny.workbench import WorkbenchEventHandler
    from thonny.workbench import WorkbenchEventHandler
    from thonny.workbench import WorkbenchEventHandler
    from thonny.workbench import WorkbenchEventHandler
    from thonny.workbench import WorkbenchEventHandler
    from thonny.workbench import WorkbenchEventHandler

# Generated at 2022-06-18 09:38:46.438430
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.globals import get_workbench
    from thonny.misc_utils import running_on_mac_os
    from thonny.ui_utils import CommonDialog
    from thonny.ui_utils import askstring
    from thonny.ui_utils import askopenfilename
    from thonny.ui_utils import askdirectory
    from thonny.ui_utils import showwarning
    from thonny.ui_utils import showerror
    from thonny.ui_utils import showinfo
    from thonny.ui_utils import askyesno
    from thonny.ui_utils import askquestion

# Generated at 2022-06-18 09:38:54.506876
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    assert wb.get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"
    wb.in_simple_mode = lambda: True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-18 09:39:05.258052
# Unit test for function update_environment
def test_update_environment():
    import os
    from thonny import get_workbench
    from thonny.languages import tr
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_default(_OPTION_NAME, True)
    get_workbench().in_simple_mode = lambda: True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_default(_OPTION_NAME, False)

# Generated at 2022-06-18 09:39:13.904309
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.globals import get_workbench
    from thonny.languages import tr
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.workbench import Workbench
    from thonny.plugins.run import RunView
    from thonny.ui_utils import CommonDialog
    from thonny.ui_utils import askstring
    from thonny.ui_utils import askinteger
    from thonny.ui_utils import askfloat
    from thonny.ui_utils import askopenfilename
    from thonny.ui_utils import asksaveasfilename
    from thonny.ui_utils import askdirectory
    from thonny.ui_utils import showerror
    from thonny.ui_utils import showinfo
   

# Generated at 2022-06-18 09:39:22.768398
# Unit test for function update_environment
def test_update_environment():
    from thonny.globals import get_workbench
    from thonny.misc_utils import running_on_mac_os, running_on_windows
    from thonny.languages import tr
    from thonny.workbench import Workbench
    from unittest.mock import patch

    workbench = Workbench()
    workbench.set_default(_OPTION_NAME, False)
    workbench.in_simple_mode = lambda: False
    workbench.get_option = lambda x: False

    with patch("os.environ", {}):
        update_environment()
        assert os.environ["PGZERO_MODE"] == "False"

    workbench.get_option = lambda x: True
    with patch("os.environ", {}):
        update_environment()

# Generated at 2022-06-18 09:39:55.933404
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-18 09:40:02.807017
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench
    from thonny.plugins.pgzero_mode import load_plugin
    from thonny.plugins.pgzero_mode import toggle_variable
    from thonny.plugins.pgzero_mode import update_environment
    from thonny.languages import tr
    from thonny.misc_utils import running_on_mac_os
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.globals import get_workbench
    from thonny.globals import get_runner
    from thonny.globals import get_shell
    from thonny.globals import get_workbench
    from thonny.globals import get

# Generated at 2022-06-18 09:40:12.088986
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import Mock
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run import RunConfigurationPage

    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.in_simple_mode = Mock(return_value=False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    wb.in_simple_mode = Mock(return_value=True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    wb.set_default(_OPTION_NAME, True)
    wb.in_simple_mode

# Generated at 2022-06-18 09:40:18.954596
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-18 09:40:28.660928
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.config_ui import ConfigurationPage
    from thonny.misc_utils import running_on_mac_os
    from thonny.globals import get_workbench
    from thonny.languages import tr
    from thonny.plugins.run.run_commands import RunCommand
    from thonny.plugins.run.run_subprocess import RunSubprocess
    from thonny.plugins.run.run_pgzero_mode import toggle_variable
    from thonny.plugins.run.run_pgzero_mode import update_environment
    from thonny.plugins.run.run_pgzero_mode import load_plugin
    from thonny.plugins.run.run_pgzero_mode import _OPTION_NAME

# Generated at 2022-06-18 09:40:36.559373
# Unit test for function update_environment
def test_update_environment():
    from thonny.plugins.run import _OPTION_NAME
    from thonny.workbench import Workbench
    from unittest.mock import Mock

    wb = Workbench()
    wb.set_default(_OPTION_NAME, True)
    wb.in_simple_mode = Mock(return_value=False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    wb.in_simple_mode = Mock(return_value=True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-18 09:40:43.652308
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench
    from thonny.plugins.pgzero_mode import load_plugin
    from thonny.plugins.pgzero_mode import _OPTION_NAME
    from thonny.languages import tr
    from thonny.misc_utils import running_on_mac_os
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.globals import get_workbench
    from thonny.misc_utils import running_on_windows
    from thonny.tktextext import TextFrame
    from thonny.ui_utils import CommonDialog
    from thonny.ui_utils import askopenfilename
    from thonny.ui_utils import askopenfil

# Generated at 2022-06-18 09:40:53.635111
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny import get_runner
    from thonny.misc_utils import running_on_mac_os

    wb = Workbench()
    wb.load_plugin("thonny.plugins.pgzero_mode")
    assert wb.get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"
    wb.set_option(_OPTION_NAME, True)
    assert wb.get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"
    wb.set_simple_mode(True)
    assert os.environ["PGZERO_MODE"] == "auto"


# Generated at 2022-06-18 09:41:02.064851
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-18 09:41:10.410946
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.globals import get_workbench
    from thonny.languages import tr
    from thonny.misc_utils import running_on_mac_os
    from thonny.ui_utils import CommonDialog
    from thonny.ui_utils import askstring
    from thonny.ui_utils import askopenfilename
    from thonny.ui_utils import askdirectory
    from thonny.ui_utils import askopenfilenames
    from thonny.ui_utils import askyesno
    from thonny.ui_utils import showwarning
    from thonny.ui_utils import showerror

# Generated at 2022-06-18 09:42:11.164056
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench
    from thonny.plugins.pgzero_mode import load_plugin
    from thonny.plugins.pgzero_mode import toggle_variable
    from thonny.plugins.pgzero_mode import update_environment
    from thonny.plugins.pgzero_mode import _OPTION_NAME
    from thonny.languages import tr
    from thonny.misc_utils import running_on_mac_os
    from thonny.misc_utils import running_on_windows

    # Test load_plugin
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    assert get_workbench().get_variable(_OPTION_NAME).get_label()

# Generated at 2022-06-18 09:42:20.240634
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.globals import get_workbench
    from thonny.languages import tr
    from thonny.workbench import Workbench
    from thonny.config_ui import ConfigurationPage
    from thonny.misc_utils import running_on_mac_os
    from thonny.ui_utils import CommonDialog
    from thonny.ui_utils import askstring
    from thonny.ui_utils import askopenfilename
    from thonny.ui_utils import askdirectory
    from thonny.ui_utils import askinteger
    from thonny.ui_utils import askfloat
    from thonny.ui_utils import askcolor
    from thonny.ui_utils import askopenfilenames
    from thonny.ui_utils import askyesno

# Generated at 2022-06-18 09:42:31.006041
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run import RunConfigurationPage
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunBackend
    from thonny.plugins.run import RunCommand
    from thonny.plugins.run import RunProgramCommand
    from thonny.plugins.run import RunSelectionCommand
    from thonny.plugins.run import RunCurrentScriptCommand
    from thonny.plugins.run import RunModuleCommand
    from thonny.plugins.run import RunDebuggerCommand
    from thonny.plugins.run import RunDebuggerCommand
    from thonny.plugins.run import RunDebuggerCommand

# Generated at 2022-06-18 09:42:37.641947
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench
    from thonny.misc_utils import running_on_mac_os
    from thonny.languages import tr
    from thonny.config import get_workbench_configuration
    from thonny.workbench import Workbench
    from thonny.plugins.run import RunViewText
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunViewText
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunViewText
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunViewText
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunViewText

# Generated at 2022-06-18 09:42:45.496681
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run import RunConfigurationPage
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunCommand
    from thonny.plugins.run import RunBackendEventHandler
    from thonny.plugins.run import RunSubprocessEventHandler
    from thonny.plugins.run import RunSubprocessEventHandler
    from thonny.plugins.run import RunBackendEventHandler
    from thonny.plugins.run import RunCommand
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunConfigurationPage
    from thonny.config_ui import ConfigurationPage

# Generated at 2022-06-18 09:42:54.057676
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.misc_utils import running_on_mac_os
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.globals import get_workbench
    from thonny.languages import tr
    from thonny.ui_utils import CommonDialog
    from thonny.ui_utils import askopenfilename
    from thonny.ui_utils import askopenfilenames
    from thonny.ui_utils import asksaveasfilename
    from thonny.ui_utils import askdirectory
    from thonny.ui_utils import showwarning
    from thonny.ui_utils import showinfo
    from thonny.ui_utils import showerror

# Generated at 2022-06-18 09:42:58.016207
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-18 09:43:01.982865
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_default = Mock()
    wb.add_command = Mock()
    load_plugin()
    assert wb.set_default.call_count == 1
    assert wb.add_command.call_count == 1

# Generated at 2022-06-18 09:43:10.448261
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.misc_utils import running_on_mac_os
    from thonny.tktextext import TextFrame
    from thonny.ui_utils import CommonDialog
    from thonny.ui_utils import askstring
    from thonny.ui_utils import askopenfilename
    from thonny.ui_utils import askdirectory
    from thonny.ui_utils import askinteger
    from thonny.ui_utils import askfloat
    from thonny.ui_utils import askcolor
    from thonny.ui_utils import askyesno
    from thonny.ui_utils import askokcancel