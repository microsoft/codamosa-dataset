

# Generated at 2022-06-18 09:32:21.646664
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run import RunConfigurationPage
    from thonny.languages import tr
    from thonny.misc_utils import running_on_mac_os
    from thonny import get_workbench
    from thonny.globals import get_workbench
    from thonny.plugins.run import RunConfigurationPage
    from thonny.config_ui import ConfigurationPage
    from thonny.workbench import Workbench
    from thonny.misc_utils import running_on_mac_os
    from thonny.languages import tr

    wb = Workbench()
    wb.create()
    wb.set_default(_OPTION_NAME, False)
    wb.add_

# Generated at 2022-06-18 09:32:27.776463
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    wb.set_option(_OPTION_NAME, False)
    wb.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-18 09:32:33.438707
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    wb.set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    wb.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-18 09:32:38.577108
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.globals import get_workbench
    from thonny.misc_utils import running_on_mac_os
    from thonny.plugins.run import RunConfigurationPage
    from thonny.ui_utils import CommonDialog
    from thonny.ui_utils import askstring
    from thonny.ui_utils import askyesno
    from thonny.ui_utils import show_dialog
    from thonny.ui_utils import show_error
    from thonny.ui_utils import show_message
    from thonny.ui_utils import show_warning
    from thonny.ui_utils import show_warning

# Generated at 2022-06-18 09:32:45.750505
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench

    wb = Workbench()
    load_plugin()
    assert wb.get_variable(_OPTION_NAME) == False
    assert wb.get_option(_OPTION_NAME) == False
    assert wb.get_command("toggle_pgzero_mode")
    assert os.environ["PGZERO_MODE"] == "False"

    wb.set_option(_OPTION_NAME, True)
    assert wb.get_variable(_OPTION_NAME) == True
    assert wb.get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"

    wb.set_simple_mode(True)
    assert os.environ["PGZERO_MODE"] == "auto"

    wb.set

# Generated at 2022-06-18 09:32:53.845231
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from unittest.mock import Mock
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.globals import get_workbench
    from thonny.plugins.run import RunConfigurationPage
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunCommand
    from thonny.plugins.run import RunBackend
    from thonny.plugins.run import RunEventHandler
    from thonny.plugins.run import RunProgramEventHandler
    from thonny.plugins.run import RunFileEventHandler
    from thonny.plugins.run import RunModuleEventHandler
    from thonny.plugins.run import RunSelectionEventHandler

# Generated at 2022-06-18 09:33:02.058482
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.misc_utils import running_on_mac_os, running_on_windows
    from thonny.globals import get_workbench
    from thonny.languages import tr
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunCommand
    from thonny.plugins.run import RunBackend
    from thonny.plugins.run import RunConfigurationPage
    from thonny.plugins.run import RunProgramDialog
    from thonny.plugins.run import RunProgramEvent
    from thonny.plugins.run import RunScriptEvent
    from thonny.plugins.run import RunSelectionEvent

# Generated at 2022-06-18 09:33:09.842539
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run import RunConfigurationPage
    from thonny.languages import tr
    from thonny.misc_utils import running_on_mac_os
    from thonny.globals import get_workbench
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunCommand
    from thonny.plugins.run import RunBackend
    from thonny.plugins.run import RunConfigurationPage
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunCommand
    from thonny.plugins.run import RunBackend
    from thonny.plugins.run import RunConfigurationPage

# Generated at 2022-06-18 09:33:20.962879
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench
    from thonny.languages import tr
    from thonny.plugins.pgzero_mode import load_plugin
    from thonny.workbench import Workbench
    from unittest.mock import Mock
    from unittest.mock import patch
    from unittest.mock import MagicMock
    from unittest.mock import call
    from unittest.mock import create_autospec
    from unittest.mock import PropertyMock
    from unittest.mock import ANY
    from thonny.misc_utils import running_on_mac_os
    from thonny.misc_utils import running_on_windows
    from thonny.misc_utils import running_on_linux
    from thonny.misc_utils import running_on

# Generated at 2022-06-18 09:33:28.169110
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-18 09:33:39.216392
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    wb.set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    wb.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-18 09:33:42.000033
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-18 09:33:49.738077
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-18 09:33:59.765176
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run import RunConfigurationPage
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunBackend
    from thonny.plugins.run import RunCommand
    from thonny.plugins.run import RunProgram
    from thonny.plugins.run import RunOptionsPage
    from thonny.plugins.run import RunSubprocess
    from thonny.plugins.run import RunSubprocessDialog
    from thonny.plugins.run import RunSubprocessDialog
    from thonny.plugins.run import RunSubprocessDialog
    from thonny.plugins.run import RunSubprocessDialog

# Generated at 2022-06-18 09:34:09.470261
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from unittest.mock import Mock
    mock_workbench = Mock(Workbench)
    mock_workbench.get_option.return_value = True
    mock_workbench.in_simple_mode.return_value = False
    with patch("thonny.plugins.pgzero_mode.get_workbench", return_value=mock_workbench):
        update_environment()
        assert os.environ["PGZERO_MODE"] == "True"

        mock_workbench.get_option.return_value = False
        update_environment()
        assert os.environ["PGZERO_MODE"] == "False"

        mock_workbench.in_simple_mode.return_value = True
        update_environment()

# Generated at 2022-06-18 09:34:19.273429
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.globals import get_workbench
    from thonny.languages import tr
    from thonny.misc_utils import running_on_mac_os
    from thonny.ui_utils import CommonDialog
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()
    assert wb.get_option(_OPTION_NAME) == False
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == True


# Generated at 2022-06-18 09:34:29.729037
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.misc_utils import running_on_mac_os
    from thonny.globals import get_workbench
    from thonny.languages import tr
    from thonny.ui_utils import CommonDialog
    from thonny.ui_utils import askstring
    from thonny.ui_utils import askopenfilename
    from thonny.ui_utils import askdirectory
    from thonny.ui_utils import showwarning
    from thonny.ui_utils import showerror
    from thonny.ui_utils import showinfo
    from thonny.ui_utils import askyesno

# Generated at 2022-06-18 09:34:41.082038
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from unittest.mock import Mock
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run import RunConfigurationPage
    from thonny.plugins.run import RunView
    from thonny.languages import tr
    from thonny.misc_utils import running_on_mac_os
    from thonny.globals import get_workbench
    from thonny import THONNY_USER_DIR
    from thonny.misc_utils import running_on_windows
    from thonny.misc_utils import running_on_linux
    from thonny.misc_utils import running_on_mac_os
    from thonny.misc_utils import running_on_

# Generated at 2022-06-18 09:34:53.018340
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench
    from thonny.plugins.pgzero_mode import load_plugin
    from thonny.workbench import Workbench

    wb = Workbench()
    load_plugin()
    assert wb.get_option(_OPTION_NAME) == False
    assert wb.get_variable(_OPTION_NAME).get() == False
    assert os.environ["PGZERO_MODE"] == "False"
    wb.set_option(_OPTION_NAME, True)
    assert wb.get_option(_OPTION_NAME) == True
    assert wb.get_variable(_OPTION_NAME).get() == True
    assert os.environ["PGZERO_MODE"] == "True"
    wb.set_simple_mode(True)
    assert wb.get_option

# Generated at 2022-06-18 09:35:02.713364
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config_ui import ConfigurationPage
    from thonny.misc_utils import running_on_mac_os
    from thonny.globals import get_workbench
    from thonny.languages import tr
    import os
    import unittest.mock
    import tkinter as tk

    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.create_configuration_page(ConfigurationPage)
    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    wb.set_option(_OPTION_NAME, False)
    update_environment()

# Generated at 2022-06-18 09:35:12.237255
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == True
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == False


# Generated at 2022-06-18 09:35:23.623931
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.globals import get_workbench
    from thonny.languages import tr
    from thonny.plugins.run.pgzero_mode import toggle_variable
    from thonny.plugins.run.pgzero_mode import update_environment
    from thonny.plugins.run.pgzero_mode import _OPTION_NAME
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.config_ui import ConfigurationDialog
    from thonny.config_ui import GeneralConfigurationPage
    from thonny.config_ui import ConfigurationDialog
    from thonny.config_ui import GeneralConfigurationPage
    from thonny.config_ui import ConfigurationDialog

# Generated at 2022-06-18 09:35:34.012754
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run import RunConfigurationPage
    from thonny.languages import EnglishLanguage
    from thonny.misc_utils import running_on_mac_os, running_on_windows
    from thonny.globals import get_workbench
    from thonny.plugins.pgzero_mode import _OPTION_NAME

    wb = Workbench(EnglishLanguage())
    wb.set_default(_OPTION_NAME, False)

# Generated at 2022-06-18 09:35:44.821733
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench

    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()

    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().get_variable(_OPTION_NAME).set(True)
    update_environment()

    assert get_workbench().get_variable(_OPTION_NAME).get() == True

# Generated at 2022-06-18 09:35:50.279080
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    assert wb.get_option(_OPTION_NAME) == False
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == True
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == False

# Generated at 2022-06-18 09:36:01.564457
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    assert wb.get_option(_OPTION_NAME) == False
    load_plugin()
    assert wb.get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"
    wb.in_simple_mode = lambda: True
    update_environment()
    assert os.environ["PGZERO_MODE"]

# Generated at 2022-06-18 09:36:11.392226
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run import RunView
    from thonny.languages import tr
    from thonny.misc_utils import running_on_mac_os
    from thonny.globals import get_workbench
    from thonny.globals import get_runner
    from thonny.globals import get_shell
    from thonny.globals import get_workbench
    from thonny.globals import get_runner
    from thonny.globals import get_shell
    from thonny.globals import get_workbench

# Generated at 2022-06-18 09:36:21.185903
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench

    wb = Workbench()
    load_plugin()
    assert wb.get_variable(_OPTION_NAME).get() == False
    assert wb.get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"

    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    wb.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-18 09:36:30.618778
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunCommand
    from thonny.plugins.run import RunBackendEventHandler
    from thonny.plugins.run import RunBackend
    from thonny.plugins.run import RunProgramThread
    from thonny.plugins.run import RunProgramDialog
    from thonny.plugins.run import RunProgramDialog
    from thonny.plugins.run import RunProgramDialog
    from thonny.plugins.run import RunProgramDialog
    from thonny.plugins.run import RunProgramDialog
    from thonny.plugins.run import RunProgramDialog
    from thonny.plugins.run import RunProgramDialog

# Generated at 2022-06-18 09:36:40.349027
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.misc_utils import running_on_mac_os
    from unittest.mock import Mock
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.globals import get_workbench
    from thonny.plugins.pgzero_mode import _OPTION_NAME
    from thonny.plugins.pgzero_mode import update_environment
    from thonny.plugins.pgzero_mode import toggle_variable
    from thonny.languages import tr
    from thonny.misc_utils import running_on_windows
    from thonny.misc_utils import running_on_mac_os
    from thonny.misc_utils import running_on_linux

# Generated at 2022-06-18 09:36:55.003153
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-18 09:37:05.398791
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run import RunConfigurationPage
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunCommand
    from thonny.plugins.run import RunBackend
    from thonny.plugins.run import RunEventHandler
    from thonny.plugins.run import RunProgramThread
    from thonny.plugins.run import RunProgramDialog
    from thonny.plugins.run import RunScriptDialog
    from thonny.plugins.run import RunScriptCommand
    from thonny.plugins.run import RunScriptEventHandler
    from thonny.plugins.run import RunScriptThread

# Generated at 2022-06-18 09:37:14.734784
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-18 09:37:19.662952
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == True
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == False

# Generated at 2022-06-18 09:37:31.636349
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.globals import get_workbench
    from thonny.languages import tr
    from thonny.misc_utils import running_on_mac_os
    from thonny.plugins.backend_configuration import BackendConfigurationPage
    from thonny.plugins.cpython_configuration import CPythonConfigurationPage
    from thonny.plugins.micropython_configuration import MicroPythonConfigurationPage
    from thonny.plugins.pylint_configuration import PylintConfigurationPage
    from thonny.plugins.python_tutor_configuration import PythonTutorConfigurationPage

# Generated at 2022-06-18 09:37:39.415402
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import Mock
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    import os
    import shutil
    import sys

    # Create a mock workbench
    wb = Workbench()
    wb.in_simple_mode = Mock(return_value=False)
    wb.get_option = Mock(return_value=True)

    # Create a mock configuration page
    config_page = ConfigurationPage(wb)
    config_page.load_plugin = Mock()
    config_page.load_plugin.return_value = None

    # Create a mock configuration dialog
    config_dialog = Mock()
    config_dialog.add_page = Mock()
    config_dialog.add_

# Generated at 2022-06-18 09:37:47.844017
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-18 09:37:58.408798
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import Mock
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_default(_OPTION_NAME, True)
    wb.set_simple_mode(False)
    wb.set_option(_OPTION_NAME, False)

    wb.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    wb.set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-18 09:38:08.628996
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run import RunConfigurationPage
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunCommand
    from thonny.plugins.run import RunBackendEventHandler
    from thonny.plugins.run import RunBackend
    from thonny.plugins.run import RunBackendProxy
    from thonny.plugins.run import RunBackendProxyEventHandler
    from thonny.plugins.run import RunBackendProxyThread
    from thonny.plugins.run import RunBackendProxyThreadEventHandler
    from thonny.plugins.run import RunBackendProxyThreadEventHandler

# Generated at 2022-06-18 09:38:20.178078
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.misc_utils import running_on_mac_os
    from unittest.mock import patch

    wb = Workbench()
    wb.set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    wb.set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    wb.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    wb.set_simple_mode(False)
    wb.set_default(_OPTION_NAME, True)
    update_environment

# Generated at 2022-06-18 09:38:50.246579
# Unit test for function toggle_variable
def test_toggle_variable():
    from unittest.mock import Mock
    from thonny.workbench import Workbench

    workbench = Workbench()
    workbench.set_default(_OPTION_NAME, False)

    toggle_variable()
    assert workbench.get_option(_OPTION_NAME) == True

    toggle_variable()
    assert workbench.get_option(_OPTION_NAME) == False

    workbench.set_default(_OPTION_NAME, True)
    toggle_variable()
    assert workbench.get_option(_OPTION_NAME) == False

    workbench.set_default(_OPTION_NAME, False)
    toggle_variable()
    assert workbench.get_option(_OPTION_NAME) == True

# Generated at 2022-06-18 09:39:00.774281
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.misc_utils import running_on_mac_os
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run import RunConfigurationPage
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunCommand
    from thonny.plugins.run import RunBackendEventHandler
    from thonny.plugins.run import RunBackend
    from thonny.plugins.run import RunProgram
    from thonny.plugins.run import RunProgramThread
    from thonny.plugins.run import RunProgramDialog
    from thonny.plugins.run import RunProgramDialogWithArguments
    from thonny.plugins.run import RunProgramDialogWith

# Generated at 2022-06-18 09:39:04.915417
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    assert get_workbench().get_option(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-18 09:39:09.200926
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == True
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == False

# Generated at 2022-06-18 09:39:18.045450
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.config_ui import ConfigurationPage
    from thonny.globals import get_runner
    from thonny.misc_utils import running_on_mac_os

    wb = Workbench()
    wb.create()
    wb.set_default(_OPTION_NAME, False)
    wb.add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()

    assert wb.get_variable(_OPTION_NAME).get() == False
    assert os.environ["PGZERO_MODE"] == "False"

    wb.event_generate

# Generated at 2022-06-18 09:39:25.840381
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run import RunConfigurationPage
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunCommand
    from thonny.plugins.run import RunBackendEventHandler
    from thonny.plugins.run import RunBackend
    from thonny.plugins.run import RunBackendProxy
    from thonny.plugins.run import RunBackendProxyEventHandler
    from thonny.plugins.run import RunBackendProxyThread
    from thonny.plugins.run import RunCommandHandler
    from thonny.plugins.run import RunEventHandler
    from thonny.plugins.run import RunViewEventHandler

# Generated at 2022-06-18 09:39:32.618489
# Unit test for function update_environment
def test_update_environment():
    from thonny.globals import get_workbench
    from thonny.workbench import Workbench
    from unittest.mock import Mock
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run import RunConfigurationPage
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunCommand
    from thonny.plugins.run import RunBackendEventHandler
    from thonny.plugins.run import RunProgramDialog
    from thonny.plugins.run import RunScriptDialog
    from thonny.plugins.run import RunModuleDialog
    from thonny.plugins.run import RunSelectionDialog
    from thonny.plugins.run import RunCurrentScriptCommand

# Generated at 2022-06-18 09:39:39.446967
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run import RunConfigurationPage
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunCommand
    from thonny.plugins.run import RunBackend
    from thonny.plugins.run import RunEventHandler
    from thonny.plugins.run import RunDebugger
    from thonny.plugins.run import RunDebuggerEventHandler
    from thonny.plugins.run import RunDebuggerView
    from thonny.plugins.run import RunDebuggerBackend
    from thonny.plugins.run import RunDebuggerCommand
    from thonny.plugins.run import RunDebuggerConfigurationPage
    from thonny.plugins.run import RunDebuggerEvent

# Generated at 2022-06-18 09:39:46.761949
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    wb.set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    wb.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-18 09:39:55.662122
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.misc_utils import running_on_mac_os, running_on_windows
    from thonny.config import get_config_dir
    import os
    import shutil
    import tempfile
    import sys

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create the thonny config directory
    os.makedirs(os.path.join(tmpdir, get_config_dir()))
    # Create the thonny config file
    config_file = os.path.join(tmpdir, get_config_dir(), "config-v2.json")
    with open(config_file, "w") as fp:
        fp.write("{}")
    # Create the thonny plugins directory

# Generated at 2022-06-18 09:40:58.684666
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.config_ui import ConfigurationDialog
    from thonny.config import get_runner
    from thonny.misc_utils import running_on_mac_os
    from thonny.ui_utils import CommonDialog
    from thonny.ui_utils import askstring
    from thonny.ui_utils import askopenfilename
    from thonny.ui_utils import askdirectory
    from thonny.ui_utils import askinteger
    from thonny.ui_utils import askfloat
    from thonny.ui_utils import askcolor
    from thonny.ui_utils import askopenfilenames

# Generated at 2022-06-18 09:41:08.166104
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.misc_utils import running_on_mac_os
    from thonny.tktextext import TextFrame
    from tkinter import Tk
    from tkinter.ttk import Button
    from unittest.mock import patch
    import os
    import shutil
    import tempfile

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create the configuration directory
    os.makedirs(os.path.join(tmpdir, "thonny"))

    # Create the configuration file
    config_file = os.path.join(tmpdir, "thonny", "config.ini")

# Generated at 2022-06-18 09:41:16.041972
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.config import Configuration
    from thonny.plugins.run import RunCommand
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunBackend
    from thonny.plugins.run import RunEventHandler
    from thonny.plugins.run import RunDebugger
    from thonny.plugins.run import RunDebuggerEventHandler
    from thonny.plugins.run import RunDebuggerView
    from thonny.plugins.run import RunDebuggerBackend
    from thonny.plugins.run import RunDebuggerCommand
    from thonny.plugins.run import RunDebuggerCommandHandler
    from thonny.plugins.run import RunDebuggerCommandHandler
    from thonny.plugins.run import RunDebuggerCommandHandler

# Generated at 2022-06-18 09:41:22.243931
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.globals import get_workbench
    from thonny.misc_utils import running_on_mac_os
    from thonny.workbench import Workbench
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunBackend
    from thonny.plugins.run import RunCommand
    from thonny.plugins.run import RunConfiguration
    from thonny.plugins.run import RunConfigurationPage
    from thonny.plugins.run import RunConfigurationDialog
    from thonny.plugins.run import RunConfigurationManager
    from thonny.plugins.run import RunScriptCommand
    from thonny.plugins.run import RunSelectionCommand
    from thonny.plugins.run import RunCurrentScriptCommand
    from thonny.plugins.run import RunCurrentModuleCommand


# Generated at 2022-06-18 09:41:31.416173
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.globals import get_workbench
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunBackend
    from thonny.plugins.run import RunCommand
    from thonny.plugins.run import RunConfigurationPage
    from thonny.plugins.run import RunOptionsPage
    from thonny.plugins.run import RunProgram
    from thonny.plugins.run import RunSubprocess
    from thonny.plugins.run import RunSubprocessEvent
    from thonny.plugins.run import RunViewEvent
    from thonny.plugins.run import RunViewEventType

# Generated at 2022-06-18 09:41:39.855851
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-18 09:41:43.797466
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-18 09:41:50.137421
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()
    assert wb.get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-18 09:42:00.163707
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run import RunConfigurationPage
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunCommand
    from thonny.plugins.run import RunBackendEventHandler
    from thonny.plugins.run import RunBackend
    from thonny.plugins.run import RunBackendProxy
    from thonny.plugins.run import RunBackendProxyEventHandler
    from thonny.plugins.run import RunBackendProxyThread
    from thonny.plugins.run import RunBackendProxyThreadEventHandler
    from thonny.plugins.run import RunBackendProxyThreadEventHandler

# Generated at 2022-06-18 09:42:07.218976
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import Mock
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.set_option(_OPTION_NAME, False)
    wb.in_simple_mode = Mock(return_value=False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    wb.in_simple_mode = Mock(return_value=True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"