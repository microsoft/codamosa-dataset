

# Generated at 2022-06-18 09:33:18.000295
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench
    from thonny.workbench import Workbench
    from thonny.config import Configuration
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run import RunConfigurationPage
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunCommand
    from thonny.plugins.run import RunBackend
    from thonny.plugins.run import RunEventHandler
    from thonny.plugins.run import RunDebugger
    from thonny.plugins.run import RunDebuggerEventHandler
    from thonny.plugins.run import RunDebuggerView
    from thonny.plugins.run import RunDebuggerBackend
    from thonny.plugins.run import RunDebuggerCommand

# Generated at 2022-06-18 09:33:27.904665
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench
    from thonny.workbench import Workbench
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run.run_config_page import RunConfigurationPage
    from thonny.languages import tr
    from thonny.misc_utils import running_on_mac_os
    from thonny.globals import get_workbench
    from thonny.plugins.run.run_config_page import RunConfigurationPage
    from thonny.plugins.run.run_command import RunConfigurationPage
    from thonny.plugins.run.run_command import RunConfigurationPage
    from thonny.plugins.run.run_command import RunConfigurationPage
    from thonny.plugins.run.run_command import RunConfigurationPage

# Generated at 2022-06-18 09:33:32.509116
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-18 09:33:41.540420
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.misc_utils import running_on_mac_os, running_on_windows
    from thonny.languages import English
    from thonny.plugins.backend_configuration import BackendConfiguration
    from thonny.plugins.python_proxy import PythonProxy
    from thonny.plugins.python_process import PythonProcess
    from thonny.plugins.thonny_backend import ThonnyBackend
    from thonny.plugins.micropython import MicroPythonProxy
    from thonny.plugins.micropython_process import MicroPythonProcess
    from thonny.plugins.micropython_backend import MicroPythonBackend
    from thonny.plugins.thonny_shell import Th

# Generated at 2022-06-18 09:33:52.341379
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.misc_utils import running_on_mac_os
    from thonny.ui_utils import CommonDialog
    from tkinter import Tk
    from thonny.plugins.backend_configuration import BackendConfigurationDialog
    from thonny.plugins.backend_configuration import BackendConfigurationPage
    from thonny.plugins.backend_configuration import BackendConfigurationDialog
    from thonny.plugins.backend_configuration import BackendConfigurationPage
    from thonny.plugins.backend_configuration import BackendConfigurationDialog
    from thonny.plugins.backend_configuration import BackendConfigurationPage

# Generated at 2022-06-18 09:34:02.177739
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.languages import tr
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunCommand
    from thonny.plugins.run import RunBackend
    from thonny.plugins.run import RunOptionsPage
    from thonny.plugins.run import RunConfigurationPage
    from thonny.plugins.run import RunCommand
    from thonny.plugins.run import RunBackend
    from thonny.plugins.run import RunOptionsPage
    from thonny.plugins.run import RunConfigurationPage
    from thonny.plugins.run import RunCommand
    from thonny.plugins.run import RunBackend

# Generated at 2022-06-18 09:34:11.899954
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.globals import get_workbench
    from thonny.misc_utils import running_on_mac_os, running_on_windows
    from thonny.tktextext import TextFrame
    import os
    import shutil
    import sys
    import tkinter as tk
    import tkinter.ttk as ttk

    # Create a temporary directory
    tmp_dir = tempfile.mkdtemp()
    # Create the configuration directory
    os.makedirs(os.path.join(tmp_dir, "thonny"))
    # Create the configuration file

# Generated at 2022-06-18 09:34:21.580248
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.misc_utils import running_on_mac_os, running_on_windows
    from thonny.languages import DEFAULT_LANGUAGE
    from thonny.ui_utils import CommonDialog
    from thonny.globals import get_workbench
    from thonny.ui_utils import askstring
    from thonny.ui_utils import askopenfilename
    from thonny.ui_utils import askdirectory
    from thonny.ui_utils import askinteger
    from thonny.ui_utils import askfloat
    from thonny.ui_utils import askyesno
    from thonny.ui_utils import ask

# Generated at 2022-06-18 09:34:32.179911
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.globals import get_runner
    from thonny.plugins.run import RunCommand
    from thonny.plugins.run import RunConfiguration
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunBackend
    from thonny.plugins.run import RunEventHandler
    from thonny.plugins.run import RunCommand
    from thonny.plugins.run import RunConfiguration
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunBackend
    from thonny.plugins.run import RunEventHandler
    from thonny.plugins.run import RunCommand
    from thonny.plugins.run import RunConfiguration
    from thonny.plugins.run import RunView


# Generated at 2022-06-18 09:34:44.120681
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.misc_utils import running_on_mac_os
    from thonny.globals import get_workbench
    from thonny import THONNY_USER_DIR
    from thonny.languages import tr
    from thonny.plugins.pgzero_mode import _OPTION_NAME
    from thonny.plugins.pgzero_mode import update_environment
    from thonny.plugins.pgzero_mode import toggle_variable
    from thonny.plugins.pgzero_mode import load_plugin
    from thonny.plugins.pgzero_mode import _OPTION_NAME
    from thonny.workbench import Workbench
   

# Generated at 2022-06-18 09:34:58.495298
# Unit test for function update_environment
def test_update_environment():
    from thonny.globals import get_workbench
    from thonny.misc_utils import running_on_mac_os, running_on_windows
    from thonny.languages import tr
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.backend_configuration import BackendConfigurationPage
    from thonny.plugins.backend_configuration import BackendConfigurationDialog
    from thonny.plugins.backend_configuration import BackendConfigurationDialog
    from thonny.plugins.backend_configuration import BackendConfigurationDialog
    from thonny.plugins.backend_configuration import BackendConfigurationDialog
    from thonny.plugins.backend_configuration import Back

# Generated at 2022-06-18 09:35:06.588230
# Unit test for function toggle_variable
def test_toggle_variable():
    from unittest.mock import Mock
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    wb.get_variable(_OPTION_NAME).set(False)
    assert wb.get_variable(_OPTION_NAME).get() == False
    toggle_variable()
    assert wb.get_variable(_OPTION_NAME).get() == True
    toggle_variable()
    assert wb.get_variable(_OPTION_NAME).get() == False

# Generated at 2022-06-18 09:35:11.584860
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench

    wb = Workbench()
    load_plugin()
    assert wb.get_variable(_OPTION_NAME).get() == False
    assert wb.get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"
    wb.set_option(_OPTION_NAME, True)
    assert wb.get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"
    wb.set_simple_mode(True)
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-18 09:35:23.042931
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import Mock
    from thonny.globals import get_workbench

    wb = Mock()
    wb.get_option = Mock(return_value=True)
    wb.in_simple_mode = Mock(return_value=False)
    get_workbench = Mock(return_value=wb)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    wb.get_option = Mock(return_value=False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    wb.in_simple_mode = Mock(return_value=True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-18 09:35:26.557237
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-18 09:35:34.696573
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().in_simple_mode = lambda: True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-18 09:35:38.954663
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-18 09:35:49.366533
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench
    from thonny.misc_utils import running_on_mac_os, running_on_windows
    from thonny.languages import tr
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run import RunConfigurationPage
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunCommand
    from thonny.plugins.run import RunBackend
    from thonny.plugins.run import RunEventHandler
    from thonny.plugins.run import RunSubprocessDialog
    from thonny.plugins.run import RunSubprocessDialog
    from thonny.plugins.run import RunSubprocessDialog
   

# Generated at 2022-06-18 09:35:55.371175
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench

    wb = Workbench()
    load_plugin()
    assert wb.get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-18 09:36:06.229958
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.globals import get_workbench
    import os
    import shutil
    import tempfile
    import unittest

    class TestConfigurationPage(ConfigurationPage):
        def __init__(self, master):
            ConfigurationPage.__init__(self, master, "test")

        def load(self):
            pass

        def apply(self):
            pass

    class TestWorkbench(Workbench):
        def create_configuration_page(self, master):
            return TestConfigurationPage(master)

    class Test(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()


# Generated at 2022-06-18 09:36:23.817080
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.misc_utils import running_on_mac_os
    from thonny.globals import get_workbench
    from thonny.languages import tr
    from thonny.plugins.pgzero_mode import _OPTION_NAME

    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    wb.set_option(_OPTION_NAME, False)
    update_environment()

# Generated at 2022-06-18 09:36:29.852707
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench

    wb = Workbench()
    load_plugin()
    assert wb.get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-18 09:36:39.738134
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from unittest.mock import patch
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run import RunConfigurationPage
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunCommand
    from thonny.plugins.run import RunBackend
    from thonny.plugins.run import RunProgramDialog
    from thonny.plugins.run import RunScriptDialog
    from thonny.plugins.run import RunModuleDialog
    from thonny.plugins.run import RunSelectionDialog
    from thonny.plugins.run import RunCurrentScriptDialog
    from thonny.plugins.run import RunCurrentModuleDialog

# Generated at 2022-06-18 09:36:46.075307
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_default = Mock()
    wb.add_command = Mock()
    load_plugin()
    wb.set_default.assert_called_once_with(_OPTION_NAME, False)
    wb.add_command.assert_called_once()
    assert wb.add_command.call_args[0][0] == "toggle_pgzero_mode"
    assert wb.add_command.call_args[0][1] == "run"
    assert wb.add_command.call_args[0][2] == tr("Pygame Zero mode")
    assert wb.add_command.call_args[0][3] == toggle_variable
    assert wb

# Generated at 2022-06-18 09:36:56.423149
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.globals import get_workbench
    from thonny.languages import tr
    from thonny.plugins.run import toggle_variable
    from thonny.plugins.run import update_environment
    from thonny.workbench import Workbench
    from unittest.mock import patch
    from unittest.mock import Mock

    workbench = Workbench()
    workbench.set_default(_OPTION_NAME, False)
    workbench.add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()


# Generated at 2022-06-18 09:37:06.551872
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunCommand
    from thonny.plugins.run import RunBackendEventHandler
    from thonny.plugins.run import RunBackendProxy
    from thonny.plugins.run import RunBackendThread
    from thonny.plugins.run import RunBackend
    from thonny.plugins.run import RunBackendProxy
    from thonny.plugins.run import RunBackendThread
    from thonny.plugins.run import RunBackend
    from thonny.plugins.run import RunBackendEventHandler
    from thonny.plugins.run import RunCommand
    from thonny.plugins.run import RunView

# Generated at 2022-06-18 09:37:18.712667
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.globals import get_workbench
    from thonny.misc_utils import running_on_mac_os, running_on_windows
    from thonny.plugins.run.run_config_page import RunConfigurationPage
    from thonny.plugins.run.run_command import RunCommand
    from thonny.plugins.run.run_subprocess import RunSubprocess
    from thonny.plugins.run.run_event_loop import RunEventLoop
    from thonny.plugins.run.run_backend import RunBackend
    from thonny.plugins.run.run_pgzero_mode import toggle_variable, update_environment
   

# Generated at 2022-06-18 09:37:29.641505
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.misc_utils import running_on_mac_os
    from thonny.tktextext import TextFrame
    from thonny.ui_utils import CommonDialog
    from thonny.plugins.backend_configuration import BackendConfigurationDialog
    from thonny.plugins.backend_configuration import BackendConfigurationPage
    from thonny.plugins.backend_configuration import BackendConfigurationDialog
    from thonny.plugins.backend_configuration import BackendConfigurationPage
    from thonny.plugins.backend_configuration import BackendConfigurationDialog
    from thonny.plugins.backend_configuration import BackendConfigurationPage

# Generated at 2022-06-18 09:37:33.579588
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-18 09:37:38.532984
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-18 09:38:01.258157
# Unit test for function update_environment
def test_update_environment():
    from thonny.globals import get_workbench
    from thonny.misc_utils import running_on_mac_os
    from thonny.languages import tr
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.cpython import CPythonProxy
    from thonny.plugins.backend_configuration import BackendConfigurationDialog
    from thonny.plugins.backend_configuration import BackendConfigurationDialog
    from thonny.plugins.backend_configuration import BackendConfigurationDialog
    from thonny.plugins.backend_configuration import BackendConfigurationDialog
    from thonny.plugins.backend_configuration import BackendConfigurationDialog

# Generated at 2022-06-18 09:38:09.101015
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-18 09:38:20.606050
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config_ui import ConfigurationPage
    from unittest.mock import Mock
    from tkinter import Tk
    from thonny.globals import get_runner

    root = Tk()
    workbench = Workbench(root)
    workbench.set_default(_OPTION_NAME, False)
    workbench.set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    workbench.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    workbench.set_option(_OPTION_NAME, False)

# Generated at 2022-06-18 09:38:26.864558
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_default = Mock()
    wb.add_command = Mock()
    load_plugin()
    wb.set_default.assert_called_once_with(_OPTION_NAME, False)
    wb.add_command.assert_called_once()
    assert wb.add_command.call_args[0][0] == "toggle_pgzero_mode"
    assert wb.add_command.call_args[1]["flag_name"] == _OPTION_NAME

# Generated at 2022-06-18 09:38:35.027303
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.misc_utils import running_on_mac_os
    from thonny.globals import get_workbench
    from thonny.languages import tr
    from thonny.plugins.pgzero_mode import _OPTION_NAME
    from thonny.plugins.pgzero_mode import update_environment
    from thonny.plugins.pgzero_mode import toggle_variable
    from thonny.plugins.pgzero_mode import load_plugin

    # Create a workbench
    workbench = Workbench()
    workbench.set_default(_OPTION_NAME, False)

# Generated at 2022-06-18 09:38:45.058430
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.misc_utils import running_on_mac_os
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.globals import get_workbench
    from thonny.languages import tr
    import os
    import sys
    import unittest
    import tkinter as tk

    class TestWorkbench(Workbench):
        def __init__(self, master, **kwargs):
            super().__init__(master, **kwargs)
            self.set_default(_OPTION_NAME, False)

# Generated at 2022-06-18 09:38:53.984505
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.misc_utils import running_on_mac_os
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.globals import get_workbench
    from thonny.plugins.pgzero_mode import _OPTION_NAME
    from thonny.plugins.pgzero_mode import update_environment

    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    wb.set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    wb

# Generated at 2022-06-18 09:39:01.515092
# Unit test for function toggle_variable
def test_toggle_variable():
    from unittest.mock import Mock
    from thonny.workbench import Workbench

    workbench = Workbench()
    workbench.set_default(_OPTION_NAME, False)
    workbench.get_variable = Mock(return_value=workbench.get_option(_OPTION_NAME))
    toggle_variable()
    assert workbench.get_option(_OPTION_NAME) == True
    toggle_variable()
    assert workbench.get_option(_OPTION_NAME) == False

# Generated at 2022-06-18 09:39:10.716814
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.globals import get_workbench
    from thonny.misc_utils import running_on_mac_os
    from thonny.ui_utils import CommonDialog
    from thonny.ui_utils import askopenfilename
    from thonny.ui_utils import askdirectory
    from thonny.ui_utils import askinteger
    from thonny.ui_utils import askfloat
    from thonny.ui_utils import askstring
    from thonny.ui_utils import showerror
    from thonny.ui_utils import showinfo
    from thonny.ui_utils import showwarning

# Generated at 2022-06-18 09:39:19.485700
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.misc_utils import running_on_mac_os
    from thonny import get_runner
    from thonny.ui_utils import ask_for_string
    from thonny.globals import get_workbench
    from thonny.languages import tr
    from thonny.plugins.pgzero_mode import toggle_variable
    from thonny.plugins.pgzero_mode import update_environment
    from thonny.plugins.pgzero_mode import _OPTION_NAME
    from thonny.plugins.pgzero_mode import load_plugin
    from thonny.plugins.pgzero_mode import test_update_environment
   

# Generated at 2022-06-18 09:39:57.373179
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.globals import get_workbench
    from thonny.languages import tr
    from thonny.plugins.run import toggle_variable
    from thonny.plugins.run import update_environment
    from thonny.plugins.run import _OPTION_NAME
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.config_ui import ConfigurationDialog
    from thonny.misc_utils import running_on_mac_os
    from thonny.misc_utils import running_on_windows
    from thonny.misc_utils import running_on_linux
    from thonny.misc_utils import running_on_rpi

# Generated at 2022-06-18 09:40:03.631364
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.globals import get_workbench
    import os
    import shutil
    import tkinter as tk
    from tkinter import ttk

    # Create a temporary directory
    tmp_dir = "/tmp/thonny/test_load_plugin"
    os.makedirs(tmp_dir, exist_ok=True)

    # Create a temporary workbench
    wb = Workbench()
    wb.create()
    wb.set_option("general.workDir", tmp_dir)
    wb.set_option("general.configDir", tmp_dir)

# Generated at 2022-06-18 09:40:12.947186
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.misc_utils import running_on_mac_os
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.globals import get_workbench
    from thonny.languages import tr
    from thonny.ui_utils import CommonDialog
    from thonny.plugins.cpython import CPythonProxy
    from thonny.plugins.cpython.config_page import CPythonConfigurationPage
    from thonny.plugins.cpython.interpreter import CPythonInterpreter
    from thonny.plugins.cpython.interpreter_proxy import CPythonProxy
    from thonny.plugins.cpython.load_cpython_plugin import load_cpython_plugin
   

# Generated at 2022-06-18 09:40:23.879044
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.misc_utils import running_on_mac_os
    from thonny.globals import get_workbench
    from thonny.plugins.pgzero_mode import toggle_variable, update_environment
    from thonny.languages import tr
    from thonny.plugins.pgzero_mode import _OPTION_NAME
    from thonny.misc_utils import running_on_windows
    from thonny import THONNY_USER_DIR
    import os
    import shutil
    import sys

    # Create a new workbench
    wb = Workbench()

    # Set the default value for the option
    wb.set_default

# Generated at 2022-06-18 09:40:33.962279
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench
    from thonny.plugins.pgzero_mode import load_plugin
    from thonny.workbench import Workbench
    from unittest.mock import Mock
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.pgzero_mode import toggle_variable
    from thonny.plugins.pgzero_mode import update_environment
    from thonny.languages import tr
    from thonny.common import TkVersion
    from thonny.workbench import Workbench
    from thonny.globals import get_workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage

# Generated at 2022-06-18 09:40:37.185503
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-18 09:40:43.966506
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.globals import get_workbench
    from thonny.misc_utils import running_on_mac_os
    from thonny.plugins.run import RunConfigurationPage
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunViewUpdater
    from thonny.plugins.run import RunViewUpdaterThread
    from thonny.plugins.run import RunViewUpdaterThread
    from thonny.plugins.run import RunViewUpdaterThread
    from thonny.plugins.run import RunViewUpdaterThread
    from thonny.plugins.run import RunViewUpdaterThread

# Generated at 2022-06-18 09:40:53.912904
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.misc_utils import running_on_mac_os
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.globals import get_workbench
    from thonny.plugins.run import RunConfigurationPage
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunCommand
    from thonny.plugins.run import RunBackendEventHandler
    from thonny.plugins.run import RunProgramDialog
    from thonny.plugins.run import RunScriptDialog
    from thonny.plugins.run import RunModuleDialog
    from thonny.plugins.run import RunSelectionDialog
    from thonny.plugins.run import RunCurrentScriptCommand

# Generated at 2022-06-18 09:40:59.859834
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    wb.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-18 09:41:07.602126
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_default = Mock()
    wb.add_command = Mock()
    load_plugin()
    wb.set_default.assert_called_once_with(_OPTION_NAME, False)
    wb.add_command.assert_called_once()
    assert wb.add_command.call_args[0][0] == "toggle_pgzero_mode"
    assert wb.add_command.call_args[1]["flag_name"] == _OPTION_NAME

# Generated at 2022-06-18 09:42:08.502756
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.config_ui import ConfigurationPage
    from thonny.globals import get_runner
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunBackend
    from thonny.plugins.run import RunCommand
    from thonny.plugins.run import RunConfigurationPage
    from thonny.plugins.run import RunOptionsPage
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunBackend
    from thonny.plugins.run import RunCommand
    from thonny.plugins.run import RunConfigurationPage
    from thonny.plugins.run import RunOptionsPage
    from thonny.plugins.run import RunView
    from thonny.plugins.run import Run

# Generated at 2022-06-18 09:42:14.732964
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run.run_config_page import RunConfigurationPage
    from thonny.plugins.run.run_command import RunCommand
    from thonny.languages import tr
    from thonny.misc_utils import running_on_mac_os

    wb = Workbench()
    wb.create()
    wb.set_default(_OPTION_NAME, False)
    wb.add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()

# Generated at 2022-06-18 09:42:22.425557
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from unittest.mock import patch
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.globals import get_workbench
    from thonny.misc_utils import running_on_mac_os
    from thonny.tktextext import TextFrame
    from thonny.ui_utils import CommonDialog
    from thonny.workbench import Workbench
    from thonny.workbench import _get_workbench
    from thonny.workbench import get_workbench
    from thonny.workbench import reset_workbench
    from thonny.workbench import show_workbench
    from thonny.workbench import WorkbenchEvent

# Generated at 2022-06-18 09:42:34.122352
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench
    from thonny.languages import tr
    from thonny.misc_utils import running_on_mac_os
    from thonny.plugins.pgzero_mode import update_environment

    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_default(_OPTION_NAME, True)
    get_workbench().set_simple_mode(True)
    update_environment()
   

# Generated at 2022-06-18 09:42:41.959337
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    assert wb.get_option(_OPTION_NAME) == False
    load_plugin()
    assert wb.get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-18 09:42:45.297884
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    assert get_workbench().get_option(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-18 09:42:53.792016
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench
    from thonny.plugins.pgzero_mode import load_plugin
    from thonny.plugins.pgzero_mode import toggle_variable
    from thonny.plugins.pgzero_mode import update_environment
    from thonny.plugins.pgzero_mode import _OPTION_NAME
    from thonny.languages import tr
    from thonny.misc_utils import running_on_mac_os
    from thonny.workbench import Workbench
    from thonny.config import Configuration
    from thonny.config_ui import ConfigurationPage
    from thonny.shell import ShellTextWidget
    from thonny.globals import get_runner
    from thonny.running import SubprocessConnection
    from thonny.ui_utils import CommonDialog

# Generated at 2022-06-18 09:43:00.064389
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-18 09:43:07.706372
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.misc_utils import running_on_mac_os
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.globals import get_workbench
    from thonny.languages import tr
    from thonny.plugins.pgzero_mode import toggle_variable, update_environment
    from thonny.plugins.pgzero_mode import _OPTION_NAME
    from thonny.plugins.pgzero_mode import load_plugin

    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)

# Generated at 2022-06-18 09:43:16.523700
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from unittest.mock import Mock
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.ui_utils import CommonDialog
    from thonny.globals import get_workbench
    from thonny.languages import tr
    from thonny.misc_utils import running_on_mac_os
    from thonny.ui_utils import askopenfilename, askdirectory, askstring
    from thonny.ui_utils import show_dialog, show_dialog_and_get_value
    from thonny.ui_utils import show_message, show_warning, show_error
    from thonny.ui_utils import show_exception, show_info