

# Generated at 2022-06-18 09:33:32.840666
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench
    from thonny.misc_utils import running_on_mac_os
    from thonny.languages import tr

    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().set_simple_mode(False)
    update_environment()

# Generated at 2022-06-18 09:33:37.265581
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False


# Generated at 2022-06-18 09:33:44.340209
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()

    assert wb.get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"

    wb.set_option(_OPTION_NAME, True)
    update_environment()

    assert wb.get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-18 09:33:52.295232
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    wb.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-18 09:34:02.146365
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import Mock
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run import RunConfigurationPage
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunCommand
    from thonny.plugins.run import RunBackend
    from thonny.plugins.run import RunEventHandler
    from thonny.plugins.run import RunProgramDialog
    from thonny.plugins.run import RunScriptDialog
    from thonny.plugins.run import RunModuleDialog
    from thonny.plugins.run import RunSelectionDialog
    from thonny.plugins.run import RunCurrentScriptCommand

# Generated at 2022-06-18 09:34:11.853808
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench
    from thonny.misc_utils import running_on_mac_os
    from thonny.languages import tr
    from thonny.workbench import Workbench

    wb = Workbench()
    load_plugin()

    assert wb.get_option(_OPTION_NAME) == False
    assert wb.get_variable(_OPTION_NAME).get() == False
    assert wb.get_variable(_OPTION_NAME).get_label() == tr("Pygame Zero mode")
    assert wb.get_variable(_OPTION_NAME).get_help() == tr("Pygame Zero mode")
    assert wb.get_variable(_OPTION_NAME).get_category() == "run"
    assert wb.get_variable(_OPTION_NAME).get_group() == 40

# Generated at 2022-06-18 09:34:15.311297
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-18 09:34:25.348295
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.misc_utils import running_on_mac_os
    from thonny.plugins.cpython import CPythonProxy
    import os
    import shutil
    import tempfile
    import unittest

    class Test(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.config_dir = os.path.join(self.temp_dir, "config")
            os.makedirs(self.config_dir)
            self.orig_config_dir = get_config_dir()
            self.orig_simple_mode = get_workbench().in_simple_mode

# Generated at 2022-06-18 09:34:36.561980
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.languages import tr
    from thonny.misc_utils import running_on_mac_os
    from thonny.plugins.run import _OPTION_NAME
    from thonny.plugins.run import toggle_variable
    from thonny.plugins.run import update_environment
    from thonny.plugins.run import load_plugin
    from thonny.plugins.run import _OPTION_NAME
    from thonny.plugins.run import toggle_variable
    from thonny.plugins.run import update_environment
    from thonny.plugins.run import load_plugin
    from thonny.plugins.run import _OPTION_NAME
   

# Generated at 2022-06-18 09:34:47.694969
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.misc_utils import running_on_mac_os
    from thonny.plugins.micropython import MicroPythonProxy
    from thonny.plugins.micropython.micropython_proxy import MicroPythonProxy
    from thonny.plugins.micropython.micropython_proxy import MicroPythonProxy
    from thonny.plugins.micropython.micropython_proxy import MicroPythonProxy
    from thonny.plugins.micropython.micropython_proxy import MicroPythonProxy
    from thonny.plugins.micropython.micropython_proxy import MicroPythonProxy

# Generated at 2022-06-18 09:35:01.028966
# Unit test for function update_environment
def test_update_environment():
    from thonny.globals import get_workbench
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.misc_utils import running_on_mac_os
    from thonny.languages import EnglishLanguage
    from thonny.ui_utils import CommonDialog
    from thonny.plugins.backend_configuration import BackendConfigurationPage
    from thonny.plugins.backend_configuration import BackendConfigurationDialog
    from thonny.plugins.backend_configuration import BackendConfiguration
    from thonny.plugins.backend_configuration import BackendConfigurationDialog
    from thonny.plugins.backend_configuration import BackendConfiguration

# Generated at 2022-06-18 09:35:08.250257
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock
    from thonny import get_workbench

    wb = Mock()
    wb.in_simple_mode = Mock(return_value=False)
    wb.get_option = Mock(return_value=False)
    wb.set_default = Mock()
    wb.add_command = Mock()
    wb.get_variable = Mock()
    wb.get_variable.return_value.get = Mock(return_value=False)
    wb.get_variable.return_value.set = Mock()
    wb.get_variable.return_value.trace = Mock()
    wb.get_variable.return_value.trace_variable = Mock()

    get_workbench.return_value = wb

    load_plugin()

    wb.set_

# Generated at 2022-06-18 09:35:11.712183
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-18 09:35:16.137190
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-18 09:35:26.689570
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run import RunConfigurationPage
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunCommand
    from thonny.plugins.run import RunBackendEventHandler
    from thonny.plugins.run import RunBackendProxy
    from thonny.plugins.run import RunBackend
    from thonny.plugins.run import RunCommand
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunBackendEventHandler
    from thonny.plugins.run import RunBackendProxy
    from thonny.plugins.run import RunBackend
    from thonny.plugins.run import RunCommand

# Generated at 2022-06-18 09:35:30.731613
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-18 09:35:41.886968
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from unittest.mock import Mock
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run.run_config_page import RunConfigurationPage
    from thonny.plugins.run.run_command import RunCommand
    from thonny.plugins.run.run_debugger import RunDebugger
    from thonny.plugins.run.run_subprocess import RunSubprocess
    from thonny.plugins.run.run_file import RunFile
    from thonny.plugins.run.run_module import RunModule
    from thonny.plugins.run.run_selection import RunSelection
    from thonny.plugins.run.run_current_script import RunCurrentScript

# Generated at 2022-06-18 09:35:52.688320
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.misc_utils import running_on_mac_os
    from thonny.globals import get_workbench
    from thonny.languages import tr
    import os
    import shutil
    import tempfile
    import unittest
    import sys

    class Test(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.config_dir = os.path.join(self.temp_dir, ".thonny")
            os.mkdir(self.config_dir)
            self.orig_config_dir = get_config_dir()

# Generated at 2022-06-18 09:36:03.201650
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from unittest.mock import Mock
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from tkinter import Tk
    from thonny.globals import get_runner
    from thonny.plugins.run import RunConfigurationPage
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunCommand
    from thonny.plugins.run import RunBackendEventHandler
    from thonny.plugins.run import RunProgram
    from thonny.plugins.run import RunProgramThread
    from thonny.plugins.run import RunProgramDialog
    from thonny.plugins.run import RunProgramDialog
    from thonny.plugins.run import RunProgramDialog
   

# Generated at 2022-06-18 09:36:07.135100
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-18 09:36:24.353453
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.misc_utils import running_on_mac_os
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.globals import get_workbench
    from thonny.languages import tr
    from thonny.plugins.backend_configuration import BackendConfigurationPage
    from thonny.plugins.backend_configuration import BackendConfigurationDialog
    from thonny.plugins.backend_configuration import BackendConfigurationDialog
    from thonny.plugins.backend_configuration import BackendConfigurationDialog
    from thonny.plugins.backend_configuration import BackendConfigurationDialog
    from thonny.plugins.backend_configuration import BackendConfigurationDialog

# Generated at 2022-06-18 09:36:28.729295
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-18 09:36:37.162410
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_default = Mock()
    wb.add_command = Mock()
    load_plugin()
    assert wb.set_default.call_args[0] == (_OPTION_NAME, False)

# Generated at 2022-06-18 09:36:46.259975
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.config import Configuration
    from thonny.config_ui import ConfigurationPage
    from thonny.misc_utils import running_on_mac_os

    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()
    assert wb.get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()

# Generated at 2022-06-18 09:36:50.882646
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == True
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == False

# Generated at 2022-06-18 09:37:01.090917
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench
    from thonny.misc_utils import running_on_mac_os
    from thonny.languages import tr
    from thonny.plugins.pgzero_mode import update_environment
    from thonny.plugins.pgzero_mode import _OPTION_NAME
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.globals import get_runner
    from thonny.running import SubprocessConnection
    from thonny.tktextext import TextFrame
    from thonny.ui_utils import CommonDialog
    from thonny.ui_utils import askopenfilename
    from thonny.ui_utils import askopenfilenames

# Generated at 2022-06-18 09:37:13.170415
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.misc_utils import running_on_mac_os, running_on_windows
    from thonny.globals import get_workbench
    from thonny import THONNY_USER_DIR
    from thonny.languages import EnglishLanguage
    from thonny.ui_utils import CommonDialog
    from thonny.ui_utils import askstring
    from thonny.ui_utils import askinteger
    from thonny.ui_utils import askfloat
    from thonny.ui_utils import askopenfilename
    from thonny.ui_utils import asksaveasfilename
    from thonny.ui_utils import askdirectory
   

# Generated at 2022-06-18 09:37:17.604679
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    import os
    import shutil
    import tempfile
    import unittest

    class TestWorkbench(Workbench):
        def __init__(self):
            self._variables = {}

        def get_variable(self, name):
            return self._variables[name]

        def set_default(self, name, value):
            self._variables[name] = value

        def in_simple_mode(self):
            return False

        def get_option(self, name):
            return self._variables[name]


# Generated at 2022-06-18 09:37:20.820100
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-18 09:37:33.251628
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.misc_utils import running_on_mac_os, running_on_windows
    from thonny.languages import english
    from thonny.languages import french
    from thonny.languages import spanish
    from thonny.languages import german
    from thonny.languages import russian
    from thonny.languages import dutch
    from thonny.languages import italian
    from thonny.languages import portuguese
    from thonny.languages import polish
    from thonny.languages import chinese_simplified
    from thonny.languages import chinese_traditional
    from thonny.languages import japanese


# Generated at 2022-06-18 09:37:54.872345
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run import RunConfigurationPage
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunCommand
    from thonny.plugins.run import RunBackend
    from thonny.plugins.run import RunEventHandler
    from thonny.plugins.run import RunCommand
    from thonny.plugins.run import RunBackend
    from thonny.plugins.run import RunEventHandler
    from thonny.plugins.run import RunCommand
    from thonny.plugins.run import RunBackend
    from thonny.plugins.run import RunEventHandler
    from thonny.plugins.run import RunCommand
    from thonny.plugins.run import Run

# Generated at 2022-06-18 09:38:06.044083
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import Mock
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.config_ui import ConfigurationDialog
    from thonny.plugins.run import RunConfigurationPage
    from thonny.plugins.run import RunConfigurationDialog
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunCommand
    from thonny.plugins.run import RunBackendEventHandler
    from thonny.plugins.run import RunEventHandler
    from thonny.plugins.run import RunDebuggerEventHandler
    from thonny.plugins.run import RunDebuggerView
    from thonny.plugins.run import RunDebuggerCommand

# Generated at 2022-06-18 09:38:15.254407
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import Mock
    from thonny.globals import get_workbench
    get_workbench().in_simple_mode = Mock(return_value=True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().in_simple_mode = Mock(return_value=False)
    get_workbench().get_option = Mock(return_value=True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().get_option = Mock(return_value=False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-18 09:38:25.295546
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.globals import get_workbench
    from thonny.misc_utils import running_on_mac_os
    from thonny.ui_utils import askopenfilename
    from thonny.ui_utils import askopenfilenames
    from thonny.ui_utils import askdirectory
    from thonny.ui_utils import askyesno
    from thonny.ui_utils import showerror
    from thonny.ui_utils import showinfo
    from thonny.ui_utils import showwarning
    from thonny.ui_utils import show_dialog
    from thonny.ui_utils import show_message

# Generated at 2022-06-18 09:38:32.562993
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.misc_utils import running_on_mac_os
    from thonny.globals import get_runner
    from thonny.plugins.backend_configuration import BackendConfigurationPage
    from thonny.plugins.backend_configuration import BackendConfigurationDialog
    from thonny.plugins.backend_configuration import BackendConfigurationCommand
    from thonny.plugins.backend_configuration import BackendConfigurationDialog
    from thonny.plugins.backend_configuration import BackendConfigurationDialog
    from thonny.plugins.backend_configuration import BackendConfigurationDialog

# Generated at 2022-06-18 09:38:38.235452
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run.run_config_page import RunConfigurationPage
    from thonny.plugins.run.run_command import RunConfigurationDialog
    from thonny.languages import tr
    from thonny.misc_utils import running_on_mac_os
    from thonny.globals import get_workbench
    from thonny.config import get_runner
    from thonny.plugins.run.run_command import RunCommand
    from thonny.plugins.run.run_subprocess import RunSubprocess
    from thonny.plugins.run.run_file import RunFile
    from thonny.plugins.run.run_module import RunModule

# Generated at 2022-06-18 09:38:48.918031
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config import Configuration
    from thonny.config_ui import ConfigurationPage
    from thonny.misc_utils import running_on_mac_os

    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    wb.set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    wb.set_option(_OPTION_NAME, True)
    wb.set_simple_mode(True)
    update_environment()

# Generated at 2022-06-18 09:38:53.910023
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-18 09:39:04.703618
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench
    from thonny.languages import tr
    from thonny.misc_utils import running_on_mac_os
    from thonny.workbench import Workbench
    from thonny.plugins.run import RunViewText
    from thonny.plugins.run import RunViewText
    from thonny.plugins.run import RunViewText
    from thonny.plugins.run import RunViewText
    from thonny.plugins.run import RunViewText
    from thonny.plugins.run import RunViewText
    from thonny.plugins.run import RunViewText
    from thonny.plugins.run import RunViewText
    from thonny.plugins.run import RunViewText
    from thonny.plugins.run import RunViewText

# Generated at 2022-06-18 09:39:08.350483
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-18 09:39:38.016447
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import Mock
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.set_option(_OPTION_NAME, True)
    wb.in_simple_mode = Mock(return_value=False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    wb.in_simple_mode = Mock(return_value=True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-18 09:39:44.169521
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()
    assert wb.get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-18 09:39:47.827617
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-18 09:39:56.278520
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from unittest.mock import Mock
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.globals import get_workbench
    from thonny.plugins.run import RunConfigurationPage
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunViewUpdater
    from thonny.plugins.run import RunViewUpdaterThread
    from thonny.plugins.run import RunViewUpdaterThread
    from thonny.plugins.run import RunViewUpdaterThread
    from thonny.plugins.run import RunViewUpdaterThread
    from thonny.plugins.run import RunViewUpdaterThread

# Generated at 2022-06-18 09:40:03.060863
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench

    wb = Workbench()
    load_plugin()
    assert wb.get_option(_OPTION_NAME) == False
    assert wb.get_variable(_OPTION_NAME) != None
    assert wb.get_command("toggle_pgzero_mode") != None
    assert os.environ["PGZERO_MODE"] == "False"
    wb.set_option(_OPTION_NAME, True)
    assert os.environ["PGZERO_MODE"] == "True"
    wb.set_option(_OPTION_NAME, False)
    assert os.environ["PGZERO_MODE"] == "False"
    wb.set_simple_mode(True)
    assert os.environ["PGZERO_MODE"] == "auto"
    wb

# Generated at 2022-06-18 09:40:10.664921
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-18 09:40:20.327763
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import Mock
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.set_simple_mode(False)
    wb.set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    wb.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-18 09:40:30.153170
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench

    wb = Workbench()
    load_plugin()
    assert wb.get_variable(_OPTION_NAME) == False
    assert wb.get_option(_OPTION_NAME) == False
    assert wb.get_command("toggle_pgzero_mode")
    assert wb.get_command("toggle_pgzero_mode").flag_name == _OPTION_NAME
    assert wb.get_command("toggle_pgzero_mode").group == 40
    assert os.environ["PGZERO_MODE"] == "False"

    wb.set_option(_OPTION_NAME, True)
    assert wb.get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"

    wb.set_simple

# Generated at 2022-06-18 09:40:39.964872
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench, get_runner
    from thonny.plugins.run import RunCommand
    from thonny.languages import tr
    from thonny.misc_utils import running_on_mac_os
    from thonny.config import get_workbench_configuration
    from thonny.config_ui import ConfigurationPage
    import os
    import sys
    import unittest
    from unittest.mock import patch

    class Test(unittest.TestCase):
        def setUp(self):
            if sys.platform == "darwin":
                self.assertTrue(running_on_mac_os())
            else:
                self.assertFalse(running_on_mac_os())
            self.orig_getcwd = os.getcwd

# Generated at 2022-06-18 09:40:44.218394
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-18 09:41:44.855776
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    import os
    import shutil
    import tempfile
    import unittest

    class Test(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.config_dir = os.path.join(self.temp_dir, "config")
            os.mkdir(self.config_dir)
            os.environ["THONNY_USER_DIR"] = self.config_dir

        def tearDown(self):
            shutil.rmtree(self.temp_dir)

        def test_update_environment(self):
            wb = Workbench()
            wb.set_default(_OPTION_NAME, False)
            update_

# Generated at 2022-06-18 09:41:47.868703
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    assert get_workbench().get_option(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-18 09:41:59.039713
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench
    from thonny.misc_utils import running_on_mac_os, running_on_windows
    from thonny.languages import tr
    from thonny.plugins.pgzero_mode import load_plugin, update_environment
    from thonny.workbench import Workbench
    from unittest.mock import MagicMock
    from unittest.mock import patch
    from thonny.config import get_workbench_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.pgzero_mode import toggle_variable
    from thonny.ui_utils import askopenfilename
    from thonny.ui_utils import askdirectory
    from thonny.ui_utils import askstring

# Generated at 2022-06-18 09:42:06.394518
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.misc_utils import running_on_mac_os
    from unittest.mock import patch

    wb = Workbench()
    wb.set_default(_OPTION_NAME, True)
    wb.set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    wb.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    wb.set_simple_mode(False)
    wb.set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    # Test that PGZERO

# Generated at 2022-06-18 09:42:13.191549
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench
    from thonny.workbench import Workbench
    from thonny.misc_utils import running_on_mac_os
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    import os
    import shutil
    import tempfile

    # Create temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create temporary config directory
    config_dir = os.path.join(temp_dir, ".thonny")
    os.mkdir(config_dir)

    # Create temporary config file
    config_file = os.path.join(config_dir, "config-v2.json")
    with open(config_file, "w") as fp:
        fp.write("{}")

    #

# Generated at 2022-06-18 09:42:21.670280
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.config import Configuration
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run import RunConfigurationPage
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunCommand
    from thonny.plugins.run import RunBackend
    from thonny.plugins.run import RunEventHandler
    from thonny.plugins.run import RunMenu
    from thonny.plugins.run import RunToolbar
    from thonny.plugins.run import RunToolbarButton
    from thonny.plugins.run import RunToolbarButtonGroup
    from thonny.plugins.run import RunToolbarButtonGroup
    from thonny.plugins.run import RunToolbarButtonGroup

# Generated at 2022-06-18 09:42:27.251915
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == True
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == False

# Generated at 2022-06-18 09:42:36.039826
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.workbench import Workbench
    from thonny.config import Configuration
    from thonny.config_ui import ConfigurationPage
    from thonny.globals import get_workbench
    from thonny.plugins.run import RunConfigurationPage
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunCommand
    from thonny.plugins.run import RunBackend
    from thonny.plugins.run import RunEventHandler
    from thonny.plugins.run import RunProgramDialog
    from thonny.plugins.run import RunScriptDialog
    from thonny.plugins.run import RunSelectionDialog
    from thonny.plugins.run import RunModuleDialog
    from thonny.plugins.run import RunCurrentScriptCommand

# Generated at 2022-06-18 09:42:44.501493
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = "auto"
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-18 09:42:51.758766
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()
    assert wb.get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"