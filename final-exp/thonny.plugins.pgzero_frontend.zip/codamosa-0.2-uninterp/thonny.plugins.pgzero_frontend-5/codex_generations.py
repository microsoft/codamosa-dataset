

# Generated at 2022-06-18 09:33:12.018780
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.misc_utils import running_on_mac_os

    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    wb.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    wb.set_simple_mode(False)
    wb.set_option(_OPTION_NAME, False)
    update_environment()

# Generated at 2022-06-18 09:33:22.707044
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench
    from thonny.plugins.pgzero_mode import _OPTION_NAME
    from thonny.languages import tr
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()
    assert wb.get_option(_OPTION_NAME) == False
    assert wb.get_variable(_OPTION_NAME).get() == False
    assert wb.get_variable(_OPTION_NAME).get() == False
   

# Generated at 2022-06-18 09:33:34.087147
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"

# Generated at 2022-06-18 09:33:42.537543
# Unit test for function update_environment
def test_update_environment():
    from thonny.globals import get_workbench
    from thonny.misc_utils import running_on_mac_os
    from thonny.languages import tr

    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    wb.set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    wb.set_default(_OPTION_NAME, False)
    wb.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"


# Generated at 2022-06-18 09:33:52.042025
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_default = Mock()
    wb.add_command = Mock()
    wb.in_simple_mode = Mock(return_value=False)
    wb.get_option = Mock(return_value=True)
    load_plugin()
    assert wb.set_default.call_count == 1
    assert wb.add_command.call_count == 1
    assert os.environ["PGZERO_MODE"] == "True"
    wb.in_simple_mode.return_value = True
    load_plugin()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-18 09:34:01.860853
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import Mock
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir

    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    wb.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    wb.set_simple_mode(False)
    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-18 09:34:11.587142
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.config_ui import ConfigurationPage
    from thonny.misc_utils import running_on_mac_os
    from thonny.globals import get_workbench
    from thonny.plugins.run.run_commands import RunCommand
    from thonny.plugins.run.run_subprocess import RunSubprocess
    from thonny.plugins.run.run_pgzero_mode import _OPTION_NAME
    from thonny.plugins.run.run_pgzero_mode import toggle_variable
    from thonny.plugins.run.run_pgzero_mode import update_environment
    from thonny.plugins.run.run_pgzero_mode import load_plugin
    from thonny.plugins.run.run_pgzero_mode import test

# Generated at 2022-06-18 09:34:21.066394
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run import RunConfigurationPage
    from thonny.languages import EnglishConfigPage
    from thonny.ui_utils import CommonDialog
    from thonny.globals import get_workbench
    from thonny.misc_utils import running_on_mac_os
    from thonny.tktextext import TextFrame
    from thonny.codeview import CodeViewText
    from thonny.ui_utils import SubprocessDialog
    from thonny.ui_utils import CommonDialog
    from thonny.ui_utils import SelectableLabel
    from thonny.ui_utils import ScrollableTreeview

# Generated at 2022-06-18 09:34:28.637822
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-18 09:34:39.685050
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import Mock
    from thonny.workbench import Workbench

    workbench = Workbench()
    workbench.set_default(_OPTION_NAME, False)
    workbench.get_variable = Mock(return_value=False)
    workbench.in_simple_mode = Mock(return_value=False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    workbench.get_variable = Mock(return_value=True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    workbench.in_simple_mode = Mock(return_value=True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-18 09:34:46.802512
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-18 09:34:58.245584
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run import RunConfigurationPage
    from thonny.languages import tr
    from thonny.misc_utils import running_on_mac_os
    from thonny.globals import get_workbench
    from thonny.globals import get_runner
    from thonny.globals import get_shell
    from thonny.globals import get_workbench
    from thonny.globals import get_runner
    from thonny.globals import get_shell
    from thonny.globals import get_workbench
    from thonny.globals import get_runner
    from thonny.globals import get_shell

# Generated at 2022-06-18 09:35:06.589044
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run import RunConfigurationPage
    from thonny.languages import tr
    from thonny.misc_utils import running_on_mac_os
    import os
    import shutil
    import sys
    import tkinter as tk

    # Create a temporary directory
    temp_dir = os.path.join(get_config_dir(), "thonny-test-run-plugin")
    if os.path.exists(temp_dir):
        shutil.rmtree(temp_dir)
    os.makedirs(temp_dir)

    # Create a temporary workbench
   

# Generated at 2022-06-18 09:35:12.199566
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    assert get_workbench().get_option(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-18 09:35:15.813928
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-18 09:35:26.344541
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from unittest.mock import Mock
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run import RunConfigurationPage
    from thonny.languages import EnglishLanguage
    from thonny.misc_utils import running_on_mac_os, running_on_windows

    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.add_command = Mock()
    wb.get_variable = Mock(return_value=False)
    wb.get_option = Mock(return_value=False)
    wb.in_simple_mode = Mock(return_value=False)

# Generated at 2022-06-18 09:35:37.458116
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.config import Configuration
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run import RunView
    from thonny.languages import tr

    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()
    assert wb.get_option(_OPTION_NAME) == False
    assert wb.get_variable(_OPTION_NAME).get() == False

# Generated at 2022-06-18 09:35:45.305196
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-18 09:35:56.548534
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench
    from thonny.misc_utils import running_on_mac_os
    from thonny.languages import tr
    from thonny.workbench import Workbench
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run.run_config_page import RunConfigurationPage
    from thonny.plugins.run.run_command import RunCommand
    from thonny.plugins.run.run_debugger import RunDebugger
    from thonny.plugins.run.run_subprocess import RunSubprocess
    from thonny.plugins.run.run_file import RunFile
    from thonny.plugins.run.run_module import RunModule
    from thonny.plugins.run.run_selection import RunSelection

# Generated at 2022-06-18 09:36:05.927770
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from unittest.mock import patch
    import os
    import sys

    with patch.object(sys, "argv", ["thonny"]):
        wb = Workbench()
        wb.set_default(_OPTION_NAME, False)
        update_environment()
        assert os.environ["PGZERO_MODE"] == "False"
        wb.set_option(_OPTION_NAME, True)
        update_environment()
        assert os.environ["PGZERO_MODE"] == "True"
        wb.set_simple_mode(True)
        update_environment()
        assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-18 09:36:23.483721
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    import os
    import shutil
    import tempfile
    import unittest

    class Test(unittest.TestCase):
        def setUp(self):
            self.orig_config_dir = get_config_dir()
            self.temp_dir = tempfile.mkdtemp()
            os.environ["THONNY_USER_DIR"] = self.temp_dir
            self.orig_simple_mode = Workbench.in_simple_mode
            Workbench.in_simple_mode = lambda self: False
            self.orig_get_option = Workbench.get_option
            Workbench.get_option = lambda self, name: False


# Generated at 2022-06-18 09:36:28.946978
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_default = Mock()
    wb.add_command = Mock()
    load_plugin()
    assert wb.set_default.call_count == 1
    assert wb.add_command.call_count == 1

# Generated at 2022-06-18 09:36:32.768533
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-18 09:36:41.829362
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench

    wb = Workbench()
    load_plugin()
    assert wb.get_variable(_OPTION_NAME).get() == False
    assert wb.get_option(_OPTION_NAME) == False
    assert wb.get_command("toggle_pgzero_mode")
    assert wb.get_command("toggle_pgzero_mode").flag_name == _OPTION_NAME
    assert wb.get_command("toggle_pgzero_mode").group == 40
    assert os.environ["PGZERO_MODE"] == "False"
    wb.get_command("toggle_pgzero_mode")()
    assert wb.get_variable(_OPTION_NAME).get() == True
    assert wb.get_option(_OPTION_NAME) == True
    assert os

# Generated at 2022-06-18 09:36:52.632026
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.misc_utils import running_on_mac_os, running_on_windows

    wb = Workbench()
    wb.set_default(_OPTION_NAME, True)
    wb.set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    wb.set_default(_OPTION_NAME, False)
    wb.set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    wb.set_default(_OPTION_NAME, True)
    wb.set_simple_mode(True)
    update_environment()


# Generated at 2022-06-18 09:37:02.400419
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.misc_utils import running_on_mac_os, running_on_windows
    from thonny.globals import get_workbench
    from thonny.plugins.run import RunViewText
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunViewText
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunViewText
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunViewText
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunViewText

# Generated at 2022-06-18 09:37:10.999078
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    wb.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-18 09:37:17.251508
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-18 09:37:24.836311
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench
    from thonny.plugins.pgzero_mode import load_plugin
    from thonny.languages import tr
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert get_workbench().get_variable(_OPTION_NAME) == False
    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    assert get_workbench().get_variable(_OPTION_NAME).get

# Generated at 2022-06-18 09:37:35.538278
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench
    from thonny.workbench import Workbench
    from thonny.config import Configuration
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run import RunConfigurationPage
    from thonny.languages import tr
    from thonny.misc_utils import running_on_mac_os
    from thonny.ui_utils import CommonDialog
    from thonny.ui_utils import askstring
    from thonny.ui_utils import askopenfilename
    from thonny.ui_utils import askdirectory
    from thonny.ui_utils import askcolor
    from thonny.ui_utils import askopenfilenames
    from thonny.ui_utils import showerror
    from thonny.ui_utils import showinfo

# Generated at 2022-06-18 09:37:51.415546
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-18 09:38:01.885250
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_default = Mock()
    wb.add_command = Mock()
    wb.in_simple_mode = Mock(return_value=False)
    wb.get_option = Mock(return_value=False)

    load_plugin()
    wb.set_default.assert_called_once_with(_OPTION_NAME, False)
    wb.add_command.assert_called_once()
    assert wb.add_command.call_args[0][0] == "toggle_pgzero_mode"
    assert wb.add_command.call_args[0][1] == "run"

# Generated at 2022-06-18 09:38:10.594176
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = "auto"
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-18 09:38:21.614173
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.config import Configuration
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run import RunConfigurationPage
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunCommand
    from thonny.plugins.run import RunBackend
    from thonny.plugins.run import RunEventHandler
    from thonny.plugins.run import RunMenu
    from thonny.plugins.run import RunCommand
    from thonny.plugins.run import RunBackend
    from thonny.plugins.run import RunEventHandler
    from thonny.plugins.run import RunMenu
    from thonny.plugins.run import RunCommand
    from thonny.plugins.run import RunBackend

# Generated at 2022-06-18 09:38:27.672714
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.misc_utils import running_on_mac_os
    from thonny.config_ui import ConfigurationPage
    from unittest.mock import Mock
    from tkinter import Tk
    from thonny.globals import get_workbench
    from thonny.languages import tr
    import os

    root = Tk()
    root.withdraw()
    wb = Workbench(root)
    wb.set_default(_OPTION_NAME, False)
    wb.add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    wb.set_

# Generated at 2022-06-18 09:38:36.028674
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.misc_utils import running_on_mac_os
    from thonny.globals import get_workbench
    from thonny.languages import tr

    # Create a workbench to test
    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )

    # Test the default value

# Generated at 2022-06-18 09:38:46.437832
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench
    from thonny.workbench import Workbench
    from thonny.languages import tr
    from thonny.misc_utils import running_on_mac_os
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.pgzero_mode import _OPTION_NAME
    from thonny.plugins.pgzero_mode import toggle_variable
    from thonny.plugins.pgzero_mode import update_environment
    from thonny.plugins.pgzero_mode import load_plugin
    import os
    import tkinter as tk
    import tkinter.ttk as ttk
    import unittest
    import unittest.mock


# Generated at 2022-06-18 09:38:49.765824
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-18 09:38:57.075746
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-18 09:39:04.744565
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    wb.set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    wb.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-18 09:39:34.413223
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from unittest.mock import Mock
    from thonny.config import Configuration
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run import RunConfigurationPage
    from thonny.languages import tr
    from thonny.misc_utils import running_on_mac_os
    from thonny.shell import ShellTextWidget
    from thonny.globals import get_runner
    from thonny.ui_utils import CommonDialog
    from thonny.ui_utils import SubprocessDialog
    from thonny.ui_utils import askopenfilename
    from thonny.ui_utils import askdirectory
    from thonny.ui_utils import askopenfilenames
    from thonny.ui_utils import askyesno


# Generated at 2022-06-18 09:39:42.185017
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run import RunConfigurationPage
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunCommand
    from thonny.plugins.run import RunBackend
    from thonny.plugins.run import RunEventHandler
    from thonny.plugins.run import RunDebugger
    from thonny.plugins.run import RunDebuggerEventHandler
    from thonny.plugins.run import RunDebuggerView
    from thonny.plugins.run import RunDebuggerCommand
    from thonny.plugins.run import RunDebuggerBackend
    from thonny.plugins.run import RunDebuggerEventHandler
    from thonny.plugins.run import RunDebuggerView

# Generated at 2022-06-18 09:39:50.004921
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    wb.set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    wb.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-18 09:39:58.557755
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench

    wb = Workbench()
    load_plugin()
    assert wb.get_variable(_OPTION_NAME).get() is False
    assert wb.get_option(_OPTION_NAME) is False
    assert os.environ["PGZERO_MODE"] == "False"

    wb.set_option(_OPTION_NAME, True)
    assert wb.get_variable(_OPTION_NAME).get() is True
    assert wb.get_option(_OPTION_NAME) is True
    assert os.environ["PGZERO_MODE"] == "True"

    wb.set_simple_mode(True)
    assert wb.get_variable(_OPTION_NAME).get() is True
    assert wb.get_option(_OPTION_NAME) is True


# Generated at 2022-06-18 09:40:03.861392
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock
    from thonny import get_workbench

    get_workbench().set_default = Mock()
    get_workbench().add_command = Mock()
    load_plugin()
    get_workbench().set_default.assert_called_once_with(_OPTION_NAME, False)
    get_workbench().add_command.assert_called_once()
    get_workbench().add_command.assert_called_with(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )



# Generated at 2022-06-18 09:40:13.064056
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench
    from thonny.misc_utils import running_on_mac_os
    from thonny.misc_utils import running_on_windows

    # Test 1: in simple mode, PGZERO_MODE should be auto
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    # Test 2: in normal mode, PGZERO_MODE should be the value of the option
    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    # Test 3: in normal mode, PGZERO_MODE should be the value

# Generated at 2022-06-18 09:40:24.000923
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.misc_utils import running_on_mac_os
    from unittest.mock import patch

    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    wb.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    wb.set_simple_mode(False)
    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    # Test that PGZERO

# Generated at 2022-06-18 09:40:32.739487
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench

    wb = Workbench()
    load_plugin()
    assert wb.get_variable(_OPTION_NAME) == False
    assert wb.get_option(_OPTION_NAME) == False
    assert wb.get_command("toggle_pgzero_mode")
    assert os.environ["PGZERO_MODE"] == "False"

    toggle_variable()
    assert wb.get_variable(_OPTION_NAME) == True
    assert wb.get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"

    wb.in_simple_mode = lambda: True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-18 09:40:37.274074
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == True
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == False

# Generated at 2022-06-18 09:40:44.483541
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench

    wb = Workbench()
    load_plugin()
    assert wb.get_option(_OPTION_NAME) == False
    assert wb.get_variable(_OPTION_NAME) != None
    assert wb.get_command("toggle_pgzero_mode") != None
    assert os.environ["PGZERO_MODE"] == "False"
    wb.destroy()


# Generated at 2022-06-18 09:41:44.783176
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from unittest.mock import Mock
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run import RunConfigurationPage
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunCommand
    from thonny.plugins.run import RunBackend
    from thonny.plugins.run import RunEventHandler
    from thonny.plugins.run import RunInterpreter
    from thonny.plugins.run import RunInterpreterProxy
    from thonny.plugins.run import RunInterpreterProxy2
    from thonny.plugins.run import RunInterpreterProxy3
    from thonny.plugins.run import RunInterpreterProxy4

# Generated at 2022-06-18 09:41:54.854172
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench
    from thonny.misc_utils import running_on_mac_os
    from thonny.languages import tr
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run import RunConfigurationPage
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunCommand
    from thonny.plugins.run import RunBackend
    from thonny.plugins.run import RunEventHandler
    from thonny.plugins.run import RunDebugger
    from thonny.plugins.run import RunDebuggerEventHandler
    from thonny.plugins.run import RunDebuggerView

# Generated at 2022-06-18 09:42:03.101124
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run import RunConfigurationPage
    from thonny.languages import EnglishLanguage
    from thonny.misc_utils import running_on_windows
    from thonny.tktextext import TextFrame
    from thonny.ui_utils import CommonDialog
    from thonny.ui_utils import SubprocessDialog
    from thonny.ui_utils import select_sequence
    from thonny.ui_utils import select_variable
    from thonny.ui_utils import show_dialog
    from thonny.ui_utils import show_dialog_for_config_page
    from thonny.ui_utils import show_dialog

# Generated at 2022-06-18 09:42:09.816496
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run import RunConfigurationPage
    from thonny.languages import tr
    from thonny.misc_utils import running_on_mac_os
    from thonny.globals import get_workbench
    from thonny.globals import get_runner
    from thonny.globals import get_shell
    from thonny.globals import get_workbench
    from thonny.globals import get_runner
    from thonny.globals import get_shell
    from thonny.globals import get_workbench
    from thonny.globals import get_runner
    from thonny.globals import get_shell

# Generated at 2022-06-18 09:42:19.688611
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.globals import get_workbench
    from thonny.misc_utils import running_on_mac_os
    from thonny.plugins.run import RunConfigurationPage
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunViewUpdater
    from thonny.plugins.run import RunViewUpdater
    from thonny.plugins.run import RunViewUpdater
    from thonny.plugins.run import RunViewUpdater
    from thonny.plugins.run import RunViewUpdater
    from thonny.plugins.run import RunViewUpdater

# Generated at 2022-06-18 09:42:22.188555
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-18 09:42:29.070768
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    assert wb.get_variable(_OPTION_NAME).get() == False
    toggle_variable()
    assert wb.get_variable(_OPTION_NAME).get() == True
    toggle_variable()
    assert wb.get_variable(_OPTION_NAME).get() == False

# Generated at 2022-06-18 09:42:36.942522
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run import RunConfigurationPage
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunCommand
    from thonny.plugins.run import RunBackend
    from thonny.plugins.run import RunEventHandler
    from thonny.plugins.run import RunMenu
    from thonny.plugins.run import RunMenuUpdater
    from thonny.plugins.run import RunViewUpdater
    from thonny.plugins.run import RunViewEventHandler
    from thonny.plugins.run import RunViewMenuUpdater
    from thonny.plugins.run import RunViewMenu
    from thonny.plugins.run import RunViewMenuHandler


# Generated at 2022-06-18 09:42:45.047595
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.misc_utils import running_on_mac_os
    from thonny.plugins.run import RunConfigurationPage
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunCommand
    from thonny.plugins.run import RunBackendEventHandler
    from thonny.plugins.run import RunEventHandler
    from thonny.plugins.run import RunProgram
    from thonny.plugins.run import RunProgramDialog
    from thonny.plugins.run import RunSubprocessDialog
    from thonny.plugins.run import RunSubprocess
    from thonny.plugins.run import RunSubprocessEventHandler


# Generated at 2022-06-18 09:42:50.100946
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny import get_workbench
    from thonny.languages import tr
    from thonny.plugins.pgzero_mode import toggle_variable

    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False