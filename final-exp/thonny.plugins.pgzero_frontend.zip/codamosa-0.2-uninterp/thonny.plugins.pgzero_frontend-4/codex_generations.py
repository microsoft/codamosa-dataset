

# Generated at 2022-06-18 09:33:21.938278
# Unit test for function update_environment
def test_update_environment():
    from thonny.globals import get_workbench
    from thonny.workbench import Workbench
    from thonny.config_ui import ConfigurationPage
    from thonny.config import get_config_dir
    from thonny.misc_utils import running_on_mac_os
    from thonny.languages import EnglishLanguage
    from thonny.plugins.cpython import CPythonProxy
    from thonny.plugins.backend_config_page import BackendConfigurationPage
    from thonny.plugins.backend_config_page import BackendConfigurationDialog
    from thonny.plugins.backend_config_page import BackendConfigurationDialog
    from thonny.plugins.backend_config_page import BackendConfigurationDialog
    from thonny.plugins.backend_config_page import BackendConfigurationDialog


# Generated at 2022-06-18 09:33:25.490269
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-18 09:33:36.463935
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run import RunView
    from thonny.globals import get_runner
    from thonny.misc_utils import running_on_mac_os

    wb = Workbench()
    wb.create()
    wb.set_default(_OPTION_NAME, False)
    wb.add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()
    assert wb.get_variable(_OPTION_NAME).get() == False
    assert os.environ["PGZERO_MODE"]

# Generated at 2022-06-18 09:33:39.966006
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-18 09:33:51.172236
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import Mock
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run import RunConfigurationPage
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunCommand
    from thonny.plugins.run import RunBackendEventHandler
    from thonny.plugins.run import RunProgram
    from thonny.plugins.run import RunProgramDialog
    from thonny.plugins.run import RunSubprocessDialog
    from thonny.plugins.run import RunSubprocess
    from thonny.plugins.run import RunSubprocessEventHandler
    from thonny.plugins.run import RunSubprocessEventHandler

# Generated at 2022-06-18 09:34:01.160451
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run import RunConfigurationPage
    from thonny.languages import EnglishLanguage
    from thonny.misc_utils import running_on_mac_os
    from thonny.misc_utils import running_on_windows
    from thonny.misc_utils import running_on_linux

    wb = Workbench(configuration_page_classes=[ConfigurationPage, RunConfigurationPage])
    wb.set_default(_OPTION_NAME, False)
    wb.set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    wb.set_

# Generated at 2022-06-18 09:34:10.550018
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run import RunConfigurationPage
    from thonny.languages import english
    from thonny.misc_utils import running_on_mac_os
    from thonny import THONNY_USER_DIR
    from thonny.globals import get_workbench
    import os
    import shutil
    import sys
    import tkinter as tk
    import traceback

    # Create a new workbench and load the plugin
    wb = Workbench()
    wb.load_plugin("pgzero_mode")

    # Test the plugin
    assert wb.get_option(_OPTION_NAME) == False

# Generated at 2022-06-18 09:34:20.173763
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_default = Mock()
    wb.add_command = Mock()
    load_plugin()
    wb.set_default.assert_called_once_with(_OPTION_NAME, False)
    wb.add_command.assert_called_once()
    assert wb.add_command.call_args[0][0] == "toggle_pgzero_mode"
    assert wb.add_command.call_args[0][1] == "run"
    assert wb.add_command.call_args[0][2] == "Pygame Zero mode"
    assert wb.add_command.call_args[0][3] == toggle_variable

# Generated at 2022-06-18 09:34:30.822612
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.misc_utils import running_on_mac_os
    from thonny.globals import get_workbench
    from thonny.languages import tr
    from thonny.ui_utils import CommonDialog
    from thonny.ui_utils import askstring
    from thonny.ui_utils import askopenfilename
    from thonny.ui_utils import askdirectory
    from thonny.ui_utils import askinteger
    from thonny.ui_utils import askfloat
    from thonny.ui_utils import askcolor
    from thonny.ui_utils import askyesno

# Generated at 2022-06-18 09:34:42.145796
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench

    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_default(_OPTION_NAME, True)
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().set_simple_mode(True)
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-18 09:34:56.696844
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.globals import get_workbench
    from thonny.misc_utils import running_on_mac_os
    from thonny.plugins.backend_configuration import BackendConfigurationPage
    from thonny.plugins.cpython.configpage import CPythonConfigurationPage
    from thonny.plugins.micropython.configpage import MicroPythonConfigurationPage
    from thonny.plugins.pylint.config_page import PylintConfigurationPage
    from thonny.plugins.run import RunConfigurationPage
    from thonny.plugins.shell import ShellConfigurationPage
    from thonny.plugins.thonnyremote import ThonnyRemoteConfigurationPage

# Generated at 2022-06-18 09:35:02.306280
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == True
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == False

# Generated at 2022-06-18 09:35:09.849274
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.misc_utils import running_on_mac_os

    # Create a dummy workbench
    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.set_option(_OPTION_NAME, True)
    wb.in_simple_mode = lambda: False

    # Create a dummy config dir
    config_dir = get_config_dir()
    if running_on_mac_os():
        config_dir = os.path.join(config_dir, "Thonny")
    os.makedirs(config_dir)

    # Call the function
    update_environment()

    # Check the environment variable

# Generated at 2022-06-18 09:35:20.691341
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from unittest.mock import Mock
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunCommand
    from thonny.plugins.run import RunBackend
    from thonny.plugins.run import RunEventHandler
    from thonny.plugins.run import RunCommandHandler
    from thonny.plugins.run import RunViewUpdater
    from thonny.plugins.run import RunViewUpdater
    from thonny.plugins.run import RunViewUpdater
    from thonny.plugins.run import RunViewUpdater
    from thonny.plugins.run import RunViewUpdater
    from thonny.plugins.run import RunViewUpdater
    from thonny.plugins.run import RunView

# Generated at 2022-06-18 09:35:29.101263
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    wb.set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    wb.set_default(_OPTION_NAME, False)
    wb.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-18 09:35:39.894782
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_default = Mock()
    wb.add_command = Mock()
    load_plugin()
    wb.set_default.assert_called_once_with(_OPTION_NAME, False)
    wb.add_command.assert_called_once()
    assert wb.add_command.call_args[0][0] == "toggle_pgzero_mode"
    assert wb.add_command.call_args[1]["flag_name"] == _OPTION_NAME
    assert wb.add_command.call_args[1]["group"] == 40
    assert wb.add_command.call_args[1]["label"] == tr("Pygame Zero mode")

# Generated at 2022-06-18 09:35:47.618443
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-18 09:35:58.658555
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()
    assert wb.get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()

# Generated at 2022-06-18 09:36:09.148230
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config_ui import ConfigurationPage
    from thonny.misc_utils import running_on_mac_os
    from thonny.globals import get_workbench
    from thonny.plugins.run import RunConfigurationPage
    import os

    workbench = Workbench()
    workbench.set_default(_OPTION_NAME, False)
    workbench.set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    workbench.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    workbench.set_option(_OPTION_NAME, False)
    workbench

# Generated at 2022-06-18 09:36:14.260859
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.workbench import Workbench

    workbench = Workbench()
    workbench.set_default(_OPTION_NAME, False)
    assert workbench.get_option(_OPTION_NAME) == False
    toggle_variable()
    assert workbench.get_option(_OPTION_NAME) == True
    toggle_variable()
    assert workbench.get_option(_OPTION_NAME) == False

# Generated at 2022-06-18 09:36:28.733771
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.globals import get_workbench
    from thonny.plugins.pgzero_mode import toggle_variable

    wb = Workbench()
    wb.create()
    wb.show()
    wb.hide_variable_explorer()
    wb.hide_shell()
    wb.hide_editor()
    wb.hide_view("View")
    wb.hide_view("DebugView")
    wb.hide_view("ShellView")
    wb.hide_view("FileBrowser")
    wb.hide_view("VariableExplorerView")
    wb.hide_view("HelpView")
    wb

# Generated at 2022-06-18 09:36:38.995787
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run import RunConfigurationPage
    from thonny.languages import tr
    from thonny.misc_utils import running_on_mac_os
    from thonny.globals import get_workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationDialog
    from thonny.ui_utils import CommonDialog
    from thonny.ui_utils import askopenfilename
    from thonny.ui_utils import askdirectoryname
    from thonny.ui_utils import askstring
    from thonny.ui_utils import showwarning
    from thonny.ui_utils import showinfo

# Generated at 2022-06-18 09:36:49.225279
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run import RunConfigurationPage
    from thonny.languages import EnglishLanguage
    from thonny.misc_utils import running_on_mac_os
    from thonny import THONNY_USER_DIR
    from thonny.globals import get_workbench
    from thonny.misc_utils import running_on_windows
    from thonny.misc_utils import running_on_linux

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()
    os.environ["THONNY_USER_DIR"] = temp_dir
    os.environ["THONNY_HOME"] = temp_dir

# Generated at 2022-06-18 09:36:59.396164
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench
    from thonny.plugins.pgzero_mode import load_plugin
    from thonny.languages import tr
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    import os
    import shutil
    import tkinter as tk
    import unittest
    from unittest.mock import Mock

    class TestWorkbench(Workbench):
        def __init__(self):
            self._commands = []
            self._variables = {}
            self._defaults = {}
            self._option_defs = {}
            self._option_defs_by_name = {}
            self._option_defs_by_category = {}
            self._option_

# Generated at 2022-06-18 09:37:06.921993
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    wb.set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    wb.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-18 09:37:18.583706
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import Mock
    from thonny.config import Configuration
    from thonny.misc_utils import running_on_mac_os
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.set_option(_OPTION_NAME, True)
    wb.set_option("view.simple_mode", True)

    wb.set_option("view.simple_mode", False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    wb.set_option("view.simple_mode", True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-18 09:37:22.313091
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == True
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == False

# Generated at 2022-06-18 09:37:33.667429
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.misc_utils import running_on_windows
    from thonny.misc_utils import running_on_mac_os
    from thonny.misc_utils import running_on_linux
    from thonny.misc_utils import running_on_rpi
    from thonny.misc_utils import running_on_raspbian
    from thonny.misc_utils import running_on_debian
    from thonny.misc_utils import running_on_ubuntu
    from thonny.misc_utils import running_on_fedora
    from thonny.misc_utils import running_on_arch
    from thonny.misc_utils import running_on_manjaro

# Generated at 2022-06-18 09:37:40.432619
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.config_ui import ConfigurationPage
    from thonny.ui_utils import CommonDialog
    from thonny.globals import get_runner
    from thonny import THONNY_USER_DIR
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunCommand
    from thonny.plugins.run import RunBackend
    from thonny.plugins.run import RunEvent
    from thonny.plugins.run import RunEventHandler
    from thonny.plugins.run import RunEventHandler
    from thonny.plugins.run import RunEventHandler
    from thonny.plugins.run import RunEventHandler
    from thonny.plugins.run import RunEventHandler

# Generated at 2022-06-18 09:37:51.808670
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny import THONNY_USER_DIR
    from thonny.misc_utils import running_on_mac_os
    from thonny.languages import EnglishLanguage
    from thonny.globals import get_workbench
    from thonny.plugins.backend_configuration import BackendConfiguration
    from thonny.plugins.backend_configuration import BackendConfigurationDialog
    from thonny.plugins.backend_configuration import BackendConfigurationDialog
    from thonny.plugins.backend_configuration import BackendConfigurationDialog
    from thonny.plugins.backend_configuration import BackendConfigurationDialog
    from thonny.plugins.backend_configuration import BackendConfigurationDialog
   

# Generated at 2022-06-18 09:38:10.793192
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import Mock
    from thonny.config import Configuration
    from thonny.workbench import Workbench

    wb = Workbench(Configuration())
    wb.set_default(_OPTION_NAME, False)
    wb.get_option = Mock(return_value=True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    wb.in_simple_mode = Mock(return_value=True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-18 09:38:21.809579
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.globals import get_workbench
    from thonny.misc_utils import running_on_mac_os
    import os
    import shutil
    import sys
    import tkinter as tk
    import traceback
    from thonny.plugins.pgzero_mode import _OPTION_NAME


# Generated at 2022-06-18 09:38:28.331212
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench
    from thonny.plugins.pgzero_mode import load_plugin
    from thonny.languages import tr
    from thonny.workbench import Workbench
    from unittest.mock import Mock
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.config import ConfigurationDialog
    import os
    import shutil
    from thonny.ui_utils import CommonDialog
    from thonny.ui_utils import askstring
    from thonny.ui_utils import askopenfilename
    from thonny.ui_utils import askdirectory
    from thonny.ui_utils import askopenfilenames
    from thonny.ui_utils import asksaveasfilename

# Generated at 2022-06-18 09:38:36.094628
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.globals import get_workbench
    from thonny.misc_utils import running_on_mac_os
    from thonny.plugins.run import RunConfigurationPage
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunViewUpdater
    from thonny.plugins.run import RunViewUpdater
    from thonny.plugins.run import RunViewUpdater
    from thonny.plugins.run import RunViewUpdater
    from thonny.plugins.run import RunViewUpdater
    from thonny.plugins.run import RunViewUpdater

# Generated at 2022-06-18 09:38:39.653519
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-18 09:38:49.723244
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench
    from thonny.workbench import Workbench
    from thonny.config import Configuration
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run import RunConfigurationPage
    from thonny.languages import tr
    from thonny.misc_utils import running_on_mac_os
    from thonny.globals import get_runner
    from thonny.tktextext import TextFrame
    from thonny.plugins.backend import BackendEventLogger
    from thonny.plugins.backend_configuration import BackendConfigurationPage
    from thonny.plugins.backend_configuration import BackendConfigurationDialog
    from thonny.plugins.backend_configuration import BackendConfigurationDialog

# Generated at 2022-06-18 09:39:00.092425
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run import RunConfigurationPage

    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.create()
    wb.show_view("ShellView", {})
    wb.show_view("EditorView", {})
    wb.show_view("DebugView", {})
    wb.show_view("VariablesView", {})
    wb.show_view("ProgramView", {})
    wb.show_view("FileBrowserView", {})
    wb.show_view("ShellView", {})
    wb.show_view("ConfigurationView", {})
   

# Generated at 2022-06-18 09:39:03.777143
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    assert get_workbench().get_option(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-18 09:39:12.737201
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run import RunConfigurationPage
    from thonny.languages import EnglishLanguage
    from thonny.misc_utils import running_on_mac_os
    from thonny.globals import get_workbench
    from thonny.plugins.pgzero_mode import load_plugin
    from thonny.plugins.pgzero_mode import toggle_variable
    from thonny.plugins.pgzero_mode import update_environment
    from thonny.plugins.pgzero_mode import _OPTION_NAME
    from thonny.misc_utils import running_on_windows
    from thonny.misc_utils import running_on_linux

# Generated at 2022-06-18 09:39:21.574895
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config_ui import ConfigurationPage
    from thonny.misc_utils import running_on_mac_os
    from thonny.globals import get_runner
    from thonny.plugins.run import RunConfigurationPage
    from thonny.plugins.run import RunCommand
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunBackendEventHandler
    from thonny.plugins.run import RunBackend
    from thonny.plugins.run import RunEventHandler
    from thonny.plugins.run import RunViewEventHandler
    from thonny.plugins.run import RunViewUpdater
    from thonny.plugins.run import RunViewUpdaterEventHandler

# Generated at 2022-06-18 09:39:58.625344
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()
    assert wb.get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == False

# Generated at 2022-06-18 09:40:01.653947
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    assert get_workbench().get_option(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-18 09:40:10.803367
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench

    wb = Workbench()
    load_plugin()
    assert wb.get_option(_OPTION_NAME) == False
    assert wb.get_variable(_OPTION_NAME).get() == False
    assert wb.get_variable(_OPTION_NAME).get_label() == tr("Pygame Zero mode")
    assert wb.get_variable(_OPTION_NAME).get_help() == ""
    assert wb.get_variable(_OPTION_NAME).get_default() == False
    assert wb.get_variable(_OPTION_NAME).get_type() == bool
    assert wb.get_variable(_OPTION_NAME).get_category() == "run"
    assert wb.get_variable(_OPTION_NAME).get_group() == 40
    assert w

# Generated at 2022-06-18 09:40:21.110698
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench

    wb = Workbench()
    load_plugin()
    assert wb.get_option(_OPTION_NAME) == False
    assert wb.get_variable(_OPTION_NAME).get() == False
    assert wb.get_command("toggle_pgzero_mode")
    assert wb.get_command("toggle_pgzero_mode").flag_name == _OPTION_NAME
    assert wb.get_command("toggle_pgzero_mode").group == 40
    assert os.environ["PGZERO_MODE"] == "False"

    wb.set_option(_OPTION_NAME, True)
    assert wb.get_option(_OPTION_NAME) == True
    assert wb.get_variable(_OPTION_NAME).get() == True

# Generated at 2022-06-18 09:40:30.924628
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.globals import get_workbench
    from thonny.misc_utils import running_on_mac_os
    from thonny.tktextext import TextFrame
    from thonny.ui_utils import CommonDialog
    from thonny.ui_utils import SubprocessDialog
    from thonny.ui_utils import askopenfilename
    from thonny.ui_utils import askopenfilenames
    from thonny.ui_utils import askopenfile
    from thonny.ui_utils import asksaveasfilename
    from thonny.ui_utils import askdirectory
    from thonny.ui_utils import askinteger

# Generated at 2022-06-18 09:40:40.596786
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run import RunConfigurationPage
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunCommand
    from thonny.plugins.run import RunBackend
    from thonny.plugins.run import RunEventHandler
    from thonny.plugins.run import RunMenu
    from thonny.plugins.run import RunToolbar
    from thonny.plugins.run import RunDialog
    from thonny.plugins.run import RunDialogCommand
    from thonny.plugins.run import RunDialogEventHandler
    from thonny.plugins.run import RunDialogView

# Generated at 2022-06-18 09:40:51.549703
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.config import Configuration
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run import RunConfigurationPage
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunCommand
    from thonny.plugins.run import RunBackend
    from thonny.plugins.run import RunEventHandler
    from thonny.plugins.run import RunDebugger
    from thonny.plugins.run import RunInterpreter
    from thonny.plugins.run import RunInterpreterProxy
    from thonny.plugins.run import RunInterpreterProxyThread
    from thonny.plugins.run import RunInterpreterProxyProcess
    from thonny.plugins.run import RunInterpreterProxyProcess2

# Generated at 2022-06-18 09:41:01.890071
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_simple_mode(False)
    update_environment()

# Generated at 2022-06-18 09:41:10.270054
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.workbench import Workbench
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run import RunConfigurationPage
    from thonny.globals import get_workbench
    from tkinter import Tk
    from thonny.config import get_runner
    from thonny.plugins.run import RunConfigurationPage
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunCommand
    from thonny.plugins.run import RunBackendEventHandler
    from thonny.plugins.run import RunBackend
    from thonny.plugins.run import RunFrontendEventHandler
    from thonny.plugins.run import RunFrontend
    from thonny.plugins.run import RunProgram
    from thonny.plugins.run import Run

# Generated at 2022-06-18 09:41:18.494019
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.misc_utils import running_on_mac_os
    from thonny.plugins.run import RunConfigurationPage
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunCommand
    from thonny.plugins.run import RunBackend
    from thonny.plugins.run import RunEventHandler
    from thonny.plugins.run import RunProgram
    from thonny.plugins.run import RunProgramDialog
    from thonny.plugins.run import RunProgramDialog
    from thonny.plugins.run import RunProgramDialog
    from thonny.plugins.run import RunProgramDialog

# Generated at 2022-06-18 09:42:20.622708
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.misc_utils import running_on_mac_os, running_on_windows
    from thonny.globals import get_workbench
    from thonny.languages import tr
    from thonny.plugins.run import RunViewText
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunViewText
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunViewText
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunViewText
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunViewText
    from thonny.plugins.run import RunView

# Generated at 2022-06-18 09:42:31.549253
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run import RunConfigurationPage
    from thonny.languages import tr
    from thonny.misc_utils import running_on_mac_os
    from thonny.globals import get_workbench
    from thonny.config import get_config_dir
    import os
    import shutil
    import sys
    import tkinter as tk
    import unittest

    class Test(unittest.TestCase):
        def setUp(self):
            self.orig_config_dir = get_config_dir()
            self.config_dir = "test_config"

# Generated at 2022-06-18 09:42:36.356720
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()
    assert wb.get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-18 09:42:44.822547
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench
    from thonny.languages import tr
    from thonny.plugins.run.pgzero_mode import load_plugin
    from thonny.plugins.run.pgzero_mode import toggle_variable
    from thonny.plugins.run.pgzero_mode import update_environment
    from thonny.plugins.run.pgzero_mode import _OPTION_NAME
    from thonny.workbench import Workbench
    from unittest.mock import Mock

    workbench = Workbench()
    workbench.set_default(_OPTION_NAME, False)
    workbench.add_command = Mock()
    workbench.in_simple_mode = Mock()
    workbench.in_simple_mode.return_value = False
    workbench.get_option = Mock()
   

# Generated at 2022-06-18 09:42:52.709206
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-18 09:42:57.980213
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    assert wb.get_option(_OPTION_NAME) == False
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == True
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == False

# Generated at 2022-06-18 09:43:03.696225
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench

    wb = Workbench()
    load_plugin()
    assert wb.get_variable(_OPTION_NAME).get() == False
    assert wb.get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert wb.get_variable(_OPTION_NAME).get() == True
    assert wb.get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-18 09:43:12.102300
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.misc_utils import running_on_mac_os
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run.run_config_page import RunConfigurationPage
    from thonny.plugins.run.run_command import RunCommand
    from thonny.plugins.run.run_subprocess import RunSubprocess
    from thonny.plugins.run.run_file import RunFile
    from thonny.plugins.run.run_module import RunModule
    from thonny.plugins.run.run_selection import RunSelection
    from thonny.plugins.run.run_current_script import RunCurrentScript