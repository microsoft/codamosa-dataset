

# Generated at 2022-06-18 09:32:28.008459
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-18 09:32:35.277581
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import Mock
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.set_simple_mode(False)
    wb.set_option(_OPTION_NAME, True)
    wb.set_simple_mode(True)
    wb.set_option(_OPTION_NAME, False)
    wb.set_simple_mode(False)
    wb.set_option(_OPTION_NAME, False)
    wb.set_simple_mode(True)
    wb.set_option(_OPTION_NAME, True)
    wb.set_simple_mode(False)
    wb.set_option(_OPTION_NAME, True)
    wb.set_simple

# Generated at 2022-06-18 09:32:41.614673
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench
    from thonny.languages import tr
    from thonny.misc_utils import running_on_mac_os
    from thonny.plugins.run.run_commands import RunCommand
    from thonny.ui_utils import get_image_path
    from thonny.workbench import Workbench
    from thonny.workbench import WorkbenchEvent
    from thonny.workbench import WorkbenchEventHandler
    from thonny.workbench import WorkbenchEventType
    from thonny.workbench import WorkbenchEventType

    # Test load_plugin
    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)

# Generated at 2022-06-18 09:32:48.983448
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench

    wb = Workbench()
    load_plugin()
    assert wb.get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"
    wb.in_simple_mode = lambda: True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-18 09:32:56.545116
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench
    from thonny.languages import tr
    from thonny.misc_utils import running_on_mac_os
    from thonny.workbench import Workbench
    from thonny.plugins.run.run_configuration import RunConfiguration
    from thonny.plugins.run.run_command import RunCommand
    from thonny.plugins.run.run_subprocess import RunSubprocess
    from thonny.plugins.run.run_pgzero_mode import load_plugin
    from thonny.plugins.run.run_pgzero_mode import toggle_variable
    from thonny.plugins.run.run_pgzero_mode import update_environment
    from thonny.plugins.run.run_pgzero_mode import _OPTION_NAME

    # Test load_plugin


# Generated at 2022-06-18 09:33:04.589679
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench
    from thonny.languages import tr
    from thonny.misc_utils import running_on_mac_os
    from thonny.workbench import Workbench
    from unittest.mock import Mock
    from unittest.mock import patch

    wb = Workbench()
    wb.set_default = Mock()
    wb.add_command = Mock()
    wb.in_simple_mode = Mock(return_value=False)
    wb.get_option = Mock(return_value=True)
    wb.get_variable = Mock()
    wb.get_variable().get = Mock(return_value=True)
    wb.get_variable().set = Mock()

# Generated at 2022-06-18 09:33:11.812443
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.config_ui import ConfigurationPage
    from thonny.misc_utils import running_on_mac_os
    from thonny.globals import get_workbench
    from thonny.plugins.run.run_commands import RunCommand
    from thonny.plugins.run.run_commands import RunSelectionCommand
    from thonny.plugins.run.run_commands import RunCurrentScriptCommand
    from thonny.plugins.run.run_commands import RunCurrentModuleCommand
    from thonny.plugins.run.run_commands import RunTestsCommand
    from thonny.plugins.run.run_commands import DebugCommand
    from thonny.plugins.run.run_commands import DebugCurrentScriptCommand

# Generated at 2022-06-18 09:33:22.707128
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench

    wb = Workbench()
    load_plugin()
    assert wb.get_option(_OPTION_NAME) == False
    assert wb.get_variable(_OPTION_NAME).get() == False
    assert wb.get_variable(_OPTION_NAME).get_label() == tr("Pygame Zero mode")
    assert wb.get_variable(_OPTION_NAME).get_help() == tr("Pygame Zero mode")
    assert wb.get_variable(_OPTION_NAME).get_flag_name() == _OPTION_NAME
    assert wb.get_variable(_OPTION_NAME).get_group() == 40
    assert wb.get_command("toggle_pgzero_mode")
    assert wb.get_command("toggle_pgzero_mode").get_

# Generated at 2022-06-18 09:33:35.353689
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from unittest.mock import Mock
    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    wb.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    wb.set_simple_mode(False)
    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-18 09:33:42.289723
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_default = Mock()
    wb.add_command = Mock()
    load_plugin()
    wb.set_default.assert_called_once_with(_OPTION_NAME, False)
    wb.add_command.assert_called_once()
    assert wb.add_command.call_args[0][0] == "toggle_pgzero_mode"
    assert wb.add_command.call_args[1]["flag_name"] == _OPTION_NAME

# Generated at 2022-06-18 09:33:56.305002
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.config_ui import ConfigurationPage
    from thonny.globals import get_runner
    from thonny.plugins.run.run_config_page import RunConfigurationPage
    from thonny.plugins.run.run_command import RunCommand
    from thonny.plugins.run.run_subprocess import RunSubprocess
    from thonny.plugins.run.run_file import RunFile
    from thonny.plugins.run.run_module import RunModule
    from thonny.plugins.run.run_selection import RunSelection
    from thonny.plugins.run.run_current_script import RunCurrentScript
    from thonny.plugins.run.run_debugger import RunDebugger

# Generated at 2022-06-18 09:34:06.015461
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run.run_config_page import RunConfigurationPage
    from thonny.plugins.run.run_command import RunCommand
    from thonny.languages import tr
    from thonny.misc_utils import running_on_mac_os

    wb = Workbench()
    wb.create()
    wb.set_default(_OPTION_NAME, False)
    wb.add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()

# Generated at 2022-06-18 09:34:08.957355
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench

    wb = Workbench()
    load_plugin()
    assert wb.get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-18 09:34:18.031292
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.misc_utils import running_on_mac_os, running_on_windows
    from thonny.languages import EnglishLanguage, RussianLanguage
    from thonny.ui_utils import CommonDialog
    from thonny.globals import get_workbench
    from thonny.plugins.backend_configuration import BackendConfigurationDialog
    from thonny.plugins.backend_configuration import BackendConfigurationPage
    from thonny.plugins.backend_configuration import BackendConfigurationCommand
    from thonny.plugins.backend_configuration import BackendConfigurationDialog
    from thonny.plugins.backend_configuration import BackendConfiguration

# Generated at 2022-06-18 09:34:29.133642
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run import RunConfigurationPage
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunCommand
    from thonny.plugins.run import RunBackendEventHandler
    from thonny.plugins.run import RunBackendProxy
    from thonny.plugins.run import RunBackend
    from thonny.plugins.run import RunEventHandler
    from thonny.plugins.run import RunProxy
    from thonny.plugins.run import RunFrontendEventHandler
    from thonny.plugins.run import RunFrontendProxy
    from thonny.plugins.run import RunFrontend

# Generated at 2022-06-18 09:34:34.408164
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.workbench import Workbench

    workbench = Workbench()
    workbench.set_default(_OPTION_NAME, False)
    toggle_variable()
    assert workbench.get_option(_OPTION_NAME) == True
    toggle_variable()
    assert workbench.get_option(_OPTION_NAME) == False

# Generated at 2022-06-18 09:34:40.305895
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench

    wb = Workbench()
    load_plugin()
    assert wb.get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-18 09:34:52.197951
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run import RunConfigurationPage
    from thonny.ui_utils import CommonDialog
    from thonny.misc_utils import running_on_mac_os, running_on_windows
    from thonny.languages import EnglishLanguage
    from thonny.globals import get_runner
    from thonny.plugins.backend_configuration import BackendConfigurationPage
    from thonny.plugins.micropython import MicroPythonConfigurationPage
    from thonny.plugins.cpython import CPythonConfigurationPage
    from thonny.plugins.python_turtle import PythonTurtleConfigurationPage

# Generated at 2022-06-18 09:35:02.146866
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.config import Configuration
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run import RunConfigurationPage
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunCommand
    from thonny.plugins.run import RunBackend
    from thonny.plugins.run import RunEventHandler
    from thonny.plugins.run import RunInterpreter
    from thonny.plugins.run import RunInterpreterProxy
    from thonny.plugins.run import RunInterpreterProxy2
    from thonny.plugins.run import RunInterpreterProxy3
    from thonny.plugins.run import RunInterpreterProxy4
    from thonny.plugins.run import RunInterpreter

# Generated at 2022-06-18 09:35:06.541093
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    assert wb.get_option(_OPTION_NAME) == False
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == True
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == False

# Generated at 2022-06-18 09:35:20.210332
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench

    wb = Workbench()
    load_plugin()
    assert wb.get_variable(_OPTION_NAME).get() == False
    assert wb.get_option(_OPTION_NAME) == False
    assert wb.get_command("toggle_pgzero_mode")
    assert wb.get_command("toggle_pgzero_mode").flag_name == _OPTION_NAME
    assert wb.get_command("toggle_pgzero_mode").group == 40



# Generated at 2022-06-18 09:35:26.774649
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.set_default("view.simple_mode", False)
    load_plugin()
    assert wb.get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"
    wb.set_default("view.simple_mode", True)
    load_plugin()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-18 09:35:30.876635
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-18 09:35:41.973678
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench, get_runner
    from thonny.plugins.run_pgzero_mode import load_plugin
    from thonny.languages import tr
    from thonny.misc_utils import running_on_mac_os
    from unittest.mock import Mock

    wb = get_workbench()
    wb.set_default("run.pgzero_mode", False)
    wb.get_option = Mock(return_value=False)
    wb.in_simple_mode = Mock(return_value=False)
    wb.add_command = Mock()
    wb.get_variable = Mock(return_value=False)
    wb.get_runner = Mock(return_value=get_runner())

    load_plugin()


# Generated at 2022-06-18 09:35:52.787369
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.globals import get_runner
    from thonny.plugins.run import RunView
    from thonny.languages import tr
    from thonny.misc_utils import running_on_mac_os
    from thonny.ui_utils import CommonDialog
    from thonny.ui_utils import askstring
    from thonny.ui_utils import askopenfilename
    from thonny.ui_utils import askdirectory
    from thonny.ui_utils import showwarning
    from thonny.ui_utils import showerror
    from thonny.ui_utils import showinfo
    from thonny.ui_utils import show_

# Generated at 2022-06-18 09:36:03.298321
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.misc_utils import running_on_mac_os
    from thonny.misc_utils import running_on_windows
    from thonny.misc_utils import running_on_linux

    # Create a temporary directory
    temp_dir = tempfile.TemporaryDirectory()
    # Create a temporary config directory
    config_dir = os.path.join(temp_dir.name, "config")
    os.mkdir(config_dir)
    # Create a temporary workbench
    workbench = Workbench(config_dir)
    # Set the workbench in simple mode
    workbench.set_simple_mode(True)
    # Set the option to True

# Generated at 2022-06-18 09:36:13.292409
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.misc_utils import running_on_mac_os
    from thonny.languages import tr
    from thonny.plugins.run.pgzero_mode import load_plugin
    from thonny.plugins.run.pgzero_mode import toggle_variable
    from thonny.plugins.run.pgzero_mode import update_environment
    from thonny.plugins.run.pgzero_mode import _OPTION_NAME
    from thonny.plugins.run.pgzero_mode import get_pgzero_mode
    from thonny.plugins.run.pgzero_mode import set_pgzero_

# Generated at 2022-06-18 09:36:24.635513
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunCommand
    from thonny.plugins.run import RunBackend
    from thonny.plugins.run import RunConfigurationPage
    from thonny.plugins.run import RunOptionsPage
    from thonny.plugins.run import RunMenu
    from thonny.plugins.run import RunToolbar
    from thonny.plugins.run import RunDebugger
    from thonny.plugins.run import RunDebuggerUI
    from thonny.plugins.run import RunDebuggerOptionsPage
    from thonny.plugins.run import RunDebuggerConfigurationPage

# Generated at 2022-06-18 09:36:29.301097
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-18 09:36:33.780743
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-18 09:36:54.707920
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run import RunConfigurationPage
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunCommand
    from thonny.plugins.run import RunBackendEventHandler
    from thonny.plugins.run import RunProgramEventHandler
    from thonny.plugins.run import RunFileEventHandler
    from thonny.plugins.run import RunModuleEventHandler
    from thonny.plugins.run import RunSelectionEventHandler
    from thonny.plugins.run import RunCurrentStatementEventHandler
    from thonny.plugins.run import RunCurrentCellEventHandler
    from thonny.plugins.run import RunCurrentFunctionEventHandler

# Generated at 2022-06-18 09:37:05.038495
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import Mock
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.set_simple_mode(False)
    wb.set_option(_OPTION_NAME, True)
    wb.set_simple_mode(True)
    wb.set_option(_OPTION_NAME, False)
    wb.set_simple_mode(False)
    wb.set_option(_OPTION_NAME, True)
    wb.set_simple_mode(True)
    wb.set_option(_OPTION_NAME, False)
    wb.set_simple_mode(False)
    wb.set_option(_OPTION_NAME, True)
    wb.set_simple

# Generated at 2022-06-18 09:37:17.207842
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import Mock
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.globals import get_workbench
    from thonny.plugins.run.run_config_page import RunConfigurationPage
    from thonny.plugins.run.run_command import RunCommand
    from thonny.plugins.run.run_subprocess import RunSubprocess

    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_default(_OPTION_NAME, True)
    get_

# Generated at 2022-06-18 09:37:23.201474
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-18 09:37:28.047108
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-18 09:37:31.773099
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-18 09:37:37.886216
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    wb.set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    wb.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-18 09:37:45.510863
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().in_simple_mode = lambda: True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-18 09:37:56.595598
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run import RunConfigurationPage
    from thonny.languages import tr
    from thonny.misc_utils import running_on_mac_os
    from thonny.globals import get_workbench
    from thonny.globals import get_runner
    from thonny.globals import get_shell
    from thonny.globals import get_workbench
    from thonny.globals import get_runner
    from thonny.globals import get_shell
    from thonny.globals import get_workbench
    from thonny.globals import get_runner
    from thonny.globals import get_shell

# Generated at 2022-06-18 09:38:07.135105
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.ui_utils import CommonDialog
    from thonny.misc_utils import running_on_mac_os

    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    wb.set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    wb.set_default(_OPTION_NAME, False)
    wb.enter_simple_mode()
    update_environment()

# Generated at 2022-06-18 09:38:36.509471
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run import RunConfigurationPage
    from thonny.plugins.run import RunView
    from thonny.plugins.run import RunBackend
    from thonny.plugins.run import RunCommand
    from thonny.plugins.run import RunProgramCommand
    from thonny.plugins.run import RunSelectionCommand
    from thonny.plugins.run import RunCurrentScriptCommand
    from thonny.plugins.run import RunModuleCommand
    from thonny.plugins.run import RunDebuggerCommand
    from thonny.plugins.run import RunDebuggerProgramCommand
    from thonny.plugins.run import RunDebuggerSelectionCommand
    from thonny.plugins.run import RunDebuggerCurrent

# Generated at 2022-06-18 09:38:42.743728
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    assert wb.get_option(_OPTION_NAME) == False
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == True
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == False

# Generated at 2022-06-18 09:38:51.758348
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.misc_utils import running_on_mac_os, running_on_windows
    from thonny.globals import get_workbench
    from thonny.languages import tr
    from thonny.plugins.pgzero_mode import toggle_variable, update_environment
    from thonny.plugins.pgzero_mode import _OPTION_NAME

    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)

# Generated at 2022-06-18 09:39:02.208636
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run import RunConfigurationPage
    from thonny.globals import get_workbench
    from thonny.languages import tr
    import os
    import shutil
    import tempfile
    import unittest

    class Test(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.orig_config_dir = get_config_dir()
            os.environ["THONNY_USER_DIR"] = self.temp_dir
            os.environ["THONNY_HOME"] = self.temp_dir
            self.orig_workbench = get

# Generated at 2022-06-18 09:39:11.382612
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench
    from thonny.workbench import Workbench
    from thonny.config import Configuration
    from thonny.languages import EnglishConfig
    from thonny.misc_utils import running_on_mac_os
    from thonny.plugins.run.run_command import RunCommand
    from thonny.plugins.run.run_subprocess import RunSubprocess
    from thonny.plugins.run.run_thread import RunThread
    from thonny.plugins.run.run_ui import RunUI
    from thonny.plugins.run.run_utils import RunUtils
    from thonny.plugins.run.run_view import RunView
    from thonny.plugins.run.run_config_page import RunConfigurationPage

# Generated at 2022-06-18 09:39:20.169504
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from unittest.mock import Mock
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run import RunConfigurationPage
    from thonny.languages import EnglishLanguage
    from thonny.misc_utils import running_on_mac_os
    from thonny.tktextext import TextFrame
    from thonny.ui_utils import CommonDialog
    from thonny.globals import get_workbench
    from thonny.ui_utils import askstring
    from thonny.ui_utils import askopenfilename
    from thonny.ui_utils import askdirectory
    from thonny.ui_utils import askinteger
    from thonny.ui_utils import ask

# Generated at 2022-06-18 09:39:27.541344
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import Mock
    from thonny.workbench import Workbench
    from thonny.config import Configuration
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run import RunConfigurationPage
    from thonny.languages import EnglishLanguage
    from thonny.misc_utils import running_on_mac_os
    from thonny.globals import get_workbench

    workbench = Workbench(Mock(), Mock(), Mock(), Mock(), Mock(), Mock(), Mock(), Mock())
    workbench.set_default(_OPTION_NAME, False)
    workbench.set_simple_mode(True)
    workbench.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"



# Generated at 2022-06-18 09:39:34.330765
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.run import RunConfigurationPage
    from thonny.languages import tr
    from thonny.misc_utils import running_on_mac_os
    from thonny.tktextext import TextFrame
    from tkinter import Tk, ttk
    from unittest.mock import Mock
    from thonny.globals import get_runner

    root = Tk()
    root.withdraw()
    wb = Workbench(root)
    wb.create_default_shell()
    wb.create_default_editor()
    wb.create_default_view()
    wb.create_default_status_bar()
    wb.create_default_menu()


# Generated at 2022-06-18 09:39:36.902280
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-18 09:39:42.318692
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-18 09:40:46.601384
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench

    wb = Workbench()
    load_plugin()
    assert wb.get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"

    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    wb.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-18 09:40:56.778152
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.globals import get_workbench
    from thonny.misc_utils import running_on_mac_os, running_on_windows
    from thonny.plugins.run import RunConfigurationPage
    from thonny.plugins.run.run_config_page import RunCommand
    from thonny.plugins.run.run_pgzero_mode import _OPTION_NAME
    from thonny.plugins.run.run_pgzero_mode import update_environment
    from thonny.plugins.run.run_pgzero_mode import toggle_variable
    from thonny.plugins.run.run_pgzero_mode import load_plugin

# Generated at 2022-06-18 09:41:04.261872
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import Mock
    from thonny.globals import get_workbench

    get_workbench().in_simple_mode = Mock(return_value=True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().in_simple_mode = Mock(return_value=False)
    get_workbench().get_option = Mock(return_value=True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-18 09:41:07.481425
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-18 09:41:14.332875
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench

    wb = Workbench()
    load_plugin()
    assert wb.get_variable(_OPTION_NAME).get() == False
    assert wb.get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"
    wb.set_option(_OPTION_NAME, True)
    assert wb.get_variable(_OPTION_NAME).get() == True
    assert wb.get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"
    wb.set_simple_mode(True)
    assert wb.get_variable(_OPTION_NAME).get() == True
    assert wb.get_option(_OPTION_NAME) == True


# Generated at 2022-06-18 09:41:21.356890
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.misc_utils import running_on_mac_os

    wb = Workbench()
    wb.create()
    wb.set_default(_OPTION_NAME, False)
    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    wb.set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    wb.set_option(_OPTION_NAME, True)
    wb.set_simple_mode(True)
    update

# Generated at 2022-06-18 09:41:30.518022
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench

    wb = Workbench()
    load_plugin()
    assert wb.get_option(_OPTION_NAME) == False
    assert wb.get_variable(_OPTION_NAME).get() == False
    assert wb.get_variable(_OPTION_NAME).get_label() == "Pygame Zero mode"
    assert wb.get_variable(_OPTION_NAME).get_help() == "Pygame Zero mode"
    assert wb.get_variable(_OPTION_NAME).get_flag_name() == _OPTION_NAME
    assert wb.get_variable(_OPTION_NAME).get_group() == 40
    assert os.environ["PGZERO_MODE"] == "False"
    wb.set_option(_OPTION_NAME, True)
    assert w

# Generated at 2022-06-18 09:41:38.498984
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    wb.set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    wb.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-18 09:41:46.059340
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    wb.set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    wb.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-18 09:41:56.702509
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    import os
    import shutil
    import tempfile

    # create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # create the config dir
    os.makedirs(os.path.join(tmpdir, "config"))
    # create the user dir
    os.makedirs(os.path.join(tmpdir, "user"))
    # create the plugins dir
    os.makedirs(os.path.join(tmpdir, "plugins"))
    # create the simple mode dir
    os.makedirs(os.path.join(tmpdir, "simple_mode"))
    # create the simple mode dir