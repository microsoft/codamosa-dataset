

# Generated at 2022-06-22 03:00:06.557775
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"



# Generated at 2022-06-22 03:00:08.635082
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.globals import get_workbench
    get_workbench().set_option(_OPTION_NAME, False)

    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME)


# Generated at 2022-06-22 03:00:15.117322
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.workbench import Workbench
    from thonny.workbench_utils import get_variable_from_name
    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    var = get_variable_from_name(_OPTION_NAME)
    assert var.get() == False
    toggle_variable()
    
    assert var.get() == True
    assert os.environ["PGZERO_MODE"] == "True"
    
    toggle_variable()
    
    assert var.get() == False
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 03:00:21.762354
# Unit test for function toggle_variable
def test_toggle_variable():
    var = get_workbench().get_variable(_OPTION_NAME)
    var.set(False)
    assert var.get() == False

    toggle_variable()
    assert var.get() == True

    toggle_variable()
    assert var.get() == False


# Generated at 2022-06-22 03:00:28.057859
# Unit test for function toggle_variable
def test_toggle_variable():
    from unittest.mock import Mock
    from thonny.config import get_workbench

    workbench = Mock() 
    workbench.get_option.return_value = False
    workbench.set_option.return_value = None

    get_workbench._main_window_proxy = workbench
    toggle_variable()
    assert workbench.set_option.called
    assert workbench.set_option.call_args[0][0] == _OPTION_NAME
    assert workbench.set_option.call_args[0][1] == True

# Generated at 2022-06-22 03:00:34.710935
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock
    from thonny.workbench import Workbench

    wb = Workbench()
    wb._get_variable = Mock()
    wb._get_option = Mock()
    wb.set_default = Mock()
    wb.add_command = Mock()

    load_plugin()
    wb._get_option.assert_called_once_with(_OPTION_NAME)

# Generated at 2022-06-22 03:00:46.689979
# Unit test for function update_environment
def test_update_environment():
    from thonny.globals import get_workbench
    from test.test_thonny.simulate_thonny import run_in_empty_workbench

    run_in_empty_workbench(lambda: None)

    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().in_simple_mode = lambda: True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().in_simple_mode = lambda: False
    update_

# Generated at 2022-06-22 03:00:54.995081
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    assert not (get_workbench().get_option(_OPTION_NAME))
    toggle_variable()
    assert (get_workbench().get_option(_OPTION_NAME))
    toggle_variable()
    assert not (get_workbench().get_option(_OPTION_NAME))

# Generated at 2022-06-22 03:01:07.020826
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_option(_OPTION_NAME, False)
    assert not get_workbench().get_option(_OPTION_NAME)
    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    
    toggle_variable()
    
    assert get_workbench().get_option(_OPTION_NAME) == True
    assert get_workbench().get_variable(_OPTION_NAME).get() == True
    
    toggle_variable()
    
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    


# Generated at 2022-06-22 03:01:15.134100
# Unit test for function toggle_variable
def test_toggle_variable():
  get_workbench()
  get_workbench().set_default(_OPTION_NAME, True)
  toggle_variable()
  assert get_workbench().get_option(_OPTION_NAME) == False

  toggle_variable()
  assert get_workbench().get_option(_OPTION_NAME) == True

  toggle_variable()
  assert get_workbench().get_option(_OPTION_NAME) == False


# Generated at 2022-06-22 03:01:23.451002
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME)

    toggle_variable()
    assert not get_workbench().get_option(_OPTION_NAME)

# Generated at 2022-06-22 03:01:27.002165
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert get_workbench().get_variable(_OPTION_NAME) is not None

# Generated at 2022-06-22 03:01:39.016421
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.globals import get_workbench
    from thonny.languages import tr
    from unittest import mock
    import sys
    import os

    if sys.platform != "win32":
        return

    option_name = "run.pgzero_mode"
    workbench = get_workbench()
    workbench.set_default(option_name, False)
    workbench.add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=option_name,
        group=40,
    )

    assert not workbench.get_variable(option_name).get()
    assert os.environ.get("PGZERO_MODE") is None

    toggle_variable()

# Generated at 2022-06-22 03:01:42.273172
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    try:
        get_workbench().event_generate("ThemeChanged")
    except:
        pass
    assert get_workbench().in_simple_mode() < 0 # sanity check
    assert get_workbench().get_variable(_OPTION_NAME).get() == False

# Generated at 2022-06-22 03:01:49.466086
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, True)
    wb.set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    wb.set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    wb.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 03:01:56.814208
# Unit test for function update_environment
def test_update_environment():
    from unittest import mock
    import sys

    old_argv = sys.argv
    sys.argv = ["thonny"]
    get_workbench().in_simple_mode.return_value = True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().in_simple_mode.return_value = False
    get_workbench().get_option.return_value = False
    update_environment()
    assert os.environ["PGZERO_MODE"] == "off"

    get_workbench().in_simple_mode.return_value = False
    get_workbench().get_option.return_value = True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "on"

    mock_var = mock

# Generated at 2022-06-22 03:02:01.282238
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_option("run.pgzero_mode", False)
    assert get_workbench().in_simple_mode() == False

    toggle_variable()
    assert get_workbench().in_simple_mode() == True

    toggle_variable()
    assert get_workbench().in_simple_mode() == False

# Generated at 2022-06-22 03:02:13.007779
# Unit test for function update_environment
def test_update_environment():
    old_val = os.environ.pop("PGZERO_MODE", None)
    try:
        get_workbench().in_simple_mode = lambda: False
        get_workbench().get_option = lambda name: False
        update_environment()
        assert os.environ["PGZERO_MODE"] == "False"

        get_workbench().get_option = lambda name: True
        update_environment()
        assert os.environ["PGZERO_MODE"] == "True"

        get_workbench().in_simple_mode = lambda: True
        update_environment()
        assert os.environ["PGZERO_MODE"] == "auto"
    finally:
        if old_val is not None:
            os.environ["PGZERO_MODE"] = old_val

# Generated at 2022-06-22 03:02:22.367088
# Unit test for function load_plugin
def test_load_plugin():
    global load_plugin
    assert "pgzero_mode" == _OPTION_NAME
    load_plugin()
    assert "PGZERO_MODE" in os.environ
    assert "False" == os.environ["PGZERO_MODE"]
    toggle_variable()
    assert "True" == os.environ["PGZERO_MODE"]
    toggle_variable()
    assert "False" == os.environ["PGZERO_MODE"]
    assert "Toggle pgzero mode" in get_workbench().get_variable(_OPTION_NAME).get_label()
    assert "Pygame Zero mode" == get_workbench().get_variable(_OPTION_NAME).get_tooltip()

# Generated at 2022-06-22 03:02:30.033782
# Unit test for function load_plugin
def test_load_plugin():
    from test.test_plugins import is_plugin_loaded

    # Check plugin is not loaded
    assert not is_plugin_loaded("pgzero_mode")

    # Load plugin
    load_plugin()

    # Check plugin is loaded
    assert is_plugin_loaded("pgzero_mode")

    # Unload plugin
    get_workbench().unload_plugin("pgzero_mode")

    # Check plugin is not loaded
    assert not is_plugin_loaded("pgzero_mode")

# Generated at 2022-06-22 03:02:42.576718
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == False


load_plugin()

# Generated at 2022-06-22 03:02:47.266679
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == True
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == False

# Generated at 2022-06-22 03:02:54.643004
# Unit test for function update_environment
def test_update_environment():
    # Test with PGZERO_MODE unset
    if "PGZERO_MODE" in os.environ:
        del os.environ["PGZERO_MODE"]
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    # Test with PGZERO_MODE set to other value
    os.environ["PGZERO_MODE"] = "True"
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()

# Generated at 2022-06-22 03:02:59.422157
# Unit test for function toggle_variable
def test_toggle_variable():
    old_val = get_workbench().get_variable(_OPTION_NAME).get()
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() != old_val
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == old_val


# Generated at 2022-06-22 03:03:09.630637
# Unit test for function load_plugin
def test_load_plugin():
    import unittest.mock
    import sys
    from thonny.workbench import Workbench
    workbench = Workbench()
    workbench.load_plugin = unittest.mock.MagicMock()
    load_plugin()
    assert workbench.get_variable(_OPTION_NAME) == False
    assert "PGZERO_MODE" in os.environ
    assert os.environ["PGZERO_MODE"] == "False"
    assert workbench.load_plugin.call_count == 1
    load_plugin()
    assert workbench.load_plugin.call_count == 2


# Generated at 2022-06-22 03:03:18.216523
# Unit test for function toggle_variable
def test_toggle_variable():
    workbench = get_workbench()
    workbench.set_simple_mode(True)
    toggle_variable()
    assert _OPTION_NAME not in workbench._option_db
    assert os.environ["PGZERO_MODE"] == "off"

    workbench.set_simple_mode(False)
    toggle_variable()
    assert workbench._option_db[_OPTION_NAME] == False
    assert os.environ["PGZERO_MODE"] == "off"
    toggle_variable()
    assert workbench._option_db[_OPTION_NAME] == True
    assert os.environ["PGZERO_MODE"] == "on"

# Generated at 2022-06-22 03:03:29.253980
# Unit test for function toggle_variable
def test_toggle_variable():
    # Initialize session
    workbench = get_workbench()
    workbench.set_option(_OPTION_NAME, False)
    assert workbench.get_option(_OPTION_NAME) is False

    # Test toggling
    toggle_variable()
    assert workbench.get_option(_OPTION_NAME) is True
    os.environ["PGZERO_MODE"] = str(workbench.get_option(_OPTION_NAME))
    assert os.environ["PGZERO_MODE"] == "1"

    toggle_variable()
    assert workbench.get_option(_OPTION_NAME) is False
    os.environ["PGZERO_MODE"] = str(workbench.get_option(_OPTION_NAME))
    assert os.environ["PGZERO_MODE"] == "0"

# Generated at 2022-06-22 03:03:37.319887
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()

    assert hasattr(get_workbench(), "toggle_pgzero_mode")
    assert get_workbench().get_variable(_OPTION_NAME).value == False
    assert os.environ["PGZERO_MODE"] == str(get_workbench().get_option(_OPTION_NAME))
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).value == True
    assert os.environ["PGZERO_MODE"] == str(get_workbench().get_option(_OPTION_NAME))

# Generated at 2022-06-22 03:03:41.956687
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    wb._simple_mode = True
    try:
        del os.environ["PGZERO_MODE"]
        update_environment()
        assert os.environ["PGZERO_MODE"] == "auto"
    finally:
        wb._simple_mode = False

# Generated at 2022-06-22 03:03:46.466021
# Unit test for function load_plugin
def test_load_plugin():
    master = Tk()
    master.withdraw()
    wb = Workbench(master=master)
    wb.option_add("*Dialog.msg.font", "TkFixedFont")
    load_plugin()
    wb.destroy()
    master.destroy()
    pass

# Generated at 2022-06-22 03:04:01.489318
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = "1"
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 03:04:09.721830
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    
    assert not wb.get_variable(_OPTION_NAME).get()
    assert wb.get_command("toggle_pgzero_mode").get_flag_value() is False
    assert os.environ.get("PGZERO_MODE") == "False"
    
    toggle_variable()
    
    assert wb.get_variable(_OPTION_NAME).get()
    assert wb.get_command("toggle_pgzero_mode").get_flag_value() is True
    assert os.environ.get("PGZERO_MODE") == "True"
    
    toggle_variable()
    
    assert not wb.get_variable(_OPTION_NAME).get()
    assert wb.get_command

# Generated at 2022-06-22 03:04:16.548698
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    load_plugin()
    assert not wb.in_simple_mode()
    assert wb.in_pgzero_mode()
    assert get_workbench().get_variable(_OPTION_NAME).get() == True
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == False

# Generated at 2022-06-22 03:04:27.955127
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock, patch
    from thonny import get_workbench, ToplevelResponse, SimpleModeRequest

    filter_cb = Mock()
    get_workbench().bind("ToplevelResponse", filter_cb, True)
    load_plugin()

    assert get_workbench().get_variable("run.pgzero_mode").get() == False

    # Try to switch to simple mode
    get_workbench().event_generate("SimpleModeRequest", request_type=SimpleModeRequest.REQUEST_BECOME_SIMPLE)

    assert get_workbench().get_variable("run.pgzero_mode").get() == False

    # Now switch to advanced mode
    get_workbench().event_generate("SimpleModeRequest", request_type=SimpleModeRequest.REQUEST_BECOME_ADVANCED)

# Generated at 2022-06-22 03:04:30.537104
# Unit test for function load_plugin
def test_load_plugin():
    if "PGZERO_MODE" in os.environ:
        del os.environ["PGZERO_MODE"]


# Generated at 2022-06-22 03:04:38.087844
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    load_plugin()
    wb.set_default(_OPTION_NAME, False)
    wb.set_option(_OPTION_NAME, True)
    assert os.environ["PGZERO_MODE"] == str(wb.get_option(_OPTION_NAME))
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == str(wb.get_option(_OPTION_NAME))

# Generated at 2022-06-22 03:04:48.125709
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_option("run.pgzero_mode", False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_option("run.pgzero_mode", True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_option("run.pgzero_mode", False)
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"


# Generated at 2022-06-22 03:04:59.431273
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import workbench
    from thonny.misc_utils import running_on_mac_os
    workbench.set_default(_OPTION_NAME, True)
    assert workbench.get_option(_OPTION_NAME)
    load_plugin()
    assert workbench.get_variable(_OPTION_NAME).get()
    workbench.in_simple_mode = Mock(return_value=True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    workbench.in_simple_mode = Mock(return_value=False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"


if __name__ == "__main__":
    load_plugin()

# Generated at 2022-06-22 03:05:07.308351
# Unit test for function toggle_variable
def test_toggle_variable():
    from unittest.mock import MagicMock
    
    wb = get_workbench()
    wb.get_variable = MagicMock()
    wb.get_variable.return_value.set = MagicMock()
    
    toggle_variable()
    
    wb.get_variable.assert_called_once_with(_OPTION_NAME)
    wb.get_variable.return_value.set.assert_called_once_with(True)
    

# Generated at 2022-06-22 03:05:12.674502
# Unit test for function load_plugin
def test_load_plugin():
    wb = Workbench()
    wb.set_simple_mode(False)
    load_plugin()
    assert wb.get_option(_OPTION_NAME) == False
    assert os.environ.get("PGZERO_MODE") == "False"
    wb.set_simple_mode(True)
    assert os.environ.get("PGZERO_MODE") == "auto"

# Generated at 2022-06-22 03:05:32.962450
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    load_plugin()
    assert _OPTION_NAME in wb.get_default_configuration()
    assert "PGZERO_MODE" in os.environ and os.environ["PGZERO_MODE"] == "False"


if __name__ == "__main__":
    from thonny import workbench

    workbench._setup_logging()
    load_plugin()
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    load_plugin()
    print(get_workbench().get_default_configuration())

# Generated at 2022-06-22 03:05:44.946703
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock, patch, ANY
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_variable = Mock()
    wb.set_default = Mock()
    wb.get_variable = Mock()
    wb.get_variable.return_value = Mock(get=Mock(return_value=False))
    wb.add_command = Mock()
    # test setup
    load_plugin()

    assert wb.set_default.called
    assert wb.set_default.call_args[0][0] == _OPTION_NAME
    assert wb.set_default.call_args[0][1] == False

    assert wb.add_command.called
    assert wb.add_command.call_args[0][0]

# Generated at 2022-06-22 03:05:46.062889
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()


if __name__ == "__main__":
    test_load_plugin()

# Generated at 2022-06-22 03:05:47.723002
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    load_plugin()
    assert wb.get_variable(_OPTION_NAME)
    assert wb.get_option(_OPTION_NAME) is False

# Generated at 2022-06-22 03:05:57.806316
# Unit test for function update_environment
def test_update_environment():
    try:
        del os.environ["PGZERO_MODE"]
    except:
        pass

    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "off"

    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "on"

    get_workbench().set_option(_OPTION_NAME, False)
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 03:06:08.821712
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench
    from thonny.tktextext import TextFrame

    def set_variable(var, value):
        var.set(value)

    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    menu = get_workbench().get_option_menu(
        "run", _OPTION_NAME, command=set_variable, variable=get_workbench().get_variable(
            _OPTION_NAME)
    )

# Generated at 2022-06-22 03:06:13.516985
# Unit test for function update_environment
def test_update_environment():
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 03:06:21.947130
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    from tkinter import Tk

    root = Tk()
    load_plugin()
    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    assert os.environ["PGZERO_MODE"] == "False"

    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == True
    assert os.environ["PGZERO_MODE"] == "True"

    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 03:06:31.408102
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    assert not wb.in_simple_mode()
    assert not wb.get_option(_OPTION_NAME)
    assert os.environ.get("PGZERO_MODE") == "False"
    toggle_variable()
    assert wb.get_option(_OPTION_NAME)
    assert os.environ.get("PGZERO_MODE") == "True"
    wb.set_simple_mode()
    assert wb.in_simple_mode()
    assert wb.get_option(_OPTION_NAME)
    # in simple mode it doesn't matter what the setting is
    assert os.environ.get("PGZERO_MODE") == "auto"

# Generated at 2022-06-22 03:06:38.202561
# Unit test for function toggle_variable
def test_toggle_variable():
    global _OPTION_NAME
    _OPTION_NAME = "test_run.pgzero_mode"
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == True
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == True

# Generated at 2022-06-22 03:07:10.205563
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench

    wb = get_workbench()
    assert not wb.get_option(_OPTION_NAME)

    load_plugin()
    assert wb.get_option(_OPTION_NAME) == False # pylint: disable=singleton-comparison
    assert wb.get_default(_OPTION_NAME) == False # pylint: disable=singleton-comparison

    wb.set_simple_mode(True)
    update_environment()
    assert "PGZERO_MODE" in os.environ
    assert os.environ["PGZERO_MODE"] == "auto"

    wb.set_simple_mode(False)
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == True # pylint: disable=singleton

# Generated at 2022-06-22 03:07:21.873742
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import MockWorkbench, MockOption

    get_workbench = lambda: MockWorkbench(
        {
            "run.pgzero_mode": MockOption(False),
            "view.simple_mode": False,
            "view.standard_mode": True,
        }
    )
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"

    get_workbench = lambda: MockWorkbench(
        {
            "run.pgzero_mode": MockOption(True),
            "view.simple_mode": True,
            "view.standard_mode": False,
        }
    )
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"


if __name__ == "__main__":
    test_update_

# Generated at 2022-06-22 03:07:30.273960
# Unit test for function update_environment
def test_update_environment():
    os.environ.pop("PGZERO_MODE", None)
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"]=="auto"

    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"]=="True"
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"]=="False"

# Generated at 2022-06-22 03:07:41.093308
# Unit test for function load_plugin
def test_load_plugin():
    old_workbench = get_workbench()

# Generated at 2022-06-22 03:07:49.850878
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    wb = Workbench()
    wb.set_default(_OPTION_NAME, True)
    assert "PGZERO_MODE" not in os.environ
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    wb.set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    wb.set_simple_mode()
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 03:08:01.932917
# Unit test for function update_environment
def test_update_environment():
    """Unit test for function update_environment."""
    root = Tk()
    root.withdraw()
    workbench = get_workbench()
    workbench.set_default(_OPTION_NAME, True) # Reset to default
    update_environment()
    assert os.environ["PGZERO_MODE"] == str(workbench.get_option(_OPTION_NAME))
    toggle_variable()
    update_environment()
    assert os.environ["PGZERO_MODE"] == str(workbench.get_option(_OPTION_NAME))
    workbench.in_simple_mode(True) # Force auto
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    workbench.in_simple_mode(False) # Revoke force auto
    update_environment()
    assert os

# Generated at 2022-06-22 03:08:09.654133
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    assert wb.get_option(_OPTION_NAME) == False
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == True
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == False
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == True
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == False

# Generated at 2022-06-22 03:08:12.301398
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    assert get_workbench().in_simple_mode() == False


# Generated at 2022-06-22 03:08:19.781950
# Unit test for function update_environment
def test_update_environment():
    test_get_workbench = GetWorkbench()
    get_workbench().set_default(_OPTION_NAME, False)
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_default(_OPTION_NAME, True)
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().in_simple_mode = lambda: True
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 03:08:25.258857
# Unit test for function load_plugin
def test_load_plugin():
    class MockWorkbench:
        def set_default(self, name, default_value):
            self.default_value = default_value
        def get_option(self, name):
            return self.default_value
        def in_simple_mode(self):
            return True
        def add_command(self, name, command, description, handler, flag_name=None, group=90):
            self.name = name
            self.command = command
            self.description = description
            self.handler = handler
            self.flag_name = flag_name
            self.group = group
        def get_variable(self, name):
            self.variable_name = name
            return MockVariable()
            
        def get_option(self, name):
            self.option_name = name
            return self.default_value
    
   

# Generated at 2022-06-22 03:08:55.694405
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_simple_mode(False)
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == False
    get_workbench().set_simple_mode(True)
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == False
    get_workbench().set_simple_mode(False)
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_simple_mode(True)
    assert os.environ["PGZERO_MODE"] == "auto"
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    get_workbench().set_simple_mode(False)
    assert os.environ["PGZERO_MODE"]

# Generated at 2022-06-22 03:08:59.752871
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = "auto"
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 03:09:03.143248
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 03:09:10.334083
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()

# Generated at 2022-06-22 03:09:20.773992
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock
    from thonny.workbench import Workbench

    wb = Workbench(Mock())
    wb.set_default(_OPTION_NAME, False)

    assert wb.in_simple_mode() == True
    assert wb.get_variable(_OPTION_NAME) == False

    load_plugin()
    # assert wb.in_simple_mode() == False
    assert wb.get_variable(_OPTION_NAME) == False

    # assert wb.get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"


load_plugin()

# Generated at 2022-06-22 03:09:29.558483
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    wb.set_simple_mode(False)
    wb.set_variable(_OPTION_NAME, False)
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    assert wb.get_variable(_OPTION_NAME).get()
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"
    assert not wb.get_variable(_OPTION_NAME).get()
    wb.set_simple_mode(True)
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "auto"
    assert wb.get_variable(_OPTION_NAME).get()

# Generated at 2022-06-22 03:09:32.189849
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()
    assert not get_workbench().get_option(_OPTION_NAME)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME)

# Generated at 2022-06-22 03:09:39.521927
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default("run.pgzero_mode", True)
    get_workbench().set_default("view.show_command_bar", True)
    get_workbench().set_default("view.show_hidden_variables", True)
    get_workbench().set_default("view.show_language_menu", True)

    load_plugin()
    assert not get_workbench().get_default("run.pgzero_mode")

    toggle_variable()
    assert get_workbench().get_default("run.pgzero_mode")

# Generated at 2022-06-22 03:09:44.612977
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default = MagicMock()
    wb.add_command = MagicMock()
    wb.in_simple_mode = MagicMock(return_value=True)
    wb.get_option = MagicMock(return_value=False)
    load_plugin()
    wb.set_default.assert_called_once_with("run.pgzero_mode", False)
    wb.add_command.assert_called_once()
    assert os.environ["PGZERO_MODE"] == "auto"
    wb.in_simple_mode.assert_called_once()


# Generated at 2022-06-22 03:09:54.535921
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    assert wb.get_variable(_OPTION_NAME) is not None
    assert "PGZERO_MODE" not in os.environ
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    wb.set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    wb.in_simple_mode = lambda: True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    wb.in_simple_mode = lambda: False
    wb.set_default(_OPTION_NAME, False)
    update_environment()
   