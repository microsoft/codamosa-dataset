

# Generated at 2022-06-22 03:01:01.081379
# Unit test for function update_environment
def test_update_environment():
    os.environ.pop("PGZERO_MODE", "")

    import thonny.workbench
    workbench = thonny.workbench.get_workbench()

    workbench.set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    workbench.set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    workbench.set_default(_OPTION_NAME, "auto")
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    workbench.set_simple_mode(True)
    update_environment()

# Generated at 2022-06-22 03:01:10.412538
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().set_simple_mode(False)
    get_workbench().set_option("run.pgzero_mode", False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    
    get_workbench().set_option("run.pgzero_mode", True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 03:01:19.828347
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, True)
    load_plugin()
    assert wb.get_option(_OPTION_NAME) == True

# Generated at 2022-06-22 03:01:26.808123
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 03:01:27.301694
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()

# Generated at 2022-06-22 03:01:39.012325
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench

    workbench = get_workbench()

    workbench.set_variable(_OPTION_NAME, True)
    assert (
        os.environ.get("PGZERO_MODE")
        == str(workbench.get_option(_OPTION_NAME))
    )

    workbench.set_variable(_OPTION_NAME, False)
    assert (
        os.environ.get("PGZERO_MODE")
        == str(workbench.get_option(_OPTION_NAME))
    )

    workbench.set_variable(_OPTION_NAME, True)
    assert (
        os.environ.get("PGZERO_MODE")
        == str(workbench.get_option(_OPTION_NAME))
    )

# Generated at 2022-06-22 03:01:49.424070
# Unit test for function toggle_variable
def test_toggle_variable():
    try:
        from test.test_programs import get_test_subprocess
        from test.test_programs import get_test_program_path

        get_workbench().set_default(_OPTION_NAME, False)
        toggle_variable()
        get_test_subprocess({get_test_program_path(
            "EmptyProgram.py"): ["1", "1"], "EchoProgram.py": ["1", "0"]})
        toggle_variable()

        get_test_subprocess({get_test_program_path(
            "EmptyProgram.py"): ["1", "1"], "EchoProgram.py": ["1", "1"]})
    except ImportError:
        # Avoid error when plugin is loaded during unit tests
        pass

load_plugin()

# Generated at 2022-06-22 03:01:54.992254
# Unit test for function load_plugin
def test_load_plugin():
    global _OPTION_NAME
    _OPTION_NAME = "run.pgzero_mode_test"
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    assert_equal(get_workbench().get_variable(_OPTION_NAME).get(), False)
    assert_equal(os.environ["PGZERO_MODE"], "False")
    get_workbench().get_variable(_OPTION_NAME).set(True)
    assert_equal(os.environ["PGZERO_MODE"], "True")

# Generated at 2022-06-22 03:02:02.063246
# Unit test for function toggle_variable
def test_toggle_variable():
    class DummyOption(object):
        def __init__(self):
            self.var = False
        def get(self):
            return self.var
        def set(self, value):
            self.var = value
    
    class DummyWorkbench(object):
        def get_variable(self, name):
            assert name == _OPTION_NAME
            return self.var
    
    wb = DummyWorkbench()
    wb.var = DummyOption()
    toggle_variable()
    assert wb.var.var == True

# Generated at 2022-06-22 03:02:10.358508
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    assert get_workbench().get_option(_OPTION_NAME) is False
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_option(_OPTION_NAME, True)
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"



load_plugin()

# Generated at 2022-06-22 03:02:22.139132
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    wb.set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    wb.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 03:02:32.176203
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    wb.set_simple_mode(False)
    wb.set_option(_OPTION_NAME, False)
    assert wb.get_option(_OPTION_NAME) == False
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == True
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == False
    wb.set_simple_mode(True)
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == True
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == False

# Generated at 2022-06-22 03:02:36.828166
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"


load_plugin()

# Generated at 2022-06-22 03:02:44.502161
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()


# Generated at 2022-06-22 03:02:49.523127
# Unit test for function update_environment
def test_update_environment():
    get_workbench().in_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().in_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 03:03:01.974942
# Unit test for function load_plugin
def test_load_plugin():
    """Unit test for function load_plugin"""
    global _OPTION_NAME

    class OptionTest:
        def __init__(self):
            self.options = {_OPTION_NAME: False}
        def get_option(self, name):
            return self.options[name]
        def in_simple_mode(self):
            return False

    class VarTest:
        def __init__(self, value):
            self.value = value
        def get(self):
            return self.value
        def set(self, value):
            self.value = value

    class CommandTest:
        def __init__(self):
            self.options = {}
            self.variables = {}
            self.add_command_calls = 0
        def set_default(self, name, value):
            self.options[name]

# Generated at 2022-06-22 03:03:14.199297
# Unit test for function toggle_variable
def test_toggle_variable():
    """Test if toggle_variable function works as expected."""

    # Create the Thonny environment
    mock_workbench = MagicMock()
    mock_workbench.get_variable = lambda x: True
    mock_workbench.in_simple_mode = lambda: False

    with patch("thonny.globals.get_workbench", return_value=mock_workbench):
        os.environ["PGZERO_MODE"] = "False"
        toggle_variable()
        assert os.environ["PGZERO_MODE"] == "True"

        # Test if when in simple mode, PGZERO_MODE is always set to "auto"
        mock_workbench.in_simple_mode.return_value = True
        toggle_variable()
        assert os.environ["PGZERO_MODE"] == "auto"

       

# Generated at 2022-06-22 03:03:19.359376
# Unit test for function toggle_variable
def test_toggle_variable():
    old_value = get_workbench().in_simple_mode()
    toggle_variable()
    assert get_workbench().in_simple_mode() != old_value
    if old_value:
        assert get_workbench().get_option(_OPTION_NAME) == True
    else:
        assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-22 03:03:23.542829
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, True)
    assert str(get_workbench().get_option(_OPTION_NAME)) == "True"
    toggle_variable()
    assert str(get_workbench().get_option(_OPTION_NAME)) == "False"



# Generated at 2022-06-22 03:03:35.215744
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench

    wb = get_workbench()
    assert not wb.get_variable(
        _OPTION_NAME
    )  # False means plugin not loaded, it is tested in test_menu_and_keybindings.py

    old_toggle_variable = toggle_variable
    toggle_variable_called = False

    def mock_toggle_variable():
        nonlocal toggle_variable_called
        toggle_variable_called = True

    toggle_variable = mock_toggle_variable
    old_get_option = wb.get_option

    def mock_get_option(option):
        if option == _OPTION_NAME:
            return True
        else:
            return old_get_option(option)

    old_get_variable = wb.get_variable


# Generated at 2022-06-22 03:03:43.485391
# Unit test for function toggle_variable
def test_toggle_variable():
    # toggling it twice should return to original value
    old_val = get_workbench().get_option(_OPTION_NAME)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) != old_val
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == old_val

# Generated at 2022-06-22 03:03:54.457912
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import MagicMock

    workbench = MagicMock()
    workbench.in_simple_mode.return_value = True
    workbench.get_option.return_value = False
    with patch("thonny.globals.get_workbench", return_value=workbench):
        update_environment()
        assert os.environ["PGZERO_MODE"] == "auto"
    
    workbench.in_simple_mode.return_value = False
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    workbench.get_option.return_value = True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 03:04:06.227027
# Unit test for function load_plugin
def test_load_plugin():
    workbench = get_workbench()
    assert workbench.in_simple_mode()
    load_plugin()
    assert workbench.get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == str(workbench.get_option(_OPTION_NAME))
    workbench.load_workbench(["--simple-mode"])
    assert workbench.in_simple_mode()
    load_plugin()
    assert workbench.in_simple_mode()
    assert os.environ["PGZERO_MODE"] == "auto"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == str(workbench.get_option(_OPTION_NAME))
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "auto"



# Generated at 2022-06-22 03:04:18.057256
# Unit test for function update_environment
def test_update_environment():
    from thonny.misc_utils import running_on_windows, running_on_mac_os

    sys.platform = "linux"
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    sys.platform = "linux"
    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment

# Generated at 2022-06-22 03:04:23.453652
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()
    if get_workbench().get_option(_OPTION_NAME):
        assert os.environ["PGZERO_MODE"] == "True"
    else:
        assert os.environ["PGZERO_MODE"] == "False"


# Generated at 2022-06-22 03:04:24.364718
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()

# Generated at 2022-06-22 03:04:33.689804
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from unittest.mock import Mock
    from thonny.config import Configuration
    from thonny.config_ui import ConfigurationPage

    get_workbench = Mock(return_value=Workbench(Mock(spec=Configuration)))
    # get_workbench().get_variable = Mock(return_value=ConfigurationPage())
    Workbench.__init__ = Mock()

    # Return default configuration
    Configuration.__init__ = Mock(return_value=None)

    load_plugin()

    # assert get_workbench().get_variable._option_name == "run.pgzero_mode"
    # assert get_workbench().in_simple_mode() == False

# Generated at 2022-06-22 03:04:41.314000
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default(_OPTION_NAME, True)
    get_workbench().in_simple_mode = lambda: True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().in_simple_mode = lambda: False
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 03:04:42.196484
# Unit test for function toggle_variable
def test_toggle_variable():
    assert toggle_variable

# Generated at 2022-06-22 03:04:49.541677
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 03:05:07.438935
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, False)
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_simple_mode(True)
    assert os.environ["PGZERO_MODE"] == "auto"



# Generated at 2022-06-22 03:05:11.726338
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, True)
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == True


# Generated at 2022-06-22 03:05:16.785847
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    assert wb.get_option(_OPTION_NAME) == False
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == True
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == False


# Generated at 2022-06-22 03:05:20.597367
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, True)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-22 03:05:27.002017
# Unit test for function toggle_variable
def test_toggle_variable():
    if get_workbench().get_option(_OPTION_NAME):
        assert os.environ["PGZERO_MODE"] == "True"
        toggle_variable()
        assert os.environ["PGZERO_MODE"] == "False"
    else:
        assert os.environ["PGZERO_MODE"] == "False"
        toggle_variable()
        assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 03:05:34.675565
# Unit test for function toggle_variable
def test_toggle_variable():
    # toggle the variable with known state
    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == True
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == False

    # toggle the variable with unknown state
    get_workbench().get_variable(_OPTION_NAME).set(None)
    assert get_workbench().get_variable(_OPTION_NAME).get() == None
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == True
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == False

    # reset the variable
    toggle_variable()

# Generated at 2022-06-22 03:05:46.341865
# Unit test for function load_plugin
def test_load_plugin():
    # pylint: disable=protected-access
    from unittest.mock import Mock
    from thonny.workbench import Workbench
    from thonny import get_shell

    wb = Workbench()
    wb.set_option("run.pgzero_mode", True)

    # run command by key binding
    get_workbench().event_generate("<<TogglePgzeroMode>>")
    assert get_workbench().get_option("run.pgzero_mode") is False
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().event_generate("<<TogglePgzeroMode>>")
    assert get_workbench().get_option("run.pgzero_mode") is True
    assert os.environ["PGZERO_MODE"] == "True"

    #

# Generated at 2022-06-22 03:05:51.271123
# Unit test for function load_plugin
def test_load_plugin():
    # First load_plugin requires workbench
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-22 03:06:03.011494
# Unit test for function toggle_variable
def test_toggle_variable():
    from unittest.mock import Mock

    wb = Mock()
    wb.in_simple_mode.return_value = False
    wb.get_variable.side_effect = lambda n: Mock(
        get=Mock(side_effect=[False, True]), set=Mock()
    )
    wb.get_option.side_effect = [False, True]
    wb.update_environment = Mock()
    wb.add_command = Mock()
    toggle_variable()
    assert wb.get_variable.call_count == 2
    assert wb.get_variable().get.call_count == 2
    assert wb.add_command.call_count == 1
    wb.add_command().__setitem__.assert_called_once_with("flag_name", _OPTION_NAME)

# Generated at 2022-06-22 03:06:14.705573
# Unit test for function update_environment
def test_update_environment():
    old_pgzero_mode = os.environ.get("PGZERO_MODE")
    old_in_simple_mode = get_workbench().in_simple_mode()


# Generated at 2022-06-22 03:06:33.488314
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_simple_mode(False)
    var = get_workbench().get_variable(_OPTION_NAME)
    var.set(False)
    assert get_workbench().get_option(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

    get_workbench().get_variable(_OPTION_NAME).set(True)
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True


# Generated at 2022-06-22 03:06:44.007950
# Unit test for function toggle_variable
def test_toggle_variable():
    from unittest import mock
    from thonny import get_workbench, get_shell
    from thonny.shell import ShellTextWidget

    mock_env = {}

    with mock.patch("os.environ", mock_env), mock.patch("thonny.globals.get_running_backend_name") as mock_get_running_backend_name:
        mock_get_running_backend_name.return_value = "CPython"

        get_workbench().set_option("run.pgzero_mode", False)
        toggle_variable()
        assert get_workbench().get_option("run.pgzero_mode") is True, "/nrun.pgzero_mode expected to be True"
        get_shell().event_generate("<<ClearBuffer>>")

# Generated at 2022-06-22 03:06:51.971047
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.languages import danish
    from thonny import get_workbench, get_runner
    from thonny.misc_utils import running_on_mac_os
    from thonny.workbench import Workbench
    
    from thonny.plugins.pgzero_mode import load_plugin as pgzero_mode

    wb = Workbench()
    pgzero_mode()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert get_workbench().in_simple_mode() == False

# Generated at 2022-06-22 03:06:54.906865
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    get_workbench().get_option(_OPTION_NAME) != True
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-22 03:07:06.421237
# Unit test for function load_plugin
def test_load_plugin():
    # arrangement
    class mock_get_workbench:
        def __init__(self):
            self.mock_set_default_called = False
            self.mock_add_command_called = False
            self.mock_set_default_called_with_option_name = None
            self.mock_set_default_called_with_value = None
            self.mock_add_command_called_with_command_name = None
            self.mock_add_command_called_with_category = None
            self.mock_add_command_called_with_label = None
            self.mock_add_command_called_with_command = None
            self.mock_add_command_called_with_flag_name = None

# Generated at 2022-06-22 03:07:10.569797
# Unit test for function update_environment
def test_update_environment():
    _workbench = get_workbench()
    _workbench.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    _workbench.set_simple_mode(False)
    _workbench.set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 03:07:17.880402
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, True)

    sys.modules["thonny.ui_utils"] = Mock()
    sys.modules["tkinter"] = Mock()
    global load_plugin
    importlib.reload(load_plugin)
    load_plugin()
    assert isinstance(wb.get_variable(_OPTION_NAME), bool)
    assert wb.get_option(_OPTION_NAME) == True

# Generated at 2022-06-22 03:07:28.833567
# Unit test for function toggle_variable
def test_toggle_variable():
    class FakeVariable:
        def __init__(self, val):
            self._val = val

        def get(self):
            return self._val

        def set(self, val):
            self._val = val

    class FakeWorkbench:
        in_simple_mode = lambda self: False
        get_variable = lambda self, name: FakeVariable(val)
        get_option = lambda self, name: val
        set_option = lambda self, name, val: val
    val = True
    var = FakeVariable(val)
    wb = FakeWorkbench()

    toggle_variable()
    assert var.get() == False
    assert os.environ["PGZERO_MODE"] == "False"

    val = False
    toggle_variable()
    assert var.get() == True

# Generated at 2022-06-22 03:07:39.553300
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.plugins.pgzero import load_plugin as load_plugin_test
    from unittest.mock import Mock

    # Mock the required functions to load plugin
    wb_mock = Mock()
    wb_mock.get_variable = Mock(return_value=Mock(get=Mock(return_value=False)))

    wb_mock.get_option = Mock(return_value=False)
    
    # Load plugin
    load_plugin_test()
    # Check the state of the required variables and options
    assert wb_mock.get_variable("run.pgzero_mode").get() == False
    assert wb_mock.get_option("run.pgzero_mode") == False

# Generated at 2022-06-22 03:07:47.442932
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == True
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == False



# Generated at 2022-06-22 03:08:15.433078
# Unit test for function toggle_variable
def test_toggle_variable():
    workbench = get_workbench()
    workbench.set_default(_OPTION_NAME, False)
    assert workbench.get_option(_OPTION_NAME) == False
    toggle_variable()
    assert workbench.get_option(_OPTION_NAME) == True
    toggle_variable()
    assert workbench.get_option(_OPTION_NAME) == False

# Generated at 2022-06-22 03:08:25.164873
# Unit test for function update_environment
def test_update_environment():
    workbench = get_workbench()
    try:
        del os.environ["PGZERO_MODE"]
    except KeyError:
        pass
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    
    workbench.set_simple_mode(False)
    workbench.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"
    
    workbench.set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"
    
    workbench.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 03:08:35.251743
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().register_command(
        "test_command", "run", tr("Test command"), lambda: None
    )
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )

# Generated at 2022-06-22 03:08:39.644831
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    assert os.environ["PGZERO_MODE"] == "False"


# Generated at 2022-06-22 03:08:47.908414
# Unit test for function update_environment
def test_update_environment():
    from unittest import mock
    import os
    from thonny import get_workbench
    from thonny.languages import tr
    get_workbench().set_default(_OPTION_NAME, True)
    os.environ["PGZERO_MODE"] = ""
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 03:08:50.449718
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False



# Generated at 2022-06-22 03:08:55.612232
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"



# Generated at 2022-06-22 03:09:04.344822
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.plugins.environment_mixin import EnvironmentMixin

    workbench = EnvironmentMixin()
    get_workbench = lambda: workbench
    load_plugin()
    assert workbench.get_option(_OPTION_NAME) == False
    assert "PGZERO_MODE" not in os.environ  # in simple mode by default
    workbench.set_option(_OPTION_NAME, True)
    assert os.environ.get("PGZERO_MODE") == "True"
    workbench.set_simple_mode(False)
    workbench.set_option(_OPTION_NAME, False)

# Generated at 2022-06-22 03:09:14.138738
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock
    from thonny.misc_utils import running_on_mac_os
    get_workbench = Mock()
    get_workbench.in_simple_mode.return_value = False
    get_workbench.get_variable.return_value = True
    get_workbench.get_option.return_value = True

# Generated at 2022-06-22 03:09:22.832091
# Unit test for function update_environment
def test_update_environment():
    # When Thonny is in simple mode, PGZERO_MODE is set 'auto'
    get_workbench().set_in_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    # When not in simple mode, PGZERO_MODE is set as the value of _OPTION_NAME
    get_workbench().set_in_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 03:10:19.435133
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )

    update_environment()

# Generated at 2022-06-22 03:10:31.189688
# Unit test for function update_environment
def test_update_environment():
    os.environ.pop("PGZERO_MODE", None)
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_default(_OPTION_NAME, True)
    get_workbench().set_simple_mode(True)
    update_environment()

# Generated at 2022-06-22 03:10:39.094747
# Unit test for function update_environment
def test_update_environment():
    # Make sure no PGZERO_MODE has been set before
    assert "PGZERO_MODE" not in os.environ
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    # Also test that when in simple mode PGZERO_MODE is set to auto
    get_workbench().set_option("general.simple_mode", True)
    update_environment()
    assert os.enviro

# Generated at 2022-06-22 03:10:43.980627
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default("run.pygame_zero_mode", False)
    load_plugin()
    assert get_workbench().get_option("run.pgzero_mode") == False
    assert get_workbench().get_default("run.pygame_mode") == False

# Generated at 2022-06-22 03:10:50.791389
# Unit test for function update_environment
def test_update_environment():
    from unittest import TestCase
    import os

    class TestWorkbench:
        @staticmethod
        def in_simple_mode():
            return False

        @staticmethod
        def get_option(_OPTION_NAME):
            return True

        @staticmethod
        def set_default(_OPTION_NAME, _):
            pass

        @staticmethod
        def add_command(*args, **kw):
            pass

    class TestCase(TestCase):
        def test_update_environment(self):
            var = get_workbench().get_variable(_OPTION_NAME)
            var.set(False)
            update_environment()
            self.assertEqual("False", os.environ["PGZERO_MODE"])

    get_workbench().__class__ = TestWorkbench
    TestCase().test_update_environment()