

# Generated at 2022-06-22 03:00:06.720997
# Unit test for function toggle_variable
def test_toggle_variable():
    # Get the variables and initialise them
    v_1 = get_workbench().get_variable(_OPTION_NAME)
    v_1.set(True)
    # Toggle the variable
    toggle_variable()
    # Get the updated value and check that is has changed
    v_2 = get_workbench().get_variable(_OPTION_NAME)
    assert v_2.get() == False
    # Return the variables to the originals
    v_1.set(True)
    v_2.set(False)
    return True



# Generated at 2022-06-22 03:00:13.998531
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, True)
    load_plugin()
    assert get_workbench().get_variable(_OPTION_NAME).get()
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() is False
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().in_simple_mode = lambda: True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().in_simple_mode = lambda: False
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 03:00:27.353640
# Unit test for function update_environment
def test_update_environment():
    # remove PGZERO_MODE from environment
    if "PGZERO_MODE" in os.environ:
        del os.environ["PGZERO_MODE"]

    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().set_default(_OPTION_NAME, True)

# Generated at 2022-06-22 03:00:35.072657
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = ""
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 03:00:39.585879
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_option(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-22 03:00:44.121337
# Unit test for function update_environment
def test_update_environment():
    os.environ.pop("PGZERO_MODE", None)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"

    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"

# Generated at 2022-06-22 03:00:51.151350
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().get_option(_OPTION_NAME)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    assert "PGZERO_MODE" in os.environ
    os.environ["PGZERO_MODE"] = str(get_workbench().get_option(_OPTION_NAME))


# Generated at 2022-06-22 03:01:03.417231
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench
    from thonny.languages import tr
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny.config_ui import ConfigurationPage
    from thonny.plugins.simple_mode import SimpleModePlugin
    from thonny.plugins.run import RunConfigurationPage
    from thonny.ui_utils import CommonDialog
    from thonny.ui_utils import select_option_dialog
    from thonny.plugins.pgzero import RunConfigurationPage
    import os
    import stat
    import random
    import string
    import traceback
    import tkinter
    import shutil
    
    # This module requires pgzero to be installed
    try:
        import pgzero
    except ImportError:
        return


# Generated at 2022-06-22 03:01:09.871897
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    assert not wb.get_variable(_OPTION_NAME).get()
    toggle_variable()
    assert wb.get_variable(_OPTION_NAME).get()
    toggle_variable()
    assert not wb.get_variable(_OPTION_NAME).get()


# Generated at 2022-06-22 03:01:12.384731
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    get_workbench().set_default(_OPTION_NAME, True)
    toggle_variable()

# Generated at 2022-06-22 03:01:19.824902
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, True)
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "0"

    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "1"


if __name__ == "__main__":
    test_toggle_variable()

# Generated at 2022-06-22 03:01:26.771011
# Unit test for function load_plugin
def test_load_plugin():
    workbench = get_workbench()
    old_commands = workbench.commands["run"]
    old_default = workbench.get_default(_OPTION_NAME)

    try:
        # Unit test
        load_plugin()
        assert "toggle_pgzero_mode" in workbench.commands["run"]
        assert workbench.get_default(_OPTION_NAME) == False
    finally:
        # rollback
        workbench.commands["run"] = old_commands
        workbench.set_default(_OPTION_NAME, old_default)

# Generated at 2022-06-22 03:01:28.507176
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 03:01:37.470938
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_default = Mock()
    wb.add_command = Mock()
    wb.in_simple_mode = Mock(return_value=True)
    wb.get_variable = Mock()
    wb.get_option = Mock(return_value=False)

    load_plugin()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 03:01:42.179972
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert get_workbench().get_variable(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME) == False
    assert os.environ['PGZERO_MODE'] == 'False'
    get_workbench().set_simple_mode()
    update_environment()
    assert os.environ['PGZERO_MODE'] == 'auto'



# Generated at 2022-06-22 03:01:49.465795
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 03:01:54.765290
# Unit test for function update_environment
def test_update_environment():
    old_env = os.environ.copy()
    try:
        get_workbench().set_option(_OPTION_NAME, False)
        update_environment()
        assert os.environ["PGZERO_MODE"] == "False"

        get_workbench().set_option(_OPTION_NAME, True)
        update_environment()
        assert os.environ["PGZERO_MODE"] == "True"
    finally:
        os.environ.clear()
        os.environ.update(old_env)

# Generated at 2022-06-22 03:01:57.682059
# Unit test for function toggle_variable
def test_toggle_variable():
    os.environ.pop("PGZERO_MODE", None)
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"


# Generated at 2022-06-22 03:02:02.292106
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().add_command = MagicMock()
    load_plugin()
    get_workbench().add_command.assert_any_call(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )

# Generated at 2022-06-22 03:02:06.256497
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 03:02:21.925454
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_shell
    from thonny.shell import ShellTextWidget

    wb = get_workbench()
    wb.clear_plugin_variables()

    # load plugin
    load_plugin()

    # Check the toggle_pgzero_mode command button
    cmd = wb.get_command("toggle_pgzero_mode")
    value = wb.get_variable(_OPTION_NAME).get()
    assert value == False
    assert cmd.label() == "Pygame Zero mode: off"

    # Check the toggle_pgzero_mode command functionality
    wb.event_generate("<<RunScript>>")
    # simulate the toggle
    wb.event_generate("<<ToggleVariable>>", data=_OPTION_NAME)

# Generated at 2022-06-22 03:02:23.452433
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().bind("ToggledPgzeroMode", lambda: None)

# Generated at 2022-06-22 03:02:34.944078
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.globals import get_workbench
    from thonny.test_utils import run_test_subprocess
    from thonny.plugins.run import ExecutionResult
    
    def run_code():
        get_workbench().get_option(_OPTION_NAME).set(True)
        env = os.environ.copy()
        env["PGZERO_MODE"] = "auto"
        
        result = get_workbench().run_command(
            "run_backend",
            ["python", "-c", "import os; print(os.environ['PGZERO_MODE'])"],
            env=env
        )
        
        assert isinstance(result, ExecutionResult)
        assert result.get_result() == "auto\n"
        
        toggle_variable()
        
        result = get

# Generated at 2022-06-22 03:02:40.059007
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().in_simple_mode = lambda:False
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == False
    get_workbench().in_simple_mode = lambda:True
    load_plugin()
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().in_simple_mode = lambda:False
    load_plugin()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 03:02:41.964774
# Unit test for function toggle_variable
def test_toggle_variable():
    ofsted = toggle_variable()
    assert ofsted == "auto"


# Generated at 2022-06-22 03:02:51.752193
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ['PGZERO_MODE'] == "False"
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ['PGZERO_MODE'] == "True"

    get_workbench().set_simple_mode(True)
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ['PGZERO_MODE'] == "auto"
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ['PGZERO_MODE'] == "auto"

# Generated at 2022-06-22 03:03:02.033838
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_default = Mock()
    wb.add_command = Mock()
    load_plugin()
    assert wb.set_default.call_count == 1
    assert wb.add_command.call_count == 1
    assert get_workbench().get_option(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ.get("PGZERO_MODE") == "False"

# Generated at 2022-06-22 03:03:11.228867
# Unit test for function load_plugin
def test_load_plugin():
    """Test that _OPTION_NAME and os.environ["PGZERO_MODE"] are set
    to default value when plugin is loaded"""
    from thonny import get_workbench
    from thonny.plugins.pgzero_mode import load_plugin, _OPTION_NAME

    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == "False"
    assert os.environ["PGZERO_MODE"] == "False"



# Generated at 2022-06-22 03:03:15.718999
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    # calling toggle_variable twice should set the value to True
    # and calling it again should set it back to False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME)
    toggle_variable()
    assert not get_workbench().get_option(_OPTION_NAME)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME)

# Generated at 2022-06-22 03:03:26.571340
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, True)
    wb.in_simple_mode = lambda: False
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    wb.in_simple_mode = lambda: True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    wb.set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    wb.in_simple_mode = lambda: False
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 03:03:40.683249
# Unit test for function toggle_variable
def test_toggle_variable():
    load_plugin()
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 03:03:41.618533
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()

# Generated at 2022-06-22 03:03:46.149698
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import workbench
    workbench.unload_plugin_by_name("pgzero_mode")
    workbench.initialize_plugins()
    load_plugin()

if __name__ == "__main__":
    # do some test
    test_load_plugin()

# Generated at 2022-06-22 03:03:53.608386
# Unit test for function toggle_variable
def test_toggle_variable():
    load_plugin()
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    assert "PGZERO_MODE" in os.environ
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert "PGZERO_MODE" in os.environ
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 03:04:05.446819
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny import get_workbench
    from thonny.workbench import Workbench
    from unittest import mock
    import tempfile
    import os
    os.environ["THONNY_USER_DIR"] = tempfile.gettempdir()
    config = tempfile.gettempdir() + "/thonny/config-v2.json"
    workbench = Workbench()
    workbench.set_default("run.pgzero_mode", True)
    toggle_variable()
    with open(config, "r") as f:
        text = f.read()
    assert "pgzero_mode" not in text

    workbench.set_default("run.pgzero_mode", False)
    toggle_variable()
    with open(config, "r") as f:
        text = f.read()

# Generated at 2022-06-22 03:04:16.203130
# Unit test for function update_environment
def test_update_environment():
    get_workbench().in_simple_mode = lambda: True
    del os.environ["PGZERO_MODE"]
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().in_simple_mode = lambda: False
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"

    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"

# Generated at 2022-06-22 03:04:22.963041
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()
    #returns nothing



# Generated at 2022-06-22 03:04:29.207988
# Unit test for function update_environment
def test_update_environment():
    from thonny.workflow import CommandLineWorkflow
    from thonny.config_ui import ConfigurationPage
    from thonny.workbench import Workbench
    old_environ = os.environ.copy()
    try:
        workflow = CommandLineWorkflow()
        os.environ[ConfigurationPage.THONNY_MODE_ENV_VAR] = "simple"
        update_environment()
        assert os.environ["PGZERO_MODE"] == "auto"

        os.environ[ConfigurationPage.THONNY_MODE_ENV_VAR] = "regular"
        get_workbench().get_option(_OPTION_NAME).set(True)
        update_environment()
        assert os.environ["PGZERO_MODE"] == "True"
    finally:
        os.environ.clear()


# Generated at 2022-06-22 03:04:41.596129
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench

    get_workbench().set_default(_OPTION_NAME, False)
    if hasattr(get_workbench(), "add_command") is False:
        raise Exception('get_workbench().add_command does not exist')

    if hasattr(get_workbench(), "set_default") is False:
        raise Exception('get_workbench().set_default does not exist')

    if hasattr(get_workbench(), "in_simple_mode") is False:
        raise Exception('get_workbench().in_simple_mode does not exist')

    if hasattr(get_workbench(), "get_option") is False:
        raise Exception('get_workbench().get_option does not exist')

    if hasattr(get_workbench(), "get_variable") is False:
        raise

# Generated at 2022-06-22 03:04:46.768454
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()

load_plugin()

# Generated at 2022-06-22 03:05:11.601014
# Unit test for function toggle_variable
def test_toggle_variable():
    #GIVEN
    #WHEN
    toggle_variable()
    #THEN
    assert get_workbench().get_option(_OPTION_NAME)

# Generated at 2022-06-22 03:05:23.119134
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench

    from thonny.plugins.pgzero_mode import load_plugin
    from thonny.plugins.pgzero_mode import toggle_variable
    from thonny.plugins.pgzero_mode import update_environment

    class DummyTk:
        workbench: Workbench = Workbench()

    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().tk = DummyTk()
    get_workbench().set_option(_OPTION_NAME, True)

    assert not get_workbench().get_option(
        "run.pgzero_mode"
    )  # default after clean installation
    load_plugin()

    assert not get_workbench().get_option(_OPTION_NAME)
    toggle_variable()
    assert get_workbench

# Generated at 2022-06-22 03:05:32.362721
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import MagicMock
    from thonny import get_workbench

    mock_workbench = MagicMock()
    mock_workbench.get_option = MagicMock(return_value=False)
    mock_workbench.in_simple_mode = MagicMock(return_value=False)
    mock_workbench.set_default = MagicMock()
    mock_workbench.add_command = MagicMock()
    get_workbench.set_workbench(mock_workbench)
    load_plugin()
    mock_workbench.set_default.assert_called_with("run.pgzero_mode", False)

# Generated at 2022-06-22 03:05:36.566191
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 03:05:45.683657
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"

    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"

    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"

# Generated at 2022-06-22 03:05:47.804330
# Unit test for function toggle_variable

# Generated at 2022-06-22 03:05:57.902736
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"


if __name__ == "__main__":
    test_load_plugin()

# Generated at 2022-06-22 03:06:02.684313
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.register_default("run.pgzero_mode", False)

    load_plugin()

    assert wb.get_option(_OPTION_NAME) is False
    assert wb.get_command("toggle_pgzero_mode") is not None

# Generated at 2022-06-22 03:06:11.874792
# Unit test for function toggle_variable
def test_toggle_variable():
    try:
        del os.environ["PGZERO_MODE"]
    except:
        pass

    if _OPTION_NAME in get_workbench().get_variable_names():
        get_workbench().unset_variable(_OPTION_NAME)

    toggle_variable()
    assert os.environ["PGZERO_MODE"] == str(True)
    assert get_workbench().get_option(_OPTION_NAME) == True

    toggle_variable()
    assert os.environ["PGZERO_MODE"] == str(False)
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-22 03:06:19.691402
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    wb.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    wb.set_simple_mode(False)
    wb.set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"
    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"

# Generated at 2022-06-22 03:07:06.839907
# Unit test for function load_plugin
def test_load_plugin():
    global load_plugin
    load_plugin()


# Generated at 2022-06-22 03:07:08.670775
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench

    wb = Workbench()
    load_plugin()

    wb.destroy()


load_plugin()

# Generated at 2022-06-22 03:07:12.514291
# Unit test for function toggle_variable
def test_toggle_variable():
    # Check if the value is set correctly
    var = get_workbench().get_variable(_OPTION_NAME)
    var.set(True)
    assert var.get() == True
    toggle_variable()
    assert var.get() == False



# Generated at 2022-06-22 03:07:14.269915
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-22 03:07:22.274846
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    get_workbench().set_option(_OPTION_NAME, True)
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_option(_OPTION_NAME, False)
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().get_option("run.simple_mode").set(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 03:07:22.875129
# Unit test for function load_plugin
def test_load_plugin():
    assert 1

# Generated at 2022-06-22 03:07:25.741770
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 03:07:29.537253
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench
    from thonny.plugins.pgzero_mode import load_plugin
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == False


# Generated at 2022-06-22 03:07:40.622046
# Unit test for function load_plugin
def test_load_plugin():
    import thonny.workbench
    from thonny import get_runner
    from thonny.config import Configuration
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.in_simple_mode = lambda: False
    wb.get_option = lambda name: False
    wb.set_default = lambda name, value: None
    wb.add_command = lambda command, menu, label, handler, flag_name=None, group=100: None

    load_plugin()

    wb = Workbench(config=Configuration())
    wb.in_simple_mode = lambda: True
    wb.get_option = lambda name: False
    wb.set_default = lambda name, value: None

# Generated at 2022-06-22 03:07:47.283570
# Unit test for function toggle_variable
def test_toggle_variable():
    assert "PGZERO_MODE" not in os.environ
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 03:09:40.809876
# Unit test for function load_plugin
def test_load_plugin():
    from test.config_helper import (
        run_in_empty_workbench,
        get_workbench_config_dict,
        get_runner_config_dict,
    )
    from thonny.run import Runner

    with run_in_empty_workbench() as workbench:
        load_plugin()
        assert _OPTION_NAME in get_workbench_config_dict()
        runner = Runner(workbench)
        assert "PGZERO_MODE" in runner.get_environment()
        assert runner.get_environment()["PGZERO_MODE"] == "False"
        workbench.get_option(_OPTION_NAME).set(True)
        runner.refresh_environment()
        assert runner.get_environment()["PGZERO_MODE"] == "True"
        workbench.enter_simple_mode()

# Generated at 2022-06-22 03:09:43.130749
# Unit test for function load_plugin
def test_load_plugin():
    # Test if loading the plugin throws no error
    load_plugin()

# Generated at 2022-06-22 03:09:48.874994
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    load_plugin()
    assert "PGZERO_MODE" in os.environ
    assert os.environ["PGZERO_MODE"] == "0"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "1"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "0"

# Generated at 2022-06-22 03:09:54.046615
# Unit test for function update_environment
def test_update_environment():
    import os
    from thonny.workbench import Workbench

    # setup

    os.environ["PGZERO_MODE"] = "auto"
    workbench = Workbench()
    workbench.set_default(_OPTION_NAME, "False")

    # test
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    # test
    workbench.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    # teardown
    workbench.destroy()

# Generated at 2022-06-22 03:10:03.412640
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = ""
    
    wb = get_workbench()
    wb._simple_mode = True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    
    wb._simple_mode = False
    wb._set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"
    
    wb._set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"