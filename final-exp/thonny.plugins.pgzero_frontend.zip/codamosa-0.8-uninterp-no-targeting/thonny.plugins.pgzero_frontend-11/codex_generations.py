

# Generated at 2022-06-22 03:00:29.000676
# Unit test for function load_plugin
def test_load_plugin():
    global get_workbench, get_option
    from thonny.workbench import Workbench
    from thonny.options_page import OptionsPage

    def get_option(self, name):
        assert name == _OPTION_NAME
        return False

    def get_workbench():
        return Workbench(OptionsPage())

    from thonny.languages import tr

    def tr(s):
        return s

    import sys

    orig_environ = sys.modules["os"].environ

# Generated at 2022-06-22 03:00:40.088303
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.plugins.backend_options.backend_option import BackendOption
    wb = Workbench()
    wb.in_simple_mode = lambda: False
    wb.set_default(_OPTION_NAME, False)
    wb.get_option = lambda s: False
    os.environ["PGZERO_MODE"] = "auto"
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0",\
        "PGZERO_MODE should be '0' when in non-simple mode and run.pgzero_mode is False"
    wb.in_simple_mode = lambda: True
    update_environment()

# Generated at 2022-06-22 03:00:46.369429
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    assert get_workbench().in_simple_mode() == False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-22 03:00:56.761441
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.workbench import Workbench
    from thonny.memory import Memory
    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.create()
    assert not wb.get_option(_OPTION_NAME)
    toggle_variable()
    assert wb.get_option(_OPTION_NAME)
    toggle_variable()
    assert not wb.get_option(_OPTION_NAME)

# Generated at 2022-06-22 03:01:04.390121
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    wb.disable_simple_mode()
    assert os.environ["PGZERO_MODE"] == "False"
    wb.enable_simple_mode()
    assert os.environ["PGZERO_MODE"] == "auto"

    wb.disable_simple_mode()
    wb.set_option(_OPTION_NAME, True)
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 03:01:06.025911
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    load_plugin()

# Generated at 2022-06-22 03:01:16.019984
# Unit test for function update_environment
def test_update_environment():
    from thonny.globals import get_workbench

    wb = get_workbench()
    wb.set_simple_mode(False)
    wb.set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    wb.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    wb.set_simple_mode(False)
    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 03:01:26.303224
# Unit test for function toggle_variable
def test_toggle_variable():
    # Test the case when there is no prior information from the user
    # regarding this option.
    config = configparser.ConfigParser()
    config.read("thonny/config.ini")
    if "run" in config:
        if config["run"]["pgzero_mode"]:
            # Test the case when the user has selected this option,
            # and so the function should disable it.
            get_workbench().set_option("run.pgzero_mode", True)
            toggle_variable()
            assert not get_workbench().get_option("run.pgzero_mode")
        else:
            # Test the case when the user has not selected this option,
            # and so the function should enable it.
            get_workbench().set_option("run.pgzero_mode", False)
            toggle_variable()

# Generated at 2022-06-22 03:01:29.490342
# Unit test for function toggle_variable
def test_toggle_variable():
    old_var = get_workbench().get_variable(_OPTION_NAME)
    old_var.set(1)
    toggle_variable()
    new_var = get_workbench().get_variable(_OPTION_NAME)
    assert old_var.get() != new_var.get()

# Generated at 2022-06-22 03:01:32.333531
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 03:01:41.390901
# Unit test for function toggle_variable
def test_toggle_variable():
    try:
        del os.environ["PGZERO_MODE"]
    except:
        pass
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 03:01:45.656806
# Unit test for function load_plugin
def test_load_plugin():
    """
    This unit test checks that the plugin loaded with no errors and
    registration of the commands was successful 
    """
    wb = get_workbench()
    assert _OPTION_NAME in wb.get_default_values()


# Generated at 2022-06-22 03:01:52.513974
# Unit test for function load_plugin
def test_load_plugin():
    class TestWorkbench:
        def add_command(self, name, category, label, command, flag_name=None, group=None):
            pass

    wb = TestWorkbench()
    load_plugin()
    # no exception raised, test passed
    assert isinstance(wb.get_variable(_OPTION_NAME), bool)

# Generated at 2022-06-22 03:01:59.672241
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench
    from thonny.languages import tr
    
    _OPTION_NAME = "run.pgzero_mode"

    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()

# Generated at 2022-06-22 03:02:05.840648
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_option(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) is True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) is False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) is True

# Generated at 2022-06-22 03:02:09.330925
# Unit test for function update_environment
def test_update_environment():
    os._called_from_test = True
    try:
        wb = get_workbench()

        wb.set_option(_OPTION_NAME, True)
        update_environment()
        assert os.environ["PGZERO_MODE"] == "True"

        wb.set_option(_OPTION_NAME, False)
        update_environment()
        assert os.environ["PGZERO_MODE"] == "False"

        wb.set_option(_OPTION_NAME, None)
        update_environment()
        assert os.environ["PGZERO_MODE"] == "auto"

    finally:
        del os._called_from_test

# Generated at 2022-06-22 03:02:19.741200
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.shell import ShellTextWidget, ShellTextScrollbar
    from thonny.shell import Shell, SubprocessConnection
    from thonny.config_ui import ConfigurationPage
    from thonny.globals import get_runner, get_shell
    wb = Workbench()
    wb._set_variable(_OPTION_NAME, True)
    wb._set_variable("run.debug_mode", False)
    wb.insert_command_set("simple_mode")
    wb.insert_command_set("shell")
    wb.insert_command_set("view")
    wb.insert_command_set("runner")
    wb.insert_command_set("register_commands")
    wb.insert_command_set("register_menu")

# Generated at 2022-06-22 03:02:32.217666
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import Mock

    get_workbench = Mock()
    get_workbench.in_simple_mode = Mock(return_value = True)
    get_workbench.get_option = Mock(return_value = False)

    os.environ = {}
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench.in_simple_mode = Mock(return_value = False)
    get_workbench.get_option = Mock(return_value = True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"

    get_workbench.in_simple_mode = Mock(return_value = False)
    get_workbench.get_option = Mock(return_value = False)
    update_

# Generated at 2022-06-22 03:02:40.588173
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import Mock, patch
    from thonny.workbench import Workbench
    from thonny.config_ui import ConfigurationPage
    import thonny.workbench
    thonny.workbench.get_workbench = Mock(return_value=Workbench())
    wb = Workbench()
    wb.get_variable = Mock()
    wb.in_simple_mode = Mock(return_value=True)
    wb.set_default = Mock()
    wb.add_command = Mock()
    page = ConfigurationPage(wb)
    page.create_widgets()
    # Test toggling Pygame Zero mode on
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()

# Generated at 2022-06-22 03:02:48.909176
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny import get_workbench
    from thonny.globals import get_runner
    from thonny.plugins.run import ConfigurationPage
    from thonny.testing.tiny_test import test_toggle, enable_for_one_test
    import os

    enable_for_one_test("test_toggle_variable")
    test_toggle("run.pgzero_mode", ConfigurationPage)
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"



# Generated at 2022-06-22 03:03:06.061215
# Unit test for function toggle_variable
def test_toggle_variable():
    from unittest.mock import Mock
    from unittest.mock import MagicMock

    # Set up a workbench mock object
    workbench = Mock()
    workbench.get_variable = Mock()
    workbench.get_variable.return_value = MagicMock()
    workbench.get_variable.return_value.set = Mock()
    workbench.get_variable.return_value.get = Mock()

    # Set up a default false value
    workbench.get_variable.return_value.get.return_value = False

    # Run toggle_variable
    toggle_variable()

    # Make sure that get_variable was called
    assert workbench.get_variable.called

    # Make sure that set was called and the return value is True
    assert workbench.get_variable.return_value.set.called


# Generated at 2022-06-22 03:03:18.005927
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = "auto"
    get_workbench().set_simple_mode(True)
    update_environment()
    print(os.environ["PGZERO_MODE"])
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    print(os.environ["PGZERO_MODE"])
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    print(os.environ["PGZERO_MODE"])

# Generated at 2022-06-22 03:03:28.828279
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    load_plugin()
    assert wb.get_option(_OPTION_NAME) is False
    assert not wb.get_option(_OPTION_NAME, True)
    assert wb.get_global_variable("PGZERO_MODE") == "auto"
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) is True
    assert wb.get_global_variable("PGZERO_MODE") == "True"
    wb.configure_simple_mode(True)
    update_environment()
    assert wb.get_global_variable("PGZERO_MODE") == "auto"
    wb.configure_simple_mode(False)
    update_environment()

# Generated at 2022-06-22 03:03:31.892019
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert get_workbench().get_variable(_OPTION_NAME).get() == False



# Generated at 2022-06-22 03:03:35.925553
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert "PGZERO_MODE" in os.environ
    assert os.environ["PGZERO_MODE"] == "True"



# Generated at 2022-06-22 03:03:46.052488
# Unit test for function update_environment
def test_update_environment():
    import sys
    import os
    import tkinter as tk

    root = tk.Tk()
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 03:03:56.047632
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench

    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().in_simple_mode = True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().in_simple_mode = False
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 03:04:05.751658
# Unit test for function update_environment
def test_update_environment():
    from unittest import mock
    from thonny.common import InlineCommand

    with mock.patch("os.environ"):
        update_environment()
        assert os.environ["PGZERO_MODE"] == "auto"

    with mock.patch("os.environ"):
        get_workbench().set_default(_OPTION_NAME, True)
        update_environment()
        assert os.environ["PGZERO_MODE"] == "1"

    with mock.patch("os.environ"):
        get_workbench().set_default(_OPTION_NAME, False)
        update_environment()
        assert os.environ["PGZERO_MODE"] == "0"

# Generated at 2022-06-22 03:04:08.648110
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_option(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME)
    toggle_variable()
    assert not get_workbench().get_option(_OPTION_NAME)

# Generated at 2022-06-22 03:04:16.635052
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    wb.set_simple_mode(False)

    if not wb.in_simple_mode():
        wb.set_option(_OPTION_NAME, False)
        toggle_variable()
        assert wb.get_option(_OPTION_NAME) == True
        toggle_variable()
        assert wb.get_option(_OPTION_NAME) == False
        wb.set_option(_OPTION_NAME, True)

# Generated at 2022-06-22 03:04:32.462905
# Unit test for function toggle_variable
def test_toggle_variable():
    # get_workbench().add_command
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-22 03:04:38.493899
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    prev_value = wb.get_option("run.pgzero_mode")
    toggle_variable()
    assert wb.get_option("run.pgzero_mode") != prev_value
    toggle_variable()
    assert wb.get_option("run.pgzero_mode") == prev_value

# Generated at 2022-06-22 03:04:45.635252
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 03:04:54.751692
# Unit test for function toggle_variable
def test_toggle_variable():
    from unittest import mock
    import tkinter as tk
    root = tk.Tk()
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, True)
    assert wb.get_option(_OPTION_NAME)
    assert "PGZERO_MODE" in os.environ and os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert not wb.get_option(_OPTION_NAME)
    assert "PGZERO_MODE" in os.environ and os.environ["PGZERO_MODE"] == "False"
    root.destroy()


# Generated at 2022-06-22 03:04:57.120207
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()

# Generated at 2022-06-22 03:05:00.721146
# Unit test for function toggle_variable
def test_toggle_variable():
    try:
        del os.environ["PGZERO_MODE"]
    except KeyError:
        pass

    toggle_variable()
    assert "1" == os.environ["PGZERO_MODE"]

    toggle_variable()
    assert "0" == os.environ["PGZERO_MODE"]

    toggle_variable()
    assert "1" == os.environ["PGZERO_MODE"]


# Generated at 2022-06-22 03:05:12.181134
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from unittest import mock
    import builtins
    import sys

    reset_sys_modules = dict(sys.modules)
    mock_get_workbench = mock.MagicMock(Workbench)
    builtins.get_workbench = mock_get_workbench
    workbench_mock = mock.MagicMock()
    mock_get_workbench.return_value = workbench_mock
    workbench_mock.get_option.return_value = True
    load_plugin()
    mock_get_workbench.assert_called()
    workbench_mock.get_option.assert_called_with(_OPTION_NAME)
    workbench_mock.set_default.assert_called_with(_OPTION_NAME, False)
    workbench_mock

# Generated at 2022-06-22 03:05:14.815959
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == 'True'
    
    
    


# Generated at 2022-06-22 03:05:22.156843
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    assert not get_workbench().in_simple_mode()
    assert get_workbench().get_option(_OPTION_NAME) == False

    get_workbench().set_default(_OPTION_NAME, True)
    load_plugin()
    assert not get_workbench().in_simple_mode()
    assert get_workbench().get_option(_OPTION_NAME) == True

# Generated at 2022-06-22 03:05:30.718878
# Unit test for function update_environment
def test_update_environment():
    if os.environ.get("THONNY_TEST_MODE"):
        wb = get_workbench()
        wb.set_simple_mode(True)
        assert os.environ.get("PGZERO_MODE") == "auto"
        wb.set_simple_mode(False)
        wb.set_option(_OPTION_NAME, True)
        update_environment()
        assert os.environ.get("PGZERO_MODE") == "True"
        wb.set_option(_OPTION_NAME, False)
        assert os.environ.get("PGZERO_MODE") == "False"

# Generated at 2022-06-22 03:05:57.466342
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    assert toggle_variable(), True
    assert toggle_variable(), False
    assert toggle_variable(), True
    assert toggle_variable(), False

# Generated at 2022-06-22 03:06:05.395064
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_in_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().set_in_simple_mode(False)
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"

    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"

# Generated at 2022-06-22 03:06:07.346474
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True

# Generated at 2022-06-22 03:06:19.152670
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from unittest.mock import Mock
    from unittest.mock import patch
    from unittest import mock

    mock_gettext = mock.MagicMock()
    mock_gettext.gettext.return_value = "gettext"
    mock_gettext.ngettext.return_value = "ngettext"

    mock_tk = Mock(Tk)
    gettext = Mock()
    gettext.gettext = mock_gettext.gettext
    gettext.ngettext = mock_gettext.ngettext

    with patch("thonny.workbench.Tk", mock_tk), patch("thonny.workbench.gettext", gettext):

        test_workbench = Workbench(mock_tk)
        load_plugin()

       

# Generated at 2022-06-22 03:06:30.546197
# Unit test for function update_environment
def test_update_environment():
    from thonny.workflow import SimpleMode

    get_workbench().set_option(_OPTION_NAME, True)
    get_workbench().set_simple_mode_enabled(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_option(_OPTION_NAME, False)
    get_workbench().set_simple_mode_enabled(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_option(_OPTION_NAME, True)
    get_workbench().set_simple_mode_enabled(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 03:06:39.148615
# Unit test for function toggle_variable
def test_toggle_variable():
    try:
        load_plugin()
        toggle_variable()
        assert (
            str(get_workbench().get_option(_OPTION_NAME)) == "True"
        ), "Expecting variable to be True"
        toggle_variable()
        assert (
            str(get_workbench().get_option(_OPTION_NAME)) == "False"
        ), "Expecting variable to be False"
    finally:
        get_workbench().remove_command("toggle_pgzero_mode")
        del get_workbench().config[_OPTION_NAME]

# Generated at 2022-06-22 03:06:41.956763
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, True)
    wb.set_default(_OPTION_NAME, False)
    update_environment()

# Generated at 2022-06-22 03:06:52.659695
# Unit test for function update_environment
def test_update_environment():
    if "PGZERO_MODE" in os.environ:
        del os.environ["PGZERO_MODE"]
    assert os.environ.get("PGZERO_MODE") is None
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ.get("PGZERO_MODE") == "False"
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ.get("PGZERO_MODE") == "True"
    get_workbench().in_simple_mode(True)
    update_environment()
    assert os.environ.get("PGZERO_MODE") == "auto"
    get_workbench().in_simple_mode(False)
    update_environment()
   

# Generated at 2022-06-22 03:06:58.717193
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench, get_runner, get_shell
    # pylint: disable=unused-variable
    from thonny.plugins.pgzero import get_pgz_canvas
    from thonny.languages import tr
    from thonny.plugins.pgzero.pgz_runner import PGZRunner

    # Test that the plugin has been loaded
    assert "toggle_pgzero_mode" in get_workbench().commands



# Generated at 2022-06-22 03:07:03.870551
# Unit test for function load_plugin
def test_load_plugin():
    old_value = os.environ.get("PGZERO_MODE")
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ.get("PGZERO_MODE") == "False"
    os.environ["PGZERO_MODE"] = old_value

# Generated at 2022-06-22 03:07:55.697509
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    pm = wb.get_plugin_manager()
    pm.install_plugin("pgzero_mode")
    pm.activate_plugin("pgzero_mode")
    assert wb.get_option("run.pgzero_mode") == False
    assert os.environ["PGZERO_MODE"] == "False"

    wb.set_option("run.pgzero_mode", True)
    wb.set_simple_mode()
    assert wb.get_option("run.pgzero_mode") == True
    assert os.environ["PGZERO_MODE"] == "auto"

    wb.set_simple_mode(False)
    assert wb.get_option("run.pgzero_mode") == True

# Generated at 2022-06-22 03:08:01.970549
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()
    return None

# Generated at 2022-06-22 03:08:13.720871
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.languages import en
    from thonny import get_workbench, get_runner
    from thonny.plugins.run.pgzero_mode import (
        update_environment,
        toggle_variable,
    )

    # Load plugin
    get_workbench().unset_default(_OPTION_NAME)
    load_plugin()

    # Check enviroment variable value
    assert os.environ["PGZERO_MODE"] == "False"

    # Check value of option
    var = get_workbench().get_variable(_OPTION_NAME)
    assert not var.get()

    # Check for menu item
    menu_info = get_workbench().get_menu("run")

# Generated at 2022-06-22 03:08:19.156564
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_simple_mode(True)
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == True
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == True

# Generated at 2022-06-22 03:08:22.735981
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()
    assert get_workbench().get_variable('run.pgzero_mode') == True
    toggle_variable()
    assert get_workbench().get_variable('run.pgzero_mode') == False

# Generated at 2022-06-22 03:08:30.862648
# Unit test for function update_environment
def test_update_environment():
    from thonny.globals import get_workbench
    from unittest.mock import Mock
    wb = Mock()
    wb.get_option = lambda name, default: name == _OPTION_NAME

    wb.in_simple_mode = lambda: True
    get_workbench().set_workbench(wb)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    wb.in_simple_mode = lambda: False
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 03:08:33.589976
# Unit test for function toggle_variable
def test_toggle_variable():
    assert get_workbench().get_option(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True

# Generated at 2022-06-22 03:08:38.371513
# Unit test for function toggle_variable
def test_toggle_variable():
    var = get_workbench().get_variable(_OPTION_NAME)
    toggle_variable()
    assert var.get() is True
    toggle_variable()
    assert var.get() is False
    get_workbench().in_simple_mode = lambda: True
    toggle_variable()
    assert var.get() is False
    get_workbench().in_simple_mode = lambda: False
    toggle_variable()
    assert var.get() is True

# Generated at 2022-06-22 03:08:43.848011
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock
    mock_workbench = Mock()
    mock_workbench.set_default = Mock()
    mock_workbench.add_command = Mock()
    global get_workbench
    get_workbench = lambda: mock_workbench
    load_plugin()
    mock_workbench.set_default.assert_called_once_with(_OPTION_NAME, False)

# Generated at 2022-06-22 03:08:47.369692
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny import get_workbench

    default_mode = get_workbench().get_variable(_OPTION_NAME).get()

    toggle_variable()
    new_mode = get_workbench().get_variable(_OPTION_NAME).get()

    assert new_mode != default_mode

