

# Generated at 2022-06-22 03:00:43.828188
# Unit test for function toggle_variable
def test_toggle_variable():
    from collections import namedtuple
    from thonny.globals import get_workbench
    from unittest.mock import Mock
    from unittest.mock import patch
    
    # Mock up get_workbench
    get_workbench.return_value = namedtuple('Workbench', ['get_option', 'get_variable'])
    get_workbench().get_option.return_value = False
    get_workbench().get_variable.return_value = namedtuple('Variable', ['set', 'get'])
    get_workbench().get_variable().get.return_value = False
    
    # call toggle_variable
    toggle_variable()
    
    # test get_option and get_variable called
    get_workbench().get_option.assert_called_once_with(_OPTION_NAME)

# Generated at 2022-06-22 03:00:50.815976
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    wb.set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    wb.set_option("run.run_in_simplified_mode", True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 03:00:51.551549
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()

# Generated at 2022-06-22 03:01:04.201538
# Unit test for function toggle_variable
def test_toggle_variable():
    from unittest.mock import Mock
    from thonny import get_workbench
    from thonny.common import ToplevelCommand

    # Make sure it's disabled
    get_workbench().set_default(_OPTION_NAME, False)
    # Make sure we can get the correct values
    get_workbench().get_variable(_OPTION_NAME).set(False)
    assert(get_workbench().get_option(_OPTION_NAME) == False)
    # Let's toggle it
    toggle_variable()
    assert(get_workbench().get_option(_OPTION_NAME) == True)
    
    # Make sure it's enabled
    get_workbench().set_default(_OPTION_NAME, True)
    # Make sure we can get the correct values

# Generated at 2022-06-22 03:01:10.885748
# Unit test for function update_environment
def test_update_environment():
    reset_workbench()
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 03:01:18.042426
# Unit test for function toggle_variable
def test_toggle_variable():
    class TestWorkbench:
        def __init__(self):
            self.mode = "test"
            self.env_var = False

        def set_variable(self, var_name, value):
            if var_name == _OPTION_NAME:
                self.env_var = value

        def get_variable(self, var_name):
            if var_name == _OPTION_NAME:
                return TestGetSet(self.env_var)
            return None

        def set_default(self, var_name, default):
            if var_name == _OPTION_NAME:
                self.env_var = default

        def in_simple_mode(self):
            return self.mode == "simple"

    class TestGetSet:
        def __init__(self, value):
            self.value = value


# Generated at 2022-06-22 03:01:19.885735
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable() == "False"

# Generated at 2022-06-22 03:01:30.530172
# Unit test for function toggle_variable
def test_toggle_variable():
    # Create dummy get_workbench and set_variable
    class MockCommand:
        def __init__(self):
            self.result = None
            self.name = None
            self.label = None
            self.handler = None
            self.flag_name = None
            self.group = None
        def add(self, name, category, label, handler, flag_name=None, group=None):
            self.name = name
            self.label = label
            self.handler = handler
            self.flag_name = flag_name
            self.group = group
    class MockVariable:
        def __init__(self):
            self.result = False
        def get(self):
            return self.result
        def set(self, value):
            self.result = value
    # Mock the get_workbench()

# Generated at 2022-06-22 03:01:39.412783
# Unit test for function update_environment
def test_update_environment():
    from thonny.globals import get_runner
    from thonny.misc_utils import running_on_windows
    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_simple_mode(True)
    update_environment()
    if running_on_windows():
        assert os.environ["PGZERO_MODE"] == "1"
    else:
        assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 03:01:43.390105
# Unit test for function update_environment
def test_update_environment():
    os.environ.pop("PGZERO_MODE", None)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 03:01:55.058452
# Unit test for function load_plugin
def test_load_plugin():
    import thonny.plugins.unit_testing
    import thonny.plugins.pgzero

    wb = thonny.plugins.unit_testing.get_new_workbench()
    load_plugin()
    assert wb.get_variable(_OPTION_NAME).get() == False

    thonny.plugins.pgzero.toggle_variable()
    assert wb.get_variable(_OPTION_NAME).get() == True

    thonny.plugins.pgzero.toggle_variable()
    assert wb.get_variable(_OPTION_NAME).get() == False
    
    wb.destroy()




# Generated at 2022-06-22 03:02:01.749839
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    import os

    os.environ["PGZERO_MODE"] = "auto"
    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"

    wb.set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"

# Generated at 2022-06-22 03:02:08.570222
# Unit test for function toggle_variable
def test_toggle_variable():
    kn = get_workbench().get_variable(_OPTION_NAME)
    try:
        kn.set(True)
        assert kn.get() == True
        toggle_variable()
        assert kn.get() == False
        toggle_variable()
        assert kn.get() == True
    finally:
        kn.set(False)

# Generated at 2022-06-22 03:02:14.803927
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.options import get_option
    from thonny.options import set_option

    #Test setup
    get_option("run.pgzero_mode")
    set_option("run.pgzero_mode", False)
    toggle_variable()

    #First toggle, pgzero should be true now
    assert get_option("run.pgzero_mode") == True

    #Second toggle, pgzero should be false now
    toggle_variable()
    assert get_option("run.pgzero_mode") == False

    #No more toggling allowed, so should still be false
    toggle_variable()
    assert get_option("run.pgzero_mode") == False


# Generated at 2022-06-22 03:02:23.366090
# Unit test for function update_environment
def test_update_environment():
    import thonnycontrib.pgzero_mode
    from thonny import get_workbench
    from thonny.options_page import OptionsPage
    from test.utils import run_test_driver

    def set_option(value):
        page = OptionsPage(get_workbench())
        page.show()
        page.nb.select(page.pgzero_mode_group)
        page.pgzero_mode_var.set(value)
        page.destroy()

    run_test_driver(
        lambda: thonnycontrib.pgzero_mode.load_plugin(),
        lambda: set_option(False),
        lambda: set_option(True),
        lambda: set_option(False),
    )

# Generated at 2022-06-22 03:02:31.045999
# Unit test for function toggle_variable
def test_toggle_variable():
    wb.set_variable(_OPTION_NAME, False)
    toggle_variable()
    assert wb.get_variable(_OPTION_NAME) is True
    toggle_variable()
    assert wb.get_variable(_OPTION_NAME) is False

    # Requires overrides for get_workbench() and get_option, but
    # not for wb.get_variable


# Method to set up test environment with proper get_workbench() and get_option return values

# Generated at 2022-06-22 03:02:41.056278
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny import get_workbench
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    import shutil
    from thonny.common import create_user_config_dir

    get_workbench().set_default(_OPTION_NAME, False)

    # Assure the configuration file folder exists
    create_user_config_dir()

    # Passes if toggle_variable toggles variable
    # Fails if variable remains the same
    current_var = get_workbench().get_variable(_OPTION_NAME)
    toggle_variable()
    if current_var == get_workbench().get_variable(_OPTION_NAME):
        raise AssertionError("variable remains the same after toggle_variable")

    # Delete test config files before exit

# Generated at 2022-06-22 03:02:42.356443
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert getattr(get_workbench().get_option(_OPTION_NAME), "get", None) is not None

# Generated at 2022-06-22 03:02:49.735688
# Unit test for function toggle_variable
def test_toggle_variable():
    os.environ["PGZERO_MODE"] = "False"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"
    os.environ["PGZERO_MODE"] = "auto"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 03:02:54.056194
# Unit test for function update_environment
def test_update_environment():
    import os
    os.environ["PGZERO_MODE"] = ""
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 03:03:01.985387
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench, get_runner
    get_workbench().set_option(_OPTION_NAME, False)
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 03:03:07.780022
# Unit test for function toggle_variable
def test_toggle_variable():
    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == True
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == False

# Generated at 2022-06-22 03:03:11.484178
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    assert os.environ["PGZERO_MODE"] == "False"



# Generated at 2022-06-22 03:03:13.562100
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import workbench

    workbench.get_option("run.pgzero_mode")

# Generated at 2022-06-22 03:03:21.802504
# Unit test for function load_plugin
def test_load_plugin():
    global _OPTION_NAME
    _OPTION_NAME = "test.run.pgzero_mode"

    workbench = get_workbench()
    workbench.set_default(_OPTION_NAME, True)
    workbench.add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )

    assert workbench.get_option(_OPTION_NAME) is True
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert workbench.get_option(_OPTION_NAME) is False
    assert os.environ["PGZERO_MODE"] == "False"


# Generated at 2022-06-22 03:03:26.761773
# Unit test for function toggle_variable
def test_toggle_variable():
    try:
        os.environ["PGZERO_MODE"] = ""
        toggle_variable()
        assert os.environ["PGZERO_MODE"] == "True"

        toggle_variable()
        assert os.environ["PGZERO_MODE"] == "False"
    except Exception as e:
        print(e)

# Generated at 2022-06-22 03:03:38.293438
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, True)
    load_plugin()
    assert not get_workbench().in_simple_mode()
    assert get_workbench().get_option(_OPTION_NAME) is True
    assert get_workbench().get_variable(_OPTION_NAME) is not None

    get_workbench().unload_plugin("thonny.plugins.pgzero")
    get_workbench().set_default(_OPTION_NAME, True)
    from thonny.plugins.pgzero import load_plugin as test_load_plugin
    test_load_plugin()
    assert not get_workbench().in_simple_mode()
    assert get_workbench().get_option(_OPTION_NAME) is True
    assert get_workbench().get_variable(_OPTION_NAME) is not None

# Generated at 2022-06-22 03:03:42.182385
# Unit test for function toggle_variable
def test_toggle_variable():
    var = get_workbench().get_variable(_OPTION_NAME)
    var.set(True)
    toggle_variable()
    assert var.get() == False
    toggle_variable()
    assert var.get() == True

# Generated at 2022-06-22 03:03:45.106469
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ.get("PGZERO_MODE") == "False"
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ.get("PGZERO_MODE") == "True"


load_plugin()

# Generated at 2022-06-22 03:03:50.584560
# Unit test for function toggle_variable
def test_toggle_variable():
    from unittest import mock
    get_workbench().set_option(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME)
    with mock.patch("os.environ") as env:
        toggle_variable()
        assert env["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 03:04:08.838676
# Unit test for function toggle_variable
def test_toggle_variable():
    # case 1
    for i in range(0, 4):
        tv = toggle_variable()
        if get_workbench().get_option("run.pgzero_mode"):
            assert get_workbench().get_option("run.pgzero_mode") == False
        else:
            assert get_workbench().get_option("run.pgzero_mode") == True
    # case 2
    toggle_variable()
    assert get_workbench().get_option("run.pgzero_mode") == False
    toggle_variable()
    assert get_workbench().get_option("run.pgzero_mode") == True



# Generated at 2022-06-22 03:04:13.538885
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench
    from thonny.plugin_utils import is_visible_command
    load_plugin()
    assert is_visible_command("toggle_pgzero_mode")

# Generated at 2022-06-22 03:04:21.609874
# Unit test for function load_plugin
def test_load_plugin():
    output_filename = __file__.replace(".py", ".output")
    global gettext, ngettext
    import builtins
    real_gettext = builtins.__dict__["_"]
    real_ngettext = builtins.__dict__["_n"]

    def new_gettext(source):
        return real_gettext(source).replace("Pygame Zero mode", "XXX")

    def new_ngettext(singular, plural, n):
        return real_ngettext(singular, plural, n).replace("Pygame Zero mode", "ZZZ")

    builtins.__dict__["_"] = new_gettext
    builtins.__dict__["_n"] = new_ngettext
    from thonny import workbench


# Generated at 2022-06-22 03:04:26.562769
# Unit test for function toggle_variable
def test_toggle_variable():
    try:
        get_workbench().set_default(_OPTION_NAME, False)
        toggle_variable()
        assert os.environ["PGZERO_MODE"] == "True"
        toggle_variable()
        assert os.environ["PGZERO_MODE"] == "False"
    finally:
        del os.environ["PGZERO_MODE"]

# Generated at 2022-06-22 03:04:31.251737
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    assert not wb.get_variable(_OPTION_NAME).get()

    toggle_variable()
    assert wb.get_variable(_OPTION_NAME).get()

    toggle_variable()
    assert not wb.get_variable(_OPTION_NAME).get()

# Generated at 2022-06-22 03:04:33.158381
# Unit test for function update_environment
def test_update_environment():
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 03:04:38.672801
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    assert get_workbench().get_variable(_OPTION_NAME).get() == False


# Generated at 2022-06-22 03:04:44.072835
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, True)
    assert get_workbench().get_variable(_OPTION_NAME).get() == True
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == True

# Generated at 2022-06-22 03:04:50.073227
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    assert get_workbench().get_option(_OPTION_NAME) == False
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False
    # TODO: check environment variable
    # os.environ["PGZERO_MODE"] == ""

# Generated at 2022-06-22 03:04:56.721193
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench, get_runner

    get_workbench().in_simple_mode = lambda: True
    get_workbench().add_command = lambda *args, **kwargs: None
    get_workbench().get_option = lambda *args, **kwargs: None
    get_workbench().set_default = lambda *args, **kwargs: None
    get_workbench().set_variable = lambda *args, **kwargs: None

    # This is how Thonny tests plugins.
    # See https://bitbucket.org/plas/thonny/src/default/thonny/testing/plugins.py
    #
    # Normally a plugin is loaded by Thonny, which calls load_plugin().
    # To run the test, we need to create the module manually, call load_plugin() and check

# Generated at 2022-06-22 03:05:25.414118
# Unit test for function update_environment
def test_update_environment():
    get_workbench().add_variable(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 03:05:33.269002
# Unit test for function update_environment
def test_update_environment():
    initial_value = os.environ.get("PGZERO_MODE")

# Generated at 2022-06-22 03:05:37.929933
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert "PGZERO_MODE" not in os.environ



# Generated at 2022-06-22 03:05:43.100284
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, True)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()

# Generated at 2022-06-22 03:05:46.037440
# Unit test for function toggle_variable
def test_toggle_variable():
    assert get_workbench().get_option(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True



# Generated at 2022-06-22 03:05:47.804735
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert get_workbench().get_default(_OPTION_NAME) == False



# Generated at 2022-06-22 03:05:56.476143
# Unit test for function toggle_variable
def test_toggle_variable():
    """Unit test for function toggle_variable"""
    toggle_variable()
    if get_workbench().get_variable(_OPTION_NAME).get():
        assert os.environ["PGZERO_MODE"] == "True"
    else:
        assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    if get_workbench().get_variable(_OPTION_NAME).get():
        assert os.environ["PGZERO_MODE"] == "True"
    else:
        assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 03:06:07.577072
# Unit test for function update_environment
def test_update_environment():
    # clean environment
    del os.environ["PGZERO_MODE"]

    # Initial state
    get_workbench().set_default(_OPTION_NAME, False)
    assert os.environ.get("PGZERO_MODE") is None

    # Switch on Pygame Zero mode
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ.get("PGZERO_MODE") == "True"

    # Switch off Pygame Zero mode
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ.get("PGZERO_MODE") == "False"

    # Enter simple mode
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().set_simple

# Generated at 2022-06-22 03:06:11.150565
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME)

# Generated at 2022-06-22 03:06:12.183546
# Unit test for function load_plugin
def test_load_plugin():
    # No checking
    pass

# Generated at 2022-06-22 03:07:02.006429
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, True)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False



# Generated at 2022-06-22 03:07:11.760901
# Unit test for function update_environment
def test_update_environment():
    import os.path
    import tempfile
    from thonny import get_workbench, load_workbench

    workbench_location = os.path.join(tempfile.gettempdir(), "thonny", "test")
    get_workbench().set_option("general.workbench_location", workbench_location)

    # We need to call load_workbench because plugins may have added commands
    # and we need to have the full command collection
    load_workbench()

    # Spoof simple mode
    get_workbench().set_simple_mode(True)

    # Set environment to something different than the default value
    os.environ["PGZERO_MODE"] = "non_default"

    # Call the function
    update_environment()

    # Check result

# Generated at 2022-06-22 03:07:18.014815
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 03:07:22.605468
# Unit test for function toggle_variable
def test_toggle_variable():
    mw = get_workbench()
    mw.set_option(_OPTION_NAME, True)
    toggle_variable()
    assert mw.get_option(_OPTION_NAME) == False
    toggle_variable()
    assert mw.get_option(_OPTION_NAME) == True

# Generated at 2022-06-22 03:07:25.542863
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == False
    get_workbench().set_option(_OPTION_NAME, True)
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-22 03:07:31.359488
# Unit test for function load_plugin
def test_load_plugin():
    import unittest.mock
    get_workbench().in_simple_mode = lambda: True
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"


if __name__ == "__main__":
    load_plugin()

# Generated at 2022-06-22 03:07:41.523583
# Unit test for function update_environment
def test_update_environment():
    """Set environment variable PGZERO_MODE for Pygame Zero mode"""
    # Set environment variable to False
    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"
    
    # Set environment variable to True
    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"
    
    # Set environment variable to auto
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 03:07:47.242218
# Unit test for function update_environment
def test_update_environment():
    from thonny.ui_utils import clear_environment
    clear_environment()
    assert os.environ.get("PGZERO_MODE") is None

    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().in_simple_mode = lambda: True
    update_environment()
    assert os.environ.get("PGZERO_MODE")=="auto"

    get_workbench().set_default(_OPTION_NAME, True)
    get_workbench().in_simple_mode = lambda: False
    update_environment()
    assert os.environ.get("PGZERO_MODE")=="True"

    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().in_simple_mode = lambda: False
    update_environment()
   

# Generated at 2022-06-22 03:07:54.497102
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    assert os.environ["PGZERO_MODE"] == "auto"

    # Test if toggle works
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    assert get_workbench().get_variable(_OPTION_NAME).get() == True
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert get_workbench().get_variable(_OPTION_NAME).get() == False


# Generated at 2022-06-22 03:08:04.397022
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().in_simple_mode = lambda: True

    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    assert os.environ["PGZERO_MODE"] == "auto"
    
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == True
    assert os.environ["PGZERO_MODE"] == "True"
    
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    assert os.environ["PGZERO_MODE"] == "False"
    
    get_workbench().in_simple_mode = lambda: False
    
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == True
    assert os

# Generated at 2022-06-22 03:10:02.427781
# Unit test for function toggle_variable
def test_toggle_variable():
    from unittest.mock import Mock
    from thonny.globals import get_workbench, get_runner
    wb = get_workbench()
    wb._variable_db = {"run.pgzero_mode": Mock()}
    toggle_variable()
    assert wb.get_variable("run.pgzero_mode").get.called
    assert wb.get_runner().switch_pgzero_mode.called

# Generated at 2022-06-22 03:10:05.020885
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()
    assert os.environ['PGZERO_MODE'] == 'True'
    toggle_variable()
    assert os.environ['PGZERO_MODE'] == 'False'

# Generated at 2022-06-22 03:10:13.281494
# Unit test for function update_environment
def test_update_environment():
    del os.environ["PGZERO_MODE"]  # in case it is already set
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 03:10:19.226717
# Unit test for function update_environment
def test_update_environment():
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 03:10:24.744692
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    assert not wb.in_simple_mode()
    assert get_workbench().get_option(_OPTION_NAME) is False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) is True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) is False



# Generated at 2022-06-22 03:10:30.886903
# Unit test for function toggle_variable
def test_toggle_variable():
    from unittest import mock

    mb = mock.MagicMock()
    with mock.patch("thonny.workbench.Workbench", return_value=mb):
        load_plugin()

        assert mb.get_option(_OPTION_NAME) == False

        toggle_variable()

        assert mb.get_option(_OPTION_NAME) == True

# Generated at 2022-06-22 03:10:38.188872
# Unit test for function load_plugin
def test_load_plugin():
    from unittest import mock
    from thonny.workbench import Workbench

    wb = Workbench(mock.MagicMock())
    with mock.patch.dict(os.environ, {}, clear=True):
        load_plugin()
        assert "PGZERO_MODE" in os.environ
        assert os.environ["PGZERO_MODE"] == "False"
        assert "PGZERO_MODE" in wb.get_option(_OPTION_NAME)
        assert wb.get_option(_OPTION_NAME)["PGZERO_MODE"] == "False"
