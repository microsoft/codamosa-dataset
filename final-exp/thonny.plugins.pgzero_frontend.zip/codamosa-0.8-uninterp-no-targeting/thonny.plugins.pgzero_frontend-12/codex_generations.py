

# Generated at 2022-06-22 03:00:43.366058
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_option(_OPTION_NAME, False)
    assert(get_workbench().get_option(_OPTION_NAME) == False)
    toggle_variable()
    assert(get_workbench().get_option(_OPTION_NAME) == True)
    toggle_variable()
    assert(get_workbench().get_option(_OPTION_NAME) == False)


# Generated at 2022-06-22 03:00:50.074023
# Unit test for function toggle_variable
def test_toggle_variable():
    # Case1: PGZero is NOT enabled
    get_workbench().set_option(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    # Case2: PGZero is enabled
    get_workbench().set_option(_OPTION_NAME, True)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False
    get_workbench().set_option(_OPTION_NAME, False)

# Generated at 2022-06-22 03:00:58.131081
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    load_plugin()
    assert wb.get_variable(_OPTION_NAME)
    assert wb.get_plugin_object(__name__) == sys.modules[__name__]
    assert wb.get_commands()
    # cleanup
    assert _OPTION_NAME in wb.variable_set
    del wb.variable_set[_OPTION_NAME]
    wb.remove_command("toggle_pgzero_mode")

# Generated at 2022-06-22 03:00:58.774656
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()

# Generated at 2022-06-22 03:01:01.769736
# Unit test for function toggle_variable
def test_toggle_variable():
    load_plugin()
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 03:01:13.170873
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == True
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == True
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == True
    toggle_variable()

# Generated at 2022-06-22 03:01:25.038140
# Unit test for function toggle_variable
def test_toggle_variable():

    class TestWB(object):
        def set_variable(self, name, value):
            self.name = name
            self.value = value

        def get_variable(self, name):
            self.name = name
            self.getter = TestGetVariable()
            return self.getter

        def in_simple_mode(self):
            return self.simple

    class TestGetVariable(object):
        def set(self, value):
            self.setter = value

        def get(self):
            return self.setter

    class TestEnv(object):
        environ = {}

    t = TestWB()
    os.environ = TestEnv()
    toggle_variable()
    assert t.name == _OPTION_NAME
    assert t.value is True
    assert t.getter.setter is True


# Generated at 2022-06-22 03:01:30.438315
# Unit test for function update_environment
def test_update_environment():
    del os.environ["PGZERO_MODE"]
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_simple_mode(True)
    del os.environ["PGZERO_MODE"]
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 03:01:40.328618
# Unit test for function update_environment
def test_update_environment():
    # In simple mode, pgzero_mode is set to auto
    orig_simple_mode = get_workbench().in_simple_mode
    get_workbench().in_simple_mode = lambda: True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().in_simple_mode = orig_simple_mode

    # PGZERO_MODE is set to value of pgzero_mode option
    orig_get_option = get_workbench().get_option
    get_workbench().get_option = lambda name: name == _OPTION_NAME
    update_environment()
    assert os.environ["PGZERO_MODE"] == str(True)
    get_workbench().get_option = orig_get_option

# Generated at 2022-06-22 03:01:45.419034
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import MagicMock
    from thonny.workbench import Workbench

    get_workbench = MagicMock(return_value=Workbench())
    get_workbench.get_variable = MagicMock()
    get_workbench.get_variable.return_value = "False"
    get_workbench.set_default = MagicMock()
    get_workbench.add_command = MagicMock()
    toggle_variable = MagicMock()

    orig_get_workbench = thonny.plugins.pgzero.get_workbench
    thonny.plugins.pgzero.get_workbench = get_workbench

# Generated at 2022-06-22 03:01:53.242818
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    from thonny import get_workbench

    assert get_workbench().get_default("run.pgzero_mode") is False

# Generated at 2022-06-22 03:01:59.028239
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    assert get_workbench().get_option(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False


# Generated at 2022-06-22 03:02:03.414524
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 03:02:08.166550
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, True)
    load_plugin()
    assert isinstance(wb.get_command("toggle_pgzero_mode"), dict)

# Generated at 2022-06-22 03:02:12.563512
# Unit test for function toggle_variable
def test_toggle_variable():

    workbench = get_workbench()
    option = workbench.get_variable(_OPTION_NAME)
    assert option.get() == False

    toggle_variable()
    assert option.get() == True

    toggle_variable()
    assert option.get() == False

if __name__ == "__main__":
    test_toggle_variable()

# Generated at 2022-06-22 03:02:18.692735
# Unit test for function update_environment
def test_update_environment():
    from test.test_thonny.test_config_page import get_workbench_with_config_page

    wb = get_workbench_with_config_page()
    wb.set_default(_OPTION_NAME, False)
    assert os.environ["PGZERO_MODE"] == "auto"
    wb.set_default(_OPTION_NAME, True)
    assert os.environ["PGZERO_MODE"] == "1"

# Generated at 2022-06-22 03:02:23.578384
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench
    import os
    from thonny.languages import tr
    load_plugin()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 03:02:35.030468
# Unit test for function load_plugin
def test_load_plugin():
    import thonnycontrib.pgzero_mode
    from thonny import get_workbench
    from thonny.common import InlineCommand
    from thonny.globals import get_workbench
    from thonny.languages import tr
    from thonny.plugins.run import RunCommandView

    workbench = get_workbench()
    workbench.unregister_command("toggle_pgzero_mode")
    workbench.set_default(_OPTION_NAME, False)
    thonnycontrib.pgzero_mode.load_plugin()
    # Test if toggle_variable() was registered and called
    assert workbench.get_variable(_OPTION_NAME).get() is False
    workbench.event_generate("OpenRunCommandView", {"view_class": RunCommandView})
    workbench.event_gener

# Generated at 2022-06-22 03:02:36.289006
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert get_workbench().get_variable(_OPTION_NAME)

# Generated at 2022-06-22 03:02:50.108758
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default("run.pgzero_mode", False)
    load_plugin()
    assert get_workbench().get_variable("run.pgzero_mode").get() == False
    assert get_workbench().get_variable("run.pgzero_mode").get() == False
    os.environ["PGZERO_MODE"] = "auto"
    get_workbench().in_simple_mode() == True
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().in_simple_mode() == False
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_default("run.pgzero_mode", True)
    get_workbench().get_option("run.pgzero_mode") == True

# Generated at 2022-06-22 03:03:10.501560
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import Mock

    workbench = Mock()
    workbench.in_simple_mode.return_value = False
    workbench.get_option.return_value = False
    get_workbench.return_value = workbench

    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    workbench.in_simple_mode.return_value = True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 03:03:19.188754
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench

    w = Workbench()
    w.in_simple_mode = lambda : False

    with mock.patch("thonny.workbench.Workbench.get_option") as get_option:
        get_option.return_value = True
        update_environment()
        assert os.environ["PGZERO_MODE"] == "True"
        get_option.return_value = False
        update_environment()
        assert os.environ["PGZERO_MODE"] == "False"
        os.environ.pop("PGZERO_MODE")

    w.in_simple_mode = lambda : True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    os.environ.pop("PGZERO_MODE")

# Generated at 2022-06-22 03:03:30.240352
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.config_ui import ConfigurationPage
    import tkinter as tk
    from thonny.memory import GlobalScope

    #  1. Create dummy workbench object, save default pgzero mode state
    workbench = Workbench()
    workbench.set_default(_OPTION_NAME, False)

    #  2. Create dummy event handler and save the Default PGZero Mode option
    def dummy_event_handler(self, event):
        self.default_pgzero_mode_var.set(self.default_pgzero_mode_var.get())
    ConfigurationPage.__init__ = dummy_event_handler

    #  3. Create dummy master object, add this page to the configuration window
    master = tk.Tk()
    dummy_page = ConfigurationPage(master)



# Generated at 2022-06-22 03:03:35.465888
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 03:03:44.379183
# Unit test for function load_plugin
def test_load_plugin():
    # this function is called by Thonny
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()
    assert os.environ["PGZERO_MODE"] == str(get_workbench().get_option(_OPTION_NAME))


if __name__ == "__main__":
    # this script is called by Thonny
    load_plugin()

# Generated at 2022-06-22 03:03:50.451999
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_global_option("pgzero_mode", False)
    assert get_workbench().get_global_option("pgzero_mode") == False
    toggle_variable()
    assert get_workbench().get_global_option("pgzero_mode") == True
    toggle_variable()
    assert get_workbench().get_global_option("pgzero_mode") == False

# Generated at 2022-06-22 03:03:58.777416
# Unit test for function load_plugin
def test_load_plugin():
    # Instantiate workbench
    import thonny
    thonny._load_test_config()
    workbench = get_workbench()
    assert workbench.get_default(_OPTION_NAME) == False
    # Run load plugin
    load_plugin()
    # Check that the command was added to the workbench
    assert workbench.get_command("toggle_pgzero_mode")
    # Check that the option is properly set to the default value
    assert workbench.get_option(_OPTION_NAME) == False
    # Check that the environment variable has been set
    assert os.environ["PGZERO_MODE"] == "False"
    # Set the option to true
    workbench.set_option(_OPTION_NAME, True)
    # Check that the environment variable has been set

# Generated at 2022-06-22 03:04:06.186473
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    wb.set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    wb.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 03:04:07.565819
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME)

# Generated at 2022-06-22 03:04:15.189256
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 03:04:35.355187
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = "true"

    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ.get("PGZERO_MODE") == "True"

    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ.get("PGZERO_MODE") == "False"

    get_workbench().in_simple_mode = lambda: True
    update_environment()
    assert os.environ.get("PGZERO_MODE") == "auto"

    del os.environ["PGZERO_MODE"]

# Generated at 2022-06-22 03:04:43.612122
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 03:04:49.983204
# Unit test for function update_environment
def test_update_environment():
    assert os.environ.get("PGZERO_MODE") is None
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ['PGZERO_MODE'] == 'False'
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ['PGZERO_MODE'] == 'True'
    get_workbench().set_default(_OPTION_NAME, 'manual')
    update_environment()
    assert os.environ['PGZERO_MODE'] == 'manual'

# Generated at 2022-06-22 03:04:52.807042
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_simple_mode(True)
    load_plugin()
    wb.set_simple_mode(False)
    load_plugin()

# Generated at 2022-06-22 03:04:57.020002
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    toggle_variable()
    variable = wb.get_variable(_OPTION_NAME)
    assert variable.get() == True

# Generated at 2022-06-22 03:05:00.171100
# Unit test for function toggle_variable
def test_toggle_variable():
    from importlib import reload
    from unittest.mock import MagicMock

    with get_execution_environment().capture_output() as captured:
        reload(__name__)
        load_plugin()
        toggle_variable()
        toggle_variable()

    output = captured.getvalue()
    assert "PGZERO_MODE" in output

# Generated at 2022-06-22 03:05:10.453264
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_workbench_settings({})
    load_plugin()
    assert wb.get_variable(_OPTION_NAME).get() == False
    assert wb.get_option(_OPTION_NAME) == False
    
    toggle_variable()
    assert wb.get_variable(_OPTION_NAME).get() == True
    assert wb.get_option(_OPTION_NAME) == True
    
    toggle_variable()
    assert wb.get_variable(_OPTION_NAME).get() == False
    assert wb.get_option(_OPTION_NAME) == False
    wb.set_workbench_settings({})

# Generated at 2022-06-22 03:05:15.117377
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_option(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME)

    get_workbench().set_option(_OPTION_NAME, True)
    toggle_variable()
    assert not get_workbench().get_option(_OPTION_NAME)

# Generated at 2022-06-22 03:05:20.698045
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().set_option(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME)
    toggle_variable()
    assert not get_workbench().get_option(_OPTION_NAME)

# Generated at 2022-06-22 03:05:30.781471
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.unload_plugin("pgzero_mode")
    wb.set_simple_mode(True)
    os.environ["PGZERO_MODE"] = "0"

# Generated at 2022-06-22 03:06:00.965107
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench

    wb = Workbench(testing=True)

    load_plugin()

    assert len(wb.get_commands()) == 1
    cmd = wb.get_commands()[0]
    assert cmd.name == "toggle_pgzero_mode"
    assert cmd.label == tr("Pygame Zero mode")  # not best practice to test translated strings
    assert cmd.group == 40
    assert cmd.flag_name == _OPTION_NAME

if __name__ == "__main__":
    test_load_plugin()

# Generated at 2022-06-22 03:06:02.133040
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()



# Generated at 2022-06-22 03:06:08.501680
# Unit test for function load_plugin
def test_load_plugin():
    assert get_workbench().get_variable(_OPTION_NAME)


if __name__ == "__main__":
    load_plugin()
    get_workbench().event_generate("Application.on_variables_changed")
    get_workbench().wait_variable(_OPTION_NAME)
    get_workbench().event_generate("Application.on_variables_changed")
    get_workbench().destroy()

# Generated at 2022-06-22 03:06:18.979955
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.in_simple_mode = lambda: True
    load_plugin()
    assert wb.get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().destroy()
    wb.in_simple_mode = lambda: False
    wb.set_default = lambda a, b: None
    load_plugin()
    assert wb.get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().destroy()


if __name__ == "__main__":
    test_load_plugin()

# Generated at 2022-06-22 03:06:30.680129
# Unit test for function load_plugin
def test_load_plugin():
    import unittest
    import thonny.workbench
    from thonny.testing import capture_output

    wb = thonny.workbench.Workbench()
    with capture_output() as (out, err):
        load_plugin()
        # print(out.getvalue())
        # print(err.getvalue())
        assert "pgzero_mode" in wb.default_config
        assert not wb.default_config["pgzero_mode"]
        assert "PGZERO_MODE" in os.environ
        assert os.environ["PGZERO_MODE"] == "False"

        wb.default_config["pgzero_mode"] = True
        update_environment()
        assert os.environ["PGZERO_MODE"] == "True"

    assert len(wb.commands) == 1

   

# Generated at 2022-06-22 03:06:42.194467
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert get_workbench().get_command("toggle_pgzero_mode")
    assert get_workbench().get_variable(_OPTION_NAME)
    assert not get_workbench().get_option(_OPTION_NAME)
    assert os.environ["PGZERO_MODE"] == "False"

    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME)
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_simple_mode(True)
    assert os.environ["PGZERO_MODE"] == "auto"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().set_simple_mode(False)

# Generated at 2022-06-22 03:06:52.909460
# Unit test for function toggle_variable
def test_toggle_variable():
    # Creating a TkInter app
    from tkinter import Tk
    from thonny.globals import get_workbench
    from thonny.plugins.run.runner import Runner
    from thonny.config_ui import ConfigurationPage

    app = Tk()
    app.withdraw()
    get_workbench().set_simple_mode(True)
    get_workbench().set_variable(_OPTION_NAME, True)
    get_workbench().set_variable("run.auto_open_io_view", True)
    get_workbench().set_variable("view.show_standard_io", False)
    update_environment()
    # Starting runner
    config = ConfigurationPage(get_workbench(), None)

# Generated at 2022-06-22 03:06:58.857823
# Unit test for function update_environment
def test_update_environment():
    if "PGZERO_MODE" in os.environ:
        del os.environ["PGZERO_MODE"]
    load_plugin()
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_simple_mode()
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 03:07:03.303429
# Unit test for function toggle_variable
def test_toggle_variable():
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"


# Generated at 2022-06-22 03:07:10.248024
# Unit test for function load_plugin
def test_load_plugin():
    # setup
    get_workbench().set_default(_OPTION_NAME, True)
    wb = get_workbench()

    # test 1
    assert os.environ["PGZERO_MODE"] == "1", os.environ["PGZERO_MODE"]

    # test 2
    wb.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto", os.environ["PGZERO_MODE"]

    # restore
    wb.set_simple_mode(False)

# Generated at 2022-06-22 03:07:37.560223
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"


# Generated at 2022-06-22 03:07:42.046233
# Unit test for function toggle_variable
def test_toggle_variable():
    clear_environment()
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    assert os.environ.get("PGZERO_MODE", "auto") == "auto"
    toggle_variable()
    assert os.environ.get("PGZERO_MODE", "auto") == "1"
    toggle_variable()
    assert os.environ.get("PGZERO_MODE", "auto") == "auto"



# Generated at 2022-06-22 03:07:51.932286
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_simple_mode(True)
    load_plugin()

    assert wb.get_variable("run.pgzero_mode").get() == False
    assert wb.get_option("run.pgzero_mode") == False
    assert os.environ["PGZERO_MODE"] == "auto"

    toggle_variable()
    assert wb.get_variable("run.pgzero_mode").get() == True
    assert wb.get_option("run.pgzero_mode") == True
    assert os.environ["PGZERO_MODE"] == "auto"

    wb.set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    toggle_variable()

# Generated at 2022-06-22 03:08:02.618478
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.clear_menu()
    load_plugin()
    wb.create_menu()
    # test command
    assert len(wb.get_commands()) == 1
    cmd = wb.get_commands()[0]
    assert cmd.name == "toggle_pgzero_mode"
    assert cmd.func == toggle_variable
    # test option
    assert wb.get_option(_OPTION_NAME) == False
    # test variable
    var = wb.get_variable(_OPTION_NAME)
    assert var.get() == False
    var.set(True)
    assert var.get() == True
    var.set(False)
    assert var.get() == False
    # test environment
    assert not "PGZERO_MODE" in os.environ

# Generated at 2022-06-22 03:08:06.444945
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert get_workbench().get_variable(_OPTION_NAME) is not None
    assert get_workbench().get_default(_OPTION_NAME) == False
    assert get_workbench().get_option(_OPTION_NAME) == False


# Generated at 2022-06-22 03:08:17.712076
# Unit test for function update_environment
def test_update_environment():
    assert "PGZERO_MODE" in os.environ
    old_value = os.environ["PGZERO_MODE"]
    os.environ["PGZERO_MODE"] = "should be overwritten"

    # Simple mode
    get_workbench().add_option("run.pgzero_mode", False)
    get_workbench().set_simple_mode()
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    # Normal mode
    get_workbench().set_normal_mode()
    get_workbench().add_option("run.pgzero_mode", True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    # Restore
    os.environ["PGZERO_MODE"] = old_value

# Generated at 2022-06-22 03:08:24.961029
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 03:08:29.661198
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME)
    toggle_variable()
    assert not get_workbench().get_variable(_OPTION_NAME)

# Generated at 2022-06-22 03:08:30.265756
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()

# Generated at 2022-06-22 03:08:36.325858
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    var = wb.get_variable(_OPTION_NAME)
    var.set(True)
    assert var.get()
    toggle_variable()
    assert not wb.get_option(_OPTION_NAME)
    assert not var.get()
    toggle_variable()
    assert wb.get_option(_OPTION_NAME)
    assert var.get()

# Generated at 2022-06-22 03:09:31.313297
# Unit test for function toggle_variable
def test_toggle_variable():
    # If plugin is not loaded, it will throw an AttributeError.
    try:
        toggle_variable()
    except AttributeError:
        pass

# Generated at 2022-06-22 03:09:39.056147
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    wb.set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    wb.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    wb.set_simple_mode(False)

# Generated at 2022-06-22 03:09:49.715123
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock
    from thonny import get_workbench

    wb = get_workbench()
    wb.get_option = Mock(return_value=True)
    wb.get_variable = Mock(return_value=True)
    wb.in_simple_mode = Mock(return_value=True)
    wb.set_default = Mock()
    wb.add_command = Mock()

    load_plugin()
    # Note: The side effect of this function is to create a variable and add a
    # command to the workbench. The only way to test this is to check if this
    # has been done.
    assert wb.add_command.called
    assert wb.set_default.called

# Generated at 2022-06-22 03:09:53.271315
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_variable(_OPTION_NAME, True)
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME) == True

# Generated at 2022-06-22 03:09:55.452173
# Unit test for function load_plugin
def test_load_plugin():
    # print(get_workbench().default_options)
    assert not get_workbench().in_simple_mode()
    assert get_workbench().get_option(_OPTION_NAME) == False


if __name__ == "__main__":
    test_load_plugin()

# Generated at 2022-06-22 03:10:06.075244
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    get_workbench().set_simple_mode(False)
    update_environment()

# Generated at 2022-06-22 03:10:17.519706
# Unit test for function update_environment
def test_update_environment():
    from test.test_thonny.helpers import run_test_driver
    from unittest.mock import patch
    from thonny.workbench import Workbench
    from thonny.plugins.pgzero_mode import update_environment
    from thonny.config import load_configuration


# Generated at 2022-06-22 03:10:28.633903
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_simple_mode(True)
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 03:10:30.456753
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 03:10:39.581782
# Unit test for function update_environment
def test_update_environment():
    import os
    from unittest.mock import MagicMock
    workbench = MagicMock()
    workbench.in_simple_mode.return_value = True
    workbench.get_option.return_value = False
    with MagicMock() as wb:
        wb.get_workbench = MagicMock(return_value=workbench)
        # from thonny.globals import get_workbench
        # get_workbench = MagicMock(return_value=workbench)
        get_workbench = wb
        # from thonny.globals import get_workbench
        # from thonny.plugins.pgzero_mode import update_environment
        update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    workbench.in_simple_mode