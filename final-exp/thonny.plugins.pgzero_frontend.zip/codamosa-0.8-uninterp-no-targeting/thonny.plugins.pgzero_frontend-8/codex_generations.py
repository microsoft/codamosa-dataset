

# Generated at 2022-06-22 03:00:42.877922
# Unit test for function update_environment
def test_update_environment():
    for value in [True, False]:
        get_workbench().set_option(_OPTION_NAME, value)
        update_environment()
        assert os.environ["PGZERO_MODE"] == str(value)
    get_workbench().set_option(_OPTION_NAME, False)
    get_workbench().enter_simple_mode()
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 03:00:46.823634
# Unit test for function update_environment
def test_update_environment():
    os.environ.clear()
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    
    

# Generated at 2022-06-22 03:00:58.973090
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    # Initialise the get_workbench() command
    load_plugin()
    # Set the 'PGZERO_MODE' environment variable to 'False' and toggle the 'PGZERO_MODE' option
    os.environ["PGZERO_MODE"] = "False"
    toggle_variable()
    assert(os.getenv("PGZERO_MODE") == "True")
    # Now set it to 'True' and toggle it again
    os.environ["PGZERO_MODE"] = "True"
    toggle_variable()
    assert(os.getenv("PGZERO_MODE") == "False")

# Generated at 2022-06-22 03:01:03.418244
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    assert os.environ["PGZERO_MODE"] == "False"



# Generated at 2022-06-22 03:01:15.561613
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = "auto"
    wb = get_workbench()
    wb._set_option("run.pgzero_mode", False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "false"
    wb._set_option("run.pgzero_mode", True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "true"
    wb._set_option("run.pgzero_mode", False)
    wb._set_option("run.simple_mode", True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    wb._set_option("run.simple_mode", False)
    update_environment()
    assert os.environ

# Generated at 2022-06-22 03:01:19.449198
# Unit test for function toggle_variable
def test_toggle_variable():
    from unittest.mock import Mock

    wb = Mock(get_variable=Mock(return_value=Mock(get=Mock(return_value=False))))
    toggle_variable()
    assert wb.get_variable.return_value.value == True



# Generated at 2022-06-22 03:01:29.181572
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().add_command(
        "toggle_pgzero_mode", "run", tr("Pygame Zero mode"), _OPTION_NAME
    )
    assert get_workbench().get_variable(_OPTION_NAME) == False
    assert os.environ.get("PGZERO_MODE", "False") == "False"
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME) == True
    assert os.environ.get("PGZERO_MODE", "False") == "True"
    load_plugin()
    assert get_workbench().get_variable(_OPTION_NAME) == False
    assert os.environ.get("PGZERO_MODE", "False") == "False"

# Generated at 2022-06-22 03:01:36.923077
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench

    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.add_command(
        "toggle_pgzero_mode", "run", tr("Pygame Zero mode"), toggle_variable, flag_name=_OPTION_NAME, group=40,
    )
    update_environment()



# Generated at 2022-06-22 03:01:42.470387
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    wb = Workbench()
    wb.set_simple_mode(False)
    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    wb.set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    wb.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 03:01:50.739437
# Unit test for function toggle_variable
def test_toggle_variable():
    # set the value as false
    get_workbench().set_option(_OPTION_NAME, False)

    # check if the value of the option is set to false
    assert get_workbench().get_option(_OPTION_NAME) == False

    # perform the toggle_variable operation which should change the value to True
    toggle_variable()

    # check if the value of the option is set to True
    assert get_workbench().get_option(_OPTION_NAME) == True

    # perform the toggle_variable operation which should change the value to False
    toggle_variable()

    # check if the value of the option is set to False
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-22 03:02:02.215180
# Unit test for function toggle_variable
def test_toggle_variable():
    # get_workbench().add_command(...) automatically calls
    # get_workbench().set_default(_OPTION_NAME, False)
    # The initial value of _OPTION_NAME should be False
    assert get_workbench().get_variable(_OPTION_NAME).get() == False

    # Call toggle_variable
    toggle_variable()

    # The value of _OPTION_NAME should now be True
    asser

# Generated at 2022-06-22 03:02:10.105612
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default(_OPTION_NAME, False)
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_default(_OPTION_NAME, True)
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_default(_OPTION_NAME, False)
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 03:02:14.747106
# Unit test for function load_plugin
def test_load_plugin():
    wb = MagicMock()

    wb.get_option.return_value = True
    toggle_variable()
    wb.set_option.assert_called_once_with(_OPTION_NAME, False)
    wb.get_option.return_value = False
    toggle_variable()
    wb.set_option.assert_called_with(_OPTION_NAME, True)

# Generated at 2022-06-22 03:02:22.337514
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import patch

    with patch.dict("os.environ"):
        get_workbench().set_simple_mode(True)
        update_environment()
        assert os.environ["PGZERO_MODE"] == "auto"

        get_workbench().set_simple_mode(False)
        update_environment()
        assert os.environ["PGZERO_MODE"] == "False"

        get_workbench().get_option(_OPTION_NAME).set(True)
        update_environment()
        assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 03:02:27.759118
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock
    get_workbench().set_variable = Mock()
    load_plugin()
    assert get_workbench().set_variable.called
    assert get_workbench().get_variable(_OPTION_NAME).get() is False

# Generated at 2022-06-22 03:02:36.624050
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"

# Generated at 2022-06-22 03:02:49.776952
# Unit test for function update_environment
def test_update_environment():
    from thonny.globals import get_runner
    from unittest.mock import MagicMock
    from thonny.configuration import get_workbench

    orig_get_workbench = get_workbench
    get_workbench_mock = MagicMock()
    get_workbench_mock.return_value = orig_get_workbench()
    get_workbench_mock.return_value.get_option.return_value = False
    get_workbench_mock.return_value.in_simple_mode.return_value = False
    update_environment()
    out, err = capsys.readouterr()
    assert "PGZERO_MODE" in out
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 03:02:57.887764
# Unit test for function load_plugin
def test_load_plugin():
    try:
        del os.environ["PGZERO_MODE"]
    except KeyError:
        pass

    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 03:03:07.830355
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()

    wb.set_default(_OPTION_NAME, False)
    wb.in_simple_mode = lambda: True
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "auto"
    assert wb.get_variable(_OPTION_NAME).get() is True

    wb.in_simple_mode = lambda: False
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"

    wb.in_simple_mode = lambda: True
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 03:03:18.796910
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock

    mb = Mock()
    mb.set_default = Mock()
    mb.add_command = Mock()
    mb.in_simple_mode = Mock(return_value=False)
    mb.get_option = Mock(return_value=False)
    load_plugin()
    assert mb.set_default.call_count == 1
    assert mb.add_command.call_count == 1
    assert os.environ["PGZERO_MODE"] == str(False)

    old_value = os.environ["PGZERO_MODE"]

    toggle_variable()
    assert mb.get_option.call_count == 1
    assert os.environ["PGZERO_MODE"] == str(True)

    toggle_variable()

# Generated at 2022-06-22 03:03:42.533376
# Unit test for function toggle_variable
def test_toggle_variable():
    old_env = dict(os.environ)

# Generated at 2022-06-22 03:03:44.768852
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get()
    toggle_variable()
    assert not get_workbench().get_variable(_OPTION_NAME).get()

# Generated at 2022-06-22 03:03:54.731809
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"

    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"

    get_workbench().in_simple_mode = lambda: True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().in_simple_mode = lambda: False
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"

# Generated at 2022-06-22 03:04:04.033757
# Unit test for function toggle_variable
def test_toggle_variable():
    from datetime import datetime

    wb = get_workbench()
    var = wb.get_variable(_OPTION_NAME)

    original_option = wb.get_option(_OPTION_NAME)
    print("Original option: " + str(original_option))

    toggle_variable()
    assert original_option != var.get()
    print("New option after one toggle: " + str(var.get()))

    toggle_variable()
    assert original_option == var.get()
    print("New option after second toggle: " + str(var.get()))

# Generated at 2022-06-22 03:04:09.598767
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    wb.set_simple_mode(False)
    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    wb.set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    wb.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 03:04:11.830875
# Unit test for function load_plugin
def test_load_plugin():
    pass


if __name__ == "__main__":
    load_plugin()

# Generated at 2022-06-22 03:04:18.858834
# Unit test for function load_plugin
def test_load_plugin():
    # GIVEN
    from unittest.mock import Mock
    from thonny.workbench import Workbench

    get_workbench = Mock(return_value=Workbench())
    orig_get_workbench = thonny.workbench.get_workbench
    thonny.workbench.get_workbench = get_workbench
    command_defs = Workbench().commands

    # WHEN
    load_plugin()
    # THEN
    thonny.workbench.get_workbench = orig_get_workbench
    assert len(command_defs) == 1

# Generated at 2022-06-22 03:04:25.361018
# Unit test for function toggle_variable
def test_toggle_variable():

    from thonny.plugins.run_pgzero_mode import toggle_variable

    get_workbench().set_default(_OPTION_NAME, True)
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == False

    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == True

# Generated at 2022-06-22 03:04:30.577504
# Unit test for function update_environment
def test_update_environment():
    # pylint: disable=unused-argument
    def mock_wb_getoption(self, *args):
        if args[0] == "run.pgzero_mode":
            return True
        return False

    def mock_wb_in_simple_mode(self, *args):
        # Side effect
        return False

    def mock_os_environ_get(self, varname):
        # Side effect
        return "auto"

    def mock_os_environ_set(self, varname, value):
        # Side effect
        global os_environ
        os_environ = varname + ":" + value

    if "PGZERO_MODE" in os.environ:
        del os.environ["PGZERO_MODE"]
    os_environ = ""


# Generated at 2022-06-22 03:04:37.314254
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()
    if get_workbench().get_option(_OPTION_NAME) == True:
        assert os.environ["PGZERO_MODE"] == str(True)
    if get_workbench().get_option(_OPTION_NAME) == False:
        assert os.environ["PGZERO_MODE"] == str(False)
    # END

# Generated at 2022-06-22 03:04:58.624460
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default("run.pygame_mode", False)
    get_workbench().set_default("run.pgzero_mode", False)
    load_plugin()
    assert get_workbench().get_option("run.pygame_mode") == True
    assert get_workbench().get_option("run.pgzero_mode") == False
    assert "PGZERO_MODE" in os.environ
    assert os.environ["PGZERO_MODE"] == "0"


if __name__ == "__main__":
    test_load_plugin()

# Generated at 2022-06-22 03:05:02.768623
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default("run.pgzero_mode", False)
    assert not get_workbench().get_variable("run.pgzero_mode").get()
    assert get_workbench().get_command("toggle_pgzero_mode")

if __name__ == "__main__":
    load_plugin()

# Generated at 2022-06-22 03:05:03.379010
# Unit test for function update_environment

# Generated at 2022-06-22 03:05:15.208775
# Unit test for function toggle_variable
def test_toggle_variable():
    if "PGZERO_MODE" in os.environ:
        old_value = os.environ["PGZERO_MODE"]

    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"

    # Unit test for function toggle_variable
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"

    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"

    # Unit test for function toggle_variable
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"

    # Restore original values
    if "PGZERO_MODE" in os.environ:
        os.environ["PGZERO_MODE"] = old_value

# Generated at 2022-06-22 03:05:15.759170
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()

# Generated at 2022-06-22 03:05:27.610970
# Unit test for function update_environment
def test_update_environment():
    from thonny.globals import set_workbench

    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    os.environ["PGZERO_MODE"] = "auto"

    # in_simple_mode=False and option value=False
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"

    # in_simple_mode=False and option value=True
    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"

    # in_simple_mode=True and option value=True
    wb.set_simple_mode(True)
    wb.set_option(_OPTION_NAME, True)
    update_

# Generated at 2022-06-22 03:05:30.189767
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert "toggle_pgzero_mode" in get_workbench().commands
    assert hasattr(get_workbench().commands["toggle_pgzero_mode"], "flag_name")

# Generated at 2022-06-22 03:05:42.965716
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench

    workbench = Workbench()
    workbench.set_default("run.command", "python3")
    workbench.set_default("run.pgzero_mode", False)

    get_workbench = lambda: workbench

    load_plugin()

    wb = get_workbench()
    assert wb.get_option("run.cmdline_options") == ""
    assert wb.get_option("run.pgzero_mode") == False
    assert os.environ["PGZERO_MODE"] == "False"

    toggle_variable()

    assert os.environ["PGZERO_MODE"] == "True"
    assert wb.get_option("run.pgzero_mode") == True



# Generated at 2022-06-22 03:05:53.458216
# Unit test for function update_environment
def test_update_environment():
    from pgzero.builtins import display
    from collections import defaultdict

    get_workbench().set_option("run.pgzero_mode", True)
    get_workbench().in_simple_mode = lambda: False
    update_environment()
    assert os.environ["PGZERO_MODE"] == "on"
    assert display.is_auto() is False
    assert display._modes == {'auto': [30, 15], 'on': [30, 15]}

    get_workbench().set_option("run.pgzero_mode", False)
    get_workbench().in_simple_mode = lambda: False
    update_environment()
    assert os.environ["PGZERO_MODE"] == "off"
    assert display.is_auto() is True

# Generated at 2022-06-22 03:05:58.670092
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    toggle_variable()
    assert wb.get_option(_OPTION_NAME)
    toggle_variable()
    assert not wb.get_option(_OPTION_NAME)


# Generated at 2022-06-22 03:06:32.463835
# Unit test for function update_environment
def test_update_environment():
    from thonny.globals import get_workbench
    from unittest.mock import patch

    with patch.dict("os.environ", {"PGZERO_MODE": "fake"}):
        # Tests if env var is set to 'auto' when in simple mode
        get_workbench().set_simple_mode(True)
        get_workbench().set_option("run.pgzero_mode", False)
        update_environment()
        assert os.environ["PGZERO_MODE"] == "auto"

        # Tests if env var is set to False (default) when not in simple mode and default
        get_workbench().set_simple_mode(False)
        get_workbench().set_option("run.pgzero_mode", False)
        update_environment()

# Generated at 2022-06-22 03:06:36.805883
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    wb.set_option("run.pgzero_mode", True)
    toggle_variable()
    wb.set_option("run.pgzero_mode", False)
    toggle_variable()

# Generated at 2022-06-22 03:06:43.110012
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_simple_mode_flag(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().set_simple_mode_flag(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 03:06:47.167757
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    load_plugin()
    assert wb.get_variable(_OPTION_NAME).get() == False
    toggle_variable()
    assert wb.get_variable(_OPTION_NAME).get() == True

# Generated at 2022-06-22 03:06:56.483148
# Unit test for function load_plugin
def test_load_plugin():
    # inside the test, get_workbench() returns mock workbench
    load_plugin()

    assert sys.platform == "darwin"

    assert get_workbench().get_default(_OPTION_NAME) == False
    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().invoke_command("toggle_pgzero_mode")
    get_workbench().perform_extra_steps()
    assert get_workbench().get_variable(_OPTION_NAME).get() == True
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().invoke_command("toggle_pgzero_mode")
    get_workbench().perform_extra_steps()
    assert get_work

# Generated at 2022-06-22 03:07:07.006927
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()
    assert "PGZERO_MODE" in os.environ
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    # Restore old state
    get_workbench().set_default(_OPTION_NAME, False)

# Generated at 2022-06-22 03:07:12.757241
# Unit test for function update_environment
def test_update_environment():
    ## This is a horrible hack to get the test cases to work.
    # I shouldn't modify the global sys.path here!
    import sys, os

    sys.path.insert(0, os.path.abspath(os.path.join(
        os.path.dirname(os.path.abspath(__file__)), "..")))
    from thonny.testing import get_runner, get_workbench
    from thonny.plugins.pgzero import update_environment
    import os

    runner = get_runner()
    runner.workbench.set_default(_OPTION_NAME, False)
    runner.workbench.set_simple_mode(False)
    update_environment()
    assert str(os.environ["PGZERO_MODE"]) == "False"


# Generated at 2022-06-22 03:07:17.925416
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.common import InlineCommand

    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME)
    toggle_variable()
    assert not get_workbench().get_option(_OPTION_NAME)

# Generated at 2022-06-22 03:07:24.779397
# Unit test for function toggle_variable
def test_toggle_variable():
    global _OPTION_NAME
    _OPTION_NAME = "test_option"

    _ = get_workbench().get_variable(_OPTION_NAME) #to initialize var.get with default value
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get()

    toggle_variable()
    assert not get_workbench().get_variable(_OPTION_NAME).get()

    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get()

# Generated at 2022-06-22 03:07:30.647407
# Unit test for function toggle_variable
def test_toggle_variable():
    from unittest.mock import Mock

    wb = Mock()
    wb.get_variable = Mock(return_value=True)
    wb.set_variable = Mock()

    toggle_variable(wb)

    wb.get_variable.assert_called_once_with(_OPTION_NAME)
    wb.set_variable.assert_called_once_with(_OPTION_NAME, False)

# Generated at 2022-06-22 03:08:28.783222
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, None)
    assert wb.get_option(_OPTION_NAME) is None

    load_plugin()

    assert wb.get_option(_OPTION_NAME) is False
    assert "PGZERO_MODE" not in os.environ
    assert os.environ["PGZERO_MODE"] == "auto"

    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"

    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 03:08:38.000701
# Unit test for function update_environment
def test_update_environment():
    os.environ.pop("PGZERO_MODE", None)
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().in_simple_mode = lambda: True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().in_simple_mode = lambda: False
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 03:08:42.729301
# Unit test for function toggle_variable
def test_toggle_variable():
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-22 03:08:46.470913
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, True)
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True

# Generated at 2022-06-22 03:08:48.597209
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert len(get_workbench().default_key_bindings) == 1
    assert get_workbench().get_default(_OPTION_NAME) == False


# Generated at 2022-06-22 03:08:52.632159
# Unit test for function load_plugin
def test_load_plugin():
    wb = Workbench()
    load_plugin()
    assert wb.get_default(_OPTION_NAME) == False
    assert wb.get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"
    os.environ["PGZERO_MODE"] = "auto"
    toggle_variable()
    assert wb.get_default(_OPTION_NAME) == False
    assert wb.get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 03:09:02.620215
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import Mock

    from thonny import get_workbench
    from thonny.plugins.run import RunCommand

    get_workbench().in_simple_mode = Mock(return_value=True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().in_simple_mode = Mock(return_value=False)
    get_workbench().add_variable(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    toggle_variable()
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 03:09:09.210951
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 03:09:15.246138
# Unit test for function load_plugin
def test_load_plugin():
    import unittest.mock as mock
    from thonny import get_workbench

    mock_workbench: mock.Mock = mock.Mock(spec=get_workbench())
    with mock.patch("thonny.plugins.pgzero.get_workbench", return_value=mock_workbench):
        load_plugin()
        mock_workbench.set_default.assert_called_once_with(_OPTION_NAME, False)
        mock_workbench.add_command.assert_called_once_with(
            "toggle_pgzero_mode",
            "run",
            "Pygame Zero mode",
            toggle_variable,
            flag_name=_OPTION_NAME,
            group=40,
        )

# Generated at 2022-06-22 03:09:24.260025
# Unit test for function toggle_variable
def test_toggle_variable():
    # Utility test function to enable/disable the PGZERO variable
    # and check the result.
    def _set_pgzero(val):
        with TemporaryDirectory() as folder:
            get_workbench().set_option("run.pgzero_mode", val)
            update_environment()
            os.chdir(folder)
            assert os.environ["PGZERO_MODE"] == ("auto" if get_workbench().in_simple_mode() else str(val))

    _set_pgzero(False)  # enabled
    _set_pgzero(True)   # disabled
    _set_pgzero(False)  # enabled
    _set_pgzero(True)   # disabled