

# Generated at 2022-06-22 03:00:15.529638
# Unit test for function load_plugin
def test_load_plugin():
    import unittest.mock
    from thonny.misc_utils import RunningPythonProcess
    from thonny import get_workbench
    from thonny.languages import tr

    w = get_workbench()
    w.set_default(_OPTION_NAME, False)

    with unittest.mock.patch.object(
        RunningPythonProcess, "send_line"
    ) as mock_send_line:
        toggle_variable()
        mock_send_line.assert_not_called()

    w.execute_command("toggle_pgzero_mode")
    assert w.get_option(_OPTION_NAME) == True

    with unittest.mock.patch.object(
        RunningPythonProcess, "send_line"
    ) as mock_send_line:
        toggle_variable()
        mock_

# Generated at 2022-06-22 03:00:25.659793
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.plugins.pgzero_mode import (
        load_plugin as actual_load_plugin,
    )

    from unittest.mock import MagicMock
    from unittest.mock import patch

    # Shuffle the plugin load path so we are sure we are loading the plugin we
    # want to test.
    with patch("thonny.plugins.pgzero_mode.load_directory") as load_directory_mock:
        load_directory_mock.side_effect = lambda path: [
            path.__add__("/test_plugin")
        ]
        actual_load_plugin()

# Generated at 2022-06-22 03:00:32.168845
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().in_simple_mode = lambda : False
    get_workbench().get_variable = lambda key : KeyVal(get=lambda : True)
    get_workbench().set_option = lambda k, v: True
    toggle_variable()

# Generated at 2022-06-22 03:00:42.757708
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_option(_OPTION_NAME, True)

    assert os.environ["PGZERO_MODE"] == "True"

    wb.set_option(_OPTION_NAME, False)
    assert os.environ["PGZERO_MODE"] == "False"
    wb.in_simple_mode = lambda: True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    wb.in_simple_mode = lambda: False
    wb.set_option(_OPTION_NAME, True)
    assert os.environ["PGZERO_MODE"] == "True"
    wb.set_option(_OPTION_NAME, False)

# Generated at 2022-06-22 03:00:50.380016
# Unit test for function update_environment
def test_update_environment():
    from unittest import mock

    with mock.patch.dict(os.environ, {}):
        get_workbench().set_option(_OPTION_NAME, True)
        update_environment()
        assert os.environ["PGZERO_MODE"] == "1"

        get_workbench().set_option(_OPTION_NAME, False)
        update_environment()
        assert os.environ["PGZERO_MODE"] == "0"

        get_workbench().set_option(_OPTION_NAME, None)
        update_environment()
        assert os.environ["PGZERO_MODE"] == "0"

# Generated at 2022-06-22 03:01:02.218775
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    load_plugin()
    assert "PGZERO_MODE" in os.environ
    assert os.environ["PGZERO_MODE"] == "0"

    # Test if command adds the command correctly
    # Also tests the toggle_variable function correctly sets the option
    wb.event_generate("<<OpenInterpreter>>", wb.interpreter)
    wb.get_menu("run").entryconfigure("toggle_pgzero_mode", state="normal")
    wb.event_generate("<<UpdateInterpreterProcess>>")
    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    wb.event_generate("<<TogglePGZeroMode>>")
    assert get

# Generated at 2022-06-22 03:01:07.957263
# Unit test for function toggle_variable
def test_toggle_variable():

    actual = get_workbench().get_variable(_OPTION_NAME).get()
    toggle_variable()

    expected = not actual  # Flip
    actual = get_workbench().get_variable(_OPTION_NAME).get()

    assert actual == expected

# Generated at 2022-06-22 03:01:16.357007
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock

    get_workbench().save_workbench_config = Mock()
    assert get_workbench().get_option("run.pgzero_mode") == False
    assert get_workbench().get_command("toggle_pgzero_mode") == toggle_variable
    assert os.environ["PGZERO_MODE"] == "False"

    toggle_variable()

    assert get_workbench().get_option("run.pgzero_mode") == True
    assert get_workbench().get_command("toggle_pgzero_mode") == toggle_variable
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().in_simple_mode = Mock(return_value=True)
    update_environment()


# Generated at 2022-06-22 03:01:26.093697
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    os.environ["PGZERO_MODE"] = "auto"
    get_workbench().set_default(_OPTION_NAME, True)
    load_plugin()
    assert get_workbench().get_variable(_OPTION_NAME).get() == True
    os.environ["PGZERO_MODE"] = "True"
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    assert get_workbench().get_variable(_OPTION_NAME).get() == True
    del os.environ["PGZERO_MODE"]

# Generated at 2022-06-22 03:01:28.157372
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench

    wb = Workbench()
    load_plugin()
    wb.destroy()

# Generated at 2022-06-22 03:01:44.409128
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock

    mock_get_workbench = Mock()
    mock_get_workbench.in_simple_mode.return_value = False
    mock_get_workbench.get_option.return_value = True
    tk = Mock()
    mock_get_workbench.get_tk.return_value = tk
    mock_get_workbench.add_command = Mock()
    mock_get_workbench.set_default = Mock()
    get_workbench.cache_clear()
    get_workbench.cache_clear()
    get_workbench.cache_clear()
    get_workbench.cache_clear()
    get_workbench.cache_clear()
    get_workbench.cache_clear()
    get_workbench.cache_clear()

# Generated at 2022-06-22 03:01:47.276615
# Unit test for function update_environment
def test_update_environment():
    del os.environ["PGZERO_MODE"]
    update_environment()
    assert os.getenv("PGZERO_MODE") == "False"

    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.getenv("PGZERO_MODE") == "auto"
    os.environ["PGZERO_MODE"] = "True"

# Generated at 2022-06-22 03:01:52.929194
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    assert get_workbench().get_variable(_OPTION_NAME) == True

# Generated at 2022-06-22 03:02:00.180035
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.set_simple_mode(False)

    load_plugin()
    assert os.environ.get("PGZERO_MODE") == "False"

    toggle_variable()
    assert os.environ.get("PGZERO_MODE") == "True"

    wb.set_simple_mode(True)
    assert os.environ.get("PGZERO_MODE") == "auto"

# Generated at 2022-06-22 03:02:12.151841
# Unit test for function update_environment
def test_update_environment():
    from thonny.globals import get_runner
    
    # Test pgzero mode on in simple mode
    get_workbench().set_default(_OPTION_NAME, True)
    assert os.environ["PGZERO_MODE"] == "auto"
    
    # Test pgzero mode off in simple mode
    get_workbench().set_default(_OPTION_NAME, False)
    assert os.environ["PGZERO_MODE"] == "auto"
    
    # Test pgzero mode off in advance mode
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"
    
    # Test pgzero mode on in advance mode
    get_work

# Generated at 2022-06-22 03:02:15.987517
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()
    
    assert get_workbench().get_option(_OPTION_NAME) == True
    
    toggle_variable()
    
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-22 03:02:22.453967
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()

    wb.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    wb.set_simple_mode(False)
    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    wb.set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 03:02:31.001701
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_simple_mode(True)
    update_environment()
    assert get_workbench().in_simple_mode()

    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 03:02:34.685447
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) is True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) is False

# Generated at 2022-06-22 03:02:41.918449
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import Mock
    from thonny.common import InMemoryConfig

    get_workbench().in_simple_mode = lambda: False
    get_workbench().get_option = lambda name: False

    get_workbench().set_option = Mock()
    update_environment()
    assert get_workbench().set_option.call_count == 0

    get_workbench().set_option = Mock()

# Generated at 2022-06-22 03:02:56.915994
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().clear_all_commands()
    load_plugin()
    assert get_workbench().get_commands()


if __name__ == "__main__":
    load_plugin()

# Generated at 2022-06-22 03:03:06.162697
# Unit test for function update_environment
def test_update_environment():
    if "PGZERO_MODE" in os.environ:
        del os.environ["PGZERO_MODE"]

    load_plugin()
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 03:03:09.207864
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    toggle_variable()
    assert wb.get_variable(_OPTION_NAME)

# Generated at 2022-06-22 03:03:19.457946
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    assert os.environ["PGZERO_MODE"] == "auto"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    wb.in_simple_mode = lambda: True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    os.environ.pop("PGZERO_MODE")

# Generated at 2022-06-22 03:03:25.578545
# Unit test for function toggle_variable
def test_toggle_variable():
    # Test if it starts with pgzero mode off
    assert get_workbench().get_variable(_OPTION_NAME) == False

    # Test if it actually gets turned on when its toggled
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME) == True

    # Test if it actually gets turned off when its toggled again
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME) == False

# Generated at 2022-06-22 03:03:30.327036
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    assert wb.get_option(_OPTION_NAME) == False
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == True
    get_workbench().set_default(_OPTION_NAME, False)

# Generated at 2022-06-22 03:03:39.000093
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default("run.pgzero_mode", False)
    get_workbench().add_command("toggle_pgzero_mode", "run", "Aaa", toggle_variable, group=30)
    assert os.environ["PGZERO_MODE"] == "False"

    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"

    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"

    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"



# Generated at 2022-06-22 03:03:40.408484
# Unit test for function toggle_variable
def test_toggle_variable():
    print("TODO: test_toggle_variable")



# Generated at 2022-06-22 03:03:46.998442
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny import get_workbench
    from thonny.plugins.pgzero_mode import toggle_variable

    assert not get_workbench().get_variable(_OPTION_NAME).get()

    toggle_variable()

    assert get_workbench().get_variable(_OPTION_NAME).get()

    toggle_variable()

    assert not get_workbench().get_variable(_OPTION_NAME).get()

# Generated at 2022-06-22 03:03:51.846590
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    wb = Workbench()
    load_plugin()
    assert wb.get_option(_OPTION_NAME, False)
    assert os.environ.get("PGZERO_MODE", None) == "False"



# Generated at 2022-06-22 03:04:19.732571
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    assert wb.get_variable(_OPTION_NAME).get() == False
    toggle_variable()
    assert wb.get_variable(_OPTION_NAME).get() == True
    toggle_variable()
    assert wb.get_variable(_OPTION_NAME).get() == False

# Generated at 2022-06-22 03:04:24.321928
# Unit test for function toggle_variable
def test_toggle_variable():
    # test if function returns no values and doesn't raise an error
    toggle_variable()
    assert not get_workbench().in_simple_mode()
    toggle_variable()
    assert get_workbench().in_simple_mode()



# Generated at 2022-06-22 03:04:33.645532
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench
    from unittest import mock

    workbench = get_workbench()

    with mock.patch.dict("os.environ", {"PGZERO_MODE": "foo"}):
        workbench.set_default(_OPTION_NAME, False)
        update_environment()
        assert os.environ["PGZERO_MODE"] == "auto"
        workbench.set_default(_OPTION_NAME, True)
        update_environment()
        assert os.environ["PGZERO_MODE"] == "True"
        workbench.set_default(_OPTION_NAME, False)
        update_environment()
        assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 03:04:37.261237
# Unit test for function load_plugin
def test_load_plugin():
    print(os.environ["PGZERO_MODE"])
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 03:04:46.850232
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import MagicMock

    wb = MagicMock()
    wb.get_option = MagicMock(return_value=False)

    wb.in_simple_mode = MagicMock(return_value=True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    wb.in_simple_mode = MagicMock(return_value=False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    
    wb.get_option = MagicMock(return_value=True)    
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 03:04:58.886171
# Unit test for function toggle_variable
def test_toggle_variable():
    from unittest.mock import Mock
    from unittest.mock import patch
    import thonny
    import os

    global _OPTION_NAME

    _OPTION_NAME = "run_pgzero_mode_test"

    workbenchMock = Mock()
    workbenchMock.get_variable = Mock(return_value=False)
    workbenchMock.set_default = Mock()
    workbenchMock.get_option = Mock(return_value=False)
    workbenchMock.add_command = Mock()

    thonny.workbench = workbenchMock
    toggle_variable()

    assert workbenchMock.get_variable.call_count == 1
    assert workbenchMock.set_default.call_count == 1

# Generated at 2022-06-22 03:05:03.466124
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().simple_mode = False
    load_plugin()
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME)
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 03:05:15.208798
# Unit test for function toggle_variable
def test_toggle_variable():
  # Create a mock workbench
  class workbench:
    def set_default(self, name, value):
      return
    def get_option(self, option_name):
      if option_name == "run.pgzero_mode":
        return True
      else:
        return False

  # Create a mock menu 
  menu = {}
  menu["get_child"] = lambda name: menu[name]
  menu["get_all_children"] = lambda: menu

  # mock the run menu
  get_workbench().get_menu("run")["get_child"] = lambda name: menu[name]

  # mock the toggle_pgzero_mode command
  get_workbench().add_command("toggle_pgzero_mode", "run", "Toggle pgzero mode", toggle_variable)

  # call the method
  toggle_

# Generated at 2022-06-22 03:05:20.395506
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, True)
    assert wb.get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "1"


load_plugin()


# Generated at 2022-06-22 03:05:30.568431
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny import get_workbench
    import os
    import test.test_runner
    from unittest.mock import MagicMock, patch

    temp_config_file = "./test_thonny_config.json"

    wb = Workbench(testing=True)
    assert not wb.in_simple_mode()
    assert not wb.get_option(_OPTION_NAME)
    update_environment()
    assert os.environ.get("PGZERO_MODE") == str(False)
    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ.get("PGZERO_MODE") == str(True)
    wb.set_option(_OPTION_NAME, False)

    #

# Generated at 2022-06-22 03:06:05.258317
# Unit test for function update_environment
def test_update_environment():
    # Reset environment for this test
    get_workbench().set_option(_OPTION_NAME, False)
    os.environ["PGZERO_MODE"] = "auto"

    # Set workbench in simple mode and check env
    get_workbench().set_simple_mode()
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    # Set workbench in full mode and check env
    get_workbench().set_full_mode()
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    # Set workbench in full mode and toggle pgzero_mode to check env
    # Note that env is updated even when workbench is in simple mode
    get_workbench().set_full_mode()
    toggle_variable()
    update_environment()

# Generated at 2022-06-22 03:06:11.409722
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    test_wb = WorkbenchMock()
    assert test_wb.get_default(_OPTION_NAME) == False
    test_wb.set_default(_OPTION_NAME, True)
    assert test_wb.get_default(_OPTION_NAME) == True

# Generated at 2022-06-22 03:06:17.049691
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == True
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == True

# Generated at 2022-06-22 03:06:21.520633
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default('run.pgzero_mode', True)
    update_environment()
    assert (os.environ['PGZERO_MODE'] == 'True')

    get_workbench().set_default('run.pgzero_mode', False)
    update_environment()
    assert (os.environ['PGZERO_MODE'] == 'False')

# Generated at 2022-06-22 03:06:27.536434
# Unit test for function toggle_variable
def test_toggle_variable():
    load_plugin()
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True

# Generated at 2022-06-22 03:06:32.438810
# Unit test for function update_environment
def test_update_environment():
    from collections import namedtuple
    Wk = namedtuple("wk", ["in_simple_mode", "get_option"])
    get_workbench.__code__ = lambda self: Wk(lambda: True, lambda x: True)
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench.__code__ = lambda self: Wk(lambda: False, lambda x: True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 03:06:40.175218
# Unit test for function toggle_variable
def test_toggle_variable():
    import unittest.mock
    import thonny

    get_workbench().clear_variables()

    # set to true
    toggle_variable()

    # check that new value was set
    assert_var_value(thonny.get_workbench(), _OPTION_NAME, True)

    # set to false
    toggle_variable()

    # check that new value was set
    assert_var_value(thonny.get_workbench(), _OPTION_NAME, False)



# Generated at 2022-06-22 03:06:50.484441
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock
    from thonny.memory import Variable
    from thonny.workbench import Workbench
    from thonny.plugins.run import run
    from thonny.languages import tr
    from thonny.ui_utils import CommonDialog
    from thonny.globals import get_workbench
    from tkinter import OptionMenu, Button, N, S, W, E, Listbox
    from tkinter.ttk import Frame, Label, Combobox, Entry, Checkbutton, Radiobutton
    from tkinter.scrolledtext import ScrolledText
    from thonny.common import ToplevelCommand
    from thonny.ui_utils import EnhancedText
    import os

    workbench = Workbench()
    workbench.set_default = Mock()
    workbench

# Generated at 2022-06-22 03:06:51.436234
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()


# Generated at 2022-06-22 03:06:57.545552
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.misc_utils import running_on_windows
    from unittest.mock import patch
    from thonny.test_utils import captured_output

    workbench = Workbench()
    workbench.set_default(_OPTION_NAME, False)
        
    with captured_output("stderr") as (out, err):
        update_environment()

    workbench.set_default(_OPTION_NAME, True)
    with captured_output("stderr") as (out, err):
        update_environment()

# Generated at 2022-06-22 03:07:52.578808
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import MagicMock, patch
    from thonny import TkVersion
    import tkinter

    with patch("thonny.workbench.Workbench.get_instance", create=True) as mock_workbench:
        default_tk = tkinter.Tk()
        if TkVersion >= 8.6:
            default_tk.option_add('*tearOff', False)

        mock_workbench.return_value = MagicMock()
        mock_workbench.return_value.get_option.return_value = False
        mock_workbench.return_value.in_simple_mode = MagicMock(return_value = False)

        update_environment()
        assert os.environ["PGZERO_MODE"] == "False"

        mock_workbench.return_value.get_

# Generated at 2022-06-22 03:07:57.114457
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, True)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True

# Generated at 2022-06-22 03:08:01.212569
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench

    workbench = Workbench(options=None, testing=True)
    try:
        workbench.set_default(_OPTION_NAME, True)
        assert "PGZERO_MODE" not in os.environ
        update_environment()
        assert os.environ["PGZERO_MODE"] == "True"
        workbench.set_simple_mode(True)
        assert os.environ["PGZERO_MODE"] == "True"
        update_environment()
        assert os.environ["PGZERO_MODE"] == "auto"
    finally:
        os.environ.pop("PGZERO_MODE")
        workbench.destroy()

# Generated at 2022-06-22 03:08:04.952045
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    try:
        toggle_variable()
        assert get_workbench().get_option(_OPTION_NAME) == True
    except AssertionError:
        raise AssertionError("get_workbench().get_option did not return the expected value")
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False


# Generated at 2022-06-22 03:08:11.344385
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import Mock
    get_workbench = Mock()
    get_workbench.in_simple_mode = False
    get_workbench.get_option = lambda x: True
    orig_os = os
    os = Mock()
    os.environ = {}
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    os = orig_os

# Generated at 2022-06-22 03:08:16.657696
# Unit test for function toggle_variable
def test_toggle_variable():
    # toggled three times
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get()
    toggle_variable()
    assert not get_workbench().get_variable(_OPTION_NAME).get()
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get()

# Generated at 2022-06-22 03:08:22.456037
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    wb.set_simple_mode(True)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    wb.set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    
    wb.set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 03:08:26.269961
# Unit test for function update_environment
def test_update_environment():

    os.environ["PGZERO_MODE"] = "auto"
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 03:08:37.356961
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench

    workbench = Workbench()
    workbench.register_command("run_module", "misc", "Run module", None)
    workbench.set_default("run.pgzero_mode", True)
    update_environment()
    assert os.getenv("PGZERO_MODE") == "True"
    workbench.set_option("run.pgzero_mode", False)
    update_environment()
    assert os.getenv("PGZERO_MODE") == "False"
    workbench.set_option("run.pgzero_mode", True)
    workbench.activate_simple_mode(True)
    workbench.invoke_command("run_module")
    assert os.getenv("PGZERO_MODE") == "auto"


# Generated at 2022-06-22 03:08:45.605897
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().unset_default(_OPTION_NAME)
    load_plugin()
    assert get_workbench().in_simple_mode() == False
    assert get_workbench().get_option(_OPTION_NAME) == False


if __name__ == "__main__":
    import logging
    import sys
    import unittest

    logging.basicConfig(
        level=logging.DEBUG,
        format="%(relativeCreated)5d %(levelname)s %(module)s:%(lineno)s %(message)s",
    )
    sys.exit(unittest.main(__name__))