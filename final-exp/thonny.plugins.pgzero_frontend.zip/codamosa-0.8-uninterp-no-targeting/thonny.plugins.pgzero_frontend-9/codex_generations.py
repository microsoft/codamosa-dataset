

# Generated at 2022-06-22 03:00:59.504959
# Unit test for function update_environment
def test_update_environment():
    old_env = os.environ.copy()
    try:
        del os.environ["PGZERO_MODE"]
        update_environment()
        assert os.environ["PGZERO_MODE"] == "auto"

        os.environ["PGZERO_MODE"] = "True"
        update_environment()
        assert os.environ["PGZERO_MODE"] == "True"

        os.environ["PGZERO_MODE"] = "False"
        update_environment()
        assert os.environ["PGZERO_MODE"] == "False"
    finally:
        os.environ.clear()
        os.environ.update(old_env)

# Generated at 2022-06-22 03:01:11.038512
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()

    original_PGZERO_MODE = os.environ["PGZERO_MODE"]
    original_option_value = wb.get_option(_OPTION_NAME)


# Generated at 2022-06-22 03:01:23.615871
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()
    assert isinstance(wb._command_ids["toggle_pgzero_mode"], int)
    assert wb.get_option(_OPTION_NAME) == False
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == True
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == False
    wb.destroy()

# Generated at 2022-06-22 03:01:29.767008
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench
    from thonny.misc_utils import running_on_mac_os
    import os

    if running_on_mac_os():
        print("Skipping test_update_environment in macOS")
        return

    os.environ["PGZERO_MODE"] = ""
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"

    wb.set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"

    wb.set_default(_OPTION_NAME, False)
    wb.enter_simple_mode()
    update_environment()

# Generated at 2022-06-22 03:01:36.163146
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny import get_workbench

    #  get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().set_option(_OPTION_NAME, True)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True



# Generated at 2022-06-22 03:01:44.451727
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.misc_utils import running_on_mac_os, running_on_windows
    from thonny.languages import normalize_language_tag
    from thonny.plugins.run.run_command import RunCommand
    from thonny.workbench import Workbench

    # Test return values
    wb_test = Workbench()
    wb_test._set_default(_OPTION_NAME, False)
    assert normalize_language_tag(wb_test.get_variable(_OPTION_NAME)) == "en"
    assert not normalize_language_tag(wb_test.get_variable(_OPTION_NAME)) == "xx"

    # Test that run plug-in is loaded

# Generated at 2022-06-22 03:01:46.717319
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_option(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME)
    toggle_variable()
    assert not get_workbench().get_option(_OPTION_NAME)

# Generated at 2022-06-22 03:01:51.044109
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    assert wb.get_variable(_OPTION_NAME).get() == Fals

# Generated at 2022-06-22 03:01:55.361999
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default(_OPTION_NAME, False)
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_default(_OPTION_NAME, True)
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 03:01:59.573048
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    assert wb.get_option(_OPTION_NAME) is False
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) is True

# Generated at 2022-06-22 03:02:09.053847
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, True)
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME)

# Generated at 2022-06-22 03:02:16.551897
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default(_OPTION_NAME, True)
    get_workbench().get_option("run.simple_mode").set(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"

    get_workbench().get_option("run.simple_mode").set(True)
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"


# Generated at 2022-06-22 03:02:20.341995
# Unit test for function toggle_variable
def test_toggle_variable():
    from ..config_ui import load_plugin
    from thonny.globals import get_workbench
    load_plugin()
    assert get_workbench().get_variable(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME) == True

# Generated at 2022-06-22 03:02:27.709480
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True



# Generated at 2022-06-22 03:02:31.049781
# Unit test for function toggle_variable
def test_toggle_variable():
    class WorkbenchStub:
        def get_variable(self, option):
            return option

        def get_option(self, option):
            return option

        def set_default(self, option, value):
            option = value

    toggle_variable()

# Generated at 2022-06-22 03:02:41.058657
# Unit test for function load_plugin
def test_load_plugin():

    old_value = None
    if "PGZERO_MODE" in os.environ:
        old_value = os.environ["PGZERO_MODE"]

    get_workbench().set_default(_OPTION_NAME, True)
    load_plugin()

    assert "PGZERO_MODE" in os.environ
    assert os.environ["PGZERO_MODE"] == "True"

    # On a single-user machine the workbench will be reset on each
    # new test case, but to test the "unload" code, we need to undo
    # whatever we did:
    get_workbench().remove_command("toggle_pgzero_mode")
    get_workbench().remove_option(_OPTION_NAME)

# Generated at 2022-06-22 03:02:42.571073
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    assert wb.get_variable(_OPTION_NAME).get() == False

# Generated at 2022-06-22 03:02:50.569398
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench

    get_workbench().in_simple_mode = lambda: True
    update_environment()
    assert os.environ["PGZERO_MODE"] == 'auto'

    get_workbench().in_simple_mode = lambda: False
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == 'True'

    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == 'False'

# Generated at 2022-06-22 03:02:55.907488
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.plugins.run_pgzero import toggle_variable
    from thonny import get_workbench
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-22 03:03:00.453879
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.workbench import Workbench

    workbench = Workbench()
    workbench.set_default(_OPTION_NAME, False)

    toggle_variable()
    assert workbench.get_option(_OPTION_NAME) == True

    toggle_variable()
    assert workbench.get_option(_OPTION_NAME) == False


# Generated at 2022-06-22 03:03:14.328952
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) is False

# Generated at 2022-06-22 03:03:19.200669
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    var = wb.get_variable(_OPTION_NAME)
    # default is False
    assert not var.get()
    # test if it works
    toggle_variable()
    assert var.get()
    # test if it works
    toggle_variable()
    assert not var.get()



# Generated at 2022-06-22 03:03:23.849540
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()

# Generated at 2022-06-22 03:03:35.468002
# Unit test for function update_environment
def test_update_environment():
    os.environ.pop("PGZERO_MODE", None)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    os.environ.pop("PGZERO_MODE", None)
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_default(_OPTION_NAME, False)
    os.environ.pop("PGZERO_MODE", None)
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_simple_mode(False)

# Generated at 2022-06-22 03:03:40.365129
# Unit test for function update_environment
def test_update_environment():
    get_workbench().register_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().register_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 03:03:48.164578
# Unit test for function toggle_variable
def test_toggle_variable():
    import unittest 
    from thonny import workbench
    from thonny.plugins.pgzero_mode import toggle_variable, _OPTION_NAME
    workbench.init()
    workbench.set_default(_OPTION_NAME, True)
    assert workbench.get_option(_OPTION_NAME) == True
    toggle_variable()
    assert workbench.get_option(_OPTION_NAME) == False


if __name__ == "__main__":
    load_plugin()

# Generated at 2022-06-22 03:03:54.652519
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.misc_utils import TemporaryModuleName
    from thonny import get_workbench

    with TemporaryModuleName("my_thonny_plugins.pgzero_mode_test", delete=True):
        import my_thonny_plugins.pgzero_mode_test

        my_thonny_plugins.pgzero_mode_test.load_plugin()
        assert "toggle_pgzero_mode" in get_workbench().commands.commands

# Generated at 2022-06-22 03:04:02.667622
# Unit test for function toggle_variable
def test_toggle_variable():

    # Set the option value to False
    get_workbench().set_option(_OPTION_NAME, False)

    # Function toggle_variable toggles the variable
    toggle_variable()

    # After toggling the variable, the variable should be True
    assert get_workbench().get_variable(_OPTION_NAME)

    # After toggling the variable, the environment variable should be "True"
    assert os.getenv("PGZERO_MODE") == "True"



# Generated at 2022-06-22 03:04:07.127821
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.globals import get_workbench

    # Called with empty workbench
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == True

    # Called to set False
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == False


# Generated at 2022-06-22 03:04:18.822633
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    assert "PGZERO_MODE" in os.environ
    del os.environ["PGZERO_MODE"]
    assert "PGZERO_MODE" not in os.environ

    # initially in simple mode
    wb.simple_mode_window.destroy()
    wb.in_simple_mode = False
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    wb.in_simple_mode = True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    # start in simple mode
    wb.simple_mode_window.destroy()
    wb.in_simple_mode = False
    update_environment()

# Generated at 2022-06-22 03:04:46.228009
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 03:04:49.124595
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME)
    toggle_variable()
    assert not get_workbench().get_option(_OPTION_NAME)

# Generated at 2022-06-22 03:04:56.124984
# Unit test for function toggle_variable
def test_toggle_variable():
    try:
        os.environ["PGZERO_MODE"]
    except KeyError:
        os.environ["PGZERO_MODE"] = "auto"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 03:05:08.189032
# Unit test for function toggle_variable
def test_toggle_variable():
    old_mode = os.environ.get("PGZERO_MODE", None)

    os.environ["PGZERO_MODE"] = "true"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "false"

    os.environ["PGZERO_MODE"] = "false"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "true"

    os.environ["PGZERO_MODE"] = "anything"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "false"

    os.environ["PGZERO_MODE"] = ""
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "true"

    os.environ["PGZERO_MODE"] = "anything"

# Generated at 2022-06-22 03:05:12.761727
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny import get_workbench
    wb = Workbench()
    wb.set_default(_OPTION_NAME, True)
    wb.set_simple_mode(True)
    update_environment()
    assert os.getenv('PGZERO_MODE') == 'auto'


# Generated at 2022-06-22 03:05:20.395516
# Unit test for function toggle_variable
def test_toggle_variable():
    print("Testing toggle_variable...", end="")
    # test_programs_dir = os.path.dirname(__file__)
    get_workbench().set_option(_OPTION_NAME, True)
    get_workbench().set_option(_OPTION_NAME, False)
    get_workbench().set_option(_OPTION_NAME, True)
    assert get_workbench().get_option(_OPTION_NAME)
    print("OK")


# Generated at 2022-06-22 03:05:26.453243
# Unit test for function load_plugin
def test_load_plugin():
    from unittest import mock
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.get_variable = mock.MagicMock(return_value=77)

    load_plugin()
    assert wb.in_simple_mode() is False
    assert wb.get_variable(_OPTION_NAME).get() == 77
    assert 'PGZERO_MODE' in os.environ

# Generated at 2022-06-22 03:05:31.839333
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert get_workbench().get_default(_OPTION_NAME) == False
    assert get_workbench().get_option(_OPTION_NAME) == False
    # assert command is shown in "Run" menu
    assert any(
        [
            command.command_id == "toggle_pgzero_mode"
            for command in get_workbench().get_commands()
        ]
    )


if __name__ == "__main__":
    test_load_plugin()

# Generated at 2022-06-22 03:05:43.916995
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    os.environ.pop("PGZERO_MODE", None)

    wb.set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    wb.set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    wb.set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 03:05:47.683441
# Unit test for function load_plugin
def test_load_plugin():
    wb = SingletonWorkbench()
    load_plugin()
    assert wb.get_option(_OPTION_NAME) == False
    wb.set_option(_OPTION_NAME, True)
    assert wb.get_option(_OPTION_NAME) == True


# Generated at 2022-06-22 03:06:45.126489
# Unit test for function toggle_variable
def test_toggle_variable():
    new_workbench = get_workbench()
    
    new_workbench.set_simple_mode(True)
    assert (os.environ["PGZERO_MODE"]) == "auto"
    
    new_workbench.set_simple_mode(False)
    new_workbench.set_option(_OPTION_NAME, False)
    assert (os.environ["PGZERO_MODE"]) == "False"
    
    toggle_variable()
    assert (os.environ["PGZERO_MODE"]) == "True"



# Generated at 2022-06-22 03:06:48.274900
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-22 03:06:52.107291
# Unit test for function load_plugin
def test_load_plugin():
    # this is registered in run.py
    get_workbench().unregister_command("run", "toggle_pgzero_mode")
    load_plugin()
    assert "toggle_pgzero_mode" in get_workbench().get_commands("run")

# Generated at 2022-06-22 03:06:59.398489
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock, call

    wb = Mock()
    wb.set_default.return_value = None
    toggle_variable.add_command.return_value = None
    update_environment.return_value = None

    load_plugin(wb)
    assert wb.set_default.call_args_list == [
        call("run.pgzero_mode", False)
    ]
    assert wb.add_command.call_args_list == [
        call(
            "toggle_pgzero_mode",
            "run",
            "Pygame Zero mode",
            toggle_variable,
            flag_name="run.pgzero_mode",
            group=40,
        )
    ]
    assert update_environment.call_args_list == [call()]
    assert wb.get

# Generated at 2022-06-22 03:07:09.858290
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.globals import get_workbench
    from thonny.misc_utils import running_on_mac_os
    w = get_workbench()
    w.set_default(_OPTION_NAME, False)
    w.add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    # In case that unit test is run on Mac OS (or any other OS with different
    # shell command), previous assert is not enough, as it is just check that
    # env. $PGZERO_MODE is correctly set to 'False'

# Generated at 2022-06-22 03:07:17.879628
# Unit test for function update_environment
def test_update_environment():
    from thonny.globals import get_workbench

    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_simple_mode(True)
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 03:07:28.138902
# Unit test for function update_environment
def test_update_environment():
    import random
    import os
    from unittest.mock import Mock

    get_workbench = Mock()
    get_workbench.in_simple_mode = Mock(return_value=True)
    get_workbench.get_option = Mock(return_value=random.random())

    os.environ["PGZERO_MODE"] = ""
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench.in_simple_mode = Mock(return_value=False)
    get_workbench.get_option = Mock(return_value=random.random())
    update_environment()
    assert os.environ["PGZERO_MODE"] == str(get_workbench.get_option())

# Generated at 2022-06-22 03:07:33.707124
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)

    load_plugin()
    assert wb.get_variable(_OPTION_NAME).get() == False
    wb.set_variable(_OPTION_NAME, True)
    wb.set_variable(_OPTION_NAME, False)

# Generated at 2022-06-22 03:07:38.446747
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    load_plugin()
    assert len(wb.get_commands()) > 0
    assert _OPTION_NAME in ("simple", "advanced") and isinstance(
        wb.get_option(_OPTION_NAME), bool
    )



# Generated at 2022-06-22 03:07:50.709085
# Unit test for function update_environment
def test_update_environment():
    # Skip this test if called from within a pgzero app
    if "PGZERO_MODE" in os.environ:
        return
    from thonny import get_workbench
    from unittest.mock import patch, MagicMock
    wb = get_workbench()
    wb.in_simple_mode = MagicMock(return_value=True)
    # check that the environment is set to auto
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    # check that the environment is set to False
    wb.in_simple_mode.return_value=False
    wb.set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    # check that the environment is

# Generated at 2022-06-22 03:09:50.430038
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import MagicMock

    wb = MagicMock()
    wb.get_option = MagicMock(return_value = True)

    get_workbench.cache_clear()
    get_workbench.return_value = wb
    update_environment()

    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 03:09:54.073953
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default(_OPION_NAME, True)
    
    assert os.environ["PGZERO_MODE"] == "1"
    
    get_workbench().set_default(_OPION_NAME, False)
    assert os.environ["PGZERO_MODE"] == "0"

# Generated at 2022-06-22 03:10:02.258569
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 03:10:03.901226
# Unit test for function toggle_variable
def test_toggle_variable():
    """
    >>> load_plugin()
    >>> toggle_variable()
    >>> toggle_variable()
    >>> toggle_variable()
    """

# Generated at 2022-06-22 03:10:15.435002
# Unit test for function update_environment
def test_update_environment():
    import thonnycontrib.pgzero_mode as pgzero_mode
    from thonny.workbench import Workbench
    from thonny.misc_utils import running_on_mac_os

    workbench = Workbench()
    workbench.set_default(pgzero_mode._OPTION_NAME, False)
    pgzero_mode.update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    workbench.set_option(pgzero_mode._OPTION_NAME, True)
    pgzero_mode.update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    workbench.in_simple_mode = lambda: False
    pgzero_mode.update_environment()
    assert os.environ["PGZERO_MODE"] == "1"



# Generated at 2022-06-22 03:10:21.972767
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import patch, MagicMock
    from thonny import get_workbench
    from thonny.languages import tr
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    mock_add_command = MagicMock()
    with patch.object(wb, "add_command", mock_add_command):
        load_plugin()
    assert mock_add_command.call_count == 1
    assert mock_add_command.call_args[0][0] == "toggle_pgzero_mode"
    assert mock_add_command.call_args[0][1] == "run"
    assert mock_add_command.call_args[0][2] == tr("Pygame Zero mode")

# Generated at 2022-06-22 03:10:32.577916
# Unit test for function update_environment
def test_update_environment():

    # if in_simple_mode, PGZERO_MODE is set to "auto".
    get_workbench().set_simple_mode(True)
    get_workbench().get_variable(_OPTION_NAME).set(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    assert get_workbench().get_option(_OPTION_NAME) == True

    # if not in_simple_mode, PGZERO_MODE is set to the value of the option.
    get_workbench().set_simple_mode(False)
    get_workbench().get_variable(_OPTION_NAME).set(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    assert get_workbench().get_option(_OPTION_NAME)

# Generated at 2022-06-22 03:10:33.852197
# Unit test for function toggle_variable
def test_toggle_variable():
    assert os.environ["PGZERO_MODE"] == str(not get_workbench().get_option(_OPTION_NAME))

# Generated at 2022-06-22 03:10:39.613878
# Unit test for function load_plugin
def test_load_plugin():
    global get_workbench
    get_workbench = create_mock_workbench(
        "Test workbench",
        default_options={
            _OPTION_NAME: False},
        commands={
            "toggle_pgzero_mode": create_mock_command(
                "toggle_pgzero_mode",
                tr("Pygame Zero mode"),
                group=40,
                )
            }
        )
    load_plugin()

# Generated at 2022-06-22 03:10:42.997067
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert get_workbench().get_variable(_OPTION_NAME).get() == False

