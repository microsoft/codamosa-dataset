

# Generated at 2022-06-22 03:00:27.418387
# Unit test for function toggle_variable
def test_toggle_variable():
    import unittest.mock
    from thonny import get_workbench

    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    
    toggle_variable()
    assert wb.get_variable(_OPTION_NAME).get() == True
    assert os.environ["PGZERO_MODE"] == "True"
    
    toggle_variable()
    assert wb.get_variable(_OPTION_NAME).get() == False
    assert os.environ["PGZERO_MODE"] == "False"
    
    wb.in_simple_mode = unittest.mock.MagicMock(return_value=True)
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "auto"
    
    wb.in_simple

# Generated at 2022-06-22 03:00:38.863514
# Unit test for function update_environment
def test_update_environment():
    import os
    from thonny.thonny import Thonny
    from thonny.config import get_config_dir
    
    if os.path.exists(get_config_dir()):
        os.rmdir(get_config_dir())
    os.environ["THONNY_USER_DIR"] = get_config_dir()
    
    wb = Thonny()
    wb.set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    
    wb.set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    
    wb.set_simple_mode(True)
    update_environment

# Generated at 2022-06-22 03:00:49.473251
# Unit test for function toggle_variable
def test_toggle_variable():
    global custom_config_path, custom_user_dir
    custom_config_path = tempfile.mkdtemp()
    custom_user_dir = tempfile.mkdtemp()
    get_workbench().set_option("run.pgzero_mode", False)
    get_workbench().set_option("run.pgzero_mode", True)
    assert get_workbench().get_option("run.pgzero_mode", False)
    get_workbench().set_option("run.pgzero_mode", True)
    assert get_workbench().get_option("run.pgzero_mode", False)
    get_workbench().set_option("run.pgzero_mode", False)
    assert not get_workbench().get_option("run.pgzero_mode", True)

# Generated at 2022-06-22 03:00:59.220955
# Unit test for function toggle_variable
def test_toggle_variable():
    from unittest.mock import Mock
    from thonny import get_workbench

    option_name = "run.pgzero_mode"
    get_workbench().set_default(option_name, False)

    assert get_workbench().get_variable(option_name).get() == False
    toggle_variable()
    assert get_workbench().get_variable(option_name).get() == True
    toggle_variable()
    assert get_workbench().get_variable(option_name).get() == False
    toggle_variable()
    assert get_workbench().get_variable(option_name).get() == True

# Generated at 2022-06-22 03:01:10.771460
# Unit test for function update_environment
def test_update_environment():
    # clear everything before and after the test
    os.environ.pop("PGZERO_MODE", None)
    restore_in_simple_mode = get_workbench().in_simple_mode()
    try:
        get_workbench().set_option(_OPTION_NAME, False)
        get_workbench().set_simple_mode(True)
        update_environment()
        assert os.environ.get("PGZERO_MODE") == "auto"

        get_workbench().set_simple_mode(False)
        get_workbench().set_option(_OPTION_NAME, True)
        update_environment()
        assert os.environ.get("PGZERO_MODE") == "True"
    finally:
        get_workbench().set_simple_mode(restore_in_simple_mode)

# Generated at 2022-06-22 03:01:23.910491
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    var = wb.get_variable(_OPTION_NAME)
    assert var is not None
    assert var.get() == False
    assert "PGZERO_MODE" not in os.environ

    toggle_variable()
    assert var.get() == True
    assert os.environ["PGZERO_MODE"] == "True"

    toggle_variable()
    assert var.get() == False
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 03:01:33.112875
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.workbench import Workbench

    workbench = Workbench()

    # User option does not exists
    var = workbench.get_user_option(_OPTION_NAME)
    assert var == None

    # Toggled option is first created and then switched on.
    toggle_variable()
    var = workbench.get_variable(_OPTION_NAME)
    assert var != None
    assert var.get() == True

    # Toggled option is first created, switched on and then switched off.
    toggle_variable()
    assert var.get() == False


# Generated at 2022-06-22 03:01:46.198430
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    assert not get_workbench().get_option(_OPTION_NAME)
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME)
    get_workbench().set_default(_OPTION_NAME, False)
    assert get_workbench().get_option(_OPTION_NAME)
    toggle_variable()
    assert not get_workbench().get_option(_OPTION_NAME)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME)

# Generated at 2022-06-22 03:01:55.058293
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    wb.set_simple_mode(False)
    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    wb.set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 03:02:02.102764
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default("run.pgzero_mode", False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_default("run.pgzero_mode", True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_default("run.pgzero_mode", False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 03:02:08.777264
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert not get_workbench().get_option(_OPTION_NAME)



# Generated at 2022-06-22 03:02:12.627445
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.globals import get_workbench
    import os

    toggle_variable()
    assert get_workbench().get_variable(
        _OPTION_NAME
    ) == get_workbench().get_option(_OPTION_NAME)
    assert "PGZERO_MODE" in os.environ, f"{'PGZERO_MODE'} not found!"
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 03:02:21.443107
# Unit test for function load_plugin
def test_load_plugin():
    global wb
    from thonny import get_workbench
    from thonny.plugins.backend_options import BackendOptions

    workbench = get_workbench()
    workbench.set_default(_OPTION_NAME, False)
    initial_value = get_workbench().get_option(_OPTION_NAME)

    wb.add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    updated_value = get_workbench().get_option(_OPTION_NAME)

# Generated at 2022-06-22 03:02:33.247371
# Unit test for function update_environment
def test_update_environment():
    from thonny.misc_utils import running_on_windows
    from thonny.workbench import Workbench
    import os

    workbench = Workbench()
    workbench.set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    workbench.show_simple_mode()
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    workbench.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    workbench.show_normal_mode()
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1" # on windows not "True"

    work

# Generated at 2022-06-22 03:02:39.326137
# Unit test for function load_plugin
def test_load_plugin():
    # This should call update_environment
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    # This should call update_environment
    try:
        update_environment()
    except Exception as e:
        print(e)
    print(os.environ["PGZERO_MODE"])

# Generated at 2022-06-22 03:02:45.272461
# Unit test for function update_environment
def test_update_environment():
    from thonny.config_ui import _get_variable_mapping
    from thonny.misc_utils import running_on_windows
    import os
    import os.path
    from thonny.plugins.backend_options import _get_default_backend_path

    get_workbench().set_simple_mode(True)
    get_workbench().set_option(_OPTION_NAME, True)


# Generated at 2022-06-22 03:02:50.354695
# Unit test for function load_plugin
def test_load_plugin():
    workbench = get_workbench()
    workbench.set_default(_OPTION_NAME, True)  
    load_plugin()
    assert workbench.get_variable(_OPTION_NAME).get() == True
    
    workbench.set_default(_OPTION_NAME, False)  
    load_plugin()
    assert workbench.get_variable(_OPTION_NAME).get() == False

# Generated at 2022-06-22 03:02:54.556264
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()
    assert (get_workbench().get_option(_OPTION_NAME)) == True
    
    toggle_variable()
    assert (get_workbench().get_option(_OPTION_NAME)) == False

# Generated at 2022-06-22 03:03:02.352727
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"

    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 03:03:05.623028
# Unit test for function load_plugin
def test_load_plugin():
    import thonny.plugins.pgzero
    thonny.plugins.pgzero.load_plugin()
    assert get_workbench().get_option("run.pgzero_mode") == False

# Generated at 2022-06-22 03:03:28.166632
# Unit test for function toggle_variable
def test_toggle_variable():
    from unittest import mock
    
    # create mock for a workbench
    mock_workbench = mock.MagicMock()
    mock_workbench.get_variable.return_value = "value"
    mock_workbench.get_option.return_value = False
    # make workbench available through load_plugin
    get_workbench.set_fake(mock_workbench)

    # do something with toggle_variable
    toggle_variable()
    # check if the right functions of the mock were called
    mock_workbench.get_variable.assert_called()
    mock_workbench.get_option.assert_called()
    mock_workbench.set_option.assert_called()
    toggle_variable()
    mock_workbench.get_variable.assert_called()

# Generated at 2022-06-22 03:03:31.998515
# Unit test for function load_plugin
def test_load_plugin():
    # Unit test for function load_plugin
    # Ensure that toggle_pgzero_mode command is registered
    assert get_workbench().get_command("toggle_pgzero_mode")

# Generated at 2022-06-22 03:03:42.087760
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)

    wb.in_simple_mode = True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    wb.in_simple_mode = False
    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    wb.in_simple_mode = False
    wb.set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 03:03:46.911294
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import Mock

    get_workbench = Mock()
    get_workbench.in_simple_mode = Mock(return_value=True)
    get_workbench.get_option = Mock(return_value=True)
    result = update_environment()
    assert result is None



# Generated at 2022-06-22 03:03:50.256891
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    wb = get_workbench()
    assert wb.get_default(_OPTION_NAME) == False
    assert wb.get_option(_OPTION_NAME) == False


# Generated at 2022-06-22 03:03:58.019893
# Unit test for function update_environment
def test_update_environment():
    # Without simple_mode, PGZERO_MODE should be the string equivalent of the
    # option
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    wb.set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    # With simple_mode, PGZERO_MODE should be "auto"
    wb.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 03:04:04.736010
# Unit test for function toggle_variable
def test_toggle_variable():
    import thonny
    import unittest
    import os

    thonny.get_workbench().variables[_OPTION_NAME].set(False)

    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"

    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"


if __name__ == "__main__":
    test_toggle_variable()

# Generated at 2022-06-22 03:04:08.680744
# Unit test for function toggle_variable
def test_toggle_variable():
    from unittest import mock

    with mock.patch("thonny.workbench.Workbench.get_variable", return_value=True):
        toggle_variable()

    with mock.patch("thonny.workbench.Workbench.get_variable", return_value=False):
        toggle_variable()

if __name__ == "__main__":
    test_toggle_variable()

# Generated at 2022-06-22 03:04:15.926321
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 03:04:27.114726
# Unit test for function update_environment
def test_update_environment():
    # Mocking methods and attributes of get_workbench()
    mock_get_workbench = MagicMock()
    mock_get_workbench.in_simple_mode.return_value = False
    mock_get_workbench.get_option.return_value = True
    get_workbench.cache_clear() # Preventing get_workbench from caching
    get_workbench.cache_cleared = False
    get_workbench.cache = mock_get_workbench
    # Testing update_environment
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    # Restoring mocked methods and attributes
    get_workbench.cache_clear()
    get_workbench.cache_cleared = False
    get_workbench.cache = None

# Generated at 2022-06-22 03:04:56.983852
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    wb.set_default(_OPTION_NAME, True)
    assert wb.get_option(_OPTION_NAME)
    wb.add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    assert wb.get_option(_OPTION_NAME)

# Generated at 2022-06-22 03:04:59.829602
# Unit test for function toggle_variable
def test_toggle_variable():
    value = get_workbench().get_variable(_OPTION_NAME)
    old_value = value.get()
    toggle_variable()
    assert value.get() != old_value

# Generated at 2022-06-22 03:05:11.518990
# Unit test for function update_environment
def test_update_environment():
    """Unit test for function update_environment"""
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    toggle_variable()
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 03:05:23.030228
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench, THONNY_USER_DIR

    # Reset workbench
    get_workbench().destroy()
    get_workbench()  # Initialize workbench again
    get_workbench().event_generate("WorkbenchRestarted")

    # Reset user-defined options
    os.remove(os.path.join(THONNY_USER_DIR, "user_options.pickle"))
    load_plugin()

    # 'PGZERO_MODE' should be set to 'auto' by default
    assert os.getenv('PGZERO_MODE') == 'auto'
    # Switch to standard mode and run update_environment. 'PGZERO_MODE' should now be 'False'
    get_workbench().set_in_simple_mode(False)
    update_environment()
    assert os.getenv

# Generated at 2022-06-22 03:05:25.459724
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-22 03:05:31.691418
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_option(_OPTION_NAME, True)
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 03:05:40.811831
# Unit test for function toggle_variable
def test_toggle_variable():
    # Set initial value
    get_workbench().set_default(_OPTION_NAME, False)

    # Test if works
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == True
    assert os.environ["PGZERO_MODE"] == "True"

    # Test if revert works
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 03:05:47.276117
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    wb.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 03:05:49.805384
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert get_workbench().get_variable("run.pgzero_mode").get() is False
    assert os.environ["PGZERO_MODE"] == "False"



# Generated at 2022-06-22 03:05:53.323352
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert get_workbench().get_variable(_OPTION_NAME) is not None
    assert get_workbench().get_option(_OPTION_NAME) is False

# Generated at 2022-06-22 03:06:48.750277
# Unit test for function toggle_variable
def test_toggle_variable():
    from unittest import mock
    from thonny.plugins.run.simplerun import SimpleRunner
    get_workbench().in_simple_mode = True
    SimpleRunner.run_module = mock.Mock()
    SimpleRunner.run_module.side_effect = [None, Exception("Test Exception")]
    toggle_variable()
    SimpleRunner.run_module.assert_called_once()
    toggle_variable()
    SimpleRunner.run_module.assert_called_with(None, None)

# Generated at 2022-06-22 03:06:55.208828
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.getenv("PGZERO_MODE") == "False"
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.getenv("PGZERO_MODE") == "True"
    get_workbench().set_simple_mode_on()
    update_environment()
    assert os.getenv("PGZERO_MODE") == "auto"

# Generated at 2022-06-22 03:06:56.551707
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()


load_plugin()

# Generated at 2022-06-22 03:07:01.493306
# Unit test for function load_plugin
def test_load_plugin():
    # pylint: disable=missing-function-docstring
    root = tk.Tk()
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    assert get_workbench().get_option(_OPTION_NAME) == False
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 03:07:05.768952
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    get_workbench().get_variable(_OPTION_NAME).set(True)
    load_plugin()
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 03:07:14.620429
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import patch
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_default(_OPTION_NAME, True)
    assert os.environ.get("PGZERO_MODE") is None

    with patch.object(wb, "in_simple_mode"):
        wb.in_simple_mode.return_value = True
        update_environment()
        assert os.environ["PGZERO_MODE"] == "auto"

        wb.in_simple_mode.return_value = False
        update_environment()
        assert os.environ["PGZERO_MODE"] == "True"


if __name__ == "__main__":
    test_update_environment()

# Generated at 2022-06-22 03:07:26.753977
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = "auto"
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    del os.environ["PGZERO_MODE"]
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    del os.environ["PGZERO_MODE"]
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()

# Generated at 2022-06-22 03:07:28.399062
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()


if __name__ == "__main__":
    test_load_plugin()

# Generated at 2022-06-22 03:07:38.861483
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock, patch

    workbench = Mock()
    workbench.in_simple_mode.return_value = False

    with patch.multiple(
        "thonny.plugins.pgzero.plugin",
        get_workbench=lambda: workbench,
        set_default=lambda x, y: None
    ):
        load_plugin()

        workbench.set_default.assert_called_with(_OPTION_NAME, False)
        workbench.add_command.assert_called_with(
            "toggle_pgzero_mode",
            "run",
            mock.ANY,
            toggle_variable,
            flag_name=_OPTION_NAME,
            group=40,
        )

# Generated at 2022-06-22 03:07:43.667954
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().get_variable(_OPTION_NAME).set(False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True


# Generated at 2022-06-22 03:09:35.966425
# Unit test for function update_environment
def test_update_environment():
    assert os.environ["PGZERO_MODE"] == "0"

# Generated at 2022-06-22 03:09:46.715797
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    original_default_value = wb.get_option(_OPTION_NAME)
    wb.set_default(_OPTION_NAME, False)
    load_plugin()
    assert wb.get_option(_OPTION_NAME) is False
    assert len(wb.get_commands()) > 1
    assert wb.get_command("toggle_pgzero_mode") is not None
    assert os.environ["PGZERO_MODE"] == "False"

    wb.set_default(_OPTION_NAME, True)
    load_plugin()
    assert wb.get_option(_OPTION_NAME) is True
    assert len(wb.get_commands()) > 1
    assert wb.get_command("toggle_pgzero_mode") is not None
    assert os.en

# Generated at 2022-06-22 03:09:47.774490
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()

# Generated at 2022-06-22 03:09:58.242357
# Unit test for function toggle_variable
def test_toggle_variable():
    try:
        from unittest import mock
    except ImportError:
        import mock
    from thonny.running import get_runner
    runner = get_runner()
    
    def SideEffect():
        raise ValueError("pygame Zero is not installed")
    create_simple_python_file('test.py', "")
    with mock.patch("thonny.globals.get_workbench", autospec=True) as mock_get_workbench:
        instance = mock_get_workbench.return_value
        instance.get_variable.return_value = True
        instance.get_editor = mock.MagicMock()
        instance.get_editor.return_value = instance
        instance.get_text = mock.MagicMock()

# Generated at 2022-06-22 03:10:06.457430
# Unit test for function update_environment
def test_update_environment():
    from thonny.config import Configuration

    conf = Configuration(backend=None, built_in_configuration=None, overrides={})
    w = WorkbenchMock(conf)
    w.set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    w.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    w.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"



# Generated at 2022-06-22 03:10:10.167248
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_simple_mode(True)
    toggle_variable()
    assert get_workbench().in_simple_mode() == False
    toggle_variable()
    assert get_workbench().in_simple_mode() == True

# Generated at 2022-06-22 03:10:12.775215
# Unit test for function toggle_variable
def test_toggle_variable():
    for _ in range(4):
        toggle_variable()

# Generated at 2022-06-22 03:10:19.100695
# Unit test for function toggle_variable
def test_toggle_variable():
    try:
        del os.environ["PGZERO_MODE"]
    except KeyError:
        pass

    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert "PGZERO_MODE" not in os.environ

    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"