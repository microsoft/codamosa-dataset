

# Generated at 2022-06-22 03:00:34.510598
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    assert wb.get_option(_OPTION_NAME) == False
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == True
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == False

# Generated at 2022-06-22 03:00:38.482199
# Unit test for function toggle_variable
def test_toggle_variable():
    no_pgzero = get_workbench().get_option(_OPTION_NAME)
    toggle_variable()
    assert no_pgzero != get_workbench().get_option(
        _OPTION_NAME
    ), "toggle_variable failed to switch the option for pgzero"

# Generated at 2022-06-22 03:00:47.730715
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    assert get_workbench().get_option(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False
    get_workbench().set_default(_OPTION_NAME, True)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True

# Generated at 2022-06-22 03:01:00.993127
# Unit test for function update_environment
def test_update_environment():
    os.environ.clear()
    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_simple_mode(True)
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().set_simple_mode(True)
    get_work

# Generated at 2022-06-22 03:01:06.870277
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 03:01:14.551920
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, True)
    assert os.environ["PGZERO_MODE"] == "True"

    wb.set_default(_OPTION_NAME, False)
    assert os.environ["PGZERO_MODE"] == "False"

    wb.set_simple_mode(True)
    assert os.environ["PGZERO_MODE"] == "auto"

    wb.set_simple_mode(False)
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 03:01:15.926282
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == False

# Generated at 2022-06-22 03:01:17.833102
# Unit test for function toggle_variable
def test_toggle_variable():
    print("test_toggle_variable")
    update_environment()
    toggle_variable()



# Generated at 2022-06-22 03:01:28.353464
# Unit test for function toggle_variable
def test_toggle_variable():
    from pexpect import REPLWrapper
    from thonny import THONNY_USER_DIR, get_workbench
    import os

    # Get the initial value of the variable
    init_var = get_workbench().get_variable(_OPTION_NAME)

    # Toggle the variable
    toggle_variable()

    # Check if the value of the variable has changed
    new_var = get_workbench().get_variable(_OPTION_NAME)
    if init_var == new_var:
        raise Exception("The value of the variable has not changed")

    # Initialize the test environment
    get_workbench().set_option("run.use_shell", True)
    repl = REPLWrapper("python", "", None, ">>> ")

    # Check if the environment has changed
    repl.run_command("import os")
    repl

# Generated at 2022-06-22 03:01:37.680292
# Unit test for function update_environment
def test_update_environment():
    if "PGZERO_MODE" in os.environ:
        del os.environ["PGZERO_MODE"]

    assert os.environ.get("PGZERO_MODE") is None

    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()

    assert os.environ["PGZERO_MODE"] == "0"

    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()

    assert os.environ["PGZERO_MODE"] == "1"

# Generated at 2022-06-22 03:01:49.160465
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default("simple", False)

    load_plugin()

    assert get_workbench().get_option("run.pgzero_mode") is False
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_option("simple", True)
    update_environment()

    assert get_workbench().get_option("run.pgzero_mode") is False
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().set_option("simple", False)
    get_workbench().set_option("run.pgzero_mode", True)
    update_environment()

    assert get_workbench().get_option("run.pgzero_mode") is True
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 03:01:51.726983
# Unit test for function toggle_variable
def test_toggle_variable():
    variable = get_workbench().get_variable(_OPTION_NAME)
    variable.set(False)
    toggle_variable()
    assert variable.get() == True


# Generated at 2022-06-22 03:02:02.025744
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    assert os.environ.get("PGZERO_MODE") == "False"
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ.get("PGZERO_MODE") == "auto"
    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, True)
    assert os.environ.get("PGZERO_MODE") == "True"
    toggle_variable()
    assert os.environ.get("PGZERO_MODE") == "False"
    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    toggle_variable()
    assert os.environ.get

# Generated at 2022-06-22 03:02:10.732850
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import MagicMock

    wb = MagicMock()
    wb.in_simple_mode.return_value = False
    wb.get_option.return_value = True
    get_workbench.return_value = wb

    update_environment()
    os.environ["PGZERO_MODE"] = "True"

    wb.get_option.return_value = False
    update_environment()
    os.environ["PGZERO_MODE"] = "False"

# Generated at 2022-06-22 03:02:20.920733
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.config import get_config_dir
    from thonny.workbench import Workbench

    config_dir = get_config_dir()
    workbench = Workbench(config_dir)

    # Test the case when Pygmae Zero mode is disabled
    var = workbench.get_variable(_OPTION_NAME)
    var.set(False)
    workbench.set_option(_OPTION_NAME, False)
    assert workbench.get_option(_OPTION_NAME) == False
    assert var.get() == False

    # Test the case when Pygmae Zero mode is enabled
    toggle_variable()
    assert workbench.get_option(_OPTION_NAME) == True
    assert var.get() == True
    toggle_variable()

# Generated at 2022-06-22 03:02:22.423478
# Unit test for function toggle_variable
def test_toggle_variable():
    _OPTION_NAME = "test_option"


# Generated at 2022-06-22 03:02:30.954073
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_simple_mode(True)
    assert get_workbench().get_variable(_OPTION_NAME).get() is False
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() is False
    get_workbench().set_simple_mode(False)
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() is True
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() is False

# Generated at 2022-06-22 03:02:34.291477
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    assert get_workbench().in_simple_mode() == False
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-22 03:02:40.126935
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.ui_utils import get_toolbar_button

    wb = get_workbench()
    wb.set_default(_OPTION_NAME, True)
    wb.get_variable(_OPTION_NAME).set(False)
    tb = get_toolbar_button("run", "toggle_pgzero_mode")
    tb.invoke()
    assert wb.get_variable(_OPTION_NAME).get() == True
    tb.invoke()
    assert wb.get_variable(_OPTION_NAME).get() == False


# Generated at 2022-06-22 03:02:50.266566
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench, get_shell
    load_plugin()
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) is True, get_workbench().get_option(_OPTION_NAME)
    cmd = get_workbench().get_command("toggle_pgzero_mode")
    cmd.run()
    assert get_workbench().get_option(_OPTION_NAME) is False, get_workbench().get_option(_OPTION_NAME)
    assert get_shell().interp.locals["PGZERO_MODE"] == "False", get_shell().interp.locals["PGZERO_MODE"]


if __name__ == "__main__":
    test_load_plugin()

# Generated at 2022-06-22 03:03:00.851295
# Unit test for function toggle_variable
def test_toggle_variable():

    get_workbench().set_option(_OPTION_NAME, False)
    assert get_workbench().get_option(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False


# Generated at 2022-06-22 03:03:07.680772
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, True)
    load_plugin()
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 03:03:16.902002
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench

    wb = Workbench()
    load_plugin()
    assert wb.get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"
    wb.set_option(_OPTION_NAME, True)
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"
    wb.in_simple_mode = lambda: True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 03:03:25.667787
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = "auto"
    
    wb = Workbench()
    wb.set_option(_OPTION_NAME, True)
    wb.set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    
    wb.set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    
    wb.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 03:03:34.427622
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 03:03:38.654566
# Unit test for function update_environment
def test_update_environment():
    del os.environ["PGZERO_MODE"]
    update_environment()
    assert os.environ["PGZERO_MODE"]=="False"
    toggle_variable()
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 03:03:39.677206
# Unit test for function toggle_variable
def test_toggle_variable():
    print("Hello World!")

# Generated at 2022-06-22 03:03:47.041398
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default("view.simple_mode", False)
    load_plugin()
    assert get_workbench().get_option("run.pgzero_mode") == False
    wb.set_option("run.pgzero_mode", True)
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 03:03:57.055234
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock
    from thonny.workbench import Workbench

    mock_workbench = Mock(Workbench)
    mock_workbench.get_option.side_effect = lambda option_name: False
    mock_workbench.set_default.side_effect = lambda option_name, value: None
    mock_workbench.add_command.side_effect = lambda cmd_name, menu_name, label, cmd, flag_name, group=None: None
    mock_workbench.in_simple_mode.side_effect = lambda : False
    global get_workbench
    get_workbench = lambda : mock_workbench
    load_plugin()
    assert mock_workbench.set_default.call_count == 1
    assert mock_workbench.add_command.call_count == 1
    assert os

# Generated at 2022-06-22 03:04:02.486154
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    wb.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "pygame"

    wb.set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "pgzero"

# Generated at 2022-06-22 03:04:20.517822
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench
    workbench = get_workbench()
    workbench.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    del os.environ["PGZERO_MODE"]
    workbench.set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    workbench.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 03:04:31.856358
# Unit test for function update_environment
def test_update_environment():
    if get_workbench().get_option("run.pgzero_mode"):
        get_workbench().set_option("run.pgzero_mode", False)

    try:
        update_environment()
        assert os.environ.get("PGZERO_MODE") == "False"
        get_workbench().set_option("run.pgzero_mode", True)
        update_environment()
        assert os.environ.get("PGZERO_MODE") == "True"
        get_workbench().set_in_simple_mode(True)
        update_environment()
        assert os.environ.get("PGZERO_MODE") == "auto"
    finally:
        get_workbench().set_in_simple_mode(False)
        get_workbench().set_option("run.pgzero_mode", False)

# Generated at 2022-06-22 03:04:39.416830
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = "auto"
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 03:04:46.524125
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import Mock
    mock_workbench = Mock()
    mock_workbench.in_simple_mode = lambda: False
    mock_workbench.get_option = lambda name: True
    os.environ["PGZERO_MODE"] = ""
    with patch("thonny.plugins.pgzero_mode.get_workbench", return_value=mock_workbench):
        update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 03:04:58.150361
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    assert os.environ["PGZERO_MODE"] == "auto"
    wb.set_default(_OPTION_NAME, True)
    assert os.environ["PGZERO_MODE"] == "True"
    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    assert os.environ["PGZERO_MODE"] == "auto"
    wb.set_default(_OPTION_NAME, True)
    wb.set_default(_OPTION_NAME, False)
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 03:05:09.898612
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = "auto"
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

#

# Generated at 2022-06-22 03:05:10.799754
# Unit test for function toggle_variable
def test_toggle_variable():
    print(toggle_variable())

# Generated at 2022-06-22 03:05:15.362962
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    wb = Workbench()
    with wb.config as c:
        c.remove_option(_OPTION_NAME)
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == False

    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-22 03:05:24.168449
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    workbench = Workbench()
    workbench.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.getenv("PGZERO_MODE") == "True"

    workbench.set_option(_OPTION_NAME, False)
    update_environment()
    assert os.getenv("PGZERO_MODE") == "False"

    workbench.set_option(_OPTION_NAME, 0)
    update_environment()
    assert os.getenv("PGZERO_MODE") == "0"

# Generated at 2022-06-22 03:05:27.257873
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] ==  "False"

# Generated at 2022-06-22 03:05:57.610007
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.plugins.run_pgzero_mode import toggle_variable
    from thonny import get_workbench
    
    
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True

# Generated at 2022-06-22 03:06:08.610631
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny import get_workbench
    from thonny.languages import tr

    # Test for toggle_variable function when in pygame zero mode
    get_workbench().set_in_simple_mode(False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME)

    # Test for toggle_variable function when not in pygame zero mode
    get_workbench().set_in_simple_mode(False)
    toggle_variable()
    assert not get_workbench().get_option(_OPTION_NAME)

    # Test for toggle_variable function when in simple mode
    get_workbench().set_in_simple_mode(True)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME)



# Generated at 2022-06-22 03:06:17.501134
# Unit test for function update_environment
def test_update_environment():
    from thonny.globals import get_workbench
    from tests.utils import hide_output

    with hide_output():
        load_plugin()

    print("Checking if environment gets updated by load_plugin()")
    assert os.environ["PGZERO_MODE"] == "False"

    print("Checking if update_environment() works fine")
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    print("Checking if toggle_variable() works fine")
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 03:06:24.606183
# Unit test for function update_environment
def test_update_environment():
    # set to auto in simple mode
    import thonny.workbench

    wb = thonny.workbench.get_workbench()
    wb._simple_mode = True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    # set to true in normal mode
    del os.environ["PGZERO_MODE"]
    wb._simple_mode = False
    option = wb.get_option(_OPTION_NAME)
    option.set(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    # set to false in normal mode
    option.set(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"



# Generated at 2022-06-22 03:06:33.076262
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    original_simple_mode = wb.in_simple_mode()
    if wb.in_simple_mode():
        wb.set_simple_mode(False)
        load_plugin()
        assert not wb.get_option(_OPTION_NAME)
        
        toggle_variable()
        assert wb.get_option(_OPTION_NAME)
        
        toggle_variable()
        assert not wb.get_option(_OPTION_NAME)
        
        wb.set_simple_mode(True)
        assert wb.get_option(_OPTION_NAME)
        assert os.environ["PGZERO_MODE"] == "auto"
        toggle_variable()
        assert os.environ["PGZERO_MODE"] == "auto"

    else:
        load

# Generated at 2022-06-22 03:06:43.822748
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    wb.set_default(_OPTION_NAME, False)
    wb.set_in_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    wb.set_default(_OPTION_NAME, False)
    wb.set_in_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    wb.set_default(_OPTION_NAME, True)
    wb.set_in_simple_mode(False)
    update_environment()

# Generated at 2022-06-22 03:06:48.470198
# Unit test for function toggle_variable
def test_toggle_variable():
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-22 03:06:55.880874
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()
    assert wb.get_variable(_OPTION_NAME) == wb.get_option(_OPTION_NAME)
    assert os.environ["PGZERO_MODE"] == str(wb.get_option(_OPTION_NAME))

# Generated at 2022-06-22 03:06:56.886355
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()



# Generated at 2022-06-22 03:06:59.241302
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()

    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 03:07:51.467043
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_simple_mode(True)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 03:07:59.997396
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"

# Generated at 2022-06-22 03:08:02.119227
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    wb.set_simple_mode(False)
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 03:08:05.111711
# Unit test for function toggle_variable
def test_toggle_variable():
    opt = get_workbench().get_option(_OPTION_NAME)
    assert opt == False
    toggle_variable()
    assert opt == True
    toggle_variable()
    assert opt == False


# Generated at 2022-06-22 03:08:10.852195
# Unit test for function load_plugin
def test_load_plugin():
    m = Mock(get_variable=Mock())
    m.in_simple_mode = Mock(return_value=False)

    with patch.dict("sys.modules"):
        sys.modules["thonny"] = m
        load_plugin()
        m.add_command.assert_called_once()
        assert m.get_variable.called

# Generated at 2022-06-22 03:08:14.665704
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock
    from thonny.workbench import Workbench
    from thonny.main import Thonny

    wb = Workbench(Mock(spec=Thonny))
    load_plugin()

# Generated at 2022-06-22 03:08:19.200768
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.clear_commands()
    load_plugin()
    assert wb.get_option(_OPTION_NAME) == False
    assert wb.in_simple_mode() == False
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"


# Generated at 2022-06-22 03:08:30.170383
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench

    get_workbench().set_default(_OPTION_NAME, True)
    load_plugin()
    assert os.environ["PGZERO_MODE"] == "1"

    get_workbench().set_default(_OPTION_NAME, False)
    assert os.environ["PGZERO_MODE"] == "0"

    # trigger plugin watching
    get_workbench().set_simple_mode(True)
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().set_simple_mode(False)
    assert os.environ["PGZERO_MODE"] == "0"

    # remove plugin
    get_workbench().event_generate("PluginUnloaded", plugin_id="thonny.plugins.pgzero_mode")

   

# Generated at 2022-06-22 03:08:36.252613
# Unit test for function load_plugin
def test_load_plugin():
    wb = DummyWorkbench()
    load_plugin()
    assert wb.get_option(_OPTION_NAME) is False
    wb.set_option(_OPTION_NAME, True)
    assert wb.get_option(_OPTION_NAME) is True
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) is False


# unit test for function toggle_variable

# Generated at 2022-06-22 03:08:46.306838
# Unit test for function update_environment
def test_update_environment():
    import os
    from thonny import get_workbench
    from thonny.plugins.pgzero_mode import load_plugin

    def remove_variable_from_os():
        del os.environ["PGZERO_MODE"]

    get_workbench().reset()
    load_plugin()
    os.environ["PGZERO_MODE"] = "ignore"

    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    remove_variable_from_os()
