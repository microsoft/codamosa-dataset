

# Generated at 2022-06-22 03:00:34.215114
# Unit test for function toggle_variable
def test_toggle_variable():
    # 1. Check that option is set on
    toggle_variable()
    assert get_workbench().get_option(
        _OPTION_NAME
    ) == True, "Toggle variable failed to set option on"

    # 2. Check that option is set off
    toggle_variable()
    assert get_workbench().get_option(
        _OPTION_NAME
    ) == False, "Toggle variable failed to set option off"

# Generated at 2022-06-22 03:00:42.164409
# Unit test for function update_environment
def test_update_environment():
    # Test to see if PGZERO_MODE is set correctly
    os.environ["PGZERO_MODE"] = ""
    get_option().set(True)
    update_environment()
    assert(os.environ["PGZERO_MODE"] == "True")
    get_option().set(False)
    update_environment()
    assert(os.environ["PGZERO_MODE"] == "False")
    get_workbench().set_simple_mode(True)
    get_option().set(True)
    update_environment()
    assert(os.environ["PGZERO_MODE"] == "auto")

# Generated at 2022-06-22 03:00:51.611444
# Unit test for function toggle_variable
def test_toggle_variable():
    import unittest.mock as mock

    from thonny import get_workbench, get_runner

    get_workbench().clear_all_variables()

    get_runner().add_environment_variable("PGZERO_MODE")

    # Test 1, initial value
    assert os.environ["PGZERO_MODE"] == "auto"

    # Test 2, toggle it
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    assert get_workbench().get_variable(_OPTION_NAME).get() == True

    # Test 3, toggle it again
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"
    assert get_workbench().get_variable(_OPTION_NAME).get() == False

    # Test 4, toggle when in

# Generated at 2022-06-22 03:01:04.254117
# Unit test for function update_environment
def test_update_environment():
    print("Started unit test for update_environment...")

    # Case 1: Simple mode
    print("Case 1: Simple mode")
    try:
        os.environ.pop("PGZERO_MODE")
    except KeyError:
        pass
    assert "PGZERO_MODE" not in os.environ
    os.environ["THONNY_SIMPLE_MODE"] = "true"
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    # Case 2: Advanced mode
    print("Case 2: Advanced mode")
    try:
        del os.environ["THONNY_SIMPLE_MODE"]
    except KeyError:
        pass
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()

# Generated at 2022-06-22 03:01:15.561302
# Unit test for function update_environment
def test_update_environment():
    _get_workbench = get_workbench
    get_workbench = Mock()
    get_workbench.return_value = Mock(
        get_option=Mock(return_value=False), in_simple_mode=Mock(return_value=False)
    )
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench.return_value = Mock(
        get_option=Mock(return_value=True), in_simple_mode=Mock(return_value=False)
    )
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 03:01:25.290625
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().get_option(_OPTION_NAME).set(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().get_option(_OPTION_NAME).set(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 03:01:28.589347
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_option(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 03:01:38.759536
# Unit test for function toggle_variable
def test_toggle_variable():
    command = get_workbench().get_command("toggle_pgzero_mode")

    assert get_workbench().get_option(_OPTION_NAME) == False
    assert get_workbench().get_variable(_OPTION_NAME).get() == False

    command.invoke()

    assert get_workbench().get_option(_OPTION_NAME) == True
    assert get_workbench().get_variable(_OPTION_NAME).get() == True

    command.invoke()

    assert get_workbench().get_option(_OPTION_NAME) == False
    assert get_workbench().get_variable(_OPTION_NAME).get() == False

# Generated at 2022-06-22 03:01:47.773777
# Unit test for function toggle_variable
def test_toggle_variable():
    # reset to default
    get_workbench().set_default(_OPTION_NAME, False)
    assert_equal(get_workbench().get_option(_OPTION_NAME), False)
    assert_equal(os.environ["PGZERO_MODE"], "False")
    toggle_variable()
    assert_equal(get_workbench().get_option(_OPTION_NAME), True)
    assert_equal(os.environ["PGZERO_MODE"], "True")

    # reset to default again
    toggle_variable()
    assert_equal(get_workbench().get_option(_OPTION_NAME), False)
    assert_equal(os.environ["PGZERO_MODE"], "False")

# Generated at 2022-06-22 03:01:59.673075
# Unit test for function toggle_variable
def test_toggle_variable():
    exec("""\
from thonny.plugins.pgzero_mode import toggle_variable
from thonny import get_workbench

toggle_variable()
assert get_workbench().get_variable("run.pgzero_mode") == True
toggle_variable()
assert get_workbench().get_variable("run.pgzero_mode") == False""", locals(), globals())


"""
from thonny import get_workbench
from thonny.languages import tr
get_workbench().set_default("run.pgzero_mode", True)
get_workbench().add_command("toggle_pgzero_mode", "run", tr("Pygame Zero mode"), update_environment,flag_name="run.pgzero_mode", group=40)
"""

# Generated at 2022-06-22 03:02:09.554032
# Unit test for function update_environment
def test_update_environment():
    import os
    import sys
    import unittest
    from unittest.mock import Mock

    if sys.platform == "win32":
        raise unittest.SkipTest("possible-bug")

    os.environ["PGZERO_MODE"] = "auto"

    workbench = Mock()
    workbench.get_option.return_value = True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"

    workbench.get_option.return_value = False
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"

    del os.environ["PGZERO_MODE"]

# Generated at 2022-06-22 03:02:19.944536
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    update_environment()
    assert os.getenv("PGZERO_MODE") == "False"

    wb.set_default(_OPTION_NAME, True)
    update_environment()
    assert os.getenv("PGZERO_MODE") == "True"

    wb._in_simple_mode = True
    update_environment()
    assert os.getenv("PGZERO_MODE") == "auto"

    wb._in_simple_mode = False
    wb.set_default(_OPTION_NAME, False)
    update_environment()
    assert os.getenv("PGZERO_MODE") == "False"


# Generated at 2022-06-22 03:02:23.479899
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default("run.pgzero_mode", True)
    assert os.environ["PGZERO_MODE"] == "True"
    load_plugin()
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 03:02:31.502885
# Unit test for function toggle_variable
def test_toggle_variable():
    
    # test if the default value is False
    assert get_workbench().get_variable(_OPTION_NAME).get() == False

    #test if the value change to True after calling toggle_variable()
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == True

    #test if the value change back to False after calling toggle_variable()
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == False


# Generated at 2022-06-22 03:02:40.513962
# Unit test for function update_environment
def test_update_environment():
    if "PGZERO_MODE" in os.environ:
        del os.environ["PGZERO_MODE"]

    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    wb.set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"

    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"

# Generated at 2022-06-22 03:02:40.978168
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()

# Generated at 2022-06-22 03:02:51.201729
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config import ConfigurationProxy
    from thonny.config_ui import ConfigurationPage
    from thonny import get_workbench
    from tkinter import BooleanVar
    from unittest import mock

    get_workbench().in_simple_mode = mock.Mock(return_value=False)

    workbench = Workbench()
    workbench.get_option = mock.Mock(return_value=True)

    # get_workbench().create_variable returns a tkinter.BooleanVar instance
    workbench.get_variable = mock.Mock(return_value=BooleanVar())
    workbench.get_variable().get.return_value = True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"

# Generated at 2022-06-22 03:03:02.650607
# Unit test for function update_environment
def test_update_environment():
    old_value = os.environ.get("PGZERO_MODE", None)

# Generated at 2022-06-22 03:03:04.270667
# Unit test for function toggle_variable
def test_toggle_variable():
    
    assert toggle_variable() == None #fix this

# Generated at 2022-06-22 03:03:16.344352
# Unit test for function toggle_variable
def test_toggle_variable():
    
    import unittest.mock as mock
    
    with mock.patch("thonny.plugins.microbit_plugin.toggle_variable"):
        workbench = mock.MagicMock()
        workbench.get_variable.return_value = mock.MagicMock()
        workbench.get_variable.return_value.get.return_value = False
        workbench.get_variable.return_value.set.return_value = True
        workbench.in_simple_mode.return_value = False
        workbench.get_option.return_value = True
        workbench.get_option.return_value = True
        workbench.add_command = mock.MagicMock()
        workbench.set_default = mock.MagicMock()

        toggle_variable()
    
    
    
    
test_toggle

# Generated at 2022-06-22 03:03:38.073468
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import workbench
    from thonny.plugins.run.run_pgzero_mode import load_plugin
    load_plugin()

    assert workbench.get_default(_OPTION_NAME) == False

    # check the menu is there
    assert workbench.get_menu("run").get_children()[-1].get_label() == "Pygame Zero mode"
    assert workbench.get_menu("run").get_children()[-1].get_flag_name() == "run.pgzero_mode"
    assert workbench.get_menu("run").get_children()[-1].get_group() == 40

# Generated at 2022-06-22 03:03:48.165880
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench

    workbench = Workbench()
    workbench.set_default(_OPTION_NAME, False)
    workbench.in_simple_mode = lambda: True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    workbench.in_simple_mode = lambda: False
    workbench.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    workbench.set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 03:03:54.060693
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    assert wb.get_option(_OPTION_NAME) is False
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) is True
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) is False



# Generated at 2022-06-22 03:04:00.290344
# Unit test for function toggle_variable
def test_toggle_variable():
    test_variable = get_workbench().get_variable(_OPTION_NAME)
    assert test_variable.get() == False
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert test_variable.get() == True
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 03:04:06.016735
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()


if __name__ == "__main__":
    test_load_plugin()

# Generated at 2022-06-22 03:04:13.113005
# Unit test for function toggle_variable
def test_toggle_variable():
    km = get_workbench().get_key_bindings()
    get_workbench().set_option(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False


# Generated at 2022-06-22 03:04:13.879853
# Unit test for function load_plugin
def test_load_plugin():
    pass

# Generated at 2022-06-22 03:04:21.118886
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny import get_workbench

    # Set plugin is not yet loaded
    assert "pgzero_mode" not in get_workbench().variables
    assert "PGZERO_MODE" not in os.environ

    # Call the function
    toggle_variable()

    # Check plugin is loaded and set to true
    assert get_workbench().variables["pgzero_mode"] == True
    assert os.environ["PGZERO_MODE"] == "True"

    # Call the function
    toggle_variable()

    # Check plugin is loaded and set to false
    assert get_workbench().variables["pgzero_mode"] == False
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 03:04:28.266624
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.globals import get_workbench

    w = get_workbench()

    load_plugin()

    w.simplify()
    w.simplify(False)

    # Assert that the plugin was loaded.
    w.de_simplify()
    w.get_variable(_OPTION_NAME)

    # Assert that the command was registered.
    w.get_command("toggle_pgzero_mode")

    # Assert that the appropriate environmental variable is set.
    os.environ["PGZERO_MODE"]

# Generated at 2022-06-22 03:04:40.296353
# Unit test for function update_environment
def test_update_environment():
    from thonny.misc_utils import running_on_windows
    try:
        get_workbench().set_option(_OPTION_NAME, "1")
        update_environment()
        assert os.environ["PGZERO_MODE"] == "1"
        
        get_workbench().set_option(_OPTION_NAME, 0)
        update_environment()
        assert os.environ["PGZERO_MODE"] == "0"
        
        get_workbench().set_option(_OPTION_NAME, "")
        update_environment()
        assert os.environ["PGZERO_MODE"] == ""
    finally:
        if running_on_windows():
            os.environ["PGZERO_MODE"] = ""
        else:
            del os.environ["PGZERO_MODE"]

# Generated at 2022-06-22 03:05:02.720375
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import Mock

    wb = Mock()
    wb.in_simple_mode = Mock(return_value=False)
    wb.get_option = Mock(return_value=False)
    wb.get_variable = Mock(return_value=False)
    # Test the function is doing what it should in gui mode
    assert "PGZERO_MODE" not in os.environ
    update_environment(wb)
    assert os.environ["PGZERO_MODE"] == "False"

    # Test the function is doing what it should in simple mode
    wb.in_simple_mode = Mock(return_value=True)
    update_environment(wb)
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 03:05:14.582445
# Unit test for function update_environment
def test_update_environment():
    import sys

    current_env = dict(os.environ)
    try:
        del os.environ["PGZERO_MODE"]
        update_environment()
        assert os.environ["PGZERO_MODE"] == "auto"

        os.environ["PGZERO_MODE"] = "True"
        update_environment()
        assert os.environ["PGZERO_MODE"] == "True"

        sys.argv = ["thonny"]
        update_environment()
        assert os.environ["PGZERO_MODE"] == "True"

        sys.argv = ["thonny", "--simple-mode"]
        update_environment()
        assert os.environ["PGZERO_MODE"] == "auto"

    finally:
        os.environ.clear()

# Generated at 2022-06-22 03:05:17.220026
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-22 03:05:23.155328
# Unit test for function load_plugin
def test_load_plugin():
    global _OPTION_NAME
    _OPTION_NAME = "TEST_OPTION_NAME"
    old_value = get_workbench().get_variable(_OPTION_NAME).get()

# Generated at 2022-06-22 03:05:33.056817
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.globals import get_workbench
    from thonny.misc_utils import running_on_linux
    from tkinter import BooleanVar
    import os

    wb = get_workbench()
    wb.set_option(_OPTION_NAME, False)

    toggle_variable()
    assert wb.get_option(_OPTION_NAME)
    assert os.environ["PGZERO_MODE"] == "True"
    assert not running_on_linux()

    toggle_variable()
    assert not wb.get_option(_OPTION_NAME)
    assert os.environ["PGZERO_MODE"] == "False"

    toggle_variable()
    assert wb.get_option(_OPTION_NAME)
    assert os.environ["PGZERO_MODE"] == "True"
   

# Generated at 2022-06-22 03:05:41.997077
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().in_simple_mode = lambda: False
    load_plugin()
    get_workbench().set_option(_OPTION_NAME, False)
    assert os.environ["PGZERO_MODE"] == "0"
    get_workbench().set_option(_OPTION_NAME, True)
    assert os.environ["PGZERO_MODE"] == "1"

    get_workbench().in_simple_mode = lambda: True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 03:05:47.643067
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import MagicMock
    from thonny.globals import get_workbench
    get_workbench = MagicMock()
    wb = MagicMock()
    wb.get_option = MagicMock(return_value=True)
    get_workbench.return_value = wb
    update_environment()

    assert os.environ.get("PGZERO_MODE") == "True"

# Generated at 2022-06-22 03:05:59.145643
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    wb.configure_interpretation_mode_menu(["pygame_zero"])
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) is True
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) is False
    assert os.environ["PGZERO_MODE"] == "False"
    wb.configure_interpretation_mode_menu(["auto"])
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    wb.configure_interpretation_mode_menu([])
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) is True
    assert os

# Generated at 2022-06-22 03:06:04.505397
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 03:06:08.179693
# Unit test for function update_environment
def test_update_environment():
    # Given
    get_workbench().set_default(_OPTION_NAME, False)

    # When
    update_environment()

    # Then
    assert os.environ["PGZERO_MODE"] == "False"



# Generated at 2022-06-22 03:06:38.903312
# Unit test for function toggle_variable
def test_toggle_variable():
    saved_var = get_workbench().get_variable(_OPTION_NAME)
    get_workbench().set_variable(_OPTION_NAME, True)
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME) == True
    get_workbench().set_variable(_OPTION_NAME, saved_var)


# Generated at 2022-06-22 03:06:43.784093
# Unit test for function toggle_variable
def test_toggle_variable():
    try:
        toggle_variable()
        assert os.environ["PGZERO_MODE"] == "True"
        toggle_variable()
        assert os.environ["PGZERO_MODE"] == "False"
    except KeyError:
        raise AssertionError(
            "Incorrect behaviour of test_toggle_variable - \
            os.environ['PGZERO_MODE'] could not be found."
        )

# Generated at 2022-06-22 03:06:52.454184
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench
    from thonny.workbench import Workbench
    from unittest.mock import MagicMock

    wb = Workbench()
    wb.set_default = MagicMock()
    wb.add_command = MagicMock()
    load_plugin()

    assert wb.set_default.call_count == 1  # set_default is called inside load_plugin()
    assert wb.add_command.call_count == 1  # add_command is called inside load_plugin()


if __name__ == "__main__":
    test_load_plugin()

# Generated at 2022-06-22 03:06:59.551101
# Unit test for function update_environment
def test_update_environment():
    from thonny.globals import get_workbench
    from thonny.languages import get_current_language

    from thonny import thonny
    from thonny.ui_utils import common_font

    class Workbench:
        def in_simple_mode(self):
            return False

        def get_option(self, name):
            return True


    class ConfigParser:
        def __init__(self, **kwargs):
            pass

        def getboolean(self, section, key):
            return True


    class Thonny:
        def __init__(self, config):
            self.config = config

        def get_option(self, key):
            return True

        def get_theme_name(self):
            return "default"


# Generated at 2022-06-22 03:07:05.415531
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == True
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == False

# Generated at 2022-06-22 03:07:10.205489
# Unit test for function update_environment
def test_update_environment():
    assert os.getenv("PGZERO_MODE", "") == ""

    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().in_simple_mode = lambda: False
    update_environment()
    assert os.getenv("PGZERO_MODE", "") == "False"

    get_workbench().set_option(_OPTION_NAME, True)
    update_enviro

# Generated at 2022-06-22 03:07:10.774051
# Unit test for function load_plugin
def test_load_plugin():
    pass

# Generated at 2022-06-22 03:07:20.121585
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.languages import tr
    from thonny.globals import get_workbench
    get_workbench().set_simple_mode(True)
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME) == True
    get_workbench().set_simple_mode(False)
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME) == True

# Generated at 2022-06-22 03:07:31.256370
# Unit test for function toggle_variable
def test_toggle_variable():
    # Capture stdout
    from io import StringIO
    import sys
    import traceback
    captured_stdout = StringIO()
    sys.stdout = captured_stdout
    # Run code
    import sys, os
    current_module = sys.modules["thonnycontrib.pgzero"]
    directory_of_current_module = os.path.dirname(current_module.__file__)

# Generated at 2022-06-22 03:07:39.331850
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_default(_OPTION_NAME, True)
    assert os.environ["PGZERO_MODE"] == "True"

    wb.set_default(_OPTION_NAME, False)
    assert os.environ["PGZERO_MODE"] == "False"

    wb.set_simple_mode(True)
    wb.set_default(_OPTION_NAME, True)
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 03:08:35.881491
# Unit test for function toggle_variable
def test_toggle_variable():
    env = os.environ.copy()
    os.environ.clear()
    assert os.environ == {}
    try:
        get_workbench().set_default(_OPTION_NAME, False)
        assert os.environ.get("PGZERO_MODE") == "False"
        toggle_variable()
        assert os.environ.get("PGZERO_MODE") == "True"
        toggle_variable()
        assert os.environ.get("PGZERO_MODE") == "False"
    finally:
        os.environ.clear()
        os.environ.update(env)

# Generated at 2022-06-22 03:08:39.778524
# Unit test for function load_plugin
def test_load_plugin():
    workbench = get_workbench()
    workbench.set_default(_OPTION_NAME, False)
    load_plugin()
    assert workbench.get_variable(_OPTION_NAME).get() == False
    #TODO: consider how to implement test cases

# Generated at 2022-06-22 03:08:46.235341
# Unit test for function load_plugin
def test_load_plugin():
    wb = Workbench()
    wb.set_default("run.pgzero_mode", "auto")

    load_plugin()

    # verifying that variable has been created
    assert wb.get_variable("run.pgzero_mode") == wb.get_variable("run.pgzero_mode")
    assert wb.get_variable("run.pgzero_mode").get() == False
    assert os.environ["PGZERO_MODE"] == str(wb.get_option("run.pgzero_mode"))

# Generated at 2022-06-22 03:08:48.205776
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default(_OPTION_NAME, None)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 03:08:48.628833
# Unit test for function load_plugin
def test_load_plugin():
    return True

# Generated at 2022-06-22 03:09:00.110390
# Unit test for function toggle_variable
def test_toggle_variable():
    from unittest.mock import Mock

    wb = Mock()
    wb.in_simple_mode = Mock(return_value=False)

    get_workbench = Mock()
    get_workbench.return_value = wb

    var = Mock()
    var.set = Mock()

    wb.get_variable = Mock(return_value=var)
    wb.get_option = Mock(return_value=False)
    wb.set_option = Mock()

    os.environ["PGZERO_MODE"] = "auto"
    toggle_variable()

    var.set.assert_called_with(False)
    wb.get_variable.assert_called_with(_OPTION_NAME)
    wb.set_option.assert_called_with(_OPTION_NAME, False)
    w

# Generated at 2022-06-22 03:09:02.657719
# Unit test for function toggle_variable
def test_toggle_variable():
    name = "x"
    toggle_variable()
    assert get_workbench().get_variable(name).get() == False
    toggle_variable()
    assert get_workbench().get_variable(name).get() == True

# Generated at 2022-06-22 03:09:13.633498
# Unit test for function update_environment
def test_update_environment():
    print("TESTING PGZero mode")
    # Test that environment is set to auto when in simple mode
    get_workbench().set_simple_mode()
    update_environment()
    assert os.environ.get("PGZERO_MODE") == "auto"

    # Test that environment is set to False when option is False
    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ.get("PGZERO_MODE") == "False"

    # Test that environment is set to True when option is True
    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()

# Generated at 2022-06-22 03:09:16.630945
# Unit test for function toggle_variable
def test_toggle_variable():
    w = get_workbench()
    w.set_default(_OPTION_NAME, False)
    assert not toggle_variable()
    assert toggle_variable()
    assert not toggle_variable()

# Generated at 2022-06-22 03:09:23.332741
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock

    get_workbench = Mock()
    wb = Mock()
    wb.in_simple_mode.return_value = False
    wb.get_option.return_value = False
    get_workbench.return_value = wb

    # TODO: test whether add_command code is called
    load_plugin()
    assert os.environ["PGZERO_MODE"] == "False"