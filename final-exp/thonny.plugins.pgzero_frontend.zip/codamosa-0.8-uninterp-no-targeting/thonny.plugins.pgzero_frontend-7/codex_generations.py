

# Generated at 2022-06-22 03:00:57.931713
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny import Thonny

    test_app = Thonny(user_dir=None)
    test_app.workbench.set_default(_OPTION_NAME, False)

    toggle_variable()
    toggle_variable()

    test_app.destroy()

# Generated at 2022-06-22 03:01:06.521718
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, True)
    
    load_plugin()
    
    assert not get_workbench().get_option(_OPTION_NAME)
    assert os.environ.get("PGZERO_MODE") == "False"
    
    get_workbench().set_default(_OPTION_NAME, False)
    
    load_plugin()
    
    assert not get_workbench().get_option(_OPTION_NAME)
    assert os.environ.get("PGZERO_MODE") == "False"



# Generated at 2022-06-22 03:01:13.708735
# Unit test for function load_plugin
def test_load_plugin():
    """
    Checks that plugin is loaded after function is called.
    """
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()
    assert "toggle_pgzero_mode" in wb.get_commands()

# Generated at 2022-06-22 03:01:19.903898
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = "auto"

    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    assert "PGZERO_MODE" not in os.environ

    wb.set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"

# Generated at 2022-06-22 03:01:26.218475
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    get_workbench().set_default(_OPTION_NAME, False)
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_default(_OPTION_NAME, True)
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_default(_OPTION_NAME, "auto")
    assert os.environ["PGZERO_MODE"] == "auto"

load_plugin()

# Generated at 2022-06-22 03:01:34.716724
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock
    from thonny.globals import get_workbench
    from thonny.workbench import Workbench
    from thonny.languages import tr
    from thonny.misc_utils import running_on_mac_os, running_on_windows
    from thonny.common import InlineCommand

    MockTK = Mock()
    workbench = Workbench(MockTK)
    get_workbench = Mock(return_value=workbench)
    load_plugin()

    assert get_workbench.call_count == 1
    workbench.set_default.assert_called_once_with(_OPTION_NAME, False)

# Generated at 2022-06-22 03:01:44.763460
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench
    from test_utils import get_python_version
    from thonny.plugins.run.pgzero_mode import load_plugin
    p = get_python_version()[0]
    if p == 'Python 3':
        s = 'pgzero_mode.py'
    else:
        s = 'pgzero_mode_%s_2.py' % p
    test_dir = os.path.dirname(os.path.abspath(__file__))
    tmp_dir = os.path.join(test_dir, 'tmp')
    if os.path.exists(tmp_dir):
        shutil.rmtree(tmp_dir)
    os.mkdir(tmp_dir)
    tb = get_workbench()

# Generated at 2022-06-22 03:01:50.169536
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_option("run.pgzero_mode", True)
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME) == False

# Generated at 2022-06-22 03:01:58.129275
# Unit test for function update_environment
def test_update_environment():
    from thonny.common import InlineCommand
    from thonny.testing import mock_tk
    from thonny.languages import tr

    mock = mock_tk()
    get_workbench().set_option(_OPTION_NAME, False)
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    InlineCommand("print(os.environ['PGZERO_MODE'])").execute()
    assert mock.stdout.getvalue() == "auto\n"
    assert mock.stderr.getvalue() == ""

# Generated at 2022-06-22 03:02:01.664848
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME) == False

# Generated at 2022-06-22 03:02:17.369182
# Unit test for function load_plugin
def test_load_plugin():
    # 1. Initialize a workbench
    # 2. Load the plugin ?
    # 3. Reset the workbench ?
    wb = get_workbench()
    load_plugin()
    # 4. Get the default value of the option
    # 5. Toggle the variable
    # 6. Value of the variable ?
    # 7. Variable set in the environment ?
    # 8. Set it back to the default value
    # 9. Toggle the variable again
    # 10. Value of the variable ?
    # 11. Variable set in the environment ?

    default_value = wb.get_option(_OPTION_NAME)
    wb.event_generate("TogglePgZeroMode")
    assert wb.get_option(_OPTION_NAME) != default_value

# Generated at 2022-06-22 03:02:24.884999
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    os.environ["PGZERO_MODE"] = str(get_workbench().get_option(_OPTION_NAME))
    assert get_workbench().get_option(_OPTION_NAME)==False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME)==True
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME)==False
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_simple_mode(True)
    #set in_simple_mode to True, which set PGZERO_MODE enviroment to "auto"

# Generated at 2022-06-22 03:02:32.661617
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.workbench import Workbench
    from thonny.memory import GlobalVariable

    wb = Workbench(default_font_family="Helvetica") 
    wb.create_user_config_folder()
    wb.create_default_configuration()
    var = GlobalVariable(wb, _OPTION_NAME)
    var.set(True)
    toggle_variable()
    # Expect False
    assert var.get() == False 
    toggle_variable()
    # Expect True
    assert var.get() == True

# Generated at 2022-06-22 03:02:39.079316
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    wb.set_option(_OPTION_NAME, False)
    assert os.environ.get("PGZERO_MODE", "") == "False"

    wb.set_option(_OPTION_NAME, True)
    assert os.environ.get("PGZERO_MODE", "") == "True"

    wb.set_option(_OPTION_NAME, False)
    wb._in_simple_mode = True
    update_environment()
    assert os.environ.get("PGZERO_MODE", "") == "auto"

# Generated at 2022-06-22 03:02:49.695999
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    os.environ["PGZERO_MODE"] = str(get_workbench().get_option(_OPTION_NAME))
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    os.environ["PGZERO_MODE"] = str(get_workbench().get_option(_OPTION_NAME))
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 03:03:01.975113
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import workbench, tktextext
    from thonny.plugins.run_pgzero_mode import load_plugin
    from unittest.mock import Mock
    import os

    mw = Mock()
    mw.add_command = Mock()
    mw.set_default = Mock()
    mw.get_variable = Mock()
    mw.set_variable = Mock()
    mw.get_option = Mock()
    mw.in_simple_mode = Mock()
    mw.get_option.return_value = False
    mw.in_simple_mode.return_value = False
    mw.get_variable.__getitem__ = Mock(return_value="False")
    mw.set_variable.__setitem__ = Mock()


# Generated at 2022-06-22 03:03:12.421815
# Unit test for function update_environment
def test_update_environment():
    import os

    get_workbench().in_simple_mode = lambda: False

# Generated at 2022-06-22 03:03:20.907226
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default("run.pgzero_mode", False)
    get_workbench().set_default("run.switch_stdin", False)
    get_workbench().set_default("run.stop_before_exit", True)
    get_workbench().set_default("run.stop_after_exception", True)
    load_plugin()
    assert get_workbench().get_option("run.pgzero_mode") == False
    assert get_workbench().get_option("run.switch_stdin") == False
    assert get_workbench().get_option("run.stop_before_exit") == True
    assert get_workbench().get_option("run.stop_after_exception") == True
    assert "PGZERO_MODE" in os.environ

# Generated at 2022-06-22 03:03:29.516369
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    wb.set_simple_mode(True)
    update_environment()
    assert wb.in_simple_mode()

    wb.set_simple_mode(False)
    # 1. set pgzero mode to false
    wb.set_option(_OPTION_NAME, False)
    update_environment()
    assert not wb.in_simple_mode()
    # 2. set pgzero mode to true
    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert not wb.in_simple_mode()

# Generated at 2022-06-22 03:03:32.137489
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, True)
    load_plugin()

# Generated at 2022-06-22 03:03:42.905554
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == True
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == False

# Generated at 2022-06-22 03:03:48.313650
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True


# Generated at 2022-06-22 03:03:57.799470
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench

    # Test command
    get_workbench().add_command_debugger = MagicMock()
    load_plugin()
    get_workbench().add_command_debugger.assert_called_with(
        "toggle_pgzero_mode",
        "run",
        "Pygame Zero mode",
        "toggle_variable",
        flag_name="run.pgzero_mode",
        group=40,
        default_sequence="<Control-F8>",
    )

    # Test option
    workbench = get_workbench()
    workbench.set_option = MagicMock()
    load_plugin()
    workbench.set_option.assert_called_with("run.pgzero_mode", False)

    # Test update env
    workbench = get_workbench()


# Generated at 2022-06-22 03:04:01.284123
# Unit test for function toggle_variable
def test_toggle_variable():
    variable = get_workbench().get_variable(_OPTION_NAME)
    assert variable.get() == False
    toggle_variable()
    assert variable.get() == True

# Generated at 2022-06-22 03:04:07.392731
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"
    get_workbench().set_option(_OPTION_NAME, "auto")
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 03:04:13.169264
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-22 03:04:15.766929
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench
    from thonny.misc_utils import running_on_windows
    workbench = get_workbench()
    workbench.set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    workbench.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    workbench.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 03:04:22.265181
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import MagicMock

    wb = MagicMock()
    f1 = MagicMock()
    f2 = MagicMock()
    f3 = MagicMock()
    f4 = MagicMock()

    wb.set_default = f1
    wb.add_command = f2
    wb.in_simple_mode = f3
    wb.get_option = f4

    load_plugin()
    wb.set_default.assert_called_once_with(_OPTION_NAME, False)
    assert f1.call_count == 1
    assert f2.call_count == 1
    assert f3.call_count == 0
    assert f4.call_count == 0

# Generated at 2022-06-22 03:04:27.821509
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    assert wb.get_option(_OPTION_NAME) == False
    
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 03:04:33.553086
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) is True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) is False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) is True

# Generated at 2022-06-22 03:04:50.974169
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    assert not wb.get_option(_OPTION_NAME)

    load_plugin()
    assert wb.get_option(_OPTION_NAME)
    com_list = list(wb.get_commands())
    assert {
        "command_id": "toggle_pgzero_mode",
        "name": "toggle pgzero mode",
        "label": "Pygame Zero mode",
        "group": 40,
    } in com_list

    assert os.environ["PGZERO_MODE"] == "0"
    wb.reset_commands()

# Generated at 2022-06-22 03:04:59.559184
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    load_plugin()
    plugin = wb.get_plugin("thonny.plugins.pgzero")
    assert wb.get_variable("run.pgzero_mode").get() == False
    assert wb.get_option("run.pgzero_mode") == False
    assert "PGZERO_MODE" in os.environ
    assert os.environ["PGZERO_MODE"] == "0"


if __name__ == "__main__":
    print("Testing: " + __file__)
    test_load_plugin()
    print("Done.")

# Generated at 2022-06-22 03:05:11.263335
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock
    
    MockTk = Mock()
    MockTk.BooleanVar = lambda: Mock()
    MockView = Mock()
    MockView.in_simple_mode = lambda: False
    
    wb = Mock()
    wb.get_variable = Mock()
    wb.set_default = Mock()
    wb.get_option = Mock()
    wb.get_variable.return_value = Mock()
    wb.in_simple_mode = Mock()
    wb.in_simple_mode.return_value = False
    wb.get_view = lambda: MockView
    
    get_workbench = Mock()
    get_workbench.return_value = wb
    
    old_add_command = wb.add_command

# Generated at 2022-06-22 03:05:22.757269
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.plugins.pgzero_mode import load_plugin
    from unittest.mock import Mock

    the_workbench = Workbench()
    the_workbench.create()

    mock_tk_bind = Mock()
    mock_messagebox = Mock()

    the_workbench.bind = mock_tk_bind
    the_workbench.get_variable = lambda name: Mock(get=lambda: True, set=lambda val: None)
    the_workbench.create_variables_checkbutton = lambda **args: None
    the_workbench.add_command = lambda *args, **kwargs: None

    load_plugin(the_workbench)
    
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 03:05:27.437249
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench
    from thonny.workbench import Workbench

    workbench = Workbench()
    workbench.set_default(_OPTION_NAME, True)
    update_environment()
    assert os.getenv("PGZERO_MODE") == "True"



# Generated at 2022-06-22 03:05:32.272876
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    os.environ["PGZERO_MODE"] = str(get_workbench().get_option(_OPTION_NAME))


# Generated at 2022-06-22 03:05:41.559788
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"
    
if __name__ == "__main__":
    test_load_plugin()
    print("Everything passed")

# Generated at 2022-06-22 03:05:44.479579
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False



# Generated at 2022-06-22 03:05:48.828490
# Unit test for function toggle_variable
def test_toggle_variable():
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_default(_OPTION_NAME, True)
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 03:06:00.919063
# Unit test for function update_environment
def test_update_environment():
    workbench = get_workbench()
    assert not workbench.in_simple_mode()
    assert not workbench.get_option(_OPTION_NAME)
    update_environment()
    assert os.environ.get("PGZERO_MODE", "") == "False"
    
    workbench.set_option_by_name(_OPTION_NAME, True)
    update_environment()
    assert os.environ.get("PGZERO_MODE", "") == "True"
    
    workbench.set_simple_mode()
    workbench.set_option_by_name(_OPTION_NAME, False)
    update_environment()
    assert os.environ.get("PGZERO_MODE", "") == "auto"
    
    workbench.set_option_by_name(_OPTION_NAME, True)

# Generated at 2022-06-22 03:06:27.436058
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_variable(_OPTION_NAME, True)
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME) == True

# Generated at 2022-06-22 03:06:31.031298
# Unit test for function toggle_variable
def test_toggle_variable(): 
    get_workbench().set_option("run.pgzero_mode", False)
    toggle_variable()
    assert get_workbench().get_option("run.pgzero_mode") == True
    toggle_variable()
    assert get_workbench().get_option("run.pgzero_mode") == False
    

# Generated at 2022-06-22 03:06:42.240104
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import patch
    from thonny import get_workbench

    get_workbench().set_default(_OPTION_NAME, False)
    assert os.environ["PGZERO_MODE"] != "True"

    get_workbench().set_option(_OPTION_NAME, True)
    assert os.environ["PGZERO_MODE"] == "True"

    with patch.dict(os.environ, {"PGZERO_MODE": "False"}):
        get_workbench().set_option(_OPTION_NAME, False)
        assert os.environ["PGZERO_MODE"] == "False"

        get_workbench().set_option(_OPTION_NAME, True)
        assert os.environ["PGZERO_MODE"] == "True"



# Generated at 2022-06-22 03:06:52.948403
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench

    wb = get_workbench()
    wb.set_simple_mode()
    assert os.environ["PGZERO_MODE"] == "auto"

    del os.environ["PGZERO_MODE"]
    assert "PGZERO_MODE" not in os.environ
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    del os.environ["PGZERO_MODE"]
    wb.set_normal_mode()
    assert os.environ.get("PGZERO_MODE") is None

    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"


# Generated at 2022-06-22 03:06:58.148172
# Unit test for function toggle_variable
def test_toggle_variable():
    test = os.environ.get("PGZERO_MODE")
    try:
        test1 = get_workbench().in_simple_mode()
    except AttributeError:
        test1 = False
    try:
        test2 = get_workbench().get_option(_OPTION_NAME)
    except AttributeError:
        test2 = False
    assert test == "auto", test1 == test2

# Generated at 2022-06-22 03:07:08.548348
# Unit test for function load_plugin
def test_load_plugin():
    # pylint: disable=import-outside-toplevel
    import sys
    from thonny.workbench import Workbench
    # pylint: disable=protected-access
    wb = Workbench()
    wb._load_plugins()
    from thonny.plugins.pgzero_mode import _OPTION_NAME

    assert _OPTION_NAME in wb.get_option_names()
    assert wb.get_option(_OPTION_NAME) == False
    assert "PGZERO_MODE" in os.environ
    assert os.environ["PGZERO_MODE"] == "False"

    wb.set_option(_OPTION_NAME, True)
    assert wb.get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"


# Generated at 2022-06-22 03:07:11.629198
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False


# Generated at 2022-06-22 03:07:23.040416
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    get_workbench().set_default(_OPTION_NAME, False)
    assert len(wb.get_commands()) == 0 # no commands before plugin load
    load_plugin()
    assert len(wb.get_commands()) == 1 # 1 new command after plugin load
    assert wb.get_option(_OPTION_NAME) == False
    wb.set_option(_OPTION_NAME, True)
    assert wb.get_option(_OPTION_NAME) == True
    wb.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    wb.set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 03:07:28.179613
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, True)
    assert get_workbench().get_option(_OPTION_NAME) is True
    load_plugin()

    assert "PGZERO_MODE" in os.environ
    assert os.environ["PGZERO_MODE"] == "True"



# Generated at 2022-06-22 03:07:29.813656
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()

# Generated at 2022-06-22 03:08:01.933070
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench, get_runner

    wb = get_workbench()
    old_simple_mode = wb.in_simple_mode()
    get_runner().process_vars["PGZERO_MODE"] = None

# Generated at 2022-06-22 03:08:10.300285
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().set_option(_OPTION_NAME, True)
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_option(_OPTION_NAME, False)
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().in_simple_mode = lambda : True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 03:08:19.902163
# Unit test for function load_plugin
def test_load_plugin():
    assert "PGZERO_MODE" not in os.environ
    try:
        wb = get_workbench()
        wb.set_simple_mode(True)
        load_plugin()
        assert get_workbench().get_option(_OPTION_NAME) is False
        assert os.environ["PGZERO_MODE"] == "auto"
        wb.set_simple_mode(False)
        toggle_variable()
        assert os.environ["PGZERO_MODE"] == "True"
        toggle_variable()
        assert os.environ["PGZERO_MODE"] == "False"
    finally:
        if "PGZERO_MODE" in os.environ:
            del os.environ["PGZERO_MODE"]

# Generated at 2022-06-22 03:08:31.052644
# Unit test for function update_environment
def test_update_environment():
    from thonny.misc_utils import running_on_mac_os
    from unittest import mock
    from thonny.workbench import Workbench
    from thonny import get_workbench

    old_workbench = get_workbench()

# Generated at 2022-06-22 03:08:38.721099
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock
    get_workbench = Mock()
    get_workbench.set_default.return_value = None
    get_workbench.add_command.return_value = None
    get_workbench.get_variable.return_value = Mock()
    get_workbench.get_variable.return_value.set = Mock()
    get_workbench.get_variable.return_value.get.return_value = None

    load_plugin()
    get_workbench.set_default.assert_called_once()
    get_workbench.add_command.assert_called_once()


if __name__ == "__main__":
    test_load_plugin()

# Generated at 2022-06-22 03:08:48.007886
# Unit test for function load_plugin
def test_load_plugin():
    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()
    assert not get_workbench().get_option(_OPTION_NAME)
    assert os.environ.get("PGZERO_MODE") == "auto"
    
    wb.set_default(_OPTION_NAME, True)
    update_environment()
    assert get_workbench().get_option(_OPTION_NAME)
    assert os.environ.get("PGZERO_MODE") == "True"
    
    wb.in_simple_

# Generated at 2022-06-22 03:08:55.653355
# Unit test for function load_plugin
def test_load_plugin():
    path = get_workbench().get_option("path.python")
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 03:09:02.952884
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock
    from thonny.workbench import Workbench
    wb = Workbench()
    wb._get_variable = Mock(return_value=False)
    load_plugin()
    wb.add_command.assert_called_with(
        "toggle_pgzero_mode",
        "run",
        "Pygame Zero mode",
        toggle_variable,
        flag_name="run.pgzero_mode",
        group=40,
    )



# Generated at 2022-06-22 03:09:13.090846
# Unit test for function load_plugin
def test_load_plugin():
    from unittest import mock
    from thonny.globals import get_workbench
    from thonny.plugins.run import pgzero_support
    
    workbench = get_workbench()
    # Clear the commands
    workbench.commands.clear()
    # Mock the right side of the update_environment function
    with mock.patch.dict(os.environ, {'PGZERO_MODE': 'auto'}):
        pgzero_support.load_plugin()
        assert workbench.commands.get('toggle_pgzero_mode') != None
        assert workbench.commands.get('toggle_pgzero_mode').flag_name == _OPTION_NAME


# Generated at 2022-06-22 03:09:14.946462
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()

# Generated at 2022-06-22 03:10:15.153960
# Unit test for function update_environment
def test_update_environment():
    from thonny.globals import get_workbench
    if "PGZERO_MODE" in os.environ:
        del os.environ["PGZERO_MODE"]
    get_workbench().set_simple_mode(True)
    assert get_workbench().get_option(_OPTION_NAME) == False
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 03:10:18.266374
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-22 03:10:29.837186
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default("run.pgzero_mode", False)
    get_workbench().in_simple_mode()
    os.environ["PGZERO_MODE"] = "auto"
    get_workbench().set_default("run.pgzero_mode", True)
    get_workbench().set_option(_OPTION_NAME, True)
    get_workbench().get_variable(_OPTION_NAME)
    get_workbench().get_option(_OPTION_NAME)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )

# Generated at 2022-06-22 03:10:33.044893
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    var = wb.get_variable(_OPTION_NAME)
    assert var.get() == False
    toggle_variable()
    assert var.get() == True
    toggle_variable()
    assert var.get() == False

# Generated at 2022-06-22 03:10:38.223346
# Unit test for function toggle_variable
def test_toggle_variable():
    # if variable disabled, then set enabled
    get_workbench().set_variable(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME) == True
    # if variable enabled, then set disabled
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME) == False


# Generated at 2022-06-22 03:10:45.793683
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import MagicMock

    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().add_command = MagicMock()

    load_plugin()

    get_workbench().add_command.assert_called_once_with(
        "toggle_pgzero_mode",
        "run",
        "Pygame Zero mode",
        toggle_variable,
        group=40,
        flag_name=_OPTION_NAME,
    )
    assert os.environ["PGZERO_MODE"] == "False"



# Generated at 2022-06-22 03:10:47.687195
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-22 03:10:56.652407
# Unit test for function toggle_variable
def test_toggle_variable():
    from unittest import mock
    from thonny import get_frontend_python_executable

    def get_variable(name):
        class MockObject(object):
            def __init__(self):
                self.get = mock.Mock()

            def set(self, value):
                self.get.assert_not_called()
                self.get.return_value = value

        return MockObject()

    get_workbench().get_variable = mock.Mock(side_effect=get_variable)

    class MockOptions(object):
        def __init__(self):
            self.get = mock.Mock()

        def set(self, name, value):
            self.get.assert_not_called()
            self.get.return_value = value
