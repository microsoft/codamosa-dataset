

# Generated at 2022-06-22 03:00:29.322718
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)

    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    load_plugin()
    assert get_workbench().get_variable(_OPTION_NAME).get() == True
    assert os.environ["PGZERO_MODE"] == "True"

    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    assert os.environ["PGZERO_MODE"] == "False"

    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == True
    assert os.environ["PGZERO_MODE"] == "True"

if __name__ == "__main__":
    test_load_plugin()

# Generated at 2022-06-22 03:00:34.710927
# Unit test for function toggle_variable
def test_toggle_variable():
    update_environment()
    assert os.environ.get("PGZERO_MODE") == "False"
    toggle_variable()
    assert os.environ.get("PGZERO_MODE") == "True"
    toggle_variable()
    assert os.environ.get("PGZERO_MODE") == "False"



# Generated at 2022-06-22 03:00:46.688613
# Unit test for function update_environment
def test_update_environment():
    from thonny.globals import get_workbench
    from thonny import THONNY_USER_DIR
    import os

    get_workbench().set_simple_mode(True)
    update_environment()

    # create a fresh config file
    os.remove(THONNY_USER_DIR / "config-v2.json")

    # check default option value
    os.environ["PGZERO_MODE"] == "auto"

    get_workbench().set_simple_mode(False)
    update_environment()

    # check default option value
    os.environ["PGZERO_MODE"] == "False"

    # chage option value
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()

    # check option value

# Generated at 2022-06-22 03:00:50.489782
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()
    return get_workbench().get_option(_OPTION_NAME)

# Generated at 2022-06-22 03:00:56.562613
# Unit test for function toggle_variable
def test_toggle_variable():
    os.environ["PGZERO_MODE"] = "True"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    assert get_workbench().get_option(_OPTION_NAME) == True

# Generated at 2022-06-22 03:01:05.449359
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"

    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"

# Generated at 2022-06-22 03:01:16.623200
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock
    from thonny.workbench import Workbench

    mock_app=Mock(spec=Workbench)
    mock_app.get_variable.return_value=False
    mock_app.in_simple_mode.return_value=False
    mock_app.get_option.return_value=False

    mock_app.set_default=Mock(return_value=None)
    mock_app.add_command=Mock(return_value=None)

    get_workbench=Mock(spec=Workbench)
    get_workbench.return_value=mock_app

    load_plugin()
    mock_app.get_variable.assert_called_once()
    mock_app.in_simple_mode.assert_called_once()
    mock_app.set_

# Generated at 2022-06-22 03:01:21.241585
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import workbench

    workbench.clear_test_data()
    load_plugin()
    assert workbench.get_option(_OPTION_NAME) is False

    workbench.get_option(_OPTION_NAME).set(True)
    assert workbench.get_option(_OPTION_NAME) is True

    workbench.clear_test_data()



# Generated at 2022-06-22 03:01:33.932107
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_simple_mode(False)
    os.environ["PGZERO_MODE"] = "False"
    toggle_variable()
    assert (
        get_workbench().get_option(_OPTION_NAME) == True
    ), "Failed to toggle middle mode to Pygame Zero mode"
    assert (
        os.environ["PGZERO_MODE"] == "True"
    ), "Failed to toggle middle mode to Pygame Zero mode"
    get_workbench().set_simple_mode(True)
    os.environ["PGZERO_MODE"] = "False"
    toggle_variable()
    assert (
        get_workbench().get_option(_OPTION_NAME) == False
    ), "Failed to toggle simple mode to normal"

# Generated at 2022-06-22 03:01:41.404436
# Unit test for function load_plugin
def test_load_plugin():
    wb = Workbench()
    wb.create()
    load_plugin()
    assert wb.get_option(_OPTION_NAME)
    assert "PGZERO_MODE" in os.environ and os.environ["PGZERO_MODE"] == "True"
    wb.set_option(_OPTION_NAME, False)
    assert wb.get_option(_OPTION_NAME) is False
    assert "PGZERO_MODE" in os.environ and os.environ["PGZERO_MODE"] == "False"
    # When in simple mode, the value is always True
    wb.in_simple_mode = lambda: True
    assert "PGZERO_MODE" in os.environ and os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 03:01:56.263103
# Unit test for function update_environment
def test_update_environment():
    workbench = get_workbench()
    var = workbench.get_option(_OPTION_NAME)
    var.set(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    var = workbench.get_option(_OPTION_NAME)
    var.set(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    workbench.in_simple_mode = lambda : True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    workbench.in_simple_mode = lambda : False
    var = workbench.get_option(_OPTION_NAME)
    var.set(True)
    update_environment()

# Generated at 2022-06-22 03:02:04.544543
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench, running
    from thonny.ui_utils import ask_bool
    from thonny.shell import ShellTextWidget
    from thonny.plugins.run import _get_run_environment
    from unittest.mock import Mock
    get_workbench().set_default(_OPTION_NAME, False) 
    # test disabled in simple mode with no toggling
    assert get_workbench().in_simple_mode() == False
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    # test disabled in simple mode with toggling
    get_workbench().toggle_simple_mode()
    assert get_workbench().in_simple_mode() == True
    update_environment()
    assert os.environ["PGZERO_MODE"]

# Generated at 2022-06-22 03:02:08.579673
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default("run.pgzero_mode", False)
    get_workbench().delete_command("toggle_pgzero_mode")
    load_plugin()
    assert get_workbench().get_option("run.pgzero_mode") == False
    assert "PGZERO_MODE" in os.environ
    assert os.environ["PGZERO_MODE"] == "False"
    assert "toggle_pgzero_mode" in get_workbench().commands
    get_workbench().set_option("run.pgzero_mode", True)
    assert get_workbench().get_option("run.pgzero_mode") == True
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().in_simple_mode = True
    update_environment()
    assert os

# Generated at 2022-06-22 03:02:15.833122
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    assert 'PGZERO_MODE' not in os.environ
    get_workbench().set_simple_mode(True)
    assert 'PGZERO_MODE' not in os.environ
    get_workbench().set_simple_mode(False)
    assert 'PGZERO_MODE' in os.environ and os.environ['PGZERO_MODE'] == "True"
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert get_workbench().get_variable(_OPTION_NAME).get

# Generated at 2022-06-22 03:02:21.818076
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = "not-auto"

# Generated at 2022-06-22 03:02:24.269827
# Unit test for function update_environment
def test_update_environment():
    del os.environ['PGZERO_MODE']
    update_environment()
    assert os.environ['PGZERO_MODE'] == 'False'

# Generated at 2022-06-22 03:02:28.310939
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = "True"
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"



# Generated at 2022-06-22 03:02:31.304359
# Unit test for function toggle_variable
def test_toggle_variable():
    # Test when the variable is on
    assert toggle_variable == True
    # Test when the variable is off
    assert toggle_variable == False
    # Test that the environment is updating
    assert update_environment

# Generated at 2022-06-22 03:02:34.720862
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True



# Generated at 2022-06-22 03:02:38.542634
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    orig_val = wb.get_option(_OPTION_NAME)
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) != orig_val
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == orig_val



# Generated at 2022-06-22 03:02:53.176406
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench
    from thonny.languages import tr
    from thonny.common import InlineCommand
    from unittest.mock import patch
    from thonny.tktextext import TextFrame
    from thonny.ui_utils import CommonRadioBtn

    get_workbench().in_simple_mode = lambda: True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().in_simple_mode = lambda: False
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"


# Generated at 2022-06-22 03:02:58.055575
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 03:02:58.862999
# Unit test for function toggle_variable

# Generated at 2022-06-22 03:03:11.580743
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.ui_utils import toggle_checkbox

    workbench = Workbench()
    workbench._unregister_core_commands()
    load_plugin()
    
    # Check that the menu item is created
    assert toggle_checkbox("View", "Pygame Zero mode", False)

    # Check that the env var is set to "False"
    assert os.environ["PGZERO_MODE"] == "False"

    # Check that the environment variable is updated
    toggle_checkbox("View", "Pygame Zero mode", True)
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_checkbox("View", "Pygame Zero mode", False)
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 03:03:16.959255
# Unit test for function toggle_variable
def test_toggle_variable():
    # Call function
    toggle_variable()
    # Check if variable is set
    var = get_workbench().get_variable(_OPTION_NAME)
    assert var.get()
    # Call function
    toggle_variable()
    # Check if variable is unset
    var = get_workbench().get_variable(_OPTION_NAME)
    assert not var.get()


# Generated at 2022-06-22 03:03:27.824450
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.in_simple_mode = lambda: False
    wb.get_option = lambda name: False
    var = wb.get_variable(_OPTION_NAME)
    var.set(True)
    load_plugin()
    assert var.get() is False
    assert wb.get_variable(_OPTION_NAME).get() is False
    assert os.environ["PGZERO_MODE"] == "False"

    wb.get_option = lambda name: True
    var = wb.get_variable(_OPTION_NAME)
    var.set(False)
    load_plugin()
    assert wb.get_variable(_OPTION_NAME).get() is True
    assert os.environ["PGZERO_MODE"] == "True"

    wb.in_

# Generated at 2022-06-22 03:03:39.292907
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    assert "PGZERO_MODE" not in os.environ
    
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    
    wb.set_option(_OPTION_NAME, True)
    
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    
    wb.enter_simple_mode()
    
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    
    wb.exit_simple_mode()
    wb.set_option(_OPTION_NAME, False)
    del os.environ["PGZERO_MODE"]
    
    update_

# Generated at 2022-06-22 03:03:46.330651
# Unit test for function update_environment
def test_update_environment():
    os.environ.pop('PGZERO_MODE', None)
    with get_workbench():
        get_workbench().set_option(_OPTION_NAME, True)
        update_environment()
        assert os.environ["PGZERO_MODE"] == "True"
        get_workbench().set_option(_OPTION_NAME, False)
        update_environment()
        assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 03:03:52.263445
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    update_environment()
    assert not os.environ["PGZERO_MODE"]

    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"]

# Generated at 2022-06-22 03:03:56.953326
# Unit test for function toggle_variable
def test_toggle_variable():
    # Test initial state
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == True

    # Test second toggle
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == False

    # Test in simple mode
    get_workbench().simple_mode = True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 03:04:19.517122
# Unit test for function update_environment
def test_update_environment():
    # This group of tests will check to make sure that the environment
    # variable is set correctly for all modes
    # Simple mode
    get_workbench().set_simple_mode(True)
    # get_workbench intitialized to simple mode in __init__.py
    # get_workbench().set_simple_mode(True) will flip it back to simple mode
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    # Normal mode
    get_workbench().set_simple_mode(False)
    get_workbench().set_option("run.pgzero_mode", False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == str(False)
    # Normal mode - with pgzero enabled

# Generated at 2022-06-22 03:04:26.690637
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.workbench import Workbench
    Workbench.get_instance().set_variable("run.pgzero_mode", True)

    # check that the PGZERO has the value 1
    assert os.environ["PGZERO_MODE"] == "1"

    # call the toggle_variable
    toggle_variable()

    # check that the PGZERO_MODE has the value 0
    assert os.environ["PGZERO_MODE"] == "0"

# Generated at 2022-06-22 03:04:29.973579
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    assert os.environ["PGZERO_MODE"] == "False"


load_plugin()

# Generated at 2022-06-22 03:04:32.056636
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.test_utils import check_toggle_variable

# Generated at 2022-06-22 03:04:44.073553
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import MagicMock
    from thonny.plugins.run import _OPTION_NAME

    get_workbench = MagicMock()
    get_workbench.return_value.get_variable.return_value.get.return_value = True
    get_workbench.return_value.in_simple_mode.return_value = True

    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    assert get_workbench.called
    assert get_workbench.return_value.in_simple_mode.called
    assert get_workbench.return_value.get_variable.called

    get_workbench.reset_mock()

    get_workbench.return_value.in_simple_mode.return_value = False
    update_environment()

# Generated at 2022-06-22 03:04:49.578211
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    assert get_workbench().get_option(_OPTION_NAME) == False
    load_plugin()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 03:04:54.464855
# Unit test for function update_environment
def test_update_environment():
    # Check if update_environment command works
    os.environ["PGZERO_MODE"] = "auto"
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 03:05:00.796512
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = "True"
    assert os.environ["PGZERO_MODE"] == "True"
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 03:05:07.394624
# Unit test for function update_environment
def test_update_environment():
    b = get_workbench()
    b.set_simple_mode(False)
    b.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"]=="True"
    
    b.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"]=="auto"

# Generated at 2022-06-22 03:05:16.872306
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import Mock
    from unittest.mock import patch
    from thonny.globals import get_shell
    from thonny.shell import Shell
    from thonny.workbench import Workbench

    mock_workbench = Mock(spec=Workbench)
    mock_workbench.in_simple_mode.return_value = True

    mock_shell = Mock(spec=Shell)

    with patch("thonny.globals.get_workbench", return_value=mock_workbench):
        # Simple mode
        update_environment()
        mock_workbench.set_default.assert_any_call(_OPTION_NAME, False)
        assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 03:05:48.702174
# Unit test for function update_environment
def test_update_environment():
    # For this test, we change the workbench's simple mode to
    # True so that we can test the case where we are in simple mode
    # For simplicity we also set the OS environ to an empty dict
    get_workbench().set_option("view.simple_mode", True)
    os.environ = {}

    # Run the function so that it puts PGZERO_MODE in os.environ
    update_environment()

    # Check that PGZERO_MODE was set to auto
    # Then reset workbench's simple mode to False so it doesn't effect other tests
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_option("view.simple_mode", False)

    # Repeat the same test, but this time in the case where we are
    # not in simple mode. For this test

# Generated at 2022-06-22 03:05:52.334139
# Unit test for function update_environment
def test_update_environment():
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 03:06:00.963711
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = "auto"
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == 'True'

    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == 'False'

    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == 'auto'

# Generated at 2022-06-22 03:06:05.577224
# Unit test for function load_plugin
def test_load_plugin():
    # Plugin unloaded
    assert "toggle_pgzero_mode" not in get_workbench().commands
    load_plugin()
    # Plugin loaded
    assert "toggle_pgzero_mode" in get_workbench().commands
    # Command group created
    assert "run" in get_workbench().categories

# Generated at 2022-06-22 03:06:17.149784
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.misc_utils import running_on_mac_os, running_on_windows
    from thonny import get_workbench
    from thonny.languages import tr
    assert not get_workbench().in_simple_mode()
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert get_workbench().get_command("toggle_pgzero_mode")
    assert get_workbench().get_command("toggle_pgzero_mode").group == 40
    assert get_workbench().get_command("toggle_pgzero_mode").label == tr("Pygame Zero mode")
    assert running_on_windows() or os.environ["PGZERO_MODE"] == "False"
    toggle_variable()

# Generated at 2022-06-22 03:06:21.850085
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().set_option(_OPTION_NAME, False)
    assert os.environ["PGZERO_MODE"] == "auto"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 03:06:32.080480
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from unittest.mock import Mock

    workbench = Workbench(Mock())
    workbench.set_default(_OPTION_NAME, False)
    assert os.environ.get("PGZERO_MODE") != "auto"
    assert os.environ.get("PGZERO_MODE") != "True"

    update_environment()
    assert os.environ.get("PGZERO_MODE") == "False"

    workbench.set_simple_mode(True)
    update_environment()
    assert os.environ.get("PGZERO_MODE") == "auto"

    workbench.set_simple_mode(False)
    workbench.set_option(_OPTION_NAME, True)
    update_environment()

# Generated at 2022-06-22 03:06:42.896796
# Unit test for function load_plugin
def test_load_plugin():
    import unittest.mock
    wb = unittest.mock.Mock()
    wb.get_variable.return_value = True
    wb.in_simple_mode.return_value = False
    wb.set_default.return_value = False
    wb.add_command.return_value = False

    globals()["get_workbench"] = unittest.mock.Mock()
    globals()["get_workbench"].return_value = wb

    load_plugin()

    wb.set_default.assert_called_once_with(
        _OPTION_NAME,
        False
    )

    assert(wb.get_variable(_OPTION_NAME) == True)


# Generated at 2022-06-22 03:06:47.951262
# Unit test for function update_environment
def test_update_environment():
    os.environ.pop("PGZERO_MODE", None)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 03:06:52.828260
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock

    wb = Mock()
    
    wb.get_option = Mock(return_value=True)
    wb.set_option = Mock(return_value=True)

    load_plugin()

    wb.set_default.assert_called()    
    wb.add_command.assert_called()

# Generated at 2022-06-22 03:07:45.147771
# Unit test for function toggle_variable
def test_toggle_variable():
    # initializes toggle_variable() with the option name
    # execute the command and check the result
    get_workbench().get_option(_OPTION_NAME, True)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME, True) == False

    # execute the command again and check the result
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME, True) == True

# Generated at 2022-06-22 03:07:50.101989
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.globals import get_workbench

    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-22 03:08:01.931743
# Unit test for function load_plugin
def test_load_plugin():
    # normal load
    from unittest.mock import Mock
    from thonny.workbench import Workbench
    mw = Mock()
    wb = Workbench(mw)
    load_plugin()
    # test check add_command and set_default_option
    mw.add_command.assert_called_with(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    mw.set_default.assert_called_with(_OPTION_NAME, False)
    # test check update_environment
    assert os.environ["PGZERO_MODE"] == "False"


if __name__ == "__main__":
    pass

# Generated at 2022-06-22 03:08:10.932894
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench, Tester

    import thonny.plugins.pgzero_mode

    wb = get_workbench()
    wb.set_simple_mode(True)
    thonny.plugins.pgzero_mode.load_plugin()
    Tester(wb).assertIn((thonny.plugins.pgzero_mode.toggle_variable, "F5"), wb.get_bindings_for("F5"))
    thonny.plugins.pgzero_mode.update_environment()
    Tester(wb).assertEqual(os.environ["PGZERO_MODE"], "True")

# Generated at 2022-06-22 03:08:15.852959
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_option(_OPTION_NAME, True)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True


# Generated at 2022-06-22 03:08:24.058599
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.plugins.run.run_configuration import run_in_debug_mode
    from thonny.ui_utils import toggle_checkbox_value
    get_workbench().set_default(_OPTION_NAME, False)
    run_in_debug_mode(True)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True

    get_workbench().set_default(_OPTION_NAME, False)
    run_in_debug_mode(False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False


# Generated at 2022-06-22 03:08:27.367830
# Unit test for function toggle_variable
def test_toggle_variable():
    workbench = get_workbench()
    var = workbench.get_variable(_OPTION_NAME)
    assert var.get() == False
    toggle_variable()
    assert var.get() == True

# Generated at 2022-06-22 03:08:36.985958
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    assert "PGZERO_MODE" in os.environ
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == True
    assert "PGZERO_MODE" in os.environ
    assert os.environ["PGZERO_MODE"] == "True"
    
    # reset back to normal state
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 03:08:38.885821
# Unit test for function toggle_variable
def test_toggle_variable():
    # start environment in pgzero mode
    # checks if pgzero_mode optio is true or false
    pass

# Generated at 2022-06-22 03:08:48.151347
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny import get_workbench
    from thonny.misc_utils import running_on_mac_os
    from test.config_helper import set_option

    set_option(_OPTION_NAME, False)

    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True

    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

    set_option(_OPTION_NAME, True)
    assert get_workbench().get_option(_OPTION_NAME) == True

    get_workbench().set_simple_mode(True)
    assert os.environ["PGZERO_MODE"] == "auto"

    if running_on_mac_os():
        toggle_variable()