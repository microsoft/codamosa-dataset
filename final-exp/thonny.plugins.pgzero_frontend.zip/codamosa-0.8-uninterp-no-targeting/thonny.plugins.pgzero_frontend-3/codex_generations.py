

# Generated at 2022-06-22 03:00:43.782423
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()

# Generated at 2022-06-22 03:00:49.466554
# Unit test for function load_plugin
def test_load_plugin():
    # Setup
    get_workbench().set_default(_OPTION_NAME, False)
    # Exercise
    load_plugin()
    # Verify
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "0"



# Generated at 2022-06-22 03:00:55.289442
# Unit test for function update_environment
def test_update_environment():
    from thonny.testutil import run_in_fresh_virtual_environment

    run_in_fresh_virtual_environment("""
    from thonny.plugins.pgzero_mode import update_environment
    update_environment()
    print("PGZERO_MODE" in os.environ)
    """)

# Generated at 2022-06-22 03:01:03.582399
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    var = wb.get_variable(_OPTION_NAME)
    pm = wb.get_plugin_manager()
    pm.activate_plugin("run")
    pm.activate_plugin("pgzero_mode")
    var.set(True)
    assert var.get()
    assert wb.get_option(_OPTION_NAME)
    assert os.environ["PGZERO_MODE"] == "True"
    pm.deactivate_plugin("pgzero_mode")
    var.set(False)
    assert var.get() == False
    assert wb.get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"
    pm.deactivate_plugin("run")

# Generated at 2022-06-22 03:01:14.104093
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny import get_workbench
    from thonny.testing import run_isolated
    from unittest.mock import Mock
    from unittest import mock
    from thonny.plugins.run import run
    from thonny.languages import tr
    import os
    import sys
    import json

    with run_isolated():
        run.load_plugin()
        var = get_workbench().get_variable(_OPTION_NAME)
        var.set(True)
        update_environment()
        assert (os.environ["PGZERO_MODE"] == "True")
        toggle_variable()
        assert (os.environ["PGZERO_MODE"] == "False")
        var.set(False)
        update_environment()

# Generated at 2022-06-22 03:01:25.386109
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert "PGZERO_MODE" in os.environ
    os.environ.pop("PGZERO_MODE")
    assert "PGZERO_MODE" not in os.environ
    load_plugin()
    assert "PGZERO_MODE" in os.environ
    assert get_workbench().get_option(_OPTION_NAME) == False

    os.environ.pop("PGZERO_MODE")
    assert "PGZERO_MODE" not in os.environ
    get_workbench().set_simple_mode(True)
    load_plugin()
    assert "PGZERO_MODE" not in os.environ
    get_workbench().set_

# Generated at 2022-06-22 03:01:37.432309
# Unit test for function load_plugin
def test_load_plugin():
    b = Tk()
    w = Workbench(master=b)
    w.create_default_layout()
    w.set_default(_OPTION_NAME, False)
    w.load_plugin(os.path.join(os.path.dirname(__file__)))
    assert len(w.commands["toggle_pgzero_mode"]) == 2


if __name__ == "__main__":
    import os.path
    from thonny.workbench import Workbench
    from tkinter import Tk

    b = Tk()
    w = Workbench(master=b)
    w.create_default_layout()
    w.create_debugger_pane()
    w.create_shell()
    w.load_plugin(os.path.join(os.path.dirname(__file__)))

# Generated at 2022-06-22 03:01:45.404992
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock

    wb = Mock(name="workbench")
    wb.set_default = Mock(name="set_default")
    wb.add_command = Mock(name="add_command")
    wb.in_simple_mode = Mock(name="in_simple_mode")
    wb.get_option = Mock(name="get_option")

    load_plugin()

    assert wb.set_default.call_count == 1
    assert wb.set_default.call_args_list == [((_OPTION_NAME, False),)]

    assert wb.add_command.call_count == 1

# Generated at 2022-06-22 03:01:52.402047
# Unit test for function update_environment
def test_update_environment():
    os.environ.pop("PGZERO_MODE", None)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    os.environ["PGZERO_MODE"] = "True"
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 03:02:01.369353
# Unit test for function toggle_variable
def test_toggle_variable():
    with tempfile.TemporaryDirectory() as tmpdir:
        workbench = workbench_fixture(tmpdir, ["thonny.plugins.run_pgzero_mode"])
        assert not workbench.get_option(_OPTION_NAME)
        assert os.environ.get("PGZERO_MODE") == "False"

        toggle_variable()
        assert workbench.get_option(_OPTION_NAME)
        assert os.environ.get("PGZERO_MODE") == "True"

        toggle_variable()
        assert not workbench.get_option(_OPTION_NAME)
        assert os.environ.get("PGZERO_MODE") == "False"

# Generated at 2022-06-22 03:02:14.292791
# Unit test for function update_environment
def test_update_environment():
    old_env = dict(os.environ)
    try:
        get_workbench().set_option(_OPTION_NAME, True)
        update_environment()
        assert os.environ["PGZERO_MODE"] == "True"

        get_workbench().set_option(_OPTION_NAME, False)
        update_environment()
        assert os.environ["PGZERO_MODE"] == "False"
    finally:
        old_env.pop("PGZERO_MODE", None)
        os.environ.clear()
        os.environ.update(old_env)

# Generated at 2022-06-22 03:02:18.002484
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()
    assert get_workbench().in_pgzero_mode() == True

    toggle_variable()
    assert get_workbench().in_pgzero_mode() == False

# Generated at 2022-06-22 03:02:23.494716
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == True
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == False

# Generated at 2022-06-22 03:02:28.461014
# Unit test for function toggle_variable
def test_toggle_variable():
    """Unit test for function toggle_variable."""

    pgz_mode = get_workbench().get_option(_OPTION_NAME)
    toggle_variable()

# Generated at 2022-06-22 03:02:37.812880
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default("run.pgzero_mode", False)
    load_plugin()
    assert get_workbench().get_variable("run.pgzero_mode").get() == False
    os.environ["PGZERO_MODE"] = "auto"
    assert os.environ.get("PGZERO_MODE") == "auto"
    toggle_variable()
    assert get_workbench().get_variable("run.pgzero_mode").get() == True
    assert os.environ.get("PGZERO_MODE") == "True"
    toggle_variable()
    assert get_workbench().get_variable("run.pgzero_mode").get() == False
    assert os.environ.get("PGZERO_MODE") == "False"
    update_environment()

# Generated at 2022-06-22 03:02:45.633148
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"


load_plugin()

# Generated at 2022-06-22 03:02:51.983932
# Unit test for function update_environment
def test_update_environment():
    import os

    wb = get_workbench()
    wb.set_simple_mode(True)
    update_environment()
    os.environ["PGZERO_MODE"] = "auto"

    wb.set_simple_mode(False)
    wb.set_option(_OPTION_NAME, True)
    update_environment()
    os.environ["PGZERO_MODE"] = "True"

    wb.set_option(_OPTION_NAME, False)
    update_environment()
    os.environ["PGZERO_MODE"] = "False"

# Generated at 2022-06-22 03:02:57.989057
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True


# Generated at 2022-06-22 03:03:08.698557
# Unit test for function update_environment
def test_update_environment():
    try:
        del os.environ["PGZERO_MODE"]
    except:
        pass

    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 03:03:13.816682
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()
    assert (
        get_workbench().get_variable(_OPTION_NAME).get() == True
    ), "Either unit test failed or code needs to be updated"
    toggle_variable()
    assert (
        get_workbench().get_variable(_OPTION_NAME).get() == False
    ), "Either unit test failed or code needs to be updated"



# Generated at 2022-06-22 03:03:27.679966
# Unit test for function toggle_variable
def test_toggle_variable():
    try:
        toggle_variable()
    except Exception:
        assert 0, "toggle_variable() failed"


# Generated at 2022-06-22 03:03:33.011256
# Unit test for function load_plugin
def test_load_plugin():
    assert get_workbench().get_option("run.pgzero_mode") == False
    if get_workbench().in_simple_mode():
        mode = "auto"
    else:
        mode = "False"
    assert os.environ["PGZERO_MODE"] == mode

# Generated at 2022-06-22 03:03:38.294075
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    
    wb.set_option(_OPTION_NAME, True)
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == False
    
    wb.set_option(_OPTION_NAME, False)
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == True

# Generated at 2022-06-22 03:03:49.859824
# Unit test for function update_environment
def test_update_environment():
    os.environ.pop("PGZERO_MODE", None)
    os.environ.pop("PGZERO_MODE", None)

    with get_workbench().config_writer() as conf:
        conf.set("run", _OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"

    with get_workbench().config_writer() as conf:
        conf.set("run", _OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"

    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"


# Generated at 2022-06-22 03:03:55.456465
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()
    get_workbench().get_option(_OPTION_NAME)

# Generated at 2022-06-22 03:04:07.054267
# Unit test for function toggle_variable
def test_toggle_variable():
    from unittest.mock import Mock

    get_workbench = Mock()

    class VariableMock:
        def __init__(self, value):
            self.value = value
            self.call_count = 0

        def get(self):
            return self.value

        def set(self, value):
            self.call_count += 1
            self.value = value

    get_workbench().get_variable.return_value = VariableMock(False)
    get_workbench().name = "Test"
    toggle_variable()
    assert get_workbench.get_variable().value
    assert get_workbench.get_variable().call_count == 2
    toggle_variable()
    assert not get_workbench.get_variable().value
    assert get_workbench.get_variable().call_count == 4
   

# Generated at 2022-06-22 03:04:12.809545
# Unit test for function toggle_variable
def test_toggle_variable():
    assert os.environ.get("PGZERO_MODE") is None
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 03:04:15.695599
# Unit test for function load_plugin
def test_load_plugin():
    # just to avoid NameError
    pass


if __name__ == "__main__":
    print(get_workbench().get_variable(_OPTION_NAME))

# Generated at 2022-06-22 03:04:27.198046
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default(
        _OPTION_NAME, False
    )  # it's not always False because other tests could have changed it
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().get_option(_OPTION_NAME).set(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"


# Generated at 2022-06-22 03:04:39.334834
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import MagicMock
    from thonny.misc_utils import ArgumentRecordingCommand

    wb = MagicMock()
    wb.get_variable.return_value.get.return_value = False

    def _get_variable(name):
        if name == _OPTION_NAME:
            return MagicMock()
        else:
            raise ValueError(name)

    wb.get_variable.side_effect = _get_variable

    load_plugin()
    wb.set_default.assert_called_once_with(_OPTION_NAME, False)
    wb.add_command.assert_called_once()
    add_command_args = wb.add_command.call_args[1]

# Generated at 2022-06-22 03:04:52.906678
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get()


if __name__ == "__main__":
    load_plugin()

# Generated at 2022-06-22 03:05:01.004493
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.workbench import Workbench
    from thonny.configuration import get_workbench
    from unittest.mock import MagicMock, patch

    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    get_workbench = MagicMock(return_value=wb)

    toggle_variable()

    assert wb.get_variable(_OPTION_NAME).get()

    toggle_variable()

    assert not wb.get_variable(_OPTION_NAME).get()


# Generated at 2022-06-22 03:05:12.388250
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import Mock

    get_workbench = Mock()
    get_workbench.in_simple_mode = Mock(return_value=False)
    get_workbench.get_option = Mock(return_value=False)
    get_workbench.set_default = Mock()

    globals()["get_workbench"] = get_workbench
    load_plugin()
    
    # Test for true
    get_workbench.get_option.return_value = True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    
    # Test for false
    get_workbench.get_option.return_value = False
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    
    # Test for in_

# Generated at 2022-06-22 03:05:14.204193
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench

    wb = Workb

# Generated at 2022-06-22 03:05:18.024333
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_simple_mode(False)
    var = get_workbench().get_variable(_OPTION_NAME)
    var.set(False)
    toggle_variable()
    assert var.get() == True
    toggle_variable()
    assert var.get() == False



# Generated at 2022-06-22 03:05:22.105478
# Unit test for function toggle_variable
def test_toggle_variable():
    set_pgzero_mode(False)
    toggle_variable()
    assert pgzero_mode()

    toggle_variable()
    assert not pgzero_mode()


# Generated at 2022-06-22 03:05:23.075726
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()


# Generated at 2022-06-22 03:05:32.334932
# Unit test for function update_environment
def test_update_environment():
    orig_value = os.environ.get("PGZERO_MODE")
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().in_simple_mode = lambda : True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    
    if orig_value is not None:
        os.environ["PGZERO_MODE"] = orig_value

# Generated at 2022-06-22 03:05:38.201793
# Unit test for function toggle_variable
def test_toggle_variable():
    try:
        del os.environ["PGZERO_MODE"]
    except:
        pass
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 03:05:46.037174
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = "auto"
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"
    get_workbench().in_simple_mode = True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 03:06:19.616392
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    assert wb.get_option(_OPTION_NAME) == False
    wb.add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    assert wb.get_option(_OPTION_NAME) == False
    os.environ["PGZERO_MODE"] = "auto"
    update_environment()
    assert wb.get_option(_OPTION_NAME) == False 
    wb.in_simple_mode = lambda : True
    update_environment()
    assert wb.get_option(_OPTION_NAME) == False 


# Generated at 2022-06-22 03:06:31.127608
# Unit test for function update_environment
def test_update_environment():
    class MockWorkbench:
        def __init__(self):
            self.simple_mode = False
        def in_simple_mode(self):
            return self.simple_mode
        def get_option(self, name):
            if name == _OPTION_NAME:
                return False
            assert False
    
    class MockOS:
        def __init__(self):
            self.my_environ = {}
        
        def environ(self):
            return self.my_environ
        
        def environ_setitem(self, name, value):
            self.my_environ[name] = value
        
        
    old_w = get_workbench()
    old_os = os

# Generated at 2022-06-22 03:06:37.681693
# Unit test for function toggle_variable
def test_toggle_variable():
    from unittest.mock import MagicMock
    from testing.virtual_io import VirtualIO
    from thonny import get_workbench

    toggle_variable()
    assert get_workbench().in_simple_mode() is False
    toggle_variable()
    assert get_workbench().in_simple_mode() is True
    toggle_variable()
    assert get_workbench().in_simple_mode() is False

# Generated at 2022-06-22 03:06:38.839962
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    if get_workbench().in_simple_mode():
        assert os.environ["PGZERO_MODE"] == "auto"
    else:
        assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 03:06:41.705070
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 03:06:46.754900
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_simple_mode(False)
    assert not get_workbench().get_option(_OPTION_NAME)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME)
    toggle_variable()
    assert not get_workbench().get_option(_OPTION_NAME)

# Generated at 2022-06-22 03:06:56.136870
# Unit test for function update_environment
def test_update_environment():
    import os
    import thonny.globals
    import unittest
    import sys

    thonny.globals.set_workbench(None)  # clear cache

    class MyOptions(unittest.TestCase):
        def setUp(self):
            self.orig_options = thonny.workbench.Workbench.default_options.copy()

        def tearDown(self):
            thonny.workbench.Workbench.default_options = self.orig_options

        def test_update_environment(self):
            thonny.workbench.Workbench.default_options["run.pgzero_mode"] = True
            workbench = thonny.workbench.Workbench()
            update_environment()
            self.assertEqual(os.environ["PGZERO_MODE"], "True")

           

# Generated at 2022-06-22 03:07:02.327507
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    wb._simple_mode = True
    wb.set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    wb._simple_mode = False
    wb.set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"

# Generated at 2022-06-22 03:07:12.112780
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default("run.pgzero_mode", False)
    load_plugin()

    assert wb.get_option("run.pgzero_mode") is False

    wb.event_generate("BindingChanged", command_id="toggle_pgzero_mode")
    assert wb.get_option("run.pgzero_mode") is True
    assert os.environ["PGZERO_MODE"] == "True"

    wb.event_generate("BindingChanged", command_id="toggle_pgzero_mode")
    assert wb.get_option("run.pgzero_mode") is False
    assert os.environ["PGZERO_MODE"] == "False"

    wb.set_simple_mode(True)

# Generated at 2022-06-22 03:07:22.023168
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_simple_mode(True)
    get_workbench().set_option(_OPTION_NAME, True)
    assert get_workbench().get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "auto"

    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"

    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"


# Generated at 2022-06-22 03:08:12.961681
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock
    from thonny.workbench import Workbench

    original_get_workbench = get_workbench
    get_workbench = Mock(return_value=Workbench())
    try:
        load_plugin()
        assert get_workbench.called
    finally:
        get_workbench = original_get_workbench
        del original_get_workbench

# Generated at 2022-06-22 03:08:16.913904
# Unit test for function toggle_variable
def test_toggle_variable():
    load_plugin()
    assert not get_workbench().get_option(_OPTION_NAME)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME)
    toggle_variable()
    assert not get_workbench().get_option(_OPTION_NAME)

# Generated at 2022-06-22 03:08:19.427251
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench

    get_workbench().destroy_ui()
    wb = Workbench()
    load_plugin()
    wb.destroy()


# Generated at 2022-06-22 03:08:27.754389
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import MagicMock

    wb = MagicMock()
    wb.set_default.return_value = True
    wb.add_command.return_value = True
    wb.get_plugin.return_value = True
    wb.get_option.return_value = False
    wb.get_variable.return_value = True
    wb.in_simple_mode.return_value = False
    load_plugin()
    assert get_workbench.return_value == wb


if __name__ == "__main__":
    load_plugin()

# Generated at 2022-06-22 03:08:35.880963
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    
    wb = Workbench()
    wb.set_default("run.pgzero_mode", None)
    load_plugin()
    assert "toggle_pgzero_mode" in wb.get_commands()
    assert wb.get_option("run.pgzero_mode") == False
    assert os.environ["PGZERO_MODE"] == "False"
    assert wb.get_variable("run.pgzero_mode").get() == False
    


# Generated at 2022-06-22 03:08:43.963703
# Unit test for function load_plugin
def test_load_plugin():
    master = Tk()
    ui = get_workbench()
    # function load_simple_mode() adds two new command to the menu bar
    # Use menu bar to check if they are added correctly
    menu_bar = ui.get_menu_bar()
    simple_mode_menu = menu_bar.children["run"]
    assert "toggle_pgzero_mode" in simple_mode_menu.children
    assert "separator1" in simple_mode_menu.children


if __name__ == "__main__":
    from thonny import workbench

    workbench.setup()
    load_plugin()

# Generated at 2022-06-22 03:08:49.664214
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    wb.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    wb.set_simple_mode(False)
    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 03:08:51.824802
# Unit test for function update_environment
def test_update_environment():
    old_env = dict(os.environ)
    load_plugin()
    update_environment()
    assert os.environ["PGZERO_MODE"] == str(get_workbench().get_option(_OPTION_NAME))
    os.environ = old_env

# Generated at 2022-06-22 03:08:57.759086
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    wb.set_option(_OPTION_NAME, False)
    assert wb.get_option(_OPTION_NAME) == False
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == True
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == False

# Generated at 2022-06-22 03:09:02.002166
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()
    assert os.environ.get("PGZERO_MODE") == str(True)
    toggle_variable()
    assert os.environ.get("PGZERO_MODE") == str(False)
    toggle_variable()
    assert os.environ.get("PGZERO_MODE") == str(True)