

# Generated at 2022-06-22 03:00:39.245415
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = ""
    assert "PGZERO_MODE" in os.environ
    update_environment()
    assert "PGZERO_MODE" in os.environ
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 03:00:49.764861
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import MagicMock

    wb_mock = MagicMock()
    wb_mock.in_simple_mode.return_value = False
    wb_mock.get_option.return_value = False

    get_workbench.return_value = wb_mock

    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    wb_mock.get_option.return_value = True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    wb_mock.in_simple_mode.return_value = True
    wb_mock.get_option.return_value = True
    update_environment()

# Generated at 2022-06-22 03:01:01.870358
# Unit test for function update_environment
def test_update_environment():
    old_PGZERO_MODE = None
    if "PGZERO_MODE" in os.environ:
        old_PGZERO_MODE = os.environ["PGZERO_MODE"]
        del os.environ["PGZERO_MODE"]

    get_workbench().set_simple_mode(True)

    update_environment()
    assert "PGZERO_MODE" not in os.environ

    get_workbench().set_simple_mode(False)

    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_option(_OPTION_NAME, False)
   

# Generated at 2022-06-22 03:01:15.179562
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import Mock
    from thonny import get_workbench

    wb = Mock()
    wb.get_option.return_value = False
    wb._in_simple_mode = False
    get_workbench.get_instance = Mock(return_value=wb)

    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    wb.get_option.return_value = True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    wb._in_simple_mode = True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    del os.environ["PGZERO_MODE"]

# Generated at 2022-06-22 03:01:19.785502
# Unit test for function toggle_variable
def test_toggle_variable():
    load_plugin()
    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == True
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == False

# Generated at 2022-06-22 03:01:25.807834
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench
    from thonny.workbench import Workbench

    workbench = Workbench()
    workbench.set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    workbench.set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    workbench.destroy()

# Generated at 2022-06-22 03:01:37.868042
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock

    d = {
        "set_default": Mock(),
        "add_command": Mock(),
        "in_simple_mode": Mock(),
        "get_option": Mock(),
        "get_variable": Mock(),
    }
    load_plugin()
    d["set_default"].assert_called_with(_OPTION_NAME, False)
    d["add_command"].assert_called_with(
        "toggle_pgzero_mode", "run", tr("Pygame Zero mode"), toggle_variable, flag_name=_OPTION_NAME, group=40
    )
    d["get_option"].reset_mock()
    d["get_variable"].reset_mock()

    # Second call (re-load) shouldn't add a command
    load_plugin()
   

# Generated at 2022-06-22 03:01:41.700497
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench

    workbench = Workbench()
    load_plugin()

    # Check a command is added
    command = workbench.get_command("toggle_pgzero_mode")
    assert command is not None

    # Check defaults are correct
    assert workbench.get_option(_OPTION_NAME) is False

    # Check state changes are being tracked
    command.invoke()
    assert workbench.get_varia

# Generated at 2022-06-22 03:01:51.417056
# Unit test for function update_environment
def test_update_environment():
    class WB:
        def __init__(self):
            self.variables = {
                _OPTION_NAME: False
            }
            self.options = {
                _OPTION_NAME: False
            }
            self.in_simple_mode = False            

        def get_variable(self, name):
            class Var:
                def __init__(self, initial_value):
                    self.initial_value = initial_value

                def get(self):
                    return self.initial_value

                def set(self, new_value):
                    self.initial_value = new_value

            return Var(self.variables[name])

        def get_option(self, name):
            return self.options[name]

        def set_simple_mode(self, enabled):
            self.in_simple_mode = enabled

       

# Generated at 2022-06-22 03:02:01.791193
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench
    from thonny.misc_utils import running_on_mac_os
    from thonny.misc_utils import running_on_rpi
    from thonny.misc_utils import running_on_windows
    from thonny.tktextext import TextFrame
    from thonny.ui_utils import CommonDialog

    assert "toggle_pgzero_mode" in get_workbench().get_command_names()
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().set_option(_OPTION_NAME, False)
    assert os.environ["PGZERO_MODE"] == "False"
    del os.environ["PGZERO_MODE"]
    get_workbench().set_option(_OPTION_NAME, True)

# Generated at 2022-06-22 03:02:07.887634
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench
    from thonny.workbench import Workbench

    wb = Workbench()
    wb._in_simple_mode = False

    wb._set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    wb._set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    wb._in_simple_mode = True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 03:02:14.376424
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_simple_mode()
    assert os.environ.get("PGZERO_MODE") == "auto"
    get_workbench().set_simple_mode(False)
    load_plugin()
    assert os.environ.get("PGZERO_MODE") == "False"
    toggle_variable()
    assert os.environ.get("PGZERO_MODE") == "True"
    get_workbench().set_simple_mode()
    assert os.environ.get("PGZERO_MODE") == "auto"

# Generated at 2022-06-22 03:02:19.245588
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_option(_OPTION_NAME, False)
    assert toggle_variable() == None
    assert get_workbench().get_option(_OPTION_NAME) == True
    assert toggle_variable() == None
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-22 03:02:32.177465
# Unit test for function update_environment
def test_update_environment():
    import os
    import thonny
    import runpy
    
    os.environ["PGZERO_MODE"] = "auto"
    sys.argv = [sys.argv[0]]
    get_workbench().set_default("run.pgzero_mode", False)
    
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    os.environ["PGZERO_MODE"] = "auto"
    sys.argv = [sys.argv[0], "-s"]
    get_workbench().set_default("run.pgzero_mode", False)

    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    os.environ["PGZERO_MODE"] = "auto"

# Generated at 2022-06-22 03:02:38.391690
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default(_OPTION_NAME, True)
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 03:02:42.743599
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    wb = get_workbench()
    assert wb.get_variable("run.pgzero_mode").get() == False
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 03:02:43.303335
# Unit test for function toggle_variable
def test_toggle_variable():
    pass

# Generated at 2022-06-22 03:02:46.556619
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_modes(["Thonny"])
    load_plugin()
    assert get_workbench().get_variable(_OPTION_NAME) == False

# Generated at 2022-06-22 03:02:52.823747
# Unit test for function toggle_variable
def test_toggle_variable():
    #pylint: disable=import-outside-toplevel

    from test.config_helper import get_variable
    from thonny import get_workbench

    try:
        var = get_variable(_OPTION_NAME)
        var.set(True)
        assert get_workbench().get_option(_OPTION_NAME) == True
        toggle_variable()
        assert get_workbench().get_option(_OPTION_NAME) == False
        toggle_variable()
        assert get_workbench().get_option(_OPTION_NAME) == True
    finally:
        var.set(False)

# Generated at 2022-06-22 03:03:04.121969
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.register_editor_mode("pygamezero", lambda: True, 17)
    wb.register_editor_mode("thonny", lambda: True, 19)

    # Unload plugin
    from thonny.plugins.pygamezero_mode import load_plugin as _load_plugin
    from thonny.plugins.pygamezero_mode import toggle_variable as _toggle_variable
    from thonny.plugins.pygamezero_mode import update_environment as _update_environment

    if "toggle_pgzero_mode" in wb.get_commands():
        wb.remove_command("toggle_pgzero_mode")
    assert not hasattr(
        wb, _OPTION_NAME
    ), "wb has '_OPTION_NAME' attribute before plugin load"
   

# Generated at 2022-06-22 03:03:19.703429
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import Mock
    from thonny import get_workbench

    wb = Mock(get_option=lambda name: False, in_simple_mode=lambda: True)
    get_workbench._workbench = wb
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    wb = Mock(get_option=lambda name: True, in_simple_mode=lambda: False)
    get_workbench._workbench = wb
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"


    wb = Mock(get_option=lambda name: False, in_simple_mode=lambda: False)
    get_workbench._workbench = wb
    update_environment()

# Generated at 2022-06-22 03:03:22.867074
# Unit test for function toggle_variable
def test_toggle_variable():
    global _OPTION_NAME
    var = get_workbench().get_variable(_OPTION_NAME)
    var.set(True)
    var.set(False)
    var.set(True)

# Generated at 2022-06-22 03:03:34.383017
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default("run.pgzero_mode", False)
    assert wb.get_variable("run.pgzero_mode").get() == False
    assert os.environ.get("PGZERO_MODE", "") == "auto"

    load_plugin()
    assert wb.get_variable("run.pgzero_mode").get() == False
    assert os.environ.get("PGZERO_MODE", "") == "False"

    wb.set_simple_mode(True)
    update_environment()
    assert os.environ.get("PGZERO_MODE", "") == "auto"

    wb.set_simple_mode(False)
    update_environment()

# Generated at 2022-06-22 03:03:41.904254
# Unit test for function toggle_variable
def test_toggle_variable():
    import tkinter as tk
    root = tk.Tk()
    get_workbench().create(root)
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().get_option(_OPTION_NAME)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False
    root.destroy()

# Generated at 2022-06-22 03:03:53.651615
# Unit test for function update_environment
def test_update_environment():
    def TestOptionGetter():
        return True

    def TestOptionSetter(value):
        raise Exception("Don't do that!")

    def TestSimpleModeGetter():
        return False

    class TestWorkbench:
        def get_option(self, option_name):
            return TestOptionGetter()

        def get_variable(self, name):
            return TestOptionGetter

        def set_option(self, option_name, value):
            TestOptionSetter(value)

        def add_command(self, *_, **__):
            pass

        def set_default(self, *_, **__):
            pass

        def in_simple_mode(self):
            return TestSimpleModeGetter()

    workbench = TestWorkbench()
    old_workbench = get_workbench()

# Generated at 2022-06-22 03:04:04.447106
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, True)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()
    assert "PGZERO_MODE" not in os.environ
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 03:04:09.875042
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()

    # Toggle mode
    var = wb.get_variable(_OPTION_NAME)
    var.set(False)
    assert var.get() == False

    toggle_variable()
    assert var.get() == True
    toggle_variable()
    assert var.get() == False

# Generated at 2022-06-22 03:04:20.033241
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench

    class MockTKApp:
        def __init__(self):
            def get_variable(name):
                return True
            self.get_variable = get_variable

    class MockTK:
        def __init__(self):
            self.IntVar = None
            def call(f, *args):
                f(*args)
            self.after = call

        def BooleanVar(self):
            return True

    mock_tk_app = MockTKApp()
    mock_tk = MockTK()
    wb = Workbench(tk_app=mock_tk_app, tk=mock_tk)
    load_plugin()
    assert "PGZERO_MODE" in os.environ

# Generated at 2022-06-22 03:04:31.653804
# Unit test for function update_environment
def test_update_environment():
    for simple_mode in [True, False]:
        for pgzero_mode_value in [False, True]:

            print("simple_mode", simple_mode, "pgzero_mode_value", pgzero_mode_value)

            # save original value, reset environment and options
            orig_pgzero_mode_value = os.environ.get("PGZERO_MODE", None)
            os.environ.pop("PGZERO_MODE", None)
            orig_simple_mode_value = get_workbench().in_simple_mode()
            get_workbench().set_simple_mode(False)
            get_workbench().set_option(_OPTION_NAME, pgzero_mode_value)

            # check behavior depending on values
            if simple_mode:
                get_workbench().set_simple_mode(simple_mode)


# Generated at 2022-06-22 03:04:43.697809
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench

    # Make sure workbench is initialised
    get_workbench()

    # Test with simple mode, 
    # Spoof that we're in simple mode
    get_workbench()._simple_mode = True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    # Test with non-simple mode, pgzero_mode on
    get_workbench()._simple_mode = False
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    # Test with non-simple mode, pgzero_mode off
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.en

# Generated at 2022-06-22 03:05:07.444020
# Unit test for function update_environment
def test_update_environment():
    from thonny.globals import get_runner
    from thonny.ui_utils import ask_ok_cancel
    from thonny.config import reset_config_variables
    from thonny import get_workbench
    from thonny.workbench import Workbench
    from thonny.languages import tr
    from thonny.plugins.run.run_command import get_run_command
    from thonny.plugins.run.run_subprocess import run_subprocess
    
    
    def get_control(master):
        return tk.Frame(master)
    
    get_runner().get_control = get_control
    wb = Workbench()
    wb._set_simple_mode("STARTUP")
    wb.set_default("run.pgzero_mode", False)


# Generated at 2022-06-22 03:05:12.057443
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 03:05:23.624396
# Unit test for function toggle_variable
def test_toggle_variable():
    # Set the boolean to true (default is False)
    test_variable = get_workbench().get_variable(_OPTION_NAME)
    test_variable.set(True)
    # Test that it is set to True
    assert test_variable.get()

    # Call function toggle_variable, then check that the boolean is set to false
    toggle_variable()
    assert test_variable.get() == False

    # Change the boolean to true (default is False)
    test_variable.set(True)
    # Call function toggle_variable, then check that the boolean is set to false
    toggle_variable()
    assert test_variable.get() == False

    # Call function toggle_variable, then check that the boolean is set to true
    toggle_variable()
    assert test_variable.get()


# Generated at 2022-06-22 03:05:30.569195
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, True)
    assert os.environ["PGZERO_MODE"] == "1"
    load_plugin()
    assert os.environ["PGZERO_MODE"] == "0"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "1"
    get_workbench().in_simple_mode = lambda: True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"



# Generated at 2022-06-22 03:05:43.378707
# Unit test for function update_environment
def test_update_environment():
    # unit test for function update_environment
    from thonny import get_workbench
    from thonny.workbench import Workbench
    from unittest.mock import Mock

    # Test in simple_mode
    workbench = Workbench()
    workbench.simple_mode = True
    workbench.get_variable = Mock(
        return_value=(
            Mock(
                get=Mock(
                    return_value=False
                )
            )
        )
    )
    get_workbench._impl = Mock(return_value=workbench)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    # Normal mode
    workbench.simple_mode = False

# Generated at 2022-06-22 03:05:48.215732
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    assert not wb.get_variable(_OPTION_NAME).get()
    load_plugin()
    assert wb.get_variable(_OPTION_NAME).get() == 0
    assert wb.get_option(_OPTION_NAME) == 0



# Generated at 2022-06-22 03:05:51.274523
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_option(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME)

# Generated at 2022-06-22 03:05:56.424341
# Unit test for function load_plugin
def test_load_plugin():
    # First unit test for function load_plugin
    # Dummy test to check if function load_plugin runs 
    assert load_plugin() == None

    # Second unit test for function load_plugin 
    # Dummy test to check if function test_load_plugin runs 
    assert test_load_plugin() == None

# Generated at 2022-06-22 03:06:03.138656
# Unit test for function update_environment
def test_update_environment():
    if "PGZERO_MODE" in os.environ:
        del os.environ["PGZERO_MODE"]
    
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 03:06:07.344652
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_runner, get_workbench

    get_workbench().test_mode()
    load_plugin()
    assert get_runner().get_cmd_args_from_sys_argv([])


if __name__ == "__main__":
    load_plugin()

# Generated at 2022-06-22 03:06:32.481904
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) is False



# Generated at 2022-06-22 03:06:38.502914
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    assert wb.get_option(_OPTION_NAME) == False
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == True
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == False



# Generated at 2022-06-22 03:06:48.275944
# Unit test for function load_plugin
def test_load_plugin():
    if "PGZERO_MODE" in os.environ:
        del os.environ["PGZERO_MODE"]

    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"

    get_workbench().set_option(_OPTION_NAME, False)
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"


if __name__ == "__main__":
    test_load_plugin()

# Generated at 2022-06-22 03:06:57.441209
# Unit test for function toggle_variable
def test_toggle_variable():
    from PyQt5.QtCore import QSettings

    # Set 1
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    toggle_variable()
    assert wb.get_variable(_OPTION_NAME).get() == True
    toggle_variable()
    assert wb.get_variable(_OPTION_NAME).get() == False

    # Set 2
    wb2 = get_workbench()
    wb2.set_default(_OPTION_NAME, True)
    toggle_variable()
    assert wb2.get_variable(_OPTION_NAME).get() == False
    toggle_variable()
    assert wb2.get_variable(_OPTION_NAME).get() == True

    # Set 3

# Generated at 2022-06-22 03:07:02.414362
# Unit test for function toggle_variable
def test_toggle_variable():
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 03:07:12.156928
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock

    class WorkbenchMock(Mock):
        def set_default(self, key, value, source=None):
            getattr(self, "set_default").__defaults__[0](key, value)

    workbench_mock = WorkbenchMock()
    workbench_mock.get_default = Mock(side_effect=lambda x: None)
    workbench_mock.set_default = Mock(side_effect=lambda *args, **kwargs: None)
    workbench_mock.add_command = Mock(side_effect=lambda *args, **kwargs: None)

    orig_workbench = get_workbench()

# Generated at 2022-06-22 03:07:18.425323
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_simple_mode(False)
    print('before toggle_variable: value of {} is {}'.format(_OPTION_NAME, get_workbench().get_variable(_OPTION_NAME).get()))
    toggle_variable()
    print('after toggle_variable: value of {} is {}'.format(_OPTION_NAME, get_workbench().get_variable(_OPTION_NAME).get()))

# Generated at 2022-06-22 03:07:29.353367
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default("run.pgzero_mode", True)
    get_workbench().set_default("view.simple_mode", False)
    get_workbench().set_option("run.pgzero_mode", True)
    update_environment()

# Generated at 2022-06-22 03:07:37.386591
# Unit test for function toggle_variable
def test_toggle_variable():
    os.environ["PGZERO_MODE"] = ""
    get_workbench().set_option(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"

    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 03:07:41.675685
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, True)
    load_plugin()
    assert wb.get_variable(_OPTION_NAME).get()
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert not wb.get_variable(_OPTION_NAME).get()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 03:08:31.050082
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_option(_OPTION_NAME, True)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-22 03:08:35.676972
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench().get_variable("run.pgzero_mode")
    assert not wb
    toggle_variable()
    wb = get_workbench().get_variable("run.pgzero_mode")
    assert wb



# Generated at 2022-06-22 03:08:42.998235
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench
    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_simple_mode(True)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 03:08:47.167280
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.common import Tester
    from thonny import get_workbench
    tester = Tester(get_workbench)
    tester.show_view("Options")
    tester.select_frame("Options").select_frame("Run").select_frame("Run")
    tester.click(tester.get_widget_by_name(_OPTION_NAME))

# Generated at 2022-06-22 03:08:57.104363
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench
    from thonny.misc_utils import running_on_mac_os
    from thonny.shell import ShellView

    get_workbench().set_default(_OPTION_NAME, True)
    get_workbench().in_simple_mode() == False

    if running_on_mac_os():
        assert os.environ["PGZERO_MODE"] == "1"
    else:
        assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().in_simple_mode(True)
    assert os.environ["PGZERO_MODE"] == "auto"



# Generated at 2022-06-22 03:09:02.583350
# Unit test for function update_environment
def test_update_environment():
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_option("run.pgzero_mode", True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_option("run.pgzero_mode", False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 03:09:11.832500
# Unit test for function update_environment
def test_update_environment():
    os.environ.pop("PGZERO_MODE", None)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_simple_mode(False)

    get_workbench().get_variable(_OPTION_NAME).set(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 03:09:21.836769
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import workbench

    workbench.set_default("run.pgzero_mode", True)

    load_plugin()
    assert "PGZERO_MODE" in os.environ
    assert os.environ["PGZERO_MODE"] == "True"

    workbench.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    workbench.set_simple_mode(False)
    workbench.set_default("run.pgzero_mode", False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 03:09:27.242685
# Unit test for function load_plugin
def test_load_plugin():
    import unittest.mock as mock

    wb = mock.Mock()
    globals()["get_workbench"] = mock.Mock(return_value=wb)

    load_plugin()
    wb.set_default.assert_called_once_with(_OPTION_NAME, False)
    assert wb.add_command.call_count == 1
    toggle_variable()
    wb.get_variable.assert_called_once_with(_OPTION_NAME)

# Generated at 2022-06-22 03:09:36.882041
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import Mock
    from thonny import get_workbench
    from thonny.common import InlineCommand

    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().in_simple_mode = Mock(return_value=True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    
    get_workbench().in_simple_mode = Mock(return_value=False)
    del os.environ["PGZERO_MODE"]
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"