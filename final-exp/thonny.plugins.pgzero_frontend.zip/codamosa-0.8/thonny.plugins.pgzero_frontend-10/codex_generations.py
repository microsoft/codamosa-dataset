

# Generated at 2022-06-22 15:27:58.394197
# Unit test for function load_plugin
def test_load_plugin():
    return """
    >>> from thonny.plugins.pgzero_mode import load_plugin
    >>> load_plugin()
    >>> get_workbench().get_option("run.pgzero_mode")
    False
    >>> get_workbench().in_simple_mode()
    False
    >>> if "PGZERO_MODE" in os.environ:
    ...     del os.environ["PGZERO_MODE"]
    >>> update_environment()
    >>> os.environ["PGZERO_MODE"]
    'False'
    """

# Generated at 2022-06-22 15:28:04.148033
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.misc_utils import running_on_mac_os, running_on_windows
    from unittest.mock import Mock

    orig_platform = sys.platform
    orig_value = os.environ.get("PGZERO_MODE")
    orig_simple_mode = Workbench.in_simple_mode
    orig_get_variable = Workbench.get_variable
    orig_get_option = Workbench.get_option
    orig_running_on_mac_os = running_on_mac_os
    orig_running_on_windows = running_on_windows

    os.environ.pop("PGZERO_MODE", None)

    workbench = Mock(spec=Workbench)
    workbench.in_simple_mode.return_value = False

   

# Generated at 2022-06-22 15:28:13.740765
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    old_mode = wb.in_simple_mode()
    if not old_mode:
        wb.set_simple_mode(True)
    result1 = os.environ["PGZERO_MODE"]
    wb.set_simple_mode(False)
    wb.set_option(_OPTION_NAME, True)
    os.environ["PGZERO_MODE"] = "foo"
    update_environment()
    result2 = os.environ["PGZERO_MODE"]
    wb.set_simple_mode(old_mode)
    if not old_mode:
        wb.set_simple_mode(True)
    assert result1 == "auto"
    assert result2 == "1"
    os.environ.pop("PGZERO_MODE")

# Generated at 2022-06-22 15:28:24.366634
# Unit test for function update_environment
def test_update_environment():
    if "PGZERO_MODE" in os.environ:
        del os.environ["PGZERO_MODE"]
    update_environment()
    assert os.environ["PGZERO_MODE"] == str(get_workbench().get_option(_OPTION_NAME))
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 15:28:35.830924
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_option("view.simple_mode", False)
    load_plugin()
    assert not get_workbench().get_option("run.pgzero_mode")
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_option("view.simple_mode", True)
    load_plugin()
    assert os.environ["PGZERO_MODE"] == "auto"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 15:28:45.340989
# Unit test for function update_environment
def test_update_environment():
    from unittest import mock

    os.environ.pop("PGZERO_MODE", None)
    with mock.patch.object(get_workbench(), "in_simple_mode", return_value=False), \
            mock.patch.object(get_workbench(), "get_option", return_value=True):
        update_environment()
        assert os.environ["PGZERO_MODE"] == "True"

    with mock.patch.object(get_workbench(), "in_simple_mode", return_value=True):
        update_environment()
        assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 15:28:55.932633
# Unit test for function update_environment
def test_update_environment():
    from thonny.globals import get_runner

    get_workbench().set_option(_OPTION_NAME, False)
    assert update_environment() is None
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_option(_OPTION_NAME, True)
    assert update_environment() is None
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_simple_mode(True, suppress_dialog=True)
    assert update_environment() is None
    assert os.environ["PGZERO_MODE"] == "auto"



# Generated at 2022-06-22 15:29:03.780124
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    var = wb.get_variable(_OPTION_NAME)
    assert var
    assert not var.get()
    assert os.environ["PGZERO_MODE"] == "False"
    assert not wb.get_commands().get("toggle_pgzero_mode").get_flag_state()

    wb.get_options()["run.pgzero_mode"] = True
    update_environment()
    assert wb.get_commands().get("toggle_pgzero_mode").get_flag_state()

    wb.get_options()["run.pgzero_mode"] = False
    update_environment()
    assert not wb.get_commands().get("toggle_pgzero_mode").get_flag_

# Generated at 2022-06-22 15:29:08.459321
# Unit test for function toggle_variable
def test_toggle_variable():
    if "PGZERO_MODE" in os.environ:
        os.environ.pop("PGZERO_MODE")
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 15:29:11.575707
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_simple_mode(True)
    toggle_variable()
    get_workbench().set_simple_mode(False)
    toggle_variable()

# Generated at 2022-06-22 15:29:22.549530
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    assert not wb.in_simple_mode()
    assert wb.get_option("run.pygame_zero_mode") is False
    wb.set_option("run.pygame_zero_mode", True)
    assert wb.get_option("run.pygame_zero_mode") is True

    # Expected to do nothing
    load_plugin()
    assert wb.get_option("run.pygame_zero_mode") is True
    assert os.environ["PGZERO_MODE"] == "True"



# Generated at 2022-06-22 15:29:31.610693
# Unit test for function update_environment
def test_update_environment():
    get_workbench().in_simple_mode = lambda: True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    
    get_workbench().in_simple_mode = lambda: False
    get_workbench().get_option = lambda name: True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    
    get_workbench().in_simple_mode = lambda: False
    get_workbench().get_option = lambda name: False
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 15:29:32.861581
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)

# Generated at 2022-06-22 15:29:42.740508
# Unit test for function update_environment
def test_update_environment():
    """ Changing option should make change in os.environ too """
    print(os.environ)
    get_workbench().set_default(_OPTION_NAME, False)
    assert "PGZERO_MODE" not in os.environ
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_option(_OPTION_NAME, False)
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_default(_OPTION_NAME, True)


# Generated at 2022-06-22 15:29:49.305465
# Unit test for function update_environment
def test_update_environment():
    for mode_name in ["auto", "auto-wait", "manual", "strict"]:
        os.environ["PGZERO_MODE"] = ""
        get_workbench().set_option(_OPTION_NAME, True)
        get_workbench().set_option("view.simplified_mode", False)
        update_environment()
        assert os.environ["PGZERO_MODE"] == "manual"
        get_workbench().set_option("view.simplified_mode", True)
        update_environment()
        assert os.environ["PGZERO_MODE"] == mode_name

# Generated at 2022-06-22 15:29:54.130066
# Unit test for function load_plugin
def test_load_plugin():
    from test.config_helper import get_workbench
    workbench = get_workbench()
    workbench.in_simple_mode = lambda: False
    load_plugin()
    workbench.in_simple_mode = lambda: True
    load_plugin()

# Generated at 2022-06-22 15:30:01.640978
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default(_OPTION_NAME, False)
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_simple_mode(1)
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_simple_mode(0)
    get_workbench().set_option(_OPTION_NAME, True)
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 15:30:04.827097
# Unit test for function update_environment
def test_update_environment():
    b = get_workbench()
    b.set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    b.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 15:30:06.455390
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()

if __name__ == "__main__":
    test_load_plugin()

# Generated at 2022-06-22 15:30:10.219340
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()

# Generated at 2022-06-22 15:30:25.152086
# Unit test for function update_environment
def test_update_environment():
    # Test that the environment var is set with no value in simple mode
    get_workbench().set_option(_OPTION_NAME, False)
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    # Test that the environment var is set to False when not in simple mode
    get_workbench().set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    # Test that the environment var is set to False when not in simple mode
    get_workbench().set_option(_OPTION_NAME, True)
    get_workbench().set_simple_mode(True)
    update_environment()

# Generated at 2022-06-22 15:30:27.354767
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny import get_workbench

    workbench = get_workbench()
    toggle_variable()
    assert workbench.get_option(_OPTION_NAME) == True



# Generated at 2022-06-22 15:30:30.025865
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, True)
    load_plugin()
    assert get_workbench().get_variable(_OPTION_NAME).get() is True

# Generated at 2022-06-22 15:30:37.395019
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)

    update_environment()
    assert "PGZERO_MODE" in os.environ
    assert os.environ["PGZERO_MODE"] == "False"

    wb.set_simple_mode(True)
    wb.set_variable(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    wb.set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 15:30:42.169904
# Unit test for function update_environment
def test_update_environment():
    get_workbench().load_plugin("new_basic_mode")
    update_environment()
    if get_workbench().in_simple_mode():
        assert os.environ["PGZERO_MODE"] == "auto"
    else:
        assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 15:30:44.208037
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-22 15:30:46.298597
# Unit test for function update_environment
def test_update_environment():
    get_workbench().load_compat_configuration()
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()

# Generated at 2022-06-22 15:30:57.514966
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    wb.set_simple_mode(False)
    wb.set_option(_OPTION_NAME, False)
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == True
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == False
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == True
    wb.set_simple_mode(True)
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == True
    wb.set_simple_mode(False)
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 15:30:58.393664
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()
    update_environment()


# Generated at 2022-06-22 15:31:03.279766
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, True)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()

# Generated at 2022-06-22 15:31:25.816317
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = ""

    get_workbench().set_default(_OPTION_NAME, True)
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().set_default(_OPTION_NAME, True)
    get_workbench().set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"


# Generated at 2022-06-22 15:31:31.471209
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default("user.interface.language", "en")
    load_plugin()
    assert get_workbench().get_command("toggle_pgzero_mode").label == "Pygame Zero mode"
    assert get_workbench().get_command("toggle_pgzero_mode").flag_name == _OPTION_NAME
    assert get_workbench().get_command("toggle_pgzero_mode").group == 40


# Generated at 2022-06-22 15:31:38.739531
# Unit test for function load_plugin
def test_load_plugin():
    # Save the environment variable
    old_environ = os.environ.copy()

# Generated at 2022-06-22 15:31:48.169672
# Unit test for function load_plugin
def test_load_plugin():
    try:
        wb = get_workbench()
        wb.unload_plugin("pgzero")
        load_plugin()
        assert wb.get_default(_OPTION_NAME)==False
        assert wb.in_simple_mode()==False
        assert os.environ["PGZERO_MODE"] == "False"
        get_workbench().set_simple_mode(True)
        assert wb.in_simple_mode()==True
        assert os.environ["PGZERO_MODE"] == "auto"
    finally:
        wb.unload_plugin("pgzero")

# Generated at 2022-06-22 15:31:52.256539
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()
    toggle_variable()

# Generated at 2022-06-22 15:31:53.648718
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()

# Generated at 2022-06-22 15:31:57.052908
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    wb.set_option("run.pgzero_mode", True)
    toggle_variable()
    assert wb.get_option("run.pgzero_mode") is False
    toggle_variable()
    assert wb.get_option("run.pgzero_mode") is True



# Generated at 2022-06-22 15:32:02.310145
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 15:32:12.581946
# Unit test for function update_environment
def test_update_environment():
    # Make sure the target variable won't be found in os.environ
    os.environ.pop("PGZERO_MODE", None)

    # Check variable is set and has expected value
    wb = get_workbench()
    wb.in_simple_mode = lambda: False
    wb.get_option = lambda s: False
    update_environment()
    assert "PGZERO_MODE" in os.environ
    assert os.environ["PGZERO_MODE"] == "False"

    # Check variable is set and has expected value
    wb.get_option = lambda s: True
    update_environment()
    assert "PGZERO_MODE" in os.environ
    assert os.environ["PGZERO_MODE"] == "True"

    # Check variable is unset and has expected value
    wb

# Generated at 2022-06-22 15:32:22.437262
# Unit test for function update_environment
def test_update_environment():
    old_env = dict(os.environ)
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().in_simple_mode = lambda: True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().in_simple_mode = lambda: False
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"
    os.environ = old_env

# Generated at 2022-06-22 15:33:00.437010
# Unit test for function toggle_variable
def test_toggle_variable():
    import unittest.mock
    wb = unittest.mock.Mock()
    wb.get_variable = lambda opt : unittest.mock.Mock(get=lambda : False)
    wb.set_variable = unittest.mock.Mock()
    wb.in_simple_mode = False

    with unittest.mock.patch("thonny.plugins.pgzero.toggle_variable.get_workbench") as gwb:
        gwb.return_value = wb
        toggle_variable()
        wb.get_variable.assert_called_once_with("run.pgzero_mode")
        wb.set_variable.assert_called_once_with("run.pgzero_mode", True)

# Generated at 2022-06-22 15:33:03.266480
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"



# Generated at 2022-06-22 15:33:09.794597
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    test_workbench = get_workbench()
    assert test_workbench.get_variable(_OPTION_NAME).get() == False
    toggle_variable()
    assert test_workbench.get_variable(_OPTION_NAME).get() == True
    toggle_variable()
    assert test_workbench.get_variable(_OPTION_NAME).get() == False

# Generated at 2022-06-22 15:33:21.670776
# Unit test for function toggle_variable
def test_toggle_variable():
    # Need to import TestCase class, as it is not available when this file is accessed
    # in the very beginning of thonny startup
    # and because we need to mock get_workbench() too, and therefore
    # as we are not testing the whole class, we need
    # to define all the necessary functions which will be called by toggle_variable().
    from unittest.mock import Mock, call
    from thonny.plugins.gui_test.gui_test_plugin import TestCase
    
    # the code below is copied from thonny/globals.py class Workbench
    class Workbench(object):
        def __init__(self):
            self.vars = {}
            self.options = {}
            self.commands = "Not initialized yet"
    
    # the code below is copied from thonny/glob

# Generated at 2022-06-22 15:33:25.650472
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_simple_mode()
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 15:33:35.204770
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny import get_workbench, get_runner
    from thonny.config_ui import ConfigurationPage

    get_workbench().clear_backend()
    get_workbench().clear_settings()

    test_page = ConfigurationPage(get_workbench(), get_runner())
    test_page.create_widgets()
    test_page.toggle_pgzero_mode()
    assert get_workbench().get_variable(_OPTION_NAME).get() == True
    test_page.toggle_pgzero_mode()
    assert get_workbench().get_variable(_OPTION_NAME).get() == False


if __name__ == "__main__":
    test_toggle_variable()

# Generated at 2022-06-22 15:33:38.933336
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny import get_workbench
    from thonny.ui_utils import toggle_checkbox_value

    toggle_checkbox_value()
    assert get_workbench().get_option(_OPTION_NAME)
    toggle_checkbox_value()
    assert not get_workbench().get_option(_OPTION_NAME)

# Generated at 2022-06-22 15:33:45.079280
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, 0)
    assert os.environ["PGZERO_MODE"] == "0"
    wb.set_option(_OPTION_NAME, 1)
    assert os.environ["PGZERO_MODE"] == "1"
    wb.set_option(_OPTION_NAME, True)
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 15:33:50.552116
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_runner, get_workbench, THONNY_USER_DIR
    from thonny.misc_utils import running_on_mac_os
    import os, os.path
    import shutil
    from thonny.plugins.pgzero_mode import update_environment, _OPTION_NAME

    # Create empty test directory
    test_dir = os.path.join(THONNY_USER_DIR, "unittest_plugins_pgzero_mode")
    if os.path.exists(test_dir):
        shutil.rmtree(test_dir)
    os.makedirs(test_dir)
    os.chdir(test_dir)

    # Create a dummy file so that the program exists
    open('exists.py', 'w').close()

    # Check that the environment is

# Generated at 2022-06-22 15:33:56.124705
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_simple_mode(True)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 15:34:27.768186
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import Mock
    import os
    os.environ.clear()
    wb = Mock()
    wb.in_simple_mode.return_value = False
    wb.get_option.return_value = True
    with MockWorkbench(wb):
        update_environment()
        os.environ["PGZERO_MODE"] == "True"


# Generated at 2022-06-22 15:34:30.052204
# Unit test for function load_plugin
def test_load_plugin():
    assert not get_workbench().get_option(_OPTION_NAME)
    assert get_workbench().get_variable(_OPTION_NAME).get() == False

# Generated at 2022-06-22 15:34:37.301702
# Unit test for function update_environment
def test_update_environment():
    from unittest import mock
    from thonny.globals import get_workbench
    get_workbench().in_simple_mode = mock.Mock(return_value=True)
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().in_simple_mode.return_value = False
    get_workbench().get_option = mock.Mock(return_value=True)
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 15:34:48.812105
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_option("run.python_path", "/usr/bin/python3")
    get_workbench().set_option("run.pygame_zero_path", "/usr/bin/pgzrun")
    get_workbench().set_option("run.python_exe_envvar_key", "PYTHON")
    get_workbench().set_option("run.python_exe", None)
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "true"

# Generated at 2022-06-22 15:34:52.283443
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench

    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)

    assert os.environ.get("PGZERO_MODE") == "False"

    wb.set_option(_OPTION_NAME, True)
    assert os.environ.get("PGZERO_MODE") == "True"

# Generated at 2022-06-22 15:34:58.023071
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) != True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) != True



# Generated at 2022-06-22 15:35:01.182277
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == True


# Generated at 2022-06-22 15:35:09.321649
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    if "PGZERO_MODE" not in os.environ:
        os.environ["PGZERO_MODE"] = "False"
    try:
        # test #1
        toggle_variable()
        assert os.environ["PGZERO_MODE"] == "True"
        assert wb.get_variable(_OPTION_NAME).get() == True
        # test #2
        toggle_variable()
        assert os.environ["PGZERO_MODE"] == "False"
        assert wb.get_variable(_OPTION_NAME).get() == False
    finally:
        os.environ["PGZERO_MODE"] = "False"
        toggle_variable()


# Generated at 2022-06-22 15:35:18.577148
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = "auto"

    get_workbench().set_default(_OPTION_NAME, True)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"

    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"




# Generated at 2022-06-22 15:35:21.892302
# Unit test for function load_plugin
def test_load_plugin():
    wb = SimpleWorkbench()
    wb.register_default(_OPTION_NAME, False)
    wb.register_command(
        "toggle_pgzero_mode",
        "run",
        lambda: True,
        flag_name=_OPTION_NAME,
        group=40,
    )
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-22 15:36:16.205922
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, True)

    # Test default value
    assert get_workbench().get_variable(_OPTION_NAME).get() is True
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() is False
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() is True

    # Test command get_status
    assert get_workbench().get_command("toggle_pgzero_mode").get_status() == "enabled"
    toggle_variable()
    assert get_workbench().get_command("toggle_pgzero_mode").get_status() == "enabled"

    # Test command get_label
    assert get_workbench().get_command("toggle_pgzero_mode").get_label() == tr

# Generated at 2022-06-22 15:36:23.763438
# Unit test for function load_plugin
def test_load_plugin():
    main_window = Mock(get_variable=lambda name: MagicMock(get=lambda: None, set=None))
    get_workbench = MagicMock(return_value=main_window)

    old_get_workbench = thonny.get_workbench
    thonny.get_workbench = get_workbench
    old_os_env = dict(os.environ)
    load_plugin()
    thonny.get_workbench = old_get_workbench
    os.environ = old_os_env

    # Tests
    assert not get_workbench().get_option(_OPTION_NAME)
    assert get_workbench().get_variable(_OPTION_NAME)
    assert get_workbench().in_simple_mode() == False

# Generated at 2022-06-22 15:36:27.928413
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny import get_workbench

    var = get_workbench().get_variable(_OPTION_NAME)
    var.set(False)
    toggle_variable()
    assert var.get() == True
    toggle_variable()
    assert var.get() == False

# Generated at 2022-06-22 15:36:38.253497
# Unit test for function toggle_variable
def test_toggle_variable():
    # initialize for test.
    os.environ["PGZERO_MODE"] = "False"
    assert os.environ["PGZERO_MODE"] == "False"

    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"

    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"

    # initialize for test.
    os.environ["PGZERO_MODE"] = "1"
    assert os.environ["PGZERO_MODE"] == "1"

    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"

    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 15:36:45.215086
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.globals import get_workbench
    from thonny.globals import get_runner
    get_workbench().set_backend("TkAgg")
    get_runner().load_helpers()
    # test for initial value of false
    assert(get_workbench().in_simple_mode() == False)
    # test for toggling to true
    toggle_variable()
    assert(get_workbench().in_simple_mode() == True)
    # test after toggling to false
    toggle_variable()
    assert(get_workbench().in_simple_mode() == False)

# Generated at 2022-06-22 15:36:49.096386
# Unit test for function toggle_variable
def test_toggle_variable():
    # Remove "PGZERO_MODE" from environment to make sure it isn't set
    if "PGZERO_MODE" in os.environ:
        del os.environ["PGZERO_MODE"]
    # Make sure it wasn't set
    assert "PGZERO_MODE" not in os.environ
    # Turn PGZero mode on
    toggle_variable()
    # Check that PGZERO_MODE has been set globally to "True"
    assert os.environ["PGZERO_MODE"] == "True"
    # Turn PGZero mode off again
    toggle_variable()
    # Check that PGZERO_MODE has been set globally to "False"
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 15:36:51.778226
# Unit test for function load_plugin
def test_load_plugin():
    # prepare test
    wb = get_workbench()
    assert not _OPTIO

# Generated at 2022-06-22 15:36:52.337212
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()

# Generated at 2022-06-22 15:36:57.480890
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()

    wb.set_option(_OPTION_NAME, True)
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == False

    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == True

# Generated at 2022-06-22 15:37:04.643333
# Unit test for function update_environment
def test_update_environment():
    wb = MagicMock()
    wb.get_option = lambda name: False
    wb.in_simple_mode = lambda: False
    with patch.object(thonny, 'get_workbench', return_value=wb):
        update_environment()
        assert os.environ["PGZERO_MODE"] == 'False'

    wb.get_option = lambda name: True
    wb.in_simple_mode = lambda: False
    with patch.object(thonny, 'get_workbench', return_value=wb):
        update_environment()
        assert os.environ["PGZERO_MODE"] == 'True'

    wb.get_option = lambda name: False
    wb.in_simple_mode = lambda: True