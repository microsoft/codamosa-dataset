

# Generated at 2022-06-22 15:27:58.133784
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_option("run.pgzero_mode", True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    wb.set_option("run.pgzero_mode", False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 15:28:00.823140
# Unit test for function load_plugin
def test_load_plugin():
    wb = Tk()
    wb.load_plugin(load_plugin)
    assert wb.get_variable(_OPTION_NAME).get() == False
    assert os.environ.get("PGZERO_MODE") == "False"

# Generated at 2022-06-22 15:28:07.400157
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from unittest.mock import Mock
    workbench = Workbench()
    workbench.get_editor = Mock()
    workbench.get_editor().get_option = Mock(return_value=True)
    load_plugin()
    assert get_workbench().get_variable(_OPTION_NAME).get() == False

# Generated at 2022-06-22 15:28:14.010464
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import MagicMock
    from thonny import get_workbench

    workbench = get_workbench()
    old_get_workbench = get_workbench
    get_workbench = MagicMock(return_value=workbench)
    workbench.in_simple_mode = MagicMock(return_value=False)
    workbench.get_option = MagicMock(return_value=True)
    os.environ = {}

    update_environment()

    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench = old_get_workbench

# Generated at 2022-06-22 15:28:26.173346
# Unit test for function toggle_variable
def test_toggle_variable():

    from thonny import get_workbench
    from tkinter import Tk

    root = Tk()
    get_workbench().set_variable(_OPTION_NAME, False)
    # User toggle pgzero mode
    toggle_variable()
    # Check if option is set to True
    result = get_workbench().get_option(_OPTION_NAME)
    assert result == True
    # User toggle pgzero mode
    toggle_variable()
    # Check if option is set to False
    result = get_workbench().get_option(_OPTION_NAME)
    assert result == False

    root.quit()


# Generated at 2022-06-22 15:28:33.712237
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from unittest.mock import MagicMock
    wb = Workbench()
    wb.get_option = MagicMock(return_value=True)
    os.environ["PGZERO_MODE"] = "0"
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"

# Generated at 2022-06-22 15:28:48.401305
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    load_plugin()
    assert len(wb.get_variable(_OPTION_NAME).trace_variable("write")) == 1
    assert len(wb.get_variable(_OPTION_NAME).trace_variable("read")) == 1
    assert bool(get_workbench().get_option(_OPTION_NAME)) is False
    get_workbench().set_option(_OPTION_NAME, True)
    assert bool(get_workbench().get_option(_OPTION_NAME)) is True
    assert os.environ["PGZERO_MODE"] == "1"
    get_workbench().set_in_simple_mode(True)
    assert os.environ["PGZERO_MODE"] == "auto"



# Generated at 2022-06-22 15:28:59.071420
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = "False"
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_default(_OPTION_NAME, True)
    get_workbench().set_simple_mode(True)
    update_environment()

# Generated at 2022-06-22 15:29:03.566941
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import Mock

    wb = Mock(get_variable=Mock(return_value=Mock(get=Mock(return_value=True))))
    wb.in_simple_mode = Mock(return_value=False)

    os.environ["PGZERO_MODE"] = "FALSE"
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    wb.in_simple_mode.return_value = True
    update_environm

# Generated at 2022-06-22 15:29:04.126137
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()

# Generated at 2022-06-22 15:29:16.867457
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert "PGZERO_MODE" not in os.environ
    wb.set_default(_OPTION_NAME, True)
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"

test_load_plugin()

# Generated at 2022-06-22 15:29:21.252245
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny import get_workbench

    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get()
    toggle_variable()
    assert not get_workbench().get_variable(_OPTION_NAME).get()
    toggle_variable()

# Generated at 2022-06-22 15:29:30.907715
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    get_workbench = lambda: Workbench()
    import thonny
    thonny.workbench = get_workbench
    from thonny.plugins.pgzero_panel import load_plugin
    from unittest.mock import MagicMock
    from thonny.workbench import Workbench
    wb = Workbench()
    wb.set_default = MagicMock()
    wb.add_command = MagicMock()
    load_plugin()
    wb.set_default.assert_called()
    wb.add_command.assert_called()

# Generated at 2022-06-22 15:29:41.189454
# Unit test for function update_environment
def test_update_environment():
    import os
    import thonny.globals
    from thonny.workbench import Workbench
    os.environ["PGZERO_MODE"] = "auto"
    wb = Workbench(config={}, simple_mode=False)
    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "true"
    wb.set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "false"
    wb = Workbench(config={}, simple_mode=True)
    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    w

# Generated at 2022-06-22 15:29:44.401218
# Unit test for function toggle_variable
def test_toggle_variable():
    load_plugin()
    saved_value = get_workbench().get_option("run.pgzero_mode")
    toggle_variable()
    new_value = get_workbench().get_option("run.pgzero_mode")
    assert saved_value != new_value
    assert new_value == True

# Generated at 2022-06-22 15:29:50.994391
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    assert wb.get_variable(_OPTION_NAME).get() is False
    assert os.environ.get("PGZERO_MODE") is None
    
    load_plugin()
    assert wb.get_variable(_OPTION_NAME).get() is False
    assert os.environ.get("PGZERO_MODE") == "False"
    
    toggle_variable()
    assert wb.get_variable(_OPTION_NAME).get() is True
    assert os.environ.get("PGZERO_MODE") == "True"

# Generated at 2022-06-22 15:29:55.453254
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_option(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-22 15:30:04.074816
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().clear_commands()
    get_workbench().vars.pop(_OPTION_NAME, None)
    load_plugin()
    assert get_workbench().get_default(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().get_variable(_OPTION_NAME).set(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    # get_workbench().in_simple_mode = lambda: True  # fake simple mode
    # update_environment()
    # assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 15:30:08.851937
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    assert not get_workbench().get_variable(_OPTION_NAME).get()
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get()
    toggle_variable()
    assert not get_workbench().get_variable(_OPTION_NAME).get()


# Generated at 2022-06-22 15:30:10.102117
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()

# Generated at 2022-06-22 15:30:30.289396
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench

    get_workbench().add_command = Mock()
    get_workbench().set_default = Mock()

    load_plugin()
    get_workbench().add_command.assert_called_once_with(
        "toggle_pgzero_mode",
        "run",
        "Pygame Zero mode",
        toggle_variable,
        flag_name="run.pgzero_mode",
        group=40,
    )
    get_workbench().set_default.assert_called_once_with("run.pgzero_mode", False)
    assert os.environ["PGZERO_MODE"] == "False"



# Generated at 2022-06-22 15:30:34.525001
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import workbench

    workbench.clear_test_data()

    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) is False
    get_workbench().set_option(_OPTION_NAME, True)
    assert get_workbench().get_option(_OPTION_NAME) is True



# Generated at 2022-06-22 15:30:45.755172
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.globals import get_workbench
    from thonny.config import get_user_config_dir
    from thonny.languages import tr

    assert os.getenv("PGZERO_MODE") == "auto" #  This is the initial state

    get_workbench().clear_variables()

    # Now we check that we can toggle the PGZERO_MODE
    toggle_variable()
    assert get_workbench().in_simple_mode() is False
    assert get_workbench().get_variable(_OPTION_NAME) is True
    assert os.getenv("PGZERO_MODE") == "True"

    # And that we can turn it off again
    toggle_variable()
    assert get_workbench().in_simple_mode() is False

# Generated at 2022-06-22 15:30:52.419902
# Unit test for function toggle_variable
def test_toggle_variable():
    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == True
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == False



# Generated at 2022-06-22 15:30:59.775398
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench, running
    from thonny.config_ui import ConfigurationPage
    from thonny.globals import get_runner
    import pygame_zero.runner
    import pgzero

    wb = get_workbench()
    wb.set_default("simple_mode", False)
    get_runner().stop_program()
    pgzero.runner.shutdown()
    load_plugin()
    assert len(ConfigurationPage.get_category("Run").get_children()) == 1
    assert wb.get_option("run.pgzero_mode") is False
    assert "PGZERO_MODE" in os.environ
    assert os.environ["PGZERO_MODE"] == "False"

    # change setting
    wb.set_option("run.pgzero_mode", True)

# Generated at 2022-06-22 15:31:09.979325
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    assert not wb.get_option(_OPTION_NAME)
    assert "PGZERO_MODE" not in os.environ
    load_plugin()
    assert wb.get_option(_OPTION_NAME) is False
    assert os.environ["PGZERO_MODE"] == "0"
    wb.set_simple_mode(True)
    assert os.environ["PGZERO_MODE"] == "auto"
    wb.set_simple_mode(False)
    assert os.environ["PGZERO_MODE"] == "0"
    wb.set_option(_OPTION_NAME, True)
    assert os.environ["PGZERO_MODE"] == "1"


if __name__ == "__main__":
    test_load_plugin()

# Generated at 2022-06-22 15:31:18.663339
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.workbench import Workbench
    from tkinter import Tk
    from tkinter import PhotoImage
    from tkinter import Button
    # Some dummy code so the test won't run witout
    # the normal Thonny application loaded
    root = Tk()
    root.withdraw()
    Workbench(root)
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    # Make sure it's set correctly to start
    assert wb.get_option(_OPTION_NAME) == False
    # Now toggle the option, and make sure it updated
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == True
    # Toggle again, and make sure the update takes
    toggle_variable()
    assert wb.get_option

# Generated at 2022-06-22 15:31:27.348721
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = "1"
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"
    
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"

# Generated at 2022-06-22 15:31:33.072184
# Unit test for function toggle_variable
def test_toggle_variable():
    old_env = os.environ.copy()

    try:
        toggle_variable()
        assert os.environ["PGZERO_MODE"] == "1"

        toggle_variable()
        assert os.environ["PGZERO_MODE"] == "0"
    finally:
        os.environ.clear()
        os.environ.update(old_env)



# Generated at 2022-06-22 15:31:38.886588
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import workbench
    from thonny.language_db import get_translation
    from thonny.plugins import load_plugin

    _create_workbench(with_modes=True)
    load_plugin("pgzero")

    assert workbench.in_simple_mode() == False
    assert workbench.get_variable(_OPTION_NAME) is not None
    assert workbench.get_option(_OPTION_NAME) == False

    assert workbench.get_command("toggle_pgzero_mode") is not None
    assert get_translation("Menu")['toggle_pgzero_mode'] is not None
    assert workbench.get_command("toggle_pgzero_mode").short_desc is not None



# Generated at 2022-06-22 15:32:10.028272
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import Mock
    wb = Mock()

    wb.get_option.side_effect = [False, True]
    wb.in_simple_mode.side_effect = [True, False]

    os.environ["PGZERO_MODE"] = "auto"
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"

    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"

    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"

# Generated at 2022-06-22 15:32:17.323189
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.destroy()
    wb.create("BareBonesWorkbench")
    load_plugin()
    assert wb.get_variable(_OPTION_NAME).get() == False
    os.environ["PGZERO_MODE"]
    wb.set_option("run.pgzero_mode", True)
    update_environment()
    assert os.environ["PGZERO_MODE"]=="True"

# Generated at 2022-06-22 15:32:20.220284
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == False

if __name__ == "__main__":
    load_plugin()

# Generated at 2022-06-22 15:32:27.759894
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, None)
    assert _OPTION_NAME not in wb.get_defaults()
    wb.set_default(_OPTION_NAME, False)
    assert _OPTION_NAME in wb.get_defaults()
    assert not wb.get_option(_OPTION_NAME)
    wb.set_option(_OPTION_NAME, True)
    assert wb.get_option(_OPTION_NAME)
    wb.set_option(_OPTION_NAME, False)
    assert not wb.get_option(_OPTION_NAME)



# Generated at 2022-06-22 15:32:34.896833
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().unset_default(_OPTION_NAME)
    assert "PGZERO_MODE" not in os.environ
    load_plugin()
    get_workbench().set_option(_OPTION_NAME, False)
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_option(_OPTION_NAME, True)
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().disable_simple_mode()
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().enable_simple_mode()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 15:32:40.369511
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) is False
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) is True
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) is False
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().in_simple_mode = lambda: True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 15:32:41.949347
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert get_workbench().get_variable(_OPTION_NAME).get() is False

# Generated at 2022-06-22 15:32:49.859799
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.plugins.background_program import get_command_state
    from unittest import mock
    from thonny import workbench

    with mock.patch("os.environ", {}), mock.patch.object(
        workbench.get_option(_OPTION_NAME), "set"
    ) as mock_set:
        load_plugin()

    assert get_command_state() == ["pgzero_mode_on"]
    assert mock_set.called



# Generated at 2022-06-22 15:32:58.293995
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny import get_workbench, options_view
    from thonny.ui_utils import clear_text
    from unittest import mock
    import textwrap

    get_workbench().create()
    get_workbench().set_default(_OPTION_NAME, False)
    assert get_workbench().get_variable(_OPTION_NAME).get() is False
    get_workbench().set_default(_OPTION_NAME, True)
    assert get_workbench().get_variable(_OPTION_NAME).get() is True
    get_workbench().set_default(_OPTION_NAME, False)
    assert get_workbench().get_variable(_OPTION_NAME).get() is False



# Generated at 2022-06-22 15:33:02.400785
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_option("run.pgzero_mode", False)
    toggle_variable()
    assert get_workbench().get_option("run.pgzero_mode")
    toggle_variable()
    assert not get_workbench().get_option("run.pgzero_mode")

# Generated at 2022-06-22 15:33:56.795436
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME)


if __name__ == "__main__":
    # Running from Thonny
    from thonny.plugins.pgzero_mode.pgzero_mode import (
        test_toggle_variable,
        toggle_variable,
    )
    test_toggle_variable()

# Generated at 2022-06-22 15:33:58.645340
# Unit test for function update_environment
def test_update_environment():

    assert os.environ["PGZERO_MODE"]=='auto'

# Generated at 2022-06-22 15:34:00.218836
# Unit test for function toggle_variable

# Generated at 2022-06-22 15:34:05.119478
# Unit test for function load_plugin
def test_load_plugin():
    from unittest import mock
    import thonny
    import thonny.workbench

    with mock.patch.object(thonny.workbench, "set_default") as m_set_default:
        with mock.patch.object(thonny.workbench, "add_command") as m_add_command:
            load_plugin()

        m_set_default.assert_called_with(_OPTION_NAME, False)
        m_add_command.assert_called_once()

# Generated at 2022-06-22 15:34:11.571027
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench
    from thonny.common import TESTS_DIR
    from thonny.misc_utils import running_on_mac_os
    from thonny.plugins.pgzo_mode import load_plugin
    from thonny.plugins.pgzo_mode import toggle_variable
    from thonny.plugins.pgzo_mode import update_environment
    from thonny.plugins.pgzo_mode import _OPTION_NAME
    from thonny.languages import select_locale
    from thonny.languages import normalize_language
    from thonny.workbench import Workbench

    # Initialize workbench with default configurations for testing
    get_workbench().get_option(_OPTION_NAME)
    get_workbench().set_default(_OPTION_NAME, False)


# Generated at 2022-06-22 15:34:20.581699
# Unit test for function load_plugin
def test_load_plugin():
    assert "PGZERO_MODE" not in os.environ
    from thonny.globals import get_workbench
    from thonny.misc_utils import running_on_mac_os
    from thonny import THONNY_USER_DIR
    from thonny.memory import init_configuration
    from thonny.plugins.run.run_configuration import RunConfiguration
    from tkinter import Tk
    import shutil

    workbench = get_workbench()
    workbench.set_default("run.pgzero_mode", True)

    if running_on_mac_os():
        shutil.rmtree(THONNY_USER_DIR)
        init_configuration()

    root = Tk()

    root.after(100, root.destroy)
    root.mainloop()

    load

# Generated at 2022-06-22 15:34:24.162032
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    wb.set_simple_mode(True)
    wb.set_simple_mode(False)
    assert wb.get_option(_OPTION_NAME) is False
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) is True
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) is False

    wb.set_simple_mode(True)
    assert wb.get_variable("PGZERO_MODE").get() == "auto"

if __name__ == "__main__":
    test_toggle_variable()

# Generated at 2022-06-22 15:34:29.990606
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import Mock
    wb_mock = Mock()
    wb_mock.get_option.return_value = 'True'
    wb_mock.in_simple_mode.return_value = True
    get_workbench(wb_mock)
    update_environment()
    assert os.environ["PGZERO_MODE"] == 'True'

    wb_mock.get_option.return_value = 'False'
    wb_mock.in_simple_mode.return_value = False
    update_environment()
    assert os.environ["PGZERO_MODE"] == 'False'

    wb_mock.in_simple_mode.return_value = True
    update_environment()
    assert os.environ["PGZERO_MODE"] == 'False'

# Generated at 2022-06-22 15:34:34.258564
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert not get_workbench().get_option(_OPTION_NAME)
    assert os.environ["PGZERO_MODE"] == str(get_workbench().get_option(_OPTION_NAME))

# Generated at 2022-06-22 15:34:41.666291
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    assert not os.environ.get("PGZERO_MODE")
    load_plugin()

    # default
    assert os.environ["PGZERO_MODE"] == "False"

    # toggle to on
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"

    # toggle to off and simple mode
    toggle_variable()
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    # toggle to on and simple mode
    toggle_variable()
    get_workbench().set_simple_mode(True)
    update_environment()

# Generated at 2022-06-22 15:35:35.681131
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench
    from unittest.mock import patch

    with patch.dict(os.environ, {}, clear=True):
        get_workbench().set_default(_OPTION_NAME, False)
        update_environment()
        assert os.environ["PGZERO_MODE"] == "False"

    with patch.dict(os.environ, {}, clear=True):
        get_workbench().set_default(_OPTION_NAME, True)
        update_environment()
        assert os.environ["PGZERO_MODE"] == "True"

    with patch.dict(os.environ, {}, clear=True):
        get_workbench().in_simple_mode = True
        update_environment()
        assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 15:35:42.939249
# Unit test for function load_plugin
def test_load_plugin():
    # save old environment
    old_env_pgzero = os.environ.get('PGZERO_MODE', None)

    # Create workbench and its variables
    class MockWorkbench():
        def __init__(self):
            self._variables = {}

        def get_variable(self, name):
            return self._variables.get(name)
        
        def set_default(self, name, value):
            self._variables[name] = value

    workbench = MockWorkbench()

    # test for automatic mode
    os.environ['THONNY_PGZERO_MODE'] = 'True'

    load_plugin()
    assert workbench.get_variable('run.pgzero_mode') == True
    assert os.environ.get('PGZERO_MODE', None) == 'auto'

    # restore

# Generated at 2022-06-22 15:35:52.122872
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import Mock
    from thonny.globals import get_workbench

    wb = Mock()
    wb.in_simple_mode = lambda: False
    wb.get_option = lambda arg: False
    wb.get_variable = lambda arg: False
    wb.get_option = lambda arg: False
    wb.get_variable = lambda arg: False
    wb.in_simple_mode = lambda: False
    wb.get_option = lambda arg: True

    with get_workbench():
        old_wb = get_workbench()
        get_workbench().set_default(_OPTION_NAME, False)

# Generated at 2022-06-22 15:35:57.517529
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_simple_mode(True)
    load_plugin()
    update_environment()
    assert os.environ['PGZERO_MODE'] == 'auto'

    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ['PGZERO_MODE'] == 'True'

# Generated at 2022-06-22 15:36:01.455403
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert get_workbench().in_simple_mode() is False
    assert get_workbench().get_option("run.pgzero_mode") is False
    assert os.environ["PGZERO_MODE"] == "False"



# Generated at 2022-06-22 15:36:08.083918
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench

    wb = Workbench()
    load_plugin()
    assert _OPTION_NAME in wb.get_variables()
    assert "PGZERO_MODE" not in os.environ
    assert not wb.in_simple_mode()
    wb.bind("<<SimpleModeToggled>>", update_environment, "+")
    assert wb.get_variable(_OPTION_NAME).get() is False
    assert os.environ["PGZERO_MODE"] == "False"

    wb.enter_simple_mode()
    assert os.environ["PGZERO_MODE"] == "auto"
    wb.leave_simple_mode()
    assert os.environ["PGZERO_MODE"] == "False"


# Generated at 2022-06-22 15:36:15.390826
# Unit test for function load_plugin
def test_load_plugin():
    original_mode = get_workbench().in_simple_mode()
    get_workbench().set_simple_mode(True)

    try:
        if _OPTION_NAME in os.environ:
            del os.environ[_OPTION_NAME]

        load_plugin()
        assert not get_workbench().get_option(_OPTION_NAME)
        assert _OPTION_NAME in get_workbench().get_available_commands()
        assert get_workbench().in_simple_mode()
        toggle_variable()
        assert get_workbench().get_option(_OPTION_NAME)
    finally:
        get_workbench().set_simple_mode(original_mode)

# Generated at 2022-06-22 15:36:22.449149
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ.get("PGZERO_MODE") == "auto"

# Generated at 2022-06-22 15:36:27.228269
# Unit test for function update_environment
def test_update_environment():
    os.environ.clear()
    update_environment()
    get_workbench().set_option(_OPTION_NAME, False)
    assert os.environ["PGZERO_MODE"] == "0"
    get_workbench().set_option(_OPTION_NAME, True)
    assert os.environ["PGZERO_MODE"] == "1"

# Generated at 2022-06-22 15:36:30.976986
# Unit test for function update_environment
def test_update_environment():
    workbench = get_workbench()
    workbench.set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    workbench.set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    workbench.set_simple_mode(True)
    workbench.set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"