

# Generated at 2022-06-22 15:26:42.834050
# Unit test for function update_environment
def test_update_environment():
    with tempfile.TemporaryDirectory() as thonny_user_dir:
        with mock.patch("thonny.workbench.Workbench.get_user_directory",
                        lambda: thonny_user_dir):
            get_workbench().set_default(_OPTION_NAME, False)
            assert os.environ["PGZERO_MODE"] == "False"

            get_workbench().set_option(_OPTION_NAME, True)
            assert os.environ["PGZERO_MODE"] == "True"

            get_workbench().set_option(_OPTION_NAME, False)
            assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 15:26:46.692281
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 15:27:00.482165
# Unit test for function update_environment
def test_update_environment():
    """Calling update_environment() sets an environment variable PGZERO_MODE.

    This variable is used by pgzero.runner to decide whether to enable or disable
    the Pygame Zero mode.

    This unit test verifies that the correct value of this variable is set
    depending on the current Thonny's mode and the plugin's option.
    """
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    wb.set_simple_mode(False)
    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    wb

# Generated at 2022-06-22 15:27:06.679216
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()

# Generated at 2022-06-22 15:27:13.622059
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench
    from thonny.misc_utils import running_on_mac_os
    workbench = get_workbench()

    workbench.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    workbench.set_simple_mode(False)
    workbench.set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"

    workbench.set_simple_mode(False)
    workbench.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"

    get_workbench().set_simple_mode(False)
    get

# Generated at 2022-06-22 15:27:28.488341
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import MagicMock

    workbench = MagicMock()
    workbench.in_simple_mode.return_value = True
    workbench.get_variable.return_value = MagicMock(get=lambda: True)
    with patch.object(sys, "modules", {"thonny": MagicMock(get_workbench=lambda: workbench)}):
        update_environment()
        assert "PGZERO_MODE" in os.environ
        assert os.environ["PGZERO_MODE"] == "auto"

    workbench.in_simple_mode.return_value = False
    with patch.object(sys, "modules", {"thonny": MagicMock(get_workbench=lambda: workbench)}):
        update_environment()
        assert "PGZERO_MODE" in os.en

# Generated at 2022-06-22 15:27:36.936460
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_option(_OPTION_NAME, True)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 15:27:46.930805
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    toggle_variable()
    assert wb.get_variable(_OPTION_NAME)
    assert wb.get_option(_OPTION_NAME)
    assert os.getenv("PGZERO_MODE") == "True"
    toggle_variable()
    assert not wb.get_variable(_OPTION_NAME)
    assert not wb.get_option(_OPTION_NAME)
    assert os.getenv("PGZERO_MODE") == "False"


# Generated at 2022-06-22 15:27:55.563003
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.globals import get_runner
    from unittest.mock import patch
    from thonny.options_page import disable_relaunch_required_notification
    from thonny.workbench import Workbench
    from thonny.plugins.pgzero_mode import (
        toggle_variable,
        _OPTION_NAME,
    )
    from thonny.languages import tr

    def mock_get_workbench(self):
        wb = Workbench()
        wb.set_default(_OPTION_NAME, False)
        return wb

    with patch.object(get_runner(), "get_workbench", mock_get_workbench):
        # Start the first test
        toggle_variable()
        # Check if the value has toggled to True
        assert get_workbench().get

# Generated at 2022-06-22 15:28:00.139230
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    test_update_environment()

    

# Generated at 2022-06-22 15:28:12.061692
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

if __name__ == "__main__":
    test_update_environment()

# Generated at 2022-06-22 15:28:26.173375
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock
    from thonny import get_workbench

    wb = get_workbench()
    wb.set_default = Mock()
    wb.add_command = Mock()
    load_plugin()

    assert wb.set_default.call_args[0][0] == _OPTION_NAME
    assert wb.add_command.call_args[0][0] == "toggle_pgzero_mode"
    assert wb.add_command.call_args[1]["flag_name"] == _OPTION_NAME
    assert wb.add_command.call_args[1]["group"] == 40

# Generated at 2022-06-22 15:28:38.644967
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = "auto"
    get_workbench().set_in_simple_mode(True)
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().set_in_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"

    get_workbench().set_in_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"

# Generated at 2022-06-22 15:28:50.507421
# Unit test for function update_environment
def test_update_environment():
    os.environ.pop("PGZERO_MODE", None)
    assert "PGZERO_MODE" not in os.environ

    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"

    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"

    get_work

# Generated at 2022-06-22 15:28:59.871915
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock

    wb_mock = Mock()
    wb_mock.in_simple_mode = Mock(return_value=True)
    wb_mock.get_option = Mock(return_value=False)
    wb_mock.get_variable = Mock()

    get_workbench.return_value = wb_mock
    load_plugin()

    wb_mock.get_variable.assert_called_once_with(_OPTION_NAME)
    wb_mock.get_variable().set.assert_called_once_with(False)

    wb_mock.in_simple_mode.assert_called_once()
    wb_mock.get_option.assert_called_once_with(_OPTION_NAME)


# Generated at 2022-06-22 15:29:03.820981
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_option("run.pgzero_mode", True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 15:29:14.065165
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_simple_mode()

    load_plugin()
    assert wb.get_default(_OPTION_NAME) == False
    assert wb.get_command("toggle_pgzero_mode")
    load_plugin()
    assert wb.get_command("toggle_pgzero_mode")
    load_plugin()
    assert wb.get_command("toggle_pgzero_mode")
    load_plugin()
    assert wb.get_command("toggle_pgzero_mode")
    load_plugin()
    assert wb.get_command("toggle_pgzero_mode")

if __name__ == "__main__":
    test_load_plugin()

# Generated at 2022-06-22 15:29:17.133824
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench

    load_plugin()
    assert "toggle_pgzero_mode" in get_workbench().commands


load_plugin()

# Generated at 2022-06-22 15:29:26.602066
# Unit test for function update_environment
def test_update_environment():
    # Note:
    # - test_environment_variable_creation is also needed for this to work
    # - I probably should use mock.patch, but get_workbench() is missing stubs
    # - this test is needed because it's important that the environment variable
    #   is set in all the right places,
    #   and it's not easy to test that manually

    # assert that it is unset when nothing is done
    assert "PGZERO_MODE" not in os.environ

    # assert that it is unset when in simple mode
    get_workbench().in_simple_mode = lambda: True
    update_environment()
    assert "PGZERO_MODE" not in os.environ

    # assert that it is set when in simple mode
    get_workbench().in_simple_mode = lambda: False
    get_workbench

# Generated at 2022-06-22 15:29:32.597825
# Unit test for function update_environment
def test_update_environment():

    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 15:29:45.487212
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()

# Generated at 2022-06-22 15:29:50.048589
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, True)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False
    
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True


if __name__ == "__main__":
    load_plugin()

# Generated at 2022-06-22 15:29:58.670212
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = ""
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 15:30:10.499662
# Unit test for function update_environment
def test_update_environment():
    assert os.environ.get("PGZERO_MODE") == "auto"
    os.environ["PGZERO_MODE"] = "original_value"

    get_workbench().in_simple_mode = lambda: False
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ.get("PGZERO_MODE") == "True"

    os.environ["PGZERO_MODE"] = "auto"
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ.get("PGZERO_MODE") == "False"

    os.environ["PGZERO_MODE"] = "auto"
    get_workbench().in_simple_mode = lambda: True

# Generated at 2022-06-22 15:30:23.165874
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock, patch
    from thonny.workbench import Workbench

    mock_get_editor = Mock(name="get_editor")
    mock_get_editor.return_value = Mock(name="Editor")
    mock_add_command = Mock(name="add_command")

    with patch("thonny.plugins.pgzero_mode.get_workbench", return_value=Mock(spec=Workbench)):
        with patch("thonny.plugins.pgzero_mode.get_editor", mock_get_editor):
            with patch("thonny.plugins.pgzero_mode.add_command", mock_add_command):
                load_plugin()

    assert os.environ["PGZERO_MODE"] == "False"

    # Ensure the toggle command has been added
    mock_get

# Generated at 2022-06-22 15:30:32.045277
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_simple_mode(True)
    if "PGZERO_MODE" in os.environ:
        del os.environ["PGZERO_MODE"]
    load_plugin()
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_simple_mode(False)
    load_plugin()
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 15:30:34.399531
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_option("run.pgzero_mode",False)
    toggle_variable()
    assert get_workbench().get_option("run.pgzero_mode") == True

# Generated at 2022-06-22 15:30:45.725120
# Unit test for function update_environment
def test_update_environment():
    # Clean up environment
    os.environ.pop("PGZERO_MODE", None)

    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"

    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"

    get_workbench().set_option(_OPTION_NAME, "auto")
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().set_option(_OPTION_NAME, "")
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().set

# Generated at 2022-06-22 15:30:57.040635
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from unittest.mock import MagicMock
    from unittest.mock import patch

    wb = Workbench()
    wb.set_simple_mode = MagicMock()

    # Test when workbench is in Simple Mode
    os.environ["THONNY_GUI_MODE"] = "simple"
    wb.in_simple_mode = MagicMock(return_value=True)

    update_environment()

    assert os.environ["PGZERO_MODE"] == "auto"

    # Test when workbench is NOT in Simple Mode
    os.environ["THONNY_GUI_MODE"] = "normal"
    wb.in_simple_mode = MagicMock(return_value=False)

# Generated at 2022-06-22 15:31:01.623136
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, True)
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME)
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    assert not get_workbench().get_option(_OPTION_NAME)



# Generated at 2022-06-22 15:31:27.919807
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()

    assert get_workbench().get_variable(_OPTION_NAME).get() == True

    toggle_variable()

    assert get_workbench().get_variable(_OPTION_NAME).get() == False

# Generated at 2022-06-22 15:31:33.974319
# Unit test for function update_environment
def test_update_environment():
    assert os.environ.get("PGZERO_MODE") is None

    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ.get("PGZERO_MODE") == "False"

    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ.get("PGZERO_MODE") == "True"

# Generated at 2022-06-22 15:31:42.746860
# Unit test for function update_environment
def test_update_environment():
    import thonny
    import os
    import sys

    os.environ["PGZERO_MODE"] = "auto"

    # PGZERO_MODE should not be set when in simple mode
    thonny.get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    # PGZERO_MODE should be set when in normal mode and user disabled PGZERO_MODE
    os.environ["PGZERO_MODE"] = "auto"
    thonny.get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    # PGZERO_MODE should

# Generated at 2022-06-22 15:31:47.138123
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny import get_workbench

    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == True
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == False

# Generated at 2022-06-22 15:31:48.822814
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert ("toggle_pgzero_mode" in get_workbench().get_commands().keys())

# Generated at 2022-06-22 15:31:56.639970
# Unit test for function toggle_variable

# Generated at 2022-06-22 15:32:02.965772
# Unit test for function toggle_variable
def test_toggle_variable():
    import unittest

    class TestToggleVariable(unittest.TestCase):
        def test_toggle_variable(self):
            toggle_variable()
            self.assertEqual(os.environ["PGZERO_MODE"], "True")
            toggle_variable()
            self.assertEqual(os.environ["PGZERO_MODE"], "False")

    # unittest.main()


# Generated at 2022-06-22 15:32:10.825079
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench

    w = Workbench()
    w.set_simple_mode(True)

    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    w.set_simple_mode(False)
    w.set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    w.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 15:32:14.187896
# Unit test for function load_plugin
def test_load_plugin():
    wb = Mock()
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()

# Generated at 2022-06-22 15:32:24.664134
# Unit test for function load_plugin
def test_load_plugin():
    _load_plugin()

    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    assert "PGZERO_MODE" not in os.environ

    # Test toggle
    get_workbench().event_generate("SimpleModeVar.set", value=False)
    os.environ["PGZERO_MODE"] = "auto"
    
    toggle_variable()
    assert "PGZERO_MODE" in os.environ
    assert os.environ["PGZERO_MODE"] == "True"
    
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"
    
    get_workbench().event_generate("SimpleModeVar.set", value=True)
    assert "PGZERO_MODE" in os.environ
    assert os.en

# Generated at 2022-06-22 15:33:22.600053
# Unit test for function update_environment
def test_update_environment():
    import os
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"

# Generated at 2022-06-22 15:33:24.019227
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()


# Generated at 2022-06-22 15:33:28.521646
# Unit test for function toggle_variable
def test_toggle_variable():
    assert get_workbench().get_option(_OPTION_NAME) == False

    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True

    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-22 15:33:32.492135
# Unit test for function toggle_variable
def test_toggle_variable():
    var = get_workbench().get_variable(_OPTION_NAME)
    var.set(False)
    toggle_variable()
    assert var.get() == True
    toggle_variable()
    assert var.get() == False



# Generated at 2022-06-22 15:33:35.692724
# Unit test for function load_plugin
def test_load_plugin():
    wb = Tk()
    wb.createcommand("load", load_plugin)
    wb.call("load", "ThonnyPGZeroMode")
    assert wb.getvar(_OPTION_NAME) == False
    wb.destroy()

# Generated at 2022-06-22 15:33:38.761246
# Unit test for function load_plugin
def test_load_plugin():
    _load_workbench()
    _load_shell()
    load_plugin()
    assert len(get_workbench().get_commands()) == 1
    assert get_workbench().get_variable(_OPTION_NAME).get() == False



# Generated at 2022-06-22 15:33:41.747015
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert get_workbench().get_variable(_OPTION_NAME).get() == False


if __name__ == "__main__":
    load_plugin()

# Generated at 2022-06-22 15:33:47.529831
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench

    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    wb.set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    wb.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    wb.set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 15:33:59.349432
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()
    try:
        assert os.environ.get("PGZERO_MODE") == "False"
        wb.get_option(_OPTION_NAME).set(True)
        assert os.environ.get("PGZERO_MODE") == "True"
        wb.get_option(_OPTION_NAME).set(False)
        assert os.environ.get("PGZERO_MODE") == "False"
    finally:
        del os

# Generated at 2022-06-22 15:34:06.372332
# Unit test for function load_plugin
def test_load_plugin():
    import unittest.mock
    wb = unittest.mock.Mock()
    wb.get_variable.return_value = True
    wb.in_simple_mode.return_value = False
    wb.get_option.side_effect = lambda name: True if name == "run.pgzero_mode" else None
    load_plugin()
    wb.set_default.assert_called_with(_OPTION_NAME, False)
    wb.add_command.assert_called()
    os.environ["PGZERO_MODE"] = "true"
    get_workbench.cache_clear()

# Generated at 2022-06-22 15:36:03.108210
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny import get_workbench
    from thonny.languages import tr
    from thonny.misc_utils import running_on_mac_os
    from thonny.ui_utils import get_dialog_master, CommonDialog
    from thonny.ui_utils import show_dialog, show_information, show_open_folder_dialog, askopenfilename
    from tkinter import filedialog
    from unittest.mock import MagicMock

    # note this test is heavily dependent on other parts of the plugin,
    # especially the 'run' module and the editor_utils module

    the_workbench = Workbench()
    the_workbench.set_default("run.pgzero_mode", False)
    the_workbench.set_simple_mode

# Generated at 2022-06-22 15:36:03.950161
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()

# Generated at 2022-06-22 15:36:08.395151
# Unit test for function update_environment
def test_update_environment():
    assert os.environ["PGZERO_MODE"] == "1"

# Generated at 2022-06-22 15:36:13.364981
# Unit test for function update_environment
def test_update_environment():
    wb = Workbench()
    wb.set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"
    wb.set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"

# Generated at 2022-06-22 15:36:14.770055
# Unit test for function load_plugin
def test_load_plugin():
    assert not get_workbench().in_simple_mode()
    lb = get_workbench().get_option(_OPTION_NAME)
    assert lb == False

# Generated at 2022-06-22 15:36:27.687073
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    load_plugin()

    # default value
    variable = wb.get_variable(_OPTION_NAME)
    assert variable.get() == False

    # set variable to True
    variable.set(True)
    assert variable.get() == True

    # update os.environ
    assert os.environ["PGZERO_MODE"] == "True"

    # set variable to False
    variable.set(False)
    assert variable.get() == False

    # update os.environ
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 15:36:38.196024
# Unit test for function toggle_variable
def test_toggle_variable():
    try:
        orig_value = os.environ["PGZERO_MODE"]
        del os.environ["PGZERO_MODE"]
    except:
        orig_value = None
    
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"
    
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    
    if orig_value is not None:
        os.environ["PGZERO_MODE"] = orig_value
    else:
        del os.environ["PGZERO_MODE"]
