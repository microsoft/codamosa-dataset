

# Generated at 2022-06-22 15:28:02.309531
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    load_plugin()
    assert get_workbench().in_simple_mode() == False
    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == True
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    os.environ["PGZERO_MODE"] = "auto"
    assert os.environ["PGZERO_MODE"] == "auto"
    load_plugin()
    assert os.environ["PGZERO_MODE"] == "auto"
    assert get_

# Generated at 2022-06-22 15:28:10.027172
# Unit test for function update_environment
def test_update_environment():
    from unittest import mock
    from thonny.workbench import Workbench
    from thonny.misc_utils import create_config_folder
    create_config_folder()
    
    get_workbench = mock.Mock()
    get_workbench.return_value = Workbench()
    
    with mock.patch('thonny.plugins.pgzero_mode.get_workbench', get_workbench):
        update_environment()
        assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 15:28:16.183851
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, True)
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == True


# Generated at 2022-06-22 15:28:27.432499
# Unit test for function update_environment
def test_update_environment():
    from test.test_runner import get_runner_class
    import unittest

    class UpdateEnvironmentTests(unittest.TestCase):
        def setUp(self):
            self.runner_class = get_runner_class("Python")
            self.runner = self.runner_class(None, None)
            self.runner._startup_env = os.environ.copy()

        def tearDown(self):
            os.environ.update(self.runner._startup_env)

        def test_disabled(self):
            os.environ["PGZERO_MODE"] = "auto"
            update_environment()
            self.assertEqual(os.environ["PGZERO_MODE"], "auto")

        def test_enabled(self):
            os.environ["PGZERO_MODE"] = "auto"


# Generated at 2022-06-22 15:28:35.956462
# Unit test for function load_plugin
def test_load_plugin():
    try:
        del os.environ["PGZERO_MODE"]
    except KeyError:
        pass

    load_plugin()
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()

    os.environ["PGZERO_MODE"] = "False"
    load_plugin()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 15:28:43.893458
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = ""
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 15:28:57.506796
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_runner
    from thonny.languages import rus
    from thonny.languages import uk
    from thonny.languages import hu
    from thonny.languages import bg
    from thonny.languages import pl
    from thonny.languages import sr

    get_workbench().set_default(_OPTION_NAME, False)
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().set_default(_OPTION_NAME, True)
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_default(_OPTION_NAME, False)
    assert os.environ["PGZERO_MODE"] == "auto"


# Generated at 2022-06-22 15:29:04.799978
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny import get_runner
    from thonny.config import get_workbench_configuration
    from thonny.globals import get_workbench
    import os

    # Initial state is False
    if not get_workbench().get_option(_OPTION_NAME):
        print("Initial state of pgzero_mode is False")
    else:
        print("Initial state of pgzero_mode is True")
        assert False

    if not os.environ["PGZERO_MODE"] == "False":
        print("PGZERO_MODE environment variable is not False")
        assert False

    get_runner().stop_running()
    toggle_variable()

    # New state is True
    if not get_workbench().get_option(_OPTION_NAME):
        print("New state of pgzero_mode is False")


# Generated at 2022-06-22 15:29:09.387605
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == True
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == False

# Generated at 2022-06-22 15:29:18.352903
# Unit test for function update_environment
def test_update_environment():
    # pylint: disable=protected-access
    from unittest import mock
    from thonny import get_runner
    from thonny.workbench import Workbench
    from thonny.common import run_module
    from thonny.plugins.pgzero_mode import update_environment

    run_module.update_environment = mock.Mock()
    wb = Workbench()
    wb._mode = "normal"
    wb._runner = get_runner.get_runner()
    wb.set_simple_mode(False)
    wb.set_option(_OPTION_NAME, True)
    update_environment()
    run_module.update_environment.assert_called_with({'PGZERO_MODE': 'True'})
    wb.set_option(_OPTION_NAME, False)
    update

# Generated at 2022-06-22 15:29:36.287898
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import Mock
    
    wb = Mock()
    wb.get_option.return_value = True
    with patch("thonny.plugins.pgzero_mode.get_workbench", return_value=wb):
        update_environment()
        assert os.environ["PGZERO_MODE"] == "True"
        
    wb.get_option.return_value = False
    with patch("thonny.plugins.pgzero_mode.get_workbench", return_value=wb):
        update_environment()
        assert os.environ["PGZERO_MODE"] == "False"
        
    wb.in_simple_mode.return_value = True
    with patch("thonny.plugins.pgzero_mode.get_workbench", return_value=wb):
        update

# Generated at 2022-06-22 15:29:43.516034
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()

# Generated at 2022-06-22 15:29:47.400641
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_option(_OPTION_NAME, False)
    toggle_variable()
    assert(get_workbench().get_option(_OPTION_NAME) == True)
    toggle_variable()
    assert (get_workbench().get_option(_OPTION_NAME) == False)

# Generated at 2022-06-22 15:29:58.568639
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.get_option(_OPTION_NAME).set(False)
    load_plugin()
    assert "PGZERO_MODE" in os.environ
    assert os.environ["PGZERO_MODE"] == "False"

    wb.get_option(_OPTION_NAME).set(True)
    load_plugin()
    assert os.environ["PGZERO_MODE"] == "True"

    wb.in_simple_mode = lambda: True
    load_plugin()
    assert os.environ["PGZERO_MODE"] == "auto"



# Generated at 2022-06-22 15:30:03.807958
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert get_workbench().get_variable("run.pgzero_mode").get() == False
    os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 15:30:12.242626
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny import get_workbench
    from thonny import environment

    # Check that the variable does not exist
    assert not get_workbench().get_variable(_OPTION_NAME)
    assert not _OPTION_NAME in environment.get_environment_variables()
    assert not os.environ["PGZERO_MODE"]

    # Check that the variable is created and initalized to True
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME)
    assert _OPTION_NAME in environment.get_environment_variables()
    assert os.environ["PGZERO_MODE"]

    # Check that the variable is toggled to False
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME)
    assert _OPTION_NAME in environment.get_

# Generated at 2022-06-22 15:30:18.994635
# Unit test for function load_plugin
def test_load_plugin():
   get_workbench().set_default(_OPTION_NAME, False)
   assert "PGZERO_MODE" not in os.environ
   load_plugin()
   assert get_workbench().get_default(_OPTION_NAME) == False
   assert "PGZERO_MODE" in os.environ
   assert os.environ["PGZERO_MODE"] == str(False)



# Generated at 2022-06-22 15:30:26.757659
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock
    from thonny import get_workbench
    from thonny.workbench import Workbench
    from thonny.languages import tr
    wb = Workbench()
    wb.in_simple_mode = Mock(return_value=True)
    wb.set_default = Mock()
    wb.add_command = Mock()
    globals()["get_workbench"] = Mock(return_value=wb)
    globals()["tr"] = Mock(return_value="translated")
    globals()["toggle_variable"] = Mock()
    globals()["update_environment"] = Mock()
    load_plugin()
    get_workbench().set_default.assert_called_with("run.pgzero_mode", False)
    get_workbench().add_command

# Generated at 2022-06-22 15:30:30.802865
# Unit test for function toggle_variable
def test_toggle_variable():
    with mock.patch.object(get_workbench(), "get_variable") as mock_variable_get:
        mock_variable_get.get.return_value = True
        toggle_variable()
        mock_variable_get.set.assert_called_with(False)


# Generated at 2022-06-22 15:30:37.690060
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    wb.set_in_simple_mode(False)
    wb.set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    wb.set_in_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    wb.set_in_simple_mode(False)
    wb.set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 15:30:58.764466
# Unit test for function update_environment
def test_update_environment():
    from thonny.common import THONNY_USER_DIR
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    os.environ.pop("PGZERO_MODE")

    os.environ["THONNY_USER_DIR"] = THONNY_USER_DIR
    load_plugin()
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_simple_

# Generated at 2022-06-22 15:31:03.814901
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    wb.change_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 15:31:08.606936
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) is False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) is True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) is False

# Generated at 2022-06-22 15:31:13.712148
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    update_environment()
    load_plugin()
    assert os.environ["PGZERO_MODE"] == "False"

    assert wb.get_variable(_OPTION_NAME).get() is False
    assert wb.find_command("toggle_pgzero_mode").flag_name == _OPTION_NAME

# Generated at 2022-06-22 15:31:20.066125
# Unit test for function update_environment
def test_update_environment():
    try:
        bkp_var = os.environ["PGZERO_MODE"]
    except:
        bkp_var = None

    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    wb = get_workbench()
    wb.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    wb.set_simple_mode(False)

    os.environ["PGZERO_MODE"] = "False"
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    os.environ["PGZERO_MODE"] = "True"
    update_environment()

# Generated at 2022-06-22 15:31:28.494375
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.workbench import Workbench
    from thonny import THONNY_USER_DIR

    workbench = Workbench()
    workbench.set_simple_mode(False)
    toggle_variable()
    assert workbench.get_option(_OPTION_NAME) == True
    toggle_variable()
    assert workbench.get_option(_OPTION_NAME) == False

# Generated at 2022-06-22 15:31:37.124299
# Unit test for function update_environment
def test_update_environment():
    import os
    import sys
    import unittest
    os.environ['PGZERO_MODE'] = ""
    get_workbench().in_simple_mode = lambda: False
    get_workbench().get_option = lambda name: False
    update_environment()
    assert os.environ['PGZERO_MODE'] == 'False'
    get_workbench().get_option = lambda name: True
    update_environment()
    assert os.environ['PGZERO_MODE'] == 'True'
    get_workbench().in_simple_mode = lambda: True
    update_environment()
    assert os.environ['PGZERO_MODE'] == 'auto'  

if __name__ == "__main__":
    import unittest
    unittest.main()

# Generated at 2022-06-22 15:31:41.241455
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, True)
    assert get_workbench().get_variable(_OPTION_NAME).get()
    toggle_variable()
    assert not get_workbench().get_variable(_OPTION_NAME).get()
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get()


# Generated at 2022-06-22 15:31:52.368640
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import workbench
    from thonny.config import Configuration
    from thonny.workbench import get_workbench
    from unittest import mock

    delete_config_file()
    wb = workbench.Workbench()
    wb.set_option("run.pgzero_mode", True)
    wb.add_command = mock.Mock()

    load_plugin()

    assert wb.add_command.call_count == 1
    wb.add_command.assert_called_once_with(
        "toggle_pgzero_mode",
        "run",
        "Pygame Zero mode",
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )

    delete_config_file()
    wb = workbench.Workbench()


# Generated at 2022-06-22 15:31:59.386157
# Unit test for function update_environment
def test_update_environment():
    get_workbench().clear_variables()
    get_workbench().set_in_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().set_in_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().get_option(_OPTION_NAME).set(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 15:32:33.018161
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from unittest import mock

    mock_workbench = mock.create_autospec(Workbench)
    mock_workbench.get_option = mock.Mock(return_value=True)

    get_workbench = mock.Mock(return_value=mock_workbench)
    with mock.patch("thonny.plugins.pgzero_mode.get_workbench", get_workbench):
        os.environ["PGZERO_MODE"] = "auto"
        update_environment()
        assert os.environ["PGZERO_MODE"] == "True"
        assert mock_workbench.get_option.call_count == 1

# Generated at 2022-06-22 15:32:40.036299
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import patch
    from thonny.globals import get_workbench

    workbench = get_workbench()
    workbench.set_default(_OPTION_NAME, False)

    with patch("os.environ", {}) as env:
        update_environment()
        assert env == {"PGZERO_MODE": "False"}

    var = workbench.get_variable(_OPTION_NAME)
    var.set(True)
    update_environment()
    assert env == {"PGZERO_MODE": "True"}

# Generated at 2022-06-22 15:32:49.899073
# Unit test for function update_environment
def test_update_environment():
    wb = MagicMock()
    wb.in_simple_mode.return_value = False
    wb.get_option.return_value = True
    with patch("thonny.plugins.pgzero_mode.get_workbench", return_value=wb):
        update_environment()
        assert os.environ.get("PGZERO_MODE") == "True"
    wb.get_option.return_value = False
    with patch("thonny.plugins.pgzero_mode.get_workbench", return_value=wb):
        update_environment()
        assert os.environ.get("PGZERO_MODE") == "False"


# Generated at 2022-06-22 15:32:59.290910
# Unit test for function update_environment
def test_update_environment():
    from thonny.globals import get_workbench
    from thonny.config_ui import ConfigurationPage
    from tkinter import Tk
    from test.test_config_ui import get_gui
    from thonny import get_runner
    import os
    import unittest

    class Test(unittest.TestCase):
        def setUp(self):
            get_workbench().clear_variables()
            get_workbench().clear_commands()
            get_workbench().clear_options()
            self.root = Tk()
            self.root.withdraw()
            self.gui = get_gui(self.root)

        def test_update_environment(self):
            get_workbench().set_option("run.pgzero_mode", False)
            get_workbench().set_simple_

# Generated at 2022-06-22 15:33:07.870901
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().in_simple_mode = True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"



# Generated at 2022-06-22 15:33:14.024869
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import Mock

    workbench = Mock()
    workbench.in_simple_mode = lambda: False
    workbench.get_option = lambda name: False
    get_workbench.cache_clear()
    get_workbench.cache["get_workbench"] = lambda: workbench
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"



# Generated at 2022-06-22 15:33:22.844088
# Unit test for function update_environment
def test_update_environment():
    from thonny.workflow import SubprocessProxy
    from thonny import get_workbench
    from unittest.mock import Mock
    from thonny.config import get_workbench_config_dir
    from thonny.globals import get_runner, get_shell
    from thonny.workflow import WorkflowProxy
    # Use a mock workbench to avoid having to work with the normal user directory
    # Mock the shell interaction to stop this test from running when the Python code is executed
    os.environ["PGZERO_MODE"] = "auto"
    mock_workbench = Mock()
    mock_workbench.in_simple_mode.return_value = False
    # Mock the workbench methods called in this function
    mock_workbench.get_option.return_value = True
    mock_workbench.get

# Generated at 2022-06-22 15:33:31.142250
# Unit test for function update_environment
def test_update_environment():
    w = get_workbench()
    w.set_simple_mode(False)
    w.set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    w.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    w.set_simple_mode(True)
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 15:33:36.521362
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_option(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME)
    assert os.environ["PGZERO_MODE"] == "True"

    toggle_variable()
    assert not get_workbench().get_option(_OPTION_NAME)
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 15:33:44.525977
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench

    get_workbench().set_default("run.before_run", ["toggle_pgzero_mode"])
    get_workbench().set_default("view.simple_mode", False)
    load_plugin()

    wb = Workbench()
    wb.set_default("run.before_run", ["toggle_pgzero_mode"])
    wb.set_default("view.simple_mode", False)
    wb.event_generate("WorkbenchConfigure")

    assert wb.get_option("run.pgzero_mode") == False
    assert os.environ["PGZERO_MODE"] == "False"


# Generated at 2022-06-22 15:35:00.253182
# Unit test for function update_environment
def test_update_environment():
    import os
    from thonny import get_workbench

    # Test case: in simple mode
    # Set env var to none
    os.environ["PGZERO_MODE"] = "None"
    update_environment()
    # Check that env var is set to auto now that in simple mode
    assert os.environ["PGZERO_MODE"] == "auto"

    # Test case: not in simple mode
    get_workbench().set_option("run.pgzero_mode", True)
    update_environment()
    # Check that env var is set to true
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 15:35:09.644913
# Unit test for function update_environment
def test_update_environment():
    class Better:
        def __init__(self):
            self._options = {}

    wb = Better()
    wb.in_simple_mode = lambda: True
    wb.get_option = lambda x: False
    wb.get_variable = lambda x: get_workbench().get_variable(x)
    globals()["get_workbench"] = lambda: wb
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    wb.in_simple_mode = lambda: False
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    wb.in_simple_mode = lambda: True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 15:35:21.381451
# Unit test for function toggle_variable
def test_toggle_variable():
    try:
        del os.environ["PGZERO_MODE"]
    except KeyError:
        pass

    assert not get_workbench().get_option(_OPTION_NAME)
    assert "PGZERO_MODE" not in os.environ

    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME)
    assert os.environ["PGZERO_MODE"] == "True"

    toggle_variable()
    assert not get_workbench().get_option(_OPTION_NAME)
    assert os.environ["PGZERO_MODE"] == "False"
    del os.environ["PGZERO_MODE"]

    get_workbench().set_simple_mode(True)
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 15:35:22.208225
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()


# Generated at 2022-06-22 15:35:32.551885
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench
    from thonny.misc_utils import running_on_mac_os, running_on_linux
    from unittest.mock import patch
    import thonny

    thonny.THONNY_USER_DIR = "test"

    get_workbench().set_default(_OPTION_NAME, False)

    with patch("os.environ") as environ:
        update_environment()
        assert environ == {"PGZERO_MODE": "0"}

    with patch("os.environ") as environ:
        get_workbench().set_option(_OPTION_NAME, True)
        update_environment()
        assert environ == {"PGZERO_MODE": "1"}

    with patch("os.environ") as environ:
        get_workbench().set_

# Generated at 2022-06-22 15:35:38.005873
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 15:35:43.372114
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.misc_utils import running_on_mac_os
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir
    from thonny import THONNY_USER_DIR
    
    wb = Workbench()
    load_plugin()
    assert not running_on_mac_os()
    assert os.path.isdir(os.path.join(get_config_dir(), THONNY_USER_DIR))
    assert os.environ["PGZERO_MODE"] == str(get_workbench().get_option(_OPTION_NAME)) or os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 15:35:52.206132
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    toggle_variable()
    assert wb.get_option(_OPTION_NAME)
    toggle_variable()
    assert not wb.get_option(_OPTION_NAME)
    wb.set_option(_OPTION_NAME, True)
    toggle_variable()
    assert not wb.get_option(_OPTION_NAME)
    toggle_variable()
    assert wb.get_option(_OPTION_NAME)
    os.environ["PGZERO_MODE"] = "auto"
    wb.set_option(_OPTION_NAME, False)
    toggle_variable()
    assert wb.get_option(_OPTION_NAME)


# Generated at 2022-06-22 15:35:57.586341
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    wb.set_simple_mode(False)
    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    wb.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 15:36:06.326945
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    assert not get_workbench().get_option(_OPTION_NAME)
    assert os.environ["PGZERO_MODE"] == "False"
    load_plugin()
    assert get_workbench().get_default(_OPTION_NAME) == False
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().in_simple_mode = lambda: True
    load_plugin()
    assert get_workbench().get_default(_OPTION_NAME) == False
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench