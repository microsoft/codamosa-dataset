

# Generated at 2022-06-22 15:27:50.293080
# Unit test for function update_environment
def test_update_environment():
    from thonny.globals import get_workbench
    from thonny import workbench
    workbench._workbench = None
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_option(_OPTION_NAME, True)
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 15:27:52.004022
# Unit test for function load_plugin
def test_load_plugin():
    pass

# Generated at 2022-06-22 15:27:58.617319
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import Mock
    get_workbench = Mock()
    get_workbench.return_value = Mock()
    get_workbench.return_value.get_option.return_value = "auto"
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench.return_value.get_option.return_value = False
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 15:28:04.221595
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock
    get_workbench = Mock()
    get_workbench().in_simple_mode.return_value = False
    get_workbench().set_default = Mock()
    get_workbench().add_command = Mock()
    get_workbench().get_option = Mock(return_value=False)
    get_workbench().set_variable = Mock()
    globals()["get_workbench"] = get_workbench

    load_plugin()

    get_workbench().set_default.assert_called_once_with(_OPTION_NAME, False)

# Generated at 2022-06-22 15:28:11.745237
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_simple_mode(False)
    update_environment()

# Generated at 2022-06-22 15:28:27.433920
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default("run.pgzero_mode", False)
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_default("run.pgzero_mode", True)
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_simple_mode(True)
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_simple_mode(False)
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_default("run.pgzero_mode", False)
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_simple_mode(True)

# Generated at 2022-06-22 15:28:35.013859
# Unit test for function load_plugin
def test_load_plugin():
    """Test if the plugin loads without errors"""
    global _OPTION_NAME

    _OPTION_NAME = "run.pgzero_mode_test"
    load_plugin()
    assert os.environ["PGZERO_MODE"] == "False"

    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"

    toggle_variable(False)
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 15:28:40.801653
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    assert len(wb.get_commands_in_group("run")) == 0

    load_plugin()
    
    assert wb.get_option(_OPTION_NAME) == wb.get_variable(_OPTION_NAME).get() == False
    assert "PGZERO_MODE" in os.environ
    assert os.environ["PGZERO_MODE"] == "auto"

    assert "toggle_pgzero_mode" in wb.get_commands_in_group("run")

# Generated at 2022-06-22 15:28:41.992376
# Unit test for function toggle_variable
def test_toggle_variable():
    print((type(True)))

# Generated at 2022-06-22 15:28:51.728831
# Unit test for function update_environment
def test_update_environment():
    saved_env = os.environ.get("PGZERO_MODE")

    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ.get("PGZERO_MODE") == "auto"

    get_workbench().set_variable(_OPTION_NAME, True)
    update_environment()
    assert os.environ.get("PGZERO_MODE") == "True"

    get_workbench().set_simple_mode(False)
    update_environment()
    assert os.environ.get("PGZERO_MODE") == "True"

    get_workbench().set_variable(_OPTION_NAME, False)
    update_environment()
    assert os.environ.get("PGZERO_MODE") == "False"

    get_workbench().set_simple_

# Generated at 2022-06-22 15:28:56.311163
# Unit test for function toggle_variable
def test_toggle_variable():
    # TODO: implement me
    pass


# Generated at 2022-06-22 15:28:57.889425
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()



# Generated at 2022-06-22 15:29:02.989003
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 15:29:07.428472
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME)
    toggle_variable()
    assert not get_workbench().get_option(_OPTION_NAME)

# Generated at 2022-06-22 15:29:09.624340
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()

# Generated at 2022-06-22 15:29:14.517948
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default("run.pgzero_mode", False)
    assert get_workbench().get_option("run.pgzero_mode") == False
    get_workbench().set_option("run.pgzero_mode",True)
    assert get_workbench().get_option("run.pgzero_mode") == True

# Generated at 2022-06-22 15:29:21.050853
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    assert wb.get_option(_OPTION_NAME) is False
    load_plugin()
    assert wb.get_command("toggle_pgzero_mode")
    assert wb.get_command("toggle_pgzero_mode").get_label() == 'Pygame Zero mode'


# Generated at 2022-06-22 15:29:27.714535
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME)

    toggle_variable()
    assert not get_workbench().get_option(_OPTION_NAME)


# Generated at 2022-06-22 15:29:32.512417
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    get_workbench = Workbench()
    load_plugin()
    assert get_workbench.get_default(_OPTION_NAME) == False
    assert get_workbench.get_option(_OPTION_NAME) == False

# Generated at 2022-06-22 15:29:36.597253
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    assert "PGZERO_MODE" in os.environ
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 15:29:51.062005
# Unit test for function load_plugin
def test_load_plugin():
    workbench = get_workbench()

    workbench.set_default(_OPTION_NAME, False)
    workbench.set_default("run.run_current_script", True)
    workbench.set_default("run.show_output_panel", True)
    workbench.set_default("editor.default_font", "courier")
    workbench.set_default("editor.highlight_current_line", True)
    workbench.set_default("editor.highlight_caret_line", True)
    workbench.set_default("editor.highlight_whitespace", True)
    workbench.set_default("editor.show_line_numbers", True)
    workbench.set_default("shell.font", "courier")

# Generated at 2022-06-22 15:30:02.352804
# Unit test for function load_plugin
def test_load_plugin():
    w = get_workbench()
    w.set_default(_OPTION_NAME, False)
    w.add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()
    assert get_workbench().get_variable(_OPTION_NAME) is False

    w.set_default(_OPTION_NAME, True)
    w.add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()

# Generated at 2022-06-22 15:30:11.391431
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import Mock
    from thonny.workbench import Workbench
    from thonny.config import get_config_dir

    MockWorkbench =  Mock(Workbench)
    wb = MockWorkbench()
    wb.in_simple_mode = Mock(return_value=True)
    wb._add_config_dir_to_path_if_needed = Mock()
    wb.get_variable = Mock()
    wb.get_option = Mock(return_value=True)

    with patch.dict("sys.modules", {"thonny.workbench": MockWorkbench}):
        load_plugin()
        wb = get_workbench()
        wb.get_variable.assert_called_once_with(_OPTION_NAME)
        wb.add_command.assert_called

# Generated at 2022-06-22 15:30:18.412717
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()

# Generated at 2022-06-22 15:30:26.498465
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.set_simple_mode(True)
    wb.add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()

    var = wb.get_variable(_OPTION_NAME)
    assert var.get() == False

    wb.in_simple_mode = True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    # @TODO Really need to test this from a shell command
    #        with os.environ['PGZERO_MODE'] == True

# Generated at 2022-06-22 15:30:33.498258
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    wb.set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    wb.in_simple_mode = lambda: True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 15:30:46.592667
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import patch
    from thonny import get_workbench

    # User defined env vars in OS
    with patch.dict("os.environ", {"PGZERO_MODE": "NOT_AUTO"}):
        get_workbench().set_simple_mode(False)
        get_workbench().set_option("run.pgzero_mode", True)
        update_environment()
        assert os.environ["PGZERO_MODE"] == "True"
        get_workbench().set_option("run.pgzero_mode", False)
        update_environment()
        assert os.environ["PGZERO_MODE"] == "False"

    # Simple mode
    get_workbench().set_simple_mode(True)
    update_environment()

# Generated at 2022-06-22 15:30:57.548382
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import patch
    from thonny.misc_utils import running_on_mac_os
    from thonny.workbench import Workbench

    wb = Workbench()
    wb._simple_mode = True

    wb._set_option(_OPTION_NAME, True)
    with patch("os.environ", autospec=True) as mock_env:
        update_environment()
        if running_on_mac_os():
            mock_env.__setitem__.assert_called_once_with("PGZERO_MODE", "auto")
        else:
            mock_env.__setitem__.assert_called_once_with("PGZERO_MODE", "auto")
            mock_env.__setitem__.reset_mock()

    wb._simple_mode = False
   

# Generated at 2022-06-22 15:30:59.434558
# Unit test for function update_environment
def test_update_environment():
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 15:31:08.297590
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench
    from thonny.languages import tr
    wb = get_workbench()
    wb.in_simple_mode = lambda: False
    wb.set_default(_OPTION_NAME, "testvalue")

    update_environment()
    assert os.environ["PGZERO_MODE"] == "testvalue"
    wb.in_simple_mode = lambda: True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 15:31:32.955486
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import MagicMock

    old_config = get_workbench().get_configuration()
    get_workbench().set_configuration(MagicMock(
        get_variable=MagicMock(return_value=True),
        get_default=MagicMock(return_value=False),
        get_option=MagicMock(return_value=True),
        set_default=MagicMock(),
        add_command=MagicMock(),
    ))
    assert get_workbench().get_option(_OPTION_NAME) == True
    assert "PGZERO_MODE" in os.environ
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_configuration(old_config)

# Generated at 2022-06-22 15:31:33.878788
# Unit test for function toggle_variable
def test_toggle_variable():

    toggle_variable()

# Generated at 2022-06-22 15:31:35.746167
# Unit test for function toggle_variable
def test_toggle_variable():
    print("test_toggle_variable")
    assert toggle_variable() == None


# Generated at 2022-06-22 15:31:42.454031
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import MagicMock
    from thonny import get_workbench
    from thonny.plugins.backend_options import set_default

    wb = get_workbench()
    wb.in_simple_mode = MagicMock(return_value=True)

    set_default = MagicMock()
    set_default = MagicMock()

    wb.add_command = MagicMock()

    load_plugin()

    assert  wb.get_option(_OPTION_NAME) == False

    assert os.environ['PGZERO_MODE'] == "auto"

# Generated at 2022-06-22 15:31:52.473208
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench
    from thonny.globals import get_runner
    from thonny.running import PythonProcess

    workbench = get_workbench()
    workbench.set_default(_OPTION_NAME, False)
    workbench.in_simple_mode()

    load_plugin()

    assert workbench.get_default(_OPTION_NAME) is False
    assert "PGZERO_MODE" in os.environ
    assert os.environ["PGZERO_MODE"] == "False"

    runner = get_runner()


# Generated at 2022-06-22 15:31:59.113484
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, True)
    assert os.environ["PGZERO_MODE"] == "True"
    #print(wb.get_option(_OPTION_NAME))
    assert wb.get_option(_OPTION_NAME) == True
    wb.set_default(_OPTION_NAME, False)
    assert os.environ["PGZERO_MODE"] == "False"
    assert wb.get_option(_OPTION_NAME) == False

# Generated at 2022-06-22 15:32:03.614809
# Unit test for function update_environment
def test_update_environment():
    assert os.environ["PGZERO_MODE"].lower() != "1"
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"].lower() == "1"

# Generated at 2022-06-22 15:32:06.717942
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_option(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME)

# Generated at 2022-06-22 15:32:14.568770
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = "off"
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto", os.environ["PGZERO_MODE"]
    
    os.environ["PGZERO_MODE"] = "off"
    get_workbench().set_default(_OPTION_NAME, True)
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto", os.environ["PGZERO_MODE"]
    
    os.environ["PGZERO_MODE"] = "off"
    get_workbench().set_

# Generated at 2022-06-22 15:32:25.011259
# Unit test for function toggle_variable
def test_toggle_variable():
    # Simple install
    try:
        import pgzero
    except:
        pgzero_installed= False
    else:
        pgzero_installed= True
    
    # Switch to false and then watiting for 2 seconds to let the update sink in
    toggle_variable()
    time.sleep(2)
    # Testing if the environment variable changes to auto
    assert os.environ["PGZERO_MODE"] == "False"
    # If it's already running, restart the kernel
    if pgzero_installed and pgzero.running:
        get_workbench().restart_shell()
    
    # Test if it works for pygame mode
    toggle_variable()
    time.sleep(2)
    assert os.environ["PGZERO_MODE"] == "True"
    # If it's already running, restart the kernel

# Generated at 2022-06-22 15:33:02.265924
# Unit test for function load_plugin
def test_load_plugin():
    workbench = get_workbench()
    workbench.unload_plugin("pgzero_mode")
    workbench.unload_plugin("thonnycontrib.pgzero_mode")
    load_plugin()
    assert workbench.get_option(_OPTION_NAME) is False
    toggle_variable()
    assert workbench.get_option(_OPTION_NAME) is True
    assert os.environ["PGZERO_MODE"] == "True"
    workbench.in_simple_mode = lambda: True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 15:33:03.621662
# Unit test for function load_plugin
def test_load_plugin():
    # No error is enough.
    load_plugin()
    assert True

# Generated at 2022-06-22 15:33:10.316727
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    
    wb = get_workbench()
    assert _OPTION_NAME in wb.get_option(_OPTION_NAME)
    assert wb.get_option(_OPTION_NAME) is False
    assert "PGZERO_MODE" not in os.environ

    wb.set_option("run.pgzero_mode", True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 15:33:14.610070
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.in_simple_mode = lambda: True

    load_plugin()
    assert wb.get_variable(_OPTION_NAME).get() == False
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 15:33:19.861417
# Unit test for function toggle_variable
def test_toggle_variable():
    # Set initial variable to True
    get_workbench().set_default(_OPTION_NAME, True)

    # Toggle variable and ensure variable is now False
    toggle_variable()
    var = get_workbench().get_variable(_OPTION_NAME)
    assert var == False

    # Toggle variable again and ensure variable is now True
    toggle_variable()
    var = get_workbench().get_variable(_OPTION_NAME)
    assert var == True

# Generated at 2022-06-22 15:33:26.324246
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_shell
    
    get_shell()
    #get_workbench().event_generate("<<OpenInterpreter>>")
    #time.sleep(0.1)
    load_plugin()
    assert not get_workbench().in_simple_mode()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert "PGZERO_MODE=False" in get_shell().get_current_environment_text()

    #get_workbench().event_generate("<<CloseInterpreter>>")
    #time.sleep(0.1)
    assert "PGZERO_MODE=" not in get_shell().get_current_environment_text()
    
    toggle_variable()
    
    #get_workbench().event_generate("<<OpenInterpreter>>")


# Generated at 2022-06-22 15:33:29.923512
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert get_workbench().in_pgzero_mode() == False
    get_workbench().set_option(_OPTION_NAME, True)
    assert get_workbench().in_pgzero_mode()

# Generated at 2022-06-22 15:33:39.386935
# Unit test for function toggle_variable
def test_toggle_variable():
    from unittest.mock import create_autospec
    from test.test_base import TestBundle
    from thonny.plugins.run import RunView
    from thonny import get_workbench

    workbench = get_workbench()
    workbench.clear_plugins()
    workbench._plugins.append(TestBundle(RunView))
    get_workbench().set_default(_OPTION_NAME, False)
    RunView.toggle_pgzero_mode = create_autospec(RunView.toggle_pgzero_mode)
    toggle_variable()

    # Collapse button should be active if variable is activated
    RunView.toggle_pgzero_mode.assert_called_with(True)

    # Collapse button should be deactivated if variable is deactivated
    toggle_variable()
    RunView.toggle_pg

# Generated at 2022-06-22 15:33:47.496690
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.globals import get_workbench
    from unittest.mock import Mock
    from thonny import ui_utils
    from thonny.workbench import Workbench

    mock_ui_utils = Mock(ui_utils)
    mock_ui_utils.create_menu_item.return_value = None
    mock_ui_utils.create_tool_button.return_value = None

    wb = Workbench()
    wb.setVar("run.pgzero_mode", False)
    wb.add_command = Mock()
    wb.set_default = Mock()
    wb.get_variable = Mock()
    wb.get_variable.return_value = False

    load_plugin()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 15:33:54.557959
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.misc_utils import running_on_linux
    from thonny.globals import get_workbench
    if not running_on_linux():
        import unittest
        import unittest.mock

        class Test(unittest.TestCase):
            def test_toggle_variable(self):
                toggle_variable()
                self.assertEqual(get_workbench().get_option(_OPTION_NAME), True)
                toggle_variable()
                self.assertEqual(get_workbench().get_option(_OPTION_NAME), False)

        suite = unittest.TestSuite()
        suite.addTest(Test("test_toggle_variable"))
        runner = unittest.TextTestRunner()
        runner.run(suite)

# Generated at 2022-06-22 15:35:02.442699
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    assert wb.get_option(_OPTION_NAME) == False, "Expected get_option(_OPTION_NAME) to return False"
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == True, "Expected get_option(_OPTION_NAME) to return True"
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == False, "Expected get_option(_OPTION_NAME) to return False"


# Generated at 2022-06-22 15:35:12.227301
# Unit test for function load_plugin
def test_load_plugin():
    # Replace get_workbench by mock object
    from unittest.mock import Mock
    get_workbench = Mock()

    # Reset globals
    globals().pop("get_workbench", None)

    # Import plugin
    from thonnycontrib import pgzero_mode

    # Call plugin's load_plugin function
    pgzero_mode.load_plugin()

    # Verify get_workbench.set_default was called once with correct parameters
    get_workbench.set_default.assert_called_once_with(
        "run.pgzero_mode", False
    )
    # Verify get_workbench.add_command was called once with correct parameters

# Generated at 2022-06-22 15:35:21.897366
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.tktextext import TextFrame, TextFrameBase
    from tkinter import Tk
    import os
    import sys

    root = Tk()
    del sys.argv[1:]
    workbench = Workbench(root)
    workbench.set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    workbench.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    workbench.set_default(_OPTION_NAME, False)
    workbench.set_simple_mode()
    update_environment()
    assert os.environ["PGZERO_MODE"]

# Generated at 2022-06-22 15:35:29.894964
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    try:
        wb.set_variable(_OPTION_NAME, True)
        update_environment()
        assert os.environ["PGZERO_MODE"] == "True"
        wb.set_variable(_OPTION_NAME, False)
        update_environment()
        assert os.environ["PGZERO_MODE"] == "False"
    finally:
        wb._set_variable(_OPTION_NAME, None)
        del os.environ["PGZERO_MODE"]

# Generated at 2022-06-22 15:35:35.025917
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = str("no")
    get_workbench()._set("run.pgzero_mode", False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "no"
    get_workbench()._set("run.pgzero_mode", True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "yes"
    get_workbench()._set("run.pgzero_mode", False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 15:35:42.587750
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_runner

    get_workbench().set_default("run.pgzero_mode", False)
    load_plugin()

    assert "PGZERO_MODE" not in os.environ
    assert get_workbench().get_variable("run.pgzero_mode") is False
    assert "pgzero_mode" in get_runner()
    get_runner().execute("from pgzero.builtins import *")

    get_workbench().set_simple_mode(True)
    assert "PGZERO_MODE" not in os.environ

    get_workbench().set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    assert "pgzero_mode" in get_runner()

# Generated at 2022-06-22 15:35:49.128183
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default(_OPTION_NAME, False)
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_default(_OPTION_NAME, True)
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().set_simple_mode(True)
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 15:35:58.677926
# Unit test for function update_environment
def test_update_environment():
    os.environ.pop("PGZERO_MODE", None)
    assert os.environ.get("PGZERO_MODE") is None

    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().set_simple_mode(False)
    get_workbench().set_option("run.pgzero_mode", True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"

    get_workbench().set_option("run.pgzero_mode", False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"

    get_workbench().set_simple_mode(True)
    update_environment()
   

# Generated at 2022-06-22 15:36:05.820837
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    wb = get_workbench()
    assert wb.get_option(_OPTION_NAME) is False
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) is True
    assert os.environ["PGZERO_MODE"] == "True"
    wb.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    wb.set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 15:36:11.519454
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny import Tester
    from thonny.workbench import Workbench

    get_workbench().set_default(_OPTION_NAME, True)
    get_workbench().set_variable("shiv", True)
    toggle_variable()
    assert get_workbench().get_variable("shiv") == False
    toggle_variable()
    assert get_workbench().get_variable("shiv") == True

