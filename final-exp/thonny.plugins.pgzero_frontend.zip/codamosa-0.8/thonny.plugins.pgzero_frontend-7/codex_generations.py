

# Generated at 2022-06-22 15:27:55.980799
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench

    wb = Workbench()
    load_plugin()
    assert _OPTION_NAME in wb.get_defaults()
    assert wb.get_option(_OPTION_NAME) == False
    assert wb.get_command("toggle_pgzero_mode")

# Generated at 2022-06-22 15:27:59.619253
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    toggle_variable()
    assert wb.get_variable(_OPTION_NAME).get()
    toggle_variable()
    assert not wb.get_variable(_OPTION_NAME).get()

# Generated at 2022-06-22 15:28:05.336927
# Unit test for function load_plugin
def test_load_plugin():
    """Shows error message if a plugin fails to load."""
    load_plugin()
    # if the test stops here, then the plugin is loaded correctly
    assert "tgl" in get_workbench().get_variable(_OPTION_NAME)


if __name__ == "__main__":
    test_load_plugin()

# Generated at 2022-06-22 15:28:08.801639
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.in_simple_mode = lambda: True
    load_plugin()
    assert os.environ["PGZERO_MODE"] == "auto"



# Generated at 2022-06-22 15:28:09.732192
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()



# Generated at 2022-06-22 15:28:20.036709
# Unit test for function load_plugin
def test_load_plugin():
    assert not os.environ.get("PGZERO_MODE")
    load_plugin()
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"
    os.environ["THONNY_SIMPLE_MODE"] = "1"
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    del os.environ["THONNY_SIMPLE_MODE"]

# Generated at 2022-06-22 15:28:23.664412
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.reload_plugin("thonny.plugins.pgzero")
    wb.activate_plugin("thonny.plugins.pgzero")
    assert wb.get_variable(_OPTION_NAME) == False
    assert "PGZERO_MODE" not in os.environ

# Generated at 2022-06-22 15:28:29.863419
# Unit test for function update_environment
def test_update_environment():
    import os
    from thonny.misc_utils import running_on_mac_os
    from thonny.ui_utils import get_default_font
    from thonny.languages import ui_language
    from tkinter import Tk, Label

    root = Tk()

    # Check for default font.
    default_font = get_default_font(root)
    assert default_font.actual()["family"] == "TkDefaultFont"

    # Check for default language.
    assert ui_language() == "en"

    # Make sure env vars are cleared.
    os.environ.pop("PGZERO_MODE", None)
    os.environ.pop("TK_FONT", None)
    os.environ.pop("TK_LANGUAGE", None)

    # Check env

# Generated at 2022-06-22 15:28:32.123010
# Unit test for function update_environment
def test_update_environment():
    # clear environment dictionary
    os.environ.clear()
    update_environment()

# Generated at 2022-06-22 15:28:42.155026
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_variable(_OPTION_NAME, True)
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False


# Generated at 2022-06-22 15:28:58.761409
# Unit test for function update_environment
def test_update_environment():
    from thonny.plugins.run.pgzero_mode import update_environment
    import os
    import pytest
    get_workbench().set_option("run.pgzero_mode", "True")
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_option("run.pgzero_mode", None)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "None"
    get_workbench().set_option("run.pgzero_mode", False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_option("run.pgzero_mode", 0)
    update_environment()

# Generated at 2022-06-22 15:29:10.852024
# Unit test for function update_environment
def test_update_environment():
    import sys
    import os
    from unittest.mock import patch

    from pytest import raises

    get_workbench().set_simple_mode(True)
    with raises(KeyError):
        os.environ["PGZERO_MODE"]
    update_environment()
    assert "PGZERO_MODE" in os.environ
    assert os.environ["PGZERO_MODE"] == "auto"
    
    get_workbench().set_simple_mode(True)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert "PGZERO_MODE" in os.environ
    assert os.environ["PGZERO_MODE"] == "on"

    get_workbench().set_simple_mode(False)
    get_workbench().set_option

# Generated at 2022-06-22 15:29:11.405897
# Unit test for function toggle_variable
def test_toggle_variable():
    assert True

# Generated at 2022-06-22 15:29:13.911943
# Unit test for function load_plugin
def test_load_plugin():
    assert "PGZERO_MODE" in os.environ
    assert os.environ["PGZERO_MODE"] in ("True", "False")

# Generated at 2022-06-22 15:29:19.627316
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    assert not wb.get_option(_OPTION_NAME)
    assert os.environ["PGZERO_MODE"] == "False"

    load_plugin()
    assert wb.get_option(_OPTION_NAME) is False
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 15:29:24.375332
# Unit test for function load_plugin
def test_load_plugin():
    import unittest

    from thonny.misc_utils import running_on_mac_os

    from thonny.testing import Tester

    tester = Tester(globals())
    runner = tester.test_runner()
    runner.run(unittest.makeSuite(TestPGZeroSupport))



# Generated at 2022-06-22 15:29:26.026722
# Unit test for function toggle_variable

# Generated at 2022-06-22 15:29:37.050777
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench

    workbench = Workbench()
    from thonny import get_workbench

    assert get_workbench() == workbench
    assert not get_workbench().in_simple_mode()

    import os

    assert os.environ.get("PGZERO_MODE") == "False"

    load_plugin()

    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"
    # flag_name here is a shortcut for get_workbench().get_variable()
    assert not get_workbench().get_option("run.pgzero_mode", is_flag=True)

    toggle_variable()

# Generated at 2022-06-22 15:29:45.436532
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()
    assert(os.environ["PGZERO_MODE"] == "False")
    toggle_variable()
    assert(os.environ["PGZERO_MODE"] == "True")
    toggle_variable()
    assert(os.environ["PGZERO_MODE"] == "False")

# Generated at 2022-06-22 15:29:52.587006
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.create()
    wb.configure()
    assert wb.get_option(_OPTION_NAME) == False
    load_plugin()
    assert get_workbench().get_variable(_OPTION_NAME) is not None
    assert get_workbench().get_option("run.pgzero_mode") == False
    assert os.environ["PGZERO_MODE"] == "False"
    assert wb.in_simple_mode() == False
    wb.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    wb.set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable

# Generated at 2022-06-22 15:30:10.498106
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    load_plugin()
    # Check that command was created
    assert get_workbench().get_command("toggle_pgzero_mode")
    # Check that aflter running the command the option is toggled
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    # Check that the enviroment was updated
    assert os.environ["PGZERO_MODE"] == "True"
    # Assert that toggling the plugin again puts it back to False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 15:30:16.098362
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.finish_initializing()

    load_plugin()

    # TODO: verify variables and menu items were created

# Generated at 2022-06-22 15:30:21.083249
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 15:30:26.375496
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert "toggle_pgzero_mode" in get_workbench().get_command_names()



# Generated at 2022-06-22 15:30:31.163272
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()

# Generated at 2022-06-22 15:30:35.500520
# Unit test for function update_environment
def test_update_environment():
    get_workbench().in_simple_mode = lambda: False
    get_workbench().get_option = lambda x: True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().in_simple_mode = lambda: True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 15:30:39.725819
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_simple_mode(True)
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_simple_mode(False)
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"


# Generated at 2022-06-22 15:30:47.777131
# Unit test for function update_environment
def test_update_environment():
    print("Old PGZERO_MODE: {}".format(os.environ.get("PGZERO_MODE", "(not set)")))
    get_workbench().set_option("run.pgzero_mode", False)
    update_environment()
    assert os.environ.get("PGZERO_MODE") == "False"

    get_workbench().set_option("run.pgzero_mode", True)
    update_environment()
    assert os.environ.get("PGZERO_MODE") == "True"

    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ.get("PGZERO_MODE") == "auto"

# Generated at 2022-06-22 15:30:52.466669
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, True)
    toggle_variable()
    assert wb.get_variable(_OPTION_NAME).get() == False
    toggle_variable()

# Generated at 2022-06-22 15:30:59.600866
# Unit test for function update_environment
def test_update_environment():
    from unittest import mock
    import thonny
    thonny.get_workbench = mock.MagicMock()

    thonny.get_workbench.in_simple_mode.return_value = False
    thonny.get_workbench.get_option.return_value = True

    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    thonny.get_workbench.get_option.return_value = False
    
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    thonny.get_workbench.in_simple_mode.return_value = True
    
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 15:31:16.582838
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    get_workbench().disable_simple_mode()
    assert os.environ["PGZERO_MODE"] == "False"
    assert get_workbench().get_option(_OPTION_NAME) == False
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    assert get_workbench().get_option(_OPTION_NAME) == True
    get_workbench().enable_simple_mode()
    assert os.environ["PGZERO_MODE"] == "auto"


if __name__ == "__main__":
    test_load_plugin()

# Generated at 2022-06-22 15:31:17.740639
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)

# Generated at 2022-06-22 15:31:24.391258
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert get_workbench().in_simple_mode() == False
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert get_workbench().in_simple_mode() == True
    assert os.environ["PGZERO_MODE"] == "True"


if __name__ == "__main__":
    test_load_plugin()

# Generated at 2022-06-22 15:31:29.817942
# Unit test for function toggle_variable
def test_toggle_variable():
    from unittest.mock import MagicMock

    wb = get_workbench()
    wb.set_sensitive = MagicMock()

    toggle_variable()
    assert wb.get_variable(_OPTION_NAME).get()

    toggle_variable()
    assert not wb.get_variable(_OPTION_NAME).get()

    wb.set_sensitive.assert_called_once()

# Generated at 2022-06-22 15:31:38.385547
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == True, "toggle_variable change from False to True"
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == False, "toggle_variable change from True to False"

# Generated at 2022-06-22 15:31:46.271007
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench
    from thonny.plugins.pygame_zero import _OPTION_NAME, load_plugin

    # Call function under test
    load_plugin()
    # Check dependencies
    wb = get_workbench()
    assert wb.get_default(_OPTION_NAME) == False
    assert wb.get_option(_OPTION_NAME) == False
    assert _OPTION_NAME in wb.get_variables()

# Generated at 2022-06-22 15:31:47.685487
# Unit test for function update_environment
def test_update_environment():
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 15:31:51.771984
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    wb.set_simple_mode(False)
    assert wb.get_variable(_OPTION_NAME).get() == False
    toggle_variable()
    assert wb.get_variable(_OPTION_NAME).get() == True
    toggle_variable()
    assert wb.get_variable(_OPTION_NAME).get() == False

# Generated at 2022-06-22 15:31:55.889497
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_simple_mode()
    assert get_workbench().get_option(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-22 15:32:07.515799
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.codeview import get_code_view

    # Initialize test context
    get_workbench().reset_test_data()
    get_workbench().show_editor()

    # Test if the command was successfully added
    assert "toggle_pgzero_mode" in [command.name for command in get_workbench().commands.commands]

    # Test if the flag was successfully added
    assert get_workbench().get_variable(_OPTION_NAME)

    # Test if the default value is False
    assert get_workbench().get_option(_OPTION_NAME) == False

    # Test if the Pygame Zero mode is off
    assert os.environ["PGZERO_MODE"] == "False"

    # Test if the code view can be successfully obtained
    assert get_code_view()

    # Test if the button

# Generated at 2022-06-22 15:32:41.163057
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import Mock

    get_workbench().in_simple_mode = lambda: True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().in_simple_mode = lambda: False
    get_workbench().get_option = Mock()
    get_workbench().get_option.return_value = False
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"
    get_workbench().get_option.return_value = True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"

# Generated at 2022-06-22 15:32:44.731596
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default(_OPTION_NAME, True)
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_default(_OPTION_NAME, False)
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 15:32:48.215267
# Unit test for function toggle_variable
def test_toggle_variable():
    try:
        # toggle_variable()
        var = get_workbench().get_variable(_OPTION_NAME)
        var.set(not var.get())
        assert not var.get()
    except TypeError:
        pass

# Generated at 2022-06-22 15:32:55.432770
# Unit test for function toggle_variable
def test_toggle_variable():
    """Function toggle_variable toggles the boolean value of the global _OPTION_NAME variable which is False by default.
    The second time toggle_variable is called, the global _OPTION_NAME variable should be set back to False."""
    get_workbench().set_variable(_OPTION_NAME, False)
    assert get_workbench().get_variable(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME) == False



# Generated at 2022-06-22 15:33:07.642688
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny import get_workbench

    wb = get_workbench()
    enable_var = wb.get_variable(_OPTION_NAME)
    wb.clear_user_variables()
    enable_var.set(True)
    assert enable_var.get() == True
    toggle_variable()
    assert enable_var.get() == False
    toggle_variable()
    assert enable_var.get() == True
    toggle_variable()
    assert enable_var.get() == False
    wb.clear_user_variables()
    assert enable_var.get() == False
    toggle_variable()
    assert enable_var.get() == True
    toggle_variable()
    assert enable_var.get() == False

    # Unit test for function update_environment
    # def test_update_environment():

# Generated at 2022-06-22 15:33:15.714362
# Unit test for function toggle_variable
def test_toggle_variable():
    from unittest.mock import Mock
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)

    wb.default_variable_value_changed = Mock()
    wb.value_changed = Mock()
    wb.add_command("toggle_pgzero_mode", "run", tr(""), toggle_variable)

    toggle_variable()
    assert wb.get_variable(_OPTION_NAME) == True

    toggle_variable()
    assert wb.get_variable(_OPTION_NAME) == False

if __name__ == "__main__":
    test_toggle_variable()

# Generated at 2022-06-22 15:33:20.507880
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, True)
    load_plugin()
    assert(get_workbench().get_option(_OPTION_NAME) == False)
    assert(os.environ["PGZERO_MODE"] == "False")
    toggle_variable()
    assert(get_workbench().get_option(_OPTION_NAME) == True)
    assert(os.environ["PGZERO_MODE"] == "True")

# Generated at 2022-06-22 15:33:26.191570
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench

    wb = Workbench()
    load_plugin()
    assert wb.get_default(_OPTION_NAME) == False
    assert wb.get_command("toggle_pgzero_mode") != None
    assert os.environ["PGZERO_MODE"] == "False"

    wb.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    wb.set_simple_mode(False)
    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 15:33:30.587603
# Unit test for function load_plugin
def test_load_plugin():
    import pytest
    from thonny.workbench import Workbench
    main = Workbench()
    main.set_default(_OPTION_NAME, True)
    pytest.main(["-qq", "-s", "-x", "--pdb", __file__])

# Generated at 2022-06-22 15:33:39.513108
# Unit test for function toggle_variable
def test_toggle_variable():
    # Code to simulate the enviroment and the initial values of the variables
    import thonny
    import unittest

    thonny.workbench.in_simple_mode = lambda: False
    getattr(thonny.workbench, "get_variable").set = lambda name, value: setattr(
        thonny.workbench, "var", value
    )
    getattr(thonny.workbench, "get_option").get = lambda name: getattr(
        thonny.workbench, "var"
    )
    setattr(thonny.workbench, "var", False)
    setattr(thonny.workbench, "simple_mode", False)

    # Test to check if the variable is changed to false
    toggle_variable()
    assert thonny.workbench.var == True



# Generated at 2022-06-22 15:34:50.561913
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().unset_default(_OPTION_NAME)
    assert get_workbench().get_option(_OPTION_NAME) == False

    get_workbench().set_default(_OPTION_NAME, True)
    assert get_workbench().get_option(_OPTION_NAME) == True
    assert get_workbench().in_simple_mode() == False

    get_workbench().set_default(_OPTION_NAME, False)
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert get_workbench().in_simple_mode() == False

    get_workbench().add_command("toggle_pgzero_mode", "run", "Pygame Zero mode")
    assert get_workbench().get_menu("run")._submenus["Pygame Zero mode"].children()[0]._

# Generated at 2022-06-22 15:34:51.468207
# Unit test for function toggle_variable
def test_toggle_variable():
    pass

# Generated at 2022-06-22 15:34:54.288961
# Unit test for function toggle_variable
def test_toggle_variable():
    #testing function toggle_variable
    assert(togglevariable.toggle_variable())

# Generated at 2022-06-22 15:35:05.437323
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    
    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 15:35:08.621138
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-22 15:35:16.704387
# Unit test for function toggle_variable
def test_toggle_variable():
    test_workbench = Workbench()
    original_value = test_workbench.get_option(_OPTION_NAME)
    toggle_variable()
    assert test_workbench.get_option(_OPTION_NAME) != original_value
    toggle_variable()
    assert test_workbench.get_option(_OPTION_NAME) == original_value

# Generated at 2022-06-22 15:35:21.742159
# Unit test for function update_environment
def test_update_environment():
    from thonnycontrib.pgzero_mode import _OPTION_NAME
    from thonny import get_workbench
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 15:35:25.198203
# Unit test for function update_environment
def test_update_environment():
    assert os.environ["PGZERO_MODE"] == str(get_workbench().get_option(_OPTION_NAME))

# Generated at 2022-06-22 15:35:33.741924
# Unit test for function toggle_variable
def test_toggle_variable():
    from unittest.mock import Mock
    from thonny.globals import get_workbench
    from thonny.globals import BoolVar
    from thonny.globals import TkVar

    # Test for None value
    var = None
    get_workbench().get_variable = Mock(return_value=var)
    toggle_variable()
    var.set.assert_not_called()

    # Test for value = True
    var = Mock()
    var.get = Mock(return_value=True)
    get_workbench().get_variable = Mock(return_value=var)
    get_workbench().get_variable.set = Mock(return_value=None)
    toggle_variable()
    var.set.assert_called_with(False)

    # Test for value = False


# Generated at 2022-06-22 15:35:41.238472
# Unit test for function update_environment
def test_update_environment():
    from thonny.globals import get_workbench
    import os
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    # TODO: test case when PGZERO_MODE is already set

# Generated at 2022-06-22 15:37:18.775805
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.memory import MemoryViewFrame
    from thonny import get_workbench

    workbench = get_workbench()
    memory_frame = MemoryViewFrame(workbench, None)

    assert workbench.get_variable(_OPTION_NAME).get() == False
    toggle_variable()
    assert workbench.get_variable(_OPTION_NAME).get() == True
    toggle_variable()
    assert workbench.get_variable(_OPTION_NAME).get() == False

# Generated at 2022-06-22 15:37:28.204992
# Unit test for function load_plugin
def test_load_plugin():
    workbench = MagicMock()
    workbench.in_simple_mode = True
    workbench.set_default = MagicMock()
    workbench.add_command = MagicMock()
    workbench.get_variable = MagicMock(return_value=MagicMock(get=MagicMock(return_value=True)))
    
    get_workbench.return_value = workbench

    load_plugin()

    workbench.set_default.assert_called_once_with(_OPTION_NAME, False)

    workbench.add_command.assert_called_once()

    args, kwargs = workbench.add_command.call_args

    assert args[0] == "toggle_pgzero_mode"
    assert args[1] == "run"
    assert isinstance(args[2], str)