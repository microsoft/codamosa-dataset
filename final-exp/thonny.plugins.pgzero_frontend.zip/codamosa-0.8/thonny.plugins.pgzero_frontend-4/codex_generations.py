

# Generated at 2022-06-22 15:27:59.104061
# Unit test for function toggle_variable
def test_toggle_variable():
    try:
        get_workbench().set_in_simple_mode(False)
        toggle_variable()
        assert get_workbench().get_variable(_OPTION_NAME).get() == True
        toggle_variable()
        assert get_workbench().get_variable(_OPTION_NAME).get() == False
    finally:
        get_workbench().set_in_simple_mode(False)
        get_workbench().set_variable(_OPTION_NAME, False)



# Generated at 2022-06-22 15:28:03.216039
# Unit test for function update_environment
def test_update_environment():
    os.environ['PGZERO_MODE'] = 'auto'
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ['PGZERO_MODE'] == 'True'

# Generated at 2022-06-22 15:28:07.104419
# Unit test for function load_plugin
def test_load_plugin():
    wb = Workbench()
    load_plugin()

    assert wb.get_variable(_OPTION_NAME).get()
    assert wb.get_variable(_OPTION_NAME).get()

# Generated at 2022-06-22 15:28:11.168234
# Unit test for function update_environment
def test_update_environment():
    get_workbench().in_simple_mode = lambda: False
    get_workbench().get_option = lambda option_name: False
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"


if __name__ == "__main__":
    load_plugin()

# Generated at 2022-06-22 15:28:23.693499
# Unit test for function update_environment
def test_update_environment():
    # Note that this is tested together with pgzero_mode in test_env_var_updating.py
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 15:28:29.008157
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_simple_mode(False)
    get_workbench().set_option("run.pgzero_mode", True)
    update_environment()
    print(os.environ["PGZERO_MODE"])
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 15:28:37.921698
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    wb.set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 15:28:46.408290
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    wb.set_simple_mode(True)
    update_environment()
    os.environ["PGZERO_MODE"] = "auto"
    wb.set_simple_mode(False)
    update_environment()
    os.environ["PGZERO_MODE"] = "True"
    wb.set_simple_mode(True)
    update_environment()
    os.environ["PGZERO_MODE"] = "auto"

# Generated at 2022-06-22 15:28:55.023436
# Unit test for function toggle_variable
def test_toggle_variable():
    from unittest.mock import patch

    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"

    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"

    with patch("thonny.languages.simple_mode.get_workbench", return_value=object()):
        get_workbench().get_option = lambda x: True
        update_environment()
        assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 15:28:58.993301
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workflow import WorkflowManager
    from unittest import mock

    with mock.patch.object(WorkflowManager, "set_default") as set_default:
        load_plugin()
        set_default.assert_called_once_with(_OPTION_NAME, False)



# Generated at 2022-06-22 15:29:08.575603
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    assert "toggle_pgzero_mode" not in wb._command_dict
    load_plugin()
    assert "toggle_pgzero_mode" in wb._command_dict

# Generated at 2022-06-22 15:29:18.170716
# Unit test for function update_environment
def test_update_environment():
    from unittest import mock
    from thonny.common import InlineCommand

    def check(simple, expected):
        with mock.patch("thonny.workbench.SimpleWorkbench.in_simple_mode", return_value=simple):
            update_environment()
            assert os.environ["PGZERO_MODE"] == expected

    wb = get_workbench()
    wb.set_default("run.pgzero_mode", False)
    check(False, "False")

    wb.set_default("run.pgzero_mode", True)
    check(False, "True")

    wb.set_option("run.pgzero_mode", False)
    wb.del_command("toggle_pgzero_mode")

# Generated at 2022-06-22 15:29:25.529038
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    wb.init_simple_mode()
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    wb.init_simple_mode()
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    os.environ["PGZERO_MODE"] = "does not exist so far"
    wb.init_simple_mode()
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 15:29:28.914256
# Unit test for function load_plugin
def test_load_plugin():
    w = get_workbench()
    assert len(w.commands["toggle_pgzero_mode"]) == len(w.default_commands) + 1

# Generated at 2022-06-22 15:29:39.051326
# Unit test for function update_environment
def test_update_environment():
    from thonny.globals import get_runner
    from thonny.plugins.run import get_interpreter_for_subprocess
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert "PGZERO_MODE" not in os.environ
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert "PGZERO_MODE" not in os.environ
    get_workbench().in_simple_mode = lambda: True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    get

# Generated at 2022-06-22 15:29:44.129710
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock
    from thonny.globals import get_workbench

    workbench = Mock(get_variable=Mock(return_value=Mock(get=Mock(return_value=False))))
    get_workbench = Mock(return_value=workbench)
    assert get_workbench().in_simple_mode() == False, "Expected False"

# Generated at 2022-06-22 15:29:51.061339
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    sys.argv = ["thonny"]
    wb.initialize(None)
    load_plugin()
    # Create a command
    assert wb.get_variable(_OPTION_NAME) is not None
    assert wb.get_option(_OPTION_NAME) is False
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) is True
    assert os.environ["PGZERO_MODE"] == "True"

    wb.close()


if __name__ == "__main__":
    test_load_plugin()

# Generated at 2022-06-22 15:29:56.496094
# Unit test for function update_environment
def test_update_environment():
    """Test environment variables"""
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 15:30:00.917528
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    import unittest
    from unittest.mock import MagicMock
    from thonny import get_runner
    import sys
    import os

    sys._called_from_test = True
    sys.argv = ["thonny"]
    wb = Workbench()
    test_workbench = wb
    # get_runner().remove_backends()
    # get_runner().add_backend("thonny.plugins.native.NativeBackend",40,"native")
    test_workbench.set_default(_OPTION_NAME, False)
    wb.add_command = MagicMock()
    load_plugin()
    wb.get_variable = MagicMock()
    wb.get_option = MagicMock()
    wb.get_option

# Generated at 2022-06-22 15:30:04.991696
# Unit test for function update_environment
def test_update_environment():
    import os
    from unittest import mock
    import builtins
    from thonny.workbench import Workbench

    os.environ["PGZERO_MODE"] = "True"

    workbench = Workbench()
    workbench.set_default(_OPTION_NAME, True)
    # Ensure module not reloaded as will break test
    builtins.reloading_thonny_plugins = True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    # Set _OPTION_NAME to False
    workbench.set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    # Disable PGZERO_MODE
    update_environment()
    assert os.enviro

# Generated at 2022-06-22 15:30:22.544273
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_option(_OPTION_NAME, False)
    assert not get_workbench().get_option(_OPTION_NAME)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME)
    toggle_variable()
    assert not get_workbench().get_option(_OPTION_NAME)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME)

# Generated at 2022-06-22 15:30:27.475538
# Unit test for function load_plugin
def test_load_plugin():
    global get_workbench
    # test that it does not crash
    load_plugin()
    assert "pgzero_mode" in get_workbench().get_defaults()


if __name__ == "__main__":
    load_plugin()

# Generated at 2022-06-22 15:30:28.917216
# Unit test for function update_environment
def test_update_environment():
    assert os.environ.get("PGZERO_MODE") == "False"

# Generated at 2022-06-22 15:30:36.873981
# Unit test for function load_plugin
def test_load_plugin():
    assert os.environ.get("PGZERO_MODE")
    get_workbench().set_simple_mode(True)
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, True)
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_option(_OPTION_NAME, False)
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_option(_OPTION_NAME, 1)
    assert os.environ["PGZERO_MODE"] == "1"

# Generated at 2022-06-22 15:30:38.227836
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()

# Generated at 2022-06-22 15:30:41.786736
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import Mock
    from collections import namedtuple

    Option = namedtuple("Option", ["name", "value"])
    Variable = namedtuple("Variable", ["name", "value"])

    workbench = Mock()
    workbench.get_option = lambda name: Option(name, str(not name.endswith("_OFF")))
    workbench.get_variable = lambda name: Variable(name, not name.endswith("_OFF"))

    assert update_environment() == None # function doesn't return anything

# Generated at 2022-06-22 15:30:46.772601
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert get_workbench().get_variable(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 15:30:52.702915
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench

    wb = Workbench(None, None)
    try:
        load_plugin()
        var = wb.get_variable(_OPTION_NAME)
        assert var.get() == False
    finally:
        wb.destroy()



# Generated at 2022-06-22 15:30:55.911302
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    wb.set_option(_OPTION_NAME, False)
    assert not wb.get_variable(_OPTION_NAME).get()
    toggle_variable()
    assert wb.get_variable(_OPTION_NAME).get()

# Generated at 2022-06-22 15:31:02.928347
# Unit test for function toggle_variable
def test_toggle_variable():
    workbench = get_workbench()
    var = workbench.get_variable(_OPTION_NAME)
    var.set(False)
    assert var.get() == False
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert var.get() == True
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert var.get() == False
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 15:31:21.218405
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import MagicMock
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 15:31:29.942898
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import MagicMock

    wb = MagicMock()
    wb.in_simple_mode.return_value = False
    wb.get_option.return_value = True
    get_workbench.return_value = wb

    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"

    wb.in_simple_mode.return_value = True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 15:31:40.536005
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock

    workbench = Mock()
    workbench.set_default = Mock()
    workbench.add_command = Mock()
    wb_get_variable = Mock()

    def get_option(name):
        if name == _OPTION_NAME:
            return wb_get_variable
        else:
            raise AssertionError("Unexpected name %s" % name)

    workbench.get_variable = wb_get_variable
    workbench.get_option = get_option

    import sys
    sys.modules["thonny"] = Mock()
  

# Generated at 2022-06-22 15:31:51.060432
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert _OPTION_NAME in get_workbench().get_default_value_names()
    assert _OPTION_NAME in get_workbench().get_variable_names()
    assert get_workbench().get_help_text("toggle_pgzero_mode") == tr("Pygame Zero mode")
    assert get_workbench().get_command("toggle_pgzero_mode").flag_name == _OPTION_NAME
    assert get_workbench().get_command("toggle_pgzero_mode").category == "run"
    assert get_workbench().get_command("toggle_pgzero_mode").group == 40
    assert "PGZERO_MODE" in os.environ


# Generated at 2022-06-22 15:31:57.457590
# Unit test for function load_plugin
def test_load_plugin():
    # Unit tests can't rely on current workbench
    from unittest import mock
    import os

    workbench = mock.MagicMock()
    load_plugin()

    assert workbench.set_default.call_args[0] == ("run.pgzero_mode", False)
    assert workbench.add_command.call_args[0][0] == "toggle_pgzero_mode"
    assert workbench.add_command.call_args[1]["flag_name"] == "run.pgzero_mode"
    assert workbench.in_simple_mode.return_value is True
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 15:32:01.504722
# Unit test for function update_environment
def test_update_environment():
    get_workbench().simple_mode = True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().simple_mode = False
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"

# Generated at 2022-06-22 15:32:06.356079
# Unit test for function update_environment
def test_update_environment():
    assert os.environ["PGZERO_MODE"] == "auto"
    os.environ.pop("PGZERO_MODE")
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 15:32:08.481850
# Unit test for function load_plugin
def test_load_plugin():
    # Setup
    get_workbench().set_default(_OPTION_NAME, False)
    # Exercise/Verify
    load_plugin()
    # Tear down



# Generated at 2022-06-22 15:32:14.720923
# Unit test for function load_plugin
def test_load_plugin():
    wb = WorkbenchForTesting()

    load_plugin()
    assert wb.get_option(_OPTION_NAME) == False
    wb.clear_all_caches()



# Generated at 2022-06-22 15:32:25.126926
# Unit test for function update_environment
def test_update_environment():
    from unittest import mock
    from thonny import get_workbench
    from thonny.workbench import Workbench
    from thonny.ui_utils import (
        SubclassableVar,
    )
    from thonny.languages import tr

    # Mock
    os.environ["PGZERO_MODE"] = "auto"
    mock_variable = SubclassableVar(True)

# Generated at 2022-06-22 15:32:41.462176
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench

    get_workbench().set_default(_OPTION_NAME, True)
    assert get_workbench().get_option(_OPTION_NAME) == True




# Generated at 2022-06-22 15:32:51.907110
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    assert wb.get_option(_OPTION_NAME) is False
    assert "PGZERO_MODE" not in os.environ
    load_plugin()
    assert wb.get_option(_OPTION_NAME) is False
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_option(_OPTION_NAME, True)
    assert wb.get_option(_OPTION_NAME) is True
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) is False
    assert os.environ["PGZERO_MODE"] == "False"
    wb.set_simple_mode(True)
    update_environment()

# Generated at 2022-06-22 15:33:02.118602
# Unit test for function load_plugin
def test_load_plugin():
    """For each command we check that it is added and can be executed."""
    import textwrap
    import unittest.mock
    import thonny
    from thonny.ui_utils import get_image_path
    from thonny.plugins.run.run_controller import _run_backend_cmd

    # When testing, we don't want to consider that the workbench is in simple mode.
    thonny.workbench.in_simple_mode = lambda: False

    assert thonny.workbench.get_variable(_OPTION_NAME) == False

    # This can't be tested because the "run.pgzero_mode" variable is not set.
    # assert run_controller._run_backend_cmd(['echo', '$PGZERO_MODE']) == 'auto\n'

    # Now we test that the

# Generated at 2022-06-22 15:33:11.873423
# Unit test for function update_environment
def test_update_environment():
    # Switch simple mode
    if get_workbench().in_simple_mode():
        get_workbench().execute_command("disable_simple_mode")
    assert get_workbench().in_simple_mode() == False

    get_workbench().get_variable(_OPTION_NAME).set(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().get_variable(_OPTION_NAME).set(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    # Switch simple mode
    if get_workbench().in_simple_mode():
        get_workbench().execute_command("disable_simple_mode")
    assert get_workbench().in_simple_mode() == True

    update_environment()

# Generated at 2022-06-22 15:33:17.732364
# Unit test for function load_plugin
def test_load_plugin():
    # Loading a plugin should not crash, even if user has no existing config or preferences
    load_plugin()
    assert "PGZERO_MODE" in os.environ
    assert not get_workbench().get_option(_OPTION_NAME)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME)
    assert "PGZERO_MODE" in os.environ
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 15:33:24.960390
# Unit test for function update_environment
def test_update_environment():
    from thonny.runner import Runner
    from thonny.shell import ShellTextWidget
    from unittest.mock import patch

    with patch("os.environ.clear"):
        with patch("os.environ.setdefault") as setdefault:
            Runner(None, ShellTextWidget())._update_environment()
        setdefault.assert_called_once_with("PGZERO_MODE", "auto")
    with patch("os.environ.clear"):
        with patch("os.environ.setdefault") as setdefault:
            with patch("thonny.get_workbench") as wb:
                wb.in_simple_mode.return_value = False
                wb.get_option.return_value = True
                Runner(None, ShellTextWidget())._update_environment()

# Generated at 2022-06-22 15:33:35.851175
# Unit test for function update_environment
def test_update_environment():
    import os
    get_workbench().set_default("run.pgzero_mode", True)
    get_workbench().set_default("view.simple_mode.enabled", False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_default("view.simple_mode.enabled", True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_default("run.pgzero_mode", False)
    get_workbench().set_default("view.simple_mode.enabled", False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_default("view.simple_mode.enabled", True)

# Generated at 2022-06-22 15:33:45.745133
# Unit test for function update_environment
def test_update_environment():
    from thonny.globals import get_workbench

    original = os.environ["PGZERO_MODE"]
    try:
        to_test = get_workbench()
        to_test.set_option("run.pgzero_mode", False)
        update_environment()
        assert os.environ["PGZERO_MODE"] == "False"
        to_test.set_option("run.pgzero_mode", True)
        update_environment()
        assert os.environ["PGZERO_MODE"] == "True"
    finally:
        os.environ["PGZERO_MODE"] = original

# Generated at 2022-06-22 15:33:48.719423
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().event_generate("PluginsLoaded")
    get_workbench().set_default(_OPTION_NAME, False)
    assert get_workbench().get_option(_OPTION_NAME) == False
    get_workbench().execute_command("toggle_pgzero_mode")
    assert get_workbench().get_option(_OPTION_NAME) == True

# Generated at 2022-06-22 15:33:55.264111
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 15:34:37.003101
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench
    from thonny.misc_utils import running_on_mac_os
    wb = get_workbench()
    assert wb.get_option(_OPTION_NAME) is False
    assert "PGZERO_MODE" not in os.environ
    load_plugin()
    assert wb.get_option(_OPTION_NAME) is False
    assert wb.get_command("toggle_pgzero_mode")

    if not running_on_mac_os():
        wb.set_simple_mode(True)
        load_plugin()
        assert "PGZERO_MODE" in os.environ and os.environ["PGZERO_MODE"] == "auto"
        wb.set_simple_mode(False)

# Generated at 2022-06-22 15:34:41.848455
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME)
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 15:34:51.823958
# Unit test for function update_environment
def test_update_environment():
    old_mode = os.environ.get("PGZERO_MODE")
    load_plugin()

    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ.get("PGZERO_MODE") == "auto"
    get_workbench().set_simple_mode(False)

    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ.get("PGZERO_MODE") == "True"

    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ.get("PGZERO_MODE") == "False"

    get_workbench().set_simple_mode(True)
    update_environment()

# Generated at 2022-06-22 15:34:55.504902
# Unit test for function load_plugin
def test_load_plugin():
    import thonny.plugins.pgzero
    thonny.plugins.pgzero.load_plugin()

# Generated at 2022-06-22 15:35:04.999814
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_simple_mode(True)
    assert os.environ.get("PGZERO_MODE") == "auto"
    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, True)
    assert os.environ.get("PGZERO_MODE") == "True"
    get_workbench().set_option(_OPTION_NAME, False)
    assert os.environ.get("PGZERO_MODE") == "False"

# Generated at 2022-06-22 15:35:11.428740
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, True)
    assert wb.get_variable(_OPTION_NAME).get()

    load_plugin()
    assert not wb.get_variable(_OPTION_NAME).get()
    assert os.environ["PGZERO_MODE"] == "0"

if __name__ == "__main__":
    wb = get_workbench()
    wb.set_simple_mode(True)
    load_plugin()
    wb.run_command("toggle_pgzero_mode")
    wb.set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"

# Generated at 2022-06-22 15:35:21.550661
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_option(_OPTION_NAME, False)
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().set_option(_OPTION_NAME, False)
    get_workbench().set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_option(_OPTION_NAME, True)
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().set_option(_OPTION_NAME, True)
    get_workbench().set_simple_

# Generated at 2022-06-22 15:35:30.136119
# Unit test for function load_plugin
def test_load_plugin():
    # Check that the "Pygame Zero mode" command has the right flag_name
    get_workbench().set_default("language", "en")
    load_plugin()
    assert get_workbench().get_option("run.pgzero_mode") is False
    cmd = get_workbench().get_command("toggle_pgzero_mode")
    assert cmd.get_label() == "Pygame Zero mode"
    assert cmd.get_group() == 40
    assert cmd.get_flag_name() == _OPTION_NAME
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 15:35:33.405829
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench

    get_workbench().in_simple_mode = lambda: False
    get_workbench().get_option = lambda x: False
    os.environ["PGZERO_MODE"] = "foo"
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().get_option = lambda x: True
    os.environ["PGZERO_MODE"] = "bar"
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().in_simple_mode = lambda: True
    os.environ["PGZERO_MODE"] = "baz"
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 15:35:37.562007
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = ""
    load_plugin()
    assert os.environ["PGZERO_MODE"] == "False"

    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"

    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 15:36:29.932260
# Unit test for function toggle_variable
def test_toggle_variable():    
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"
    
    
    
## Unit test for function load_plugin()
#def test_load_plugin():
#    load_plugin()
#    assert os.environ["PGZERO_MODE"] == "False"
#    toggle_variable()
#    assert os.environ["PGZERO_MODE"] == "True"
#    toggle_variable()
#    assert os.environ["PGZERO_MODE"] == "False"
#    
#

# Generated at 2022-06-22 15:36:39.433510
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench

    Workbench.create_default_shell = lambda self: None
    Workbench.set_default = lambda self, option_id, value: None
    Workbench.in_simple_mode = lambda: False
    Workbench.get_option = lambda self, option_id: True
    Workbench.add_command = lambda *args: None
    os.environ["PGZERO_MODE"] = ""
    old_set_environment = os.environ.__setitem__

    try:
        os.environ.__setitem__ = lambda self, key, value: None
        load_plugin()
    finally:
        os.environ.__setitem__ = old_set_environment

# Generated at 2022-06-22 15:36:46.111934
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_option(_OPTION_NAME, False)
    os.environ["PGZERO_MODE"] = "auto"
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME)
    assert os.environ["PGZERO_MODE"] == "1"
    toggle_variable()
    assert not get_workbench().get_option(_OPTION_NAME)
    assert os.environ["PGZERO_MODE"] == "0"


if __name__ == "__main__":
    print(update_environment())
    print(toggle_variable())

# Generated at 2022-06-22 15:36:56.290441
# Unit test for function update_environment
def test_update_environment():
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_simple_mode(False)
    get_workbench().set_default("test_pgzero_mode", False)
    os.environ.pop("PGZERO_MODE")
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"
    get_workbench().set_option("test_pgzero_mode", True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 15:37:03.880577
# Unit test for function update_environment
def test_update_environment():
    from thonny.misc_utils import running_on_windows
    import tkinter as tk
    if running_on_windows():
        # Running tests on Windows is problematic as
        # pythonw.exe doesn't support changing sys.stdout
        return

    root = tk.Tk()
    root.withdraw()

# Generated at 2022-06-22 15:37:05.214159
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    # no crash
    assert "PGZERO_MODE" in os.environ



# Generated at 2022-06-22 15:37:07.044505
# Unit test for function toggle_variable
def test_toggle_variable():
    option = get_workbench().get_option(_OPTION_NAME)
    get_workbench().set_option(_OPTION_NAME, option)
    assert option == get_workbench().get_option(_OPTION_NAME)

# Generated at 2022-06-22 15:37:11.534555
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench

    wb = Workbench()
    original_value = wb.get_option(_OPTION_NAME)

    load_plugin()
    assert wb.get_option(_OPTION_NAME) == original_value

# Generated at 2022-06-22 15:37:19.891423
# Unit test for function update_environment
def test_update_environment():
    from unittest import mock
    import os

    mb = mock.MagicMock()
    mb.in_simple_mode.return_value = True
    mb.get_option.return_value = True
    with mock.patch("thonny.globals.get_workbench", return_value=mb):
        update_environment()
        assert os.environ["PGZERO_MODE"] == "auto"
    with mock.patch("thonny.globals.get_workbench", return_value=mb):
        update_environment()
        assert os.environ["PGZERO_MODE"] == "True"

if __name__ == "__main__":
    load_plugin()

# Generated at 2022-06-22 15:37:28.886317
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench
    from thonny.misc_utils import running_on_mac_os, running_on_windows
    from unittest.mock import MagicMock
    from thonny.workbench import Workbench
    wb = get_workbench().__class__()
    wb.in_simple_mode = MagicMock()
    wb.get_option = MagicMock()
    os.environ["PGZERO_MODE"] = "test"
    wb.in_simple_mode.return_value = True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    wb.in_simple_mode.return_value = False
    wb.get_option.return_value = False
    update_environment()