

# Generated at 2022-06-22 15:27:57.787212
# Unit test for function load_plugin
def test_load_plugin():
    print("test_load_plugin")
    load_plugin()

    # check command added
    get_workbench().get_command("toggle_pgzero_mode")

    # check options
    get_workbench().get_variable(_OPTION_NAME)
    assert get_workbench().get_variable(_OPTION_NAME) == False


if __name__ == "__main__":
    test_load_plugin()

# Generated at 2022-06-22 15:28:03.496513
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = ""
    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_simple_mode(True)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"



# Generated at 2022-06-22 15:28:13.554973
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()

    wb.set_default(_OPTION_NAME, None)
    load_plugin()

    assert wb.get_default(_OPTION_NAME) is False
    assert len(wb.get_option(_OPTION_NAME, True)) == 2
    assert wb.get_variable(_OPTION_NAME).get() is False

    wb.set_default(_OPTION_NAME, None)
    load_plugin()

    assert wb.get_default(_OPTION_NAME) is True
    assert len(wb.get_option(_OPTION_NAME, True)) == 2
    assert wb.get_variable(_OPTION_NAME).get() is True

    wb.set_default(_OPTION_NAME, None)
    load_plugin()


# Generated at 2022-06-22 15:28:25.297335
# Unit test for function update_environment
def test_update_environment():
    from thonny.running import set_simple_mode
    from unittest.mock import patch

    env = os.environ.copy()
    with patch.dict(os.environ, env, clear=True):
        update_environment()
        assert os.environ["PGZERO_MODE"] == "False"

    with patch.dict(os.environ, env, clear=True):
        set_simple_mode(True)
        update_environment()
        assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 15:28:34.725234
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench

    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    assert os.environ.get("PGZERO_MODE") == "False"



# Generated at 2022-06-22 15:28:41.931527
# Unit test for function load_plugin
def test_load_plugin():
    root = get_workbench().get_option("paths.workbench_dir")
    old_path = os.environ["PATH"]
    old_pgzero_mode = os.environ.get("PGZERO_MODE")

# Generated at 2022-06-22 15:28:50.057627
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    
    from test_simple_mode import test_start_simple_mode
    test_start_simple_mode()
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 15:28:58.527371
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_runner, get_workbench
    from thonny.languages import tr
    from thonny.plugins.games.pgzrun_service import get_pgzero_mode, set_pgzero_mode
    from thonny.plugins.games.pgzrun_service import get_pgzero_mode_env_var, set_pgzero_mode_env_var
    runner = get_runner()
    wb = get_workbench()
    wb.unregister_command("toggle_pgzero_mode")
    wb.unset_option(_OPTION_NAME)
    assert not get_pgzero_mode()
    assert not bool(get_pgzero_mode_env_var())

    load_plugin()


# Generated at 2022-06-22 15:29:05.234070
# Unit test for function update_environment
def test_update_environment():
    from ri import get_tkinter_master
    import os
    from thonny import get_workbench
    from thonny.workbench import Workbench
    from thonny import ui_utils

    os.environ["PGZERO_MODE"] = ""
    master = get_tkinter_master()
    workbench = Workbench(master)
    workbench.set_default(_OPTION_NAME, False)
    assert os.environ["PGZERO_MODE"] == ""
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"
    workbench.set_option(_OPTION_NAME, True)
    update_environment()
    #print(os.environ["PGZERO_MODE"])

# Generated at 2022-06-22 15:29:11.082759
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench
    from thonny.shell import ShellTextWidget
    from unittest import mock

    workbench = get_workbench()

    mcc = mock.Mock()
    mcc.get_current_editor = mock.Mock()
    mcc.get_current_editor.return_value.get_filename = mock.Mock()
    mcc.get_current_editor.return_value.get_filename.return_value = "My Program.py"
    mcc.busy = mock.Mock()
    mcc.busy.return_value = False
    mcc.add_backend_option = mock.Mock()
    mcc.add_backend_option.return_value = None
    mcc.add_command = mock.Mock()
    mcc.add

# Generated at 2022-06-22 15:29:16.219575
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    # Checking if toggle command is available
    assert "toggle_pgzero_mode" in get_workbench().commands

# Generated at 2022-06-22 15:29:20.591381
# Unit test for function load_plugin
def test_load_plugin():
    unload_plugin()
    load_plugin()
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME)
    toggle_variable()
    assert not get_workbench().get_option(_OPTION_NAME)



# Generated at 2022-06-22 15:29:32.563084
# Unit test for function update_environment
def test_update_environment():
    from thonny import ui_utils
    from thonny.simple_editor import SimpleEditorWindow
    from thonny.codeview import CodeView
    import os

    def mw_factory():
        return ui_utils.run_in_top_level_wrapper(SimpleEditorWindow.main)

    def cw_factory():
        return CodeView(ui_utils.run_in_top_level_wrapper(SimpleEditorWindow.main))

    from thonny.misc_utils import running_on_windows, running_on_mac_os

    # Editor is running in simple mode
    os.environ["PGZERO_MODE"] = "True"
    get_workbench().set_option(_OPTION_NAME, True)
    assert os.environ["PGZERO_MODE"] == "True"
    get_work

# Generated at 2022-06-22 15:29:37.232687
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    old_mode = wb.get_option("run.pgzero_mode")
    toggle_variable()
    new_mode = wb.get_option("run.pgzero_mode")
    assert old_mode != new_mode
    toggle_variable()
    new_mode = wb.get_option("run.pgzero_mode")
    assert old_mode == new_mode

# Generated at 2022-06-22 15:29:37.687163
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()

# Generated at 2022-06-22 15:29:46.808384
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    old_active_group = wb.get_default("view.active_group")
    wb.set_default("view.active_group", wb.default_group_name)
    wb.set_default(_OPTION_NAME, False)
    load_plugin()
    assert wb.get_command("toggle_pgzero_mode")
    assert not os.environ["PGZERO_MODE"]
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert not os.environ["PGZERO_MODE"]
    wb.set_default("view.active_group", old_active_group)

# Generated at 2022-06-22 15:30:00.750258
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.globals import get_workbench
    from thonny.misc_utils import running_on_mac_os
    from thonny.misc_utils import running_on_windows

    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    assert os.environ["PGZERO_MODE"] == "False"
    localvars = locals()
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    get_work

# Generated at 2022-06-22 15:30:02.954080
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    load_plugin()
    assert os.environ["PGZERO_MODE"] == "False"
    assert isinstance(wb.get_option(_OPTION_NAME), bool)



# Generated at 2022-06-22 15:30:09.472199
# Unit test for function load_plugin
def test_load_plugin():
    w = get_workbench()
    assert not w.in_simple_mode()
    assert not w.get_option(_OPTION_NAME)
    assert os.environ["PGZERO_MODE"] == "False"

    toggle_variable()
    assert w.get_option(_OPTION_NAME)
    assert os.environ["PGZERO_MODE"] == "True"

    toggle_variable()
    assert not w.get_option(_OPTION_NAME)
    assert os.environ["PGZERO_MODE"] == "False"



# Generated at 2022-06-22 15:30:19.637796
# Unit test for function toggle_variable
def test_toggle_variable():
    import unittest
    import unittest.mock
    from thonny.workbench import Workbench

    class MockWorkbench(Workbench):
        def get_variable(self, name):
            class MockVariable:
                def __init__(self):
                    self.value = False
                def set(self, value):
                    self.value = value
                def get(self):
                    return self.value
            return MockVariable()
        def get_option(self, name):
            return None
        def in_simple_mode(self):
            return False

    with unittest.mock.patch("thonny.plugins.pgzero_mode.get_workbench", return_value=MockWorkbench()):
        import thonny.plugins.pgzero_mode
        toggle_variable()
        import os

# Generated at 2022-06-22 15:30:26.592252
# Unit test for function load_plugin
def test_load_plugin():
    assert get_workbench().get_default(_OPTION_NAME) == False

# Generated at 2022-06-22 15:30:32.135367
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, True)
    get_workbench().set_simple_mode(True)
    get_workbench().set_option(_OPTION_NAME, False)
    get_workbench().set_option(_OPTION_NAME, True)
    get_workbench().set_option(_OPTION_NAME, False)

# Generated at 2022-06-22 15:30:36.615720
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = "auto"
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"
    
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"

# Generated at 2022-06-22 15:30:41.631976
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.globals import get_workbench
    try:
        import pgzero
    except:
        raise Exception("The plugin cannot be tested because package pgzero is not available.")

    # read configuration
    get_workbench().set_default(_OPTION_NAME, True)
    # testing
    assert get_workbench().get_variable(_OPTION_NAME).get() == True
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == True

# Generated at 2022-06-22 15:30:46.374119
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.globals import get_workbench
    wb = get_workbench()
    wb.set_simple_mode(True)
    wb.set_default(_OPTION_NAME, False)
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == True


# Generated at 2022-06-22 15:30:57.515426
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock
    from thonny.misc_utils import running_on_mac_os

    mock_workbench = Mock()

    class Options:
        def __init__(self):
            self.get = Mock(return_value=False)

    mock_workbench.in_simple_mode = Mock(return_value=False)
    mock_workbench.get_option = Mock(return_value=False)
    mock_workbench.get_variable = Mock(return_value=Options())
    mock_workbench.add_command = Mock()
    mock_workbench.set_default = Mock()

    original_environ = os.environ.copy()

    load_plugin()
    mock_workbench.set_default.assert_called_once_with(_OPTION_NAME, False)
    mock

# Generated at 2022-06-22 15:31:01.113096
# Unit test for function toggle_variable
def test_toggle_variable():
    """Testing whether the toggle_variable function works"""
    var = get_workbench().get_variable(_OPTION_NAME)
    var.set(False)
    toggle_variable()
    assert var.get()
    toggle_variable()
    assert not var.get()

# Generated at 2022-06-22 15:31:11.452632
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny import get_workbench
    from thonny.languages import tr
    from thonny import ui_utils
    from thonny.ui_utils import question_dialog
    from thonny.ui_utils import show_error
    from thonny.ui_utils import show_info


    def question_dialog(title, message, *args, **kwds):
        return True

    def show_error(message, *args, **kwds):
        return True
    # mock show error function to avoid an error message when testing

    def show_info(title, message, *args, **kwds):
        # mock show info to display message if test was successful
        showInfo = "message displayed"

    def tkRoot():
        return True

    import unittest
    import unittest.mock

# Generated at 2022-06-22 15:31:18.392834
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    workbench = get_workbench()
    assert workbench.get_variable(_OPTION_NAME).get() == False
    assert workbench.get_option(_OPTION_NAME) == False
    workbench.get_variable(_OPTION_NAME).set(True)
    assert workbench.get_option(_OPTION_NAME) == True
    assert 'PGZERO_MODE' in os.environ
    assert os.environ['PGZERO_MODE'] == "False"
    os.environ['THONNY_SIMPLE'] = '1'
    toggle_variable()
    assert workbench.get_option(_OPTION_NAME) == False
    assert os.environ['PGZERO_MODE'] == "auto"
    del os.environ['THONNY_SIMPLE']
    toggle_variable()

# Generated at 2022-06-22 15:31:23.251567
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_option(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME)
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 15:31:33.319444
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.config_ui import ConfigurationDialog
    from thonny import get_workbench

    def mycb():
        var = get_workbench().get_variable(_OPTION_NAME)
        assert var.get() == True

    # Add a callback to know when the toggle is clicked
    get_workbench().add_command("toggle_pgzero_mode", None, None, mycb)
    # Create a configuration dialog to toggle the variable
    ConfigurationDialog(get_workbench(), "").show_long_status(
        "Pygame Zero mode", "", "", _OPTION_NAME
    )

# Generated at 2022-06-22 15:31:40.282354
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()

    # test that plugin is loaded
    if not (
        get_workbench().get_command("toggle_pgzero_mode")
        and get_workbench().get_default(_OPTION_NAME) is False
        and os.environ["PGZERO_MODE"] == "False"
    ):
        raise AssertionError


if __name__ == "__main__":
    test_load_plugin()

# Generated at 2022-06-22 15:31:47.037141
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )



# Generated at 2022-06-22 15:31:55.158741
# Unit test for function load_plugin
def test_load_plugin():
    test_mode = MagicMock()
    get_workbench().get_option = test_mode
    load_plugin()
    assert len(get_workbench().commands["run"]._commands.keys()) == 2
    test_mode.assert_called()
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

# Generated at 2022-06-22 15:31:57.649189
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = "auto"
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 15:32:00.268736
# Unit test for function toggle_variable
def test_toggle_variable():
    global _OPTION_NAME
    _OPTION_NAME = "_OPTION_NAME"
    var = get_workbench().get_variable(_OPTION_NAME)
    var.set(False)
    toggle_variable()
    assert var.get() == True
    toggle_variable()
    assert var.get() == False

# Generated at 2022-06-22 15:32:11.174268
# Unit test for function update_environment
def test_update_environment():
    from unittest import mock
    from thonny.globals import get_workbench

    workbench = get_workbench()

    with mock.patch.object(workbench, 'in_simple_mode', return_value=False):
        with mock.patch.object(workbench, 'get_option', return_value=True):
            update_environment()
            assert os.environ["PGZERO_MODE"] == "True"
            update_environment()
            assert os.environ["PGZERO_MODE"] == "True"

            workbench.get_option.assert_called_with(_OPTION_NAME)

        with mock.patch.object(workbench, 'get_option', return_value=False):
            update_environment()
            assert os.environ["PGZERO_MODE"] == "False"
            update_

# Generated at 2022-06-22 15:32:13.551327
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    if _OPTION_NAME not in wb._commands:
        raise AssertionError("Command not found")



# Generated at 2022-06-22 15:32:23.150160
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = ""
    get_workbench().set_option(_OPTION_NAME, "")
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    os.environ["PGZERO_MODE"] = ""
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"

    os.environ["PGZERO_MODE"] = ""
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"

# Generated at 2022-06-22 15:32:28.434385
# Unit test for function update_environment
def test_update_environment():
    workbench = get_workbench()
    assert "PGZERO_MODE" not in os.environ
    workbench.set_default(_OPTION_NAME, True)
    workbench.set_option("view.simple_mode", False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    workbench.set_default(_OPTION_NAME, False)
    workbench.set_option("view.simple_mode", True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 15:32:49.373195
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench
    from thonny.languages import tr
    from thonny.workbench import Workbench

    wb = Workbench()
    try:
        load_plugin()
        var = wb.get_variable(_OPTION_NAME)
        assert var == False
    except Exception as e:
        raise e
    finally:
        wb.destroy()

if __name__ == "__main__":
    test_load_plugin()

# Generated at 2022-06-22 15:32:58.881914
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench, SimpleWorkbench
    from thonny.misc_utils import running_on_mac_os

    os.environ["PGZERO_MODE"] = "default"
    workbench = Workbench()
    simple_workbench = SimpleWorkbench()

    workbench.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1" or os.environ["PGZERO_MODE"] == "true"

    workbench.set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0" or os.environ["PGZERO_MODE"] == "false"

    # On Mac OS, PGZERO_MODE is set to auto, because

# Generated at 2022-06-22 15:33:10.046257
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.config_ui import ConfigurationPage
    from tkinter import Tk, StringVar
    from tkinter.ttk import Checkbutton
    from thonny.ui_utils import CommonCheckbuttonWithVar
    import os
    import thonny

    root = Tk()
    get_workbench().set_default(_OPTION_NAME, False)
    wb = Workbench(root)
    page = ConfigurationPage(wb.get_option_page("Run"))
    page.grid(row=0, column=0, sticky="nswe")

    page.widgets["pg_zero_check"]["variable"].set(False)
    os.environ["PGZERO_MODE"] = "auto"
    update_environment()

# Generated at 2022-06-22 15:33:14.870313
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, True)
    toggle_variable()
    assert not wb.get_variable(_OPTION_NAME).get()
    toggle_variable()
    assert wb.get_variable(_OPTION_NAME).get()

# Generated at 2022-06-22 15:33:18.740696
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny import get_workbench
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-22 15:33:21.860024
# Unit test for function update_environment
def test_update_environment():
    import os
    import ast
    from thonny.globals import get_workbench
    get_workbench().set_default(_OPTION_NAME, True)

    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 15:33:27.556756
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    try:
        wb.set_simple_mode()
        wb.set_option(_OPTION_NAME, False)
        assert os.environ["PGZERO_MODE"] == "auto"
        toggle_variable()
        assert os.environ["PGZERO_MODE"] == "auto"
        
        wb.set_simple_mode(False)
        wb.set_option(_OPTION_NAME, False)
        assert os.environ["PGZERO_MODE"] == "0"
        toggle_variable()
        assert os.environ["PGZERO_MODE"] == "1"
        toggle_variable()
        assert os.environ["PGZERO_MODE"] == "0"
    finally:
        wb.set_simpl

# Generated at 2022-06-22 15:33:34.836359
# Unit test for function load_plugin
def test_load_plugin():
    workbench = MockWorkbench()
    sys.modules["thonny.globals"] = workbench
    load_plugin()
    assert workbench.get_variable(_OPTION_NAME).get() == False
    assert workbench.get_command("toggle_pgzero_mode").label == tr("Pygame Zero mode")
    assert workbench.get_command("toggle_pgzero_mode").flag_name == _OPTION_NAME
    assert workbench.get_command("toggle_pgzero_mode").group == 40

# Generated at 2022-06-22 15:33:43.386930
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    old_get_option = wb.get_option
    old_set_default = wb.set_default
    old_add_command = wb.add_command


# Generated at 2022-06-22 15:33:46.711893
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    os.environ["PGZERO_MODE"] = "auto"


# Generated at 2022-06-22 15:34:22.170747
# Unit test for function update_environment
def test_update_environment():
    from thonny.common import InlineCommand
    get_workbench().set_variable(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_variable(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_variable(_OPTION_NAME, "test")
    update_environment()
    assert os.environ["PGZERO_MODE"] == "test"
    get_workbench().set_in_simple_mode(True)
    InlineCommand.set_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    # Inline command
   

# Generated at 2022-06-22 15:34:28.821811
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench
    from thonny.misc_utils import running_on_mac_os

    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    # On mac os only simple mode is enabled
    if running_on_mac_os():
        wb.set_default(_OPTION_NAME, True)
        update_environment()
        assert os.environ["PGZERO_MODE"] == "True"
    else:
        # On other OSes set it to simple mode
        wb.set_default(_OPTION_NAME, True)
        wb.set_simple_mode(True)
        update_environment()

# Generated at 2022-06-22 15:34:34.216957
# Unit test for function load_plugin
def test_load_plugin():
    workbench = get_workbench()
    workbench.set_default(_OPTION_NAME, True)
    load_plugin()
    assert workbench.get_option(_OPTION_NAME) == False
    assert workbench.get_option("run.pgzero_mode") == False


# Generated at 2022-06-22 15:34:41.643306
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert get_workbench().get_default(_OPTION_NAME) == False
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert get_workbench().get_command("toggle_pgzero_mode")
    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    assert os.environ["PGZERO_MODE"] == "auto"

    # Enable pgzero mode
    toggle_variable()

    assert get_workbench().get_default(_OPTION_NAME) == False
    assert get_workbench().get_option(_OPTION_NAME) == True
    assert get_workbench().get_command("toggle_pgzero_mode")
    assert get_workbench().get_variable(_OPTION_NAME).get() == True
    assert os.environ

# Generated at 2022-06-22 15:34:51.687958
# Unit test for function update_environment
def test_update_environment():
    assert os.environ.get("PGZERO_MODE", None) is None
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ.get("PGZERO_MODE", None) == "False"
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ.get("PGZERO_MODE", None) == "True"
    get_workbench().set_default(_OPTION_NAME, True)
    get_workbench().enter_simple_mode()
    update_environment()
    assert os.environ.get("PGZERO_MODE", None) == "auto"
    get_workbench().leave_simple_mode()
    update_environment()

# Generated at 2022-06-22 15:34:59.778418
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import workbench
    from thonny.config import get_user_config_dir

    load_plugin()
    assert workbench.get_default(_OPTION_NAME) is False
    # Check that the variable is under .thonny/config
    assert os.path.isfile(os.path.join(get_user_config_dir(), "variables.json"))
    # Check that the variable was added to the commands.
    assert "toggle_pgzero_mode" in workbench.commands.keys()

# Generated at 2022-06-22 15:35:09.474735
# Unit test for function update_environment
def test_update_environment():
    if os.environ.get("PGZERO_MODE") is not None:
        del os.environ["PGZERO_MODE"]

    # basic - assume false by default
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"

    # basic - assume true by default
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"

    # simple mode
    get_workbench().enter_simple_mode()
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    # leave simple mode
    get_workbench().leave_simple_mode()
    update_environment()

# Generated at 2022-06-22 15:35:16.783688
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 15:35:23.864865
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import MagicMock

    get_workbench().in_simple_mode = MagicMock(return_value=False)
    get_workbench().get_option = MagicMock(return_value=False)
    load_plugin()
    assert get_workbench().in_simple_mode.call_count == 3
    assert get_workbench().get_option.call_count == 2
    assert get_workbench().get_option.call_args[0] == (_OPTION_NAME,)
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().reset_mock()

    get_workbench().in_simple_mode = MagicMock(return_value=True)
    load_plugin()
    assert get_workbench().in_simple_mode.call_count

# Generated at 2022-06-22 15:35:32.030693
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "environment",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )

    assert get_workbench().get_option(_OPTION_NAME) == False

    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True

    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

if __name__ == "__main__":
    load_plugin()
    test_load_plugin()

# Generated at 2022-06-22 15:36:26.767608
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    assert wb.get_variable(_OPTION_NAME).get() == False
    get_workbench().in_simple_mode = lambda: True
    toggle_variable()
    assert wb.get_variable(_OPTION_NAME).get() == True

    get_workbench().in_simple_mode = lambda: False
    toggle_variable()
    assert wb.get_variable(_OPTION_NAME).get() == False

# Generated at 2022-06-22 15:36:31.656536
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, True)
    get_workbench().set_option(_OPTION_NAME, True)
    assert get_workbench().get_option(_OPTION_NAME) is True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) is False
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 15:36:40.269315
# Unit test for function update_environment
def test_update_environment():
    # without extension
    from importlib import reload
    import os
    from thonny.config import load_configuration, get_workbench
    from thonny.languages import tr
    from thonny.common import InProgramMode
    from thonny.plugins.backend_server import create_backend_server
    from thonny.plugins.simple_mode import _OPTION_NAME, toggle_variable
    import __main__


    # This will be used by the extension to detect when it's running as unit test
    __main__.__unittest = True
    # This will allow the plugin to be loaded by the workbench
    __main__.USE_SIMPLE_BACKEND = False

    # reset configuration
    load_configuration()

    # reset language
    tr._ = tr.gettext

    # setup workbench


# Generated at 2022-06-22 15:36:43.209978
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    assert not get_workbench().get_option(_OPTION_NAME)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME)
    toggle_variable()
    assert not get_workbench().get_option(_OPTION_NAME)



# Generated at 2022-06-22 15:36:45.016820
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()
    assert True

# Generated at 2022-06-22 15:36:46.748477
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, True)
    toggle_variable()
    assert get_workbench().ge

# Generated at 2022-06-22 15:36:53.602227
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert not get_workbench().get_option(_OPTION_NAME)
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME)
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert not get_workbench().get_option(_OPTION_NAME)
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 15:37:01.458243
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    bg = get_workbench().get_default(_OPTION_NAME)
    load_plugin()
    fg = get_workbench().get_default(_OPTION_NAME)
    assert bg is False and fg is False

# Generated at 2022-06-22 15:37:04.275270
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get()
    toggle_variable()
    assert not get_workbench().get_variable(_OPTION_NAME).get()

# Generated at 2022-06-22 15:37:05.359187
# Unit test for function update_environment
def test_update_environment():
    assert os.environ["PGZERO_MODE"] == "auto"