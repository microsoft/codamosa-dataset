

# Generated at 2022-06-22 15:26:43.205190
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench
    from unittest.mock import patch, MagicMock

    with patch.dict(os.environ, {"PGZERO_MODE": "auto"}, clear=True):
        # Create mock workbench
        wb = MagicMock()
        wb.get_option.return_value = False
        wb.in_simple_mode.return_value = False

        # Set mock workbench to be used by update_environment
        get_workbench.set(wb)
        update_environment()
        assert os.environ.get("PGZERO_MODE") == "False"
        wb.get_option.return_value = True
        update_environment()
        assert os.environ.get("PGZERO_MODE") == "True"

# Generated at 2022-06-22 15:26:53.341789
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_simple_mode(True)
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() is False
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() is True
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() is False

    get_workbench().set_simple_mode(False)
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() is True
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() is False
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() is True

# Generated at 2022-06-22 15:27:10.234440
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.set_variable('run.pgzero_mode', False)
    load_plugin()
    assert wb.get_option(_OPTION_NAME) == False
    assert wb.get_variable(_OPTION_NAME) == False

# Generated at 2022-06-22 15:27:16.102327
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == False

    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"


# Generated at 2022-06-22 15:27:28.488164
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock, MagicMock
    from thonny.workbench import Workbench

    workbench = MagicMock()
    workbench.in_simple_mode = Mock(return_value=True)
    workbench.get_variable = Mock(return_value=False)

    # create a module that adds a command based on the main frame:
    import sys
    import os
    from thonny.workbench import Workbench
    from thonny.languages import tr

    old_workbench = sys.modules["thonny.workbench"]
    sys.modules["thonny.workbench"] = workbench


# Generated at 2022-06-22 15:27:40.342730
# Unit test for function load_plugin
def test_load_plugin():
    from unittest import mock
    from thonny.globals import get_workbench
    from thonny import ui_utils

    wb = get_workbench()
    
    test_name = "test_load_plugin"
    wb.set_option(test_name, "test_value")
    assert wb.get_option(test_name) == True

    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().set_variable(_OPTION_NAME, False)

    wb.get_variable(_OPTION_NAME)
    assert wb.get_variable(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "auto"

    test_value = "test_value"

# Generated at 2022-06-22 15:27:49.329776
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock

    get_workbench = Mock()
    get_workbench().in_simple_mode.return_value = False
    get_workbench().get_option.return_value = True
    get_workbench().set_default.return_value = None
    get_workbench().add_command.return_value = None
    globals()["get_workbench"] = get_workbench
    load_plugin()
    assert get_workbench().set_default.call_count == 1
    assert get_workbench().add_command.call_count == 1
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 15:27:55.389674
# Unit test for function load_plugin
def test_load_plugin():
    """
    This unit test test the function load_plugin.
    """
    from thonny.workbench import Workbench

    workbench = Workbench()
    load_plugin()
    assert workbench.get_command("toggle_pgzero_mode") is not No

# Generated at 2022-06-22 15:28:02.549750
# Unit test for function load_plugin
def test_load_plugin():
    """Unit test for function load_plugin."""
    from thonny.workbench import Workbench

    # Create a workbench with mocked classes
    workbench = Workbench()
    workbench.set_default = MagicMock()
    workbench.add_command = MagicMock()

    # Call the function
    load_plugin()

    # Test if the workbench calls the set default and add command function
    workbench.set_default.assert_called_with(_OPTION_NAME, False)
    workbench.add_command.assert_called_with(
        "toggle_pgzero_mode",
        "run",
        ANY,
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )

# Generated at 2022-06-22 15:28:13.065042
# Unit test for function update_environment
def test_update_environment():
    get_workbench = MagicMock()
    get_workbench.in_simple_mode = Mock(return_value=False)
    get_workbench.get_option = Mock(return_value=True)
    os.environ = {
        "VIRTUAL_ENV": "/home/user/thonny/venv/",
        "PGZERO_MODE": "off",
    }
    update_environment()
    assert os.environ["PGZERO_MODE"] == "on"
    get_workbench.get_option = Mock(return_value=False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "off"
    get_workbench.in_simple_mode = Mock(return_value=True)
    update_environment()

# Generated at 2022-06-22 15:28:29.410955
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.unload_plugin_by_name("pgzero_mode")
    wb.unload_plugin_by_name("pgzero_mode")
    wb.load_plugin("pgzero_mode")
    wb.load_plugin("pgzero_mode")

# Generated at 2022-06-22 15:28:39.721866
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock, MagicMock

    get_workbench = Mock()
    set_default = MagicMock()
    set_default.get = Mock(return_value="True")
    get_workbench.set_default = set_default
    add_command = MagicMock()
    get_workbench.add_command = add_command
    load_plugin()

    assert get_workbench.mock_calls[0][0] == "set_default"
    assert get_workbench.mock_calls[0][1][0] == "run.pgzero_mode"
    assert get_workbench.mock_calls[0][1][1] == False
    assert get_workbench.mock_calls[1][0] == "add_command"
    assert get_workbench

# Generated at 2022-06-22 15:28:47.101598
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    wb = Workbench()
    wb._configuration = {"run": {"pgzero_mode": True}}
    wb.in_simple_mode = lambda: False
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    wb._configuration = {"run": {"pgzero_mode": False}}
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    wb.in_simple_mode = lambda: True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 15:28:56.381266
# Unit test for function load_plugin
def test_load_plugin():
    assert not get_workbench().in_simple_mode()
    from thonny.globals import load_workbench
    from unittest import mock

    for var_name in ("PGZERO_MODE", "RESOURCES_PATH", "RESOURCES_DIR"):
        if var_name in os.environ:
            del os.environ[var_name]

    with mock.patch("thonny.plugins.pgzero.get_workbench") as mock_get_workbench:
        mock_wb = mock.Mock(spec_set=["set_default", "add_command"])
        mock_get_workbench.return_value = mock_wb
        load_workbench()
        mock_wb.set_default.assert_called_once_with("run.pgzero_mode", False)
       

# Generated at 2022-06-22 15:28:58.388327
# Unit test for function update_environment
def test_update_environment():
    from thonny.workflow import SubprocessEnvironment

    env = SubprocessEnvironment()
    # Simple mode doesn't support Pygame Zero
    env.update()
    assert "PGZERO_MODE" not in os.environ

# Generated at 2022-06-22 15:29:01.900441
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import Mock
    from thonny.globals import get_workbench
    from thonny.workbench import Workbench
    from thonny.options import Configuration

    get_workbench = get_workbench
    wb = get_workbench()
    wb._ini_filename = '.'
    wb._user_dir = '.'
    wb._options = Mock(spec=Configuration)
    wb._options.get.return_value = True
    wb.in_simple_mode = Mock(return_value=False)
    del os.environ["PGZERO_MODE"]
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench = get_workbench
    wb = get_workbench()
    wb

# Generated at 2022-06-22 15:29:09.569416
# Unit test for function load_plugin
def test_load_plugin():
    original_config = get_workbench().get_plugin_manager().get_configuration("PGZeroMode")
    try:
        get_workbench().get_plugin_manager().set_configuration("PGZeroMode", {})
        load_plugin()
        assert get_workbench().get_option(_OPTION_NAME, False) == False

        toggle_variable()
        assert get_workbench().get_option(_OPTION_NAME, True) == True
    finally:
        get_workbench().get_plugin_manager().set_configuration("PGZeroMode", original_config)

# Generated at 2022-06-22 15:29:15.019078
# Unit test for function toggle_variable
def test_toggle_variable():
    if not get_workbench():
        # the plugin may be loaded very early, before the workbench is ready
        return
    
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == True
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == False

# Generated at 2022-06-22 15:29:21.966094
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.getenv("PGZERO_MODE") == "True"
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.getenv("PGZERO_MODE") == "auto"
    get_workbench().set_simple_mode(False)
    assert os.getenv("PGZERO_MODE") == "auto"

# Generated at 2022-06-22 15:29:29.859548
# Unit test for function update_environment
def test_update_environment():
    # Given:
    get_workbench().set_option(_OPTION_NAME, False)
    # When:
    update_environment()
    # Then:
    assert os.environ["PGZERO_MODE"] == "off"

    # Given:
    get_workbench().set_option(_OPTION_NAME, True)
    # When:
    update_environment()
    # Then:
    assert os.environ["PGZERO_MODE"] == "on"

# Generated at 2022-06-22 15:29:43.818907
# Unit test for function toggle_variable
def test_toggle_variable():
    assert not get_workbench().get_option(_OPTION_NAME)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME)

# Generated at 2022-06-22 15:29:51.802148
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock
    from thonny import get_workbench, get_runner

    from thonny.plugins.pgzero_mode import _OPTION_NAME
    wb = get_workbench()
    wb.clear_all_commands()
    wb.clear_all_variables()
    wb.clear_all_menus()
    wb.clear_all_toolbars()
    wb.clear_all_debugger_views()

    mock_get_runner = Mock()
    mock_get_runner.return_value = "my_runner"
    get_runner.cache_clear()
    get_runner.cache_info()
    get_runner.side_effect = mock_get_runner

    load_plugin()


# Generated at 2022-06-22 15:30:02.713528
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench
    from thonny.workbench import Workbench
    get_workbench().set_default("simple_mode", False)
    old_value = os.environ.get("PGZERO_MODE")
    load_plugin()
    assert get_workbench().get_variable("run.pgzero_mode") == False
    assert os.environ.get("PGZERO_MODE") == "False"
    toggle_variable()
    assert get_workbench().get_variable("run.pgzero_mode") == True
    assert os.environ.get("PGZERO_MODE") == "True"
    get_workbench().set_default("simple_mode", True)
    update_environment()
    assert os.environ.get("PGZERO_MODE") == "auto"

# Generated at 2022-06-22 15:30:08.729375
# Unit test for function update_environment
def test_update_environment():
    if "PGZERO_MODE" in os.environ:
        del os.environ["PGZERO_MODE"]

    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 15:30:09.701537
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()

# Generated at 2022-06-22 15:30:15.680828
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny import ui_utils
    from thonny.plugins.run_pgzero_mode import toggle_variable, _OPTION_NAME

    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)

    from unittest import mock

    ui_utils.show_dialog = mock.Mock(return_value=True)
    toggle_variable()
    assert ui_utils.show_dialog.call_count == 1
    assert wb.get_variable(_OPTION_NAME).get()
    ui_utils.show_dialog.reset_mock()

    toggle_variable()
    assert ui_utils.show_dialog.call_count == 1

# Generated at 2022-06-22 15:30:22.702862
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 15:30:30.474777
# Unit test for function toggle_variable
def test_toggle_variable():
    old_value = os.environ.get("PGZERO_MODE", None)
    try:
        del os.environ["PGZERO_MODE"]
        toggle_variable()
        assert os.environ["PGZERO_MODE"] == "True"
        toggle_variable()
        assert os.environ["PGZERO_MODE"] == "False"
        toggle_variable()
        assert os.environ["PGZERO_MODE"] == "True"
    finally:
        if old_value is None:
            try:
                del os.environ["PGZERO_MODE"]
            except:
                pass
        else:
            os.environ["PGZERO_MODE"] = old_value


# Generated at 2022-06-22 15:30:34.026261
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench

    # default (False)
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    # False
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    # True
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 15:30:46.772700
# Unit test for function update_environment
def test_update_environment():
    import os
    from unittest.mock import patch
    from unittest import mock
    from thonny import get_workbench

    with patch.dict("os.environ", {"PGZERO_MODE": "auto"}):
        assert os.environ["PGZERO_MODE"] == "auto"
        get_workbench().in_simple_mode = mock.MagicMock(return_value=False)
        get_workbench().set_option(_OPTION_NAME, True)
        get_workbench().set_default(_OPTION_NAME, False)
        update_environment()
        assert os.environ["PGZERO_MODE"] == "True"
        get_workbench().in_simple_mode = mock.MagicMock(return_value=True)
        update_environment()

# Generated at 2022-06-22 15:31:12.985075
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().unset_default(_OPTION_NAME)
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert 'auto' in os.environ["PGZERO_MODE"]

# Generated at 2022-06-22 15:31:16.025207
# Unit test for function toggle_variable
def test_toggle_variable():
    test_var = get_workbench().get_variable(_OPTION_NAME)
    test_var.set(True)
    assert test_var.get() == True
    toggle_variable()
    assert test_var.get() == False
    toggle_variable()
    assert test_var.get() == True

# Generated at 2022-06-22 15:31:21.696232
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.misc_utils import running_on_mac_os, running_on_windows
    from thonny import get_workbench
    from thonny.languages import tr
    from thonny.plugins.pgzero_mode import load_plugin
    load_plugin()

    assert "toggle_pgzero_mode" in get_workbench().commands
    assert "run" in get_workbench().commands["toggle_pgzero_mode"]
    assert "Pygame Zero mode" in get_workbench().commands["toggle_pgzero_mode"]["run"]
    assert "PgZeroModeClass" in get_workbench().commands["toggle_pgzero_mode"]["run"]
    assert "show_turtle_doc" in get_workbench().commands["toggle_pgzero_mode"]["run"]


# Generated at 2022-06-22 15:31:33.377474
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import Mock
    import os
    import thonny
    import tkinter as tk
    from thonny.plugins.pgzero_mode import update_environment

    # Simulate thonny as launched from command line
    thonny._in_simple_mode = False
    get_workbench().set_option(_OPTION_NAME, False)

    # Setup
    os.environ.pop("PGZERO_MODE", None)

    # Test case 1: thonny launched from command line
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    # Test case 2: thonny launched as simple mode
    thonny._in_simple_mode = True
    update_environment()

# Generated at 2022-06-22 15:31:40.607025
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()

    # set-up
    wb.set_in_simple_mode(True)
    wb.set_option(_OPTION_NAME, True)
    del os.environ["PGZERO_MODE"]

    # call
    load_plugin()

    # check
    assert not wb.get_option(_OPTION_NAME)
    assert wb.get_option(_OPTION_NAME, False)
    assert os.environ["PGZERO_MODE"] == "auto"



# Generated at 2022-06-22 15:31:48.536807
# Unit test for function toggle_variable
def test_toggle_variable():
    test_case = unittest.TestCase()
    var = get_workbench().get_variable(_OPTION_NAME)
    test_case.assertEqual(var.get(), False)
    toggle_variable()
    test_case.assertEqual(var.get(), True)
    toggle_variable()
    test_case.assertEqual(var.get(), False)

if __name__ == "__main__":
    test_toggle_variable()

# Generated at 2022-06-22 15:31:56.395122
# Unit test for function update_environment
def test_update_environment():
    from thonny.globals import get_workbench
    assert "PGZERO_MODE" not in os.environ
    get_workbench().set_default(_OPTION_NAME, True)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"
    get_workbench().set_default(_OPTION_NAME, True)
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ

# Generated at 2022-06-22 15:32:02.210046
# Unit test for function update_environment
def test_update_environment():
    class WorkbenchMock:
        def __init__(self):
            self.options = {"run.pgzero_mode":True}
            
        def in_simple_mode(self):
            return False
            
        def get_option(self, name):
            return self.options[name]
            
        def set_default(self, name, value):
            self.options[name] = value
            
        def get_variable(self, name):
            return self
            
        def get(self):
            return self.options[name]
            
        def set(self, value):
            self.options[name] = value
                
    workbenchMock = WorkbenchMock()
    global get_workbench
    old_get_workbench = get_workbench
    get_workbench = lambda: workbenchMock

# Generated at 2022-06-22 15:32:11.105506
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import MagicMock
    get_workbench().in_simple_mode = MagicMock(return_value=True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().in_simple_mode = MagicMock(return_value=False)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"

    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"

# Generated at 2022-06-22 15:32:13.240060
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    old_value = wb.get_option(_OPTION_NAME)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) != old_value

# Generated at 2022-06-22 15:33:20.996817
# Unit test for function load_plugin
def test_load_plugin():
    wb = SimpleMock()
    wb.in_simple_mode = lambda: False
    wb.get_option = lambda x: False
    wb.set_default = lambda x, y: None
    wb.get_variable = lambda x: SimpleMock(get=lambda: False, set=lambda x: None)
    wb.add_command = lambda a,b,c,d,e,f: None
    load_plugin()
    assert os.environ["PGZERO_MODE"] == "False"

    wb = SimpleMock()
    wb.in_simple_mode = lambda: True
    wb.get_option = lambda x: False
    wb.set_default = lambda x, y: None

# Generated at 2022-06-22 15:33:27.073239
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from unittest.mock import MagicMock
    import sys
    import os

    # sys.modules is used to mock modules thonny imports
    if "tkinter" in sys.modules:
        del sys.modules["tkinter"]

    # MagicMock class is used to mock objects thonny creates
    wb = MagicMock(Workbench)

    global get_workbench
    global _OPTION_NAME

    def mock_get_workbench():
        global wb
        return wb

    get_workbench = mock_get_workbench

    _OPTION_NAME = "run.pgzero_mode"

    os.environ["PGZERO_MODE"] = "True"


# Generated at 2022-06-22 15:33:33.205852
# Unit test for function toggle_variable
def test_toggle_variable():
    global _OPTION_NAME
    # Save values pre test
    saved_value = get_workbench().get_variable(_OPTION_NAME)
    # test
    toggle_variable()
    # Check test
    assert get_workbench().get_variable(_OPTION_NAME) == True
    # Restore values post test
    get_workbench().set_variable(_OPTION_NAME, saved_value)

# Generated at 2022-06-22 15:33:40.171552
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    toggle_variable()
    assert True==wb.get_option(_OPTION_NAME)
    toggle_variable()
    assert False==wb.get_option(_OPTION_NAME)
    toggle_variable()
    assert True==wb.get_option(_OPTION_NAME)
    wb.set_default(_OPTION_NAME, True)
    toggle_variable()
    assert False==wb.get_option(_OPTION_NAME)
    toggle_variable()
    assert True==wb.get_option(_OPTION_NAME)

# Generated at 2022-06-22 15:33:43.851302
# Unit test for function toggle_variable
def test_toggle_variable():
    assert get_workbench().get_variable(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME) == False

# Generated at 2022-06-22 15:33:49.580933
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import MagicMock
    import sys
    import os

    workbench = MagicMock()
    workbench.in_simple_mode.return_value = False
    workbench.get_option.return_value = True
    global get_workbench
    get_workbench = lambda: workbench

    if "PGZERO_MODE" in os.environ:
        del os.environ["PGZERO_MODE"]
    update_environment()
    assert "PGZERO_MODE" in os.environ
    assert os.environ["PGZERO_MODE"] == "True"

    workbench.in_simple_mode.return_value = True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 15:33:57.770192
# Unit test for function update_environment
def test_update_environment():
    if os.getenv("PGZERO_MODE") is not None:
        os.environ.pop("PGZERO_MODE")
    update_environment()
    assert os.getenv("PGZERO_MODE") == "auto"
    get_workbench().set_option(_OPTION_NAME, True)
    os.environ["PGZERO_MODE"] = "old"
    update_environment()
    assert os.getenv("PGZERO_MODE") == "1"

    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.getenv("PGZERO_MODE") == "0"

# Generated at 2022-06-22 15:34:06.935374
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 15:34:12.085128
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock
    from thonny import get_workbench
    from thonny.workbench import Workbench

    mock_tk = Mock()
    mock_workbench = Mock(spec=Workbench)
    mock_workbench.get_editor_notebook = Mock()
    mock_workbench.get_editor_notebook = Mock()
    mock_workbench.get_editor_notebook = Mock()
    mock_workbench.get_editor_notebook = Mock()
    mock_workbench.get_editor_notebook = Mock()

    get_workbench.return_value = mock_workbench

    load_plugin()

    assert os.environ["PGZERO_MODE"] == "0"

# Generated at 2022-06-22 15:34:21.581425
# Unit test for function update_environment
def test_update_environment():
    import os
    import builtins
    import unittest
    import unittest.mock
    from thonny.globals import get_workbench

    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().in_simple_mode = unittest.mock.Mock(return_value=False)
    get_workbench().get_option = unittest.mock.Mock(return_value=False)
    update_environment()

    assert os.environ["PGZERO_MODE"] == "False"

    # Change to simple mode
    get_workbench().in_simple_mode = unittest.mock.Mock(return_value=True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    #

# Generated at 2022-06-22 15:36:15.923785
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import Mock
    
    workbench = Mock()
    workbench.in_simple_mode.return_value = False
    workbench.get_option.return_value = True
    get_workbench.return_value = workbench
    
    with freeze_current_state():
        update_environment()
        assert os.environ["PGZERO_MODE"] == "True"
        workbench.get_option.return_value = False
        update_environment()
        assert os.environ["PGZERO_MODE"] == "False"
        workbench.in_simple_mode.return_value = True
        update_environment()
        assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 15:36:28.260969
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    class DummyEvent:
        """ Dummy Event class with empty attributes.
        """
        pass

    # for set default option value
    assert not wb.get_option(_OPTION_NAME)

    # for add command
    assert wb.get_command("toggle_pgzero_mode") is not None

    # for call function
    wb.event_generate("<<OpenInterpreter>>", DummyEvent())
    assert os.environ["PGZERO_MODE"] == str(False)

    # for toggle variable
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == str(True)

# Generated at 2022-06-22 15:36:38.994759
# Unit test for function update_environment
def test_update_environment():
    from thonny.misc_utils import running_on_windows
    from unittest import mock
    os.environ.pop("PGZERO_MODE", None)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    if running_on_windows():
        assert os.environ["PGZERO_MODE"] == "1"
    else:
        assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    if running_on_windows():
        assert os.environ["PGZERO_MODE"] == "0"
    else:
        assert os.environ["PGZERO_MODE"] == "False"
    mock_get_workbench = mock.MagicM