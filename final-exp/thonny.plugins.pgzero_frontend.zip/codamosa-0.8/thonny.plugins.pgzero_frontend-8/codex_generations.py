

# Generated at 2022-06-22 15:26:42.834056
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    wb.set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    wb.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 15:26:48.688808
# Unit test for function update_environment
def test_update_environment():
    # Initialize simple mode
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    # Initialize advanced mode
    get_workbench().set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    # Toggle advanced mode to simple mode
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    # Toggle simple mode back to advanced mode
    get_workbench().set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    # Toggle advanced mode to PgZero mode

# Generated at 2022-06-22 15:26:59.424800
# Unit test for function load_plugin
def test_load_plugin():
    wb = MagicMock(name="wb")
    wb.get_variable = MagicMock(side_effect=lambda name: wb)
    wb.set_default = wb.get_variable
    wb.get_option = lambda name: False
    wb.add_command = MagicMock(name="add_command")
    load_plugin()
    wb.add_command.assert_called_once_with("toggle_pgzero_mode", "run",
                                           "Pygame Zero mode",
                                           toggle_variable,
                                           flag_name="run.pgzero_mode",
                                           group=40)



# Generated at 2022-06-22 15:27:09.664839
# Unit test for function toggle_variable
def test_toggle_variable():
    print(get_workbench().get_option(_OPTION_NAME))
    toggle_variable()
    print(get_workbench().get_option(_OPTION_NAME))
    toggle_variable()
    print(get_workbench().get_option(_OPTION_NAME))

# Generated at 2022-06-22 15:27:14.638139
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.set_simple_mode(True)
    load_plugin()
    assert wb.get_option(_OPTION_NAME) == False
    assert "PGZERO_MODE" in os.envir

# Generated at 2022-06-22 15:27:25.115196
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == True
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == False


# Generated at 2022-06-22 15:27:39.569068
# Unit test for function toggle_variable
def test_toggle_variable():
    assert get_workbench().in_simple_mode() == True
    toggle_variable()
    assert get_workbench().in_simple_mode() == False
    toggle_variable()
    assert get_workbench().in_simple_mode() == True
    toggle_variable()
    assert get_workbench().in_simple_mode() == False
    toggle_variable()
    assert get_workbench().in_simple_mode() == True
    toggle_variable()
    assert get_workbench().in_simple_mode() == False
    toggle_variable()
    assert get_workbench().in_simple_mode() == True

# Generated at 2022-06-22 15:27:50.175637
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    # load_plugin calls get_workbench().add_command(), which adds toggling command to IDE
    assert get_workbench().get_command("toggle_pgzero_mode") is not None
    # Unit test for update_environement
    assert os.environ.get("PGZERO_MODE") == "False"
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ.get("PGZERO_MODE") == "True"
    get_workbench().in_simple_mode(True)
    update_environment()
    assert os.environ.get("PGZERO_MODE") == "auto"

# Generated at 2022-06-22 15:28:00.788698
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    load_plugin()
    assert wb.get_option(_OPTION_NAME) is False
    # The option is saved as string since it's a system variable
    assert wb.get_option(_OPTION_NAME, as_type=str) == "False"
    
    # create and update non-existent environment variable PGZERO_MODE
    # because it must be changed when option changes
    os.environ["PGZERO_MODE"] = "orig"
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) is True
    assert wb.get_option(_OPTION_NAME, as_type=str) == "True"

# Generated at 2022-06-22 15:28:11.169194
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench
    workbench = get_workbench()
    # Test with in_simple_mode=False
    workbench.in_simple_mode = False
    workbench.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    workbench.set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    # Test with in_simple_mode=True
    workbench.in_simple_mode = True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 15:28:32.688859
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-22 15:28:42.469610
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().get_option(_OPTION_NAME)
    assert "Pygame Zero mode" in get_workbench().commands["toggle_pgzero_mode"].label
    test_option = get_workbench().get_variable(_OPTION_NAME)
    assert test_option.get() == False

# Generated at 2022-06-22 15:28:52.105394
# Unit test for function update_environment
def test_update_environment():
    from test.config_helper import run_in_fresh_venv
    from thonny import get_workbench

    def check_pgzero_mode(expected_mode):
        assert os.environ["PGZERO_MODE"] == expected_mode
        assert get_workbench().get_option("run.pgzero_mode") == (
            expected_mode == "1"
        )


# Generated at 2022-06-22 15:28:56.628047
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.globals import get_workbench
    plugin = get_workbench().get_plugin("thonny.plugins.run.pgzero")
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-22 15:29:07.954706
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = "auto"
    from thonny import get_workbench


# Generated at 2022-06-22 15:29:13.541409
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default("run.pgzero_mode", False)
    load_plugin()
    assert not os.environ.get("PGZERO_MODE")

# Not needed - load_plugin is called automatically anyway
# def setup():
#     load_plugin()

# Generated at 2022-06-22 15:29:24.994846
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock

    get_workbench = Mock()
    wb = Mock()
    get_workbench.return_value = wb
    wb.get_variable = Mock(return_value="var")
    wb.in_simple_mode = Mock(return_value=False)

    load_plugin()

    wb.set_default.assert_called_once_with(_OPTION_NAME, False)
    assert len(wb.add_command.call_args_list) == 1
    assert wb.add_command.call_args_list[0][1]["command_id"] == "toggle_pgzero_mode"
    assert wb.add_command.call_args_list[0][1]["label"] == "Pygame Zero mode"
    assert wb.add_command.call

# Generated at 2022-06-22 15:29:30.508059
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_simple_mode(False)
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_simple_mode(True)
    assert os.environ["PGZERO_MODE"] == ""

# Generated at 2022-06-22 15:29:35.246336
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    assert wb.get_option(_OPTION_NAME) == False
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == True
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == False

# Generated at 2022-06-22 15:29:43.239010
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.ui_utils import SubprocessDialog
    from thonny.workbench import Workbench

    w = Workbench()

    load_plugin()
    assert w.in_simple_mode() is False
    w.set_default(_OPTION_NAME, False)
    update_environme

# Generated at 2022-06-22 15:29:55.750505
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default("thonny.simple_mode", False)
    load_plugin()
    assert os.environ["PGZERO_MODE"] == "False"

    wb.set_default("thonny.simple_mode", True)
    load_plugin()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 15:30:04.565927
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    wb.set_option("run.pgzero_mode", True)
    assert os.environ["PGZERO_MODE"] == "True"
    wb.set_option("run.pgzero_mode", False)
    assert os.environ["PGZERO_MODE"] == "False"
    wb.set_simple_mode(True)
    assert os.environ["PGZERO_MODE"] == "auto"
    wb.set_simple_mode(False)
    assert os.environ["PGZERO_MODE"] == "auto"
    wb.set_option("run.pgzero_mode", True)
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 15:30:09.654727
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, True)
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 15:30:14.672105
# Unit test for function update_environment
def test_update_environment():
    workbench = get_workbench()
    workbench.set_default(_OPTION_NAME, True)
    os.environ["PGZERO_MODE"] = "True"
    update_environment()
    assert "PGZERO_MODE" in os.environ

    workbench.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    workbench.set_default(_OPTION_NAME, False)
    workbench.set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 15:30:21.845343
# Unit test for function update_environment
def test_update_environment():
    import os
    import thonny
    tb = thonny.get_workbench()
    tb.set_simple_mode(True)
    tb.set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    tb.set_simple_mode(False)
    tb.set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 15:30:27.416813
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    load_plugin()
    assert wb.get_variable(_OPTION_NAME).get() == False

if __name__ == "__main__":
    test_load_plugin()
    print("SUCCESS: " + __file__)

# Generated at 2022-06-22 15:30:32.045806
# Unit test for function toggle_variable
def test_toggle_variable():
    # Set simple mode to False
    get_workbench().set_simple_mode(False)
    # Set option to True
    get_workbench().set_option(_OPTION_NAME, True)
    toggle_variable()
    # Option should now be False
    assert get_workbench().get_option(_OPTION_NAME) is False


# Generated at 2022-06-22 15:30:39.201137
# Unit test for function update_environment
def test_update_environment():
    get_workbench().in_simple_mode()
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 15:30:45.122837
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.workbench import Workbench
    _root = Tk()
    _root.withdraw()
    _workbench = Workbench(_root)
    toggle_variable()
    assert get_workbench().get_option("run.pgzero_mode")
    toggle_variable()
    assert not get_workbench().get_option("run.pgzero_mode")
    _root.destroy()


# Generated at 2022-06-22 15:30:56.759767
# Unit test for function update_environment
def test_update_environment():
    env = dict(os.environ)
    del os.environ["PGZERO_MODE"]
    
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    os.environ = env
    get

# Generated at 2022-06-22 15:31:17.199033
# Unit test for function load_plugin
def test_load_plugin():
    import unittest.mock as mock
    from thonny.ui_utils import CommonDialog
    from thonny.workbench import Workbench
    from thonny.config_ui import ConfigurationPage
    import os

    wb = Workbench()
    wb.cleanup()
    assert "PGZERO_MODE" not in os.environ

    load_plugin()
    assert wb.get_variable(_OPTION_NAME) is not None
    assert wb.get_variable(_OPTION_NAME).get() == False
    assert "PGZERO_MODE" in os.environ
    assert os.environ["PGZERO_MODE"] == "False"
    assert wb.get_default(_OPTION_NAME) == False

    wb.set_option(_OPTION_NAME, True)

# Generated at 2022-06-22 15:31:27.095878
# Unit test for function update_environment
def test_update_environment():
    from thonny.misc_utils import running_on_linux

    get_workbench().set_default(_OPTION_NAME, True)
    get_workbench().run_command("toggle_pgzero_mode")
    update_environment()
    if running_on_linux():
        assert os.environ["PGZERO_MODE"] == "False"
    else:
        assert os.environ["PGZERO_MODE"] == "False"  # True on Linux, False on other platforms?

    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().run_command("toggle_pgzero_mode")
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 15:31:29.776206
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import workbench
    workbench.get_option = lambda x: True
    load_plugin()
    assert workbench.get_command("toggle_pgzero_mode") != None

# Generated at 2022-06-22 15:31:41.079273
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_simple_mode(True)
    load_plugin()
    assert os.environ["PGZERO_MODE"] == "auto"
    assert wb.get_option(_OPTION_NAME)

    wb.set_simple_mode(False)
    load_plugin()
    assert os.environ["PGZERO_MODE"] == "False"
    assert not wb.get_option(_OPTION_NAME)

    load_plugin()
    wb.set_simple_mode(True)
    assert os.environ["PGZERO_MODE"] == "auto"
    assert wb.get_option(_OPTION_NAME)

# Generated at 2022-06-22 15:31:49.471941
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench

    wb = Workbench()
    load_plugin()

    wb.set_simple_mode(True)
    update_environment()

    assert os.environ.get("PGZERO_MODE") == "auto"

    wb.set_simple_mode(False)
    wb.set_option(_OPTION_NAME, True)
    update_environment()

    assert os.environ.get("PGZERO_MODE") == "True"

# Generated at 2022-06-22 15:31:51.615397
# Unit test for function load_plugin
def test_load_plugin():
    wb = SimpleWorkbench()
    wb.load_plugin(load_plugin)
    assert wb.get_variable("run.pgzero_mode") is not None


# Generated at 2022-06-22 15:31:53.632818
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench

    workbench = Workbench()
    load_plugin()
    assert workbench.get_option(_OPTION_NAME) is False

# Generated at 2022-06-22 15:32:00.471300
# Unit test for function load_plugin
def test_load_plugin():
    global load_plugin
    from thonny.workbench import Workbench
    from thonny.common import STDERR
    from thonny import get_workbench, running
    from thonny.languages import tr
    from thonny.misc_utils import running_on_mac_os
    import os
    import sys

    if running_on_mac_os():
        # This test fails on MacOS. Skip it.
        return


# Generated at 2022-06-22 15:32:06.816313
# Unit test for function load_plugin
def test_load_plugin():
    thonny.workbench.unload_plugin("pgzn_mode")
    load_plugin()
    var = get_workbench().get_variable(_OPTION_NAME)
    var.set(True)
    assert os.environ["PGZERO_MODE"] == "True"
    var.set(False)
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 15:32:13.758705
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_option(_OPTION_NAME, False)
    # Initial state
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    assert os.environ.get("PGZERO_MODE") == "False"

    # In simple mode, PGZERO_MODE should be always "auto"
    get_workbench().set_simple_mode(True)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    assert os.environ.get("PGZERO_MODE") == "auto"

# Generated at 2022-06-22 15:32:45.005098
# Unit test for function toggle_variable
def test_toggle_variable():
    # Start in no simplified mode
    os.environ["PGZERO_MODE"] = ""
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 15:32:46.329226
# Unit test for function load_plugin
def test_load_plugin():
    # Just for coverage purposes
    load_plugin()

# Generated at 2022-06-22 15:32:50.061314
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    assert os.environ["PGZERO_MODE"] == "auto"
    try:
        del os.environ["PGZERO_MODE"]
    except KeyError:
        pass
    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"


load_plugin()

# Generated at 2022-06-22 15:32:53.217263
# Unit test for function toggle_variable
def test_toggle_variable():
    values = [0, 0, 1, 1, 0, 0, 0, 1, 1]
    for val in values:
        toggle_variable()
        assert get_workbench().get_variable(_OPTION_NAME).get() == val
        update_environment()

# Generated at 2022-06-22 15:33:02.854612
# Unit test for function update_environment
def test_update_environment():
    workbench = get_workbench()
    workbench.set_simple_mode(True)
    workbench.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    workbench.set_simple_mode(False)
    workbench.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    workbench.set_simple_mode(False)
    workbench.set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 15:33:11.819567
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.in_simple_mode = lambda: False
    wb.get_option = lambda _name: False
    wb._variables = {}
    wb._commands = {}
    load_plugin()

    # Check variable
    assert isinstance(wb._variables[_OPTION_NAME], tkinter.BooleanVar)

    # Check environment variable
    assert os.environ["PGZERO_MODE"] == "False"

    # Check command
    wb._commands["toggle_pgzero_mode"]["func"]()
    assert os.environ["PGZERO_MODE"] == "True"
    assert wb._variables[_OPTION_NAME].get() == True

# Generated at 2022-06-22 15:33:18.392496
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_option("run.pgzero_mode", False)
    assert os.environ["PGZERO_MODE"] == "0"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "1"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "0"
    get_workbench().set_option("run.pgzero_mode", True)
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "0"

# Generated at 2022-06-22 15:33:25.437490
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import create_autospec, patch

    wb = create_autospec(get_workbench())
    wb.in_simple_mode.return_value = False
    wb.get_option.return_value = False

    with patch("thonny.plugins.pgzero.get_workbench", return_value=wb):
        update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    wb.get_option.return_value = True

    with patch("thonny.plugins.pgzero.get_workbench", return_value=wb):
        update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 15:33:36.249799
# Unit test for function load_plugin
def test_load_plugin():
    # Initial state
    wb = get_workbench()
    wb.unload_plugin("thonnycontrib.pgzero")
    wb.set_default(_OPTION_NAME, False)
    assert not wb.get_option(_OPTION_NAME)
    # The plugin is not loaded
    assert not wb.get_menu("run").get_command("toggle_pgzero_mode")

    # Load the plugin
    wb.load_plugin("thonnycontrib.pgzero")

    # The command exists in the menu
    assert wb.get_menu("run").get_command("toggle_pgzero_mode")
    # The plugin does set the default value
    assert wb.get_option(_OPTION_NAME)

    # Unload the plugin

# Generated at 2022-06-22 15:33:46.022463
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    wb.set_simple_mode(False)
    wb.set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    wb.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    wb.set_simple_mode(False)
    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 15:34:53.972549
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == False



# Generated at 2022-06-22 15:35:00.382891
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, True)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()
    assert _OPTION_NAME in get_workbench().get_option(_OPTION_NAME)
    assert "PGZERO_MODE" in os.environ

# Generated at 2022-06-22 15:35:07.263614
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()


if __name__ == "__main__":
    test_load_plugin()
    print(os.environ["PGZERO_MODE"])

# Generated at 2022-06-22 15:35:10.911421
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import Mock

    wb = Mock(in_simple_mode=lambda: False)
    wb.get_option = lambda name: True
    os.environ["PGZERO_MODE"] = "True"
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    wb.get_option = lambda name: False
    update_environment()
    assert os.environ["PGZERO_MODE"] == ""

# Generated at 2022-06-22 15:35:21.484494
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import MagicMock
    wb = MagicMock()
    wb.get_option.return_value = True
    wb.in_simple_mode.return_value = True
    wb.__setattr__("simple_mode", True)
    get_workbench().in_simple_mode = wb.in_simple_mode
    get_workbench().get_option = wb.get_option
    get_workbench().simple_mode = wb.simple_mode
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    wb.get_option.return_value = True
    wb.in_simple_mode.return_value = False
    wb.__setattr__("simple_mode", False)

# Generated at 2022-06-22 15:35:24.854010
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert len(list(get_workbench().get_commands().keys())) > 0

# Generated at 2022-06-22 15:35:31.473786
# Unit test for function update_environment
def test_update_environment():
    from unittest import mock
    from thonny import get_workbench
    
    with mock.patch('os.environ', {'PGZERO_MODE': 'auto'}) as mocked_env:
        get_workbench().set_option(_OPTION_NAME, True)
        update_environment()
        get_workbench().set_option(_OPTION_NAME, False)
        update_environment()
        get_workbench().set_option(_OPTION_NAME, True)
        update_environment()
        
    assert mocked_env['PGZERO_MODE'] == 'True'

# Generated at 2022-06-22 15:35:34.258097
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert "PGZERO_MODE" in os.environ


if __name__ == "__main__":
    load_plugin()

# Generated at 2022-06-22 15:35:35.368836
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) is False


# Generated at 2022-06-22 15:35:35.858666
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()