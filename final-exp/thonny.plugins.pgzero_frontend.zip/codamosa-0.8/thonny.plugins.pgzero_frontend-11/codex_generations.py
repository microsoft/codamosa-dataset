

# Generated at 2022-06-22 15:27:49.501083
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False


load_plugin()

# Generated at 2022-06-22 15:27:55.481940
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    wb = Workbench()
    wb.create()
    load_plugin()
    assert wb.has_view("toggle_pgzero_mode")


if __name__ == "__main__":
    load_plugin()

# Generated at 2022-06-22 15:28:02.989392
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import MagicMock

    get_workbench().set_default(_OPTION_NAME, True)
    get_workbench().in_simple_mode = MagicMock(return_value=True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().set_default(_OPTION_NAME, True)
    get_workbench().in_simple_mode = MagicMock(return_value=False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().in_simple_mode = MagicMock(return_value=True)
    update_environment()

# Generated at 2022-06-22 15:28:05.529902
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True

# Generated at 2022-06-22 15:28:08.537722
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_option(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True

# Generated at 2022-06-22 15:28:10.506285
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()

# Generated at 2022-06-22 15:28:16.291341
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    toggle_variable()
    toggle_variable()
    update_environment()
    assert "PGZERO_MODE" not in os.environ
    wb.in_simple_mode = True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    os.environ.pop("PGZERO_MODE")

# Generated at 2022-06-22 15:28:27.433267
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny._normalized_tk_vars import BooleanVar
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    assert wb.get_variable(_OPTION_NAME) == BooleanVar(False)
    wb.set_default(_OPTION_NAME, True)
    assert wb.get_variable(_OPTION_NAME) == BooleanVar(True)
    toggle_variable()
    assert wb.get_variable(_OPTION_NAME) == BooleanVar(False)
    env = os.environ.get("PGZERO_MODE")
    assert env == "auto"
    toggle_variable()
    assert wb.get_variable(_OPTION_NAME) == BooleanVar(True)
    assert env == "True"



# Generated at 2022-06-22 15:28:36.293989
# Unit test for function update_environment
def test_update_environment():
    workbench = get_workbench()
    workbench.set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"
    workbench.set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"
    workbench.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"


# Generated at 2022-06-22 15:28:45.421218
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny import get_workbench
    from test.test_get_workbench import add_workbench
    add_workbench()
    assert get_workbench().get_option(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False


# Generated at 2022-06-22 15:28:59.648964
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    from thonny.globals import init_workbench

    init_workbench()
    wb = Workbench()
    wb.set_default(_OPTION_NAME, True)
    assert os.environ["PGZERO_MODE"] == "True"
    wb.set_default(_OPTION_NAME, False)
    assert os.environ["PGZERO_MODE"] == "False"
    wb.set_simple_mode(True)
    assert os.environ["PGZERO_MODE"] == "auto"
    wb.set_simple_mode(False)
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 15:29:10.684624
# Unit test for function update_environment
def test_update_environment():
    from unittest import mock

    os.environ["PGZERO_MODE"] = ""
    get_workbench().set_default(_OPTION_NAME, False)
    
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    
    with mock.patch('thonny.plugins.pgzero_mode.get_workbench') as mock_workbench:
        mock_workbench.in_simple_mode.return_value = True
        update_environment()
        assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 15:29:15.864923
# Unit test for function toggle_variable
def test_toggle_variable():
    os.environ["PGZERO_MODE"] = str(True)
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == str(False)
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == str(True)
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == str(False)

# Generated at 2022-06-22 15:29:25.302124
# Unit test for function update_environment
def test_update_environment():
    import os
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 15:29:29.999265
# Unit test for function update_environment
def test_update_environment():
    changed_env = dict(os.environ)
    changed_env["PGZERO_MODE"] = "auto"
    got_env = update_environment()
    assert got_env == changed_env

# Generated at 2022-06-22 15:29:37.847548
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default("run.pgzero_mode", False)
    load_plugin()
    assert get_workbench().get_option("run.pgzero_mode") is False
    assert get_workbench().get_default("run.pgzero_mode") is False
    toggle_variable()
    assert get_workbench().get_option("run.pgzero_mode") is True
    assert get_workbench().get_default("run.pgzero_mode") is False
    toggle_variable()
    assert get_workbench().get_option("run.pgzero_mode") is False
    assert get_workbench().get_default("run.pgzero_mode") is False


# Generated at 2022-06-22 15:29:41.870929
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, True)
    toggle_variable()
    assert not get_workbench().get_variable(_OPTION_NAME).get()


# Generated at 2022-06-22 15:29:48.900698
# Unit test for function update_environment
def test_update_environment():
    from thonny.globals import get_workbench, get_runner
    get_workbench().set_in_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, True)

    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_option(_OPTION_NAME, False)

    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_in_simple_mode(True)
    get_runner().initialize()
    update_environment()

    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 15:30:01.194979
# Unit test for function update_environment
def test_update_environment():
    from thonny.globals import get_running_backend
    from thonny.plugins.backend_pgzero.backend import PygameZeroBackend
    old_backend = get_running_backend()
    old_simple_mode = get_workbench().in_simple_mode()
    old_env = os.environ.copy()

# Generated at 2022-06-22 15:30:03.525618
# Unit test for function toggle_variable
def test_toggle_variable():
    dum = get_workbench()
    dum.set_variable(_OPTION_NAME,True)
    toggle_variable()
    assert dum.get_variable(_OPTION_NAME) == False
    

# Generated at 2022-06-22 15:30:17.130015
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = "True"
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    os.environ["PGZERO_MODE"] = "False"
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    os.environ["PGZERO_MODE"] = "auto"
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 15:30:25.562292
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    get_workbench().event_generate("ThemeChanged")
    get_workbench().event_generate("DebuggerResponse", {
        "command": "debugger-started"})
    
    assert get_workbench().get_variable(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"
    
    get_workbench().set_simple_mode(True)
    update_environment()
   

# Generated at 2022-06-22 15:30:34.646570
# Unit test for function load_plugin
def test_load_plugin():
    def turtle_mode_variable_callback(value):
        print(value)

    get_workbench().set_option("view.show_turtle", True)
    get_workbench().turtle_mode.set(True)
    get_workbench().turtle_mode.trace("w", turtle_mode_variable_callback)
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) is False

    get_workbench().get_variable(_OPTION_NAME).set(True)
    # Variable has been set
    assert get_workbench().get_option(_OPTION_NAME) is True
    # But we're still in turtle mode
    assert get_workbench().in_simple_mode() is True



# Generated at 2022-06-22 15:30:41.434222
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    wb.set_simple_mode(False)

    assert wb.get_option(_OPTION_NAME) == False

    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == True

    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == False

# Generated at 2022-06-22 15:30:45.320659
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny import get_workbench

    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True

    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-22 15:30:53.731096
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().set_simple_mode(False)
    toggle_variable()
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"

    toggle_variable()
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"

# Generated at 2022-06-22 15:30:57.258945
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    wb = Workbench()
    wb.set_default(_OPTION_NAME, True)
    wb.set_simple_mode(True)
    update_environment()
    a

# Generated at 2022-06-22 15:31:03.850655
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import MagicMock
    import sys

    get_workbench().set_default(_OPTION_NAME, False)
    wb = get_workbench()
    wb.in_simple_mode = MagicMock(return_value=False)
    wb.get_option = MagicMock(return_value=False)
    os.environ = {"PGZERO_MODE": "auto"}
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 15:31:12.359603
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    wb.set_simple_mode(True)
    wb.set_default(_OPTION_NAME, False)
    assert wb.get_option(_OPTION_NAME) is False
    assert os.environ["PGZERO_MODE"] == "auto"
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) is True
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) is False
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 15:31:19.078538
# Unit test for function update_environment
def test_update_environment():
    # Skip test if pgzero is not installed
    pygame = sys.modules.get("pygame")
    if not pygame:
        try:
            import pygame
        except ImportError:
            return
    # Skip test if pgzero is not installed
    pgzero = sys.modules.get("pgzero")
    if not pgzero:
        try:
            import pgzero
        except ImportError:
            return
    # Check default mode auto
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    # Check mode False
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"
    # Check mode True

# Generated at 2022-06-22 15:31:40.281669
# Unit test for function update_environment
def test_update_environment():
    # Test simple mode
    wb = get_workbench()
    wb._simple_mode = True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    wb._simple_mode = False

    # Test other mode
    wb._options[_OPTION_NAME] = False
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"
    wb._options[_OPTION_NAME] = True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"

# Generated at 2022-06-22 15:31:51.733721
# Unit test for function update_environment
def test_update_environment():
    from thonny.globals import get_runner
    from test.test_simple_mode import test_simple_mode
    from test.config_helper import set_json_config_content
    from thonny.plugins.micropython_plugin import install_micropython_variables
    from thonny.plugins.micropython_plugin import update_micropython_environment
    from thonny.plugins.pgzero_mode import update_environment
    from thonny.globals import get_workbench

    test_simple_mode()
    install_micropython_variables()

    # We are in simple mode, pgzero mode should be 'auto'
    # Program should be on the board
    update_environment()
    update_micropython_environment()
    get_runner().detect_device()
    assert get

# Generated at 2022-06-22 15:31:58.997130
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench

    old_workbench = get_workbench()

# Generated at 2022-06-22 15:32:03.182637
# Unit test for function toggle_variable
def test_toggle_variable():
    # Test if variable value toggles between True and False
    toggle_variable()
    var = get_workbench().get_variable(_OPTION_NAME)
    assert var.get() == True
    toggle_variable()
    assert var.get() == False

# Generated at 2022-06-22 15:32:06.395449
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME) == False

# Generated at 2022-06-22 15:32:08.005078
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert get_workbench().get_variable(_OPTION_NAME) == False



# Generated at 2022-06-22 15:32:22.117641
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.plugins.run.run_configuration import get_run_backend
    from thonny.languages import english
    from thonny.misc_utils import running_on_windows

    # Mock workbench to avoid SystemExit
    workbench = Workbench()
    workbench.set_default("run.expected_backend", "python")
    workbench.set_default("run.use_subprocess", False)
    workbench.set_default("run.wait_before_exit", False)
    workbench.set_default("run.show_python_environment", False)
    workbench.set_default("run.show_python_warnings", False)
    workbench.set_default("run.use_private_python", False)
    workbench.set_

# Generated at 2022-06-22 15:32:28.255716
# Unit test for function toggle_variable
def test_toggle_variable():
    from unittest.mock import patch
    import thonny

    with patch.object(thonny.get_workbench(), "get_variable") as mocked_get_variable, patch.object(
        thonny.get_workbench(), "set_variable"
    ) as mocked_set_variable:
        mocked_get_variable.return_value = True
        toggle_variable()
        mocked_get_variable.assert_called_with(_OPTION_NAME)
        mocked_set_variable.assert_called_with(_OPTION_NAME, False)

# Generated at 2022-06-22 15:32:35.286730
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench
    from unittest.mock import MagicMock

# Generated at 2022-06-22 15:32:37.198370
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 15:32:59.400009
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench
    from thonny.globals import get_runner
    import builtins
    import tkinter
    import os

    get_runner().clear_sys_path()
    # In general, setting a variable in os.environ is not permitted
    # therefore temporarily replace os.environ by a mutable object
    # to allow unit tests to be performed without side effects
    orig_dict = os.environ
    os.environ = dict()

    get_workbench().set_option(_OPTION_NAME, True)
    get_workbench().set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()

# Generated at 2022-06-22 15:33:06.971846
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_in_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_in_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 15:33:20.995111
# Unit test for function toggle_variable
def test_toggle_variable():
    from unittest.mock import Mock

    mock_workbench = Mock()
    mock_workbench.in_simple_mode.return_value = False
    mock_workbench.get_option.return_value = False
    mock_workbench.get_variable.return_value = True
    mock_workbench.set_variable.return_value = True
    mock_workbench.set_default.return_value = True

    mock_workbench.in_simple_mode.side_effect = lambda: False
    toggle_variable()

    mock_workbench.get_variable.assert_called_once_with(_OPTION_NAME)
    mock_workbench.set_variable.assert_called_once_with(_OPTION_NAME, True)

# Generated at 2022-06-22 15:33:26.678408
# Unit test for function update_environment
def test_update_environment():
    from collections import ChainMap
    from unittest.mock import Mock

    from thonny import get_workbench
    from thonny.config import Configuration

    class MockConfig(Configuration):
        def __init__(self):
            super().__init__()
            self._data = {}
            self._data[_OPTION_NAME] = True

        def get(self, key, default=None):
            try:
                return self._data[key]
            except KeyError:
                return default

    get_workbench().get_user_configuration = Mock(
        return_value=MockConfig()
    )

    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"



# Generated at 2022-06-22 15:33:33.507561
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench

    os.environ["PGZERO_MODE"] = "auto"
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "false"

    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "true"

# Generated at 2022-06-22 15:33:42.580348
# Unit test for function load_plugin
def test_load_plugin():
    from test.test_utils import run_in_captured_editor, assert_editor_contains
    from thonny import get_workbench

    def test_function():
        from thonny import get_workbench
        get_workbench().set_default(_OPTION_NAME, False)
        get_workbench().add_command(
            "toggle_pgzero_mode",
            "run",
            tr("Pygame Zero mode"),
            toggle_variable,
            flag_name=_OPTION_NAME,
            group=40,
        )
        update_environment()

    run_in_captured_editor("", test_function)
    command_names = tuple(get_workbench().commands.keys())

    assert "toggle_pgzero_mode" in command_names
    assert not get_workbench().get_option

# Generated at 2022-06-22 15:33:54.308502
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().set_default("run.rectangle_mode", False)
    get_workbench().set_default("run.orange_mode", False)
    get_workbench().set_default("run.pygamezero_mode", False)
    get_workbench().set_default("run.repl_mixin", "thonny.plugins.micropython.MicroPythonReplMixin")
    get_workbench().set_default("run.interactive_shell_mixin", "thonny.plugins.standard_shell.StandardShellMixin")
    get_workbench().set_default("run.interactive_shell_class", "thonny.shell.ShellTextWidget")

# Generated at 2022-06-22 15:34:00.736501
# Unit test for function load_plugin
def test_load_plugin():
    import math
    from thonny import get_workbench
    from thonny.languages import tr
    from thonny.plugins.pgzeromode import load_plugin
    from thonny.plugins.pgzeromode import toggle_variable
    from thonny.plugins.pgzeromode import update_environment
    from thonny.plugins.pgzeromode import _OPTION_NAME
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == str(get_workbench().get_option(_OPTION_NAME))
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True

# Generated at 2022-06-22 15:34:06.287488
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock

    get_workbench = Mock()
    get_workbench().set_default = Mock()
    get_workbench().add_command = Mock()
    setattr(sys.modules["__main__"], "get_workbench", get_workbench)
    load_plugin()
    assert get_workbench.call_count == 1
    assert get_workbench().set_default.call_count == 1
    assert get_workbench().add_command.call_count == 1

# Generated at 2022-06-22 15:34:09.462950
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, True)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )

# Generated at 2022-06-22 15:34:50.158179
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench, ui_utils, misc_utils, plugin_manager
    from test.config_helper import get_script_path
    from test.mock_tk import Text
    
    temporary_cwd = get_script_path()
    original_cwd = os.getcwd()
    os.chdir(temporary_cwd)

# Generated at 2022-06-22 15:34:57.672003
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = "auto"
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    os.environ["PGZERO_MODE"] = "True"
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 15:35:06.804461
# Unit test for function toggle_variable
def test_toggle_variable():
    from unittest.mock import Mock, patch
    from thonny import get_workbench

    options = Mock()
    get_workbench().get_default_config_dir = Mock(return_value=None)
    get_workbench().set_variable = Mock()

    with patch.object(get_workbench(), 'get_variable', Mock(return_value=options)):
        # First execution should set the variable to True
        toggle_variable()
        assert get_workbench().set_variable.call_args[0][0] == _OPTION_NAME
        assert get_workbench().set_variable.call_args[0][1] == True
        assert get_workbench().set_variable.call_args[1] == {}

        # Second execution should set the variable to False
        toggle_variable()
        assert get_work

# Generated at 2022-06-22 15:35:11.993743
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert get_workbench().get_default(_OPTION_NAME) is False
    assert get_workbench().find_command("toggle_pgzero_mode")
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert get_workbench().get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"
    
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_simple_mode(False)



# Generated at 2022-06-22 15:35:15.633113
# Unit test for function load_plugin
def test_load_plugin():
    wb = Workbench()
    wb.create()
    load_plugin()
    assert wb.get_variable(_OPTION_NAME).get() == False

# Generated at 2022-06-22 15:35:16.174813
# Unit test for function toggle_variable
def test_toggle_variable():
    pass

# Generated at 2022-06-22 15:35:17.029997
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()


load_plugin()

# Generated at 2022-06-22 15:35:23.999481
# Unit test for function update_environment
def test_update_environment():
    import os
    import unittest
    import test.test_runner

    class TestSimpleMode(unittest.TestCase):
        def setUp(self):
            # Save value of "PGZERO_MODE"
            self.old_pgzero_mode = os.environ["PGZERO_MODE"]

            # Simulate Thonny's SimpleMode
            get_workbench().in_simple_mode = lambda: True

        def tearDown(self):
            # Restore value of the environment variable
            os.environ["PGZERO_MODE"] = self.old_pgzero_mode

        def test_pgzero_mode_is_auto_in_simple_mode(self):
            self.assertEqual(os.environ["PGZERO_MODE"], "auto")


# Generated at 2022-06-22 15:35:30.575085
# Unit test for function update_environment
def test_update_environment():
    tk_root = Tk()
    wb = Workbench(tk_root)
    wb.set_default(_OPTION_NAME, False)
    wb.set_simple_mode(False)
    assert os.environ["PGZERO_MODE"] == "False"
    wb.set_default(_OPTION_NAME, True)
    assert os.environ["PGZERO_MODE"] == "True"
    wb.set_simple_mode(True)
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 15:35:33.213906
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_simple_mode(True)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"


if __name__ == "__main__":
    test_update_environment()

# Generated at 2022-06-22 15:36:18.531465
# Unit test for function update_environment
def test_update_environment():
    from os import environ
    from unittest.mock import patch
    from thonny.workbench import Workbench

    reset_thonny_env = environ.copy()
    wb = Workbench(in_simple_mode=False)

    # pgzero mode set to False when in advanced mode
    patch.object(wb, "in_simple_mode", return_value=False).start()
    with patch.dict(environ, {"PGZERO_MODE": "1"}, clear=True):
        update_environment()
    assert environ["PGZERO_MODE"] == "0"

    # pgzero mode set to 'auto' when in simple mode
    patch.object(wb, "in_simple_mode", return_value=True).start()

# Generated at 2022-06-22 15:36:19.699699
# Unit test for function toggle_variable
def test_toggle_variable():
    for i in range(2):
        toggle_variable()

# Generated at 2022-06-22 15:36:27.546859
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()
    assert _OPTION_NAME in wb.get_default_options()
    wb.reset_to_defaults()

# Generated at 2022-06-22 15:36:38.379512
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import Mock
    from thonny.globals import get_workbench

    wb = Mock()
    env = {}
    os.environ = env
    wb.in_simple_mode = Mock(return_value = True)
    get_workbench = Mock(return_value = wb)
    update_environment()
    assert env['PGZERO_MODE'] == 'auto'
    wb.in_simple_mode = Mock(return_value = False)
    wb.get_option = Mock(return_value = False)
    update_environment()
    assert env['PGZERO_MODE'] == 'False'
    wb.get_option = Mock(return_value = True)
    update_environment()
    assert env['PGZERO_MODE'] == 'True'

# Generated at 2022-06-22 15:36:42.945733
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()


if __name__ == "__main__":
    test_load_plugin()

# Generated at 2022-06-22 15:36:46.974243
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert get_workbench().get_variable("run.pgzero_mode").get() == False
    toggle_variable()
    assert get_workbench().get_variable("run.pgzero_mode").get() == True

# Generated at 2022-06-22 15:36:52.442476
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().in_simple_mode = lambda: False
    load_plugin()
    assert "PGZERO_MODE" not in os.environ

    get_workbench().in_simple_mode = lambda: True
    load_plugin()
    assert os.environ["PGZERO_MODE"] == "auto"


if __name__ == "__main__":
    load_plugin()

# Generated at 2022-06-22 15:37:01.706977
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock
    from thonny import get_workbench
    from thonny.languages import english
    get_workbench().set_default("run.pgzero_mode", True)
    get_workbench().get_variable = Mock(return_value=True)
    get_workbench()._registered_commands = {}
    get_workbench()._registered_flags = {}
    get_workbench()._registered_menus = {}
    get_workbench()._registered_tools = {}
    get_workbench()._registered_shortcuts = {}
    get_workbench()._registered_views = {}
    get_workbench()._registered_variables = {}
    get_workbench()._registered_editor_extensions = {}
    load_plugin()

# Generated at 2022-06-22 15:37:06.216235
# Unit test for function load_plugin
def test_load_plugin():
    global get_workbench
    from thonny.workbench import Workbench
    from unittest.mock import Mock

    get_workbench = Mock()
    get_workbench.return_value = Workbench()
    load_plugin()

    assert get_workbench.call_count == 1
    assert get_workbench.call_args[0] == ()
    assert get_workbench.return_value.get_variable.call_count == 1
    assert get_workbench.return_value.get_variable.call_args[0] == (_OPTION_NAME,)
    assert get_workbench.return_value.get_variable.return_value.set.call_count == 1
    assert get_workbench.return_value.get_variable.return_value.set.call_args[0] == (False,)

# Generated at 2022-06-22 15:37:16.806987
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.workbench import Workbench
    from thonny.config_ui import ConfigurationPage, Checkbox
    from thonny.misc_utils import running_on_mac_os
    import os
    import tkinter as tk
    import tkinter.ttk as ttk

    def on_pgzero_mode(event):
        if event.widget.instate(("selected",)):
            get_workbench().set_option(_OPTION_NAME, True)
        else:
            get_workbench().set_option(_OPTION_NAME, False)
