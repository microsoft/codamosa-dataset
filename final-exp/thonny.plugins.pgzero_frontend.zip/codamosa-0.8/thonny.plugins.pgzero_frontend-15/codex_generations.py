

# Generated at 2022-06-22 15:28:00.717925
# Unit test for function update_environment
def test_update_environment():
    import thonny
    import sys
    import os

    get_workbench = thonny.get_workbench
    thonny.set_simple_mode = lambda : True
    thonny.get_workbench = lambda : thonny.misc_utils.FakeConfig()
    sys.modules['pgzero'] = __import__('pgzero')
    old_simple_mode = thonny.simple_mode
    thonny.in_simple_mode = lambda : True
    old_pgzero_mode = os.environ["PGZERO_MODE"]
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    thonny.get_workbench = lambda : thonny.misc_utils.FakeConfig(run={"pgzero_mode": 1})

# Generated at 2022-06-22 15:28:07.718279
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default(_OPTION_NAME, True)
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 15:28:15.476659
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.testing import create_workbench
    from pygame import display
    from thonny.globals import get_runner
    from thonny.runners import SubprocessBackend

    wb = create_workbench()

    # Test with no Pygame Zero mode
    load_plugin()
    get_workbench().set_option("run.pgzero_mode", False)
    assert os.environ["PGZERO_MODE"] == "0"

    # Test with Pygame mode
    load_plugin()
    get_workbench().set_option("run.pgzero_mode", True)
    assert os.environ["PGZERO_MODE"] == "1"

    # Test in simple mode
    get_workbench().set_simple_mode(True)
    load

# Generated at 2022-06-22 15:28:23.712976
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"

    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"


# Generated at 2022-06-22 15:28:24.245596
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()

# Generated at 2022-06-22 15:28:28.903569
# Unit test for function update_environment
def test_update_environment():
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 15:28:39.239819
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import patch
    from thonny.globals import get_workbench
    from thonny import THONNY_USER_DIR

    with patch("os.environ", new=dict()):
        # Test simple mode
        get_workbench().set_simple_mode()
        update_environment()
        assert os.environ["PGZERO_MODE"] == "auto"

        # Test advanced mode
        get_workbench().set_advanced_mode()
        update_environment()
        assert os.environ["PGZERO_MODE"] == str(False)

        get_workbench().set_option(_OPTION_NAME, True)
        update_environment()
        assert os.environ["PGZERO_MODE"] == str(True)


# Generated at 2022-06-22 15:28:45.606260
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert os.getenv("PGZERO_MODE") == "True"
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert os.getenv("PGZERO_MODE") == "False"

# Generated at 2022-06-22 15:28:51.660867
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    assert not get_workbench().get_option(_OPTION_NAME)
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME)

# Generated at 2022-06-22 15:29:00.158503
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    toggle_variable()
    assert wb.get_option(_OPTION_NAME)
    toggle_variable()
    assert not wb.get_option(_OPTION_NAME)
    
    
if __name__ == "__main__":
    wb = get_workbench()
    wb.add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()
    print("PGZERO_MODE:", os.environ["PGZERO_MODE"])

# Generated at 2022-06-22 15:29:15.129049
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_option("run.pgzero_mode", True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_option("run.pgzero_mode", False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_simple_mode()
    update_environment()
    assert "PGZERO_MODE" not in os.environ

# Generated at 2022-06-22 15:29:21.091873
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, True) 
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    wb.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 15:29:27.755101
# Unit test for function load_plugin
def test_load_plugin():
    global get_workbench
    get_workbench = lambda: TestWorkbench(
        {_OPTION_NAME: True, "run.backend": "cpython"}
    )
    load_plugin()
    assert os.environ["PGZERO_MODE"] == "True"



# Generated at 2022-06-22 15:29:36.091753
# Unit test for function load_plugin
def test_load_plugin():
    from unittest import mock

    with mock.patch.object(get_workbench(), "set_default") as mock_set_default:
        with mock.patch.object(get_workbench(), "add_command") as mock_add_command:
            with mock.patch.object(os, "environ") as mock_environ:
                load_plugin()

    mock_set_default.assert_called_once_with(_OPTION_NAME, False)
    mock_add_command.assert_called_once()
    assert mock_environ.__setitem__.call_count == 1


# Generated at 2022-06-22 15:29:41.987877
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    get_workbench().get_variable(_OPTION_NAME).set(True)

# Generated at 2022-06-22 15:29:47.816119
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    load_plugin()
    wb.event_generate("Application.startup", when="tail")
    assert wb.get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"
    wb.set_option(_OPTION_NAME, True)
    assert wb.get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 15:29:53.752752
# Unit test for function toggle_variable
def test_toggle_variable():
    class FakeVariable:
        def __init__(self):
            self.value = False

        def set(self, value):
            self.value = value

        def get(self):
            return self.value

    class FakeWorkbench:
        def __init__(self):
            self.pgzero_mode = FakeVariable()

        def in_simple_mode(self):
            return False

        def get_variable(self, name):
            return self.pgzero_mode

    wb = FakeWorkbench()
    assert wb.get_variable(_OPTION_NAME).get()==False

    toggle_variable()
    assert wb.get_variable(_OPTION_NAME).get()==True

    wb.in_simple_mode = lambda: True
    toggle_variable()

# Generated at 2022-06-22 15:30:01.993496
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    wb.set_simple_mode(False)
    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    wb.set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    wb.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 15:30:09.727141
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_simple_mode()
    get_workbench().set_option(_OPTION_NAME, True)

    toggle_variable()
    assert not get_workbench().get_option(_OPTION_NAME)
    assert get_workbench().get_variable(_OPTION_NAME).get()
    assert os.environ["PGZERO_MODE"] == str(False)

    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME)
    assert not get_workbench().get_variable(_OPTION_NAME).get()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 15:30:15.703573
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    old_get_variable = wb.get_variable
    old_set_default = wb.set_default
    old_add_command = wb.add_command
    old_in_simple_mode = wb.in_simple_mode
    old_get_option = wb.get_option


# Generated at 2022-06-22 15:30:27.173149
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.workbench import Workbench

    wb = Workbench()
    var = wb.get_variable(_OPTION_NAME)

    toggle_variable()
    assert var.get()

    toggle_variable()
    assert not var.get()

# Generated at 2022-06-22 15:30:36.509634
# Unit test for function update_environment
def test_update_environment():
    old_env = os.environ.copy()
    old_workbench = get_workbench()
    os.environ["PGZERO_MODE"] = "non_default"
    
    class TestWorkbench:
        def get_option(self, name):
            return True
        
        def in_simple_mode(self):
            return False
    
    get_workbench = lambda: TestWorkbench()
    update_environment()
    os.environ["PGZERO_MODE"] = "auto"
    
    get_workbench = lambda: TestWorkbench()
    get_workbench().in_simple_mode = lambda: True
    update_environment()
    os.environ["PGZERO_MODE"] = "True"
    
    get_workbench = lambda: TestWorkbench()

# Generated at 2022-06-22 15:30:40.737489
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench
    from thonny.languages import tr
    from thonny.globals import get_workbench
    from thonny.config import get_workbench

    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    assert wb.in_simple_mode() == False
    assert wb.get_option(_OPTION_NAME) == False
    # How to test update_environment()

# Generated at 2022-06-22 15:30:49.206215
# Unit test for function update_environment
def test_update_environment():
    from thonny.globals import get_runner, get_workbench, get_shell
    from thonny.common import ToplevelCommand
    from thonny.ui_utils import find_dialog
    import unittest
    import os

    class RunPgZeroModeTests(unittest.TestCase):
        def setUp(self):
            get_workbench().flush_command_history()

        def tearDown(self):
            get_workbench().event_generate("Quit")

        def test_update_environment(self):
            get_workbench().set_default(_OPTION_NAME, True)
            get_workbench().event_generate("New")
            get_shell().run_command("%run pgzero_hello.py")
            get_runner().wait_until_idle()
            pg

# Generated at 2022-06-22 15:30:51.908862
# Unit test for function toggle_variable
def test_toggle_variable():
    
    # If a program fails it returns a value of 1 and if it passes it returns 0
    assert toggle_variable() == 0

# Generated at 2022-06-22 15:30:58.262174
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.config_ui import ConfigurationPage

    get_workbench().set_default(
        _OPTION_NAME, False
    )  #Just to make sure that it is not set to true
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == True
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    assert get_workbench().get_variable(_OPTION_NAME).get() != True

# Generated at 2022-06-22 15:31:07.521887
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny import THONNY_USER_DIR
    from thonny import get_runner

    wb = Workbench()
    wb._testing = True
    wb.load_plugin(thonny.plugins.pgzero_plugin)

    # Check that toggle_variable function has been registered
    # and that it is accessible from the workbench.
    # Also checks that the variable has been set.
    assert len(wb._commands) == len(wb._commands_dict) > 0
    assert wb._commands_dict["toggle_pgzero_mode"]
    assert wb.get_option(_OPTION_NAME)

    # Check that the environment has been updated to auto mode.
    assert get_runner().get_pgzero_mode() == "auto"

    wb

# Generated at 2022-06-22 15:31:16.584928
# Unit test for function update_environment
def test_update_environment():
    import os
    import unittest.mock as mock
    from thonny import get_workbench
    from thonny.languages import tr
    
    _OPTION_NAME = "run.pgzero_mode"

    def _load_config():
        """Load basic configuration"""
        import configparser
        # Create empty config
        config = configparser.ConfigParser()
        # Create default config
        default_config = configparser.ConfigParser()
        default_config.read_dict({"thonny": {"simple_mode": "False"}})
        # Merge configs into one
        config.read_dict(default_config)
        config.read("config.ini")
        return config

    def _get_workbench(config):
        """Return a workbench"""
        from thonny.workbench import Workbench


# Generated at 2022-06-22 15:31:27.128045
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock
    from unittest import mock
    from thonny import get_workbench

    wb = Mock()
    wb.set_default = mock.Mock()
    wb.add_command = mock.Mock()
    wb.get_variable = mock.Mock(return_value=Mock(get=mock.Mock(return_value=True)))
    wb.in_simple_mode = mock.Mock(return_value=True)
    get_workbench = mock.Mock(return_value=wb)
    mock.patch("thonny.plugins.pgzero_mode.get_workbench", get_workbench)
    load_plugin()

    wb.set_default.assert_called_with("run.pgzero_mode", False)
    w

# Generated at 2022-06-22 15:31:30.430103
# Unit test for function update_environment
def test_update_environment():
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"


load_plugin()

# Generated at 2022-06-22 15:31:43.506042
# Unit test for function update_environment
def test_update_environment():
    from thonny.globals import get_workbench, InlineCommand

    get_workbench().set_default(_OPTION_NAME, True)
    get_workbench().execute_command("run_module")
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    def f():
        get_workbench().set_simple_mode(True)
        update_environment()
        assert os.environ["PGZERO_MODE"] == "auto"

   

# Generated at 2022-06-22 15:31:50.430235
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    load_plugin()
    assert wb.get_option(_OPTION_NAME) is False
    assert "PGZERO_MODE" not in os.environ
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) is True
    assert os.environ["PGZERO_MODE"] == "1"
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) is False
    assert os.environ["PGZERO_MODE"] == "0"

# Generated at 2022-06-22 15:31:53.162870
# Unit test for function toggle_variable
def test_toggle_variable():
    # Arrange
    # Act
    toggle_variable()
    # Assert
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 15:31:54.532070
# Unit test for function update_environment
def test_update_environment():
    get_workbench().add_option('option_name', False)
    update_environme

# Generated at 2022-06-22 15:32:01.109499
# Unit test for function update_environment
def test_update_environment():
    workbench = get_workbench()
    workbench.set_option(_OPTION_NAME, True)
    assert os.environ.get("PGZERO_MODE", None) == "True"

    workbench.set_option(_OPTION_NAME, False)
    assert os.environ.get("PGZERO_MODE", None) == "False"

    workbench.set_in_simple_mode(True)
    update_environment()
    assert os.environ.get("PGZERO_MODE", None) == "auto"

    workbench.set_in_simple_mode(False)
    update_environment()
    assert os.environ.get("PGZERO_MODE", None) == "False"

    workbench.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.en

# Generated at 2022-06-22 15:32:08.139227
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = "auto"
    assert os.environ["PGZERO_MODE"] == "auto"

    os.environ["PGZERO_MODE"] = "True"
    assert os.environ["PGZERO_MODE"] == "True"

    os.environ["PGZERO_MODE"] = "False"
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 15:32:16.906856
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    os.environ["PGZERO_MODE"] = "auto"
    get_workbench().set_default(_OPTION_NAME, True)    
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 15:32:25.423204
# Unit test for function load_plugin
def test_load_plugin():
    import unittest.mock
    from thonny import get_runner
    from thonny.globals import get_workbench, get_runner
    from thonny.languages import tr
    from thonny.plugins.pgzero_mode import load_plugin

    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    load_plugin()
    runner = get_runner()
    assert runner.get_option(_OPTION_NAME) == False
    assert runner.get_option(_OPTION_NAME) == True
    assert runner.get_option(_OPTION_NAME) == False

# Generated at 2022-06-22 15:32:33.372048
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = "whatever"
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    del os.environ["PGZERO_MODE"]

# Generated at 2022-06-22 15:32:42.688995
# Unit test for function update_environment
def test_update_environment():
    from thonny import ui_utils
    from thonny.plugins.background_system_shells import (
        update_environment as update_environment_orig,
    )
    from thonny.workbench import get_workbench
    from unittest.mock import Mock

    ui_utils._root = Mock()
    wb = get_workbench()
    get_workbench().in_simple_mode = Mock(return_value=False)
    get_workbench().get_option = Mock(return_value=True)
    update_environment()
    get_workbench().get_option.assert_called_once_with(_OPTION_NAME)
    update_environment_orig.assert_called_once_with()
    get_workbench().in_simple_mode = Mock(return_value=True)
    update_

# Generated at 2022-06-22 15:33:07.331013
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default(_OPTION_NAME, True)
    get_workbench().set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_default(_OPTION_NAME, True)
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().set_simple_

# Generated at 2022-06-22 15:33:16.221080
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    # Tests for in_simple_mode()
    test_in_simple = True
    wb.set_simple_mode(test_in_simple)
    assert "PGZERO_MODE" in os.environ
    assert os.environ["PGZERO_MODE"] == "auto"
    test_in_simple = False
    wb.set_simple_mode(test_in_simple)
    assert "PGZERO_MODE" in os.environ
    assert os.environ["PGZERO_MODE"] == "False"
    # Tests for PGZERO_MODE - in non simple mode it is set as a bit more complicated
    test_pgzero_mode = True
    wb.set_option(_OPTION_NAME, test_pgzero_mode)

# Generated at 2022-06-22 15:33:21.948863
# Unit test for function update_environment
def test_update_environment():
    # Load plugin into workbench
    load_plugin()

    # environment variable PGZERO_MODE should be set to false
    assert os.environ["PGZERO_MODE"] == "False"

    # set in_simple_mode to true
    get_workbench().in_simple_mode_ = True

    # update the environment variable PGZERO_MODE
    update_environment()

    # since in_simple_mode is true, PGZERO_MODE should be set to auto
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 15:33:25.844821
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    wb.set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    wb.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 15:33:36.249358
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench

    from thonny.config import load_special_configurations

    load_special_configurations(get_workbench())

    from thonny.plugins.python_mode import PythonModePlugin

    plugin = PythonModePlugin()
    plugin.activate()

    # Check if is in Pygame Zero mode
    plugin.load_plugin()
    assert get_workbench().get_variable(_OPTION_NAME).get() is False
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() is True

    # Check if plugin is loaded
    assert get_workbench().in_simple_mode() is False

    # Check if the environment is loaded
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 15:33:44.759242
# Unit test for function update_environment
def test_update_environment():
    assert os.environ.get("PGZERO_MODE", "") == ""
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ.get("PGZERO_MODE", "") == "False"
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ.get("PGZERO_MODE", "") == "True"

# Generated at 2022-06-22 15:33:49.744317
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert "pgzero_mode" in get_workbench().get_defaults()
    assert "toggle_pgzero_mode" in get_workbench().get_commands()
    assert "PGZERO_MODE" not in os.environ
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert "PGZERO_MODE" in os.environ
    assert "true" in os.environ["PGZERO_MODE"]
    toggle_variable()
    assert "false" in os.environ["PGZERO_MODE"]
    get_workbench().set_simple_mode(True)
    update_environment()
    assert "auto" in os.environ["PGZERO_MODE"]
    get_workbench().set_simple_mode(False)

# Generated at 2022-06-22 15:33:59.241413
# Unit test for function update_environment
def test_update_environment():
    orig_workbench = get_workbench()
    class TestWorkbench:
        def __init__(self):
            TestWorkbench.called = 0
            TestWorkbench.in_simple_mode_result = False
            TestWorkbench.get_option_result = False
        
        def in_simple_mode(self):
            TestWorkbench.called += 1
            return TestWorkbench.in_simple_mode_result
        
        def get_option(self, name):
            TestWorkbench.called += 1
            assert name == _OPTION_NAME
            return TestWorkbench.get_option_result
    
    workbench = TestWorkbench()
    get_workbench._set_workbench(workbench)
    
    update_environment()
    assert workbench.called == 2

# Generated at 2022-06-22 15:34:07.993167
# Unit test for function update_environment
def test_update_environment():
    initial_value = dict(os.environ)["PGZERO_MODE"]
    get_workbench().set_simple_mode()
    os.environ["PGZERO_MODE"] = "bla"
    update_environment()
    assert dict(os.environ)["PGZERO_MODE"] == "auto"
    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert dict(os.environ)["PGZERO_MODE"] == "1"
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert dict(os.environ)["PGZERO_MODE"] == "0"
    os.environ["PGZERO_MODE"] = initial_value

# Generated at 2022-06-22 15:34:18.160930
# Unit test for function load_plugin
def test_load_plugin():
    wb = TestWorkbench()
    wb.set_simple_mode(False)

    assert "PGZERO_MODE" not in os.environ
    load_plugin()
    assert os.environ["PGZERO_MODE"] == "False"

    wb.set_simple_mode(True)
    load_plugin()
    assert os.environ["PGZERO_MODE"] == "auto"
    wb.set_simple_mode(False)
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 15:34:59.808731
# Unit test for function update_environment
def test_update_environment():
    import os
    from thonny import get_workbench
    from thonny.languages import tr
    from PGZeroMode import load_plugin
    load_plugin()
    get_workbench().set_simple_mode(0)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_simple_mode(1)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 15:35:05.093905
# Unit test for function load_plugin
def test_load_plugin():
    my_workbench = get_workbench()
    my_workbench.set_default(_OPTION_NAME, False)
    my_workbench.add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()



# Generated at 2022-06-22 15:35:10.160312
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 15:35:21.450287
# Unit test for function update_environment
def test_update_environment():
    old_value = os.environ.get('PGZERO_MODE', '')

    os.environ['PGZERO_MODE'] = 'auto'
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ['PGZERO_MODE'] == 'auto'

    os.environ['PGZERO_MODE'] = 'auto'
    get_workbench().set_simple_mode(False)
    update_environment()
    assert os.environ['PGZERO_MODE'] == 'False'

    os.environ['PGZERO_MODE'] = 'auto'
    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()

# Generated at 2022-06-22 15:35:26.826409
# Unit test for function load_plugin
def test_load_plugin():
    try:
        from test.test_simple_plugin import load_plugin as load_plugin
        from test.test_simple_plugin import unload_plugin as unload_plugin
        load_plugin()
        test_load_plugin_helper()
    finally:
        unload_plugin()



# Generated at 2022-06-22 15:35:33.890775
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    wb.set_variable("run.pgzero_mode", True)
    wb.set_variable("view.simple_mode", False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    wb.set_variable("run.pgzero_mode", False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    wb.set_variable("view.simple_mode", True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    del os.environ["PGZERO_MODE"]

# Generated at 2022-06-22 15:35:40.364267
# Unit test for function toggle_variable
def test_toggle_variable():
    import thonny.plugins.pgzero_mode as pgzero_mode
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert pgzero_mode.get_workbench().get_option(_OPTION_NAME)
    toggle_variable()
    assert not pgzero_mode.get_workbench().get_option(_OPTION_NAME)
    pgzero_mode.get_workbench().set_simple_mode(True)
    toggle_variable()
    assert not pgzero_mode.get_workbench().get_option(_OPTION_NAME)

# Generated at 2022-06-22 15:35:45.582698
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert get_workbench().get_default(_OPTION_NAME)==False
    assert get_workbench().get_option(_OPTION_NAME)==False
    assert os.environ["PGZERO_MODE"]==str(get_workbench().get_option(_OPTION_NAME))

# Generated at 2022-06-22 15:35:49.163773
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    var = wb.get_variable(_OPTION_NAME)
    var.set(False)

    toggle_variable()
    assert var.get() == True

    toggle_variable()
    assert var.get() == False

# Generated at 2022-06-22 15:35:58.712993
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import patch

    import thonny.plugin_manager

    namespace = dict(get_workbench=lambda: thonny.plugin_manager._manager)
    with patch.dict(thonny.plugin_manager.__dict__, namespace):
        get_workbench().set_default(_OPTION_NAME, True)
        update_environment()
        assert os.environ["PGZERO_MODE"] == "True"

        get_workbench().set_simple_mode()
        update_environment()
        assert os.environ["PGZERO_MODE"] == "auto"

        get_workbench().set_simple_mode(False)
        get_workbench().set_option(_OPTION_NAME, False)
        update_environment()

# Generated at 2022-06-22 15:36:47.589885
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock

    wb = Mock()
    wb.get_option.return_value = False
    wb.in_simple_mode.return_value = True
    wb.get_variable.return_value = Mock(get=Mock(return_value=False), set=Mock())

    load_plugin()
    wb.add_command.assert_called()



# Generated at 2022-06-22 15:36:48.215138
# Unit test for function update_environment

# Generated at 2022-06-22 15:36:55.366059
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_simple_mode(True)
    get_workbench().set_default(_OPTION_NAME, False)
    env = os.environ
    env["PGZERO_MODE"] = "False"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 15:37:00.683024
# Unit test for function toggle_variable
def test_toggle_variable():
    assert os.environ.get("PGZERO_MODE") == "False"
    toggle_variable()
    assert os.environ.get("PGZERO_MODE") == "True"

# Generated at 2022-06-22 15:37:07.465529
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench
    get_workbench().set_in_simple_mode(False)
    get_workbench().set_option("run.pgzero_mode", False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_option("run.pgzero_mode", True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_in_simple_mode(True)
    get_workbench().set_option("run.pgzero_mode", False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_option("run.pgzero_mode", True)
    update

# Generated at 2022-06-22 15:37:12.166809
# Unit test for function toggle_variable
def test_toggle_variable():
    from unittest import mock

    with mock.patch.object(get_workbench(), 'get_variable', return_value=True) as mock_get_variable:
        toggle_variable()
        mock_get_variable.assert_called_with(_OPTION_NAME)
    

# Generated at 2022-06-22 15:37:14.866023
# Unit test for function update_environment
def test_update_environment():
    if os.getenv("PGZERO_MODE") != None:
        del os.environ["PGZERO_MODE"]
    update_environment()
    assert os.getenv("PGZERO_MODE") == "False"

# Generated at 2022-06-22 15:37:22.176835
# Unit test for function update_environment
def test_update_environment():
    workbench = get_workbench()  # using thonny's testsupport
    workbench.set_default(_OPTION_NAME, False)

    # default
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    # pygame zero mode enabled
    workbench.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    # pygame zero mode disabled
    workbench.set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 15:37:25.103594
# Unit test for function update_environment
def test_update_environment():
    os.environ.pop("PGZERO_MODE", None)
    wb = get_workbench()
    wb.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 15:37:29.188299
# Unit test for function load_plugin
def test_load_plugin():
    var = get_workbench().get_variable(_OPTION_NAME)
    assert var.get() == False
    get_workbench().set_option(_OPTION_NAME, True)
    assert var.get() == True
    toggle_variable()
    assert var.get() == False