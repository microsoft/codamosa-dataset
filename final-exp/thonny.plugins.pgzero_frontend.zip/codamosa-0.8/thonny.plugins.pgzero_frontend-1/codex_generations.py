

# Generated at 2022-06-22 15:28:01.092048
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock

    get_workbench().set_default = Mock()
    get_workbench().add_command = Mock()

    load_plugin()
    assert get_workbench().get_default(_OPTION_NAME) is False
    get_workbench().set_default.assert_called_with(_OPTION_NAME, False)
    assert (
        get_workbench().add_command.call_args_list
        == [
            ("toggle_pgzero_mode", "run", tr("Pygame Zero mode"), toggle_variable, _OPTION_NAME, 40)
        ]
    )

# Generated at 2022-06-22 15:28:07.667014
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default("run.pgzero_mode", True)
    load_plugin()
    assert get_workbench().get_option("run.pgzero_mode") == False
    get_workbench().set_default("run.pgzero_mode", False)
    load_plugin()
    assert get_workbench().get_option("run.pgzero_mode") == True

# Generated at 2022-06-22 15:28:15.449506
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench

    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)

    assert wb.get_option(_OPTION_NAME) is False
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().set_default(_OPTION_NAME, True)
    assert wb.get_option(_OPTION_NAME) is True
    assert os.environ["PGZERO_MODE"] == "1"

    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"

    toggle_variable()
    assert wb.get_option(_OPTION_NAME) is False
    assert os.environ["PGZERO_MODE"] == "auto"

    toggle_variable()
    assert w

# Generated at 2022-06-22 15:28:27.432884
# Unit test for function update_environment
def test_update_environment():
    try:
        from test.test_environment import run_isolated
    except ImportError:
        from test.support import run_unittest
        import unittest

        class EnvironmentTests(unittest.TestCase):
            def test_update_environment(self):
                self.assertIsNone(os.environ.get("PGZERO_MODE"))
                workbench = get_workbench()
                # test in_simple_mode
                workbench.simple_mode = True
                pgzero_mode = workbench.get_option(_OPTION_NAME)
                workbench.set_option(_OPTION_NAME, pgzero_mode)
                update_environment()
                self.assertEqual(os.environ["PGZERO_MODE"], "auto")
                # test non-simple_mode

# Generated at 2022-06-22 15:28:37.755008
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import MagicMock, sentinel
    workbench = MagicMock()
    workbench.in_simple_mode.return_value = sentinel.in_simple_mode
    workbench.get_option.return_value = sentinel.get_option
    get_workbench.return_value = workbench
    update_environment()

    workbench.in_simple_mode.assert_called_once_with()
    if sentinel.in_simple_mode:
        expected_env = "auto"
    else:
        expected_env = sentinel.get_option
    assert os.environ["PGZERO_MODE"] == expected_env

# Generated at 2022-06-22 15:28:46.460601
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) is False
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, True)
    assert get_workbench().get_option(_OPTION_NAME) is True
    assert os.environ["PGZERO_MODE"] == "1"
    get_workbench().set_option(_OPTION_NAME, False)
    assert get_workbench().get_option(_OPTION_NAME) is False
    assert os.environ["PGZERO_MODE"] == "0"

# Generated at 2022-06-22 15:28:50.019919
# Unit test for function toggle_variable
def test_toggle_variable():
    os.environ["PGZERO_MODE"] = "0"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "1"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "0"



# Generated at 2022-06-22 15:28:54.346829
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) is True
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) is False

# Generated at 2022-06-22 15:29:00.822485
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    wb.set_simple_mode(True)
    wb.set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    wb.set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 15:29:11.371038
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock
    from thonny import get_workbench
    from thonny.workbench import Workbench

    mock_workbench = Mock(spec=Workbench)
    mock_workbench.set_default = Mock()
    mock_workbench.add_command = Mock()

    get_workbench = Mock()
    get_workbench.return_value = mock_workbench

    load_plugin()

    mock_workbench.set_default.assert_called_once_with(_OPTION_NAME, False)
    mock_workbench.add_command.assert_called_once()

    args, kwargs = mock_workbench.add_command.call_args

    args, kwargs = mock_workbench.add_command.call_args


# Generated at 2022-06-22 15:29:20.043893
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_option(_OPTION_NAME, False)
    assert get_workbench().get_option(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-22 15:29:31.922431
# Unit test for function update_environment
def test_update_environment():
    from thonny.globals import get_workbench
    from thonny.common import InlineCommand
    from thonny.languages import tr

    # Set the same value for a second time
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_simple_mode(False)
    get_workbench().set_option("run.pgzero_mode", False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    # Set the same value for a second time
    get_workbench().set_simple_mode(False)
    get_workbench().set_option("run.pgzero_mode", True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    # Set

# Generated at 2022-06-22 15:29:34.058015
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    load_plugin()
    assert wb.get_variable(_OPTION_NAME).get() == False

# Generated at 2022-06-22 15:29:41.225889
# Unit test for function update_environment
def test_update_environment():
    if _OPTION_NAME in os.environ:
        del os.environ[_OPTION_NAME]
        
    get_workbench().in_simple_mode = lambda: True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    
    get_workbench().get_option = lambda option_name: True
    get_workbench().in_simple_mode = lambda: False
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 15:29:44.846673
# Unit test for function load_plugin
def test_load_plugin():
    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()

# Generated at 2022-06-22 15:29:48.353108
# Unit test for function toggle_variable
def test_toggle_variable():
    assert get_workbench().get_option(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False


# Generated at 2022-06-22 15:29:52.286419
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    try:
        load_plugin()
        var = wb.get_variable(_OPTION_NAME)
        assert not var.get()
        assert var.get_label() == tr("Pygame Zero mode")
        assert var.get_help_text() == tr("Start with Pygame Zero mode (pgzero.auto)")
        assert "PGZERO_MODE" not in os.environ
        var.set(True)
        wb.in_simple_mode = lambda: True
        update_environment()
        assert os.environ["PGZERO_MODE"] == "auto"
        wb.in_simple_mode = lambda: False
        update_environment()
        assert os.environ["PGZERO_MODE"] == "True"
    finally:
        del wb.commands

# Generated at 2022-06-22 15:30:02.996103
# Unit test for function update_environment
def test_update_environment():
    import os

    wb = get_workbench()
    orig_env = os.environ.get("PGZERO_MODE", "")

    # Reset the workbench to get rid of any previous commands
    wb.destroy()
    wb.create()


# Generated at 2022-06-22 15:30:06.201241
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()

# Generated at 2022-06-22 15:30:13.590397
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"
    
    wb.set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"
    
    wb.in_simple_mode = lambda : True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

# Generated at 2022-06-22 15:30:26.867595
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import THONNY_USER_DIR
    import os
    import shutil
    import sys
    import tempfile

    temp_cwd = tempfile.mkdtemp()
    os.chdir(temp_cwd)
    os.mkdir(os.path.join(temp_cwd, "user_dir"))

    sys.argv = ["thonny", "-u", os.path.join(temp_cwd, "user_dir")]
    os.environ["THONNY_USER_DIR"] = os.path.join(temp_cwd, "user_dir")

    from thonny.workbench import Workbench

    wb = Workbench()
    import thonnycontrib.pgzero_plugin

    assert wb.get_option(_OPTION_NAME) == False

# Generated at 2022-06-22 15:30:31.679452
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = ""
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"

# Generated at 2022-06-22 15:30:38.014410
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import Mock

    wb = Mock()
    wb.get_option.side_effect = lambda name: True

    get_workbench.cache_clear()
    get_workbench.cache(wb)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench.cache_clear()
    get_workbench.cache(wb)
    wb.get_option.side_effect = lambda name: False
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 15:30:47.991994
# Unit test for function update_environment
def test_update_environment():
    if "PGZERO_MODE" in os.environ:
        del os.environ["PGZERO_MODE"]

    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"

    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"

    get_workbench().set_option(_OPTION_NAME, "auto")
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().set_option(_OPTION_NAME, "1")
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"

# Generated at 2022-06-22 15:30:57.957832
# Unit test for function toggle_variable
def test_toggle_variable():
    uut = toggle_variable
    wb = get_workbench()
    wb.set_option(_OPTION_NAME, False)
    wb.set_simple_mode(True)

    # at the beginning the PGZERO_MODE is None
    assert os.environ["PGZERO_MODE"] == "auto"

    # call first time, the PGZERO_MODE is changed to True
    uut()
    assert wb.get_option(_OPTION_NAME)
    assert os.environ["PGZERO_MODE"] == "True"

    # call second time, the PGZERO_MODE is changed to False
    uut()
    assert not wb.get_option(_OPTION_NAME)
    assert os.environ["PGZERO_MODE"] == "False"

    # call third time, the PGZ

# Generated at 2022-06-22 15:31:01.869776
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_variable(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-22 15:31:09.530944
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import patch, MagicMock
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.run_command = MagicMock()
    wb.add_command = MagicMock()
    setattr(thonny.workbench, "Workbench", MagicMock(return_value=wb))
    update_environment()
    with patch.dict("os.environ", {}, clear=True):
        wb.get_variable(_OPTION_NAME).set(True)
        update_environment()
        assert os.environ["PGZERO_MODE"] == "True"
        wb.get_variable(_OPTION_NAME).set(False)
        update_environment()
        assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 15:31:14.266286
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, True)
    os.environ["PGZERO_MODE"] = "0"
    load_plugin()
    assert os.environ["PGZERO_MODE"] == "0"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "1"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "0"

# Generated at 2022-06-22 15:31:24.392696
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import Mock
    from thonny.workflow import SimpleView

    workbench = Mock()
    workbench.in_simple_mode = Mock(return_value=False)
    workbench.get_option = Mock(return_value=True)
    get_workbench = Mock(return_value=workbench)

    save_option = os.environ.get("PGZERO_MODE", None)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    if save_option is not None:
        os.environ["PGZERO_MODE"] = save_option
    else:
        del os.environ["PGZERO_MODE"]



# Generated at 2022-06-22 15:31:32.583855
# Unit test for function load_plugin
def test_load_plugin():
    plugin_manager._load_plugin("thonnycontrib.pgzero")
    assert "toggle_pgzero_mode" in get_workbench().commands
    assert get_workbench().get_variable(_OPTION_NAME) is not None
    get_workbench().set_simple_mode(True)
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_simple_mode(False)
    assert os.environ[_OPTION_NAME] == "False"
    toggle_variable()
    assert os.environ[_OPTION_NAME] == "True"

# Generated at 2022-06-22 15:31:45.982846
# Unit test for function load_plugin
def test_load_plugin():
    # The only test is to see if no exceptions occur.
    load_plugin()


# Generated at 2022-06-22 15:31:54.391905
# Unit test for function update_environment
def test_update_environment():
    old_value = os.environ.get("PGZERO_MODE")
    try:
        wb = get_workbench()
        wb._erase_all()
        wb.set_default(_OPTION_NAME, False)
        update_environment()
        assert os.environ.get("PGZERO_MODE") == "False"
        wb.set_option(_OPTION_NAME, True)
        update_environment()
        assert os.environ.get("PGZERO_MODE") == "True"
        wb.in_simple_mode = lambda : True
        update_environment()
        assert os.environ.get("PGZERO_MODE") == "auto"
    finally:
        if old_value is None:
            del os.environ["PGZERO_MODE"]

# Generated at 2022-06-22 15:32:00.132439
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.misc_utils import running_on_ci
    if running_on_ci():
        return
    reset_environment()
    assert os.environ.get("PGZERO_MODE") is None

    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"

    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"



# Generated at 2022-06-22 15:32:11.069411
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.workflow import configure_simple_backend
    from thonny import get_workbench
    from thonny.misc_utils import running_on_mac_os
    
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    os.environ["PGZERO_MODE"] = "auto"
    
    configure_simple_backend()
    toggle_variable()
    run_test(get_workbench().get_option(_OPTION_NAME) == True)
    run_test(os.environ["PGZERO_MODE"] == "true")
    
    configure_simple_backend()
    toggle_variable()
    run_test(get_workbench().get_option(_OPTION_NAME) == False)

# Generated at 2022-06-22 15:32:20.095443
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert not ("PGZERO_MODE" in os.environ)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert "PGZERO_MODE" in os.environ
    assert os.environ["PGZERO_MODE"] == "True"
    # Set simple mode
    get_workbench().set_simple_mode()
    update_environment()
    assert "PGZERO_MODE" in os.environ
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 15:32:28.094747
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import Mock

    wb = Mock()
    wb.get_option.return_value = True
    wb.in_simple_mode.return_value = False
    get_workbench.return_value = wb

    update_environment()
    os.environ["PGZERO_MODE"] = "True"

    wb.get_option.return_value = False
    wb.in_simple_mode.return_value = False

    update_environment()
    os.environ["PGZERO_MODE"] = "False"

    wb.in_simple_mode.return_value = True
    update_environment()
    os.environ["PGZERO_MODE"] = "auto"

# Generated at 2022-06-22 15:32:33.603632
# Unit test for function update_environment
def test_update_environment():
    import os
    from thonny.workbench import Workbench
    del os.environ["PGZERO_MODE"]
    workbench = Workbench()
    workbench.set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    workbench.in_simple_mode = lambda: False
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"



# Generated at 2022-06-22 15:32:34.576815
# Unit test for function toggle_variable
def test_toggle_variable():
    print(toggle_variable())

# Generated at 2022-06-22 15:32:40.344202
# Unit test for function toggle_variable
def test_toggle_variable():
    from unittest import mock
    from thonny import misc_utils
    from thonny.workbench import Workbench
    
    
    get_workbench().set_variable(_OPTION_NAME, False)
    assert get_workbench().get_variable(_OPTION_NAME) == False
    mock_variable_set = mock.Mock()
    get_workbench().set_variable = mock_variable_set
    toggle_variable()
    assert mock_variable_set.called == True

# Generated at 2022-06-22 15:32:51.744711
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import MagicMock
    from thonny.globals import get_workbench
    actual_workbench = get_workbench()
    mock_workbench = MagicMock()
    mock_workbench.get_option = MagicMock(side_effect=[True, False, False, True])
    mock_workbench.in_simple_mode = MagicMock(side_effect=[False, True, False, False])
    get_workbench.cache_clear()
    get_workbench.return_value = mock_workbench
    # check with in_simple_mode=False and get_option=True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    # check with in_simple_mode=True and get_option=True
    update_environment()


# Generated at 2022-06-22 15:33:22.203146
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.globals import get_workbench

    get_workbench().set_test_mode()
    get_workbench().set_variable(_OPTION_NAME, False)
    wb = get_workbench()
    assert wb.in_simple_mode()
    assert not wb.get_option(_OPTION_NAME)
    toggle_variable()
    assert wb.get_option(_OPTION_NAME)
    assert not wb.in_simple_mode()
    toggle_variable()
    assert not wb.get_option(_OPTION_NAME)
    assert wb.in_simple_mode()

# Generated at 2022-06-22 15:33:24.281850
# Unit test for function load_plugin
def test_load_plugin():
    assert get_workbench().get_option("run.pgzero_mode") == False

# Generated at 2022-06-22 15:33:35.532636
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )

    # Test toggle_variable
    toggle_variable()
    assert wb.get_variable(_OPTION_NAME)
    toggle_variable()
    assert not wb.get_variable(_OPTION_NAME)

    # Test update_environment
    wb.in_simple_mode = lambda: True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    wb.in_simple_

# Generated at 2022-06-22 15:33:42.122750
# Unit test for function update_environment
def test_update_environment():
    # Test 1: normal operation
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    # Test 1: simple_mode
    get_workbench().set_option(_OPTION_NAME, True)
    os.environ["PGZERO_MODE"] = ""
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"



# Generated at 2022-06-22 15:33:52.911463
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = "something"

    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_default(_OPTION_NAME, None)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 15:34:05.278222
# Unit test for function update_environment
def test_update_environment():
    # Enter simple mode
    get_workbench().set_in_simple_mode(True)
    
    # Disable Pygame Zero mode
    var = get_workbench().get_variable(_OPTION_NAME)
    var.set(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    
    # Enable Pygame Zero mode
    var.set(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    
    # Leave simple mode
    get_workbench().set_in_simple_mode(False)
    
    # Disable Pygame Zero mode
    var.set(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "no"
    
    # Enable Pygame

# Generated at 2022-06-22 15:34:10.106168
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    test_workbench = Tester(get_workbench())
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()
    test_workbench.check_cmd_exist("toggle_pgzero_mode")

# Generated at 2022-06-22 15:34:15.520420
# Unit test for function toggle_variable
def test_toggle_variable():
    test_workbench = get_workbench()
    test_workbench.set_default(_OPTION_NAME, True)
    toggle_variable()
    assert test_workbench.get_option(_OPTION_NAME) == False
    toggle_variable()
    assert test_workbench.get_option(_OPTION_NAME) == True



# Generated at 2022-06-22 15:34:20.132105
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, True)
    wb.set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    wb.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 15:34:27.063300
# Unit test for function load_plugin
def test_load_plugin():
    from unittest import mock
    from thonny import get_workbench

    workbench = get_workbench()
    workbench.register_command = mock.MagicMock()
    workbench.set_default = mock.MagicMock()
    load_plugin()
    assert workbench.set_default.call_args_list[0][0] == (_OPTION_NAME, False)

# Generated at 2022-06-22 15:35:22.062363
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().remove_command("toggle_pgzero_mode", "run")

    load_plugin()
    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    assert os.environ["PGZERO_MODE"] == "False"


if __name__ == "__main__":
    test_load_plugin()

# Generated at 2022-06-22 15:35:32.553195
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock
    from thonny.plugins.run import run_commands
    from thonny.workbench import Workbench
    from thonny.languages import tr

    wb = Workbench()
    wb.create()
    save_get_tk = run_commands._get_tk


# Generated at 2022-06-22 15:35:41.635123
# Unit test for function toggle_variable
def test_toggle_variable():
    from unittest import mock

    with mock.patch('thonny.plugins.pgzero_mode.os') as mocked_os:
        with mock.patch('thonny.plugins.pgzero_mode.get_workbench') as mocked_wb:
            mocked_wb().get_variable.return_value.get.return_value = False
            mocked_wb().get_variable.return_value.set.return_value = None
            toggle_variable()
            assert mocked_wb().get_variable.return_value.set.return_value is None
            mocked_wb().get_variable.return_value.set.return_value = None
            mocked_wb().get_variable.return_value.get.return_value = True
            toggle_variable()

# Generated at 2022-06-22 15:35:42.208683
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()

# Generated at 2022-06-22 15:35:48.726188
# Unit test for function load_plugin
def test_load_plugin():
    # pylint: disable=unused-variable
    import thonnycontrib.pgzero_mode

    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().add_command(
        "toggle_pgzero_mode2",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    load_plugin()

# Generated at 2022-06-22 15:35:57.659572
# Unit test for function toggle_variable
def test_toggle_variable():
    from test.config_helper import TkVersionDetector
    from test.config_helper import set_tk_version
    from unittest.mock import Mock, patch
    from thonny.config import Configuration

    viewer = get_workbench().get_option(_OPTION_NAME)
    assert viewer != None

    # Test pgzero_mode = True
    viewer.set(True)
    with patch.object(Configuration, "save") as mock_save:
        toggle_variable()
    # check pgzero_mode set to False
    assert viewer.get() == False

    # Test pgzero_mode = False
    with patch.object(Configuration, "save") as mock_save:
        toggle_variable()
    # check pgzero_mode set to True
    assert viewer.get() == True



# Generated at 2022-06-22 15:36:05.738261
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench

    wb = Workbench()
    load_plugin()

    assert "toggle_pgzero_mode" in wb.get_commands()
    assert wb.get_variable(_OPTION_NAME).get() is False

    assert "PGZERO_MODE" in os.environ
    assert os.environ["PGZERO_MODE"] == "False"

    assert "toggle_pgzero_mode" in wb.get_variable(_OPTION_NAME).get_dependencies()
    assert "PGZERO_MODE" in wb.get_variable(_OPTION_NAME).get_dependents()


if __name__ == "__main__":
    test_load_plugin()

# Generated at 2022-06-22 15:36:10.887600
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert get_workbench().get_default(_OPTION_NAME) == False
    assert get_workbench().get_option(_OPTION_NAME) == False
    toggle_varia

# Generated at 2022-06-22 15:36:17.656094
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    assert not get_workbench().get_variable(_OPTION_NAME).get()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    assert get_workbench().get_variable(_OPTION_NAME).get()
    assert get_workbench().get_option(_OPTION_NAME) == True


# Generated at 2022-06-22 15:36:24.564764
# Unit test for function load_plugin
def test_load_plugin():
    # noinspection PyUnresolvedReferences
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()
    assert wb.get_option(_OPTION_NAME) is False
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) is True
    assert os.getenv("PGZERO_MODE") == "True"
    wb.in_simple_mode = True
    toggle_variable()