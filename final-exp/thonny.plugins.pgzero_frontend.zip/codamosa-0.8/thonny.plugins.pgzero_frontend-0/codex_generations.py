

# Generated at 2022-06-22 15:27:53.877480
# Unit test for function load_plugin
def test_load_plugin():
    # This function is called before loading the plugin
    assert "PGZERO_MODE" not in os.environ

    # Simulate loading of plugin
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )

    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    # Simulate de-loading of plugin
    get_

# Generated at 2022-06-22 15:27:59.657767
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, FontSettingsWindow(True))
    assert get_workbench().get_option(_OPTION_NAME) is True
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) is False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) is True
    
    
    

if __name__ == "__main__":
    load_plugin()

# Generated at 2022-06-22 15:28:06.622783
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert "PGZERO_MODE" in os.environ
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 15:28:11.208828
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, True)
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == True

    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-22 15:28:26.712338
# Unit test for function update_environment
def test_update_environment():
    original_value = os.environ.get("PGZERO_MODE")
    get_workbench().set_default(_OPTION_NAME, True)
    get_workbench().set_simple_mode(True)
    assert os.environ.get("PGZERO_MODE") == "auto"
    get_workbench().set_simple_mode(False)
    assert os.environ.get("PGZERO_MODE") == "True"
    get_workbench().set_default(_OPTION_NAME, False)
    assert os.environ.get("PGZERO_MODE") == "False"
    # Returning environment to original state
    os.environ["PGZERO_MODE"] = original_value or None

# Generated at 2022-06-22 15:28:29.073831
# Unit test for function update_environment
def test_update_environment():
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 15:28:39.572183
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    assert not wb.in_simple_mode()
    assert get_workbench().get_option(_OPTION_NAME) is False
    assert os.environ["PGZERO_MODE"] == "0"

    # enable simple mode
    wb.set_simple_mode(True)
    load_plugin()
    assert wb.in_simple_mode()
    assert get_workbench().get_option(_OPTION_NAME) is False
    assert os.environ["PGZERO_MODE"] == "auto"

    # disable simple mode
    wb.set_simple_mode(False)
    load_plugin()
    assert not wb.in_simple_mode()
    assert get_workbench().get_option(_OPTION_NAME) is False

# Generated at 2022-06-22 15:28:43.341759
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    assert wb.get_variable(_OPTION_NAME).get() == False
    toggle_variable()
    assert wb.get_variable(_OPTION_NAME).get() == True

# Generated at 2022-06-22 15:28:45.416911
# Unit test for function toggle_variable
def test_toggle_variable():
    # Code for Unit test
    assert True, "foo"

# Generated at 2022-06-22 15:28:55.613005
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"
    get_workbench().set_option(_OPTION_NAME, False)
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().s

# Generated at 2022-06-22 15:29:06.343888
# Unit test for function load_plugin
def test_load_plugin():
    import thonny.plugins.pgzero_mode as pgzero_mode
    from thonny.workbench import Workbench
    wb = Workbench()
    wb.add_command = MagicMock()
    pgzero_mode.load_plugin()

    # Check the command was added

# Generated at 2022-06-22 15:29:17.751865
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    load_plugin()
    assert wb.get_default(_OPTION_NAME) == False
    assert wb.get_command("toggle_pgzero_mode")
    assert wb.get_option(_OPTION_NAME) == False
    assert "PGZERO_MODE" not in os.environ

    old_in_simple_mode = wb.in_simple_mode
    wb.in_simple_mode = lambda : True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    wb.in_simple_mode = lambda : False
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"

    toggle_variable()

# Generated at 2022-06-22 15:29:26.762820
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny import get_workbench
    workbench= get_workbench()
    workbench.set_simple_mode(True)
    assert workbench.in_simple_mode() == True
    assert 'PGZERO_MODE' not in os.environ
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert workbench.in_simple_mode() == False
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    assert workbench.in_simple_mode() == True
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()

# Generated at 2022-06-22 15:29:36.598255
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()

    wb.set_simple_mode(True)
    wb.set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    wb.set_simple_mode(False)
    wb.set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    wb.set_simple_mode(False)
    wb.set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 15:29:45.275592
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    wb.set_simple_mode(False)
    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    wb.set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    wb.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"


# Generated at 2022-06-22 15:29:52.509634
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench, get_shell
    from thonny.languages import tr
    from thonny.ui_utils import check_variable_setter
    
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()
    

# Generated at 2022-06-22 15:30:03.144828
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench
    from thonny.misc_utils import running_on_linux
    from unittest.mock import patch

    get_workbench().set_default(_OPTION_NAME, True)

    with patch.dict("os.environ", clear=True):
        # check if PGZERO_MODE is set to 1
        update_environment()
        assert os.environ["PGZERO_MODE"] == 1

        # check if PGZERO_MODE is set to 0
        get_workbench().set_default(_OPTION_NAME, False)
        update_environment()
        if running_on_linux():
            assert os.environ["PGZERO_MODE"] == 0

# Generated at 2022-06-22 15:30:11.320708
# Unit test for function toggle_variable
def test_toggle_variable():
    old_get_workbench = get_workbench
    get_workbench().set_option(_OPTION_NAME, False)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    assert get_workbench().get_option(_OPTION_NAME) == False, "Wrong initial value"
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True, "Wrong new value"
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False, "Wrong new value"

# Generated at 2022-06-22 15:30:14.593239
# Unit test for function update_environment
def test_update_environment():
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 15:30:21.084036
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    workbench = Workbench()
    workbench.set_default(_OPTION_NAME, True)
    os.environ["PGZERO_MODE"] = "auto"
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    workbench.set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 15:30:36.367733
# Unit test for function update_environment
def test_update_environment():
    from thonny.backend import BackendEventLoop, get_serial_ports
    from thonny.config_ui import TkOptionEditor
    from thonny.configuration import Configuration
    from thonny.memory import InMemoryBackend
    from thonny.misc_utils import running_on_mac_os

    config = Configuration(auto_save=False)
    backend = InMemoryBackend()
    config.set_backend(backend)
    config.set_workbench(get_workbench())
    option_editor = TkOptionEditor(config)
    # Don't let the GUI interfere
    option_editor.hide()
    evt = BackendEventLoop()
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()

    # test default
    assert os.environ

# Generated at 2022-06-22 15:30:38.972022
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert os.environ['PGZERO_MODE'] == 'False'

# Generated at 2022-06-22 15:30:41.595129
# Unit test for function toggle_variable
def test_toggle_variable():
    pv = get_workbench().get_variable(_OPTION_NAME)
    pv.set(False)
    toggle_variable()
    assert pv.get() == True
    toggle_variable()
    assert pv.get() == False
    toggle_variable()

# Generated at 2022-06-22 15:30:44.458760
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.unregister_all_plugins()
    wb.register_plugin("thonny.plugins.pgzero_mode")

# Generated at 2022-06-22 15:30:49.092773
# Unit test for function update_environment
def test_update_environment():
    from thonny.test_utils import capture_output
    from thonny import get_workbench
    from os import environ

    clean_environ = environ.copy()
    get_workbench().in_simple_mode = lambda: False

    # Unit test 1
    get_workbench().set_option("run.pgzero_mode", False)
    update_environment()
    assert environ == clean_environ

    # Unit test 2
    get_workbench().set_option("run.pgzero_mode", True)
    update_environment()
    assert environ["PGZERO_MODE"] == "True"

    # Unit test 3
    get_workbench().in_simple_mode = lambda: True
    get_workbench().set_option("run.pgzero_mode", False)
    update_environment()
   

# Generated at 2022-06-22 15:30:53.731050
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-22 15:30:57.965526
# Unit test for function toggle_variable
def test_toggle_variable():
    load_plugin()

    # Test 1: if variable is not set initially in simple mode
    os.environ["PGZERO_MODE"] = "no"
    toggle_variable()

    # Check that the variable is set
    assert os.environ["PGZERO_MODE"] == "auto"



# Generated at 2022-06-22 15:31:03.591102
# Unit test for function load_plugin
def test_load_plugin():
    saved_value = get_workbench().get_variable(_OPTION_NAME).get()
    try:
        get_workbench().set_variable(_OPTION_NAME, False)
        load_plugin()
        assert get_workbench().get_variable(_OPTION_NAME).get() == False
    finally:
        get_workbench().set_variable(_OPTION_NAME, saved_value)



# Generated at 2022-06-22 15:31:13.890443
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock

    mock_workbench = Mock()
    mock_workbench.get_variable = Mock(side_effect=get_workbench().get_variable)
    mock_workbench.add_command = Mock()
    mock_workbench.set_default = Mock()
    mock_workbench.in_simple_mode = Mock()

    global get_workbench
    old_get_workbench = get_workbench
    get_workbench = lambda: mock_workbench

    load_plugin()

    mock_workbench.set_default.assert_called_once_with(_OPTION_NAME, False)

# Generated at 2022-06-22 15:31:19.778955
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_in_simple_mode(False)
    assert not wb.get_variable(_OPTION_NAME).get()
    assert os.environ["PGZERO_MODE"] == "0"
    toggle_variable()
    assert wb.get_variable(_OPTION_NAME).get()
    assert os.environ["PGZERO_MODE"] == "1"
    toggle_variable()
    assert not wb.get_variable(_OPTION_NAME).get()
    assert os.environ["PGZERO_MODE"] == "0"
    wb.set_in_simple_mode(True)
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 15:31:42.110947
# Unit test for function update_environment
def test_update_environment():
    try:
        env_orig = os.environ["PGZERO_MODE"]
    except KeyError:
        env_orig = None

    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()

    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()

    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_simple_mode(True)
    update_environment()

    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()

    assert os

# Generated at 2022-06-22 15:31:49.205366
# Unit test for function toggle_variable
def test_toggle_variable():
    # Create a new project so that _OPTION_NAME is not added to old projects
    wb = get_workbench()
    wb.create_project()
    var = wb.get_variable(_OPTION_NAME)

    # Variable should not be set
    assert var.get() == False

    # Set the variable to True, then False again
    toggle_variable()
    assert var.get() == True
    toggle_variable()
    assert var.get() == False

# Generated at 2022-06-22 15:31:54.355862
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 15:32:04.529653
# Unit test for function update_environment
def test_update_environment():
    from thonny.misc_utils import running_on_mac_os
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    if running_on_mac_os():
        assert os.environ["PGZERO_MODE"] == "auto"
    else:
        assert os.environ["PGZERO_MODE"] == "0"

    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"

    get_workbench().set_simple_mode(True)
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 15:32:11.202902
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_in_simple_mode(True)
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().set_in_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_in_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 15:32:14.273059
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = "auto"
    update_environment()
    assert os.environ.get("PGZERO_MODE") == "auto"
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"

# Generated at 2022-06-22 15:32:14.858860
# Unit test for function toggle_variable
def test_toggle_variable():
    pass

# Generated at 2022-06-22 15:32:15.852864
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()



# Generated at 2022-06-22 15:32:19.716576
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench
    from thonny.languages import tr
    wb = get_workbench()
    wb._in_simple_mode = True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"



# Generated at 2022-06-22 15:32:23.486173
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 15:33:01.692850
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench
    from thonny.misc_utils import running_on_mac_os
    from thonny.misc_utils import running_on_windows

    wb = get_workbench()
    orig_initial_view = wb.get_option("initial_view")
    orig_simple_mode = wb.in_simple_mode()
    wb.set_option("initial_view", "Editor")
    wb.set_option("run.pgzero_mode", 0)
    if running_on_mac_os():
        assert os.environ["PGZERO_MODE"] == "auto"
    elif running_on_windows():
        assert os.environ["PGZERO_MODE"] == "auto"
    else:
        assert os.environ["PGZERO_MODE"]

# Generated at 2022-06-22 15:33:06.691966
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert get_workbench().get_option("run.pgzero_mode")

    assert get_workbench().get_variable("run.pgzero_mode")
    assert get_workbench().get_variable("run.pgzero_mode").get()



# Generated at 2022-06-22 15:33:17.146956
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ.get("PGZERO_MODE") == "True"
    load_plugin()
    assert os.environ.get("PGZERO_MODE") == "False"
    toggle_variable()
    assert os.environ.get("PGZERO_MODE") == "True"

# Generated at 2022-06-22 15:33:19.631705
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == True
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == False

# Generated at 2022-06-22 15:33:24.493015
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_runner
    from thonny.ui_utils import SubprocessDialog
    from unittest.mock import patch

    with patch("thonny.ui_utils.SubprocessDialog.start_subprocess") as start_subprocess:
        update_environment()
        start_subprocess.assert_called_once_with(
            get_runner().get_command_line(),
            cwd=None,
            env={"PGZERO_MODE":"False"},
            wait_for_completion=False
        )

# Generated at 2022-06-22 15:33:35.734385
# Unit test for function load_plugin
def test_load_plugin():
    global get_workbench
    
    class MockWorkbench:
        
        def __init__(self):
            self.options = {}
        
        def in_simple_mode(self):
            return False
            
        def add_command(self, command_name, category, label, command, flag_name=None, group=None):
            print("Added command", command_name, "to", category)
        
        def set_default(self, name, value):
            self.options[name] = value
        
        def get_option(self, name):
            return self.options["run.pgzero_mode"]
            
    def mock_get_workbench():
        return MockWorkbench()
            
    get_workbench = mock_get_workbench
    
    load_plugin()
    
    assert os.en

# Generated at 2022-06-22 15:33:37.368241
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()

if __name__ == "__main__":
    test_load_plugin()

# Generated at 2022-06-22 15:33:41.875769
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench, workbench
    get_workbench().set_default(_OPTION_NAME, False)
    assert get_workbench().get_option(_OPTION_NAME) is False


# Generated at 2022-06-22 15:33:48.586367
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.config_ui import ConfigurationPage
    from thonny.workbench import Workbench
    from unittest.mock import Mock
    from unittest.mock import MagicMock
    from unittest.mock import patch
    original_get_variable = Workbench.get_variable

    def get_variable(self, _):
        return MagicMock()

    Workbench.get_variable = get_variable

    from unittest.mock import sentinel


# Generated at 2022-06-22 15:33:57.644237
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    wb._set_variable(_OPTION_NAME, False)
    wb._set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    wb._set_variable(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    wb._set_variable(_OPTION_NAME, False)
    wb._set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 15:35:00.867308
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    assert wb.get_option(_OPTION_NAME)==False
    assert os.environ["PGZERO_MODE"] == "False"
    os.environ.pop("PGZERO_MODE", None)

# Generated at 2022-06-22 15:35:08.138815
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_default(_OPTION_NAME, False)

    wb.in_simple_mode = lambda: False
    wb._getting_started_frame.destroy()
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    wb.in_simple_mode = lambda: True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    os.environ.pop("PGZERO_MODE")

# Generated at 2022-06-22 15:35:13.968641
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, True)
    load_plugin()
    assert get_workbench().get_variable(_OPTION_NAME).get() == True
    assert get_workbench().get_option(_OPTION_NAME) == True
    assert os.environ.get("PGZERO_MODE") == "True"

# Generated at 2022-06-22 15:35:14.715733
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()

# Generated at 2022-06-22 15:35:16.944419
# Unit test for function load_plugin
def test_load_plugin():
    # pylint: disable=unused-variable
    # (we want to load the module)
    import thonnycontrib.pgzmode

# Generated at 2022-06-22 15:35:22.155218
# Unit test for function update_environment
def test_update_environment():
    from thonny.config import get_workbench
    from unittest.mock import Mock
    get_workbench = Mock()
    get_workbench.get_option = Mock(return_value=False)
    get_workbench.in_simple_mode = Mock(return_value=False)
    update_environment()
    print(os.environ["PGZERO_MODE"])
    assert os.environ["PGZERO_MODE"] == str(get_workbench.get_option(_OPTION_NAME))

# Generated at 2022-06-22 15:35:29.422586
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert (
        "run" in get_workbench().get_variable(
            "shell.additional_environment_variables"
        )
    )
    assert "PGZERO_MODE" in get_workbench().get_variable("shell.additional_environment_variables")["run"]
    assert "false" == get_workbench().get_variable("shell.additional_environment_variables")["run"]["PGZERO_MODE"]



# Generated at 2022-06-22 15:35:32.723794
# Unit test for function toggle_variable
def test_toggle_variable():
    load_plugin()
    assert not get_workbench().get_variable(_OPTION_NAME).get()
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get()
    toggle_variable()
    assert not get_workbench().get_variable(_OPTION_NAME).get()

# Generated at 2022-06-22 15:35:40.489224
# Unit test for function toggle_variable
def test_toggle_variable():
    from unittest.mock import Mock

    wb = Mock()
    wb.get_variable = lambda name: get_workbench().get_variable(name)
    wb.set_variable = lambda name, val: get_workbench().set_variable(name, val)

    wb.get_variable(_OPTION_NAME).set(False)
    assert wb.get_variable(_OPTION_NAME).get() == False
    toggle_variable()
    assert wb.get_variable(_OPTION_NAME).get() == True
    toggle_variable()
    assert wb.get_variable(_OPTION_NAME).get() == False

# Generated at 2022-06-22 15:35:48.071153
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import MagicMock
    wb = MagicMock()
    wb.get_option.return_value = "test_value"

    wb.in_simple_mode.return_value = True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    wb.in_simple_mode.return_value = False
    update_environment()
    assert os.environ["PGZERO_MODE"] == "test_value"

# Generated at 2022-06-22 15:37:24.922581
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    cmd = wb.get_command("toggle_pgzero_mode")
    assert cmd.label == tr("Pygame Zero mode")
    assert cmd.flag_name == _OPTION_NAME



# Generated at 2022-06-22 15:37:25.347595
# Unit test for function load_plugin

# Generated at 2022-06-22 15:37:30.110727
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False
