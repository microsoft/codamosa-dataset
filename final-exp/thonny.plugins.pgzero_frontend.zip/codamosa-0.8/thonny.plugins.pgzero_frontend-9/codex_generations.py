

# Generated at 2022-06-22 15:27:50.135814
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock

    wb = Mock()
    wb.in_simple_mode.return_value = False
    wb.set_default(_OPTION_NAME, False)
    wb.get_option.return_value = True
    wb.get_variable.return_value.get.return_value = False

    update_environment()
    # load_plugin(wb)

    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 15:27:53.717835
# Unit test for function toggle_variable
def test_toggle_variable():
    
    if (get_workbench().get_option(_OPTION_NAME) == True):
        toggle_variable()
    else:
        toggle_variable()

# Generated at 2022-06-22 15:27:59.197689
# Unit test for function update_environment
def test_update_environment():
    if os.environ["PGZERO_MODE"] == "auto":
        assert not get_workbench().get_option(_OPTION_NAME)
    elif os.environ["PGZERO_MODE"] == "True":
        assert get_workbench().get_option(_OPTION_NAME)
    elif os.environ["PGZERO_MODE"] == "False":
        assert not get_workbench().get_option(_OPTION_NAME)

# Generated at 2022-06-22 15:28:05.186192
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, True)
    wb.set_option(_OPTION_NAME, False)
    assert not wb.get_option(_OPTION_NAME)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 15:28:14.260014
# Unit test for function load_plugin
def test_load_plugin():
    from unittest import mock

    import thonny
    from thonny import get_workbench, get_runner

    get_workbench().set_default("run.pgzero_mode", True)
    get_workbench().get_option("run.pgzero_mode")

    mb = mock.MagicMock()
    info = mock.MagicMock()
    info.flag_name = "run.pgzero_mode"
    mb.in_simple_mode.return_value = False
    mb.get_option = get_workbench().get_option
    mb.get_option.return_value = False
    thonny.workbench = mb
    mb.get_runner = get_runner()
    mb.get_runner().env.clear()

# Generated at 2022-06-22 15:28:20.738997
# Unit test for function load_plugin
def test_load_plugin():
    assert len(get_workbench().commands) == 0
    load_plugin()
    assert len(get_workbench().commands) == 1

# Generated at 2022-06-22 15:28:25.675172
# Unit test for function toggle_variable
def test_toggle_variable():
    # Need to set `self.in_simple_mode` to False, otherwise
    # an exception will occur when calling `toggle_variable`
    get_workbench().in_simple_mode = False
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get()
    toggle_variable()
    assert not get_workbench().get_variable(_OPTION_NAME).get()


# Generated at 2022-06-22 15:28:35.561374
# Unit test for function update_environment
def test_update_environment():
    wb = Workbench()
    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    wb.set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    wb._simple_mode = True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 15:28:46.552593
# Unit test for function toggle_variable
def test_toggle_variable():
    from tests.utils import mock_tk_root
    from tests.utils import assert_equal, assert_true, assert_false
    from tkinter import BooleanVar
    from unittest.mock import MagicMock
    from thonny.workbench import Workbench

    root = mock_tk_root()
    wb = Workbench(root)

    wb.set_default(_OPTION_NAME, False)
    wb.add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )

    r = get_run_view()
    r.toggle_pgzero_mode_button.invoke()

# Generated at 2022-06-22 15:28:56.107388
# Unit test for function load_plugin
def test_load_plugin():
    # With option enabled
    wb = MockWorkbench()
    wb.set_default(_OPTION_NAME, False)
    load_plugin()
    assert len(wb._commands) == 1
    assert "toggle_pgzero_mode" in wb._commands
    assert "run" in wb._commands
    assert "toggle_pgzero_mode" in wb._key_bindings
    assert "run" in wb._key_bindings
    # With option disabled
    wb = MockWorkbench()
    wb.set_default(_OPTION_NAME, True)
    load_plugin()
    assert len(wb._commands) == 1
    assert "toggle_pgzero_mode" in wb._commands
    assert "run" in wb._commands



# Generated at 2022-06-22 15:29:02.591725
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()

# Generated at 2022-06-22 15:29:07.709732
# Unit test for function toggle_variable
def test_toggle_variable():
    old_value = get_workbench().get_option(_OPTION_NAME)

    new_value = not old_value
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == new_value


if __name__ == "__main__":
    test_toggle_variable()

# Generated at 2022-06-22 15:29:11.534339
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 15:29:19.484318
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import patch
    from thonny.workbench import Workbench
    workbench = Workbench()
    workbench.set_simple_mode(True)
    with patch.dict(os.environ, {}):
        update_environment()
        assert os.environ["PGZERO_MODE"] == "auto"
    workbench.set_simple_mode(False)
    workbench.set_option(_OPTION_NAME, False)
    with patch.dict(os.environ, {}):
        update_environment()
        assert os.environ["PGZERO_MODE"] == "0"
    workbench.set_option(_OPTION_NAME, True)
    with patch.dict(os.environ, {}):
        update_environment()

# Generated at 2022-06-22 15:29:27.320873
# Unit test for function load_plugin
def test_load_plugin():
    # Mock object to substitute Tk root object
    class TestWorkbench(object):
        def __init__(self):
            self.variables = {}
            self.commands = []

        def get_variable(self, name):
            if name in self.variables:
                return self.variables[name]
            else:
                return None

        def in_simple_mode(self):
            return False

        def get_option(self, name):
            if name in self.variables:
                return self.variables[name].get()

        def set_default(self, name, value):
            self.variables[name] = TkVariable(value)


# Generated at 2022-06-22 15:29:37.124738
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()
    assert get_workbench().get_variable("run.pgzero_mode").get() == True
    toggle_variable()
    assert get_workbench().get_variable("run.pgzero_mode").get() == False


if __name__ == "__main__":
    load_plugin()
    print("PGZERO_MODE", os.environ["PGZERO_MODE"])
    print("OPTION_NAME", get_workbench().get_option("run.pgzero_mode"))

    test_toggle_variable()
    print("PGZERO_MODE", os.environ["PGZERO_MODE"])
    print("OPTION_NAME", get_workbench().get_option("run.pgzero_mode"))

# Generated at 2022-06-22 15:29:48.031766
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.remove_command("toggle_pgzero_mode")
    wb.add_command = Mock()
    load_plugin()
    assert wb.get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "auto"
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"
    wb.in_simple_mode = Mock(return_value = True)
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 15:29:50.580426
# Unit test for function toggle_variable
def test_toggle_variable():
    from tkinter import BooleanVar
    from thonny import get_workbench
    test_wb = get_workbench()
    test_wb.set_default(_OPTION_NAME, False)
    test_wb.varDict[_OPTION_NAME] = BooleanVar()
    toggle_variable()
    assert test_wb.get_variable(_OPTION_NAME).get() == True

# Generated at 2022-06-22 15:29:56.738565
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = "auto"
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"

# Generated at 2022-06-22 15:29:59.120079
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    var = wb.get_variable(_OPTION_NAME)
    assert var
    assert var.get() == False
    toggle_variable()
    assert var.get() == True
    toggle_variable()
    assert var.get() == False
    toggle_variable()
    assert var.get() == True


# Generated at 2022-06-22 15:30:08.238997
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().in_simple_mode = lambda: False
    load_plugin()
    assert get_workbench().get_option("run.pgzero_mode") == False
    assert os.environ["PGZERO_MODE"] == "False"



# Generated at 2022-06-22 15:30:19.256141
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock
    from thonny import get_workbench
    from thonny.workbench import Workbench
    from thonny.languages import tr

    wb = Workbench()
    get_workbench.return_value = wb
    load_plugin()

    assert wb.options["run.pgzero_mode"] is False

    wb.in_simple_mode.return_value = True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    wb.in_simple_mode.return_value = False
    wb.options["run.pgzero_mode"] = True
    update_environment()

    assert os.environ["PGZERO_MODE"] == "True"


# Generated at 2022-06-22 15:30:26.920675
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()

    print("Testing load_plugin function")
    print("Test the status of pygame_zero mode")
    var = get_workbench().get_variable(_OPTION_NAME)
    assert not var.get()

    print("Swith to pygame_zero mode")
    toggle_variable()
    update_environment()
    var = get_workbench().get_variable(_OPTION_NAME)
    assert var.get()

    print("Test the toggling function")

    print

# Generated at 2022-06-22 15:30:32.853327
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(
        _OPTION_NAME) == True, "set_default(_OPTION_NAME, False) failed."
    toggle_variable()
    assert get_workbench().get_option(
        _OPTION_NAME) == False, "set_default(_OPTION_NAME, True) failed."

# Generated at 2022-06-22 15:30:39.756690
# Unit test for function update_environment
def test_update_environment():
    from unittest import mock
    from thonny.workbench import Workbench

    workbench = Workbench()
    workbench.set_default(_OPTION_NAME, False)
    workbench._simple_mode = False
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    workbench._simple_mode = True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    with mock.patch.object(workbench, "_simple_mode", False):
        workbench.set_option(_OPTION_NAME, True)
        update_environment()
        assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 15:30:45.282043
# Unit test for function load_plugin
def test_load_plugin():
    import unittest
    from unittest.mock import Mock

    wb = Mock(spec_set=get_workbench())

    wb.get_option.return_value = True
    load_plugin()
    wb.set_default.assert_called_once_with(_OPTION_NAME, False)
    wb.add_command.assert_called_once()



# Generated at 2022-06-22 15:30:55.351053
# Unit test for function update_environment
def test_update_environment():
    print(os.environ["PGZERO_MODE"])
    print(get_workbench().get_option(_OPTION_NAME))
    update_environment()
    print(os.environ["PGZERO_MODE"])
    print(get_workbench().get_option(_OPTION_NAME))
    toggle_variable()
    print(os.environ["PGZERO_MODE"])
    print(get_workbench().get_option(_OPTION_NAME))
    toggle_variable()
    print(os.environ["PGZERO_MODE"])
    print(get_workbench().get_option(_OPTION_NAME))

# Generated at 2022-06-22 15:31:04.562346
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)


    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        "Pygame Zero mode",
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )

    get_workbench().get_command("toggle_pgzero_mode").func()
    assert get_workbench().get_variable(_OPTION_NAME).get() == True

    get_workbench().get_command("toggle_pgzero_mode").func()
    assert get_workbench().get_variable(_OPTION_NAME).get() == False

# Generated at 2022-06-22 15:31:11.074434
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import workbench
    from thonny.ui_utils import toggle_checkbox

    workbench.in_simple_mode = lambda:False
    load_plugin()

    # Get widget
    cmd = workbench.get_command("toggle_pgzero_mode")
    assert cmd is not None
    cmd.invoke()
    assert workbench.get_option("run.pgzero_mode") is True
    cmd.invoke()
    assert workbench.get_option("run.pgzero_mode") is False

# Generated at 2022-06-22 15:31:15.327592
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench

    get_workbench().options["run.pgzero_mode"] = False
    load_plugin()
    assert get_workbench().get_option("run.pgzero_mode") == False

    get_workbench().options["run.pgzero_mode"] = True
    load_plugin()
    assert get_workbench().get_option("run.pgzero_mode") == True


# Generated at 2022-06-22 15:31:36.096756
# Unit test for function update_environment
def test_update_environment():
    from thonny.globals import get_workbench
    from thonny.test_utils import test_shell

    get_workbench().set_option(_OPTION_NAME, False)
    assert get_workbench().in_simple_mode() == False
    update_environment()
    assert "PGZERO_MODE" in os.environ
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_option(_OPTION_NAME, True)
    assert get_workbench().in_simple_mode() == False
    update_environment()
    assert "PGZERO_MODE" in os.environ
    assert os.environ["PGZERO_MODE"] == "True"

    test_shell.create()
    test_shell.execute("from thonny import *")
   

# Generated at 2022-06-22 15:31:42.087572
# Unit test for function update_environment

# Generated at 2022-06-22 15:31:50.192549
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 15:31:57.778808
# Unit test for function update_environment
def test_update_environment():
    from test.helper import run_interactive_toplevel
    from thonny import get_workbench
    from thonny.misc_utils import running_on_mac_os, running_on_windows, running_on_linux

    # Test on Mac OS
    if running_on_mac_os():
        run_interactive_toplevel("import os; print(os.environ['PGZERO_MODE'])")
        assert get_workbench().get_variable("PGZERO_MODE") == "auto"
        get_workbench().set_option(_OPTION_NAME, True)
        run_interactive_toplevel("import os; print(os.environ['PGZERO_MODE'])")
        assert get_workbench().get_variable("PGZERO_MODE") == "True"

    # Test on

# Generated at 2022-06-22 15:32:03.032043
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench
    from unittest.mock import Mock

    workbench_mock = Mock()
    get_workbench.GET_WORKBENCH_MOCK = workbench_mock

    workbench_mock.in_simple_mode.return_value = False
    workbench_mock.get_option.return_value = True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    workbench_mock.in_simple_mode.return_value = True
    workbench_mock.get_option.return_value = True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    workbench_mock.in_simple_mode.return_value = False
    workbench_mock

# Generated at 2022-06-22 15:32:09.261713
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench

    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    get_workbench().set_simple_mode(True)
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, False)
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 15:32:22.162954
# Unit test for function load_plugin
def test_load_plugin():
    
    # Get the workbench
    workbench = get_workbench()
    
    # Remove the pgzero mode command if it exists
    if workbench.in_simple_mode():
        workbench.remove_command("toggle_pgzero_mode")
    else:
        workbench.remove_command("run", "toggle_pgzero_mode")
    
    # Remove the pgzero mode environment variables
    if "PGZERO_MODE" in os.environ:
        del os.environ["PGZERO_MODE"]
    
    # Remove the pgzero mode option if it exists
    if workbench.has_option(_OPTION_NAME):
        workbench.remove_option(_OPTION_NAME)
    
    # Load the plugin
    load_plugin()
    
    # Check the workbench has the pgzero mode option and it

# Generated at 2022-06-22 15:32:31.292959
# Unit test for function update_environment
def test_update_environment():
    try:
        os.environ["PGZERO_MODE"]
    except:
        print("Variable PGZERO_MODE was not set.")
        
    print("The current PGZERO_MODE is:", str(os.environ['PGZERO_MODE']))
    old_value = os.environ['PGZERO_MODE']
    
    update_environment()
    wb = get_workbench()
    wb.set_option("run.pgzero_mode", True)
    print("The new PGZERO_MODE is:", str(os.environ['PGZERO_MODE']))
    assert os.environ['PGZERO_MODE'] == "True"
    
    update_environment()
    wb.set_option("run.pgzero_mode", False)

# Generated at 2022-06-22 15:32:41.545964
# Unit test for function update_environment
def test_update_environment():
    from thonny import workbench_open, workbench_close
    from thonny.globals import get_runner
    from thonny.languages import get_locale_key
    from thonny.misc_utils import running_on_mac_os

    workbench_close()
    workbench_open()
    get_workbench().add_view(WorkbenchTestView(None, None, None))

    if running_on_mac_os():
        expected_env_languages = "en,et"
    else:
        expected_env_languages = "et_EE.UTF-8"

    assert get_runner().get_environment()["LC_ALL"] == expected_env_languages
    assert get_runner().get_environment()["LANG"] == expected_env_languages

    get_workbench().get

# Generated at 2022-06-22 15:32:53.069768
# Unit test for function update_environment
def test_update_environment():
    import unittest
    import tempfile
    from thonny import get_workbench
    from pgzero.builtins import env, pgzrun

    class Test(unittest.TestCase):
        def setUp(self):
            self.old_pgzrun = pgzrun.run

        def tearDown(self):
            pgzrun.run = self.old_pgzrun

        def test_update_environment(self):
            get_workbench().set_simple_mode(False)
            update_environment()
            self.assertEqual(env.pgzero_mode, False)

            get_workbench().set_simple_mode(True)
            update_environment()
            self.assertEqual(env.pgzero_mode, "auto")

            get_workbench().set_simple_mode(False)
            get

# Generated at 2022-06-22 15:33:24.330609
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    wb.set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    wb.set_default(_OPTION_NAME, "auto")
    wb.set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    wb.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    wb.set_simple_mode(False)
    update_environment()

# Generated at 2022-06-22 15:33:26.249743
# Unit test for function load_plugin
def test_load_plugin():
    global load_plugin
    load_plugin()


# Generated at 2022-06-22 15:33:31.426930
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.globals import get_workbench

    get_workbench().set_option(_OPTION_NAME, 0)

    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == 1

    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == 0

# Generated at 2022-06-22 15:33:38.760239
# Unit test for function update_environment
def test_update_environment():
    os.environ.clear()
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().in_simple_mode = lambda: False

    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().in_simple_mode = lambda: True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 15:33:44.687849
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from unittest.mock import Mock

    wb = Workbench()
    wb.add_command = Mock()
    wb.set_default = Mock()
    get_workbench = Mock(return_value=wb)
    load_plugin()
    assert wb.get_default(_OPTION_NAME) == False
    assert wb.add_command.call_count == 1

# Generated at 2022-06-22 15:33:47.395373
# Unit test for function toggle_variable
def test_toggle_variable():
    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == True
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == False

# Generated at 2022-06-22 15:33:57.052737
# Unit test for function update_environment
def test_update_environment():
    from thonny.globals import get_workbench
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ.get("PGZERO_MODE") == "False"
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ.get("PGZERO_MODE") == "True"
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ.get("PGZERO_MODE") == "False"

# Generated at 2022-06-22 15:34:00.513211
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 15:34:07.709651
# Unit test for function update_environment
def test_update_environment():
    orig_pgzero_mode = os.environ.get("PGZERO_MODE", None)
    try:
        del os.environ["PGZERO_MODE"]
        update_environment()
        assert os.environ["PGZERO_MODE"] == "auto"
        get_workbench().set_option(_OPTION_NAME, True)
        update_environment()
        assert os.environ["PGZERO_MODE"] == "true"
    finally:
        if orig_pgzero_mode != None:
            os.environ["PGZERO_MODE"] = orig_pgzero_mode
        else:
            del os.environ["PGZERO_MODE"]

# Generated at 2022-06-22 15:34:16.900257
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import patch
    os.environ["PGZERO_MODE"] = "true"
    update_environment()
    with patch("os.environ.__setitem__") as set_env_mock:
        update_environment()
        assert set_env_mock.call_count == 1, "update_environment should have updated env variable"


if __name__ == "__main__":
    load_plugin()

# Generated at 2022-06-22 15:35:19.586310
# Unit test for function toggle_variable
def test_toggle_variable():
    tb = get_workbench()
    tb.set_simple_mode(False)
    toggle_variable()
    assert tb.get_variable(_OPTION_NAME).get() == True
    toggle_variable()
    assert tb.get_variable(_OPTION_NAME).get() == False
    tb.set_simple_mode(True)
    toggle_variable()
    assert tb.get_variable(_OPTION_NAME).get() == True
    toggle_variable()
    assert tb.get_variable(_OPTION_NAME).get() == True

# Generated at 2022-06-22 15:35:25.062843
# Unit test for function toggle_variable
def test_toggle_variable():
    from pytest import raises, skip
    from thonny.misc_utils import running_on_mac_os, running_on_windows
    from thonny.workbench import Workbench
    from thonny.languages import english, finnish
    
    if running_on_mac_os():
        skip("Pygame Zero is not supported on Mac OS")
    elif running_on_windows():
        skip("Pygame Zero is not supported on Windows")
    else:
        wb = Workbench()
        wb.set_default(_OPTION_NAME, False)
        toggle_variable()
        assert wb.get_option(_OPTION_NAME) is True
        toggle_variable()
        assert wb.get_option(_OPTION_NAME) is False

# Generated at 2022-06-22 15:35:25.605717
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()

# Generated at 2022-06-22 15:35:33.995120
# Unit test for function toggle_variable
def test_toggle_variable():
    # Mock get_workbench and in_simple_mode()
    workbench_get = mock.Mock()
    workbench_variable = mock.Mock()

    workbench_get.return_value = workbench_variable
    get_workbench.return_value = workbench_get
    workbench_get.in_simple_mode.return_value = False

    # Call toggle_variable()
    toggle_variable()

    # Verify that the workbench_variable get function was called
    workbench_get.assert_called_with("run.pgzero_mode")

    # Verify that the workbench_variable set function was called with arg True
    workbench_variable.set.assert_called_with(False)

    # Verify that the update_environment was called
    mock_update_environment = mock.Mock()
    update_environment.side

# Generated at 2022-06-22 15:35:38.858742
# Unit test for function toggle_variable
def test_toggle_variable():
    """
    This function unit tests the function toggle_variable.
    """
    # When initially toggling the variable, it should be True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    # When toggling the variable again, it should be False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-22 15:35:44.151903
# Unit test for function toggle_variable
def test_toggle_variable():
    
    assert get_workbench().in_simple_mode() == False
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"
    
    toggle_variable()
    
    assert get_workbench().in_simple_mode() == False
    assert get_workbench().get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"
    
    toggle_variable()
    assert get_workbench().in_simple_mode() == False
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"
    
    get_workbench().set_simple_mode("simple")
    
   

# Generated at 2022-06-22 15:35:53.252387
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench

    env = os.environ

# Generated at 2022-06-22 15:36:01.865664
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = "1"
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "1"
    
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"
    
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    
    del os.environ["PGZERO_MODE"]

# Generated at 2022-06-22 15:36:07.764041
# Unit test for function load_plugin
def test_load_plugin():
    from unittest import TestCase
    from unittest.mock import Mock

    get_workbench = Mock()
    wb = Mock()
    wb.get_variable = lambda opt: Mock()
    wb.add_command = Mock()
    get_workbench.return_value = wb

    globals()["get_workbench"] = get_workbench
    try:
        load_plugin()
        wb.get_variable.assert_called_with(_OPTION_NAME)
        wb.add_command.assert_called()
    finally:
        del globals()["get_workbench"]

# Generated at 2022-06-22 15:36:15.753976
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    assert not get_workbench().get_option(_OPTION_NAME)
    assert os.environ["PGZERO_MODE"] == "auto"

    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME)
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"