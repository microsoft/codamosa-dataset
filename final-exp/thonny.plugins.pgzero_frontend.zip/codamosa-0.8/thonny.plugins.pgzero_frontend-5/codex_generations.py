

# Generated at 2022-06-22 15:27:49.103448
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert wb.execute_command("toggle_pgzero_mode") == False
    assert wb.execute_command("toggle_pgzero_mode") == True
    assert wb.execute_command("toggle_pgzero_mode") == False

# Generated at 2022-06-22 15:27:58.218948
# Unit test for function load_plugin
def test_load_plugin():
    global get_workbench, toggle_variable, update_environment
    import unittest.mock

    get_workbench = unittest.mock.Mock()
    toggle_variable = unittest.mock.Mock()
    update_environment = unittest.mock.Mock()

    load_plugin()

    assert get_workbench().set_default.call_count == 1
    assert get_workbench().add_command.call_count == 1
    assert update_environment.call_count == 1

# Generated at 2022-06-22 15:28:02.546021
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, True)
    toggle_variable()
    assert not get_workbench().get_variable("run.pgzero_mode")
    toggle_variable()
    assert get_workbench().get_variable("run.pgzero_mode")

# Generated at 2022-06-22 15:28:09.118294
# Unit test for function update_environment
def test_update_environment():
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 15:28:13.105020
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, True)
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == False
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == True

# Generated at 2022-06-22 15:28:20.047873
# Unit test for function update_environment
def test_update_environment():
    assert os.environ["PGZERO_MODE"] != ""

# Generated at 2022-06-22 15:28:29.739622
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import Mock
    get_workbench().set_in_simple_mode(False)
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    
    get_workbench().set_in_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    
    get_workbench().set_in_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 15:28:39.633575
# Unit test for function update_environment
def test_update_environment():
    from thonny.config import get_workbench, set_option
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ.get("PGZERO_MODE") == "auto"

    get_workbench().set_simple_mode(False)
    update_environment()
    # otherwise environment is not changed
    assert os.environ.get("PGZERO_MODE") == "auto"

    set_option("run.pgzero_mode", True)
    update_environment()
    assert os.environ.get("PGZERO_MODE") == "true"

    set_option("run.pgzero_mode", False)
    update_environment()
    assert os.environ.get("PGZERO_MODE") == "false"

# Generated at 2022-06-22 15:28:43.930960
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    wb.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    wb.set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"

# Generated at 2022-06-22 15:28:51.237165
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()
    assert get_workbench().get_option("run.pgzero_mode") == True
    toggle_variable()
    assert get_workbench().get_option("run.pgzero_mode") == False

# Generated at 2022-06-22 15:28:57.760826
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

load_plugin()

# Generated at 2022-06-22 15:29:04.545144
# Unit test for function update_environment
def test_update_environment():
    test_wb = get_workbench()
    var = test_wb.get_variable(_OPTION_NAME)
    
    test_wb.set_default(_OPTION_NAME, False)
    test_wb.in_simple_mode = lambda: True
    update_environment()
    if os.environ["PGZERO_MODE"] != "auto":
        return False
    test_wb.in_simple_mode = lambda: False
    update_environment()
    if os.environ["PGZERO_MODE"] != "False":
        return False
    var.set(True)
    update_environment()
    if os.environ["PGZERO_MODE"] != "True":
        return False
    return True

# Generated at 2022-06-22 15:29:15.328244
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench

    wb = Workbench()
    load_plugin()

    # Test workbench commands
    assert len(wb.get_commands()) == 1
    assert wb.get_commands()[0]["name"] == "toggle_pgzero_mode"
    assert wb.get_commands()[0]["command"] == toggle_variable
    assert wb.get_commands()[0]["short_help"] == tr("Pygame Zero mode")
    assert wb.get_commands()[0]["flag_name"] == _OPTION_NAME
    assert wb.get_commands()[0]["group"] == 40

    # Test default settings
    assert not wb.get_option(_OPTION_NAME)

# Generated at 2022-06-22 15:29:19.975885
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.misc_utils import running_on_windows
    from thonny import get_workbench
    from thonny.languages import tr
    
    get_workbench().get_variable(_OPTION_NAME).get()
    get_workbench().in_simple_mode()
    get_workbench().get_option(_OPTION_NAME)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )

# Generated at 2022-06-22 15:29:31.784748
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.config import get_running_interpreter_info
    get_workbench().set_default("interpreter.name", "python&pgzero")
    interp_info = get_running_interpreter_info()
    if os.environ.get("PGZERO_MODE") != "True":
        os.environ["PGZERO_MODE"] = "False"
    
    if interp_info["name"] != "python&pgzero" or os.environ.get("PGZERO_MODE") != "False":
        return False

    toggle_variable()
    interp_info = get_running_interpreter_info()
    if interp_info["name"] != "python&pgzero" or os.environ.get("PGZERO_MODE") != "True":
        return False

   

# Generated at 2022-06-22 15:29:35.933987
# Unit test for function toggle_variable
def test_toggle_variable():
    b = get_workbench()
    toggle_variable()
    assert b.get_variable(_OPTION_NAME).get()
    toggle_variable()
    assert not b.get_variable(_OPTION_NAME).get()
    toggle_variable()
    assert b.get_variable(_OPTION_NAME).get()
    toggle_variable()

# Generated at 2022-06-22 15:29:43.515925
# Unit test for function update_environment
def test_update_environment():
    from test.test_config_page import create_workbench

    wb = create_workbench()
    del os.environ["PGZERO_MODE"]
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    wb.set_option(_OPTION_NAME, True)
    upda

# Generated at 2022-06-22 15:29:50.041885
# Unit test for function load_plugin
def test_load_plugin():
    if "PGZERO_MODE" in os.environ:
        del os.environ["PGZERO_MODE"]

    from thonny import workbench

    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()

    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 15:30:01.995546
# Unit test for function load_plugin
def test_load_plugin():
    from unittest import mock
    from thonny import get_workbench

    wb = get_workbench()
    wb._clear()
    assert not wb.in_simple_mode()
    assert not wb.get_option(_OPTION_NAME)
    assert os.environ.get("PGZERO_MODE", "") != "auto"
    load_plugin()
    assert wb.get_option(_OPTION_NAME) == False
    assert os.environ.get("PGZERO_MODE", "") == "False"
    wb.set_simple_mode_enabled(True)
    assert wb.get_option(_OPTION_NAME) == False
    assert os.environ.get("PGZERO_MODE", "") == "auto"


# Generated at 2022-06-22 15:30:02.671313
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()

# Generated at 2022-06-22 15:30:17.959034
# Unit test for function toggle_variable
def test_toggle_variable():
    from unittest.mock import Mock

    workbench = Mock()
    workbench.get_option = Mock(return_value=False)
    workbench.set_option = Mock()
    workbench.in_simple_mode = Mock(return_value=False)

    get_workbench().get_option = workbench.get_option
    get_workbench().set_option = workbench.set_option
    get_workbench().in_simple_mode = workbench.in_simple_mode

    toggle_variable()
    workbench.set_option.assert_called_with(_OPTION_NAME, True)



# Generated at 2022-06-22 15:30:25.690724
# Unit test for function load_plugin
def test_load_plugin():
    backup = list(get_workbench().commands.keys())
    backup_options = get_workbench().options.copy()
    backup_environment = os.environ.copy()

    try:
        from thonny.plugins.run.pgzero_mode import load_plugin

        load_plugin()
        assert "toggle_pgzero_mode" in get_workbench().commands
        assert "run.pgzero_mode" in get_workbench().options
    finally:
        get_workbench().commands.clear()
        get_workbench().commands.update({name: cmd for name, cmd in backup})
        get_workbench().options = backup_options
        os.environ.clear()
        os.environ.update(backup_environment)

# Generated at 2022-06-22 15:30:31.337789
# Unit test for function load_plugin
def test_load_plugin():
    plugin_name = 'thonnycontrib.pgzero'
    get_workbench().set_default(_OPTION_NAME, True)
    mock_workbench = Mock(wraps=get_workbench())
    sys.modules["thonny"] = mock_workbench
    mock_workbench.get_option = lambda *args: True
    mock_workbench.in_simple_mode = lambda *args: True
    mock_workbench.set_default = lambda *args: None
    mock_workbench.get_variable = lambda *args: True
    mock_workbench.add_command = lambda *args: None
    mock_workbench.get_workbench = lambda *args: mock_workbench

    load_plugin()
    del sys.modules["thonny"]

# Generated at 2022-06-22 15:30:39.200909
# Unit test for function update_environment
def test_update_environment():
    if _OPTION_NAME in os.environ:
        os.environ.pop(_OPTION_NAME)

    # Test that the variable is set and not set depending on simple mode
    get_workbench().in_simple_mode.return_value = True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    get_workbench().in_simple_mode.return_value = False
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    # Test that the environment variable is set to the value of the option
    get_workbench().get_option.return_value = True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 15:30:48.383497
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    import unittest.mock
    from thonny.option_utils import OptionUtils
    from thonny.options import OptionsPage
    from tkinter import Tk

    mock_options_page = unittest.mock.MagicMock(spec=OptionsPage)
    mock_options_page.get_var.return_value = False

    root = Tk()
    wb = Workbench(root)
    wb._options_page = mock_options_page

    update_environment()

    option_utils = OptionUtils(wb)
    ou = option_utils._OptionUtils__workbench._options_page

    assert ou.get_var("run.pgzero_mode").get() == False

# Generated at 2022-06-22 15:30:58.076286
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.unload_plugins()
    assert _OPTION_NAME not in wb.get_cached_options()
    assert "PGZERO_MODE" not in os.environ
    load_plugin()
    assert _OPTION_NAME in wb.get_cached_options()
    assert wb.get_option(_OPTION_NAME) is False
    assert "PGZERO_MODE" in os.environ
    assert os.environ["PGZERO_MODE"] == "False"
    wb.set_option(_OPTION_NAME, True)
    assert os.environ["PGZERO_MODE"] == "True"
    wb.unload_plugins()
    assert _OPTION_NAME not in wb.get_cached_options()

# Generated at 2022-06-22 15:31:07.393782
# Unit test for function load_plugin
def test_load_plugin():
    """Test if plugin is loaded properly"""

    wb = get_workbench()
    assert not wb.get_variable(_OPTION_NAME).get()

    # Load plugin
    load_plugin()

    assert wb.get_command("toggle_pgzero_mode")
    assert wb.get_plugin_variable(_OPTION_NAME)

    # Check the environment
    assert "PGZERO_MODE" not in os.environ

    # Enable simple mode
    wb.set_simple_mode(True)
    assert os.environ["PGZERO_MODE"] == "auto"

    # Disable simple mode
    wb.set_simple_mode(False)
    assert os.environ["PGZERO_MODE"] == "False"

    # Toggle the pgzero mode

# Generated at 2022-06-22 15:31:12.518357
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    get_workbench().set_simple_mode(True)
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_simple_mode(False)
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 15:31:16.646896
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, True)
    load_plugin()
    assert not wb.get_option(_OPTION_NAME)
    assert os.environ["PGZERO_MODE"] == "False"

    toggle_variable()
    assert wb.get_option(_OPTION_NAME)
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 15:31:27.165527
# Unit test for function update_environment
def test_update_environment():
    # Check for turning variable on/off
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.getenv("PGZERO_MODE") == 'False'
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.getenv("PGZERO_MODE") == 'True'
    # Check for turning simple mode on/off
    get_workbench().set_default(_OPTION_NAME, True)
    get_workbench().in_simple_mode = lambda: False
    update_environment()
    assert os.getenv("PGZERO_MODE") == 'True'
    get_workbench().set_default(_OPTION_NAME, True)
    get_workbench().in_simple_mode = lambda: True
    update

# Generated at 2022-06-22 15:31:48.860527
# Unit test for function load_plugin
def test_load_plugin():
    from unittest import mock
    from thonny.workbench import Workbench

    mock_workbench = Workbench()
    mock_workbench.get_variable = mock.MagicMock()
    mock_workbench.in_simple_mode = mock.MagicMock(return_value=False)
    mock_workbench.get_option = mock.MagicMock(return_value=True)
    mock_workbench.set_default = mock.MagicMock(return_value=False)
    mock_workbench.add_command = mock.MagicMock()

    with mock.patch("thonny.plugins.pgzero.get_workbench", return_value=mock_workbench):
        load_plugin()

# Generated at 2022-06-22 15:31:54.631884
# Unit test for function update_environment
def test_update_environment():
    command_interpreter = get_workbench().get_command_interpreter()
    command_interpreter.execute("run.pygame_mode")
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    command_interpreter.execute("run.pygame_mode")
    assert os.environ["PGZERO_MODE"] == "False"
    command_interpreter.execute("run.pygame_mode")
    assert os.environ["PGZERO_MODE"] == "True"



# Generated at 2022-06-22 15:31:58.832091
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, True)
    load_plugin()
    assert wb.get_option(_OPTION_NAME) == True

if __name__ == "__main__":
    test_load_plugin()

# Generated at 2022-06-22 15:32:05.805391
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_default("run.pgzero_mode", False)
    wb.add_command("toggle_pgzero_mode", "run", "Pygame Zero mode", toggle_variable, flag_name=_OPTION_NAME, group=40)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 15:32:09.186362
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    assert get_workbench().get_option(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-22 15:32:22.164125
# Unit test for function load_plugin
def test_load_plugin():
    workbench = get_workbench()
    workbench.set_default("run.pgzero_mode", False)
    load_plugin()
    assert workbench.get_variable("run.pgzero_mode").get() == False
    assert workbench.get_option("run.pgzero_mode") == False
    toggle_variable()
    assert workbench.get_variable("run.pgzero_mode").get() == True
    assert workbench.get_option("run.pgzero_mode") == True
    toggle_variable()
    assert workbench.get_variable("run.pgzero_mode").get() == False
    assert workbench.get_option("run.pgzero_mode") == False
    workbench.set_simple_mode(True)
    update_environment()

# Generated at 2022-06-22 15:32:31.292871
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import Mock
    from thonny.workbench import Workbench

    get_workbench = Mock(return_value=Mock(Workbench))
    get_workbench().set_default.assert_called_once_with(
        "run.pgzero_mode", False)
    get_workbench().add_command.assert_called_once_with(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()
    assert os.environ.get("PGZERO_MODE", "auto") == "auto"
    get_workbench().set_default("run.pgzero_mode", True)
    update_environment()
   

# Generated at 2022-06-22 15:32:35.605817
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_simple_mode(False)
    assert os.environ["PGZERO_MODE"] == "False"
    
    get_workbench().set_simple_mode(True)
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 15:32:40.368978
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = "auto"
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ.get("PGZERO_MODE") == "auto"
    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ.get("PGZERO_MODE") == "False"
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ.get("PGZERO_MODE") == "True"

# Generated at 2022-06-22 15:32:41.941305
# Unit test for function toggle_variable
def test_toggle_variable():
    
    toggle_variable()

# Generated at 2022-06-22 15:33:13.644570
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-22 15:33:20.322841
# Unit test for function update_environment
def test_update_environment():
    import os
    from thonny.plugins.pygame_zero import _OPTION_NAME
    from thonny import get_workbench

    workbench = get_workbench()
    workbench.set_default(_OPTION_NAME, True)

    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    workbench.set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    del os.environ["PGZERO_MODE"]

# Generated at 2022-06-22 15:33:31.185530
# Unit test for function load_plugin
def test_load_plugin():
    from pathlib import Path
    from test.test_runpy import get_temp_dir
    from test.capture import create_runner
    from thonny.main import _initialize_environment
    from thonny import get_workbench, get_runner
    from thonny.ui_utils import show_dialog

    runner = create_runner(get_temp_dir(), capture_input=True)
    runner.hide_main_window = True
    runner.subprocess_args = ("-i",)
    runner.start()
    _initialize_environment(runner)

    runner.execute_code("from thonny import *")
    runner.execute_code(
        "load_plugin('" + Path(__file__).resolve().as_posix() + "')"
    )
    assert get_workbench().get

# Generated at 2022-06-22 15:33:33.804374
# Unit test for function load_plugin
def test_load_plugin():
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "0"




# Generated at 2022-06-22 15:33:39.084364
# Unit test for function toggle_variable
def test_toggle_variable():
    workbench = get_workbench()
    workbench.set_default(_OPTION_NAME, False)
    try:
        update_environment()
        assert not workbench.get_option(_OPTION_NAME)
        toggle_variable()
        assert workbench.get_option(_OPTION_NAME)
        toggle_variable()
        assert not workbench.get_option(_OPTION_NAME)
    finally:
        workbench.set_default(_OPTION_NAME, False)

# Generated at 2022-06-22 15:33:46.115018
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.workbench import Workbench

    wb = Workbench()
    wb.set_simple_mode(False)
    assert wb.get_option(_OPTION_NAME) == False
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == True
    toggle_variable()
    assert wb.get_option(_OPTION_NAME) == False
    wb.set_simple_mode(True)
    assert os.getenv("PGZERO_MODE") == "auto"
    toggle_variable()
    assert os.getenv("PGZERO_MODE") == "True"
    toggle_variable()
    assert os.getenv("PGZERO_MODE") == "auto"

# Generated at 2022-06-22 15:33:55.707594
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 15:34:04.093996
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

    # simple mode
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    get_workbench().set_option("view.simple_mode", True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 15:34:08.384630
# Unit test for function load_plugin
def test_load_plugin():
    k = get_workbench()
    load_plugin()
    assert k.get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == str(k.get_option(_OPTION_NAME))
    k.set_simple_mode(True)
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 15:34:16.484748
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.unregister_all_commands()
    wb.destroy_ui()

    load_plugin()
    wb.get_default(_OPTION_NAME)
    wb.in_simple_mode()
    wb.add_command
    wb.set_default(_OPTION_NAME, False)
    wb.add_command
    wb.add_command
    wb.add_command



# Generated at 2022-06-22 15:35:21.866701
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    load_plugin()
    assert os.environ['PGZERO_MODE'] == "False"
    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ['PGZERO_MODE'] == "True"
    wb.set_option(_OPTION_NAME, False)
    wb.add_command("toggle_pgzero_mode", "run", "Pygame Zero mode", toggle_variable, flag_name=_OPTION_NAME, group=40)
    assert os.environ['PGZERO_MODE'] == "False"
    toggle_variable()
    assert os.environ['PGZERO_MODE'] == "True"
    toggle_variable()
    assert os.environ['PGZERO_MODE'] == "False"


# Generated at 2022-06-22 15:35:32.430183
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    var = wb.test_get_variable(_OPTION_NAME)
    # resets option value
    var._value = False
    # resets environment variable
    os.environ["PGZERO_MODE"] = ""

    # pgzero mode is disabled in Simple mode
    wb.in_simple_mode = lambda: True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    # pgzero mode is disabled
    wb.in_simple_mode = lambda: False
    var._value = False
    update_environment()
    assert os.environ["PGZERO_MODE"] == "off"

    # pgzero mode is enabled
    var._value = True
    update_environment()

# Generated at 2022-06-22 15:35:36.945077
# Unit test for function toggle_variable
def test_toggle_variable():
    try:
        toggle_variable()
        assert os.environ["PGZERO_MODE"] == "True"
        toggle_variable()
        assert os.environ["PGZERO_MODE"] == "False"
    except:
        os.environ["PGZERO_MODE"] = "False"
        raise

# Generated at 2022-06-22 15:35:40.764577
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = "1"
    if not get_workbench().in_simple_mode():
        update_environment()
        assert os.environ["PGZERO_MODE"] == "1"
    else:
        update_environment()
        assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-22 15:35:49.018890
# Unit test for function update_environment
def test_update_environment():
    from thonny.workbench import Workbench
    wb = Workbench()
    wb.set_default(_OPTION_NAME, True)

    assert "PGZERO_MODE" not in os.environ

    # check that PGZERO_MODE is updated too
    wb._simple_mode = False
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    # check that PGZERO_MODE is cleared in simple mode
    wb._simple_mode = True
    update_environment()
    assert "PGZERO_MODE" not in os.environ

# Generated at 2022-06-22 15:35:52.205720
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().remove_command("toggle_pgzero_mode")

    load_plugin()

    assert len(get_workbench().get_commands()) > 0
    assert _OPTION_NAME in get_workbench().get_option_names()

# Generated at 2022-06-22 15:36:02.373572
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.languages import get_languages, known_languages

    wb = Workbench()
    load_plugin()
    assert wb.get_option(_OPTION_NAME) == False

    assert get_languages() == known_languages

    assert os.environ.get("PGZERO_MODE") == "False"

    wb.set_option(_OPTION_NAME, True)
    assert wb.get_option(_OPTION_NAME) == True
    assert os.environ.get("PGZERO_MODE") == "True"

    wb.execute_command("toggle_pgzero_mode")
    assert wb.get_option(_OPTION_NAME) == False

# Generated at 2022-06-22 15:36:05.113459
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = "auto"
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "0"

# Generated at 2022-06-22 15:36:12.912035
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        "Pygame Zero mode",
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-22 15:36:21.583299
# Unit test for function update_environment
def test_update_environment():
    import os
    from test.globals import TestGlobalApi

    os.environ["PGZERO_MODE"] = ""
    wb = TestGlobalApi()
    wb.set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    wb.set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    wb.set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    wb.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
