

# Generated at 2022-06-26 07:23:21.408718
# Unit test for function toggle_variable
def test_toggle_variable():
    var_0 = load_plugin()
    var_1 = toggle_variable()


# Generated at 2022-06-26 07:23:23.127621
# Unit test for function update_environment
def test_update_environment():
    # Case 0:
    var_0 = load_plugin()
    test_update_environment_0()

# Case 0:

# Generated at 2022-06-26 07:23:26.067610
# Unit test for function load_plugin
def test_load_plugin():
    # Ensure that plugin was loaded
    with unittest.mock.patch('builtins.get_workbench', return_value=unittest.mock.MagicMock()) as mock:
        load_plugin()


# Generated at 2022-06-26 07:23:30.825926
# Unit test for function update_environment
def test_update_environment():
    var_0 = get_workbench()
    var_0.set_default(_OPTION_NAME, True)
    var_1 = get_workbench().get_option(_OPTION_NAME)
    os.environ["PGZERO_MODE"] = str(var_1)

    var_2 = update_environment()


# Generated at 2022-06-26 07:23:33.991256
# Unit test for function update_environment
def test_update_environment():
    f = update_environment()
    g = update_environment()
    for i in f:
        assert i in g
    for i in g:
        assert i in f

# Generated at 2022-06-26 07:23:36.682490
# Unit test for function toggle_variable
def test_toggle_variable():
    test_case_0()
    assert var_0 == load_plugin()


# Generated at 2022-06-26 07:23:41.670005
# Unit test for function load_plugin
def test_load_plugin():
    # Test for correct type
    assert isinstance(var_0, types.ModuleType)
    ## Test for correct value
    assert var_0.__name__ == "thonnycontrib.thonnypgzero.plugin"

if __name__ == "__main__":
    # load the plugin with load_plugin()
    test_load_plugin()
    test_case_0()

# Generated at 2022-06-26 07:23:48.128762
# Unit test for function load_plugin
def test_load_plugin():
    wb_0 = Mock()
    wb_0.get_variable = Mock(return_value=Mock())
    wb_0.in_simple_mode = Mock(return_value=Mock())
    wb_0.get_option = Mock(return_value=False)
    wb_0.set_default = Mock(return_value=False)
    wb_0.add_command = Mock(return_value=False)
    load_plugin(wb_0)


# Generated at 2022-06-26 07:23:59.430868
# Unit test for function load_plugin
def test_load_plugin():
    if not get_workbench().in_simple_mode():
        var_1 = load_plugin()
    else:
        var_1 = 1
    var_2 = _OPTION_NAME
    var_3 = load_plugin()
    var_4 = toggle_variable()
    var_5 = load_plugin()
    var_6 = _OPTION_NAME
    # Checking with these lines:
    #  var_1 != var_1
    #  var_2 == var_2
    #  var_3 != var_3
    #  var_4 != var_4
    #  var_5 != var_5
    #  var_6 == var_6

# Generated at 2022-06-26 07:24:05.535667
# Unit test for function load_plugin
def test_load_plugin():
    from unittest.mock import MagicMock
    from thonny.globals import get_workbench
    get_workbench().set_default = MagicMock()
    get_workbench().add_command = MagicMock()
    get_workbench().set_option = MagicMock()
    get_workbench().get_option = MagicMock()
    get_workbench().get_option.return_value = False
    load_plugin()
    assert get_workbench().get_option()


# Generated at 2022-06-26 07:24:22.351615
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()

# Generated at 2022-06-26 07:24:27.421232
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    assert var_0 == get_workbench().set_default(_OPTION_NAME, False)
    assert var_0 == get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )

# Generated at 2022-06-26 07:24:28.404300
# Unit test for function update_environment
def test_update_environment():
    assert False


# Generated at 2022-06-26 07:24:29.633179
# Unit test for function update_environment
def test_update_environment():
    var_0 = update_environment()


# Generated at 2022-06-26 07:24:32.752054
# Unit test for function update_environment
def test_update_environment():
    var_0 = None
    os.environ["PGZERO_MODE"] = "auto"
    var_0 = update_environment()
    assert var_0 == None


# Generated at 2022-06-26 07:24:33.660403
# Unit test for function load_plugin
def test_load_plugin():
    assert load_plugin() == None


# Generated at 2022-06-26 07:24:34.527082
# Unit test for function update_environment
def test_update_environment():
    var_0 = update_environment()


# Generated at 2022-06-26 07:24:38.324523
# Unit test for function update_environment
def test_update_environment():
    # Test the case where get_workbench().get_variable(_OPTION_NAME) is set to False
    var_0 = load_plugin()
    get_workbench().set_default(_OPTION_NAME, False)
    out_0 = update_environment()
    assert out_0 == None
    

# Generated at 2022-06-26 07:24:39.777136
# Unit test for function update_environment
def test_update_environment():
    test1_var_0 = update_environment()


# Generated at 2022-06-26 07:24:44.490579
# Unit test for function update_environment
def test_update_environment():
    if __name__ == '__main__':
        unittest.main()



# Generated at 2022-06-26 07:24:51.151809
# Unit test for function load_plugin
def test_load_plugin():
    return None


# Generated at 2022-06-26 07:24:52.455820
# Unit test for function toggle_variable
def test_toggle_variable():
    test_case_0()

# Generated at 2022-06-26 07:25:01.749480
# Unit test for function load_plugin
def test_load_plugin():
    # Uncommented lines are deprecated
    # test_0_install_dir_path = "/opt/thonny/plugins/pygame_zero_mode"
    # test_0_install_dir_path = "/home/kk/.local/share/thonny/plugins/pygame_zero_mode"
    # test_0_install_dir_path = "/home/kk/Documents/thonny/plugins/pygame_zero_mode"
    # test_0_install_dir_path = "/home/kk/.local/share/thonny/plugine-0.3/pygame_zero_mode"
    import os
    import thonnycontrib.pgzero_mode as thonnycontrib_pgzero_mode

    thonnycontrib_pgzero_mode.load_plugin()
    # print(thonny.

# Generated at 2022-06-26 07:25:02.598978
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    pass


# Generated at 2022-06-26 07:25:05.008439
# Unit test for function load_plugin
def test_load_plugin():

    get_workbench = test_case_0()
    assert get_workbench == load_plugin()


# should update_environment write to os.environ["PGZERO_MODE"]?

# Generated at 2022-06-26 07:25:06.768161
# Unit test for function load_plugin
def test_load_plugin():
    # Input parameters
    test_case_0()
    return None


# Generated at 2022-06-26 07:25:13.642198
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, True)
    wb.set_option(_OPTION_NAME, True)
    load_plugin()
    assert wb.get_option(_OPTION_NAME) == True

    wb.set_default(_OPTION_NAME, False)
    wb.set_option(_OPTION_NAME, False)
    load_plugin()
    assert wb.get_option(_OPTION_NAME) == False

test_load_plugin()

# Generated at 2022-06-26 07:25:15.694233
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()

if __name__ == "__main__":
    test_load_plugin()

# Generated at 2022-06-26 07:25:16.708179
# Unit test for function toggle_variable
def test_toggle_variable():
    assert callable(toggle_variable)

# Generated at 2022-06-26 07:25:17.528236
# Unit test for function update_environment
def test_update_environment():
    var_0 = update_environment()

# Generated at 2022-06-26 07:25:29.688997
# Unit test for function update_environment
def test_update_environment():
    var_0 = update_environment()


# Generated at 2022-06-26 07:25:33.731585
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, True)
    var_0 = get_workbench().get_variable(_OPTION_NAME)
    test_0 = str(var_0)
    var_0.set(not var_0.get())
    test_1 = var_0 ==  False #test_0
    assert test_1


# Generated at 2022-06-26 07:25:35.211436
# Unit test for function update_environment
def test_update_environment():
    assert update_environment() == None


# Generated at 2022-06-26 07:25:36.774621
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    test_case_0()


# Generated at 2022-06-26 07:25:39.664611
# Unit test for function update_environment
def test_update_environment():
    if update_environment():
        print("Test case 0")
        assert update_environment() == None, "Test case 0 is failed"


# Generated at 2022-06-26 07:25:40.268111
# Unit test for function update_environment
def test_update_environment():
    pass

# Generated at 2022-06-26 07:25:43.252579
# Unit test for function toggle_variable
def test_toggle_variable():
    #Test Case 1
    #Return Value:
    #    Value of _OPTION_NAME variable
    #Input Value:
    #    _OPTION_NAME = true
    #Expected Output:
    #    False
    #Assertion:
    #    The value of the variable is equal to expected output
    test_case_1 = load_plugin()
    assert test_case_1 == false


# Generated at 2022-06-26 07:25:44.746455
# Unit test for function update_environment
def test_update_environment():
    env_0 = update_environment()
    return env_0



# Generated at 2022-06-26 07:25:50.721667
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, True)
    get_workbench().set_option(_OPTION_NAME, True)
    assert get_workbench().get_option(_OPTION_NAME) == True
    result = toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False


# Generated at 2022-06-26 07:25:57.122437
# Unit test for function toggle_variable
def test_toggle_variable():
    with tempfile.TemporaryDirectory() as tmpdirname:
        os.environ["PGZERO_MODE"] = "auto"
        test_case_0()
        assert os.environ["PGZERO_MODE"] == "True"
        os.environ["PGZERO_MODE"] = "True"
        test_case_0()
        assert os.environ["PGZERO_MODE"] == "False"
        os.environ["PGZERO_MODE"] = "False"
        test_case_0()
        assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-26 07:26:22.855399
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert 2 + 2 == 4


# Generated at 2022-06-26 07:26:28.015786
# Unit test for function toggle_variable
def test_toggle_variable():
    case_0 = (
        """get_workbench().get_variable(_OPTION_NAME).set(False)
    """,
        {
            "get_workbench().__getitem__(_OPTION_NAME).get()": False,
            "get_workbench().__getitem__(_OPTION_NAME).get()": True,
        },
    )
    cases = [case_0]
    for case in cases:
        # Input.
        print(f"Input: {case[0]}")
        # Output.
        print(f"Output: {var_0}")
        # Assertion.
        assert var_0 == case[1]
        print("")


# Generated at 2022-06-26 07:26:30.284962
# Unit test for function update_environment
def test_update_environment():
    assert os.environ["PGZERO_MODE"] == "1"
    var_0 = update_environment()
    assert var_0 is None


# Generated at 2022-06-26 07:26:33.714325
# Unit test for function toggle_variable
def test_toggle_variable():
    var_0 = get_workbench().get_variable(_OPTION_NAME)
    save_0 = var_0.get()
    toggle_variable()
    var_1 = get_workbench().get_variable(_OPTION_NAME)
    assert var_1.get() != save_0
    var_0.set(save_0)


# Generated at 2022-06-26 07:26:43.492081
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, True)
    load_plugin()
    assert not get_workbench().in_simple_mode()
    get_workbench().set_simple_mode()
    load_plugin()
    assert get_workbench().in_simple_mode()
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    assert not get_workbench().in_simple_mode()
    get_workbench().set_simple_mode()
    load_plugin()
    assert get_workbench().in_simple_mode()

# Generated at 2022-06-26 07:26:49.111961
# Unit test for function load_plugin
def test_load_plugin():
    expected_result_0 = None

    result_0 = load_plugin()

    assert result_0 == expected_result_0




if __name__ == "__main__":
    from thonny import workbench

    workbench.setup("thonny")
    get_workbench().set_simple_mode(True)
    load_plugin()
    get_workbench().event_generate("Plugin-activated", {"plugin_name": "pgzero_mode"})

# Generated at 2022-06-26 07:26:51.893652
# Unit test for function update_environment
def test_update_environment():
    # Arrange
    get_workbench().set_default(_OPTION_NAME, False)

    # Act
    test_var = load_plugin()

    # Assert
    assert test_var.get() == False


# Generated at 2022-06-26 07:26:53.804431
# Unit test for function update_environment
def test_update_environment():
    var_0 = update_environment()

# Generated at 2022-06-26 07:26:54.854680
# Unit test for function update_environment
def test_update_environment():
    update_environment()
    assert True


# Generated at 2022-06-26 07:26:55.649545
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()


# Generated at 2022-06-26 07:27:50.375666
# Unit test for function update_environment
def test_update_environment():
    update_enviroment()


# Generated at 2022-06-26 07:27:53.472372
# Unit test for function update_environment
def test_update_environment():
    
    assert test_0(False) == os.environ["PGZERO_MODE"]
    assert test_0(True) == os.environ["PGZERO_MODE"]

# Generated at 2022-06-26 07:27:57.064351
# Unit test for function update_environment
def test_update_environment():
    env_0 = os.environ["PGZERO_MODE"]
    expected_0 = "False"
    assert env_0 == expected_0


if __name__ == "__main__":
    test_case_0()
    test_update_environment()

# Generated at 2022-06-26 07:27:58.089415
# Unit test for function update_environment
def test_update_environment():
    var_0 = update_environment()


# Generated at 2022-06-26 07:28:06.994298
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.codeview import CodeViewEvent
    from thonny.codeview import CodeViewTextEvent
    from thonny.codeview import CommandResult
    from thonny.codeview import FocusEvent
    from thonny.codeview import InputEvent
    from thonny.codeview import QuitEvent
    from thonny.codeview import SelectionEvent
    from thonny.codeview import StateEvent
    from thonny.codeview import WindowEvent

    wb = get_workbench()
    wb.synchronize_with_editor()
    wb.re_run_code()

    wb.get_editor_notebook().add_new_file()

    wb.get_editor_notebook().add_open_file("/home/pi/hello.py")
    wb.get_editor_note

# Generated at 2022-06-26 07:28:09.002357
# Unit test for function load_plugin
def test_load_plugin():
    # test_case_1
    assert load_plugin() != None, "Function load_plugin does not return value for valid inputs"


# Generated at 2022-06-26 07:28:09.788337
# Unit test for function load_plugin
def test_load_plugin():
    assert True == load_plugin()


# Generated at 2022-06-26 07:28:11.342653
# Unit test for function toggle_variable

# Generated at 2022-06-26 07:28:15.492979
# Unit test for function update_environment
def test_update_environment():
    # Setup
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()

    # Exercise
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()



# Generated at 2022-06-26 07:28:16.271486
# Unit test for function update_environment
def test_update_environment():
    test_case_0()

# Generated at 2022-06-26 07:30:24.862590
# Unit test for function load_plugin
def test_load_plugin():
    assert load_plugin() == None


# Generated at 2022-06-26 07:30:32.646570
# Unit test for function update_environment
def test_update_environment():
    sample_0_get_workbench = Mock()
    sample_0_get_workbench.in_simple_mode = MagicMock(return_value=True)
    sample_0_get_workbench.get_option = MagicMock(return_value=False)
    get_workbench.return_value = sample_0_get_workbench
    sample_0_os_set_env = {"PGZERO_MODE": "auto"}
    sample_0_os_set_env_expected = {"PGZERO_MODE": "auto"}
    with patch.dict(os.environ, sample_0_os_set_env, clear=True):
        update_environment()
    assert os.environ == sample_0_os_set_env_expected
    sample_1_get_workbench = Mock()
    sample_1_

# Generated at 2022-06-26 07:30:35.050677
# Unit test for function update_environment
def test_update_environment():
    expected_result = None
    actual_result = update_environment()
    assert actual_result == expected_result

# Generated at 2022-06-26 07:30:36.732719
# Unit test for function toggle_variable
def test_toggle_variable():
    assert toggle_variable() == None, 'toggle_variable() returned incorrect value'


# Generated at 2022-06-26 07:30:43.636402
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    assert os.environ["PGZERO_MODE"] == "0"
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == True
    assert os.environ["PGZERO_MODE"] == "1"
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    assert os.environ["PGZERO_MODE"] == "0"

# Generated at 2022-06-26 07:30:45.345832
# Unit test for function toggle_variable
def test_toggle_variable():
    var = True
    assert var == True

test_case_0()
test_toggle_variable()

# Generated at 2022-06-26 07:30:46.139001
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    

# Generated at 2022-06-26 07:30:47.294692
# Unit test for function toggle_variable
def test_toggle_variable():
    func_var_0 = toggle_variable()


# Generated at 2022-06-26 07:30:48.053204
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()


# Generated at 2022-06-26 07:30:48.795595
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
