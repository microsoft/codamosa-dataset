

# Generated at 2022-06-26 07:23:05.414320
# Unit test for function load_plugin
def test_load_plugin():
    # ---
    load_plugin()


# Generated at 2022-06-26 07:23:08.792279
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny.test.test_runner import saved_user_options

    def helper():
        get_workbench().set_option(_OPTION_NAME, False)
        toggle_variable()

    with saved_user_options():
        helper()

    assert get_workbench().get_option(_OPTION_NAME) is True


# Generated at 2022-06-26 07:23:09.428070
# Unit test for function update_environment
def test_update_environment():
    assert update_environment() == None


# Generated at 2022-06-26 07:23:18.291495
# Unit test for function load_plugin
def test_load_plugin():
    # Mock the get_workbench() function in module thonny.
    workbench = MagicMock(name="workbench")
    workbench.in_simple_mode = MagicMock(name="in_simple_mode")
    workbench.in_simple_mode.return_value = False
    get_workbench = MagicMock('get_workbench')
    get_workbench.return_value = workbench
    workbench.set_default = MagicMock('set_default')
    workbench.set_default.return_value = None
    workbench.add_command = MagicMock('add_command')
    workbench.add_command.return_value = None
    workbench.variable = MagicMock('variable')
    workbench.get_variable = MagicMock('get_variable')

# Generated at 2022-06-26 07:23:26.277338
# Unit test for function load_plugin
def test_load_plugin():

    # Creating Thonny's workbench
    wb = WorkbenchMock()

    # Create the plugin instance
    plugin = pgzero_mode(wb)

    # Set the default value for the variable 'run.pgzero_mode'
    wb.set_default("run.pgzero_mode", False)

    # Run the method 'load_plugin'
    plugin.load_plugin()

    # Assert the created command at the workbench
    assert wb.getCommand("toggle_pgzero_mode") == {
        "name": "Toggle Pygame Zero mode",
        "command_id": "toggle_pgzero_mode",
        "category": "Run",
        "short_desc": "Toggle the use of Pygame Zero mode",
        "handler": toggle_variable,
        "group_id": 40,
    }

   

# Generated at 2022-06-26 07:23:32.763391
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny import get_workbench
    from thonny.plugins.pgzero_mode import get_pgzero_mode

    get_workbench().set_default(_OPTION_NAME, True)
    toggle_variable()
    assert not get_pgzero_mode()

    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_pgzero_mode()


# Generated at 2022-06-26 07:23:42.405464
# Unit test for function toggle_variable
def test_toggle_variable():
    var_0 = get_workbench().get_variable(_OPTION_NAME)
    var_0.set(0)
    try:
        if 'PGZERO_MODE' in os.environ:
            del os.environ['PGZERO_MODE']
    except:
        var_0.set(1)
    try:
        toggle_variable()
    except:
        var_0.set(1)
    assert os.environ['PGZERO_MODE'] == 'True'
    try:
        if 'PGZERO_MODE' in os.environ:
            del os.environ['PGZERO_MODE']
    except:
        var_0.set(1)
    try:
        toggle_variable()
    except:
        var_0.set(1)

# Generated at 2022-06-26 07:23:47.830718
# Unit test for function load_plugin
def test_load_plugin():
    var_0 = load_plugin()
    var_1 = get_workbench().set_default(_OPTION_NAME, False)
    var_2 = get_workbench().add_command("toggle_pgzero_mode", "run", tr("Pygame Zero mode"), toggle_variable, flag_name=_OPTION_NAME, group=40)
    var_3 = update_environment()


# Generated at 2022-06-26 07:23:51.686244
# Unit test for function update_environment
def test_update_environment():
    if get_workbench().in_simple_mode():
        os.environ["PGZERO_MODE"] = "auto"
    else:
        os.environ["PGZERO_MODE"] = str(get_workbench().get_option(_OPTION_NAME))


# Generated at 2022-06-26 07:23:55.814684
# Unit test for function update_environment
def test_update_environment():
    if get_workbench().in_simple_mode():
        os.environ["PGZERO_MODE"] = "auto"
    else:
        os.environ["PGZERO_MODE"] = str(get_workbench().get_option(_OPTION_MODE))

# Generated at 2022-06-26 07:24:00.468662
# Unit test for function toggle_variable
def test_toggle_variable():
    # TODO: Add unit test for function toggle_variable
    pass


# Generated at 2022-06-26 07:24:01.846280
# Unit test for function update_environment
def test_update_environment():
    assert 1 == 1

# Generated at 2022-06-26 07:24:14.829083
# Unit test for function update_environment
def test_update_environment():
    var_0 = update_environment()

    # Test description:
    # 1. in_simple_mode == True
    # 2. _OPTION_NAME == False
    # 3. Test result: os.environ["PGZERO_MODE"] == ''
    print("Test description:")
    print("1. in_simple_mode == True")
    print("2. _OPTION_NAME == False")
    print("3. Test result: os.environ['PGZERO_MODE'] == ''")
    var_0 = get_workbench().in_simple_mode = mock.Mock(return_value=True)

# Generated at 2022-06-26 07:24:22.279088
# Unit test for function load_plugin
def test_load_plugin():
    if hasattr(get_workbench(), "get_variable"):
        get_workbench().set_simple_mode(True)

    if hasattr(get_workbench(), "add_command"):
        get_workbench().set_option("run.pgzero_mode", False)


# Generated at 2022-06-26 07:24:24.070270
# Unit test for function load_plugin
def test_load_plugin():
    assert load_plugin()


# Generated at 2022-06-26 07:24:36.608049
# Unit test for function update_environment
def test_update_environment():
	def dummy_get_workbench():
		return dummy_get_workbench
	def dummy_get_option(identifier):
		return True
	def dummy_in_simple_mode():
		return False
	get_workbench.get_workbench = lambda: dummy_get_workbench
	dummy_get_workbench.get_option = lambda x: dummy_get_option
	dummy_get_workbench.in_simple_mode = lambda: dummy_in_simple_mode
	try:
		update_environment()
	except Exception as err:
		raise AssertionError(err)

# Generated at 2022-06-26 07:24:43.967087
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default(_OPTION_NAME, True)
    #if get_workbench().in_simple_mode():
    #   os.environ["PGZERO_MODE"] = "auto"
    #else:
    #    os.environ["PGZERO_MODE"] = str(get_workbench().get_option(_OPTION_NAME))

    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-26 07:24:48.547514
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert get_workbench().in_simple_mode() == False
    assert os.environ["PGZERO_MODE"] == "False"



# Generated at 2022-06-26 07:24:51.749748
# Unit test for function toggle_variable
def test_toggle_variable():
    assert toggle_variable() is None, 'toggle_variable returned None, expected type	None'


if __name__ == "__main__":
    test_case_0()
    test_toggle_variable()

# Generated at 2022-06-26 07:25:01.248513
# Unit test for function toggle_variable
def test_toggle_variable():
    from unittest import mock

    mock_1 = mock.Mock()
    mock_2 = mock.Mock()
    mock_3 = mock.Mock()

    with mock.patch.dict(sys.modules, {"thonny": mock.Mock()}):
        import thonny

        mock_2.get_workbench.return_value = mock_3
        thonny.get_workbench = mock_2
        mock_3.get_variable.return_value = mock_1
        mock_1.set.return_value = None
        mock_3.get_variable.return_value = mock_1
        mock_1.get.return_value = None
        thonny.toggle_variable()
        mock_3.get_variable.assert_called_once_with(_OPTION_NAME)
        mock

# Generated at 2022-06-26 07:25:07.391963
# Unit test for function load_plugin
def test_load_plugin():
    # setup
    global get_workbench
    # test
    test_1 = load_plugin()
    # verify
    assert get_workbench == test_1

# Generated at 2022-06-26 07:25:15.144434
# Unit test for function load_plugin
def test_load_plugin():
    wb = TestWorkbench()
    load_plugin()
    assert wb.get_option(_OPTION_NAME) == False
    assert wb.get_command("toggle_pgzero_mode")
    assert os.environ["PGZERO_MODE"] == "False"
    wb.execute_command("toggle_pgzero_mode")
    assert wb.get_option(_OPTION_NAME) == True
    assert wb.get_command("toggle_pgzero_mode")
    assert os.environ["PGZERO_MODE"] == "True"



# Generated at 2022-06-26 07:25:20.767634
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)

    # Test variable is set to the False value
    os.environ["PGZERO_MODE"] = "auto"
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    # Test variable is set to the True value
    wb.set_default(_OPTION_NAME, True)
    os.environ["PGZERO_MODE"] = "auto"
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

    wb.set_default(_OPTION_NAME, False)

# Generated at 2022-06-26 07:25:31.616399
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().get_variable(_OPTION_NAME)
    get_workbench().add_command("toggle_pgzero_mode", "run", tr("Pygame Zero mode"), toggle_variable, flag_name=_OPTION_NAME, group=40)
    os.environ["PGZERO_MODE"] = str(get_workbench().get_option(_OPTION_NAME))
    if not hasattr(test_case_0, "__call__"):
        raise AttributeError("test_case_0 does not have __call__")
    var_0 = test_case_0()
    assert var_0.__name__ == "toggle_variable"

# Generated at 2022-06-26 07:25:32.522743
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable


# Generated at 2022-06-26 07:25:33.385699
# Unit test for function update_environment
def test_update_environment():
    assert update_environment() == None


# Generated at 2022-06-26 07:25:35.532496
# Unit test for function load_plugin
def test_load_plugin():
    _plugin_manager = None
    _plugin_manager = load_plugin()


# Generated at 2022-06-26 07:25:37.086437
# Unit test for function load_plugin
def test_load_plugin():
    assert type(load_plugin()) is None


# Generated at 2022-06-26 07:25:37.890383
# Unit test for function update_environment
def test_update_environment():
    update_environment()

# Generated at 2022-06-26 07:25:39.714712
# Unit test for function update_environment
def test_update_environment():
    assert isinstance(update_environment(), object)

# Generated at 2022-06-26 07:25:47.287745
# Unit test for function update_environment
def test_update_environment():
    # Simple test
    update_environment()


# Generated at 2022-06-26 07:25:48.667669
# Unit test for function update_environment
def test_update_environment():
    var_0 = update_environment()

# Generated at 2022-06-26 07:25:50.065182
# Unit test for function update_environment
def test_update_environment():
    # assert update_environment() == None
    pass


# Generated at 2022-06-26 07:25:51.003912
# Unit test for function update_environment
def test_update_environment():
    var_0 = update_environment()


# Generated at 2022-06-26 07:25:51.920801
# Unit test for function update_environment
def test_update_environment():
    update_environment()


# Generated at 2022-06-26 07:25:55.557796
# Unit test for function update_environment
def test_update_environment():
    if get_workbench().in_simple_mode():
        os.environ["PGZERO_MODE"] = "auto"
    else:
        os.environ["PGZERO_MODE"] = str(get_workbench().get_option(_OPTION_NAME))

# Generated at 2022-06-26 07:25:56.744249
# Unit test for function update_environment
def test_update_environment():
    test_case_0()


# Generated at 2022-06-26 07:25:58.965329
# Unit test for function toggle_variable
def test_toggle_variable():
    return None
    assert False # TODO: implement your test here


# Generated at 2022-06-26 07:26:02.219882
# Unit test for function load_plugin
def test_load_plugin():
    """
    Unit test for function load_plugin
      Arguments: None
      Returns: None
    """
    # Add your unit test code here
    # To see the result, run 'nosetests -v' on the command line
    assert True

# Generated at 2022-06-26 07:26:03.316805
# Unit test for function toggle_variable
def test_toggle_variable():
    pass


# Generated at 2022-06-26 07:26:23.020951
# Unit test for function load_plugin
def test_load_plugin():
    set_test_data("options.run.pgzero_mode", "True")
    set_test_data("environment.PGZERO_MODE", "True")
    load_plugin()
    assert_equal(get_workbench().in_simple_mode(), False)
    assert_equal(get_workbench().get_option("run.pgzero_mode"), True)
    assert_equal(get_workbench().get_variable("run.pgzero_mode").get(), True)
    assert_equal(get_test_data("environment.PGZERO_MODE"), "True")
    assert_equal(get_test_data("options.run.pgzero_mode"), "True")


# Generated at 2022-06-26 07:26:24.467624
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = "False"
    update_environment()
    

# Generated at 2022-06-26 07:26:26.271903
# Unit test for function update_environment
def test_update_environment():
    # for now, there are no tests for this function
    pass


# Generated at 2022-06-26 07:26:31.173169
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.globals import get_workbench
    wb = get_workbench()
    wb.remove_command("toggle_pgzero_mode")
    load_plugin()
    assert "toggle_pgzero_mode" in wb.get_commands()["run"]
    assert wb.get_variable("run.pgzero_mode").get() == False
    try:
        _test_case_0()
    except Exception:
        pass

# Generated at 2022-06-26 07:26:31.967387
# Unit test for function update_environment
def test_update_environment():
    update_environment()
    assert 1 == 1

# Generated at 2022-06-26 07:26:32.699200
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()


# Generated at 2022-06-26 07:26:35.850292
# Unit test for function toggle_variable
def test_toggle_variable():
    
    # This test case checks that the variable is not initialized
    test_case_0()
    assert False


# Generated at 2022-06-26 07:26:41.611611
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    wb.add_variable(var_name = 'TEST_VARIABLE', value = False, scope = 'default')
    wb.set_option(option_name = 'run.pgzero_mode', value = False)

# Generated at 2022-06-26 07:26:42.452106
# Unit test for function update_environment
def test_update_environment():
    update_environment()

# Generated at 2022-06-26 07:26:51.690207
# Unit test for function update_environment
def test_update_environment():
    import os
    import unittest

    # First, test that the function cannot be run when not in simple mode
    os.environ["PGZERO_MODE"] = "auto"
    os.environ["THONNY_SIMPLE_MODE"] = "1"
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    os.environ["THONNY_SIMPLE_MODE"] = "0"
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    os.environ["THONNY_SIMPLE_MODE"] = "False"
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

    # Then, test that the function can be run

# Generated at 2022-06-26 07:27:20.143657
# Unit test for function update_environment
def test_update_environment():
    assert os.environ["PGZERO_MODE"] == "auto"


# Generated at 2022-06-26 07:27:23.523722
# Unit test for function update_environment
def test_update_environment():

    py_text_0 = str()
    print(py_text_0)

# Generated at 2022-06-26 07:27:24.597788
# Unit test for function load_plugin
def test_load_plugin():
    assert callable(load_plugin)

# Generated at 2022-06-26 07:27:25.114617
# Unit test for function update_environment
def test_update_environment():
    pass



# Generated at 2022-06-26 07:27:35.879668
# Unit test for function load_plugin

# Generated at 2022-06-26 07:27:37.289756
# Unit test for function update_environment
def test_update_environment():
    var_0 = update_environment()


# Generated at 2022-06-26 07:27:41.882555
# Unit test for function load_plugin
def test_load_plugin():
    # Test parameters
    package = "thonny-plugins.pgz_mode"
    # Execute function
    # Execute load_plugin()
    load_plugin()
    # Verify
    assert os.getenv("PGZERO_MODE") == "True"


# Generated at 2022-06-26 07:27:46.903768
# Unit test for function update_environment
def test_update_environment():
    global os
    # Mock os module
    class MockOsModule():
        def __init__(self):
            self.environ = {}
            self.environ_get = self.environ.get
            self.environ_set = self.environ.set
    os = MockOsModule()
    var_0 = update_environment()
    assert os.environ == {"PGZERO_MODE": "false"}

# Generated at 2022-06-26 07:27:49.891876
# Unit test for function toggle_variable
def test_toggle_variable():
    # Another function call
    assert toggle_variable() == None


# Generated at 2022-06-26 07:27:51.009286
# Unit test for function toggle_variable
def test_toggle_variable():
    assert(var_0 == True)



# Generated at 2022-06-26 07:28:46.042160
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()


# Generated at 2022-06-26 07:28:46.974716
# Unit test for function update_environment
def test_update_environment():
    assert update_environment() == None


# Generated at 2022-06-26 07:28:49.557033
# Unit test for function update_environment
def test_update_environment():
    pass

if __name__ == "__main__":
    """Run the unit tests."""
    print("Running unit tests for pgzero_mode.py")
    test_case_0()
    test_update_environment()
    print("Done!")

# Generated at 2022-06-26 07:28:50.800331
# Unit test for function toggle_variable
def test_toggle_variable():
    # Unit test for function toggle_variable
    assert var_0 == None


# Generated at 2022-06-26 07:28:52.087832
# Unit test for function update_environment
def test_update_environment():
    pass  # TODO



# Generated at 2022-06-26 07:28:53.454356
# Unit test for function update_environment
def test_update_environment():
    # TODO: Implement unit test
    pass



# Generated at 2022-06-26 07:28:54.735458
# Unit test for function load_plugin
def test_load_plugin():
    # Test passing no arguments
    load_plugin()



# Generated at 2022-06-26 07:28:55.547915
# Unit test for function update_environment
def test_update_environment():
    var_0 = update_environment()


# Generated at 2022-06-26 07:28:57.007027
# Unit test for function load_plugin
def test_load_plugin():
    # SUT
    load_plugin()
    #
    assert True

# Generated at 2022-06-26 07:28:58.477504
# Unit test for function toggle_variable
def test_toggle_variable():
    # Test
    print('Function toggle_variable being tested')
    assert True


# Generated at 2022-06-26 07:30:57.517318
# Unit test for function toggle_variable
def test_toggle_variable():
    try:
        raise NotImplementedError("Test not implemented")
    except:
        if get_workbench().get_option("unit_test_mode"):
            raise


# Generated at 2022-06-26 07:30:58.242515
# Unit test for function load_plugin
def test_load_plugin():
    var_0 = load_plugin()


# Generated at 2022-06-26 07:31:04.859712
# Unit test for function update_environment
def test_update_environment():
    if not os.environ.get("PGZERO_MODE"): # Test: 0.0
        if not get_workbench().in_simple_mode(): # Test: 0.0.0
            if not get_workbench().get_option(_OPTION_NAME): # Test: 0.0.0.0
                if os.environ.get("PGZERO_MODE") == "auto": # Test: 0.0.0.0.0
                    return (0)
                else: # Test: 0.0.0.0.1
                    return (1)
            else: # Test: 0.0.0.1
                if os.environ.get("PGZERO_MODE") == "True": # Test: 0.0.0.1.0
                    return (0)

# Generated at 2022-06-26 07:31:06.507098
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = "auto"
    assert os.environ["PGZERO_MODE"] == "auto"



# Generated at 2022-06-26 07:31:07.173387
# Unit test for function toggle_variable
def test_toggle_variable():
    test_case_0()



# Generated at 2022-06-26 07:31:09.371613
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_option(_OPTION_NAME,True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-26 07:31:11.449382
# Unit test for function update_environment
def test_update_environment():
    a = get_workbench
    b = update_environment()
    assert b == "auto"

# Generated at 2022-06-26 07:31:12.665907
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()



# Generated at 2022-06-26 07:31:18.258116
# Unit test for function update_environment
def test_update_environment():
    from thonny.backend import get_runner
    # Patch:
    var = get_workbench().get_variable(_OPTION_NAME)
    var.set(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    # Patch:
    var.set(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-26 07:31:22.543251
# Unit test for function toggle_variable
def test_toggle_variable():
    import unittest.mock as mock
    get_workbench = mock.MagicMock()
    set_default = mock.MagicMock()
    get_variable = mock.MagicMock()
    toggle_variable()
    assert get_workbench is get_workbench
    assert set_default is set_default
    assert get_variable is get_variable