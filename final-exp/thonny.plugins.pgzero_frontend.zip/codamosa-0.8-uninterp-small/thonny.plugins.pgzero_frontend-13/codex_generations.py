

# Generated at 2022-06-26 07:23:15.836974
# Unit test for function update_environment
def test_update_environment():
    assert update_environment() == None


# Generated at 2022-06-26 07:23:16.860069
# Unit test for function toggle_variable
def test_toggle_variable():
    # Test case 0
    test_case_0()


# Generated at 2022-06-26 07:23:23.128916
# Unit test for function toggle_variable
def test_toggle_variable():
    var_0 = test_case_0()
    assert var_0 == None, "Return value was not as expected"

# Generated at 2022-06-26 07:23:24.301939
# Unit test for function load_plugin
def test_load_plugin():
    print("Nothing to test")

# Generated at 2022-06-26 07:23:26.647747
# Unit test for function load_plugin
def test_load_plugin():
    var_0 = load_plugin()

"""
All params in get_workbench()
"""

# Generated at 2022-06-26 07:23:31.310666
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default("run.pgzero_mode", False)
    get_workbench().add_command("toggle_pgzero_mode", "run", "Pygame Zero mode", toggle_variable, flag_name="run.pgzero_mode", group=40, checkable=True)
    update_environment()

# Generated at 2022-06-26 07:23:32.278901
# Unit test for function update_environment
def test_update_environment():
    env_0 = update_environment()
    assert True

# Generated at 2022-06-26 07:23:33.989516
# Unit test for function update_environment
def test_update_environment():
    assert update_environment() == None

# Generated at 2022-06-26 07:23:37.374889
# Unit test for function load_plugin
def test_load_plugin():
    # run before module code
    # verify that the plugin is properly loaded
    assert False


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 07:23:44.247521
# Unit test for function toggle_variable
def test_toggle_variable():
    import os, pytest
    from thonny.languages import tr
    from thonny.ui_utils import toggle_checkbox
    from thonny.running import get_runner, get_backend_python_interpreter, get_interpreter_for_subprocess
    from thonny.globals import get_workbench
    from thonny.test_utils import (
        captured_output,
        captured_program_output,
        parse_file_source,
    )
    from thonny.misc_utils import running_on_windows, running_on_mac_os
    from thonny.ui_utils import toggle_checkbox
    from thonny.plugins.thonnypgzero.pgzero_comm import PygameZeroRunner
    from thonny.plugins.thonnypgzero import thonny

# Generated at 2022-06-26 07:23:48.045593
# Unit test for function update_environment
def test_update_environment():
    var_0 = update_environment()


# Generated at 2022-06-26 07:23:51.294798
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    var_0 = get_workbench().get_variable(_OPTION_NAME)
    var_0.set(True)
    assert var_0._get() == True
    load_plugin()



# Generated at 2022-06-26 07:23:53.138984
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()



if __name__ == '__main__':
    load_plugin()

# Generated at 2022-06-26 07:24:02.225763
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().delete_all_commands()
    get_workbench().delete_all_variables()
    load_plugin()
    assert get_workbench().get_command("toggle_pgzero_mode")
    assert get_workbench().get_variable(_OPTION_NAME)
    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"


# Generated at 2022-06-26 07:24:07.377895
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_variable(_OPTION_NAME, False)
    load_plugin()
    assert wb.get_variable(_OPTION_NAME) == False

# Generated at 2022-06-26 07:24:10.584184
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = "auto"
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-26 07:24:14.194335
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = "auto"
    expected = os.environ["PGZERO_MODE"]
    actual = update_environment
    assert_equal(expected, actual)

# Generated at 2022-06-26 07:24:15.121388
# Unit test for function toggle_variable
def test_toggle_variable():
    return


# Generated at 2022-06-26 07:24:18.330910
# Unit test for function update_environment
def test_update_environment():
    var_0 = update_environment()


# Generated at 2022-06-26 07:24:20.248753
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = str("True")
    assert update_environment() == "auto"

# Generated at 2022-06-26 07:24:27.771077
# Unit test for function load_plugin
def test_load_plugin():
    btn_0_var = load_plugin()


# Generated at 2022-06-26 07:24:35.039826
# Unit test for function load_plugin
def test_load_plugin():
    # Set up a test version of the Tk application
    test_frame = Tk()

    # Set up a test version of the Workbench
    test_workbench = Workbench()

    # Set up a test version of the Workbench UI
    test_workbench_ui = WorkbenchUI(test_frame, test_workbench)

    # Call the load_plugin function to set up the plugin
    load_plugin()

    # Check to see if an option was set
    assert get_workbench().has_option(_OPTION_NAME)

    # Check to see if a command was added
    assert test_workbench.has_command(
        "toggle_pgzero_mode"
    ), "Thonny command to toggle Pygame Zero mode not added"

    # Check to see if the command added is a callback

# Generated at 2022-06-26 07:24:36.207425
# Unit test for function update_environment
def test_update_environment():
    assert update_environment()
    assert update_environment()

# Generated at 2022-06-26 07:24:38.316238
# Unit test for function toggle_variable
def test_toggle_variable():
    pass

# Generated at 2022-06-26 07:24:40.116743
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.plugins.pgzero_mode import load_plugin
    load_plugin()


# Generated at 2022-06-26 07:24:44.490811
# Unit test for function load_plugin
def test_load_plugin():
    #try out the plugin
    load_plugin()
    #assert the results
    assert 1 == 1

# Generated at 2022-06-26 07:24:45.526299
# Unit test for function update_environment
def test_update_environment():
    var_0 = update_environment()

# Generated at 2022-06-26 07:24:48.408890
# Unit test for function update_environment
def test_update_environment():
    update_environment()

if __name__ == "__main__":
    #test_case_0()
    test_update_environment()

# Generated at 2022-06-26 07:24:58.396697
# Unit test for function load_plugin
def test_load_plugin():
    from unittest import mock
    from thonny.workbench import Workbench

    with mock.patch("thonny.plugins.pgzero.Workbench.get_variable") as wb_get_variable, mock.patch("thonny.plugins.pgzero.get_workbench") as pgzero_get_workbench:
        # Setup mocked Workbench
        workbench = get_workbench()
        workbench.set_variable("variable", True)

        # Setup mocked thonny.plugins.pgzero.get_worbench function
        pgzero_get_workbench.return_value = workbench

        # Setup mocked thonny.plugins.pgzero.Workbench.get_variable function
        var = get_workbench().get_variable(_OPTION_NAME)
        var.set(False)

        load_plugin()

# Generated at 2022-06-26 07:24:59.284088
# Unit test for function update_environment
def test_update_environment():
    assert update_environment() == None


# Generated at 2022-06-26 07:25:15.787027
# Unit test for function toggle_variable
def test_toggle_variable():
    set_option_0 = get_workbench().set_option(_OPTION_NAME, False)
    var_0 = get_workbench().get_variable(_OPTION_NAME)
    assert (var_0.get()) == False
    get_workbench().set_option(_OPTION_NAME, True)
    assert (var_0.get()) == True


# Generated at 2022-06-26 07:25:18.732136
# Unit test for function update_environment
def test_update_environment():
    temp_0 = os.environ["PGZERO_MODE"]
    update_environment()
    var_0 = os.environ["PGZERO_MODE"]
    os.environ["PGZERO_MODE"] = temp_0
    assert var_0 is None


# Generated at 2022-06-26 07:25:30.849414
# Unit test for function toggle_variable
def test_toggle_variable():
    pass


#######################################################################
#
# The rest of this file is a testcase for the plugin.
#
# TODO: Ideally, this would be a separate file in a subfolder
#
#######################################################################

# import unittest
# from thonny import running
# from thonny.sysdep import get_python_version_info
#
# class PgZeroModeTest(unittest.TestCase):
#     def tearDown(self):
#         os.environ["PGZERO_MODE"] = "auto"
#
#     def test_simple_mode(self):
#         try:
#             get_workbench().set_default("View.PGZERO_MODE", False)
#             update_environment()
#             self.assertEqual(os.environ["PGZERO_MODE"], str(

# Generated at 2022-06-26 07:25:36.053547
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    func = get_workbench().add_command
    var_0 = func("toggle_pgzero_mode", "run",tr("Pygame Zero mode"),toggle_variable,flag_name=_OPTION_NAME,group=40,)
    var_1 = update_environment()


# Generated at 2022-06-26 07:25:40.619161
# Unit test for function update_environment
def test_update_environment():
    check_0 = update_environment()
    assert get_workbench().in_simple_mode() == True
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "auto"


# Generated at 2022-06-26 07:25:43.969193
# Unit test for function load_plugin
def test_load_plugin():
    wb_1 = get_workbench()
    wb_1.set_default(_OPTION_NAME, False)
    wb_1.add_command("toggle_pgzero_mode", "run", "Pygame Zero mode", toggle_variable, flag_name=_OPTION_NAME, group=40)
    update_environment()


# Generated at 2022-06-26 07:25:49.459862
# Unit test for function toggle_variable
def test_toggle_variable():
    var_1 = get_workbench().get_variable("run.pgzero_mode")
    var_2 = var_1.get()

# Generated at 2022-06-26 07:25:50.430232
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()


# Generated at 2022-06-26 07:25:52.746399
# Unit test for function load_plugin
def test_load_plugin():
    try:
        var_0 = load_plugin()
    except Exception as e:
        assert False, "Test execution failed:\n %s" % e


# Generated at 2022-06-26 07:25:55.370291
# Unit test for function load_plugin
def test_load_plugin():
    global load_plugin
    assert callable(load_plugin)

    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) is False



# Generated at 2022-06-26 07:26:20.064507
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-26 07:26:20.854328
# Unit test for function update_environment
def test_update_environment():
    var_0 = update_environment()

# Generated at 2022-06-26 07:26:27.152120
# Unit test for function toggle_variable
def test_toggle_variable():

    # Set up environment
    if not get_workbench().in_simple_mode():
        get_workbench().set_option(_OPTION_NAME, False)
    get_workbench().get_variable(_OPTION_NAME).set(False)

    # Check default value
    assert os.getenv("PGZERO_MODE") == "0"

    # Change value
    toggle_variable()

    # Check new value
    assert os.getenv("PGZERO_MODE") == "1"

    # Restore environment
    get_workbench().set_option(_OPTION_NAME, False)
    get_workbench().get_variable(_OPTION_NAME).set(False)
    update_environment()

# Generated at 2022-06-26 07:26:29.255361
# Unit test for function toggle_variable
def test_toggle_variable():
    pass
    # get_workbench().toggle_pgzero_mode
    # assert var_0 == get_workbench().toggle_pgzero_mode
    # assert False



# Generated at 2022-06-26 07:26:35.521130
# Unit test for function load_plugin
def test_load_plugin():
    # Initialize thonny's workbench
    get_workbench().set_default(_OPTION_NAME, False)
    # Test if the command toggle_pgzero_mode exists
    _ = get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    assert os.environ["PGZERO_MODE"] == "0"
    # Call load_plugin
    load_plugin()
    assert os.environ["PGZERO_MODE"] == "1"
    # Test if the command toggle_pgzero_mode exists

# Generated at 2022-06-26 07:26:43.848765
# Unit test for function load_plugin
def test_load_plugin():
    # Initialize globals
    get_workbench().in_simple_mode = lambda: bool(random.choice([True, False]))
    get_workbench().get_variable = lambda x: Variable
    get_workbench().set_default = lambda x, y: None
    get_workbench().add_command = lambda x, y, z, var, flag_name, group: None
    get_workbench().get_option = lambda x: bool(random.choice([True, False]))

    # Call function under test
    load_plugin()

# Generated at 2022-06-26 07:26:46.631483
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().get_variable(_OPTION_NAME).set(True)
    load_plugin()
    get_workbench().get_variable(_OPTION_NAME).set(False)
    load_plugin()

# Generated at 2022-06-26 07:26:48.274326
# Unit test for function toggle_variable
def test_toggle_variable():
    assert (toggle_variable() is None), "Function toggle_variable does not return None"


# Generated at 2022-06-26 07:26:49.195163
# Unit test for function update_environment
def test_update_environment():
    assert update_environment() is None


# Generated at 2022-06-26 07:26:50.504306
# Unit test for function toggle_variable
def test_toggle_variable():
    test_case_0()
    assert False


# Generated at 2022-06-26 07:27:42.691085
# Unit test for function update_environment
def test_update_environment():
    result = get_workbench().get_option(_OPTION_NAME)
    assert result == False

# Generated at 2022-06-26 07:27:43.898428
# Unit test for function update_environment
def test_update_environment():
    test_value = update_environment()
    assert test_value == None


# Generated at 2022-06-26 07:27:47.334774
# Unit test for function toggle_variable
def test_toggle_variable():
    result_0 = toggle_variable()
    # Should be: result_0 = False

    result_1 = toggle_variable()
    # Should be: result_1 = True

    result_2 = toggle_variable()
    # Should be: result_2 = False



# Generated at 2022-06-26 07:27:49.717897
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()


# Generated at 2022-06-26 07:27:57.669301
# Unit test for function load_plugin
def test_load_plugin():
    # Initializes a test environment
    # dbg = Debug()
    # dbg.register_stop_point('load_plugin', 'test_case_0')
    # dbg.start_debugger()
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()


# Generated at 2022-06-26 07:27:59.525018
# Unit test for function load_plugin
def test_load_plugin():
    try:
        load_plugin()
        assert True
    except Exception as e:
        assert False, e


# Generated at 2022-06-26 07:28:01.609255
# Unit test for function toggle_variable
def test_toggle_variable():
    # test empty input
    toggle_variable.toggle_variable()
    # test non-empty input
    toggle_variable.toggle_variable()



# Generated at 2022-06-26 07:28:03.666091
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench

    assert isinstance(get_workbench(), object)

# Generated at 2022-06-26 07:28:06.347981
# Unit test for function load_plugin
def test_load_plugin():
    try:
        if load_plugin() is not None:
            print("PASS")
    except Exception:
        print("FAIL")

if __name__ == "__main__":
    test_case_0()
    test_load_plugin()

# Generated at 2022-06-26 07:28:08.166713
# Unit test for function load_plugin
def test_load_plugin():
    """Test if Thonny window is loaded and if the plugin is able to load."""
    try:
        load_plugin()
    except:
        return False
    return True

# Generated at 2022-06-26 07:30:19.682447
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default("run.pgzero_mode", True)
    get_workbench().option("run.pgzero_mode").set(True)
    get_workbench().option("run.pgzero_mode").set(True)
    get_workbench().option("run.pgzero_mode").set(True)
    get_workbench().option("run.pgzero_mode").set(True)
    get_workbench().option("run.pgzero_mode").set(True)
    get_workbench().option("run.pgzero_mode").set(True)
    get_workbench().option("run.pgzero_mode").set(True)
    assert_front_end("run.pgzero_mode", True)


# Generated at 2022-06-26 07:30:21.288222
# Unit test for function load_plugin
def test_load_plugin():
    # Load plugin and check if it was successful
    load_plugin()

# Generated at 2022-06-26 07:30:22.071994
# Unit test for function load_plugin
def test_load_plugin():
    
    load_plugin()

# Generated at 2022-06-26 07:30:22.938479
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()


# Generated at 2022-06-26 07:30:24.312097
# Unit test for function update_environment
def test_update_environment():
    update_environment()

if __name__ == "__main__":
    unittest.main()

# Generated at 2022-06-26 07:30:25.046760
# Unit test for function load_plugin
def test_load_plugin():
    var_0 = load_plugin()



# Generated at 2022-06-26 07:30:29.270574
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = "auto"
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    os.environ["PGZERO_MODE"] = "True"
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-26 07:30:30.281073
# Unit test for function load_plugin
def test_load_plugin():
    test_case_0()
    test_load_plugin()

# Generated at 2022-06-26 07:30:31.533592
# Unit test for function toggle_variable
def test_toggle_variable():
    try:
        return_value = toggle_variable()
    except:
        return False
    return return_value


# Generated at 2022-06-26 07:30:35.966796
# Unit test for function update_environment
def test_update_environment():
    update_environment()
    get_workbench().get_option(_OPTION_NAME)
    var_1 = env
    var_2 = str(get_workbench().get_option(_OPTION_NAME))
    assert var_1 == var_2

