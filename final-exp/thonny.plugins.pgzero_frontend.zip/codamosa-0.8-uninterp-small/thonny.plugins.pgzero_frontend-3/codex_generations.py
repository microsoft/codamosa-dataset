

# Generated at 2022-06-26 07:23:24.870339
# Unit test for function load_plugin
def test_load_plugin():
    pass
    # get_workbench().set_default(_OPTION_NAME, False)
    # get_workbench().add_command(
    #     "toggle_pgzero_mode",
    #     "run",
    #     tr("Pygame Zero mode"),
    #     toggle_variable,
    #     flag_name=_OPTION_NAME,
    #     group=40,
    # )
    # update_environment()
    # assert True == True


# Generated at 2022-06-26 07:23:25.446509
# Unit test for function load_plugin
def test_load_plugin():
    var_2 = load_plugin()

# Generated at 2022-06-26 07:23:26.379294
# Unit test for function update_environment
def test_update_environment():
    assert update_environment()

# Generated at 2022-06-26 07:23:28.058279
# Unit test for function load_plugin
def test_load_plugin():
    assert not True


# Generated at 2022-06-26 07:23:29.312588
# Unit test for function update_environment
def test_update_environment():
    update_environment()


# Generated at 2022-06-26 07:23:31.395241
# Unit test for function load_plugin
def test_load_plugin():
    try:
        test_case_0()
    except:
        get_workbench().undo_command()
        raise


# Generated at 2022-06-26 07:23:32.761757
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench



# Generated at 2022-06-26 07:23:34.632803
# Unit test for function update_environment
def test_update_environment():
    var_0 = update_environment()


# Generated at 2022-06-26 07:23:39.043771
# Unit test for function toggle_variable
def test_toggle_variable():
    # TODO:
    var_0 = load_plugin()
    var_1 = get_workbench().get_variable(_OPTION_NAME)
    var_1.set(False)
    toggle_variable_0 = toggle_variable()
    assert var_1.get() == True



# Generated at 2022-06-26 07:23:39.915420
# Unit test for function update_environment
def test_update_environment():
    var_0 = update_environment()


# Generated at 2022-06-26 07:23:45.687623
# Unit test for function toggle_variable
def test_toggle_variable():
    var_0 = test_case_0()
# Unit test name
test_case_0.__name__ = "test_case_0"

# Generated at 2022-06-26 07:23:50.979550
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    load_plugin()
    assert wb.get_option(_OPTION_NAME) == False  # Failed


# Generated at 2022-06-26 07:23:52.054540
# Unit test for function toggle_variable
def test_toggle_variable():
    assert var_0 == True

# Generated at 2022-06-26 07:23:53.017423
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()


# Generated at 2022-06-26 07:24:00.132026
# Unit test for function load_plugin
def test_load_plugin():
    # Arrange
    workbench = get_workbench()
    workbench.set_default(_OPTION_NAME, False)
    workbench.add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    # Act
    update_environment()


# Generated at 2022-06-26 07:24:00.745792
# Unit test for function update_environment
def test_update_environment():
    update_environment()

# Generated at 2022-06-26 07:24:10.202033
# Unit test for function toggle_variable
def test_toggle_variable():
    variable = BooleanVar()
    variable.set(False)
    workbench = get_workbench()
    workbench.set_variable(_OPTION_NAME, variable)
    test_case_0()
    variable.set(True)
    test_case_0()

# Generated at 2022-06-26 07:24:21.403171
# Unit test for function toggle_variable
def test_toggle_variable():
    var_0 = get_workbench().get_variable(_OPTION_NAME)
    var_0.set(False)
    assert (get_workbench().in_simple_mode() == False), "get_workbench().in_simple_mode() == False"
    var_1 = toggle_variable()
    assert (get_workbench().get_option(_OPTION_NAME) == True), "get_workbench().get_option(_OPTION_NAME) == True"
    os.environ["PGZERO_MODE"] = "auto"
    assert (os.environ["PGZERO_MODE"] == "auto"), "os.environ[PGZERO_MODE] == auto"
    var_2 = get_workbench().in_simple_mode()
    assert (var_2 == False), "var_2 == False"
    var

# Generated at 2022-06-26 07:24:26.316004
# Unit test for function update_environment
def test_update_environment():
    # Test get_workbench().in_simple_mode() returning False
    # Test os.environ["PGZERO_MODE"] = str(get_workbench().get_option(_OPTION_NAME))
    # Test Exception
    os.environ["PGZERO_MODE"] = "auto"
    update_environment()

# Generated at 2022-06-26 07:24:31.721532
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(
        "preferences.general.language", "en_US"
    )  # Override OS language
    load_plugin()

    assert "toggle_pgzero_mode" in wb._application.get_menu("run")
    assert wb.get_option("run.pgzero_mode") == False
    assert os.environ["PGZERO_MODE"] == str(False)

# Generated at 2022-06-26 07:24:39.397511
# Unit test for function update_environment
def test_update_environment():
    update_environment()
    update_environment()
    update_environment()



# Generated at 2022-06-26 07:24:40.296234
# Unit test for function update_environment
def test_update_environment():
    var_0 = update_environment()

# Generated at 2022-06-26 07:24:43.353929
# Unit test for function update_environment
def test_update_environment():
    update_environment()


# Generated at 2022-06-26 07:24:44.360553
# Unit test for function update_environment
def test_update_environment():
    update_environment()


# Generated at 2022-06-26 07:24:54.963271
# Unit test for function update_environment
def test_update_environment():
    with patch.object(get_workbench(), "in_simple_mode", return_value=True):
        with patch.dict(os.environ, clear=True):
            update_environment()
            assert os.environ["PGZERO_MODE"] == "auto"
    with patch.object(get_workbench(), "get_option", return_value=False):
        with patch.object(get_workbench(), "in_simple_mode", return_value=False):
            with patch.dict(os.environ, clear=True):
                update_environment()
                assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-26 07:24:55.880777
# Unit test for function update_environment
def test_update_environment():
    update_environment()


# Generated at 2022-06-26 07:24:58.708487
# Unit test for function load_plugin
def test_load_plugin():
    try:
        assert __name__ == "__main__"
        x = load_plugin()
    except AssertionError as e:
        print(e)



# Generated at 2022-06-26 07:25:01.062928
# Unit test for function toggle_variable
def test_toggle_variable():
  
  def get_input():
    return [toggle_variable()]

  def expected_output():
    return [None]

  assert expected_output() == get_input()

# Generated at 2022-06-26 07:25:02.599434
# Unit test for function update_environment
def test_update_environment():
    """
    Unit test for function update_environment
    """
    var_0 = update_environment()


# Generated at 2022-06-26 07:25:04.094787
# Unit test for function toggle_variable
def test_toggle_variable():
    assert isinstance(var_0, str)
    assert var_0 == "auto"


# Generated at 2022-06-26 07:25:16.637981
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)


# Generated at 2022-06-26 07:25:21.418381
# Unit test for function load_plugin
def test_load_plugin():
    wb_0 = get_workbench()
    assert wb_0.get_option(_OPTION_NAME) == False
    wb_0.set_option(_OPTION_NAME, False)
    load_plugin()
    assert wb_0.get_option(_OPTION_NAME) == False

# Generated at 2022-06-26 07:25:23.571192
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()


# Generated at 2022-06-26 07:25:25.772921
# Unit test for function load_plugin
def test_load_plugin():
    test_1 = load_plugin()
    # assert test_1

# Generated at 2022-06-26 07:25:26.821478
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()


# Generated at 2022-06-26 07:25:28.327138
# Unit test for function load_plugin
def test_load_plugin():
    test_load_plugin = load_plugin()


# Generated at 2022-06-26 07:25:28.920330
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()

# Generated at 2022-06-26 07:25:32.125625
# Unit test for function load_plugin
def test_load_plugin():
    # clear the tk root window
    for widget in root.winfo_children():
        widget.destroy()
    # TODO: call the function to be tested
    load_plugin()
    # TODO: assert
    assert "TODO" != None


# Generated at 2022-06-26 07:25:33.035203
# Unit test for function update_environment
def test_update_environment():
    var_0 = update_environment()

# Generated at 2022-06-26 07:25:33.529890
# Unit test for function update_environment
def test_update_environment():
    update_environment()

# Generated at 2022-06-26 07:25:58.867425
# Unit test for function toggle_variable
def test_toggle_variable():

    # Testing default case
    var_0 = toggle_variable()
    assert var_0 is None



# Generated at 2022-06-26 07:26:02.092933
# Unit test for function load_plugin
def test_load_plugin():
    # load_plugin()
    # b = get_workbench()
    # assert b._defaults[_OPTION_NAME] == False
    # assert b.default(_OPTION_NAME) == False
    return


# Generated at 2022-06-26 07:26:03.267190
# Unit test for function update_environment
def test_update_environment():
    assert update_environment()



# Generated at 2022-06-26 07:26:04.196241
# Unit test for function update_environment
def test_update_environment():
    assert True == update_environment()


# Generated at 2022-06-26 07:26:05.200229
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()


# Generated at 2022-06-26 07:26:07.440923
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = "auto"
    assert os.environ["PGZERO_MODE"] == "auto"


# Generated at 2022-06-26 07:26:08.086907
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()

# Generated at 2022-06-26 07:26:09.013535
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()


# Generated at 2022-06-26 07:26:12.652413
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().open_command_view()
    test.equal(len(get_workbench().get_menu("run")), 1)
    test.equal(len(get_workbench().get_toolbar("run")), 2)
    test.equal(get_workbench().get_default(_OPTION_NAME), False)


if __name__ == "__main__":
    test.test_main()

# Generated at 2022-06-26 07:26:14.023062
# Unit test for function update_environment
def test_update_environment():
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"


# Generated at 2022-06-26 07:27:06.426070
# Unit test for function toggle_variable
def test_toggle_variable():
    set_data_path("/home/summerson/thonny/Thonny/plugins/pgzero_mode")
    var_0 = None
    test_case_0()
    return

run_tests_if_main()

# Generated at 2022-06-26 07:27:08.516643
# Unit test for function load_plugin
def test_load_plugin():
    test_case_0()



# Generated at 2022-06-26 07:27:13.061276
# Unit test for function toggle_variable
def test_toggle_variable():
    assert var_0 is not None

# Generated at 2022-06-26 07:27:14.539545
# Unit test for function update_environment
def test_update_environment():
    update_environment()


# Generated at 2022-06-26 07:27:16.508171
# Unit test for function update_environment
def test_update_environment():
    assert update_environment("I am a test") == "I am a test"
    



# Generated at 2022-06-26 07:27:17.404532
# Unit test for function update_environment
def test_update_environment():
    get_workbench()
    update_environment()

# Generated at 2022-06-26 07:27:19.169532
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()


# Generated at 2022-06-26 07:27:22.276917
# Unit test for function update_environment
def test_update_environment():
    result = update_environment()
    assert result == None, "function 'update_environment' returned: %s" % result
    
# Unit tests for function toggle_variable

# Generated at 2022-06-26 07:27:23.978998
# Unit test for function update_environment
def test_update_environment():
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-26 07:27:25.243064
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    assert True == load_plugin()

# Generated at 2022-06-26 07:29:22.613991
# Unit test for function load_plugin
def test_load_plugin():
    # create a new plugin manager and install this plugin
    pm = get_workbench().get_plugin_manager()
    pm.install_plugin(get_plugin_path())
    pm.activate_plugin("pgzerotools")
    # now try the test case
    test_case_0()

# Generated at 2022-06-26 07:29:23.117342
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()

# Generated at 2022-06-26 07:29:24.085883
# Unit test for function update_environment
def test_update_environment():
    assert update_environment() == None


# Generated at 2022-06-26 07:29:25.726367
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default = MagicMock()
    wb.add_command = MagicMock()
    load_plugin()
    assert wb.set_default.call_count == 1
    assert wb.add_command.call_count == 1


# Generated at 2022-06-26 07:29:26.509468
# Unit test for function update_environment
def test_update_environment():
    env_0 = update_environment()


# Generated at 2022-06-26 07:29:28.005344
# Unit test for function load_plugin
def test_load_plugin():
    """
    Unit test for function load_plugin()
    """
    #TODO: add unit tests
    assert False, "Not implemented"

# Generated at 2022-06-26 07:29:34.359488
# Unit test for function load_plugin
def test_load_plugin():
    # Get the workbench
    workbench = get_workbench()
    # Set the default option for the plugin
    workbench.set_default(_OPTION_NAME, False)
    # Add the command
    workbench.add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40
    )
    # Update environment
    update_environment()


# Generated at 2022-06-26 07:29:36.288127
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_option("run.pgzero_mode", True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"


# Generated at 2022-06-26 07:29:38.496812
# Unit test for function update_environment
def test_update_environment():
    assert "PGZERO_MODE" == "auto"


# Generated at 2022-06-26 07:29:42.143476
# Unit test for function toggle_variable
def test_toggle_variable():
    # Test the case where the get_workbench().get_variable(_OPTION_NAME) is correct
    assert toggle_variable() == True
    # Test the case where the get_workbench().get_variable(_OPTION_NAME) is incorrect
    assert toggle_variable() == False


