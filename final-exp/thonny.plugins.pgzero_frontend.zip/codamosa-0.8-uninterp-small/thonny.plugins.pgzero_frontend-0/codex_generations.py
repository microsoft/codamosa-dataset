

# Generated at 2022-06-26 07:23:14.960615
# Unit test for function load_plugin
def test_load_plugin():

    def side_effect_0(self_0, location_0):
        return "pgzero.ini"
    get_workbench().get_option = MagicMock(side_effect=side_effect_0)

    def side_effect_1(self_0, name_0):
        return None
    get_workbench().get_variable = MagicMock(side_effect=side_effect_1)

    def side_effect_2(self_0, name_0, value_0):
        pass
    get_workbench().set_default = MagicMock(side_effect=side_effect_2)


# Generated at 2022-06-26 07:23:15.561683
# Unit test for function load_plugin
def test_load_plugin():
    pass

# Generated at 2022-06-26 07:23:21.987589
# Unit test for function load_plugin
def test_load_plugin():
    case_0_input = None
    case_0_expected_output = None
    with patch("builtins.get_workbench", return_value=MockWorkbench()) as case_0_patch:
        var_0 = load_plugin()
        var_1 = None
        var_1 = var_0
        case_0_actual_output = (var_0, var_1)
        case_0_expected_output = (None, None)
        assert (
            case_0_actual_output == case_0_expected_output
        ), "load_plugin() did not return the correct output."

# Test for function toggle_variable

# Generated at 2022-06-26 07:23:23.090983
# Unit test for function update_environment
def test_update_environment():
    test_case_0()
    update_environment()

# Generated at 2022-06-26 07:23:24.448104
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    test_case_0()



# Generated at 2022-06-26 07:23:25.446246
# Unit test for function update_environment
def test_update_environment():
    test_case_0()


# Generated at 2022-06-26 07:23:28.556598
# Unit test for function update_environment
def test_update_environment():
    """
    Unit test for function update_environment
    """
    var_0 = load_plugin()
    var_1 = update_environment()


# Generated at 2022-06-26 07:23:37.333823
# Unit test for function update_environment
def test_update_environment():
    get_workbench().in_simple_mode = sentinel
    get_workbench().get_option = sentinel
    get_workbench().in_simple_mode()
    os.environ["PGZERO_MODE"] = "auto"
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().get_option()
    get_workbench().get_option().get()
    os.environ["PGZERO_MODE"] = str(get_workbench().get_option().get())
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-26 07:23:38.770187
# Unit test for function toggle_variable
def test_toggle_variable():
    var_0 = toggle_variable()


# Generated at 2022-06-26 07:23:41.339108
# Unit test for function load_plugin
def test_load_plugin():
    # Load plugin and assert it is set up as expected
    load_plugin()
    assert get_workbench().in_simple_mode() == False
    assert get_workbench().get_option(_OPTION_NAME) == False



# Generated at 2022-06-26 07:23:45.772899
# Unit test for function toggle_variable
def test_toggle_variable():
    result_0 = toggle_variable()
    assert result_0 is False


# Generated at 2022-06-26 07:23:48.620018
# Unit test for function load_plugin
def test_load_plugin():
    """Ensures that load_plugin is a function"""
    load_plugin()
    assert isinstance(load_plugin, collections.Callable), "load_plugin is not an instance of the type Callable"

# Generated at 2022-06-26 07:23:49.471768
# Unit test for function load_plugin
def test_load_plugin():
    assert load_plugin() == None

# Generated at 2022-06-26 07:24:00.876652
# Unit test for function update_environment
def test_update_environment():

    # Creating mock objects
    temp_get_workbench = 'update_environment:get_workbench'
    temp_in_simple_mode = 'update_environment:in_simple_mode'
    temp_get_option = 'update_environment:get_option'

    # Creating mocks
    mock_get_workbench = Mock(return_value=temp_get_workbench)
    mock_in_simple_mode = Mock(return_value=temp_in_simple_mode)
    mock_get_option = Mock(return_value=temp_get_option)
    mock_os_environ_key_0 = Mock(return_value=temp_get_workbench)
    mock_os_environ_key_1 = Mock(return_value=temp_in_simple_mode)
    mock_os_environ_key_2

# Generated at 2022-06-26 07:24:07.689667
# Unit test for function load_plugin
def test_load_plugin():
    # Resetting dictionary values
    # Re-initializing function global variables
    global _OPTION_NAME
    _OPTION_NAME = "run.pgzero_mode"

    # Calling function load_plugin
    load_plugin()



# Generated at 2022-06-26 07:24:08.768592
# Unit test for function update_environment
def test_update_environment():
    assert update_environment() == None

# Generated at 2022-06-26 07:24:10.337930
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()


# Generated at 2022-06-26 07:24:21.533396
# Unit test for function load_plugin
def test_load_plugin():
    bw = get_workbench()

    # Get default values
    run_default_pgzero_mode = bw.get_default(_OPTION_NAME)

    # Plugin is not loaded
    assert bw.get_commands().get("toggle_pgzero_mode") is None

    # Load plugin
    load_plugin()

    # Ensure unit test is using default variables
    bw.restore_defaults()

    # Plugin is loaded
    assert bw.get_commands().get("toggle_pgzero_mode") is not None

    assert bw.get_variable(_OPTION_NAME) is not None

    assert bw.get_option(_OPTION_NAME) == run_default_pgzero_mode

    assert os.getenv("PGZERO_MODE") == str(run_default_pgzero_mode)

    #

# Generated at 2022-06-26 07:24:22.199562
# Unit test for function toggle_variable
def test_toggle_variable():
    assert toggle_variable(), "test_case_0 failed"

# Generated at 2022-06-26 07:24:25.574983
# Unit test for function update_environment
def test_update_environment():
    # Update environment in simple mode
    get_workbench().set_simple_mode()
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    
    

# Generated at 2022-06-26 07:24:39.344547
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.languages import tr
    from thonny.misc_utils import running_on_linux, running_on_windows
    from thonny.misc_utils import running_on_mac_os
    # Calls function load_plugin
    load_plugin()
    if running_on_mac_os():
        assert os.environ["PGZERO_MODE"] == "0"
    elif running_on_windows():
        assert os.environ["PGZERO_MODE"] == "0"
    elif running_on_linux():
        assert os.environ["PGZERO_MODE"] == "0"
    # Checks that function load_plugin returns None
    assert load_plugin() is None


# Generated at 2022-06-26 07:24:40.569181
# Unit test for function toggle_variable
def test_toggle_variable():
    assert var_0 == "auto"

#test_case_1

# Generated at 2022-06-26 07:24:49.719848
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == False, "Error"
    assert get_workbench().add_command("toggle_pgzero_mode", "run", tr("Pygame Zero mode"), toggle_variable, flag_name=_OPTION_NAME, group=40) == None, "Error"
    assert update_environment() == None, "Error"

# Run this function on every test to be sure that the env is always in the same state

# Generated at 2022-06-26 07:24:50.714454
# Unit test for function update_environment
def test_update_environment():
    var_0 = update_environment()

# Generated at 2022-06-26 07:24:55.793274
# Unit test for function update_environment
def test_update_environment():
    import subprocess

    # test function doesn't crash
    update_environment()

    # check defaults to False
    assert 'PGZERO_MODE=False' in subprocess.check_output(["env"])

    # check it can be changed
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert 'PGZERO_MODE=True' in subprocess.check_output(["env"])



# Generated at 2022-06-26 07:24:56.973147
# Unit test for function update_environment
def test_update_environment():
    # Call update_environment
    var_0 = update_environment()


# Generated at 2022-06-26 07:24:59.662156
# Unit test for function load_plugin
def test_load_plugin():
    from unittest import mock

    with mock.patch.object(get_workbench(), "set_default") as func_mock:
        load_plugin()
        func_mock.assert_called()



# Generated at 2022-06-26 07:25:00.228628
# Unit test for function update_environment
def test_update_environment():
    pass

# Generated at 2022-06-26 07:25:02.563483
# Unit test for function toggle_variable
def test_toggle_variable():
    assert (toggle_variable() == None)

if __name__ == "__main__" :
    assert (toggle_variable() == None)
    assert (update_environment() == None)

# Generated at 2022-06-26 07:25:04.673625
# Unit test for function toggle_variable
def test_toggle_variable():
    # Test for function toggle_variable
    # Test for function toggle_variable
    # Test for function toggle_variable
    # Test for function toggle_variable
    assert 1 == 0

# Generated at 2022-06-26 07:25:16.839493
# Unit test for function update_environment
def test_update_environment():
    pass

# Generated at 2022-06-26 07:25:19.493355
# Unit test for function toggle_variable
def test_toggle_variable():
    # GIVEN
    # WHEN
    var_0 = toggle_variable()
    # THEN
    assert var_0 is None


# Generated at 2022-06-26 07:25:20.437290
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()


# Generated at 2022-06-26 07:25:21.514364
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()


# Generated at 2022-06-26 07:25:23.684254
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()


# Generated at 2022-06-26 07:25:25.448168
# Unit test for function toggle_variable
def test_toggle_variable():
    pass # test case 0


# Generated at 2022-06-26 07:25:25.808415
# Unit test for function load_plugin
def test_load_plugin():
    pass

# Generated at 2022-06-26 07:25:26.868706
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()


# Generated at 2022-06-26 07:25:27.950816
# Unit test for function load_plugin
def test_load_plugin():
    assert load_plugin() == None


# Generated at 2022-06-26 07:25:28.561378
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()

# Generated at 2022-06-26 07:25:59.166372
# Unit test for function update_environment
def test_update_environment():
    # Test for simple mode
    get_workbench().in_simple_mode = lambda: True
    update_environment()
    assert os.environ.get("PGZERO_MODE") == "auto"
    # Test for advanced mode
    get_workbench().in_simple_mode = lambda: False
    get_workbench().get_option = lambda s: True
    update_environment()
    assert os.environ.get("PGZERO_MODE") == "True"
    # Test for advanced mode
    get_workbench().in_simple_mode = lambda: False
    get_workbench().get_option = lambda s: False
    update_environment()
    assert os.environ.get("PGZERO_MODE") == "False"
    # Test for advanced mode
    get_workbench().in_simple_mode = lambda: False

# Generated at 2022-06-26 07:26:00.128523
# Unit test for function load_plugin
def test_load_plugin():
    # This is a dummy
    pass;

# Generated at 2022-06-26 07:26:01.503187
# Unit test for function update_environment
def test_update_environment():
    actual = update_environment()
    assert (0 == 0)

# Generated at 2022-06-26 07:26:03.025285
# Unit test for function load_plugin
def test_load_plugin():
    # Ensure the function will run without errors
    load_plugin()


# Generated at 2022-06-26 07:26:09.086133
# Unit test for function update_environment
def test_update_environment():
    # Check if it raises the correct exception
    try:
        update_environment()
    except:
        import traceback
        traceback.print_exc()
        assert False, "Exception raised."
    # Check if the function returns the correct type
    if not isinstance(update_environment(), None):
        print("Function update_environment() didn't return type None, instead it returned type: " + str(type(update_environment())))
        assert False
    # Check if the function returns the correct value
    # N/A
    return

# Generated at 2022-06-26 07:26:09.904301
# Unit test for function update_environment
def test_update_environment():
    test_update_environment()

# Generated at 2022-06-26 07:26:14.222782
# Unit test for function load_plugin
def test_load_plugin():
    try:
        wb = get_workbench()
    except:
        wb = None
    if wb == None:
        wb = Workbench()
    load_plugin(wb)

    test_case_0()

# Generated at 2022-06-26 07:26:15.020792
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()


# Generated at 2022-06-26 07:26:16.106691
# Unit test for function update_environment
def test_update_environment():
    var_0 = update_environment()


# Generated at 2022-06-26 07:26:17.230210
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()


# Generated at 2022-06-26 07:27:13.190665
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()


# Generated at 2022-06-26 07:27:14.595425
# Unit test for function load_plugin
def test_load_plugin():
    assert load_plugin() == None


# Generated at 2022-06-26 07:27:15.833792
# Unit test for function load_plugin
def test_load_plugin():
    assert load_plugin()


# Generated at 2022-06-26 07:27:22.943600
# Unit test for function update_environment
def test_update_environment():
    # Load the plugin
    load_plugin()
    # Update the environment
    update_environment()
    # Test the variable set in the environment
    assert os.environ["PGZERO_MODE"] == "True"
    # Set the variable to False
    get_workbench().set_option(_OPTION_NAME, False)
    # Update the environment again
    update_environment()
    # Test the variable set in the environment
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-26 07:27:23.846030
# Unit test for function load_plugin
def test_load_plugin():
    assert not load_plugin()

# Generated at 2022-06-26 07:27:24.835488
# Unit test for function toggle_variable
def test_toggle_variable():
    assert test_case_0() <= 5

# Generated at 2022-06-26 07:27:25.694380
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()


# Generated at 2022-06-26 07:27:26.416558
# Unit test for function update_environment
def test_update_environment():

    assert update_environment() == None

# Generated at 2022-06-26 07:27:31.663052
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench, get_shell

    load_plugin()
    test_case_0()

##print(f"TEST: {__name__}")

##load_plugin()
#test_case_0()

# Generated at 2022-06-26 07:27:35.324860
# Unit test for function load_plugin
def test_load_plugin():
    root_0 = load_plugin()


# Generated at 2022-06-26 07:29:34.883728
# Unit test for function load_plugin
def test_load_plugin():
    # if os.path.isfile(_OPTION_NAME):
    #    os.remove(_OPTION_NAME)
    load_plugin()


# Generated at 2022-06-26 07:29:40.997474
# Unit test for function load_plugin
def test_load_plugin():
    try: 
        from thonny.plugins.run_pgzero_mode import load_plugin
        from thonny.plugins.run_pgzero_mode import update_environment
        from thonny.plugins.run_pgzero_mode import toggle_variable
    except ImportError: 
        print("Error: thonny.plugins.run_pgzero_mode module not found!")
        return False
    load_plugin()
    return True


# Generated at 2022-06-26 07:29:41.966298
# Unit test for function load_plugin
def test_load_plugin():
    var_0 = load_plugin()

# Generated at 2022-06-26 07:29:42.763466
# Unit test for function toggle_variable
def test_toggle_variable():
    var_0 = toggle_variable()


# Generated at 2022-06-26 07:29:49.853779
# Unit test for function toggle_variable
def test_toggle_variable():
    # Test case 0
    # Function toggle_variable is used in the plugin's load function, we have to simulate the loading of the plugin.
    # To test its functionality we have to simulate the loading of the plugin and simulate its command either being
    # configured to be on or off. Function toggle_variable will set the variable to the opposite of its current state
    # and update the environment variable if it is in normal mode
    test_load = type("TestLoad", (object,), {"in_simple_mode": lambda: False})()

# Generated at 2022-06-26 07:29:51.353821
# Unit test for function toggle_variable
def test_toggle_variable():
    # Delete the following lines and replace with your own code
    raise NotImplementedError()

# Generated at 2022-06-26 07:29:53.117417
# Unit test for function toggle_variable
def test_toggle_variable():
    assert toggle_variable() == None


# Generated at 2022-06-26 07:30:01.338326
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, 0)
    wb.set_default(_OPTION_NAME, 1)
    wb.set_default(_OPTION_NAME, False)
    wb.set_default(_OPTION_NAME, True)
    wb.set_default(_OPTION_NAME, '2')
    wb.set_default(_OPTION_NAME, '3')
    wb.set_default(_OPTION_NAME, None)
    wb.set_default(_OPTION_NAME, None)
    wb.set_default(_OPTION_NAME, '')
    wb.set_default(_OPTION_NAME, '')

# Generated at 2022-06-26 07:30:02.207370
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()


# Generated at 2022-06-26 07:30:05.861354
# Unit test for function load_plugin
def test_load_plugin():
    # Tested function
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()