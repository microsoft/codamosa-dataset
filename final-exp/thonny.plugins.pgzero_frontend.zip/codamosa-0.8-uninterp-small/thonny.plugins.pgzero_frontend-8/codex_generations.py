

# Generated at 2022-06-26 07:23:05.414334
# Unit test for function load_plugin
def test_load_plugin():
    assert True


# Generated at 2022-06-26 07:23:06.610309
# Unit test for function update_environment
def test_update_environment():
    assert get_workbench().in_simple_mode()


# End unit test
# End unit test

# Generated at 2022-06-26 07:23:11.441441
# Unit test for function load_plugin
def test_load_plugin():
    # Ensure get_workbench().set_default() is called for function load_plugin
    assert_raises(
        NotImplementedError,
        load_plugin,
    )

    # Ensure get_workbench().add_command() is called for function load_plugin
    assert_raises(
        NotImplementedError,
        load_plugin,
    )

# Generated at 2022-06-26 07:23:12.179564
# Unit test for function update_environment
def test_update_environment():
    pass

# Generated at 2022-06-26 07:23:13.385631
# Unit test for function toggle_variable
def test_toggle_variable():
    # toggle_variable()
    test_var = env.test_var
    assert test_var == 1

# Generated at 2022-06-26 07:23:15.835496
# Unit test for function toggle_variable
def test_toggle_variable():

    toggle_variable()


# Generated at 2022-06-26 07:23:16.585392
# Unit test for function update_environment
def test_update_environment():
    var_0 = update_environment()


# Generated at 2022-06-26 07:23:17.754524
# Unit test for function load_plugin
def test_load_plugin():
    assumption_0 = load_plugin() == None
    assert assumption_0


# Generated at 2022-06-26 07:23:25.298909
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    wb.set_simple_mode(True)
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    wb.set_simple_mode(False)
    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    wb.set_simple_mode(False)
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"



# Generated at 2022-06-26 07:23:26.737553
# Unit test for function load_plugin
def test_load_plugin():
    var_0 = load_plugin()

# Generated at 2022-06-26 07:23:39.622386
# Unit test for function load_plugin
def test_load_plugin():
    # a = get_workbench()
    # b = get_workbench().get_variable(_OPTION_NAME)
    # c = b.get()
    # d = b.set(not c)
    # e = update_environment

    # var_1 = a (get_workbench)
    # var_2 = b (get_workbench().get_variable(_OPTION_NAME))
    # var_3 = c (var_2.get())
    # var_4 = d (var_2.set(not var_3))
    # var_5 = e (update_environment)
    # var_6 = _OPTION_NAME ('run.pgzero_mode')

    pass

# Generated at 2022-06-26 07:23:44.592297
# Unit test for function toggle_variable
def test_toggle_variable():
    # Assert error when the method is call with invalid number of arguments
    with pytest.raises(TypeError):
        toggle_variable(1)

    # Assert error when the method is call with invalid number of arguments
    try:
        with pytest.raises(TypeError):
            toggle_variable(1)
    except Exception:
        pass

    # Assert error when the method is call with invalid number of arguments
    try:
        with pytest.raises(TypeError):
            toggle_variable(1)
    except Exception:
        pass


# Generated at 2022-06-26 07:23:45.987043
# Unit test for function toggle_variable
def test_toggle_variable():
    # Test if the function throws an exception
    assert toggle_variable() == None



# Generated at 2022-06-26 07:23:48.453665
# Unit test for function load_plugin

# Generated at 2022-06-26 07:23:49.314205
# Unit test for function update_environment
def test_update_environment():
    pass


# Generated at 2022-06-26 07:24:00.876232
# Unit test for function load_plugin
def test_load_plugin():
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert load_plugin() is None
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert load_plugin() is None
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert load_plugin() is None
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert load_plugin() is None
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert load_plugin() is None
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert load_plugin() is None
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert load_plugin() is None
    assert get

# Generated at 2022-06-26 07:24:07.021672
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()
    # TODO: check that everything is OK


# Generated at 2022-06-26 07:24:11.885737
# Unit test for function update_environment
def test_update_environment():
    try:
        os.environ["PGZERO_MODE"]
    except KeyError:
        raise
    get_workbench().set_default("run.pgzero_mode", False)
    test_case_0()
    update_environment()

# Load plugin for user
load_plugin()

# Run unit test for development
test_update_environment()

# Generated at 2022-06-26 07:24:13.113090
# Unit test for function toggle_variable
def test_toggle_variable():
    test_toggle_variable_0()



# Generated at 2022-06-26 07:24:21.118127
# Unit test for function load_plugin
def test_load_plugin():
    # Set up mock object
    wb_mock = Mock()

    # Call function under test
    load_plugin()

    # Check for expected calls
    wb_mock.set_default.assert_called_once_with(
        _OPTION_NAME, False
    )
    wb_mock.add_command.assert_called_once_with(
        "toggle_pgzero_mode", "run", tr("Pygame Zero mode"),
        toggle_variable, flag_name=_OPTION_NAME, group=40
    )

# Generated at 2022-06-26 07:24:28.611568
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert get_workbench().get_command("toggle_pgzero_mode") != None


# Generated at 2022-06-26 07:24:29.659104
# Unit test for function update_environment
def test_update_environment():
    assert update_environment() is None

if __name__ == '__main__':
    import unittest
    unittest.main()

# Generated at 2022-06-26 07:24:31.202258
# Unit test for function update_environment
def test_update_environment():
    # Replace 'pass' with your test code
    pass



# Generated at 2022-06-26 07:24:32.036382
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()

# Generated at 2022-06-26 07:24:32.512331
# Unit test for function update_environment
def test_update_environment():
    update_environment()

# Generated at 2022-06-26 07:24:36.546402
# Unit test for function toggle_variable
def test_toggle_variable():
    # test_case_0
    get_workbench().set_default(_OPTION_NAME, False)
    assert toggle_variable() == None
    # test_case_1
    get_workbench().set_default(_OPTION_NAME, True)
    assert toggle_variable() == None



# Generated at 2022-06-26 07:24:39.354713
# Unit test for function toggle_variable
def test_toggle_variable():
    assert toggle_variable( ) == None,__name__ + ": line 17"


# Generated at 2022-06-26 07:24:42.462486
# Unit test for function update_environment
def test_update_environment():
    get_workbench().add_variable(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False", "Function update_environment failed"

# Generated at 2022-06-26 07:24:46.218360
# Unit test for function update_environment
def test_update_environment():
    assert update_environment() == None

#def test_load_plugin():
 #   assert load_plugin() == None

#def test_toggle_variable():
 #   assert toggle_variable() == None

# Generated at 2022-06-26 07:24:48.547552
# Unit test for function update_environment
def test_update_environment():
    expected = None
    var_0 = update_environment()
    assert expected == var_0


# Generated at 2022-06-26 07:25:01.614185
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()

# Generated at 2022-06-26 07:25:06.731301
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().get_option(_OPTION_NAME)
    get_workbench().add_command()
    get_workbench().set_default()
    test_case_0()
    # Assert
    assert os.environ["PGZERO_MODE"] == "auto"
    assert get_workbench().get_variable(_OPTION_NAME)
    assert get_workbench().in_simple_mode()
    # load_plugin()
    # assert get_workbench().get_option(_OPTION_NAME)



# Generated at 2022-06-26 07:25:09.233728
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert isinstance(get_workbench(), object)

if __name__ == "__main__":
    print(test_case_0())
    print(test_load_plugin())

# Generated at 2022-06-26 07:25:10.328749
# Unit test for function update_environment
def test_update_environment():
    var_0 = update_environment()


# Generated at 2022-06-26 07:25:11.011528
# Unit test for function update_environment
def test_update_environment():
    pass

# Generated at 2022-06-26 07:25:13.129841
# Unit test for function update_environment
def test_update_environment():
    var_0 = get_workbench().in_simple_mode()
    func_0 = update_environment()


# Generated at 2022-06-26 07:25:19.246272
# Unit test for function update_environment
def test_update_environment():
    # os.environ["PGZERO_MODE"] = "auto"
    # exp_0 = "auto"
    # act_0 = str(update_environment())
    # assert act_0 == exp_0

    # os.environ["PGZERO_MODE"] = str(get_workbench().get_option(_OPTION_NAME))
    # exp_0 = str(get_workbench().get_option(_OPTION_NAME))
    # act_0 = str(update_environment())
    # assert act_0 == exp_0   

    pass

# Generated at 2022-06-26 07:25:24.775899
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, True)
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert get_workbench().in_simple_mode() == True
test_load_plugin()


# Generated at 2022-06-26 07:25:26.308180
# Unit test for function toggle_variable
def test_toggle_variable():
    """Unit test for function toggle_variable"""
    test_case_0()

# Generated at 2022-06-26 07:25:27.433136
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert True

# Generated at 2022-06-26 07:25:52.043794
# Unit test for function load_plugin
def test_load_plugin():
    # test case 0
    assert load_plugin() is None


# Generated at 2022-06-26 07:25:55.370434
# Unit test for function update_environment
def test_update_environment():
    get_workbench().in_simple_mode = lambda : False
    get_workbench().get_option = lambda x: True
    os.environ["PGZERO_MODE"] = "auto"
    assert update_environment() == None


# Generated at 2022-06-26 07:26:00.437005
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    var_0 = get_workbench().get_variable(_OPTION_NAME)
    var_1 = var_0.get()
    assert var_1 == False
    assert isinstance(var_1, bool)
    var_2 = update_environment()
    assert var_2 is None

# Generated at 2022-06-26 07:26:05.388595
# Unit test for function toggle_variable
def test_toggle_variable():
    try:
        function_name = "toggle_variable"
        test = "No Error"
        output = toggle_variable()
        actual = "No Error"
        assert actual == output
    except AssertionError as e:
        test = "Error"
        print("Failed:", e)
    return [function_name, test, output, actual]




# Generated at 2022-06-26 07:26:07.181494
# Unit test for function toggle_variable
def test_toggle_variable():
    assert toggle_variable() == None, 'The result of toggle_variable did not match expected value: None'


# Generated at 2022-06-26 07:26:08.706279
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 07:26:09.198635
# Unit test for function update_environment
def test_update_environment():
    update_environment()

# Generated at 2022-06-26 07:26:19.581140
# Unit test for function toggle_variable
def test_toggle_variable():
    with get_workbench().set_simple_mode():
        get_workbench().set_default(_OPTION_NAME, True)
        assert get_workbench().get_variable(_OPTION_NAME).get() is True
        assert os.environ["PGZERO_MODE"] == "True"
        toggle_variable()
        assert get_workbench().get_variable(_OPTION_NAME).get() is False
        assert os.environ["PGZERO_MODE"] == "False"

    with get_workbench().set_simple_mode():
        get_workbench().set_default(_OPTION_NAME, False)
        assert get_workbench().get_variable(_OPTION_NAME).get() is False
        assert os.environ["PGZERO_MODE"] == "False"
        toggle_variable()
        assert get_workbench

# Generated at 2022-06-26 07:26:20.648818
# Unit test for function update_environment
def test_update_environment():
    # always returns None
    assert update_environment() is None


# Generated at 2022-06-26 07:26:22.031377
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()


# Generated at 2022-06-26 07:27:14.378737
# Unit test for function update_environment
def test_update_environment():
    update_environment()


# Generated at 2022-06-26 07:27:22.908468
# Unit test for function load_plugin
def test_load_plugin():
    # Check that 'PGZERO_MODE' is set to 'False'
    assert os.environ["PGZERO_MODE"] == 'False'
    load_plugin()
    # Check that 'PGZERO_MODE' is set to 'True'
    var_0 = toggle_variable()
    assert os.environ["PGZERO_MODE"] == 'True'
    # Check that 'PGZERO_MODE' is set to 'False'
    var_1 = toggle_variable()
    assert os.environ["PGZERO_MODE"] == 'False'

# Generated at 2022-06-26 07:27:23.845319
# Unit test for function update_environment
def test_update_environment():
    update_environment()


# Generated at 2022-06-26 07:27:34.622096
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_option(_OPTION_NAME, True)
    old_env_0 = os.environ.get("PGZERO_MODE")
    update_environment()
    if old_env_0 != os.environ.get("PGZERO_MODE"):
        raise Exception("%s != %s" % (old_env_0, os.environ.get("PGZERO_MODE")))
    get_workbench().set_option(_OPTION_NAME, False)
    old_env_0 = os.environ.get("PGZERO_MODE")
    update_environment()

# Generated at 2022-06-26 07:27:36.392932
# Unit test for function load_plugin
def test_load_plugin():
    assert load_plugin() == None  #TODO check this assertion


# Generated at 2022-06-26 07:27:37.734244
# Unit test for function toggle_variable
def test_toggle_variable():
    test_case_0()

# Generated at 2022-06-26 07:27:46.838663
# Unit test for function update_environment
def test_update_environment():
    test_get_workbench = get_workbench()
    v = test_get_workbench.set_default(_OPTION_NAME, False)
    v = test_get_workbench.get_option(_OPTION_NAME)
    v = str(v)
    assert os.environ["PGZERO_MODE"] == v, 'AssertionError: os.environ["PGZERO_MODE"] == v'
    v = test_get_workbench.get_option(_OPTION_NAME)
    v = str(v)
    assert os.environ["PGZERO_MODE"] == v, 'AssertionError: os.environ["PGZERO_MODE"] == v'

# Generated at 2022-06-26 07:27:49.474743
# Unit test for function load_plugin
def test_load_plugin():
    assert load_plugin() == None


# Generated at 2022-06-26 07:27:50.640609
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()


# Generated at 2022-06-26 07:28:00.571495
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench, get_runner
    from thonny.languages import tr
    from unittest.mock import patch

    with patch.object(get_workbench(), "set_default") as mock_set_default:
        with patch.object(get_workbench(), "add_command") as mock_add_command:
            with patch.object(get_workbench(), "get_option", return_value=False):
                with patch.object(os, "environ") as mock_environ:
                    load_plugin()
                    mock_set_default.assert_called_with("run.pgzero_mode", False)

# Generated at 2022-06-26 07:30:12.460987
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    assert (wb.get_default(_OPTION_NAME) == False)
    assert (wb.get_option(_OPTION_NAME) == False)
    assert (os.environ["PGZERO_MODE"] == "False")

    load_plugin()
    assert (wb.get_default(_OPTION_NAME) == False)
    assert (wb.get_option(_OPTION_NAME) == False)
    assert (os.environ["PGZERO_MODE"] == "False")

    wb.set_option(_OPTION_NAME, True)
    load_plugin()
    assert (os.environ["PGZERO_MODE"] == "True")

    wb.set_option(_OPTION_NAME, False)
    wb.set_simple_mode(True)
    load_

# Generated at 2022-06-26 07:30:13.315349
# Unit test for function load_plugin
def test_load_plugin():
    assert load_plugin()
    

# Generated at 2022-06-26 07:30:14.225414
# Unit test for function update_environment
def test_update_environment():
    update_environment()


# Generated at 2022-06-26 07:30:15.569216
# Unit test for function toggle_variable
def test_toggle_variable():
    assert(toggle_variable() != None)


# Generated at 2022-06-26 07:30:16.502252
# Unit test for function update_environment
def test_update_environment():
    update_environment()
    assert True


# Generated at 2022-06-26 07:30:17.315709
# Unit test for function update_environment
def test_update_environment():
    pass


# Generated at 2022-06-26 07:30:19.287939
# Unit test for function toggle_variable
def test_toggle_variable():
    assert var_0 == ("the value of the variable is changed")


# Generated at 2022-06-26 07:30:20.446444
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert True


# Generated at 2022-06-26 07:30:21.441111
# Unit test for function load_plugin
def test_load_plugin():
    assert load_plugin() != None


# Generated at 2022-06-26 07:30:22.268650
# Unit test for function update_environment
def test_update_environment():
    update_environment()
