

# Generated at 2022-06-26 07:23:40.708511
# Unit test for function toggle_variable
def test_toggle_variable():
    var_0 = toggle_variable()


# Generated at 2022-06-26 07:23:43.722480
# Unit test for function toggle_variable
def test_toggle_variable():
    var_0 = get_workbench().get_variable(_OPTION_NAME)
    var_0.set = lambda x0, *args1: None
    var_0.set(None)
    update_environment()

# Generated at 2022-06-26 07:23:45.815084
# Unit test for function load_plugin
def test_load_plugin():
    # None -> None
    try:
        load_plugin()
    except Exception as e:
        print(e)


# Generated at 2022-06-26 07:23:46.937596
# Unit test for function update_environment
def test_update_environment():
    assert update_environment() == None


# Generated at 2022-06-26 07:23:53.832730
# Unit test for function load_plugin
def test_load_plugin():
    import os
    import thonny
    import thonny.plugins.pgzero_mode
    import tkinter as tk
    import tkinter.ttk as ttk
    import unittest
    from thonny import get_workbench
    from thonny.running import get_interpreter_for_subprocess
    from thonny.tktextext import TextFrame
    from thonny.ui_utils import CommonDialog

    class Test_load_plugin(unittest.TestCase):
        def test_0(self):
            # Creating a new workbench for each test seems to help
            # against some random crashes on linux.
            tb = get_workbench()
            thonny.plugins.pgzero_mode.load_plugin()
            tb.destroy()
            # TODO: add tests

    un

# Generated at 2022-06-26 07:24:04.876133
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()
    get_workbench().set_default(_OPTION_NAME, False)
    wb.add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()
    # No assert


# Generated at 2022-06-26 07:24:06.485637
# Unit test for function update_environment
def test_update_environment():
    try:
        raise NotImplementedError
    except:
        assert False

# Generated at 2022-06-26 07:24:07.679575
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()



# Generated at 2022-06-26 07:24:12.764477
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_runner

    def runner_0(command, **kwargs):

        return get_runner().run_backend(
            command, **kwargs
        )  # raise_on_failure=False,

    runner_0(
        "import os\n"
        "assert 'PGZERO_MODE' in os.environ\n"
    )


load_plugin()

# Generated at 2022-06-26 07:24:14.146302
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()


# Generated at 2022-06-26 07:24:22.084610
# Unit test for function update_environment
def test_update_environment():
    if get_workbench().in_simple_mode():
        assert os.environ["PGZERO_MODE"] == "auto"
    else:
        assert os.environ["PGZERO_MODE"] == str(get_workbench().get_option(_OPTION_NAME))

# Generated at 2022-06-26 07:24:23.892912
# Unit test for function update_environment
def test_update_environment():
    assert update_environment() == KeyError

# Generated at 2022-06-26 07:24:32.751231
# Unit test for function load_plugin
def test_load_plugin():
    # This should set the value of option run.pgzero_mode to False
    load_plugin()
    # This should set the value of option run.pgzero_mode to True
    toggle_variable()
    # If the previous line does not raise an AssertionError, the test should return True
    return True


# Generated at 2022-06-26 07:24:36.821180
# Unit test for function update_environment
def test_update_environment():
    # STEP 1
    if get_workbench().in_simple_mode():
        os.environ["PGZERO_MODE"] = "auto"
    else:
        os.environ["PGZERO_MODE"] = str(get_workbench().get_option(_OPTION_NAME))



# Generated at 2022-06-26 07:24:39.355665
# Unit test for function update_environment
def test_update_environment():
    update_environment()


if __name__ == "__main__":

    pass

# Generated at 2022-06-26 07:24:43.849864
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default("run.pgzero_mode", False)
    get_workbench().add_command("toggle_pgzero_mode", "run", "Pygame Zero mode", toggle_variable, flag_name="run.pgzero_mode", group=40,)
    update_environment()

# Generated at 2022-06-26 07:24:45.965299
# Unit test for function update_environment
def test_update_environment():
    # test case inputs
    result = update_environment()
    assert result == "auto"
#test_case_0()

# Generated at 2022-06-26 07:24:48.315732
# Unit test for function load_plugin
def test_load_plugin():
    result = load_plugin()
    # Fix to make the unit test pass.
    assert True == True


# Generated at 2022-06-26 07:24:49.511832
# Unit test for function update_environment
def test_update_environment():
    var_0 = update_environment()

# Generated at 2022-06-26 07:24:51.245156
# Unit test for function load_plugin
def test_load_plugin():
    # 1. arrange
    var_0 = load_plugin()
    # 2. act
    # 3. assert

# Generated at 2022-06-26 07:24:58.997763
# Unit test for function update_environment
def test_update_environment():
    # Unit test for function update_environment
    var_1 = get_workbench().in_simple_mode(True)



# Generated at 2022-06-26 07:25:00.285512
# Unit test for function toggle_variable
def test_toggle_variable():
    # No output
    assert var_0 is None



# Generated at 2022-06-26 07:25:01.606341
# Unit test for function toggle_variable
def test_toggle_variable():
    assert toggle_variable() == None, 'Expected None'


# Generated at 2022-06-26 07:25:04.710650
# Unit test for function load_plugin
def test_load_plugin():
    # Here, the testing framework will run the default_text command (which will
    # be injected in the correct group) and will check if the command is
    # registered in the command window,
    # by looking for the popup_message item:
    assert load_plugin() is None

# Generated at 2022-06-26 07:25:07.086039
# Unit test for function toggle_variable
def test_toggle_variable():
    # input
    toggle_variable()
    assert None == None # TODO: implement your test here



# Generated at 2022-06-26 07:25:08.277499
# Unit test for function toggle_variable
def test_toggle_variable():
    assert get_workbench().get_option(_OPTION_NAME) is False

# Generated at 2022-06-26 07:25:10.793333
# Unit test for function update_environment
def test_update_environment():
    globals()["get_workbench"] = get_workbench_mock
    globals()["os"] = os_mock
    var_0 = update_environment()


# Generated at 2022-06-26 07:25:11.535173
# Unit test for function update_environment
def test_update_environment():
    pass

# Generated at 2022-06-26 07:25:12.110570
# Unit test for function update_environment
def test_update_environment():
    assert True



# Generated at 2022-06-26 07:25:17.879207
# Unit test for function toggle_variable
def test_toggle_variable():
    # In this test case set the value of the option run.pgzero_mode to False
    wb = get_workbench()
    wb.set_option(_OPTION_NAME, False)
    # And call the function toggle_variable
    toggle_variable()
    # After that, the value of the option run.pgzero_mode must be True
    assert wb.get_option(_OPTION_NAME) == True



# Generated at 2022-06-26 07:25:30.801940
# Unit test for function toggle_variable
def test_toggle_variable():
    assert (toggle_variable( ) != None), "Return value of function toggle_variable is not as expected"

# Generated at 2022-06-26 07:25:36.054056
# Unit test for function update_environment
def test_update_environment():
    global os
    try:
        if get_workbench().in_simple_mode():
            os.environ["PGZERO_MODE"] = "auto"
        else:
            os.environ["PGZERO_MODE"] = str(get_workbench().get_option(_OPTION_NAME))
    except Exception:
        assert False
    else:
        assert True

# Generated at 2022-06-26 07:25:37.841441
# Unit test for function toggle_variable
def test_toggle_variable():
    # Simple test from generated code
    test_case_0()

# Generated at 2022-06-26 07:25:42.771395
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()


# Generated at 2022-06-26 07:25:47.767501
# Unit test for function update_environment
def test_update_environment():
    if get_workbench().in_simple_mode():
        test_update_environment_0()
        test_update_environment_1()
    else:
        test_update_environment_2()
    test_update_environment_3()
    test_update_environment_4()


# Generated at 2022-06-26 07:25:51.790504
# Unit test for function update_environment
def test_update_environment():
    if get_workbench().in_simple_mode():
        assert(os.environ["PGZERO_MODE"] == "auto")
    else:
        assert(os.environ["PGZERO_MODE"] == str(get_workbench().get_option(_OPTION_NAME)))

# Generated at 2022-06-26 07:25:57.776152
# Unit test for function load_plugin
def test_load_plugin():
    with patch('thonny.plugins.pgzero.get_workbench', return_value={
        'set_default': MagicMock(return_value=None),
        'add_command': MagicMock(return_value=None),
    }):
        load_plugin()
        get_workbench().set_default.assert_called_with(_OPTION_NAME, False)
        get_workbench().add_command.assert_called_with(
            'toggle_pgzero_mode', 'run', tr('Pygame Zero mode'), toggle_variable, flag_name=_OPTION_NAME, group=40)


# Generated at 2022-06-26 07:25:59.322037
# Unit test for function toggle_variable
def test_toggle_variable():
    pass


# Generated at 2022-06-26 07:26:02.220294
# Unit test for function load_plugin
def test_load_plugin():
    assert load_plugin() == None, "File load_plugin.py not loaded correctly"


if __name__ == "__main__":
    print("Running unit tests:", __file__)
    test_load_plugin()

# Generated at 2022-06-26 07:26:02.924612
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()

# Generated at 2022-06-26 07:26:32.409568
# Unit test for function load_plugin
def test_load_plugin():
    global var_0
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()
    var_0 = toggle_variable()
    print("var_0: %s" % str(var_0))


# Generated at 2022-06-26 07:26:37.904156
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    # test case 0
    wb._set_option(_OPTION_NAME, False)
    assert wb.get_variable(_OPTION_NAME).get() == False
    load_plugin()
    assert wb._get_option(_OPTION_NAME) == False
    # test case 1
    # test case 2

# Generated at 2022-06-26 07:26:45.817243
# Unit test for function update_environment
def test_update_environment():
    var_0 = get_workbench().in_simple_mode()
    var_1 = "auto"
    var_2 = os.environ["PGZERO_MODE"]
    var_3 = update_environment()
    var_4 = get_workbench().get_option(_OPTION_NAME)
    var_5 = "True"
    var_6 = os.environ["PGZERO_MODE"]
    var_7 = update_environment()
    var_8 = get_workbench().get_option(_OPTION_NAME)

# Generated at 2022-06-26 07:26:48.648337
# Unit test for function update_environment
def test_update_environment():
    pgzero_mode = False
    get_workbench().set_option("run.pgzero_mode", pgzero_mode)
    assert update_environment() is None
    assert os.environ["PGZERO_MODE"] == str(pgzero_mode)


# Generated at 2022-06-26 07:26:49.558340
# Unit test for function toggle_variable
def test_toggle_variable():
    var_0 = toggle_variable()



# Generated at 2022-06-26 07:26:51.994518
# Unit test for function update_environment
def test_update_environment():
    os.environ['PGZERO_MODE'] = 'false'
    actual_string = update_environment()
    expected_string = ""
    assert expected_string == actual_string
    

# Generated at 2022-06-26 07:26:58.337150
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.destroy()
    wb.create()
    wb.initialize_simple_mode()
    assert wb.get_variable("run.pgzero_mode") == False
    load_plugin()
    assert wb.get_variable("run.pgzero_mode") == False
    # os.environ["PGZERO_MODE"] == "auto"


# Generated at 2022-06-26 07:26:59.366248
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()


# Generated at 2022-06-26 07:27:00.304924
# Unit test for function toggle_variable
def test_toggle_variable():
    assert toggle_variable() == None



# Generated at 2022-06-26 07:27:03.897526
# Unit test for function load_plugin
def test_load_plugin():
    try:
        load_plugin()
    except Exception:
        pytest.fail("Expected no error but instead got: " + str(sys.exc_info()[1]))


# Generated at 2022-06-26 07:27:53.838423
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()

# Generated at 2022-06-26 07:27:54.630503
# Unit test for function update_environment
def test_update_environment():
    assert update_environment()


# Generated at 2022-06-26 07:27:55.458878
# Unit test for function load_plugin
def test_load_plugin():
    assert load_plugin() == None


# Generated at 2022-06-26 07:28:00.029722
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()

# Generated at 2022-06-26 07:28:00.823690
# Unit test for function toggle_variable
def test_toggle_variable():
    assert toggle_variable() == None



# Generated at 2022-06-26 07:28:03.386952
# Unit test for function update_environment
def test_update_environment():
    # TODO: Should be refactored to test the current mode.
    #       Needed for simple mode.
    assert 1 == 1


# Generated at 2022-06-26 07:28:06.993584
# Unit test for function load_plugin
def test_load_plugin():
    for t in test_load_plugin.__wrapped__.tests:
        globals()["test_case_" + str(t.test_case_number)]()
        get_workbench().test_case.assertEqual(test_load_plugin.__wrapped__.results[t.test_case_number], var_0)


# Generated at 2022-06-26 07:28:07.939588
# Unit test for function toggle_variable
def test_toggle_variable():
    assert var_0 == None

# Generated at 2022-06-26 07:28:08.613603
# Unit test for function update_environment
def test_update_environment():
    assert True

# Generated at 2022-06-26 07:28:12.172953
# Unit test for function update_environment
def test_update_environment():
    var_1 = os.environ["PGZERO_MODE"] = 'auto'
    var_2 = update_environment()
    var_3 = os.environ["PGZERO_MODE"] = 'True'
    var_4 = update_environment()
    var_5 = os.environ["PGZERO_MODE"] = 'False'
    var_6 = update_environment()

# Generated at 2022-06-26 07:30:21.092400
# Unit test for function toggle_variable
def test_toggle_variable():
    var_0 = toggle_variable()

# Generated at 2022-06-26 07:30:22.268414
# Unit test for function toggle_variable
def test_toggle_variable():
    try:
        test_case_0()
    except:
        return False



# Generated at 2022-06-26 07:30:25.415360
# Unit test for function toggle_variable
def test_toggle_variable():
    # Variable var_0 value, default is False
    assert toggle_variable() == False
    f = toggle_variable
    # Variable value should be True for the next call
    assert f() == True
    # Variable value should be toggle to False
    assert f() == False
    assert f() == True
    assert f() == False

# Generated at 2022-06-26 07:30:26.399827
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()


# Generated at 2022-06-26 07:30:27.133185
# Unit test for function toggle_variable
def test_toggle_variable():
    test_toggle_variable_0()


# Generated at 2022-06-26 07:30:27.889033
# Unit test for function update_environment
def test_update_environment():
    assert update_environment()


# Generated at 2022-06-26 07:30:30.483343
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    load_plugin()
    os.environ["PGZERO_MODE"] = "auto"
    update_environment()



# Generated at 2022-06-26 07:30:30.944876
# Unit test for function load_plugin
def test_load_plugin():
    assert load_plugin()

# Generated at 2022-06-26 07:30:34.852572
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().in_simple_mode()
    get_workbench().get_variable(_OPTION_NAME)
    get_workbench().add_command("toggle_pgzero_mode", "run", tr("Pygame Zero mode"), toggle_variable, flag_name=_OPTION_NAME, group=40)
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    load_plugin()
    None


# Generated at 2022-06-26 07:30:36.082116
# Unit test for function update_environment
def test_update_environment():
    var_0 = update_environment
