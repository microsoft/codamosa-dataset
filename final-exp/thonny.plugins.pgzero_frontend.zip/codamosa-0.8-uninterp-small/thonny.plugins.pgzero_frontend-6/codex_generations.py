

# Generated at 2022-06-26 07:23:13.017410
# Unit test for function update_environment
def test_update_environment():
    assert update_environment() == None

# Generated at 2022-06-26 07:23:13.915176
# Unit test for function update_environment
def test_update_environment():
    update_environment()


# Generated at 2022-06-26 07:23:17.819300
# Unit test for function load_plugin
def test_load_plugin():
    print("Test case 1")
    var_1 = load_plugin()
    # Test if the conditions are met to execute the code inside the condition
    if var_1 == None:
        print(True)
    else:
        print(False)


# Generated at 2022-06-26 07:23:18.675420
# Unit test for function load_plugin
def test_load_plugin():
    assert load_plugin() == None


# Generated at 2022-06-26 07:23:23.240526
# Unit test for function load_plugin
def test_load_plugin():
    var_0 = get_workbench()
    var_1 = var_0.set_default(_OPTION_NAME, False)
    var_2 = var_0.add_command("toggle_pgzero_mode", "run", tr("Pygame Zero mode"), toggle_variable, flag_name=_OPTION_NAME, group=40)
    var_3 = var_0.in_simple_mode()
    var_4 = var_3 == False
    var_3 = var_4
    if var_3:
        var_5 = get_workbench()
        var_6 = var_5.get_option(_OPTION_NAME)
        var_7 = str(var_6)
        var_8 = os.environ
        var_8["PGZERO_MODE"] = var_7
    else:
        var_

# Generated at 2022-06-26 07:23:27.036498
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench
    from thonny.languages import tr
    from thonny.common import ToplevelCommand, SidebarCommand
    import os
    import tkinter as Tk
    var_0 = get_workbench()
    var_1 = update_environment()


# Generated at 2022-06-26 07:23:28.047116
# Unit test for function load_plugin
def test_load_plugin():
    return load_plugin()


# Generated at 2022-06-26 07:23:31.803899
# Unit test for function load_plugin
def test_load_plugin():
    # Setup
    expected_result_0 = None
    expected_result_1 = None

    # Execution
    result_0 = load_plugin()

    # Verification
    assert result_0 == expected_result_0
    assert result_1 == expected_result_1


# Generated at 2022-06-26 07:23:41.843948
# Unit test for function load_plugin
def test_load_plugin():
    var_0 = get_workbench()
    var_1 = type(var_0)
    with capture_output() as (stdout, stderr):
        var_0.set_default(_OPTION_NAME, False)
        var_0.add_command("toggle_pgzero_mode", "run", tr("Pygame Zero mode"), toggle_variable, flag_name=_OPTION_NAME, group=40)
        update_environment()
    assert (
        stdout.getvalue()
        == ""
    ), "Expected different output: '%s' vs '%s'" % (stdout.getvalue(), "",)
    assert (
        stderr.getvalue()
        == ""
    ), "Expected different output: '%s' vs '%s'" % (stderr.getvalue(), "",)


# Generated at 2022-06-26 07:23:44.796305
# Unit test for function update_environment
def test_update_environment():
    var_0 = update_environment()


if __name__ == "__main__":
    import pytest

    pytest.main(["-v", "-s", "-x", __file__])

# Generated at 2022-06-26 07:24:02.876286
# Unit test for function update_environment
def test_update_environment():
    flag_0 = True
    # unit test for setting the pgzero_mode to "auto"
    os.environ["PGZERO_MODE"] = "auto"
    if not os.environ["PGZERO_MODE"] == "auto":
        flag_0 = False
    # unit test for setting the pgzero_mode to "false"
    os.environ["PGZERO_MODE"] = "false"
    if not os.environ["PGZERO_MODE"] == "false":
        flag_0 = False
    # unit test for setting the pgzero_mode to "true"
    os.environ["PGZERO_MODE"] = "true"
    if not os.environ["PGZERO_MODE"] == "true":
        flag_0 = False
    return flag_0


# Generated at 2022-06-26 07:24:07.105661
# Unit test for function load_plugin
def test_load_plugin():
    import os
    assert 'PGZERO_MODE' in os.environ.keys()
    assert os.environ['PGZERO_MODE'] == 'False'

# Generated at 2022-06-26 07:24:10.011024
# Unit test for function toggle_variable
def test_toggle_variable():
    unit_test.stop()
    v = update_environment()
    unit_test.resume()
    assert v is None


# Generated at 2022-06-26 07:24:19.555462
# Unit test for function update_environment
def test_update_environment():
    var_0 = get_workbench()
    var_1 = var_0.in_simple_mode
    var_2 = var_1()
    var_3 = not var_2
    var_4 = get_workbench()
    var_5 = var_4.get_option
    var_6 = _OPTION_NAME
    var_7 = var_5(var_6)
    if var_3:
        var_8 = "auto"
    else:
        var_8 = str(var_7)
    os.environ["PGZERO_MODE"] = var_8


# Generated at 2022-06-26 07:24:21.899099
# Unit test for function toggle_variable
def test_toggle_variable():

    ####
    # Test preparation
    ####
    toggle_variable()



# Generated at 2022-06-26 07:24:23.753612
# Unit test for function toggle_variable
def test_toggle_variable():
    assert toggle_variable() is None


# Generated at 2022-06-26 07:24:29.420485
# Unit test for function load_plugin
def test_load_plugin():
    # Called with:
    load_plugin()


# Generated at 2022-06-26 07:24:30.518926
# Unit test for function update_environment
def test_update_environment():
    update_environment()


# Generated at 2022-06-26 07:24:39.484515
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    # check if intial values are right
    try:
        assert wb["PGZERO_MODE"] == "auto", "PGZERO_MODE intial value"
    except KeyError:
        raise AssertionError("PGZERO_MODE intial value")
    try:
        assert wb["run"]["pgzero_mode"].get() == False, "run.pgzero_mode intial value"
    except KeyError:
        raise AssertionError("run.pgzero_mode intial value")
    # test for PGZERO_MODE
    wb["run"]["pgzero_mode"].set(True)
    try:
        assert wb["PGZERO_MODE"] == "True", "PGZERO_MODE True value"
    except KeyError:
        raise

# Generated at 2022-06-26 07:24:40.690457
# Unit test for function load_plugin
def test_load_plugin():
    var_0 = None
    var_0 = load_plugin()


# Generated at 2022-06-26 07:24:53.460886
# Unit test for function update_environment
def test_update_environment():
    update_environment()

# Generated at 2022-06-26 07:24:57.669722
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_simple_mode(False)
    get_workbench().set_option(_OPTION_NAME, False)
    expected_0 = os.environ["PGZERO_MODE"]
    update_environment()
    actual_0 = os.environ["PGZERO_MODE"]
    assert actual_0 == expected_0


# Generated at 2022-06-26 07:24:58.619514
# Unit test for function load_plugin
def test_load_plugin():
    var_0 = get_workbench()


# Generated at 2022-06-26 07:24:59.160182
# Unit test for function toggle_variable
def test_toggle_variable():
    pass

# Generated at 2022-06-26 07:25:02.559315
# Unit test for function load_plugin
def test_load_plugin():
    try:
        assert get_workbench().in_simple_mode() == True
       
        assert get_workbench().get_option(_OPTION_NAME) == False
    except Exception:
        assert False
    else:
        assert True
#

# Generated at 2022-06-26 07:25:03.408072
# Unit test for function update_environment
def test_update_environment():
    assert update_environment() == None


# Generated at 2022-06-26 07:25:04.557841
# Unit test for function load_plugin
def test_load_plugin():
    # Setup test
    load_plugin()
    assert True


# Generated at 2022-06-26 07:25:10.329900
# Unit test for function toggle_variable
def test_toggle_variable():
    if 'PGZERO_MODE' not in os.environ:
        os.environ['PGZERO_MODE'] = 'False'
    toggle_variable()
    if os.environ['PGZERO_MODE'] != 'True':
        raise AssertionError
    toggle_variable()
    if os.environ['PGZERO_MODE'] != 'False':
        raise AssertionError


# Generated at 2022-06-26 07:25:15.443360
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-26 07:25:15.991715
# Unit test for function load_plugin
def test_load_plugin():
    pass

# Generated at 2022-06-26 07:25:28.919294
# Unit test for function toggle_variable
def test_toggle_variable():
    _test_toggle_variable()
    _test_function_call_0()


# Generated at 2022-06-26 07:25:30.229481
# Unit test for function update_environment
def test_update_environment():
    var_0 = update_environment()


# # Unit test for function load_plugin

# Generated at 2022-06-26 07:25:33.856336
# Unit test for function toggle_variable
def test_toggle_variable():
    # Stub
    get_workbench = lambda: None
    get_workbench().get_variable = env._get_variable

    # Fixture
    opt = env.get_variable(test_case_0.flag_name)
    flag_value = opt.get()

    # Exercise
    test_case_0()

    # Verify
    assert opt.get() != flag_value


# Generated at 2022-06-26 07:25:35.255520
# Unit test for function update_environment
def test_update_environment():
    assert update_environment() is None


# Generated at 2022-06-26 07:25:38.671006
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME) == False


# Generated at 2022-06-26 07:25:42.157413
# Unit test for function update_environment
def test_update_environment():
    var_0 = update_environment()

from thonny import get_workbench
import tkinter
from tkinter import messagebox
from thonny.languages import tr

_OPTION_NAME = "run.pgzero_mode"



# Generated at 2022-06-26 07:25:43.574554
# Unit test for function update_environment
def test_update_environment():
    update_environment()


# Generated at 2022-06-26 07:25:49.055938
# Unit test for function load_plugin
def test_load_plugin():
    os.environ["PGZERO_MODE"] = "FALSE"
    load_plugin()
    assert get_workbench().get_option("run.pgzero_mode") == False
    assert os.environ.get("PGZERO_MODE") == "auto"

# Generated at 2022-06-26 07:25:55.557946
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_option(_OPTION_NAME, False)
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_option(_OPTION_NAME, True)
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().in_simple_mode = lambda: True
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().in_simple_mode = lambda: False

# Generated at 2022-06-26 07:25:57.450397
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert get_workbench().in_simple_mode() == True


# Generated at 2022-06-26 07:26:24.965059
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().get_variable(_OPTION_NAME).set(True)
    toggle_variable()
    var_0 = get_workbench().get_variable(_OPTION_NAME).get()
    assert var_0 == False
    toggle_variable()
    var_1 = get_workbench().get_variable(_OPTION_NAME).get()
    assert var_1 == True


# Generated at 2022-06-26 07:26:33.328396
# Unit test for function load_plugin

# Generated at 2022-06-26 07:26:35.178442
# Unit test for function update_environment
def test_update_environment():
    assert update_environment() == None

# Generated at 2022-06-26 07:26:38.523048
# Unit test for function update_environment
def test_update_environment():
    from thonny.languages import tr

    os.environ["PGZERO_MODE"] = tr("auto")
    return (os.environ["PGZERO_MODE"] == "auto")



# Generated at 2022-06-26 07:26:39.944414
# Unit test for function update_environment
def test_update_environment():
    assert (update_environment() == None)

# Generated at 2022-06-26 07:26:48.676703
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench = get_workbench()
    get_workbench = get_workbench()
    get_workbench = get_workbench()
    get_workbench = get_workbench()
    get_workbench = get_workbench()
    get_workbench = get_workbench()
    get_workbench = get_workbench()
    get_workbench = get_workbench()
    get_workbench = get_workbench()
    function = get_workbench().get_commands()
    expected = None
    assert function == expected
    get_workbench = get_workbench()
    get_workbench = get_workbench()


# Generated at 2022-06-26 07:26:51.547081
# Unit test for function load_plugin
def test_load_plugin():
    # Add the plugin
    load_plugin()
    # Check if the var_0 is false
    assert not var_0
    # Toggle the var_0
    toggle_variable()
    # Now var_0 should be true
    assert var_0

# Generated at 2022-06-26 07:26:54.699138
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_simple_mode(False)
    update_environment()
    # Should also test if PGZERO_MODE is in os.environ

# Generated at 2022-06-26 07:27:01.282817
# Unit test for function update_environment
def test_update_environment():
    assert os.environ["PGZERO_MODE"] == "auto"

if __name__ == "__main__":
    import thonny  # isort:skip

    # When running in Thonny's embedded Python, this mock is necessary for
    # global variable handling
    get_workbench = thonny.workbench.get_workbench
    get_workbench().set_simple_mode()

    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()

# Generated at 2022-06-26 07:27:02.147863
# Unit test for function update_environment
def test_update_environment():
    expected_0 = update_environment()


# Generated at 2022-06-26 07:27:53.837762
# Unit test for function update_environment
def test_update_environment():
    assert update_environment() == None

# Generated at 2022-06-26 07:27:56.172862
# Unit test for function toggle_variable
def test_toggle_variable():
    expected_result = 1
    actual_result = 1
    assert actual_result == expected_result


if __name__ == "__main__":
    actual_result = test_toggle_variable()

# Generated at 2022-06-26 07:27:57.783915
# Unit test for function update_environment
def test_update_environment():
    pass


# Generated at 2022-06-26 07:27:58.360136
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()

# Generated at 2022-06-26 07:27:59.206758
# Unit test for function update_environment
def test_update_environment():
    var_0 = update_environment()

# Generated at 2022-06-26 07:28:00.850722
# Unit test for function toggle_variable
def test_toggle_variable():
    assert toggle_variable() == None


# Generated at 2022-06-26 07:28:09.085024
# Unit test for function load_plugin
def test_load_plugin():
    import thonny.backend
    from thonny.languages import tr
    from thonny.config import get_workbench
    import os
    import __main__

    def update_environment():
        if get_workbench().in_simple_mode():
            os.environ["PGZERO_MODE"] = "auto"
        else:
            os.environ["PGZERO_MODE"] = str(get_workbench().get_option(_OPTION_NAME))

    def toggle_variable():
        var = get_workbench().get_variable(_OPTION_NAME)
        var.set(not var.get())
        update_environment()

    def load_plugin():
        get_workbench().set_default(_OPTION_NAME, False)

# Generated at 2022-06-26 07:28:09.856853
# Unit test for function update_environment
def test_update_environment():
    update_environment()


# Generated at 2022-06-26 07:28:10.592360
# Unit test for function update_environment
def test_update_environment():
    update_environment()


# Generated at 2022-06-26 07:28:16.008925
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    with mock.patch("thonny.plugins.pgzero_mode.get_workbench") as mock_get_workbench:
        instance = mock_get_workbench.return_value
        test_load_plugin_0()
        assert instance.set_default.call_args_list == [mock.call("run.pgzero_mode", False)]
        assert instance.add_command.call_args_list == [mock.call("toggle_pgzero_mode", "run", "Pygame Zero mode", toggle_variable, flag_name="run.pgzero_mode", group=40)]
        assert test_case_0() == None


# Generated at 2022-06-26 07:30:22.818779
# Unit test for function update_environment
def test_update_environment():
    var_0 = update_environment()


# Generated at 2022-06-26 07:30:24.215026
# Unit test for function toggle_variable
def test_toggle_variable():
    var_0 = toggle_variable()
    assert var_0 == None, 'Return value is incorrect'


# Generated at 2022-06-26 07:30:27.133242
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_option(_OPTION_NAME, True)
    update_environment()
    # Check that the environment variable PGZERO_MODE is set to "True"
    assert os.environ["PGZERO_MODE"] == "True"


# Generated at 2022-06-26 07:30:27.887918
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()



# Generated at 2022-06-26 07:30:29.408911
# Unit test for function update_environment
def test_update_environment():
    assert False, "Test not implemented."


# Generated at 2022-06-26 07:30:32.440314
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default('run.pgzero_mode', True)
    load_plugin()
    assert get_workbench().pgzero_mode == get_workbench().get_option(
        'run.pgzero_mode')
    update_environment()

if __name__ == "__main__":
    load_plugin()

# Generated at 2022-06-26 07:30:39.617561
# Unit test for function load_plugin
def test_load_plugin():
    try:
        import enum
        from thonny.plugins.pgzero.bootstrap import load_plugin
        from thonny.plugins.pgzero import bootstrap
        from thonny import get_workbench
        from thonny.languages import tr
        import os
    except:
        assert False, "Can not import packages"

    try:
        load_plugin()
    except:
        assert False, "Fail to load plugin"
    assert True



# Generated at 2022-06-26 07:30:40.374523
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()


# Generated at 2022-06-26 07:30:40.849811
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()

# Generated at 2022-06-26 07:30:42.205803
# Unit test for function load_plugin
def test_load_plugin():
    try:
        load_plugin()
    except Exception:
        assert False, "load_plugin failed"
