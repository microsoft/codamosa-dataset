

# Generated at 2022-06-26 07:23:23.566726
# Unit test for function toggle_variable
def test_toggle_variable():
    # Test 0: Test return value
    try:
        assert test_case_0() is None
    except AssertionError:
        print('Failed test case: "{}"'.format('0_0'))


if __name__ == "__main__":
    from thonny import workbench

    workbench.set_default("use_unittest_for_executing_files", True)
    import thonny.plugins.pygamemode

    workbench.set_default(_OPTION_NAME, False)
    workbench.add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    workbench.unittest_main()

# Generated at 2022-06-26 07:23:24.282233
# Unit test for function toggle_variable
def test_toggle_variable():
    assert isinstance(var_0, bool)



# Generated at 2022-06-26 07:23:27.488523
# Unit test for function load_plugin
def test_load_plugin():
    assert not get_workbench().get_option(_OPTION_NAME)
    assert not load_plugin()
    assert get_workbench().get_option(_OPTION_NAME)

# Generated at 2022-06-26 07:23:30.469367
# Unit test for function load_plugin
def test_load_plugin():
    # Arrange
    # Unit test for function _OPTION_NAME
    var_0 = _OPTION_NAME
    # Act
    var_0 = load_plugin()


# Generated at 2022-06-26 07:23:32.149579
# Unit test for function load_plugin
def test_load_plugin():
    var_1 = load_plugin()

if __name__ == '__main__':
    test_load_plugin()

# Generated at 2022-06-26 07:23:40.565214
# Unit test for function update_environment
def test_update_environment():
    try:
        wb = get_workbench()
        var = wb.get_variable(_OPTION_NAME)
        old_var = var.get()
        var.set(True)
        update_environment()
        assert os.environ["PGZERO_MODE"] == "True"
        var.set(False)
        update_environment()
        assert os.environ["PGZERO_MODE"] == "False"
        var.set(old_var)
        update_environment()
    except Exception:
        var.set(old_var)
        update_environment()
        raise

# Generated at 2022-06-26 07:23:42.356994
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-26 07:23:43.397861
# Unit test for function load_plugin
def test_load_plugin():
    assert load_plugin() == None


# Generated at 2022-06-26 07:23:45.053272
# Unit test for function toggle_variable
def test_toggle_variable():
    var_0 = toggle_variable()
    assert None is not var_0


# Generated at 2022-06-26 07:23:53.010948
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    old_simple_mode = wb.in_simple_mode()
    old_option = wb.get_option(_OPTION_NAME)
    # 1. Simple mode and pgzero mode (default is False)
    wb.set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    # 2. Simple mode and pgzero mode on
    wb.set_simple_mode(True)
    wb.set_option(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    # 3. Not simple mode and pgzero mode (default is False)
    wb.set_simple_mode(False)
    update_environment()


# Generated at 2022-06-26 07:24:00.830022
# Unit test for function update_environment
def test_update_environment():
    # Code in this function will be executed at the time of test run
    assert update_environment() == None

# Generated at 2022-06-26 07:24:05.332093
# Unit test for function update_environment
def test_update_environment():
    assert update_environment is not None,"No way"

# Generated at 2022-06-26 07:24:06.069572
# Unit test for function update_environment
def test_update_environment():
    update_environment()

# Generated at 2022-06-26 07:24:07.062943
# Unit test for function toggle_variable
def test_toggle_variable():
    var_0 = toggle_variable()


# Generated at 2022-06-26 07:24:13.337907
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    var_0 = get_workbench().get_variable(_OPTION_NAME)
    assert var_0.get() == False
    toggle_variable()
    var_1 = get_workbench().get_variable(_OPTION_NAME)
    assert var_1.get() == True
    toggle_variable()
    var_2 = get_workbench().get_variable(_OPTION_NAME)
    assert var_2.get() == False


# Generated at 2022-06-26 07:24:17.351392
# Unit test for function update_environment
def test_update_environment():
    test_name = 'PGZERO_MODE'
    if (test_name != 'PGZERO_MODE'):
        return (True)
    else:
        return (False)

# Generated at 2022-06-26 07:24:19.888979
# Unit test for function load_plugin
def test_load_plugin():
    print()
    get_workbench().set_default(_OPTION_NAME, False)
    load_plugin()


# Generated at 2022-06-26 07:24:24.278259
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    if not wb.get_variable(_OPTION_NAME).get():
        test_case_0()
    else:
        test_case_1()


# Generated at 2022-06-26 07:24:29.159971
# Unit test for function update_environment
def test_update_environment():
    if get_workbench().in_simple_mode():
        assert os.environ["PGZERO_MODE"] == "auto", "Expected 'auto' but got {}".format(os.environ["PGZERO_MODE"])



# Generated at 2022-06-26 07:24:30.797544
# Unit test for function update_environment
def test_update_environment():
    # assert
    var_0 = update_environment()



# Generated at 2022-06-26 07:24:38.424586
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()

# Generated at 2022-06-26 07:24:43.849711
# Unit test for function load_plugin
def test_load_plugin():
    import unittest
    from unittest.mock import patch

    _get_workbench = patch("thonny.plugins.pgzero_mode.get_workbench", return_value={})
    _set_default = patch("thonny.plugins.pgzero_mode.get_workbench().set_default", side_effect=AttributeError)


# Generated at 2022-06-26 07:24:51.339909
# Unit test for function toggle_variable
def test_toggle_variable():
    var_0 = get_workbench().get_variable(_OPTION_NAME)
    var_0.get()
    # Testing condition
    if var_0.get():
        # Test if var_0.get() is True
        assert True
    else:
        # Test if var_0.get() is False
        assert True
    # Test if var_0.set(not var_0.get()) doesn't return None
    assert var_0.set(not var_0.get()) is not None



# Generated at 2022-06-26 07:24:53.215065
# Unit test for function toggle_variable
def test_toggle_variable():
    assert eval("var_0") is None, "var_0 is None"


# Generated at 2022-06-26 07:24:54.233471
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()


# Generated at 2022-06-26 07:24:55.138509
# Unit test for function toggle_variable
def test_toggle_variable():
    var_0 = toggle_variable()


# Generated at 2022-06-26 07:24:56.053283
# Unit test for function update_environment
def test_update_environment():
    assert update_environment() == None


# Generated at 2022-06-26 07:24:57.964817
# Unit test for function load_plugin
def test_load_plugin():
    # Unit test for function load_plugin
    # Function call
    assert load_plugin() == None


# Generated at 2022-06-26 07:25:06.281775
# Unit test for function load_plugin
def test_load_plugin():
    # Create a temporary variable
    global var_0
    var_0 = None
    # Create a temporary variable
    global get_workbench_0
    get_workbench_0 = get_workbench()
    # Set default for option 'run.pgzero_mode'
    get_workbench_0.set_default(_OPTION_NAME, False)
    # Function 'add_command' from object 'Workbench'
    get_workbench_0.add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    # Verify function 'add_command' from object 'Workbench'
    assert 0 == 0
    # Call function 'update_environment'
    update_

# Generated at 2022-06-26 07:25:13.819250
# Unit test for function update_environment
def test_update_environment():
    get_workbench().in_simple_mode(False)
    test_value = os.environ["PGZERO_MODE"]
    _0 = True
    while _0:
        test_value = toggle_variable(test_value)
        if test_value == "auto":
            get_workbench().in_simple_mode(True)
            test_value = toggle_variable(test_value)
            break
        else:
            get_workbench().in_simple_mode(False)
            break
    if test_value == "auto":
        print("Test passed")
    else:
        print("Test failed")

# Generated at 2022-06-26 07:25:30.617962
# Unit test for function update_environment
def test_update_environment():
    # Example 1
    # Expected Output:
    #   os.environ["PGZERO_MODE"] = 'auto'
    update_environment()

    # Example 3
    # Expected Output:
    #   os.environ["PGZERO_MODE"] = 'False'
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()



# Generated at 2022-06-26 07:25:32.354931
# Unit test for function toggle_variable
def test_toggle_variable():
    # Test case where the missing value is expected.
    assert var_0 == None

# Generated at 2022-06-26 07:25:33.817433
# Unit test for function load_plugin
def test_load_plugin():
    print("Testing load_plugin")
    assert load_plugin() == None, "test_load_plugin failed"

# Generated at 2022-06-26 07:25:36.389977
# Unit test for function update_environment
def test_update_environment():
    try:
        update_environment()
    except Exception as e:
        print(e.message)
    else:
        pass

# Generated at 2022-06-26 07:25:39.416031
# Unit test for function load_plugin
def test_load_plugin():
    try:
        load_plugin()
    except:
        pytest.fail("Function call failed.")
    else:
        pass

# Generated at 2022-06-26 07:25:45.046708
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    get_workbench().set_default("run.pgzero_mode", False)
    wb = get_workbench()
    wb.add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name="run.pgzero_mode",
        group=40,
    )
    os.environ["PGZERO_MODE"] = str(get_workbench().get_option(_OPTION_NAME))

    load_plugin()
    assert get_workbench().get_option("run.pgzero_mode") == False



# Generated at 2022-06-26 07:25:51.179887
# Unit test for function update_environment
def test_update_environment():

    # Ensure that this test does not persist between executions of the test suite.
    # It is possible that the default value for this option is true and therefore
    # the test would fail. This is not desirable.
    os.environ["PGZERO_MODE"] = ""
    update_environment()

    assert( os.environ["PGZERO_MODE"] == "False" )


# Generated at 2022-06-26 07:25:52.084730
# Unit test for function load_plugin
def test_load_plugin():
    var_0 = load_plugin()


# Generated at 2022-06-26 07:25:54.777454
# Unit test for function update_environment
def test_update_environment():
    # Test case where get_workbench().in_simple_mode() == (False)
    assert update_environment() == (None)
    pass

# Test function load_plugin

# Generated at 2022-06-26 07:25:55.669966
# Unit test for function update_environment
def test_update_environment():
    var_0 = update_environment()


# Generated at 2022-06-26 07:26:22.255859
# Unit test for function toggle_variable
def test_toggle_variable():
    # Check that function works
    assert callable(toggle_variable()), "toggle_variable not callable"
    assert (toggle_variable() == None), "toggle_variable returns value"



# Generated at 2022-06-26 07:26:28.535802
# Unit test for function update_environment
def test_update_environment():
    simple = get_workbench().in_simple_mode()
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_simple_mode(simple)
    update_environment()

# Generated at 2022-06-26 07:26:29.378120
# Unit test for function load_plugin
def test_load_plugin():
    
    load_plugin()

# Generated at 2022-06-26 07:26:30.605239
# Unit test for function toggle_variable
def test_toggle_variable():
    # TODO: fix this test
    test_case_0()

# Generated at 2022-06-26 07:26:33.714704
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_option("run.pgzero_mode",True)
    update_environment()

if __name__ == "__main__":
    print("Running Unit tests")
    # Unit test for function toggle_variable
    print("Function: toggle_variable")
    test_case_0()
    test_update_environment()

# Generated at 2022-06-26 07:26:37.944725
# Unit test for function toggle_variable
def test_toggle_variable():
    var = get_workbench().get_variable(_OPTION_NAME)  # TODO: test that this is False initially
    toggle_variable()
    var = get_workbench().get_variable(_OPTION_NAME)
    assert var is True


# Generated at 2022-06-26 07:26:48.761007
# Unit test for function load_plugin
def test_load_plugin():
    global toggle_variable, update_environment

    def toggle_variable():
        pass

    def update_environment():
        pass

    _load_plugin()

    from thonny.plugins.pgzero_mode import toggle_variable, update_environment
    assert toggle_variable

    class Workbench():
        def __init__(self):
            self.option = None

        def set_default(self, key, value):
            if key == "run.pgzero_mode":
                self.option = value

        def get_option(self, key):
            return self.option

        def add_command(self, key, value, text, command, flag_name, group):
            pass

        def in_simple_mode(self):
            return True

    _Workbench = Workbench
    _load_plugin()
    update_environment()




# Generated at 2022-06-26 07:26:49.637663
# Unit test for function update_environment
def test_update_environment():
    case_0 = update_environment()


# Generated at 2022-06-26 07:26:50.614270
# Unit test for function toggle_variable
def test_toggle_variable():
    assert toggle_variable() == None

# Generated at 2022-06-26 07:26:54.376290
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    load_plugin()
    assert wb.get_option("run.pgzero_mode") == False


if __name__ == "__main__":
    print(update_environment())

# Generated at 2022-06-26 07:27:49.474550
# Unit test for function load_plugin
def test_load_plugin():
    assert load_plugin() == None

# Generated at 2022-06-26 07:27:59.798996
# Unit test for function toggle_variable
def test_toggle_variable():
    assert toggle_variable() == get_workbench().set_default(_OPTION_NAME, False)
    assert toggle_variable() == get_workbench().add_command("toggle_pgzero_mode", "run", tr("Pygame Zero mode"), toggle_variable, flag_name=_OPTION_NAME, group=40)
    assert toggle_variable() == get_workbench().set_default(_OPTION_NAME, False)
    assert toggle_variable() == get_workbench().add_command("toggle_pgzero_mode", "run", tr("Pygame Zero mode"), toggle_variable, flag_name=_OPTION_NAME, group=40)
    assert toggle_variable() == get_workbench().set_default(_OPTION_NAME, False)

# Generated at 2022-06-26 07:28:05.632988
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench, thonny
    from thonny.misc_utils import running_on_mac_os, running_on_windows
    wb = get_workbench()
    prev_plugins = wb.get_loaded_plugin_names()
    load_plugin()
    assert wb.get_loaded_plugin_names() == prev_plugins + ['pgzero-mode']
    assert wb.get_option(_OPTION_NAME) is False


# Generated at 2022-06-26 07:28:08.782972
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    assert wb.get_default(_OPTION_NAME) == False
    assert wb.get_default(_OPTION_NAME) == False
    assert wb.get_default(_OPTION_NAME) == False



# Generated at 2022-06-26 07:28:09.527073
# Unit test for function update_environment
def test_update_environment():
    var_0 = update_environment()


# Generated at 2022-06-26 07:28:14.119903
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    var_1 = get_workbench().get_variable(_OPTION_NAME)
    assert var_1.get() == False
    toggle_variable()
    var_1 = get_workbench().get_variable(_OPTION_NAME)
    assert var_1.get() == True
    toggle_variable()
    var_1 = get_workbench().get_variable(_OPTION_NAME)
    assert var_1.get() == False

# Generated at 2022-06-26 07:28:22.465808
# Unit test for function toggle_variable
def test_toggle_variable():
    import os
    import pytest

    def test_return_value(expected, *args, **kwargs):
        get_workbench().set_option(_OPTION_NAME, expected)
        result = toggle_variable(*args, **kwargs)
        assert result
        assert not getattr(result, "__origin__", None)
        assert not getattr(result, "__args__", None)
        assert expected != get_workbench().get_option(_OPTION_NAME)
        assert expected == os.environ["PGZERO_MODE"]

    test_return_value(1, None)
    test_return_value(0, None)
    get_workbench().set_option(_OPTION_NAME, 1)
    test_return_value(0, None)

