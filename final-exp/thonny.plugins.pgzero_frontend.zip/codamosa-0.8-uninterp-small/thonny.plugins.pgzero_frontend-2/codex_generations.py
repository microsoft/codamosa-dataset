

# Generated at 2022-06-26 07:23:41.243938
# Unit test for function toggle_variable
def test_toggle_variable():

    # Create a workbench object
    workbench = get_workbench()

    # Add option _OPTION_NAME with value False
    workbench.set_default(_OPTION_NAME, False)

    # Get option _OPTION_NAME and store it in variable var_0
    var_0 = workbench.get_option(_OPTION_NAME)

    # Call function toggle_variable
    toggle_variable()

    # Get option _OPTION_NAME and store it in variable var_1
    var_1 = workbench.get_option(_OPTION_NAME)

    # Check if var_0 == var_1
    assert var_0 == var_1



# Generated at 2022-06-26 07:23:42.152378
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()


# Generated at 2022-06-26 07:23:43.201606
# Unit test for function update_environment
def test_update_environment():
    var_0 = update_environment()


# Generated at 2022-06-26 07:23:44.258549
# Unit test for function load_plugin
def test_load_plugin():
    assert load_plugin() == None


# Generated at 2022-06-26 07:23:45.313721
# Unit test for function update_environment
def test_update_environment():
    pass


# Generated at 2022-06-26 07:23:46.393987
# Unit test for function update_environment
def test_update_environment():
    update_environment()


# Generated at 2022-06-26 07:23:48.372170
# Unit test for function load_plugin
def test_load_plugin():
    # Init Thonny workbench
    get_workbench()
    # Test function
    load_plugin()
test_load_plugin()

# Generated at 2022-06-26 07:23:50.454022
# Unit test for function toggle_variable
def test_toggle_variable():
    print("Test case 0: ", end="")
    test_case_0()
    print("Done.")

if __name__ == "__main__":
    test_toggle_variable()

# Generated at 2022-06-26 07:23:51.157611
# Unit test for function toggle_variable
def test_toggle_variable():
    assert False

# Generated at 2022-06-26 07:23:53.312476
# Unit test for function update_environment
def test_update_environment():
    env = os.environ.copy()
    os.environ = {}
    var_0 = update_environment()
    os.environ = env

# Generated at 2022-06-26 07:23:57.179484
# Unit test for function update_environment
def test_update_environment():
    assert update_environment() == None


# Generated at 2022-06-26 07:24:04.574328
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = ""
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    os.environ["PGZERO_MODE"] = ""
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    os.environ["PGZERO_MODE"] = ""
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"



# Generated at 2022-06-26 07:24:06.811413
# Unit test for function load_plugin
def test_load_plugin():
    test_case_0()


if __name__ == "__main__":
    test_load_plugin()

# Generated at 2022-06-26 07:24:11.150526
# Unit test for function update_environment
def test_update_environment():
    # Case 0
    env_0 = os.environ["PGZERO_MODE"]
    os.environ["PGZERO_MODE"] = "auto"
    env_1 = os.environ["PGZERO_MODE"]
    assert env_0 != env_1


# Generated at 2022-06-26 07:24:22.140468
# Unit test for function toggle_variable
def test_toggle_variable():
    var_0 = load_plugin()
    var_1 = update_environment()
    var_2 = get_workbench().get_variable(_OPTION_NAME)
    var_3 = get_workbench().in_simple_mode()
    var_4 = get_workbench().set_default(_OPTION_NAME, False)
    var_5 = get_workbench().add_command("toggle_pgzero_mode", "run", tr("Pygame Zero mode"), toggle_variable, flag_name=_OPTION_NAME, group=40)
    var_6 = update_environment()
    var_7 = toggle_variable()
    var_8 = update_environment()
    var_9 = toggle_variable()
    var_10 = update_environment()
    var_11 = toggle_variable()
    var_12 = update_environment()


# Generated at 2022-06-26 07:24:24.453873
# Unit test for function update_environment
def test_update_environment():
    var_0 = get_workbench().get_option("run.pgzero_mode")
    var_1 = update_environment()



# Generated at 2022-06-26 07:24:38.131271
# Unit test for function toggle_variable
def test_toggle_variable():
    # Set value for toggle_variable()'s argument
    # If a parameter toggling function has been defined, use it
    # If a parameter has been defined but no toggling function, use a setter function to toggle value
    # Otherwise, use a simple variable assignment to toggle value

    # Get the current value of variable after calling function
    # If this is a parameter variable, get value from getter function
    # Otherwise, use variable directly
    var_0 = toggle_variable()
    assert var_0 == False

    # Set value for toggle_variable()'s argument
    # If a parameter toggling function has been defined, use it
    # If a parameter has been defined but no toggling function, use a setter function to toggle value
    # Otherwise, use a simple variable assignment to toggle value

    # Get the current value of variable after calling function
   

# Generated at 2022-06-26 07:24:40.929368
# Unit test for function toggle_variable
def test_toggle_variable():
    var = get_workbench().get_variable(_OPTION_NAME)
    var.set(False)
    assert var.get() == False
    toggle_variable()
    assert var.get() == True

# Generated at 2022-06-26 07:24:42.373016
# Unit test for function update_environment
def test_update_environment():
    assert update_environment() == None
    return

# Generated at 2022-06-26 07:24:44.362338
# Unit test for function update_environment
def test_update_environment():
    var_0 = update_environment()
    assert var_0 == None


# Generated at 2022-06-26 07:24:58.270992
# Unit test for function toggle_variable
def test_toggle_variable():
    # Testing when the option _OPTION_NAME is the same as the param flag_name
    _OPTION_NAME = "flag_name"
    get_workbench().set_option(_OPTION_NAME, False)
    assert get_workbench().get_option(_OPTION_NAME) == False
    get_workbench().set_option(_OPTION_NAME, True)
    assert get_workbench().get_option(_OPTION_NAME) == True
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == False
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True



# Generated at 2022-06-26 07:25:00.273925
# Unit test for function update_environment
def test_update_environment():
    var = get_workbench().get_variable(_OPTION_NAME)
    var.set(False)
    update_environment()

# Generated at 2022-06-26 07:25:02.600144
# Unit test for function toggle_variable
def test_toggle_variable():
    try:
        print("Case 0")
        test_case_0()
    except Exception as e:
        print("Error: " + str(e))
        assert False


# Generated at 2022-06-26 07:25:03.455918
# Unit test for function update_environment
def test_update_environment():
    assert update_environment()


# Generated at 2022-06-26 07:25:04.287344
# Unit test for function load_plugin
def test_load_plugin():
    test_case_0()

# Generated at 2022-06-26 07:25:06.402411
# Unit test for function update_environment
def test_update_environment():
    update_environment()


# Generated at 2022-06-26 07:25:16.586428
# Unit test for function toggle_variable
def test_toggle_variable():
    assert "pgzrun" in var_0

#print("\nFunction toggle_variable output:\n", var_0)
print("\nFunction toggle_variable output:\n")
print("pgzrun")

# Generated at 2022-06-26 07:25:21.693886
# Unit test for function update_environment
def test_update_environment():
    import os
    old_environ = os.environ
    # Set environment variable
    os.environ = {'PGZERO_MODE': 'False'}
    # Call function
    update_environment()
    assert os.getenv('PGZERO_MODE') == 'False'
    # Restore environment variable
    os.environ = old_environ

# Generated at 2022-06-26 07:25:25.447467
# Unit test for function load_plugin
def test_load_plugin():
    # Arrange
    var_0 = load_plugin()
    # Act
    # Assert

# Generated at 2022-06-26 07:25:28.183429
# Unit test for function toggle_variable
def test_toggle_variable():
    os.environ["PGZERO_MODE"] = "auto"
    assert os.environ["PGZERO_MODE"] == "auto"



# Generated at 2022-06-26 07:25:40.951293
# Unit test for function update_environment
def test_update_environment():
    assert update_environment()
    assert update_environment()
    assert update_environment()

# Generated at 2022-06-26 07:25:42.769606
# Unit test for function update_environment
def test_update_environment():
    test_case_0()


if __name__ == "__main__":
    # test_update_environment()
    test_case_0()

# Generated at 2022-06-26 07:25:43.806331
# Unit test for function toggle_variable
def test_toggle_variable():
    assert (toggle_variable() == None)


# Generated at 2022-06-26 07:25:49.980760
# Unit test for function load_plugin
def test_load_plugin():
    import thonny
    thonny.plugins.load_plugin("ThonnyPlugins.pgzero_mode")
    import thonny.plugins.pgzero_mode

    # Insert your test code here
    assert thonny.plugins.pgzero_mode._OPTION_NAME == "run.pgzero_mode"


# Generated at 2022-06-26 07:25:57.341927
# Unit test for function update_environment
def test_update_environment():
    # Case for running script with environment variable PGZERO_MODE
    os.environ["PGZERO_MODE"] = 1
    var_1 = update_environment()
    assert os.environ["PGZERO_MODE"] == 1

    # Case for running script with environment variable PGZERO_MODE
    os.environ["PGZERO_MODE"] = 0
    var_2 = update_environment()
    assert os.environ["PGZERO_MODE"] == 0

    # Case for running script with environment variable PGZERO_MODE
    os.environ["PGZERO_MODE"] = ""
    var_3 = update_environment()
    assert os.environ["PGZERO_MODE"] == ""

# Generated at 2022-06-26 07:25:58.764239
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()

# Generated at 2022-06-26 07:26:06.231050
# Unit test for function toggle_variable
def test_toggle_variable():
    """
    # Tests if variable is False, True, False and True after toggle_variable is called
    # variable is 'PGZERO_MODE' and can be seen in os.environ variable
    """
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "False"
    toggle_variable()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-26 07:26:07.819699
# Unit test for function update_environment
def test_update_environment():
    update_environment()


test_case_0()
test_update_environment()
update_environment()

# Generated at 2022-06-26 07:26:09.600485
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert(1 == 1)


if __name__ == "__main__":
    test_load_plugin()

# Generated at 2022-06-26 07:26:10.672772
# Unit test for function toggle_variable
def test_toggle_variable():
    exec(test_case_0.__doc__)


# Generated at 2022-06-26 07:26:35.228959
# Unit test for function toggle_variable
def test_toggle_variable():
    test_case_0()
    assert False


# Generated at 2022-06-26 07:26:44.785131
# Unit test for function load_plugin
def test_load_plugin():
    try:
        plugin_dir = get_workbench().get_plugin_dir("thonny-pgzero")
        main_dir = os.path.dirname(plugin_dir)
        sys.path.insert(0, main_dir)

        load_plugin()
        assert get_workbench().get_option("run.pgzero_mode") == False, 'Current value of run.pgzero_mode is "False"'
        assert os.environ["PGZERO_MODE"] == "False", 'Current value of os.environ["PGZERO_MODE"] is "False"'
    finally:
        sys.path.remove(main_dir)



# Generated at 2022-06-26 07:26:47.148502
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = get_workbench().get_option(_OPTION_NAME)
    test_0 = update_environment()


# Generated at 2022-06-26 07:26:47.797817
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()

# Generated at 2022-06-26 07:26:50.763097
# Unit test for function toggle_variable
def test_toggle_variable():
    old_value = get_workbench().get_variable(_OPTION_NAME)
    toggle_variable()
    returned_value = get_workbench().get_variable(_OPTION_NAME)
    assert old_value != returned_value


# Generated at 2022-06-26 07:26:51.512302
# Unit test for function update_environment
def test_update_environment():
    var_0 = update_environment()

# Generated at 2022-06-26 07:26:52.786808
# Unit test for function toggle_variable
def test_toggle_variable():
    test = False
    test_case_0()

# Generated at 2022-06-26 07:26:54.502982
# Unit test for function load_plugin
def test_load_plugin():
    test_load_plugin_0()



# Generated at 2022-06-26 07:26:55.007148
# Unit test for function toggle_variable
def test_toggle_variable():
    pass


# Generated at 2022-06-26 07:26:57.343665
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = "auto"
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"


# Generated at 2022-06-26 07:27:48.301351
# Unit test for function load_plugin
def test_load_plugin():
    test_case_0()


# Generated at 2022-06-26 07:27:51.313078
# Unit test for function toggle_variable
def test_toggle_variable():
    if var_0 == True:
        print("Variable is now True")
    else:
        print("Variable is now False")


# Generated at 2022-06-26 07:27:52.151377
# Unit test for function toggle_variable
def test_toggle_variable():
    assert toggle_variable() == None


# Generated at 2022-06-26 07:27:53.640571
# Unit test for function update_environment
def test_update_environment():
    assert update_environment() == None



# Generated at 2022-06-26 07:27:59.760577
# Unit test for function toggle_variable
def test_toggle_variable():
    var = {"_get_command": None}

    def mock_get_command(self, command_name):
        var["_get_command"] = command_name
        return True, "true()"
    setattr(get_workbench(), "get_command", mock_get_command)

    assert var["_get_command"] == None

    toggle_variable()
    assert var["_get_command"] == "toggle_pgzero_mode"
    assert var["_get_command"] != None



# Generated at 2022-06-26 07:28:00.570306
# Unit test for function update_environment
def test_update_environment():
    var_0 = update_environment()

# Generated at 2022-06-26 07:28:01.728497
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()


# Generated at 2022-06-26 07:28:03.934576
# Unit test for function update_environment
def test_update_environment():
    assert update_environment() == None


if __name__ == "__main__":
    # Test for case 0
    test_case_0()

    # Unit test for function update_environment
    test_update_environment()

# Generated at 2022-06-26 07:28:04.760896
# Unit test for function toggle_variable
def test_toggle_variable():
    assert toggle_variable() == None


# Generated at 2022-06-26 07:28:05.558254
# Unit test for function update_environment
def test_update_environment():
    assert update_environment() == None

# Generated at 2022-06-26 07:30:11.110810
# Unit test for function update_environment
def test_update_environment():
    var_0 = update_environment()


# Generated at 2022-06-26 07:30:11.835345
# Unit test for function update_environment
def test_update_environment():
    assert update_environment() is None

# Generated at 2022-06-26 07:30:13.028231
# Unit test for function toggle_variable
def test_toggle_variable():
# Arrange
    result = toggle_variable()
    assert result is None


# Generated at 2022-06-26 07:30:13.980671
# Unit test for function load_plugin
def test_load_plugin():
    var_0 = load_plugin()

# Generated at 2022-06-26 07:30:22.741997
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.clear_all_variables()
    wb.delete_all_commands()
    load_plugin()
    assert ('toggle_pgzero_mode', 'run', 'Pygame Zero mode') in [
        (c.name, c.category, c.description) for c in get_workbench().get_commands()
    ], 'command "toggle_pgzero_mode" not in command list'
    assert not get_workbench().in_simple_mode(), 'in_simple_mode() not False'
    assert not get_workbench().get_option(_OPTION_NAME), 'get_option(_OPTION_NAME) not False'


# Generated at 2022-06-26 07:30:23.551335
# Unit test for function update_environment
def test_update_environment():
    update_environment()


# Generated at 2022-06-26 07:30:24.314384
# Unit test for function update_environment
def test_update_environment():
    update_environment()


# Generated at 2022-06-26 07:30:24.795685
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()

# Generated at 2022-06-26 07:30:29.384790
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()
    # pass


# Generated at 2022-06-26 07:30:31.927329
# Unit test for function update_environment
def test_update_environment():
    try:
        env_var_0 = update_environment()
        assert env_var_0 == "auto"
    except AssertionError:
        raise AssertionError


if __name__ == "__main__":
    test_case_0()
    test_update_environment()