

# Generated at 2022-06-26 07:23:06.365733
# Unit test for function update_environment
def test_update_environment():
    update_environment()

# Generated at 2022-06-26 07:23:08.382623
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    var_0 = os.environ.get("PGZERO_MODE")
    check_result_0 = "auto"
    assert var_0 == check_result_0


# Generated at 2022-06-26 07:23:09.164680
# Unit test for function update_environment
def test_update_environment():
    update_environment()

# Generated at 2022-06-26 07:23:18.291195
# Unit test for function update_environment
def test_update_environment():
    update_environment()


# Integration tests for toggle_variable and update_environment
# def test_case_1():
#     var_0 = toggle_variable()
#     var_1 = update_environment()
#     assert var_0 == var_1, 'toggle_variable and update_environment must return True if the PGZERO_MODE is enabled, and must return False if the PGZERO_MODE is disabled'


# def test_case_2():
#     var_0 = toggle_variable()
#     var_1 = update_environment()
#     assert var_0 == var_1, 'toggle_variable and update_environment must return True if the PGZERO_MODE is enabled, and must return False if the PGZERO_MODE is disabled'


# def test_case_3():
#     var_0 = toggle_variable()
#    

# Generated at 2022-06-26 07:23:23.090800
# Unit test for function toggle_variable
def test_toggle_variable():
    w = get_workbench()
    w.set_default('run.pgzero_mode',True)
    assert w.get_option('run.pgzero_mode') == True
    w.get_variable(_OPTION_NAME).set(False)
    toggle_variable()
    assert w.get_option('run.pgzero_mode')== True
    toggle_variable()
    assert w.get_option('run.pgzero_mode')== False

# Generated at 2022-06-26 07:23:24.340589
# Unit test for function toggle_variable
def test_toggle_variable():
    assert toggle_variable() is None

# Generated at 2022-06-26 07:23:25.649842
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()

# Generated at 2022-06-26 07:23:27.704064
# Unit test for function toggle_variable
def test_toggle_variable():
    # The first case
    test_case_0()
    # The rest cases



# Generated at 2022-06-26 07:23:29.085848
# Unit test for function update_environment
def test_update_environment():
    var_0 = update_environment()


# Generated at 2022-06-26 07:23:40.102901
# Unit test for function toggle_variable
def test_toggle_variable():
    update_environment()
    from thonny import get_workbench
    from thonny.common import InlineCommand
    from thonny.plugins.run import _OPTION_NAME
    import os

    if get_workbench().in_simple_mode():
        os.environ["PGZERO_MODE"] = "auto"
    else:
        os.environ["PGZERO_MODE"] = str(get_workbench().get_option(_OPTION_NAME))

    toggle_variable()
    assert os.environ["PGZERO_MODE"] == str(get_workbench().get_option(_OPTION_NAME))
    assert get_workbench().get_variable(_OPTION_NAME).get() is True
    toggle_variable()

# Generated at 2022-06-26 07:23:52.227497
# Unit test for function toggle_variable
def test_toggle_variable():
    import thonny
    from thonny.plugins.runpgzero_mode.pgzero_mode import toggle_variable

    thonny.plugins.runpgzero_mode.pgzero_mode.update_environment()
    test_case_0()

# Generated at 2022-06-26 07:23:54.006294
# Unit test for function toggle_variable
def test_toggle_variable():
    assert var_0 == get_workbench().get_variable(_OPTION_NAME)


# Generated at 2022-06-26 07:23:55.124689
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()


# Generated at 2022-06-26 07:24:03.075310
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    var_0 = get_workbench().get_variable(_OPTION_NAME)
    var_1 = get_workbench().get_variable(_OPTION_NAME)
    var_2 = get_workbench().get_option(_OPTION_NAME)
    print(var_0, var_1, var_2)
    assert (
        var_0 == get_workbench()
    ), "The assert statement is supposed to pass for this test."


# Generated at 2022-06-26 07:24:06.240075
# Unit test for function update_environment
def test_update_environment():
    var_0 = update_environment()
    assert var_0 == None

# Generated at 2022-06-26 07:24:15.346276
# Unit test for function update_environment

# Generated at 2022-06-26 07:24:18.332736
# Unit test for function update_environment
def test_update_environment():
    test_case = update_environment()


# Generated at 2022-06-26 07:24:23.654938
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = "auto"
    update_environment()
    # We cannot perform an assert on os.environ as we cannot set it back to auto later
    # assert os.environ["PGZERO_MODE"] == "auto"


# Generated at 2022-06-26 07:24:29.419073
# Unit test for function load_plugin
def test_load_plugin():
    # Empty
    assert load_plugin()


# Generated at 2022-06-26 07:24:30.520192
# Unit test for function toggle_variable
def test_toggle_variable():
    assert toggle_variable()


# Generated at 2022-06-26 07:24:43.946878
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()

# Generated at 2022-06-26 07:24:45.101923
# Unit test for function update_environment
def test_update_environment():
    var_0 = update_environment()

# Generated at 2022-06-26 07:24:51.245588
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert get_workbench().in_simple_mode() != get_workbench().get_option(_OPTION_NAME)
    assert not get_workbench().get_option(_OPTION_NAME)
    assert get_workbench().get_variable(_OPTION_NAME)
    assert get_workbench().get_option(_OPTION_NAME) in [True, False]



# Generated at 2022-06-26 07:24:53.501351
# Unit test for function toggle_variable
def test_toggle_variable():
    try:
        output = toggle_variable()
    except Exception:
        output = None
    assert output is not None


# Generated at 2022-06-26 07:24:55.490191
# Unit test for function update_environment
def test_update_environment():
    print('\n# Unit test for function update_environment')
    var_0 = update_environment()
    assert var_0 == None


# Generated at 2022-06-26 07:24:58.173205
# Unit test for function toggle_variable
def test_toggle_variable():
    orig_env = os.environ.get("PGZERO_MODE")
    os.environ["PGZERO_MODE"] = "auto"
    test_case_0()
    os.environ["PGZERO_MODE"] = orig_env

# Generated at 2022-06-26 07:25:06.418945
# Unit test for function toggle_variable
def test_toggle_variable():
    assert var_0 == False
    toggle_variable()
    assert var_0 == True

# Generated at 2022-06-26 07:25:07.241468
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()


# Generated at 2022-06-26 07:25:12.108617
# Unit test for function update_environment
def test_update_environment():
    """Test thonny.plugins.pgzero.update_environment function."""

    environ = dict()

    update_environment()

    # expected environment:
    # {'PGZERO_MODE': 'False'}
    environ.update({"PGZERO_MODE": "False"})

    assert os.environ == environ
    # TODO: add more tests

# Generated at 2022-06-26 07:25:14.851306
# Unit test for function update_environment
def test_update_environment():
    expected = 'auto'
    os.environ['PGZERO_MODE'] = 'auto'
    actual = update_environment()
    assert expected == actual

# Generated at 2022-06-26 07:25:30.010348
# Unit test for function toggle_variable
def test_toggle_variable():
    # Setup the environment
    env = get_workbench()
    var = get_workbench().get_variable(_OPTION_NAME)
    var.set(True)
    # Run the code
    toggle_variable()
    # Check for the expected results
    assert not var.get(), "Unexpected output"


# Generated at 2022-06-26 07:25:31.414464
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()


# Generated at 2022-06-26 07:25:42.195045
# Unit test for function load_plugin
def test_load_plugin():
    unit_test = get_workbench()
    unit_test.set_default(_OPTION_NAME, True)
    unit_test.add_command("toggle_pgzero_mode", "run", tr("Pygame Zero mode"), toggle_variable, flag_name=_OPTION_NAME, group=40)
    unit_test.in_simple_mode = lambda : False
    unit_test.get_option = lambda option, default=None : True
    os.environ["PGZERO_MODE"] = "True"
    # Calling unit test function
    load_plugin()
    # Testing if set_option() is called
    assert unit_test.get_option("run.pgzero_mode") == True, "Expected True, Received: " + str(unit_test.get_option("run.pgzero_mode"))
    # Testing if get

# Generated at 2022-06-26 07:25:43.573914
# Unit test for function load_plugin
def test_load_plugin():
   assert load_plugin()


# Generated at 2022-06-26 07:25:49.413510
# Unit test for function load_plugin
def test_load_plugin():
    workbench = get_workbench()
    workbench.destroy()
    workbench.__init__()
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert os.environ["PGZERO_MODE"] == "False"



# Generated at 2022-06-26 07:25:52.125872
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench

    wb = Workbench()
    load_plugin()
    assert wb._get_command(_OPTION_NAME) is not None
    wb.destroy()

# Generated at 2022-06-26 07:25:53.041510
# Unit test for function toggle_variable
def test_toggle_variable():
    var_0 = toggle_variable()


# Generated at 2022-06-26 07:25:54.343053
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()


# Generated at 2022-06-26 07:25:55.585195
# Unit test for function update_environment
def test_update_environment():
    assert update_environment() == None

# Generated at 2022-06-26 07:25:57.495436
# Unit test for function toggle_variable
def test_toggle_variable():
    if(toggle_variable()):
        print("Passed")
    else:
        print("Failed")

# Generated at 2022-06-26 07:26:21.557258
# Unit test for function update_environment
def test_update_environment():
    var_0 = update_environment()


# Generated at 2022-06-26 07:26:22.164732
# Unit test for function update_environment
def test_update_environment():
    assert update_environment() == None


# Generated at 2022-06-26 07:26:24.013807
# Unit test for function toggle_variable
def test_toggle_variable():
    command_0 = get_workbench().get_command("toggle_pgzero_mode")
    # command_0.invoke()

# Generated at 2022-06-26 07:26:31.896500
# Unit test for function toggle_variable
def test_toggle_variable():
    """Unit test for function toggle_variable
    ----------
    set flag ON
    False
    set flag ON
    True
    set flag ON
    False
    set flag ON
    True
    """
    get_workbench().set_option(_OPTION_NAME, False)

    flag_0 = toggle_variable()
    print(flag_0)
    assert flag_0 == False

    flag_0 = toggle_variable()
    print(flag_0)
    assert flag_0 == True

    flag_0 = toggle_variable()
    print(flag_0)
    assert flag_0 == False

    flag_0 = toggle_variable()
    print(flag_0)
    assert flag_0 == True


# Generated at 2022-06-26 07:26:35.376176
# Unit test for function update_environment
def test_update_environment():
    old_var = os.environ["PGZERO_MODE"]
    os.environ["PGZERO_MODE"] = "auto"
    update_environment()
    os.environ["PGZERO_MODE"] = old_var



# Generated at 2022-06-26 07:26:39.945051
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    load_plugin()

# Generated at 2022-06-26 07:26:41.099522
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()


# Generated at 2022-06-26 07:26:42.335722
# Unit test for function update_environment
def test_update_environment():
    assert update_environment() == None


# Generated at 2022-06-26 07:26:47.189497
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, True)
    assert get_workbench().get_variable(_OPTION_NAME).get() == True
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == True

# Generated at 2022-06-26 07:26:48.162113
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()


# Generated at 2022-06-26 07:27:48.448874
# Unit test for function toggle_variable
def test_toggle_variable():
    import unittest
    from unittest.mock import patch
    from thonny.plugins.pgzero_mode import pgzero_mode

    class TestToggleVariable(unittest.TestCase):
        """Class for testing toggle_variable function"""
        @classmethod
        def setUp(cls):
            get_workbench().set_default(_OPTION_NAME, False)

        @patch("pgzero_mode.get_workbench", return_value=get_workbench())
        def test_when_pgzero_mode_is_false(self, mock_get_workbench):
            """When pgzero_mode is false"""
            mock_get_workbench.assert_called_once()
            pgzero_mode.toggle_variable()
            assert get_workbench().get_option(_OPTION_NAME) == True
           

# Generated at 2022-06-26 07:27:50.735784
# Unit test for function update_environment
def test_update_environment():
    env = update_environment()
    assert env["PGZERO_MODE"] == "auto"


# Generated at 2022-06-26 07:27:54.107816
# Unit test for function update_environment
def test_update_environment():
    x = get_workbench().in_simple_mode()
    x = get_workbench().get_option(_OPTION_NAME)
    assert 'PGZERO_MODE' in os.environ


# Generated at 2022-06-26 07:27:54.886466
# Unit test for function update_environment
def test_update_environment():
    var_0 = update_environment()


# Generated at 2022-06-26 07:27:56.593164
# Unit test for function load_plugin
def test_load_plugin():
    assert get_workbench().get_variable(_OPTION_NAME) == False



# Generated at 2022-06-26 07:28:02.226746
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    var = get_workbench().get_variable(_OPTION_NAME)
    var.set(0)
    var_0 = var.get()
    assert var_0 == 0

    toggle_variable()
    var_1 = var.get()
    assert var_1 == 1

    toggle_variable()
    var_2 = var.get()
    assert var_2 == 0

# Generated at 2022-06-26 07:28:03.560582
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    #assert test_case_0


# Generated at 2022-06-26 07:28:07.915837
# Unit test for function toggle_variable
def test_toggle_variable():
    import unittest
    import thonny
    from thonny.languages import tr

    thonny.set_simple_mode(False)
    thonny.set_workbench_option("run.pgzero_mode", False)

    toggle_variable()

    # Check post-condition: var_0 == True
    if var_0 == True:
        pass
    else:
        unittest.TestCase.fail("")



# Generated at 2022-06-26 07:28:08.862885
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()


# Generated at 2022-06-26 07:28:11.272184
# Unit test for function update_environment
def test_update_environment():
    try:
        print (os.environ["PGZERO_MODE"])
    except KeyError:
        assert True
    else:
        assert False

    update_environment()

    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-26 07:30:16.099355
# Unit test for function toggle_variable
def test_toggle_variable():
    assert toggle_variable() == None



# Generated at 2022-06-26 07:30:25.326694
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_shell
    from thonny.shell import ShellTextWidget
    from thonny.running import get_interpreter
    from thonny import ui_utils

    def test_func_0():
        get_shell().perform_command("import os")
        get_shell().perform_command("os.environ['PGZERO_MODE']")

    def test_func_1():
        return get_shell().text_widget.tag_ranges("stdout_tag")

    load_plugin()
    test_func_0()
    ui_utils.simulate_key_press(get_shell().text_widget, "<F8>")
    test_func_0()
    ui_utils.simulate_key_press(get_shell().text_widget, "<F9>")


# Generated at 2022-06-26 07:30:27.922864
# Unit test for function update_environment
def test_update_environment():
    testVal = "0"
    os.environ['PGZERO_MODE'] = testVal
    update_environment()
    checkVal = os.environ.get('PGZERO_MODE')
    assert(checkVal == testVal)

# Generated at 2022-06-26 07:30:29.477731
# Unit test for function update_environment
def test_update_environment():
    var_0 = update_environment()


# Generated at 2022-06-26 07:30:30.090167
# Unit test for function toggle_variable
def test_toggle_variable():
    var_0 = False
    var_0 = True


# Generated at 2022-06-26 07:30:32.897296
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()

# Generated at 2022-06-26 07:30:34.901062
# Unit test for function toggle_variable
def test_toggle_variable():
    print("Test of function toggle_variable in module pgzero_mode")


# Generated at 2022-06-26 07:30:36.120985
# Unit test for function update_environment
def test_update_environment():
    update_environment()



# Generated at 2022-06-26 07:30:36.871231
# Unit test for function update_environment
def test_update_environment():
    update_environment()
    return True


# Generated at 2022-06-26 07:30:40.065477
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().set_option(_OPTION_NAME, "True")
    output = update_environment()
    assert output == None
