

# Generated at 2022-06-26 07:23:31.685383
# Unit test for function load_plugin
def test_load_plugin():
    pass

# Generated at 2022-06-26 07:23:36.182498
# Unit test for function update_environment
def test_update_environment():
    # Assumes that the environment variable PGZERO_MODE has not been set
    var_0 = update_environment()
    assert os.environ['PGZERO_MODE'] == '0'



# Generated at 2022-06-26 07:23:41.766896
# Unit test for function load_plugin
def test_load_plugin():
    wb = MockWorkbench()
    wb.set_option("run.pgzero_mode", False)
    load_plugin()
    assert (wb.get_option("run.pgzero_mode") == False)
    assert (wb.get_command("toggle_pgzero_mode").name == "toggle_pgzero_mode")
    assert (wb.get_command("toggle_pgzero_mode").group == 40)
# def load_plugin():
#     get_workbench().set_default(_OPTION_NAME, False)
#     get_workbench().add_command(
#         "toggle_pgzero_mode",
#         "run",
#         tr("Pygame Zero mode"),
#         toggle_variable,
#         flag_name=_OPTION_NAME,
#         group=40,
#     )
#    

# Generated at 2022-06-26 07:23:45.602043
# Unit test for function toggle_variable
def test_toggle_variable():
    var_0 = 0
    var_1 = 1
    if (var_0 < 1) and (var_1 == 0):
        var_0 = var_1
    assert var_0 == 0
    var_0 = toggle_variable()


# Generated at 2022-06-26 07:23:47.431587
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    pass # Function load_plugin already has a test (test_load_plugin)


# Generated at 2022-06-26 07:23:52.101549
# Unit test for function update_environment
def test_update_environment():
    env = {}

    def mock_get_workbench():
        w = MagicMock()
        w.in_simple_mode.return_value = False
        w.get_option.return_value = True
        return w

    with patch.dict(os.environ, env), patch("thonny.plugins.pgzeroplugin.get_workbench", mock_get_workbench):
        update_environment()
        assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-26 07:23:53.101173
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()


# Generated at 2022-06-26 07:23:57.861260
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.add_command("toggle_pgzero_mode", "run", tr("Pygame Zero mode"), toggle_variable, flag_name=_OPTION_NAME, group=40)
    update_environment()

# Generated at 2022-06-26 07:24:07.073455
# Unit test for function update_environment
def test_update_environment():
    set_simple_mode(True)
    os.environ['PGZERO_MODE'] = 'False'
    update_environment()

# Generated at 2022-06-26 07:24:09.024662
# Unit test for function update_environment
def test_update_environment():
    # assert {"PGZERO_MODE": "False"} == os.environ
    pass



# Generated at 2022-06-26 07:24:17.447225
# Unit test for function toggle_variable
def test_toggle_variable():
    var_0 = get_workbench().get_variable(_OPTION_NAME)

    var_0.set(True)
    toggle_variable()
    assert var_0.get() == False

    var_0.set(False)
    toggle_variable()
    assert var_0.get() == True

# Generated at 2022-06-26 07:24:19.166545
# Unit test for function load_plugin
def test_load_plugin():
    global get_workbench
    get_workbench = MagicMock()

# Generated at 2022-06-26 07:24:21.898865
# Unit test for function load_plugin
def test_load_plugin():
    try:
        load_plugin()
    except:
        raise AssertionError("cannot load plugin")


# Generated at 2022-06-26 07:24:23.751635
# Unit test for function toggle_variable
def test_toggle_variable():
    pass  # TODO: Implement test



# Generated at 2022-06-26 07:24:28.872711
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()


# Generated at 2022-06-26 07:24:35.596423
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_simple_mode(False)
    assert update_environment() == None
    get_workbench().set_simple_mode(True)
    assert update_environment() == None

if __name__ == "__main__":
    # Alternative: use python -m pytest src/thonnyplugins/pgzeroplugin/tests.py
    import pytest
    pytest.main(["src/thonnyplugins/pgzeroplugin/tests.py"])

# Generated at 2022-06-26 07:24:42.639689
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    update_environment()
    var_1 = os.environ["PGZERO_MODE"]
    del os.environ["PGZERO_MODE"]
    wb.in_simple_mode = True
    update_environment()
    var_2 = os.environ["PGZERO_MODE"]
    os.environ["PGZERO_MODE"] = var_1
    wb.in_simple_mode = False
    update_environment()
    var_3 = os.environ["PGZERO_MODE"]
    os.environ["PGZERO_MODE"] = var_2
    wb.in_simple_mode = True
    update_environment()

# Generated at 2022-06-26 07:24:47.684887
# Unit test for function update_environment
def test_update_environment():
    if get_workbench().in_simple_mode():
        os.environ["PGZERO_MODE"] = "auto"
    else:
        os.environ["PGZERO_MODE"] = str(get_workbench().get_option(_OPTION_NAME))


# Generated at 2022-06-26 07:24:49.336693
# Unit test for function update_environment
def test_update_environment():
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-26 07:24:50.223087
# Unit test for function update_environment
def test_update_environment():
    update_environment()



# Generated at 2022-06-26 07:24:58.312085
# Unit test for function load_plugin
def test_load_plugin():
    """
    Checks whether load_plugin causes any error or exceptions

    """
    try:
        load_plugin()
    except Exception:
        assert False

# Generated at 2022-06-26 07:24:59.968659
# Unit test for function toggle_variable
def test_toggle_variable():
    # init

    # execute
    toggle_variable()

    # verify
    assert True


# Generated at 2022-06-26 07:25:03.936802
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.reset_test_data()
    load_plugin()
    
    # test for function 'toggle_variable'
    for i in range(2):
        try:
            test_case_0()
        except:
            wb.reset_test_data()


# Generated at 2022-06-26 07:25:11.138356
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    expected_0 = "False"
    result_0 = os.environ["PGZERO_MODE"]
    assert expected_0 == result_0

    get_workbench().set_default(_OPTION_NAME, True)
    update_environment()
    expected_1 = "True"
    result_1 = os.environ["PGZERO_MODE"]
    assert expected_1 == result_1

# Generated at 2022-06-26 07:25:11.792647
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()

# Generated at 2022-06-26 07:25:14.076366
# Unit test for function load_plugin
def test_load_plugin():
    assert (
        load_plugin()
        == None
    ), "Failed to load plugin, check if all the modules are installed"


# Generated at 2022-06-26 07:25:15.774856
# Unit test for function update_environment
def test_update_environment():
    # No test case is defined for the function
    pass


# Generated at 2022-06-26 07:25:17.709889
# Unit test for function toggle_variable
def test_toggle_variable():
    try:
        # Case 0
        test_case_0()
    except:
        assert False, "Unhandled exception"


# Generated at 2022-06-26 07:25:21.751255
# Unit test for function update_environment
def test_update_environment():
    if get_workbench().in_simple_mode():
        os.environ["PGZERO_MODE"] = "auto"
    else:
        os.environ["PGZERO_MODE"] = str(get_workbench().get_option(_OPTION_NAME))


# Generated at 2022-06-26 07:25:24.293948
# Unit test for function update_environment
def test_update_environment():
    assert update_environment() is None

# Generated at 2022-06-26 07:25:36.999228
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    pass



# Generated at 2022-06-26 07:25:37.890840
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()

# Generated at 2022-06-26 07:25:42.272768
# Unit test for function update_environment
def test_update_environment():
    from thonny import get_workbench
    update_environment()
    # get_workbench().builtins
    assert get_workbench().builtins.get("PGZERO_MODE") == str(get_workbench().get_option("run.pgzero_mode")), "Function test_update_environment did not return expected result"

# Generated at 2022-06-26 07:25:43.248780
# Unit test for function update_environment
def test_update_environment():
    pass

# Generated at 2022-06-26 07:25:44.368057
# Unit test for function load_plugin
def test_load_plugin():
    assert (load_plugin()) is None

# Generated at 2022-06-26 07:25:55.593433
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench

    class Workbench_0(Workbench):
        def __init__(self):
            Workbench.__init__(self)
            self.default_browser_path = ''
            self.get_option = ''
            self.in_simple_mode = False
            self.last_page = 0

    class Variable_0():
        def __init__(self):
            self.get = ''

    wb_0 = Workbench_0()
    var_0 = Variable_0()
    wb_0.get_variable = lambda: var_0
    var_0.set = lambda: None
    load_plugin()


# Generated at 2022-06-26 07:25:59.513838
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert pgzero_mode.update_environment() == None
    assert pgzero_mode.load_plugin() == None
    assert pgzero_mode.toggle_variable() == None

# Generated at 2022-06-26 07:26:01.622602
# Unit test for function toggle_variable
def test_toggle_variable():
    # case - 0
    # Function call
    res = toggle_variable()
    # Function return check (None)
    assert res is None



# Generated at 2022-06-26 07:26:03.119510
# Unit test for function load_plugin
def test_load_plugin():
    assert get_workbench().in_simple_mode() == False

# Generated at 2022-06-26 07:26:03.701417
# Unit test for function update_environment
def test_update_environment():
    update_environment()

# Generated at 2022-06-26 07:26:29.110025
# Unit test for function update_environment
def test_update_environment():
    var_0 = update_environment()


# Generated at 2022-06-26 07:26:30.071992
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()


# Generated at 2022-06-26 07:26:30.673469
# Unit test for function update_environment
def test_update_environment():
    assert update_environment()

# Generated at 2022-06-26 07:26:31.237392
# Unit test for function update_environment
def test_update_environment():
    var_0 = update_environment()

# Generated at 2022-06-26 07:26:32.570125
# Unit test for function toggle_variable
def test_toggle_variable():
    assert callable(toggle_variable)
    assert isinstance(toggle_variable(), None.__class__)


# Generated at 2022-06-26 07:26:36.442359
# Unit test for function load_plugin
def test_load_plugin():
    with patch("thonny.plugins.pgzero_mode.get_workbench", return_value=MagicMock()):
        load_plugin()
        assert get_workbench().set_default.called


# Generated at 2022-06-26 07:26:37.903842
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = "auto"
    update_environment()

# Generated at 2022-06-26 07:26:44.784663
# Unit test for function update_environment
def test_update_environment():
    # Get the variables that are set by the update_environment function
    var_0 = os.environ["PGZERO_MODE"] 
    get_workbench().set_variable(_OPTION_NAME, True) 
    update_environment()
    var_1 = os.environ["PGZERO_MODE"] 

if __name__ == "__main__":
    test_case_0()
    test_update_environment()

# Generated at 2022-06-26 07:26:45.693495
# Unit test for function load_plugin
def test_load_plugin():
    pass



# Generated at 2022-06-26 07:26:54.167399
# Unit test for function load_plugin
def test_load_plugin():
    global test_case_0
    
    import thonny
    thonny.workbench.set_option("run.pgzero_mode", True)
    load_plugin()
    thonny.workbench.set_option("run.pgzero_mode", None)
    load_plugin()
    try:
        thonny.workbench.set_option("run.pgzero_mode", "str")
        load_plugin()
    except Exception as e:
        print("Exception was raised: ", type(e))
        print("Arguments were: ", e.args)
    thonny.workbench.set_option("run.pgzero_mode", True)
    load_plugin()
    thonny.workbench.set_option("run.pgzero_mode", False)
    load_plugin()

# Generated at 2022-06-26 07:27:54.973433
# Unit test for function load_plugin
def test_load_plugin():
    try:
        from unittest.mock import Mock
    except ImportError:
        from mock import Mock  # python < 3.3
    wb_mock = get_workbench.get_workbench = Mock()
    load_plugin()
    wb_mock.assert_called_once_with()
    wb_mock.return_value.set_default.assert_called_once_with('run.pgzero_mode', False)
    wb_mock.return_value.add_command.assert_called_once_with(
        'toggle_pgzero_mode', 'run', 'Pygame Zero mode', toggle_variable,
        flag_name='run.pgzero_mode', group=40
    )
    wb_mock.return_value.in_simple_mode.assert_called_once_with

# Generated at 2022-06-26 07:27:56.097113
# Unit test for function load_plugin
def test_load_plugin():
    var_0 = load_plugin()
    assert var_0 == None

# Generated at 2022-06-26 07:27:59.447942
# Unit test for function update_environment
def test_update_environment():
    var_0 = get_workbench().set_default(_OPTION_NAME, False)
    os.environ["PGZERO_MODE"] = str(get_workbench().get_option(_OPTION_NAME))



# Generated at 2022-06-26 07:28:00.263105
# Unit test for function load_plugin
def test_load_plugin():
    var_0 = load_plugin()

# Generated at 2022-06-26 07:28:02.465209
# Unit test for function toggle_variable
def test_toggle_variable():
    # Check that this function doesn't return anything
    assert_equal(toggle_variable(), None)


# Generated at 2022-06-26 07:28:03.064519
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()

# Generated at 2022-06-26 07:28:04.002402
# Unit test for function load_plugin
def test_load_plugin():
    assert callable(load_plugin)

# Generated at 2022-06-26 07:28:04.520500
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()

# Generated at 2022-06-26 07:28:05.918471
# Unit test for function toggle_variable
def test_toggle_variable():
    # Check type boolean for function return value
    assert isinstance(toggle_variable(), bool) is True


# Generated at 2022-06-26 07:28:08.324231
# Unit test for function toggle_variable
def test_toggle_variable():
    print('Testing toggle_variable')
    assert test_case_0() is None, 'Failed test_case_0'
    # TODO: Add your own test cases here
    print('Test toggle_variable passed!')



# Generated at 2022-06-26 07:30:16.141631
# Unit test for function toggle_variable
def test_toggle_variable():
    # Pass a function object as an argument
    assert toggle_variable() == None
    # Pass a function object as an argument
    assert toggle_variable() == None

# Generated at 2022-06-26 07:30:25.047104
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert get_workbench().in_simple_mode() == False
    assert os.environ["PGZERO_MODE"] == str(get_workbench().get_option(_OPTION_NAME))
    assert get_workbench() != None
    assert get_workbench().get_variable(_OPTION_NAME) != None
    assert os.environ != None

# Generated at 2022-06-26 07:30:32.765937
# Unit test for function update_environment
def test_update_environment():

    def test_case_0():
        os.environ["PGZERO_MODE"] = "true"
        assert get_workbench().in_simple_mode()
        update_environment()
        assert os.environ["PGZERO_MODE"] == "true"

    def test_case_1():
        os.environ["PGZERO_MODE"] = "true"
        get_workbench().leave_simple_mode()
        update_environment()
        assert os.environ["PGZERO_MODE"] == "false"

    def test_case_2():
        os.environ["PGZERO_MODE"] = "false"
        get_workbench().enter_simple_mode()
        update_environment()
        assert os.environ["PGZERO_MODE"] == "auto"


# Generated at 2022-06-26 07:30:34.869535
# Unit test for function toggle_variable
def test_toggle_variable():
    # Check None returns None
    assert(toggle_variable() == None)


# Generated at 2022-06-26 07:30:38.128497
# Unit test for function update_environment
def test_update_environment():
    test_workbench = get_workbench()
    test_workbench.set_default("run.pgzero_mode", True)
    test_workbench.options_dialog_shown = True
    assert update_environment() == None

# Generated at 2022-06-26 07:30:46.723225
# Unit test for function update_environment
def test_update_environment():
    from unittest.mock import patch
    import os
    from thonny import get_workbench
    from thonny.languages import tr
    with patch('thonny.plugins.pgzero.os') as mocked_os:
        mocked_os.environ.__getitem__.side_effect = lambda _: mocked_os.environ.__getitem__()
        mocked_os.environ.__setitem__.side_effect = lambda _,__: mocked_os.environ.__setitem__(__)
        mocked_os.environ.__setitem__('PGZERO_MODE', 'auto')
        with patch('thonny.plugins.pgzero.get_workbench') as mocked_get_workbench:
            mocked_get_workbench().in_simple_mode.return_value = True
           

# Generated at 2022-06-26 07:30:50.572125
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()


# Generated at 2022-06-26 07:30:52.815130
# Unit test for function toggle_variable
def test_toggle_variable():
    # Set expected results
    expected_var_0 = None

    # Call test case
    test_case_0()

    # Check results
    assert var_0 == expected_var_0

# Generated at 2022-06-26 07:30:54.511865
# Unit test for function load_plugin
def test_load_plugin():
    # Load plugin
    load_plugin()

    # Test if toggle_variable returns the correct value type
    test_case_0()

# Generated at 2022-06-26 07:30:55.984678
# Unit test for function update_environment
def test_update_environment():
    # Test for function update_environment
    assert update_environment() == None