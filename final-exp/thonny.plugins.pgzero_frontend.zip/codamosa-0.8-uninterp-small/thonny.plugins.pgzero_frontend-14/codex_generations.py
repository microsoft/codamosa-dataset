

# Generated at 2022-06-26 07:23:31.683855
# Unit test for function load_plugin
def test_load_plugin():
    # Arrange
    from thonny.plugins.pgzero_mode.pgzero_mode import load_plugin

    # Act
    load_plugin()
    # Assert
    pass



# Generated at 2022-06-26 07:23:41.076266
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_simple_mode(True)
    os.environ["PGZERO_MODE"] = "auto"
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_simple_mode(False)
    get_workbench().set_default(_OPTION_NAME, False)
    os.environ["PGZERO_MODE"] = "auto"
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_variable(_OPTION_NAME, True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-26 07:23:47.872840
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()
    try:
        assert_equal(toggle_variable(), None)
    except:
        traceback.print_exc()
        print("FAILED test_toggle_variable")


# Generated at 2022-06-26 07:23:52.457494
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()

    var_0 = load_plugin()
    var_1 = wb.get_variable("run.pgzero_mode")
    expected_0 = False
    expected_1 = False
    assert var_0 == expected_0
    assert var_1 == expected_1
    assert True


# Generated at 2022-06-26 07:23:53.057014
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()

# Generated at 2022-06-26 07:24:02.495389
# Unit test for function toggle_variable
def test_toggle_variable():

    try:
        from unittest.mock import patch

        with patch(
            "thonny.plugins.run.pgzero_mode.get_workbench",
            return_value=True,
            autospec=None,
        ):
            assert toggle_variable() is None
    except ImportError:
        from unittest.mock import patch

        with patch(
            "thonny.plugins.run.pgzero_mode.get_workbench",
            return_value=True,
            autospec=None,
        ):
            assert toggle_variable() is None



# Generated at 2022-06-26 07:24:05.449961
# Unit test for function load_plugin
def test_load_plugin():
    assert load_plugin() == None


# Generated at 2022-06-26 07:24:06.181416
# Unit test for function update_environment
def test_update_environment():
    pass

# Generated at 2022-06-26 07:24:07.393711
# Unit test for function load_plugin
def test_load_plugin():
    assert load_plugin()


# Generated at 2022-06-26 07:24:11.813475
# Unit test for function load_plugin
def test_load_plugin():
    print("testing load_plugin")
    # Unit test for 
    def test_case_0() :
        assert isinstance(load_plugin(), object)
        assert isinstance(load_plugin(), object)
    
    
    
    
    
    
    
    

test_load_plugin()

# Generated at 2022-06-26 07:24:18.331271
# Unit test for function update_environment
def test_update_environment():
    pass


# Generated at 2022-06-26 07:24:27.687178
# Unit test for function load_plugin
def test_load_plugin():
    list_case_0 = [
        b'',
        b'\t',
        b' \t ',
        b'aozora.txt',
        b'non_existent',
        b'bash',
        b'python',
    ]

    for str_case_0 in list_case_0:
        try:
            load_plugin(test_case_0)
        except Exception as error_case_0:
            raise Exception('Test Failed: Function load_plugin() raised an exception on input {}'.format(str_case_0))
        else:
            pass

    set_case_0 = set(list_case_0)
    set_case_0.add(b'')

# Generated at 2022-06-26 07:24:35.012335
# Unit test for function update_environment
def test_update_environment():
    simple_mode_true = get_workbench().in_simple_mode()
    get_workbench().set_default(_OPTION_NAME, True)
    var_1 = update_environment()
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_default(_OPTION_NAME, False)
    var_2 = update_environment()
    assert os.environ["PGZERO_MODE"] == "False"
    get_workbench().set_default(_OPTION_NAME, True)
    get_workbench().set_in_simple_mode(True)
    var_3 = update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_in_simple_mode(simple_mode_true)

# Unit test

# Generated at 2022-06-26 07:24:36.206533
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()


# Generated at 2022-06-26 07:24:46.847368
# Unit test for function toggle_variable
def test_toggle_variable():
    var_1 = get_workbench().get_variable(_OPTION_NAME)
    var_2 = get_workbench().in_simple_mode()
    var_3 = get_workbench().get_variable(_OPTION_NAME)
    var_4 = toggle_variable()
    var_5 = update_environment()
    var_6 = get_workbench()
    var_7 = get_workbench().get_option(_OPTION_NAME)
    var_8 = get_workbench().get_variable(_OPTION_NAME)
    var_9 = get_workbench().in_simple_mode()
    var_10 = get_workbench().get_variable(_OPTION_NAME)
    var_11 = toggle_variable()
    var_12 = update_environment()
    return var_0, var_1, var_2,

# Generated at 2022-06-26 07:24:55.557201
# Unit test for function load_plugin
def test_load_plugin():
    # If plugin is successfully loaded, it will create
    # plugin_menu commands like toggle_pgzero_mode
    # Check this link for more details:
    # https://thonny.readthedocs.io/en/latest/workbench_dev.html#creating-commands
    commands = get_workbench().commands
    assert "toggle_pgzero_mode" in commands.keys()

    # Toggle the mode and make sure the environment is updated
    toggle_variable()
    assert os.getenv("PGZERO_MODE") == "True"

    # Toggle it back to make sure it can be toggled twice
    toggle_variable()
    assert os.getenv("PGZERO_MODE") == "False"

# Generated at 2022-06-26 07:25:00.267919
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    wb.set_simple_mode()
    result_0 = var_0
    wb.set_simple_mode()
    result_1 = var_1
    wb.set_simple_mode()
    result_2 = var_2
    wb.set_simple_mode()
    result_3 = var_3
    wb.set_simple_mode()
    result_4 = var_4
    load_plugin()

# Generated at 2022-06-26 07:25:01.202822
# Unit test for function update_environment
def test_update_environment():
    assert update_environment() == None


# Generated at 2022-06-26 07:25:05.804183
# Unit test for function toggle_variable
def test_toggle_variable():
    # A side effect of the function being tested is that the environment variable PGZERO_MODE must be set
    test_0 = {"stored": {}, "expected": {"PGZERO_MODE": "True"}}
    exec(compile(open(__file__).read(), __file__, 'exec'))
    result = set_environment_variable_PGZERO_MODE()

# Generated at 2022-06-26 07:25:10.977749
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_simple_mode_var(0)
    set_option_name("False")
    set_env("False")
    var_0 = toggle_variable()
    assert_equal(type(var_0), NoneType)
    assert_equal(get_option_name(), "True")
    assert_equal(get_env(), "True")

    # Unit test for function update_environment

# Generated at 2022-06-26 07:25:19.113528
# Unit test for function update_environment
def test_update_environment():

    # Testing if the value of the environment variable 'PGZERO_MODE' is set to 'auto' or not. 
    if os.environ["PGZERO_MODE"] == "auto":
        assert True
    # If value didn't set to 'auto'
    else:
        assert False

# Generated at 2022-06-26 07:25:20.393429
# Unit test for function update_environment
def test_update_environment():
    output = update_environment()
    assert output == None

# Generated at 2022-06-26 07:25:24.887246
# Unit test for function load_plugin
def test_load_plugin():
    test_wb = get_workbench()
    load_plugin()
    assert isinstance(test_wb.get_variable('run.pgzero_mode'), bool) == True


# Generated at 2022-06-26 07:25:25.989608
# Unit test for function update_environment
def test_update_environment():
    var_0 = update_environment()

# Generated at 2022-06-26 07:25:27.011282
# Unit test for function update_environment
def test_update_environment():
    assert update_environment() == None

# Generated at 2022-06-26 07:25:28.089096
# Unit test for function load_plugin
def test_load_plugin():
    pass


# Generated at 2022-06-26 07:25:29.734976
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default(_OPTION_NAME, False)
    update_environment()
    return True

# Generated at 2022-06-26 07:25:30.661463
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()



# Generated at 2022-06-26 07:25:32.007290
# Unit test for function toggle_variable
def test_toggle_variable():
    assert callable(toggle_variable)


# Generated at 2022-06-26 07:25:32.914655
# Unit test for function toggle_variable
def test_toggle_variable():
    test_case_0()

# Generated at 2022-06-26 07:25:45.439041
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()

# Generated at 2022-06-26 07:25:47.049323
# Unit test for function toggle_variable
def test_toggle_variable():
    pass


# Generated at 2022-06-26 07:25:48.027555
# Unit test for function toggle_variable
def test_toggle_variable():
    assert var_0 == True

# Generated at 2022-06-26 07:25:49.413094
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()


# Generated at 2022-06-26 07:25:53.936913
# Unit test for function toggle_variable
def test_toggle_variable():
    print("Test: toggle_variable")

    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()


# Generated at 2022-06-26 07:25:54.391687
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()

# Generated at 2022-06-26 07:26:00.035819
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, True)
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == True
    var_0 = update_environment()
    assert var_0 != True
    var_1 = test_case_0()
    assert var_1 != True

# Generated at 2022-06-26 07:26:09.600801
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    import thonny
    from thonny.workbench import get_workbench
    from thonny.languages import tr
    import os
    # Create a dummy workbench to test against
    thonny.workbench = Workbench()
    # Set if the plugin has been loaded the first time
    thonny.reset_all_shells_but_leave_state()
    # Run the plugin loading function
    load_plugin()
    # Test the command added
    assert isinstance(thonny.workbench.commands["toggle_pgzero_mode"], dict)
    # Test the workbench option set
    assert thonny.get_workbench().get_option('run.pgzero_mode') == False
    # Test the environment varialbe set

# Generated at 2022-06-26 07:26:14.352712
# Unit test for function update_environment
def test_update_environment():
    from thonny.misc_utils import running_on_mac_os, running_on_windows
    if running_on_mac_os():
        os.environ["PGZERO_MODE"] = "auto"
    os.environ["PGZERO_MODE"] = "auto"

# Generated at 2022-06-26 07:26:15.423815
# Unit test for function update_environment
def test_update_environment():
    # Test for variables with non-standard values
    var_0 = update_environment()

# Generated at 2022-06-26 07:26:40.772397
# Unit test for function toggle_variable
def test_toggle_variable():
    test_case_0()
    test_case_1()


# Generated at 2022-06-26 07:26:42.834285
# Unit test for function load_plugin
def test_load_plugin():
    """Unit test for function load_plugin"""

    # function call
    assert load_plugin() is None

# Generated at 2022-06-26 07:26:51.618552
# Unit test for function toggle_variable
def test_toggle_variable():
    assert not var_0

if __name__ == "__main__":
    load_plugin()

    test_toggle_variable()

# Generated at 2022-06-26 07:26:58.195336
# Unit test for function load_plugin
def test_load_plugin():

    # Clean up environment
    for key in list(os.environ.keys()):
        if key.startswith("PGZERO"):
            del os.environ[key]

    # Load plugin
    load_plugin()

    # Check if variable exists
    assert(get_workbench().get_variable(_OPTION_NAME).get())

    # Check environment variable
    assert(os.environ["PGZERO_MODE"] == "True")

# Generated at 2022-06-26 07:27:01.327275
# Unit test for function update_environment
def test_update_environment():
    expected_0 = "auto"
    expected_1 = "False"
    actual_0 = update_environment()
    actual_1 = update_environment()
    assert expected_0 == actual_0
    assert expected_1 == actual_1

# Generated at 2022-06-26 07:27:01.861158
# Unit test for function load_plugin
def test_load_plugin():
   pass

# Generated at 2022-06-26 07:27:04.337564
# Unit test for function toggle_variable
def test_toggle_variable():
    # Test that the function runs at all
    assert test_case_0() is None


# Generated at 2022-06-26 07:27:06.386876
# Unit test for function update_environment
def test_update_environment():
    import os

    update_environment()
    var_0 = os.environ["PGZERO_MODE"]


# Generated at 2022-06-26 07:27:09.943405
# Unit test for function toggle_variable
def test_toggle_variable():
    # Test 1
    if toggle_variable():
        return False
    # Test 2
    if not toggle_variable():
        return False
    return True



# Generated at 2022-06-26 07:27:23.847278
# Unit test for function update_environment
def test_update_environment():
    # Test case 1
    original_env = dict(os.environ)
    os.environ.clear()
    update_environment()
    assert os.environ == {'PGZERO_MODE': 'True'}
    os.environ.clear()
    os.environ.update(original_env)
    # Test case 2
    original_env = dict(os.environ)
    os.environ.clear()
    get_workbench().set_option(_OPTION_NAME, False)
    update_environment()
    assert os.environ == {'PGZERO_MODE': 'False'}
    os.environ.clear()
    os.environ.update(original_env)
    # Test case 3
    original_env = dict(os.environ)
    os.environ.clear()
   

# Generated at 2022-06-26 07:28:14.094280
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()

if __name__ == "__main__":
    load_plugin()

# Generated at 2022-06-26 07:28:16.196992
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    wb.in_simple_mode = lambda: True
    test_0 = update_environment()
    os.environ["PGZERO_MODE"] = "auto"


# Generated at 2022-06-26 07:28:17.097423
# Unit test for function load_plugin
def test_load_plugin():
    assert load_plugin() != None


# Generated at 2022-06-26 07:28:18.149908
# Unit test for function toggle_variable
def test_toggle_variable():
    var_0 = toggle_variable()

# Generated at 2022-06-26 07:28:18.651828
# Unit test for function load_plugin
def test_load_plugin():
    load_plugi

# Generated at 2022-06-26 07:28:20.450820
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_simple_mode(True)
    test_case_0()

# Generated at 2022-06-26 07:28:21.017077
# Unit test for function update_environment
def test_update_environment():
    pass

# Generated at 2022-06-26 07:28:22.240096
# Unit test for function update_environment
def test_update_environment():
    update_environment()

# Generated at 2022-06-26 07:28:23.358001
# Unit test for function load_plugin
def test_load_plugin():
    assert toggle_variable == load_plugin()


# Generated at 2022-06-26 07:28:25.271031
# Unit test for function update_environment
def test_update_environment():
    if not get_workbench().in_simple_mode():
        assert true == true
    else:
        assert true == false


# Generated at 2022-06-26 07:30:33.452472
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_variable(_OPTION_NAME, False)
    load_plugin()
    try:
        get_workbench().get_option(_OPTION_NAME)
    except:
        return False
    return True


# Generated at 2022-06-26 07:30:34.265920
# Unit test for function update_environment
def test_update_environment():
    pass

# Generated at 2022-06-26 07:30:35.568301
# Unit test for function update_environment
def test_update_environment():
    assert update_environment() is None

# Generated at 2022-06-26 07:30:39.687125
# Unit test for function load_plugin
def test_load_plugin():
    # Create a temporary environment
    old_env = dict(os.environ)
    os.environ.clear()
    # Call the function
    load_plugin()
    # Restore the temporary environment
    os.environ.clear()
    os.environ.update(old_env)



# Generated at 2022-06-26 07:30:44.041729
# Unit test for function load_plugin
def test_load_plugin():
    # Check that it returns None
    assert load_plugin() is None
    # Check that it sets the appropriate option
    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    # Check that it adds the command
    assert get_workbench().commands['toggle_pgzero_mode'] is not None
    # Check that it adds the option
    assert get_workbench().options[_OPTION_NAME] is not None


# Generated at 2022-06-26 07:30:45.415114
# Unit test for function toggle_variable
def test_toggle_variable():
    pass  # TODO: implement your test here


# Generated at 2022-06-26 07:30:45.922444
# Unit test for function load_plugin
def test_load_plugin():
    pass

# Generated at 2022-06-26 07:30:48.581015
# Unit test for function toggle_variable
def test_toggle_variable():
    wb = get_workbench()
    var = wb.get_variable(_OPTION_NAME)
    var.set(False)
    toggle_variable()
    assertion_0 = var.get()
    assert assertion_0

# Generated at 2022-06-26 07:30:51.579943
# Unit test for function update_environment
def test_update_environment():
    if get_workbench().in_simple_mode():
        os.environ["PGZERO_MODE"] = "auto"
    else:
        os.environ["PGZERO_MODE"] = str(get_workbench().get_option(_OPTION_NAME))

# Generated at 2022-06-26 07:30:52.058456
# Unit test for function load_plugin
def test_load_plugin():
    assert load_plugin()