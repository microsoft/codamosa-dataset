

# Generated at 2022-06-26 07:23:14.960670
# Unit test for function update_environment
def test_update_environment():
    # FIXME: not testable at  moment
    assert update_environment() == False

# Generated at 2022-06-26 07:23:15.837957
# Unit test for function toggle_variable
def test_toggle_variable():
    assert toggle_variable() == None

# Generated at 2022-06-26 07:23:23.798350
# Unit test for function update_environment

# Generated at 2022-06-26 07:23:24.580066
# Unit test for function update_environment
def test_update_environment():
    ""
    assert True


# Generated at 2022-06-26 07:23:25.657328
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()


# Generated at 2022-06-26 07:23:26.941346
# Unit test for function load_plugin
def test_load_plugin():
    assert load_plugin() == None


# Generated at 2022-06-26 07:23:29.123075
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME) == False


# Generated at 2022-06-26 07:23:37.415953
# Unit test for function toggle_variable
def test_toggle_variable():
    # Function to "toggle" the value of a variable
    assert not get_workbench().get_variable(
        _OPTION_NAME
    ), "This test should not be run in PGZ mode"
    toggle_variable()
    assert get_workbench().get_variable(
        _OPTION_NAME
    ), "PGZ mode not enabled after running toggle_variable()"
    toggle_variable()
    assert not get_workbench().get_variable(
        _OPTION_NAME
    ), "PGZ mode not disabled after running toggle_variable()"



# Generated at 2022-06-26 07:23:38.329566
# Unit test for function load_plugin
def test_load_plugin():
    var_0 = load_plugin()

# Generated at 2022-06-26 07:23:38.713064
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()

# Generated at 2022-06-26 07:23:46.837912
# Unit test for function update_environment
def test_update_environment():
    environment_value = get_workbench().get_environment("PGZERO_MODE") or ''
    assert environment_value == update_environment()


# Generated at 2022-06-26 07:23:48.737812
# Unit test for function toggle_variable
def test_toggle_variable():
    test_case_0()
# def test_toggle_variable_2():
#     test_case_0()


# Generated at 2022-06-26 07:23:52.347875
# Unit test for function toggle_variable
def test_toggle_variable():
    try:
        from pgzrun import _PYGAMEZERO_MODE
    except ImportError:
        _PYGAMEZERO_MODE = False
    assert _PYGAMEZERO_MODE == False
    toggle_variable()
    assert _PYGAMEZERO_MODE == True
    toggle_variable()
    assert _PYGAMEZERO_MODE == False

# Generated at 2022-06-26 07:23:53.260385
# Unit test for function update_environment
def test_update_environment():
    pass # nothing to test


# Generated at 2022-06-26 07:24:01.778173
# Unit test for function update_environment
def test_update_environment():
    var_1 = update_environment()


# Generated at 2022-06-26 07:24:06.066001
# Unit test for function update_environment
def test_update_environment():
	pass

# Generated at 2022-06-26 07:24:07.322652
# Unit test for function update_environment
def test_update_environment():
    assert update_environment() == None


# Generated at 2022-06-26 07:24:14.143128
# Unit test for function load_plugin
def test_load_plugin():
    fd, path = mkstemp()
    old_stdout = sys.stdout
    sys.stdout = os.fdopen(fd, 'w')

    @add_cmd
    def foo_cmd():
        pass
    try:
        load_plugin()
        foo_cmd()
        assert True # TODO: implement your test here
    except:
        import traceback
        traceback.print_exc()
        assert False
    finally:
        sys.stdout.close()
        sys.stdout = old_stdout
        os.remove(path)

# Generated at 2022-06-26 07:24:17.809423
# Unit test for function load_plugin
def test_load_plugin():
    # Check for function call
    assert load_plugin()

if __name__ == "__main__":
    test_case_0()
    test_load_plugin()

# Generated at 2022-06-26 07:24:21.137714
# Unit test for function update_environment
def test_update_environment():
    # User code
    def test_function(param_1):
        for x in [1, 2, 3]:
            if param_1 == x:
                param_1 += 1
        return param_1

    variable = test_function(1)
    assert variable == 2



# Generated at 2022-06-26 07:24:27.879362
# Unit test for function load_plugin
def test_load_plugin():
    assert load_plugin()



# Generated at 2022-06-26 07:24:29.057551
# Unit test for function update_environment
def test_update_environment():
    pass


# Generated at 2022-06-26 07:24:34.422693
# Unit test for function update_environment
def test_update_environment():
    load_plugin()
    workbench = get_workbench()
    workbench.open_view("OptionsView")
    workbench.set_option("run.pgzero_mode", True)
    pgzero_mode = os.environ.get("PGZERO_MODE")
    expected_pgzero_mode = "True"
    assert pgzero_mode == expected_pgzero_mode

# Generated at 2022-06-26 07:24:34.955717
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()

# Generated at 2022-06-26 07:24:37.285278
# Unit test for function load_plugin
def test_load_plugin():
    print("\nUnit test for function load_plugin: \n")

    # Test fails, as no input is given
    assert load_plugin() == None

# Generated at 2022-06-26 07:24:38.809119
# Unit test for function update_environment
def test_update_environment():
    update_environment()


# Generated at 2022-06-26 07:24:42.836671
# Unit test for function load_plugin
def test_load_plugin():
    try:
        get_workbench().get_command("toggle_pgzero_mode")
    except:
        load_plugin()
        try:
            get_workbench().get_command("toggle_pgzero_mode")
        except:
            raise Exception("Plugin failed to load")

# Generated at 2022-06-26 07:24:44.785666
# Unit test for function load_plugin
def test_load_plugin():
    assert(load_plugin())


# Unit test 1 for function toggle_variable

# Generated at 2022-06-26 07:24:47.635733
# Unit test for function update_environment
def test_update_environment():
    test_input = ""
    expected_result = None
    actual_result = update_environment()
    assert actual_result == expected_result

# Generated at 2022-06-26 07:24:48.596271
# Unit test for function update_environment
def test_update_environment():
    var_0 = update_environment()



# Generated at 2022-06-26 07:25:00.781672
# Unit test for function update_environment
def test_update_environment():
    update_environment()



# Generated at 2022-06-26 07:25:01.688160
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()


# Generated at 2022-06-26 07:25:08.339293
# Unit test for function toggle_variable
def test_toggle_variable():
    from thonny import get_shell
    from thonny.shell import ShellTextWidget
    from thonny.codeview import CodeViewText
    from thonny.ui_utils import select_sequence

    get_workbench().set_option("run.force_run_in_ui_process", True)
    test_case_0()

    shell = get_shell()
    assert isinstance(shell.text, ShellTextWidget)
    assert isinstance(shell.text.code_view, CodeViewText)

    # Verify that shell is in Pygame Zero mode after calling toggle_variable
    select_sequence(shell._add_to_history("help('pgzrun.go')"), "<Return>")
    select_sequence(shell.text, "<Shift>", "<Tab>")
    select_sequence(shell.text, "<F9>")


# Generated at 2022-06-26 07:25:15.776138
# Unit test for function update_environment
def test_update_environment():

    # Case 0
    # Try with in_simple_mode() as False
    get_workbench().in_simple_mode = lambda: False
    get_workbench().get_option = lambda x: False
    test_update_environment_case_0()
    get_workbench().in_simple_mode = lambda: True
    test_update_environment_case_0()
    get_workbench().in_simple_mode = lambda: False
    get_workbench().get_option = lambda x: True
    test_update_environment_case_0()



# Generated at 2022-06-26 07:25:16.404187
# Unit test for function load_plugin
def test_load_plugin():
    pass


# Generated at 2022-06-26 07:25:17.693500
# Unit test for function update_environment
def test_update_environment():
    assert (update_environment() == None)

# Generated at 2022-06-26 07:25:18.561281
# Unit test for function toggle_variable
def test_toggle_variable():
    return None

# Generated at 2022-06-26 07:25:19.945724
# Unit test for function update_environment
def test_update_environment():
    update_environment()
    assert True

# Generated at 2022-06-26 07:25:21.014657
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()



# Generated at 2022-06-26 07:25:22.333878
# Unit test for function load_plugin
def test_load_plugin():
    test_case_0()


load_plugin()

# Generated at 2022-06-26 07:25:51.181193
# Unit test for function update_environment
def test_update_environment():

    get_workbench().set_default("run.pgzero_mode", False)

    update_environment()

    assert os.environ["PGZERO_MODE"] == 'False'

    get_workbench().set_default("run.pgzero_mode", True)

    update_environment()

    assert os.environ["PGZERO_MODE"] == 'True'

# Generated at 2022-06-26 07:25:53.463482
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = "auto"
    update_environment()
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-26 07:25:54.777392
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert True


# Generated at 2022-06-26 07:25:56.030836
# Unit test for function load_plugin
def test_load_plugin():
    tb = get_workbench()
    load_plugin()



# Generated at 2022-06-26 07:26:00.385703
# Unit test for function load_plugin
def test_load_plugin():
    # Before function load_plugin
    assert not get_workbench().get_option(_OPTION_NAME)
    # After function load_plugin
    load_plugin()
    assert get_workbench().get_option(_OPTION_NAME)

# Generated at 2022-06-26 07:26:03.025127
# Unit test for function load_plugin
def test_load_plugin():
    # Unit test for function update_environment
    def test_update_environment(self):
        self.load_plugin = test_load_plugin()


# Generated at 2022-06-26 07:26:04.033263
# Unit test for function load_plugin
def test_load_plugin():
    assert load_plugin() is None


# Generated at 2022-06-26 07:26:05.010541
# Unit test for function load_plugin
def test_load_plugin():

    # Update the environment
    update_environment()

# Generated at 2022-06-26 07:26:11.232239
# Unit test for function load_plugin
def test_load_plugin():
    print("Test: function load_plugin")

    # Setup
    try:
        import wx
    except ImportError:
        raise ImportError("wx is required for this test")
    wx.App()
    import sys
    import thonny
    from thonny.workbench import Workbench
    sys.argv = ["thonny"]
    get_workbench().set_default(_OPTION_NAME, False)
    var_0 = load_plugin()

    # Teardown
    del var_0
    # get_workbench().destroy()



# Generated at 2022-06-26 07:26:12.925268
# Unit test for function toggle_variable
def test_toggle_variable():
    test_case_0()


# Generated at 2022-06-26 07:27:06.385999
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()

    wb.set_default(_OPTION_NAME, False)
    wb.add_command("toggle_pgzero_mode", "run", "Pygame Zero mode", toggle_variable, flag_name=_OPTION_NAME, group=40)
    update_environment()


# Generated at 2022-06-26 07:27:13.679685
# Unit test for function update_environment
def test_update_environment():
    # Unit test for function update_environment
    # Create mock object for object Variable
    var_0 = get_workbench().get_variable(
        _OPTION_NAME
    )  # Mock object for object Variable
    # Create mock object for object Tk
    var_1 = get_workbench().in_simple_mode()
    var_2 = str(get_workbench().get_option(_OPTION_NAME))
    os.environ["PGZERO_MODE"] = var_2  # Set value for environment variable PGZERO_MODE


if __name__ == "__main__":
    test_update_environment()

# Generated at 2022-06-26 07:27:14.865914
# Unit test for function toggle_variable
def test_toggle_variable():
    assert callable(toggle_variable())


# Generated at 2022-06-26 07:27:15.448869
# Unit test for function update_environment
def test_update_environment():
    assert update_environment() is None

# Generated at 2022-06-26 07:27:20.243054
# Unit test for function load_plugin
def test_load_plugin():
    assert load_plugin() is None, "Function load_plugin does not work correctly"

# Driver code
loop = asyncio.get_event_loop()

loop.run_until_complete(test_load_plugin())
loop.run_until_complete(test_case_0())

# Generated at 2022-06-26 07:27:23.969444
# Unit test for function load_plugin
def test_load_plugin():
    assert (
        load_plugin() == None
    ), "The unit test of function load_plugin is not yet implemented"

# Generated at 2022-06-26 07:27:24.907433
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()


# Generated at 2022-06-26 07:27:25.779832
# Unit test for function update_environment

# Generated at 2022-06-26 07:27:34.234607
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_simple_mode()
    assert wb.in_simple_mode()
    load_plugin()
    assert not wb.in_simple_mode()
    # Test taken from https://github.com/thonny/thonny/blob/fa325a73f2c2dcc0f9026a947c0bcf99c4e4b15e/thonny/plugins/simple_mode/simplemode.py#L91
    assert wb.get_option(_OPTION_NAME) == False

# Generated at 2022-06-26 07:27:35.711073
# Unit test for function update_environment
def test_update_environment():
    assert update_environment() == None


# Generated at 2022-06-26 07:29:34.241728
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench
    from thonny.plugins.pgzero import _OPTION_NAME
    from thonny.plugins.pgzero import toggle_variable
    from thonny.plugins.pgzero import update_environment
    from thonny.plugins.pgzero import load_plugin
    from thonny.plugins.pgzero import get_workbench
    from thonny.plugins.pgzero import toggle_variable
    from thonny.plugins.pgzero import update_environment

# Generated at 2022-06-26 07:29:36.546397
# Unit test for function toggle_variable
def test_toggle_variable():
    assert get_workbench().get_variable(_OPTION_NAME).get() == False
    toggle_variable()
    assert get_workbench().get_variable(_OPTION_NAME).get() == True



# Generated at 2022-06-26 07:29:39.376779
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = toggle_variable()
    update_environment()



# Generated at 2022-06-26 07:29:42.950339
# Unit test for function update_environment
def test_update_environment():
    # Test 1
    os.environ["PGZERO_MODE"] = "1"

    # Test 2
    # Test 3
    os.environ["PGZERO_MODE"] = "0"

    # Test 4
    os.environ["PGZERO_MODE"] = "auto"



# Generated at 2022-06-26 07:29:43.532756
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()

# Generated at 2022-06-26 07:29:44.342034
# Unit test for function update_environment
def test_update_environment():
    pass

# Generated at 2022-06-26 07:29:46.672590
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench
    test_get_workbench = get_workbench()
    test_load_plugin = load_plugin()
    assert test_load_plugin is None


# Generated at 2022-06-26 07:29:47.611073
# Unit test for function update_environment
def test_update_environment():
    var_0 = update_environment()


# Generated at 2022-06-26 07:29:49.650615
# Unit test for function toggle_variable
def test_toggle_variable():
    # Test if the variable is true
    if var_0 == True:
        assert True
    else:
        # Fail
        assert False


# Generated at 2022-06-26 07:29:53.374103
# Unit test for function update_environment
def test_update_environment():
    # Check that function does not fail if environment var is not set
    if "PGZERO_MODE" in os.environ:
        os.environ.pop("PGZERO_MODE")
    update_environment()