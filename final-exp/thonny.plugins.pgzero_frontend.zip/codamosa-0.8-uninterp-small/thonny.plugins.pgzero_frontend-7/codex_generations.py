

# Generated at 2022-06-26 07:23:21.408734
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default(_OPTION_NAME, True)
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-26 07:23:28.293149
# Unit test for function toggle_variable
def test_toggle_variable():
    var_0 = load_plugin()
    print("")
    var_1 = get_workbench()
    print("")
    var_2 = var_1.get_variable('run.pgzero_mode')
    print("")
    var_2.set(not var_2.get())
    print("")
    var_3 = update_environment()
    print("")
    var_4 = get_workbench()
    print("")
    var_5 = var_4.in_simple_mode()
    print("")
    var_6 = os.environ.get("PGZERO_MODE")
    print("")
    var_7 = get_workbench()
    print("")
    var_8 = var_7.get_option('run.pgzero_mode')
    print("")


# Unit test

# Generated at 2022-06-26 07:23:31.226426
# Unit test for function toggle_variable
def test_toggle_variable():
    # Checks that variable 'PGZERO_MODE' is set to 'True' after calling 'toggle_variable'
    global PGZERO_MODE
    toggle_variable()
    assert PGZERO_MODE == True

# Generated at 2022-06-26 07:23:32.558366
# Unit test for function toggle_variable
def test_toggle_variable():
    pass # Fill in test_toggle_variable


# Generated at 2022-06-26 07:23:34.380393
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()


# Generated at 2022-06-26 07:23:36.765551
# Unit test for function toggle_variable
def test_toggle_variable():
    assert get_workbench().get_variable(_OPTION_NAME) == False



# Generated at 2022-06-26 07:23:38.488438
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()


# Generated at 2022-06-26 07:23:47.705625
# Unit test for function toggle_variable
def test_toggle_variable():
    import os
    import sys
    import unittest
    import unittest.mock
    from thonny import get_workbench
    from thonny.plugins.load_in_pgzero_mode import update_environment
    from thonny.plugins.load_in_pgzero_mode import toggle_variable
    with unittest.mock.patch('thonny.languages.tr') as tr:
        tr.side_effect = lambda x: x
        get_workbench().set_in_simple_mode(False)
        get_workbench().set_default(_OPTION_NAME, False)
        update_environment()
        assert os.environ['PGZERO_MODE'] == 'False'
        toggle_variable()
        update_environment()

# Generated at 2022-06-26 07:23:48.576973
# Unit test for function toggle_variable
def test_toggle_variable():
    assert toggle_variable() == None


# Generated at 2022-06-26 07:23:49.432562
# Unit test for function load_plugin
def test_load_plugin():
    assert (None is not None)


# Generated at 2022-06-26 07:23:56.667847
# Unit test for function load_plugin
def test_load_plugin():
    test_wb = get_workbench()
    test_wb.set_default(_OPTION_NAME, True)
    assert test_wb.get_option(_OPTION_NAME) == True
    assert os.environ["PGZERO_MODE"] == "True"


# Generated at 2022-06-26 07:23:57.665538
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()


# Generated at 2022-06-26 07:24:00.607799
# Unit test for function load_plugin
def test_load_plugin():
    FileSystemLoader.run_unit_test(load_plugin)
    assert FileSystemLoader.num_unit_test_failures() == 0


# Generated at 2022-06-26 07:24:04.263011
# Unit test for function update_environment
def test_update_environment():
    # Setup
    get_workbench = mock.Mock()
    os.environ = dict()

    # Execute test case
    update_environment()

    # Assert
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-26 07:24:05.956422
# Unit test for function update_environment
def test_update_environment():
    var_0 = update_environment()


# Generated at 2022-06-26 07:24:06.947847
# Unit test for function toggle_variable
def test_toggle_variable():
    assert toggle_variable() == None


# Generated at 2022-06-26 07:24:15.764438
# Unit test for function load_plugin
def test_load_plugin():
    # Define a new test data set
    var_0 = get_workbench()
    var_1 = get_workbench()
    var_2 = get_workbench()
    var_3 = get_workbench()
    var_4 = get_workbench()
    var_5 = get_workbench()
    var_6 = get_workbench()
    var_7 = get_workbench()
    var_8 = get_workbench()
    var_9 = get_workbench()
    var_10 = get_workbench()
    var_11 = get_workbench()
    var_12 = get_workbench()
    var_13 = get_workbench()
    var_14 = get_workbench()
    var_15 = get_workbench()
    var_16 = get_workbench()
    var

# Generated at 2022-06-26 07:24:18.393980
# Unit test for function update_environment
def test_update_environment():
    assert None == update_environment()


# Generated at 2022-06-26 07:24:19.888675
# Unit test for function toggle_variable
def test_toggle_variable():
    # Case 0
    assert test_case_0() == None

# Generated at 2022-06-26 07:24:22.701552
# Unit test for function update_environment
def test_update_environment():
    if (get_workbench().get_variable(_OPTION_NAME) == update_environment()):
        return True
    else:
        return False

# Generated at 2022-06-26 07:24:35.499769
# Unit test for function toggle_variable
def test_toggle_variable():
    # Initialize get_workbench()
    get_workbench().in_simple_mode = Mock(return_value=True)
    get_workbench().get_variable(_OPTION_NAME).set = Mock(return_value=True)
    # Call the function
    toggle_variable()
    # Verify the result
    get_workbench().in_simple_mode.assert_called_with()
    assert get_workbench().get_variable(_OPTION_NAME).get() == False

    # Initialize get_workbench()
    get_workbench().in_simple_mode = Mock(return_value=False)

# Generated at 2022-06-26 07:24:39.969992
# Unit test for function update_environment
def test_update_environment():
    update_environment()
    # Check that the global variable PGZERO_MODE has been set to auto
    assert os.environ["PGZERO_MODE"] == "auto"
    # Check the varible is set to true
    get_workbench().get_variable(_OPTION_NAME).set(True)
    # Check that the global variable PGZERO_MODE has been set to true
    update_environment()
    assert os.environ["PGZERO_MODE"] == "True"

# Generated at 2022-06-26 07:24:42.765883
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()

# Generated at 2022-06-26 07:24:49.194596
# Unit test for function toggle_variable
def test_toggle_variable():
    a_list_of_variables = [
        ['a', 'b', 'c', 'd'],
        ['e', 'f', 'g', 'h'],
        ['i', 'j', 'k', 'l'],
        ['m', 'n', 'o', 'p'],
    ]
    assert var_0 == a_list_of_variables

# Generated at 2022-06-26 07:24:50.055357
# Unit test for function load_plugin
def test_load_plugin():
    return load_plugin()


# Generated at 2022-06-26 07:24:53.862415
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )



# Generated at 2022-06-26 07:24:59.312893
# Unit test for function toggle_variable
def test_toggle_variable():
    # If var_0 = True
    var_0 = True
    assert var_0 is True
    # Then var = toggle_variable(var_0) should be False
    var_1 = toggle_variable(var_0)
    assert var_1 == False
    # Else var_0 = False
    var_0 = False
    assert var_0 is False
    # Then var = toggle_variable(var_0) should be True
    var_1 = toggle_variable(var_0)
    assert var_1 is True


# Generated at 2022-06-26 07:25:03.701312
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    assert wb.get_default(_OPTION_NAME) == False
    # assert 'toggle_pgzero_mode' in wb.get_command_names()
    # assert wb.get_command('toggle_pgzero_mode') != None
    # assert wb.get_command_binding('toggle_pgzero_mode') != None



# Generated at 2022-06-26 07:25:13.002628
# Unit test for function load_plugin
def test_load_plugin():
    old_wa = get_workbench()
    get_workbench = lambda: old_wa
    pm = MagicMock()
    pm.get_option = lambda name: True if name == _OPTION_NAME else None
    old_wa = get_workbench()
    get_workbench = lambda: pm
    load_plugin()
    assert pm.get_option.called == 1
    assert pm.set_default.called == 1
    assert pm.add_command.called == 1
    assert pm.set_default.call_args_list[0] == call(_OPTION_NAME, False)
    del get_workbench
    get_workbench = lambda: old_wa

# Test for function update_environment

# Generated at 2022-06-26 07:25:20.791681
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()
    if get_workbench().in_simple_mode():
        var_0 = (os.environ.get('PGZERO_MODE'), 'auto')
    else:
        var_0 = (os.environ.get('PGZERO_MODE'), str(get_workbench().get_option(_OPTION_NAME)))

# Generated at 2022-06-26 07:25:40.021648
# Unit test for function load_plugin
def test_load_plugin():
    workbench = get_workbench()
    load_plugin()
    assert workbench.get_default(_OPTION_NAME) == False
    assert list(workbench.find_commands("toggle_pgzero_mode")) == [{'category': 'run', 
                                                                  'command': 'toggle_pgzero_mode', 
                                                                  'label': 'Pygame Zero mode',
                                                                  'flag_name': 'run.pgzero_mode'}]
    assert update_environment() == None

# Generated at 2022-06-26 07:25:42.347152
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = "auto"
    update_environment()
    assert os.environ["PGZERO_MODE"] != "auto"


# Generated at 2022-06-26 07:25:43.678875
# Unit test for function update_environment
def test_update_environment():
    assert update_environment() == None


# Generated at 2022-06-26 07:25:44.786069
# Unit test for function update_environment
def test_update_environment():
    update_environment()


# Generated at 2022-06-26 07:25:46.673233
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()


# Generated at 2022-06-26 07:25:49.151372
# Unit test for function load_plugin
def test_load_plugin():
    assert get_workbench().get_option('run.pgzero_mode') == False


# Generated at 2022-06-26 07:25:56.153840
# Unit test for function toggle_variable
def test_toggle_variable():
    with patch('sys.exit', return_value=None):
        with patch('tkinter.messagebox.askyesno', return_value=True):
            os.environ["PGZERO_MODE"] = "auto"
            toggle_variable()
            assert os.environ["PGZERO_MODE"] == "True"
    
        with patch('tkinter.messagebox.askyesno', return_value=True):
            os.environ["PGZERO_MODE"] = "True"
            toggle_variable()
            assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-26 07:25:59.657253
# Unit test for function load_plugin
def test_load_plugin():
    assert load_plugin == load_plugin()
    

if __name__ == '__main__':
    print('test case 0: ', test_case_0())

# Generated at 2022-06-26 07:26:01.762644
# Unit test for function update_environment
def test_update_environment():
    var_0 = update_environment()

if __name__ == "__main__":
    update_environment
    toggle_variable

# Generated at 2022-06-26 07:26:05.574666
# Unit test for function toggle_variable
def test_toggle_variable():
    print("Unit test for function toggle_variable")
    test_case_0()

if __name__ == "__main__":
    print("Unit test for plugin test_case_0")
    test_toggle_variable()
    print("Unit test for plugin completed")

# Generated at 2022-06-26 07:26:30.909121
# Unit test for function update_environment
def test_update_environment():
    assert update_environment() == None


# Generated at 2022-06-26 07:26:34.515384
# Unit test for function update_environment
def test_update_environment():
    assert get_workbench().in_simple_mode() == True
    assert os.environ["PGZERO_MODE"] == "auto"
    get_workbench().set_variable(_OPTION_NAME, True)
    assert os.environ["PGZERO_MODE"] == "True"
    get_workbench().set_variable(_OPTION_NAME, False)
    assert os.environ["PGZERO_MODE"] == "False"

# Generated at 2022-06-26 07:26:39.301991
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.common import get_runner

    def mock_get_runner():
        return {}

    original_get_runner = get_runner.get()
    get_runner.set(mock_get_runner)
    load_plugin()
    get_runner.set(original_get_runner)



# Generated at 2022-06-26 07:26:40.867399
# Unit test for function load_plugin
def test_load_plugin():    
    load_plugin()


# Generated at 2022-06-26 07:26:42.596148
# Unit test for function update_environment
def test_update_environment():
    assert get_workbench().get_option(_OPTION_NAME) == False

# Generated at 2022-06-26 07:26:43.847211
# Unit test for function update_environment
def test_update_environment():
    assert update_environment() is None

# Generated at 2022-06-26 07:26:44.825533
# Unit test for function load_plugin
def test_load_plugin():
    assert load_plugin() is None



# Generated at 2022-06-26 07:26:45.733757
# Unit test for function load_plugin
def test_load_plugin():
    test_case_0()

# Generated at 2022-06-26 07:26:47.703163
# Unit test for function update_environment
def test_update_environment():
    assert update_environment() == None


if __name__ == '__main__':
    update_environment()

# Generated at 2022-06-26 07:26:49.599639
# Unit test for function toggle_variable
def test_toggle_variable():
    # Check toggle_variable returns None
    output  = toggle_variable()
    expected_output = None
    assert output == expected_output


# Generated at 2022-06-26 07:27:46.174536
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    wb.add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()
    return True


# Generated at 2022-06-26 07:27:54.857924
# Unit test for function load_plugin
def test_load_plugin():
    from importlib import reload
    from thonny import ToplevelCommand, get_workbench
    from thonny.languages import tr
    import thonny.running
    import os
    reload(thonny.running)
    get_workbench().clear_commands()
    get_workbench().clear_variable("run.pgzero_mode")
    get_workbench().clear_environment()
    load_plugin()
    assert get_workbench().get_option("run.pgzero_mode") is False, "Error loading plugin"
    assert os.environ["PGZERO_MODE"] == 'False', "Error loading plugin"
    assert get_workbench().get_command("toggle_pgzero_mode").flag_name == 'run.pgzero_mode', "Error loading plugin"
    assert get_workbench().get_command

# Generated at 2022-06-26 07:27:55.719815
# Unit test for function update_environment
def test_update_environment():
    var_0 = update_environment()

# Generated at 2022-06-26 07:27:59.045078
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_option(_OPTION_NAME, True)
    # Test that calling the function sets PGZERO_MODE to True
    assert os.environ["PGZERO_MODE"] == "True"



# Generated at 2022-06-26 07:27:59.877462
# Unit test for function toggle_variable
def test_toggle_variable():
    assert toggle_variable()


# Generated at 2022-06-26 07:28:01.648723
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()

if __name__ == '__main__':
    test_load_plugin()

# Generated at 2022-06-26 07:28:05.807512
# Unit test for function update_environment
def test_update_environment():
    # if get_workbench().in_simple_mode():
    #     assert os.environ["PGZERO_MODE"] == "auto"
    # else:
    #     assert os.environ["PGZERO_MODE"] == str(get_workbench().get_option(_OPTION_NAME))
    assert "PGZERO_MODE" in os.environ, "The environment variable has not been added."

# Generated at 2022-06-26 07:28:08.946606
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()

# Generated at 2022-06-26 07:28:09.716580
# Unit test for function toggle_variable
def test_toggle_variable():
    assert toggle_variable() == None


# Generated at 2022-06-26 07:28:12.139879
# Unit test for function load_plugin
def test_load_plugin():
    root = tkinter.Tk()
    root.withdraw()

    wb = Workbench(root) # Initialize workbench
    load_plugin()
    # Add your test steps here.
    # Do not use assert here.

# Generated at 2022-06-26 07:30:23.179192
# Unit test for function toggle_variable
def test_toggle_variable():
    var_0 = get_workbench().get_variable(_OPTION_NAME)
    var_0.set(False)
    toggle_variable()
    assert var_0.get() == True
    toggle_variable()
    assert var_0.get() == False


# Generated at 2022-06-26 07:30:24.243115
# Unit test for function toggle_variable
def test_toggle_variable():
    result_0 = toggle_variable()
    assert result_0 == True



# Generated at 2022-06-26 07:30:25.292528
# Unit test for function load_plugin
def test_load_plugin():
    wb = load_plugin()
    assert wb is not None

# Generated at 2022-06-26 07:30:27.624103
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default(_OPTION_NAME, False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) != True


# Generated at 2022-06-26 07:30:32.476516
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.workbench import Workbench
    from thonny.languages import en

    wb_0 = Workbench()
    wb_0.load_plugin(load_plugin)
    assert_0 = wb_0.get_plugin("run").commands["toggle_pgzero_mode"].name == "Pygame Zero mode"
    wb_0.unload_plugin(load_plugin)
    del wb_0
    return assert_0



# Generated at 2022-06-26 07:30:34.265568
# Unit test for function update_environment
def test_update_environment():
    assert update_environment() == None

# Generated at 2022-06-26 07:30:36.769022
# Unit test for function toggle_variable
def test_toggle_variable():
	# function call
	var_0 = toggle_variable()
	#print("Test of function toggle_variable")
	assert var_0 == None
	#print("0")


# Generated at 2022-06-26 07:30:37.842236
# Unit test for function toggle_variable
def test_toggle_variable():
    assert (toggle_variable()) == None

# Generated at 2022-06-26 07:30:40.441688
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert len(get_workbench().commands) == 1
    assert get_workbench().commands[0]._command_id == 'toggle_pgzero_mode'

# Generated at 2022-06-26 07:30:41.182714
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
