

# Generated at 2022-06-26 07:23:37.809489
# Unit test for function toggle_variable
def test_toggle_variable():
    assert var_0.get() == False
    toggle_variable()
    assert var_0.get() == True


# Generated at 2022-06-26 07:23:39.763387
# Unit test for function toggle_variable
def test_toggle_variable():
    print('Unit test for toggle_variable()')
    toggle_variable()
    assert 1
    print('Passed.')


# Generated at 2022-06-26 07:23:41.664133
# Unit test for function update_environment
def test_update_environment():
    assert update_environment() == None


# Generated at 2022-06-26 07:23:43.397782
# Unit test for function load_plugin
def test_load_plugin():
    w = load_plugin()
    assert not get_workbench().get_option(_OPTION_NAME)


# Generated at 2022-06-26 07:23:44.338946
# Unit test for function update_environment
def test_update_environment():
    update_environment()


# Generated at 2022-06-26 07:23:46.980608
# Unit test for function toggle_variable
def test_toggle_variable():
    var_0 = get_workbench()

    var_0.set_default(_OPTION_NAME, False)
    test_case_0()


# Generated at 2022-06-26 07:23:50.736782
# Unit test for function update_environment
def test_update_environment():
    import thonny
    import os
    import builtins

    builtins.get_workbench = lambda: thonny.get_workbench()
    os.environ = {'LC_ALL': 'C.UTF-8'}
    var_0 = update_environment()
    assert var_0 is None



# Generated at 2022-06-26 07:23:51.824065
# Unit test for function load_plugin
def test_load_plugin():
    var_0 = load_plugin()


# Generated at 2022-06-26 07:24:03.035877
# Unit test for function load_plugin
def test_load_plugin():
    # Check if 'toggle_pgzero_mode' exists in the 'commands' dictionary
    # of the TkApplication class
    assert 'toggle_pgzero_mode' in get_workbench().commands
    # Check if 'toggle_pgzero_mode' is in the 'run' menu of the menu bar
    assert get_workbench().get_menu('run').index('toggle_pgzero_mode')
    # Check if 'pgzero_mode' exist in the '_options' dictionary
    # of the TkApplication class
    assert 'pgzero_mode' in get_workbench()._options
    # Check if the 'pgzero_mode' option has the value 'False'
    assert get_workbench()._options['pgzero_mode']['value'] is False

# Generated at 2022-06-26 07:24:08.521211
# Unit test for function load_plugin
def test_load_plugin():
    """Load plugin and verify environment variable has the expected value"""
    load_plugin()
    assert os.environ["PGZERO_MODE"] == "False"


# Generated at 2022-06-26 07:24:22.493729
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_default("run.pgzero_mode",False)
    get_workbench().get_variable("run.pgzero_mode").set(True)
    assert get_workbench().get_variable("run.pgzero_mode").get() == True
    toggle_variable()
    assert get_workbench().get_variable("run.pgzero_mode").get() == False
    toggle_variable()
    assert get_workbench().get_variable("run.pgzero_mode").get() == True
    toggle_variable()
    assert get_workbench().get_variable("run.pgzero_mode").get() == False

# Generated at 2022-06-26 07:24:25.222734
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default(_OPTION_NAME, False)
    var_0 = update_environment()


# Generated at 2022-06-26 07:24:26.928016
# Unit test for function toggle_variable
def test_toggle_variable():
    pass


# Generated at 2022-06-26 07:24:28.013308
# Unit test for function load_plugin
def test_load_plugin():
    assert_equal(load_plugin(), None)

# Generated at 2022-06-26 07:24:33.830035
# Unit test for function toggle_variable
def test_toggle_variable():
    assert var_0 == None, "expected 'None' but got %s" % repr(var_0)
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()
    assert var_0 == None, "expected 'None' but got %s" % repr(var_0)


# Generated at 2022-06-26 07:24:41.772372
# Unit test for function toggle_variable
def test_toggle_variable():
    # it should fail if the input argument is None
    try:
        toggle_variable(None)
        raise RuntimeError("Should have failed")
    except TypeError:
        pass

    # it should fail if the variable is not valid
    def get_variable_error(name):
        return None

    get_workbench().get_variable = get_variable_error

    try:
        toggle_variable("name")
        raise RuntimeError("Should have failed")
    except RuntimeError:
        pass

    # it should update the variable
    def get_variable(name):
        return name
    get_workbench().get_variable = get_variable
    get_workbench().set_default("name", False)

    toggle_variable("name")
    assert get_workbench().get_variable("name") == True

    toggle_variable("name")


# Generated at 2022-06-26 07:24:44.553623
# Unit test for function toggle_variable
def test_toggle_variable():
    # Should not raise any exception
    toggle_variable()
    assert True == True


# Generated at 2022-06-26 07:24:51.105881
# Unit test for function toggle_variable
def test_toggle_variable():
    var_0 = get_workbench().get_variable('run.pgzero_mode')
    var_0.set(False)
    var_0.get() == False
    toggle_variable()
    var_0.set(False)
    var_0.get() == False
    toggle_variable()
    var_0.set(False)
    var_0.get() == False
    toggle_variable()


# Generated at 2022-06-26 07:24:52.401972
# Unit test for function load_plugin
def test_load_plugin():
    # User code
    pass


# Generated at 2022-06-26 07:25:01.688434
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench()
    try:
        var_0 = False
        var_1 = "pgzero_mode"
        var_0 = get_workbench().set_default(var_1, var_0)
        var_2 = "toggle_pgzero_mode"
        var_3 = "run"
        var_4 = tr("Pygame Zero mode")
        var_5 = toggle_variable
        var_6 = "pgzero_mode"
        var_5 = get_workbench().add_command(var_2, var_3, var_4, var_5, flag_name=var_6, group=40)
        var_7 = update_environment()
        var_7
    except:
        raise
    return var_0, var_1, var_2, var_3, var_4, var_

# Generated at 2022-06-26 07:25:12.235059
# Unit test for function update_environment
def test_update_environment():
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()


# Generated at 2022-06-26 07:25:13.130015
# Unit test for function update_environment
def test_update_environment():
    x = update_environment()


# Generated at 2022-06-26 07:25:15.104165
# Unit test for function load_plugin
def test_load_plugin():
    # Smoketest the function
    assert load_plugin() is None


# Generated at 2022-06-26 07:25:16.798314
# Unit test for function update_environment
def test_update_environment():
    if update_environment():
        return 0
    else:
        return -1


# Generated at 2022-06-26 07:25:26.577127
# Unit test for function toggle_variable
def test_toggle_variable():
    # Set up the test
    try:
        # Get the data
        var_0 = toggle_variable()

    except:
        # Get the exception message
        var_1 = sys.exc_info()[1]
        # Raise it again
        raise
    else:
        # If all is ok, then return None
        pass

if __name__ == "__main__":
    t1 = multiprocessing.Process(target=test_case_0)
    t1.start()
    t1.join()
    print(test_toggle_variable())

# Generated at 2022-06-26 07:25:30.925298
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"

# Generated at 2022-06-26 07:25:41.956518
# Unit test for function load_plugin
def test_load_plugin():
    import sys
    import os
    import thonny
    from thonny.config import get_workbench
    get_workbench().set_default(_OPTION_NAME, True)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    os.environ["PGZERO_MODE"] = "auto"

# Generated at 2022-06-26 07:25:53.572341
# Unit test for function load_plugin
def test_load_plugin():
    from thonny.plugins.pgzero_mode import load_plugin
    from thonny.workbench import Workbench
    from thonny.languages import English
    from thonny.running import get_runner, get_backend_python_executable
    from thonny.ui_utils import CommonDialog
    import unittest
    import io, sys
    import os
    import shutil

    import tempfile 
    # Create a temporary directory
    tmp_dir = tempfile.mkdtemp()
    os.chdir(tmp_dir)
    wb = Workbench(English, get_runner(), get_backend_python_executable(),
                                       lambda: None,
                                       [],
                                       False,
                                       None,
                                       None)

# Generated at 2022-06-26 07:25:54.818511
# Unit test for function load_plugin
def test_load_plugin():
    test = load_plugin()
    assert test == None

# Generated at 2022-06-26 07:25:57.406087
# Unit test for function toggle_variable
def test_toggle_variable():
    get_workbench().set_option(_OPTION_NAME,False)
    toggle_variable()
    assert get_workbench().get_option(_OPTION_NAME) == True

# Generated at 2022-06-26 07:26:10.022011
# Unit test for function update_environment
def test_update_environment():
    assert False

# Generated at 2022-06-26 07:26:14.629675
# Unit test for function load_plugin
def test_load_plugin():
    """Unit test for function load_plugin"""
    test_case_0()


# Local Variables:
# coding: utf-8
# compile-command: "python3 -m unittest -v thonnycontrib.pgzero_mode"
# End:

# Generated at 2022-06-26 07:26:18.215433
# Unit test for function update_environment
def test_update_environment():
    try:
        get_workbench().set_simple_mode(False)
        update_environment()
        assert os.environ["PGZERO_MODE"] is not "auto"
    finally:
        get_workbench().set_simple_mode(True)

# Generated at 2022-06-26 07:26:19.047683
# Unit test for function load_plugin
def test_load_plugin():
    assert load_plugin() == None

# Generated at 2022-06-26 07:26:23.318022
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    var_1 = update_environment()


# Generated at 2022-06-26 07:26:26.982901
# Unit test for function update_environment
def test_update_environment():
    old_os_environ = os.environ.copy()
    wb = get_workbench()
    wb.set_default(_OPTION_NAME, False)
    test_update_environment_0()
    os.environ = old_os_environ



# Generated at 2022-06-26 07:26:34.103723
# Unit test for function update_environment
def test_update_environment():
    # Check that function updates environment variable
    update_environment()
    assert os.environ["PGZERO_MODE"] == str(get_workbench().get_option(_OPTION_NAME))
    # Check that function updates environment variable when in simple mode
    get_workbench().set_default(_OPTION_NAME, True)
    get_workbench().set_simple_mode(True)
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    # Check that function updates environment variable when not in simple mode
    get_workbench().set_simple_mode(False)
    update_environment()
    assert os.environ["PGZERO_MODE"] == str(get_workbench().get_option(_OPTION_NAME))


# Generated at 2022-06-26 07:26:35.424975
# Unit test for function update_environment
def test_update_environment():
    var_0 = update_environment()

# Generated at 2022-06-26 07:26:46.418489
# Unit test for function load_plugin
def test_load_plugin():
    # prepare
    prev_env = os.environ.copy()
    prev_settings = {}
    for key in [_OPTION_NAME]:
        prev_settings[key] = get_workbench().get_option(key)
    
    # invoke
    load_plugin()
    
    # compare
    assert get_workbench().get_option(_OPTION_NAME) == False
    assert "PGZERO_MODE" in os.environ
    assert os.environ["PGZERO_MODE"] == "False"
    
    # cleanup
    os.environ.clear()
    os.environ.update(prev_env)
    for key in prev_settings:
        get_workbench().set_option(key, prev_settings[key])


# Generated at 2022-06-26 07:26:47.313825
# Unit test for function load_plugin
def test_load_plugin():
    assert load_plugin() == None


# Generated at 2022-06-26 07:27:15.733786
# Unit test for function toggle_variable
def test_toggle_variable():
    assert(var_0 == False)

# Generated at 2022-06-26 07:27:16.669954
# Unit test for function load_plugin
def test_load_plugin():
    test_case_0()



# Generated at 2022-06-26 07:27:17.247915
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()

# Generated at 2022-06-26 07:27:22.944126
# Unit test for function load_plugin
def test_load_plugin():
    get_workbench().set_default(_OPTION_NAME, False)
    get_workbench().add_command(
        "toggle_pgzero_mode",
        "run",
        tr("Pygame Zero mode"),
        toggle_variable,
        flag_name=_OPTION_NAME,
        group=40,
    )
    update_environment()

# Generated at 2022-06-26 07:27:23.849751
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()


# Generated at 2022-06-26 07:27:28.433548
# Unit test for function toggle_variable
def test_toggle_variable():
    print("Unit test for function toggle_variable:ed_variables_0")
    print("\t Unit test for load_plugin")
    print("\t Unit test for load_plugin")
    # ed_variables_0 = "toggle_variable"
    # Check type of loaded module
    test_case_0()



# Generated at 2022-06-26 07:27:37.752867
# Unit test for function load_plugin
def test_load_plugin():
    from thonny import get_workbench
    _set_workbench(get_workbench())
    from thonny.plugin_manager import load_plugin
    import os
    import tempfile
    from unittest.mock import Mock
    from thonny.plugins.pgzero import _OPTION_NAME
    plugin_dir = tempfile.mkdtemp()

# Generated at 2022-06-26 07:27:41.611753
# Unit test for function update_environment
def test_update_environment():
    os.environ["PGZERO_MODE"] = "auto"
    update_environment()
    assert os.environ["PGZERO_MODE"] == "auto"
    assert update_environment() == None

# Generated at 2022-06-26 07:27:42.206283
# Unit test for function update_environment
def test_update_environment():
    var_1 = update_environment()


# Generated at 2022-06-26 07:27:46.546076
# Unit test for function load_plugin
def test_load_plugin():
    wb = get_workbench()
    wb._default_options = {}
    assert len(wb._commands) == 0
    assert _OPTION_NAME not in wb._default_options
    load_plugin()
    assert _OPTION_NAME in wb._default_options
    assert len(wb._commands) == 1


# Generated at 2022-06-26 07:28:42.943885
# Unit test for function update_environment
def test_update_environment():
    update_environment()


# Generated at 2022-06-26 07:28:45.738004
# Unit test for function load_plugin
def test_load_plugin():
    # Check that the present value of the variables are correct
    assert _OPTION_NAME == "run.pgzero_mode"

    # Unit test load_plugin
    load_plugin()



# Generated at 2022-06-26 07:28:55.112330
# Unit test for function load_plugin
def test_load_plugin():
    # Input arguments for the module
    get_workbench = MagicMock()
    get_workbench.set_default = MagicMock()
    get_workbench.add_command = MagicMock()
    get_workbench.in_simple_mode = MagicMock()

    load_plugin()

    # Checking if set_default was called with arguments
    assert get_workbench.set_default.call_args_list[0][0] == (_OPTION_NAME, False)
    
    # Checking if add_command was called with arguments
    assert get_workbench.add_command.call_args_list[0][1] == {'label': '_Pygame Zero mode', 'command': toggle_variable, 'flag_name': _OPTION_NAME, 'group': 40}

    # Checking if in_simple_mode was called
   

# Generated at 2022-06-26 07:28:55.882079
# Unit test for function toggle_variable
def test_toggle_variable():
    pass



# Generated at 2022-06-26 07:28:56.385624
# Unit test for function update_environment
def test_update_environment():
    pass

# Generated at 2022-06-26 07:28:58.054932
# Unit test for function toggle_variable
def test_toggle_variable():
    toggle_variable()
    assert var_0 == True


# Generated at 2022-06-26 07:28:59.836411
# Unit test for function toggle_variable
def test_toggle_variable():
    if var_0 == True:
        print("Value of var_0 is true")
    elif var_0 == False:
        print("Value of var_0 is false")
    else:
        print("Something else is changing the value of var_0")



# Generated at 2022-06-26 07:29:02.009275
# Unit test for function toggle_variable
def test_toggle_variable():
    assert callable(toggle_variable)
    # the assertion below is commented out since the function toggle_variable is
    # currently defined as an assignment, not a function definition.
    #assert var_0 == None


# Generated at 2022-06-26 07:29:02.393171
# Unit test for function update_environment
def test_update_environment():
    assert update_environment()

# Generated at 2022-06-26 07:29:03.094767
# Unit test for function update_environment
def test_update_environment():
    pass


# Generated at 2022-06-26 07:31:08.993332
# Unit test for function toggle_variable
def test_toggle_variable():
    # Nothing to test
    assert True

# Generated at 2022-06-26 07:31:18.996085
# Unit test for function update_environment
def test_update_environment():
    global os

# Generated at 2022-06-26 07:31:21.445792
# Unit test for function toggle_variable
def test_toggle_variable():
    # Test case 0
    # This test case is not yet fully implemented

    # Test case 1
    # This test case is not yet fully implemented

    pass

# Generated at 2022-06-26 07:31:22.392339
# Unit test for function update_environment
def test_update_environment():
    assert update_environment() == None


# Generated at 2022-06-26 07:31:23.237355
# Unit test for function load_plugin
def test_load_plugin():
    load_plugin()
    assert True


# Generated at 2022-06-26 07:31:24.393018
# Unit test for function update_environment
def test_update_environment():
    var_0 = os.environ["PGZERO_MODE"] == "auto"


# Generated at 2022-06-26 07:31:27.127765
# Unit test for function update_environment
def test_update_environment():
    wb = get_workbench()
    os.environ["PGZERO_MODE"] = "auto"
    update_environment()

    # Test
    if not isinstance(get_workbench(), 'auto'):
        raise AssertionError
    if not isinstance(get_workbench(), False):
        raise AssertionError



# Generated at 2022-06-26 07:31:28.407730
# Unit test for function toggle_variable
def test_toggle_variable():
    assert var_0 == False, "test case 0 failed"

# Generated at 2022-06-26 07:31:29.799152
# Unit test for function toggle_variable
def test_toggle_variable():
    # test case 0
    result = test_case_0()
    assert result is None


# Generated at 2022-06-26 07:31:30.695471
# Unit test for function load_plugin
def test_load_plugin():
    var_0 = load_plugin()
