

# Generated at 2022-06-22 21:40:56.740230
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # TODO: Write unit tests for function
    pass

# Generated at 2022-06-22 21:41:05.302310
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Unit test for function get_best_parsable_locale
    '''

    from ansible.module_utils.basic import AnsibleModule

    am = AnsibleModule(
        argument_spec={},
    )

    # test with no arguments
    assert get_best_parsable_locale(am) == 'C'

    # test with preferences
    pref = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    assert get_best_parsable_locale(am,pref) == 'C'

# Generated at 2022-06-22 21:41:14.303356
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    mod = AnsibleModule()
    mod.run_command = lambda x: (0, 'C.utf8\nen_US.utf8\nC', '')
    assert get_best_parsable_locale(mod, preferences=None) == 'C.utf8'

    mod.run_command = lambda x: (1, 'C.utf8\nen_US.utf8\nC', '')
    assert get_best_parsable_locale(mod, preferences=None) == 'C'

    mod.run_command = lambda x: (0, '', '')
    assert get_best_parsable_locale(mod, preferences=None) == 'C'

    mod.run_command = lambda x: (1, '', '')
   

# Generated at 2022-06-22 21:41:23.438616
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)

    # Should raise exception if locale command not found
    try:
        get_best_parsable_locale(module, raise_on_locale=True)
        assert False
    except RuntimeWarning:
        pass

    # Should return a locale
    locale = get_best_parsable_locale(module)
    assert locale

    # Should return a locale if preferences are specified
    locale = get_best_parsable_locale(module, preferences=['C'])
    assert locale == 'C'

    # Should return the first preferred locale that matches
    locale = get_best_parsable_locale(module, preferences=['utf8', 'C'])
    assert locale

# Generated at 2022-06-22 21:41:34.300376
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Test to get best parsable locale
    '''
    class AnsibleModuleMock:
        def __init__(self):
            pass

        def get_bin_path(self, bin_path):
            return bin_path

        def run_command(self, command):
            out = '''
            C
            C.UTF-8
            en_US.utf8
            POSIX
            '''
            return 0, out, ''

    module = AnsibleModuleMock()
    assert get_best_parsable_locale(module) == 'C.utf8'
    assert get_best_parsable_locale(module, ['POSIX', 'C', 'en_US.utf8']) == 'POSIX'

# Generated at 2022-06-22 21:41:43.116109
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    assert get_best_parsable_locale(None) == 'C'
    assert get_best_parsable_locale(None, ['en_US']) == 'C'
    assert get_best_parsable_locale(None, ['en_US', 'C']) == 'C'
    assert get_best_parsable_locale(None, ['C.UTF-8']) == 'C'
    assert get_best_parsable_locale(None, ['en_US'], True) == 'C'

    # Get information from command execution
    rc, out, err = (0, '', '')
    # class MockModule(object):
    #     def __init__(self, rc, out, err):
    #         self.rc = rc
    #         self.out = out
   

# Generated at 2022-06-22 21:41:54.895743
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.six import PY2
    from ansible.module_utils.basic import AnsibleModule

    class FakeModule(object):
        def __init__(self, result):
            self.result = result

        def get_bin_path(self, tool):
            return tool

        def run_command(self, args, check_rc=True):
            return self.result.pop()

    # FakeModule's run_command will return results for each command in
    # order. For example, FakeModule([(0, "a\n", ''), (0, 'b\n', '')]
    # is a module that will return 'a' when asked for locale -a, and
    # 'b' if asked again.

    # First check that we fail with the locale present but locale -a
    # failing.
    fake

# Generated at 2022-06-22 21:42:02.038123
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    mock_module = MockModule()
    locale = get_best_parsable_locale(mock_module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX'])
    assert locale == 'C'

    # Test that when no locale is found, 'C' is returned
    mock_module.run_command.return_value = ['', '', '']
    locale = get_best_parsable_locale(mock_module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX'])
    assert locale == 'C'

    # Test that when a command fails, 'C' is returned
    mock_module.run_command.return_value = ['', '', 1]

# Generated at 2022-06-22 21:42:10.510072
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # mockup an AnsibleModule instance
    class AnsibleModule:
        def __init__(self):
            self.bin_path_mock = '/usr/bin'

        def get_bin_path(self, tool_name):
            self.tool_name = tool_name
            return self.bin_path_mock + '/%s' % tool_name

        def run_command(self, cmd):
            self.cmd = cmd
            output_dict = {
                '/usr/bin/locale -a': ['C', 'C.UTF-8', 'en_US.utf8', 'POSIX'],
                '/usr/bin/locale -a': [],
            }
            if cmd[1] == '-a':
                # normal output
                return 0, output_dict[cmd], ''

# Generated at 2022-06-22 21:42:21.723696
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        from ansible.module_utils.basic import AnsibleModule
    except ImportError:
        pass

# Generated at 2022-06-22 21:42:32.764335
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import platform
    import tempfile
    import warnings

    from ansible.module_utils.basic import AnsibleModule

    class Module(object):

        def __init__(self, stdout=None, stderr=None, **kwargs):
            self.args = {'platform': platform.system().lower(), 'warn': True}
            self.params = {'platform': platform.system().lower(), 'warn': True}
            self.tmpdir = tempfile.mkdtemp()
            self.stdout = stdout
            self.stderr = stderr

        def get_bin_path(self, arg, required=False, opt_dirs=[]):
            if arg == 'locale':
                return '/usr/bin/locale'
            else:
                raise Exception("unsupported lookup: %s" % arg)

       

# Generated at 2022-06-22 21:42:41.325085
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import unittest
    import unittest.mock as mock
    from ansible.module_utils import basic
    from ansible.module_utils.six import PY3

    class MockModule(basic.AnsibleModule):
        def __init__(self):
            super(MockModule, self).__init__()
            self.run_command = mock.Mock()

    class TestGetBestParsableLocaleCase(unittest.TestCase):
        def setUp(self):
            self.stdin = None
            self.stdout = None
            self.stderr = None

            self.module = MockModule()

            self.module.run_command.return_value = (0, self.stdout, self.stderr)


# Generated at 2022-06-22 21:42:45.933435
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    module = ansible.module_utils.basic.AnsibleModule(argument_spec=dict())
    locale = get_best_parsable_locale(module)
    assert locale == 'C'

# Generated at 2022-06-22 21:42:57.519950
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class FakeModule:
        def __init__(self):
            self.fail_json = False
            self.run_command_return_value = (0, "", "")

        def get_bin_path(self, app):
            return True

        def run_command(self, command):
            return self.run_command_return_value

    def test_get_best_parsable_locale_exception():
        module = FakeModule()
        module.fail_json = True
        module.run_command_return_value = (1, "", "")
        assert get_best_parsable_locale(module) == 'C'

    def test_get_best_parsable_locale_defaults():
        module = FakeModule()

# Generated at 2022-06-22 21:43:09.691685
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            preferences=dict(type='list', default=['C.utf8', 'en_US.utf8', 'C', 'POSIX', 'en_US.utf8'])
        ),
        supports_check_mode=True
    )

    # Test 1: check_mode
    result = get_best_parsable_locale(module, module.params['preferences'])
    module.exit_json(changed=True, locale=result)

    # Test 2: test with expected locale
    result = get_best_parsable_locale(module, ['C'])
    module.exit_json(changed=True, locale=result)

    # Test 3: test with unexpected locale

# Generated at 2022-06-22 21:43:17.255596
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None, ['C.UTF-8']) == 'C.UTF-8', 'should get C.UTF-8'
    assert get_best_parsable_locale(None, ['fr_FR.UTF-8', 'C.UTF-8']) == 'fr_FR.UTF-8', 'should get fr_FR.UTF-8'
    assert get_best_parsable_locale(None, ['fr_FR.UTF-8', 'de_DE.UTF-8']) == 'fr_FR.UTF-8', 'should get fr_FR.UTF-8'

# Generated at 2022-06-22 21:43:26.611074
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.basic import AnsibleModule

    class MockAnsibleModule(AnsibleModule):

        def __init__(self):
            self.run_command_expectations = dict()
            self.run_command_expectation_errors = dict()
            self.get_bin_path_expectations = dict()
            self.get_bin_path_expectation_errors = dict()

        def run_command(self, cmd, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False):
            expected = self.run_command_expectations[cmd]
            ret = dict()
            ret['rc'] = expected['rc']

# Generated at 2022-06-22 21:43:37.287856
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import os

    os.environ['LC_ALL'] = "C"
    # no locale available, no preferences
    assert get_best_parsable_locale(None) == "C"
    # no locale available, no preferences, raise on locale
    assert get_best_parsable_locale(None, raise_on_locale=True) == "C"
    # no locale available, with preferences
    assert get_best_parsable_locale(None, preferences=['foo']) == "C"
    # no locale available, with preferences, raise on locale
    assert get_best_parsable_locale(None, preferences=['foo'], raise_on_locale=True) == "C"
    # locale available, no preferences

# Generated at 2022-06-22 21:43:48.232694
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.utils.template

    # Create a fake module
    class FakeModule(object):
        params = {}
        _ansible_version = "2.0"

        def fail_json(self, *args, **kwargs):
            print("FAIL")

        def get_bin_path(self, command, required=False):
            if command == "locale":
                return "/usr/bin/locale"


# Generated at 2022-06-22 21:43:57.402195
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils import basic
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.six import text_type

    class MockAnsibleModule(object):
        def __init__(self):
            self.fail_json_called = False
            self.fail_json_msg = None
            self.exit_args = None

        def exit_json(self, **kwargs):
            self.exit_args = kwargs

        def get_bin_path(self, executable):
            return '/bin/' + executable


# Generated at 2022-06-22 21:44:08.549916
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import os
    import shutil
    import tempfile
    import unittest

    def mkfile(module, path, lines):
        with open(path, "w") as f:
            for line in lines:
                f.write(line + "\n")

    def run(module, params, expected_result):
        result = get_best_parsable_locale(module, raise_on_locale=params['raise_on_locale'])
        assert expected_result == result

    class TestGetBestParsableLocale(unittest.TestCase):

        def _test_get_best_pl(self, params, expected_result, locale_lines):
            with tempfile.TemporaryDirectory() as tmpdir:
                # Create mock locale command
                locale

# Generated at 2022-06-22 21:44:18.601534
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Mock module.run_command
    cmd_result1 = dict(rc=0, out='C\nen_US.utf8\nen_US.UTF-8\nen_US\nen_US.iso88591\nen_US.iso885915@euro\nC.utf8\n', err='')
    cmd_result2 = dict(rc=1, out='', err='locale: Cannot set LC_CTYPE to default locale: No such file or directory \n')

    def run_command_side_effect(*args, **kwargs):
        if args[0] == '/usr/bin/env':
            return cmd_result1
        else:
            return cmd_result2

    module.run_

# Generated at 2022-06-22 21:44:25.163985
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    def run_module(module_args):
        module_args = json.dumps(module_args)
        return AnsibleModule(argument_spec={})

    assert get_best_parsable_locale(run_module([])) == 'C'



# Generated at 2022-06-22 21:44:36.712225
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import tempfile
    from ansible.module_utils.basic import AnsibleModule

    data = '''
    #!/usr/bin/python
    import pickle
    import sys

    module = AnsibleModule(argument_spec={})

    prefs = module.params['prefs']
    raise_on_locale = module.params['raise_on_locale']

    with open('{}', 'w') as f:
        pickle.dump(get_best_parsable_locale(module, prefs, raise_on_locale), f)
    '''

    tmp_file = tempfile.mktemp()
    with open(tmp_file, 'w') as f:
        f.write(data.format(tmp_file))


# Generated at 2022-06-22 21:44:47.707927
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    # Simulate AnsibleModule object
    module = AnsibleModule(argument_spec={})

    # Simulate locale list
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    avail_locales = ["en_US", "en_US.iso88591", "en_US.utf8", "en_US@users"]

    #
    # Test when all preferences are available
    #
    mod_get_bin_path = lambda name: "/usr/bin/locale"
    module.get_bin_path = mod_get_bin_path
    mod_run_command = lambda cmd, check_rc=None: (0, "\n".join(avail_locales), "")
    module.run_command = mod

# Generated at 2022-06-22 21:44:59.187944
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleFallbackNotFound
    import os
    import tempfile
    import shutil

    # Unit test scenario I: Locale tool is not present in the system. Neither of the
    # preferred locales are found in the system. The function should return 'C'
    # and should not raise any exception.

    available_locales = ['de_DE.utf8', 'de_DE.UTF-8']
    # Initialize the AnsibleModule object
    module = AnsibleModule({})
    # Set the locale path to a temporary directory so that 'locale' tool is not found
    module.LOCALEPATH = tempfile.mkdtemp()
    assert(module.LOCALEPATH is not None)
    # Test if get_best_

# Generated at 2022-06-22 21:45:05.042387
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={'preferences': dict(type='list', default=['C.UTF-8'])},
                           supports_check_mode=False)

    best_locale = get_best_parsable_locale(module)
    assert best_locale != None
    assert best_locale.endswith('.UTF-8')

# Generated at 2022-06-22 21:45:18.284588
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    assert get_best_parsable_locale(None) == 'C'
    assert get_best_parsable_locale(None, ['C']) == 'C'
    assert get_best_parsable_locale(None, ['de_DE.utf8']) == 'C'
    assert get_best_parsable_locale(None, ['de_DE.utf8', 'en_US.utf8']) == 'en_US.utf8'
    assert get_best_parsable_locale(None, ['en_US.utf8']) == 'en_US.utf8'
    assert get_best_parsable_locale(None, ['en_US.utf8', 'de_DE.utf8']) == 'en_US.utf8'
    assert get_best_pars

# Generated at 2022-06-22 21:45:29.585486
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Test if the locale parser can return the preferred locale,
        or raise an exception if locale command is not found.
    '''

    import ansible.module_utils.basic
    import os

    # test if get_best_parsable_locale() returns the correct preferred locale
    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )


# Generated at 2022-06-22 21:45:40.004111
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    These tests are for function get_best_parsable_locale as it's used by unit and integration tests.
    '''

    class FakeModule(object):
        def __init__(self):
            self.run_command_results = []
            self.run_command_calls = []
            self.get_bin_path_results = []

        def get_bin_path(self, bin):
            # there are no tools on a fake system!
            self.get_bin_path_results.append(None)
            return None

        def run_command(self, command):
            self.run_command_calls.append(command)
            return self.run_command_results.pop(0)

    # test case 01, no locale tool
    fake_module = FakeModule()
    fake_module.run

# Generated at 2022-06-22 21:45:51.676533
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    mod = AnsibleModule()

    assert get_best_parsable_locale(mod) == 'C', \
        "Expected 'C' locale, but found '%s' instead" % get_best_parsable_locale(mod)

    # Create a list of locales that exist, and create a preference list that
    # will be missing replacements, but will be satisfied by the POSIX locale
    # that is always available
    locales = [
        'C.utf8',
        'C.UTF-8',
        'en_US.utf8',
        'en_US.UTF-8',
        'C',
        'POSIX',
        'en_US.iso88591',
        'en_US.ISO8859-1'
    ]

# Generated at 2022-06-22 21:45:56.888961
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    m = AnsibleModule(argument_spec={}, supports_check_mode=True)

    try:
        result = get_best_parsable_locale(m, raise_on_locale=True)
    except RuntimeWarning as e:
        result = str(e)

    assert result == "Could not find 'locale' tool"

# Generated at 2022-06-22 21:46:06.001794
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module_mock = MockModule()
    module_mock.run_command = Mock(return_value=(0, 'C\nen_US.utf8\nPOSIX\n', ''))
    # autodetect what we have on the system
    best_locale = get_best_parsable_locale(module_mock)
    assert best_locale == 'C'

    # only have POSIX
    expected = 'POSIX'
    module_mock.run_command = Mock(return_value=(0, 'POSIX\n', ''))
    best_locale = get_best_parsable_locale(module_mock)
    assert best_locale == expected

    # prefer C.utf8
    expected = 'C.utf8'

# Generated at 2022-06-22 21:46:17.296034
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    import os
    import json
    import tempfile
    import pytest
    import ansible.modules.system.locale as locale

    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    # Get the executable for the script.
    this_module_path = os.path.dirname(os.path.realpath(__file__))
    executable = sys.executable
    if not executable:
        pytest.skip('python executable not found')

    locale_module = locale.Locale()

    # Create a temp directory to store the test script in.
    tmpdir = tempfile.mkdtemp()

    # Path to the test data directory.
    test_data_path = os.path.join(this_module_path, 'test', 'data')

    #

# Generated at 2022-06-22 21:46:26.720194
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible_collections.notmintest.not_a_real_collection.tests.unit.compat.mock import patch
    from ansible.module_utils.basic import AnsibleModule
    module_helper = AnsibleModule(
        argument_spec={
            'preferences': {'type': 'list'},
            'raise_on_locale': {'type': 'bool'},
        }
    )
    get_best_parsable_locale(module_helper)

    with patch("ansible.module_utils.six.moves.builtins.open") as mock_open:
        get_best_parsable_locale(module_helper, raise_on_locale=True)

    module_helper.fail_json = lambda msg: msg
    assert module_helper.fail_

# Generated at 2022-06-22 21:46:28.357617
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None) is 'C'

# Generated at 2022-06-22 21:46:37.745656
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six.moves import StringIO
    from ansible_collections.ansible.netcommon.plugins.module_utils.network.common.utils import load_provider
    from ansible_collections.ansible.netcommon.tests.unit.compat import unittest
    from ansible_collections.ansible.netcommon.tests.unit.compat.mock import MagicMock

    class AnsibleModuleTest(AnsibleModule):

        _ANSIBLE_ARGS = []

        def __init__(self, *args, **kwargs):
            super(AnsibleModuleTest, self).__init__(*args, **kwargs)

# Generated at 2022-06-22 21:46:42.256565
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    # On Travis CI, locale -a returns only C
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-22 21:46:52.855076
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.common.process import get_bin_path
    dummy_module = lambda: None
    dummy_module.get_bin_path = get_bin_path
    dummy_module.run_command = lambda x, y: (0, 'af_ZA.utf8\naf_ZA.utf-8\nC\nC.utf8\nC.UTF-8\n', '')
    assert get_best_parsable_locale(dummy_module, preferences=['af_ZA.utf8', 'C.UTF-8', 'C', 'POSIX']) == 'C.UTF-8'

# Generated at 2022-06-22 21:47:04.331674
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    m = AnsibleModule()
    assert m.get_bin_path('locale')
    assert get_best_parsable_locale(m) == 'C'
    assert get_best_parsable_locale(m, preferences=['C']) == 'C'
    assert get_best_parsable_locale(m, preferences=['POSIX']) == 'C'
    assert get_best_parsable_locale(m, preferences=['not.a.locale.name']) == 'C'
    assert get_best_parsable_locale(m, preferences=['POSIX', 'not.a.locale.name', 'C']) == 'C'

# Generated at 2022-06-22 21:47:13.362982
# Unit test for function get_best_parsable_locale

# Generated at 2022-06-22 21:47:22.301676
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes

    am = AnsibleModule(argument_spec={})
    am._module = am
    am._socket_path = '\x00'
    am._display.verbosity = 0
    am.run_command = lambda x: (0, to_bytes('C.utf8\nen_US.utf8\nen_US.iso88591'), '')

    assert get_best_parsable_locale(am) == 'C.utf8'



# Generated at 2022-06-22 21:47:32.417696
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class MockModule(object):
        def __init__(self, locale_path=None, run_command_output=None, run_command_rc=None):
            self.params = dict()
            self.run_command_rc = run_command_rc
            self.run_command_output = run_command_output
            self.locale_path = locale_path
            self.fail_json = lambda **kwargs: dict(failed=True, msg="", **kwargs)

        def get_bin_path(self, name, opt_dirs=None, required=False):
            return self.locale_path

        def run_command(self, command):
            rc = self.run_command_rc
            out = self.run_command_output

            return rc, out, ""

    # check if we get "C" when

# Generated at 2022-06-22 21:47:38.230702
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = FakeModule()
    module.run_command = lambda cmd, raise_on_locale=None: ([0, 'C\nen_US.utf8'], '', '')
    assert 'C' == get_best_parsable_locale(module)
    assert 'C' == get_best_parsable_locale(module, ['en_US.utf8', 'C'])



# Generated at 2022-06-22 21:47:46.122869
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    class TestModule:
        def run_command(self, command):
            if command == ['locale', '-a']:
                return 0, 'C\nC.utf8\nen_US.utf8\nen_US\n', ''
            else:
                raise Exception('Unexpected')

        def get_bin_path(self, command):
            # let's pretend this exists
            return 'locale'

    by_default_locale = get_best_parsable_locale(TestModule()).strip()
    assert by_default_locale == 'C'

    by_preference_locale = get_best_parsable_locale(TestModule(), preferences=['C.utf8', 'en_US.utf8']).strip()
    assert by

# Generated at 2022-06-22 21:47:55.377872
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # we need to provide a fake AnsibleModule instance
    from ansible.module_utils import basic
    import io

    class StubAnsibleModule():
        def __init__(self):
            self.run_command_called = False
            self.run_command_return_value = None
            self.run_command_exception = None

        def get_bin_path(self, command, required=False):
            if command == "locale":
                # return a valid path
                return "/bin/locale"
            else:
                return None


# Generated at 2022-06-22 21:48:03.157605
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.locales import get_best_parsable_locale

    # Setup
    m = AnsibleModule(argument_spec={})
    m.run_command = run_command

    # Test no locale on path
    assert get_best_parsable_locale(m, raise_on_locale=True) == 'C'

    # Test success with locale found
    assert get_best_parsable_locale(m, preferences=['C.utf8', 'C']) == 'C.utf8'

    # Test unsucces with locale not found
    assert get_best_parsable_locale(m, preferences=['fr', 'C']) == 'C'

    # Test error if no locale found and no default

# Generated at 2022-06-22 21:48:12.529778
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    class ModuleArgs(object):
        def __init__(self):
            self.get_bin_path_results = ['locale']
            self.run_command_results = {}
            self.run_command_results['default'] = (0, 'C.utf8', '')
            self.run_command_results['no_locale_tool'] = None
            self.run_command_results['no_output'] = (0, '', '')
            self.run_command_results['rc_one'] = (1, '', '')
            self.expected_results = {}
            self.expected_results['default'] = 'C.utf8'
            self.expected_results['prefer_en_US'] = 'en_US.utf8'

# Generated at 2022-06-22 21:48:19.084838
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from tempfile import NamedTemporaryFile
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            preferences=dict(type='str', default=['en_US.utf8', 'C', 'POSIX'], required=False),
        ),
    )

    output = {}
    input = {
        'preferences': ['en_US.utf8', 'C.utf8', 'POSIX', 'C'],
    }
    input['preferences'].extend(['en_US.utf8', 'C.utf8', 'POSIX', 'C'])
    output['preferences'] = input['preferences']

# Generated at 2022-06-22 21:48:29.746695
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    # The test module has attached the ansible.cfg file
    # to it.
    test_module = AnsibleModule({})

    # The current locale on my Linux workstation is 'en_US.utf8'.
    # On my Mac workstation the locale is 'C'

    # Test with the default preferences on my Linux workstation
    best_locale = get_best_parsable_locale(test_module)
    assert best_locale == 'C.utf8'

    # Test with the default preferences on my Mac workstation
    best_locale = get_best_parsable_locale(test_module)
    assert best_locale == 'C'

    # Test with a bad preferred locale on my Mac workstation
    best_locale = get_best_

# Generated at 2022-06-22 21:48:35.745547
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        from ansible.module_utils.basic import AnsibleModule
    except ImportError:
        print("could not import ansible.module_utils.basic")
        exit()

    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

    from mock import Mock, MagicMock
    module.get_bin_path = Mock(return_value=True)
    module.run_command = MagicMock(return_value=(0, '', ''))
    assert get_best_parsable_locale(module) == 'C'
    # we assert that there is only ever one call to get_bin_path and that is at the very beginning
    # we mock run_command to return 0 because we should pass the call to run_command if we have module.get

# Generated at 2022-06-22 21:48:46.082954
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import unittest
    import mock

    class MockModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs
            self.failed = False

        def exit_json(self, **kwargs):
            return

        def fail_json(self, **kwargs):
            self.failed = True

        def get_bin_path(self, path):
            return path

    class TestGetBestParsableLocale(unittest.TestCase):
        def test_get_best_parsable_locale(self):
            # Basic test to make sure we can run
            module = MockModule(use_docker=False,
                                use_persistent_connections=False)
            result = get_best_parsable_locale(module)
            assert result == 'C'



# Generated at 2022-06-22 21:48:56.587775
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import re

    # Create a blank AnsibleModule
    module = AnsibleModule(argument_spec={})

    # We expect to successfully get a locale found
    locale = get_best_parsable_locale(module)
    assert len(locale) > 0

    # Verify we have an ascii compatible locale
    assert re.match('^[\w\/\_\-\+]+$', locale)

    # Verify we have an english locale
    assert re.match('^en', locale)

if __name__ == '__main__':
    # Run unit tests
    test_get_best_parsable_locale()

# Generated at 2022-06-22 21:49:06.410790
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    def _mock(path, *args, **kwargs):
        return 0, ['C', 'C.UTF-8', 'en_US.UTF-8'], ''

    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    assert get_best_parsable_locale(None, preferences, raise_on_locale=False) == 'C'

    preferences = ['en_US.utf8', 'POSIX', 'C']
    assert get_best_parsable_locale(None, preferences, raise_on_locale=False) == 'C'

    preferences = ['es_US.utf8', 'de_DE.utf8', 'ar_AE.utf8']

# Generated at 2022-06-22 21:49:12.445772
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    fake_module = FakeModule()
    fake_module.set_output([0, 'C.utf8\nen_US.utf8\nC\nPOSIX', '', 0])
    fake_module.set_bin_path('locale')

    # Test default settings
    assert get_best_parsable_locale(fake_module) == 'C'

    # Test for a specific locale
    fake_module.set_output([0, 'C.utf8\nen_US.utf8\nC\nPOSIX', '', 0])
    assert get_best_parsable_locale(fake_module, ['en_US.utf8']) == 'en_US.utf8'

    # Test for a specific locale, but we don't have it

# Generated at 2022-06-22 21:49:22.677046
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Unit tests for function get_best_parsable_locale
    '''

    import os
    import sys
    import platform
    import tempfile
    import unittest

    from ansible.module_utils.basic import *

    if not os.path.isabs(__file__):
        __file__ = os.path.join(os.getcwd(), __file__)

    DATA_DIR = os.path.normpath(os.path.join(os.path.dirname(__file__), '..', 'unit', 'data'))
    FIXTURE_DATA = {}

    def set_module_args(module_args):
        '''
            Helper to load the test arguments
        '''

        module_args = dict(module_args)

# Generated at 2022-06-22 21:49:29.372455
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.basic import AnsibleModule

    # function being tested
    from ansible.module_utils.facts.locale import get_best_parsable_locale

    # needed to mock properly for parsing
    from ansible.module_utils.facts import module_facts

    class TestModule(object):
        def __init__(self, prefs=None, raise_on_locale=False):
            self.bin_path_returns = dict(
                locale='/usr/bin/locale',
            )

            self.bin_paths = dict()


# Generated at 2022-06-22 21:49:30.680126
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale({}) == 'C'

# Generated at 2022-06-22 21:49:36.275143
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    preference = ['C.UTF-8', 'en_US.utf8', 'C', 'POSIX']
    locale = get_best_parsable_locale(module, preference, raise_on_locale=True)
    assert locale == 'en_US.utf8'

# Generated at 2022-06-22 21:49:44.738287
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Test for get_best_parsable_locale
    '''

    from ansible.modules.system.locale import get_bin_path

    # Create a mock ansible module
    from ansible.modules.system import locale as ansible_locale
    module = ansible_locale
    module.run_command = run_command
    module.get_bin_path = get_bin_path

    # Set a mock locale binary
    module._is_bin_path_overridden = {'locale': 'locale_test_bin'}
    available_locales = ['POSIX', 'ascii', 'C.UTF-8', 'en_US.UTF-8']

    # Set a mock environment

# Generated at 2022-06-22 21:49:50.277151
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    This function unit tests the function get_best_parsable_locale
    '''

    import test.units.module_utils.basic as basic

    class TestLocaleCommand():
        '''
        Mock class to simulate a locale command
        '''
        def __init__(self):
            self.locale = 'C'

        def run_command(self, locale_cmd):
            '''
            Simulate a locale command
            '''
            return 0, self.locale, ''

    # test positive case
    # no preferences given, simulate C
    test_module = TestLocaleCommand()
    assert get_best_parsable_locale(test_module) == 'C'

    # test positive case
    # preferences given, simulate C.utf8

# Generated at 2022-06-22 21:49:59.833187
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    import mock

    # note, an actual module has a lot of behavior and this mock prevents exploding

# Generated at 2022-06-22 21:50:05.336818
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_native
    import sys
    import locale

    m = AnsibleModule(
        argument_spec=dict(
            check=dict(type='bool', required=False, default=False),
            raise_on_locale=dict(type='bool', required=False, default=False),
            preferences=dict(type='list', required=False, default=None),
        ),
        supports_check_mode=True
    )

    # python3 sometimes returns C.UTF-8, with the period.  So strip it out

# Generated at 2022-06-22 21:50:16.081563
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class AnsibleModule:
        def get_bin_path(self, arg):
            return arg

        def run_command(self, arg):
            return 0, "", ""

    preferences = ['C.utf8', 'en_us.utf8', 'C', 'POSIX']
    assert preferences == get_best_parsable_locale(AnsibleModule(), preferences)

    preferences = ['C.utf8', 'en_us.utf8', 'POSIX', 'C']
    assert 'C' == get_best_parsable_locale(AnsibleModule(), preferences)

    preferences = ['C.utf8', 'POSIX', 'English', 'C']
    assert 'C' == get_best_parsable_locale(AnsibleModule(), preferences)

# Generated at 2022-06-22 21:50:23.294723
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    module = ansible.module_utils.basic.AnsibleModule(name='get_best_parsable_locale', argument_spec={}, supports_check_mode=True)
    assert get_best_parsable_locale(module) == 'C', "Test get_best_parsable_locale fails because 'C' locale is not an option"

# Generated at 2022-06-22 21:50:30.275746
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    # Test get_best_parsable_locale with AnsibleModule mocks
    module = AnsibleModule()

    # Test get_best_parsable_locale with a locale that is not available
    module.get_bin_path = lambda x: '/usr/bin/locale'
    module.run_command = lambda x: (0, '\nC\nen_US.utf8\nC.utf8\nen_US.utf8\nen_US.utf8', '')
    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, ['en_US.utf8']) == 'en_US.utf8'
    assert get_best_parsable_locale

# Generated at 2022-06-22 21:50:42.035786
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    class module():
        def __init__(self):
            self.bin_path = {'locale': '/bin/locale'}

        class run_command:
            def return_value(self, rc, out, err):
                return rc, out, err

    def run_command_func(command):
        if command == ['/bin/locale', '-a']:
            return 0, 'C.utf8\nen_US.utf8\nPOSIX\nC', ''
        elif command == ['/bin/locale']:
            raise RuntimeWarning('Could not find "locale" tool')
        else:
            return 1, '', ''

    m = module()
    m.run_command = run_command_func

    # Test without explicit preferences

# Generated at 2022-06-22 21:50:49.521313
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = object()
    module.get_bin_path = lambda x: x
    module.run_command = lambda x: (0, 'C\nen_US.utf8', None)
    assert get_best_parsable_locale(module) == 'en_US.utf8'

    module.run_command = lambda x: (0, 'C\nen_US.utf8\nen_US.utf8', None)
    assert get_best_parsable_locale(module) == 'en_US.utf8'

    module.run_command = lambda x: (0, 'C\nen_US.utf8\nen_GB.utf8', None)
    assert get_best_parsable_locale(module) == 'en_US.utf8'


# Generated at 2022-06-22 21:50:58.940739
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import OrderedDict
    import ansible.module_utils.include_role

    if not hasattr(ansible.module_utils.include_role, 'RunResult'):
        class RunResult(object):
            def __init__(self, rc, out, err):
                self.rc = rc
                self.out = out
                self.err = err
        ansible.module_utils.include_role.RunResult = RunResult

    class ModuleExit(Exception):
        pass

    class AnsibleModule(object):
        def get_bin_path(self, tool):
            if tool == 'locale':
                return '/bin/locale'
