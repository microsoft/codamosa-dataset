

# Generated at 2022-06-22 21:41:02.822225
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    # a fake module for testing
    class FakeModule:

        def __init__(self):
            self.fail_json = None
            self.params = None
            self.exit_json = None
            self.run_command = None
            self.get_bin_path = None

        def fail_json(self, **kwargs):
            pass

        def exit_json(self, **kwargs):
            pass

        def get_bin_path(self, binary):
            pass

    module = FakeModule()

    # test out preferred locales with the C locale
    module.run_command = lambda args, check_rc=True: (0, "C\nC.utf8", '')

# Generated at 2022-06-22 21:41:12.358608
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModuleError


# Generated at 2022-06-22 21:41:13.826083
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None) == 'C'

# Generated at 2022-06-22 21:41:15.312411
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None) == 'C'

# Generated at 2022-06-22 21:41:23.854434
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils import basic
    import os

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )

    # Test with a fake locale
    preferences = ['a', 'b']

    fd, temp_path = tempfile.mkstemp()
    try:
        os.close(fd)
        module.get_bin_path = lambda _: temp_path

        f = open(temp_path, 'w')
        print("""# Comment
a
c
b
""", file=f)
        f.close()

        assert 'a' == get_best_parsable_locale(module, preferences)
    finally:
        os.remove(temp_path)

    # Test

# Generated at 2022-06-22 21:41:31.933243
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils import basic
    import pytest
    from mock import patch

    # Test case 1
    # get_best_parsable_locale() without any args
    # We expect 'C' as return value
    assert get_best_parsable_locale(basic) == 'C'

    # Test case 2
    # get_best_parsable_locale() is called with a preferred locale
    # that is not installed
    # We expect 'C' as return value
    assert get_best_parsable_locale(basic, preferences=['a_b_c']) == 'C'

    # Test case 3
    # get_best_parsable_locale() is called with a preferred locale
    # that is not installed and raise_on_locale arg set to True
    # We expect Runtime

# Generated at 2022-06-22 21:41:43.355264
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    """
    Test case: Return the first matched preferred locale or 'C' which is the default
    Test data:
        Test 1: Test if the found is 'POSIX'
        Test 2: Test if the found is 'C'
    """
    from ansible.module_utils.basic import AnsibleModule
    import sys

    sys.modules['ansible'] = None
    sys.modules['ansible.module_utils.basic'] = None
    sys.modules['ansible.module_utils.basic.module'] = None
    class _module(object):
        def __init__(self, Preferences):
            self.run_command = _command(Preferences)
        def get_bin_path(self, *args, **kwargs):
            return 'locale'


# Generated at 2022-06-22 21:41:55.180958
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    if PY3:
        import subprocess
    else:
        from subprocess import CalledProcessError

    class MockModule(AnsibleModule):
        def __init__(self, *args, **kwargs):
            self.params = {}
            self.return_values = {}
            self.fail_json = {}
            super(MockModule, self).__init__(*args, **kwargs)

        def run_command(self, args, check_rc=False):
            if args == ['locale', '-a']:
                return self.return_values.get('locale', [0, 'C\nen_US\nen_US.utf8', ''])
            else:
                raise CalledProcess

# Generated at 2022-06-22 21:42:04.210041
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    m = AnsibleModule()
    locale = get_best_parsable_locale(m)
    if locale == 'C':
        print("test: ok")
    else:
        print("test: fail")
    # import doctest
    # from ansible.module_utils.basic import *
    # failure_count, test_count = doctest.testmod(module=get_best_parsable_locale, verbose=True)
    # print('%s' % (failure_count))

# Generated at 2022-06-22 21:42:15.268106
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    import sys

    # Mock ansible module
    class MockAnsibleModule:
        def __init__(self, params):
            self.params = params

        def get_bin_path(self, tool, required=False, opt_dirs=[]):
            if tool != "locale":
                return None
            else:
                return "locale"

        def run_command(cmd, in_data=None, check_rc=True, executable=None, data=None, binary_data=False, path_prefix=None, cwd=None, use_unsafe_shell=False, prompt_regex=None, environ_update=None, umask=None, encoding=None, errors='strict', expand_user_and_vars=False):
            return (0, LOCALE_OUTPUT, "")

    # Mock the

# Generated at 2022-06-22 21:42:24.978243
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    class TestModule(object):
        def __init__(self, run_command):
            self._run_command = run_command
            self.params = {}
            self.check_mode = False

        def get_bin_path(self, name):
            return name

        def run_command(self, cmd):
            return self._run_command(cmd)

    m = AnsibleModule(
        argument_spec=dict(),
    )

    # Default behavior is to return 'C' if locale fails
    m._ansible_module = TestModule(lambda cmd: (0, None, None))
    assert get_best_parsable_locale(m) == 'C'

    # When locale fails, 'raise_on_locale=True' should raise exception
    m

# Generated at 2022-06-22 21:42:33.710982
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    This test should raise an exception with the suggested locale
    for the test platform.
    '''

    from ansible.module_utils.common.process import get_bin_path
    locale = get_bin_path('locale')
    if locale:
        from ansible.module_utils.basic import AnsibleModule
        module = AnsibleModule({'_raw_params': '', '_uses_shell': False, '_ansible_module_name': '', '_ansible_version': '', '_ansible_sysvinit_module': False})
        found = get_best_parsable_locale(module, raise_on_locale=True)
        assert found == 'C.utf8'

# Generated at 2022-06-22 21:42:41.664334
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    def mock_run_command(args):
        if args[1] == "-a":
            return(0, "C\nen_US.utf8\n", "")
        else:
            return(127, "locale: not found", "")

    def mock_get_bin_path(args):
        return "locale"

    result = get_best_parsable_locale(
        module=object(),
        preferences=['C', 'en_US.utf8'],
    )

    assert result == 'C'
    # This test doesn't actually run python-c-locale, so this test
    # will always be skipped
    #result = get_best_parsable_locale(
    #    module=object(),
    #    preferences=['en_US.utf8', 'C'],
    #

# Generated at 2022-06-22 21:42:51.251030
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.modules.system import locale_gen
    from ansible.module_utils.basic import AnsibleModule
    from collections import namedtuple

    def throw(name, *args, **kwargs):
        raise SubprocessError(stdout='throw', stderr='me')

    # Throw SubprocessError if locale is not installed
    module = AnsibleModule(argument_spec={})
    module.run_command = throw
    assert locale_gen._get_best_parsable_locale(module) == 'C'
    assert locale_gen._get_best_parsable_locale(module, preferences=['fake']) == 'C'
    assert locale_gen._get_best_parsable_locale(module, raise_on_locale=True) == 'C'
    assert locale_gen._get_best_

# Generated at 2022-06-22 21:42:56.628669
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Fake module for get_bin_path
    class fake_module(object):
        def get_bin_path(self, name):
            if name == "locale":
                return "/opt/ansible/bin/locale"
    locale = get_best_parsable_locale(fake_module())
    assert locale == 'C'

# Generated at 2022-06-22 21:43:03.080351
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.local import LocalAnsibleModule

    result = None
    module = LocalAnsibleModule()
    result = get_best_parsable_locale(module)
    assert result == 'C'

# Generated at 2022-06-22 21:43:13.002864
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class AnsibleModule:
        def __init__(self):
            self.params = {'run_command.return_value': (0, '', ''),
                           'get_bin_path.return_value': 'locale'}

        def run_command(self, args):
            if args[0] == 'locale' and args[1] == '-a':
                return self.params['run_command.return_value']
            else:
                print('run_command should be called with ("locale", "-a") but was called with {0}'.format(args))

        def get_bin_path(self, what):
            if what == 'locale':
                return self.params['get_bin_path.return_value']

# Generated at 2022-06-22 21:43:20.867713
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    class ModuleMock:
        def __init__(self):
            self.fail_json = None
            self.params = None
            self.bin_path = None

        def get_bin_path(self, tool):
            self.bin_path = tool
            if tool == "locale":
               return True
            else:
               return False

        def run_command(self, cmd):
            if cmd == [self.bin_path, '-a']:
                return (0, "POSIX\nC.utf8\n", "")
            else:
                return (0, "", "")

    module = ModuleMock()

    assert get_best_parsable_locale(module) == "C.utf8"
    assert module.bin_path == "locale"



# Generated at 2022-06-22 21:43:30.348495
# Unit test for function get_best_parsable_locale

# Generated at 2022-06-22 21:43:39.467001
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    class MockModule:
        def __init__(self, name):
            self.name = name
            self.fail_json = self.fail_json_check

        def fail_json_check(self, msg):
            raise RuntimeError("%s: %s" % (self.name, msg))

        def get_bin_path(self, name):
            if name == 'locale':
                return name

        def run_command(self, args):
            cmd = args[0]

            if cmd == 'locale':
                return 0, 'C', None
            elif cmd == 'locale -a':
                return 0, '\n'.join(['C', 'en_US', 'POSIX']), None
            else:
                raise RuntimeWarning("Unknown invocation %s" % cmd)


# Generated at 2022-06-22 21:43:49.139459
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import ansible.module_utils.locale

    # Test default return code
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    result = ansible.module_utils.locale.get_best_parsable_locale(module)
    assert result == 'C'
    result = ansible.module_utils.locale.get_best_parsable_locale(module, raise_on_locale=True)
    assert result == 'C'

    # Test custom locale, should be returned
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)

# Generated at 2022-06-22 21:43:52.258753
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    """
    Test that we get 'C' locale if we don't have locale available
    """
    # Mock module and run the function
    found = get_best_parsable_locale(None)
    # Verify
    assert found == 'C'

# Generated at 2022-06-22 21:43:59.880250
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Test if get_best_parsable_locale returns C locale when locale is unavailable
    try:
        import ansible.module_utils.basic  # pylint: disable=unused-import
    except:  # pylint: disable=bare-except
        # Mock ansible.module_utils.basic.AnsibleModule.run_command to return an error code
        import sys
        import imp
        import ansible.module_utils.basic
        def run_command(command, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False):
            if command == ['locale', '-a']:
                return 1, "", "error"
            return 0, "", ""

        sys.modules['ansible.module_utils.basic'].AnsibleModule.run_

# Generated at 2022-06-22 21:44:09.673343
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    module.get_bin_path = get_bin_path
    module.run_command = lambda x: (0, 'C\nc\n', '')

    locale = get_best_parsable_locale(module)
    assert locale == 'C'

    module.run_command = lambda x: (0, 'C\nc\nen_US.UTF-8\n', '')
    locale = get_best_parsable_locale(module)
    assert locale == 'C'

    expected_locale = ['en_US.UTF-8', 'en_US.UTF8', 'en_US', 'en']
   

# Generated at 2022-06-22 21:44:19.328684
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import tempfile
    import shutil

    ANSIBLE_LOCALE_BIN = ''

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.locale import get_best_parsable_locale

    test_get_best_parsable_locale_results = {}

    def setUpModule():
        global ANSIBLE_LOCALE_BIN
        test_get_best_parsable_locale_results['tmpdir'] = tempfile.mkdtemp()
        ANSIBLE_LOCALE_BIN = str(test_get_best_parsable_locale_results['tmpdir'])

        import os
        import os.path as ospath

        locale = ospath.join(ANSIBLE_LOCALE_BIN, 'locale')
        restricted_

# Generated at 2022-06-22 21:44:30.692809
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())

    # Test normal operation
    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, ["C.utf8", "C", "POSIX"]) == 'C'

    # Test that the default preferences work
    assert get_best_parsable_locale(module, None) == 'C'
    assert get_best_parsable_locale(module, ["C", "POSIX", "POSIX", "C", "C.utf8"]) == 'C'

    # The locale command should fail. The result should have a RuntimeWarning, but
    # it should not raise an exception. The default locale will be returned.
    assert get

# Generated at 2022-06-22 21:44:38.589216
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    """
    Test function that finds the best locale for parsing output.

    """

    from ansible.module_utils.basic import AnsibleModule

    class FakeModule:
        def __init__(self):
            self.run_command = run_command
            self.get_bin_path = get_bin_path

    # pylint: disable=unused-argument
    def get_bin_path(self, executable):
        """
        Return the path for the 'locale' binary for testing.

        """
        return "/usr/bin/locale"

    # pylint: disable=unused-argument

# Generated at 2022-06-22 21:44:40.029774
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Add code for unit test
    pass

# Generated at 2022-06-22 21:44:48.729781
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Mock module to use with our test cases
    class ModuleMock:

        bin_path = None
        run_command_rc = 0
        run_command_out = ''
        run_command_err = ''

        def run_command(self, d):
            return self.run_command_rc, self.run_command_out, self.run_command_err

        def get_bin_path(self, name):
            return self.bin_path

    # Test cases

    # Test case 1 - No locale command
    m = ModuleMock()
    m.bin_path = None
    result = get_best_parsable_locale(m)
    assert result == 'C'

    # Test case 2 - Good output and found locale in preferences
    m = ModuleMock()

# Generated at 2022-06-22 21:44:59.718416
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # get_best_parsable_locale is not a direct class but instead is a function
    # so we have to mock out the AnsibleModule that is passed in
    from mock import Mock
    from ansible.module_utils.basic import AnsibleModule

    # we are going to mock the run_command from the AnsibleModule
    # and return a tuple of a return code, stdout and stderr
    # this mocks out everything else from the AnsibleModule so
    # that we can test the get_best_parsable_locale function by itself
    def run_command(self, arg1):
        if arg1 == ['locale', '-a']:
            return (0, 'C.utf8', '')
        else:
            raise Exception("This was not expected to be called")


# Generated at 2022-06-22 21:45:09.627461
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY2

    module = AnsibleModule(argument_spec={})
    assert isinstance(module, AnsibleModule)
    assert get_best_parsable_locale(module) == 'C'

    module = AnsibleModule(argument_spec={})
    module.run_command = lambda x: (0, 'C\nC.utf8\nPOSIX\nen_US.utf8', '')
    assert get_best_parsable_locale(module) == 'C.utf8'

    module = AnsibleModule(argument_spec={})
    module.run_command = lambda x: (0, 'C\nC.utf8\nPOSIX\nen_US.utf8', '')

# Generated at 2022-06-22 21:45:17.599947
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        test_get_best_parsable_locale

        unit test for get_best_parsable_locale

        :returns: the locale
    '''

    from ansible.module_utils.basic import AnsibleModule

    module_args = dict(
        command='/usr/bin/locale -a'
    )
    module = AnsibleModule(module_args)

    return get_best_parsable_locale(module, ['C.UTF-8', 'en_US.UTF-8'])

# Generated at 2022-06-22 21:45:29.484860
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import random
    import sys

    try:
        from unittest import mock
    except:
        try:
            import mock
        except ImportError:
            print("ERROR: python-mock is missing. Try: yum install python-mock or pip install mock")
            sys.exit(1)


# Generated at 2022-06-22 21:45:34.442576
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    found = get_best_parsable_locale(AnsibleModule, preferences=preferences, raise_on_locale=False)
    assert found == 'C'

# Generated at 2022-06-22 21:45:43.078586
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    locale_lookup = {
            'locale': [
                'ar_DZ.utf8',
                'ar_EG.utf8',
                'ar_SS.utf8',
                'de_DE.utf8',
                'en_AU.utf8',
                'en_CA.utf8',
                'en_GB.utf8',
                'en_US.utf8',
                'ja_JP.utf8',
                'pl_PL.utf8',
            ],
            'rc': 0,
            'stderr': '',
        }

    class FakeModule:
        def __init__(self):
            pass

        def get_bin_path(self, tool):
            return '/bin/locale'


# Generated at 2022-06-22 21:45:47.017696
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    assert get_best_parsable_locale(module) == 'C'


# Generated at 2022-06-22 21:45:57.581046
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    import ansible.module_utils.basic
    import shutil
    import tempfile

    locale_cmd = None
    locale_cmd_output = 'C\nC.UTF-8\n'

    # Use temporary directories, as to not pollute the system.
    # Note that this is needed *before* instantiating the module.
    system_temp_dir = tempfile.mkdtemp()
    ansible_temp_dir = tempfile.mkdtemp()

    # Mock the module.
    # Mock the module.
    #
    # Next, instantiate the module to get an `ansible.module_utils.basic.AnsibleModule` instance.
    test_module = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict(),
        bypass_checks=True,
    )

    # Now,

# Generated at 2022-06-22 21:46:06.483227
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Unit test for function get_best_parsable_locale
    '''

    import ansible.module_utils.basic
    from ansible.module_utils.common._collections_compat import MutableMapping


# Generated at 2022-06-22 21:46:09.023283
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None, None) == 'C'

# Generated at 2022-06-22 21:46:18.671622
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    import unittest

    class TestModule(object):
        def __init__(self):
            self.params = {}
            self.fail_json = None

        def get_bin_path(self, tool, required=False):
            if self.fail_json:
                raise Exception
            else:
                return '/usr/bin/locale'

        def run_command(self, cmd, tmp_path, follow=False, environ_update=None, check_rc=False):
            stdout = ''
            if cmd[1] == '-a':
                stdout = 'C\nC.UTF-8\nen_US.utf8\nfr_CA.UTF-8\n'
            rc = 0
            stderr = ''
            if self.fail_json:
                rc = 1
                st

# Generated at 2022-06-22 21:46:26.957426
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''Test get_best_parsable_locale'''

    from ansible.module_utils.six import PY3, b
    if PY3:
        from unittest.mock import patch, mock_open
    else:
        from mock import patch, mock_open

    locale_test_data = {
        'no_pref': {"out": "en_US.utf8\nC.utf8\nC\nPOSIX\n"},
        'all_prefs': {"out": "C.utf8\nen_US.utf8\nC\nPOSIX\n"},
        'no_match': {"out": "fr_CA.utf8\nde_DE.utf8\n"},
    }

    # Data may be unicode here, so convert to bytes in py2

# Generated at 2022-06-22 21:46:36.928723
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    import os

    class TestModule(object):
        def __init__(self, mod_args=None, extra_args=None):
            self.params = mod_args or dict()
            self.extra_args = extra_args or dict()

        def fail_json(self, **kwargs):
            self.fail_json_args = kwargs.copy()
            self.fail_json_args['failed'] = True

        def get_bin_path(self, tool, required=False, opt_dirs=[]):
            return os.environ.get('PATH') or ''


# Generated at 2022-06-22 21:46:48.082049
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    if sys.version_info < (2, 6):
        return True

    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts import cache

    am = AnsibleModule(argument_spec={})
    am.params = {}
    am.exit_json = am.fail_json = lambda x, **y: None
    am.get_bin_path = basic.get_bin_path
    am.run_command = basic.run_command

    orig_stdout = sys.stdout
    orig_stderr = sys.stderr

# Generated at 2022-06-22 21:46:55.996884
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Note that this requires that the system either has locales set up, or
    # it will get the default of C.
    # Also note that if you want to unit test against a system that doesn't
    # have the required locales, you can run:
    #   sudo locale-gen en_US.utf8 && sudo update-locale LANG=en_US.UTF-8
    # on a Ubuntu system, and then run your ansible-playbook command with a
    # locale of "en_US.utf8"
    from ansible.module_utils.basic import AnsibleModule
    m = AnsibleModule(argument_spec=dict())

    # First run with default preferences, which will get the default locale
    # (C) if the system does not have the required locales.

# Generated at 2022-06-22 21:47:03.854214
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Dummy class for AnsibleModule
    class Module():
        def __init__(self):
            self.locale = 'C.utf8'

    # Define module object
    m = Module()

    # Test locale with no substrings
    locale = get_best_parsable_locale(m)
    assert locale == "C"

    # Test locale with substrings
    locale = get_best_parsable_locale(m, ['en', 'de'])
    assert locale == "de"

if __name__ == '__main__':
    test_get_best_parsable_locale()

# Generated at 2022-06-22 21:47:13.030840
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six.moves import StringIO

    module = AnsibleModule(argument_spec={})

    # get_best_parsable_locale with no argument
    r1 = get_best_parsable_locale(module)
    assert(r1)

    # get_best_parsable_locale with non-existent locale
    r2 = get_best_parsable_locale(module, preferences=['XX.YY'])
    assert(r2 == 'C')

    # get_best_parsable_locale with locale in preferences
    env_output = """
am_ET.UTF-8
C
POSIX
"""

# Generated at 2022-06-22 21:47:13.664609
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    pass

# Generated at 2022-06-22 21:47:21.649684
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # The function get_best_parsable_locale uses run_command, which is mocked.
    # We will run a fake module that we create and use a fake locale tool with
    # a specific locale output (en_US.utf8 and en_US.utf8).
    module = FakeModule()

    # Check to see if the function returns the correct output
    # when the preferred locales are not passed
    assert module.get_best_parsable_locale() == 'C.utf8'

    # Check to see if the function returns the correct output
    # when the preferred locales are not passed
    # and the locale tool does not return en_US.utf8
    module.locale_tool_output = 'C.utf8'
    assert module.get_best_parsable_locale() == 'C.utf8'



# Generated at 2022-06-22 21:47:30.405825
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    test_module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    assert get_best_parsable_locale(test_module) == 'C'

    # force failure on shell tools
    test_module.check_mode = True
    assert get_best_parsable_locale(test_module) == False

    test_module.check_mode = False
    test_module.run_command = lambda *args, **kwargs: (0, "C\nen_US.utf8\n", "")
    assert get_best_parsable_locale(test_module) == 'C'

# Generated at 2022-06-22 21:47:40.999224
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # First test: default function
    def module_run_command(args, check_rc=True, close_fds=False, cwd=None, executable=None, data=None, binary_data=False, path_prefix=None, use_unsafe_shell=False, prompt_regex=None, environ_update=None, umask=None, encoding=None, errors='surrogate_then_replace', json_mode=False, expand_user_and_vars=True):
        return 0, "en_US.utf8\nC\nPOSIX", ''
    class TestUL:
        def __init__(self):
            self.run_command = module_run_command
    test = TestUL()
    assert (get_best_parsable_locale(test) == 'en_US.utf8')

   

# Generated at 2022-06-22 21:47:43.326554
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    # Test case 1
    # Standard test case, default config
    m = AnsibleModule()
    res = get_best_parsabl

# Generated at 2022-06-22 21:47:54.195721
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # pylint: disable=missing-docstring
    import sys
    import os
    import pytest
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text, to_bytes
    from ansible.module_utils.basic import AnsibleModule

    try:
        from __main__ import display
    except ImportError:
        from ansible.utils.display import Display
        display = Display()

    def _get_module(**kwargs):
        # we need a fake module that does not require info about any remote
        # system or arguments
        return AnsibleModule(argument_spec=dict(), **kwargs)

    def _run_module(requirements=None, params=dict()):
        display.verbosity = 3
        params

# Generated at 2022-06-22 21:48:02.364763
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    import ansible.module_utils.local_ansible_utils as utils
    import ansible.module_utils.local_ansible_utils_class as class_utils
    import ansible.module_utils.facts.system.distribution as distribution
    import sys

    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict()
    )
    # We don't want to actually run this module because it is
    # designed to be used by other modules and not by end users.
    module.exit_json = class_utils.dummy_function
    module.fail_json = class_utils.dummy_function
    utils.HAS_LANG = distribution.HAS_LANG

# Generated at 2022-06-22 21:48:11.650484
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    """Test function to get the best locale

    """
    import collections

    class AnsibleModuleFake:
        """AnsibleModuleFake is a simple fake object for AnsibleModule.
        """
        def __init__(self):
            self.params = {}

        def get_bin_path(self, arg):
            """Fake get_bin_path method for AnsibleModule.
            """
            if arg == "locale":
                return True
            else:
                return False

        def run_command(self, arg):
            """Fake run_command method for AnsibleModule.

            :param arg: list of arguments to run command
            :return: tuple containing return code, stdout and stderr
            """

            return (0, "", "")


# Generated at 2022-06-22 21:48:18.764382
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import os
    import tempfile
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_native

    path = tempfile.mkdtemp()

# Generated at 2022-06-22 21:48:27.505879
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = object()
    module.get_bin_path = lambda x: "/usr/bin/locale"
    module.run_command = lambda x: (0, "locale: Cannot set LC_CTYPE to default locale: No such file or directory\n"
                                    "locale: Cannot set LC_ALL to default locale: No such file or directory\n"
                                    "C\n"
                                    "C.UTF-8\n"
                                    "POSIX\n",
                                    "")
    assert get_best_parsable_locale(module) == "C.UTF-8"

# Generated at 2022-06-22 21:48:31.259612
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule({})
    preferences = ['de_DE.utf8', 'de_DE.latin1', 'C.utf8', 'C']
    assert get_best_parsable_locale(module, preferences) == 'de_DE.utf8'

# Generated at 2022-06-22 21:48:42.137049
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Unit test for function get_best_parsable_locale
        :returns: nothing
    '''
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )

    try:
        get_best_parsable_locale(module, preferences=['C'])
    except Exception:
        raise
    else:
        assert True

    try:
        get_best_parsable_locale(module, preferences=None)
    except Exception:
        raise
    else:
        assert True

    try:
        get_best_parsable_locale(module, preferences=[])
    except Exception:
        raise
    else:
        assert True

# Generated at 2022-06-22 21:48:50.547478
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import StringIO

    # Create a new fake ansible module

# Generated at 2022-06-22 21:49:01.357890
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    class MockModule(object):

        def __init__(self):
            self.fail_json = None

        def get_bin_path(self, exe):
            return exe

        def run_command(self, cmd):
            # is_executable will return false for 'locale' so this will be executed
            # but if get_best_parsable_locale is called with raise_on_locale=True, this will
            # cause an exception to be raised
            return (1, '', 'No such file or directory')

    # Test to make sure that default posix is returned when an error occurs
    m = MockModule()
    locale = get_best_parsable_locale(m)
    assert locale == 'C'

    # Test to make sure that the preferences are evaluated in order
    m = MockModule()


# Generated at 2022-06-22 21:49:10.060013
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.text.converters import to_bytes

    # Generate a mock module, with locale installed and which
    # returns all locales as supported
    mock_module = AnsibleModule(
        argument_spec=dict()
    )
    mock_module.run_command = lambda args, **kwargs: (0, "C.utf8\nen_US.utf8\nC\nPOSIX\nfoo_BAR.UTF-8", "")
    assert get_best_parsable_locale(mock_module, raise_on_locale=True) == "C.utf8"

    mock_module.get_bin_path = lambda _: to_bytes('/usr/bin/locale')

# Generated at 2022-06-22 21:49:14.786031
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Simple sanity test
    assert 'C' == get_best_parsable_locale(None)

    # Test with no locale tool
    assert 'C' == get_best_parsable_locale(None)

    # Test with bad preferences
    assert 'C' == get_best_parsable_locale(None, ['xyz'])

# Generated at 2022-06-22 21:49:23.744842
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    import os
    import tempfile
    import locale

    # If locale was not specified, the system will fall back to C locale
    assert locale.getdefaultlocale()[0] is None
    tmpfile = tempfile.mktemp()
    f = open(tmpfile, 'w')
    f.write('C\C.utf8\C.utf-8\n')
    f.close()

    class AnsibleModule(object):
        def __init__(self):
            self.params = False
            self.fail_json = False

        def get_bin_path(self, tool):
            return tool

        def run_command(self, cmd):
            if cmd[0] == 'locale':
                return 0, open(tmpfile, 'r').read(), ''

# Generated at 2022-06-22 21:49:33.746381
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class Module(object):
        def __init__(self):
            self.fail_json = lambda msg: msg
            self.get_bin_path = lambda path: path
            self.run_command = lambda cmd: (0, 'C\nC.UTF-8\n', '')
        def run_command(self, cmd, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False, path_prefix=None, cwd=None, use_unsafe_shell=False, prompt_regex=None, environ_update=None):
            return (0, '', '')

    assert get_best_parsable_locale(Module(), raise_on_locale=False) == 'C'

# Generated at 2022-06-22 21:49:43.710248
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Test default locale
    best_locale = get_best_parsable_locale(None)
    assert best_locale == 'C'

    # Test best locale

    # Mock out module.get_bin_path method
    # We want to set the 'which' command's path to the same path that gets set in the _ansible_module_data class
    def get_bin_path(self, args):
        return '/usr/bin/which'

    # Mock out module.run_command method
    # We want the return code to be 0, stdout to mock out the locale command's output, and stderr to be empty

# Generated at 2022-06-22 21:49:53.617008
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None) == 'C'
    assert get_best_parsable_locale(None, ['foo']) == 'C'
    assert get_best_parsable_locale(None, ['C']) == 'C'
    assert get_best_parsable_locale(None, ['foo', 'C', 'bar']) == 'C'
    assert get_best_parsable_locale(None, ['en_US.utf8', 'C', 'POSIX']) == 'en_US.utf8'
    assert get_best_parsable_locale(None, ['C.utf8', 'POSIX', 'foo']) == 'C.utf8'

# Generated at 2022-06-22 21:50:02.190502
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    class MockModule(AnsibleModule):

        def __init__(self, module_args, **kwargs):
            # We can't use basic.AnsibleModule because we are doing unit tests.
            super(MockModule, self).__init__(module_args, **kwargs)
            self._locale_cache = None

        def get_bin_path(self, arg, required=False, opt_dirs=[]):
            return "/usr/bin/locale"

        def run_command(self, cmd):
            if cmd[-1] == '-a':
                if self._locale_cache:
                    return (0, self._locale_cache, '')


# Generated at 2022-06-22 21:50:04.067637
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None, ['C', 'POSIX']) == 'C'

# Generated at 2022-06-22 21:50:06.446268
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    locale_name = get_best_parsable_locale(None)
    assert locale_name == 'C'

# Generated at 2022-06-22 21:50:17.045469
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import os
    import sys
    import types

    class Environment():
        def __init__(self):
            self._environ = os.environ
            os.environ['LC_ALL'] = 'C'

        def __getitem__(self, key):
            try:
                return self._environ[key]
            except KeyError:
                return None

        def __setitem__(self, key, value):
            self._environ[key] = value

        def __delitem__(self, key):
            try:
                del self._environ[key]
            except KeyError:
                pass

        def __contains__(self, key):
            return key in self._environ

        def __len__(self):
            return len(self._environ)

        def __iter__(self):
            return

# Generated at 2022-06-22 21:50:20.834248
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None, ['en_US.utf8'], raise_on_locale=True) == 'C'

# Generated at 2022-06-22 21:50:31.373883
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})

    # Create a stub module object
    class StubModule(object):
        def __init__(self, module):
            self.module = module

        def run_command(self, command):
            if command[-1] == '-a':
                return [0, 'en_US.utf8\nC.utf8\nPOSIX', None]
            elif command[-1] == '-d':
                return [0, 'en_US.utf8', None]

        def get_bin_path(self, command):
            return command

    # Test the default behaviour
    module.params = {'preferences': None}
    stub = StubModule(module)
    assert get_best_parsable_

# Generated at 2022-06-22 21:50:43.333238
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Unit test for function get_best_parsable_locale which calls the function
        and checks the output
    '''

    # Fail case, no module object is not passed
    from ansible.module_utils.basic import AnsibleModule

    module = None
    preferences = ["C.utf8", "en_US.utf8", "C", "POSIX"]
    assert get_best_parsable_locale(module, preferences, raise_on_locale=False) == "C"

    # Fail case, comments are passed
    module = "#!/usr/bin/python"
    assert get_best_parsable_locale(module, preferences, raise_on_locale=True) == "C"

    # Fail case, the locale is not found

# Generated at 2022-06-22 21:50:48.340355
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    assert 'C' == get_best_parsable_locale(AnsibleModule(argument_spec={}))

    # Empty preferences
    assert 'C' == get_best_parsable_locale(AnsibleModule(argument_spec={}), preferences=[])

# Generated at 2022-06-22 21:50:52.075932
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    am = AnsibleModule()
    assert get_best_parsable_locale(am) == 'C'