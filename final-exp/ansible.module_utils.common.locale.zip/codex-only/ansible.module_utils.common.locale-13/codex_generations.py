

# Generated at 2022-06-22 21:41:02.597353
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts.system.base import get_distribution
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector

    # create a temporary module for the purposes of this test
    tmp_module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    # populate the temporary module with a distribution fact collector
    # that returns the OSX platform
    tmp_module._distribution = DistributionFactCollector(tmp_module, get_distribution(tmp_module, [u'Darwin']))

    result = get_best_parsable_locale(tmp_module)
    assert result == 'C'

# Generated at 2022-06-22 21:41:12.206871
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import itertools
    class TestAnsibleModule(AnsibleModule):
        def __init__(self, *args, **kwargs):
            # __init__ accepts additional keyword-only argument 'argument_spec'.
            if kwargs.pop('argument_spec', False):
                kwargs['argument_spec'] = dict(
                    argument_spec=kwargs.pop('argument_spec')
                )
            super(TestAnsibleModule, self).__init__(*args, **kwargs)

        def get_bin_path(self, executable, required=False, opt_dirs=None):
            return 'locale'


# Generated at 2022-06-22 21:41:17.191673
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Let's try a locale that does not exist
    module = None
    assert get_best_parsable_locale(module, preferences=["ru_RU.UTF-8"]) == "C"
    assert get_best_parsable_locale(module) == "C"

# Generated at 2022-06-22 21:41:22.207611
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec = dict()
    )
    locale = get_best_parsable_locale(module, preferences=['C.UTF-8', 'en_US.UTF-8', 'POSIX'])
    assert locale == 'C.UTF-8'

# Generated at 2022-06-22 21:41:33.916186
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.basic import AnsibleModule
    class FakeModule(AnsibleModule):
        @staticmethod
        def get_bin_path(binary, required=False, opt_dirs=None):
            if binary == 'locale':
                return 'locale'
            else:
                return None

        @staticmethod
        def run_command(cmd):
            if cmd == ['locale', '-a']:
                return 0, 'a\n en_US.utf8 \n C \n C.utf8 \n POSIX', ''
            else:
                return 1, '', 'not found'

    md = FakeModule()

    assert get_best_parsable_locale(md) == 'C.utf8'
    assert get_best_parsable_locale(md, ['C'])

# Generated at 2022-06-22 21:41:41.423043
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Unit test for function get_best_parsable_locale
        :returns: nothing
    '''
    assert 'POSIX' == get_best_parsable_locale('not_a_module', ['POSIX'])
    assert 'C' == get_best_parsable_locale('not_a_module', [])
    assert 'POSIX' == get_best_parsable_locale('not_a_module')

# Generated at 2022-06-22 21:41:49.088142
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Fake ansible module to test function
    class FakeModule:
        def __init__(self):
            self.params = {}

        def get_bin_path(self, name, required=False, opt_dirs=[]):
            return '/usr/bin/' + name

        def run_command(self, args, check_rc=True, close_fds=True,
                        executable=None, data=None, binary_data=False,
                        path_prefix=None, cwd=None, use_unsafe_shell=False,
                        prompt_regex=None, environ_update=None,
                        umask=None):
            return (0, 'C.utf8\nC\nen_US.utf8\nen_US\nen_US.UTF-8', None)

    fakemodule = FakeModule()
    assert get

# Generated at 2022-06-22 21:41:59.028529
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.basic import AnsibleModule

    # define test cases

# Generated at 2022-06-22 21:42:09.130385
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class Module:
        def __init__(self):
            self.debug = True

        def get_bin_path(self, name):
            return True

        def run_command(self, args):
            rc = 0
            out = err = ''
            if args == [True, '-a']:
                out = "C\nen_US.utf8\nen_US.utf8\nPOSIX\nC\n"

            return rc, out, err

    m = Module()
    assert get_best_parsable_locale(m) == 'en_US.utf8'
    assert get_best_parsable_locale(m, ['en_US.utf8']) == 'en_US.utf8'

# Generated at 2022-06-22 21:42:20.498502
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    C = {
        'bin': '/bin'
    }

    M = ansible.module_utils.basic.AnsibleModule(
        argument_spec={},
        check_invalid_arguments=False
    )

    locale_fn = '''
    #!/bin/sh
    if [ "$1" = '-a' ]; then
        echo "C.utf8"
        echo "C.UTF-8"
        echo "C.utf-8"
        echo "C"
        echo "POSIX"
        exit 0
    fi
    exit 1
    '''


# Generated at 2022-06-22 21:42:27.911511
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict()
    )
    #Failing get_bin_path
    assert get_best_parsable_locale(module) == 'C'
    
    #Failing run_command
    module.get_bin_path = lambda p: "locale"
    module.run_command = lambda p, env: (1, "", "RuntimeError")
    assert get_best_parsable_locale(module) == 'C'
    
    #Failing preferred locale lookup
    module.run_command = lambda p, env: (0, "", "")
    assert get_best_parsable_locale(module) == 'C'
    
    #Successful lookup
    module

# Generated at 2022-06-22 21:42:29.778510
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(preferences=['C']) == 'C'

# Generated at 2022-06-22 21:42:40.189975
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.common.process import get_bin_path
    module = AnsibleModule({}, {}, {})
    module.get_bin_path = get_bin_path
    locale = get_best_parsable_locale(module)
    assert locale in ('POSIX', 'C')

    available = ['C', 'POSIX', 'de_DE.utf8', 'de_DE.UTF-8', 'de_DE.utf-8', 'de_DE.UTF8', 'de_DE', 'de.utf8', 'de.UTF-8', 'de.utf-8', 'de.UTF8', 'de']
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    locale = get_

# Generated at 2022-06-22 21:42:47.356066
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # pylint: disable=import-error, no-name-in-module
    from ansible.module_utils.basic import AnsibleModule
    got = get_best_parsable_locale(AnsibleModule(argument_spec=dict()))
    assert got in ['C.utf8', 'en_US.utf8', 'C', 'POSIX']

# Generated at 2022-06-22 21:42:57.840757
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic as basic
    import ansible.module_utils.common.collections as collections
    import os

    class TestModule:
        def __init__(self, args):
            self.params = collections.AnsibleModule(argument_spec=dict())
            self.params.update(args)

        def get_bin_path(self, command):
            if command == "locale":
                return "/usr/bin/locale"
            else:
                return None


# Generated at 2022-06-22 21:43:01.356231
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    assert get_best_parsable_locale(module) is not None

# Generated at 2022-06-22 21:43:12.228960
# Unit test for function get_best_parsable_locale

# Generated at 2022-06-22 21:43:19.477152
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # test the function get_best_parsable_locale()
    from ansible.module_utils.basic import AnsibleModule

    preferred = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    module = AnsibleModule(argument_spec={})

    x = get_best_parsable_locale(module, preferred)
    assert x == 'C'

# Generated at 2022-06-22 21:43:29.301572
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    from ansible.module_utils.common.process import get_bin_path

    class TestModule(ansible.module_utils.basic.AnsibleModule):
        def __init__(self):
            self.fail_json = lambda x: x

    class TestRunner(ansible.module_utils.basic.AnsibleModule):
        def __init__(self):
            self.run_command = lambda x: (0, '', '')

    m = TestModule()
    m.get_bin_path = lambda x: get_bin_path(x)
    m.run_command = TestRunner().run_command

    assert get_best_parsable_locale(m) == 'C'

    m = TestModule()


# Generated at 2022-06-22 21:43:38.896160
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import os
    import sys
    import subprocess
    import unittest

    class FakeModule:
        def __init__(self):
            self.run_command = run_command

    def run_command(self, *args, **kwargs):
        return subprocess.Popen(args[0], stdout=subprocess.PIPE, stderr=subprocess.PIPE).communicate()

    try:
        # Python 2
        # Assume Python 2.7+
        from StringIO import StringIO
        from cStringIO import StringIO as BytesIO
    except:
        # Python 3
        from io import StringIO, BytesIO

    # module is a map of AnsibleModule instances to FakeModule instances

# Generated at 2022-06-22 21:43:48.839693
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    class TestAnsibleModule(AnsibleModule):
        def __init__(self):
            self.params = {}
            self.called = {}
            self.command_warnings = []

        def get_bin_path(self, name, required=False, opt_dirs=[]):
            if name in ['locale']:
                return name
            else:
                return None


# Generated at 2022-06-22 21:43:53.784249
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    am = AnsibleModule(argument_spec={})
    # invoke with no arguments to see if it finds C
    assert get_best_parsable_locale(am) == 'C'

# Generated at 2022-06-22 21:44:00.947034
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # some of this is untested because of lack of python 3.2 support

    # testing locale
    module = FakeModule()
    module.get_bin_path_returns = 'locale'
    module.run_command_returns = (0, 'C', '')
    assert get_best_parsable_locale(module) == 'C'
    assert module.get_bin_path_called_with == 'locale'
    assert module.run_command_called_with == ['locale', '-a']

    # testing locale does not exist
    module = FakeModule()
    module.get_bin_path_returns = None
    assert get_best_parsable_locale(module) == 'C'

    # testing locale, no output
    module = FakeModule()
    module.get_bin_path_

# Generated at 2022-06-22 21:44:11.162777
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    if sys.hexversion >= 0x3040000:
        import unittest.mock as mock
    else:
        import mock

    locale = mock.MagicMock()
    locale.return_value = '/usr/bin/locale'
    module = mock.MagicMock()
    module.get_bin_path = locale
    run_command = mock.MagicMock()
    run_command.return_value = (0, 'POSIX\nen_US.utf8\nC\n', '')
    module.run_command = run_command
    assert get_best_parsable_locale(module) == 'POSIX'
    run_command.return_value = (1, '', 'Something went wrong')
    get_best_parsable_locale(module)

# Generated at 2022-06-22 21:44:20.214263
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import pytest
    from sys import version_info as py_version_info

    if py_version_info[0] > 2:
        # Python3.3 does not have mock
        from unittest.mock import MagicMock
        mock = MagicMock()
    else:
        from mock import MagicMock
        mock = MagicMock()

    module = AnsibleModule({})
    module.get_bin_path = mock.get_bin_path
    module.run_command = mock.run_command
    mock.get_bin_path.return_value = True
    mock.run_command.return_value = (0, 'cs_CZ.utf8\nen_US.utf8\nC\nPOSIX\n', '')

    # Default

# Generated at 2022-06-22 21:44:30.912660
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    mod = AnsibleModule()
    # first test
    best_locale = get_best_parsable_locale(mod)
    # to make test portable, we don't want failure if the locale C is not found
    # because some system do not have it
    if best_locale != 'C':
        mod.fail_json(msg="test_get_best_parsable_locale failed: expected C: got {0}".format(best_locale))
    # second test
    best_locale = get_best_parsable_locale(mod, preferences=['se_SE.utf8', 'C.utf8'])

# Generated at 2022-06-22 21:44:36.472348
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    m = AnsibleModule()

    # Known locale
    pref_list = ['C.UTF-8', 'C', 'POSIX']
    assert m.get_best_parsable_locale(preferences=pref_list) == 'C.UTF-8', "Incorrect locale returned"

    # Unknown locale
    pref_list = ['AB.CD', 'C.UTF-8', 'C', 'POSIX']
    assert m.get_best_parsable_locale(preferences=pref_list) == 'C.UTF-8', "Incorrect locale returned"

    # Mixed locale
    pref_list = ['C.UTF-8', 'AB.CD', 'C', 'POSIX']
    assert m.get_best_parsable_loc

# Generated at 2022-06-22 21:44:43.245000
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    ansible_module = AnsibleModule()

    assert get_best_parsable_locale(ansible_module) == 'C'
    assert get_best_parsable_locale(ansible_module, preferences=['C.UTF-8', 'POSIX']) == 'C'

# Generated at 2022-06-22 21:44:50.897880
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.lookup import debug

    loader = lookup_loader

    # Test with a normal module instance having set language, should return lang set
    # The language set in the module object will depend on the user running the
    # test, so we don't do exact matching
    class stubbed_module(object):
        def __init__(self):
            self.no_log_values = set()
            self.params = ImmutableDict()
            self.language = os.environ.get("LANG")

        def get_bin_path(self, _):
            return None

        def run_command(self, _):
            return 0, None, None

    m = stubbed_module()

# Generated at 2022-06-22 21:45:00.629098
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    """
    Get locale 'C' even in case of empty preferences or unavailable locale
    """

    import collections
    import unittest

    import ansible.module_utils.basic

    class AnsibleModule(ansible.module_utils.basic.AnsibleModule):
        """
        AnsibleModule wrapper class that records and plays back function calls
        """

        def __init__(self, *args, **kwargs):
            import sys
            import argparse
            import json

            class FakeModuleArgumentParser(argparse.ArgumentParser):
                """
                Argument parser for testing exceptions
                """
                def error(self, message):
                    raise RuntimeError(message)

            self.__actions = collections.OrderedDict()
            self.__result = {}

            self.__actions['get_bin_path'] = collections.OrderedD

# Generated at 2022-06-22 21:45:10.000606
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class AnsibleModule:
        def __init__(self):
            self.params = {}
            self.params['path'] = []

        def get_bin_path(self, name):
            return name

        def run_command(self, args):
            import locale
            import os

            def get_language_encoding():
                return os.environ['LANG'].split('.')[1]

            system_locales = ['C', 'en_US', 'en_US.utf8']
            self.params['path'] = system_locales

            enc = get_language_encoding()
            system_locales.append('fr_FR.%s' % enc)
            system_locales.append('fr_FR')

            return 0, '\n'.join(system_locales), ''

    locale = get_best

# Generated at 2022-06-22 21:45:15.175190
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import unittest
    import sys
    import locale

    # Import some code from the main module to make testing easier.
    from ansible.module_utils.common.collections import is_iterable
    from ansible.module_utils.six.moves import StringIO

    # Create a mock for AnsibleModule.
    cur_locale = locale.getlocale(locale.LC_ALL)
    locale.setlocale(locale.LC_ALL, "C")
    from ansible.module_utils.basic import AnsibleModule
    modobj = AnsibleModule(argument_spec=dict())
    modobj.run_command = run_command
    locale.setlocale(locale.LC_ALL, cur_locale)

    # Create a mock run_command function.

# Generated at 2022-06-22 21:45:18.449750
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    preferences = get_best_parsable_locale(module)
    assert isinstance(preferences, str)

# Generated at 2022-06-22 21:45:29.615475
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Set up test
    import os
    import sys
    import types
    import shutil
    import tempfile
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils import basic


# Generated at 2022-06-22 21:45:40.045767
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    import json
    import logging
    import pytest
    import os

    from ansible.module_utils.basic import AnsibleModule

    class MockAnsibleModule:
        def __init__(self):
            self.params = {}
            self.log = logging.getLogger('ansible.playbook')
            return

        def get_bin_path(self, name):
            return os.path.abspath(name)

        def run_command(self, cmd, cwd=None):
            if cmd == ['locale', '-a']:
                return (0, "C\nC.utf8\nen_US.utf8", "")
            return (1, "", "Unable to run command %s"% cmd)

    mock_module = MockAnsibleModule()
    assert get_best_parsable

# Generated at 2022-06-22 21:45:41.840641
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None) == 'C'

# Generated at 2022-06-22 21:45:46.086770
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule()
    locale = get_best_parsable_locale(module)
    assert locale is not None

# Generated at 2022-06-22 21:45:53.186728
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    import ansible.module_utils.facts
    import os
    actual = 'C'
    am = ansible.module_utils.basic.AnsibleModule(argument_spec={'preferences': dict(type='list', default=None)})
    am.get_bin_path = os.getenv
    if os.name == 'posix':
        actual = get_best_parsable_locale(am)
    assert actual == os.getenv('LANG')

# Generated at 2022-06-22 21:45:59.136425
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # issue 39454
    import mock
    mock_module = mock.MagicMock()
    mock_module.run_command.return_value = 0, 'C\nen_US.utf8\nja_JP.utf8', ''
    try:
        found = get_best_parsable_locale(mock_module, preferences=['ja_JP.utf8'])
    except RuntimeWarning:
        pass

    assert found == 'ja_JP.utf8'

# Generated at 2022-06-22 21:46:03.813836
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    # these are not expected to exist, so no need to change in test
    module = AnsibleModule(argument_spec=dict(raise_on_locale=dict(type='bool', default=False)))
    locale = get_best_parsable_locale(module)
    assert locale == 'C'

# Generated at 2022-06-22 21:46:15.020188
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule()
    assert get_best_parsable_locale(module) == 'C'

    preferences = ['C', 'POSIX']
    assert get_best_parsable_locale(module, preferences) == 'C'

    preferences = ['POSIX', 'C']
    assert get_best_parsable_locale(module, preferences) == 'C'

    preferences = ['C', 'POSIX']
    assert get_best_parsable_locale(module, preferences) == 'C'

    preferences = ['C.utf8']
    assert get_best_parsable_locale(module, preferences) == 'C'

    preferences = ['en_US.utf8']

# Generated at 2022-06-22 21:46:23.407133
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    locale_mock = dict(
        get_bin_path={
            True: "/usr/bin/locale"
        },
        run_command={
            (['locale', '-a'],): (0, 'C\nC.utf8\nen.utf8\n', None)
        },
    )

    # Since there is no way to mock a class, we are mocking the
    # variables created by AnsibleModule. We need to mock
    # the variables that AnsibleModule creates
    params = dict()
    check_mode = False
    _ansible_check_mode = True
    _ansible_selinux_special_fs = []
    _ansible_no_log = False
    _ansible_verbosity = 5
    _ansible_debug = False
    _ansible_diff = False
    _

# Generated at 2022-06-22 21:46:26.427713
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale({'get_bin_path': lambda _: 'locale'}, None, True) == 'C'

# Generated at 2022-06-22 21:46:36.301198
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # The test_utils module cannot import ansible.module_utils, so we use a
    # string here
    from ansible.module_utils.basic import AnsibleModule

    # Creating a mock module
    module = AnsibleModule()

    # We will check if we get the right locale
    assert get_best_parsable_locale(module) == 'C'

    # We will check if we get the right locale
    assert get_best_parsable_locale(module, preferences=['en_US.utf8']) == 'en_US.utf8'

    # We will check if we get the right locale
    assert get_best_parsable_locale(module, preferences=['en_US.utf8', 'C']) == 'en_US.utf8'

# Generated at 2022-06-22 21:46:41.809773
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    """Test get_best_parsable_locale function"""
    from ansible_collections.ansible.community.plugins.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-22 21:46:52.580470
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    class FakeModule(object):

        def get_bin_path(self, arg1):
            return "/usr/bin/locale"

        def run_command(self, arg1):
            return (0, 'C\nen_US.utf8\nen_US.UTF-8\nen_US.utf8\nen_US.UTF-8', '')

    res = get_best_parsable_locale(FakeModule())
    assert res == 'C.utf8'

    class FakeModule2(object):

        def get_bin_path(self, arg1):
            return "/usr/bin/locale"


# Generated at 2022-06-22 21:47:04.296250
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils import basic
    # Try 'C' locale on US English system
    parsed_locale = get_best_parsable_locale(basic.AnsibleModule(
        argument_spec=dict()
    ))
    assert parsed_locale == 'C'

    # Try 'C' locale on non-US English system
    parsed_locale = get_best_parsable_locale(basic.AnsibleModule(
        argument_spec=dict()
    ), preferences=['it_CH.utf8', 'fr_CH.utf8', 'de_CH.utf8'])
    assert parsed_locale == 'C'

    # Try 'it_CH.utf8' locale on Swiss German system

# Generated at 2022-06-22 21:47:13.364066
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest
    import platform
    import mock

    # Mock AnsibleModule and related functions
    from ansible.module_utils.basic import AnsibleModule

    run_command_failed = False

    def get_bin_path_mock(self, exe):
        if exe == 'locale':
            return 'locale'
        else:
            raise RuntimeWarning("Could not find '%s' tool" % exe)

    def run_command_mock(self, cmd):
        if cmd == ['locale', '-a']:
            if run_command_failed:
                return (1, "", "Unable to get locale information")

# Generated at 2022-06-22 21:47:24.593478
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.text.formatters import json as to_json


# Generated at 2022-06-22 21:47:35.602331
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    if not HAS_ANSIBLE_TEST:
        return

    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())

    # Test default case when binary locale is present and has output
    rc, out, err = module.run_command([module.get_bin_path('locale'), '-a'])
    with patch(MODULE_UTILS + "get_bin_path", return_value="/bin/locale"):
        with patch(MODULE_UTILS + "run_command", return_value=(0, out, err)):
            assert get_best_parsable_locale(module) == 'C'

    # Test locale bin not present
    with patch(MODULE_UTILS + "get_bin_path", return_value=None):
        assert get_

# Generated at 2022-06-22 21:47:43.994443
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import platform
    import mock
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_text


# Generated at 2022-06-22 21:47:53.474006
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Test for locales in preferred order
    module = MockModule()
    assert 'en_US.utf8' == get_best_parsable_locale(module, ['en_US.utf8', 'C.utf8', 'POSIX'])

    # Test for unavailable locale
    assert 'C' == get_best_parsable_locale(module, ['fr_FR.utf8'])

    # Test for first available locale
    assert 'POSIX' == get_best_parsable_locale(module, ['fr_FR.utf8', 'POSIX'])

    # Test for default locale if no locales given
    assert 'C' == get_best_parsable_locale(module)


# Generated at 2022-06-22 21:48:01.841603
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    locale = get_best_parsable_locale()
    assert locale == 'C'  # for platforms with no locale, it should return the default 'C'

    # the default value for preferences is the following list, so
    # test if it returns the default value: 'C'
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    locale = get_best_parsable_locale(preferences=preferences)
    assert locale == 'C'

    # test if it returns the value of the first prefered locale in the list
    preferences = ['en_US.utf8', 'C', 'POSIX']
    locale = get_best_parsable_locale(preferences=preferences)
    assert locale == 'en_US.utf8'

    # test

# Generated at 2022-06-22 21:48:03.695175
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    import ansible.module_utils.basic
    import ansible.module_utils.facts

    assert get_best_parsable_locale(ansible.module_utils.facts.AnsibleFactsModule()) in ['C', 'C.utf8', 'POSIX', 'en_US.utf8']

# Generated at 2022-06-22 21:48:09.821403
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    # Import the module using the mock environment but don't do any setup
    module = AnsibleModule(argument_spec={}, supports_check_mode=False)

    # mock out the module to use a static 'locale' command of the system that has the
    # expected locales.

# Generated at 2022-06-22 21:48:13.171045
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = None

    locale = get_best_parsable_locale(module)
    assert locale == 'C'

    locale = get_best_parsable_locale(module, preferences=['en_US.utf8'])
    assert locale == 'C'

# Generated at 2022-06-22 21:48:23.649437
# Unit test for function get_best_parsable_locale

# Generated at 2022-06-22 21:48:32.505033
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # sanity check, ensure we get valid locale options
    module = None
    assert get_best_parsable_locale(module) in ['C', 'POSIX']

    # if we don't have a locale option, then we should get C
    # a None preferences variable should also return C
    module = None
    preferences = None
    assert get_best_parsable_locale(module, preferences) == 'C'

    # we have preferences so test if we can match one of our locale preferences
    module = None
    preferences = ['C', 'POSIX']
    # test by changing the first preference to not match any locale option
    preferences[0] = 'NOT_A_REAL_LOCALE'
    assert get_best_parsable_locale(module, preferences) == 'POSIX'

    # we don't have any of our

# Generated at 2022-06-22 21:48:43.700008
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # pylint: disable=no-self-use
    # pylint: disable=too-many-arguments
    # pylint: disable=too-many-locals
    # pylint: disable=too-few-public-methods
    class MockModule(object):
        '''
        Mock Module class to use in testing
        '''
        def __init__(self, locale_bin, locale_rc, locale_out, locale_err, locale_warning):
            self.locale_bin = locale_bin
            self.locale_rc = locale_rc
            self.locale_out = locale_out
            self.locale_err = locale_err
            self.locale_warning = locale_warning


# Generated at 2022-06-22 21:48:46.633933
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # FIXME: This is a stub function which originally existed in
    #        AnsibleModule and was moved to this file but it did
    #        not contain any tests.  The tests here should mock
    #        out ansible.module_utils.basic.AnsibleModule in order
    #        to test the functionality of this function.
    assert True

# Generated at 2022-06-22 21:48:50.693284
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    assert get_best_parsable_locale(AnsibleModule({})) == 'C'

# Generated at 2022-06-22 21:49:01.611097
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        The below mocks need to be removed,
        as they should be in the ansible-test utility
    '''
    class MockModule:
        def __init__(self, bin_path=None, run_command=None):
            self.bin_path = bin_path
            self.run_command = run_command

        def get_bin_path(self, command):
            return self.bin_path

        def run_command(self, command):
            return self.run_command

    preferences = ['C.UTF-8', 'C.utf8', 'C', 'POSIX']
    module = MockModule(bin_path=None, run_command=(0, '', ''))
    result = get_best_parsable_locale(module, preferences)
    assert result == 'C'

    module = Mock

# Generated at 2022-06-22 21:49:10.200866
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    def _ansible_module(check_command, locale='C', locale_a=None):
        class FakeModule(object):
            class FakeModuleRunCommand(object):
                def __init__(self):
                    self.rc = 0
                    self.out = ''
                    self.err = ''
                    self.command = ''
                    self.check_command = check_command

                def run_command(self, command):
                    self.command = command
                    if command[0] == locale:
                        if command[1] == '--version':
                            self.rc = 1
                        elif command[1] == '-a':
                            self.out = locale_a
                    return self.rc, self.out, self.err
            bin_ansible_call = FakeModuleRunCommand()


# Generated at 2022-06-22 21:49:21.107895
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import sys

    # basic test cases
    locale_binary = 'locale'
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False,
    )
    # no locale binary
    assert get_best_parsable_locale(module, preferences=['C']) == 'C'

    # no preferred locale, we don't actually have to have the binary here
    module.get_bin_path = lambda cmd: locale_binary
    assert get_best_parsable_locale(module) == 'C'

    # locale binary, locale not installed
    module.run_command = lambda cmd, *args: (0, '', '')
    assert get_best_parsable_locale(module) == 'C'



# Generated at 2022-06-22 21:49:32.421612
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    import sys
    try:
        from unittest.mock import Mock
    except ImportError:
        # Python 2
        from mock import Mock

    try:
        from unittest.mock import patch
    except ImportError:
        # Python 2
        from mock import patch

    module = Mock()

    # Returns 'C' as default
    # module does not have get_bin_path
    assert get_best_parsable_locale(module) == 'C'

    # module has get_bin_path but returns no value
    module.get_bin_path = Mock(return_value=None)
    assert get_best_parsable_locale(module) == 'C'

    # default locale is 'C'
    def run_command_default(args):
        return 0, 'C', ''

# Generated at 2022-06-22 21:49:40.710050
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Test 1
    result = get_best_parsable_locale(None)
    assert result == "C"

    # Test 2
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    result = get_best_parsable_locale(None, preferences)
    assert result in preferences

    # Test 3
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    result = get_best_parsable_locale(None, preferences, True)
    assert result in preferences

# Generated at 2022-06-22 21:49:44.248339
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    locale = get_best_parsable_locale(module)
    assert locale == 'C'

# Generated at 2022-06-22 21:49:54.693661
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale('', ['C','fr_FR.utf8','fr_FR']) == 'C'
    assert get_best_parsable_locale('', ['fr_FR.utf8','fr_FR','C']) == 'fr_FR.utf8'
    assert get_best_parsable_locale('', ['fr_FR','fr_FR.utf8','C']) == 'fr_FR'
    assert get_best_parsable_locale('', ['fr_FR','C','fr_FR.utf8']) == 'fr_FR'
    assert get_best_parsable_locale('', ['en_US.utf8','C','fr_FR']) == 'en_US.utf8'

# Generated at 2022-06-22 21:50:02.771301
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.basic import AnsibleModule
    from io import StringIO

    test_input = StringIO("""
de_DE.UTF-8 UTF-8
en_US.UTF-8 UTF-8
fr_FR.UTF-8 UTF-8
C.UTF-8 UTF-8
POSIX
""")

    preferences = ['POSIX', 'C.UTF-8', 'C']

    module = AnsibleModule(
        argument_spec=dict(
            locale=dict()
        )
    )

    # Set the fake locale command
    def fake_run_command(*args, **kwargs):
        # first run_command is to find if locale exists, fake it
        if args[0][0] == module.get_bin_path("locale"):
            return 0, '', ''

        # then its

# Generated at 2022-06-22 21:50:07.834943
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils import basic
    import ansible.module_utils.common.ansible_util as ansible_utils

    m = basic.AnsibleModule(
        argument_spec=dict(),
    )

    ret = ansible_utils.get_best_parsable_locale(m)
    assert ret == 'C'

# Generated at 2022-06-22 21:50:18.158290
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import os
    import unittest
    import sys

    # import get_best_parsable_locale
    sys.path.append(os.path.dirname(__file__) + '/../../../')
    from lib.common.tools import get_best_parsable_locale

    # initialize the unittest module
    suite = unittest.TestSuite()

    # Mock an AnsibleModule object
    class MockAnsibleModule(object):

        class MockPath(object):
            @classmethod
            def get_bin_path(self, bin_name, required=False):
                return 'locale'


# Generated at 2022-06-22 21:50:21.262631
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = AnsibleModule(context={})
    output = get_best_parsable_locale(module)
    assert(output == 'C')

# Generated at 2022-06-22 21:50:29.286655
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.command

    locale_command_mock = ('C\nC.UTF-8\nen_US.utf8\nen_US.UTF-8\nen_US.utf8\n'
                           'en_US.UTF-8\nPOSIX\n')

    module = ansible.module_utils.command.AnsibleModule(argument_spec=dict())

    # Test with available locales
    module.run_command = lambda x: (0, locale_command_mock, '')

    best_locale = get_best_parsable_locale(module)
    assert best_locale == 'POSIX'

    best_locale = get_best_parsable_locale(module, preferences=['en_US.utf8', 'POSIX'])
    assert best_loc

# Generated at 2022-06-22 21:50:35.696054
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils import basic

    module = basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False,
    )

    # if the function fails, it should return 'C'. We do not have a way to test
    # if the locale tool is available or not.
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-22 21:50:46.417211
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Unit test for get_best_parsable_locale
    '''
    from ansible.module_utils.basic import AnsibleModule
    import sys
    import os

    class Locale(object):
        # class to mock locale binary, setup to return a list of locales on the system
        def __init__(self, locale_list):
            self.locale_list = locale_list

        def __call__(self, *args, **kwargs):
            if args[0] == '-a':
                return (0, '\n'.join(self.locale_list), '')
            else:
                return (1, '', 'unknown argument')

    # Test 1: Valid locale
    ansible_module = AnsibleModule({}, supports_check_mode=False)

# Generated at 2022-06-22 21:50:55.054554
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class AnsibleModule:
        def __init__(self, *args, **kwargs):
            pass

        def get_bin_path(self, name):
            return name

        def run_command(self, cmd, *args, **kwargs):
            locale = cmd[0]
            assert locale == 'locale'

            # scenario #1
            if cmd[1] == '-a':
                return (0, '\n'.join((
                    'C',
                    'C.UTF-8',
                    'en_US.utf8',
                    'POSIX',
                )), '')

            # scenario #2