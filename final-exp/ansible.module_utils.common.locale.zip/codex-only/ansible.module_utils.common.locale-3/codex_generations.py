

# Generated at 2022-06-22 21:41:02.241757
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec={}, supports_check_mode=True
    )

    # We want the application to continue if the locale cannot be found
    assert 'C' == get_best_parsable_locale(module, raise_on_locale=False)

    # We want the application to continue if the locale cannot be found, but we
    # have a list of locales that we prefer
    preferences = ['not_a_real_locale', 'C']
    assert 'C' == get_best_parsable_locale(module, preferences, raise_on_locale=False)

# Generated at 2022-06-22 21:41:11.765828
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.six import PY2
    import ansible.module_utils.common.parameters as cp
    import ansible.module_utils.basic as basic

    class FakeModule(object):
        def __init__(self):
            self.params = cp.Parameters({})
            self.check_mode = None
            self.fail_json = None

        def fail_json_on_cli_error(self, *args, **kwargs):
            pass

        @property
        def _name(self):
            return 'get_best_parsable_locale_test_module'

        def get_bin_path(self, binary, opt_dirs=(), required=False):
            if required:
                self.fail_json_on_cli_error(msg="locale not found")


# Generated at 2022-06-22 21:41:22.094953
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils.linux import get_best_parsable_locale as linux_get_best_parsable_locale

    # Test cases
    test_cases = [
        # No preferred locales (should return "C")
        ({}, 'locale_a', 0, 'C'),
        # One preferred locale
        ({}, 'locale_b', 0, 'en_US.utf8'),
        # Two preferred locales
        ({}, 'locale_c', 0, 'C.utf8'),
        # Bad locale command
        ({}, 'locale_d', 1, 'C')
    ]

    # run all the test cases

# Generated at 2022-06-22 21:41:33.772648
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    res1 = get_best_parsable_locale(module, [])
    res2 = get_best_parsable_locale(module, ['en_US.utf8', 'C.utf8', 'POSIX'])
    res3 = get_best_parsable_locale(module, ['en_US.utf8', 'POSIX'])
    res4 = get_best_parsable_locale(module, ['en_US.utf8', 'POSIX', 'C.utf8', 'C'])

# Generated at 2022-06-22 21:41:43.421823
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )

    assert get_best_parsable_locale(module, preferences=["de_DE.utf8"], raise_on_locale=False) == 'C'
    assert get_best_parsable_locale(module, preferences=["C.utf8"], raise_on_locale=False) == 'C'
    assert get_best_parsable_locale(module, preferences=["posix", "C.utf8"], raise_on_locale=False) == 'C'

# Generated at 2022-06-22 21:41:53.684349
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.utils.module_docs_fragments import get_best_parsable_locale

    assert get_best_parsable_locale(None, None) == 'C'
    assert get_best_parsable_locale(None, ['not_a_locale']) == 'C'
    assert get_best_parsable_locale(None, ['C']) == 'C'
    assert get_best_parsable_locale(None, ['C', 'not_a_locale']) == 'C'
    assert get_best_parsable_locale(None, ['not_a_locale', 'C']) == 'C'

# Generated at 2022-06-22 21:41:55.868322
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    assert get_best_parsable_locale(AnsibleModule()) == 'C'

# Generated at 2022-06-22 21:42:07.400989
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import os
    import tempfile
    temp_dir = tempfile.mkdtemp()
    os.environ['TERM'] = 'xterm'
    os.environ['LANG'] = 'C.UTF-8'
    os.environ['PATH'] = temp_dir + os.pathsep + os.environ['PATH']
    os.environ['LC_ALL'] = 'C.UTF-8'

    class MockModule(object):
        def __init__(self, *args, **kwargs):
            self.language = kwargs.get('language', 'c')
            self.params = kwargs

        def get_bin_path(self, *args):
            return os.path.join(temp_dir, args[0])


# Generated at 2022-06-22 21:42:18.542661
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    test_module = AnsibleModule(
        argument_spec=dict()
    )

    # Test preferred locales passed
    preferences = ['en_US.utf8', 'C.utf8', 'C']
    assert get_best_parsable_locale(test_module, preferences, raise_on_locale=True) == 'en_US.utf8'

    # Test locales not passed
    assert get_best_parsable_locale(test_module, preferences=None, raise_on_locale=True) == 'POSIX'

    # Test no available locales
    assert get_best_parsable_locale(test_module, ['en_AU.utf8'], raise_on_locale=True) == 'C'

    # Test no

# Generated at 2022-06-22 21:42:27.008390
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    test_module = type('test_module', (object,), {})
    test_module.run_command = type('run_command', (object,), {})
    test_module.get_bin_path = type('get_bin_path', (object,), {})

# Generated at 2022-06-22 21:42:29.689439
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    am = AnsibleModule({}, {})
    assert get_best_parsable_locale(am) == 'C'

# Generated at 2022-06-22 21:42:40.137938
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # This is a mock module
    class MockModule(object):
        def __init__(self, run_rc, run_out, run_err):
            self.run_rc = run_rc
            self.run_out = run_out
            self.run_err = run_err

        def get_bin_path(self, arg):
            if arg == 'locale':
                return 'locale'
            return None

        def run_command(self, command):
            return (self.run_rc, self.run_out, self.run_err)

    # Test 1: success, C.utf8 is available
    in1_run_rc = 0
    in1_run_out = 'C.UTF-8\nC\nen_US.UTF-8\nen_US.UTF-8\nen_US'


# Generated at 2022-06-22 21:42:51.140106
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # return_value_of_get_bin_path
    # items_to_check_if_in_available_locale
    # expected_return_value_of_function
    #       The items in items_to_check_if_in_available_locale will be checked
    #       in order, if an item is found that is in the list, that is the
    #       expected_return_value_of_function
    examples = [
        ('/usr/bin/locale', ['C.utf8', 'en_US.utf8', 'C', 'POSIX'], 'en_US.utf8'),
        ('/usr/bin/locale', ['POSIX', 'C'], 'C'),
        (None, ['POSIX', 'C'], 'C'),
    ]


# Generated at 2022-06-22 21:43:00.405934
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    def fake_get_bin_path(module, executable):
        if executable == 'locale':
            return '/dummy/locale'
        return None

    class FakeModule(object):
        def __init__(self, executable, locales):
            self.get_bin_path = fake_get_bin_path
            self.executable = executable
            self.locales = locales
            self.run_command_called = False
            self.rc = None
            self.out = None
            self.err = None

        def run_command(self, cmd):
            self.run_command_called = True
            assert cmd == ['/dummy/locale', '-a']
            self.rc = 0
            self.out = '\n'.join(self.locales)
            return self.rc, self.out,

# Generated at 2022-06-22 21:43:08.679228
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    locale = "C.utf8"

    # Mock up the module object

# Generated at 2022-06-22 21:43:10.439763
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None) == 'C'



# Generated at 2022-06-22 21:43:12.509797
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule()

    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-22 21:43:21.327443
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import os

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    def test_default_locale():
        locale = get_best_parsable_locale(module)
        assert locale == 'C'

    if 'LANG' not in os.environ:
        test_default_locale()
    else:
        os.environ['LANG'] = 'C.utf8'
        test_default_locale()

# Generated at 2022-06-22 21:43:30.684761
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # A good first guess
    assert get_best_parsable_locale(None) == 'C'

    # Test that a matching preference is returned
    assert get_best_parsable_locale(None,
                                    preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'
    # Test that a valid preferred locale is selected
    assert get_best_parsable_locale(None,
                                    preferences=['en_US.utf8', 'POSIX']) == 'en_US.utf8'

    # Test that a valid preferred locale is selected
    assert get_best_parsable_locale(None,
                                    preferences=['POSIX', 'C.utf8']) == 'C.utf8'

    # Test that first preference is selected if multiple match

# Generated at 2022-06-22 21:43:37.184368
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Mock out the module and bin_path
    class MockModule:
        def __init__(self):
            self.path = ['bin']

        def get_bin_path(self, name):
            return name

        def run_command(self, cmd, **kwargs):
            return 0, 'test', ''

    class MockModuleLocaleFail:
        def __init__(self):
            self.path = ['bin']

        def get_bin_path(self, name):
            return name

        def run_command(self, cmd, **kwargs):
            return 1, '', ''

    class MockModuleLocaleFail2:
        def __init__(self):
            self.path = ['bin']

        def get_bin_path(self, name):
            return name


# Generated at 2022-06-22 21:43:43.740166
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    ''' test get_best_parsable_locale '''

    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    locale = module.get_best_parsable_locale(module)
    assert locale == 'C'

# Generated at 2022-06-22 21:43:47.323361
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-22 21:43:58.833538
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils._text import to_bytes
    from mock import patch, Mock

    # Always returns C when locale not found
    mock_module = Mock()
    mock_module.run_command.return_value = (1, None, None)
    mock_module.get_bin_path.return_value = None
    try:
        get_best_parsable_locale(mock_module)
        assert False, "Should have exited here"
    except RuntimeWarning:
        pass

    # Respects configured preferred locales
    mock_module = Mock()
    mock_module.get_bin_path.return_value = "/usr/bin/locale"

# Generated at 2022-06-22 21:44:02.189735
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    assert get_best_parsable_locale(AnsibleModule) == 'C'

# Generated at 2022-06-22 21:44:07.542495
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    :returns: Boolean result of tests
    '''
    try:
        from ansible.module_utils.basic import AnsibleModule
    except ImportError:
        # Skip test if we can't import Ansible
        return False

    module = AnsibleModule(argument_spec=dict())
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-22 21:44:17.726076
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule, get_exception
    from ansible.module_utils.common.locales import get_best_parsable_locale

    module = AnsibleModule(
        argument_spec={
            'preferences': dict(type='list', default=None),
            'raise_on_locale': dict(type='bool', default=False)
        }
    )

    try:
        result = get_best_parsable_locale(module)
        module.exit_json(changed=False, locale=result)
    except Exception as e:
        module.fail_json(msg=repr(e), exception=traceback.format_exc())

if __name__ == '__main__':
    test_get_best_parsable_locale()

# Generated at 2022-06-22 21:44:25.700653
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Locale is not available
    module = None
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    try:
        get_best_parsable_locale(module, preferences, False)
    except Exception as e:
        assert e.message == "Could not find 'locale' tool"

    # Locale does not return proper output
    module = None
    class FakeAnsibleModule:
        def __init__(self):
            self.run_command = None
        def run_command(self, cmd):
            return 1, None, 'Fake Error: locale -a'
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    module = FakeAnsibleModule()

# Generated at 2022-06-22 21:44:36.197266
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # The code is not executable outside the module, so we use this trick
    # to run the unit test.
    module = type('AnsibleModule', (object,), dict(
        get_bin_path=lambda self, x: None,
        run_command=lambda self, x: (0, 'C\nPOSIX', ''),
    ))
    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, preferences=['POSIX', 'en_US.utf8']) == 'POSIX'
    assert get_best_parsable_locale(module, preferences=['fr_FR.utf8']) == 'C'

# Generated at 2022-06-22 21:44:47.566318
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Check if it chooses C
    assert get_best_parsable_locale(None) == 'C'
    # Check if it finds a non-default locale
    assert get_best_parsable_locale(None, preferences=['en_US.utf8']) == 'en_US.utf8'
    # Check if it prefers first locale if two match
    assert get_best_parsable_locale(None, preferences=['en_US.utf8', 'C.utf8']) == 'en_US.utf8'
    # Check if it returns the default locale if none found
    assert get_best_parsable_locale(None, preferences=['invalid_locale']) == 'C'
    # Check if it returns C if no locales provided

# Generated at 2022-06-22 21:44:59.102808
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    assert module.get_best_parsable_locale == get_best_parsable_locale

    # verify that the "C" locale is returned when locale is not installed
    # or not in the PATH
    module.run_command = lambda args, check_rc=True: (1, '', '')
    assert get_best_parsable_locale(module, preferences=None, raise_on_locale=False) == 'C'

    # verify that the "C" locale is returned when there is no output from locale's -a command
    module.run_command = lambda args, check_rc=True: (0, '', '')

# Generated at 2022-06-22 21:45:08.608818
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # mock module object
    class Module(object):
        class AnsibleModule(object):
            def get_bin_path(self, tool):
                return "locale"
            def run_command(self, command):
                if command == [locale, '-a']:
                    return 0, "C\nen\nen_US.utf8\nen_US\nen_US.UTF-8", ""
                else:
                    return 1, "", "command %s not expected" % command

    module = Module.AnsibleModule()
    locale = module.get_bin_path("locale")

    # test preferences - all available
    test_preferences = ["C", "en", "en_US.utf8", "en_US", "en_US.UTF-8"]
    assert get_best_parsable_locale

# Generated at 2022-06-22 21:45:19.187586
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # testing function directly as it is easier to unit test
    from ansible.module_utils.common._collections_compat import UserDict
    class AnsibleModule:
        def __init__(self):
            self.MODULE_LANG = 'C'
            self.params = UserDict()
            self.params['preferred_local'] = None
            self.params['fail_on_locale'] = False

        def get_bin_path(self, program):
            return program

        def run_command(self, cmd):
            if self.params['preferred_local'] is None:
                out = ('C.utf8\nen_US.utf8\nC\nPOSIX\n')
                return (0, out, "")
            else:
                return (0, '', "")

    # Testing with no

# Generated at 2022-06-22 21:45:29.856755
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.lang import set_locale
    from ansible.module_utils.common import load_platform_subclass

    # Create a fake AnsibleModule that does as little as possible
    module = AnsibleModule({})
    module.run_command = lambda cmd: (0, 'C\nC.UTF-8\n', '')

    # Create a fake Distro class that does as little as possible
    class MyDistro(object):
        @staticmethod
        def get_lang_env_vars():
            return {'LANGUAGE': None, 'LC_ALL': '', 'LC_MESSAGES': None}
    module.Distribution = load_platform_subclass(MyDistro, 'Distribution', 'MyDistro')

# Generated at 2022-06-22 21:45:40.206162
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict()
    )

    module.run_command = run_command_mock

    result, _ = get_best_parsable_locale(module)
    assert result == 'C.utf8'

    result, _ = get_best_parsable_locale(module, preferences=['C.utf8', 'C'])
    assert result == 'C.utf8'

    result, _ = get_best_parsable_locale(module, preferences=['en_US.utf8', 'en_US', 'C'])
    assert result == 'en_US.utf8'

    result, _ = get_best_parsable_locale(module, preferences=['C'])
    assert result

# Generated at 2022-06-22 21:45:51.972624
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec={},
    )

    test_input = ['C', 'C.UTF-8', 'POSIX', 'foo']
    test_output = get_best_parsable_locale(module, test_input)

    assert test_output == 'C'

    test_input = ['POSIX', 'foo']
    test_output = get_best_parsable_locale(module, test_input)

    assert test_output == 'POSIX'

    test_input = ['POSIX', 'C', 'foo']
    test_output = get_best_parsable_locale(module, test_input)

    assert test_output == 'POSIX'


# Generated at 2022-06-22 21:45:58.332110
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    """Test the get_best_parsable_locale function from this module
    """
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule()

    assert get_best_parsable_locale(module) == 'C'

    # Test that function does not raise an exception due to a missing 'locale' tool
    get_best_parsable_locale(module, preferences=['C'], raise_on_locale=True)


# Generated at 2022-06-22 21:46:07.005859
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import unittest
    import sys
    import os
    import StringIO
    import tempfile
    import shutil

    sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))
    from ansible.module_utils import basic

    # If a locale is set, we use it
    os.environ['LC_ALL'] = 'de_DE.utf8'
    # AnsibleModule object
    o = basic.AnsibleModule(
        argument_spec={
            'test_arg': {'required': False}
        },
    )
    assert ('de_DE.utf8' == get_best_parsable_locale(o))
    del os.environ['LC_ALL']

    # If locale cannot be found, use 'C'
    o

# Generated at 2022-06-22 21:46:18.106638
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Test that the 'C' locale is returned when locale is not installed
    # and raise_on_locale is False
    module_mock = Mock(spec_set=AnsibleModule)
    module_mock.get_bin_path = Mock(return_value=None)
    assert get_best_parsable_locale(module_mock, raise_on_locale=False) == 'C'

    # Test that when a preferred locale is available it returned
    module_mock = Mock(spec_set=AnsibleModule)
    module_mock.get_bin_path = Mock(return_value='locale')
    module_mock.run_command = Mock(return_value=(0, 'en_US.utf8\nC', None))

# Generated at 2022-06-22 21:46:26.777780
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.six import PY3

    # Test with unsupported CLIs
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    found = get_best_parsable_locale(module)
    assert found == 'C'

    # Test with supported CLIs
    if PY3:
        from ansible.module_utils.basic import AnsibleModuleMock
        module = AnsibleModuleMock(argument_spec=dict())
        found = get_best_parsable_locale(module)
        assert found == 'C'

    # Test with importing ansible
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    found = get_best_parsable_loc

# Generated at 2022-06-22 21:46:29.700659
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    assert get_best_parsable_locale(AnsibleModule(argument_spec={})) == 'C'

# Generated at 2022-06-22 21:46:38.427339
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.utils import module_docs
    from ansible.module_utils.basic import AnsibleModule

    try:
        get_best_parsable_locale(AnsibleModule(), raise_on_locale=True)
    except RuntimeWarning:
        pass
    else:
        raise AssertionError("Expected call to fail without installed locales")

    try:
        get_best_parsable_locale(AnsibleModule(argument_spec={}))
    except RuntimeWarning:
        raise AssertionError("Expected call to succeed but failed")

    del module_docs['get_best_parsable_locale']
    module_docs['get_best_parsable_locale'] = '''Gets the best locale, but returns a value'''

    assert 'C' == get_best_p

# Generated at 2022-06-22 21:46:42.713043
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    am = AnsibleModule()
    locale = get_best_parsable_locale(am)
    assert locale is not None
    assert isinstance(locale, str)

# Generated at 2022-06-22 21:46:50.884230
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Test situation where no preferences are provided
    assert 'C' == get_best_parsable_locale("")
    # Test situation where an empty list of preferences is provided
    assert 'C' == get_best_parsable_locale("", [])
    # Test situation where a single preference is provided
    assert 'C' == get_best_parsable_locale("", ['en_US'])

    # Test situation where preferences are provided but none are found
    assert 'C' == get_best_parsable_locale("", ['en_US', 'fr_FR'])

# Generated at 2022-06-22 21:46:57.327047
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    # test available languages
    preferences = ['C.utf8', 'es.utf8', 'C', 'POSIX']
    ENGLISH_LINES = ['C', 'POSIX', 'en_US.utf8', 'es_MX.utf8', 'es_US.utf8']
    # test only available language is POSIX
    POSIX_ONLY = ['POSIX']
    test_module = ansible.module_utils.basic.AnsibleModule(
        argument_spec={},
        supports_check_mode=False,
        bypass_checks=False
    )
    test_module.run_command = lambda args: (0, '\n'.join(ENGLISH_LINES), '')

# Generated at 2022-06-22 21:47:05.965791
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import sys

    # Create a basic module used for testing
    test_module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )

    # Test on Linux
    if sys.platform.startswith('linux'):

        # Ensure locale is a valid command
        test_module.run_command = lambda x, use_unsafe_shell=False, find_executable=None, encoding=None: (0, '', '')
        result = get_best_parsable_locale(test_module)
        assert result == None

        # Test the normal return path

# Generated at 2022-06-22 21:47:11.457791
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_native

    module = AnsibleModule(argument_spec=dict())

    # test1
    ret = get_best_parsable_locale(module, None, False)
    assert to_native(ret) == 'C'

    module = AnsibleModule(argument_spec=dict())
    # test2
    ret = get_best_parsable_locale(module, ['C', 'POSIX'], False)
    assert to_native(ret) == 'C'

    module = AnsibleModule(argument_spec=dict())
    # test3
    ret = get_best_parsable_locale(module, ['C.utf8', 'C', 'POSIX'], False)
    assert to_native

# Generated at 2022-06-22 21:47:22.301841
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    # Use a fake module to get the correct value.
    # This function is a bit too complex for a simple mocker call.
    mock_module = AnsibleModule({})
    fake_locale_bin = '/usr/bin/locale'
    mock_module.get_bin_path = lambda *args, **kwargs: fake_locale_bin
    mock_module.run_command = lambda *args, **kwargs: (0, 'C\nen_US.utf8', None)
    locale = get_best_parsable_locale(mock_module, raise_on_locale=True)
    assert locale == 'en_US.utf8', "en_US.utf8 should be returned as a parsable locale"

# Generated at 2022-06-22 21:47:32.417542
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        import ansible.modules.system.locale
    except ImportError:
        print('ERROR: Failed to import Ansible module locale')
        return

    # Initialize the module arguments
    basic_args = dict(
        name='C',
        arguments='',
        env=dict(
            LANG='C',
            LC_ALL='C',
            LC_MESSAGES='C',
            LANGUAGE='C',
            LC_CTYPE='C',
            LANG_ALL='C'
        )
    )

    # Monkey patch the module to use our custom function
    basic_args['get_best_parsable_locale'] = get_best_parsable_locale
    basic_args['get_bin_path'] = lambda x: '/usr/bin/' + x

    # Initial

# Generated at 2022-06-22 21:47:42.352940
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import tempfile

    # First, we test the normal case
    locale_module_mock = type(
        "AnsibleModule",
        (object,),
        dict(
            get_bin_path=lambda self, bin: '/bin/sh',
            run_command=lambda self, command: (0, 'C\nen_US.utf8\nC\nPOSIX', '')
        )
    )
    normal_ansible_module = locale_module_mock()
    assert 'C' == get_best_parsable_locale(normal_ansible_module)

    # Now we test the case where locale cannot be run

# Generated at 2022-06-22 21:47:53.546945
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = AnsibleModule(argument_spec={})
    module.params['raise_on_locale'] = True

    class AnsibleRun:
        def __init__(self):
            self.command = "locale"

        def run_command(self, command):
            self.command = command
            return 0, "", ""

    module.get_bin_path = lambda path: "/bin/false"
    module.run_command = AnsibleRun().run_command

    locale_utf8 = get_best_parsable_locale(module)
    assert locale_utf8 == 'C'
    assert module.run_command.command == ["/bin/false", "-a"]

    module.run_command = AnsibleRun().run_command
    module.get_bin_path = lambda path: "/usr/bin/locale"

# Generated at 2022-06-22 21:48:01.910161
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX', 'POSIX.utf8']
    raise_on_locale = False

    module = AnsibleModule(argument_spec=dict())
    module.run_command = lambda args, **kwargs: (0, 'C.utf8\nC\nen_US.utf8', '')
    assert get_best_parsable_locale(module, preferences, raise_on_locale) == 'C.utf8'

    preferences.reverse()
    assert get_best_parsable_locale(module, preferences, raise_on_locale) == 'POSIX.utf8'

    preferences.reverse()
    preferences.remove('POSIX.utf8')

# Generated at 2022-06-22 21:48:04.294073
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    assert 'C' == get_best_parsable_locale(module)

    module = AnsibleModule(argument_spec={}, supports_check_mode=True)

    assert 'C' == get_best_parsable_locale(module, ['C', 'UTF-8'])

# Generated at 2022-06-22 21:48:13.209586
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.plugins.action.normal
    from ansible.module_utils.common.process import get_bin_path

    locale = get_bin_path("locale")
    if not locale:
        # not using required=true as that forces fail_json
        raise RuntimeWarning("Could not find 'locale' tool")

    available = []

    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']

    rc, out, err = ansible.plugins.action.normal._get_locale()
    assert rc == 0
    assert out
    available = out.strip().splitlines()
    assert available

    found = 'C'  # default posix, its ascii but always there
    for pref in preferences:
        if pref in available:
            found = pref
            break


# Generated at 2022-06-22 21:48:23.648371
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    import subprocess

    preferences = ['fr_CA.utf8', 'fr_FR.utf8', 'fr_CH.utf8', 'fr_BE.utf8', 'fr.utf8']

    class ModuleStub:
        def __init__(self):
            self.run_command_calls = []

        def get_bin_path(self, cmd):
            return cmd

        def run_command(self, cmd):
            self.run_command_calls.append(cmd)
            stdout = subprocess.check_output(cmd)
            return 0, stdout, ''

    module = ModuleStub()

# Generated at 2022-06-22 21:48:32.474049
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.basic import AnsibleModule

    test_obj = AnsibleModule(
        arg_spec=dict(),
        supports_check_mode=False
    )

    # Check the POSIX defaults
    best = get_best_parsable_locale(test_obj)
    assert best == 'C'

    # Check with a list of preferred locales
    best = get_best_parsable_locale(test_obj, ['en_US.utf8', 'C.utf8'])
    assert best == 'en_US.utf8'

    # test with non-existent locale
    best = get_best_parsable_locale(test_obj, ['C.utf8', 'en_US.utf8', 'en_EE.utf8'])

# Generated at 2022-06-22 21:48:43.699947
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    am = AnsibleModule()
    am.run_command = lambda x: ([0, 'en_US.UTF-8\nen_US.UTF8\nC.UTF-8'], '', '')

    assert get_best_parsable_locale(am) == 'en_US.UTF-8'

    am.run_command = lambda x: ([0, 'en_US.UTF-8\nen_US.UTF8\nC\nC.UTF-8'], '', '')
    assert get_best_parsable_locale(am, ['C.UTF-8', 'POSIX']) == 'C.UTF-8'


# Generated at 2022-06-22 21:48:55.138328
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    # mocked up module and parameters
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # Test for default value
    res = get_best_parsable_locale(module)
    assert res == 'C'

    # Test for raised exception due to locale CLI issues
    try:
        # test for empty locale output
        res = get_best_parsable_locale(module, raise_on_locale=True)
    except RuntimeWarning as e:
        assert 'Unable to get locale information' in str(e)

    # Test for custom preferences list
    res = get_best_parsable_locale(module, ['ko_KR.utf8', 'ko_KR.eucKR'])

# Generated at 2022-06-22 21:49:05.422578
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Mock the module
    module = AnsibleModule(argument_spec=dict())

    # Mock get_bin_path
    module.get_bin_path = MagicMock(return_value='true')

    # Mock an available list
    out = 'en_US.utf8\nC\nPOSIX'
    rc = 0

    # Mock the run_command
    module.run_command = MagicMock(return_value=(rc, out, ''))
    assert get_best_parsable_locale(module) == 'C'

    # Mock the run_command
    rc = 1
    module.run_command = MagicMock(return_value=(rc, out, ''))
    assert get_best_parsable_locale(module, raise_on_locale=True) == 'C'

    # Test that it

# Generated at 2022-06-22 21:49:11.922420
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    c = """
        def main():
            import sys
            module = AnsibleModule(argument_spec={})
            locale_info = get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX'])
            module.exit_json(msg=locale_info)

        from ansible.module_utils.basic import *
        main()
    """
    p = subprocess.Popen(['python'], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    rc, out, err = p.communicate(c)
    locale_info = json.loads(out)
    assert locale_info['msg'] in ['C', 'POSIX']

# Generated at 2022-06-22 21:49:20.169532
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import os

    if os.name != 'posix':
        return 'skip'

    test = AnsibleModule(argument_spec=dict())

    res = get_best_parsable_locale(test)
    assert res == 'C'

    test.run_command = lambda args, **kwargs: (0, 'C.utf8\nen_US.utf8\nC\nPOSIX', '')

    res = get_best_parsable_locale(test)
    assert res == 'C.utf8'

# Generated at 2022-06-22 21:49:29.845196
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import os

    test_module = AnsibleModule(
        argument_spec=dict()
    )

    found = 'C'  # default posix, its ascii but always there
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']

    if os.path.exists('/usr/bin/locale'):
        found = get_best_parsable_locale(test_module, preferences)

    if found not in preferences:
        raise AssertionError("The 'locale' tool does not appear to return any of the expected results")

# Generated at 2022-06-22 21:49:40.749489
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Unit test for function get_best_parsable_locale
        :returns: A tuple that contains a boolean and a string
    '''
    from ansible.module_utils.basic import AnsibleModule
    # test successful detection of C.utf8, en_US.utf8, and POSIX
    module = AnsibleModule(argument_spec={})
    assert (get_best_parsable_locale(module) in ['C.utf8', 'en_US.utf8', 'POSIX'])

    # test successful detection of ar_AE.utf8
    module = AnsibleModule(argument_spec={})
    assert (get_best_parsable_locale(module, ['ar_AE.utf8']) == 'ar_AE.utf8')


# Generated at 2022-06-22 21:49:51.708528
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # test with a bad locale
    preferences_bad = ['C.utf8', 'de_DE.utf8', 'C', 'POSIX']

    # test without a locale
    preferences_none = ['C.utf8', 'fr_FR.utf8', 'C', 'POSIX']

    # test working locale
    preferences_working = ['C.utf8', 'fr_FR.utf8', 'C', 'POSIX']

    # test with no list of preferences
    preferences_empty = None

    # test with empty list of preferences
    preferences_empty_list = []

    # test with a list of 

# Generated at 2022-06-22 21:49:55.349940
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    ''' basic test for get_best_parsable_locale '''
    from ansible.module_utils.basic import AnsibleModule
    tmp = AnsibleModule(argument_spec=dict(), supports_check_mode=False)
    assert get_best_parsable_locale(tmp) == 'C'

# Generated at 2022-06-22 21:50:03.200967
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Test to see the get_best_parsable_locale will return the preferred locale
        or C in the case of none being available
    '''

    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule()

    # test default order
    best = get_best_parsable_locale(module)
    assert best in ("C.utf8", "en_US.utf8", "C", "POSIX")

    # test custom order
    best = get_best_parsable_locale(module, preferences=['C.utf8', 'abc', 'en_US.utf8', 'XYZ'])
    assert best == 'C.utf8'

    # test locale missing

# Generated at 2022-06-22 21:50:11.930745
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    my_module = MockModule()

    # Test with empty list of preferences
    assert get_best_parsable_locale(my_module, preferences=[]) == 'C'

    # Test that an unknown locale returns the default
    my_module.run_command = Mock(return_value=(0, 'de_DE.utf8', None))
    assert get_best_parsable_locale(my_module, preferences=['en_US.utf8', 'de_DE.utf8']) == 'C'

# This class is used for getting the version of ansible.module_utils._text

# Generated at 2022-06-22 21:50:16.836396
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    try:
        module = AnsibleModule(argument_spec=dict())
        x = get_best_parsable_locale(module, raise_on_locale=True)
        assert x == 'C' or x == 'POSIX'
    except RuntimeWarning:
        # not all systems have locale
        pass

# Generated at 2022-06-22 21:50:21.444374
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    for locale in [None, [], ['C.utf8', 'en_US.utf8', 'C', 'POSIX']]:
        result = get_best_parsable_locale(AnsibleModule, locale)
        assert result == 'C'

    preferred = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    result = get_best_parsable_locale(AnsibleModule, preferred)
    assert result in preferred


# Generated at 2022-06-22 21:50:29.367217
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    import io
    def get_bin_path(self, arg):
        return "/usr/bin/locale"

    def run_command(self, args, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False, path_prefix=None, cwd=None, use_unsafe_shell=False, prompt_regex=None, environ_update=None, umask=None):
        output = "C\nC.utf8\nPOSIX\nen_US.utf8\nen_US"
        return 0, output, None

    opts = ansible.module_utils.basic.AnsibleModule.ansible_opts
    ansible.module_utils.basic.AnsibleModule.ansible_opts = []


# Generated at 2022-06-22 21:50:41.451255
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    preferences = ['C.UTF-8', 'de_DE.UTF-8', 'en_US.UTF-8', 'C', 'POSIX', 'C.UTF-8']
    available = preferences + ["es_ES.UTF-8", "en_IN.UTF-8"]
    available.extend(["fr_FR.UTF-8", "tr_TR.UTF-8"])

    module = AnsibleModule(argument_spec=dict())
    found = module._get_best_parsable_locale(preferences=preferences, available_locales=available)

    # locale -a on the system where i am running unit test for this code
    # gives ['C', 'C.UTF-8', 'de_DE.UTF-8', 'en_IN.

# Generated at 2022-06-22 21:50:49.277137
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.basic import AnsibleModule

    # Create an instance of the AnsibleModule class...
    module = AnsibleModule(argument_spec=dict())

    # ... and run the function using the FakeAnsibleModule class
    class FakeAnsibleModule():

        # Create run_command mock
        class RunCommand():
            def __init__(self, rc, out, err):
                self.rc = rc
                self.out = out
                self.err = err

        # Mock module.run_command()

# Generated at 2022-06-22 21:50:58.858612
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import iteritems

    ansible_module = AnsibleModule(argument_spec=dict(), supports_check_mode=True)

    # The testing function
    def _test_get_best_parsable_locale(preferences, availables, rc, err, should_have_warning, expectations):
        ansible_module.run_command = mock_run_command

        if should_have_warning:
            warnings = []
            for v in availables.values():
                warnings.append("Could not find 'locale' tool")
            for v in err.values():
                warnings.append("No output from locale, rc=%s: %s" % (rc, to_native(v)))