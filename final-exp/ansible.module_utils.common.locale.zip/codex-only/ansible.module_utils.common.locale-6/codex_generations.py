

# Generated at 2022-06-22 21:40:55.046412
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    import unittest
    import os
    import sys
    try:
        from unittest.mock import patch, MagicMock
    except ImportError:
        from mock import patch, MagicMock

    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-22 21:41:05.678348
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            preferences=dict(type='list')
        ),
    )
    assert module.get_bin_path('locale')

    # no args
    got_locale = get_best_parsable_locale(module)
    assert got_locale == 'C', "Expected C got %s" % got_locale

    # empty list of preferences
    got_locale = get_best_parsable_locale(module, preferences=[])
    assert got_locale == 'C', "Expected C got %s" % got_locale

    # preferences not avail
    got_locale = get_best_parsable_locale(module, preferences=['foo', 'bar'])


# Generated at 2022-06-22 21:41:14.548015
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    class TestAnsibleModule(AnsibleModule):
        def __init__(self, *args, **kwargs):
            self.run_command_results = []
            self.run_command_responses = []
            super(TestAnsibleModule, self).__init__(*args, **kwargs)

        def run_command(self, cmd, args=(), check_rc=False, close_fds=True, executable=None, data=None):
            result = self.run_command_results.pop(0)
            response = self.run_command_responses.pop(0)
            return (result, response, None)

    module = TestAnsibleModule(
        argument_spec=dict(),
    )

    # Negative test case
    module.run

# Generated at 2022-06-22 21:41:23.546713
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    for version in sys.version_info[0:2]:
        if version < 3:
            import __builtin__ as builtins
        else:
            import builtins
    import ansible.module_utils.basic
    import ansible.module_utils.local_ansible_utils as utils

# Generated at 2022-06-22 21:41:35.442742
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # no module, so mock it
    module = type('module', (object,), {})()
    module.get_bin_path = lambda x: None
    module.run_command = lambda x: (0, "C,POSIX", None)

    assert get_best_parsable_locale(module) == "C"

    module.run_command = lambda x: (0, "C.utf8,POSIX", None)

    # Test when the option is not there
    assert get_best_parsable_locale(module, preferences=['Blah.utf8']) == "C"

    # Test when the option is there
    assert get_best_parsable_locale(module, preferences=['C.utf8']) == "C.utf8"

    # Test when no argument is there
    assert get_

# Generated at 2022-06-22 21:41:45.645113
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    import os
    import tempfile

    def get_available_locales():
        "Mock out the 'locale -a' command output, and return the result"
        fd, filename = tempfile.mkstemp()
        try:
            out = os.fdopen(fd, 'w')
            out.write('en_US\n')
            out.write('en_US.utf8\n')
            out.write('C\n')
            out.write('POSIX\n')
            out.write('C.UTF-8\n')
            out.close()
            with open(filename, 'r') as f:
                return f.read().strip().splitlines()
        finally:
            os.remove(filename)

    from ansible.module_utils import basic

# Generated at 2022-06-22 21:41:56.879378
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.basic import AnsibleModule

    def run_command(args, check_rc=False, close_fds=True, executable=None, data=None, binary_data=False):
        """Simulate ansible.module_utils.common.process.run_command
        """
        cmd = args[0]
        params = None

        if len(args) > 1:
            params = args[1:]

        out = ''
        err = ''
        rc = 0

        if cmd == get_bin_path('locale'):
            # Simulate locale -a
            out = ['C.UTF-8', 'en_US.UTF-8', 'POSIX']
            rc = 0

# Generated at 2022-06-22 21:42:08.212468
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    import mock

    class FakeModule:
        """Fake ansible module class with mock run_command"""
        def run_command(self, command):
            if command[0] == "locale":
                return 0, "test_locale_1\ntest_locale_2\nC\n", ""
            elif command[0] == "ip":
                return 1, "", "command ip not found"
            else:
                raise Exception("Unexpected command %s" % command[0])

        def get_bin_path(self, command):
            if command == "locale":
                return "locale"
            elif command == "ip":
                return None
            else:
                raise Exception("Unexpected command %s" % command)

    test_module = FakeModule()

    # No existing locales,

# Generated at 2022-06-22 21:42:19.180941
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class FakeModule(object):
        def __init__(self, outstring):
            self.outstring = outstring

        def run_command(self, args):
            out = self.outstring
            rc = 0
            err = ''
            return (rc, out, err)

        def get_bin_path(self, executable):
            return True

    # No outstring
    module = FakeModule('')
    assert get_best_parsable_locale(module) == 'C'

    # No preferred
    outstring = '''
C
POSIX
C.utf8
en_US.utf8
en_US.UTF-8
'''
    module = FakeModule(outstring)
    assert get_best_parsable_locale(module) == 'C'

    # Preferred present

# Generated at 2022-06-22 21:42:27.312271
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3
    import sys

    # Set values for on-purpose non-failing unit tests
    rc = 0
    out = ''
    err = ''

    # Test that locale -a returns the locale of the system
    module = AnsibleModule(argument_spec={})
    module.run_command = lambda args, **kwargs: (rc, out, err)
    test_locale = get_best_parsable_locale(module)
    if PY3:
        test_system_locale = sys.stdout.encoding
    else:
        import locale
        test_system_locale = locale.getpreferredencoding()

# Generated at 2022-06-22 21:42:38.075986
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    mod = AnsibleModule(
        argument_spec=dict(
            preferences=dict(required=False, type='list'),
            raise_on_locale=dict(required=False, type='bool'),
        ),
        supports_check_mode=True,
    )

    mod.get_bin_path = lambda x: '/bin/locale'

    # test with no given preferences
    mod.run_command = lambda x: (0, "C\nen_US.utf8\nC.utf8\nen_US.utf8\nen_US.utf8", '')
    utf8_locale = get_best_parsable_locale(mod)
    assert utf8_locale == "en_US.utf8"

    # test with a preference

# Generated at 2022-06-22 21:42:44.114804
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    parms = dict(
        path='/bin'
    )

    # no preferences
    module = AnsibleModule(argument_spec=parms, supports_check_mode=False)
    res = get_best_parsable_locale(module)
    assert res == 'C'

    # Given preferences
    module = AnsibleModule(argument_spec=parms, supports_check_mode=False)
    res = get_best_parsable_locale(module, ['C', 'POSIX', 'en_US.utf8'])
    assert res == 'C'

# Generated at 2022-06-22 21:42:47.879361
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale('module', ['C.utf8', 'en_US.utf8', 'C', 'POSIX'], False) == 'C'

# Generated at 2022-06-22 21:42:57.085618
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict()
    )

    locale = get_best_parsable_locale(module)
    print("Default locale is: '%s'" % locale)

    best = get_best_parsable_locale(module, ['en_AT.utf8', 'en_BE.utf8'])
    print("Best from the list 'en_AT.utf8', 'en_BE.utf8' is: '%s'" % best)


if __name__ == '__main__':
    test_get_best_parsable_locale()

# Generated at 2022-06-22 21:43:08.992379
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # This is the test method for get_best_parsable_locale function
    # if the function returns the expected output, the test will be passed
    # otherwise failed

    # Load JSON output from the file
    # This is a sample output of the command:
    # This is the sample input to the test
    with open('/vagrant/ansible/test/units/module_utils/basic/locale_unix_output.json') as f:
        input_json = json.load(f)
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX', 'zh_CN.utf8']
    for key, value in input_json.items():
        output = get_best_parsable_locale(key, preferences)
        assert output == value

# Generated at 2022-06-22 21:43:10.564006
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None) == 'C'

# Generated at 2022-06-22 21:43:11.095959
# Unit test for function get_best_parsable_locale

# Generated at 2022-06-22 21:43:16.606826
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    def mock_run_command(cmd):
        out = 'C\nen_US.utf8\nen_US.utf8\nen_US.utf8\nen_US.utf8\nC.UTF-8'
        return 0, out, ''

    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict()
    )
    module.run_command = mock_run_command

    assert get_best_parsable_locale(module) == 'en_US.utf8'

# Generated at 2022-06-22 21:43:26.198647
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Test function get_best_parsable_locale
    :return:
    '''
    import tempfile
    import textwrap
    import shutil
    import sys

    from ansible.module_utils._text import to_text
    from ansible.module_utils.basic import AnsibleModule

    tf = tempfile.NamedTemporaryFile()
    if sys.platform == 'win32':
        from ansible.module_utils.win32 import get_file_encoding
        encoding = get_file_encoding(sys.stdin)

# Generated at 2022-06-22 21:43:36.986102
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Unit test for function get_best_parsable_locale()
    '''
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Test 1
    # Valid set of preferences
    # Expected Return: en_US.utf8
    preferences = ['en_US.utf8', 'C.utf8', 'POSIX', 'C']
    assert get_best_parsable_locale(module, preferences) == "en_US.utf8"

    # Test 2
    # Valid set of preferences with raise_on_locale=True
    # Expected Raise: RuntimeWarning
    preferences = ['en_US.utf8', 'C.utf8', 'POSIX', 'C']

# Generated at 2022-06-22 21:43:48.198602
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.common.process import get_bin_path
    import mock
    import sys

    # Importing is not enough as ansible may have monkey-patched the original module
    sys.modules['locale'] = mock.Mock()

    # Set get_bin_path to return our fake executable
    module_mock = mock.MagicMock()
    module_mock.get_bin_path.return_value = 'locale'

    # Set locale -a to return our locale prefs
    locale_a_mock = mock.MagicMock()

# Generated at 2022-06-22 21:43:58.947108
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    # fixtures
    m_run_command = dict(rc=0, stdout="", err="")
    m_get_bin_path = None

    # specific test hook
    def run_hook(args):
        if args[0] == "/usr/bin/locale":
            if args[1] == "-a":
                return m_run_command["rc"], m_run_command["stdout"], m_run_command["err"]
            if args[1] == "-m":
                return m_run_command["rc"], m_run_command["stdout"], m_run_command["err"]

    def get_bin_hook(cmd):
        return m_get_bin_path
    # test class
    class TestModule(AnsibleModule):
        pass

# Generated at 2022-06-22 21:44:07.405181
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    # AnsibleModule.run_command doesn't work without a class instance
    # so we have to mock it
    class mock_module(AnsibleModule):
        def run_command(self, cmd):
            if cmd == ['locale', '-a']:
                # empty output
                return (0, '', '')
            else:
                return (0, '', '')
    module = mock_module(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, preferences=['en_US.utf8']) == 'en_US.utf8'


# Generated at 2022-06-22 21:44:17.647332
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.compat.tests import unittest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.text.converters import to_bytes

    class TestModule(object):
        def __init__(self):
            self.run_command_count = 0
            self.run_command_rc = 0
            self.run_command_out = b''
            self.run_command_err = b''

        def get_bin_path(self, command):
            if command == b'locale':
                return b'locale'
            else:
                return None

        def run_command(self, args):
            '''Simulate the system locale command'''
            self.run_command_count += 1


# Generated at 2022-06-22 21:44:21.644628
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule()

    found = get_best_parsable_locale(module=module)
    assert found == 'C'

    preferences = ['en_US', 'fr_FR']
    found = get_best_parsable_locale(module=module, preferences=preferences)
    # Note: we expect 'C' as the default, see docstring
    assert found == 'C'

# Generated at 2022-06-22 21:44:27.786110
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    locale = "C"
    test_module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(test_module) == locale
    assert get_best_parsable_locale(test_module, preferences=None) == locale
    assert get_best_parsable_locale(test_module, preferences=['a', 'b', 'c']) == locale

# Generated at 2022-06-22 21:44:37.708858
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.basic import AnsibleModule

    test_module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # No test for 'locale' command installed, last resort is always 'C'
    assert get_best_parsable_locale(test_module, raise_on_locale=True) == 'C'

    # Test for non-existing locales, 'C' is last resort
    assert get_best_parsable_locale(test_module, preferences=['A', 'B', 'C'], raise_on_locale=True) == 'C'

    # Test for existing locales, first match of preferred list wins

# Generated at 2022-06-22 21:44:48.024582
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    def mock_get_bin_path(name):
        if name == 'locale':
            return 'locale'
        return None

    def mock_run_command(args, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False, path_prefix=None, cwd=None, use_unsafe_shell=False, prompt_regex=None, environ_update=None):
        if args[0] == 'locale' and args[1] == '-a':
            return 0, '\n'.join(['C', 'POSIX', 'en_US.UTF-8', 'fr_FR.UTF-8', 'es_ES.UTF-8', ]), ''
        return None

    class AnsibleModuleMock:
        def __init__(self):
            self

# Generated at 2022-06-22 21:44:58.248809
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = AnsibleModule(argument_spec=dict())
    preference = ['en_US.utf8', 'C']

    # when the locale is not installed, it should return the default C
    module.run_command = MagicMock(return_value=(1, "", ""))
    assert get_best_parsable_locale(module, preference) == 'C'

    # try a locale that is not installed
    module.run_command = MagicMock(return_value=(0, '', ''))
    assert get_best_parsable_locale(module, preference) == 'C'

    # try a valid locale with multiple preferences
    module.run_command = MagicMock(return_value=(0, 'C.utf8\nen_US.utf8', ''))

# Generated at 2022-06-22 21:45:08.034560
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import StringIO

    test_module = AnsibleModule(argument_spec={})

    test_preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX', 'fr_FR.utf8']
    expected_locale = 'C.utf8'

    def test_run_command(args, check_rc=True):
        return (0, expected_locale, '')

    def test_get_bin_path(path):
        return None

    # Mock the module
    test_module.run_command = test_run_command
    test_module.get_bin_path = test_get_bin_path
    test_module.params = {}
    test_module.warnings = []

# Generated at 2022-06-22 21:45:18.981365
# Unit test for function get_best_parsable_locale

# Generated at 2022-06-22 21:45:29.780752
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Create a fake AnsibleModule()
    class AnsibleModule():
        def get_bin_path(self, name):
            if name.endswith('locale'):
                return name
            return None

        def run_command(self, cmd, check_rc=False):
            if cmd[0] == 'locale' and len(cmd) == 2 and cmd[1] == '-a':
                return (0, 'C\nen_US.utf8\nC.utf8', '')
            return (127, '', 'unknown command or could not be found')

    module = AnsibleModule()

    # Test with no preferences given
    assert get_best_parsable_locale(module) == "C.utf8"

    # Test with preferences given, with the first and last being the same
    # Test that with the

# Generated at 2022-06-22 21:45:33.617174
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    test_module = AnsibleModule()

    result = get_best_parsable_locale(test_module)
    assert result is not None
    assert result == 'C'

# Generated at 2022-06-22 21:45:42.603134
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class FakeAnsibleModule(object):
        def __init__(self):
            self.run_command = self.fake_run_command
            self.get_bin_path = self.fake_get_bin_path

        def fake_run_command(self, args, check_rc=True):
            if args == ['/usr/bin/locale', '-a']:
                return 0, "C\nen_US.utf8\nPOSIX\nen_US.utf8.utf8\n"
            else:
                return 1, "", "This is a test"

        def fake_get_bin_path(self, args):
            return '/usr/bin/locale'

    module = FakeAnsibleModule()

    assert('C' == get_best_parsable_locale(module, ['C']))

# Generated at 2022-06-22 21:45:47.690675
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic as basic

    assert get_best_parsable_locale(basic.AnsibleModule(basic.basic._load_params())) == 'C', 'get_best_parsable_locale did not return expected locale'

# Generated at 2022-06-22 21:45:58.240677
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # pip install mock
    from mock import Mock, patch
    import os

    # the locale module is a dictionary (module_utils) containing the function we want to test
    # get_best_parsable_locale.  The module, get_best_parsable_locale is passed as an argument
    # in a Mock class.  So testing the module, is essentially testing the get_best_parsable_locale
    # function.
    from ansible.module_utils.locale import get_best_parsable_locale

    # test the case where the C locale is returned since an exception is raised
    module = Mock()

    pref = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']

# Generated at 2022-06-22 21:46:06.941015
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import re

    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']

    module = AnsibleModule({})
    # Test non-English output

    # Test non-English locale
    locale = get_best_parsable_locale(module, preferences, raise_on_locale=True)
    assert locale in preferences

    # Test invalid locale
    preferences = ['invalid.locale']

    # Test non-English locale
    locale = get_best_parsable_locale(module, preferences, raise_on_locale=True)
    assert locale in preferences

    # Test non-ASCII locale
    preferences = ['fi_FI.iso88591']

    # Test non-English locale
    locale = get_best_

# Generated at 2022-06-22 21:46:18.106605
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Tests for getting available locale.
    :return: None
    '''
    import os
    import subprocess
    import sys
    import unittest
    import tempfile
    from test.support.script_helper import assert_python_ok

    import ansible.module_utils.basic
    import ansible.module_utils.i18n

    module_name = "test_module_path"
    module_path = os.path.join(module_name + ".py")

# Generated at 2022-06-22 21:46:26.776120
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    def get_best_parsable_locale_stub(module, preferences):
        return "C.UTF-8"

    module = Mock()
    module.get_bin_path.side_effect = get_best_parsable_locale_stub
    module.out = "C.UTF-8"
    assert get_best_parsable_locale(module) == "C.UTF-8"

    module.get_bin_path.side_effect = None
    module.run_command.return_value = (0, "C.UTF-8", "")
    module.out = "C.UTF-8"
    assert get_best_parsable_locale(module) == "C.UTF-8"

    module.run_command.return_value = (0, "", "")

# Generated at 2022-06-22 21:46:34.208622
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None, None) == 'C'
    assert get_best_parsable_locale(None, ['C']) == 'C'
    assert get_best_parsable_locale(None, ['en_US.UTF-8', 'C']) == 'en_US.UTF-8'
    assert get_best_parsable_locale(None, ['en_US.UTF-8', 'en_US.UTF-8']) == 'en_US.UTF-8'

# Generated at 2022-06-22 21:46:40.696278
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # We use a common mock module for most tests
    from ansible.module_utils.basic import AnsibleModule

    mock_module = AnsibleModule({})
    mock_module._ansible_debug = True
    # get_bin_path() always returns the tool name if it exists
    mock_module.get_bin_path = lambda x: x

    # Test cases for get_best_parsable_locale() return value

# Generated at 2022-06-22 21:46:51.863292
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None) == 'C'

    module = MagicMock()
    module.get_bin_path.return_value = '/bin/locale'

    stdout = '''\
C
C.utf8
de_DE.utf8
C.UTF-8
de_DE.UTF-8
POSIX
'''.strip()

    module.run_command.return_value = (0, stdout, '')

    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, ['POSIX']) == 'POSIX'
    assert get_best_parsable_locale(module, ['de_DE.utf8']) == 'de_DE.utf8'
    assert get_best_p

# Generated at 2022-06-22 21:47:02.209461
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule({})
    assert get_best_parsable_locale(module) == 'C'

    module = AnsibleModule({})
    assert get_best_parsable_locale(module, ['foo']) == 'C'

    module = AnsibleModule({})
    assert get_best_parsable_locale(module, ['foo', 'C']) == 'C'

    module = AnsibleModule({})
    assert get_best_parsable_locale(module, ['foo', 'POSIX']) == 'POSIX'

# Generated at 2022-06-22 21:47:11.939906
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    test_module = object()
    test_module.run_command = get_best_parsable_locale_run_command
    test_module.get_bin_path = get_best_parsable_locale_bin_path

    test_preferences = ['C.UTF-8', 'en_US.UTF-8', 'POSIX']
    test_locale_list = ['C.UTF-8', 'de_DE.UTF-8', 'POSIX', 'en_US.UTF-8']
    test_result = get_best_parsable_locale(test_module, test_preferences)
    assert test_result == 'C.UTF-8'


# Generated at 2022-06-22 21:47:23.112090
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.common.process import get_bin_path, get_bin_path_py3
    import os

    def _get_bin_path(name):
        return os.path.join(os.path.dirname(__file__), name)

    def get_bin_path_mock(name):
        if name == 'locale':
            return '/bin/locale'
        return get_bin_path_py3(name)

    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-22 21:47:33.503209
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # import modules needed to set up the ansible module
    from ansible.module_utils.basic import AnsibleModule
    import sys
    import tempfile
    import platform

    # set up some fake data
    tmp_dir = tempfile.gettempdir()
    tmp_file = tempfile.NamedTemporaryFile()

# Generated at 2022-06-22 21:47:43.000340
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import platform

    current_os = platform.system()
    # Test default return when None passed in
    if current_os == "Linux":
        assert get_best_parsable_locale(AnsibleModule(argument_spec={})) == "C"
    elif current_os == "FreeBSD":
        assert get_best_parsable_locale(AnsibleModule(argument_spec={})) == "POSIX"
    else:
        assert get_best_parsable_locale(AnsibleModule(argument_spec={})) == "en_US.utf8"

    # Linux

# Generated at 2022-06-22 21:47:48.210996
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    _module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(_module, raise_on_locale=True, preferences=['FOO_BAR_BAZ']) == 'C'

# Generated at 2022-06-22 21:47:51.982851
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible import module_utils
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    assert module_utils.get_best_parsable_locale(module)

# Generated at 2022-06-22 21:48:00.726606
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    This is a very minimal test of the get_best_parsable_locale method to ensure
    that we don't introduce a regression. We can enhance this as necessary.
    '''

    try:
        import ansible.module_utils.basic
    except ImportError:
        return

    test_module = ansible.module_utils.basic.AnsibleModule(argument_spec=dict())

    # This is the list of available locates on the test system

# Generated at 2022-06-22 21:48:11.272182
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    test_preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    test_available = test_preferences

    # test that we got the first one in the list
    result = get_best_parsable_locale(AnsibleModule(argument_spec={}, supports_check_mode=True), test_preferences, test_available)
    assert result == test_available[0]

    # test that we got the second one in the list (ensure we quit)
    test_preferences = test_available[1:]
    test_available = test_preferences

# Generated at 2022-06-22 21:48:15.781155
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import tempfile

    locale_path = tempfile.mktemp()

    # make fake locale command
    with open(locale_path, 'w') as f:
        f.write("""#!/usr/bin/python
import sys
import json

print(json.dumps(sys.argv))
""")

    with open(locale_path, 'r') as f:
        # so we can read the file
        pass

    # Make the fake binary executable
    import os
    os.chmod(locale_path, 0o755)

    class FakeModule(AnsibleModule):
        def __init__(self):
            self.run_command = self.fake_run_command
            self.get_bin_path = self.fake_get_bin

# Generated at 2022-06-22 21:48:26.262154
# Unit test for function get_best_parsable_locale

# Generated at 2022-06-22 21:48:32.361271
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils import basic

    module = AnsibleModule(
        argument_spec=dict(
            foo=dict(type='int', default=1),
            bar=dict(type='str'),
        )
    )

    try:
        basic.get_best_parsable_locale(module, raise_on_locale=True)
        assert False
    except RuntimeWarning:
        assert True

    module.run_command = mock.Mock()
    module.run_command.return_value = (0, 'posix\nC.UTF-8\nfr_FR.utf8', '')
    assert basic.get_best_parsable_locale(module) == 'C.UTF-8'


# Generated at 2022-06-22 21:48:43.569162
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    assert module.get_best_parsable_locale() == 'C'
    assert module.get_best_parsable_locale(preferences=['foo']) == 'C'
    assert module.get_best_parsable_locale(preferences=['C']) == 'C'
    assert module.get_best_parsable_locale(preferences=['C', 'POSIX']) == 'C'
    assert module.get_best_parsable_locale(preferences=['POSIX', 'C']) == 'C'
    assert module.get_best_parsable_locale(preferences=['C', 'en_US.utf8'])

# Generated at 2022-06-22 21:48:44.743550
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    pass  # FIXME: implement unit test

# Generated at 2022-06-22 21:48:51.981954
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Some testing component(s) are required

    # Test 1: locale command not present
    TestModule = type('AnsibleModule', (), {'get_bin_path': lambda self, *args: None})
    TestModule = TestModule()
    assert get_best_parsable_locale(TestModule) == 'C'

    # Test 2: no output from locale command
    TestModule = type('AnsibleModule', (), {'run_command': lambda self, *args: [0, '', '']})
    TestModule = TestModule()
    assert get_best_parsable_locale(TestModule) == 'C'

    def test_run_command(cmd, check=True):
        assert cmd[0] == 'locale'
        assert cmd[1] == '-a'

# Generated at 2022-06-22 21:49:03.184596
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(supports_check_mode=True)

    # no locale but use_posix_locale_for_parsing is true
    assert get_best_parsable_locale(module, raise_on_locale=True) == 'C'
    # no locale but use_posix_locale_for_parsing is false
    assert get_best_parsable_locale(module, raise_on_locale=False) == 'C'

    # with locale but not runnable
    module.get_bin_path = lambda x: '/bin/locale'
    assert get_best_parsable_locale(module, raise_on_locale=False) == 'C'

    # with locale but not runnable

# Generated at 2022-06-22 21:49:04.725668
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None) == 'C'



# Generated at 2022-06-22 21:49:11.565464
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None) == 'C'
    assert get_best_parsable_locale(None, preferences=None) == 'POSIX'
    assert get_best_parsable_locale(None, preferences=['en_US.utf8', 'en_GB']) == 'en_US.utf8'
    assert get_best_parsable_locale(None, preferences=['en_GB', 'en_US.utf8']) == 'en_US.utf8'
    assert get_best_parsable_locale(None, preferences=['en_US.utf8', 'en_GB', 'C.utf8']) == 'en_US.utf8'

# Generated at 2022-06-22 21:49:21.936808
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Unit test for function get_best_parsable_locale
    '''

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY2

    class FakeModule(object):

        def __init__(self, out, err, rc):
            self.out = out
            self.err = err
            self.rc = rc

        def get_bin_path(self, arg):
            '''
                Function to mock method get_bin_path
            '''
            if arg in ['locale']:
                return arg
            return None

        def run_command(self, arg):
            '''
                Function to mock method run_command
            '''

# Generated at 2022-06-22 21:49:24.171016
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    if get_best_parsable_locale() != 'C':
        print("get_best_parsable_locale() returned a locale other than 'C'")
        sys.exit(1)

# Generated at 2022-06-22 21:49:25.100391
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale() == 'C'

# Generated at 2022-06-22 21:49:35.327141
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        This is a unit test for the get_best_parsable_locale function
        It requires an AnsibleModule instance
    '''
    from ansible.module_utils import basic

    # Create a new module instance
    module = basic.AnsibleModule(argument_spec={})

    # test default if no preferred locales specified
    best_locale = get_best_parsable_locale(module)
    assert best_locale == 'C'

    # test with a list of preferred locales
    pref_locales = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    best_locale = get_best_parsable_locale(module, preferences=pref_locales)
    assert best_locale == 'C'

# Generated at 2022-06-22 21:49:44.375917
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    locale_list = ['C', 'C.UTF-8', 'POSIX']
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    module = AnsibleModule(argument_spec={})
    module.run_command = lambda x: (0, '\n'.join(locale_list) + '\n', '')

    assert get_best_parsable_locale(module) == 'C'

    module.run_command = lambda x: (0, 'C\nen_US\nen_US.utf8\nPOSIX', '')
    assert get_best_parsable_locale(module) == 'en_US.utf8'

test_get_best_parsable_locale()

# Generated at 2022-06-22 21:49:54.773693
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    import os
    import tempfile
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat import unittest
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch, Mock
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils import basic

    ##########################################################################
    # Test Cases
    ##########################################################################

    class TestGetBestParsableLocale(unittest.TestCase):

        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.old_cwd = os.getcwd()
            os.chdir(self.tmpdir)


# Generated at 2022-06-22 21:50:02.835936
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    test_module = AnsibleModule(
        argument_spec = dict(
            language = dict(type='str', default='en_US.utf8'),
        ),
    )

    # Test where no preferences list is given
    # as well as forcing the language to be available
    # to test the language preference feature
    assert(get_best_parsable_locale(test_module, [test_module.params['language']]) == test_module.params['language'])

    # Test the default locale behavior
    # with no locale CLI
    test_bin_paths = test_module.get_bin_path()
    test_bin_paths.pop('locale')

# Generated at 2022-06-22 21:50:13.309116
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Test with all defaults
    parser_locale = get_best_parsable_locale(module)
    assert parser_locale == 'C'

    # Test with a locale available in system
    parser_locale = get_best_parsable_locale(module, preferences=['it_IT.UTF-8'])
    assert parser_locale == 'it_IT.UTF-8'

    # Test with a locale not available in system
    parser_locale = get_best_parsable_locale(module, preferences=['en_US.UTF-8'])
    assert parser_locale == 'C'

# Generated at 2022-06-22 21:50:21.142542
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    from ansible.module_utils.basic import AnsibleModule

    def execute_module(name, *args):
        if name == "run_command":
            return (0, "", "")
        elif name == "get_bin_path":
            return "locale"
        else:
            print("Unexpected command %s" % name)
            sys.exit(1)

    class MyModule(AnsibleModule):
        def run_command(self, command):
            return execute_module(*command)

        def get_bin_path(self, command):
            return execute_module(*command)

    m = MyModule()
    # these commands run successfully and return a locale
    assert m.get_best_parsable_locale() == 'C'
    assert m.get_best_parsable_

# Generated at 2022-06-22 21:50:29.231418
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Test code for function get_best_parsable_locale
    '''
    # Thorough testing is not practical, but we can get some coverage.
    from ansible.module_utils.basic import AnsibleModule
    # pylint: disable=unused-argument
    # pylint: disable=no-self-use
    class MockModule:
        def __init__(self, *args, **kwargs):
            pass

        def get_bin_path(self, *args, **kwargs):
            return 'bin_path'

        def run_command(self, *args, **kwargs):
            return (0, 'a_locale', None)

    # no preferences, C.utf8, C, or POSIX in the available locales.
    # We should get the default, 'C'.
   

# Generated at 2022-06-22 21:50:41.177816
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    def mock_get_bin_path(module_name):
        return '/bin/locale'
    def mock_run_command(cmd, argv):
        return 0, 'C.utf8\nen_US.utf8\nen_US.utf8\nC\nPOSIX\n', ''

    preferences = ['foo', 'C', 'bar']

    from ansible.module_utils.basic import AnsibleModule
    am = AnsibleModule(argument_spec={}, check_invalid_arguments=False)
    am.get_bin_path = mock_get_bin_path
    am.run_command = mock_run_command

    assert get_best_parsable_locale(am, preferences) == 'C'

    preferences = ['MISSING', 'C', 'POSIX']
    assert get_best_p

# Generated at 2022-06-22 21:50:49.213088
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # The standard locale module should not be present to test this with it does
    # not work, so we remove it first.
    try:
        del sys.modules['locale']
    except:
        pass
    from ansible.module_utils import basic
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.six import iteritems, string_types
    from ansible.module_utils.six.moves import shlex_quote
    from ansible.module_utils.six.moves.urllib.parse import urlparse
    from ansible.module_utils.six.moves.urllib.request import url2pathname, pathname2url
    from ansible.module_utils.urls import *
    module = AnsibleModule('testmodule', {})

# Generated at 2022-06-22 21:50:58.858739
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    """Test case 1: Check the return value of function get_best_parsable_locale"""

    with mock.patch('os.path.exists') as os_mock:
        os_mock.return_value = True
        with mock.patch.object(ansible.module_utils.basic.AnsibleModule, 'run_command') as run_mock:
            run_mock.return_value = (0, 'C.utf8\nen_US.utf8\nC\nPOSIX\n', '')
            module = ansible.module_utils.basic.AnsibleModule(
                argument_spec={},
                supports_check_mode=True
                )
            locale = get_best_parsable_locale(module)
            assert locale == 'C.utf8'
