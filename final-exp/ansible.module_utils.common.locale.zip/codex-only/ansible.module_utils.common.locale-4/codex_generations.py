

# Generated at 2022-06-22 21:41:03.987834
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.modules.system.hardware.networking.ping as test_module
    locale = get_best_parsable_locale(test_module)
    if locale != 'C':
        print("Expected C as result of get_best_parsable_locale, received %s" % locale)
        return False

    # Just test that it does not raise exceptions
    get_best_parsable_locale(test_module, ['C.utf8', 'en_US.utf8', 'C', 'POSIX'])

    return True

# Test for function get_best_parsable_locale
if __name__ == '__main__':
    test_get_best_parsable_locale()

# Generated at 2022-06-22 21:41:13.279008
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    import unittest

    try:
        from unittest import mock
    except ImportError:
        import mock

    # class to mock AnsibleModule
    class FakeAnsibleModule(object):

        def __init__(self):
            self.run_command = mock.MagicMock()

        def get_bin_path(self, name):
            if name != 'locale':
                raise Exception("unexpected command '%s' called" % name)
            return '/usr/bin/locale'

    # Function to run the test
    def run_test(case):
        am = FakeAnsibleModule()

        if 'fake_locale_output' in case:
            am.run_command.return_value = (0, case['fake_locale_output'], None)

# Generated at 2022-06-22 21:41:19.076128
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible_module_get_best_parsable_locale

    module = ansible_module_get_best_parsable_locale.MyModule()

    # detect_needs_sshpass=False => no sshpass dependency
    results = get_best_parsable_locale(module, preferences=['C', 'POSIX'])

    assert 'C' == results

# Generated at 2022-06-22 21:41:31.067134
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    module = ansible.module_utils.basic.AnsibleModule(argument_spec=dict())
    # Test defaults
    found = get_best_parsable_locale(module)
    assert found == 'C'
    # Test when locale is actually found
    preferences = ['C.utf8', 'C', 'POSIX']
    setattr(module, 'run_command', lambda x: (0, '\n'.join(preferences), ''))
    found = get_best_parsable_locale(module, preferences)
    assert found == 'C.utf8'
    # Test when locale is not found
    preferences = ['C.utf8', 'z.Y.utf8', 'POSIX']

# Generated at 2022-06-22 21:41:42.660139
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    m = AnsibleModule(argument_spec={})
    m.run_command = lambda x: (0, 'C\nen_US.utf8\nC.utf8\nPOSIX', '')
    assert m.get_bin_path("locale") == '/bin/locale'
    assert get_best_parsable_locale(m) == 'C.utf8'
    # default preferences, first choice
    assert get_best_parsable_locale(m, ['en_US.utf8']) == 'en_US.utf8'
    # default preferences, last choice
    assert get_best_parsable_locale(m, ['POSIX']) == 'POSIX'
    # default preferences, no choice
    assert get_best_p

# Generated at 2022-06-22 21:41:50.913421
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule()

    assert get_best_parsable_locale(module) == 'C'

    # Ensure that the test can find en_US.utf8
    module.run_command = lambda cmd: (0, '', '')
    module.run_command = lambda cmd: (0, 'en_US.utf8', '')
    assert get_best_parsable_locale(module, preferences=['en_US.utf8']) == 'en_US.utf8'

# Generated at 2022-06-22 21:41:55.732987
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    sys.path.append('../../lib')
    import ansible.module_utils
    import ansible.module_utils.basic

    module = ansible.module_utils.basic.AnsibleModule(argument_spec={})

    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-22 21:42:07.229510
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.common import AnsibleModule
    m = AnsibleModule()

    # Test default preference
    assert get_best_parsable_locale(m) == 'C'

    # If a preference is specified, it should be returned
    # even if it is not in the list of available locales
    assert get_best_parsable_locale(m, ['prefer_this']) == 'C'

    # Test the case where locale -a returns an empty list
    m._output_check = m.get_bin_path
    m.run_command = _run_command_empty_list_returned
    assert get_best_parsable_locale(m) == 'C'

    # Test the case where locale command fails
    m.run_command = _run_command_command_fails


# Generated at 2022-06-22 21:42:15.593673
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    import textwrap
    from ansible.module_utils.shell import AnsibleModule
    # Mock the locale command to return the default locale, C.utf8
    # which should match the first locale in the preferences list
    locale_list =  '''
    C.utf8
    de_DE.utf8
    en_US.utf8
    POSIX
    '''
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
        check_invalid_arguments=False
    )
    preferences = ['C.utf8', 'de_DE.utf8', 'en_US.utf8', 'POSIX']
    module.run_command = lambda cmd, tmp: (0, locale_list, '')

# Generated at 2022-06-22 21:42:25.183697
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import os
    import shutil
    import tempfile
    import filecmp
    import platform

    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-22 21:42:28.333367
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec = dict()
    )

    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-22 21:42:38.962724
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY2
    from distutils.version import LooseVersion
    import os
    import platform
    import sys

    # of all modules, I believe this one is the smallest
    osx_platform = "Darwin"
    redhat_platform = "Linux"
    # When the platfrom is linux and its version is less than 2.6.32-573.12.1.el6
    # the output of locale -a contains the encoding after the locale.
    # But when its version is at least 2.6.32-573.12.1.el6, the output of locale -a
    # contains the encoding before the locale.
    rhel = 'Red Hat Enterprise Linux'

# Generated at 2022-06-22 21:42:46.005995
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import os

    # Fake ansible module
    class AnsibleModule:
        def get_bin_path(self, name):
            return os.path.join('/bin', name)

        def run_command(self, cmd):
            if cmd == [os.path.join('/bin', 'locale'), '-a']:
                return 0, 'C.utf8\nen_US.utf8\nPOSIX\nC\n', None
            else:
                return 1, None, 'locale command not found'

    # Case 1: locale binary not found
    mod = AnsibleModule()
    assert get_best_parsable_locale(mod) == 'C'

    # Case 2: Best locale
    mod = AnsibleModule()

# Generated at 2022-06-22 21:42:55.745430
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.common.process as process
    module = process.AnsibleModule(argument_spec={}, check_invalid_arguments=False)
    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'ru_RU.utf8', 'en_US.utf8']) == 'C.utf8'
    assert get_best_parsable_locale(module, preferences=['ru_RU.utf8', 'C.utf8', 'en_US.utf8']) == 'C.utf8'

# Generated at 2022-06-22 21:42:57.044588
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None) == 'C'

# Generated at 2022-06-22 21:43:09.452993
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # we have to do this because mock is not part of the stdlib
    import ansible.module_utils.basic
    m = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    assert get_best_parsable_locale(m) == 'C'
    assert get_best_parsable_locale(m, preferences=['en_US.utf8', 'en_US.UTF-8']) == 'C'
    assert get_best_parsable_locale(m, preferences=['en_US.utf8', 'en_US.UTF-8', 'C']) == 'C'
    assert get_best_parsable_locale(m, raise_on_locale=True) == 'C'

# Generated at 2022-06-22 21:43:15.487311
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    assert get_best_parsable_locale(preferences=['C.utf8', 'en_US.utf8', 'C']) == 'C'
    assert get_best_parsable_locale(preferences=['C.utf8', 'en_US.utf8', 'C'], raise_on_locale=True) == 'C'
    assert get_best_parsable_locale(preferences=['C.utf8', 'en_US.utf8', 'C']) == 'C'

# Generated at 2022-06-22 21:43:25.767186
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils import basic
    import os
    import sys

    module = basic.AnsibleModule(
        argument_spec=dict(),
        check_invalid_arguments=False,
        bypass_checks=True
    )

    # Default locales: test default case
    os.environ['LC_ALL'] = 'C'
    assert get_best_parsable_locale(module) == 'C'

    # Preferred locale available: test case
    os.environ['LC_ALL'] = 'C'
    assert get_best_parsable_locale(module, preferences=['en_US.utf8']) == 'en_US.utf8'

    # Preferred locale not available: test case
    os.environ['LC_ALL'] = 'C'
    assert get_best_parsable

# Generated at 2022-06-22 21:43:36.675149
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    import ansible.module_utils.basic
    import os
    import sys

    # Setup test environment
    sys.path.append(os.path.dirname(__file__) + "/../../../../test/")
    test_env_path = os.path.dirname(__file__) + "/../../../../test/test_env.py"
    if os.path.exists(test_env_path):
        import test_env
        test_env.setup_test_environment()

    # Define mock locale() function

# Generated at 2022-06-22 21:43:44.556136
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class MockModule():
        def get_bin_path(self, path):
            return "/usr/bin/locale"

        def run_command(self, cmd):
            return 0, "foobar\nen_US.utf8\n", ""

    module = MockModule()
    assert (get_best_parsable_locale(module) == "en_US.utf8")



# Generated at 2022-06-22 21:43:53.778663
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = FakeAnsibleModule()
    assert get_best_parsable_locale(module) == 'C'
    assert 'locale' not in module.run_commands
    assert 'Could not find' not in module.warnings

    module = FakeAnsibleModule(locale_output='')
    assert 'locale' in module.run_commands
    assert get_best_parsable_locale(module) == 'C'
    assert 'Could not find' not in module.warnings

    module = FakeAnsibleModule(locale_output='foo\nbar\nbaz')
    assert get_best_parsable_locale(module) == 'C'
    assert 'Could not find' not in module.warnings


# Generated at 2022-06-22 21:44:00.947391
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.compat.tests.mock import patch, mock_open, MagicMock
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-22 21:44:11.162957
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    """ test_get_best_parsable_locale - Unit Tests for get_best_parsable_locale()
    """
    def get_best_parsable_locale_bare(module, preferences=None, raise_on_locale=False):
        """
            Run get_best_parsable_locale() with a fake AnsibleModule
        """
        fake_module = AnsibleModuleMock(module)
        return get_best_parsable_locale(module=fake_module,
                                        preferences=preferences,
                                        raise_on_locale=raise_on_locale)

    def test_with_stdout(preferences, stdout, expected):
        """
            Unit test a call to get_best_parsable_locale() with a given stdout
        """
       

# Generated at 2022-06-22 21:44:12.512096
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(object) == 'C'

# Generated at 2022-06-22 21:44:15.218286
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    result = get_best_parsable_locale(None)
    expected = 'C'
    assert result == expected


# Generated at 2022-06-22 21:44:19.260621
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import locale
    locale.setlocale(locale.LC_ALL, 'C')
    assert locale.getlocale()[1] == 'C'
    assert get_best_parsable_locale(AnsibleModule, raise_on_locale=True) == 'C'
    assert locale.getlocale()[1] == 'C'


# Generated at 2022-06-22 21:44:30.665020
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Fake the Ansible module
    class FakeModule(object):
        def get_bin_path(self, toolname):
            if toolname == 'locale':
                return toolname
            return None

        def run_command(self, commands):
            if commands[0] == 'locale' and commands[1] == '-a':
                return 0, 'fr_FR.UTF-8\nen_US.UTF-8\nC\nen_US.UTF-8', ''
            return -1, '', 'Error'

    class FakeModule2(object):
        def get_bin_path(self, toolname):
            if toolname == 'locale':
                return toolname
            return None


# Generated at 2022-06-22 21:44:38.588421
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.six import PY2, PY3, StringIO
    from ansible.module_utils.six.moves import shlex_quote
    from ansible.module_utils.basic import AnsibleModule

    # Test case 1: Preference list is not provided, output should be 'C'
    if PY2:
        from ansible.module_utils.basic import _AnsibleModule
    else:
        from ansible.module_utils.basic import _ansible_module_created as _AnsibleModule

    data = dict(
        params=dict(),
        check_invalid_arguments=False,
        _ansible_version=2
    )
    module = AnsibleModule(_AnsibleModule, data, supports_check_mode=False)
    assert get_best_parsable_loc

# Generated at 2022-06-22 21:44:48.317599
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import logging
    import unittest
    import sys
    import os

    # Mock ansible module required for unit testing
    mock_module = lambda: None
    mock_module.run_command = lambda x: (0, "C\nen_US.utf8\nC.UTF-8\nen_US.UTF-8", None)
    mock_module.get_bin_path = lambda x: True
    
    # Test result from run_command
    assert(get_best_parsable_locale(mock_module) == 'C')
    assert(get_best_parsable_locale(mock_module, preferences=['C']) == 'C')

# Generated at 2022-06-22 21:44:56.563462
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module_mock = AnsibleModule(argument_spec=dict())
    module_mock.run_command = test_get_best_parsable_locale_run_command
    assert get_best_parsable_locale(module_mock, ['en_US.utf8', 'C.utf8', 'en_US', 'C']) == 'en_US.utf8'
    assert get_best_parsable_locale(module_mock, ['en_US.utf8', 'C.utf8', 'en_US', 'C']) == 'en_US.utf8'


# Generated at 2022-06-22 21:45:08.310507
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.basic import AnsibleModule
    import os

    def get_best_parsable_locale(_ansible_module, preferences=None):
        return get_best_parsable_locale(_ansible_module, preferences=preferences, raise_on_locale=True)

    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=False,
    )

    # env LC_ALL=C locale -a:
    en_US_utf8_output = "POSIX\nC\nC.UTF-8\nen_US.utf8\n"
    # env LC_ALL=C locale -a:

# Generated at 2022-06-22 21:45:14.473569
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class AnsibleModule(object):
        @staticmethod
        def get_bin_path(*args):
            return '/usr/bin/locale'

        @staticmethod
        def run_command(*args):
            if args[0][1] == '-a':
                return (0, 'C.utf8\nen_US.utf8\nC\nPOSIX', None)
            else:
                return (0, '', None)

    # Testcase: available locale preference list in order of preference
    test_locale_preference = ['C.utf8', 'en_US.utf8', 'C']
    assert get_best_parsable_locale(AnsibleModule, test_locale_preference) == 'C.utf8'
    test_locale_preference.append('POSIX')
    assert get

# Generated at 2022-06-22 21:45:24.211090
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    """
    Validate the get_best_parsable_locale method.
    :return: None
    """

    assert 'C' == get_best_parsable_locale(None)
    assert 'C' == get_best_parsable_locale(None, preferences=['C'])
    assert 'C' == get_best_parsable_locale(None, preferences=['nope', 'nada', 'C'])
    assert 'C' == get_best_parsable_locale(None, preferences=['nope', 'nada', 'C.utf8'])
    assert 'C' == get_best_parsable_locale(None, preferences=['nope', 'nada', 'en_US.utf8'])
    assert 'POSIX' == get_best_parsable

# Generated at 2022-06-22 21:45:35.908363
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    """This is a unit test for get_best_parsable_locale"""
    try:
        from ansible.module_utils.basic import AnsibleModule
    except ImportError:
        # no ansible installed
        import sys
        sys.path.append('../lib')
        from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict())
    module.get_bin_path = lambda x: '/usr/bin/locale'

    module.run_command = lambda *args: (0, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test with preferred locale
    module.run_command = lambda *args: (0, 'C\nC.utf8\nPOSIX\nbogus', '')

# Generated at 2022-06-22 21:45:43.927846
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})

    # Test case 1: locale -a returns output
    locale_a_output = 'C\nen_US\nen_US.iso885915\nen_US.utf8'
    rc = 0
    err = ''
    class _module_mock:
        def get_bin_path(self, tool):
            return '/bin/locale'
        def run_command(self, args):
            return (rc, locale_a_output, err)
    module = _module_mock()
    available = []
    preferences = ['C', 'POSIX']
    assert preferences[0] == get_best_parsable_locale(module, preferences)

    # Test case 2: locale -a fails
    rc

# Generated at 2022-06-22 21:45:47.973372
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # OK
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    locale = get_best_parsable_locale(module)
    assert locale == 'C'

# Generated at 2022-06-22 21:45:53.736255
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as temp_dir:
        module = AnsibleModule({'_ansible_tmpdir': temp_dir})
        locale = get_best_parsable_locale(module, raise_on_locale=True)
        assert locale == 'C'

# Generated at 2022-06-22 21:46:03.406920
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Fail to find locale command
    module = MockModule(bin_path=False)
    assert get_best_parsable_locale(module, preferences=['_test_']) == 'C'

    # Fail to find locale command but asked to raise exception
    module = MockModule(bin_path=False)
    try:
        get_best_parsable_locale(module, preferences=['_test_'], raise_on_locale=True)
    except RuntimeWarning:
        pass
    else:
        assert False, "RuntimeWarning should be raised"

    # Fail to get any locale output
    module = MockModule(run_command=lambda x: (0, '', ''))
    assert get_best_parsable_locale(module) == 'C'

    # Fail to get any locale output and asked to raise exception

# Generated at 2022-06-22 21:46:09.452920
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Unit test for function get_best_parsable_locale
        :return: None
    '''
    from ansible.module_utils.basic import AnsibleModule

    # create a fake module reference
    module = AnsibleModule(argument_spec={})

    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'POSIX', 'C']) == 'C'


if __name__ == '__main__':
    test_get_best_parsable_locale

# Generated at 2022-06-22 21:46:10.714976
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # TODO: implement unit tests
    pass

# Generated at 2022-06-22 21:46:13.488940
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    locale = get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8'])
    assert locale == 'C'

# Generated at 2022-06-22 21:46:18.590485
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    for case in [None, 'C.UTF-8', 'C.utf8', 'POSIX']:
        assert case == get_best_parsable_locale(None, [case])
    assert 'C' == get_best_parsable_locale(None, [None, 'C.UTF-8', 'C'])
    assert 'C' == get_best_parsable_locale(None, ['C.UTF-8', 'C', None])

# Generated at 2022-06-22 21:46:23.044914
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic

    preferences = ['en_US.utf8', 'en_US.utf-8', 'C']
    found_locale = get_best_parsable_locale(ansible.module_utils.basic.AnsibleModule(argument_spec=dict()), preferences)
    print(found_locale)

# Generated at 2022-06-22 21:46:28.513674
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic  # noqa: F811; pylint: disable=unused-import

    for lang in [None, 'en_US', 'C.UTF-8', 'C.utf8', 'C']:
        assert get_best_parsable_locale(None, [lang], True) == 'C'

# Generated at 2022-06-22 21:46:37.834972
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Import lib
    from ansible.module_utils.basic import AnsibleModule
    import os
    import errno

    class FakeModule(object):
        def __init__(self):
            self.run_command = run_command
            self.get_bin_path = get_bin_path

    # Helper functions
    def run_command(command):
        # Case 1 - locale -a
        if command == [locale, '-a']:
            # Case 1 - locale -a - with output
            if rc_1 == 0:
                return rc_1, out_1, ""
            else:
                # Case 1 - locale -a - with error
                return rc_1, "", err_1
        # Case 2 - locale -a

# Generated at 2022-06-22 21:46:49.564622
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    global module, raise_on_locale
    module = dict()
    raise_on_locale = False

    # Test 1: Return C
    module['get_bin_path'] = lambda x: '/bin/locale'
    module['run_command'] = lambda x: (0, "C.utf8\nen_US.utf8\nC\nPOSIX", '')
    result = get_best_parsable_locale(module)
    assert(result == "C")

    # Test 2: Return POSIX
    module['get_bin_path'] = lambda x: '/bin/locale'
    module['run_command'] = lambda x: (0, "C.utf8\nen_US.utf8\nPOSIX\nC", '')

# Generated at 2022-06-22 21:46:52.461791
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(name='test_get_best_parsable_locale', supports_check_mode=True)
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-22 21:47:04.273005
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    class TestModule(object):
        def get_bin_path(self, bin_name):
            return "locale" if bin_name == "locale" else None

        def run_command(self, cmd):
            if '-a' in cmd:
                return 0, 'en_US.utf8\nC.utf8\nC\nPOSIX\n', None
            else:
                return 0, 'LANG=C\nLANGUAGE:\nen_US.UTF-8\n', None

    test = TestModule()

    assert get_best_parsable_locale(test, preferences=['en_US.utf8', 'C']) == 'en_US.utf8'
    assert get_best_parsable_locale(test) == 'C.utf8'
    assert get_best_p

# Generated at 2022-06-22 21:47:13.364172
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    # Set prefs to get 'en_US.UTF-8'
    prefs = ['en_US.utf8', 'en_US.UTF-8']
    module = AnsibleModule({})
    assert get_best_parsable_locale(module, preferences=prefs) == 'en_US.UTF-8'

    # Set prefs to get 'en_US.UTF-8' even if it is the first locale in the list
    prefs = ['en_US.UTF-8', 'en_US.utf8', 'C']
    module = AnsibleModule({})
    assert get_best_parsable_locale(module, preferences=prefs) == 'en_US.UTF-8'

    # Set prefs to get 'en_US.utf

# Generated at 2022-06-22 21:47:20.156759
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert isinstance(get_best_parsable_locale(None), str)
    assert isinstance(get_best_parsable_locale(None, ['test_locale']), str)

# Import module snippets
from ansible.module_utils.basic import *
main = AnsibleModule(argument_spec=dict())

if __name__ == '__main__':
    main()

# Generated at 2022-06-22 21:47:27.804441
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import mock
    from ansible.module_utils._text import to_text

    class MyModule(object):
        def get_bin_path(self, cmd, required=False):
            return '/usr/bin/locale'

        def run_command(self, cmd, check_rc=True, close_fds=True, executable=None,
                        data=None, binary_data=False, path_prefix=None, cwd=None,
                        use_unsafe_shell=False, prompt_regex=None, environ_update=None,
                        umask=None, encoding='utf-8', errors='strict', expand_user_and_vars=False):
            return 0, to_text(out), ''


# Generated at 2022-06-22 21:47:38.498828
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class FakeModule(object):

        def __init__(self):
            self._bin_paths = {}

        def get_bin_path(self, name):
            if name in self._bin_paths:
                return self._bin_paths[name]
            else:
                return None

        def run_command(self, cmd):
            if cmd[0] == 'locale' and cmd[1] == '-a':
                if self._available:
                    return 0, '\n'.join(self._available), None
                else:
                    return 1, None, "No output, %s" % (self._bin_paths)
            else:
                raise RuntimeError("Called with %s" % (cmd))

    class FakeModuleRaise(FakeModule):
        def run_command(self, cmd):
            raise

# Generated at 2022-06-22 21:47:46.303555
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale({'get_bin_path': lambda x: x},
                                    preferences=['C', 'en_US.utf8']) == 'en_US.utf8'
    assert get_best_parsable_locale({'get_bin_path': lambda x: x},
                                    preferences=['en_US.utf8', 'C']) == 'en_US.utf8'

    assert get_best_parsable_locale({'get_bin_path': lambda x: False},
                                    preferences=['en_US.utf8', 'C']) == 'C'


# Generated at 2022-06-22 21:47:55.458053
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import sys
    import syslog

    # We directly call the function, so skip the test if we cannot find it
    if (sys.version_info.major is not 2 and sys.version_info.major is not 3):
        return

    # Test for locale binary
    module = AnsibleModule(argument_spec={})
    found = get_best_parsable_locale(module)

    # Test for output from locale
    module = AnsibleModule(argument_spec={'output': {}})
    rc=0
    out='C\nC.UTF-8'
    err='no error'
    module.run_command = lambda args: (rc, out, err)
    found = get_best_parsable_locale(module)

# Generated at 2022-06-22 21:47:58.444904
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    locale = 'C.UTF-8'
    assert locale == get_best_parsable_locale(locale)


if __name__ == '__main__':
    test_get_best_parsable_locale()

# Generated at 2022-06-22 21:48:10.133812
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(),
    )

    test_preferences = ['C.utf8', 'C', 'fake_locale']
    assert get_best_parsable_locale(module, preferences=test_preferences, raise_on_locale=False) == 'C'

    test_preferences = ['ja_JP.utf8', 'fake_locale']
    assert get_best_parsable_locale(module, preferences=test_preferences, raise_on_locale=False) == 'C'

    test_preferences = ['ja_JP.utf8', 'en_US.utf8', 'C', 'POSIX']

# Generated at 2022-06-22 21:48:13.430377
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # If module is not AnsibleModule, the function will return 'C'
    locale = get_best_parsable_locale(5)
    assert locale == 'C'

    # If locale is not in PATH, the function will return 'C'
    locale = get_best_parsable_locale(None, raise_on_locale=True)
    assert locale == 'C'

# Generated at 2022-06-22 21:48:23.647821
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    class FakeModule(object):
        def get_bin_path(self, bin):
            return bin

        def run_command(self, cmd):
            # nothing
            if cmd[0] == 'locale' and cmd[1] == '-a':
                out = 'C\nC.US\nen_US\nen_US.UTF-8\n'
                return 0, out, ''
            # language only
            elif cmd[0] == 'locale' and cmd[1] == '-a':
                out = 'C\nen_US\nen_US.UTF-8\n'
                return 0, out, ''
            elif cmd[0] == 'locale':
                return 1, '', 'Not found'
            else:
                assert False, 'unexpected run_command: %s' % cmd

   

# Generated at 2022-06-22 21:48:30.834977
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    ''' test get_best_parsable_locale '''

    # test existing locale
    class MockModule:
        def get_bin_path(self, bin_name):
            if bin_name == 'locale':
                return '/usr/bin/locale'
            return (255, '', 'MockModule::get_bin_path({}) not implemented'.format(bin_name))

        def run_command(self, task_vars):
            if task_vars == ['/usr/bin/locale', '-a']:
                return (0, 'ar_AF.utf8\nen_US.utf8\noff\nC.utf8\nPOSIX\n', '')
            return (255, '', 'MockModule::run_command({}) not implemented'.format(task_vars))

    mm

# Generated at 2022-06-22 21:48:42.365012
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    preference = ['C.utf8', 'C', 'POSIX']
    example_output = """C
C.UTF-8
en_US.utf8
POSIX
"""

    assert get_best_parsable_locale(example_output, preference) == 'C.utf8'
    preference = ['en_US.utf8', 'C', 'POSIX']
    assert get_best_parsable_locale(example_output, preference) == 'en_US.utf8'
    preference = ['C.utf8', 'POSIX', 'C']
    assert get_best_parsable_locale(example_output, preference) == 'C.utf8'

    preference = ['C', 'POSIX', 'en_US.utf8']

# Generated at 2022-06-22 21:48:46.807147
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    class TestAnsibleModule(AnsibleModule):
        pass

    module = TestAnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )

    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-22 21:48:57.643035
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils import basic
    from ansible.module_utils.ansible_release import __version__ as version

    module = basic.AnsibleModule(
        argument_spec=dict(),
    )

    module.run_command = _mock_run_command
    module.get_bin_path = _mock_get_bin_path

    found_languages = {
        'C': 'default',
        'C.ASCII': 'mock_english',
        'C.UTF-8': 'mock_english',
        'POSIX': 'default'
    }

    # Check different versions of Python
    # Use Ansible version as proxy
    if version[0] == '2':
        from ansible.module_utils.unicode import get_unicode_type
        binary_type = get_unic

# Generated at 2022-06-22 21:49:05.698340
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    module = type('obj', (object,), {'run_command':
                                     lambda a, b: (0, 'C\nen_US.utf8\nen_US.utf8\nen_US.utf8', ''),
                                     'get_bin_path':
                                     lambda a: '/usr/bin/true'})

    assert get_best_parsable_locale(module, preferences) == 'C.utf8'



# Generated at 2022-06-22 21:49:12.081420
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.modules.system.setup import get_best_parsable_locale
    print("get_best_parsable_locale")

# import module snippets
from ansible.module_utils.basic import *
from ansible.module_utils.facts import *
from ansible.module_utils.urls import *
from ansible.module_utils.six import iteritems
from ansible.module_utils.six.moves import configparser

# Generated at 2022-06-22 21:49:20.892857
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    # Test to make sure function won't throw an Exception.
    # Assert that it returns 'C' when 'en_US.utf8' is not in system locales
    assert get_best_parsable_locale(module=module) == 'C'
    # This is for the case where 'locale' tool does not exist and the output cannot be parsed.
    module.run_command = lambda args: (0, '', 'No output from locale')
    assert get_best_parsable_locale(module=module) == 'C'

# Generated at 2022-06-22 21:49:27.471921
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils import basic
    from ansible.module_utils.six import StringIO

    def get_bin_path(executable):
        return executable

    def run_command(command, check_rc=True):
        if command[1] == "-a":
            return 0, StringIO('C\nen_US.utf8\nPOSIX'), ""
        else:
            return 0, "C", ""

    m = basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False,
        check_invalid_arguments=False,
        bypass_checks=True,
    )
    m.get_bin_path = get_bin_path

    m.run_command = run_command

    assert "en_US.utf8" == get_best_parsable_

# Generated at 2022-06-22 21:49:38.441607
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.basic import AnsibleModule

    # Test with locale installed
    # locale -a output looks like
    locale_a_output = """
C
C.UTF-8
en_US.utf8
posix
"""

    # Test with locale not installed
    # locale -a output looks like
    no_locale_output = """
/bin/sh: locale: command not found
"""

    # Test with corrupt output
    # locale -a output looks like
    corrupt_output = """
C
C.UTF-8
en_US.utf8
posix
AAA
"""

    module = AnsibleModule()

    # test locale installed
    locale = module.get_bin_path('locale')

# Generated at 2022-06-22 21:49:45.344192
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = ansible_module_mock()

    expected_locale = 'C.utf8'
    preferences = ['C.utf8']

    module.run_command.return_value = (0, 'C.utf8', '')
    locale = get_best_parsable_locale(module, preferences)
    assert locale == expected_locale

    module.run_command.return_value = (1, '', '')
    preferences = ['C.utf8']
    module.get_bin_path.side_effect = RuntimeError('not found')
    expected_locale = 'C'
    locale = get_best_parsable_locale(module, preferences, True)
    assert locale == expected_locale



# Generated at 2022-06-22 21:49:50.422083
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Tests for the get_best_parsable_locale function, which attempts to return the
        best possible locale for parsing output in English.
    '''
    from ansible.module_utils.basic import AnsibleModule

    test_module = AnsibleModule({})

    assert get_best_parsable_locale(test_module) == 'C'

# Generated at 2022-06-22 21:49:59.931401
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes

    am = AnsibleModule(argument_spec=dict(), supports_check_mode=True)

    # These are in no particular order, but I wanted a mix.
    preferences = ['en_US.utf8', 'en_US.UTF-8', 'C.utf8', 'POSIX', 'C']
    available = ['en_US.utf8', 'af_ZA.utf8', 'af_ZA.UTF-8', 'C.UTF-8', 'C.UTF8', 'POSIX', 'C']

    # Just get what's available
    assert get_best_parsable_locale(am, available) == 'en_US.utf8'

    # Get what's in the list and available

# Generated at 2022-06-22 21:50:05.124675
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.modules.system.locale as locale
    module = locale.AnsibleModule
    module.get_bin_path = lambda x: 'locale'
    module.run_command = lambda x: (1, "", "")
    assert get_best_parsable_locale(module) == 'C'
    module.run_command = lambda x: (0, "C\nen_US.utf8\nde_DE.utf8\n", "")
    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, preferences=['de_DE.utf8', 'en_US.utf8']) == 'de_DE.utf8'

# Generated at 2022-06-22 21:50:16.296638
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common._collections_compat import Mapping

    class FakeModule(AnsibleModule):

        def __init__(self):
            self.params = {}
            self.params['locale'] = None
            self.params['warn'] = False
            self.params['changeme'] = 'not changed'
            self.result = dict(foo='bar')

        def fail_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs
            self._failed = True

        def exit_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs
            self._changed = True

       

# Generated at 2022-06-22 21:50:24.586874
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Test for get_best_parsable_locale
    '''
    from ansible.module_utils.basic import AnsibleModule

    mod = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    assert get_best_parsable_locale(mod, preferences, raise_on_locale=True) == 'C'

# Generated at 2022-06-22 21:50:31.223891
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    m = AnsibleModule(argument_spec={}, supports_check_mode=True)

    # no preferences
    found = get_best_parsable_locale(m)
    assert found in ['C', 'POSIX'], found

    # preferences
    found = get_best_parsable_locale(m, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX'])
    assert found in ['C', 'POSIX'], found

# Generated at 2022-06-22 21:50:43.085279
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    m = AnsibleModule(argument_spec={})

    # dummy up the module to test function
    m.get_bin_path = lambda x: 'locale'

    m.run_command = lambda args, binary_data=False: (0, 'C\nen_US.utf8\nPOSIX', '')

    locale = get_best_parsable_locale(m)
    assert locale == 'C'

    locale = get_best_parsable_locale(m, ['POSIX', 'C', 'C.utf8'])
    assert locale == 'POSIX'

    locale = get_best_parsable_locale(m, ['en_CA.utf8', 'C.utf8', 'en_US.utf8'])
    assert locale

# Generated at 2022-06-22 21:50:52.016242
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = MagicMock()

    # Test with no locale
    module.get_bin_path.return_value = None
    assert get_best_parsable_locale(module) == 'C'

    # Test with missing locale
    module.get_bin_path.return_value = '/usr/bin/locale'
    module.run_command.return_value = (1, '', 'error')
    assert get_best_parsable_locale(module) == 'C'

    # Test with empty locale
    module.run_command.return_value = (0, '', '')
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-22 21:51:00.126604
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import tempfile
    import os
    import shutil
    from ansible.utils.path import unfrackpath
    from ansible.module_utils.pycompat24 import get_exception

    locale_cmd = '#!/bin/sh\necho a b c d e f g h i j k l\necho a_b_c_d_e_f_g_h_i_j_k_l'
    os.environ['LANG'] = 'C.UTF-8'
    os.environ['LC_ALL'] = 'C.UTF-8'
    os.environ['LANGUAGE'] = 'C.UTF-8'
    os.environ['LC_MESSAGES'] = 'C.UTF-8'
    module = Ansible