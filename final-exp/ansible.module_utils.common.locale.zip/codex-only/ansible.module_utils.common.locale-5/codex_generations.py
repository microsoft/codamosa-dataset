

# Generated at 2022-06-22 21:41:05.621623
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import ansible.module_utils.basic
    AM = AnsibleModule(argument_spec={})

    def run_command(args, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False, path_prefix=None, cwd=None,
                    use_unsafe_shell=False, prompt_regex=None, environ_update=None, umask=None, encoding=None, errors=None,
                    create_empty_tmpdir=False, remove_tmpdir=True, log_filename=None, stdin=None):
        return 0, '', ''

    AM.run_command = run_command

    assert get_best_parsable_locale(AM) == 'C'

# Generated at 2022-06-22 21:41:14.498469
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Run the get_best_parsable_locale function with some test data.
        Verify the output of the function.
        :returns: Nothing
    '''

    class TestModule(object):
        def __init__(self, locale_output):
            self.locale_output = locale_output

        def get_bin_path(self, tool):
            if tool == 'locale':
                return True

        def run_command(self, cmd):
            if cmd == [True, '-a']:
                return 0, self.locale_output, None
            else:
                raise ValueError('Invalid command: {}'.format(cmd))

    # Test one:
    # Successfully find the best locale
    locale_output = 'C\nC.UTF-8\nPOSIX'

# Generated at 2022-06-22 21:41:23.546865
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # mock module
    # for function get_bin_path
    module = mock.MagicMock()
    module.get_bin_path.return_value = 'locale'
    # for function run_command
    module.run_command.return_value = (0, 'out.strip().splitlines', '')
    # for get_best_parsable_locale
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    try:
        locale = get_best_parsable_locale(module, preferences)
    except:
        pass

    # testing function get_bin_path
    module.get_bin_path.assert_called_with('locale')

    # testing function run_command

# Generated at 2022-06-22 21:41:35.442484
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic

    # Create a class with an ansible module
    class test_module:
        class _AnsibleModule:
            class _UnixModule:
                def _execute_module(self, module_name=None, module_args=None, tmp=None, task_vars=None):
                    return 0, "C\nen_UK.utf8\nen_US.utf8", ""

            def __init__(self):
                self._ansible_module_commands = self._UnixModule()

            def get_bin_path(self, app):
                return app

            def run_command(self, cmd):
                return self._ansible_module_commands._execute_module(module_args=cmd)

    tm = test_module()

    # When function gets empty list, it should return '

# Generated at 2022-06-22 21:41:41.077433
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.locales import get_best_parsable_locale
    for klass in (AnsibleModule, ):
        with klass.mock():
            assert get_best_parsable_locale(klass) == 'C'



# Generated at 2022-06-22 21:41:48.880770
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    import platform

    from ansible.module_utils.six import PY3
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.pycompat24 import get_exception

    if PY3:
        import io
        import locale

        saved = sys.stdout
        sys.stdout = io.StringIO()
        try:
            locale.getlocale()
        finally:
            stdout = sys.stdout
            sys.stdout = saved

        LOCALE_C = 'C'

        # From POSIX locales
        LOCALE_POSIX = 'posix'
        # From Windows
        LOCALE_WINDOWS = 'cp1252'
        # From locale.getlocale()

# Generated at 2022-06-22 21:41:56.240400
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = None
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']

    best_locale = get_best_parsable_locale(module, preferences, raise_on_locale=False)

    assert best_locale is 'C'

    best_locale = get_best_parsable_locale(module, preferences, raise_on_locale=True)

    assert best_locale is 'C'


# vi: ts=4 expandtab

# Generated at 2022-06-22 21:42:07.571570
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import mock
    from ansible.module_utils.basic import AnsibleModule

    preferences = None
    raise_on_locale = False

    # Test 1: locale tool not found
    module = AnsibleModule(argument_spec={})
    module.get_bin_path = mock.Mock(return_value=None)
    actual_result = get_best_parsable_locale(module, preferences, raise_on_locale)
    assert actual_result == 'C'

    # Test 2: locale tool found, output has POSIX, so POSIX is selected
    module = AnsibleModule(argument_spec={})
    module.get_bin_path = mock.Mock(return_value='/usr/bin/locale')

# Generated at 2022-06-22 21:42:17.046637
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, ['C.utf8']) == 'C.utf8'
    assert get_best_parsable_locale(module, ['FOO']) == 'C'
    assert get_best_parsable_locale(module, ['FOO', 'BAR', 'C.utf8']) == 'C.utf8'
    assert get_best_parsable_locale(module, ['FOO', 'BAR', 'C']) == 'C'

# Generated at 2022-06-22 21:42:26.224677
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Example locale output
    locale = u'''
C
en_US.utf8
locale: Cannot set LC_CTYPE to default locale: No such file or directory
locale: Cannot set LC_ALL to default locale: No such file or directory
'''

    from ansible.module_utils.basic import AnsibleModule

    class ModuleStub:

        def get_bin_path(self, name):
            if name == "locale":
                return locale

        def run_command(self, cmd):
            if cmd[-1] == 'locale':
                return 0, locale, ''
            return -1, '', 'Command not found'

    module = ModuleStub()

    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-22 21:42:36.917652
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils import basic
    import tempfile
    import os

    os.environ['LC_ALL'] = 'C'

    def _check( raises, *args, **kwargs):
        try:
            got = get_best_parsable_locale( *args, **kwargs )
            if raises:
                raise AssertionError('unexpected success')
        except RuntimeWarning:
            if not raises:
                raise AssertionError('unexpected failure')
            return got

        return got

    # not installed, no output
    m = basic.AnsibleModule(argument_spec={})
    m.run_command = lambda x: (0, '', 'locale: command not found')
    assert _check( raises = True, module = m) == 'C'

    # locale missing, no output


# Generated at 2022-06-22 21:42:39.784959
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale({}) == 'C'
    assert get_best_parsable_locale({}, ['de-DE', 'en-US']) == 'C'

# Generated at 2022-06-22 21:42:43.601825
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # NOTE: No test cases for RuntimeWarning.  The point of the test
    #       is to assert correct behavior when the data is correct.

    # Test empty list
    preferences = []
    assert get_best_parsable_locale(None, preferences) == 'C'

    # Test non-existent locale
    assert get_best_parsable_locale(None, ['abc123']) == 'C'

    # Test for normal usage, return first preference
    preferences = ['test_locale_1', 'test_locale_2', 'test_locale_3', 'test_locale_4']
    assert get_best_parsable_locale(None, preferences) == 'test_locale_1'

# Generated at 2022-06-22 21:42:51.711153
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import os
    import tempfile
    import shutil
    import subprocess
    import sys

    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest
    from ansible.module_utils.basic import AnsibleModule, get_exception

    class TestGetBestParsableLocale(unittest.TestCase):

        @classmethod
        def setUpClass(cls):
            cls.temp_dir = tempfile.mkdtemp()

        @classmethod
        def tearDownClass(cls):
            shutil.rmtree(cls.temp_dir)

        def setUp(self):
            self.old_path = os.environ['PATH']

# Generated at 2022-06-22 21:42:55.174305
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule()

    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-22 21:42:57.491204
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({})
    assert get_best_parsable_locale(module)

# Generated at 2022-06-22 21:43:09.641291
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    module = AnsibleModule(argument_spec={})

    prefs = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']

    if PY3:
        locale = module.get_bin_path("locale")
        rc, out, err = module.run_command([locale, '-a'])
        if rc == 0:
            locales = out.strip().splitlines()
            default = get_best_parsable_locale(module, prefs)
            # if locales is not empty, make sure it is a match
            if locales:
                assert default in locales
            # if locales is empty, make sure it is the default locale

# Generated at 2022-06-22 21:43:17.231372
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import tempfile
    import json
    import os
    from ansible.module_utils.basic import AnsibleModule

    # Test: Returns 'C' locale when no locale bin available
    with tempfile.TemporaryDirectory() as tmpdir:
        os.mkdir(os.path.join(tmpdir, 'bin'))
        with open(os.path.join(tmpdir, 'ansible.cfg'), 'w') as f:
            f.write("[defaults]\n")
            f.write("executable = %s/bin/\n" % tmpdir)

        # get module with new bin path

# Generated at 2022-06-22 21:43:18.734968
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None) == 'C'

# Generated at 2022-06-22 21:43:28.261148
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # mock class to fake module.run_command
    class MockClass:
        # a dummy module instance
        class FakeModule:
            def __init__(self):
                pass

        # create a local locale variable
        locale = 'locale'

        def __init__(self):
            pass

        def get_bin_path(self, cmd, required=False):
            if cmd == 'locale':
                return self.locale
            else:
                return None

        def run_command(self, cmd, check_rc=False):
            if cmd[0] == 'locale':
                return (0, 'C\nen_US.utf8', None)
            else:
                return None

        def fail_json(self, **kwargs):
            self.rc = kwargs['rc']
            self.msg = kw

# Generated at 2022-06-22 21:43:38.376797
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule({})

    # Assert C defaults to C
    assert get_best_parsable_locale(module) == 'C', "C did not default to C"

    # Assert empty list defaults to C
    assert get_best_parsable_locale(module, []) == 'C', "C did not default to C"

    # Assert C.utf8 defaults to C.utf8
    assert get_best_parsable_locale(module, ['C.utf8']) == 'C.utf8', "C.utf8 did not match"

    # Assert en_US.utf8 defaults to en_US.utf8

# Generated at 2022-06-22 21:43:48.468187
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # This is a unit test runner
    # We create a mock AnsibleModule and then execute it
    # The output of this is then checked for the expected response
    import ansible.module_utils

    class MockAnsibleModule(ansible.module_utils.basic.AnsibleModule):

        def __init__(self):
            self.params = {}
            self.result = {}

        def fail_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs
            raise Exception("FAIL")

        def exit_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs

        def run_command(self, command):
            self.exit_args = command

# Generated at 2022-06-22 21:43:49.241758
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    pass

# Generated at 2022-06-22 21:43:51.356305
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    #print(get_best_parsable_locale())
    assert get_best_parsable_locale() == 'C'

# Generated at 2022-06-22 21:43:56.573186
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    found = get_best_parsable_locale(module, ['xyz', 'C.utf8', 'en_US.utf8'])
    assert found == 'C.utf8'

# Generated at 2022-06-22 21:44:03.787357
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Assume if get_best_parsable_locale is working, then no exception will be thrown
    # and function will return 'C'
    testLocale = get_best_parsable_locale(None)
    assert testLocale == 'C', "Expected 'C', but got %s" % testLocale


# Generated at 2022-06-22 21:44:14.941273
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.executor.module_common import ModuleBase

    class TestModule(ModuleBase):
        def get_bin_path(self, arg, required=False):
            if arg == 'locale':
                return arg
            return None


# Generated at 2022-06-22 21:44:18.565255
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils import basic
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.text.converters import to_bytes

    # Make sure the utf-8 chars are handled properly
    preferences = ['de_DE.utf8', 'fr_FR.utf8', 'C', 'POSIX']

    # Create module instance
    module = basic.AnsibleModule(argument_spec=dict())

    # Set available locales
    available = "C\nC.utf8\nen_US.utf8\nfr_FR.utf8\nde_DE.utf8\nPOSIX\n"
    module.run_command = lambda args, check_rc: (0, to_bytes(available), to_bytes(''))

    # Test


# Generated at 2022-06-22 21:44:28.364501
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # The get_bin_path will throw a RuntimeWarning and we will land inside the try block
    # to handle the same.
    assert get_best_parsable_locale(None) == 'C', "Unable to get the best parsable locale"
    # An undefined locale will be set to None.
    assert get_best_parsable_locale(None, None) == 'C', "Unable to get the best parsable locale"
    assert get_best_parsable_locale(None, ['a', 'b', 'c', 'd']) == 'C', "Unable to get the best parsable locale"

# Generated at 2022-06-22 21:44:34.890597
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    module.fail_json = fail_json

    # make sure any failures to find locale tool works
    try:
        get_best_parsable_locale(module, raise_on_locale=True)
    except RuntimeWarning:
        pass
    else:
        assert False, 'get_best_parsable_locale should raise exception if locale fails'

    # make sure failure to find valid locale works
    try:
        get_best_parsable_locale(module, preferences=['notreal'], raise_on_locale=True)
    except RuntimeWarning:
        pass
    else:
        assert False, 'get_best_parsable_locale should raise exception if locale fails'

    #

# Generated at 2022-06-22 21:44:47.377686
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    testcase = {
        'input': {
            'preferences': None,
            'cmd_results': [
                {
                    'rc': 0,
                    'out': 'C.utf8\nen_US.utf8\nC',
                    'err': None
                },
                {
                    'rc': 127,
                    'out': None,
                    'err': 'No such file or directory'
                },
                {
                    'rc': 0,
                    'out': 'POSIX',
                    'err': None
                }
            ]
        },
        'output': {
            'preferences': None,
            'best_locale': None
        }
    }

    module = AnsibleModule(argument_spec={})


# Generated at 2022-06-22 21:44:51.606438
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import unittest
    from ansible.module_utils.basic import AnsibleModule

    class MockAnsibleModule(AnsibleModule):

        def __init__(self, locale_list=None):
            self.locale_list = locale_list
            AnsibleModule.__init__(self, argument_spec={})

        def run_command(self, command):
            self.command = command
            return (0, '\n'.join(self.locale_list), None)

    class TestBestParsableLocale(unittest.TestCase):
        def test_default_prefs(self):
            locale_list = ['C.utf8', 'en_US.utf8', 'C']
            mod = MockAnsibleModule(locale_list)
            best = get_best_parsable_locale

# Generated at 2022-06-22 21:44:58.001263
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={}, supports_check_mode=False)
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    result = get_best_parsable_locale(module, preferences, True)
    assert result == preferences[0]

# Generated at 2022-06-22 21:45:07.802361
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    import sys
    import tempfile

    from ansible.utils.local import AnsibleModule

    # setup mock module with fake filename /etc/locale.conf
    test_en_US = '''
LANG="en_US.UTF-8"
LC_COLLATE="C"
LC_CTYPE="C.UTF-8"
'''
    locale_path = tempfile.mkstemp()
    with open(locale_path[1], 'w') as file:
        file.write(test_en_US)

    class FakeAnsibleModule(AnsibleModule):
        def __init__(self):
            self.params = {}
            self.exit_json = sys.exit
            self.fail_json = sys.exit
            self._ansible_sys_paths = []

# Generated at 2022-06-22 21:45:18.867683
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    mock_module = MagicMock()
    mock_module.get_bin_path.return_value = 'locale'
    mock_module.run_command.return_value = (0, 'af_ZA.UTF-8', '')

    assert get_best_parsable_locale(mock_module) == 'af_ZA.UTF-8'

    mock_module.reset_mock()

    mock_module.run_command.return_value = (0, 'foobar\naf_ZA.UTF-8', '')
    assert get_best_parsable_locale(mock_module) == 'af_ZA.UTF-8'

    mock_module.reset_mock()

    mock_module.run_command.return_value = (0, 'af_ZA.UTF-8', '')
   

# Generated at 2022-06-22 21:45:21.435734
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None, ['POSIX', 'C']) == 'POSIX'

# Generated at 2022-06-22 21:45:30.558937
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    import tempfile
    # a hack to get around relative imports
    if __name__ == "__main__":
        sys.path.append("../..")

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import get_exception
    from ansible.module_utils.six import PY3

    # creating a temporary file to hold the locale -a output for locale 'C' default
    # locale output for locale 'C'
    # creating a temporary file to hold the locale -a output for locale 'C.utf8'
    # locale output for locale 'C.utf8'
    # creating a temporary file to hold the locale -a output for locale 'en_US.utf8'
    # locale output for locale 'en_US.utf8'
    # creating a temporary file to

# Generated at 2022-06-22 21:45:40.664679
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Mock an AnsibleModule
    try:
        from ansible.module_utils.basic import AnsibleModule
    except ImportError:
        # Ansible 2.4
        from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Case: locale not found
    module.get_bin_path = lambda x: None
    best_locale = get_best_parsable_locale(module)
    assert best_locale == 'C'

    # Case: runs command and finds a preferred locale
    module.get_bin_path = lambda x: x
    module.run_command = lambda x: (0, 'C.utf8\nen_US.utf8\nC\nnl_NL.utf8', '')
    best_locale = get_best_p

# Generated at 2022-06-22 21:45:52.210932
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    from ansible.module_utils.common.locales import get_best_parsable_locale

    # Test gathering a list of locales from locale -a
    m = AnsibleModule(
        argument_spec={}
    )

    m.params = {}
    m.get_bin_path = lambda x: 'locale'

    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']

    m.run_command = lambda x: (0, 'C\nen_US.utf8\nen_US.utf-8\nen_US\nC.utf8\nC.UTF-8', '')

    assert get_best_parsable_locale(m, preferences) == 'C.utf8'

    m

# Generated at 2022-06-22 21:45:59.049892
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(preferences=['C.utf8', 'C', 'POSIX']) == 'C'
    assert get_best_parsable_locale(preferences=['POSIX', 'C', 'C.utf8']) == 'POSIX'
    assert get_best_parsable_locale(preferences=['C.utf8']) == 'C'
    assert get_best_parsable_locale(preferences=['C', 'POSIX']) == 'C'

# Generated at 2022-06-22 21:46:07.405111
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    import imp
    import unittest
    import tempfile
    import platform
    import os

    import ansible.module_utils.basic as basic
    basic._ANSIBLE_ARGS = imp.load_source('ansible.module_utils.basic', 'lib/ansible/module_utils/basic.py').AnsibleModuleArgs()
    basic._ANSIBLE_ARGS.no_log = True
    basic.HAS_PYTHON26 = True
    basic.SYSTEM_ENCODING = sys.getfilesystemencoding()

    # Mock module class
    class TestModule(object):
        def __init__(self, bin_path, args, rc, out, err):
            self.bin_path = bin_path
            self.args = args
            self.rc = rc
            self.out = out

# Generated at 2022-06-22 21:46:18.143950
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.common.text.converters import to_bytes, to_text
    import locale

    TEST_PREFERENCES = [locale.getpreferredencoding(), 'C']

    # This file is encoded in UTF-8
    TEST_FILE = b'f\xc3\xb6\xc3\xb6.txt'
    TEST_FILE_TEXT = to_text(TEST_FILE, errors='surrogate_or_strict')

    # It is decoded to 'f\xf6\xf6.txt' in Python 3 and 'f??.txt' in Python 2
    # The locale encoding is determined by the system locale
    if TEST_FILE_TEXT == u'f??.txt':
        # Mac OS X users have a UTF-8 locale and do not run into problems
        TEST_OUTPUT

# Generated at 2022-06-22 21:46:26.776102
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import os

    for test_locale in ('C', 'de_DE', 'de_DE.UTF-8'):
        os.environ['LC_ALL'] = test_locale
        assert get_best_parsable_locale(AnsibleModule()) == 'C'

    for test_locale in ('C.UTF-8', 'en_US.UTF-8'):
        os.environ['LC_ALL'] = test_locale
        assert get_best_parsable_locale(AnsibleModule()) == test_locale

    os.environ['LC_ALL'] = 'en_US.UTF-8'

# Generated at 2022-06-22 21:46:28.758322
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None, raise_on_locale=False) == 'C'

# Generated at 2022-06-22 21:46:37.962042
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Unit test for function get_best_parsable_locale.
        This test requires that a supported locale be installed.
    '''

    # Partial setup of module.  Only need module.get_bin_path and module.run_command
    # module.exists_glob is not needed for this test
    import os
    import tempfile
    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.tmpdir = tempfile.gettempdir()
            self.mutex_dir = self.tmpdir + os.sep + 'ansible-command'
            self.bin_path = 'PATH=/bin:/sbin:/usr/bin:/usr/sbin'


# Generated at 2022-06-22 21:46:49.690984
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    mod = AnsibleModule({})
    # we need to mock the module.get_bin_path("locale") call
    mod.get_bin_path = lambda x: '/bin/locale'

    # we need to mock the module.run_command("locale -a") call
    output = """C
en_US.utf8
fr_FR.utf8
C.utf8
POSIX
en_US
it_IT.utf8
es_ES.utf8
de_DE.utf8
"""


# Generated at 2022-06-22 21:46:56.679040
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']

    # 'locale -a' output - command successful, no output
    module = AnsibleModule(
        argument_spec=dict(),
    )
    rc = 0
    out = ''
    err = ''
    module.run_command = lambda cmd, data=None, check_rc=True, close_fds=True: (rc, out, err)
    assert get_best_parsable_locale(module, preferences) == 'C'

    # 'locale -a' output - command successful, with output
    module = AnsibleModule(
        argument_spec=dict(),
    )
    rc = 0

# Generated at 2022-06-22 21:46:58.943572
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None, None) == 'C'
    assert get_best_parsable_locale(None, ['it.utf8', 'es.utf8', 'en.utf8']) == 'en.utf8'
    assert get_best_parsable_locale(None, ['pt.utf8', 'br.utf8']) == 'C'

# Generated at 2022-06-22 21:47:09.988527
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    # no locale
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

    # no locale but we want to raise
    module = AnsibleModule(argument_spec={})
    try:
        get_best_parsable_locale(module, raise_on_locale=True)
        assert False, "Should have raised but did not"
    except RuntimeWarning:
        pass

    # locale returns POSIX
    module = AnsibleModule(argument_spec={})
    module.get_bin_path = lambda x: {'C.utf8': 'locale'}[x]
    module.run_command = lambda x: (0, 'C.utf8', '')
    assert get

# Generated at 2022-06-22 21:47:20.308345
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class AnsibleModule:
        def __init__(self):
            self.run_command_rc = 0
            self.run_command_stdout = []
            self.run_command_stderr = []

        def get_bin_path(self, command):
            return "/bin/locale"

        def run_command(self, command):
            return self.run_command_rc, self.run_command_stdout, self.run_command_stderr

    am = AnsibleModule()
    am.run_command_stdout = b"en_US.utf8\nC\nPOSIX\nC.utf8\n"

# Generated at 2022-06-22 21:47:27.825277
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic

    # create fake module object
    class FakeModule(object):
        def __init__(self, locale):
            self.locale = locale

        def get_bin_path(self, locale):
            return self.locale

        def run_command(self, command):
            if command[0] == 'locale' and command[1] == '-a':
                return 0, self.locale, None

    # Case 1: It should return C in case of not finding any other preferred locale
    module = FakeModule('')
    assert get_best_parsable_locale(module) == 'C'

    # Case 2: It should return C in case of an exception
    module = FakeModule('')

# Generated at 2022-06-22 21:47:38.498888
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import os

    thisfile = os.path.dirname(os.path.realpath(__file__))


# Generated at 2022-06-22 21:47:45.131274
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    module = AnsibleModule()

    assert module.get_bin_path('locale')

    assert get_best_parsable_locale(module, preferences=[], raise_on_locale=False) == 'C'

    # Test with an empty output
    # Test with not executable command
    module.run_command = lambda x, *args, **kwargs: (1, '', '')
    assert get_best_parsable_locale(module, preferences=[], raise_on_locale=True) == 'C'

    # Test with not executable command
    module.run_command = lambda x, *args, **kwargs: (2, '', '')
    assert get_best_parsable

# Generated at 2022-06-22 21:47:54.778135
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    # Test that default values work
    module = AnsibleModule(supports_check_mode=False)
    result = get_best_parsable_locale(module)
    assert result == 'C'

    # Test that module raises an exception if locale CLI fails to show any locale
    # Also test that the exception is being handled and locale value is 'C'
    module = AnsibleModule(supports_check_mode=False)
    module.run_command = lambda x, environ_update=None, check_rc=True: (1, '', 'locale: Cannot set LC_CTYPE to default locale: No such file or directory')
    result = get_best_parsable_locale(module)
    assert result == 'C'



# Generated at 2022-06-22 21:48:02.520141
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None) == 'C'
    assert get_best_parsable_locale(None, ['C.utf8', 'en_US.utf8']) == 'C'
    assert get_best_parsable_locale(None, ['C.utf8', 'en_US.utf8'], True) == 'C'
    assert get_best_parsable_locale(None, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'
    assert get_best_parsable_locale(None, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX'], raise_on_locale=True) == 'C'

# Generated at 2022-06-22 21:48:11.756418
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import unittest
    import tempfile
    import shutil
    import os
    import sys

    class TestGetBestParsableLocale(unittest.TestCase):

        def setUp(self):
            self.tempdir = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_get_best_parsable_locale(self):
            '''
            Testing locale bin not found
            '''
            self.assertRaises(RuntimeWarning, get_best_parsable_locale, self.tempdir)


        def test_get_best_parsable_locale_error_code(self):
            '''
            Testing locale bin found with error
            '''

# Generated at 2022-06-22 21:48:21.584877
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # we are going to moke a module object to pass around
    class M:
        def __init__(self, p=None, b=None, r=False):
            self.params = p
            self.bin_path = b
            self.raise_on_locale = r

        def get_bin_path(self, bin):
            return self.bin_path[bin]

        def run_command(self, bin):
            return self.bin_path[bin]

    def test_locale(m, prefs, bin_path, exp):
        for p in prefs:
            m.params = p
            if isinstance(bin_path, dict):
                m.bin_path = bin_path
            else:
                m.bin_path = {'locale': bin_path}
            a = get_best

# Generated at 2022-06-22 21:48:31.329930
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # check defaults
    best_locale = get_best_parsable_locale(None, raise_on_locale=True)
    assert best_locale == 'C'

    # check a non-existent locale, should fall back to 'C'
    best_locale = get_best_parsable_locale(None, ['en_ZZ.utf8'])
    assert best_locale == 'C'

    # check a real locale
    best_locale = get_best_parsable_locale(None, ['en_US.utf8'])
    assert best_locale == 'en_US.utf8'

    # check an unavailable locale
    best_locale = get_best_parsable_locale(None, ['en_US.utf8', 'en_ZZ.utf8'])
   

# Generated at 2022-06-22 21:48:42.615585
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    # Making sure we are on a posix system
    if sys.platform != 'win32':
        # We need to install language module
        import test.support
        test.support.import_module('ansible.module_utils.basic')
        test.support.import_module('ansible.module_utils.facts.system.locale')
        import unittest
        from ansible.module_utils.facts.system.locale import get_best_parsable_locale
        import ansible.module_utils.basic
        module = ansible.module_utils.basic.AnsibleModule(
            argument_spec=dict(),
        )
        # We are testing if we get the default from the function
        result = get_best_parsable_locale(module, preferences=None)

# Generated at 2022-06-22 21:48:43.653428
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # TODO
    pass

# Generated at 2022-06-22 21:48:51.488920
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Test for the base case. We expect a successful return of 'C.utf8'.
    class TestModule(object):
        def run_command(self, cmd):
            return 0, 'C.utf8', None
        def get_bin_path(self, cmd_name):
            return cmd_name
    assert get_best_parsable_locale(TestModule()) == 'C.utf8'

    # Test for the base case. We expect a successful return of 'C'.
    class TestModule2(object):
        def run_command(self, cmd):
            return 0, 'C', None
        def get_bin_path(self, cmd_name):
            return cmd_name
    assert get_best_parsable_locale(TestModule2()) == 'C'

    # Test for the success with a custom preference 'en

# Generated at 2022-06-22 21:49:03.148071
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        from ansible.module_utils.basic import AnsibleModule
    except:
        from ansible.module_utils.basic import *


# Generated at 2022-06-22 21:49:14.312557
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    import ansible.module_utils.basic
    from ansible.module_utils.common._collections_compat import Mapping
    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict(
            test_key=dict(required=True, type='str')
        ),
        supports_check_mode=True
    )

    # Test get_best_parsable_locale
    assert get_best_parsable_locale(module) == 'C'

    # Test get_best_parsable_locale with no locales available

# Generated at 2022-06-22 21:49:23.476940
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    import os
    from ansible.module_utils.basic import AnsibleModule
    sys.modules['ansible.module_utils.basic'] = AnsibleModule

    # Set to a list of locales for which test should pass

# Generated at 2022-06-22 21:49:31.353712
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = AnsibleModule(argument_spec={})
    module.fail_json = Mock(return_value=dict())
    module.run_command = Mock(return_value=(0, "", ""))
    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-22 21:49:41.908027
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils._text import to_bytes
    import sys
    import os
    import re

    mock_module = type('Module',(object,),{"run_command":run_command})
    mock_module.fail_json = lambda **kwargs: sys.exit(1)
    mock_module.get_bin_path = lambda cmd, required: "mock_get_bin_path"

    # Case 1: Get default, 'C', locale
    rc, out, err = (0, '', '')
    mock_module.run_command = lambda cmd: (rc, out, err)
    locale = get_best_parsable_locale(mock_module, raise_on_locale=False)
    assert locale == 'C'

    # Case 2: Get best parsable locale, 'en_US.

# Generated at 2022-06-22 21:49:52.983554
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    '''

        Tests that if the locale tool can't be found get_best_parsable_locale raises
        an exception as expected

    '''

    from ansible.module_utils.basic import AnsibleModule

    # Testing that when the locale tool is missing we get the expected exception
    module = AnsibleModule({})
    try:
        best_locale = get_best_parsable_locale(module)
    except RuntimeWarning:
        assert True
    else:
        assert False

    # Testing that if we have no locaes available then get_best_parsable_locale
    # returns the expected value
    module = AnsibleModule({})
    module.get_bin_path = lambda x: '/usr/bin/locale'
    module.run_command = lambda x: (0, '', '')
   

# Generated at 2022-06-22 21:50:01.402485
# Unit test for function get_best_parsable_locale

# Generated at 2022-06-22 21:50:04.271109
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # check if get_bin_path fail
    try:
        # check the parameters
        assert get_best_parsable_locale(locale=None)
    except RuntimeWarning:
        pass

# Generated at 2022-06-22 21:50:15.689657
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Unit Test for function get_best_parsable_locale

        :param module: an AnsibleModule instance
        :param preferences: A list of preferred locales, in order of preference
        :param raise_on_locale: boolean that determines if we raise exception or not
                                due to locale CLI issues
        :returns: The first matched preferred locale or 'C' which is the default
    '''

    from ansible.module_utils.basic import AnsibleModule

    preference_list = ['C.utf8', 'en_US.utf8', 'C', 'POSIX', 'fr_CA.utf8']

    # Test for case where a list of preferences is provided
    module = AnsibleModule(argument_spec=dict())
    result = get_best_parsable_locale(module, preference_list)

# Generated at 2022-06-22 21:50:26.786786
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    class FakeModule:

        class FakeRun:

            def __init__(self, rc, out, err):
                self.rc = rc
                self.stdout = out
                self.stderr = err

            def communicate(self):
                return self.stdout, self.stderr

        class FakePopen:

            def __init__(self, run):
                self.run = run

            def wait(self):
                return self.run

        def __init__(self, locale_path, locale_rc_out_err, runcwd=None, locale_preferences=None, raise_on_locale=False):
            self.locale_path = locale_path
            self.locale_rc_out_err = locale_rc_out_err
            self.runcwd = runcwd

# Generated at 2022-06-22 21:50:35.621402
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    import subprocess

    class Module:

        def __init__(self):
            self.run_command = self

        def __call__(self, commands):
            return (0, subprocess.check_output(commands).decode(sys.stdout.encoding), "")

        def get_bin_path(self, name):
            return name

    module = Module()

    assert get_best_parsable_locale(module) == 'C'
    # fail due to missing tool
    module.get_bin_path = lambda name: None
    try:
        get_best_parsable_locale(module)
        assert False, "Expected RuntimeWarning"
    except RuntimeWarning:
        pass

    # fail due to not having available locales

# Generated at 2022-06-22 21:50:46.383338
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    if sys.version_info[0] == 2:
        from future_builtins import zip

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import env_fallback

    # Mocking module
    m = AnsibleModule(
        argument_spec={},
        supports_check_mode=False,
        bypass_checks=False,
        no_log=True
    )

    # Mocking locale command
    m.run_command = lambda x: (0, 'C', '')

    assert get_best_parsable_locale(m, preferences=None, raise_on_locale=True) == 'C'


# Generated at 2022-06-22 21:50:55.020808
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    """Test get_best_parsable_locale function"""
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.basic import AnsibleModule

    class TestModule(object):
        def __init__(self):
            self.params = {}

        def fail_json(self, **kwargs):
            pass

        def run_command(self, cmd, check_rc=True):
            if cmd[1] == '-a':
                return 0, to_bytes('C.utf8\nen_US.utf8'), ''
            return 0, '', ''

        def get_bin_path(self, cmd):
            return '/bin/locale'

    test_module = TestModule()
