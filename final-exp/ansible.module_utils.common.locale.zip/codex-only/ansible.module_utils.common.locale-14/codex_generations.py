

# Generated at 2022-06-22 21:41:00.883210
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = AnsibleModule(argument_spec={'a': dict()})
    # We are always going to fail so we can always force ourselves to get a result
    # Even if we have to just say "C"
    assert module.get_best_parsable_locale(preferences=["C"], raise_on_locale=True) == "C"

# Generated at 2022-06-22 21:41:10.369842
# Unit test for function get_best_parsable_locale

# Generated at 2022-06-22 21:41:21.562916
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    import tempfile
    import textwrap as tw
    from ansible.module_utils import basic

    # Create a temporary module for testing
    temp_module_file = tempfile.NamedTemporaryFile()
    temp_module_file_name = temp_module_file.name

# Generated at 2022-06-22 21:41:30.481013
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Import ansible.module_utils.basic and AnsibleModule not in same module
    from ansible.module_utils.basic import AnsibleModule

    # Test with locale not found
    module = AnsibleModule(
        argument_spec={}
    )
    # Test without arguments
    locale_default = get_best_parsable_locale(module)
    assert locale_default == 'C'

    # Test with preference list
    locale_default = get_best_parsable_locale(module, preferences=['de', 'ar', 'C'])
    assert locale_default == 'C'

# Generated at 2022-06-22 21:41:42.189494
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = None # TODO
    preferences_test_cases = [
        ["C", "en_US.utf8", "C.utf8"],
        ["en_US.utf8",],
        ["POSIX", "C.utf8", "C"],
        ["POSIX", "C.utf8", "C", "en_US.utf8"],
        ["POSIX", "C.utf8", "C", "en_US.utf8", "en_GB.utf8"],
        ["POSIX", "C.utf8", "C", "en_GB.utf8"],
    ]

    for pref in preferences_test_cases:
        locale = get_best_parsable_locale(module, pref)
        assert(locale in pref)

if __name__ == '__main__':
    test_get_best

# Generated at 2022-06-22 21:41:45.896903
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    result = get_best_parsable_locale(module, preferences=["POSIX.utf8", "POSIX", "en_US.utf8", "C.utf8", "C"])
    assert "POSIX" == result

# Generated at 2022-06-22 21:41:57.033149
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Using mock module (pip install mock) to simulate module.run_command, as to not
    # have to use a local/remote machine to test this function.

    class AnsibleModule(object):
        def run_command(self, command):
            if command[1] == '-a':
                if command == ['locale', '-a']:
                    return 0, "C.utf8\nen_US.utf8\nPOSIX\n", None
                else:
                    return 1, None, None
            else:
                return 0, None, None

        def get_bin_path(self, program):
            return '/usr/bin/locale'

    mod = AnsibleModule()
    # When command locale -a returns en_US.utf8

# Generated at 2022-06-22 21:42:08.362342
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    class MockModule(object):
        def get_bin_path(self, name):
            return name
        def run_command(self, name):
            if name[1] == '-a':
                return 0, '\n'.join(['en_US.utf8', 'C.UTF-8', 'C',
                                     'C.utf8', 'en_US.UTF-8', u'\u20ac_FR.utf8']), None
            elif name[0] == 'locale':
                return 0, u'\u20ac_FR.utf8', None
            else:
                return 1, None, None
    module = MockModule()
    assert 'C.utf8' == get_best_parsable_locale(module)

# Generated at 2022-06-22 21:42:19.570909
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Create simple class to act like AnsibleModule
    class AnsibleModule:
        def __init__(self, *args, **kwargs):
            pass

        def get_bin_path(self, cmd):
            return cmd

        def run_command(self, cmd):
            return_code = 0

# Generated at 2022-06-22 21:42:27.429277
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import StringIO

    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True,
    )

    # Mock AnsibleModule with default return values
    module.run_command = lambda x: (0, "C.UTF-8", None)
    assert get_best_parsable_locale(module) == "C.UTF-8"


    # Mock AnsibleModule with specific return values
    module.run_command = lambda x: (0, "C.UTF-8\\nen_US.UTF-8", None)
    assert get_best_parsable_locale(module) == "C.UTF-8"


    # Mock AnsibleModule with specific return values
    module.run_

# Generated at 2022-06-22 21:42:31.751372
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    locale_module = AnsibleModule(argument_spec={})

    locale_bin = locale_module.get_bin_path('locale')

    def mock_run_command(args):
        if args[0] == locale_bin and args[1] == '-a':
            return 0, 'C\nen_US.utf8\nen_US.ISO-8859-1\nen_US\nen_GB.utf8\nen_GB.ISO-8859-1\nen_GB\n', ''
        else:
            raise ValueError('unexpected command: ' + ' '.join(args))

    locale_module.run_command = mock_run_command

    assert get_best_parsable_locale(locale_module) == 'C'

# Generated at 2022-06-22 21:42:40.993953
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible_collections.ansible.community.tests.unit.compat.mock import create_autospec
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.basic import AnsibleModule
    import sys

    def _mock_get_bin_path(name):
        if name == 'locale':
            return '/bin/locale'
        return None


# Generated at 2022-06-22 21:42:51.215318
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts.system.base import BaseFactCollector

    class FakeModule(AnsibleModule):
        def __init__(self):
            self.params = {}
            self.module = 'fake'

        def get_bin_path(self, executable, required=False):
            return '/usr/bin/locale'


# Generated at 2022-06-22 21:42:55.076506
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    assert get_best_parsable_locale(preferences=preferences) == "C"

# Generated at 2022-06-22 21:42:57.726260
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    print(get_best_parsable_locale(module))



# Generated at 2022-06-22 21:43:01.281886
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None, ['C.utf8', 'en_US.utf8', 'C', 'POSIX'], False) == 'C'

# Generated at 2022-06-22 21:43:10.929330
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Test data
    module = FakeModule()
    module.run_command = fake_run_command
    module.get_bin_path = fake_get_bin_path

    # Test default preferences
    try:
        assert get_best_parsable_locale(module, None) == 'C.utf8'
    except RuntimeWarning:
        assert get_best_parsable_locale(module, None) == 'C'

    # Test with preferences
    assert get_best_parsable_locale(module, ['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C.utf8'


# Generated at 2022-06-22 21:43:17.926520
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # import ansible.module_utils.basic
    # get rid of wrong locale warning
    # ? best way to fix this?
    # ansible.module_utils.basic.LOOKUP_ERROR_ON_MISSING_LOOKUP_PLUGIN = False
    # import ansible.module_utils.basic
    # from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_util.facts import get_file_content
    from ansible.module_utils.facts import get_file_content
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector

    module = AnsibleModule({})

# Generated at 2022-06-22 21:43:27.016993
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = AnsibleModule(argument_spec=dict())
    module.get_bin_path = Mock(return_value='/bin/locale')
    module.run_command = Mock(return_value=(0, 'C', None))

    assert get_best_parsable_locale(module, ['C', 'POSIX']) == 'C'

    module.run_command.return_value=(0, 'C\nPOSIX', None)
    assert get_best_parsable_locale(module, ['POSIX', 'C']) == 'POSIX'

    module.run_command.return_value=(0, '', None)
    with pytest.raises(RuntimeWarning):
        get_best_parsable_locale(module)

    module.run_command.return_value=(127, '', None)

# Generated at 2022-06-22 21:43:37.596133
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import os
    import sys

    try:
        from unittest import mock
    except ImportError:
        import mock

    sys.modules['ansible'] = mock.Mock()
    sys.modules['ansible.module_utils'] = mock.Mock()
    sys.modules['ansible.module_utils.basic'] = mock.Mock()
    sys.modules['ansible.module_utils.basic.AnsibleModule'] = mock.Mock()
    sys.modules['ansible.module_utils.six'] = mock.Mock()

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-22 21:43:48.261776
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    import ansible.module_utils.facts.system.base
    class AnsibleMockModule(ansible.module_utils.basic.AnsibleModule):
        def get_bin_path(self, executable, required=True, opt_dirs=None):
            return executable

    # test with bad locale command output
    test_module = AnsibleMockModule(argument_spec={})
    test_out = test_module.run_command([])
    assert get_best_parsable_locale(test_module, ['C.utf8'], True) == 'C'

    # test with multiple locale command outputs

# Generated at 2022-06-22 21:43:57.447216
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import unittest
    import sys

    if sys.version_info >= (3, 4):
        from unittest.mock import MagicMock
    else:
        from mock import Mock as MagicMock

    class TestGetBestParsableLocale(unittest.TestCase):
        def setUp(self):
            self.mock_module = MagicMock()
            self.mock_module.run_command.return_value = (0, '', '')
            self.mock_module.get_bin_path.return_value = 'locale'
            self.preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']

        def test_get_best_parsable_locale_empty(self):
            best_locale = get_best_pars

# Generated at 2022-06-22 21:44:05.524536
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule()

    try:
        assert get_best_parsable_locale(module, preferences=['C', 'en_US.utf8'],
                                        raise_on_locale=False) == 'C'
    except Exception:
        assert False, 'Error running get_best_parsable_locale function'

# Generated at 2022-06-22 21:44:16.337717
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # test for locale not installed
    module.get_bin_path = lambda x: None
    assert get_best_parsable_locale(module) == 'C'

    # test for success case
    available_locales = 'C\nC-UTF-8\nen_US.utf8\n'
    module.get_bin_path = lambda x: './locale'
    module.run_command = lambda x: (0, available_locales, '')
    assert get_best_parsable_locale(module) == 'C-UTF-8'

    # test for case where locale is not available
    module.get_bin_path = lambda x: './locale'
    module.run

# Generated at 2022-06-22 21:44:22.350550
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # The function is not directly callable, but we can mock the module object
    class FakeModule():
        def __init__(self):
            self.params = {'locale': 'en_US.UTF-8'}

        def get_bin_path(self, arg):
            return "/usr/bin/locale"

        def run_command(self, cmd):
            assert len(cmd) == 2
            assert cmd[0] == "/usr/bin/locale"
            assert cmd[1] == "-a"
            return 0, 'en_US.UTF-8\nC.UTF-8\nC\nPOSIX\n', ''

    class FakeModuleWithMissingLocale():
        def __init__(self):
            self.params = {'locale': 'en_US.UTF-8'}


# Generated at 2022-06-22 21:44:31.634057
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic as basic
    ansible_module = basic.AnsibleModule(argument_spec={})

    # Cannot find locale command
    try:
        get_best_parsable_locale(ansible_module)
    except RuntimeWarning:
        pass
    else:
        assert False, 'Should have thrown RuntimeWarning'

    # No output from locale command
    ansible_module.get_bin_path = lambda x: 'locale'
    ansible_module.run_command = lambda x: (0, '', None)
    locale = get_best_parsable_locale(ansible_module)
    assert locale == 'C'

    # Non-zero return code from locale command
    ansible_module.run_command = lambda x: (1, '', 'Runtime error')

# Generated at 2022-06-22 21:44:36.137893
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict()
    )

    # With no preferences, we expect 'C'
    assert get_best_parsable_locale(module, raise_on_locale=True) == 'C'

    # With preferences, we expect the first match
    assert get_best_parsable_locale(module, preferences=['C', 'POSIX'], raise_on_locale=True) == 'C'

# Generated at 2022-06-22 21:44:47.566367
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.facts.system.base import get_distribution
    from ansible.module_utils._text import to_bytes

    fake_module = get_distribution()
    fake_module.run_command = lambda args, **kwargs: (0, to_bytes('C\n'), None)
    prefer_c = fake_module.get_bin_path('locale')
    prefer_c = get_best_parsable_locale(fake_module, preferences=['C', 'POSIX'], raise_on_locale=True)
    assert prefer_c == 'C'

    fake_module = get_distribution()
    fake_module.run_command = lambda args, **kwargs: (1, None, None)

# Generated at 2022-06-22 21:44:57.820927
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    import sys

    class ModuleStub(object):

        def __init__(self, locale_output, raise_excep=None):
            self.locale_output = locale_output
            self.raise_excep = raise_excep

        def get_bin_path(self, exe):
            if exe == 'locale':
                return 'locale'
            else:
                return None

        def run_command(self, cmd):
            if self.raise_excep:
                raise RuntimeWarning('raise_excep is set.')

            if cmd == ['locale', '-a']:
                return (0, self.locale_output, '')
            else:
                return (1, '', 'run_command: unknown command')

    # best locale is C.utf8

# Generated at 2022-06-22 21:45:08.959277
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # unit test for function get_best_parsable_locale
    temp_facts = dict(ansible_python_version='2.6.5',
                      ansible_pkg_mgr='yum',
                      ansible_os_family='RedHat',
                      ansible_distribution='CentOS',
                      ansible_distribution_major_version='5',
                      ansible_distribution_version='5.11')

    # create fake module object
    module = type('AnsibleModule', (object,), dict(
        fail_json=lambda self, *args, **kwargs: {'failed': True},
        run_command=lambda self, *args, **kwargs: {'rc': 0, 'stdout': 'C', 'stderr': ''}))()

    # create instance of AnsibleModule
    module = module

# Generated at 2022-06-22 21:45:17.288340
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    from inspect import isfunction

    as_module = ansible.module_utils.basic.AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = False,
    )

    # get_best_parsable_locale must exist
    assert isfunction(get_best_parsable_locale)

    # get_best_parsable_locale must return a type of str
    assert type(get_best_parsable_locale(as_module)) is str

# Generated at 2022-06-22 21:45:29.486365
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import mock

    mock_run_command = mock.Mock()

# Generated at 2022-06-22 21:45:39.922820
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.six import StringIO, text_type

    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    assert get_best_parsable_locale(module) == 'C'

    fake_locale_output = StringIO(text_type("""
C
C.utf8
C.UTF-8
C.iso885915
C.ISO8859-15
en_US.utf8
en_US.UTF-8
en_US.iso885915
en_US.ISO8859-15
en_US.US-ASCII
POSIX
""".strip()))

    module.run_command = lambda x: (0, fake_locale_output, '')

    # make sure we get the first match
    assert get

# Generated at 2022-06-22 21:45:51.604246
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    ''' unit test for get_best_parsable_locale '''
    import ansible.module_utils.basic
    module = ansible.module_utils.basic.AnsibleModule(argument_spec={})

    assert get_best_parsable_locale(module) == 'C'

    # best one is in the middle of the list
    preferences = ['fr', 'C', 'POSIX', 'en_US']
    assert get_best_parsable_locale(module, preferences=preferences) == 'C'

    # Should not raise exceptions
    preferences = ['es', 'fr', 'en_AU']
    assert get_best_parsable_locale(module, preferences=preferences) == 'C'

    # should raise exception
    module = ansible.module_utils.basic.Ansible

# Generated at 2022-06-22 21:46:01.445168
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # dummy AnsibleModule
    module = type('AnsibleModule',(object,),{})()

    # empty preferences, return "C"
    assert get_best_parsable_locale(module, []) == 'C'

    # empty locale, preference will be checked
    module.get_bin_path = lambda x:''
    assert get_best_parsable_locale(module, ['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'

    # empty locale, preference will be checked
    module.get_bin_path = lambda x:''
    assert get_best_parsable_locale(module, ['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'

    # locale returns empty list

# Generated at 2022-06-22 21:46:08.781586
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.modules.system import locale_gen
    from ansible.module_utils._text import to_bytes

    fake_cmd = dict(rc=0, out=b'C.utf8\nC\nPOSIX', err=b'')
    fake_cmd_rc1 = dict(rc=1, out=b'', err=b'some error')

    # test case: locale is present, no preferences given
    module = locale_gen.AnsibleModule(argument_spec=dict(update=dict(type='bool')))
    module.run_command = lambda *a, **kw: fake_cmd
    assert module._get_best_parsable_locale() == 'C.utf8'

    # test case: locale is present, preferences given

# Generated at 2022-06-22 21:46:18.540318
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Create a class that emulates an AnsibleModule
    class AnsibleModule:
        def __init__(self):
            self.params = {}

        def get_bin_path(self, executable, required=True):
            return executable

        def run_command(self, command, cwd=None):
            if command[0] == "locale":
                rc = 0
                out = '''C
en_US.UTF-8
en_US.UTF-8
en_US.UTF-8'''
                err = ''
            return rc, out, err

    # Create an AnsibleModule instance
    am = AnsibleModule()
    locale = get_best_parsable_locale(am)

    assert(locale == 'C')

    # Create a class that emulates an AnsibleModule

# Generated at 2022-06-22 21:46:26.880289
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={}, supports_check_mode=True)

    # A test implementation of run_command
    def test_run_command(command):
        if command[0] == "locale" and command[1] == "-a":
            if command[2] == "C":
                return 0, "en_US.utf-8\nen_US.us\nC.utf-8\nC\nC.utf8\nPOSIX", ""
            else:
                return 0, "C\nen_US.utf-8\nen_US.us\nC.utf-8\nPOSIX", ""
        else:
            return 0, "", ""

    module.run_command = test_run_command

    # These are the same

# Generated at 2022-06-22 21:46:32.888498
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.facts.system.locale import get_best_parsable_locale
    try:
        # On BSD platforms /usr/bin/locale doesn't exist by default, which
        # will lead to the test failing.
        get_best_parsable_locale(None)
    except RuntimeWarning:
        pass
    else:
        assert False, "get_best_parsable_locale should raise exception"

# Generated at 2022-06-22 21:46:42.874496
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six.moves import StringIO

    # if locale command is not found, returns C
    module = AnsibleModule(argument_spec={}, supports_check_mode=True, stdin_add_newline=False)
    assert get_best_parsable_locale(module) == 'C'

    # if user provided an empty environment, returns C
    module = AnsibleModule(argument_spec={}, supports_check_mode=True, stdin_add_newline=False)
    assert get_best_parsable_locale(module, raise_on_locale=True) == 'C'

    # if the user provided an environment with C, returns C

# Generated at 2022-06-22 21:46:49.310756
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None) == 'C'
    assert get_best_parsable_locale(None, ['not', 'available']) == 'C'
    assert get_best_parsable_locale(None, ['C']) == 'C'
    assert get_best_parsable_locale(None, ['C', 'POSIX']) == 'C'

# Generated at 2022-06-22 21:46:56.434693
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    am = AnsibleModule(argument_spec=dict())

    # Test the default case
    assert get_best_parsable_locale(am) == 'C'

    # Test an alternate, but valid, case
    am.get_bin_path = lambda x, required=True: "/usr/bin/locale"
    am.run_command = lambda x, check_rc=True: (0, "C\nen_US.utf8\n", '')

    assert get_best_parsable_locale(am, preferences=['C.utf8', 'en_US.utf8']) == 'C.utf8'

    # Test the case of an error with locale

# Generated at 2022-06-22 21:46:59.749439
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_native


    result = {}
    error = None
    out = None

    myModule = AnsibleModule(
        argument_spec={},
        supports_check_mode=True,
    )

    try:
        out = get_best_parsable_locale(myModule, None)
    except Exception as e:
        error = to_native(e)


    myModule.exit_json(changed=False, result=result, error=error, out=out)

# Generated at 2022-06-22 21:47:07.800966
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule()

    assert get_best_parsable_locale(module) == "C"
    assert get_best_parsable_locale(module, preferences=['nl_NL.utf8']) == "C"
    assert get_best_parsable_locale(module, preferences=['nl_NL.utf8', 'C']) == "C"
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'C']) == "C"
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'POSIX']) == "C"

# Generated at 2022-06-22 21:47:16.930563
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        import ansible.module_utils.basic
        import ansible.module_utils.facts.system
        from ansible.module_utils._text import to_native
    except ImportError:
        print("TODO: no unit tests for this module yet, ansible not installed")
        return False

    env = {}
    module = None

# Generated at 2022-06-22 21:47:26.445730
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Unit test for function get_best_parsable_locale
    '''

    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Test the 'C' locale
    assert ('C' == get_best_parsable_locale(module))

    assert ('C.utf8' == get_best_parsable_locale(module, ['C.utf8']))

    assert ('C.utf8' == get_best_parsable_locale(module, ['C', 'C.utf8']))

    assert ('C' == get_best_parsable_locale(module, ['C.UTF-8', 'C.UTF-7', 'C']))

# Generated at 2022-06-22 21:47:31.938308
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import ansible.module_utils.facts.system.locale

    test_module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)

    found = ansible.module_utils.facts.system.locale.get_best_parsable_locale(test_module)
    assert found == 'C'

# Generated at 2022-06-22 21:47:41.985575
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Construct a MockModule class that just returns a fake version of AnsibleModule

    # get_bin_path returns 'locale' if the parameter given is 'locale'
    def get_bin_path(self, parameter):
        if parameter == 'locale':
            return 'locale'
        else:
            return None

    # run_command returns 0 if the parameter given is 'locale'
    def run_command(self, parameters):
        if parameters[0] == 'locale':
            return 0, 'C.utf8\nen_US.utf8\nC\nPOSIX', ''
        else:
            return 1, 'error', 'error'

    # The class we construct will have get_bin_path and run_command
    # as non-class member functions
    class MockModule:
        get_bin_path = get

# Generated at 2022-06-22 21:47:53.342843
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # To test the function, fake the module
    class TestAnsibleModule(object):
        @staticmethod
        def get_bin_path(name):
            if name == "locale":
                return "/path/to/locale"
            else:
                return None

        @staticmethod
        def run_command(args):
            if args[0] == "/path/to/locale" and args[1] == "-a":
                return 0, "en_CN.utf8", ""
            else:
                return 256, "", ""

    # Mock a module object
    module = TestAnsibleModule()

    # test default preference
    result = get_best_parsable_locale(module)
    assert result == "en_CN.utf8"

    # test specified preference

# Generated at 2022-06-22 21:48:01.782829
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    import subprocess
    import tempfile
    import shutil
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.process import get_bin_path

    class MockModule(object):
        fail_json = None
        params = None
        args = None

        def __init__(self, params=None, fail_json=False):
            self.fail_json = fail_json
            self.params = params
            self.args = {}

        def get_bin_path(self, tool, local=False, required=False, opt_dirs=[]):
            return get_bin_path(self, tool, local, required, opt_dirs)


# Generated at 2022-06-22 21:48:11.487576
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    """
    Test output of get_best_parsable_locale function.
    """
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec={},
    )

    # we are testing get_best_parsable_locale without calling run_command
    # so it is required to mock it
    module.run_command = lambda *args, **kwargs: (0, "C.utf8\nen_US.utf8\nen_GB.utf8", '')

    # test default preferred locales
    assert get_best_parsable_locale(module) == "C.utf8"

    # test non-default preferred locales

# Generated at 2022-06-22 21:48:21.304701
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import random
    import unittest

    class MockModuleRun(object):
        def __init__(self, available, rc, stderr=None):
            self.available = available
            self.rc = rc
            self.stderr = stderr
            self.called = False

        def __call__(self, cmd):
            self.called = True
            nocmd = [c for c in cmd if c != 'locale' and c != '-a']
            if not nocmd:
                if self.stderr:
                    return self.rc, None, self.stderr
                else:
                    return self.rc, self.available, None



# Generated at 2022-06-22 21:48:31.188937
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Test various permutations with the mocked locale executable
    # locale -a returns a list of available locales, and locale -uC
    # sets the locale to the default ("C") locale and prints
    # information in an uncluttered format.
    LOCALE_OUTPUT = """
C.UTF-8
en_US.UTF-8
en_US.utf8
en_US
es_ES.UTF-8
es_ES.utf8
es_ES@euro
es_ES.UTF8
es_ES
klingon_Qo'noS
""".strip()
    cmd = {
        "rc": 0,
        "stderr": "",
        "stdout": LOCALE_OUTPUT,
        "cmd": ["locale", "-a"],
    }

# Generated at 2022-06-22 21:48:42.489959
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    class FakeModule(AnsibleModule):
        def __init__(self, *args, **kwargs):
            self.run_command = kwargs.pop('run_command', None)
            super(FakeModule, self).__init__(*args, **kwargs)
        def get_bin_path(self, *args, **kwargs):
            return '/bin/locale'

    def run_command(self, args, check_rc=True):
        rc = 0
        out = ''
        err = ''

        if args[0] == '/bin/locale' and args[1] == '-a':
            rc = 0

# Generated at 2022-06-22 21:48:47.854067
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    preferences = ['C.utf8', 'C', 'en_US.utf8']
    best_locale = get_best_parsable_locale(None, preferences)

    assert best_locale != preferences[0], "C.utf8 is invalid test"
    assert best_locale != preferences[2], "en_US.utf8 is invalid test"
    assert best_locale == preferences[1], "C is invalid test"

# Generated at 2022-06-22 21:48:57.729448
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={}, supports_check_mode=True)

    # first test, no preference provided
    # for this test, we will mock the results of the 'locale -a' command
    module.run_command = lambda args: (args[1] == '-a' and (0, 'C.utf8\nen_US.utf8\nC\nPOSIX', '') or (0, '', ''))

    locale = get_best_parsable_locale(module)
    assert locale == 'C.utf8'

    # second test, preference provided even if not in the list of supported locales
    # for this test, we will mock the results of the 'locale -a' command

# Generated at 2022-06-22 21:49:08.177261
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import os
    import sys
    import tempfile
    sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))
    from test.units.lib.linux.scriptlet import Modules

    preferences = ['C.utf8', 'C.UTF-8', 'C', 'POSIX']
    locals_list = ['C.utf8', 'C.UTF-8', 'C', 'POSIX']
    # This should be 'C' always
    expected_result_before = 'C'
    expected_result_after = 'C.utf8'

    temp_file = tempfile.TemporaryFile()
    os.environ['LC_ALL'] = expected_result_before
    os.environ['LC_CTYPE'] = expected_result_before
    os.en

# Generated at 2022-06-22 21:49:19.596688
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import mock
    import sys

    class MockAnsibleModule(object):
        class ExitJson(Exception):
            def __init__(self):
                self.fail_msg = "Ooops, not expected!"

        class FailJson(Exception):
            def __init__(self):
                self.fail_msg = "Ooops, not expected!"

        def  __init__(self, **kwargs):
            self.params = {}
            for arg, argval in kwargs.items():
                self.params[arg] = argval

        def fail_json(self, **kwargs):
            self.exit_args = kwargs
            raise self.FailJson()

        def exit_json(self, **kwargs):
            self.exit_args = kwargs
            raise self.ExitJson()


# Generated at 2022-06-22 21:49:26.692662
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    import ansible.module_utils.basic
    from ansible.module_utils.basic import AnsibleModule

    # create a fake module to test with
    module_class = type('MyModule', (object,), dict())
    module_class.run_command = lambda self, x: (0, 'C\nC.UTF-8\n', '')
    module_class.get_bin_path = lambda self, x: '/usr/bin/locale'
    module_class.ANSIBLE_MODULE_ARGS = dict()

    module = AnsibleModule(argument_spec=dict(), supports_check_mode=True)
    module.__class__ = module_class

    locale = get_best_parsable_locale(module, preferences=['C', 'C.UTF-8'], raise_on_locale=True)


# Generated at 2022-06-22 21:49:37.401519
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.basic import AnsibleModule

    # Test method with only 1 available locale
    def test_get_best_parsable_locale_1():
        module = AnsibleModule(argument_spec={})
        module.run_command = lambda a: (0, 'C\nen_US.utf8', '')
        assert get_best_parsable_locale(module) == 'C'

    # Test method with 2 available locales, C and en_US.utf8
    def test_get_best_parsable_locale_2():
        module = AnsibleModule(argument_spec={})
        module.run_command = lambda a: (0, 'C\nen_US.utf8', '')

# Generated at 2022-06-22 21:49:45.332377
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Test locale function
        :return:
    '''
    import sys
    import os
    import tempfile
    import shutil
    import getpass

    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.process import get_bin_path
    from ansible.modules.system.locale import get_best_parsable_locale

    from ansible_collections.ansible.community.tests.unit.compat.mock import patch

    locale = get_bin_path('locale')
    if not locale:
        pytest.skip('locale not found in PATH')

    tmpdir = tempfile.mkdtemp()


# Generated at 2022-06-22 21:49:55.278689
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    binary_locale = to_native("locale")
    binary_locale_expectation = [0, "", ""]

    fake_locale_list = ["POSIX", "C", "en_US.utf8", "C.utf8"]

    class FakeAnsibleModule():

        def get_bin_path(self, binary):
            if binary == "locale":
                return binary_locale

        def run_command(self, command):
            if command[0] == binary_locale:
                return binary_locale_expectation

    def test_get_best_locale_exception(input_locale_list):
        locale = get_best_parsable_locale(FakeAnsibleModule(), input_locale_list)
        assert locale == "C"

    # test getting a good

# Generated at 2022-06-22 21:50:03.146358
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Tests for get_best_parsable_locale
    '''
    # pylint: disable=import-error,redefined-outer-name
    from ansible.module_utils.six import PY3
    from ansible.module_utils.basic import AnsibleModule

    class MockModule(object):
        ''' mock class to mock AnsibleModule instance '''
        def __init__(self, locale_bin_path=None, locale_bin_path_list=None, locale_bin_path_output=None, locale_bin_path_output_list=None,
                     locale_bin_path_rc=None, run_command_output=None, run_command_output_list=None, run_command_rc=None):
            self.locale_bin_path = locale_bin_path

# Generated at 2022-06-22 21:50:04.486409
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    assert get_best_parsable_locale(None) == "C"

# Generated at 2022-06-22 21:50:12.710948
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class FakeModule:
        @staticmethod
        def get_bin_path(bin):
            return 'locale'

        @staticmethod
        def run_command(args):
            if args[0] == 'locale':
                if args[1] == '-a':
                    return 0, 'C.utf8\nen_US.utf8\nen_US.utf8\nC\nPOSIX', ''
            return 0, '', ''

    assert get_best_parsable_locale(FakeModule()) == 'C.utf8'

# Generated at 2022-06-22 21:50:20.807410
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class MockModule(object):

        def get_bin_path(self, name):
            return True

        def run_command(self, cmd, environ_update=None, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False, path_prefix=None, cwd=None, use_unsafe_shell=False, prompt_regex=None, environ_update_with_values=None):
            if cmd == ["locale", "-a"]:
                return 0, "C\nen_US\nen_US.utf8\nen_US.UTF-8", ""
            if cmd == ["locale", "C.utf8"]:
                return 0, "yes", ""
            else:
                return 1, "", "locale command not found"

    m_mod = MockModule

# Generated at 2022-06-22 21:50:25.135961
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import os
    import tempfile

    # No locale, no error
    m = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(m) == 'C'

    # Error is suppressed
    _, tmpfile = tempfile.mkstemp()
    os.chmod(tmpfile, 0o500)

    loccmd = [tmpfile, '-a']
    assert get_best_parsable_locale(m, raise_on_locale=True) == 'C'
    os.unlink(tmpfile)

    # Return preferred locale if found
    _, tmpfile = tempfile.mkstemp()

# Generated at 2022-06-22 21:50:31.224169
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )

    assert 'en_US.utf8' == get_best_parsable_locale(module, ['en_US.utf8'])
    assert 'C' == get_best_parsable_locale(module, ['foo', 'bar', 'C'])

# Generated at 2022-06-22 21:50:43.084851
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # This unit test requires Python 2.6 or higher
    from ansible.module_utils.six import PY2, PY3
    if PY2:
        from ansible.module_utils.basic import AnsibleModule
    elif PY3:
        from ansible.module_utils._text import to_bytes, to_text
        from ansible.module_utils.common.collections import is_sequence
        from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
            argument_spec = dict(),
            supports_check_mode = False,
            )
    preferences = None
    raise_on_locale = False
    locale = get_best_parsable_locale(module, preferences, raise_on_locale)
    assert(is_sequence(preferences))

# Generated at 2022-06-22 21:50:52.345723
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict(), supports_check_mode=True)

    # preferences to test
    pref = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']

    # Test with locale CLI is absent and when the locale CLI gives output with locale it doesn't exist
    try:
        locale = get_best_parsable_locale(module, raise_on_locale=True)
    except RuntimeWarning:
        locale = None
        assert locale is None

    # Test when the locale CLI gives output with locale it exists
    locale = get_best_parsable_locale(module, preferences=pref)
    assert locale is not None

# Generated at 2022-06-22 21:51:00.309850
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # This function depends on environment variables.
    # In order to test it, we need to do some os hacking:
    import os
    import sys
    # Patch os.environ to fake LANG=C.utf8
    os.environ = {'LANG': 'C.utf8'}

    # Mock AnsibleModule that mimics a real AnsibleModule
    class MockAnsibleModule(object):

        def __init__(self):
            self.params = {'locale': None}

        def set_params(self, *args, **kwargs):
            self.params = dict(*args, **kwargs)

        def get_bin_path(self, arg):
            return os.path.abspath(os.path.join(os.path.dirname(__file__), arg))
