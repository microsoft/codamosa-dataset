

# Generated at 2022-06-22 21:41:03.612652
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = None
    preferences = ['de_DE.utf8', 'de_DE.utf-8', 'en_US.utf8', 'en_US.utf-8']
    available = ['C.utf8', 'de_DE.utf8', 'en_US.utf8', 'POSIX', 'de_DE.UTF-8', 'en_US.UTF-8']

    result = get_best_parsable_locale(module, preferences, available, True)
    assert 'de_DE.utf8' == result

    result = get_best_parsable_locale(module, preferences, available, False)
    assert 'de_DE.utf8' == result


# Generated at 2022-06-22 21:41:11.118100
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule()

    best_locale = get_best_parsable_locale(module)
    assert best_locale == 'POSIX' or best_locale == 'C'

    try:
        best_locale = get_best_parsable_locale(module, raise_on_locale=True)
        assert False, "get_best_parsable_locale with raise_on_locale=true should raise exception when locale tool is not there"
    except RuntimeWarning:
        pass

# Generated at 2022-06-22 21:41:14.013575
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.modules.system import locale_gen

    assert 'C' == get_best_parsable_locale(locale_gen)

# Generated at 2022-06-22 21:41:15.923620
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None) != None

# Generated at 2022-06-22 21:41:24.658082
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils import locales

    # Locale raises a warning
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    module.run_command = lambda command: (1, '', '')

    assert locales.get_best_parsable_locale(module) == 'C'

    # Locale returns English
    module.run_command = lambda command: (0, 'C\nen_US\n', '')
    assert locales.get_best_parsable_locale(module) == 'C'

    # Locale returns Russian
    module.run_command = lambda command: (0, 'C\nen_US\nru_RU\n', '')
    assert locales.get_best_

# Generated at 2022-06-22 21:41:30.631919
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # TODO: Properly this unit test belongs in the test suite, not here
    module = AnsibleModule(argument_spec={})
    res = get_best_parsable_locale(module)
    assert res == 'C', "A locale should be returned"
    res = get_best_parsable_locale(module, preferences=['foo'])
    assert res == 'C', "A locale should be returned"

# Generated at 2022-06-22 21:41:42.310659
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    import shutil
    import tempfile
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common._collections_compat import Mapping

    def run_command_mock(args):
        if args == ['locale', '-a']:
            # Available locales
            return 0, 'C\nen_US\nen_US.ISO8859-1\nen_US.ISO8859-15\nen_US.utf8', ''
        elif args == ['locale', '-c', '-k', 'variant']:
            return 0, '''variant
            en_US.ISO8859-15
            ''', ''

# Generated at 2022-06-22 21:41:52.091639
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    test_module = AnsibleModule(argument_spec={})

    # Test with no exception
    preferences = ['C', 'POSIX']
    raise_on_locale = False
    assert get_best_parsable_locale(test_module, preferences, raise_on_locale) == 'C'

    # Test with exception
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    raise_on_locale = True
    assert get_best_parsable_locale(test_module, preferences, raise_on_locale) == 'C.utf8'

# Generated at 2022-06-22 21:42:00.864111
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Simulate the module, AnsibleModule
    class AnsibleModule():
        def get_bin_path(self, arg):
            return '/usr/bin/locale'

        def run_command(self, cmd):
            rc = 0
            # the output is based on macOS high sierra

# Generated at 2022-06-22 21:42:10.904365
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.common.text.converters import to_bytes, to_text

    msg = "Unable to get locale information, rc=%s: %s"
    out = to_bytes("C\nC.UTF-8\nen_US.utf8\nen_US.UTF-8\nPOSIX\n")

    import json
    import sys

    class FakeModule():
        def __init__(self):
            self.fail_json = lambda **args: sys.exit(1)

        def get_bin_path(self, name):
            return True

        def run_command(self, args):
            if args == [True, '-a']:
                return 0, out, ''

# Generated at 2022-06-22 21:42:17.448610
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    test_module = AnsibleModule({}, supports_check_mode=False)
    test_module.params = {}

    my_locale = get_best_parsable_locale(test_module, ['C.utf8', 'en_US.utf8', 'C', 'POSIX'], raise_on_locale=False)
    assert my_locale == 'C'

# Generated at 2022-06-22 21:42:18.072283
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    pass

# Generated at 2022-06-22 21:42:26.753924
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.process import get_bin_path
    from time import time
    from tempfile import NamedTemporaryFile
    import locale
    import os
    import sys

    print("Python version: %s" % sys.version_info)

    # For now, only test on Linux
    if 'linux' not in sys.platform:
        print("Skipping get_best_parsable_locale unit test on platform '%s'" % sys.platform)
        return

    # Test some basics.
    failcount = 0

# Generated at 2022-06-22 21:42:37.444438
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Test if the get_best_parsable_locale function returns the first preferred locale
    # in the list that is available

    preferences = ['en_US.utf8','en_US','C','POSIX','en_GB.utf8','C.utf8']

    # Create a mock ansible module for testing
    class AnsibleModuleMock(object):

        def __init__(self):
            self.bin_path_cache = None

        def get_bin_path(self, name):
            return 'locale'

        def run_command(self, cmd):
            if cmd == ['locale', '-a']:
                return (0, 'C\nen_US.utf8\nen_GB.utf8\nC.utf8\nen_US\nPOSIX', '')

# Generated at 2022-06-22 21:42:42.710127
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert "C" == get_best_parsable_locale(None)
    assert "en_US.utf8" == get_best_parsable_locale(None, ["en_US.utf8"])
    assert "en_US.utf8" == get_best_parsable_locale(None, ["en_US.utf8", "C"])
    assert "C" == get_best_parsable_locale(None, ["en_US.utf8", "C", "POSIX"])

# Generated at 2022-06-22 21:42:51.457486
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class FakeModule(object):

        def __init__(self, rc, out, err, locale=None):
            self._rc = rc
            self._out = out
            self._err = err
            self._locale = locale

        def get_bin_path(self, name):
            if name == 'locale' and self._locale:
                return self._locale
            return None

        def run_command(self, cmd):
            return self._rc, self._out, self._err


# Generated at 2022-06-22 21:43:00.583463
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    fake_module = MockModule()
    fake_module.run_command = lambda x: ('', '', '')
    locale = get_best_parsable_locale(fake_module, ['en_US.utf8', 'en_US'], False)
    assert locale == 'C'

    fake_module.get_bin_path.return_value = '/usr/bin'
    with patch('ansible.module_utils.common._collections_compat.TemporaryFile') as mocked_tf:
        mocked_tf.return_value.__enter__.return_value.read.return_value = b'C.utf8\nen_US.utf8\nen_US'
        locale = get_best_parsable_locale(fake_module, ['en_US.utf8', 'en_US'], False)
       

# Generated at 2022-06-22 21:43:11.736532
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Test get_best_parsable_locale
    '''

    def find_locale(preferred=None):
        ''' Simple function to test get_best_locale '''

        from ansible.module_utils.basic import AnsibleModule
        from ansible.module_utils.common.locales import get_best_parsable_locale

        module = AnsibleModule({},
                               supports_check_mode=False)

        best = get_best_parsable_locale(module, preferred)
        return best

    assert find_locale() == 'C'
    assert find_locale(preferred=['C.utf8']) == 'C.utf8'

    # test that we catch runtimeerror
    import pytest
    with pytest.raises(RuntimeError):
        assert find

# Generated at 2022-06-22 21:43:23.244506
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import tempfile
    import os
    import textwrap

    # Mock the module class, and create an instance of a module
    mock_module = type('AnsibleModule', (object,), dict(
        run_command=run_command_mock,
        get_bin_path=get_bin_path_mock,
    ))
    mod = mock_module()

    def test_locale(locale, a="C"):
        global mock_locale_command
        mock_locale_command = '''%s''' % textwrap.dedent(locale)
        return get_best_parsable_locale(mod)


# Generated at 2022-06-22 21:43:29.561712
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = None
    try:
        # By default, C locale should be returned
        assert get_best_parsable_locale(module) == 'C'
        # Preference list should be honored
        assert get_best_parsable_locale(module, preferences=['en_US', 'C']) == 'en_US'
    except Exception as e:
        print(e)
        assert False

# Generated at 2022-06-22 21:43:39.070087
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    class FakeModule:
        def __init__(self, results_of_run_command=None, bin_path=None):
            self.results_of_run_command = results_of_run_command
            self.bin_path = bin_path

        def run_command(self, cmd, environ_update=None, check_rc=False,
                        close_fds=True, executable=None, data=None, binary_data=False,
                        path_prefix=None, cwd=None, use_unsafe_shell=False,
                        prompt_regex=None):
            return self.results_of_run_command

        def get_bin_path(self, tool, required=False, opt_dirs=[]):
            return self.bin_path

    # Successfully finds one of the preferred locales

# Generated at 2022-06-22 21:43:41.945701
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None) == 'C'

# Generated at 2022-06-22 21:43:49.601824
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.basic import AnsibleModule

    # Test: test case without any best locale available
    module = AnsibleModule({})
    assert get_best_parsable_locale(module, ["abc.utf8", "def_gh.utf8"]) == 'C'

    # Test: test case with valid best locale available
    module = AnsibleModule({})
    assert get_best_parsable_locale(module, ["C.utf8", "def_gh.utf8"]) == 'C'

    # Test: test case with multiple valid best locale available
    module = AnsibleModule({})
    assert get_best_parsable_locale(module, ["abc.utf8", "C.utf8"]) == 'C.utf8'

    # Test: test case with multiple valid best locale available in completely

# Generated at 2022-06-22 21:43:58.257829
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # create a mock module class instance
    class Module(object):
        def get_bin_path(self, name):
            if name == "locale":
                return "/usr/bin/locale"
            else:
                return None

        def run_command(self, command):
            if len(command) != 2:
                raise Exception("Unexpected command: %s" % command)
            if command[0] != "/usr/bin/locale":
                raise Exception("Unexpected command: %s" % command)
            if command[1] != "-a":
                raise Exception("Unexpected command: %s" % command)

            # This is the output of my `locale -a`
            return 0, """C
en_US.utf8
POSIX
""", ""


# Generated at 2022-06-22 21:44:08.806697
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import pytest

    test_module = AnsibleModule({})
    test_module.get_bin_path = lambda *a, **kw: '/usr/bin/locale'


# Generated at 2022-06-22 21:44:14.670949
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    best_locale = get_best_parsable_locale(module)
    assert best_locale == 'C'
    try:
        import locale
        for pref in ['C.utf8', 'C']:
            assert pref in locale.getdefaultlocale()
    except ImportError:
        pass

# Generated at 2022-06-22 21:44:21.805800
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import b
    import sys

    # Base case with no preferences
    ansible_module = AnsibleModule(argument_spec=dict())
    assert get_best_parsable_locale(ansible_module) == 'C'

    # Base case with a locale preference list
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    ansible_module = AnsibleModule(argument_spec=dict())
    assert get_best_parsable_locale(ansible_module, preferences) == 'C.utf8'

    # Check for a non-existent locale
    preferences = ['foo']
    ansible_module = AnsibleModule(argument_spec=dict())
    assert get_best

# Generated at 2022-06-22 21:44:31.455046
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Create AnsibleModule instance
    class Options(object):
        def __init__(self, options):
            self.__dict__.update(self._check_type_dict(options))

        def _check_type_dict(self, input_dict):
            return dict((key, value) for key, value in input_dict.items())

    class AnsibleModule(object):
        def __init__(self, argument_spec, bypass_checks=None, no_log=None,
                     check_invalid_arguments=None, mutually_exclusive=None,
                     required_together=None, required_one_of=None,
                     add_file_common_args=None, supporting_class=None,
                     required_if=None, required_by=None):
            self.argument_spec = argument_spec
            self.params = Options

# Generated at 2022-06-22 21:44:38.669577
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import os
    import sys

    class AnsibleModuleMock():
        def __init__(self):
            global __file__
            __file__ = os.path.dirname(os.path.realpath(__file__))
            self.params = {}
            if 'ANSIBLE_MODULE_ARGS' in os.environ:
                self.params = json.loads(os.environ['ANSIBLE_MODULE_ARGS'])
            self.fail_json = self.fail_jsonp = self.exit_json = self.exit_jsonp = self.deprecate = self.deprecate_warnings = self.add_path_info = lambda *args,**kwargs: self
            self.basic = self.AnsibleModuleMockBasic()
            self.params = self.AnsibleModuleMockParams()

# Generated at 2022-06-22 21:44:48.377070
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic as basic

    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    rank = dict()
    rank[None] = 0
    rank[preferences[0]] = 1
    rank[preferences[1]] = 2
    rank[preferences[2]] = 3
    rank[preferences[3]] = 4

    for out in preferences + ['test.utf8']:
        for err in [None, '']:
            for rc in [0, 1, 2]:
                module = AnsibleModuleStub(basic)
                module.run_command = classmethod(lambda cls, executable, args: (rc, out, err))

# Generated at 2022-06-22 21:44:58.767559
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    """ Unit test for get_best_parsable_locale """
    from ansible.module_utils.basic import AnsibleModule
    import tempfile

    temp_dir = tempfile.mkdtemp()
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )

    module.tmpdir = temp_dir

    module.run_command = magic_run_command

    # If your system doesn't have any of the preferred locales, it will fallback to 'C'
    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, ['es_ES.utf8', 'en_US.utf8', 'C']) == 'en_US.utf8'
    assert get_best_pars

# Generated at 2022-06-22 21:45:09.265566
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class AnsibleModuleMock():
        def __init__(self):
            self.params = {}

        def fail_json(self, msg):
            raise Exception(msg)

        def get_bin_path(self, name, required=False):
            return '/bin/locale'

        def run_command(self, args, check_rc=False, data=None):
            if args == ['/bin/locale', '-a']:
                return (0, 'C\nC.UTF-8\nEnglish_United States.1252\n', '')
            elif args == ['/bin/locale', '-a']:
                return (0, 'C\nC.UTF-8\nEnglish_United States.1252\n', '')
            else:
                raise Exception('Unexpected args to run_command')

# Generated at 2022-06-22 21:45:14.702439
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    mock_module = AnsibleModule(argument_spec={}, supports_check_mode=True, bypass_checks=True)
    # Ran command above, output was as follows
    available = """
C
C.UTF-8
en_GB.utf8
en_US.utf8
POSIX
"""
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    locale_list = [s.strip() for s in available.splitlines()]
    locale_list = [s for s in locale_list if s != '']

    result = get_best_parsable_locale(mock_module, preferences=preferences, raise_on_locale=False)
    assert result == "en_US.utf8"


# Generated at 2022-06-22 21:45:24.240785
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.common.process import get_bin_path

    class TestModule:
        def get_bin_path(self, tool):
            import os
            return os.path.join(os.getcwd(), 'test', 'get_bin_path', tool)

        def run_command(self, cmd):
            import sys
            import os
            if cmd[0] == 'locale':
                return 0, '\n'.join(os.listdir(os.path.join(os.getcwd(), 'test', 'get_bin_path', 'locale_data'))), ''
            else:
                sys.exit(1)

    test_local_name = 'en_US.UTF-8'

# Generated at 2022-06-22 21:45:26.824696
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None, ['C.utf8', 'en_US.utf8', 'C', 'POSIX'], False) == 'C'

# Generated at 2022-06-22 21:45:33.163164
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    module = ansible.module_utils.basic.AnsibleModule(argument_spec=dict())
    import ansible.module_utils.facts.system.locale
    assert ansible.module_utils.facts.system.locale.get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-22 21:45:42.277873
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    # create an ansible module object
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # check that we are getting the user's system locale as default
    current_locale = get_best_parsable_locale(module)
    assert current_locale == module.run_command('locale')[1].strip()

    # check that we are getting the first locale in the list of preferences
    pref_list = ['C.utf8', 'en_US.utf8', 'C']
    found_locale = get_best_parsable_locale(module, pref_list)
    assert found_locale == pref_list[0]

    # check that we are getting the default locale since the pref

# Generated at 2022-06-22 21:45:53.995833
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common._collections_compat import Mapping
    import textwrap

    class Mock(object):
        def __init__(self, debug=False, params=None, diff=False, check_mode=False, no_log=False, run_command=None, get_bin_path=None):
            self.debug = debug
            self.params = params
            self.diff = diff
            self.check_mode = check_mode
            self.no_log = no_log
            self.run_command = run_command
            self.get_bin_path = get_bin_path

    class TestCase(object):
        def __init__(self, description, module, result):
            self.description = description
            self.module = module

# Generated at 2022-06-22 21:46:03.569257
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import os, shutil
    try:
        old_locale = os.environ['LC_ALL']
        del os.environ['LC_ALL']
    except KeyError:
        old_locale = None


# Generated at 2022-06-22 21:46:09.557108
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Test fake module to test get_best_parsable_locale function
    class FakeModule(object):
        def __init__(self, available):
            self.available = available

        def get_bin_path(self, bin_name):
            return bin_name

        def run_command(self, command):
            return 0, self.available, ''

    pref = ['de_DE.utf8', 'C.utf8', 'C', 'POSIX']
    avail = ['POSIX', 'C', 'en_US.utf8', 'en_US.utf8']
    fm = FakeModule(avail)
    result = get_best_parsable_locale(fm, pref)
    if result != 'POSIX':
        raise Exception('Test failed, expected POSIX, got ' + result)


# Generated at 2022-06-22 21:46:18.999624
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import os
    import tempfile
    import shutil
    import textwrap

    # Setup test environment
    tmpdir = tempfile.mkdtemp()

    # Mock up the locale command
    locdir = os.path.join(tmpdir, 'usr', 'bin')
    os.makedirs(locdir)
    locfile = open(os.path.join(locdir, 'locale'), 'w')

# Generated at 2022-06-22 21:46:27.094198
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    import syslog
    import tempfile
    import mock
    try:
        from ansible.module_utils import basic
        from ansible.module_utils.common._collections_compat import MutableMapping
    except ImportError:
        sys.path.append('lib')
        from ansible.module_utils import basic
        from ansible_collections.ansible.community.plugins.module_utils.common._collections_compat import MutableMapping

    # define a temp file to work with
    temp_file = tempfile.mkstemp()[1]

    # define a mock AnsibleModule to work with
    class TestModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs
            self.debug = []


# Generated at 2022-06-22 21:46:36.975375
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    test_module = AnsibleModule({}, {})
    test_preferences = ['A_PREF', 'A_SECOND_PREF', 'A_THIRD_PREF']

    assert get_best_parsable_locale(test_module, test_preferences) == 'C'
    assert get_best_parsable_locale(test_module) == 'C'

    # Test preferences found
    test_module.run_command = lambda x: (0, 'A_SECOND_PREF\nC\n', '')
    assert get_best_parsable_locale(test_module, test_preferences) == 'A_SECOND_PREF'
    assert get_best_parsable_locale(test_module)

# Generated at 2022-06-22 21:46:48.158931
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Monkeypatch AnsibleModule until we can refactor to not need it.
    from ansible.module_utils.basic import AnsibleModule
    get_bin_save = AnsibleModule.get_bin_path

    # Choose a non-existant path and make sure get_best_parsable_locale
    # returns C by default
    def mock_get_bin_path(name):
        if name == 'locale':
            return '/something/absurd/here'
        return get_bin_save(name)

    AnsibleModule.get_bin_path = mock_get_bin_path
    assert get_best_parsable_locale(AnsibleModule()) == 'C'

    # Make sure we return first preference if we find it

# Generated at 2022-06-22 21:46:52.019354
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    result = get_best_parsable_locale(module)
    assert result == 'C'

# Generated at 2022-06-22 21:47:04.154859
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    ''' Test the get_best_parsable_locale function '''
    from ansible.module_utils.basic import AnsibleModule
    import mock

    help_text_bad_locale = """ansible-doc -h
    Usage: /usr/bin/ansible-doc [options] module ...

    Options:
      -h, --help            show this help message and exit
      -l, --list            list available modules
      -s, --snippet         show playbook snippet for specified module(s)
      -M MODULE_PATH, --module-path=MODULE_PATH
                            ansible modules/ directory
      -v, --verbose         verbose mode (-vvv for more, -vvvv to enable
                            connection debugging)"""


# Generated at 2022-06-22 21:47:13.254644
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    import sys
    import os

    module_name = 'TestGetBestParsableLocaleAnsibleModule'
    module_path = os.path.join(os.path.dirname(__file__), 'ansible_modlib.py')

    module_args = {}
    module_args.update(ANSIBLE_MODULE_ARGS)

    try:
        my_ansible_module = ansible.module_utils.basic.AnsibleModule(
            argument_spec=module_args,
            supports_check_mode=True
        )
    except Exception as e:
        print("failed to load %s: %s" % (module_name, to_native(e)), file=sys.stderr)
        sys.exit(1)

    my_ansible_module

# Generated at 2022-06-22 21:47:21.296560
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    class FakeModule:

        def __init__(self, is_locale_command_available=True, is_locale_command_output_available=True, is_locale_command_output_invalid_utf8=False):
            self.is_locale_command_available = is_locale_command_available
            self.is_locale_command_output_available = is_locale_command_output_available
            self.is_locale_command_output_invalid_utf8 = is_locale_command_output_invalid_utf8

        def get_bin_path(self, binary_name):
            if binary_name == "locale":
                return "/usr/bin/locale" if self.is_locale_command_available else None


# Generated at 2022-06-22 21:47:23.987716
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())

    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-22 21:47:34.761294
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = object()

    def mock_run_command(args, **kwargs):
        if args[0] == 'locale':
            if args[1] == '-a':
                return 0, '\n'.join(['C', 'C.utf8', 'POSIX', 'en_GB.utf8', 'en_US.utf8']), ''
            else:
                return 0, '', ''
        else:
            return 1, '', ''
    module.run_command = mock_run_command

    def mock_get_bin_path(bin_name, **kwargs):
        if bin_name == 'locale':
            return 'locale'
        else:
            return None
    module.get_bin_path = mock_get_bin_path

    # test that we find C.utf8 first
   

# Generated at 2022-06-22 21:47:42.483814
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None, ['en_US.utf8', 'C']) == 'en_US.utf8'
    assert get_best_parsable_locale(None, ['en_US.utf8', 'C']) == 'en_US.utf8'
    assert get_best_parsable_locale(None, ['de_DE.utf8', 'C']) == 'C'
    assert get_best_parsable_locale(None, ['C']) == 'C'
    assert get_best_parsable_locale(None, ['C.utf8']) == 'C'

# Generated at 2022-06-22 21:47:53.881575
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.six import PY3
    if PY3:
        import unittest
        import sys
        import os
        import tempfile

        class TestGetBestParsableLocale(unittest.TestCase):

            def setUp(self):
                self.temp_dir = tempfile.mkdtemp()
                self.path_var = os.environ.get('PATH')
                os.environ['PATH'] = self.temp_dir
                self.test_file_contents = '''#!/bin/sh
                echo C
                echo C.utf8
                echo en_US.utf8
                echo POSIX
                '''

                self.locale_test_file = 'locale'

                if sys.platform.startswith('win'):
                    self.locale_test_

# Generated at 2022-06-22 21:48:01.014701
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict())

    try:
        result = get_best_parsable_locale(module, preferences=['en_US.utf8'])
        assert result == 'en_US.utf8'
    except RuntimeWarning:
        assert False

    result = get_best_parsable_locale(module, preferences=['zz_ZZ.utf8'], raise_on_locale=True)
    assert result == 'C'

if __name__ == '__main__':

    # Unit test the function
    test_get_best_parsable_locale()

# Generated at 2022-06-22 21:48:11.344133
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Unit test to ensure that a preferred locale is returned. This isn't a complete
        unit test as the function relies on shell commands and the systems locale
    '''
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule()

    preferred = ['C.utf8']
    assert get_best_parsable_locale(module, preferences=preferred) == 'C.utf8'

    preferred = ['en_US.utf8']
    assert get_best_parsable_locale(module, preferences=preferred) == 'en_US.utf8'

    preferred = ['en_US.utf8', 'C.utf8']
    assert get_best_parsable_locale(module, preferences=preferred) == 'en_US.utf8'

# Generated at 2022-06-22 21:48:17.114881
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.common.removed import removed_module
    import ansible.module_utils.basic

    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict(),
    )

    module.params['preferences'] = ['en_US.utf8', 'en_GB.utf8', 'C']

    locale = get_best_parsable_locale(module, module.params['preferences'])

    assert locale == 'C'  # default posix, its ascii but always there



# Generated at 2022-06-22 21:48:27.848241
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils import basic
    import os

    module = basic.AnsibleModule(argument_spec={})
    module.get_bin_path = lambda x: '/usr/bin/locale'
    module.run_command = lambda x: (0, os.linesep.join(['C', 'C.utf8']), '')
    assert get_best_parsable_locale(module) == 'C'
    module.run_command = lambda x: (0, os.linesep.join(['en_US.utf8', 'C', 'C.utf8']), '')
    assert get_best_parsable_locale(module) == 'en_US.utf8'
    module.run_command = lambda x: (1, '', '')
    assert get_best_parsable_

# Generated at 2022-06-22 21:48:33.075883
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Unit test for function get_best_parsable_locale
    # pylint: disable=global-variable-undefined, global-statement
    # pylint: disable=too-few-public-methods, too-many-instance-attributes
    # pylint: disable=protected-access, unused-argument

    from ansible.module_utils.basic import AnsibleModule

    # list of locales available on the system
    test_locales = ['C', 'da_DK.utf8', 'sr_RS.utf8', 'hr_HR.utf8', 'lv_LV.utf8', 'zh_CN.utf8']

    class MyModule(AnsibleModule):
        '''
            Fake module class
        '''

# Generated at 2022-06-22 21:48:42.698075
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    test_module = None  # can't be tested by unit test because get_bin_path is tested already
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']

    assert get_best_parsable_locale(test_module, preferences, False) == 'C.utf8'
    assert get_best_parsable_locale(test_module, [], False) == 'C'
    assert get_best_parsable_locale(test_module, ['bad_locale'], False) == 'C'
    assert get_best_parsable_locale(test_module, None, False) == 'C.utf8'

# Generated at 2022-06-22 21:48:45.437654
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule()

    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-22 21:48:57.546120
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Test cases for function get_best_parsable_locale
    Test cases:
    1. Test that no locale has been found,
    2. Test that C locale has been found,
    3. Test that user preferred locale has been found.
    '''
    import unittest
    import mock
    import ansible.module_utils.common.process
    import ansible.module_utils.common.collections

    class AnsibleModuleMock(object):
        def __new__(cls, *args, **kwargs):
            obj = ansible.module_utils.basic.AnsibleModule
            return obj(*args, **kwargs)

        @staticmethod
        def get_bin_path(s):
            return 'locale'


# Generated at 2022-06-22 21:49:02.631700
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        import ansible.module_utils.basic
    except ImportError:
        raise ImportError("Cannot load ansible module")

    m = ansible.module_utils.basic.AnsibleModule(argument_spec=dict())
    assert get_best_parsable_locale(m) == 'C'

# Generated at 2022-06-22 21:49:10.341172
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import tempfile
    from ansible.module_utils.basic import AnsibleModule

    src_dir = tempfile.mkdtemp()
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False,
    )
    # test that we return 'C' if locale not found
    module.get_bin_path = lambda _: None
    assert 'C' == get_best_parsable_locale(module)
    # test that we return 'C' if locale not available
    module.run_command = lambda _: (0, '', 'locale command found but output empty')
    assert 'C' == get_best_parsable_locale(module)
    # test that we return 'C' if locale failed

# Generated at 2022-06-22 21:49:14.067723
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    try:
        get_best_parsable_locale(module)
    except RuntimeWarning:
        pass

# Generated at 2022-06-22 21:49:22.469137
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Test get_best_parsable_locale module
    '''
    import os

    # Test case 1: module is not provided
    assert get_best_parsable_locale(None) is None

    # Test case 2: locale is not found
    assert get_best_parsable_locale(None, raise_on_locale=True)

    # Test case 3: POSIX locale is provided
    assert get_best_parsable_locale(None, preferences=['POSIX']) == 'C'

    # Test case 4: UTF-8 locale is provided
    assert get_best_parsable_locale(None, preferences=['C.utf8']) == 'C.utf8'

# Generated at 2022-06-22 21:49:29.201879
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Patching  out the import for an AnsibleModule since its not present in unit tests
    and ModuleDeprecationWarning raises the error.
    '''
    from ansible.module_utils.six.moves.mock import patch
    from ansible.compat.tests.mock import Mock
    patch_module = patch('ansible.module_utils.facts.system.locale.AnsibleModule',
                         Mock(return_value=Mock(get_bin_path=Mock(return_value='/bin/locale'))))
    patch_module.start()
    try:
        from ansible.module_utils.facts.system.locale import get_best_parsable_locale
    except ImportError:
        raise
    patch_module.stop()


# Generated at 2022-06-22 21:49:40.172489
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Unit test for function get_best_parsable_locale
    '''
    from ansible.module_utils._text import to_bytes

    class FakeModule(object):
        ''' fake module for locale finder '''
        def __init__(self):
            self.params = {}
            self.boolean = 'yes'
            self.run_command_result = (0, 'C\nC.UTF-8\nen_US.utf8', '')

        def get_bin_path(self, cmd):
            ''' fake a binary path '''
            if cmd == 'locale':
                return cmd

        def run_command(self, args):
            ''' fake a run command '''
            if args[0] == 'locale' and args[1] == '-a':
                return self

# Generated at 2022-06-22 21:49:51.937993
# Unit test for function get_best_parsable_locale

# Generated at 2022-06-22 21:50:00.722508
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # This is a fake AnsibleModule which is needed by the current implementation of the get_best_parsable_locale
    # This test only ensures that the function runs through without throwing exceptions and returns something
    class FakeAnsibleModule():
        def __init__(self):
            self.get_bin_path_mock = None
            self.run_command_mock = None

        def get_bin_path(self, cmd):
            return self.get_bin_path_mock

        def run_command(self, cmd):
            return self.run_command_mock

    # If locale command is not available, 'C' is returned
    fake_ansible_module = FakeAnsibleModule()
    fake_ansible_module.get_bin_path_mock = None
    assert get_best_parsable_loc

# Generated at 2022-06-22 21:50:03.834782
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'

# Generated at 2022-06-22 21:50:15.167085
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    test_module = FakeAnsibleModule(
        # running locale -a gives this output
        run_command_stdout='C\nC.UTF-8\nen_US.UTF-8\nPOSIX'
    )

    assert 'C.UTF-8' == get_best_parsable_locale(test_module)
    assert 'POSIX' == get_best_parsable_locale(test_module, ['POSIX'])
    assert 'C' == get_best_parsable_locale(test_module, ['en_GB.UTF-8'])
    assert 'C' == get_best_parsable_locale(test_module, ['en_GB.UTF-8'], raise_on_locale=True)

# Generated at 2022-06-22 21:50:26.337050
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        A simple unit test for the get_best_parsable_locale
        when raise_on_locale is passed in as False (default)
    '''
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts.system.locale import get_best_parsable_locale
    import sys

    # Force get_best_parsable_locale to raise Exception
    # and force it to return 'C' locale
    module = AnsibleModule(argument_spec={})
    preferences = ['C.utf8', 'ja_JP.utf8', 'C', 'POSIX']
    module.run_command = raise_exception
    sys.modules['__main__'].__file__ = __file__   # needed for 'ansible-doc'
    assert get

# Generated at 2022-06-22 21:50:35.306083
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    class MockModule(object):
        def __init__(self):
            pass

        def get_bin_path(self, *args, **kwargs):
            return "/usr/bin/locale"

        def run_command(self, *args, **kwargs):
            return 0, "C\nen_US.utf8\nen_US\n", ""

    class MockEfailModule(object):
        def __init__(self):
            pass

        def get_bin_path(self, *args, **kwargs):
            return "/usr/bin/locale"

        def run_command(self, *args, **kwargs):
            return 1, "C\nen_US.utf8\nen_US\n", "Command failed"


# Generated at 2022-06-22 21:50:46.131826
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic as module
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-22 21:50:54.945804
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.internal.locale import (get_best_parsable_locale,
                                                      to_native)
    import sys

    binary = sys.executable
