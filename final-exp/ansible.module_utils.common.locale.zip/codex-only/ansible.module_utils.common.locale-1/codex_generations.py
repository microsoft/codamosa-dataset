

# Generated at 2022-06-22 21:40:59.775160
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    result = get_best_parsable_locale(None, ['en_US.utf8', 'en_US.UTF-8'], False)
    assert result == 'C', 'test_get_best_parsable_locale: got %s, expected C' % result

# Generated at 2022-06-22 21:41:09.230530
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={}, supports_check_mode=True)

    # Test default values
    assert get_best_parsable_locale(module) == 'C'

    # Test that the first preferred locale will be returned
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C.utf8'

    # Test that the first preferred locale found in available will be returned
    assert get_best_parsable_locale(module, preferences=['es_ES.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'

    # Test default locale in available
    assert get_best_parsable

# Generated at 2022-06-22 21:41:18.230829
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())

    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, preferences=['en_US.utf8']) == 'en_US.utf8'
    assert get_best_parsable_locale(module, preferences=['brishi_BRISHI.utf8']) == 'C'

# Generated at 2022-06-22 21:41:30.084416
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.local import LocalAnsibleModule

    # This test uses some special modules to trick AnsibleModule into thinking it's
    # returning from a command line run
    module_files = {
        'ansible.module_utils.basic': AnsibleModule,
        'ansible.module_utils.local': LocalAnsibleModule,
    }
    for mod_name, mod_val in module_files.items():
        try:
            del sys.modules[mod_name]
            sys.modules[mod_name] = mod_val
        except KeyError:
            sys.modules[mod_name] = mod_val

    # We need to use these modules to mock os.path and subprocess
    import mock

# Generated at 2022-06-22 21:41:39.429572
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule()

    # The function will decide what to return if the module is not passed in
    assert get_best_parsable_locale() == 'C'
    # If the default list of locales is passed in, the function will return
    # the first locale found in the system
    assert get_best_parsable_locale(module)
    # If a locale in the given list is found in the system, the function should
    # return that
    assert get_best_parsable_locale(module, preferences=['abcd']) == 'abcd'

# Generated at 2022-06-22 21:41:50.772379
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    import shutil
    import os
    import tempfile
    import datetime
    import time
    from ansible.module_utils.six import PY2

    # Create AnsibleModule stub
    class AnsibleModuleStub():

        def __init__(self):
            self.params = {}

        def get_bin_path(self, tool):
            if tool == "locale":
                # make a temp file for testing, needs to be executable
                self.fd, self.locale_path = tempfile.mkstemp()
                os.write(self.fd, "#!/bin/sh\n")
                os.write(self.fd, "echo en_US.utf8\n")
                os.write(self.fd, "echo C.utf8\n")

# Generated at 2022-06-22 21:42:00.242739
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    import os
    import tempfile

    # Create a fake module and rewrite PATH to include the fake bin directory
    fake_module = type('fake_module', (object, ), {
        'get_bin_path': lambda s, b: os.path.join(tempfile.gettempdir(), 'bin', b),
        'run_command': lambda s, c, *a, **k: [(0, 'C\nPOSIX\nfr_FR.utf8', '')]
    })

    # Check that the correct locales are found
    assert 'POSIX' == get_best_parsable_locale(fake_module)
    assert 'C' == get_best_parsable_locale(fake_module, ['fr_FR.utf8'])
    assert 'fr_FR.utf8' == get_best_parsable_

# Generated at 2022-06-22 21:42:09.807682
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # For testing purposes we'll use the module as a dummy object
    # and build a fake class with the attributes we need
    class FakeModule():
        def __init__(self):
            self.get_bin_path_return = "/usr/bin/locale"
            self.run_command_return = (0, "C\nC.utf8\nen_US.utf8\nen_US.utf8\nPOSIX\n", "")

        def get_bin_path(self, string):
            return self.get_bin_path_return

        def run_command(self, command):
            return self.run_command_return

    fm = FakeModule()

    assert get_best_parsable_locale(fm) == 'C.utf8'


# Generated at 2022-06-22 21:42:21.072825
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class Module(object):
        def __init__(self, out, err, rc=0):
            self.out = out
            self.err = err
            self.rc = rc

        def run_command(self, cmd, *_, **__):
            return self.rc, self.out, self.err

        def get_bin_path(self, tool):
            if 'locale' in tool:
                return command
            else:
                return None

    command = '/usr/bin/locale'
    available = [
        'ar_IN',
        'ar_PS',
        'ar_SA',
        'C.utf8',
        'de_DE',
        'en_US.utf8',
        'ja_JP',
        'POSIX'
    ]
    # Test case where locale run command returns

# Generated at 2022-06-22 21:42:29.734336
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # function is hard to test as it uses AnsibleModule
    from ansible.module_utils.basic import AnsibleModule

    # When raise_on_locale is False, should return 'C' in case of error
    assert get_best_parsable_locale(AnsibleModule()) == 'C'

    # When raise_on_locale is True, should raise exception in case of error
    try:
        assert get_best_parsable_locale(AnsibleModule(), raise_on_locale=True)
    except RuntimeWarning:
        assert True
    else:
        assert False, 'Did not raise error'

# Generated at 2022-06-22 21:42:40.137778
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Import here so ansible doesn't load this as a module
    import q_module

    class FakeModule(object):
        parameters = {}
        _debug = False

        def get_bin_path(self, name):
            return "/usr/bin/locale"


# Generated at 2022-06-22 21:42:50.866969
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Function
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    module = AnsibleModule(argument_spec={})
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']

    if PY3:
        available = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
        assert get_best_parsable_locale(module, preferences=preferences) == 'C.utf8'
    else:
        available = ['en_US.utf8', 'en_US']
        assert get_best_parsable_locale(module, preferences=preferences) == 'en_US.utf8'

# Generated at 2022-06-22 21:42:59.801680
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Import required module
    import ansible.module_utils.basic as basic
    module = basic.AnsibleModule(argument_spec={})

    # Test default preference
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    assert module.get_best_parsable_locale(module, preferences) in preferences, 'Default preference should be in preferences'

    # Test empty availability
    assert module.get_best_parsable_locale(module, preferences, availability=[]) == 'C', 'Empty availability should return "C"'

    # Test empty preference
    assert module.get_best_parsable_locale(module, availability=preferences) == 'C', 'Empty preference should return "C"'

# Generated at 2022-06-22 21:43:11.336899
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Fake module return values

    # Asserts with no preferences
    assert ('C' == get_best_parsable_locale(fake_module, raise_on_locale=True))
    assert ('C' == get_best_parsable_locale(fake_module))

    # Asserts with preferences
    assert ('POSIX' == get_best_parsable_locale(fake_module, preferences=['POSIX']))
    assert ('POSIX' == get_best_parsable_locale(fake_module, preferences=['POSIX', 'BOGUS']))
    assert ('POSIX' == get_best_parsable_locale(fake_module, preferences=['BOGUS', 'POSIX']))

    # Asserts with empty available list

# Generated at 2022-06-22 21:43:17.942071
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    import unittest

    # Import module to use code under test without pylint warnings
    sys.path.append('/Library/Developer/CommandLineTools/Library/PrivateFrameworks/Python3.framework/Versions/3.7/lib/python3.7/site-packages')
    if sys.version_info[0] > 2:
        from unittest.mock import Mock, patch
    else:
        from mock import Mock, patch # pylint: disable=import-error,no-name-in-module

    # Mock out AnsibleModule class for testing get_best_parsable_locale function
    class MockAnsibleModule(object):
        '''Mock AnsibleModule class for testing get_best_parsable_locale function'''

# Generated at 2022-06-22 21:43:21.377069
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    mymodule = ansible.module_utils.basic.AnsibleModule(argument_spec={})
    assert(get_best_parsable_locale(mymodule) == 'C')

# Generated at 2022-06-22 21:43:32.970178
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.basic import AnsibleModule

    def test_run_command(self, args, check_rc=True):
        rc = 0
        out = ''
        err = ''

        if args[0] == 'locale':
            # just running locale -a
            rc = 0
            out = '''
C
en_US.utf8
POSIX
'''

        elif args[0] == 'lsb_release':
            # running lsb_release -a
            rc = 0
            out = '''
Distributor ID: Ubuntu
Description:    Ubuntu 14.04.3 LTS
Release:        14.04
Codename:       trusty
'''

        return (rc, out, err)

    module = AnsibleModule(
        argument_spec=dict(),
    )

# Generated at 2022-06-22 21:43:40.757255
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # The module class should be mocked
    module = 'mocked'

    # Test case 1: we want to find 'en', so we need to make sure that
    #              'en' is found in the availabllocales list and it's not
    #              in the locales list, making sure that the first one wins
    preferences = ['de_DE.utf8', 'en.utf8', 'C']
    available = "de_DE.utf8\nen.utf8\nC"
    locales = "de_DE.UTF-8\nen.UTF-8"
    found = 'de_DE.utf8'

    # Create a Mock for the 'run_command' function, so we can tell it what
    # to return in case of success and failure
    #
    # Note: 'run_command' is called in the function, so

# Generated at 2022-06-22 21:43:49.766216
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    import os
    import pwd
    from tempfile import NamedTemporaryFile
    from ansible.compat import json

    # Create a fake module to pass to the function
    class FakeModule(object):

        def __init__(self):
            self.params = {}
            self.version_info = []

        def get_bin_path(self, name, required=False):
            if name == 'locale':
                # Use path of the python interpreter to have a sure existent locale path
                python_path = sys.executable
                locale_path = os.path.join(os.path.dirname(python_path), 'locale')
                return locale_path
            else:
                raise RuntimeError("No binary named '%s' found" % name)


# Generated at 2022-06-22 21:43:58.369954
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    import os
    import tempfile

    template = """\
from ansible.compat.tests import mock
from ansible.compat.tests.mock import patch
from ansible.module_utils.basic import AnsibleModule
from ansible.module_utils.helpers import get_best_parsable_locale

module = AnsibleModule(argument_spec=dict())

with tempfile.NamedTemporaryFile(mode='w') as locale_fd:
    locale_fd.flush()
    locale_fd.close()
    with patch('ansible.module_utils.helpers.locale', return_value=locale_fd.name):
        with patch('ansible.module_utils.helpers.module', return_value=module):
            %s
"""

    # Test when we get a success

# Generated at 2022-06-22 21:44:08.825761
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six.moves import StringIO

    class TestModule(AnsibleModule):
        def __init__(self):
            self.exit_args = {}
            self.exit_json = None
            self.fail_json = None
            self.params = {
                '_ansible_check_mode': False,
                '_ansible_debug': False,
                '_ansible_diff': False
            }

        def exit_json(self, **kwargs):
            self.exit_args = kwargs

        def fail_json(self, **kwargs):
            self.exit_args = kwargs

        def run_command(self, cmd, cwd=None):
            out = StringIO()

# Generated at 2022-06-22 21:44:18.777401
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    """
    ansible.module_utils.system.get_best_parsable_locale_default
    functionality tests.
    """
    from ansible.module_utils.basic import AnsibleModule, get_exception
    import traceback

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )

    preferences = ['C.utf8', 'C.UTF-8', 'C.utf-8', 'en_US.utf8', 'en_US.UTF-8',
                   'en_US.utf-8', 'en_US', 'C', 'POSIX', 'test']

    # Test positive scenarios

# Generated at 2022-06-22 21:44:23.664533
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    results = get_best_parsable_locale(AnsibleModule('', {}))
    assert results == 'C'

# Generated at 2022-06-22 21:44:33.395703
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.common import AnsibleModule
    module = AnsibleModule(argument_spec=dict())

    # Test 1: No preferences
    assert 'C' == get_best_parsable_locale(module)
    # Test 2: With preferences
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    assert 'C' == get_best_parsable_locale(module, preferences)


# Generated at 2022-06-22 21:44:45.443691
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    # Create an AnsibleModule based on the module utils
    module = ansible.module_utils.basic.AnsibleModule()
    # Create a list of locales
    locale_list = ['C', 'C.utf8', 'POSIX', 'en_US.utf8', 'C.UTF-8']
    locale_list.remove('C.utf8')
    locale_list.remove('en_US.utf8')
    # Check function
    best_locale = get_best_parsable_locale(module,locale_list)
    assert best_locale == 'C'

# Generated at 2022-06-22 21:44:57.550740
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic as basic
    from ansible.module_utils.basic import AnsibleModule

    assert 'C' == get_best_parsable_locale(AnsibleModule(argument_spec={}))

    with basic.AnsibleModuleMock(argument_spec={}) as module:
        module.run_command = lambda x, check_rc=False: (0, 'C.UTF-8', '')
        assert 'C.UTF-8' == get_best_parsable_locale(module)

    with basic.AnsibleModuleMock(argument_spec={}) as module:
        module.run_command = lambda x, check_rc=False: (0, 'C.UTF-8\nen_US.UTF-8', '')
        assert 'C.UTF-8' == get_

# Generated at 2022-06-22 21:45:05.467373
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils import basic
    module = basic.AnsibleModule(argument_spec={})
    module.fail_json = fail_json
    p = [
      'C.utf8', 'en_US.utf8', 'en_US.utf8', 'C', 'POSIX',
    ]
    l = get_best_parsable_locale(module, p)
    assert l == 'C'

# Generated at 2022-06-22 21:45:14.980588
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(module=None, raise_on_locale=False) == 'C'
    assert get_best_parsable_locale(module=None, preferences=['foo'], raise_on_locale=False) == 'C'
    assert get_best_parsable_locale(module=None, preferences=['C'], raise_on_locale=False) == 'C'

# Generated at 2022-06-22 21:45:24.270163
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Import inside function due to module_utils.common.missing_required_lib
    from ansible.module_utils.basic import AnsibleModule
    import os
    import tempfile
    import shutil

    tmpdir = tempfile.mkdtemp()
    test_dir = tempfile.mkdtemp(dir=tmpdir)
    locale_dir = os.path.join(test_dir, 'locale-test')

# Generated at 2022-06-22 21:45:35.993782
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import b
    from ansible.compat.tests import unittest

    class TestException(Exception):
        pass

    class FakeModule(object):
        def __init__(self, locale_path=None, locale_rc=0,
                     locale_out=None, locale_err=b('')):
            """
            :param locale_out: A list of locales to fake out
            :type locale_out: list
            """

            self.fail_json = self.fail
            self.params = {}
            self.locale_rc = locale_rc
            self.locale_path = locale_path
            self.locale_out = locale_out
            self.locale_err = locale_err

# Generated at 2022-06-22 21:45:39.588488
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = AnsibleModule(argument_spec={})
    found = get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX'])

    assert found == 'C'

# Generated at 2022-06-22 21:45:45.700713
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import sys
    import os

    # Force locale to C for testing
    os.environ["LC_ALL"] = "None"

    # Gather locale information from the system
    a = AnsibleModule(argument_spec=dict())
    best_locale, unused = get_best_parsable_locale(a, raise_on_locale=True)

    # Start testing
    # 1. The current locale should be C and best_locale should be C
    if (sys.version_info[0] == 2):
        import locale
        current_locale = locale.getdefaultlocale()[0]
    else:
        import locale
        current_locale = locale.getdefaultlocale()[0]

    assert current_locale == 'C'
   

# Generated at 2022-06-22 21:45:56.014838
# Unit test for function get_best_parsable_locale

# Generated at 2022-06-22 21:46:05.355010
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Mocking AnsibleModule
    class FakeModule:
        def __init__(self):
            self.fail_json = lambda **kw: kw

        def get_bin_path(self, command):
            if command == 'locale':
                return '/usr/bin/locale'
            else:
                return None

        def run_command(self, cmd):
            # Mocking locale -a
            output = '''en_US.utf8
C
POSIX
en_US.utf8
C
POSIX'''
            return 0, output, ''

    best_locale = get_best_parsable_locale(FakeModule())
    assert best_locale == 'C'

    best_locale = get_best_parsable_locale(FakeModule(), preferences=['POSIX', 'C'])


# Generated at 2022-06-22 21:46:16.816835
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # If we find the exact locale we are looking for then it is first one returned
    old_get_bin_path = AnsibleModule.get_bin_path
    AnsibleModule.get_bin_path = lambda s, v: '/usr/bin/locale'
    old_run_command = AnsibleModule.run_command
    AnsibleModule.run_command = lambda s, v: (0, 'C\nen_US\nen_US.utf8', None)
    assert get_best_parsable_locale(AnsibleModule()) == 'C'
    AnsibleModule.get_bin_path = old_get_bin_path
    AnsibleModule.run_command = old_run_command

    # If we find the locale even if it is not first then it is returned
    old_get_bin_path = AnsibleModule

# Generated at 2022-06-22 21:46:26.264186
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import os

    class Module(object):
        def __init__(self):
            self.log = []
            self.run_command_results = [
                (0, "en_US.utf8\nen_US.UTF-8\nC\nC.utf8\nC.UTF-8\n", ''),  # locale -a
                (0, '/usr/bin/locale', ''),  # get_bin_path
            ]

        def get_bin_path(self, name):
            return self.run_command_results[-1][1]

        def run_command(self, args):
            self.log.append(args)
            return self.run_command_results.pop()

    module = Module()
    ret = get_best_parsable_locale(module)

# Generated at 2022-06-22 21:46:36.456301
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # When import fails, pretend we are on a system where the locale tool does not exist
    def pretend_module_run_command(module, cmd, *args, **kwargs):
        return 1, None, None
    try:
        from ansible.module_utils.basic import AnsibleModule
    except Exception:  # pylint: disable=broad-except
        class AnsibleModule(object):
            pass
        AnsibleModule.run_command = pretend_module_run_command

    module = AnsibleModule()

    # System with locale command and no available languages, should return C
    def pretend_no_locales(module, cmd, *args, **kwargs):
        return 0, None, None

    module.run_command = pretend_no_locales
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-22 21:46:47.761585
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import mock
    module = mock.Mock(spec=['get_bin_path', 'run_command'])
    module.get_bin_path.return_value = 'locale'
    preferences = ['C.utf8', 'C', 'POSIX']

    # Happy path.
    module.run_command.return_value = 0, 'C\nPOSIX', ''
    answer = get_best_parsable_locale(module, preferences)
    assert answer == 'C'

    # If the tool is not present, we need to take the warning and return 'C'
    module.get_bin_path.return_value = None
    answer = get_best_parsable_locale(module, preferences)
    assert answer == 'C'

    # If the tool failed to get locale information, we should take the warning and return

# Generated at 2022-06-22 21:46:55.003885
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from units.modules.utils import AnsibleModule

    import sys
    import tempfile

    # Test 1:
    # - Check for 'locale' binary
    # - No output from 'locale -a' command

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # For testing purposes, we will save the original value of sys.stdout
    orig_stdout = sys.stdout

    # Make a temp file
    tf = tempfile.mktemp()

    # Open a temp file and save it as sys.stdout
    try:
        sys.stdout = open(tf, 'w')
    except IOError as e:
        module.fail_json(msg="Could not open file {0}".format(tf))


# Generated at 2022-06-22 21:47:05.179565
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    try:
        import ansible.module_utils.common.utils
    except ImportError:
        print("ansible required for this unit test")
        import sys
        sys.exit(1)

    # This method isn't available on older versions of Ansible
    if not hasattr(ansible.module_utils.common.utils, 'get_bin_path'):
         print("ansible.module_utils.common.utils.get_bin_path() is not available; This method is only available in Ansible >= 2.4")
         import sys
         sys.exit(1)

    class JUnitTestModule(object):

        def __init__(self):
            self.environment = {}


# Generated at 2022-06-22 21:47:06.393221
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None, ['POSIX', 'C']) == 'C'


# Generated at 2022-06-22 21:47:17.892899
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils.common.process import get_bin_path
    from shutil import which
    from tempfile import mkdtemp
    from ansible.module_utils.six import PY2
    from ansible.module_utils._text import to_bytes

    dummy_module = AnsibleModule(
        argument_spec=dict(
        ),
    )

    # When locale is not installed, /usr/bin/locale -> /usr/bin/true
    assert get_bin_path(dummy_module, 'locale') == get_bin_path(dummy_module, 'true')

    # When locale is not installed, use C locale to parse locale output
    assert get_

# Generated at 2022-06-22 21:47:27.120283
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule  # pylint: disable=import-error

    # Test 1: Find locale 'C'
    am = AnsibleModule()
    locale = get_best_parsable_locale(am)
    assert locale == 'C'

    # Test 2: Find locale C.utf8
    preference = ['C.utf8']
    am = AnsibleModule()
    locale = get_best_parsable_locale(am, preferences=preference)
    assert locale == 'C.utf8'

    # Test 3: Find locale POSIX
    preference = ['POSIX']
    am = AnsibleModule()
    locale = get_best_parsable_locale(am, preferences=preference)
    assert locale == 'POSIX'

    # Test 4: Find locale en_

# Generated at 2022-06-22 21:47:33.945348
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, ['fr_FR.utf8']) is None
    assert get_best_parsable_locale(module, ['C', 'C.utf8']) == 'C'
    assert get_best_parsable_locale(module, ['C', 'B']) == 'C'

# Generated at 2022-06-22 21:47:43.931468
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.locale
    import ansible.module_utils.basic
    import ansible.module_utils.six
    import sys

    # Python 2.6 compat
    class NullFile(object):
        def write(self, text):
            pass

    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.fail_json = None
            self.warn = None
            self.run_command = lambda *args, **kwargs: (0, "", "")
            self.get_bin_path = lambda x: '/bin/%s' % x
            self.log = NullFile()


# Generated at 2022-06-22 21:47:48.476675
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    result = get_best_parsable_locale(module)
    assert result == 'C'

# Generated at 2022-06-22 21:47:55.687166
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )

    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, preferences=['POSIX']) == 'C'
    assert get_best_parsable_locale(module, preferences=['POSIX', 'C']) == 'C'
    assert get_best_parsable_locale(module, preferences=['POSIX', 'C', 'C.utf8']) == 'C'

# Generated at 2022-06-22 21:48:03.649559
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # pylint: disable=import-error
    from ansible.module_utils.basic import AnsibleModule  # This is just for testing
    from ansible.module_utils.six import PY3  # This is just for testing

    # test unicode
    out = b'en_US.utf8\nC\nPOSIX\n'
    if PY3:
        out = out.decode()
    module = AnsibleModule(argument_spec={})
    module.get_bin_path = lambda _: True  # always return true so we don't skip the test
    module.run_command = lambda _, env_update=None: (0, out, '')  # always return successful
    locale = get_best_parsable_locale(module=module, preferences=None, raise_on_locale=False)

# Generated at 2022-06-22 21:48:06.765221
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={}, check_invalid_arguments=False)

    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, preferences=[]) == 'C'

# Generated at 2022-06-22 21:48:18.044324
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # We can't use unittest here because it's not supported in 2.6
    import sys
    import ansible.module_utils.basic
    # TODO init module in a more proper way
    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec={},
        bypass_checks=True,
    )

    # Test for standard POSIX
    module.run_command = lambda x: (0, 'C', None)
    assert get_best_parsable_locale(module, [], False) == 'C'

    # Test for default POSIX
    module.run_command = lambda x: (0, 'POSIX', None)
    assert get_best_parsable_locale(module, [], False) == 'C'

    # Test for English

# Generated at 2022-06-22 21:48:28.811059
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''Unit test for get_best_parsable_locale'''
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']

    # case 1: locale -a returns empty list
    rc, out, err = 0, '', ''
    res = get_best_parsable_locale(rc, out, err, preferences=preferences)
    assert res == 'C'

    # case 2: locale CLI tool is not available
    res = get_best_parsable_locale(None, None, None, preferences=preferences)
    assert res == 'C'

    # case 3: from empty list of preferences
    rc, out, err = 0, 'C\nen_US.utf8\nen_US.utf8\nPOSIX', ''
    res = get_

# Generated at 2022-06-22 21:48:33.530653
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.basic import AnsibleModule
    bin_path = get_bin_path('locale')
    if bin_path is None:
        print("locale not found, skipping test")
    else:
        import shutil
        import tempfile
        import os
        import atexit
        m = AnsibleModule(argument_spec={})
        m._ansible_version = '2.0.0'
        m._ansible_debug = True
        t = tempfile.mkdtemp()
        atexit.register(lambda: shutil.rmtree(t))
        os.chmod(t, 0o700)

# Generated at 2022-06-22 21:48:44.882640
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import get_exception
    from ansible.module_utils.basic import EXIT_FAILURE
    from ansible.module_utils.basic import EXIT_SUCCESS
    from ansible.module_utils.basic import AnsibleExitJson
    from ansible.module_utils.basic import AnsibleFailJson
    import sys

    # this is a module, we have to exit, not raise an exception
    def fail(module, msg, **kwargs):
        raise AnsibleFailJson(msg=msg, **kwargs)  # use real AnsibleFailJson so we don't need to test this part

    # this is a module, we have to exit, not raise an exception

# Generated at 2022-06-22 21:48:52.069809
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Test the get_best_parsable_locale() function.

    This is done by patching the module.run_command() method
    and inspecting the arguments passed to it.

    '''

    from ansible.module_utils.basic import AnsibleModule

    # Create an instance of AnsibleModule
    module = AnsibleModule()

    # Patch module.run_command()
    def run_command(args, check_rc=False, close_fds=False, executable=None, data=None, binary_data=False):
        '''
        Fake module.run_command() method

        Raise a RuntimeError if the command is not
        ['locale', '-a']
        '''

# Generated at 2022-06-22 21:48:53.485769
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None) == 'C'

# Generated at 2022-06-22 21:49:04.374462
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    # test default settings
    result = get_best_parsable_locale(AnsibleModule(argument_spec={}))
    assert result == 'C'

    # test error handling and default return when specified
    result = get_best_parsable_locale(AnsibleModule(argument_spec={}), raise_on_locale=True)
    assert result == 'C'

    # test returning of specified locale (C)
    result = get_best_parsable_locale(AnsibleModule(argument_spec={}), ['C'])
    assert result == 'C'

    # test returning of specified locale (C.utf8)

# Generated at 2022-06-22 21:49:11.271666
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Test to ensure we get the preferred locale as expected
    '''
    # Test to ensure we properly handle no locale tool by returning 'C'
    # and not raising an exception.
    class MockModule:
        def __init__(self):
            self.args = None
            self.bin_path = None
        def get_bin_path(self, executable=None, required=True, opt_dirs=[]):
            return None
        def fail_json(self, *args, **kwargs):
            return {"failed": True}

# Generated at 2022-06-22 21:49:21.594420
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic

    module = ansible.module_utils.basic.AnsibleModule(argument_spec={})
    # Empty 'locale -a' response should not return empty string as it's related to issue #13132
    assert get_best_parsable_locale(module, preferences=[]) == 'C'
    # If 'locale -a' returns supported locale, it should be used
    assert get_best_parsable_locale(module, preferences=['de_DE.utf8']) == 'de_DE.utf8'
    # If 'locale -a' returns supported locale, it should be used even if there is a preferred locale that is not available
    assert get_best_parsable_locale(module, preferences=['xx_XX.utf8', 'de_DE.utf8'])

# Generated at 2022-06-22 21:49:32.465698
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import _load_params, AnsibleModule
    from ansible.module_utils.common.sys_info import get_distribution
    # For systems where locale is not located, we are not testing
    module = AnsibleModule(_load_params())
    if module.get_bin_path('locale'):
        if get_distribution().lower() in ['centos', 'rhel', 'fedora']:
            assert get_best_parsable_locale(module) == 'C'
        elif get_distribution().lower() in ['debian', 'ubuntu']:
            assert get_best_parsable_locale(module) == 'POSIX'
    else:
        raise RuntimeError('locale binary not found, please fix')

# Generated at 2022-06-22 21:49:42.750030
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import collections

    FakeModule = collections.namedtuple('FakeModule', ['get_bin_path', 'run_command'])
    FakeSubproc = collections.namedtuple('FakeSubproc', ['stdout', 'stderr'])

    def fake_run_command(args):
        if len(args) == 2:
            # locale -a
            if args[0] == '/path/to/locale' and args[1] == '-a':
                return (
                    0,
                    'C\nPOSIX\nen_US.utf8\nen_US.utf8\nen_GB.utf8\n',
                    ''
                )

# Generated at 2022-06-22 21:49:47.026582
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None, ['C.utf8', 'en_US.utf8']) == 'C.utf8'
    assert get_best_parsable_locale(None, ['foo', 'bar']) == 'C'

# Generated at 2022-06-22 21:49:48.371207
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None) == 'C'

# Generated at 2022-06-22 21:49:58.329048
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    import os
    import sys
    import shutil
    import tempfile
    import subprocess
    from ansible.module_utils.basic import AnsibleModule

    # We now create a fake module
    # we need to do 2 things
    # 1. set the module path to be where this file is
    # 2. add an empty basic.py to that path
    file, path = tempfile.mkstemp(dir=os.getcwd())
    os.close(file)
    sys.path.append(os.path.dirname(path))
    file, path = tempfile.mkstemp(dir=os.path.dirname(path))
    os.close(file)

    class FakeModule(object):

        def __init__(self):
            self.params = {}


# Generated at 2022-06-22 21:50:04.726227
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    import os

    def test_module():
        return AnsibleModule(argument_spec={'test_arg': {'default': 'value'}})

    # Set an environment variable that is not defined in the path
    os.environ['FOO'] = 'bar'

    module = test_module()
    # Give an invalid locale to see if it will use the default
    preferences = ['invalid_locale']
    # Run get_best_parsable_locale and make sure it returns C
    assert get_best_parsable_locale(module=module, preferences=preferences, raise_on_locale=False) == "C"

    # Run get_best_parsable_locale with invalid preferences
    assert get_best_parsable_locale

# Generated at 2022-06-22 21:50:16.169714
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class MockModule(object):
        def __init__(self):
            self.params = None
        def get_bin_path(self, path):
            return path
        def run_command(self, argv):
            if argv[0] == 'locale' and argv[1] == '-a':
                return 0, 'C.utf8\nen_US.utf8\nPOSIX', ''
            raise Exception('command failure')

    m = MockModule()
    # tests
    assert get_best_parsable_locale(m) == 'C.utf8'
    assert get_best_parsable_locale(m, preferences=['en_US.utf8', 'C']) == 'en_US.utf8'

# Generated at 2022-06-22 21:50:24.135303
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # No value, defaults to C
    assert 'C' == get_best_parsable_locale(None)

    # Value not in list, defaults to C
    assert 'C' == get_best_parsable_locale(None,['en_AU.utf8'])

    # Value in list, returns value
    assert 'en_AU.utf8' == get_best_parsable_locale(None,['en_AU.utf8','en_US.utf8'])

# Generated at 2022-06-22 21:50:34.042871
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Importing for this test file instead of skipping test because
    # it's a test inside a test and Ansible has a way of skipping tests
    # but not individual functions within a test file
    try:
        from ansible.module_utils.basic import AnsibleModule
    except ImportError:
        pass

    result = {'changed': False,
              'rc': 0,
              'stdout': 'C\nen_US.utf8\nen_US.UTF-8\n',
              'stdout_lines': ['C', 'en_US.utf8', 'en_US.UTF-8']
              }

    module_mock = AnsibleModule(argument_spec={})
    module_mock.run_command = lambda x: (0, result['stdout'], 'error')
    # No preferred locale, should return the first.

# Generated at 2022-06-22 21:50:42.845518
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Set up fake module
    class ModuleFailJson(Exception):
        pass

    class AnsibleModule:
        def __init__(self):
            self.params = dict()

        def get_bin_path(self, program):
            if program == "locale":
                return program

        def run_command(self, args):
            if args == ["locale", "-a"]:
                return 0, "en_US.utf8\nen_US.utf8", ""
            return 0, "", ""

    module = AnsibleModule()

    get_best_parsable_locale(module)

# Generated at 2022-06-22 21:50:47.100729
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None) == 'C'
    assert get_best_parsable_locale(None, preferences=['sh_SN.utf8']) == 'C'
    assert get_best_parsable_locale(None, preferences=['C.utf8', 'sh_SN.utf8']) == 'C.utf8'

# Generated at 2022-06-22 21:50:50.200242
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    import ansible.module_utils.basic
    m = ansible.module_utils.basic.AnsibleModule(argument_spec={})
    # test that this function does not throw an exception
    get_best_parsable_locale(m)

# Generated at 2022-06-22 21:50:57.133645
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        import unittest2 as unittest
        from ansible.compat.tests.mock import patch
    except ImportError:
        import unittest
        from unittest.mock import patch
    from ansible.compat.tests import unittest
    from ansible.module_utils.basic import AnsibleModule

    class TestAnsibleModule (AnsibleModule):
        def __init__(self):
            super(TestAnsibleModule, self).__init__()
            self._ids = []

    class TestGetBestParsableLocale(unittest.TestCase):
        def setUp(self):
            self.module = TestAnsibleModule()

        def tearDown(self):
            pass
