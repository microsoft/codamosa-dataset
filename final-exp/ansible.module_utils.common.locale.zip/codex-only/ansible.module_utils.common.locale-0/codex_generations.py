

# Generated at 2022-06-22 21:41:05.311359
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Return locale 'C' by default when detection of locale fails
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

    # Return locale 'C' when detection of locale fails but raise_on_locale is True
    module = AnsibleModule(argument_spec={})
    try:
        get_best_parsable_locale(module, raise_on_locale=True)
    except Exception as e:
        assert to_native(e) == "Unable to get best parsable locale"

    # Return locale 'C' by default if preferred preference is not in available
    module = AnsibleModule(argument_spec={})

# Generated at 2022-06-22 21:41:14.302543
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    # Test case 1:
    # Test with Module class
    module = AnsibleModule()
    assert get_best_parsable_locale(module) == 'C'

    # Test case 2:
    # Test with ('C', 'POSIX') preference list
    preferences = ('C', 'POSIX')
    assert get_best_parsable_locale(module, preferences) == 'C'

    # Test case 3:
    # Test with ('C.utf8', 'POSIX') preference list
    preferences = ('C.utf8', 'POSIX')
    assert get_best_parsable_locale(module, preferences) == 'C.utf8'

    # Test case 4:
    # Test with ('en_US.utf8', 'POSIX') preference list

# Generated at 2022-06-22 21:41:17.532429
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = FakeModule(dict())
    assert (get_best_parsable_locale(module) == 'en_US.UTF-8')

# Generated at 2022-06-22 21:41:29.192904
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils import six

    class FakeModule(AnsibleModule):
        def __init__(self):
            self.params = {'locale_preferences': ['de_DE.utf8', 'C.utf8', 'POSIX']}
            self.check_mode = False
            self.exit_json = self.exit_json_noargs
            self.fail_json = self.fail_json_noargs

        def fail_json_noargs(self, rc=None, msg=None, **kwargs):
            self.exited_args = rc
            self.exited_kwargs = kwargs

        def exit_json_noargs(self, **kwargs):
            self.exited_args = 0
            self.exited

# Generated at 2022-06-22 21:41:38.045327
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils

    # happy path
    result = get_best_parsable_locale(ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict(
        ),
    ))
    assert result in ['C', 'POSIX']

    # bad paths
    try:
        get_best_parsable_locale(ansible.module_utils.basic.AnsibleModule(
            argument_spec=dict(
            ),
        ), raise_on_locale=True)
        # should have raised
        assert False
    except RuntimeWarning:
        pass

# Generated at 2022-06-22 21:41:48.384121
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    mock_module = AnsibleModule()

    # Raise exception or not
    assert get_best_parsable_locale(mock_module) == 'C'
    assert get_best_parsable_locale(mock_module, raise_on_locale=True) == 'C'

    assert get_best_parsable_locale(mock_module, preferences=['es_ES.utf8']) == 'C'
    assert get_best_parsable_locale(mock_module, preferences=['es_ES.utf8'], raise_on_locale=True) == 'C'


# Generated at 2022-06-22 21:41:49.716915
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # TODO:
    pass

# Generated at 2022-06-22 21:41:59.630460
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    test_module = {'get_bin_path' : lambda *args: '/usr/bin/locale'}
    result = get_best_parsable_locale(test_module)
    assert result == 'C'

    test_module = {'get_bin_path' : lambda *args: None}
    result = get_best_parsable_locale(test_module)
    assert result == 'C'

    test_module = {'get_bin_path' : lambda *args: '/usr/bin/locale', 'run_command' : lambda *args: (0, '', '')}
    result = get_best_parsable_locale(test_module)
    assert result == 'C'


# Generated at 2022-06-22 21:42:09.480903
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Test for a supported locale
    module.get_bin_path = lambda x: x
    module.run_command = lambda x: (0, "C.utf8\nen_US.utf8\nen_US.utf-8", "")
    assert get_best_parsable_locale(module, ['ja_JP.utf8', 'en_US.utf8', 'C', 'POSIX']) == "en_US.utf8"

    # Test for a non-supported locale
    module.get_bin_path = lambda x: x
    module.run_command = lambda x: (0, "C.utf8\nen_US.utf8\nen_US.utf-8", "")

# Generated at 2022-06-22 21:42:20.764988
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    testmodule = AnsibleModule({}, {})
    testmodule.run_command = AnsibleModule.run_command

    # No preference and no installed locale
    locale = get_best_parsable_locale(testmodule, preferences=None, raise_on_locale=True)
    assert locale == 'C'

    # No preferences but an installed locale
    locale = get_best_parsable_locale(testmodule, preferences=None, raise_on_locale=True)
    assert locale == 'C'
    testmodule.run_command = lambda x: (0, 'C.utf8\nen_US.utf8', '')
    locale = get_best_parsable_locale(testmodule, preferences=None, raise_on_locale=True)

# Generated at 2022-06-22 21:42:23.171598
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    assert module
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-22 21:42:33.657085
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Test standard case, locale 'C' is default locale
    assert get_best_parsable_locale(None) == 'C'
    assert get_best_parsable_locale(None, ['en_US.utf8', 'C', 'POSIX']) == 'C'
    assert get_best_parsable_locale(None, ['en_US.utf8', 'POSIX']) == 'POSIX'
    assert get_best_parsable_locale(None, ['en_US.utf8']) == 'en_US.utf8'
    assert get_best_parsable_locale(None, ['en_US']) == 'C'
    assert get_best_parsable_locale(None, ['en']) == 'C'
    assert get_best_parsable_loc

# Generated at 2022-06-22 21:42:40.731355
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    ansible_module = AnsibleModule()

    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    pref_1 = get_best_parsable_locale(ansible_module, preferences)
    assert pref_1 == 'C'

    # raise exception if locale not available
    try:
        pref_2 = get_best_parsable_locale(ansible_module, preferences, raise_on_locale=True)
    except Exception as e:
        raise Exception(e)

    assert pref_2 != 'C'

    pass

# Generated at 2022-06-22 21:42:51.167864
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.basic import AnsibleModule

    class MockModule:
        def __init__(self):
            self.params = {}
            self.params['warnings'] = []

        def run_command(self, cmd):
            out = None
            if cmd[-1] == '-a':
                out = 'C\nen_US.utf8\nit_IT.utf8\nfr_FR.utf8\nC.utf8\n'
            return 0, out, None

        def get_bin_path(self, cmd):
            if cmd == 'locale':
                return '/path/to/locale'
            return None
    module = MockModule()
    # check that locale is found and a preferred one is used
    locale = get_best_parsable_locale(module)

# Generated at 2022-06-22 21:42:57.840589
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None) == 'C'
    assert get_best_parsable_locale(None, preferences=['a', 'b', 'c']) == 'C'
    assert get_best_parsable_locale(None, preferences=['en_US', 'POSIX']) == 'C'
    assert get_best_parsable_locale(None, preferences=['en', 'POSIX']) == 'C'

# Generated at 2022-06-22 21:43:06.263784
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Unit test of function get_best_parsable_locale
    :return: nothing
    '''
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict())

    locale = get_best_parsable_locale(module)

    print("Best parsable locale: %s" % locale)

# Main program for testing
if __name__ == '__main__':
    test_get_best_parsable_locale()

# Generated at 2022-06-22 21:43:14.309016
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    # no provided preferences
    assert not preferences
    module = AnsibleModule()
    assert get_best_parsable_locale(module, preferences) == 'C'
    module.cleanup()

    # provide preferences with 1 match
    preferences = ['C.utf8', 'C']
    module = AnsibleModule()
    assert get_best_parsable_locale(module, preferences) == 'C.utf8'
    module.cleanup()

    # provide preferences with no matches
    preferences = ['de', 'es']
    module = AnsibleModule()
    assert get_best_parsable_locale(module, preferences) == 'C'
    module.cleanup()

# Generated at 2022-06-22 21:43:24.915461
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils import basic
    import os

    preferences = [ 'de_DE.utf8', 'C.utf8', 'en_US.utf8', 'C', 'POSIX' ]

    # good output with right locale
    rc = 0
    # C.UTF-8
    # C.utf8
    # de_DE.utf8
    out = '''C.UTF-8\nC.utf8\nde_DE.utf8'''
    err = ''

    module = basic.AnsibleModule(
        argument_spec = dict()
    )
    module.get_bin_path = lambda x: '/usr/bin/locale'
    module.run_command = lambda x: (rc, out, err)

# Generated at 2022-06-22 21:43:26.655132
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale() == 'C'

# Generated at 2022-06-22 21:43:36.728651
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={}, supports_check_mode=True)

    # return 'C' locale
    assert get_best_parsable_locale(module, preferences=['POSIX', 'C.UTF-8']) == 'C'
    # return 'C' locale
    assert get_best_parsable_locale(module, preferences=['POSIX', 'C.utf-8']) == 'C'
    # raise RuntimeWarning exception as locale command is not found
    assert get_best_parsable_locale(module, preferences=['POSIX', 'C.utf-8'], raise_on_locale=True) == 'C'



# Generated at 2022-06-22 21:43:41.987922
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    found = get_best_parsable_locale(AnsibleModule)
    assert isinstance(found, str)

# Generated at 2022-06-22 21:43:46.655206
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    class TestModule(object):
        def get_bin_path(self,name=None):
            return "locale"
        def run_command(self,command):
            return 0, "en_US.utf8\nC.utf8\nC", ''

    module = TestModule()
    assert get_best_parsable_locale(module) == "en_US.utf8"

# Generated at 2022-06-22 21:43:58.580140
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    locale_found = get_best_parsable_locale(None)
    assert locale_found == 'C', "test_get_best_parsable_locale failed"
    assert get_best_parsable_locale(None, ['c']) == 'C', "test_get_best_parsable_locale failed"
    assert get_best_parsable_locale(None, ['POSIX']) == 'C', "test_get_best_parsable_locale failed"
    assert get_best_parsable_locale(None, ['en_US.utf8']) == 'en_US.utf8', "test_get_best_parsable_locale failed"

# Generated at 2022-06-22 21:44:08.843106
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six.moves import StringIO

    test_cases = dict()

    test_cases['en_US.UTF-8'] = u'C.UTF-8'
    test_cases['C.UTF-8'] = u'C.UTF-8'
    test_cases['POSIX'] = u'C.UTF-8'
    test_cases['en_US.UTF-8 en_US.UTF-8'] = u'C.UTF-8'
    test_cases[''] = u'C.UTF-8'

    for key, result in test_cases.items():
        modules = dict()
        modules['command'] = 'locale -a'
        modules['rc'] = 0

# Generated at 2022-06-22 21:44:13.530097
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict()
    )

    # Check default: returns C, if locale not installed or not working
    assert get_best_parsable_locale(module) == 'C'

    return True

# Generated at 2022-06-22 21:44:21.223854
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    import ansible.module_utils.facts
    import ansible.module_utils.six
    import ansible.module_utils.six.moves. builtins
    import copy

    out_dict = copy.deepcopy(ansible.module_utils.facts.FACTS_BSD)  # facts are immutable, no need to deepcopy

    utf8_locales = ['C.utf8', 'en_US.utf8', 'ja_JP.utf8']
    for utf8_locale in utf8_locales:
        out_dict['locale_all'] = utf8_locale
        module_args = {}
        module_args['gather_subset'] = ['all']

# Generated at 2022-06-22 21:44:29.660617
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import tempfile
    from ansible.module_utils.basic import AnsibleModule

    test_module = AnsibleModule({})
    working_locale_path = tempfile.NamedTemporaryFile()
    working_locale_path.write(b'C\nen_US.utf8\nC.utf8\n')
    working_locale_path.flush()

    test_module.params = {
        '_ansible_path': working_locale_path.name
    }

    assert get_best_parsable_locale(test_module) == 'C.utf8'

# Generated at 2022-06-22 21:44:36.392703
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible import module_utils
    import os
    import tempfile

    module_path = tempfile.mktemp()
    f = open(module_path, 'w')

# Generated at 2022-06-22 21:44:47.594829
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.text.utils import get_best_parsable_locale
    import os

    module = AnsibleModule()

    try:
        locale = get_best_parsable_locale(module, raise_on_locale=True)
        if locale not in ['C.utf8', 'en_US.utf8', 'C', 'POSIX']:
            raise Exception("get_best_parsable_locale returned %s which is not a recognized locale" % locale)
    except:
        # issue with running locale, defaults to 'C'
        if locale != 'C':
            raise Exception("get_best_parsable_locale returned %s which is not the expected 'C' locale" % locale)



# Generated at 2022-06-22 21:44:57.823034
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    ''' test get_best_parsable_locale() '''
    import tempfile

    class AnsibleModuleClass(object):
        ''' Dummy class to match the AnsibleModule spec '''
        FAIL_JSON = object()
        EXIT_JSON = object()
        EXIT_FAILURE = object()
        EXIT_SUCCESS = object()
        BIN_ANSIBLE_MODULE_CLI = None
        BIN_PYTHON = None

        def __init__(self, params):
            self.params = params

        def get_bin_path(self, bin_name, required=False, opt_dirs=''):
            ''' Dummy class to match the AnsibleModule spec '''
            return self.params[bin_name]


# Generated at 2022-06-22 21:45:08.958282
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    def get_bin_path(name):
        return "/usr/bin/{}".format(name)
    def run_command(command):
        locale_cmd, locale_args = command[0], command[1:]
        if locale_cmd.endswith("locale"):
            if locale_args == ["-a"]:
                return 0, "en_US.utf8\nPOSIX\nC\nC.utf8\n", ""
            elif locale_args == ["-c", "POSIX"]:
                return 0, "LANG=POSIX\nLANGUAGE=POSIX\n", ""
            elif locale_args == ["-c", "C"]:
                return 0, "LANG=C\nLANGUAGE=C\n", ""

# Generated at 2022-06-22 21:45:15.757296
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleFallbackNotFound
    import os
    import sys

    if not sys.executable:
        sys.exit("Could not find Python executable, please use 'python' to run this program.")
    if not sys.version_info[:2] == (2, 6):
        sys.exit("Unsupported Python version %s, please use Python 2.6" % sys.version_info)

    try:
        from ansible.module_utils.basic import AnsibleModule
        from ansible.module_utils.basic import AnsibleFallbackNotFound
    except ImportError:
        sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..', 'lib'))

# Generated at 2022-06-22 21:45:28.810287
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import b

    test_pref = ['cs_CZ.utf8', 'en_US.utf8']
    test_locale = '''
C
C.utf8
en_HK.utf8
en_PH.utf8
en_US.iso885915
en_US.utf8
POSIX
'''

    assert get_best_parsable_locale(AnsibleModule(argument_spec={}), preferences=test_pref, raise_on_locale=True) == test_pref[1]

    assert get_best_parsable_locale(AnsibleModule(argument_spec={}), preferences=None, raise_on_locale=True) == 'C'

    assert get_

# Generated at 2022-06-22 21:45:38.316210
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    pref = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    # Given a pref and a list of locales that should be returned
    # the first matching preferred locale
    module = AnsibleModule(argument_spec=dict())
    assert get_best_parsable_locale(module, pref, True) == "C.utf8"
    pref = ['C.utf8', 'en_US.utf8', 'POSIX', 'C']
    module = AnsibleModule(argument_spec=dict())
    assert get_best_parsable_locale(module, pref, True) == "C"

# Generated at 2022-06-22 21:45:43.392246
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Test without arguments
    try:
        get_best_parsable_locale(None)
    except RuntimeWarning:
        pass
    except Exception:
        raise AssertionError('test_get_best_parsable_locale() without arguments failed')

    # Test with invalid arguments
    try:
        get_best_parsable_locale('no_module')
    except RuntimeWarning:
        pass
    except Exception:
        raise AssertionError('test_get_best_parsable_locale() with invalid arguments failed')

# Generated at 2022-06-22 21:45:45.863832
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert isinstance(get_best_parsable_locale(None), str)

# Generated at 2022-06-22 21:45:56.266408
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import os
    import sys
    import test
    import tempfile
    import ansible.module_utils.basic

    class AnsibleModuleStub(ansible.module_utils.basic.AnsibleModule):
        def get_bin_path(self, command):
            return os.getenv('PATH', os.path.abspath(os.path.curdir))

        def run_command(self, args):
            return (0, '\n'.join(sys.getfilesystemencoding(), 'C')), ''

    module = AnsibleModuleStub(argument_spec={}, bypass_checks=True)
    assert get_best_parsable_locale(module, preferences=['C', 'POSIX']) == 'C'
    pref = 'da_DK.utf8'
    assert get_best_parsable_

# Generated at 2022-06-22 21:46:05.499018
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Create a mock module
    module = AnsibleModule
    module.run_command = Mock(return_value=(0, "", ""))

    locale_output = "C\nen_US.utf8\nPOSIX"
    module.run_command.return_value = (0, locale_output, "")
    assert get_best_parsable_locale(module) == "en_US.utf8"

    locale_output = "en_US.utf8\nPOSIX"
    module.run_command.return_value = (0, locale_output, "")
    assert get_best_parsable_locale(module) == "en_US.utf8"

    locale_output = "POSIX"
    module.run_command.return_value = (0, locale_output, "")
    assert get_

# Generated at 2022-06-22 21:46:16.977480
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Ensures that get_best_parsable_locale returns the first matched preferred
    locale from a list of available locales.
    List of available locales can be empty, indicating that no previous
    locales were set or list of available locales returns a
    RuntimeWarning for the user.
    '''
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule

    # List of available locales is empty
    def test_empty():
        module = AnsibleModule({'run_command': run_command_empty_locale})
        locale = get_best_parsable_locale(module)
        assert locale == 'C'

    # List of available locales is not empty

# Generated at 2022-06-22 21:46:26.396592
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    mock = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(mock) == 'C'

    def mock_run_command(cmd, *args, **kwargs):
        return 0, "C\nen_US.utf-8", ""

    mock.run_command = mock_run_command
    pref = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    assert get_best_parsable_locale(mock, pref) == 'en_US.utf8'
    assert get_best_parsable_locale(mock, pref, raise_on_locale=True) == 'en_US.utf8'

# Generated at 2022-06-22 21:46:36.569384
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    test_module = get_test_module()
    test_module.run_command.side_effect = return_locale_output(test_module,
                                                               rc=0, out="", err="")
    locale = get_best_parsable_locale(test_module,
                                      preferences=['C', 'POSIX'])
    assert(locale == "C")

    test_module.run_command.side_effect = return_locale_output(test_module,
                                                               rc=0, out="C\nPOSIX\nC.UTF-8\nen_US.utf8", err="")
    locale = get_best_parsable_locale(test_module,
                                      preferences=['en_US.utf8', 'C', 'POSIX'])

# Generated at 2022-06-22 21:46:37.976936
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None) == 'C'

# Generated at 2022-06-22 21:46:49.733110
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert(get_best_parsable_locale({'run_command': lambda *args, **kwargs: (0, '', '',),
                                     'get_bin_path': lambda *args, **kwargs: '/usr/bin/locale'},
                                    preferences=('C.utf8', 'C')) == 'C')
    assert(get_best_parsable_locale({'run_command': lambda *args, **kwargs: (0, '', '',),
                                     'get_bin_path': lambda *args, **kwargs: '/usr/bin/locale'},
                                    preferences=('C.utf8', 'C', 'C.UTF8')) == 'C.UTF8')
    # pylint: disable=protected-access

# Generated at 2022-06-22 21:46:56.515013
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class FakeModule:
        class FakeRunCommand:
            def __init__(self, rc, out, err):
                self.rc = rc
                self.stdout = out
                self.stderr = err

            def __call__(self, *args, **kwargs):
                return self.rc, self.stdout, self.stderr

        def __init__(self, rc, out, err, output):
            self.run_command = FakeModule.FakeRunCommand(rc, out, err)
            self.output = output
            self.warnings = []

        def get_bin_path(self, binary):
            # Must return an executable or False
            return binary

        def fail_json(self, *args, **kwargs):
            if self.output:
                print(self.output)

    test_cases

# Generated at 2022-06-22 21:47:05.697777
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    m = AnsibleModule(
        argument_spec=dict(
            test_locale=dict(type='str', default='none'),
        ),
    )

# Generated at 2022-06-22 21:47:09.361818
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    best_parsable_locale = get_best_parsable_locale(module, raise_on_locale=True)
    assert best_parsable_locale

# Generated at 2022-06-22 21:47:19.374670
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None, ['xx', 'yy']) == 'C'
    assert get_best_parsable_locale(None, ['C']) == 'C'
    assert get_best_parsable_locale(None, ['C', 'POSIX']) == 'C'
    assert get_best_parsable_locale(None, ['POSIX', 'C']) == 'C'
    assert get_best_parsable_locale(None, ['POSIX']) == 'C'
    assert get_best_parsable_locale(None, ['en_US.utf8', 'POSIX']) == 'en_US.utf8'

# Generated at 2022-06-22 21:47:27.735711
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class AnsibleModule(object):
        def __init__(self, fail_json, raise_on_locale) :
            self.fail_json = fail_json
            self.raise_on_locale = raise_on_locale

        def get_bin_path(self, tool):
            return tool

        def run_command(self, cmd):
            if cmd[0] == 'locale' and cmd[1] == '-a':
                return 0, 'C\nen_US.utf8\neu_ES.utf8\n', None
            return 0, '', None

    # 1. empty preferences
    module = AnsibleModule(False, False)
    preferences = []
    found = get_best_parsable_locale(module, preferences, False)
    assert found == 'C'

    # 2.

# Generated at 2022-06-22 21:47:38.456613
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils import basic
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']

    # Case 1: if local is not installed in machine, then it should return 'C'
    x = basic.AnsibleModule(argument_spec={})
    x.run_command = lambda args: (None, None, None)
    assert get_best_parsable_locale(x) == 'C'

    # Case 2: if locale is installed, but locale -a command return empty string,
    # then it should return 'C'
    x.run_command = lambda args: (0, '', '')
    assert get_best_parsable_locale(x) == 'C'

    # Case 3: if preferences is not provided, it should return first matched preferred locale in preferences

# Generated at 2022-06-22 21:47:46.268140
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    import tempfile

    script = '''#!/bin/sh
    if [ "$1" = "locale" ] && [ "$2" = "-a" ]; then
        echo C.UTF-8
        echo en_US.UTF-8
    else
        echo "Unknown command"
    fi
    '''

    # write the above script to a tempfile and make it executable
    tempscript = tempfile.NamedTemporaryFile(mode='w')
    tempscript.write(script)
    tempscript.flush()
    os.chmod(tempscript.name, os.stat(tempscript.name).st_mode | stat.S_IEXEC)

    # put in our PATH, so we'll find it before any actual locale program
    old_path = os.environ['PATH']

# Generated at 2022-06-22 21:47:52.756748
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class AnsibleModule():
        def get_bin_path(self, exe):
            # print("get_bin_path(%s)" % exe)
            return 'locale'

        def run_command(self, cmd):
            # print("run_command(%s)" % cmd)
            return 0, 'C\nen_US.UTF-8\nen_US.utf8\n????\n', ''

    am = AnsibleModule()
    assert get_best_parsable_locale(am) == 'en_US.utf8'

# Generated at 2022-06-22 21:47:58.333883
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    def run_command(args, check_rc=False, close_fds=True, executable=None, data=None, binary_data=False, path_prefix=None, cwd=None, use_unsafe_shell=False, prompt_regex=None, environ_update=None, umask=None, encoding=None, errors='strict'):
        return 0, '', ''

    class FakeModule:
        def __init__(self):
            self.params = {'preferences': None}
        def get_bin_path(self, path):
            return path

# Generated at 2022-06-22 21:48:10.131745
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    import sys
    import unittest

    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule
    from io import StringIO
    
    from ansible.module_utils.common.locales import get_best_parsable_locale

    class MyModule(object):

        def __init__(self, run_command_args=None):
            self.run_command_args = run_command_args
            self.params = {}

        def get_bin_path(self, tool=None, required=False, opt_dirs=[]):
            return "locale"

        def run_command(self, command):
            if self.run_command_args:
                return self.run_command_args
            else:
                raise RuntimeError()


# Generated at 2022-06-22 21:48:19.427537
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Test on POSIX
    assert get_best_parsable_locale(None, raise_on_locale=True) == 'C'

    # Test on non-POSIX
    # If no locale is available, use POSIX
    assert get_best_parsable_locale(None, [], raise_on_locale=True) == 'POSIX'
    # If locale not available, use first preferred
    assert get_best_parsable_locale(None, ['POSIX', 'C'], raise_on_locale=True) == 'POSIX'
    # If locale not available, use first preferred
    assert get_best_parsable_locale(None, ['POSIX', 'fr_FR'], raise_on_locale=True) == 'fr_FR'
    # If locale is available, use it

# Generated at 2022-06-22 21:48:30.023027
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    class MockAnsibleModule:

        @staticmethod
        def run_command(cmd):
            return 0, 'en_US.utf8\nC\nPOSIX\n', ''

        @staticmethod
        def get_bin_path(tool):
            return 0

    class LocaleTestCase(unittest.TestCase):

        def setUp(self):
            self.ansible_module = MockAnsibleModule

        def test_get_best_parsable_locale_normal_success(self):
            self.assertEquals(get_best_parsable_locale(self.ansible_module), 'en_US.utf8')

       

# Generated at 2022-06-22 21:48:38.136978
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    ''' test_get_best_parsable_locale '''
    from ansible.module_utils.basic import AnsibleModule
    mymodule = AnsibleModule(argument_spec={}, supports_check_mode=True)
    assert get_best_parsable_locale(mymodule) == 'C'
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    assert get_best_parsable_locale(mymodule, preferences) == 'C'

# Generated at 2022-06-22 21:48:47.543139
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Set the locale binary path
    locale = '/usr/bin/locale'

    # Test with en_US.utf8 present
    test_out = '''C
en_US.utf8
POSIX
'''
    assert get_best_parsable_locale(locale, test_out) == 'en_US.utf8'

    # Test without en_US.utf8 present
    test_out = '''C
POSIX
'''
    assert get_best_parsable_locale(locale, test_out) == 'C'

    # Test with empty output
    test_out = ''''''
    assert get_best_parsable_locale(locale, test_out) == 'C'

# Generated at 2022-06-22 21:48:51.835403
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    locale = get_best_parsable_locale(module)
    assert locale == "C"

# Generated at 2022-06-22 21:49:03.184356
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    m_run_command = AnsibleModule._AnsibleModule__run_command
    m_get_bin_path = AnsibleModule.get_bin_path

    def run_command(self, args, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False, path_prefix=None, cwd=None, use_unsafe_shell=False, prompt_regex=None):
        if 'locale' in args:
            rc = 0
            out = 'C.utf8\nen_US.utf8\nC\nPOSIX\nJUNK\nCODE'
        else:
            rc = 1
            out = ''

        if 'fail' in args:
            rc = 1

# Generated at 2022-06-22 21:49:10.552375
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = type('module', (object,), {'get_bin_path': lambda x, y: False})
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'C', 'POSIX']) == 'C'
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'C', 'POSIX'], raise_on_locale=True) == 'C'
    module = type('module', (object,), {'get_bin_path': lambda x, y: True, 'run_command': lambda x, y: (0, '', '')})
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'C', 'POSIX']) == 'C'
    assert get_best_parsable_

# Generated at 2022-06-22 21:49:21.370499
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Providing a list of supported locales
    assert get_best_parsable_locale(None, preferences=['C.utf8', 'en_US.utf8'], raise_on_locale=True) == 'C.utf8'
    # Providing a list of supported locales with None preference
    assert get_best_parsable_locale(None, preferences=['C.utf8', 'en_US.utf8', None], raise_on_locale=True) == 'C.utf8'
    # Providing a list of supported locales with 'C.utf8' preference
    assert get_best_parsable_locale(None, preferences=['C.utf8', 'en_US.utf8', 'C.utf8'], raise_on_locale=True) == 'C.utf8'
   

# Generated at 2022-06-22 21:49:25.268760
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    ansible_module = AnsibleModule(argument_spec={})

    # Test 1 - A proper locale list is returned in the absence of any error
    assert isinstance(get_best_parsable_locale(ansible_module), str)

    # Test 2 - An exception is raised when the locale is not found
    ansible_module = AnsibleModule(argument_spec={}, bypass_checks=True)
    from ansible.module_utils.basic import AnsibleFallbackNotFound
    with pytest.raises(AnsibleFallbackNotFound):
        get_best_parsable_locale(ansible_module)

    # Test 3 - An exception is raised when the locale is not found

# Generated at 2022-06-22 21:49:30.264101
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    preferred_locale = 'C'
    assert get_best_parsable_locale(module) == preferred_locale, "Expected %s but got %s" % (preferred_locale, get_best_parsable_locale(module))

# Generated at 2022-06-22 21:49:36.222800
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule()
    assert module.get_bin_path("locale")
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) in ['C.utf8', 'en_US.utf8', 'C', 'POSIX']

# Generated at 2022-06-22 21:49:44.709707
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    import ansible.module_utils.basic
    import ansible.module_utils.facts.system.locale
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.common.process

    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )
    module.run_command = ansible.module_utils.common.process.run_command
    module.get_bin_path = ansible.module_utils.facts.system.platform.get_bin_path
    module.get_best_parsable_locale = ansible.module_utils.facts.system.locale.get_best_parsable_locale

    # Tests for when locale command is not found
   

# Generated at 2022-06-22 21:49:50.259270
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    class FakeModule:
        def __init__(self):
            self.locale_bin_path = None
            self.rc = 0
            self.stdout = None
            self.stderr = None
            self.cmd = None
            self.args = None

        def get_bin_path(self, app):
            return self.locale_bin_path

        def run_command(self, args, check_rc=True):
            self.cmd = args[0]
            self.args = args[1:]
            return (self.rc, self.stdout, self.stderr)

    # test the default case of empty preferred locale list
    module = FakeModule()
    module.stdout = "C.utf8\nen_US.utf8\nC\nPOSIX\n"
    module.locale_

# Generated at 2022-06-22 21:49:59.796531
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import os
    import tempfile
    import shutil
    from ansible.module_utils._text import to_bytes

    # Create a tmpdir and place an empty locale file there
    tmpdir = tempfile.mkdtemp()
    localefile = tmpdir + '/locale'
    with open(localefile, 'wb') as f:
        f.write(to_bytes(''))

    # Set our environment to use the empty locale file
    os.environ['LOCALE_PATH'] = tmpdir
    # Setting LANGUAGE is required on fedora
    os.environ['LANGUAGE'] = 'en'

    # Test with the test locale file and preferences
    from ansible import module_utils
    module = module_utils.basic.AnsibleModule(
        argument_spec={},
    )

# Generated at 2022-06-22 21:50:02.116632
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # TODO: Test is not written yet.
    # Test the following case:
    # Test locale command is present
    # Test the output of the command
    # Test the function returns the expected default locale 'C'
    assert False

# Generated at 2022-06-22 21:50:06.446297
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    locale = get_best_parsable_locale(module, ['C', 'POSIX'], True)
    assert locale in ['C', 'POSIX']



# Generated at 2022-06-22 21:50:09.134888
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule({})
    assert(get_best_parsable_locale(module) is 'C')

# Generated at 2022-06-22 21:50:16.923112
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    m = AnsibleModule(argument_spec=dict())
    assert get_best_parsable_locale(m, ['C.utf8', 'en_US.utf8']) == 'C.utf8'
    assert get_best_parsable_locale(m, preferences=None) == 'C'
    assert get_best_parsable_locale(m, ['C.utf8', 'en_US.utf8'], raise_on_locale=True) == 'C.utf8'

# Generated at 2022-06-22 21:50:23.960680
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.common.process import get_bin_path

    a_module = AnsibleModule(
        argument_spec=dict(),
    )

    locale = get_best_parsable_locale(a_module)

    if locale in ['C', 'POSIX']:
        assert not get_bin_path('locale')
    else:
        assert get_bin_path('locale')

# Generated at 2022-06-22 21:50:33.971837
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    import unittest
    from ansible.module_utils._text import to_native
    from ansible.module_utils.common._collections import ImmutableDict


    class TestAnsibleModule(object):

        def __init__(self):
            self._result = ImmutableDict()
            self.fail_json = self._fail_json
            self.params = ImmutableDict()

        def _fail_json(self, **kwargs):

            self._result = ImmutableDict(kwargs)
            if self._result['msg']:
                to_native(self._result['msg'])

        def get_bin_path(self, name):

            return name


# Generated at 2022-06-22 21:50:35.401113
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None) == 'C'

# Generated at 2022-06-22 21:50:46.202769
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    locale_fixture = [
        "C",
        "C.UTF-8",
        "en_US.utf8",
        "en_GB.utf8",
        "en_US.UTF-8",
        "en_GB.UTF-8",
        "POSIX"
    ]


# Generated at 2022-06-22 21:50:54.985024
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule()
