

# Generated at 2022-06-22 21:41:05.311768
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Normal POSIX test
    module = {}
    module['get_bin_path'] = lambda x: x
    assert get_best_parsable_locale(module) == 'C'

    # Test with preferred locale 'fr_FR.utf8'
    preferences = ['fr_FR.utf8']
    module = {}
    module['get_bin_path'] = lambda x: x
    assert get_best_parsable_locale(module, preferences) == 'C'

    # Test with locale (fr_FR.utf8) does not exist
    preferences = ['fr_FR.utf8']
    module = {}
    module['get_bin_path'] = lambda x: x
    module['run_command'] = lambda x, y: (0, 'en_US.UTF-8', None)
    assert get_best_

# Generated at 2022-06-22 21:41:14.302967
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import os
    import mock
    from ansible.module_utils.basic import AnsibleModule

    # Create a mock module without parameters and check_mode
    test_module = mock.MagicMock(spec_set=AnsibleModule)
    test_module.params = {}
    test_module.check_mode = False

    # Mock os.geteuid to prevent privilege issues
    with mock.patch.object(os, 'geteuid', return_value=1000):
        # Mock locale to return our test preferences
        with mock.patch.object(test_module, 'run_command', return_value=(0, 'C.UTF-8\nen_US.UTF-8\nC\nPOSIX', '')):
            # Test the default preferences
            assert get_best_parsable_locale(test_module) == 'C'

# Generated at 2022-06-22 21:41:17.532440
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    assert get_best_parsable_locale(AnsibleModule()) == 'C'

# Generated at 2022-06-22 21:41:29.192890
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Create a module object to test
    class Module(object):
        def __init__(self):
            self.params = {
                "module_name": "unit_test_module",
                "module_args": {},
            }
        def get_bin_path(self, arg):
            return "/usr/bin/locale"
        def run_command(self, arg):
            return (0, "C\nC.UTF-8\nPOSIX\nfr_FR.UTF-8\nfr_FR.UTF8\nfr_FR.UTF-8@euro\nfr_FR.UTF8@euro\n\n", "")

    module = Module()
    # Test for default parameters
    assert get_best_parsable_locale(module) == "C"

    # Test for all preferred locales (

# Generated at 2022-06-22 21:41:35.728541
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    locale = get_best_parsable_locale(module)
    assert locale == 'C'

    module = AnsibleModule(argument_spec={})
    locale = get_best_parsable_locale(module, preferences=['en_US.utf8'])
    assert locale == 'en_US.utf8'

# Generated at 2022-06-22 21:41:45.862369
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    import unittest
    import tempfile
    import shutil

    from ansible.module_utils import basic
    from ansible.module_utils.common.process import get_bin_path

    if sys.version_info[0] >= 3:
        unicode = str

    def _mock_run_command(self, cmd, check_rc=False, close_fds=True, executable=None, data=None):
        if cmd[0] == 'locale':
            # simulate a system that only has 'C' locale
            return (0, '', '')

# Generated at 2022-06-22 21:41:53.343949
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = None
    preferences = [u'C.utf8', 'POSIX']
    locale = get_best_parsable_locale(None, preferences)
    assert(locale == 'C.utf8' or locale == 'POSIX')

    preferences = [u'POSIX', u'C.utf8']
    locale = get_best_parsable_locale(None, preferences)
    assert(locale == 'POSIX' or locale == 'C.utf8')

# Generated at 2022-06-22 21:42:01.403758
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class FakeModule(object):
        def __init__(self):
            self.fail_json = False
            self.warnings = []

        def get_bin_path(self, path):
            return path

        def run_command(self, args):
            if args[0] == "locale":
                if args[1] == "-a":
                    return 0, '''C
en_US.utf8''', ''

# Generated at 2022-06-22 21:42:11.227991
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.system.os
    from ansible.module_utils.facts.system import distribution, platform, os

    def test_run_command(args):
        error = ''
        if args[1] == '-a':
            output = 'C.utf8'
        return (0, output, error)

    class FakeAnsibleModule(object):
        def __init__(self):
            self.run_command = test_run_command
            self.get_bin_path = lambda x: ''
            self.params = {}
            self.platform = platform
            self.os = os
            self.distribution = distribution

    module = FakeAnsibleModule()



# Generated at 2022-06-22 21:42:22.229053
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={}, supports_check_mode=False)

    # Ensure that there is no error in setting locale to 'C', since the locale tool is not available.
    module.run_command = lambda x, **kwarg: (123, '', 'Error running command')
    get_best_parsable_locale(module)

    # Ensure that there is no error in setting locale to 'C', since the output of locale is empty.
    module.run_command = lambda x, **kwarg: (0, '', '')
    get_best_parsable_locale(module)

    # Ensure that the locale is set to the first preferred locale (POSIX) if it is available.

# Generated at 2022-06-22 21:42:32.905169
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    import stat
    import os
    import traceback
    import tempfile
    import shutil

    assert get_best_parsable_locale(None) == 'C', 'Default return value in "C" failed'


# Generated at 2022-06-22 21:42:41.389836
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Test expected values with no locales, incorrect command, and no good ones
    '''
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({}, {}, support_check_mode=True)
    assert module.get_best_parsable_locale(["en_US.utf8"]) == "C"
    assert module.get_best_parsable_locale() == "C"
    module = AnsibleModule({}, {"arguments": "locale -a"}, support_check_mode=True)

    try:
        assert module.get_best_parsable_locale() == None
    except RuntimeWarning:
        assert True, "This should have raised a warning"
    else:
        assert False, "This should have raised a warning"

    module = AnsibleModule

# Generated at 2022-06-22 21:42:47.455480
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    class AnsibleModule:

        def get_bin_path(self, executable):
            if executable == 'locale':
                return '/usr/bin/locale'

        def run_command(self, args, check_rc=True):
            if args == ['/usr/bin/locale', '-a']:
                return (0, '''# en_US.iso88591
# en_US.iso885915@euro
# en_US.utf8
# en_US.utf8@euro
# en_US
# C.ascii
# C.iso88591
# C.utf8
# POSIX
''', '')
            else:
                raise AssertionError('run_command called with unknown arguments %s' % repr(args))

    module = AnsibleModule()

    assert get_best_pars

# Generated at 2022-06-22 21:42:57.963393
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Make sure we can run this locally, maybe this will be deprecated or rewritten.
    # Mock the module and run our test.
    import ansible.module_utils.basic
    import ansible.module_utils.text
    from ansible.module_utils import six
    from ansible.module_utils._text import to_bytes, to_text

    mock_ansible = ansible.module_utils.basic
    mock_text = ansible.module_utils.text

    # Test with no prefs
    expected = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']


# Generated at 2022-06-22 21:43:10.203870
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Test the default case of the function
    assert get_best_parsable_locale(None) == 'C'

    # Test the case of no preferences being passed in
    assert get_best_parsable_locale(None) == 'C'

    assert get_best_parsable_locale(None, preferences=['C.UTF-8']) == 'C'

    assert get_best_parsable_locale(None, preferences=['C.UTF-8', 'C']) == 'C'

    assert get_best_parsable_locale(None, preferences=['C.UTF-8', 'C', 'POSIX']) == 'C'

    # Test the case of a preference that is not in the available locales being passed in

# Generated at 2022-06-22 21:43:12.369662
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
  from ansible.module_utils.common.process import get_bin_path

  assert(get_best_parsable_locale(get_bin_path) == 'C')

# Generated at 2022-06-22 21:43:19.246030
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    result = get_best_parsable_locale(None, preferences=['C.utf8', 'en_US.utf8', 'C.utf-8', 'C', 'POSIX'], raise_on_locale=False)
    assert result in ['C.utf8', 'en_US.utf8', 'C.utf-8', 'C', 'POSIX']

# Generated at 2022-06-22 21:43:23.334730
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    ''' get_best_parsable_locale returns C if there is no locale found '''

    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-22 21:43:34.868575
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six.moves import StringIO

    def command_output(command, rc=0, out=None, err=None):
        if out is None:
            out = StringIO()
        if err is None:
            err = StringIO()
        out.write('en_US\nen_US.utf8\nC\nC.utf8\nPOSIX\n')
        out.seek(0)
        err.seek(0)
        return rc, out, err

    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True,
        bypass_checks=True
    )
    module.run_command = command_output
    assert 'C.utf8' == get_best_parsable

# Generated at 2022-06-22 21:43:40.461673
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # should find locale
    assert get_best_parsable_locale(module, ['C', 'en_US.utf8']) == 'C'

    # should find locale
    assert get_best_parsable_locale(module, ['en_US.utf8', 'C']) == 'en_US.utf8'

    # search for locales in non-existent order
    assert get_best_parsable_locale(module, ['foo', 'bar']) == 'C'

# Generated at 2022-06-22 21:43:49.270298
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Testing for get_best_parsable_locale getting the first preferred locale
    # When there is an output in the preferred list from the system command
    from ansible.module_utils.basic import AnsibleModule
    import sys

    class Bunch(object):
        def __init__(self, adict):
            self.__dict__.update(adict)

    import locale
    locale.setlocale(locale.LC_ALL, "")

    # We need to mock the run_command to return the output as the output which
    # will be returned by the system command to test get_best_parsable_locale
    # function
    backup_run_command = AnsibleModule.run_command


# Generated at 2022-06-22 21:43:58.055736
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # mock the ansible module
    # Note: python module unittest.mock is required.
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({})

    # unit test for available locales
    module.run_command = mock_run_command
    test_available_locales = ['C', 'en_US.utf8', 'POSIX', 'en_US.utf8']
    test_preferences = ['zh_CN.utf8', 'C', 'en_US.utf8']
    assert get_best_parsable_locale(module, test_preferences) == 'C'
    assert get_best_parsable_locale(module) == 'POSIX'

# Generated at 2022-06-22 21:44:08.369910
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule  # Not used for internal consumption

    module = AnsibleModule()

    try:
        locale = get_best_parsable_locale(module, preferences=['xx_yy.utf8'], raise_on_locale=True)
        assert False, 'This should have raised an exception'
    except RuntimeWarning as ex:
        assert 'Could not find' in str(ex), 'This did not raise the correct exception'

    # Production code will not raise the exception and will return 'C'
    locale = get_best_parsable_locale(module, preferences=['xx_yy.utf8'])
    assert locale == 'C', "This should've returned 'C', but returned '%s'" % locale

# Generated at 2022-06-22 21:44:18.454511
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class MockAnsibleModule():

        def get_bin_path(self, binpath):
            return binpath


# Generated at 2022-06-22 21:44:28.606431
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # The following 3 imports are required for unit testing

    import io
    from ansible.module_utils.six.moves import StringIO

    from ansible.module_utils.ansible_release import __version__ as ansible_version
    from ansible.module_utils.basic import AnsibleModule

    # Create a fake ansible module which uses the get_bin_path function.
    # Also, using a fake output stream so we can test the output of the
    # run_command function.


# Generated at 2022-06-22 21:44:37.997984
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Unit test for function get_best_parsable_locale
        For testing this function requires the Python module mock to be installed
        It can be obtained from the Python package index: https://pypi.python.org/pypi/mock
    '''

    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec = dict()
    )

    # Test for all locales and preferred locales, one at a time, including not found

    # Test for locale C
    assert module.get_bin_path("locale") is not None
    module.run_command = mock.MagicMock(return_value=(0, 'C C.utf8 POSIX\n', ''))
    assert 'C' == get_best_parsable_locale(module)

   

# Generated at 2022-06-22 21:44:48.106326
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    # Test case: no preference so default to 'C'
    preferences = []
    result = get_best_parsable_locale(AnsibleModule, preferences)
    assert result == 'C'

    # Test case: preference, but no locale found
    preferences = ['en_US.utf8']
    result = get_best_parsable_locale(AnsibleModule, preferences)
    assert result == 'C'

    # Test case: no preference and no locale found
    preferences = None
    result = get_best_parsable_locale(AnsibleModule, preferences)
    assert result == 'C'

    # Test case: preference, with locale found
    preferences = ['fr_FR.utf8', 'de_DE.utf8']

# Generated at 2022-06-22 21:44:58.343562
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import EnvironmentError

    # Create a fake module for testing purposes
    class FakeModule(object):
        def __init__(self, rc=0, out=None, err=None):
            self._rc = rc
            self._out = out
            self._err = err

        def get_bin_path(self, binary):
            if binary == "locale":
                return "/usr/bin/locale"

        def run_command(self, args):
            return (self._rc, self._out, self._err)

    # Create a FakeModule instance
    mod = FakeModule()

    # Detect failing to find locale due to not being installed
    mod._rc = None

# Generated at 2022-06-22 21:45:09.107016
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})

    prefs = ['C.utf8', 'fr_FR.utf8', 'C', 'POSIX']

    # Test best value from preference list
    module.run_command = lambda args, cwd=None: (0, 'C.utf8\nC\nPOSIX', '')
    assert get_best_parsable_locale(module, preferences=prefs) == 'C.utf8'

    # Test default value
    module.run_command = lambda args, cwd=None: (0, 'fr_FR.utf8\nC\nPOSIX', '')
    assert get_best_parsable_locale(module, preferences=prefs) == 'C'

    # Test empty locale output


# Generated at 2022-06-22 21:45:19.324037
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Unit test for function get_best_parsable_locale.
    '''

    class AnsibleModule:
        '''
            Fake AnsibleModule class.
        '''

        def run_command(self, cmd):
            '''
                Fake run_command method.
            '''

            available = ['C', 'POSIX']
            if cmd[1] == '-a':
                return (0, '\n'.join(available), '')
            else:
                return (0, '', '')

        def get_bin_path(self, cmd):
            '''
                Fake get_bin_path method.
            '''

            return cmd

    # test a good search

# Generated at 2022-06-22 21:45:28.332653
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    test_input = ['C', 'en_US.utf8', 'C.utf8', 'POSIX']
    test_output = 'en_US.utf8'
    assert test_output == get_best_parsable_locale(None, preferences=test_input)

    # check the default ordering of preferences
    test_input = ['C', 'C.utf8']
    test_output = 'C.utf8'
    assert test_output == get_best_parsable_locale(None, preferences=test_input)

# unit test for function get_best_parsable_locale

# Generated at 2022-06-22 21:45:39.158196
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    mod = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )

    # basic test
    assert get_best_parsable_locale(mod) == 'C'

    # test where the locale CLI is not available
    import os

    if "PATH" in os.environ:
        del os.environ["PATH"]

    assert get_best_parsable_locale(mod) == 'C'

    # test where the preferred locale is available
    class MockModule(object):
        def __init__(self, rc, out=None, err=None, warnings=None):
            self.rc = rc
            self.out = out
            self.err = err
            self.warnings = warnings


# Generated at 2022-06-22 21:45:50.794960
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    import ansible.module_utils.basic_module_arguments
    import ansible.module_utils.command
    import ansible.module_utils.six
    import ansible.module_utils.system

    module = ansible.module_utils.basic.AnsibleModule(
        ansible_options=ansible.module_utils.basic_module_arguments.get_extended_arg_spec(),
        argument_spec={},
        supports_check_mode=True)

    ansible.module_utils.command.Command = ansible.module_utils.command.unused_command
    ansible.module_utils.system.System = ansible.module_utils.system.unused_system

    found = get_best_parsable_locale(module)

# Generated at 2022-06-22 21:45:58.560377
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    # create a mock module for testing
    module = AnsibleModule(argument_spec={})
    module.shell = True
    module.run_command = mock_run_command

    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, ['fr_FR.utf8', 'en_US.utf8']) == 'en_US.utf8'
    assert get_best_parsable_locale(module, [], raise_on_locale=True) == 'C'



# Generated at 2022-06-22 21:46:02.603974
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    _module = AnsibleModule(supports_check_mode=False)

    result = get_best_parsable_locale(_module)

    assert result in ['C.utf8', 'en_US.utf8', 'C', 'POSIX']



# Generated at 2022-06-22 21:46:09.257192
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict())
    preferences = ['C.utf8', 'en_US.utf8', 'c', 'POSIX']
    found = 'C'

    module.get_bin_path = lambda x: "/usr/bin/locale"

    # set locale -a output as 'POSIX'
    module.run_command = lambda locale, a: (0, "POSIX", "")
    found = get_best_parsable_locale(module, preferences, False)
    assert found == 'POSIX'

    # set locale -a output as 'en_US.utf8'
    module.run_command = lambda locale, a: (0, "en_US.utf8", "")
    found = get_best_pars

# Generated at 2022-06-22 21:46:17.650052
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    mod = AnsibleModule()

    defaults = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    # Test with defaults
    assert get_best_parsable_locale(mod) in defaults

    # Test with a given list of preferred locales
    assert get_best_parsable_locale(mod, preferences=['en_US']) == 'en_US'

    # Test with an invalid locale in a given list of preferred locales
    assert get_best_parsable_locale(mod, preferences=['en_US', 'C.utf8']) == 'C.utf8'

# Generated at 2022-06-22 21:46:26.720789
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    module = ansible.module_utils.basic.AnsibleModule(argument_spec={})


# Generated at 2022-06-22 21:46:36.820998
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils
    ansible.module_utils.basic.AnsibleModule = FakeAnsibleModuleClass
    from ansible.module_utils.facts import get_best_parsable_locale
    module = FakeAnsibleModuleClass()
    assert get_best_parsable_locale(module, ['en_US', 'en_GB']) == 'en_US'
    test_get_best_parsable_locale.locale_output = b''
    assert get_best_parsable_locale(module) == 'C'
    test_get_best_parsable_locale.locale_output = b''

# Generated at 2022-06-22 21:46:45.579838
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    ''' test for function get_best_parsable_locale '''
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import env_fallback
    if not env_fallback('LC_ALL'):
        assert get_best_parsable_locale(AnsibleModule({}), ['en_US.utf8']) == 'en_US.utf8'
    if not env_fallback('LC_ALL'):
        assert get_best_parsable_locale(AnsibleModule({})) == 'C'

# Generated at 2022-06-22 21:46:54.563234
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    """Test get_best_parsable_locale()"""

    import ansible.module_utils.basic as basic
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY2

    test_module = basic
    # test module_utils.basic functions
    test_module.ANSIBLE_VERSION = '2.8.0'
    test_module.ANSIBLE_MODULE_ARGS = {'version': True}
    test_module.ANSIBLE_METADATA = {}
    test_module.ANSIBLE_MODULE_REQUIRED_IF = []
    test_module.ANSIBLE_COMPATIBLE_INTERFACES = ['cli']
    test_module.IS_WINDOWS = False

    class AnsiModule:
        def __init__(self):
            self

# Generated at 2022-06-22 21:47:05.148941
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import _get_bin_path
    from ansible.module_utils.common.process import get_bin_path

    class ModuleTest(AnsibleModule):
        def __init__(self):
            super(ModuleTest, self).__init__(argument_spec={})

    module = ModuleTest()
    module.get_bin_path = _get_bin_path
    module.run_command = get_bin_path

    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, preferences=["en_US.utf8"]) == 'C'

# Generated at 2022-06-22 21:47:13.887383
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    m = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict(),
    )

    # normal case
    assert get_best_parsable_locale(m) == 'C'

    # with specific preferences
    assert get_best_parsable_locale(m, preferences=['C', 'POSIX']) == 'C'
    assert get_best_parsable_locale(m, preferences=['POSIX', 'C']) == 'C'

    # with non-existent pref
    assert get_best_parsable_locale(m, preferences=['JP']) == 'C'

    # with mixed pref
    assert get_best_parsable_locale(m, preferences=['JP', 'C']) == 'C'

# Generated at 2022-06-22 21:47:25.168282
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import os
    import sys

    class AnsibleModule:
        def __init__(self, **kwargs):
            self.run_command_exclude = kwargs.get("run_command_exclude", None)

        def get_bin_path(self, command):
            if self.run_command_exclude is not None and command in self.run_command_exclude:
                return None
            return command

        def run_command(self, cmd, **kwargs):
            # get_bin_path must be before run_command as we are mocking it
            locale = self.get_bin_path(cmd[0])

            if locale is None:
                return 127, None, None

# Generated at 2022-06-22 21:47:36.418195
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    def run(module, preferences, expected, exc_raised=False):
        # stub
        class Mod:
            def __init__(self):
                self._bin_path = {'locale': '/usr/bin/locale'}
                self._rc = 0
                self._stdout = '''af_ZA.utf8
de_CH.utf8
fr_CH.utf8
POSIX
'''
                self._stderr = ''

            def get_bin_path(self, s):
                return self._bin_path.get(s)

            def run_command(self, cmd):
                return self._rc, self._stdout, self._stderr

        m = Mod()
        found = get_best_parsable_locale(m, preferences)

# Generated at 2022-06-22 21:47:44.220961
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())

    # typical test of all available locales
    with open('/bin/locale', 'rb') as f:
        lines = f.readlines()
        line = lines[0]

    locales = line.split()

    # Test each locale and make sure it returns a valid locale string
    for locale in locales:
        pref = get_best_parsable_locale(module, preferences=[locale])
        assert pref != 'C', 'Found C, should have found some other locale'

    # Test to make sure it returns C when passed an empty list
    pref = get_best_parsable_locale(module, preferences=[])

# Generated at 2022-06-22 21:47:49.476714
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Basic unit test for get_best_parsable_locale

    :return: Return boolean
    '''

    assert get_best_parsable_locale(None) == 'C'

# pylint: disable=unused-argument

# Generated at 2022-06-22 21:47:54.057522
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    test_module = AnsibleModule(argument_spec={})

    assert get_best_parsable_locale(test_module, None, False) == 'C'


# Generated at 2022-06-22 21:47:59.680739
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.locales import get_best_parsable_locale

    module = AnsibleModule(argument_spec={})
    prefs = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    best_locale = get_best_parsable_locale(module, preferences=prefs)
    assert best_locale in prefs

# Generated at 2022-06-22 21:48:11.158811
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import os
    import tempfile

    from ansible.module_utils.basic import AnsibleModule

    # Create AnsibleModule instance for test
    # Use tempfile.mkstemp() to allow ansible module to write to a tempfile
    # that is not in a world readable /var/log directory
    (fd, fname) = tempfile.mkstemp()
    amodule = AnsibleModule(argument_spec={}, supports_check_mode=False)

    # Basic test, no locale preferences, expect 'C'
    best_locale = get_best_parsable_locale(amodule, preferences=None)
    assert best_locale == 'C'

    # Test with fake locales, expect pref1
    loc_pref = ['pref1', 'pref2']
    best_locale = get_best

# Generated at 2022-06-22 21:48:15.955335
# Unit test for function get_best_parsable_locale

# Generated at 2022-06-22 21:48:25.887918
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Mock module class for testing.
    class MockModule(object):
        def get_bin_path(self, args):
            if args == "locale":
                return "locale"
            else:
                return None
        def run_command(self, args):
            if args[0] == "locale" and args[1] == "-a":
                return (0, "C\nC.utf8\nen_US.utf8\nen_US\nko_KR.utf8\nen_US.gbk", None)
            else:
                return (127, None, None)

    module = MockModule()

    assert get_best_parsable_locale(module) == "C.utf8"

# Generated at 2022-06-22 21:48:33.680346
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Mock module and get_best_parsable_locale
    import __builtin__
    import mock
    reload(mock)
    module_mock = mock.Mock(name='AnsibleModule')
    module_mock.run_command.return_value = (0, 'C.UTF-8 POSIX C.utf8', None)
    locale_mock = mock.Mock(name='locale')
    module_mock.get_bin_path.return_value = locale_mock


# Generated at 2022-06-22 21:48:44.926010
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module, raise_on_locale=True) == 'C'

    def fake_run_command(self, cmd, in_data=None, binary_data=False, check_rc=False, close_fds=True, executable=None, data=None, path_prefix=None, cwd=None, prompt_regex=None, environ_update=None, umask=None, encoding=None, errors='surrogate_then_replace'):
        '''
        fake run_command used for unit testing
        '''

# Generated at 2022-06-22 21:48:52.086523
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    # Test output for a two-line output
    out = b'C\nC.UTF-8\n'
    rc = 0
    err = b''
    m = AnsibleModule(dict())
    m.get_bin_path = lambda x: x
    m.run_command = lambda x: (rc, out, err)

    preference = ['C.UTF-8', 'C']
    # Test preference list beginning with the preferred locale
    assert get_best_parsable_locale(m, preference) == preference[0]
    preference = ['C', 'C.UTF-8']
    # Test preference list with the preferred locale in the middle
    assert get_best_parsable_locale(m, preference) == preference[1]

# Generated at 2022-06-22 21:49:03.226746
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.system import SystemLocale
    from ansible.module_utils.common.sys_info import get_distribution

    # When no other locale is available, the locale module returns 'C' locale
    locale_mock = {
        'path': ('/bin/locale',),
        'stdout_lines': (),
        'warnings': [],
        'changed': False,
        'rc': 0,
        'stdout': ''
    }

    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    module.run_command = SystemLocale.run_command
    module.get_bin_path = SystemLocale.get_bin_path
    module.get_distribution = lambda: get_

# Generated at 2022-06-22 21:49:10.569116
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import os
    import pytest

    # only run tests if locale is installed
    rc, _, _ = AnsibleModule(
    ).run_command(['locale', '-a'])
    if rc != 0:
        pytest.skip("locale is not installed")

    test_module = AnsibleModule(
        argument_spec=dict(
            preferences=dict(type='list', default=None)
        )
    )

    # check that we get the first preferred locale
    test_module.params['preferences'] = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    found = get_best_parsable_locale(test_module)
    assert found == 'C.utf8'

    # when preferred

# Generated at 2022-06-22 21:49:21.380167
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Unit test function for get_best_parsable_locale
    '''

    class AnsibleModuleStub:
        '''
            AnsibleModule stub for testing get_best_parsable_locale
        '''

        def get_bin_path(self, command, required=False):
            '''
                AnsibleModule get_bin_path stub for testing get_best_parsable_locale
            '''
            if command == "locale":
                return "/usr/bin/locale"
            else:
                return None

        def run_command(self, command):
            '''
                AnsibleModule run_command stub for testing get_best_parsable_locale
            '''

# Generated at 2022-06-22 21:49:25.283074
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system import SystemFactCollector
    from ansible.module_utils._text import to_bytes

    # We want to test a scenario where a locale isn't found
    # This test is against the SystemFactCollector, because it
    # calls get_best_parsable_locale
    # We need to mock the module - so we will do that as well
    # We will set the run_command method to return the output we
    # want it to.
    def run_command_return_non_asupported_locale(*args, **kwargs):
        output_str = "abc123\n"
        output_str += "C.UTF-8\n"

# Generated at 2022-06-22 21:49:35.961666
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})

    # test invalid locale tool
    module.get_bin_path = lambda x: ''
    assert get_best_parsable_locale(module) == 'C'

    # test locale tool, with only 'C' locale
    module.get_bin_path = lambda x: 'locale'
    module.run_command = lambda x: (0, 'C', None)
    assert get_best_parsable_locale(module) == 'C'

    # test locale tool, with only 'C' locale, but with no output
    module.get_bin_path = lambda x: 'locale'
    module.run_command = lambda x: (0, '', None)
    assert get_best_pars

# Generated at 2022-06-22 21:49:44.559075
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    By mocking the AnsibleModule class, we manage
    the return code, the standard output, and the
    error output of the command 'locale -a', and
    compare the returned value to the expected one.

    We do this in order to test our function in
    the various use cases (and not only in the
    default one).
    '''

# Generated at 2022-06-22 21:49:54.851787
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Import required python modules for unit testing
    import sys
    import os
    import shutil
    from ansible.module_utils.basic import AnsibleModule

    # Import required mocker modules for unit testing
    from tests.unit.mock.ansible_module import AnsibleModuleTestCase
    from tests.unit.mock.ansible_module import DIR

    # Create system 'locale' tool wrapper
    LOCALE_TOOL = os.path.join(DIR, "unit/ansible")
    os.mkdir(LOCALE_TOOL)

    # Create system locales
    LOCALE_AVAILABLE = ["de", "en", "fr"]
    LOCALE_AVAILABLE_OUTPUT = '\n'.join(LOCALE_AVAILABLE)

    # Create wrapper 'locale' tool

# Generated at 2022-06-22 21:50:02.866611
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    ''' test for the above get_best_parsable_locale '''
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    # creating class to mock AnsibleModule
    class MockAnsibleModule():
        def __init__(self, params):
            self._params = params

        def get_bin_path(self, name, required=False):
            if self._params['_bin_path']:
                return self._params['_bin_path']
            return None

        def run_command(self, cmd):
            if self._params['_rc'] is not None:
                return (self._params['_rc'], self._params['_out'], self._params['_err'])
            return (0, "", "")

    # tests

# Generated at 2022-06-22 21:50:14.150753
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule, get_platform
    from ansible.module_utils.pycompat24 import get_exception
    import os
    import sys

    if get_platform() not in ('Linux',):
        msg = 'Test skipped: locale will not work on platform: %s' % get_platform()
        raise SkipTest(msg)

    class FakeAnsibleModule(object):
        @staticmethod
        def run_command(args, **kwargs):
            if args == ['locale', '-a']:
                retval = 0
                output = 'en_US.utf8\nen_US_POSIX\nen_US\nC\nPOSIX\nC.utf8\nklingon'
                stderr

# Generated at 2022-06-22 21:50:25.190385
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Import is here because this unit test is run in isolation, outside of the
    # Ansible test framework, which means the module is not loaded.
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    module.get_bin_path = lambda x: x
    module.run_command = lambda x: (0, x, '')
    module.run_command.__name__ = 'run_command'  # AnsibleModule.run_command is not mocked properly

    # test for the C locale
    assert get_best_parsable_locale(module, preferences=['C']) == 'C'

    # test for the POSIX locale
    assert get_best_parsable_locale(module, preferences=['POSIX']) == 'POSIX'

    # test

# Generated at 2022-06-22 21:50:34.928829
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.basic import AnsibleModule

    # Mock module
    module = AnsibleModule(argument_spec={})

    module.run_command = lambda cmd: 0, ['en_US.utf8', 'C.utf8'], ''
    module.get_bin_path = get_bin_path
    assert get_best_parsable_locale(module) == 'en_US.utf8'

    # Expected preference is C.utf8.
    module.run_command = lambda cmd: 0, ['C.utf8', 'C', 'en_US.utf8'], ''
    assert get_best_parsable_locale(module) == 'C.utf8'

    # Expected preference is C.utf8.

# Generated at 2022-06-22 21:50:36.596262
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'  # default POSIX

# Generated at 2022-06-22 21:50:46.929357
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import os
    import json
    import mock
    import sys
    import tempfile
    from ansible.module_utils._text import to_bytes

    # Make a temp directory to store the fixtures
    tmpdir = tempfile.mkdtemp()


# Generated at 2022-06-22 21:50:55.379697
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    """Test the get_best_parsable_locale function"""

    import os
    import sys
    import tempfile

    # This is a fake AnsibleModule to pass to the get_best_parsable_locale function
    class FakeAnsibleModule:

        def __init__(self, **kwargs):
            self.params = kwargs
            self.module_name = 'ansible.module_utils.basic'

        def get_bin_path(self, cmd, required=False, opt_dirs=[]):
            """
            This is a fake get_bin_path func that always returns the path to the current command
            """

            return os.path.abspath(os.path.expanduser(cmd))
