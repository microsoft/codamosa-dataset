

# Generated at 2022-06-22 21:41:05.655861
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''Test function get_best_parsable_locale'''

    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    # the test module doesn't include locale, so test for this
    assert get_best_parsable_locale(module) == 'C'

    # when we mock the module to include locale, it should work as intended
    module.get_bin_path = lambda x: 'locale'
    locale_output = '''C
C.UTF-8
de_DE.utf8
en_US.utf8
POSIX
'''
    module.run_command = lambda x: (0, locale_output, '')

# Generated at 2022-06-22 21:41:14.523567
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    cases = [
        {'raw_preferences': None, 'expected': 'C'},
        {'raw_preferences': ['C.utf8', 'en_US.utf8', 'C', 'POSIX'], 'expected': 'C'},
        {'raw_preferences': ['C.utf8', 'en_US.utf8', 'POSIX', 'C'], 'expected': 'en_US.utf8'}
    ]

    class DummyModule:
        def get_bin_path(name):
            if name == 'locale':
                return locale
            else:
                return None

        def run_command(args):
            if args[0] == 'locale' and args[1] == '-a':
                return 0, available, ''
            else:
                return -1, '',

# Generated at 2022-06-22 21:41:16.934372
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None) == 'C'

# Generated at 2022-06-22 21:41:28.744912
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    import ansible.module_utils.basic
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-22 21:41:40.382893
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class AnsibleModule:
        def __init__(self):
            self.params = {
                "module_utils": {
                    "basic": {
                        "AnsibleModule": self
                    }
                },
                "warnings": [],
                "changed": False,
                "parsed_locales": [
                    "C",
                    "en_US.UTF-8",
                    "it_IT.UTF-8",
                ]
            }
        def fail_json(self, **kwargs):
            raise Exception()

        def get_bin_path(self, command):
            return command

        def run_command(self, command):
            if command[0] == 'locale':
                return (0, '\n'.join(self.params['parsed_locales']), '')

# Generated at 2022-06-22 21:41:51.061557
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''test_get_best_parsable_locale'''

    # TODO: test with ssh key only auth
    # TODO: test with 2FA

    from ansible.module_utils import basic
    from ansible.module_utils.common.text.converters import to_text

    module = basic.AnsibleModule(argument_spec={})
    module.exit_json = lambda: None

    assert to_text(get_best_parsable_locale(module)) == 'C'
    assert to_text(get_best_parsable_locale(module, preferences=['POSIX', 'foo'])) == 'POSIX'
    assert to_text(get_best_parsable_locale(module, preferences=['foo'])) == 'C'

# Generated at 2022-06-22 21:42:00.442459
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    import os
    import tempfile
    import traceback

    # The test code is kept in a separate function to make testing easier.
    # It's not a great idea to do this, because it forces the use of global
    # variables.  However, this is a testing function and not a real module,
    # so we make an exception here.
    #
    # The test code is as simple as possible.  It mocks up an AnsibleModule
    # and then calls the function under test.  A whole test suite could be
    # written against the function to ensure it's correct, but that's not
    # necessary for such a small function.  We just want to ensure that the
    # function runs to completion.

# Generated at 2022-06-22 21:42:09.927258
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Unit test for function get_best_parsable_locale
    '''
    import os
    import unittest
    import mock

    test_environment = {'PATH' : os.path.join(os.path.dirname(os.path.realpath(__file__)), 'test_data', 'bin')}

    # Testcase for normal use
    with mock.patch.dict(os.environ, test_environment, clear=True):
        from ansible.module_utils.basic import AnsibleModule

        # Testcase for normal use
        module = AnsibleModule(argument_spec={})
        locale = get_best_parsable_locale(module)
        assert locale == 'C.utf8', "Expected C.utf8, got %s" % locale

        # Testcase for normal use
       

# Generated at 2022-06-22 21:42:21.202155
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    ''' Test case list for get_best_parsable_locale functionality '''

# Generated at 2022-06-22 21:42:32.362057
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    # a fake module object to be passed to get_best_parsable_locale
    module = AnsibleModule(argument_spec={})
    module.run_command = lambda x, y=None: (0, "C\nC.utf8\nPOSIX\nen_US.utf8\nen_US", "")

    # just check if we get the right locale
    locale = get_best_parsable_locale(module)
    assert locale == 'C.utf8'

    # change order of preferred locales and check
    # that returned value is now 'POSIX'
    module.run_command = lambda x, y=None: (0, "C\nC.utf8\nPOSIX\nen_US.utf8\nen_US", "")


# Generated at 2022-06-22 21:42:41.114943
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import mock
    import os

    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']

    out_data = "POSIX\nC\nen_US.utf8\nC.utf8"
    out = mock.Mock(rc=0, stdout=out_data, stderr=None)
    module = mock.Mock(run_command=out, get_bin_path=os.path.expanduser('~/.ansible/tmp/ansible_locale_payload')) # noqa

    res = get_best_parsable_locale(module, preferences)
    assert res == 'POSIX'

    out_data = "POSIX\nC\nen_US.utf8\nC.utf8"

# Generated at 2022-06-22 21:42:51.227906
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Python 3
    try:
        from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    except ImportError:
        AnsibleUnsafeText = None

    # Python 2
    if AnsibleUnsafeText is None:
        try:
            from ansible.utils.unicode import to_unicode as to_text
        except ImportError:
            to_text = to_unicode
    else:
        to_text = to_native

    from ansible.module_utils.basic import AnsibleModule

    # Parameterized data

# Generated at 2022-06-22 21:43:00.462760
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    m = ansible.module_utils.basic.AnsibleModule(argument_spec={})

    # Successfully find the right locale
    assert m.get_best_parsable_locale(['en_US.utf8']) == 'en_US.utf8'
    assert m.get_best_parsable_locale(['en_US.utf8', 'C.utf8', 'C', 'POSIX']) == 'C.utf8'
    assert m.get_best_parsable_locale(['C.utf8', 'C', 'POSIX']) == 'C.utf8'
    assert m.get_best_parsable_locale(['C', 'POSIX']) == 'C'
    assert m.get_best_parsable_

# Generated at 2022-06-22 21:43:05.243519
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None) == 'C'

    # Test with a locale CLI module
    module = get_locale_cli_module()
    assert get_best_parsable_locale(module, ['some-not-supported-locale']) == 'C'
    assert get_best_parsable_locale(module, ['C.utf8']) == 'C.utf8'
    assert get_best_parsable_locale(module, ['C', 'C.utf8']) == 'C'
    assert get_best_parsable_locale(module, ['C.utf8', 'C']) == 'C.utf8'

# Tests that can't run on Travis due to locale issues on Linux Docker containers

# Generated at 2022-06-22 21:43:14.261842
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    ''' Test case:
        Test get_best_parsable_locale() with a variety of scenarios
    '''

    import unittest
    import BaseHTTPServer
    import urllib2

    from ansible.module_utils.basic import AnsibleModule

    class MockLocaleModule(object):

        def __init__(self, name):
            pass

        def get_bin_path(self, name):
            return 'locale'

        def run_command(self, command):
            if command[0].endswith('locale') and command[1] == '-a':
                return 0, 'C\nen_US.utf8\nanother locale\n', ''
            return 1, '', ''

    # Create mock request handler so we can test locale web server

# Generated at 2022-06-22 21:43:24.832441
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    """
    Tests for get_best_parsable_locale
    """
    from ansible.module_utils.basic import AnsibleModule

    class MockModule(object):
        def __init__(self, locale='C', stderr='', returncode=0):
            self.run_command_return = returncode, locale, stderr

        def get_bin_path(self, locale):
            return locale

        def run_command(self, args):
            return self.run_command_return


# Generated at 2022-06-22 21:43:36.158057
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3
    import os
    import os.path
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    my_env = os.environ.copy()
    prefs = ['C', 'POSIX', 'en_US.utf8', 'C.utf8']
    # Run in a different LC_ALL env to test
    my_env['LC_ALL'] = 'POSIX'
    if PY3:
        my_env['LANG'] = 'POSIX'

# Generated at 2022-06-22 21:43:47.756411
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    ansible_module = AnsibleModuleMock()

    ansible_module.get_bin_path = lambda *args, **kwargs: "/usr/bin/locale"

    ansible_module.run_command = lambda *args, **kwargs: (0, "C\nen_US.utf8\n", "")
    assert get_best_parsable_locale(ansible_module) == "en_US.utf8"

    ansible_module.run_command = lambda *args, **kwargs: (0, "C\nen_US.utf8\n", "")
    assert get_best_parsable_locale(ansible_module, preferences=['C.utf8']) == "C"

    ansible_module.run_command = lambda *args, **kwargs: (1, "", "")

# Generated at 2022-06-22 21:43:58.903412
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys

    # Mock an AnsibleModule instance for a unit test
    class AnsibleModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, name, required=False):
            return sys.executable

        # Mock subprocess.check_output in AnsibleModule
        def run_command(self, args, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False):
            return 0, None, None

    module = AnsibleModule()

    # Test locales the module will use and add more if needed
    test_locales = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']

# Generated at 2022-06-22 21:44:02.244915
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    module.debug('foo')
    preferences = ['C.utf8', 'POSIX', 'en_US.utf8']
    assert get_best_parsable_locale(module, preferences) == 'C.utf8'

# Generated at 2022-06-22 21:44:13.193260
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    test_preferences = ['de_DE.utf8', 'en_US.utf8', 'en_GB.utf8']
    test_output = """
    C
    C.UTF-8
    de_DE
    de_DE.iso88591
    de_DE.iso885915@euro
    de_DE.utf8
    en_US
    en_US.iso88591
    en_US.iso885915@euro
    en_US.utf8
    en_GB.utf8
    POSIX
    """.strip().splitlines()


# Generated at 2022-06-22 21:44:20.020365
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.common.process import get_bin_path
    import pytest
    assert 'locale' in get_bin_path('locale')
    module_mock = mock.MagicMock()
    module_mock.check_mode = False
    module_mock.no_log = False
    module_mock.run_command.return_value = (0, 'C\tC.UTF-8\n', '')
    module_mock.get_bin_path.return_value = 'locale'
    assert get_best_parsable_locale(module_mock) == 'C'

# Generated at 2022-06-22 21:44:30.911924
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    test_module = type('test_module',(object,),dict(get_bin_path=lambda self, value: True))
    test_module.run_command = lambda self, value: (0, "C.utf8\nen_US.utf8\nen_UK.utf8", '')
    test_module = test_module()
    assert get_best_parsable_locale(test_module) == 'C.utf8'
    assert get_best_parsable_locale(test_module, preferences=['en_US.utf8']) == 'en_US.utf8'
    assert get_best_parsable_locale(test_module, preferences=['en_US.utf8', 'en_UK.utf8']) == 'en_US.utf8'
    assert get_best_parsable

# Generated at 2022-06-22 21:44:36.505602
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None, ['C.utf8', 'en_US.utf8', 'C', 'POSIX'], raise_on_locale=False) == 'C'
    assert get_best_parsable_locale(None, ['C.utf8'], raise_on_locale=False) == 'C'
    assert get_best_parsable_locale(None, ['C'], raise_on_locale=False) == 'C'
    assert get_best_parsable_locale(None, ['POSIX'], raise_on_locale=False) == 'C'

# TODO: Uncomment following lines to run unit test.
# from ansible.module_utils.basic import AnsibleModule
# test_get_best_parsable_locale()

# Generated at 2022-06-22 21:44:42.756385
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    test_module = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )
    assert type(get_best_parsable_locale(test_module)) == str

# Generated at 2022-06-22 21:44:50.393812
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    from ansible.module_utils.basic import AnsibleModule

    assert get_best_parsable_locale(AnsibleModule(
        argument_spec={}
    ), raise_on_locale=True) == 'C'
    # sys.platform is used to determine whether to include the 'C' locale at the end of the
    # preferences list.  Test both cases, where sys.platform is 'win32' and where it is not.
    for platform in ('win32', 'darwin'):
        preferences_when_not_win32 = ['C.utf8', 'en_US.utf8', 'POSIX', 'C']
        preferences_when_win32 = ['C.utf8', 'en_US.utf8', 'POSIX']
        sys.platform = platform
        assert get_best_parsable

# Generated at 2022-06-22 21:44:54.934084
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.common.removed import removed
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict())

    assert get_best_parsable_locale(module, preferences=None, raise_on_locale=False) == 'C'

    assert get_best_parsable_locale(module, preferences=['ko_KR'], raise_on_locale=False) == 'C'

    assert get_best_parsable_locale(module, preferences=['ko_KR', 'C.utf8'], raise_on_locale=False) == 'ko_KR'

# Generated at 2022-06-22 21:45:05.742746
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    def check_locale(preferences, exp_result):
        '''
            Unit test helper
        '''
        module = AnsibleModule(argument_spec={})
        module.get_bin_path = lambda _x: '/usr/bin/locale'
        # Test with and without module context
        with module.check_mode:
            result = get_best_parsable_locale(module, preferences, True)
        assert result == exp_result

        result = get_best_parsable_locale(module, preferences, True)
        assert result == exp_result

    # Test with an emulated locale -a invocation
    module = AnsibleModule(argument_spec={})

# Generated at 2022-06-22 21:45:09.945479
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Mocked AnsibleModule
    class MockModule:

        def __init__(self):
            self.ansible_os_family = 'Linux'

        def get_bin_path(self, tool):
            return '/bin'

        def run_command(self, command):
            return 0, "", ""

    assert get_best_parsable_locale(MockModule()) == 'C'

# Generated at 2022-06-22 21:45:16.690090
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # First, declare fake module
    class FakeModule():
        def __init__(self, fail_json_in, rc_in, out_in, err_in):
            self.fail_json = fail_json_in
            self.rc = rc_in
            self.out = out_in
            self.err = err_in

        def get_bin_path(self, name=None):
            if name == 'locale':
                return 'locale'
            else:
                return None

        def run_command(self, command_list=None):
            return (self.rc, self.out, self.err)

    # Now, lets do tests
    # Test 1: Succeed
    m = FakeModule(None, 0, 'en_US.utf8\nC.utf8\n', None)
    assert get

# Generated at 2022-06-22 21:45:29.182341
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None) == 'C'
    assert get_best_parsable_locale(None, ['C', 'POSIX']) == 'C'
    assert get_best_parsable_locale(None, ['C.UTF-8', 'POSIX']) == 'C'
    assert get_best_parsable_locale(None, ['C.UTF-8', 'POSIX']) == 'C'
    assert get_best_parsable_locale(None, ['de_DE', 'de_DE.UTF-8', 'C.UTF-8', 'POSIX']) == 'de_DE.UTF-8'

# Generated at 2022-06-22 21:45:39.674790
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import ModuleLoader
    from ansible.module_utils.common._collections_compat import MutableMapping

    the_loader = ModuleLoader()

    the_play_context = PlayContext()

    the_module = the_loader._create_module_from_plugin(
        object_path='ansible.builtin.ping',
        play_context=the_play_context,
        shared_loader_obj=the_loader
    )

    the_play_context.connection = 'local'
    the_play_context._connection_info = MutableMapping()

    the_module = the_module(
        argument_spec = {},
        supports_check_mode = False
    )

    the_module.run()

# Generated at 2022-06-22 21:45:51.330836
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    mymodule = AnsibleModule({})

    # Test that the module will return C on a system
    # with nothing in the preferences list
    preferences = []
    selected_locale = get_best_parsable_locale(mymodule, preferences=preferences, raise_on_locale=False)
    assert selected_locale == 'C'

    # Test that when raise_on_locale is set, the module will raise
    # an exception on a system with nothing in the preferences list
    try:
        get_best_parsable_locale(mymodule, preferences=preferences, raise_on_locale=True)
    except RuntimeError:
        assert 1 == 1    # Success if we entered the exception block
    else:
        assert 0 == 1    #

# Generated at 2022-06-22 21:45:58.007967
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    To unit test this function, break the function in to two parts.
    Call this function and use the last two args to get the 'found' string.
    '''

    result = get_best_parsable_locale(module=None, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX'], raise_on_locale=False)
    assert result == 'C'

# Generated at 2022-06-22 21:46:05.426120
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    preferences_valid = ['en_US.utf8', 'en_US.UTF-8', 'POSIX']
    preferences_invalid = ['es_ES.utf8', 'es_CO.UTF-8', 'mx_MX']

    # The return value must be in preferences_valid,
    # if there is a match, or 'C' otherwise.

    assert get_best_parsable_locale([], preferences_valid) in preferences_valid
    assert get_best_parsable_locale(None, preferences_invalid) == 'C'
    assert get_best_parsable_locale([], None) == 'C'

# Generated at 2022-06-22 21:46:10.616349
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    # Actual linux
    module = AnsibleModule({}, check_invalid_arguments=False)
    prefs = ['fr_FR.utf8', 'C.utf8', 'C.UTF-8', 'C']
    assert get_best_parsable_locale(module, prefs) == 'fr_FR.utf8'

    # Best POSIX locale
    module = AnsibleModule({}, check_invalid_arguments=False)
    prefs = ['fr_FR.utf8']
    assert get_best_parsable_locale(module, prefs) == 'C'

    # Weird empty locale
    module = AnsibleModule({}, check_invalid_arguments=False)
    prefs = ['', 'fr_FR.utf8']
   

# Generated at 2022-06-22 21:46:19.515358
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Test get_best_parsable_locale for expected locale results
    '''


# Generated at 2022-06-22 21:46:27.317347
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    def run_command(cmd, **kwargs):
        class Response:
            def __init__(self, rc, out, err):
                self.rc = rc
                self.out = out
                self.err = err
        if 'C' in cmd:
            rc = 0
            out = 'C\nen_US.utf8\nC.utf8\nen_US\nC.iso885915\n'
        else:
            rc = 1
            out = ''
        return (rc, out, '')

    def get_bin_path(filename, **kwargs):
        return '/bin/locale'

    def fail_json(msg):
        raise RuntimeError(msg)


# Generated at 2022-06-22 21:46:37.104997
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils import basic

    module = basic.AnsibleModule(
        argument_spec=dict(
            test_opt=dict(type="str")
        )
    )

    assert get_best_parsable_locale(module=module) == "C"

    assert get_best_parsable_locale(module=module, preferences=["C", "POSIX"]) == "C"
    assert get_best_parsable_locale(module=module, preferences=["POSIX", "C"]) == "C"

    assert get_best_parsable_locale(module=module, preferences=["en_US.utf8", "POSIX", "C"]) == "en_US.utf8"

# Generated at 2022-06-22 21:46:49.022341
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible import module_utils

    class FakeModule(object):
        def __init__(self, bin_paths):
            self.bin_paths = bin_paths

        def get_bin_path(self, name):
            return self.bin_paths[name]

        def run_command(self, args):
            return (0, '', '')

    class TestCase():
        def __init__(self, name, expected_return_value, bin_paths=None):
            self.name = name
            self.expected_return_value = expected_return_value
            self.bin_paths = bin_paths

    test_cases = dict()
    test_cases['no bin_path'] = TestCase('return default, no bin_path', 'C', bin_paths=None)
    test_

# Generated at 2022-06-22 21:46:56.126907
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class fake_module:
        def __init__(self):
            self.run_command_rc = 0

        def get_bin_path(self, cmd):
            return cmd

        def run_command(self, cmd, environ_update=None, check_rc=True, data=None):
            return self.run_command_rc, "a b c d e f".split(), ""

    def test_func(locale_output, expectations):
        fake_module.run_command_rc = 0
        fake_module.run_command_out = "\n".join(locale_output)

        for preference, expectation in expectations.items():
            if isinstance(preference, tuple):
                preference, raise_on_locale = preference
            else:
                raise_on_locale = False

            # fixup #for the test

# Generated at 2022-06-22 21:47:05.540096
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    import unittest

    class MockAnsibleModule():
        def __init__(self):
            pass

        def get_bin_path(self, name):
            return 'locale'

        def run_command(self, cmd):
            cmd_to_response = {
                ['locale', '-a']:
                {'rc': 0, 'out': "C\nen_US.UTF-8\ntr_TR.UTF-8\nC.UTF-8\n", 'err': None},
                ['locale', '-a', '-u']:
                {'rc': 0, 'out': None, 'err': 'locale: Cannot set LC_ALL to default locale: No such file or directory\n'}
            }

            response = cmd_to_response[cmd]

# Generated at 2022-06-22 21:47:14.024945
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    module = AnsibleModule(argument_spec=dict())

    # Create a list of locales supported by the system
    rc, out, err = module.run_command([module.get_bin_path('locale'), '-a'])
    available = out.split('\n')

    # The list of locale should not be empty
    assert available

    # Check that the first preference is supported.
    assert preferences[0] in available or preferences[1] in available or preferences[2] in available or preferences[3] in available

    # Check that the returned locale is in the supported locales
    assert get_best_parsable_locale(module, preferences) in available

# Generated at 2022-06-22 21:47:25.313724
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Setup test
    class fake_module:
        def __init__(self):
            self.run_command_paths = []
            self.run_command_rc_values = []
            self.run_command_out_values = []
            self.run_command_err_values = []
            self.run_command_call_count = 0

        def get_bin_path(self, *args, **kwargs):
            return "locale"

        def run_command(self, args, *kwargs):
            self.run_command_call_count += 1
            self.run_command_paths.append(args[0])
            rc = self.run_command_rc_values.pop(0)
            out = self.run_command_out_values.pop(0)
            err = self.run_command

# Generated at 2022-06-22 21:47:29.782863
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule()
    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, preferences=['EN_US.utf8']) == 'C'

# Generated at 2022-06-22 21:47:40.458992
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys

    if sys.version_info >= (3, 0):
        from unittest.mock import MagicMock
    else:
        from mock import MagicMock

    locale = '/usr/bin/locale'
    module = MagicMock(name='ansible.module_utils.basic.AnsibleModule')
    module.get_bin_path.return_value = locale
    test_locale = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    # test when output from locale command is empty
    module.run_command.return_value = (0, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # test when locale is not found

# Generated at 2022-06-22 21:47:48.099717
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Set up a module, needed by the tested function.
    class MyModule():
        def __init__(self):
            self.run_command_rc = 0
            self.run_command_out = 'C\nen_US.utf8\n'
        # Gets the path of the given executable
        # This is the test implementation.
        def get_bin_path(self, exe):
            return '/usr/bin/locale'
        # Runs the given command
        # This is the test implementation.
        def run_command(self, args):
            return (self.run_command_rc, self.run_command_out, '')

    # Reset return values to obtain the desired test results.
    module = MyModule()
    module.run_command_rc = 0

# Generated at 2022-06-22 21:47:56.395351
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import b

    #  we expect 'C' locale
    assert get_best_parsable_locale(AnsibleModule(argument_spec={})) == 'C'

    #  we specify an unavailable locale
    pref = ['unavailable_locale_xyz']
    assert get_best_parsable_locale(AnsibleModule(argument_spec={}), pref) == 'C'

    # We specify a locale, the second one is unavailable
    pref = ['en_US.utf8', 'unavailable_locale_xyz']
    assert get_best_parsable_locale(AnsibleModule(argument_spec={}), pref) == 'en_US.utf8'

    # We specify a locale,

# Generated at 2022-06-22 21:48:04.130631
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Test get_best_parsable_locale function
    '''

    from ansible.module_utils.basic import AnsibleModule

    class TestModule(object):
        def __init__(self, bin_path, err_msg, out_msg, rc):
            self.bin_path = bin_path
            self.err_msg = err_msg
            self.out_msg = out_msg
            self.rc = rc

        def get_bin_path(self, path):
            if path == 'locale':
                return self.bin_path
            else:
                return None

        def run_command(self, cmd):
            if cmd == ['locale', '-a']:
                return self.rc, self.out_msg, self.err_msg

    #  test with preferences=None and raise

# Generated at 2022-06-22 21:48:13.429715
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils import basic
    import os

    os.environ['LC_ALL'] = 'en_US.UTF-8'
    os.environ['LANG'] = 'en_US.UTF-8'
    os.environ['LANGUAGE'] = 'en_US.UTF-8'
    preferences = ['C.utf8', 'en_US.utf8', 'C']

    module = basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    assert get_best_parsable_locale(module, preferences) == 'C.utf8'

    os.environ['LC_ALL'] = 'C.UTF-8'
    os.environ['LANG'] = 'C.UTF-8'

# Generated at 2022-06-22 21:48:19.452943
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import os
    import sys
    import tempfile
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common._collections_compat import Mapping

    # Simulate the AnsibleModule class
    test_module = type('test_module', (object,), {
        '__file__': __file__,
        'params': {},
        'fail_json': lambda self, **kwargs: sys.exit(4),
        'get_bin_path': lambda self, _: None,
        'run_command': lambda self, command: None,
        'check_mode': False})

    ANSIBLE_PLUGINS = os.path.join(tempfile.gettempdir(), 'ansible_plugins')

    # simulate various systems

# Generated at 2022-06-22 21:48:30.022984
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    preferences = ['C', 'POSIX', 'C.UTF-8']
    found = get_best_parsable_locale(module, preferences, False)
    assert found == 'C'
    preferences = ['C', 'POSIX', 'C.UTF-8']
    found = get_best_parsable_locale(module, preferences, True)
    assert found == 'C'
    preferences = ['en_US', 'POSIX', 'C.UTF-8']
    found = get_best_parsable_locale(module, preferences, False)
    assert found == 'C'
    preferences = ['C.UTF-8', 'POSIX', 'C']
    found = get_best_parsable

# Generated at 2022-06-22 21:48:41.715704
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Locale function is not available
    assert get_best_parsable_locale(module=None, preferences=None, raise_on_locale=False) == 'C'

    # No preferred locale is specified, return C by default
    assert get_best_parsable_locale(module=None, preferences=[], raise_on_locale=False) == 'C'

    # test with locale
    assert get_best_parsable_locale(
        module=None,
        preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX'],
        raise_on_locale=False
    ) == 'C'

    # test with locale, but the preference is not available, return 'C' by default

# Generated at 2022-06-22 21:48:47.920870
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    dmodule = AnsibleModule(  # noqa=F405
        argument_spec=dict(),
    )

    # try to find the locale from preferences
    assert get_best_parsable_locale(dmodule, ['en_US.utf8']) == 'en_US.utf8'

    # default to 'C' if nothing found
    assert get_best_parsable_locale(dmodule, ['asd']) == 'C'

# Generated at 2022-06-22 21:48:57.755785
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import mock

    # Use mock module to simulate running locale -a and receiving a specific locale list
    locale = mock.Mock(return_value=({'rc': 0, 'stdout': 'C\nen_US.UTF-8\nen_US.utf8\nen_US\n', 'stderr': ''}))

    # IMPORTANT - when setting the class_to_mock in the with statement, you must use the full path
    #             to the module including the name of the file.
    with mock.patch('ansible.modules.system.get_best_parsable_locale.AnsibleModule', locale=locale):
        from ansible.modules.system import get_best_parsable_locale
        assert get_best_parsable_locale is not None
        ansible_module = get_best_

# Generated at 2022-06-22 21:49:06.972828
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=False,
    )

    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, ['fr_FR.utf8']) == 'C'
    assert get_best_parsable_locale(module, ['C.utf8', 'C', 'POSIX']) == 'C'
    assert get_best_parsable_locale(module, ['POSIX', 'C.utf8', 'C']) == 'POSIX'

# Generated at 2022-06-22 21:49:19.347421
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    test_module = AnsibleModule()
    test_module.run_command = fake_run_command
    test_module.get_bin_path = lambda x: x

    # Check for the provided locale in the list of supported locales
    assert get_best_parsable_locale(test_module, ['C']) == 'C'
    assert get_best_parsable_locale(test_module, ['C.UTF-8']) == 'C.UTF-8'

    # Check for the most appropriate locale
    assert get_best_parsable_locale(test_module) == 'C.UTF-8'

    # Check when the locale tool is not available

# Generated at 2022-06-22 21:49:22.816937
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None, None) == 'C'
    assert get_best_parsable_locale(None, ['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'

test_get_best_parsable_locale()

# Generated at 2022-06-22 21:49:33.080571
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.basic import AnsibleModule

    # locale -a command to execute
    CMD_RC = 0
    CMD_OUT = "C.utf8\nen_US.utf8\nC\nPOSIX\n"
    CMD_ERR = ""

    # function to mock module.run_command
    def dummy_run_command(self, args, check_rc=False, close_fds=True, executable=None, data=None, binary_data=False):
        return (CMD_RC, CMD_OUT, CMD_ERR)

    # function to mock os.path.isfile
    def dummy_os_path_isfile(file_path):
        return True

    # function to mock module.

# Generated at 2022-06-22 21:49:37.905564
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    test_module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(test_module) in ['C.utf8', 'en_US.utf8', 'C', 'POSIX']

# Generated at 2022-06-22 21:49:45.520907
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # stub out get_bin_path and run_command so we can focus on our function
    def get_bin_path_stub(module):
        # always pretend we found it
        return True

    def run_command_stub(module, cmd):
        # pretend some of our locales are available and some are not
        available = ['C', 'POSIX', 'en_US.utf8', 'C.utf8']
        return 0, '\n'.join(available), ''

    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.plugins.loader import base_loader
    from ansible.module_utils.common.process import AnsibleProcess
    from ansible.executor.process.result import ProcessResult

    # create a stubbed out AnsibleModule

# Generated at 2022-06-22 21:49:55.422557
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils import common_koji
    from ansible.module_utils.six import PY2, PY3
    from ansible.module_utils import six

    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']

    # if we want to test with no locale installed (e.g. container)
    module = AnsibleModule(argument_spec={})
    assert common_koji.get_best_parsable_locale(module, preferences) == 'C'

    # if we have installed the locales in our systems
    module = AnsibleModule(argument_spec={})
    assert common_koji.get_best_parsable_locale(module, preferences, True) in preferences

    # if

# Generated at 2022-06-22 21:50:02.960100
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # This mocking is not ideal, but this is due to the fact that module is an import var.
    # The alternative is to pass it as an argument but that would change the code
    # of get_best_parsable_locale
    import ansible.module_utils.basic
    module = ansible.module_utils.basic.AnsibleModule(argument_spec={})

    # Set the locale to one of the default ones
    module.run_command = lambda x: (1, "", "")
    assert get_best_parsable_locale(module) == "C"

    # Set the locale to one of the preferred ones
    module.run_command = lambda x: (0, "C.utf8", "")
    assert get_best_parsable_locale(module) == "C.utf8"

# Generated at 2022-06-22 21:50:14.249565
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Define some mock data to feed to the module
    test_cases = [
        {
            "input": {"bin_path": "not_a_bin", "run_command": "bad_run_command"},
            "output": None,
        },
        {
            "input": {"bin_path": None, "run_command": "bad_run_command"},
            "output": None,
        },
        {
            "input": {"bin_path": None, "run_command": None},
            "output": "C",
        },
        {
            "input": {"bin_path": None, "run_command": None},
            "output": "C",
        },
    ]

    # Run our tests
    import ansible.module_utils.basic
    for test_case in test_cases:
        ansible

# Generated at 2022-06-22 21:50:25.304979
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict()
    )

    assert(get_best_parsable_locale(module) == 'C')
    assert(get_best_parsable_locale(module) == 'C')
    assert(get_best_parsable_locale(module) == 'C')
    assert(get_best_parsable_locale(module) == 'C')

    preferences = ['C', 'C.utf8', 'POSIX']
    assert(get_best_parsable_locale(module, preferences) == 'C')

    preferences = ['POSIX', 'C.utf8', 'C', 'POSIX']

# Generated at 2022-06-22 21:50:31.787740
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    am = AnsibleModule(argument_spec=dict())

    # NOTE(retr0h): Use locale that's only available in English.
    preferences = ['en_US.utf8', 'en_GB.utf8']

    # NOTE(retr0h): When this raises an exception
    # and the caller wants to continue, it should use the 'C' locale.
    found = get_best_parsable_locale(am, preferences)
    assert found == 'en_GB.utf8'

# Generated at 2022-06-22 21:50:43.673029
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    class FakeModule(AnsibleModule):

        def get_bin_path(self, executable_name, required=True):
            if executable_name == 'locale':
                return 'locale'
            else:
                return None

        def run_command(self, cmd_list):
            if cmd_list[1] == '-a':
                return (0, "en_US.utf8\nen_US.utf8\nC.utf8", "")
            else:
                return (0, "", "")

    module = FakeModule(argument_spec={})

    assert get_best_parsable_locale(module) == 'C.utf8'

    module2 = FakeModule(argument_spec={})
    assert get_best_parsable

# Generated at 2022-06-22 21:50:53.064758
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # The function's return depends on the output of 'locale -a', which is
    # defined by the user's environment and thus cannot be tightly controlled.
    # However, we can ensure that the default return value is 'C' and that
    # the resulting string is one of the values in preferences.

    from ansible.module_utils.basic import AnsibleModule

    preferences = ['a', 'b', 'c', 'd']
    class MockPopen(object):
        def __init__(self, *args, **kwargs):
            self.returncode = 0
            self.communicate = self.fake_communicate

        def fake_communicate(self):
            output = [] if self.returncode != 0 else preferences
            return '\n'.join(output), ''

    module = AnsibleModule(argument_spec=dict())

# Generated at 2022-06-22 21:51:00.702072
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import iteritems
    from ansible.module_utils.six.moves import StringIO
