

# Generated at 2022-06-22 21:40:55.799915
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six.moves import cStringIO as StringIO

    # create our own module to use with the function
    class FakeModule:
        # required for AnsibleModule()._handle_aliases()
        _ANSIBLE_ARGS = []

        def __init__(self, *args, **kwargs):
            self.no_log_values = []
            self.params = kwargs

        def get_bin_path(self, arg, *args, **kwargs):
            if arg == 'locale':
                # simulate we have the tool
                return 'locale'
            else:
                return None


# Generated at 2022-06-22 21:40:57.749172
# Unit test for function get_best_parsable_locale

# Generated at 2022-06-22 21:41:06.424097
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Unit test for the get_best_parsable_locale function.
    '''
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY2

    test_module = AnsibleModule(argument_spec=dict())

    # Test without preferences
    if PY2:
        test_module.run_command = lambda x, environ_update=None, binary_data=None:\
            (0, 'C\nen_US.utf8', '')
    else:
        test_module.run_command = lambda x, environ_update=None, binary_data=None:\
            (0, b'C\nen_US.utf8', b'')
    assert get_best_parsable_locale(test_module) is 'C'



# Generated at 2022-06-22 21:41:14.931857
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    locale = 'C'
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    assert get_best_parsable_locale(locale, preferences) == 'C'
    preferences = ['C.utf8', 'en_US.utf8', 'POSIX']
    assert get_best_parsable_locale(locale, preferences) == 'C'
    preferences = ['en_US.utf8', 'C', 'POSIX']
    assert get_best_parsable_locale(locale, preferences) == 'POSIX'
    preferences = ['en_US.utf8', 'POSIX']
    assert get_best_parsable_locale(locale, preferences) == 'POSIX'
    preferences = ['POSIX', 'en_US.utf8']


# Generated at 2022-06-22 21:41:23.697880
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # We need to import the module to test, but the module depends on
    # get_best_parsable_locale, so we need to import that first!
    this_module = __name__
    __import__(this_module)
    import sys
    a = sys.modules[this_module]
    a.get_best_parsable_locale(a, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX'], raise_on_locale=True)

    # Should fail without raise_on_locale set
    b = sys.modules[this_module]
    b.get_best_parsable_locale(b, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX'], raise_on_locale=False)

# Generated at 2022-06-22 21:41:35.447899
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class FakeModule(object):
        def __init__(self):
            self.fail_json = lambda msg: msg
            self.run_command = self.fake_run_command
            self.get_bin_path = self.fake_get_bin_path

        def fake_run_command(self, cmd):
            if cmd[1] == '-a':
                return 0, 'C\nen_US.utf8\nC.utf8\nPOSIX', None
            return -1, None, None

        def fake_get_bin_path(self, binary):
            return binary

    fake_module = FakeModule()

    # Test when preferences are None
    test_locale = get_best_parsable_locale(fake_module)
    assert test_locale == "C.utf8"

    # Test when

# Generated at 2022-06-22 21:41:45.681651
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Unit test for function get_best_parsable_locale
    '''

    # Test standard case
    # Test return 'C' when fail to find best locale
    assert get_best_parsable_locale(None, preferences=None, raise_on_locale=False) == 'C'
    assert get_best_parsable_locale(None, preferences=['en_US.utf8'], raise_on_locale=False) == 'C'
    assert get_best_parsable_locale(None, preferences=['C.utf8'], raise_on_locale=False) == 'C'

    # Test return correct preferred locale

# Generated at 2022-06-22 21:41:56.879254
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils import basic
    import copy

    # Setup module instance
    cli_args = ('./hacking/test-module', )
    ns = basic._load_params()
    module = basic.AnsibleModule(argument_spec={}, supports_check_mode=True, no_log=True, namespace=ns, cli_args=cli_args)

    # Mock preferences
    module.run_command = lambda x: (1, 'de_DE.utf8', '')
    assert get_best_parsable_locale(module, preferences=['de_DE.utf8', 'C', 'POSIX'], raise_on_locale=True) == 'C'

    # Mock preferences with no parsable locale
    module.run_command = lambda x: (0, '', '')
    assert get

# Generated at 2022-06-22 21:42:08.202886
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import StringIO
    import sys
    import unittest

    try:
        from io import StringIO
    except ImportError:
        pass

    save_stdout = sys.stdout

# Generated at 2022-06-22 21:42:19.182664
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils import basic
    from ansible.module_utils.common._collections_compat import namedtuple

    class FakeModule(object):
        def __init__(self):
            self.params = {
                'name': 'FakeModule'
            }
            self.fake_rc = 0
            self.fake_out = 'C.UTF-8\nen_US.UTF-8\nen_US.UTF8\nen_US.utf8\nen_US.C\nenUS'
            self.fake_err = ''

        def fail_json(self, *args, **kwargs):
            return {'failed': True}

        def get_bin_path(self, *args, **kwargs):
            return '/usr/bin/locale'


# Generated at 2022-06-22 21:42:27.312007
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils import basic
    args = {}
    connections = {}
    sut = basic._ANSIBLE_ARGS
    sut.update(args)
    sut['ANSIBLE_MODULE_ARGS'] = sut
    sut['ANSIBLE_CONNECTION'] = connections
    sut['ANSIBLE_MODULE_NAME'] = ""
    sut['ANSIBLE_MODULE_PATH'] = ""
    sut['ANSIBLE_MODULE_REQUIRED_IF'] = ""
    sut['ANSIBLE_MODULE_REQUIRED_WITH'] = ""
    sut['ANSIBLE_MODULE_SUPPORTED_HASH_ALGORITHMS'] = ""
    sut['ANSIBLE_MODULE_REQUIRE_ARGS'] = True
    sut['ANSIBLE_DEBUG'] = False


# Generated at 2022-06-22 21:42:38.064021
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    import ansible.modules.system.locale as locale

    # Setup
    test_bin_path = '/bin:/usr/bin'
    test_fail_json = True
    test_msg = 'I fail because that is my purpose in life'
    test_preferences = ['C', 'POSIX']

    class AnsibleModuleFake:

        def __init__(self, fail_json=False):
            self._fail_json = fail_json

        def get_bin_path(self, program, required=False, opt_dirs=[]):
            if program == 'locale':
                return test_bin_path
            return ''

        def run_command(self, cmd):
            return (0, 'A\nB\nC', '')


# Generated at 2022-06-22 21:42:45.454996
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    #
    # Test 1: Verify that function returns C if locale command
    #         is not present.
    #
    test_module = None
    locale = get_best_parsable_locale(test_module)
    assert locale == 'C'

    #
    # Test 2: Verify that function returns C if locale command
    #         execution fails.
    #
    test_module = module_mock({})
    locale = get_best_parsable_locale(test_module)
    assert locale == 'C'

    #
    # Test 3: Verify that function returns C if locale command
    #         returns empty difference.
    #
    test_module = module_mock({}, rc=0, out='\n')
    locale = get_best_parsable_locale(test_module)
    assert locale

# Generated at 2022-06-22 21:42:51.064571
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Runs the unit test for function get_best_parsable_locale
        :returns: None
    '''

    locale_test_cases = get_test_cases()

    # iterate through test cases to run function and assertion
    for item in locale_test_cases:
        test_case = item.get('test_case')
        expected_result = item.get('expected_result')

        # run function and assertion
        assert get_best_parsable_locale(test_case) == expected_result


# Generated at 2022-06-22 21:43:00.377716
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleFallbackNotFound
    from ansible.module_utils.six import PY3

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False,
    )

    # Test the standard case on a non-C locale system
    if PY3:
        assert module.get_best_parsable_locale() == 'C.utf8', 'Default locale output differs from v2'

    else:
        assert module.get_best_parsable_locale() == 'C', 'Default locale output differs from v2'

    # Test the raise_on_locale=True case

# Generated at 2022-06-22 21:43:11.618507
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Tests that get_best_parsable_locale returns what we expect.
    '''

# Generated at 2022-06-22 21:43:23.105135
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    am = AnsibleModule(argument_spec={'preferences': dict(type='list', required=False)})
    am.exit_json = exit_json
    am.run_command = run_command


# Generated at 2022-06-22 21:43:34.635781
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils._text import to_text
    import pytest

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts import ansible_facts

    class ModuleTest(AnsibleModule):
        def __init__(self, *args, **kwargs):
            super(ModuleTest, self).__init__(*args, **kwargs)
            self.facts = ansible_facts(self)

    module = ModuleTest(argument_spec={}, supports_check_mode=False)
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    module.get_bin_path = lambda x: None

    # Attempt to use locale, should raise RuntimeWarning and return C

# Generated at 2022-06-22 21:43:41.632456
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    locale.setlocale(locale.LC_ALL, '')
    assert(locale.getpreferredencoding() == get_best_parsable_locale())
    assert(locale.getpreferredencoding() == get_best_parsable_locale(preferences=[locale.getpreferredencoding()]))
    assert('utf8' == get_best_parsable_locale(preferences=['utf8']))
    assert('C' == get_best_parsable_locale(preferences=['utf8', locale.getpreferredencoding()]))
    assert('C' == get_best_parsable_locale(preferences=['utf8', 'utf8']))

# Generated at 2022-06-22 21:43:42.426962
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    pass

# Generated at 2022-06-22 21:43:48.840027
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    sys.modules['__main__'] = sys.modules['ansible.module_utils.basic']
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.locales import get_best_parsable_locale

    module = AnsibleModule(
        argument_spec = dict(),
    )

    best_locale = get_best_parsable_locale(module, preferences=['en_US.utf8', 'en_US.UTF-8', 'C.utf8', 'C.UTF-8', 'C'])
    assert best_locale == 'C'

# Generated at 2022-06-22 21:43:55.405939
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None, ['en_US.utf8', 'en_US', 'C']) == 'en_US.utf8'
    assert get_best_parsable_locale(None, ['en_US.utf8', 'C']) == 'en_US.utf8'
    assert get_best_parsable_locale(None, ['en_US', 'C']) == 'C'
    assert get_best_parsable_locale(None, ['C']) == 'C'

# Generated at 2022-06-22 21:44:02.422762
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    class MockModule(AnsibleModule):
        '''
        Mimics the ansible module object and mocks run_command()
        '''
        def run_command(self, cmd, environ_update=None, check_rc=True, cwd=None, stdin=None, data=None):
            '''
            Mimics:
            https://github.com/ansible/ansible/blob/devel/lib/ansible/module_utils/basic.py#L181
            '''
            locale_cmd = ['/usr/bin/locale', '-a']
            en_us_utf8_cmd = ['/usr/bin/locale', '-a', 'en_US.utf8']

# Generated at 2022-06-22 21:44:09.626793
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    import imp

    class AnsibleModule(object):
        def __init__(self, argument_spec, bypass_checks=False, no_log=False,
                     check_invalid_arguments=True, mutually_exclusive=None, required_together=None,
                     required_one_of=None, add_file_common_args=False, supports_check_mode=False):
            self.argument_spec = argument_spec
            self.bypass_checks = bypass_checks
            self.no_log = no_log
            self.check_invalid_arguments = check_invalid_arguments
            self.mutually_exclusive = mutually_exclusive or []
            self.required_together = required_together or []
            self.required_one_of = required_one_of or []
            self.add_file_common

# Generated at 2022-06-22 21:44:14.292133
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = MockModule()
    if module.get_bin_path("locale"):
        assert get_best_parsable_locale(module) is not None
    else:
        assert get_best_parsable_locale(module, raise_on_locale=True) is None



# Generated at 2022-06-22 21:44:18.351893
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    best_locale = None
    try:
        import ansible.module_utils.basic as basic

        module = basic.AnsibleModule(argument_spec={})
        best_locale = get_best_parsable_locale(module)
    except:
        pass
    assert best_locale is not None

# Generated at 2022-06-22 21:44:30.257408
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY2
    from mock import patch, call, Mock

# Generated at 2022-06-22 21:44:38.566800
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule({})
    assert get_best_parsable_locale(module) == 'C'

    module = AnsibleModule({})
    assert get_best_parsable_locale(module, preferences=['en_US.utf8', 'en_US.UTF-8']) == 'C'

    module = AnsibleModule({})
    assert get_best_parsable_locale(module, preferences=['en_US.utf8', 'en_US.UTF-8'], raise_on_locale=True) == 'C'

    module = AnsibleModule({})
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX'])

# Generated at 2022-06-22 21:44:48.287612
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    def test_bin_path(name):
        if name == "locale":
            return "/usr/bin/locale"
        else:
            return None

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.pycompat24 import get_exception

    class TestAnsibleModule(AnsibleModule):
        def __init__(self):
            super(TestAnsibleModule, self).__init__()
            self.result = dict()

        def fail_json(self, **args):
            raise AnsibleFailJson(args)


# Generated at 2022-06-22 21:44:49.823634
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    assert get_best_parsable_locale(AnsibleModule()) == 'C'

# Generated at 2022-06-22 21:44:58.174831
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(),
    )

    try:
        found = get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX'], raise_on_locale=True)
        assert found == 'C' or found == 'POSIX'
    except RuntimeWarning:
        assert 'module.run_command()' in 'AnsibleModule'
    except Exception as e:
        assert 'ansible.module_utils.basic.AnsibleModule' in 'AnsibleModule'

# Generated at 2022-06-22 21:45:00.713663
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    m = AnsibleModule({})
    assert get_best_parsable_locale(m) is not None

# Generated at 2022-06-22 21:45:10.004445
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.basic import AnsibleModule
    import pytest

    class AnsibleModuleFake(AnsibleModule):

        def run_command(self, command):
            # Note: the first element is 'locale'
            if command[1] == '-a':
                return (0, '\n'.join(['C', 'en_US.utf8', 'C.utf8', 'POSIX']), None)

    result_1 = get_best_parsable_locale(AnsibleModuleFake(), ['C', 'POSIX', 'C.utf8', 'en_US.utf8'])
    assert result_1 == 'C'


# Generated at 2022-06-22 21:45:15.175698
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # import module snippets
    from ansible.module_utils.basic import AnsibleModule

    # the test module, required
    # noinspection PyPep8
    module = AnsibleModule(
         argument_spec=dict()
    )

    print("##################################################################################")
    print("Test 1")
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    found = get_best_parsable_locale(module, preferences)
    assert(found in preferences)
    print("Found: %s" % found)

    print("##################################################################################")
    print("Test 2:")
    print("Test running with no preferences")
    found = get_best_parsable_locale(module)
    print("Found: %s" % found)


# Generated at 2022-06-22 21:45:22.772535
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    m = AnsibleModule(argument_spec={})

    # first test that we get the default locale when locale is missing
    assert get_best_parsable_locale(m) == 'C'

    # next test that we get a particular locale when we supply a match in preferences
    assert get_best_parsable_locale(m, preferences=['POSIX']) == 'POSIX'

    # now test that we get the default locale when there is no match in preferences
    assert get_best_parsable_locale(m, preferences=['asdf']) == 'C'

# Generated at 2022-06-22 21:45:30.895838
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import socket
    import tempfile

    ansible = AnsibleModule(argument_spec={})

    try:
        # save current locale
        test_locale = get_best_parsable_locale(ansible, raise_on_locale=True)
    except RuntimeError as e:
        # if we can't determine locale, set to 'C'
        test_locale = 'C'

    # set to test locale
    # NOTE: tested on CentOS 6.7
    fd, tmp_file = tempfile.mkstemp()
    os.close(fd)
    ansible.run_command(['locale', '-a'], check_rc=True)

# Generated at 2022-06-22 21:45:36.968582
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
      The test is to test the function get_best_parsable_locale
    '''
    try:
        from ansible.module_utils.basic import AnsibleModule
    except ImportError:
        raise ImportError("Unable to import AnsibleModule")

    module = AnsibleModule(argument_spec=dict())
    best_locale = get_best_parsable_locale(module)

    import os
    if not os.path.exists('/usr/bin/locale'):
        assert best_locale == 'C'
    elif os.path.exists('/usr/bin/locale'):
        assert best_locale == 'C.utf8'

    module = None

# Generated at 2022-06-22 21:45:44.439318
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic

    # This requires AnsibleModule

    class CliModule(object):
        def __init__(self, run_command=None):
            self.run_command = run_command

        def get_bin_path(self, path):
            return path

    m = CliModule()

    # Test with empty locale output
    m.run_command = lambda x: (0, '', '')
    assert 'C' == get_best_parsable_locale(m, raise_on_locale=True)

    m.run_command = lambda x: (1, '', '')
    try:
        get_best_parsable_locale(m, raise_on_locale=True)
        assert False
    except RuntimeWarning:
        pass

    # Test with empty locale

# Generated at 2022-06-22 21:45:55.029165
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # import Ansible module and AnsibleModule class
    from ansible.compat.tests.mock import patch
    from ansible.module_utils.basic import AnsibleModule
    import random

    # mock AnsibleModule
    mod = AnsibleModule(argument_spec=dict())

    # mock get_bin_path to return /usr/bin

# Generated at 2022-06-22 21:46:04.465670
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Fake get_best_parsable_locale with a generator
    def best_locale(*args):
        skip = False
        # The first time it is called return a valid value
        # the second time return an invalid value
        for value in ['C', None]:
            if skip:
                skip = False
                continue
            skip = True
            yield value


    # Test with a valid locale
    best_locale_gen = best_locale()
    locale = get_best_parsable_locale(None, None, raise_on_locale=True)
    assert locale == next(best_locale_gen)

    # Test with an invalid locale
    best_locale_gen = best_locale()

    import pytest
    with pytest.raises(RuntimeWarning):
        locale = get_best_p

# Generated at 2022-06-22 21:46:15.577553
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # using required=False to test failure on empty
    from ansible.module_utils.basic import AnsibleModule

    test_module = AnsibleModule({})
    assert get_best_parsable_locale(test_module, raise_on_locale=True) == 'C'

    test_module = AnsibleModule({})
    assert get_best_parsable_locale(test_module, ['C', 'en_US.utf8'], raise_on_locale=True) == 'C'

    test_module = AnsibleModule({})
    assert get_best_parsable_locale(test_module, ['c', 'en_US.utf8'], raise_on_locale=True) == 'C'

    test_module = AnsibleModule({})
    assert get_best_parsable_loc

# Generated at 2022-06-22 21:46:24.607448
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    # below is example output for locale -a
    example_output = '''
C
C.UTF-8
de_DE.utf8
en_US.utf8
POSIX
'''
    # Below is the class we are mocking, AnsibleModule
    class MockAnsibleModule:
        def __init__(self):
            # make a dict of parameters that matches the above output
            self.params = dict(
                binary='locale',
                arguments='-a',
                rc=0,
                stdout=example_output,
                stderr='',
            )

        def get_bin_path(self, binary):
            # if they specified the binary name, return it
            if binary == self.params['binary']:
                return binary
            return None



# Generated at 2022-06-22 21:46:35.316420
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    test_preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    test_found = 'C'

    # first test with no output
    module = AnsibleModule(fakeargs=[])
    assert get_best_parsable_locale(module) == test_found

    # second test with no preferences
    test_preferences = None
    assert get_best_parsable_locale(module, test_preferences) == test_found

    # third test with empty output
    test_preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    assert get_best_parsable_locale(module, test_preferences) == test_found



# Generated at 2022-06-22 21:46:45.693697
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    # Ensure that a locale of C can be found
    assert get_best_parsable_locale(AnsibleModule(argument_spec={})) == "C"

    # Ensure that a locale of POSIX can be found
    assert get_best_parsable_locale(AnsibleModule(argument_spec={}), ['POSIX', 'C']) == "POSIX"
    assert get_best_parsable_locale(AnsibleModule(argument_spec={}), ['POSIX']) == "POSIX"

    # Ensure that a locale of en_US.utf8 can be found

# Generated at 2022-06-22 21:46:49.657222
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None, ['POSIX', 'C.UTF-8']) == 'POSIX'
    assert get_best_parsable_locale(None, ['POSIX2', 'C.UTF-8']) == 'C.UTF-8'

# Generated at 2022-06-22 21:46:56.655200
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    # no preferences
    assert ('C' in get_best_parsable_locale(AnsibleModule(argument_spec=dict())))

    # preferred match
    assert ('C.utf8' in get_best_parsable_locale(AnsibleModule(argument_spec=dict()), ['C.utf8', 'C']))

    # preferred list exhausted
    assert ('C' in get_best_parsable_locale(AnsibleModule(argument_spec=dict()), ['xyz', 'abc']))

    # no locale available (raises RuntimeWarning)
    from ansible.module_utils import basic
    module = AnsibleModule(argument_spec={})

# Generated at 2022-06-22 21:47:05.749651
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import os
    import tempfile

    def _test_val(mod, exp, **kwargs):
        res = get_best_parsable_locale(mod, **kwargs)
        assert res == exp

    import ansible.module_utils.basic

    # If the locale command succeeds and returns a list,
    # we try to find our preferred locale in that list.
    with tempfile.NamedTemporaryFile(delete=False) as f:
        f.write(b"C\nen_US.utf8\nC.utf8\nPOSIX\n")
        f.close()

# Generated at 2022-06-22 21:47:06.505272
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # TODO: Add unit test for this function
    pass

# Generated at 2022-06-22 21:47:17.925153
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import json
    import tempfile

    from ansible.module_utils.basic import AnsibleModule

    script_full_path = tempfile.mkstemp()[1]
    script_data = '''
    #!/bin/sh
    echo 'en_US.utf8'
    echo 'C'
    '''
    open(script_full_path, 'w').write(script_data)

    module = AnsibleModule({})
    module.get_bin_path = lambda x: script_full_path

    # Normal behavior
    assert get_best_parsable_locale(module) == 'en_US.utf8'

    # User specifies locale
    module = AnsibleModule({'ansible_user_preferred_locales': ['C.utf8', 'C', 'POSIX']})
    module.get_

# Generated at 2022-06-22 21:47:27.130215
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts.collector.locale import get_best_parsable_locale
    from ansible.module_utils.facts.collector.locale import get_locale

    # First test case.  This test case ensures that the get_best_parsable_locale
    # function returns the correct locale when there is no error getting the list
    # of available locales.
    module = AnsibleModule(argument_spec={})
    module.run_command = lambda x: (0, 'POSIX\nen_US.utf8\nen_US.US-ASCII\nC\nC.utf8\n', None)
    test_locale = get_best_parsable_locale(module)
    assert test_locale

# Generated at 2022-06-22 21:47:37.903249
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.locales import get_best_parsable_locale
    from ansible.module_utils._text import to_native


# Generated at 2022-06-22 21:47:45.480500
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common import get_exception

    # test if we can handle when the binary does not exist

    # test if we can handle an invalid locale list
    # test the general use case


if __name__ == '__main__':
    # Let's not waste time on this one
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common import get_exception

    am = AnsibleModule(argument_spec={})

    try:
        result = get_best_parsable_locale(am)
        print("Success: %s" % result)
    except Exception as e:
        print("Error: %s" % get_exception())

# Generated at 2022-06-22 21:47:54.970485
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.basic import AnsibleModule

    # test default locale
    module = AnsibleModule(argument_spec=dict())
    assert get_best_parsable_locale(module) == 'C'

    # test with non-default locale
    preferences = ['en_US.utf8', 'C']
    module = AnsibleModule(argument_spec=dict())
    assert get_best_parsable_locale(module, preferences=preferences) == 'C'

    # test with specific locale that is available
    preferences = ['en_US.utf8', 'C']
    module = AnsibleModule(argument_spec=dict())
    assert get_best_parsable_locale(module, preferences=preferences) == 'C'

    # test with specific locale, but raise_on_locale is

# Generated at 2022-06-22 21:48:02.904388
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    import sys

    class TestModule(object):

        def __init__(self, bin_path=None):
            self.bin_path_cache = bin_path

        def get_bin_path(self, binary):
            return self.bin_path_cache

        def run_command(self, args):
            class Out:
                def __init__(self, lines):
                    self.splitlines = lambda: lines

            # the call to run commands will have args[0] as 'locale'
            if args[1] == '-a':
                return 0, Out(['C', 'en_US.utf8', 'C.utf8']), ''
            else:
                assert(False)

    # Test case 1: passing locales that are present in system will return first matched locale

# Generated at 2022-06-22 21:48:07.011253
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    module = ansible.module_utils.basic.AnsibleModule(argument_spec={})
    # test with an undefined locale
    assert('C' == get_best_parsable_locale(module))



# Generated at 2022-06-22 21:48:11.862424
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict(),
    )

    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-22 21:48:21.892341
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import os
    import sys
    from ansible.module_utils.basic import AnsibleModule

    def mock_run_command(*args, **kwargs):
        return 0, 'C, C.UTF-8, en_US.UTF-8, en_US', ''

    orig_run_command = AnsibleModule.run_command
    AnsibleModule.run_command = mock_run_command

    module = AnsibleModule(argument_spec={}, check_invalid_arguments=False)
    assert get_best_parsable_locale(module, preferences=['C.utf8']) == 'C'
    assert get_best_parsable_locale(module, preferences=['en_US.utf8']) == 'en_US.UTF-8'

# Generated at 2022-06-22 21:48:31.534969
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    import unittest
    import mock
    import sys

    from ansible.module_utils.common.process import get_bin_path

    class ModuleMock:

        def __init__(self):
            self.fail_json = mock.Mock()

        def get_bin_path(self, _locale):
            if _locale == 'locale':
                return get_bin_path(_locale)
            else:
                _locale = ''

        def run_command(self, _locale):
            if _locale[0] == 'locale':
                return 0, 'C', ''
            else:
                return 1, '', 'locale command not found'

    class TestFindLocale(unittest.TestCase):
        '''Test the get best parsable locale function'''


# Generated at 2022-06-22 21:48:42.778816
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    # define a dummy AnsibleModule
    test_ansible_module = AnsibleModule(argument_spec = dict())

    # test_preferences and test_locales is a list of locales
    test_preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    test_locales = ['C', 'C.utf8', 'POSIX']
    expected_locale = 'C'
    assert get_best_parsable_locale(test_ansible_module, test_preferences, test_locales) == expected_locale

    test_locales = ['C', 'POSIX', 'C.utf8']
    expected_locale = 'POSIX'
    assert get_best_parsable_

# Generated at 2022-06-22 21:48:51.061274
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    ansible_module = AnsibleModule({})

    assert get_best_parsable_locale(ansible_module) == 'C'
    assert get_best_parsable_locale(ansible_module, preferences=['C.utf8', 'en_US.utf8', 'C']) == 'C'
    assert get_best_parsable_locale(ansible_module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'

    # Fake module that has no locale command
    class FakeAnsibleModule:
        def __init__(self, params):
            self.params = params
            self.called = False
            self.rc = 1
            self.out = ''
           

# Generated at 2022-06-22 21:49:02.136255
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.basic import AnsibleModule

    try:
        locale = AnsibleModule()
    except:
        locale = None

    # run the test
    print("Test 1: %s" % get_best_parsable_locale(locale, preferences=None, raise_on_locale=False))
    print("Test 2: %s" % get_best_parsable_locale(locale, preferences=None, raise_on_locale=True))
    print("Test 3: %s" % get_best_parsable_locale(locale, preferences=['fr_FR.UTF8'], raise_on_locale=False))

# Generated at 2022-06-22 21:49:10.308095
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # tests mostly use the locale module and not mocks
    # so we need to patch that
    from ansible.module_utils.locale import Locale
    from ansible.module_utils.basic import AnsibleModule

    # pylint: disable=no-member
    # get_bin_path is a member of ModuleBase
    # pylint: disable=protected-access
    # pylint: disable=invalid-name
    # pylint: disable=too-many-locals

# Generated at 2022-06-22 21:49:21.194394
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    # These are all valid locales
    POSIX_LOCALES = ['C.utf8', 'en_US.utf8', 'C', 'POSIX', 'es_MX.utf8', 'fr_CA.utf8', 'de_DE.utf8']
    # These are not valid locales
    INVALID_LOCALES = ['foobar']
    TEST_ARG_SPEC = dict(
        preferences=dict(type='raw'),
    )

    # Test POSIX checking
    m = AnsibleModule(
        argument_spec=TEST_ARG_SPEC,
        supports_check_mode=True
    )

# Generated at 2022-06-22 21:49:32.507793
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import StringIO

    # Fake available locales for this example
    locales_input = '''
C
C.UTF-8
en_US
en_US.utf8
zh_CN.utf8
'''

    # Fake the module input stream
    module = AnsibleModule(
        argument_spec={},
    )
    module._ansible_rm_tmpdir = lambda: None  # noop
    module.run_command = lambda args: (0, StringIO(locales_input).read(), '')

    # no arguments == default
    best_locale = get_best_parsable_locale(module)
    assert best_locale == 'C'

    # Choose from fake locales
    best_locale

# Generated at 2022-06-22 21:49:42.772662
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Mock module with custom methods
    class MockModule(object):
        def get_bin_path(self, cmd):
            if cmd == 'locale':
                return '/bin/locale'
            else:
                return None

        def run_command(self, cmd, environ_update=None, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False):
            out = 'en_US.utf8'
            return 0, out, None

    mod = MockModule()

    found = get_best_parsable_locale(mod)
    assert found == 'en_US.utf8'

    # try invalid locale
    found = None

# Generated at 2022-06-22 21:49:46.325274
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-22 21:49:55.829129
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class _AM_Mock:
        _args = {}
        cmd_results = {}
        cmd_results['run_command'] = [0, 'C\nen_US.utf8\ncxx_CZ.utf8\n', '']
        def __init__(self, **args):
            self._args = args

        def get_bin_path(self, tool):
            if tool == 'locale':
                return '/usr/bin/locale'
            else:
                return None

        def run_command(self, cmd):
            if cmd[1] == '-a':
                return self.cmd_results['run_command']
            else:
                return [1, '', '']


# Generated at 2022-06-22 21:50:03.433417
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import unittest
    import json
    import sys
    import tempfile
    import os
    import re
    import subprocess
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.six import BytesIO


# Generated at 2022-06-22 21:50:07.742527
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic as basic

    module = basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )

    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-22 21:50:09.273810
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(module=None) == 'C'

# Generated at 2022-06-22 21:50:19.074349
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils import basic
    import os
    import tempfile
    import json
    from ansible.compat.tests import unittest

    class FakeModule(object):
        def __init__(self):
            self.run_command_results = []
            self.run_command_calls = []
            self.fail_json_results = []
            self.fail_json_calls = []
            self.logger = basic._AnsibleLoggingAdapter(self)
            self.version_info = (2, 5, 0)

        def exit_json(self, rc=0, msg=''):
            assert(rc == 0)
            assert(msg == '')

        def fail_json(self, msg, rc=1):
            self.fail_json_results.append([msg, rc])
           

# Generated at 2022-06-22 21:50:28.171106
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    class TestModule(AnsibleModule):
        def get_bin_path(self, arg, required=False):
            if arg == "locale":
                return "/usr/bin/locale"
            else:
                return None

        def run_command(self, arg):
            if arg[0] == "/usr/bin/locale":
                if PY3:
                    return 0, 'C.UTF-8\nen_US.UTF-8\nen_US.utf8\nC\nPOSIX', None
                else:
                    return 0, 'C.UTF-8\nen_US.UTF-8\nen_US.utf8\nC\nPOSIX', None

# Generated at 2022-06-22 21:50:36.654732
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    get_best_parsable_locale(None)
    get_best_parsable_locale(None, None)
    get_best_parsable_locale(None, ['test'])
    get_best_parsable_locale(None, [])
    get_best_parsable_locale(None, ['test'], True)
    get_best_parsable_locale(None, [], True)
    get_best_parsable_locale(None, None, True)



# Generated at 2022-06-22 21:50:46.962356
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None, None) == 'C'
    assert get_best_parsable_locale(None, None, True) == 'C'

    class FakeModule:
        def run_command(self, cmd, **kwargs):
            if cmd == ['locale', '-a']:
                return 0, 'C.utf8\nen_US.utf8\nC\nPOSIX\n', ''
            else:
                raise RuntimeError("This code should not have been reached.")

        def get_bin_path(self, prog):
            if prog == "locale":
                return '/usr/bin/locale'
            else:
                raise RuntimeError("This code should not have been reached.")

    # Top preference

# Generated at 2022-06-22 21:50:55.407740
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    test_cases = [
        # test case: <test_name>, <returned_locale>, <is_exception_raised>, <preferences>, <available_locales>
        ["C_locale", "C", False, None, ['C', 'en_US.utf8']],
        ["a_locale_not_available", "C", False, ['en_US.utf8'], ['C']],
        ["unexpected_available_output", "C", False, None, ['']],
        ["preference_locale", "a_locale", False, ['a_locale'], ['C', 'a_locale', 'another_locale']],
    ]

    from ansible.module_utils.basic import AnsibleModule

    for test_case in test_cases:
        preferences = None
        raise_