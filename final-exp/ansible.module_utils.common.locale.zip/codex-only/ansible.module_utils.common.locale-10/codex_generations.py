

# Generated at 2022-06-22 21:41:04.278600
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    import ansible.module_utils.basic as basic_module
    import tempfile
    import subprocess

    # We need to mock out some things for our test
    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.fail_json = lambda x, exit_code=0: exit(exit_code)
            self._debug = False

        def get_bin_path(self, name):
            return name

        def run_command(self, args, check_rc=True):
            stdout = tempfile.NamedTemporaryFile()
            stderr = tempfile.NamedTemporaryFile()
            proc = subprocess.Popen(args, shell=False, stdout=stdout, stderr=stderr)
            proc.wait()
            stdout.seek(0)

# Generated at 2022-06-22 21:41:13.539359
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils._text import to_bytes

    stdout = StringIO()
    ansible.module_utils.basic.AnsibleModule._shared_debug_logger = ansible.module_utils.basic._logger_from_stream(stdout)

    test_module = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict(
            preferences=dict(required=False, type='list'),
            raise_on_locale=dict(required=False, type='bool')
        )
    )


# Generated at 2022-06-22 21:41:22.949266
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import PY3

    class TestModule(object):
        def __init__(self, locale_strings, rc=0, return_stderr=False):
            self._locale_strings = locale_strings
            self._return_stderr = return_stderr
            self._rc = rc

        def get_bin_path(self, _):
            return 'local'

        def run_command(self, cmd, _=None):
            if cmd == ['local', '-a']:
                if self._return_stderr:
                    return self._rc, '', self._locale_strings
                return self._rc, self._locale_strings, ''

# Generated at 2022-06-22 21:41:34.814662
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # test when locale is C, output should return C
    from ansible.module_utils.basic import AnsibleModule
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    import mock

    am = AnsibleModule(
        argument_spec=dict(),
    )
    vm = VariableManager()
    am.params = {}
    am.vars = vm.get_vars(host=HostVars())

    am.get_bin_path = mock.Mock(return_value='/usr/bin/locale')

    am.run_command = mock.Mock(return_value=(0, 'C', ''))

    res = get_best_parsable_locale(am, preferences=['C'])
    assert res == 'C'

    # test

# Generated at 2022-06-22 21:41:45.271584
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # imports for mocking
    import mock
    from ansible.module_utils.basic import AnsibleModule

    # making module mock
    module = mock.Mock(spec=AnsibleModule)
    module.run_command.return_value = (0, "C\nen_US.UTF-8\nen_US.UTF8\n", None)

    # test
    assert get_best_parsable_locale(module) == 'C'

    # test that raise_on_locale=False prevents exception
    module.run_command.return_value = (1, None, "Error")
    assert get_best_parsable_locale(module, raise_on_locale=False) == 'C'

    # test that raise_on_locale=True re-raises exception
    module.run_command.return_

# Generated at 2022-06-22 21:41:56.641161
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict())

    # test available, default preferences
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']

    def run_locale(args):
        return 0, '\n'.join(preferences), ''

    module.run_command = run_locale
    assert get_best_parsable_locale(module) == 'C.utf8'

    # test available, default preferences
    preferences = ['C.utf8', 'en_US.utf8']

    def run_locale(args):
        return 0, '\n'.join(preferences), ''

    module.run_command = run_locale
    assert get_best_parsable_locale

# Generated at 2022-06-22 21:42:07.947548
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import platform

    module = AnsibleModule({})

    # Test if the locale is C
    assert get_best_parsable_locale(module) == 'C'

    # Asserting if the locale is en_US.utf8 for the debian platform
    if platform.dist()[0] == 'debian':
        assert get_best_parsable_locale(module) == 'en_US.utf8'
        assert get_best_parsable_locale(module, ['C.utf8', 'en_US.utf8', 'C', 'POSIX', 'C.utf8']) == 'C.utf8'

    # Asserting if the locale is POSIX when locale -a command fails

# Generated at 2022-06-22 21:42:18.806764
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Test for CentOS 7 locale command
    locale_centos7 = '''C
en_US.utf8
'''
    # Test for CentOS 8 locale command
    locale_centos8 = '''C
en_US.utf8
POSIX
'''
    # Test for Ubuntu 18.04 locale command

# Generated at 2022-06-22 21:42:27.112017
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils import basic
    import pytest

    # Default case
    module = basic.AnsibleModule(argument_spec={})
    result = get_best_parsable_locale(module)
    assert result == 'C'

    # Best case, prefer 'en_US.utf8'
    module = basic.AnsibleModule(argument_spec={})
    result = get_best_parsable_locale(module, preferences=['en_US.utf8'])
    assert result == 'en_US.utf8'

    # Best case, prefer 'en_US.utf8' but only 'C' available
    module = basic.AnsibleModule(argument_spec={})
    result = get_best_parsable_locale(module, preferences=['en_US.utf8'])


# Generated at 2022-06-22 21:42:37.874196
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Setup test case(s):
    test_cases = dict()
    # Test case 1:
    test_cases[1] = dict(
        preferences=None,
        out='C.UTF-8/C/POSIX',
        err='',
        rc=0,
        expected='C'
    )
    # Test case 2:
    test_cases[2] = dict(
        preferences=['en_GB.utf8', 'en_US.utf8'],
        out='C.UTF-8/C/POSIX',
        err='',
        rc=0,
        expected='C'
    )
    # Test case 3:

# Generated at 2022-06-22 21:42:45.335702
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import mock
    import os

    # Mocking the module class, to test the function get_best_parsable_locale()
    mock_module = mock.Mock(spec=dict)

    # Assigning element to dictionary
    mock_module.__dict__ = {
        "module_args": {},
        "params": {}
    }
    # Mocking the function run_command() as it is required by get_best_parsable_locale() 
    mock_module.run_command = mock.Mock(return_value=(0, 'C\nC.UTF-8\nen_US.utf8', ''))

# Generated at 2022-06-22 21:42:47.143785
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    result = get_best_parsable_locale(None)
    assert result == "C"



# Generated at 2022-06-22 21:42:49.451395
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import pytest

    with pytest.raises(RuntimeWarning):
        get_best_parsable_locale(object)

# Generated at 2022-06-22 21:42:58.779950
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    # Note: the 'required' parameter is set to False, as there is no 'locale'
    # in the PATH on some systems (eg, OSX)
    module = AnsibleModule(
        argument_spec=dict(
            locale=dict(type='str', required=False),
            preferences=dict(type='list', required=False),
        ),
    )

    assert module.get_best_parsable_locale(module, raise_on_locale=False) == 'C'
    assert module.get_best_parsable_locale(module, raise_on_locale=True) == 'C'

# Generated at 2022-06-22 21:43:10.627454
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Loading ansible module
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})

    # Test with empty preferences
    preference = None
    assert get_best_parsable_locale(module, preference) == "C"

    # Test with preferences that doesn't exist
    preference = ['fr_FR', 'fr_BE']
    assert get_best_parsable_locale(module, preference) == "C"

    # Test with preferences that exist
    preference = ['fr_FR.utf8', 'POSIX', 'fr_BE']
    assert get_best_parsable_locale(module, preference) == "fr_FR.utf8"

    # Test without preferences and without supported locale

# Generated at 2022-06-22 21:43:17.829854
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from io import StringIO

    # Test with POSIX, C, en_US.utf8
    # POSIX first because that is best for ansible team
    # C is next because its always there
    # en_US.utf8 is last because sometimes its there, but we can't depend on it
    preferences = ['POSIX', 'C', 'en_US.utf8']
    locale = get_best_parsable_locale(AnsibleModule(), preferences=preferences)
    assert locale == 'POSIX'

    # Simulate output as if we ran 'locale -a'
    all_locales = ['C', 'POSIX', 'de_DE', 'de_DE.utf8', 'en_US', 'en_US.utf8']
    all_loc

# Generated at 2022-06-22 21:43:26.952230
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.locales import get_best_parsable_locale

    test_module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )

    found = get_best_parsable_locale(test_module)
    assert found == 'C'

    with test_module.get_bin_path.patcher(test_module):
        test_module.get_bin_path.patcher.is_working = True
        test_module.run_command.patcher.is_working = True

# Generated at 2022-06-22 21:43:37.584166
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Tests the get_best_parsable_locale function
        :return: None
    '''


# Generated at 2022-06-22 21:43:48.263865
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={}, supports_check_mode=False)

    # Mock current locale
    # Note that this mocks the run_command function of AnsibleModule
    def mock_cmd(cmd):
        if cmd == ['locale', '-a']:
            return(0,'C.utf8\nen_US.utf8\nen_US.utf8\nja_JP.utf8\nC','')

    module.run_command = mock_cmd

    # Method to parse unit test results
    def run_test(mod, exp_locale):
        locale = get_best_parsable_locale(module)

# Generated at 2022-06-22 21:43:57.435750
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.text.converters import to_bytes

    class TestArgs:
        pass

    # This test will fail if it cannot locate the 'locale' command on the system
    # and even if it can, the 'locale -a' command might return something other
    # than the specific list below, but we'll just live with that.
    test_args = TestArgs()
    test_args.params = {}
    test_args.tmpdir = None
    test_args.supports_check_mode = None
    test_args.no_log = None
    test_args.add_file_common_args = None
    test_args.warnings = None
    test_args.check_invalid_arguments = None
    test_

# Generated at 2022-06-22 21:44:08.550655
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import os
    import tempfile

    from ansible.module_utils.six import StringIO
    from ansible.module_utils.basic import AnsibleModule

    _, tmpfile = tempfile.mkstemp(prefix="ansible_test_locale_")
    os.remove(tmpfile)
    os.makedirs(tmpfile)
    script = os.path.join(tmpfile, 'locale')
    with open(script, 'w+') as fd:
        fd.write('''#!/bin/sh
echo -e "C.UTF-8\nen_US.UTF-8"
''')
    os.chmod(script, 0o755)
    os.putenv('PATH', "%s:" % tmpfile)

    # First run with one preferred locale

# Generated at 2022-06-22 21:44:18.602092
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    import tempfile
    import os
    import re
    from ansible.module_utils.basic import AnsibleModule

    if hasattr(sys.stdin, 'close'):
        sys.stdin.close()

    if hasattr(sys.stdin, 'fileno'):
        dev_null = os.open(os.devnull, os.O_RDWR)
        os.dup2(dev_null, sys.stdin.fileno())

    fd, tmpfile = tempfile.mkstemp()
    os.close(fd)

    fd, tmpfile_err = tempfile.mkstemp()
    os.close(fd)


# Generated at 2022-06-22 21:44:30.386595
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    """
    This function will unit test the get_best_parsable_locale() function.
    """
    import mock
    import sys

    #
    # The following code is just to create a class that has a run_command
    # instance variable. Right now the only way to do this is to actually
    # run a command against a real module instance.
    #
    my_module = mock.MagicMock()
    my_module.run_command = mock.MagicMock()
    # class that has a fake run_command
    my_class = type('MyClass', (object,), {'run_command': my_module.run_command})
    # instantiate my_class class
    my_object = my_class()


# Generated at 2022-06-22 21:44:34.052310
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule()
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-22 21:44:46.990393
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ..module_utils.basic import AnsibleModule
    import os

    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.fail_json = lambda *args, **kwargs: False
            self.run_command = lambda *args, **kwargs: (0, os.linesep.join(['any.utf-8', 'foo.utf-8', 'bar.utf-8']), '')
            self.get_bin_path = lambda _: 'locale'

        def get_bin_path(self, exe):
            return exe

    module = FakeModule()
    assert 'foo.utf-8' == get_best_parsable_locale(module, ['foo.utf-8'])
    assert 'foo.utf-8' == get_best_pars

# Generated at 2022-06-22 21:44:53.737293
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.text.converters import to_bytes

    module = AnsibleModule(
        argument_spec = dict(
            preferences = dict(type='list', default=None),
            raise_on_locale  = dict(type='bool', default=False)
        )
    )

    preferences = module.params['preferences']
    raise_on_locale = module.params['raise_on_locale']


# Generated at 2022-06-22 21:44:58.611970
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    assert get_best_parsable_locale(None) == 'C'

    try:
        get_best_parsable_locale(None, raise_on_locale=True)
        raise Exception('Expected RuntimeWarning exception to be thrown and not caught')
    except RuntimeWarning:
        pass

# Generated at 2022-06-22 21:45:02.350729
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.basic import AnsibleModule

    assert get_best_parsable_locale(AnsibleModule(arg_spec=[])) == 'C'

# Generated at 2022-06-22 21:45:10.590511
# Unit test for function get_best_parsable_locale

# Generated at 2022-06-22 21:45:19.442197
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # with unsupported preferences
    prefs = ['C.UTF-8', 'en_US.UTF-8', 'C', 'POSIX']
    try:
        get_best_parsable_locale(module, preferences=prefs)
    except RuntimeWarning:
        pass

    # with supported preferences
    prefs = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    try:
        get_best_parsable_locale(module, preferences=prefs)
    except RuntimeWarning:
        assert False

# Generated at 2022-06-22 21:45:26.702196
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = 'TEST'
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']

    class AnsibleModule:

        def __init__(self, test_module):
            self.test_module = test_module

        def get_bin_path(self, name):
            return name

        def run_command(self, command):
            if command[0] == 'locale':
                if self.test_module == 'test_locale_found':
                    out = """
                        C
                        C.UTF-8
                        en_US.utf8
                        POSIX
                    """
                elif self.test_module == 'test_locale_not_found':
                    out = """
                        C
                        C.UTF-8
                        POSIX
                    """,

# Generated at 2022-06-22 21:45:38.740897
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.basic import AnsibleModule

    # Assume locale is not available since it is not included in PATH
    module = AnsibleModule(
        argument_spec={
        },
    )

    # Should return 'C'
    assert get_best_parsable_locale(module) == 'C'

    module.run_command = lambda cmd: (0, "en_US\nfr_FR\n", None)
    # Should return en_US as specified in preferences
    assert get_best_parsable_locale(module, preferences=['en_US', 'POSIX']) == 'en_US'

    # Should return fr_FR since it is the first locale available

# Generated at 2022-06-22 21:45:50.255439
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # When no locale tool is found, return the default C
    module = MockModule('missing_locale_tool')
    assert get_best_parsable_locale(module) == 'C'

    # When the locale tool is found, but outputs an error, return the default C
    def fail_locale(*args, **kwargs):
        return '', "locale: Cannot set LC_CTYPE to default locale: No such file or directory", ''

    module = MockModule('broken_locale', fail_locale)
    assert get_best_parsable_locale(module) == 'C'

    # When there are no output, return the default C
    def no_output_locale(*args, **kwargs):
        return '0', '', ''

# Generated at 2022-06-22 21:45:54.311177
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    if AnsibleModule is None:
        return

    m = AnsibleModule(argument_spec={})
    assert 'en_US.utf8' == get_best_parsable_locale(m)

# Generated at 2022-06-22 21:46:03.854324
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils._text import to_text

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils._text import to_text

    ansible_module = AnsibleModule(argument_spec=dict())

    # first test case: no locale
    ansible_module._has_run = True
    ansible_module.run_command = lambda x, binary_data=False: (
        1,
        to_bytes(''),
        to_bytes(''),
    )

# Generated at 2022-06-22 21:46:15.020405
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class TestModule(object):
        def run_command(self, args):
            if args[1] == '-a':
                return (0, 'C\nen_US.utf8\nen_US\n', '')
            else:
                return (0, '', '')

        def get_bin_path(self, name):
            if name == 'locale':
                return 'locale'
            else:
                return None

    test_module = TestModule()

    assert get_best_parsable_locale(test_module) == 'en_US.utf8'
    assert get_best_parsable_locale(test_module, preferences=['en_US.utf8']) == 'en_US.utf8'

# Generated at 2022-06-22 21:46:23.408194
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible_collections.ansible.community.tests.unit.compat import unittest
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch, MagicMock

    test_cmd = ['locale', '-a']
    test_cmd_out = MagicMock()
    test_cmd_out.strip.return_value = '''
C
POSIX
en_US.utf8
'''
    test_cmd_err = ''
    test_cmd_rc = 0

    class TestModule(object):
        params = {'locale': None}
        fail_json = MagicMock()

    class TestAnsibleModule(object):
        params = {'locale': None}
        fail_json = MagicMock()

# Generated at 2022-06-22 21:46:34.754965
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    import unittest

    class MockModule(object):
        def __init__(self, locale_path, locale_output, run_command_rc, run_command_out, run_command_err):
            self._locale_path = locale_path
            self._locale_output = locale_output
            self._run_command_rc = run_command_rc
            self._run_command_out = run_command_out
            self._run_command_err = run_command_err

        def get_bin_path(self, tool):
            return self._locale_path

        def run_command(self, cmd):
            if self._locale_path and self._locale_output:
                return self._run_command_rc, self._run_command_out, self._run_command_err

           

# Generated at 2022-06-22 21:46:39.248627
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    test_module = AnsibleModule(argument_spec={})

    assert get_best_parsable_locale(test_module, ['en_US.utf8']) == 'C'
    assert get_best_parsable_locale(test_module, ['de_DE.utf8']) == 'C'
    assert get_best_parsable_locale(test_module, ['C.utf8']) == 'C'

# Generated at 2022-06-22 21:46:50.853666
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # pylint: disable=unused-argument
    # pylint: disable=too-few-public-methods
    class AnsibleModule(object):
        class RunCommandResult(object):
            def __init__(self, rc, out, err):
                self.rc = rc
                self.out = out
                self.err = err

        def __init__(self):
            self.params = {'locale': ['C']}

        def get_bin_path(self, tool, required=False):
            return tool


# Generated at 2022-06-22 21:46:57.309603
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Tests to ensure the function get_best_parsable_locale gets
        the correct locale when passed an OS specific list of
        preferences in that order.
    '''

    # Test values
    test_preferences = ['en_US.utf8', 'en_US.UTF-8', 'en_US.utf-8',
                        'C.utf8', 'C.UTF-8', 'C.utf-8',
                        'en_US', 'en.utf8', 'en.UTF-8', 'en.utf-8',
                        'en', 'C', 'POSIX']

    # Ubuntu locale output
    ubuntu_locale_output = '''C
en_US.utf8
POSIX
'''

    # Ubuntu OS

# Generated at 2022-06-22 21:47:00.863550
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    test_module = AnsibleModule({'from_ansible': True})
    assert test_module.get_best_parsable_locale() == 'C'

# Generated at 2022-06-22 21:47:11.234615
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    # Make Ansible think we have a CL
    module = AnsibleModule(argument_spec={})
    module.run_command = lambda argv: (0, '\nC\nC.UTF-8\nC.utf8\nC.utf8\nen_US.utf8\nen_US.UTF-8\n', '')
    assert get_best_parsable_locale(module) == 'en_US.utf8'

    module.run_command = lambda argv: (0, '\nC\nC.UTF-8\nC.utf8\nC.utf8\nen_US.utf8\nen_US.UTF-8\n', '')

# Generated at 2022-06-22 21:47:22.477415
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.modules.extras.system.setup import main as setup_main
    from ansible.compat.tests import mock

    def _get_bin_path(self):
        return self._mock_locale

    def _run_command(self, args):
        if args[0] == self._mock_locale:
            if args[1] == '-a':
                return 0, self._mock_locale_a, ''
        return 1, '', 'error'

    def _fail_json(self, **args):
        raise Exception(args['msg'])

    # If test failed it will not find locale tool and use default 'C'

# Generated at 2022-06-22 21:47:32.699200
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module_args = dict(
        preferences=['en_GB.UTF-8', 'de_DE.UTF-8', 'en_US.UTF-8'],
    )
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )

    assert get_best_parsable_locale(module) == 'C'

    module_args['preferences'] = ['en_US.UTF-8', 'de_DE.UTF-8', 'en_GB.UTF-8']
    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )


# Generated at 2022-06-22 21:47:42.514478
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    # setup test module instance
    module = AnsibleModule(argument_spec=dict())

    # run test cases
    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, ['en_US.utf8', 'C']) == 'en_US.utf8'
    assert get_best_parsable_locale(module, ['en_UK.utf8', 'C']) == 'C'
    assert get_best_parsable_locale(module, ['POSIX', 'C']) == 'C'
    assert get_best_parsable_locale(module, ['C.utf8', 'POSIX', 'C']) == 'C.utf8'



# Generated at 2022-06-22 21:47:53.921814
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Test get_best_parsable_locale for C locale
    '''
    # ansible.module_utils.basic.AnsibleModule
    class MockAnsibleModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, tool):
            '''
            :param tool: the tool to look for
            :return: '' if not found, the tool if found
            '''
            if tool:
                return tool
            else:
                return ''

        def run_command(self, cmd):
            '''
            This runs the command and returns the rc, stdout and stderr
            '''

# Generated at 2022-06-22 21:48:02.176564
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys

    if sys.version_info >= (2, 7):
        import unittest
    else:
        import unittest2 as unittest

    from ansible.module_utils.common.process import get_bin_path

    class FakeModule(object):
        def __init__(self):
            self._locale_path = None

        def run_command(self, args, check_rc=False, close_fds=True, executable=None, data=None, binary_data=False):
            stdout = None
            stderr = None
            rc = 0

# Generated at 2022-06-22 21:48:04.893171
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    assert get_best_parsable_locale(AnsibleModule(argument_spec={})) == 'C'

# Generated at 2022-06-22 21:48:07.990827
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-22 21:48:15.166525
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    # Initializing the AnsibleModule instance
    instance = AnsibleModule(argument_spec=dict())

    # Setting the up data
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']

    # Expected output
    expected_output = 'C'

    # Calling the function and testing that it returns the expected output
    assert(get_best_parsable_locale(instance, preferences) == expected_output)

# Generated at 2022-06-22 21:48:18.997375
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import ansible.constants

    ansible.constants.DEFAULT_HASH_BEHAVIOUR = 'merge'

    module = AnsibleModule({})
    locale = get_best_parsable_locale(module)

    assert locale == 'C'

# Generated at 2022-06-22 21:48:26.998118
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Test text options
    parsed_text_option = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']

    # Test locale options
    locale_options = ['C.utf8', 'en_US.utf8', 'POSIX']

    # Test for text options
    for text_option in parsed_text_option:
        best_text_option = get_best_parsable_locale(locale_options, text_option)
        assert best_text_option == text_option

# Generated at 2022-06-22 21:48:28.095493
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    mod = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(mod)

# Generated at 2022-06-22 21:48:39.290444
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    ansible_module = get_fake_ansible_module()

    rc, out, err = ansible_module.run_command([])
    assert rc == 0
    assert out is not None
    assert err is not None

    try:
        ansible_module.get_bin_path("locale")
        raise AssertionError("get_bin_path locale should not work")
    except RuntimeError:
        pass

    try:
        get_best_parsable_locale(ansible_module, ['en_US.UTF-8'], True)
    except RuntimeWarning as e:
        assert str(e) == "Could not find 'locale' tool"

    ansible_module._executable = 'python'


# Generated at 2022-06-22 21:48:47.919152
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils._text import to_bytes
    import pytest

    # empty run_command returns
    class MockModule:
        def __init__(self, run_commands):
            self._run_commands = run_commands
            self.failed = False
            self.warned = False

        def run_command(self, argv):
            return self._run_commands.pop(0)

        def exit_json(self, **kwargs):
            pass

        def fail_json(self, **kwargs):
            if kwargs.get('msg', '').startswith('locale'):
                self.warned = True
            else:
                self.failed = True

    # see if we ignore locale errors if told to
    module = MockModule([(1, None, None)])
   

# Generated at 2022-06-22 21:48:57.755598
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    locale_list = ['C', 'C.UTF-8', 'en_US.UTF-8', 'it_IT.UTF-8', 'ar_AE.UTF-8', 'ar_AE.eu.UTF-8']
    preferences = [ 'C.UTF-8', 'en_US.UTF-8', 'C', 'POSIX']
    # Test when the first preferecnce in the preference list is available
    assert get_best_parsable_locale(locale_list, preferences) == 'C.UTF-8'
    # Test when the first preferecnce in the preference list is not available
    assert get_best_parsable_locale(locale_list, ['en_US.UTF-8', 'C.UTF-8']) == 'en_US.UTF-8'
    # Test when the first pref

# Generated at 2022-06-22 21:49:08.178157
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from _pytest.monkeypatch import MonkeyPatch
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.basic import to_native

    class AnsibleModuleMock(object):
        def __init__(self):
            self.params = {}
            self.run_command_results = {
                '/bin/bar': (0, 'foo', ''),
                '/usr/bin/locale': (0, 'foo\nbar\nbaz\n', ''),
                '/usr/bin/locale -a': (0, 'foo\nbar\nbaz\n', ''),
            }

        def run_command(self, cmd):
            return self.run_command_results[to_native(cmd)]



# Generated at 2022-06-22 21:49:19.599756
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common._text import to_native
    from ansible.module_utils.common._collections_compat import Mapping
    import os
    import json

    # A base AnsibleModule for us to build off of
    class AnsibleModuleTest(AnsibleModule):
        def __init__(self):
            pass

        def _ansible_argspec(self):
            # We do not need argspec for this test
            pass

        def get_bin_path(self, arg, opt_dirs=None):
            return '/usr/bin/'

        def run_command(self, args):
            args = [to_native(i) for i in args]
            # Simulating get_best_parsable_locale

# Generated at 2022-06-22 21:49:31.168715
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    locale_values = ['C', 'C.utf8', 'fr_FR.utf8', 'Zulu.utf8', 'en_US.utf8', 'POSIX', 'DoesntExist']

    # Test several different preferences against the locale_values,
    # using en_US.utf8 as the best match, and C as the default.
    result = get_best_parsable_locale(AnsibleModule(argument_spec={}), ['en_US.utf8', 'Zulu.utf8', 'POSIX'])
    assert result == 'en_US.utf8'

    result = get_best_parsable_locale(AnsibleModule(argument_spec={}), ['DoesntExist', 'Zulu.utf8', 'POSIX'])

# Generated at 2022-06-22 21:49:41.762134
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.common.process import get_bin_path as get_system_bin
    from ansible.module_utils.six import PY2
    from ansible.module_utils.ansible_release import __version__ as ansible_version

    class TestModule:
        def __init__(self):
            self.bin_path_cache = {}

        def get_bin_path(self, executable):
            return get_system_bin(executable)

        def run_command(self, cmd):
            from ansible.module_utils.basic import run_command
            return run_command(cmd, None, None, False, False, 'all', None, None)

    m = TestModule()

    # RedHat 6.x returns non-zero exit codes when you pass non-valid locales to the CLI
    # Therefore

# Generated at 2022-06-22 21:49:52.941411
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule()
    assert (get_best_parsable_locale(module, preferences=['C']) == 'C')
    assert (get_best_parsable_locale(module, preferences=['C.utf8']) == 'C.utf8')
    assert (get_best_parsable_locale(module, preferences=['C.utf8', 'C.utf8']) == 'C.utf8')
    # When both are present, it should prefer the utf8 version
    assert (get_best_parsable_locale(module, preferences=['C.utf8', 'C']) == 'C.utf8')
    # When invalid locale is passed, it should prefer the next one

# Generated at 2022-06-22 21:49:57.180281
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, ['fake']) == 'C'

# Generated at 2022-06-22 21:50:04.199543
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Mock the module object
    class AnsibleModule():
        def run_command(self, args):
            return (0,'outstream','errstream')
        def get_bin_path(self, args):
            return 'locale'
    class ArgParser():
        def __init__(self, argdict):
            pass
    class AnsibleFailJson():
        def __init__(self, argdict):
            raise Exception("test_get_best_parsable_locale")
    module = AnsibleModule()
    a = get_best_parsable_locale(module)
    assert a == 'C'

# Generated at 2022-06-22 21:50:15.594295
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils import basic
    from ansible.module_utils.common.parameters import get_best_parsable_locale

    module = basic.AnsibleModule(
        argument_spec=dict(
            preferences=dict(required=False, type='list', default=[])
        )
    )

    module.run_command = basic.run_command

    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    rc, out, err = module.run_command(['locale', '-a'])
    available = out.strip().splitlines()

    found = get_best_parsable_locale(module, preferences, raise_on_locale=True)
    assert found in available or found == 'C'

    # In case of no 'locale

# Generated at 2022-06-22 21:50:26.715975
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # POSIX
    assert get_best_parsable_locale(['C', 'POSIX']) == 'C'

    # en_US.UTF-8
    assert get_best_parsable_locale(['en_US.utf8', 'C']) == 'en_US.utf8'

    # first preference
    assert get_best_parsable_locale(['en_US.utf8', 'POSIX', 'C']) == 'en_US.utf8'

    # first ISO
    assert get_best_parsable_locale(['en_US.utf8', 'iso', 'C']) == 'iso'

    # no ISO

# Generated at 2022-06-22 21:50:35.560818
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import os
    import tempfile
    import shutil
    import filecmp
    import platform

    orig_locale = os.environ.get('LC_ALL', 'C')

# Generated at 2022-06-22 21:50:46.346328
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # locale module that allows us to fake locale output
    # it is not a full module, just enough to test the function
    class Fake_Module(object):
        def get_bin_path(self, arg):
            return '/usr/bin/locale'

        def run_command(self, cmd):
            if cmd[1] == '-a':
                output = ['C.utf8', 'en_US.utf8', 'C',
                          'POSIX', 'C.utf8', 'zh_TW.utf8']
                return 0, '\n'.join(output), ''
            else:
                raise RuntimeError('Bad command')

    class Fake_Module_No_Locale(Fake_Module):
        def get_bin_path(self, arg):
            return None


# Generated at 2022-06-22 21:50:58.168807
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.modules.system import _locale_info

    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    locale_info = {
        'C': 'C',
        'POSIX': 'POSIX',
        'en_US.utf8': 'en_US.utf8',
        'en_US.UTF-8': 'en_US.UTF-8',
        'borkedlocale': None,
        'missing_locale': None,
    }
    # add a lot of locales in a random order
    count = 0
    while len(locale_info) <= 25:
        count += 1
        locale_info[str(count)] = str(count)
        available = locale_info.copy()
        available.pop('missing_locale')
