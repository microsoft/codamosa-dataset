

# Generated at 2022-06-22 21:41:04.350758
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    test_get_best_parsable_locale verifies the get_best_parsable_locale
    function returns the expected locale when using the C locale
    '''
    # NOTE: We use the to_native function because Python3 will print
    # bytes instead of a string, but this function is only called
    # with strings so it will always succeed.
    # pylint: disable=deprecated-method
    get_best_parsable_locale_test_class = get_best_parsable_locale_test_class()

    # 1. Test case: The function returns the expected locale when using
    # the C locale.
    result = get_best_parsable_locale_test_class.get_best_parsable_locale(None)
    assert result == 'C'
   

# Generated at 2022-06-22 21:41:13.604059
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

  module = None

  # Make sure we get a default locale
  preferred_locales = None
  preferred_locale = get_best_parsable_locale(module, preferred_locales)
  assert preferred_locale == 'C'

  # Make sure we get a known locale (first of the preferred_locales)
  preferred_locales = ['en_US.utf8', 'en_US.UTF-8', 'en_US.utf-8', 'en_US.UTF8', 'en_US.utf8', 'en_US.US-ASCII']
  preferred_locale = get_best_parsable_locale(module, preferred_locales)
  assert preferred_locale == 'en_US.utf8'

  # Make sure we get a default locale when the preferred locale is not known
  preferred_loc

# Generated at 2022-06-22 21:41:23.010129
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # We need a module to test this function, so we create a fake
    # one for testing purposes

    class FakeModule:

        def __init__(self):
            self.run_command = run_command
            self.get_bin_path = get_bin_path
            self.warn = warn

        def exit(self):
            pass

    # This function is the one which should get mocked
    def get_bin_path(binary):
        if binary == 'locale':
            return None
        else:
            return 'test'

    # We define some fake results for the run_command function

# Generated at 2022-06-22 21:41:34.861409
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # this test code will only be run if the local
    # "ansible/test/utils/get_best_parsable_locale"
    # directory is found in the python path so it
    # will not be running in a normal ansible run

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common._collections_compat import MutableSequence

    import random
    import os

    class TestModule(object):
        def __init__(self):
            self._command_results = tuple()
            self._bin_paths = set()

        def get_bin_path(self, command):
            if command in self._bin_paths:
                return command
            return None

        def run_command(self, cmd, *args, **kwargs):
            return self._command

# Generated at 2022-06-22 21:41:45.310680
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = type('AnsibleModule', (object,), {})()
    module.run_command = lambda *args: (0, 'C', '')
    module.get_bin_path = lambda *args: 'locale'

    found = get_best_parsable_locale(module)
    assert found == "C"

    found = get_best_parsable_locale(module, ['C', 'POSIX'])
    assert found == "C"

    module = type('AnsibleModule', (object,), {})()
    module.run_command = lambda *args: (0, 'POSIX', '')
    module.get_bin_path = lambda *args: 'locale'

    found = get_best_parsable_locale(module)
    assert found == "C"


# Generated at 2022-06-22 21:41:50.675078
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    locale.get_best_parsable_locale(None)
    locale.get_best_parsable_locale(None, ['foo', 'bar', 'baz'])
    try:
        locale.get_best_parsable_locale(None, raise_on_locale=True)
    except RuntimeError:
        pass

# Generated at 2022-06-22 21:42:00.174281
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Pseudo-AnsibleModule to test this function
    class AnsibleModule():
        def __init__(self):
            self.fail_json = self.fail_jsonp

        def fail_jsonp(self, *args, **kwargs):
            pass

        def get_bin_path(self, tool):
            return tool

        def run_command(self, command):
            return (1, "", "")

    module = AnsibleModule()

    # If the first preferred locale is not available on the system, the
    # function should return the next available preferred locale
    pref1 = get_best_parsable_locale(module, ["C", "en_US.utf8"])
    assert(pref1 == "en_US.utf8")

    # If a preferred locale is not available on the system, but the "

# Generated at 2022-06-22 21:42:09.806425
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Test case where locale is not present
    module = AnsibleModule({'locale': 'fakelocale'})
    assert get_best_parsable_locale(module) == 'C'

    module = AnsibleModule({'locale': 'fakelocale'}, False)
    assert get_best_parsable_locale(module, raise_on_locale=True) == 'C'

    # Test case where locale is present, but we have no preferences
    module = AnsibleModule({'locale': 'C.utf8'})
    assert get_best_parsable_locale(module) == 'C.utf8'

    module = AnsibleModule({'locale': 'C.utf8'}, False)
    assert get_best_parsable_locale(module, raise_on_locale=True)

# Generated at 2022-06-22 21:42:13.793353
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    test_module = AnsibleModule(argument_spec={})
    assert test_module.get_bin_path('locale')
    assert to_native(get_best_parsable_locale(test_module)) != ''

# Generated at 2022-06-22 21:42:16.743337
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = get_best_parsable_locale(False, {'en_US.utf8', 'C.utf8'})
    assert module == 'en_US.utf8'

# Generated at 2022-06-22 21:42:25.970926
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Test get_best_parsable_locale function
        :returns: Boolean
    '''

    class FakeModule(object):
        def __init__(self, locale, locale_list, locale_err):
            self.locale = locale
            self.locale_list = locale_list
            self.locale_err = locale_err

        def get_bin_path(self, cmd):
            return self.locale

        def run_command(self, cmd, check_rc=True):
            status = 0
            if self.locale_err:
                status = 1
            return status, self.locale_list, self.locale_err

    good_locale_list = ''
    for locale in ['en_IN', 'C.utf8', 'POSIX', 'C']:
        good

# Generated at 2022-06-22 21:42:36.631523
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils import basic
    import platform

    class AnsibleModuleFake(object):
        def __init__(self, params):
            self.params = params
            self.check_mode = False

        def get_bin_path(self, name, required=False):
            if name == 'locale':
                return '/usr/bin/locale'
            return None

        def run_command(self, args, check_rc=True):
            return 0, '', ''

    assert get_best_parsable_locale(AnsibleModuleFake({}), raise_on_locale=False) == 'C'

    class AnsibleModuleFake(object):
        def __init__(self, params):
            self.params = params
            self.check_mode = False


# Generated at 2022-06-22 21:42:37.258866
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    pass

# Generated at 2022-06-22 21:42:41.286297
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict()
    )
    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, ['nonexistinglocale']) == 'C'

# Generated at 2022-06-22 21:42:48.093127
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    preferences = ['foo', 'bar']
    from ansible.modules.remote_management.network import CLI
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=CLI.argument_spec,
        supports_check_mode=False
    )

    result = get_best_parsable_locale(module, preferences)
    assert result == 'C'



# Generated at 2022-06-22 21:42:58.314389
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.basic import AnsibleModule

    test_module = AnsibleModule(
        argument_spec = dict()
    )

    # Test with default preferences
    best_locale = get_best_parsable_locale(test_module)
    assert best_locale == 'C', 'Default best parsable locale test failed'

    # Test with non-existent preferences
    best_locale = get_best_parsable_locale(test_module, preferences = ['foo', 'bar'])
    assert best_locale == 'C', 'Non-existent best locale test failed'

    # Test with existing preference
    # Note: This is not a valid locale to use by itself in many cases, but is an existing locale

# Generated at 2022-06-22 21:43:10.394536
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    import ansible.module_utils.basic

    am = ansible.module_utils.basic.AnsibleModule(argument_spec={}, supports_check_mode=True)

    # determine if LC_ALL=C works
    try:
        assert to_native(get_best_parsable_locale(am, raise_on_locale=True)) == 'C'
    except RuntimeWarning:
        pass

    # determine if LC_ALL=C.UTF-8 works
    am.params = {'preferences': ['C.utf8']}
    try:
        assert to_native(get_best_parsable_locale(am, raise_on_locale=True)) == 'C.utf8'
    except RuntimeWarning:
        pass

    # determine if LC_

# Generated at 2022-06-22 21:43:18.276351
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    class FakeModule:
        def __init__(self, locale, rc, stdout):
            self.locale = locale
            self.rc = rc
            self.stdout = stdout

        def run_command(self, args):
            if self.locale:
                rc, stdout = 0, self.locale
                stderr = ''
            else:
                rc, stdout, stderr = args[1:]
            return int(self.rc), stdout, stderr

        def get_bin_path(self, name):
            if name == 'locale':
                return self.locale

    # Test 1: locale exists and the output is the first one of preferences

# Generated at 2022-06-22 21:43:27.984458
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import StringIO

    module = AnsibleModule(
        argument_spec=dict()
    )

    # simulate no locale command
    module.get_bin_path = lambda x: None
    assert get_best_parsable_locale(module) == 'C'

    # simulate no output from locale
    module.get_bin_path = lambda x: '/usr/bin/locale'
    module.run_command = lambda x: (0, None, None)
    assert get_best_parsable_locale(module, raise_on_locale=True) == 'C'

    # simulate locale command failing
    module.get_bin_path = lambda x: '/usr/bin/locale'
    module.run_command

# Generated at 2022-06-22 21:43:38.210003
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    # available locales
    avail = '''
C
C.UTF-8
en_US.utf8
POSIX
    '''
    # preferences
    pref = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    # create ansible module
    am = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )
    # set locale mock
    am.get_bin_path = lambda x: '/usr/bin/locale'
    # set run command mock
    am.run_command = lambda x: (0, avail, None)
    # call to get_best_parsable_locale
    returned = get_best_parsable_locale(am)

# Generated at 2022-06-22 21:43:48.392774
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Ensure that get_best_parsable_locale returns the correct locale.
    '''

    # Import inside test function because it depends on get_best_parsable_locale
    from ansible.module_utils._text import to_native
    from ansible.module_utils.basic import AnsibleModule

    class FakeMod:
        def run_command(self, args):
            assert args[0] == 'locale'
            question = args[1]

            if question == '-a':
                return 0, 'C\nC.utf8\nPOSIX\nen_US.utf8', ''
            elif question == '-m':
                return 0, 'ISO8859-1\nUTF-8', ''
            else:
                return 1, '', to_native(question)


# Generated at 2022-06-22 21:43:49.664865
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # There is no way to reliably unit test this function.
    # The best is to manually run it in a particular environment.
    pass

# Generated at 2022-06-22 21:43:52.720014
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None) == 'C'
    assert get_best_parsable_locale(None, ['en_US.UTF-8']) == 'en_US.UTF-8'


# Generated at 2022-06-22 21:44:00.238899
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import tempfile
    import os
    import shutil

    # create a temp directory to store the 'locale' binary
    tmpd = tempfile.mkdtemp()
    locale_bin = os.path.join(tmpd, 'locale')

# Generated at 2022-06-22 21:44:10.170254
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    fake_module = FakeAnsibleModule()
    assert get_best_parsable_locale(fake_module) == 'C'

    fake_module.fail_json = True
    fake_module.run_command = FakeAnsibleRunCommand()
    fake_module.get_bin_path = FakeGetBinPath()
    assert get_best_parsable_locale(fake_module) == 'C'

    fake_module.fail_json = True
    fake_module.run_command = FakeAnsibleRunCommand([0, 'C', ''])
    fake_module.get_bin_path = FakeGetBinPath()
    assert get_best_parsable_locale(fake_module) == 'C'

    fake_module.fail_json = True
    fake_module.run_command = FakeAn

# Generated at 2022-06-22 21:44:19.690657
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    """
    Sanity check to make sure we got a function that works
    """
    import sys
    import os
    import unittest

    class get_best_parsable_locale_Test(unittest.TestCase):

        def test_get_best_parsable_locale(self):
            """
            Test that the function gets the best locale possible,
            but if it fails, it will return 'C' which is the default
            """
            # We will add the current directory to the PYTHONPATH
            sys.path.append('.')
            import module_utils.basic

            # Mock the module

# Generated at 2022-06-22 21:44:30.831155
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class FakeModule:
        def __init__(self):
            self.bin_path_cache = {}

        def get_bin_path(self, name):
            return '/usr/bin/' + name

        def run_command(self, command):
            if command[1] == '-a':
                return 0, '\n'.join(['pl_PL.utf8', 'C.utf8', 'en_US.utf8', 'C']), ''
            else:
                return 0, '', ''

    mod = FakeModule()
    assert get_best_parsable_locale(mod) == 'pl_PL.utf8'
    assert get_best_parsable_locale(mod, ['da_DK.utf8']) == 'C'

# Generated at 2022-06-22 21:44:35.837478
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # This test is based on the following assumption:
    # When preferences specified, the test actually queries
    # locale -a command and chooses the first available.
    # "C" is the first element in the array.
    # In case the system does not have C locale, the second
    # assumption is that the system has "POSIX" locale.
    #
    # If both not available, the test will fail.
    #
    # If both are available, the test will pass.
    preferences = ['C', 'POSIX']
    try:
        locale = get_best_parsable_locale(preferences)
        assert locale == 'C' or locale == 'POSIX'
        assert True
    except:
        assert False

# Generated at 2022-06-22 21:44:47.055113
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )
    good_locale = get_best_parsable_locale(module)
    assert good_locale == 'C'
    good_locale_with_good_pref = get_best_parsable_locale(module, ['C', 'POSIX'])
    assert good_locale_with_good_pref == 'C'
    good_locale_with_bad_pref = get_best_parsable_locale(module, ['c', 'POSIX'])
    assert good_locale_with_bad_pref == 'C'

# Generated at 2022-06-22 21:44:53.726081
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={}, supports_check_mode=True)

    # Test with no options
    assert get_best_parsable_locale(module) == 'C'

    # Fake a set of locales and test
    def run_command(command):
        if command[1] == '-a':
            return True, 'ar_AR.utf8\nen_US.utf8\nen_US.utf8\nen_US.utf8\nen_US.utf8', None

    module.run_command = run_command

    # Test with options

# Generated at 2022-06-22 21:44:56.474246
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None, preferences=['C.utf8'], raise_on_locale=False) == 'C'


# Generated at 2022-06-22 21:45:08.286677
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.basic import AnsibleModule

    from ansible.module_utils.facts import ansible_locale

    module = AnsibleModule(
        argument_spec=dict(
            preferences=dict(type='list'),
            raise_on_locale=dict(type='bool'),
        ),
        supports_check_mode=True,
    )

    preferences = module.params.get('preferences', None)
    raise_on_locale = module.params.get('raise_on_locale', False)

    try:
        # pref doesn't matter
        result = get_best_parsable_locale(module, preferences, raise_on_locale)
        module.exit_json(ansible_facts=dict(ansible_locale=result))
    except RuntimeWarning as ex:
        module

# Generated at 2022-06-22 21:45:13.492063
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    locale = get_best_parsable_locale(module)
    assert locale == 'C' or locale == 'POSIX' or locale == 'en_US.UTF-8', \
        "Expected 'C' or 'POSIX' or 'en_US.UTF-8' but got %s" % locale

    preferences = ['POSIX', 'I_HATE_CCCP', 'ru_RU.CP1251']
    locale = get_best_parsable_locale(module, preferences)
    assert locale == 'POSIX', "Expected 'POSIX' but got %s" % locale

# Generated at 2022-06-22 21:45:20.468404
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class FakeModule:
        def get_bin_path(self, _):
            return True
        def run_command(self, cmd):
            if cmd[1] == '-a':
                return 0, 'C.utf8\nPOSIX', ''
            else:
                return 0, '', ''

    # Test case: all good
    fake_module = FakeModule()
    assert get_best_parsable_locale(fake_module) == 'C.utf8'

    # Test case: no locale tool
    fake_module.get_bin_path = lambda _: None
    assert get_best_parsable_locale(fake_module) == 'C'

    # Test case: no output from locale -a
    def run_command(cmd):
        if cmd[1] == '-a':
            return 0

# Generated at 2022-06-22 21:45:30.252164
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    import mock
    from ansible.module_utils import basic
    from ansible.module_utils.common.process import get_bin_path as mock_get_bin_path
    from ansible.module_utils.common.process import run_command as mock_run_command

    module = basic.AnsibleModule(
        argument_spec={},
    )

    # Set the return value of mock_get_bin_path to point to the fake binary.
    mock_fake_bin = mock.Mock()
    mock_get_bin_path.return_value = mock_fake_bin

    # Assert 'C' is returned when there is no locale command on the PATH
    with mock.patch('ansible.module_utils.basic.AnsibleModule.get_bin_path') as mock_get_bin_path:
        mock_get

# Generated at 2022-06-22 21:45:40.438154
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    class TestModule(object):
        def __init__(self):
            self.fail_json = None

    class TestModule2(object):
        def __init__(self):
            self.fail_json = None

    class TestModule3(object):
        def __init__(self):
            self.fail_json = None

    class TestModule4(object):
        def __init__(self):
            self.fail_json = None

    class TestModule5(object):
        def __init__(self):
            self.fail_json = None

    class TestModule6(object):
        def __init__(self):
            self.fail_json = None

    class TestModule7(object):
        def __init__(self):
            self.fail_

# Generated at 2022-06-22 21:45:52.049187
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.utils import module_docs
    from ansible.module_utils.basic import AnsibleModule
    module_args = dict()
    module_args['name'] = "foo"
    module_args['user'] = "admin"
    module_args['password'] = "admin"
    module_args['format'] = "json"
    module_args['action'] = "create"
    module_args['ip'] = "localhost"
    module_args['port'] = "8080"
    module_args['ssl'] = False
    module_args['mycert'] = ""
    module_args['mykey'] = ""
    module = AnsibleModule(
        argument_spec=module_docs['service_controller']['options'],
        supports_check_mode=False
    )

    assert get_best_parsable

# Generated at 2022-06-22 21:46:01.958953
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    class FakeAnsibleModule:
        def get_bin_path(self, *args, **kwargs):
            return "/bin/locale"

        def run_command(self, *args, **kwargs):
            return [0, 'C', '']

    fake_module = FakeAnsibleModule()
    locale = get_best_parsable_locale(fake_module)

    assert locale == 'C'

    # Test with a specific locale name
    fake_module.run_command = lambda *args, **kwargs: [0, 'C\nen_US.utf8\nxx_XX.utf8', '']
    locale = get_best_parsable_locale(fake_module, ['en_US.utf8'])

    assert locale == 'en_US.utf8'

    # Test with a locale

# Generated at 2022-06-22 21:46:04.229915
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Test for getting the best parsable locale
    '''
    found = get_best_parsable_locale(None, None, False)
    assert found == 'C'

# Generated at 2022-06-22 21:46:10.066875
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Create a fake module and set some locale
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = []
            self.run_command_results.append(('', ['C', 'C.ascii', 'C.utf8', 'de_AT.utf8'], ''))
            self.run_command_results.append(('', [], ''))

        def get_bin_path(self, arg):
            return 'locale'

        def run_command(self, arg):
            return self.run_command_results.pop()

    test = FakeModule()
    assert get_best_parsable_locale(test) == 'C'
    assert get_best_parsable_locale(test) == 'C.ascii'
    assert get_best_

# Generated at 2022-06-22 21:46:19.199207
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    import unittest
    import types
    if sys.version_info[0] < 3:
        from io import BytesIO as StringIO
    else:
        from io import StringIO
    from ansible.module_utils.basic import AnsibleModule

    class TestModule(AnsibleModule):
        pass

    class TestException(Exception):
        pass

    class MockPopen:

        def __init__(self, returncode, stdout, stderr):
            self.returncode = returncode
            self.stdout = stdout
            self.stderr = stderr

        def communicate(self):
            return self.stdout, self.stderr

    class MockPopenZero(MockPopen):
        pass

    class MockPopenNonZero(MockPopen):
        pass

   

# Generated at 2022-06-22 21:46:27.126770
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    module = FakeModule()

    assert get_best_parsable_locale(module) == "C"

    module.bin_path_exists = False
    assert get_best_parsable_locale(module) == "C"

    module.bin_path_exists = True
    module.run_command_err = b'locale: Cannot set LC_CTYPE to default locale: No such file or directory'
    assert get_best_parsable_locale(module, raise_on_locale=True) == "C"

    module.run_command_err = b'locale: Cannot set LC_CTYPE to default locale: No such file or directory'
    assert get_best_parsable_locale(module, raise_on_locale=False) == "C"

    module.run_command

# Generated at 2022-06-22 21:46:32.292863
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Case of missing preferences
    assert get_best_parsable_locale(module) is 'C'

    # Case of existing preferences
    assert get_best_parsable_locale(module, preferences=['C.utf8']) is 'C.utf8'

# Generated at 2022-06-22 21:46:33.830176
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    locale = get_best_parsable_locale()
    assert locale == 'C'

# Generated at 2022-06-22 21:46:40.526132
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.modules.system import locale_gen
    from ansible.module_utils.system import locale
    from ansible.module_utils.facts.system.locale import get_locale

    # Create the AnsibleModule
    module = AnsibleModule(argument_spec={})

    # Create the mock module class
    class MockModule:
        args = {}

        def get_bin_path(self, arg, opt_dirs=None):
            return arg


# Generated at 2022-06-22 21:46:41.166712
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    pass

# Generated at 2022-06-22 21:46:52.210492
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    class TestModule(object):
        def __init__(self):
            self.params = {}
            self.run_command_results = []

        def get_bin_path(self, tool, opt_dirs=None):
            return tool

        def run_command(self, command, check_rc=True, close_fds=True, executable=None, data=None):
            return self.run_command_results.pop(0)

    module = AnsibleModule(argument_spec={}, supports_check_mode=True)

    # Create test module, configured for various unit tests
    tm = TestModule()

    # Unit test, no locales
    tm.run_command_results = [(0, '', '')]
    assert get_best_parsable_

# Generated at 2022-06-22 21:47:04.226639
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})

    # known list of available locales
    available_locales = [
        "C.UTF-8",
        "POSIX",
        "en_US.utf8",
        "en_US.utf8@foxymonkey",
        "es_MX.utf8@foxymonkey",
        "foo",
    ]

    # ensure we get C if there are no available locales
    assert get_best_parsable_locale(module) == 'C'

    # ensure we get the first available locale in the preferences list if it exists
    assert get_best_parsable_locale(module, [available_locales[0]]) == available_locales[0]

    # ensure we get the first available locale

# Generated at 2022-06-22 21:47:13.328188
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # return 'C' if we can't find a locale
    assert get_best_parsable_locale(module) == 'C'

    # return the first locale we find
    assert get_best_parsable_locale(module, preferences=['B', 'A', 'C']) == 'B'

    # return 'C' if we can't find anything else
    assert get_best_parsable_locale(module, preferences=['B', 'A']) == 'C'

    # we should hit an exception on a unicode locale if localize is false

# Generated at 2022-06-22 21:47:21.333664
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    # Test setup
    # Check possible available locales with: locale -a
    module = AnsibleModule(argument_spec=dict())
    preferences = ['en_US.utf8', 'en_US.UTF-8', 'C', 'POSIX']
    raise_on_locale = False

    # Test output
    # Parsable should be en_US.UTF-8
    assert(get_best_parsable_locale(module, preferences, raise_on_locale) == "en_US.UTF-8")
    # Parsable should be C (default)
    preferences = ['en_CA.utf8', 'en_CA.UTF-8', 'C', 'POSIX']

# Generated at 2022-06-22 21:47:31.653538
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    # create the module object
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)

    # This is the default that we should get back
    assert get_best_parsable_locale(module, raise_on_locale=True) == 'C'

    # When we set the preferences, we should get the first thing in the list
    # this will not work with all linux flavors
    preferences = ['POSIX', 'C', 'C.utf8']
    assert get_best_parsable_locale(module, preferences=preferences, raise_on_locale=True) == preferences[0]

    # this will cause a RuntimeWarning
    preferences = ['POSIX', 'C', 'C.utf8', 'en_US.utf8']

# Generated at 2022-06-22 21:47:41.809521
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class MockModule(object):
        def __init__(self):
            self.fail_json_msg = []

        def fail_json(self, msg):
            self.fail_json_msg.append(msg)

        def get_bin_path(self, arg):
            return '/bin/locale'

        def run_command(self, args):
            if args == ['/bin/locale', '-a']:
                return 0, 'C.utf8\nen_US.utf8\nja_JP.utf8\n', ''
            else:
                return 1, '', 'Unable to get locale information'

    with open('/etc/default/locale', 'w') as f:
        f.write('LANG="en_US.utf8"\n')

    # check the function get_best_p

# Generated at 2022-06-22 21:47:49.711326
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # return 'C' on failure
    assert get_best_parsable_locale(None) == 'C'

    # return 'C' on failure
    assert get_best_parsable_locale(None, preferences=['fake']) == 'C'

    # return 'C' on failure
    assert get_best_parsable_locale(None, preferences=['C']) == 'C'

# Generated at 2022-06-22 21:47:59.836908
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    locale_list = ['C', 'POSIX', 'C.UTF-8']

    # Test if C locale is returned
    best_locale = get_best_parsable_locale(locale_list)
    assert best_locale == 'C'

    # Test if POSIX locale is returned
    locale_list = ['POSIX', 'C', 'POSIX.UTF-8']
    best_locale = get_best_parsable_locale(locale_list)
    assert best_locale == 'POSIX'

    # Test if C.UTF-8 locale is returned
    locale_list = ['POSIX', 'C', 'POSIX.UTF-8', 'C.UTF-8']
    best_locale = get_best_parsable_locale(locale_list)
    assert best_locale

# Generated at 2022-06-22 21:48:11.197135
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys

    sys.path.append('../test')

    class MockModule(object):
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err

        def get_bin_path(self, path, required=True):
            self.path = path
            return path

        def run_command(self, cmd, check_rc=True):
            self.cmd = cmd
            return (self.rc, self.out, self.err)

    # Test case 1: Test that default preference is returned properly
    rc = 0
    out = 'C.utf8\nen_US.utf8\nja_JP.utf8\n'
    err = ''

    mm = MockModule(rc, out, err)

    assert 'C.utf8'

# Generated at 2022-06-22 21:48:21.022786
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import io
    import sys
    import ansible
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat import unittest
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch, Mock
    import ansible_collections.notstdlib.moveitallout.plugins.module_utils._text as _text

    class TestModule(object):
        def __init__(self):
            self._result = {}
            self.params = {}
            self.fail = False
            self.fail_json = lambda **kwargs: setattr(self, 'fail', True)

        def run_command(self, cmd, check_rc=True):
            raise RuntimeWarning("Run command")


# Generated at 2022-06-22 21:48:30.373002
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class AnsibleModule(object):
        def __init__(self, *args, **kwargs):
            self.params = kwargs

        @classmethod
        def get_bin_path(self, name, *args, **kwargs):
            if name == 'locale':
                return True
            return False

        @classmethod
        def run_command(self, *args, **kwargs):
            if 'locale' in args[0]:
                return 0, 'C.utf8\nen_US.utf8\nen_US.utf8\nc\n', ''
            return 0, '', ''

    module = AnsibleModule()

    assert get_best_parsable_locale(module, None) == 'C.utf8'

# Generated at 2022-06-22 21:48:42.173081
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    import os

    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.basic import AnsibleModule, AnsibleExitJson

    try:
        from unittest.mock import MagicMock, patch
    except:
        from mock import MagicMock, patch


    # Custom class to redirect stdout only, not stderr
    class ShowOut(object):
        def __init__(self, stream):
            self.stream = stream

        def __enter__(self):
            self.old = sys.stdout
            sys.stdout = self.stream
            return self

        def __exit__(self, *args):
            sys.stdout = self.old

        def write(self, what):
            if what == "":
                return

# Generated at 2022-06-22 21:48:50.587111
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.pycompat24 import get_exception

    with AnsibleModule(argument_spec={}) as module:
        preference = ['POSIX', 'C.utf8', 'en_US.utf8',  'C']
        assert get_best_parsable_locale(module, preference) == 'POSIX'
        assert get_best_parsable_locale(module, ['POSIX']) == 'POSIX'

        # Simulating locale -a output without POSIX
        module.run_command = lambda x: (0, '\n'.join(preference[1:]), '')
        assert get_best_parsable_locale(module, preference) == 'C.utf8'
        assert get_best_parsable_

# Generated at 2022-06-22 21:49:01.444497
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    # Testing None Preferences
    tmp = AnsibleModule(add_file_common_args=False, argument_spec={}, supports_check_mode=False)
    assert (get_best_parsable_locale(tmp) == 'C')

    # Testing Available Preferences
    tmp = AnsibleModule(add_file_common_args=False, argument_spec={}, supports_check_mode=False)
    assert (get_best_parsable_locale(tmp, preferences=['C', 'POSIX']) == 'C')

    # Testing Not Available Preferences
    tmp = AnsibleModule(add_file_common_args=False, argument_spec={}, supports_check_mode=False)

# Generated at 2022-06-22 21:49:07.426772
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None) == 'C'
    assert get_best_parsable_locale(None, preferences=['abc']) == 'C'
    assert get_best_parsable_locale(None, preferences=['C', 'POSIX']) == 'C'
    assert get_best_parsable_locale(None, preferences=['POSIX', 'C']) == 'C'

# Generated at 2022-06-22 21:49:19.395470
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    import os
    import sys
    import shutil
    import tempfile
    import AnsibleModule

    # Create temporary dir
    tmpdir = tempfile.mkdtemp()
    os.chdir(tmpdir)

    open('locale', 'a').close()

    def fake_run_command(*args, **kwargs):
        if '-a' in args[0]:
            return 0, 'C\nC.utf8', ''
        else:
            return 0, '', ''

    module = AnsibleModule.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )
    module.run_command = fake_run_command

    assert module.get_bin_path('locale')


# Generated at 2022-06-22 21:49:28.545737
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Mock class with run_command method.
    class M:
        def run_command(self, locale):
            assert locale == [locale, '-a']
            return (0, 'C\nC.utf8', '')

    m = M()
    best_locale = get_best_parsable_locale(m, preferences=['C', 'C.utf8'])
    assert best_locale == 'C.utf8'

    best_locale = get_best_parsable_locale(m, preferences=['C'])
    assert best_locale == 'C'

# Generated at 2022-06-22 21:49:39.517324
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Test function

    # test for locale not available
    module = FakeModuleForUtil()
    module.run_command = lambda x, check_rc=False, encoding=None: (1, '', '')

    # test for locale with no output
    module.run_command = lambda x, check_rc=False, encoding=None: (0, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # test for locale with default output
    module.run_command = lambda x, check_rc=False, encoding=None: (0, 'C\nen_US\nPOSIX\nen_US.utf8\n', '')
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-22 21:49:44.970662
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    module = AnsibleUnsafeText('module')
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    assert get_best_parsable_locale(module, preferences) == 'C'

# Generated at 2022-06-22 21:49:50.367514
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    assert module is not None
    assert get_best_parsable_locale(module=module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) in ['C.utf8', 'en_US.utf8', 'C', 'POSIX']

# Generated at 2022-06-22 21:49:59.867935
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import os

    # Test without preferences
    am = AnsibleModule(argument_spec=dict())
    am.get_bin_path = lambda x: x if x == 'locale' else None
    am.run_command = lambda x: (0, '\n'.join(['C', 'POSIX', 'en_US.utf8']), '')
    assert 'en_US.utf8' == get_best_parsable_locale(am)

    # Test with preferences
    am = AnsibleModule(argument_spec=dict())
    am.get_bin_path = lambda x: x if x == 'locale' else None

# Generated at 2022-06-22 21:50:02.740426
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = None
    preferences = None
    raise_on_locale = True
    locale = get_best_parsable_locale(module, preferences, raise_on_locale)
    assert locale is not None
    assert locale == 'C'

# Generated at 2022-06-22 21:50:14.055581
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-22 21:50:25.188581
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-22 21:50:34.927270
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import mock
    import tempfile

    temp_file = tempfile.NamedTemporaryFile(delete=False)
    temp_file.write(b"en_US.utf8\nC\nC.utf8\n")
    temp_file.close()

    test_locale = """#!/usr/bin/python

import sys

if "--version" in sys.argv:
    print("JUNK")
elif "--help" in sys.argv:
    print("This is a test to find the best parsable locale")
elif sys.argv[1] == '-a':
    with open('%s') as candidates:
        for candidate in candidates:
            print(candidate.rstrip(), end='')
""" % temp_file.name


# Generated at 2022-06-22 21:50:38.315045
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-22 21:50:47.923696
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class TestModule:
        class TestModule:
            class TestModule2:
                class AnsibleModule_fail_json(object):
                    def __call__(self, args):
                        raise SystemExit

                fail_json = AnsibleModule_fail_json()

            fail_json = TestModule2()

        def run_command(self, test):
            return 0, 'C\nen_US.utf8', ''

    test = TestModule()

    try:
        result = get_best_parsable_locale(test, preferences=['en_US.utf8', 'en_US.utf8'])
    except RuntimeWarning:
        result = False

    assert result == 'en_US.utf8'


# Generated at 2022-06-22 21:50:52.863407
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Test to ensure that best_parsable_locale is being returned
    '''

    mock_module = MagicMock()
    mock_module.get_bin_path = MagicMock(return_value=True)
    mock_module.run_command = MagicMock(return_value=(0, '', ''))

    result = get_best_parsable_locale(mock_module)

    assert result == 'C'

# Generated at 2022-06-22 21:50:56.665377
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # this module is not meant to be run as a standalone unit test
    from ansible.module_utils.basic import AnsibleModule
    assert get_best_parsable_locale(AnsibleModule(), raise_on_locale=True)
    assert get_best_parsable_locale(AnsibleModule())
    assert get_best_parsable_locale(AnsibleModule(), preferences=['C', 'POSIX'])