

# Generated at 2022-06-20 15:54:39.458494
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    # class DummyModule:
    #     def __init__(self, *args):
    #         self.params = dict()
    #         self.called = []
    #         self.result = dict(cmd=args)

    class DummyModule(AnsibleModule):
        def __init__(self, *args, **kwargs):
            super(DummyModule, self).__init__(*args, **kwargs)

            self.get_bin_path_called = False

    module = DummyModule(argument_spec=dict())

    def mock_run_command(self, *args):
        if 'locale' in args[0][0]:
            self.get_bin_path_called = True

            return 0, 'foo', None

    module.run

# Generated at 2022-06-20 15:54:49.846138
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.common.process import get_bin_path
    module = None
    assert get_best_parsable_locale(module) == 'C'

    module = type('module', (object,), {'run_command': run_command})
    assert get_best_parsable_locale(module) == 'POSIX'
    assert get_best_parsable_locale(module, raise_on_locale=True) == 'POSIX'

    module = type('module', (object,),
                  {'run_command': run_command, 'get_bin_path': get_bin_path})
    assert get_best_parsable_locale(module) == 'POSIX'
    assert get_best_parsable_locale(module, raise_on_locale=True)

# Generated at 2022-06-20 15:54:59.081022
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''Unit test for function get_best_parsable_locale'''
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule
    import ansible.module_utils.facts as facts
    import sys

    if sys.version_info[0] < 3:
        def to_bytes(s):
            if isinstance(s, str):
                return s
            else:
                return str(s)

        def to_native(s):
            return to_bytes(s)
    else:
        def to_bytes(s):
            if isinstance(s, bytes):
                return s
            else:
                return s.encode('utf-8', errors='surrogateescape')


# Generated at 2022-06-20 15:55:05.188215
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None, ['POSIX', 'C']) == 'POSIX'
    assert get_best_parsable_locale(None, ['POSIX', 'en_US.utf8']) == 'POSIX'
    assert get_best_parsable_locale(None, ['en_US.utf8', 'POSIX']) == 'en_US.utf8'

# Generated at 2022-06-20 15:55:16.776018
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Test first preference found
    preferences = ['ar_SA.utf8', 'C.utf8', 'en_US.utf8', 'C', 'POSIX']
    found = get_best_parsable_locale(None, preferences)
    assert found == 'C.utf8'

    # Test last preference found
    preferences = ['ar_SA.utf8', 'en_US.utf8', 'C', 'POSIX']
    found = get_best_parsable_locale(None, preferences)
    assert found == 'POSIX'

    # Test no preferences found, default is used
    preferences = ['ar_SA.utf8', 'en_US.utf8', 'POSIX']
    found = get_best_parsable_locale(None, preferences)
    assert found == 'C'

# Generated at 2022-06-20 15:55:23.882126
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module_name = 'test_get_best_parsable_locale'
    module_args = ''
    module_kwargs = {}

    import ansible.module_utils.basic
    from ansible.module_utils.basic import AnsibleModule

    # Fake the module
    m = AnsibleModule(module_name, module_args, module_kwargs)
    m.run_command = lambda args, check_rc=True: (0, 'C.utf8\nen_US.utf8\nen_GB.utf8\nC\n', '')

    found = get_best_parsable_locale(m, ['en_GB.utf8'])
    assert(found=='en_GB.utf8')

# Generated at 2022-06-20 15:55:27.200882
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    preferences = ['fr', 'it']
    found = get_best_parsable_locale({}, preferences)
    if found != 'C':
        raise Exception('get_best_parsable_locale failed')

# Generated at 2022-06-20 15:55:34.636400
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys

    # Mock ansible module class
    class FakeModule(object):
        def __init__(self):
            self.params = {}

        def fail_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs
            sys.exit(1)

        def get_bin_path(self, value):
            return value

        def run_command(self, *args, **kwargs):
            self.cmd = args
            self.cmd_kwargs = kwargs
            return (0, "", "")

    # Test module with no preferred locales
    mod = FakeModule()
    locale = get_best_parsable_locale(mod)
    assert locale == 'C'  # default locale should be C

    # Test module with preferred local

# Generated at 2022-06-20 15:55:44.994535
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    """
    Ensures that the function returns the expected locale
    when given a test data set of the locales installed on the system.

    ex.
    The test set of locales installed on the system is:

    ['C', 'C.UTF-8', 'en_US.utf8', 'POSIX', 'en_US.utf8']

    Expected:
    The function will return C.UTF-8 since it appears in all lists,
    and is the first item in the preferences list input to the function.

    The function will also return 'POSIX' when preferences is None,
    or if no preferred locales can be found in the installed locales.

    """

    import ansible.module_utils.basic
    # ansible.module_utils.basic is required here to initialize the _ANSIBLE_ARGS
    # global variable so that the Ansible

# Generated at 2022-06-20 15:55:55.341974
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict())

    test_locale = "foo_BAR.baz"
    test_priority_locale = "bar_FOO.baz"

    module.run_command = lambda command, cwd=None: (0, test_locale, '')
    assert 'C' == get_best_parsable_locale(module, raise_on_locale=True)

    module.run_command = lambda command, cwd=None: (0, test_locale, '')
    assert 'C' == get_best_parsable_locale(module)

    module.run_command = lambda command, cwd=None: (0, test_locale, '')
    assert test_locale == get_

# Generated at 2022-06-20 15:56:03.667346
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Test function with no preference list
    assert get_best_parsable_locale(preferences=None) == 'C'

# Generated at 2022-06-20 15:56:12.656473
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Unit test for function get_best_parsable_locale
    '''
    class FakeModule(object):
        def __init__(self):
            self.params = {}

        def run_command(self, command, check_rc=False, encoding=None):
            return 0, '', ''

        def get_bin_path(self, bin_path, required=False):
            return 'locale'

        def fail_json(self, *args, **kwargs):
            pass


# Generated at 2022-06-20 15:56:22.483375
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.utils.shlex import shlex_split

    # Initialize the Ansible module
    from ansible.modules.system.setup import get_distribution
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True,
    )

    # Get all the available and parsing supported locales
    strong_locale_list = []
    known_locale_list = []
    for line in get_all_locales().splitlines():
        known_locale_list.append(line.split('.utf8')[0])
        if '.' in line:
            strong_locale_list.append(line.split('.')[0])

    # Ansible will prefer unicode locales, but will fall back to ascii if

# Generated at 2022-06-20 15:56:30.979439
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule('foo')

    # Patch the module to return a specific list of locales
    module.get_bin_path = lambda x: "locale"

    module.run_command = lambda x: (0, '''
C
C.UTF-8
en_US.utf8
en_US.UTF-8
en_US.utf8@foo
FOO
foo
POSIX
POSIX.utf8
''', 'stderr')

    assert get_best_parsable_locale(module, preferences=['POSIX', 'C.UTF-8']) == 'POSIX'

# Generated at 2022-06-20 15:56:35.552974
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None) == 'C'
    # try a couple of the locales we expect to find
    assert get_best_parsable_locale(None, ['C', 'C.utf8']) == 'C'
    assert get_best_parsable_locale(None, ['C.utf8', 'C']) == 'C.utf8'



# Generated at 2022-06-20 15:56:43.975054
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False,
    )
    # Values for testing must match available locales on test system.
    d_locales = dict(
        de=['de_DE.utf8', 'C.utf8', 'de_DE.utf8', 'C', 'POSIX'],
        ru=['ru_RU.utf8', 'C.utf8', 'ru_RU.utf8', 'C', 'POSIX'])
    d_best_locale = dict(
        de='de_DE.utf8',
        ru='ru_RU.utf8')
    for locale, locale_pref in d_locales.items():
        best = get_best_parsable

# Generated at 2022-06-20 15:56:50.297781
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    mod = AnsibleModule(argument_spec={})
    # test that we didn't raise an eception and return the default 
    assert get_best_parsable_locale(mod) == 'C'
    # test that we did raise an exception because we want to
    raised = False
    try:
        assert get_best_parsable_locale(mod, raise_on_locale=True)
    except RuntimeWarning:
        raised = True
    assert raised == True
    # test that we were able to get the locale we wanted
    assert get_best_parsable_locale(mod, ['C.utf8']) == 'C.utf8'
    # test that we returned the default

# Generated at 2022-06-20 15:57:00.367581
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Unit test for function get_best_parsable_locale
        :returns: None when no test failure
    '''

    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())

    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX'], raise_on_locale=True) == 'C'
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX'], raise_on_locale=False) == 'C'

# Generated at 2022-06-20 15:57:09.268584
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes, to_text

    class FakeModule(object):
        def __init__(self):
            self.run_command_calls = []
            self.fail_json_calls = []
            self.exit_args = []
            self.warn_args = []

        def get_bin_path(self, prog, required=False, opt_dirs=[]):
            if prog == "locale":
                return to_bytes("locale")


# Generated at 2022-06-20 15:57:19.594616
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        import __builtin__ as builtins
    except ImportError:
        import builtins

    import sys
    if sys.version_info[0] >= 3:
        import unittest.mock as mock
    else:
        import mock

    from ansible.module_utils.basic import AnsibleModule

    with mock.patch.object(builtins, '__import__', create=True) as mock_import:
        # Mock out executables
        mock_locale = mock_import.return_value.get_bin_path.return_value
        mock_run_command = mock_locale.run_command

        # Test no locale tool
        mock_import.return_value.get_bin_path.return_value = None
        m = AnsibleModule(argument_spec={})
        assert get_best_pars

# Generated at 2022-06-20 15:57:33.917377
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils import basic
    import os
    import tempfile
    import shutil

    # Create a temp directory
    tmpdir = tempfile.mkdtemp()

    # Create the test file
    (fd, test_file) = tempfile.mkstemp()

    # Write to the file
    os.write(fd, '#!/bin/sh\n')
    os.write(fd, 'echo C.utf8\necho C.ascii\necho C\n')

    os.close(fd)

    # Make the file executable
    os.chmod(test_file, 0o755)

    # Set executable file as locale
    os.environ['PATH'] = tmpdir + os.pathsep + os.environ['PATH']


# Generated at 2022-06-20 15:57:45.336701
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    # Simply trying to get the best locale. This should return 'C'
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    assert get_best_parsable_locale(module) == 'C'

    # Setting preferences to 'C'. This should still return 'C'
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    assert get_best_parsable_locale(module, preferences=['C']) == 'C'

    # Setting preferences to 'en_US' and 'C' which are both available.
    # This should return 'en_US'
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    assert get_best_parsable_loc

# Generated at 2022-06-20 15:57:57.545229
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Driver function to do unit tests of the get_best_parsable_locale() function.
    '''

    # list of input locale preferences
    locale_preferences = ['C', 'NOPE', 'en_US.utf8', 'POSIX']

    # available locales
    available_locales = ['C', 'POSIX', 'en_US.utf8', 'C.utf8']

    # test get_best_parsable_locale() with the above inputs
    best_locale = get_best_parsable_locale(locale_preferences, available_locales)

    # make sure the result is 'en_US.utf8', which is the first locale that
    # is available and matches the locale preferences
    assert best_locale == 'en_US.utf8'

# Generated at 2022-06-20 15:58:08.136619
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class C:
        def __init__(self, module, preferences, raise_on_locale):
            self.module = module
            self.preferences = preferences
            self.raise_on_locale = raise_on_locale
        def get_bin_path(self, path):
            return path
        @staticmethod
        def run_command(command):
            return [0, '\n'.join(['C', 'en_US.utf8', 'POSIX', 'C.utf8']), '']

    # overriding the default preference
    assert 'en_US.utf8' == get_best_parsable_locale(C(None, ['en_US.utf8'], False))
    # overriding the default preference

# Generated at 2022-06-20 15:58:15.175557
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    preferences = ['C.utf8', 'C', 'POSIX']
    test_default_locale = get_best_parsable_locale(AnsibleModule, preferences)
    assert test_default_locale == 'C.utf8' or test_default_locale == 'C'

    # Tests to see if a RuntimeWarning is raised under circumstances that it should be
    preferences = ['C.utf8', 'C', 'POSIX', 'badlocale']
    try:
        get_best_parsable_locale(AnsibleModule, preferences)
    except RuntimeWarning:
        pass
    else:
        assert False, "No exceptions raised"

if __name__ == '__main__':
    test_get_best_parsable_locale()

# Generated at 2022-06-20 15:58:26.337032
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils import basic
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_TRUE, BOOLEANS_FALSE

    # Create a fake module with Native AnsibleModule
    class AnsibleModule:
        def __init__(self, argument_spec, bypass_checks=False, no_log=False,
                     check_invalid_arguments=None, mutually_exclusive=None, required_together=None,
                     required_one_of=None, add_file_common_args=False, supports_check_mode=False,
                     required_if=None):

            self.argument_spec = argument_spec
            self.bypass_checks = bypass_checks
            self.no_

# Generated at 2022-06-20 15:58:29.562007
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = None
    # Change the env to 'C'. This is important to test the functions
    # which set locale environment variables.
    test_locale = 'C'
    return_locale = get_best_parsable_locale(module)
    assert test_locale == return_locale

# Generated at 2022-06-20 15:58:40.503065
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(preferences=None) == 'C'
    assert get_best_parsable_locale(preferences=['C']) == 'C'
    assert get_best_parsable_locale(preferences=['C', 'POSIX']) == 'C'
    assert get_best_parsable_locale(preferences=['POSIX', 'C']) == 'C'
    assert get_best_parsable_locale(preferences=['POSIX', 'C', 'C.utf8']) == 'C'
    assert get_best_parsable_locale(preferences=['POSIX', 'C', 'en_US.utf8']) == 'C'

# Generated at 2022-06-20 15:58:48.160169
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    import mock
    import sys
    import os

    # Skip test on platforms other than Linux, or when locale is not available.
    if sys.platform.startswith('linux') and os.path.exists('/usr/bin/locale'):

        from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-20 15:58:49.889661
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())

    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-20 15:59:06.677029
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils import basic

    # test basic function of locale with no locale issues
    module = AnsibleModule(
        argument_spec={
            'test_var': {'type': 'str'},
        },
        supports_check_mode=True
    )
    # These are the locales the system supports
    # We should detect that we have en_US.utf8 or C
    # since these are the defaults in the function
    module.run_command = lambda x: (0, 'C\nen_US.utf8', '')
    assert get_best_parsable_locale(module) == 'en_US.utf8'
    module.run_command = lambda x: (0, 'en_US.utf8', '')
    assert get

# Generated at 2022-06-20 15:59:16.536684
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.process import get_bin_path

    module = AnsibleModule(
        argument_spec=dict(),
    )
    module._debug = False

    # When /usr/bin/locale is available on the system,
    # get_best_parsable_locale should return C.utf8 or C at first
    def test_no_locale_bin(module, preferences=None, raise_on_locale=False):
        # When /usr/bin/locale is not available on the system,
        # locale should be set to None
        assert get_bin_path(module, 'locale') is None
        # When /usr/bin/locale is not available on the system,
        # get_best_parsable_

# Generated at 2022-06-20 15:59:23.957927
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import collections

    dummy_module = collections.namedtuple('AnsibleModule', ['run_command', 'get_bin_path'])
    dummy_module.run_command = lambda x: (0, x[1], '')
    dummy_module.get_bin_path = lambda x: x

    # For this test we are using locale C.utf8. This locale is set to utf8 but
    # it might not be installed on the test system. In that case the tests will
    # fail. See comments in get_best... for why we prefer C.utf8 over C.

    # Test that with wrong preferences we get C as expected
    assert 'C' == get_best_parsable_locale(dummy_module, preferences=['wrong'])

    # Test that with no preferences we get C.utf8

# Generated at 2022-06-20 15:59:34.093633
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Test case for unit test get_best_parsable_locale
    '''
    # Using an AnsibleModule mock
    import sys
    sys.modules['ansible'] = None
    class AnsibleModuleMock(object):
        '''
            Mock object for class AnsibleModule
        '''
        def __init__(self):
            self.run_command_args = []

        def get_bin_path(self, _):
            '''
                mock for get_bin_path
            '''
            return 'locale'

        def run_command(self, args):
            '''
                mock for run_command
            '''
            self.run_command_args.append(args)
            return 0, 'arg1\narg2\narg3', ''

    ansible_module = Ans

# Generated at 2022-06-20 15:59:42.985162
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six.moves import StringIO

    class FakeModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, cmd):
            return cmd

        def run_command(self, cmd):
            if 'locale' not in cmd:
                return 9, "no", "bad"
            if '-a' in cmd:
                return 0, "aaa\nbbb\nccc", ""
            return 0, "", ""

        def fail_json(self, *args, **kwargs):
            pass

    # known locale installed
    module = FakeModule()
    assert get_best_parsable_locale(module, ['ccc']) == 'ccc'



# Generated at 2022-06-20 15:59:53.118450
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.basic import AnsibleModule

    mod = AnsibleModule({})
    default = get_best_parsable_locale(mod)
    assert default == 'C', 'Default locale should be C'

    assert get_best_parsable_locale(mod, ['POSIX']) == 'C', 'POSIX should resolve to C'

    # Test that get_best_parsable_locale will throw an exception if locale is not installed

# Generated at 2022-06-20 15:59:54.824802
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None) == 'C'

# Generated at 2022-06-20 16:00:04.385646
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Basic unit test for function get_best_parsable_locale

        :param self:
        :returns:
    '''
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Check we get the default value
    assert get_best_parsable_locale(module) == 'C'

    # Check we get the first possible one
    assert get_best_parsable_locale(module, ['POSIX', 'C']) == 'POSIX'

    # Check we get the first one
    assert get_best_parsable_locale(module, ['POSIX', 'C', 'en_US']) == 'POSIX'

    # Check we get the second one

# Generated at 2022-06-20 16:00:12.259787
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    m = AnsibleModule(argument_spec={})

    locales = m.run_command(['locale', '-a'])

    assert get_best_parsable_locale(m) in locales[1].split('\n')

    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    assert get_best_parsable_locale(m, preferences) in locales[1].split('\n')

    if not PY3:
        class BadModule(object):
            def run_command(self, command):
                return None, None, None


# Generated at 2022-06-20 16:00:21.875891
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    """
        Test best locale for parsing output
    """
    from ansible.utils.hashing import md5s
    from ansible.module_utils.common.collections import is_collection

    test_locales = ['C', 'POSIX', 'en_US.utf8', 'C.utf8', 'en_US.UTF-8']

    # NOTE: In the future we should add more locales, but right now the tests are slow enough.
    # This testing is not exhaustive, but it's a start.
    # We should probably also use mock_modules instead of the hacky import attempt

    # Test a collection and see if we get the same thing back from the parser.

# Generated at 2022-06-20 16:00:36.463981
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    assert(get_best_parsable_locale({'get_bin_path': lambda x: '/usr/bin/locale'}, None, False) in preferences)
    assert(get_best_parsable_locale({'get_bin_path': lambda x: '/usr/bin/locale'}, None, True) in preferences)
    assert(get_best_parsable_locale({'get_bin_path': lambda x: '/usr/bin/locale'}, ['C'], False) in preferences)
    assert(get_best_parsable_locale({'get_bin_path': lambda x: '/usr/bin/locale'}, ['C'], True) in preferences)

# Generated at 2022-06-20 16:00:45.054396
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import os
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common._collections_compat import Mapping

    # test language list
    preferences = ['cy_GB.utf8', 'fr_CA.utf8', 'C', 'POSIX']

    # test language list in non-standard order
    preferences_reverse = ['cy_GB.utf8', 'POSIX', 'fr_CA.utf8', 'C']


# Generated at 2022-06-20 16:00:53.131015
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.process import get_bin_path

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    locale_bin = get_bin_path(module, 'locale')
    if locale_bin:
        locale_list = get_best_parsable_locale(module)
        assert locale_list == 'C'
    else:
        assert False, 'locale binary not found'

# Generated at 2022-06-20 16:01:00.103987
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    assert get_best_parsable_locale(preferences=None) == 'C'
    assert get_best_parsable_locale(preferences=['C.utf8']) == 'C.utf8'
    assert get_best_parsable_locale(preferences=['en_US.utf8']) == 'en_US.utf8'
    assert get_best_parsable_locale(preferences=['de_DE.utf8']) == 'C'

if __name__ == '__main__':
    test_get_best_parsable_locale()

# Generated at 2022-06-20 16:01:04.299804
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
	from ansible.module_utils.basic import AnsibleModule
	module = AnsibleModule(argument_spec={})
	locale = get_best_parsable_locale(module=module)
	if locale != 'C':
		raise Exception("Unexpected locale %s" % locale)

# Generated at 2022-06-20 16:01:14.018670
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    """
    Test that get_best_parsable_locale works as expected.
    """

    assert get_best_parsable_locale(None) == 'C'

    assert get_best_parsable_locale(None, ['C', 'z_Z']) == 'C'

    assert get_best_parsable_locale(None, ['z_Z', 'C']) == 'C'

    assert get_best_parsable_locale(None, ['z_Z', 'C', 'en_US.utf8']) == 'en_US.utf8'

    assert get_best_parsable_locale(None, preferences=None) == 'C'


# Generated at 2022-06-20 16:01:21.792710
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import unittest
    import sys
    import os
    import ansible_collections.ansible.community.tests.unit.compat.mock as mock
    import tempfile

    class TestLocale(unittest.TestCase):
        def setUp(self):
            # create the mock module
            self.m = mock.Mock()

            # create a temp directory
            self.test_dir = tempfile.mkdtemp()
            self.locale_path = os.path.join(self.test_dir, 'locale')

            # create a mock for the 'locale' tool
            mock_locale_tool = os.path.join(self.test_dir, 'mock_locale')
            open(mock_locale_tool, 'w').close() # create a file

# Generated at 2022-06-20 16:01:28.975868
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils import basic

    mod = AnsibleModule(
        argument_spec=dict(
        )
    )

    # Test should return locale 'C' by default
    assert get_best_parsable_locale(mod) == 'C'

    # Test should return the first matched preferred locale
    pref = ['foo', 'C', 'bar']
    assert get_best_parsable_locale(mod, pref) == 'C'

# Generated at 2022-06-20 16:01:37.747545
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common._collections_compat import MutableMapping
    import pytest
    import mock
    module = AnsibleModule()

    # Test: Function raise_on_locale
    # Expected Result: RuntimeWarning exception with message
    module.run_command = mock.Mock(return_value=(1, None, None))
    with pytest.raises(RuntimeWarning):
        get_best_parsable_locale(module, raise_on_locale=True)

    module = AnsibleModule()
    # Test: Function does not raise_on_locale, command succeeded
    # Expected Result: Success, return of C

# Generated at 2022-06-20 16:01:49.992523
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import os
    import json
    import shutil

    class FakeModule(object):
        def __init__(self, bin_path):
            self.bin_path = bin_path

        def get_bin_path(self, cmd):
            return self.bin_path

        def run_command(self, cmd, environ_update=None, check_rc=True, close_fds=True, cwd=None, data=None, binary_data=False, path_prefix=None, use_unsafe_shell=False, prompt_regex=None):
            return 0, None, None

    # Run with empty bin_path
    assert get_best_parsable_locale(FakeModule('')) == 'C'

    # Create a temp directory and add it to the PATH

# Generated at 2022-06-20 16:02:05.955777
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None) == 'C'

# Generated at 2022-06-20 16:02:10.874475
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.run_command = lambda x: (0, '', '')

        def get_bin_path(self, cmd):
            if cmd == 'locale':
                return cmd

    module = FakeModule()
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-20 16:02:14.864021
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Basic test of module
    '''
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    locale = get_best_parsable_locale(module, raise_on_locale=True)
    assert locale == 'C'

if __name__ == '__main__':
    test_get_best_parsable_locale()

# Generated at 2022-06-20 16:02:24.035355
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # pylint: disable=import-error
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils import common_koji as ko

    # pylint: disable=protected-access
    module = AnsibleModule({})
    # pylint: disable=unused-variable
    k = ko.CommonKoji(module)
    # prefer en_US but if it doesn't exist use the default
    assert ko._get_best_parsable_locale(module, ['en_US', 'en_CA', 'fake_locale'], raise_on_locale=False) == 'C'
    # prefer en_US and if it doesn't exist fail

# Generated at 2022-06-20 16:02:34.502789
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    import os
    import tempfile
    if sys.version_info[0] < 3:
        import mock
    else:
        from unittest import mock

    #
    # Mock out the functions we need
    #
    def locale_exists():
        return True
    commands_orig = os.getenv("__ansible_commands_all__", None)
    os.environ["__ansible_commands_all__"] = json.dumps({'locale': 'localefake'})
    with mock.patch.dict('os.environ', os.environ):
        with mock.patch("ansible.module_utils.basic.AnsibleModule.get_bin_path", side_effect=locale_exists):
            from ansible.module_utils.basic import AnsibleModule
            module

# Generated at 2022-06-20 16:02:39.930584
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    m = ansible.module_utils.basic.AnsibleModule(
        argument_spec={}
    )

    # Make a fake environment variable
    os.environ['LANG'] = 'en_US.utf8'
    assert get_best_parsable_locale(m) == 'en_US.utf8'

    # Make a fake environment variable
    os.environ['LANG'] = 'C.UTF-8'
    assert get_best_parsable_locale(m) == 'C.UTF-8'

    # Make a fake environment variable
    os.environ['LANG'] = 'en_US'
    assert get_best_parsable_locale(m) == 'POSIX'

    # Make a fake environment variable
    os.environ

# Generated at 2022-06-20 16:02:44.676937
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    ''' A unit test for the function get_best_parsable_locale '''
    import ansible.module_utils.basic as basic

    test_module = basic.AnsibleModule(argument_spec={'test_args': dict(type='list', elements='str')})

    ret_val = get_best_parsable_locale(test_module)
    assert ret_val == 'C'

# Generated at 2022-06-20 16:02:54.367125
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import ctypes
    from ansible.module_utils._text import to_bytes, to_text

    # Test for error handling in case the locale tool is missing
    test_module = AnsibleModule(argument_spec={})
    test_module.get_bin_path = lambda command, required=False: None
    test_module.run_command = lambda args, check_rc=None: (0, '', '')
    best_locale = test_module.get_best_parsable_locale()
    assert best_locale == "C"

    # Mock the locale tool to return a given locale

# Generated at 2022-06-20 16:03:05.239485
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    m = AnsibleModule(argument_spec={})

    # Test without "locale" tool in PATH
    preferences = ['en_US.utf8']
    found = get_best_parsable_locale(m, preferences)
    assert found == 'C', "found=%s did not match expectation" % found

    # Test with "locale" tool in PATH, but no preferences
    m = AnsibleModule(argument_spec={})
    found = get_best_parsable_locale(m)
    assert found == 'C', "found=%s did not match expectation" % found

    # Test with "locale" tool in PATH, preferences with no matches
    m = AnsibleModule(argument_spec={})

# Generated at 2022-06-20 16:03:10.944386
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
       This unit test is to make sure that the function get_best_parsable_locale does
       not throw any exceptions.
    '''

    from ansible.module_utils.basic import AnsibleModule
    #import ansible.module_utils.basic
    #ansible.module_utils.basic.AnsibleModule = AnisbleModule
    fakeModule = AnsibleModule(argument_spec=dict())
    get_best_parsable_locale(fakeModule)

# Generated at 2022-06-20 16:03:50.472366
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule({})

    # No locale found
    module.run_command = lambda x: (1, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # List of 'C' locales
    module.run_command = lambda x: (0, 'C\nC.utf8\nC.UTF-8\n', '')
    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, preferences=['en_US', 'fr']) == 'C'
    assert get_best_parsable_locale(module, preferences=['C.UTF-8', 'fr']) == 'C.UTF-8'

# Generated at 2022-06-20 16:03:57.398560
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = DummyAnsibleModule()

    assert 'C' == get_best_parsable_locale(module)
    assert module.warn_args[0].startswith('Locale selection')
    assert module.warn_args[0].endswith('not found, defaulting to C locale')

    module = DummyAnsibleModule(locale_rc=1, locale_out="")
    assert 'C' == get_best_parsable_locale(module)
    assert module.warn_args[0].startswith('Unable to get')
    assert module.warn_args[0].endswith('rc=1: No output')

    module = DummyAnsibleModule(locale_rc=-2, locale_err="Forced Failure")
    assert 'C' == get_best_parsable_

# Generated at 2022-06-20 16:04:03.299531
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    mod = AnsibleModule(
        argument_spec=dict(
            preferences=dict(type='list', default=None),
            raise_on_locale=dict(type='bool'),
        )
    )

    ret = get_best_parsable_locale(mod, preferences=mod.params['preferences'],
                                   raise_on_locale=mod.params['raise_on_locale'])
    assert ret == 'C'

# Generated at 2022-06-20 16:04:09.188377
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Fake module
    class FakeModule:
        def __init__(self, path):
            self.path = path

        def get_bin_path(self, name):
            return self.path

        def run_command(self, args):
            if self.path is not None:
                return (0, '%s.utf8\n%s' % (self.path, self.path), '')
            else:
                return (1, '', '')

    # With an existing 'locale' executable, can retrieve the correct locale
    fm = FakeModule('C.utf8')
    assert get_best_parsable_locale(fm, ['C.utf8', 'en_US.utf8']) == 'C.utf8'
    fm = FakeModule('en_US.utf8')
    assert get_

# Generated at 2022-06-20 16:04:21.580885
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    import tempfile
    import os
    import stat
    import shutil
    import atexit

    def clean_up_locale_tool():
        shutil.rmtree(temp_locale_dir)

    mod_name = 'ansible.module_utils.basic.best_parsable_locale'
    mod_path = '%s.get_best_parsable_locale' % (mod_name)
    atexit.register(clean_up_locale_tool)

    # Make a temp dir for our tests
    temp_locale_dir = tempfile.mkdtemp()

    # Add the temp dir to the path
    os.environ['PATH'] = '%s%s%s' % (os.environ['PATH'], os.pathsep, temp_locale_dir)

# Generated at 2022-06-20 16:04:28.839857
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Helper function for loading modules for testing
    from ansible.module_utils.six import PY2
    if PY2:
        from ansible.module_utils import basic
    else:
        from ansible.module_utils import basic

    class ModuleHelper(basic.AnsibleModule):
        def __init__(self, *args, **kwargs):
            self.params = {}
            self.result = {}
            basic.AnsibleModule.__init__(self, *args, **kwargs)

        def get_bin_path(self, arg, *args, **kwargs):
            return arg

        def run_command(self, arg, *args, **kwargs):
            return 0, arg, ''


    # Test that we get the first listed locale