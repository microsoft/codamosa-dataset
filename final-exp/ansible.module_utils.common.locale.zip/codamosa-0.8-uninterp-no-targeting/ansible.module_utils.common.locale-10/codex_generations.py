

# Generated at 2022-06-20 15:54:38.766245
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import QUIET_WARNINGS, AnsibleModule
    from ansible.module_utils.pycompat24 import get_exception
    module = AnsibleModule(argument_spec={})
    preferences = ['en_US.utf8', 'en_US.UTF-8', 'en_US', 'C.UTF-8']
    assert 'C.utf8' == get_best_parsable_locale(module, preferences, raise_on_locale=True)
    try:
        get_best_parsable_locale(module, preferences, raise_on_locale=True)
    except Exception as e:
        assert False, 'Should not have raised an exception'
    # Test that we raise an exception if locale fails to execute

# Generated at 2022-06-20 15:54:49.324491
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    preferences = ['fr_CA.utf8', 'C', 'POSIX']
    locale_list = ['fr_CA.utf8', 'C', 'POSIX']

    class MyModuleError(Exception):
        def __init__(self, s):
            self.s = s

        def __str__(self):
            return self.s

    class MyModule(object):
        def __init__(self):
            self.params = {}
            self.fail_json = False

        def fail_json_from_assert(self, *args, **kwargs):
            self.fail_json = True

        def get_bin_path(self, *args, **kwargs):
            return 'locale'


# Generated at 2022-06-20 15:54:58.937591
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.six import PY3
    from ansible.module_utils.basic import AnsibleModule
    import sys

    if PY3:
        Unicode = str
    else:
        Unicode = unicode

    def _my_cmd_wrapper(cmd, **kwargs):
        """
        Mock command run wrapper
        """
        cmds = {
            '/bin/locale -a': {
                "stdout": "C\nen_US.utf8\nen_US.UTF-8",
                "stderr": "",
                "rc": 0,
            },
        }
        if cmd in cmds:
            return cmds[cmd]
        raise ValueError


# Generated at 2022-06-20 15:55:09.910172
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    This is a simple unit test for the get_best_parsable_locale function.
    It does the following:
    1. Imports the module.
    2. Creates a class TestModule containing member variables for best_parsable_locale
       and a function called run_command.
    3. Creates a list of available locales and a list of preferred locales.
    4. Sets the class variable best_parsable_locale to the result returned by the
       get_best_parsable_locale function.
    5. Creates a list of expected output (in this case, the first preferred locale
       "en_US" or "en_US.utf8" will be returned by the function.
    6. Runs the test.
    '''

    # import module

# Generated at 2022-06-20 15:55:20.922475
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Test that when there is a default locale and the right list of preferred
    locales is given, it returns the best possible locale in English
    '''
    import sys
    import os
    import ansible.modules.system.locale as locale_module
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleFallbackNotFound
    from ansible.module_utils.six import PY2
    import pytest

    class FakeModule(object):
        def __init__(self, *args, **kwargs):
            self.params = {}
            self.args = args
            self.kwargs = kwargs
            self.exit_args = {}
            self.fail_json_called = False
            self.checked = False
            self.rc = 0
           

# Generated at 2022-06-20 15:55:31.949110
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    am = AnsibleModule(
        argument_spec = dict()
    )

    # test if no executable is found
    assert 'C' == get_best_parsable_locale(am), "Should fall back to 'C' locale by default"

    # TODO: Test if locale is found but not locale -a.
    # That is actually not possible, as the no executable case is being handled
    # before we call locale -a
    # Test if locale is found, but locale -a returns an error
    # Test if locale is found and locale -a returns nothing

    # Test if locale is found, but locale -a returns an error
    am.run_command = lambda x: (1, '', 'Error\n')
    assert 'C' == get_best_parsable_

# Generated at 2022-06-20 15:55:40.333325
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule

    from ansible.module_utils.six import PY2

    module = AnsibleModule(
        argument_spec=dict(),
    )

    if PY2:
        # TODO: Fix this unit test for Python3
        assert get_best_parsable_locale(module) == 'C'
    else:
        assert get_best_parsable_locale(module) == 'C.UTF-8'

# Generated at 2022-06-20 15:55:47.283964
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Test the locale utility
    '''
    class MockModule(object):
        '''
        Mock class to use with the locale utility
        '''
        def __init__(self):
            self.params = {}
            self.fail_json_called = False

        def fail_json(self, *args, **kwargs):
            self.fail_json_called = True
            self.fail_json_args = args
            self.fail_json_kwargs = kwargs

    class MockCmd(object):
        '''
        Mock class to use with the locale utility
        '''
        def __init__(self, cmd, module):
            self.cmd = cmd
            self.module = module

        def __call__(self, command, check_rc=False):
            cmd = ' '.join(command)



# Generated at 2022-06-20 15:55:56.440810
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule
    mock_module = AnsibleModule(
        argument_spec = dict(),
    )
    mock_module.run_command = lambda x: (0, to_bytes("C.utf8\nC.UTF-8\nC\nen_US.utf8\nen_US\nen_US.UTF-8\n"), to_bytes(''))
    assert get_best_parsable_locale(mock_module) == 'C.utf8'
    assert get_best_parsable_locale(mock_module, preferences=['en_US.utf8']) == 'en_US.utf8'

# Generated at 2022-06-20 15:55:57.814573
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    print(get_best_parsable_locale(object))

# Generated at 2022-06-20 15:56:12.853129
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # empty case
    assert get_best_parsable_locale(None) == 'C'

    # locale command not found
    class FakeModule:
        def __init__(self):
            self.params = None

        def get_bin_path(self, bin):
            return None

        def run_command(self, command):
            return (0, '', '')

    assert get_best_parsable_locale(FakeModule()) == 'C'

    # locale command returned no output
    class FakeModule2:
        def __init__(self):
            self.params = None

        def get_bin_path(self, bin):
            return 'locale'

        def run_command(self, command):
            return (0, '', '')


# Generated at 2022-06-20 15:56:18.618351
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys

    try:
        from unittest import mock
    except:
        try:
            import mock
        except:
            # TODO: find a proper way to do this
            #
            # Need to do this because we might be running
            # this unit test inside a virtualenv.
            #
            # In that case, mock is an indirect dependency
            # of this module and might not be installed.
            #
            # So we will just jump to the `else` clause and
            # skip the tests in this case.
            #
            pass

    if sys.version_info[:2] == (2, 6):
        try:
            import unittest2 as unittest
        except ImportError:
            import unittest
    else:
        import unittest


# Generated at 2022-06-20 15:56:30.291208
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    class MockAnsibleModule():

        def __init__(self):
            pass

        def get_bin_path(self, command):
            if command == "locale":
                return "/usr/bin/locale"
            else:
                return "command_not_found"

        def run_command(self, cmd):
            test_results = {
                "/usr/bin/locale -a": (0, "en_US\nen_US.UTF-8", ""),
                "/usr/bin/locale -a --no-wrapper": (0, "en_US\nen_US.UTF-8", ""),
                "/usr/bin/locale -a --wrong-option": (255, "", "unknown option `wrong-option'"),
            }

# Generated at 2022-06-20 15:56:40.926428
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.basic import AnsibleModule

    preferences = ['C.utf8', 'fr_FR.utf8', 'C', 'POSIX']
    found = 'C'  # default posix, its ascii but always there

    # get_best_parsable_locale doesn't care about the AnsibleModule arguments
    module = AnsibleModule(argument_spec={})

    # available doesn't contain any valid locales
    available = []
    assert get_best_parsable_locale(module, preferences, False) == found
    assert get_best_parsable_locale(module, preferences, True) == found

    # available contains a valid locale
    available = ['C.utf8', 'fr_FR.utf8', 'POSIX']

# Generated at 2022-06-20 15:56:47.983500
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Get a locale list
    def _run_command_side_effect(args, **kwargs):
        if args == ['/usr/bin/locale', '-a']:
            return 0, '\n'.join(locales), ''
        raise Exception

    # Fixture
    preferences=['C', 'POSIX', 'foo']

    # Test 1: We can't find a preferred locale, so we should get the first locale of the list
    locales = ['foo', 'POSIX', 'C']
    found = get_best_parsable_locale(None, preferences, _run_command=_run_command_side_effect)
    assert found == 'foo'

    # Test 2: We should get the preferred locale from the top of the list
    locales = ['foo', 'bar', 'POSIX', 'C']
   

# Generated at 2022-06-20 15:56:50.826000
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    preferences = ['en_US.utf8', 'C', 'POSIX']
    module = AnsibleModule(argument_spec=dict(preferences=dict(type='list', default=preferences)))
    locale = get_best_parsable_locale(module)
    assert locale == 'en_US.utf8' or locale == 'C'

# Generated at 2022-06-20 15:57:02.197896
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Tests the function get_best_parsable_locale
    Check that there is always a return value (C or an other language)
    '''

    # Mock the function
    mock_module = MockAnsibleModule('', [], [])
    # This would be the command you want to patch
    with patch('ansible.module_utils._text.get_best_parsable_locale') as p:
        # this is the mock of the instance
        mock_instance = p.return_value
        # This is what you wish to return
        mock_instance.run_command.return_value = (0, '', '')

    from ansible.module_utils._text import get_best_parsable_locale

    # Call the function

# Generated at 2022-06-20 15:57:12.775424
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    result = get_best_parsable_locale(module)

    assert result == 'C'

    preferred = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    module.run_command = fake_run_command_return(0, '\n'.join(preferred), None)

    result = get_best_parsable_locale(module)
    assert result == preferred[1]

    preferred = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    module.run_command = fake_run_command_return(1, '\n'.join(preferred), 'Some Error')

    result = get_best_pars

# Generated at 2022-06-20 15:57:22.221753
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    import copy
    import unittest

    class TestModule():
        def __init__(self):
            self.run_command_calls = 0
            self.get_bin_path_calls = 0
            self.rc = 0
            self.out = None
            self.err = None
            self.fail = False
            self.failure = False

        def get_bin_path(self, module):
            self.get_bin_path_calls += 1
            if module == 'locale':
                if self.fail:
                    return None
            return 'locale'

        def run_command(self, cmd):
            self.run_command_calls += 1
            if self.fail:
                self.rc = 1
                self.out = None
                self.err = 'locale error'

# Generated at 2022-06-20 15:57:31.888132
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    # Test for existence of first element in output
    module = AnsibleModule(argument_spec={})
    module.params['name'] = 'foobar'
    p_locale = get_best_parsable_locale(module)
    assert p_locale == 'C', "Expected best parsable locale to be 'C'"

    # Test for existence of second element in output
    module = AnsibleModule(argument_spec={})
    module.params['name'] = 'foobar'
    pref = ['foo', 'bar']
    p_locale = get_best_parsable_locale(module, pref)
    assert p_locale == 'bar', "Expected best parsable locale to be 'bar'"

# Generated at 2022-06-20 15:57:48.536524
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch
    from ansible.module_utils.basic import AnsibleModule

    with patch.dict(sys.modules, {"ansible.module_utils.basic": AnsibleModule}):
        from ansible.module_utils.basic import get_best_parsable_locale
        module = AnsibleModule(argument_spec={})
        ret = get_best_parsable_locale(module)
        assert ret == 'C'

        ret = get_best_parsable_locale(module, preferences=['C'])
        assert ret == 'C'

        ret = get_best_parsable_locale(module, preferences=['xx_XX.utf8'])
        assert ret == 'C'



# Generated at 2022-06-20 15:57:56.377131
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # The 'C' locale exists on all unix-like operating systems
    assert get_best_parsable_locale(module) == 'C'

    preferences = ['POSIX', 'C']
    assert get_best_parsable_locale(module, preferences=preferences) == 'C'

    preferences = ['POSIX', 'Fake Locale']
    assert get_best_parsable_locale(module, preferences=preferences) == 'C'

# Generated at 2022-06-20 15:58:01.747522
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({})

    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, preferences=['en_AU.utf8']) == 'C'
    assert get_best_parsable_locale(module, preferences=['C']) == 'C'
    assert get_best_parsable_locale(module, raise_on_locale=True) == 'C'

# Generated at 2022-06-20 15:58:11.344862
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule()
    # Test 1: Test that with no preference, we return 'C'
    # Test 2: Test that with preference, we return the last value in the list
    # Test 3: Test that with an invalid preference, we return the last valid value in the list

    test_data = {
        'test_case': [1, 2, 3],
        'preferences': [None, ['en_US.utf8', 'C', 'POSIX', 'C.utf32', 'C.ISO8859-1'],
                       ['C.utf32', 'C.ISO8859-1']],
        'result': ['C', 'C.utf8', 'C'],
        'return_code': [0, 0, 0]
    }


# Generated at 2022-06-20 15:58:16.783430
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    m = AnsibleModule(supports_check_mode=False)

    # Test with default
    locale = get_best_parsable_locale(m)
    assert locale == 'C'

    # Test with explicit default
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    locale = get_best_parsable_locale(m, preferences)
    assert locale == 'C'

    # Test with non-existent locale
    preferences = ['doesnotexist']
    locale = get_best_parsable_locale(m, preferences, raise_on_locale=True)
    assert locale == 'C'

# Generated at 2022-06-20 15:58:23.139810
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    # Empty
    m = AnsibleModule(argument_spec=dict())
    found = get_best_parsable_locale(m)
    assert found == 'C'

    # C.utf8
    m = AnsibleModule(argument_spec=dict())

    class FakeOut:
        def __init__(self, out):
            self.out = out
            self.err = ''
            self.rc = 0

    fakeout_utf8 = FakeOut('C\nen_US.utf8\nen_US\nzh_CN.utf8')
    m.run_command = lambda x: fakeout_utf8
    found = get_best_parsable_locale(m)
    assert found == 'C.utf8'

    # en_US.

# Generated at 2022-06-20 15:58:30.914161
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import tempfile
    import os
    import stat
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.six import PY3
    if PY3:
        from unittest.mock import patch,MagicMock
    else:
        from mock import patch, MagicMock

    class mymodule(AnsibleModule):
        def __init__(self):
            super(mymodule, self).__init__(
                argument_spec = dict()
            )
            self.params = MagicMock(return_value=dict())
            self.params.__getitem__ = MagicMock(return_value=dict())

# Generated at 2022-06-20 15:58:41.112706
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import os
    import tempfile
    import time
    import shutil
    import locale
    import locale_compat
    import json
    import pytest

    try:
        from ansible.module_utils import basic
    except ImportError:
        from ..module_utils import basic

    # TODO: make a fake AnsibleModule
    class FakeAnsibleModule(object):
        def __init__(self, facts={}):
            self.facts = facts
            self.params = {
                'ANSIBLE_PERSISTENT_LOCALE': 'True'
            }
            self.tempdir = tempfile.mkdtemp()
            self.locales_dir = os.path.join(self.tempdir, 'locales')
            os.mkdir(self.locales_dir)

# Generated at 2022-06-20 15:58:48.567113
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    import unittest
    if sys.version_info[0] < 3:
        from mock import patch, Mock
    else:
        from unittest.mock import patch, Mock

    class TestGetBestParsableLocale(unittest.TestCase):

        @patch("ansible.module_utils.basic.get_bin_path")
        @patch("ansible.module_utils.basic.AnsibleModule.run_command")
        def test_default_fallback(self, mock_run_command, mock_get_bin_path):
            # default values without a locale binary
            mock_get_bin_path.return_value = None
            mock_run_command.return_value = (1, "", "")

            # test default fallback
            mod = Mock()
            result = get_best

# Generated at 2022-06-20 15:58:51.337206
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    am = AnsibleModule(argument_spec={})
    assert am.get_best_parsable_locale() == 'C'

# vim: expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-20 15:59:07.573248
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None) == 'C'
    assert get_best_parsable_locale(None, preferences=['en_US.utf8']) == 'en_US.utf8'
    assert get_best_parsable_locale(None, preferences=['en_US.utf8', 'C']) == 'en_US.utf8'
    assert get_best_parsable_locale(None, preferences=['en_US.utf8', 'C', 'POSIX']) == 'en_US.utf8'
    assert get_best_parsable_locale(None, preferences=['POSIX', 'C']) == 'C'
    assert get_best_parsable_locale(None, preferences=['POSIX']) == 'C'
    assert get_

# Generated at 2022-06-20 15:59:14.820732
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        tests get_best_parsable_locale
    '''

    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})

    # default posix, its ascii but always there
    assert 'C' == get_best_parsable_locale(module)

    # OSX and FreeBSD should have en_US.UTF-8
    assert 'en_US.UTF-8' == get_best_parsable_locale(module, ['en_US.utf8'])

# Generated at 2022-06-20 15:59:22.830524
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    preferences = [
        'C.utf8', 'en_US.utf8', 'C', 'POSIX'
    ]

    # Test case when locale -a returns empty string
    out = ""
    return_value = get_best_parsable_locale(out, preferences)
    assert return_value == 'C'

    # Test case when none of the preferences are found
    out = "C.utf8\nen_IN.utf8\nen_US.utf8\nen_US\nen_IN"
    return_value = get_best_parsable_locale(out, preferences)
    assert return_value == 'C'

    # Test case when a perfect match is found
    out = "C.utf8\nen_IN.utf8\nen_US.utf8\nen_US\nen_IN"
    preferences

# Generated at 2022-06-20 15:59:33.098738
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    test get_best_parsable_locale
    '''
    from ansible.module_utils.basic import AnsibleModule
    am = AnsibleModule()
    am.get_bin_path = lambda *args, **kwargs: '/usr/bin/locale'
    am.run_command = lambda *args, **kwargs: (0, 'C\nPOSIX\nen_US.utf8\nC.utf8', '')
    assert get_best_parsable_locale(am) == 'C.utf8'
    am.run_command = lambda *args, **kwargs: (0, 'C\nen_US.utf8\nC.utf8\nPOSIX', '')
    assert get_best_parsable_locale(am) == 'C.utf8'


# Generated at 2022-06-20 15:59:41.074012
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import mock
    import sys

    if sys.version_info < (2, 7):
        try:
            import unittest2 as unittest
        except ImportError:
            raise ImportError("Please install unittest2 to run tests with Python2.6")
    else:
        import unittest


    class AnsibleModule_mock(object):
        def __init__(self, **kwargs):
            return

        def get_bin_path(self,name, required=False):
            if name == 'locale':
                return '/bin/broken/locale'
            raise RuntimeError("{} not supported by get_bin_path".format(name))


# Generated at 2022-06-20 15:59:45.762752
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.basic import AnsibleModule
    tmp = get_best_parsable_locale(AnsibleModule())
    assert tmp == 'C'


# Generated at 2022-06-20 15:59:52.856347
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # The values returned will depend on the local system
    # and its locale setup. This test only tests that the
    # function is not throwing any exception

    from ansible.module_utils.basic import AnsibleModule, missing_required_lib
    if missing_required_lib('parsedatetime', url='https://pypi.python.org/pypi/parsedatetime'):
        module = None
    else:
        from ansible.module_utils.basic import AnsibleModule
        module = AnsibleModule({})
        get_best_parsable_locale(module)

# Generated at 2022-06-20 16:00:03.208695
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import unittest
    import tempfile
    import shutil
    import os
    from ansible.module_utils.basic import AnsibleModule

    # We need a locale file or else fake_module will fail
    tmp = tempfile.mkdtemp()

    fd, tmpfile = tempfile.mkstemp(dir=tmp)
    os.close(fd)

    os.environ['LC_ALL'] = 'C'
    os.environ['LANG'] = 'C'
    os.environ['LANGUAGE'] = 'C'

    os.putenv('LC_ALL', 'C')
    os.putenv('LANG', 'C')
    os.putenv('LANGUAGE', 'C')

    def fake_module(**kwargs):
        return AnsibleModule(**kwargs)


# Generated at 2022-06-20 16:00:08.984371
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict(locale=dict(type='path')))

    try:
        module.get_bin_path.set_defaults(locale_path='/usr/bin')
        mod_path = module.get_bin_path('locale')
        assert mod_path == '/usr/bin/locale'
    except AttributeError:
        module.get_bin_path = lambda x: '/usr/bin/locale'


# Generated at 2022-06-20 16:00:18.860965
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    class MockModule(object):
        '''create a mock module that can be passed in for testing'''
        def get_bin_path(self, bin):
            return 'locale'

        def run_command(self, cmd):
            '''provide mocked output for locale -a'''
            return [0, 'C', '']

    # test that we receive a proper response when no preferences are given
    mm = MockModule()
    assert 'C' == get_best_parsable_locale(mm)

    # test that a blank list of preferences returns the default
    mm = MockModule()
    assert 'C' == get_best_parsable_locale(mm, [])

    # test that a preference that is not available returns the default
    mm = MockModule()
    assert 'C' == get_best_parsable

# Generated at 2022-06-20 16:00:34.708589
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule()
    prefs = ['fr_FR.utf8', 'C.utf8', 'en_US.utf8', 'C', 'POSIX']
    good_locale = get_best_parsable_locale(module, preferences=prefs)
    assert good_locale == 'C', 'Did not return default locale'

    raise_on_locale = True
    try:
        good_locale = get_best_parsable_locale(module, preferences=prefs,
                                               raise_on_locale=raise_on_locale)
        assert False, 'Did not raise'
    except (RuntimeWarning, AssertionError):
        pass

# Generated at 2022-06-20 16:00:38.996855
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Mock the module
    class AnsibleModule:
        def __init__(self):
            self.params = {}

        def get_bin_path(self, command):
            return "/bin/" + command

        def run_command(self, command):
            return (0, "", "")

    # Test the function
    module = AnsibleModule()
    assert get_best_parsable_locale(module) == "C"

# Generated at 2022-06-20 16:00:47.123185
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Test with the following locales available
    available_locales = ['C.UTF-8', 'en_US.UTF-8', 'POSIX']
    # Expected locale that would be returned by running the function
    expected_locale = 'en_US.UTF-8'

    # Test that the function does not crash
    result = get_best_parsable_locale(available_locales=available_locales)
    # Test that the expected locale was returned
    assert expected_locale == result

# Generated at 2022-06-20 16:00:55.017616
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict())

    assert 'C' == get_best_parsable_locale(module, preferences=None, raise_on_locale=False)

    module = AnsibleModule(argument_spec=dict())

    try:
        get_best_parsable_locale(module, preferences=None, raise_on_locale=True)
        raise Exception("Test failed, should have raised an exception")
    except RuntimeWarning:
        pass




# Generated at 2022-06-20 16:01:07.752993
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    """ verify that the correct locale is returned when using the get_best_parsable_locale()
    function
    """
    from ansible.module_utils.basic import AnsibleModule

    # Build up mocks of the AnsibleModule object
    def mock_run_command(cmd, path=None, use_unsafe_shell=False):
        """ Return a mock result for the 'locale -a' command """
        if cmd[0] == 'locale' and cmd[1] == '-a':
            stdout = 'en_US.utf8\nen_US\nen_US.ASCII\nen_US.ISO-8859-1\nen_CA.utf8\nen_CA'
            return 0, stdout, ''
        else:
            return 1, None, ''

# Generated at 2022-06-20 16:01:17.064527
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Import the function into the test namespace
    from ansible.module_utils.locale import get_best_parsable_locale

    # Import the FakeModule class
    from ansible.module_utils.basic import AnsibleModule
    class FakeModule(AnsibleModule):
        def get_bin_path(self, arg):
            return '/usr/bin/locale'
        def run_command(self, arg):
            return 0, 'C en_US.utf8', ''

    m = FakeModule(argument_spec={})
    rc = get_best_parsable_locale(m)
    assert rc == 'C'

    m = FakeModule(argument_spec={})
    rc = get_best_parsable_locale(m, raise_on_locale=True)
    assert rc == 'C'

# Generated at 2022-06-20 16:01:18.776875
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    locale = get_best_parsable_locale(None,preferences=['en_US.UTF-8'])
    assert locale == 'en_US.UTF-8'

# Generated at 2022-06-20 16:01:23.924260
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from units.compat import unittest

    from ansible.module_utils.basic import AnsibleModule

    class TestModule(object):
        def __init__(self, found, available=None, locale_rc=0, locale_err='', locale_out=''):
            self.params = {}
            self.fail_json = Exception

            self.mock_run_command = self.MockRunCommand(self, locale_rc, locale_err, locale_out)
            self.get_bin_path = self.MockGetBinPath(self, found, available)

        class MockRunCommand(object):
            def __init__(self, testmodule, rc, err, out):
                self.testmodule = testmodule
                self.rc = rc
                self.err = err
                self.out = out


# Generated at 2022-06-20 16:01:28.927030
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    desired_locale = get_best_parsable_locale(module, None, False)
    assert desired_locale == 'C'

# Generated at 2022-06-20 16:01:37.715107
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    module = basic.AnsibleModule(argument_spec=dict())

    # No locale installed

    module.run_command = lambda x: (1, '', 'locale: Command not found')

    # Should return just plain C
    assert get_best_parsable_locale(module) == 'C'

    # Some C locales and English
    module.run_command = lambda x: (0, '''C
en_US
en_US.ISO8859-1
en_US.utf8''', '')

    assert get_best_parsable_locale(module) == 'C'

    # If a language is preferred, it should be used

# Generated at 2022-06-20 16:01:57.581320
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import string_types

    module = AnsibleModule()

    locale = get_best_parsable_locale(module)

    assert isinstance(locale, string_types)

    locale = get_best_parsable_locale(module, ['en_US.utf8'])
    assert locale == 'en_US.utf8'

# Generated at 2022-06-20 16:02:00.091597
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    test = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(test) == 'C', 'Locale should be C'

# Generated at 2022-06-20 16:02:10.482998
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    ''' test_get_best_parsable_locale '''
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import env_fallback
    from ansible.module_utils.six import PY3
    from ansible.module_utils.pycompat24 import get_exception

    module = AnsibleModule(argument_spec={})

    # The locale module has no optional parameters
    params = module.params
    env = os.environ

    env['LC_ALL'] = 'C'

    if not PY3:
        locale_module = __import__("locale")
        locale_module.resetlocale(locale_module.LC_ALL)


# Generated at 2022-06-20 16:02:13.097195
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    test_module = AnsibleModule(
        argument_spec={},
    )

    assert 'C' == get_best_parsable_locale(test_module)

# Generated at 2022-06-20 16:02:20.089566
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    test_preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']

    test_out = ['an_AN', 'C.utf8', 'POSIX', 'C']
    test_rc = 0
    assert 'C.utf8' == get_best_parsable_locale(test_rc, test_out, test_preferences)

    test_out = ['an_AN', 'POSIX', 'C']
    test_rc = 0
    assert 'POSIX' == get_best_parsable_locale(test_rc, test_out, test_preferences)

    test_out = ['an_AN', 'POSIX', 'C']
    test_rc = 0

# Generated at 2022-06-20 16:02:27.470872
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import os
    import tempfile
    import shutil

    # test preset locale
    os.environ['LC_ALL'] = 'en_US.utf8'
    assert(get_best_parsable_locale(None, ['en_US.utf8', 'en_US.UTF-8', 'C']) == 'en_US.utf8')
    del os.environ['LC_ALL']

    # test new POSIX standard
    os.environ['LC_ALL'] = 'C.utf8'
    assert(get_best_parsable_locale(None, ['C.utf8', 'C.UTF-8', 'C']) == 'C.utf8')
    del os.environ['LC_ALL']

    os.environ['LC_ALL'] = 'C'

# Generated at 2022-06-20 16:02:33.949295
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    sys.path.append('/Users/cbrandtbuffalo/Documents/personal/ansible/lib')
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    result = get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX'], raise_on_locale=False)
    assert result == 'C'

# Generated at 2022-06-20 16:02:39.659902
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    am = AnsibleModule(
        argument_spec=dict(
            preferences=dict(type='list', default=None),
            raise_on_locale=dict(type='bool', default=False),
        )
    )
    locale_output = b'''\
C
C.UTF-8
en_US.utf8
POSIX
'''
    am.run_command = MagicMock(return_value=(0, locale_output, ''))
    assert get_best_parsable_locale(am) == 'en_US.utf8'

    am.run_command.return_value = (1, '', 'Failed to run locale')

# Generated at 2022-06-20 16:02:49.526752
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    import os
    import unittest
    import string
    import random

    # Python 2/3 compatibility
    if sys.version_info[0] == 2:
        from StringIO import StringIO
    else:
        from io import StringIO

    from ansible.module_utils import basic

    class MockAnsibleModule(object):

        def __init__(self):
            self.params = {}
            self.fail_json = Mock(side_effect=self.exit_json)
            self.exit_json = Mock()


# Generated at 2022-06-20 16:02:56.965736
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils import basic
    from ansible.module_utils.common._collections_compat import Mapping

    class MyModule(basic.AnsibleModule):

        def get_bin_path(self, arg):
            if arg == 'locale':
                return 'locale'
            else:
                return None

        def run_command(self, args, check_rc=True):
            fout = open('tests/unit/module_utils/test_get_best_parsable_locale_locale_a', 'r')
            out = fout.read()
            fout.close()
            return 0, out, ''

        def __init__(self, **kwargs):
            super(MyModule, self).__init__(**kwargs)


# Generated at 2022-06-20 16:03:13.723744
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(
        module=None,
        preferences=['de_DE', 'en_US'],
        raise_on_locale=False
    ) == 'C'


# Generated at 2022-06-20 16:03:24.398403
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import unittest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.pycompat24 import get_exception

    class GetBestParsableLocaleTest(unittest.TestCase):
        def test_get_best_parsable_locale(self):
            def run_command(self, args, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False, path_prefix=None, cwd=None,
                use_unsafe_shell=False, prompt_regex=None, environ_update=None, umask=None, encoding=None, errors=None,
                expand_user_and_vars=True):
                return 0, '', None


# Generated at 2022-06-20 16:03:36.750137
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    import tempfile

    # create a temp module to simulate ansible module.
    # We will use this module to provide the mocked
    # modules that is needed to test the above function.
    tmp_fp = tempfile.NamedTemporaryFile()

# Generated at 2022-06-20 16:03:45.606208
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    """Execute get_best_parsable_locale function."""
    from ansible_collections.ansible.community.plugins.module_utils.basic import AnsibleModule

    module = AnsibleModule()
    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, preferences=["en_US.utf8"]) == 'en_US.utf8'
    assert get_best_parsable_locale(module, preferences=["en_US.utf8", "foo"]) == 'en_US.utf8'
    assert get_best_parsable_locale(module, preferences=["foo"]) == 'C'

# Generated at 2022-06-20 16:03:54.394859
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    import json
    import os

    module = AnsibleModule(
        argument_spec=dict(),
    )

    locale = get_best_parsable_locale(module)
    assert locale

    # nothing should be returned as the binary path does not exist
    module.module_implementation_prereqs['locale'] = 'fakepath'
    locale = get_best_parsable_locale(module)
    assert locale == 'C'

    # run the function with all possible return messages from the locale command
    # all successful paths tested


# Generated at 2022-06-20 16:03:59.885224
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    module_mock = None

# Generated at 2022-06-20 16:04:06.837562
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    test_module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )

    try:
        assert get_best_parsable_locale(test_module) == 'C'
    except RuntimeWarning:
        test_module.fail_json("No 'locale' tool available")

    assert get_best_parsable_locale(test_module, ['C.utf8', 'en_US.utf8', 'POSIX', 'C']) == 'C'
    assert get_best_parsable_locale(test_module, ['C.utf8', 'en_US.utf8', 'C']) == 'C'

# Generated at 2022-06-20 16:04:18.829974
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    # Construct locale with locale command
    locale = ['locale']
    # Construct locale with locale command (alternate)
    locale_alt = ['localeconf', '-c']
    # Construct fake AnsibleModule class
    module = AnsibleModule(argument_spec={})

    # Test for locale command
    module.get_bin_path = lambda x: {'locale':locale,'localeconf':locale_alt}[x]
    # Test case 1: Get the 'C' locale
    assert get_best_parsable_locale(module,preferences=['C']),'C'
    # Test case 2: Get the locale in preferences

# Generated at 2022-06-20 16:04:26.050576
# Unit test for function get_best_parsable_locale