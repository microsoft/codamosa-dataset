

# Generated at 2022-06-20 15:54:32.252249
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Test default behavior of 'C'
    assert get_best_parsable_locale(None) == 'C'

    # Test default preferences
    pref = 'C.utf8'

    assert get_best_parsable_locale(None, pref) == pref

    # Test specific preferences
    pref = 'de_AT.utf8'
    pref_list = [pref]
    assert get_best_parsable_locale(None, pref_list) == pref

# Generated at 2022-06-20 15:54:43.902573
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import mock
    from ansible.module_utils import basic
    from ansible.module_utils.local_ansible_utils_extension import LocalAnsibleModule

    module = LocalAnsibleModule()

    # Mock 'module' instance with defaults and return_values
    module.get_bin_path = mock.MagicMock(return_value=True)
    module.run_command = mock.MagicMock(return_value=(0, "C\nC.utf8\nen_US.UTF-8\nPOSIX", ""))

    # Test when 'preferences' is None
    locale = get_best_parsable_locale(module)
    module.get_bin_path.assert_called_once_with("locale")

# Generated at 2022-06-20 15:54:53.560551
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Mock AnsibleModule class
    class MockAnsibleModule:
        def __init__(self, **kwargs):
            self.params = kwargs

        def get_bin_path(self, cmd):
            return '/bin/locale'

        def run_command(self, cmd):
            return 0, 'C.UTF-8 C.utf8 C en_US.UTF-8 en_US.utf8 en_US', None

    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    module = MockAnsibleModule()
    assert get_best_parsable_locale(module, preferences) == 'C.UTF-8'
    preferences = ['en_US.utf8', 'C', 'POSIX']

# Generated at 2022-06-20 15:54:56.917560
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None, ['C', 'POSIX']) == 'C'
    assert get_best_parsable_locale(None, ['C.UTF-8', 'POSIX']) == 'C.utf8'



# Generated at 2022-06-20 15:55:07.954134
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    pref = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    fake_locale_list = ['C.utf8', 'C', 'POSIX']
    found = get_best_parsable_locale(fake_locale_list, pref, raise_on_locale=False)
    assert found == 'C.utf8', 'locale match failed, expected "C.utf8", found "%s"' % found
    pref.reverse()
    found = get_best_parsable_locale(fake_locale_list, pref, raise_on_locale=False)
    assert found == 'C.utf8', 'locale match failed, expected "C.utf8", found "%s"' % found
    pref = ['C', 'POSIX']
    found = get_best_pars

# Generated at 2022-06-20 15:55:19.273795
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    def run_command_dummy(args, **kwargs):
        # Assume the locale command is being run with '-a'
        if args[0] == 'locale':
            if args[1] == '-a':
                # First run will return available locales and we will use the first one
                # Second run will return nothing and we will use the default C locale
                if len(locales) > 0:
                    return 0, '\n'.join(locales), None
                else:
                    return 0, '', None
            else:
                raise Exception('Invalid command to run_command_dummy: %s' % args)
        else:
            return 0, None, None

    # Import the class here so that the unit test doesn't require the full Ansible environment
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-20 15:55:26.956282
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})

    assert get_best_parsable_locale(module) in ['C.utf8', 'en_US.utf8', 'C', 'POSIX']

    assert get_best_parsable_locale(module, ['POSIX', 'C']) in ['POSIX', 'C']

# Generated at 2022-06-20 15:55:34.527425
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    import unittest
    class TestGetBestLocale(unittest.TestCase):

        def test_locale_not_available(self):
            from ansible.modules.system.locale import get_best_parsable_locale
            from ansible.module_utils.common.collections import ImmutableDict

            # Mock empty locale dict
            locale_dict = {}
            locale_dict['bin_path'] = None

            # Calling the function
            with self.assertRaises(RuntimeWarning):
                get_best_parsable_locale(locale_dict, preferences=['C', 'POSIX'])

        def test_locale_with_preferences(self):
            from ansible.modules.system.locale import get_best_parsable_locale

# Generated at 2022-06-20 15:55:44.956871
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import sys

    # Test preferences containing a locale that's not available on the system
    preferences = ['ja_JP.utf8']
    module = AnsibleModule(
        {},
        supports_check_mode=True
    )
    assert get_best_parsable_locale(module, preferences=preferences) == 'C'

    # Test preferences containing a locale that is available on the system
    preferences = ['C.utf8']
    assert get_best_parsable_locale(module, preferences=preferences) == 'C.utf8'

    # Test preferences containing an available locale but not in the right order
    preferences = ['ja_JP.utf8', 'C.utf8']

# Generated at 2022-06-20 15:55:46.953175
# Unit test for function get_best_parsable_locale

# Generated at 2022-06-20 15:55:53.240292
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    test_module = AnsibleModule(argument_spec=dict())  # needed for AnsibleModule.get_bin_path
    assert get_best_parsable_locale(test_module) is not None

# Generated at 2022-06-20 15:56:03.832656
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    ''' Unit test for function get_best_parsable_locale '''
    class MockModule(object):
        ''' mock class to be used by get_best_parsable_locale '''
        def __init__(self, bin_paths):
            self._bin_paths = bin_paths

        def get_bin_path(self, name):
            ''' mock method for get_bin_path '''
            if name in self._bin_paths:
                return self._bin_paths[name]
            return None

        def run_command(self, cmd):
            ''' mock method for run_command '''
            rc = 0
            out = ''
            err = ''
            try:
                out = self._bin_paths[cmd[0]]
            except KeyError:
                rc = 1

# Generated at 2022-06-20 15:56:14.896869
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    import ansible.module_utils.basic
    import ansible.module_utils.parsing.convert_bool

    class AnsibleModule:
        def __init__(self, **kwargs):
            self.ansible_module = ansible.module_utils.basic.AnsibleModule
            self.boolean = ansible.module_utils.parsing.convert_bool.boolean

        def get_bin_path(self, arg, **kwargs):
            if arg == "locale":
                return arg
            return None

        def run_command(self, arg, **kwargs):
            if arg[0] == "locale":
                return [0, "C.UTF-8\nen_US.UTF-8", ""]
            return [1, "", ""]


# Generated at 2022-06-20 15:56:23.407598
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # The simply test case is too easy to screw up, so instead use a dumb function
    # that fails on purpose. The test case is that it doesn't raise an exception.
    # If the test case were any more complicated then it would be testing the
    # ansible module, not the function being tested.

    class FakeModule():
        def fake_get_bin_path(self, x):
            return '/dummy/path/locale'

        def fake_run_command(self, cmd):
            return (1, '', 'Cannot run locale')

        def __init__(self):
            self.run_command = self.fake_run_command
            self.get_bin_path = self.fake_get_bin_path

    fake_module = FakeModule()
    preference_list = ['fake_locale', 'C']

    actual

# Generated at 2022-06-20 15:56:32.692428
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.sys_info import get_platform_subclass

    class FakeModule(AnsibleModule):
        ''' A fake module used for testing '''

        def __init__(self, **kwargs):
            self.params = {}
            self.exit_json = kwargs.get('exit_json', None)
            self.fail_json = kwargs.get('fail_json', None)
            self.run_command = kwargs.get('run_command', None)
            self.get_bin_path = kwargs.get('get_bin_path', None)

    # test valid case of C and en_US

# Generated at 2022-06-20 15:56:43.173196
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.process import get_bin_path
    module = AnsibleModule(argument_spec={})

    # No locales available
    module.run_command = lambda args, **kwargs: (1, "", "")
    assert get_best_parsable_locale(module) == "C"
    module.run_command = lambda args, **kwargs: (0, "", "")

    # Best locale is the first choice
    module.run_command = lambda args, **kwargs: (0, "en_US.utf8\nen_US\n", "")
    assert get_best_parsable_locale(module) == "en_US.utf8"

    # Best locale is the second choice
    module.run

# Generated at 2022-06-20 15:56:49.504149
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import os

    current_locale = os.environ.get('LC_ALL', 'C')

    expected_value = current_locale

    module = AnsibleModule(argument_spec={})
    ansible_locale = get_best_parsable_locale(module)

    if ansible_locale == "C":
        print("WARNING: Unit test for function get_best_parsable_locale() FAILED")
        print("WARNING: Found locale 'C' by default. This usually means your system does not support the required locale")
        print("WARNING: modules. This is not a problem unless you want to parse output from i18n tools.")

# Generated at 2022-06-20 15:57:00.997797
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Test case with no tool available
    module = MockModule(run_command=lambda args: (1, '', 'locale: not found'))
    assert get_best_parsable_locale(module, ['foo']) == 'C', 'Unexpected default value for missing tool'

    # Test cases with tool available but some error
    for error_message in [
        '',
        'Failed to get locale information',
        'Something wrong',
        'locale: Cannot set LC_ALL to default locale: No such file or directory',
    ]:
        module = MockModule(run_command=lambda args: (1, error_message, 'locale: not found'))
        assert get_best_parsable_locale(module, ['foo']) == 'C', 'Unexpected default value for error'

    # Test case where

# Generated at 2022-06-20 15:57:09.768777
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    class MockModule:
        '''
        Mock module class
        '''

        def get_bin_path(self, name, required=False, opt_dirs=None):
            '''
            Return the name of the module (other methods are not in this test)
            '''
            return name

        def run_command(self, args):
            '''
            Run command
            '''

            retcode = 0
            stdout = ''
            stderr = ''

            # implicit dependency of locale -a on correct
            # language settings.
            # CI/CD/any other build environment might not
            # have this set up in a way that gives an expected
            # list of locales

# Generated at 2022-06-20 15:57:19.967770
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class ModuleMock(object):
        def __init__(self, locale_path, locale_a_output, locale_a_rc, locale_a_err):
            self.argv = ["", "", ""]
            self._locale_path = locale_path
            self._locale_a_output = locale_a_output
            self._locale_a_rc = locale_a_rc
            self._locale_a_err = locale_a_err

        def get_bin_path(self, exe, required=False):
            if exe != "locale":
                raise RuntimeError("Not expecting to get_bin_path for any exe other than 'locale'")
            return self._locale_path


# Generated at 2022-06-20 15:57:32.598618
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.locale import get_best_parsable_locale

    # The '_ansible_module_testing_local' is required to avoid
    # requiring the find_bin utility for modules.
    # The second false argument is to ensure we don't exit the module
    # on an error.
    module = AnsibleModule(argument_spec={}, _ansible_module_testing_local=True, bypass_checks=False)

    try:
        # Testing when we have a locale available
        locale = get_best_parsable_locale(module)
        assert locale == 'C'

    except:
        raise RuntimeError("locale.get_best_parsable_locale() did not return a locale, but there should be one available")

# Generated at 2022-06-20 15:57:44.408620
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Function to unit test get_best_parsable_locale. This will monkey patch
    get_bin_path and run_command to simulate the output of locale -a on the
    shell.
    '''
    import types
    import tempfile
    import shutil

    module = types.ModuleType('ansibullbot.encode_decode.get_best_parsable_locale.test_module')
    module.__dict__.update({
        'get_bin_path': lambda x: x,
        'run_command': run_command,
    })

    # Test with default preferences, which should return C.utf8
    locale = get_best_parsable_locale(module)
    assert locale == 'C.utf8'

    # Create a tempfile with a list of locales that should match

# Generated at 2022-06-20 15:57:51.363925
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.six import PY3
    import ansible.module_utils.basic
    if not PY3:
        import __builtin__ as builtins
    else:
        import builtins

    def set_module_args(args):
        if '_ansible_version' in args:
            del args['_ansible_version']
        if 'ANSIBLE_MODULE_ARGS' in os.environ:
            del os.environ['ANSIBLE_MODULE_ARGS']
        module_args = json.dumps(args)
        os.environ['ANSIBLE_MODULE_ARGS'] = module_args

    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    locale_loc

# Generated at 2022-06-20 15:57:54.897613
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = AnsibleModule(argument_spec=dict())
    best_locale = get_best_parsable_locale(module)
    assert best_locale in ['C.utf8', 'en_US.utf8', 'C', 'POSIX']

# Generated at 2022-06-20 15:58:03.401642
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY2

    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

    locale = module.get_bin_path("locale")
    module.run_command.return_value = (0, 'C\nen_US', '')
    assert get_best_parsable_locale(module, ['en_US']) == 'en_US'

    module.run_command.return_value = (0, '', '')
    assert get_best_parsable_locale(module, ['en_US']) == 'C'


# Generated at 2022-06-20 15:58:12.379690
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict()
    )

    # Test invalid locale
    # If parameter raise_on_locale is False, function should return 'C'
    # If parameter raise_on_locale is True, function should raise exception
    preferences = ['a', 'b']
    assert get_best_parsable_locale(module, preferences=preferences) == 'C'
    assert get_best_parsable_locale(module, preferences=preferences, raise_on_locale=True) == 'C'

    # Test valid locale
    # For example, check locale 'C'
    preferences = ['C']

# Generated at 2022-06-20 15:58:22.156965
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''Test get_best_parsable_locale'''
    class AnsibleModule:
        '''Fake AnsibleModule'''
        def get_bin_path(self, cmd):
            '''Fake get_bin_path'''
            return "/bin/locale"
        def run_command(self, cmd):
            '''Fake run_command'''
            return (0, "", "")
    ansiblemodule = AnsibleModule()
    assert get_best_parsable_locale(ansiblemodule) == 'C'

# Generated at 2022-06-20 15:58:27.399739
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    # test that C is returned when no locale -a info can be found
    assert get_best_parsable_locale(module, raise_on_locale=True) == 'C'
    # test that en_US.utf8 is returned when locale -a info can be found
    assert get_best_parsable_locale(module, ['en_US.utf8'], raise_on_locale=True) == 'en_US.utf8'

# Generated at 2022-06-20 15:58:33.737908
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={}, supports_check_mode=True)

    locale = get_best_parsable_locale(module, ['POSIX', 'C'])
    assert locale == 'POSIX', 'Expected POSIX to be found'

    locale = get_best_parsable_locale(module, ['C.utf8', 'POSIX'])
    assert locale == 'C.utf8', 'Expected C.utf8 to be found'

    locale = get_best_parsable_locale(module, ['en_US.utf8', 'POSIX'])
    assert locale == 'en_US.utf8', 'Expected en_US.utf8 to be found'


# Generated at 2022-06-20 15:58:43.594134
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Simplest test case: a preference that matches the only available locale
    class Module:
        def __init__(self):
            self.fallback = 'C'
        def run_command(self, args):
            if args[0] == 'locale' and args[1] == '-a':
                return (0, 'C\nen_US.utf8\nen_US.utf8\nC\n', '')
            else:
                raise Exception('unexpected arguments: %s' % args)

    class TestModule(Module):
        pass
    assert get_best_parsable_locale(TestModule()) == 'C'

    # Test case: multiple languages available, the first preference matches
    class TestModule(Module):
        pass

# Generated at 2022-06-20 15:58:59.254031
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    ''' Test the get_best_parsable_locale function '''

    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    result = get_best_parsable_locale(module)
    assert result == 'C'

# Generated at 2022-06-20 15:59:07.365772
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    """
        Tests function get_best_parsable_locale
        This function returns the 'C' locale by default as POSIX
        systems have the C locale available. For testing purposes
        the values of the parameters are being overwritten so
        the test can go through
    """
    # create a temporary class with stubs for the module functions
    class AnsibleModule:
        def get_bin_path(self, name):
            return 'locale'

        def run_command(self, cmd):
            return (0, "", "")

        def fail_json(self, msg):
            pass

    m = AnsibleModule()
    locale = get_best_parsable_locale(m)

    assert locale == 'C'

# Generated at 2022-06-20 15:59:16.869437
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    for missing_locale in ["en_US.utf8", "en_US.UTF-8", "en_US.utf-8", "en_US.UTF8"]:
        assert get_best_parsable_locale(
            build_fake_module(["C.UTF-8", missing_locale]),
            preferences=["en_US.utf8", "en_US.UTF-8", "en_US.utf-8", "en_US.UTF8"]) == "C.UTF-8"


# Generated at 2022-06-20 15:59:27.988032
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.six import StringIO

    module = type('AnsibleModule', (object,), dict(
        check_mode=False,
        fail_json=lambda kwargs: None,
        exit_json=lambda kwargs: None,
        get_bin_path=lambda x: "locale",
        run_command=lambda *args, **kwargs: (0, 'C\nen_US', ''),
    ))

    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, ['en_US', 'C']) == 'en_US'
    assert get_best_parsable_locale(module, ['C.UTF-8', 'C']) == 'C'
    assert get_best_pars

# Generated at 2022-06-20 15:59:36.873895
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import os

    if hasattr(os, "getenv"):
        os.environ["LC_ALL"] = ''
        os.environ["LANGUAGE"] = ''
        os.environ["LANG"] = ''

    module = AnsibleModule(supports_check_mode=True)

    # testing with a preferred list of locales as provided by a user
    choices = ["C.utf8", "POSIX", "C", "en_US.utf8"]
    # if we don't specify any locale preference, it picks a default
    default_locale = get_best_parsable_locale(module)
    assert default_locale in ['C', 'POSIX']

    user_preferred_locale = get_best_parsable_locale

# Generated at 2022-06-20 15:59:39.289014
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict()
    )

    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-20 15:59:45.748309
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import tempfile
    import shutil
    import os

    def create_tmp_locale(locale):
        f = tempfile.NamedTemporaryFile(delete=False)
        f.write(b'# %s\n' % locale)
        f.close()

    tmp_dir = tempfile.mkdtemp()
    os.environ['PATH'] = tmp_dir + os.pathsep + os.environ['PATH']

    # Create a fake locale command
    loc_script = os.path.join(tmp_dir, 'locale')
    f = tempfile.NamedTemporaryFile(delete=False, dir=tmp_dir, mode='w')

# Generated at 2022-06-20 15:59:54.380621
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # noqa - required for testing
    import os
    import tempfile
    import mock
    import shutil

    from ansible.module_utils.basic import AnsibleModule

    # TODO: Test with non-consistent locale tool output and make sure resolved
    #       locale is always in the expected list.
    #       This is currently covered by the integration tests.

    # Test with consistent locale tool output
    locale_tool_output = u"""C
C.UTF-8
en_US.utf8
POSIX
""".encode('utf-8')

# Generated at 2022-06-20 16:00:03.965761
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    if sys.version_info[0] > 2:
        # This is a 2.x python only test since module_utils.basic
        # requires 2.x, you can still run this with 3.x but the
        # import will fail.
        import unittest
        from ansible.module_utils.basic import AnsibleModule

        class TestModuleUtilsBestParseLocale(unittest.TestCase):
            def test_get_best_parsable_locale(self):
                # test that the get_best_parsable_locale will use first
                # valid locale in preferences
                am = AnsibleModule({})
                locale = get_best_parsable_locale(am, ['bad', 'fake', 'en_US.utf8'])

# Generated at 2022-06-20 16:00:11.945701
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    class TestGetBestParsableLocale(unittest.TestCase):
        '''Unit test for function get_best_parsable_locale()'''

        def test_get_best_parsable_locale(self):
            # Mock the AnsibleModule and use a temporary file
            import tempfile
            tmpfile = tempfile.NamedTemporaryFile(delete=True)
            tmpfile.write(b'C\nen_US.utf8\nC.utf8\n')
            tmpfile.seek(0)


# Generated at 2022-06-20 16:00:35.095703
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.compat.tests.mock import patch, MagicMock

    module = MagicMock()
    setattr(module, '_debug', True)
    module.get_bin_path.return_value = None

    # test 1, default preferences
    with patch('ansible.module_utils.basic.AnsibleModule.run_command', return_value=(0, 'C\nen_US.utf8', '')):
        locale = get_best_parsable_locale(module)
        assert locale == 'C'

    # test 2, custom preferences

# Generated at 2022-06-20 16:00:37.464120
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from . import AnsibleModule
    module = AnsibleModule()
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-20 16:00:41.435254
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Test the function get_best_parsable_locale
    '''
    from ansible.module_utils.basic import AnsibleModule
    test_module = AnsibleModule(argument_spec={})

    assert test_module.get_best_parsable_locale() == "C"

# Generated at 2022-06-20 16:00:50.164391
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # This can be executed and tested on random location with module_utils/setup_locales.sh
    import sys
    import test.utils.temp_dir as temp_dir
    import ansible.module_utils.basic as basic
    import ansible.module_utils.locales as locales
    import ansible.module_utils.six as six

    # Gather available locales
    class TempModule:
        @staticmethod
        def get_bin_path(binary):
            return '/usr/bin/locale'

        @staticmethod
        def run_command(args):
            return 0, None, None

    m = TempModule()

# Generated at 2022-06-20 16:00:58.505001
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None, ['C.utf8', 'en_US.utf8'], False) == 'C.utf8'
    assert get_best_parsable_locale(None, ['en_US.utf8', 'C.utf8'], False) == 'C.utf8'
    assert get_best_parsable_locale(None, ['en_US.utf8', 'en_US.ascii'], False) == 'C'
    assert get_best_parsable_locale(None, ['en_US.utf8', 'en_US.ascii'], True) == 'C'

# For unit testing.
if __name__ == '__main__':
    import sys

# Generated at 2022-06-20 16:01:08.926226
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    # hack to avoid calling the real run_command
    sys.modules['ansible.module_utils.basic'].run_command = lambda x, decode_errors=None: (0, '\n'.join(['C.utf8', 'en_US.utf8', 'POSIX']), '')
    sys.modules['ansible.module_utils.basic'].get_bin_path = lambda x, required=None: 'locale'
    sys.modules['ansible.module_utils.basic'].AnsibleModule = object

    assert 'POSIX' == get_best_parsable_locale(object())
    assert 'C.utf8' == get_best_parsable_locale(object(), ['C.utf8'])

# Generated at 2022-06-20 16:01:17.942092
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # This is a global import that is necessary for this function to work
    from ansible.module_utils.basic import AnsibleModule

    class MockModule:
        def get_bin_path(self, tool):
            return '/usr/bin/{0}'.format(tool)

        def run_command(self, command):
            if command == ['/usr/bin/locale', '-a']:
                return (0, 'C\nen_US.utf8', None)
            else:
                raise RuntimeError('Unknown command')

    preferences = ['en_US.utf8', 'C.utf8', 'en_US.UTF-8', 'C']
    best_locale = get_best_parsable_locale(MockModule(), preferences)
    if best_locale != 'en_US.utf8':
        raise

# Generated at 2022-06-20 16:01:19.106507
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # TODO: Add tests for the get_best_parsable_locale function
    pass

# Generated at 2022-06-20 16:01:20.333479
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # FIXME: This is not a unit test, but it's not worth the effort of removing this unused function.
    pass

# Generated at 2022-06-20 16:01:31.755888
# Unit test for function get_best_parsable_locale

# Generated at 2022-06-20 16:02:10.202177
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys

    # emulate AnsibleModule()
    class AnsibleModule(object):
        def __init__(self, argspec):
            self.exit_args = dict()
            self.params = dict()

        def get_bin_path(self, tool, required=False):
            if tool in ['locale', 'locale-gen']:
                return tool
            else:
                return None

        def run_command(self, cmd, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False):
            return 0, 'test_out', 'test_err'

        def exit_json(self, rc=0, changed=False, failed=False, msg=None):
            self.exit_args['rc'] = rc
            self.exit_args['changed'] = changed
           

# Generated at 2022-06-20 16:02:19.721237
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None) in ['C.utf8', 'en_US.utf8', 'C', 'POSIX', 'C'], \
        'get_best_parsable_locale should return one of allowed locales or C'
    assert get_best_parsable_locale(None, ['C', 'POSIX']) == 'C', \
        'get_best_parsable_locale should return C as it is first matching locale in given list'
    assert get_best_parsable_locale(None, ['POSIX', 'C']) == 'C', \
        'get_best_parsable_locale should return C as it is first matching locale in given list'

# Generated at 2022-06-20 16:02:27.210267
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # stub out a fake os module which we'll use to mock the session
    import os

    class OSModule(object):
        def __init__(self):
            # create a list of 'locales' that will be returned
            self.locales = [ 'en_US.utf8', 'en_US.UTF-8', 'C', 'POSIX', 'fr_FR.utf8', 'fr_FR.UTF-8', 'fr_CA.utf8', 'fr_CA.UTF-8', 'C.UTF-8' ]
            # set the default locale
            self.default_locale = 'en_US.utf8'
            # set locale_info
            self.locale_info = {
                'default': 'en_US.utf8',
                'supported': self.locales
            }


# Generated at 2022-06-20 16:02:30.859289
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert(get_best_parsable_locale(module) == 'C')
    assert(get_best_parsable_locale(module, ["en_US.utf8"]) == 'en_US.utf8')

# Generated at 2022-06-20 16:02:41.088201
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert 'C' == get_best_parsable_locale(None, preferences=['C', 'POSIX'])
    assert 'POSIX' == get_best_parsable_locale(None, preferences=['POSIX', 'C'])
    assert 'C.utf8' == get_best_parsable_locale(None, preferences=['C.utf8', 'POSIX'])
    assert 'POSIX' == get_best_parsable_locale(None, preferences=['POSIX', 'C.utf8'])



# Generated at 2022-06-20 16:02:50.872475
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.locale import get_best_parsable_locale

    module = AnsibleModule()

    # Test with no preferences specified (default)
    assert get_best_parsable_locale(module) == 'C'

    # Test with preferences and all missing
    assert get_best_parsable_locale(module, preferences=['foo', 'bar']) == 'C'

    # Test with preferences, first bad but second good
    assert get_best_parsable_locale(module, preferences=['foo', 'POSIX']) == 'POSIX'

    # Test with preferences, first good

# Generated at 2022-06-20 16:02:57.437433
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class TestModule():
        def __init__(self):
            self.run_command = MockRun()
            self.get_bin_path = lambda x: '/usr/bin/locale'

    # when locale -a returns locale we want it returns it
    t = TestModule()
    t.run_command.value = (0, 'C\nen_US\nC.utf8\n')
    assert 'C' == get_best_parsable_locale(t)

    # when locale -a returns locale not in list it returns C
    t = TestModule()
    t.run_command.value = (0, 'C\nen_US\nC.utf8\n')
    assert 'C' == get_best_parsable_locale(t, preferences=['en_US', 'C.utf8'])

# Generated at 2022-06-20 16:03:00.121660
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # This test is non-trivial because we cannot mock module.run_command() easily
    # as it is not a function call but an instance method.
    assert False

# Generated at 2022-06-20 16:03:04.577753
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Tests get_best_parsable_locale function
    '''

    # Get locale
    locale = get_best_parsable_locale(None)
    assert locale == 'C'

# Generated at 2022-06-20 16:03:13.407336
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    import tempfile
    import os
    import textwrap
    import ast
    import imp
    import shutil

    # Make a fake module
    with tempfile.NamedTemporaryFile() as temp_file:
        temp_file.write(textwrap.dedent(u'''\
        #!/usr/bin/python

        try:
            import json
        except ImportError:
            import simplejson as json

        import ansible.module_utils.basic as basic_utils
        import ansible.module_utils.get_best_parsable_locale as parsable_locale
        import ansible.module_utils.systemd as systemd

        if __name__ == '__main__':
            basic_utils.main()
        ''').encode(u'utf-8'))
        temp_file.flush

# Generated at 2022-06-20 16:03:48.745546
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    class FakeModule(AnsibleModule):
        def __init__(self):
            self.params = {}
            self.args = None
            self.tmpdir = None
            self.debug = None
            self.verbosity = None
            self.check_mode = None
            self.no_log = None
            self.force_color = None
            self.params = None
            self.fail_json = None
            self.exit_json = None
            self.run_command = None
            self.get_bin_path = None
            self.logging = None
            self.aliases = None

        def run_command(self, cmd):
            """
            A fake run_command method to test the return values
            """

# Generated at 2022-06-20 16:03:58.219847
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six.moves import shlex_quote

    import os
    import copy
    import shutil
    from subprocess import PIPE

    # We need to test if we get the correct locale, when no locale is installed
    # we need to test if we get 'C' and not raise an exception

    # Create a dummy locale directory
    locale_dir = '/tmp/locale_test'
    locale_test_1 = locale_dir+'/en_US.utf8/LC_MESSAGES/'
    locale_test_2 = locale_dir+'/fr_CA.utf8/LC_MESSAGES/'
    locale_test_3 = locale_dir+'/posix/LC_MESSAGES/'
    locale_test

# Generated at 2022-06-20 16:04:06.163764
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import os
    import sys

    module = AnsibleModule(argument_spec={})
    module._ansible_tmpdir = os.path.dirname(os.path.dirname(os.path.abspath(__file__))) + '/test/'

    # testing posix standard, should work
    assert get_best_parsable_locale(module) == 'C', 'Unable to get posix locale'

    # with no locale tool on path
    module.get_bin_path = lambda _: ''
    assert get_best_parsable_locale(module) == 'C', 'Unable to get posix locale'

    # with no preferred locale

# Generated at 2022-06-20 16:04:18.134761
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.compat.tests.mock import patch
    from ansible.compat.tests.mock import Mock

    # Mock the run_command for get_best_parsable_locale
    with patch('ansible.module_utils.basic.AnsibleModule._run_command', Mock(return_value=(0, 'C.utf8\nen_US.utf8\nen_US.utf8\nen_US', ''))):
        from ansible.module_utils.basic import get_best_parsable_locale
        am = AnsibleModule(argument_spec={})
        result = get_best_parsable_locale(am, raise_on_locale=False)
        assert result == 'C.utf8'

    # Mock the run

# Generated at 2022-06-20 16:04:25.756906
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    def run_command_original(self, args, check_rc=True, close_fds=True, executable=None,
                             data=None, binary_data=False, path_prefix=None, cwd=None,
                             use_unsafe_shell=False, prompt_regex=None, environ_update=None,
                             umask=None, encoding=None, errors='strict', log_errors=True,
                             become_user=None, become_ask_pass=None, become_exe=None,
                             become=False, shell=None, executable_state=None,
                             stdin_add_newline=True):

        class MockCompletedProcess:
            returncode = 0
            stdout = ""