

# Generated at 2022-06-20 15:54:36.618159
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Verify correct locale is returned
    '''

    locales = [
        ("C.utf8", None, True),
        ("en_US.utf8", None, True),
        ("C", None, True),
        ("POSIX", None, True),
        ("C", ['POSIX', 'C'], True),
        ("POSIX", ['POSIX', 'C'], True),
        (None, ['POSIX', 'C'], False),
    ]

    # Mock the module class and functions
    module = MockModule()
    module.get_bin_path = Mock(return_value='/usr/bin/locale')
    module.run_command = Mock(side_effect=get_run_command_locale())


# Generated at 2022-06-20 15:54:47.365503
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.modules.utilities.logic import get_best_parsable_locale
    import ansible.module_utils.facts.system.distribution

    class AnsibleModule():

        @staticmethod
        def _exec(command, in_data=None, sudoable=True):
            return 0, None, None

        @staticmethod
        def get_bin_path(command):
            return None

        @staticmethod
        def run_command(command):
            return 0, None, None

        def __init__(self):
            self.params = {}
            self.distribution = {}

    ansible_module = AnsibleModule()
    ansible_module.distribution = ansible.module_utils.facts.system.distribution.Distribution()
    ansible_module.distribution.name = 'CentOS'


# Generated at 2022-06-20 15:54:57.988210
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import sys

    class TestModule(AnsibleModule):
        pass

    # Mocking the AnsibleModule.get_bin_path method
    class MockFile(object):
        """
        Fake class for mocking open for getting path for 'locale'
        """
        def __init__(self):
            self.pos = 0

        def read(self):
            self.pos += 1
            return "/usr/bin/locale"

    def mock_open(path, mode='r'):
        return MockFile()

    module = TestModule()
    module.get_bin_path = lambda x: x

    # Mocking open
    sys.modules['__builtin__'].open = mock_open

    # Test case with english in available locales
    bytes = ''


# Generated at 2022-06-20 15:55:09.090493
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import unittest
    from tempfile import NamedTemporaryFile
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.basic import AnsibleModule

    class TestAnsibleModule(AnsibleModule):
        def run_command(self, args):
            # If a location for the output file hasn't been specified, create a temporary file
            if not self._output_path:
                self._output_path = NamedTemporaryFile(delete=False)
                self._close_temporary_file = True  # The output file should be closed and deleted
            else:
                self._close_temporary_file = False

            # Write the locale -a output and return it's path

# Generated at 2022-06-20 15:55:20.232703
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    # test available locale set
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    module.run_command = lambda x, **kw: (0, '\n'.join(['C', 'en_US.utf8', 'C.utf8', 'POSIX']), '')
    assert get_best_parsable_locale(module) == 'C.utf8', "locale C.utf8 should be chosen"

    module.run_command = lambda x, **kw: (0, '\n'.join(['C', 'en_US.utf8', 'C.utf8', 'POSIX']), '')

# Generated at 2022-06-20 15:55:31.508386
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Set up test run and preferences
    class MockModule:
        def __init__(self, *args, **kwargs):
            self.params = kwargs.get('params', dict())
            self.bin_path = kwargs.get('bin_path', dict())
            self.run_command_rc = kwargs.get('rc', 0)
            self.run_command_out = kwargs.get('out', None)
            self.run_command_err = kwargs.get('err', None)

        def get_bin_path(self, cmd, *args, **kwargs):
            # We don't need to test for bin_path existence
            return self.bin_path


# Generated at 2022-06-20 15:55:35.259637
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.ansible_release import __version__ as ansible_version

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY2

    def fake_run_command(cmd):
        class FakeStringIOOutput:
            def __init__(self, *args):
                if PY2:
                    self.out = u"\n".join(args)
                else:
                    self.out = "\n".join(args)
            def __getattr__(self, attr):
                return None
            def __getitem__(self, item):
                if item == 0:
                    return 0
                else:
                    return self.out

# Generated at 2022-06-20 15:55:45.992535
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    fake_module = AnsibleModule(argument_spec={})
    fake_module.run_command = lambda x: (0, "C\nen_US.utf8\nC.utf8\nPOSIX", '')
    assert get_best_parsable_locale(fake_module) == 'C.utf8'
    fake_module.run_command = lambda x: (1, None, '')
    assert get_best_parsable_locale(fake_module) == 'C'
    fake_module.run_command = lambda x: (0, "C\nen_US.utf8\nC.utf8\nPOSIX", '')

# Generated at 2022-06-20 15:55:55.712203
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    # Test getting the 'C' locale when no locale-a command is available
    mod = AnsibleModule(argument_spec={})
    best = get_best_parsable_locale(mod)
    assert best == 'C'

    # Test getting the 'C' locale when locale-a command is present, but empty
    mod = AnsibleModule(argument_spec={}, supports_check_mode=True)
    mod.run_command = lambda cmd, environ_update=None, check_rc=True, binary_data=False, path_prefix=None, data=None: (0, '', '')
    best = get_best_parsable_locale(mod)
    assert best == 'C'

    # Test getting the first locale for locale-a command that returns a

# Generated at 2022-06-20 15:55:58.558066
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None, None) == 'C'
    assert get_best_parsable_locale(None, ['en_US']) == 'C'

# Generated at 2022-06-20 15:56:12.125210
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec={}
    )
    module.run_command = test_module_run_command
    assert module.get_bin_path('locale') == 'locale'
    assert get_best_parsable_locale(module) == 'C.utf8'
    assert get_best_parsable_locale(module, preferences=['foo', 'ja_JP.utf8']) == 'C'
    assert get_best_parsable_locale(module, preferences=['de', 'ja_JP.utf8']) == 'C'

# Generated at 2022-06-20 15:56:22.251871
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # We test that we get correctly the preference for the best match for 'locale' command
    class MockModule(object):
        def get_bin_path(self, path):
            return "/usr/bin"

        def run_command(self, cmd):
            # We return the list of locales available on the system as the output of 'locale' command
            if cmd == ["/usr/bin", '-a']:
                return 0, "fr_FR.utf8\nen_US.utf8\nC.utf8\nen_US.ISO-8859-1\nen_US.utf8\nen_US.utf8\nen_US.utf8", ""
            else:
                pass

    test_module = MockModule()
    # We test that we choose the correct locale from preferences
    assert get_best_parsable_loc

# Generated at 2022-06-20 15:56:32.029965
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.sys_info import get_distribution

    # Test when locale is not found
    module = AnsibleModule(argument_spec={})
    module.get_bin_path = lambda x: None
    locale = get_best_parsable_locale(module)
    assert locale == 'C'

    # Test when locale is found
    distro = get_distribution()
    if distro.lower() == 'redhat':
        module.run_command = lambda x: [0, 'C.UTF-8\nC.utf8', None]
    else:
        module.run_command = lambda x: [0, 'C.utf8\nC\nPOSIX', None]

    locale = get_best_parsable

# Generated at 2022-06-20 15:56:43.106685
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.common.text.converters import to_bytes

    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(),
    )

    try:
        # call get_best_parsable_locale without the required locale binary
        module.get_bin_path = lambda x: None
        get_best_parsable_locale(module)
    except Exception as e:
        assert 'Could not find' in to_native(e)

    module.get_bin_path = lambda x: x

    # call get_best_parsable_locale without the required locale binary
    # and with raise_on_locale=True

# Generated at 2022-06-20 15:56:54.152944
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys as _sys
    module = _sys.modules[__name__]
    setattr(module, 'run_command', lambda *args: (1, '', 'error'))
    assert get_best_parsable_locale(module) == 'C'
    setattr(module, 'run_command', lambda *args: (0, 'C\nc', ''))
    assert get_best_parsable_locale(module) == 'C'
    setattr(module, 'run_command', lambda *args: (0, 'C\nen_US', ''))
    assert get_best_parsable_locale(module) == 'en_US'
    setattr(module, 'run_command', lambda *args: (0, 'C\nen_US.utf8', ''))
    assert get_best_p

# Generated at 2022-06-20 15:57:05.414031
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Unit test to verify the function get_best_parsable_locale
    '''

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    class MockModule(AnsibleModule):
        '''
            Dummy class for mocking module objects
        '''

        def get_bin_path(self, arg, required=None):
            '''
                Dummy method to mock get_bin_path()
            '''

            return '/usr/bin/locale'


# Generated at 2022-06-20 15:57:16.557565
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec = dict(),
    )

    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, ['en_US.utf8']) == 'en_US.utf8'
    assert get_best_parsable_locale(module, ['C.utf8']) == 'C.utf8'
    assert get_best_parsable_locale(module, ['POSIX']) == 'POSIX'
    assert get_best_parsable_locale(module, ['en_US.utf8', 'POSIX']) == 'en_US.utf8'

# Generated at 2022-06-20 15:57:20.215168
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Test function get_best_parsable_locale
    '''
    # Valid test
    module = AnsibleModule(argument_spec=dict())
    assert get_best_parsable_locale(module) == 'C'

    # Test exception
    assert get_best_parsable_locale(module, raise_on_locale=True) == 'C'

# Generated at 2022-06-20 15:57:31.540667
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    test_module = AnsibleModule({})
    assert get_best_parsable_locale(test_module) == 'C'

    test_module = AnsibleModule({})
    assert get_best_parsable_locale(test_module, preferences=['xxx']) == 'C'

    test_module = AnsibleModule({})
    assert get_best_parsable_locale(test_module, preferences=['C']) == 'C'

    test_module = AnsibleModule({})
    assert get_best_parsable_locale(test_module, preferences=['POSIX']) == 'C'

    test_module = AnsibleModule({})

# Generated at 2022-06-20 15:57:35.627696
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = "AnsibleModule"
    assert get_best_parsable_locale(module) == "C"
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8']) == "C.utf8"

# Generated at 2022-06-20 15:57:51.267051
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None) is 'C'
    assert get_best_parsable_locale(None, ['C.utf8', 'en_US.utf8', 'C', 'POSIX']) is 'C'

# Generated at 2022-06-20 15:58:00.664172
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict())

    assert get_best_parsable_locale(module) == 'C'

    assert get_best_parsable_locale(module, ['C']) == 'C'
    assert get_best_parsable_locale(module, ['POSIX']) == 'C'
    assert get_best_parsable_locale(module, ['C', 'POSIX']) == 'C'

    assert get_best_parsable_locale(module, ['C.UTF-8', 'C']) == 'C'
    assert get_best_parsable_locale(module, ['en_US.UTF-8', 'C']) == 'en_US.UTF-8'

    assert get

# Generated at 2022-06-20 15:58:10.986965
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class TestModule:
        def get_bin_path(self, a):
            if a == "locale":
                # If a is "locale", tell the function that it exists
                return True
            else:
                # Otherwise return None
                return None

    # Create a fake module
    module = TestModule()

    # locale is present
    rc = 0
    out = """C
en_US.utf8
fr_FR.utf8
"""
    err = ""

    def run_command(a):
        if a[0] == "locale":
            return (rc, out, err)

    # Set the fake run_command attribute
    module.run_command = run_command

    # no preferences
    assert get_best_parsable_locale(module) == "C.utf8"

    # ask for en

# Generated at 2022-06-20 15:58:23.335493
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import os
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.basic import AnsibleModule

    # Locale list for testing
    locale_list = '''.utf8@en_US
C
C.ISO8859-1
C.UTF-8
en_US.utf8
POSIX
en_US'''.splitlines()

    def test_wrapper(pref, expect, locale_list=locale_list):
        def set_stdout(pref=pref, locale_list=locale_list):
            stdout = StringIO()
            for l in locale_list:
                stdout.writelines([l, os.linesep])
            stdout.seek(0)
            return stdout


# Generated at 2022-06-20 15:58:30.688861
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import os
    import ansible.module_utils.basic

    class FakeModule:
        def __init__(self):
            self.run_command_calls = list()
            self.run_command_rc = 0
            self.run_command_out = None
            self.run_command_err = None

        def run_command(self, cmd):
            self.run_command_calls.append(cmd)
            return self.run_command_rc, self.run_command_out, self.run_command_err

        def get_bin_path(self, name):
            if name == 'locale':
                return os.path.join('/usr', name)


# Generated at 2022-06-20 15:58:34.775013
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = AnsibleModule(argument_spec={}, bypass_checks=True)
    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, ['en_US.utf8', 'NotAnOption']) == 'C'

# Generated at 2022-06-20 15:58:37.148888
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    assert ansible.module_utils.basic.get_best_parsable_locale() == 'C'

# Generated at 2022-06-20 15:58:46.009748
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    A unit test for get_best_parsable_locale

    :returns:
        :returns: boolean - True if all tests passed, False otherwise
    '''
    from ansible.module_utils.basic import AnsibleModule

    class TestAnsibleModule(AnsibleModule):
        def run_command(self, args):
            if args[0] == "locale":
                if args[1] == "-a":
                    return 0, 'C.utf8\nen_US.utf8\n'
                else:
                    raise RuntimeWarning("Unexpected locale command %s" % args)

    module = TestAnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == "C.utf8"
    assert get_best_parsable_locale

# Generated at 2022-06-20 15:58:54.376223
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''Function to test get_best_parsable_locale, in ansible.module_utils.common.i18n'''

    import os
    import tempfile
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import get_exception

    params = dict(
        preferences=['en_US.utf8', 'C.utf8', 'C', 'POSIX'],
        raise_on_locale=True,
    )
    spec = dict(
        preferences=dict(type='list', default=params['preferences']),
        raise_on_locale=dict(type='bool', default=params['raise_on_locale']),
    )
    module = AnsibleModule(argument_spec=spec)
    params['module'] = module


# Generated at 2022-06-20 15:59:05.132612
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils import basic
    module = basic.AnsibleModule(argument_spec={}, supports_check_mode=True)

    preferences = ['C', 'POSIX', 'en_US.utf8', 'C.utf8']
    default = get_best_parsable_locale(module)
    assert default == preferences[0]

    preferences = ['POSIX']
    best = get_best_parsable_locale(module, preferences)
    assert best == preferences[0]

    preferences = ['POSIX', 'C']
    best = get_best_parsable_locale(module, preferences)
    assert best == preferences[0]

    preferences = ['POSIX', 'en_US.utf8']
    best = get_best_parsable_locale(module, preferences)
    assert best

# Generated at 2022-06-20 15:59:26.931595
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    class AnsibleModuleMock:

        def get_bin_path(self, path):
            return path

        def run_command(self, cmd):
            return 0, 'C\nen_US.utf8', ''

    module = AnsibleModuleMock()

    # Test default preference
    assert(get_best_parsable_locale(module) == 'C')

    # Test with raise_on_locale=True to force raise exception
    assert(get_best_parsable_locale(module, raise_on_locale=True) == 'C')

# Generated at 2022-06-20 15:59:36.056281
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    import tempfile
    import os
    # Import required modules
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six import PY3

    if PY3:
        from unittest import mock
    else:
        import mock

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes

    class TestAnsibleModule(AnsibleModule):
        pass

    test_module = TestAnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False,
        bypass_checks=True,
        no_log=True
    )

    class TestLocaleModule(object):

        def __init__(self):
            self.exit_args = {}
            self

# Generated at 2022-06-20 15:59:44.774462
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    import os
    import tempfile

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import get_exception

    from ansible.module_utils.urllib3.util.url import is_ipv6

    global module
    global tmpdir


# Generated at 2022-06-20 15:59:49.111174
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    results = get_best_parsable_locale(None,['C.utf8','en_US.utf8','C','POSIX','sv_SE.utf8'])
    assert results == 'C.utf8' or results == 'en_US.utf8'

# Generated at 2022-06-20 15:59:50.266389
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Unit test to verify the locale output parser
    '''
    pass

# Generated at 2022-06-20 15:59:56.160430
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    fake_module = type('FakeModule', (object,), {
        'run_command': lambda *args, **kwargs: 0,
        'get_bin_path': lambda *args, **kwargs: 'locale'
    })

    fake_module.run_command.return_value = (0, 'C\nC.utf8\nen_US.utf8\nen_US.UTF-8', '')

    # Ensure that None is returned if preferences are not sent
    assert get_best_parsable_locale(fake_module) == 'C'

    # Ensure that the first available preferred locale is returned
    assert get_best_parsable_locale(fake_module, ['en_AU.utf8', 'C', 'POSIX']) == 'C'

    # Ensure that the first available preferred locale is returned

# Generated at 2022-06-20 16:00:05.012216
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class AnsibleModule(object):
        def __init__(self):
            self.bin_path = dict()

        def get_bin_path(self, name):
            return self.bin_path.get(name, None)

        @staticmethod
        def run_command(cmd):
            if 'locale' in cmd:
                return (0, '\n'.join([
                    'C',
                    'en_US.utf8',
                    'en_US.utf8'
                ]), None)

    module = AnsibleModule()

    # Test that a valid preference is found
    assert get_best_parsable_locale(module, preferences=['de_DE.utf8']) == 'C'

    # Test that the first valid preference is returned

# Generated at 2022-06-20 16:00:12.475522
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    assert get_best_parsable_locale(AnsibleModule(argument_spec={})) == 'C'
    # Locale commands differ by OS.  Unfortunately, this requires either mocking
    # out the whole function or dropping to the os module.
    import os, sys
    if sys.platform == 'darwin':
        assert get_best_parsable_locale(AnsibleModule(argument_spec={}), ['en_US.UTF-8', 'C']) == 'en_US.UTF-8'
        os.environ['LC_CTYPE'] = 'en_US.UTF-8'
        assert get_best_parsable_locale(AnsibleModule(argument_spec={})) == 'en_US.UTF-8'
   

# Generated at 2022-06-20 16:00:21.977304
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    import pytest
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    class ModuleFailJson:

        def __init__(self, msg=None, **kwargs):
            self.params = {}
            self.tmpdir = '/tmp'

        def fail_json(self, msg=None, **kwargs):
            if msg:
                pytest.fail(msg)

        def get_bin_path(self, binary, required=True, opt_dirs=()):
            return binary

    # This is a list of output from various Linux OS's and their OS versions
    # which I used to help test and understand how this function works. This
    # will also serve as a way to see how much this function has been tested.
    # If it is not tested, it

# Generated at 2022-06-20 16:00:30.838234
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    def get_bin_path(name):
        return name

    def run_command(cmd):
        if cmd == ["locale", "-a"]:
            return (0, "C.utf8\nen_us.utf8\nPOSIX\n", "")
        else:
            raise RuntimeError("Unhandled command %s" % cmd)

    with AnsibleModule(argument_spec={}) as dummy_module:
        dummy_module.get_bin_path = get_bin_path
        dummy_module.run_command = run_command
        assert get_best_parsable_locale(dummy_module) == 'C.utf8'

# Generated at 2022-06-20 16:00:54.409058
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Test function get_best_parsable_locale
    '''
    assert get_best_parsable_locale(None, preferences=['xyz']) == 'C'
    assert get_best_parsable_locale(None, preferences=['C', 'POSIX']) == 'C'
    assert get_best_parsable_locale(None, preferences=['xyz', 'C', 'POSIX']) == 'C'
    assert get_best_parsable_locale(None, preferences=['C', 'POSIX', 'xyz']) == 'C'

# Generated at 2022-06-20 16:00:59.105190
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Unit test for function get_best_parsable_locale
    '''
    class ModuleMock(object):
        '''
            Mock class for AnsibleModule
        '''

        def get_bin_path(self, executable):
            '''
                Mock for function get_bin_path
            '''
            if executable == 'locale':
                return execu

# Generated at 2022-06-20 16:01:09.051275
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
    )

    # Existing locale
    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, ['ja_JP.utf8']) == 'C'

    # Non existing locale in list
    assert get_best_parsable_locale(module, ['some-random-locale']) == 'C'

    # If a locale should be found, raise an exception
    module.run_command = MagicMock(return_value=(1, '', ''))
    with pytest.raises(RuntimeWarning):
        get_best_parsable_locale(module, raise_on_locale=True)

# Generated at 2022-06-20 16:01:11.276730
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # TODO: Write unit tests for the get_best_parsable_locale function.
    pass

# Generated at 2022-06-20 16:01:19.439854
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # this is the default locale, when locale is not found
    assert get_best_parsable_locale(None) == 'C'

    class FakeModule(object):
        def __init__(self, rc, out, err):
            self.exit_args = None
            self.rc = rc
            self.out = out
            self.err = err

        def fail_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs
            raise Exception("fail_json")

        def get_bin_path(self, locale):
            if locale is None:
                return locale
            else:
                return 'locale'

        def run_command(self, argv):
            return self.rc, self.out, self.err

    # this is the

# Generated at 2022-06-20 16:01:23.460434
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})

    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-20 16:01:31.929987
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    """
    Test that we can detect various locales
    """
    import ansible.module_utils.basic
    module = ansible.module_utils.basic.AnsibleModule(argument_spec={})
    print(get_best_parsable_locale(module))
    print(get_best_parsable_locale(module, ['en_GB']))
    print(get_best_parsable_locale(module, ['en_GB', 'C', 'de_DE']))

if __name__ == "__main__":
    test_get_best_parsable_locale()

# Generated at 2022-06-20 16:01:34.711451
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})

    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-20 16:01:44.938250
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import cStringIO

    class fake_module(object):
        def __init__(self, *args, **kwargs):
            self.run_command_result = (0, to_bytes(""), to_bytes(""))
            self.warnings = []
            self.params = {}

            # properly fake the StringIO behavior
            self._stdin_buffer = cStringIO()
            self._stdout_buffer = cStringIO()
            self._stderr_buffer = cStringIO()

        def fail_json(self, *args, **kwargs):
            raise Exception('FAIL_JSON')



# Generated at 2022-06-20 16:01:49.284714
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Unit tests for function get_best_parsable_locale
    '''

    assert get_best_parsable_locale() == 'C'

    # execptions are RuntimeWarning and not AnsibleError class
    try:
        get_best_parsable_locale(raise_on_locale=True)
    except RuntimeWarning:
        pass

# Generated at 2022-06-20 16:02:06.738975
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    m = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(m) == 'C'

# Generated at 2022-06-20 16:02:14.698118
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    import os
    import syslog
    import tempfile
    import ansible.module_utils.basic
    import ansible.module_utils.facts

    # Test on Linux
    if sys.platform.startswith("linux"):
        from ansible.module_utils.facts.system.distribution import DistributionFactCollector

        def _create_fake_dist(distribution_name):
            """
            Creates a fake distributor for the specified distribution name using the
            distribution names from /usr/lib/os-release as the list of known distribution
            names.
            """

# Generated at 2022-06-20 16:02:24.364791
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.basic import AnsibleModule

    # This test uses sandboxed_module to mimic the AnsibleModule object
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.urls import open_url

    class AnsibleModuleSandbox(AnsibleModule):
        def __init__(self, argument_spec=None, **kwargs):
            self.argument_spec = argument_spec or dict()
            self.fail_json = open_url
            self.supports_check_mode = kwargs.get('supports_check_mode', False)
            self.run_command_environ_update = kwargs.get('run_command_environ_update', dict())

# Generated at 2022-06-20 16:02:34.842064
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.basic import AnsibleModule, get_bin_path
    from ansible.module_utils.six import PY2

    from ansible.module_utils.basic import AnsibleModule

    class TestModule(AnsibleModule):
        def __init__(self):
            super(TestModule, self).__init__()

            self.deprecations = dict()

    def fail_json_mock(self, *args, **kwargs):
        raise AssertionError('fail_json must not be called during unit tests')

    TestModule.fail_json = fail_json_mock

    module = TestModule()

    if PY2:
        from __builtin__ import execfile
    else:
        from builtins import __import__ as execfile


# Generated at 2022-06-20 16:02:40.789459
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict())

    assert get_best_parsable_locale(module) == "C"

    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    assert get_best_parsable_locale(module, preferences=preferences) == "C"

# Generated at 2022-06-20 16:02:50.585958
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict())

    def run_command(args, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False, path_prefix=None, cwd=None, use_unsafe_shell=False, prompt_regex=None):
        rc = 0
        out = None
        err = None

        if args[0] == 'locale' and args[1] == '-a':
            # Standard POSIX locales
            out = '''
C
POSIX
'''
        if out:
            return rc, out, err
        else:
            raise RuntimeError('FAIL')

    module.run_command = run_command
    # This should throw an error due to locale CLI

# Generated at 2022-06-20 16:02:57.575326
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    unit test for get_best_parsable_locale
    '''

    class ModuleMock(object):
        '''
        A mock for AnsibleModule.
        '''

        def __init__(self):
            self.params = {}
            self.debug = False
            self.check_mode = False
            self.exit_json = None

    class RunCommandMock(object):
        '''
        A mock for module.run_command.
        '''

        def __init__(self):
            self.rc = 0
            self.out = ''
            self.err = ''

        def __call__(self, args):
            '''
            Returns the mock implementation for module.run_command.
            '''


# Generated at 2022-06-20 16:03:04.756305
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import unittest
    import six

    class MockModule(object):
        def __init__(self, locale_path, locale_stdout, locale_stderr):
            self.args = {'locale_path': locale_path}
            self._locale_path = locale_path
            self._locale_stdout = locale_stdout
            self._locale_stderr = locale_stderr

        def get_bin_path(self, arg, opt_dirs=[]):
            return self._locale_path

        def run_command(self, cmd, check_rc=True, close_fds=True):
            if cmd[0] != self._locale_path:
                raise Exception("Unexpected command %s" % cmd)

# Generated at 2022-06-20 16:03:12.608519
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils import basic
    from ansible.module_utils.common.process import get_bin_path
    from ansible.parsing.dataloader import DataLoader

    # Initialize module objects
    argv = ['']
    dataloader = DataLoader()
    module = basic.AnsibleModule(argument_spec=dict(), supports_check_mode=False, check_invalid_arguments=False)
    module.run_command = get_bin_path

    # Happy path
    test_prefs = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    locale_rc, locale_out, locale_err = module.run_command(['locale', '-a'])
    assert locale_out


# Generated at 2022-06-20 16:03:23.078122
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # get_best_parsable_locale without preferences and without locale
    assert(get_best_parsable_locale() == 'C')

    # get_best_parsable_locale without preferences and with locale
    assert(get_best_parsable_locale(['C.utf8', 'en_US.utf8', 'C']) == 'C.utf8')

    # get_best_parsable_locale with preferences and without locale
    assert(get_best_parsable_locale(['C.utf8', 'en_US.utf8', 'C'], preferences=['C']) == 'C')

    # get_best_parsable_locale with preferences and with locale

# Generated at 2022-06-20 16:03:47.018741
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = AnsibleModule({})
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']

    # Test with a clean environment
    assert get_best_parsable_locale(module, preferences) == "C"

    # Test with a messy environment
    os.environ['LC_ALL'] = 'fr_FR.utf8'
    os.environ['LANG'] = 'fr_FR.utf8'
    assert get_best_parsable_locale(module, preferences) == "en_US.utf8"

    # Test with no locales at all
    preferences = ['en_US.utf8']
    module.run_command = lambda x: (1, '', '')
    assert get_best_parsable_locale(module, preferences) == "C"

# Generated at 2022-06-20 16:03:56.594141
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils as module_utils
    import ansible.module_utils.common.process as process

    class FakeModule(object):
        def __init__(self):
            self.run_command = run_command
            self.get_bin_path = get_bin_path


# Generated at 2022-06-20 16:04:05.158753
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    if sys.version_info[0] == 2:
        import __builtin__ as builtins  # pylint: disable=import-error
    else:
        import builtins  # pylint: disable=import-error

    # mock base AnsibleModule
    class Module():
        def __init__(self, **kwargs):
            self.params = kwargs

        def get_bin_path(self, arg, required=None):
            return None

        def fail_json(self, **kwargs):
            return False

        def run_command(self, arg):
            return [0, 'C\nen_US\nen_US.iso88591', '']

    m = Module()
    msg = "Could not find 'locale' tool"

# Generated at 2022-06-20 16:04:16.431806
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    import ansible.module_utils.basic
    import ansible.module_utils.common.systemd
    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec={
            'raise_on_locale': dict(type='bool', required=False, default=False),
        },
    )

    m_systemd_get_best_parsable_locale = ansible.module_utils.common.systemd.get_best_parsable_locale

    # Test for default locale (C)
    ansible.module_utils.common.systemd.get_best_parsable_locale = lambda module, preferences, raise_on_locale: 'C'

# Generated at 2022-06-20 16:04:25.060523
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Mock out AnsibleModule
    class FakeModule(object):
        def __init__(self):
            self._bin_path = {'/usr/bin/locale': '/usr/bin/locale'}

        def get_bin_path(self, command, required=False):
            if command in self._bin_path:
                return self._bin_path[command]
            else:
                return None

        def run_command(self, command):
            class FakeOut(object):
                def strip(self):
                    return 'C C.UTF-8 en_US.UTF-8 POSIX'

            class FakeErr(object):
                pass

            return 0, FakeOut(), FakeErr()


    # Get the best parsable locale
    fake_module = FakeModule()
    assert get_best_parsable_locale