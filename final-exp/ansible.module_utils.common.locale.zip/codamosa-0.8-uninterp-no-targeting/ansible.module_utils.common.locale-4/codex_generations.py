

# Generated at 2022-06-20 15:54:32.434400
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    am = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )

    assert get_best_parsable_locale(am) == 'C'


# Generated at 2022-06-20 15:54:44.191265
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.utils.display import Display
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import StringIO

    module_args = dict(check=dict(required=False, type='bool', default=False))

    module = AnsibleModule(argument_spec=module_args,
                           supports_check_mode=True)

    display = Display()
    # Set stdout.
    display.verbosity = 2
    display.columns = 80
    display.stdout = StringIO()

    assert get_best_parsable_locale(module, preferences=['C.UTF-8'], raise_on_locale=False) == 'C.UTF-8'

# Generated at 2022-06-20 15:54:53.830229
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import pytest
    mock_module = AnsibleModule(supports_check_mode=True, bypass_checks=True)

    # "locale -a" does not return anything
    mock_module.run_command = lambda args, **kwargs: (0, '', '')
    assert get_best_parsable_locale(mock_module) == 'C'

    # "locale -a" returns a bunch of locales, including some from preferences
    mock_module.run_command = lambda args, **kwargs: (0, "en_US\nen_US.utf8\nC\nC.utf8\nPOSIX", '')
    assert get_best_parsable_locale(mock_module) == 'C.utf8'

   

# Generated at 2022-06-20 15:55:01.359108
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    import os
    import tempfile
    import shutil

    # get the current working directory to restore at the end
    # of this function
    cwd = os.getcwd()

    # create temporary directory
    tmpdir = tempfile.mkdtemp()


# Generated at 2022-06-20 15:55:04.570589
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-20 15:55:08.035526
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    values = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    for v in values:
        assert(get_best_parsable_locale(None, preferences=[v]) == v)

# Generated at 2022-06-20 15:55:19.315377
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    import unittest
    import mock
    class TestAnsibleModule(object):

        def __init__(self):
            self.params = None
            self.fail_json = None

        def get_bin_path(self, name):
            if name.endswith('locale'):
                return 'locale'

        def run_command(self, cmd):
            out = ''
            if cmd == ['locale', '-a']:
                out = 'C'
            return 0, out, ''

        def fail_json(self, *args, **kwargs):
            pass


# Generated at 2022-06-20 15:55:31.347401
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import sys

    # To test this module, we need to execute it in a Python interpreter that does
    # not have pyc files, otherwise the pyc file will be loaded under Python3.
    # The easiest way to achieve this is to run `PYTHONPATH=. unicode_strings` from
    # the command line. This will run the py code under Python2.

    assert sys.version_info < (3,)

    ansible_module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True,
    )

    # Default case
    best_locale = get_best_parsable_locale(ansible_module)
    assert best_locale == 'C'

    # New line on stdout
    ansible_module._exec

# Generated at 2022-06-20 15:55:42.977539
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-20 15:55:49.108024
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    # Test that 'C' is returned if there is no locale tool
    tmp = AnsibleModule.get_bin_path
    AnsibleModule.get_bin_path = lambda x, y: None

    assert get_best_parsable_locale(AnsibleModule, raise_on_locale=False) == 'C'

    AnsibleModule.get_bin_path = lambda x, y: '/usr/bin/locale'

    # Test that 'C' is returned if the module raises a warning when there is a locale tool
    tmp2 = AnsibleModule.run_command
    AnsibleModule.run_command = lambda x, y, z: (1, '', 'Test')


# Generated at 2022-06-20 15:56:05.124434
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    module.run_command = lambda x: (0, 'C\nPOSIX\nen_US.utf8\nen_US.UTF-8\nC.UTF-8\nUTF-8', '')
    retval = get_best_parsable_locale(module, None)
    assert retval == 'C'

    module.run_command = lambda x: (0, 'C\nen_US.utf8\nen_US.UTF-8\nC.UTF-8\nUTF-8', '')
    retval = get_best_parsable_locale(module, ['C.utf8'])
    assert retval == 'C.utf8'


# Generated at 2022-06-20 15:56:16.609340
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Test scenario:

        1) test_values: no 'locale', empty list of locale
        2) test_values2: 'locale', but no output
        3) test_values3: 'locale', with empty list of available locales
        4) test_values4: 'locale', with empty list of available locales, no 'C'
        5) test_values5: 'locale', list of available locales, no preferred locales
        6) test_values6: 'locale', list of available locales, list of preferred locales, no match

    '''

    # Importing libraries here, as this function is used on ansible.module_utils
    # and Ansible fails on import if not on end of file
    import sys
    import mock
    from ansible.module_utils.basic import AnsibleModule



# Generated at 2022-06-20 15:56:24.296388
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    avail_locales = '\n'.join(['C.utf8', 'POSIX', 'en_US.utf8', 'C', 'en_US.utf8', 'POSIX'])
    # mock the locale -a output
    mod = AnsibleModule(argument_spec={'raise_on_locale': dict(type='bool', default=False)})
    mod.get_bin_path = lambda x: 'locale'
    mod.run_command = lambda x: (0, avail_locales, '')

    assert get_best_parsable_locale(mod) == 'en_US.utf8'
    assert get_best_parsable_locale(mod, preferences=['POSIX', 'C.utf8']) == 'POSIX'


# Generated at 2022-06-20 15:56:32.065232
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module, preferences=['C.UTF-8',]) == 'C'

    module = AnsibleModule(argument_spec={})
    try:
        get_best_parsable_locale(module, preferences=['en_AU.UTF-8',], raise_on_locale=True)
    except RuntimeWarning:
        assert True
    else:
        assert False

# Generated at 2022-06-20 15:56:43.103816
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # TODO: For now only testing the exception cases.
    #       Functionality can be tested by checking the output of locale -a.
    #       However, this is not always available (macOS) and at least one of the
    #       locales (C) should always be available.

    from ansible_collections.ansible.community.tests.unit.compat.mock import Mock

    m = Mock()

    # The 'locale' command does not exist
    m.run_command.return_value = (1, None, '')
    assert get_best_parsable_locale(m, raise_on_locale=True) == 'C'

    m.reset_mock()

    # The 'locale -a' command does not return anything

# Generated at 2022-06-20 15:56:49.741637
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
        print("Cases to test:")
        print("1) locale -a output is empty")
        print("2) locale -a is successful")
        print("3) no locale tool is installed")
        print("4) no locale tool is installed and raise_on_locale is true")
        print("5) user specifies a list of locales")
        print("6) user specifies a list of locales and raise_on_locale is true")
        print("7) locale -a output is empty and raise_on_locale is true")
        print("8) locale -a is successful and raise_on_locale is true")
        print("9) locale -a is successful and raise_on_locale is true and no valid locale is found")

# Generated at 2022-06-20 15:56:55.466620
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module_args = dict(preferences=['en_US.utf8', 'C'])
    module = AnsibleModule(argument_spec=module_args)
    res = get_best_parsable_locale(module, raise_on_locale=True)
    module.exit_json(msg="test", result=res)


# Generated at 2022-06-20 15:57:06.276082
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    if sys.version_info[0] < 3:
        from mock import MagicMock, patch
    else:
        from unittest.mock import MagicMock, patch

    module_args = dict(
        executable=None,
        _uses_shell=False,
        _raw_params='foo',
    )
    m = MagicMock(**module_args)

    # Locale is not found
    with patch('os.path.exists', return_value=False):
        # No preferences defined
        assert get_best_parsable_locale(m) == 'C'
        assert get_best_parsable_locale(m, preferences=['foo', 'bar']) == 'C'

    # Locale is found, but we have no preferences

# Generated at 2022-06-20 15:57:12.109237
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        The function get_best_parsable_locale is called without any
        parameters and without any module. Preferances are the default
        settings. The result is compared with the default setting 'C'.
        An exception is
    '''

    try:
        assert(get_best_parsable_locale(None) == 'C')
    except:
        assert(False)

# Generated at 2022-06-20 15:57:21.772450
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    locale = get_best_parsable_locale(None, None)
    assert locale == 'C'
    locale = get_best_parsable_locale(None, ['C'])
    assert locale == 'C'
    locale = get_best_parsable_locale(None, ['C.UTF-8', 'C'])
    assert locale == 'C'
    locale = get_best_parsable_locale(None, ['C', 'C.UTF-8'])
    assert locale == 'C'
    locale = get_best_parsable_locale(None, ['en_US'])
    assert locale == 'C'
    locale = get_best_parsable_locale(None, ['en_US', 'C'])
    assert locale == 'C'
    locale = get_best

# Generated at 2022-06-20 15:57:34.532033
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None, ['C.UTF-8'], True) == 'C.UTF-8'
    assert get_best_parsable_locale(None, ['C.UTF-8', 'en_US.UTF-8'], True) == 'C.UTF-8'



# Generated at 2022-06-20 15:57:44.828702
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.common.process import get_bin_path

    import sys

    module = AnsibleModule(argument_spec={})
    module.params['_ansible_verbosity'] = 4

    if sys.platform == 'darwin':
        preferences = ['en_US.UTF-8', 'C']
    else:
        preferences = ['en_US.utf8', 'C.utf8', 'C', 'POSIX']

    best = get_best_parsable_locale(module, preferences)
    assert(best in preferences)

# Generated at 2022-06-20 15:57:51.615245
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    m = ansible.module_utils.basic.AnsibleModule(argument_spec={})
    assert(get_best_parsable_locale(m, ['en_US.utf8', 'C']) == 'en_US.utf8')
    assert(get_best_parsable_locale(m, ['en_US.utf8', 'en_US.utf8', 'en_US.utf8']) == 'en_US.utf8')
    assert(get_best_parsable_locale(m, ['en_US.utf8', 'C', 'C']) == 'en_US.utf8')
    assert(get_best_parsable_locale(m, ['C', 'C', 'C']) == 'C')

# Generated at 2022-06-20 15:57:53.904221
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    assert get_best_parsable_locale(AnsibleModule) == 'C'

# Generated at 2022-06-20 15:58:02.751522
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils import basic

    module = AnsibleModule(argument_spec={})
    assert basic.get_best_parsable_locale(module) == 'C'

    with basic.AnsibleModuleStub(argument_spec={}, locale_binary_path='/usr/bin/locale') as module:
        out = 'C\nen_US.utf8\nC.utf8\nen_US.utf8\n'
        assert basic.get_best_parsable_locale(module, preferences=['C.utf8']) == 'C.utf8'
        assert basic.get_best_parsable_locale(module, preferences=['en_US.utf8']) == 'en_US.utf8'
        assert basic

# Generated at 2022-06-20 15:58:05.951910
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale({}) == 'C'
    assert get_best_parsable_locale({}, ['C', 'C.utf8']) == 'C'

# Generated at 2022-06-20 15:58:11.135713
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    m = AnsibleModule(argument_spec=dict(preferences=dict(type='list')))

    try:
        locale_result = get_best_parsable_locale(m, raise_on_locale=False)
    except RuntimeWarning:
        # If its not available, test passes.
        locale_result = 'C'

    assert locale_result == 'C'

# Generated at 2022-06-20 15:58:14.898102
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(),
    )

    result = get_best_parsable_locale(module)
    assert result == 'C'

# Generated at 2022-06-20 15:58:22.924482
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    current_locale = get_best_parsable_locale(module=module)

    assert ( isinstance(current_locale, str) )

    current_locale = get_best_parsable_locale(module=module, raise_on_locale=True)

    assert ( isinstance(current_locale, str) )


# Generated at 2022-06-20 15:58:26.488804
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={}, supports_check_mode=False)

    assert 'en' in get_best_parsable_locale(module, ['en_US.utf8', 'en_US.UTF-8', 'en_US'])

# Generated at 2022-06-20 15:58:48.239853
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    m = AnsibleModule(
        argument_spec=dict(
            locale=dict(type='str', default=None),
            preferences=dict(type='list', default=None),
            raise_on_locale=dict(type='bool', default=True)
        )
    )

    # This is an ugly test but it tests the happy path and the failure path
    # this test is run in the current environment so the locale available
    # and the locale binary are the same as on the system running the test.

# Generated at 2022-06-20 15:58:55.474026
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class AnsibleModule(object):
        def __init__(self):
            self.bin_path = "/bin/"

        def get_bin_path(self, executable, optional=False):
            if executable in ["locale"]:
                return self.bin_path + executable

        def run_command(self, args):
            if args == ["/bin/locale", "-a"]:
                out = "POSIX\nC.utf8\nen_US.utf8\n"
                return (0, out, "")
            else:
                return None

    # Test: locale commands installed, good data
    d = AnsibleModule()
    assert get_best_parsable_locale(d) == "C.utf8"

    # Test: locale commands installed, good data
    d = AnsibleModule()
    d.run

# Generated at 2022-06-20 15:59:05.354501
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    ''' This is not a true unit test, it requires a Linux install with the 'locale' program installed
        This is solely done to test the function and the code coverage of it
    '''
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_native
    from ansible.module_utils.common.process import get_bin_path
    import os

    if os.name != 'posix':
        # This is a POSIX only function, it doesn't support Windows
        raise Exception('Not a POSIX based OS')
    if os.getenv('VIRTUAL_ENV') is not None:
        # This function is not available in a virtualenv where locale is not installed
        raise Exception('Running in a virtual environment')

    module = AnsibleModule(argument_spec=dict())
   

# Generated at 2022-06-20 15:59:16.229782
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    """Test various output from locale -a command and make sure we get
        expected response from get_best_parsable_locale function

        :return: None
    """
    import errno
    import sys
    from ansible.module_utils import basic
    from ansible.module_utils.common.process import get_bin_path

    locale = get_bin_path("locale")
    if locale is None:
        print("locale is not available, skipping")
        sys.exit(errno.ENOTFOUND)

    def _fake_run_command(cmd, raise_on_err=True, environ_update=None, data=None):
        return (0, "c\nPOSIX\nen_US.utf8\nen_US.UTF-8", "")


# Generated at 2022-06-20 15:59:26.979553
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes

    # When able to retrieve locale information
    module = AnsibleModule(argument_spec={})
    module.run_command = lambda args: (0, to_bytes(u'C\nen_US.utf8\nC.utf8\nen_GB.utf8'), None)
    assert 'C' == get_best_parsable_locale(module)
    assert 'en_GB.utf8' == get_best_parsable_locale(module, preferences=['en_GB.utf8', 'en_US.utf8'])

    # When unable to retrieve locale information
    module.run_command = lambda args: (1, None, None)
    assert 'C' == get_best_pars

# Generated at 2022-06-20 15:59:36.101808
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.tests.unit import utils
    from io import StringIO

    my_env = None
    my_rc = 1
    my_out = StringIO()
    my_err = StringIO()

    class TestModule(object):

        def __init__(self):
            self.params = {}

        def exit_json(self, rc):
            pass

        def fail_json(self, **kwargs):
            pass

        def run_command(self, args):
            return my_rc, my_out, my_err

        def get_bin_path(self, app):
            if app == 'locale':
                return '/usr/bin/locale'
            else:
                return None

    def test_env(name):
        my_env

# Generated at 2022-06-20 15:59:44.805166
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Basic test to check that the function correctly finds an available locale
        and returns it.  It also tests the case where no locales are available.
    '''
    import sys

    sys.modules['ansible'] = sys.modules['__main__']  # hack to get import to work
    sys.modules['ansible.module_utils.basic'] = sys.modules['__main__']
    import ansible.module_utils
    ansible.module_utils.basic = sys.modules['__main__']  # hack to get import to work
    from ansible.module_utils.basic import AnsibleModule

    module_args = {}
    module = AnsibleModule(
        argument_spec=module_args,
    )

    # We mock the run_command to return the same locale (C) as it is returned on
    # a

# Generated at 2022-06-20 15:59:49.827852
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Test for get_best_parsable_locale
    '''
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    result = get_best_parsable_locale(module)
    assert result == 'C'

# Generated at 2022-06-20 15:59:56.016540
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    ''' get_best_parsable_locale should correctly find the preference
    when multiple locales are available.
    '''

    import unittest2 as unittest
    import ansible.module_utils.basic
    from ansible.compat.tests import patch, mock_open

    class AnsibleModuleMock(object):

        def __init__(self):
            self.run_command = lambda x: ('', 'en_US.utf8\nen_US.utf8\nen_GB.utf8\nen_US.iso88591\nC')

        def get_bin_path(self):
            return True


# Generated at 2022-06-20 16:00:01.754024
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    import ansible.module_utils.basic as basic_utils
    import ansible.module_utils.common.parameters as param_utils

    # Mock params
    params = param_utils.AnsibleModuleParameters()

    # Mock module
    module = basic_utils.AnsibleModule(argument_spec=params.argument_spec, supports_check_mode=params.supports_check_mode)

    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-20 16:00:39.153418
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    """
    Function to test the output of the function get_best_parsable_locale
    compared to the output of the command locale -a
    """
    from ansible.module_utils.basic import AnsibleModule
    my_locale_a = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )
    my_available_locales = my_locale_a.run_command(['locale', '-a'])
    for pref in ['C', 'POSIX']:
        if pref in my_available_locales[1]:
            assert get_best_parsable_locale(my_locale_a) == pref
            break
    else:
        if 'en_US.utf8' in my_available_locales[1]:
            assert get_best_

# Generated at 2022-06-20 16:00:48.764448
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Verify that we get best locale if LC_MESSAGES is not set, and locales
    # are installed
    module = type('FakeModule', (object,), {
        'run_command': lambda self, args:
        (0, '\nC\nC.utf8\nen_US.utf8\nPOSIX\n', None),
        'get_bin_path': lambda self, command: 'blah'
    })()

    assert get_best_parsable_locale(module) == 'C.utf8'

    # Verify that we get best locale if LC_MESSAGES is set

# Generated at 2022-06-20 16:00:56.270417
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.basic import AnsibleModule

    # Run get_best_parsable_locale
    module = AnsibleModule(argument_spec={})
    locale = get_best_parsable_locale(module)
    assert locale == 'C', "Wrong locale returned"

    # Run get_best_parsable_locale with preferred locales
    module = AnsibleModule(argument_spec={})
    locale = get_best_parsable_locale(module, preferences=['C.utf8'])
    assert locale == 'C.utf8', "Wrong locale returned"

# Generated at 2022-06-20 16:01:04.250178
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import os
    import sys

    # test for linux
    if sys.platform.startswith('linux'):
        # if not in a pty it will not send messages
        assert get_best_parsable_locale(None, raise_on_locale=True) is not None

    # test for mac
    if sys.platform.startswith('darwin'):
        assert get_best_parsable_locale(None, raise_on_locale=True) is not None

# Generated at 2022-06-20 16:01:14.018258
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    """
    Tests return value of get_best_parsable_locale function
    """
    import ansible.module_utils
    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec={},
        supports_check_mode=True,
    )

    # Modify list of preferred locales and ensure that best match is returned
    preferences = ['en_US.utf8', 'C.utf8']
    assert get_best_parsable_locale(module, preferences=preferences, raise_on_locale=True) == 'en_US.utf8'

    preferences = ['en_US', 'C']
    assert get_best_parsable_locale(module, preferences=preferences, raise_on_locale=True) == 'en_US'


# Generated at 2022-06-20 16:01:18.857200
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    """
    Describe the test here

    :avocado: tags=baremetal,test_get_best_parsable_locale
    """
    with open('test_get_best_parsable_locale.json', 'w') as f:
        f.write('{"best_parsable_locale": "C"}\n')


if __name__ == "__main__":
    main()

# Generated at 2022-06-20 16:01:24.710197
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    import sys
    sys.path.append('/usr/share/ansible')

    from ansible.module_utils.basic import AnsibleModule

    def test_locale(a_module, preferences=None, raise_on_locale=False):
        ''' Returns the best parsable locale and the error message (if any) '''

        error_message = None
        try:
            best_locale = get_best_parsable_locale(a_module, preferences, raise_on_locale)
        except RuntimeWarning as e:
            error_message = str(e)
        return best_locale, error_message

    # Real locale command (debian stretch) output...

# Generated at 2022-06-20 16:01:34.968167
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    # Private function imports
    from ansible.module_utils.common.locales import get_best_parsable_locale

    m = AnsibleModule()
    m.get_bin_path = lambda x: '/usr/bin/locale'
    m.run_command = lambda x: (0, '\n'.join(
        [
            'C',
            'C.UTF-8',
            'C.utf8',
            'en_US.utf8',
            'POSIX',
        ]
    ), '')

    assert get_best_parsable_locale(m) == 'C.utf8'
    assert get_best_parsable_locale(m, ['POSIX', 'C.UTF-8']) == 'POSIX'

# Generated at 2022-06-20 16:01:45.280441
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils import basic

    module_args = {"preferences": ['POSIX', 'C.utf8', 'en_US.utf8', 'C', 'C.utf8'], "raise_on_locale": True}
    amodule = basic.AnsibleModule(argument_spec=module_args)

    # System locale present in preferences, should return 1st preferred locale
    # i.e C.utf8
    assert 'C.utf8' == get_best_parsable_locale(amodule)

    # System locale not present in preferences, should return 1st preferred
    # locale i.e POSIX

# Generated at 2022-06-20 16:01:52.864848
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # test that 'C' is returned when there is no locale tool
    module.get_bin_path = lambda tool: None
    try:
        assert module.get_best_parsable_locale() == 'C'
    except RuntimeWarning:
        assert False, 'get_parsable_locale() raised RuntimeWarning unexpectedly!'

    # test that 'C' is returned when there is no output from 'locale -a'
    module.get_bin_path = lambda tool: 'locale'
    module.run_command = lambda cmd: (0, '', None)

# Generated at 2022-06-20 16:02:55.381785
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    # test with no preferences given
    assert get_best_parsable_locale(None) in preferences
    # test with valid preferences
    assert get_best_parsable_locale(None, ['POSIX']) == 'POSIX'
    # test with invalid preferences
    assert get_best_parsable_locale(None, ['POSIX', 'en_US.utf8', 'invalid']) in ['POSIX', 'en_US.utf8']

# Generated at 2022-06-20 16:03:00.152566
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    ''' Tests for get_best_parsable_locale '''

    # Needs to be modern AnsibleModule to not fail
    from ansible.module_utils.basic import AnsibleModule
    import os
    import tempfile

    # Use a fix locale output
    locale_out = tempfile.mkstemp()[1]
    with open(locale_out, "w") as f:
        f.write(os.linesep.join(['C', 'en_US.utf8', 'POSIX', 'C.utf8']))
    os.environ['ANSIBLE_LOCALE_OUT'] = locale_out

    # Mock the module
    module = AnsibleModule(
        argument_spec=dict()
    )

    # Test that C.utf8 is chosen by default
    assert get_best_parsable_locale

# Generated at 2022-06-20 16:03:11.103354
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    locale_path = "/bin/locale"
    locale_cmd = []
    locale_cmd.append(locale_path)
    locale_cmd.append('-a')

    # Test case 1: Match single locale
    test_preferences = ['de_CH.UTF-8']
    available = ['de_CH.UTF-8', 'pt_BR.UTF-8']
    found = 'C'
    for pref in test_preferences:
        if pref in available:
            found = pref
            break
    assert found == 'de_CH.UTF-8'

    # Test case 2: Match multiple locales
    test_preferences = ['de_CH.UTF-8', 'pt_BR.UTF-8']
    available = ['de_CH.UTF-8', 'pt_BR.UTF-8']
   

# Generated at 2022-06-20 16:03:17.691498
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Checking with proper preference
    assert get_best_parsable_locale(None, ['C.UTF-8', 'POSIX']) == 'C.UTF-8'

    # Checking without preference
    assert get_best_parsable_locale(None) == 'C'

    # Checking with empty preference
    assert get_best_parsable_locale(None, []) == None

    # Checking with None preference
    assert get_best_parsable_locale(None, None) == 'C'

# vim: expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-20 16:03:28.176659
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, preferences=['POSIX']) == 'C'
    assert get_best_parsable_locale(module, preferences=['POSIX', 'C']) == 'C'
    assert get_best_parsable_locale(module, preferences=['POSIX', 'C.utf8']) == 'C'
    assert get_best_parsable_locale(module, preferences=['POSIX', 'C.utf8', 'en_US.utf8']) == 'C.utf8'

# Generated at 2022-06-20 16:03:38.993124
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Set up mocks for AnsibleModule and os.path
    class MockAnsibleModule:
        def __init__(self, name):
            self.name = name
        def get_bin_path(self, name):
            if name == 'locale':
                return name
            else:
                return False
        def run_command(self, cmd):
            return (0, self.name, '')
    m = MockAnsibleModule('test_get_best_parsable_locale')

    # Test case 1: Use default preferences with no errors
    assert get_best_parsable_locale(m) == 'test_get_best_parsable_locale'

    # Test case 2: Use custom preferences with no errors

# Generated at 2022-06-20 16:03:46.684296
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = MagicMock()
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    result = ['C.utf8', 'POSIX']
    for pref in preferences:
        available = ['C', 'C.utf8', 'POSIX', 'en_US.utf8']
        out = '\n'.join(available) + '\n'

        module.get_bin_path.return_value = 'locale'
        module.run_command.return_value = (0, out, '')
        best_locale = get_best_parsable_locale(module, [pref], raise_on_locale=True)
        assert best_locale in result

# Generated at 2022-06-20 16:03:48.696680
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    mod = AnsibleModule()
    assert 'C' == get_best_parsable_locale(mod)

# Generated at 2022-06-20 16:03:54.793621
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None) == 'C'
    assert get_best_parsable_locale(None, ['C']) == 'C'
    assert get_best_parsable_locale(None, ['XXX']) == 'C'
    assert get_best_parsable_locale(None, ['C', 'XXX']) == 'C'
    assert get_best_parsable_locale(None, ['XXX', 'C']) == 'C'
    assert get_best_parsable_locale(None, ['XXX', 'XXX2']) == 'C'

# Generated at 2022-06-20 16:03:57.888614
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    test_module = AnsibleModule(
        argument_spec=dict()
    )

    assert get_best_parsable_locale(test_module) == "C"