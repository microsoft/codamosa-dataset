

# Generated at 2022-06-20 15:54:35.827391
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    class FakeModule():
        def __init__(self):
            self.run_command = fake_run_command

    class FakeModule2():
        def __init__(self):
            self.run_command = fake_run_command_stderr

    def fake_run_command(self, command):
        if 'run_command' in self.fail_json_msg:
            return 1, None, None
        if command[1] == '-a':
            return 0, 'C\nPOSIX\nen_US\nen_US.utf8\nen_US.UTF-8\n', ''

# Generated at 2022-06-20 15:54:46.739354
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Unit test to check language parsing with different outputs
    '''

    # This is to check that we are always returning C in case of failure
    assert get_best_parsable_locale() == 'C'

    assert get_best_parsable_locale([]) == 'C'

    # Added to make sure the parser will select 'C' by default
    assert get_best_parsable_locale(['en_US.utf8']) == 'en_US.utf8'

    # Added to make sure the parser will select 'C' by default
    assert get_best_parsable_locale(['en_US.utf8', 'C.utf8']) == 'en_US.utf8'

    # Added to make sure the parser will select 'C' by default
    assert get_best_pars

# Generated at 2022-06-20 15:54:50.706269
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    """
    This function is to unit test the function get_best_parsable_locale
    """
    # Call the function under test
    ret = get_best_parsable_locale(None, ['C.utf8', 'en_US.utf8', 'C', 'POSIX'])

    # Verify the expected result
    assert ret == 'C'

# Generated at 2022-06-20 15:55:02.320107
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common._collections_compat import Sequence

    preferences = ['en_US.utf8', 'C', 'POSIX']
    module = AnsibleModule(argument_spec={'preferences': {'type': 'list', 'elements': 'str', 'required': False}})

    if module.params['preferences']:
        if not isinstance(module.params['preferences'], Sequence):
            module.fail_json(msg="preferences expects a list")
        preferences = module.params['preferences']

    module.exit_json(msg=get_best_parsable_locale(module, preferences, raise_on_locale=True))


if __name__ == '__main__':
    test_get

# Generated at 2022-06-20 15:55:13.720702
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import os
    import tempfile
    import random

    class Module(object):
        def get_bin_path(self, path):
            return path

        def run_command(self, args):
            # When we run this command to get the selected locales we can
            # either use the full list of locales that are installed on the
            # system or we can create a test set.

            # Returning an empty list will used the test set of locales
            available = []

            # If this file exists we will read it and return the list of
            # installed locales
            locales_file = '/etc/locale.gen'

            if os.path.isfile(locales_file):
                with open(locales_file, 'r') as f:
                    available = [x.strip() for x in f.readlines()]

           

# Generated at 2022-06-20 15:55:22.989856
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Returns a list with the same number of elements as the expected list
        and the i-th element is True if and only if the i-th element of the
        expected list is contained in the actual list.

        :param expected: A list of strings
        :param actual: A list of strings
        :returns: A list of booleans
    '''

    expected = ['LANG', 'LC_CTYPE']

# Generated at 2022-06-20 15:55:32.877854
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.compat.tests.mock import create_autospec
    from ansible.module_utils.six import u

    test_preferences = ['en_US.utf8', 'C.utf8', 'POSIX', 'C']
    test_preferences_empty = []


# Generated at 2022-06-20 15:55:34.821364
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None) == 'C'

# Generated at 2022-06-20 15:55:38.400932
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    module = AnsibleModule(argument_spec={}, supports_check_mode=True)

    assert module.get_bin_path('locale')

    assert get_best_parsable_locale(module)

# Generated at 2022-06-20 15:55:48.769428
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Set up some test data that can be used to test function get_best_parsable_locale
    # Note that this module is not available in Ansible 2.4 below
    from ansible.module_utils.basic import AnsibleModule

    # by default, this will use the non-english locale 'es_ES.utf8'
    # This can be changed by modifying 'LANG' environment variable
    # For example, export LANG=en_US.utf8
    mod = AnsibleModule({})
    assert isinstance(mod, AnsibleModule)
    assert mod.get_bin_path("locale")

    # This is the locale set up in the system
    # Note that this is not available in all systems.
    system_locale = 'es_ES.utf8'

    # These are the locales we want to try to find in

# Generated at 2022-06-20 15:56:03.594097
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Test the get_best_parsable_locale function
    :return:
    '''
    try:
        from ansible.module_utils.basic import AnsibleModule
    except ImportError:
        # Don't fail on imports.
        pass
    else:
        from ansible.module_utils.basic import AnsibleModule
        from ansible.module_utils.common._collections_compat import Mapping
        import sys

        class TestModule(AnsibleModule):
            ''' Dummy class for unit tests'''
            TESTING = True

        if sys.version_info < (2, 7):
            from unittest2 import TestCase, main
        else:
            from unittest import TestCase, main


# Generated at 2022-06-20 15:56:09.377624
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    ''' Test that we get the best possible locale when using get_best_parsable_locale'''
    import AnsibleModule
    module = AnsibleModule.AnsibleModule(argument_spec={}, supports_check_mode=False, check_invalid_arguments=False)
    best_parsable_locale = get_best_parsable_locale(module)
    assert best_parsable_locale == "C"

# Generated at 2022-06-20 15:56:20.633857
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    """Test get_best_parsable_locale"""

    # given
    import sys
    import os
    import collections
    import subprocess

    # import ansible module class
    from ansible.module_utils.basic import AnsibleModule

    # import ansible module utils
    import ansible.module_utils.basic
    import ansible.module_utils.six

    # mock module
    path_to_this_module = os.path.realpath(os.path.dirname(__file__))

    # mock `run_command` to return a list of available locales

# Generated at 2022-06-20 15:56:31.741354
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    am = AnsibleModule(argument_spec={})

    preferences = ['C.utf8', 'en_US.utf8']
    found = 'C'  # default posix, its ascii but always there

# Generated at 2022-06-20 15:56:43.079932
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        This is only tested on systems that support locale -a
        (we don't test windows)
    '''
    module = AnsibleModule(argument_spec=dict())

    locales = module.run_command(['locale', '-a'])
    assert locales[0] == 0
    assert isinstance(locales[1], str)

    # this is ok
    assert get_best_parsable_locale(module=module) == 'C'

    # we can set a list of preferences
    assert get_best_parsable_locale(module=module, preferences=['en_US.utf8']) == 'en_US.utf8'

    # this will return the first in the list

# Generated at 2022-06-20 15:56:49.771484
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.pycompat24 import get_exception

    def run_cmd(cmd, **kwargs):
        if cmd == ['locale', '-a']:
            return (0, "C\nen_US.utf8\nC.utf8", "")
        else:
            raise Exception("Unexpected cmd: %s" % " ".join(cmd))

    test_module = AnsibleModule(argument_spec={}, supports_check_mode=True, check_invalid_arguments=False)
    test_module.get_bin_path = lambda x: 'test'
    test_module.run_command = run_cmd

    assert get_best_parsable_locale(test_module) == "C.utf8"

# Generated at 2022-06-20 15:57:01.276775
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    # Create a mock module and call the function directly
    module = AnsibleModule()
    module.run_command = lambda cmd: (0, "C\nC.UTF-8\n", '')
    result = get_best_parsable_locale(module)
    assert result == 'C.UTF-8'

    module.run_command = lambda cmd: (1, '', 'unable to get locale')
    result = get_best_parsable_locale(module, preferences=['fr_CA.UTF-8', 'C.UTF-8'])
    assert result == 'C'

    module.run_command = lambda cmd: (0, '', 'unable to get locale')

# Generated at 2022-06-20 15:57:04.676308
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale({},None,raise_on_locale=True) == 'C'

if __name__ == '__main__':
    test_get_best_parsable_locale()

# Generated at 2022-06-20 15:57:16.385309
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Test function get_best_parsable_locale():
    # Test 0
    # Test for non-existent locale program
    # Expected: return 'C'

    import os
    import tempfile

    class fake_exception(Exception):
        pass

    class fake_module(object):

        def __init__(self, *args, **kwargs):
            self.bin_path = None
            self.module_args = []

        def get_bin_path(self, tool, required=False):
            if tool != 'locale':
                if required:
                    raise fake_exception("Unit test exception")
                else:
                    return None
            else:
                return self.bin_path

        def run_command(self, arguments, **kwargs):
            if self.bin_path is None:
                raise fake_

# Generated at 2022-06-20 15:57:25.201585
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict()
    )

    # good case
    locale = get_best_parsable_locale(module, ['C', 'POSIX'])
    assert locale == 'C'

    # bad case
    try:
        get_best_parsable_locale(module, ['foo'], True)
        assert False
    except RuntimeWarning:
        assert True

    # bad case with no raise
    locale = get_best_parsable_locale(module, ['foo'], False)
    assert locale == 'C'

# Generated at 2022-06-20 15:57:35.770125
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Whether this check is or not necessary depends on the platform
    if sys.version_info[:3] < (2, 7, 9):
        raise RuntimeWarning("Python version 2.7.9 or newer is required")

    from ansible.module_utils.basic import AnsibleModule

    actual = get_best_parsable_locale(AnsibleModule(argument_spec={}))
    assert actual == "C"

# Generated at 2022-06-20 15:57:46.904369
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic as basic

    module = basic.AnsibleModule(argument_spec={'preferences': {'type': 'list'}})

    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, ['C', 'POSIX']) == 'C'
    assert get_best_parsable_locale(module, ['POSIX', 'C']) == 'C'
    assert get_best_parsable_locale(module, ['POSIX', 'fr_FR']) == 'C'
    assert get_best_parsable_locale(module, ['fr_FR', 'POSIX']) == 'C'


# Generated at 2022-06-20 15:57:57.800570
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Try the various scenarios where we can get the locale information
    # 1. First preference is available
    # 2. A preference is available
    # 3. There are no preferences and none of them are available
    assert get_best_parsable_locale(
        module=None,
        preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX'],
        raise_on_locale=False
    ) == 'C.utf8'

    assert get_best_parsable_locale(
        module=None,
        preferences=['C.utf8', 'en_US.utf8'],
        raise_on_locale=False
    ) == 'C.utf8'


# Generated at 2022-06-20 15:57:58.834790
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None) == 'C'

# Generated at 2022-06-20 15:58:09.704487
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    This function is used to test get_best_parsable_locale function
    in parse.py module
    '''
    import sys

    if sys.version_info >= (3, 0):
        import unittest
        # Mocking module class
        import ansible.module_utils.basic

        class_mocked_basic_module = unittest.mock.Mock(ansible.module_utils.basic.AnsibleModule)
        # Mocking methods
        (class_mocked_basic_module.get_bin_path.side_effect) = ['locale']
        (class_mocked_basic_module.run_command.side_effect) = [0, ['POSIX']]

        from ansible.module_utils.basic import AnsibleModule
        parsed_data = get_best_pars

# Generated at 2022-06-20 15:58:16.200339
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    m = ansible.module_utils.basic.AnsibleModule(argument_spec={})
    #
    # We will test all the paths in this function. We
    # need to make sure that get_best_parsable_locale
    # is returning the right locale. We do this by
    # expecting a certain locale to be returned.
    #
    locale = get_best_parsable_locale(m, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX'], raise_on_locale=True)
    assert locale == 'C'
    #
    # This test should return en_US.utf8. If it does not, then we
    # have an issue in the get_best_parsable_locale function.
   

# Generated at 2022-06-20 15:58:16.845424
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    pass

# Generated at 2022-06-20 15:58:17.795971
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    pass

# Generated at 2022-06-20 15:58:27.703107
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule({}, check_invalid_arguments=False)
    # wrapper for AnsibleModule.run_command which returns a 3-tuple
    module.run_command = lambda *args: (0, None, None)

    # C locale will be returned when 'locale -a' returns no output
    assert 'C' == get_best_parsable_locale(module)

    # C.utf8 gets returned when available
    module.run_command = lambda *args: (0, 'C.utf8', None)
    assert 'C.utf8' == get_best_parsable_locale(module)

    # C locale gets returned when C.utf8 is not available

# Generated at 2022-06-20 15:58:33.202580
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    pref_list = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    pref_list_one = ['C']
    pref_list_two = ['C.utf8']

    # Test input as None
    out = get_best_parsable_locale(None)
    assert out == 'C'

    # Test input as empty string
    out = get_best_parsable_locale('')
    assert out == 'C'

    # Test input as list
    out = get_best_parsable_locale(pref_list)
    assert out == 'C'

    # Test input as list
    out = get_best_parsable_locale(pref_list_one)
    assert out == 'C'

    # Test input as list

# Generated at 2022-06-20 15:58:43.651548
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule({})

    for test_input, expected_output in (
            (['C'], 'C'),
            (['C-IS-NOT-AVAILABLE'], 'C'),
            (['C.UTF-8'], 'C.UTF-8'),
            # Last item in the default preference list is POSIX
            (['C', 'C.UTF-8', 'POSIX'], 'POSIX'),
            ):
        assert expected_output == get_best_parsable_locale(module, test_input)

# Generated at 2022-06-20 15:58:52.220394
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    # no locale
    preferences = None
    raise_on_locale= False
    locale = get_best_parsable_locale(AnsibleModule, preferences, raise_on_locale)
    assert locale == 'C'

    # locale set
    preferences = ['ja_JP.utf8']
    raise_on_locale= False
    locale = get_best_parsable_locale(AnsibleModule, preferences, raise_on_locale)
    assert locale == 'C'

# Generated at 2022-06-20 15:58:54.582562
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    assert get_best_parsable_locale(AnsibleModule(argument_spec={})) == 'C'

# Generated at 2022-06-20 15:59:05.210441
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    am = AnsibleModule({})
    # Fake a 'locale -a' env
    am.run_command = lambda cmd: (0, "C\nC.UTF-8\nen_US.UTF-8\nen_US.UTF-8\n", "")
    assert "C" == get_best_parsable_locale(am)

    am = AnsibleModule({})
    am.run_command = lambda cmd: (0, "en_US.UTF-8\nC.UTF-8\nC\nen_US.UTF-8\n", "")
    assert "C" == get_best_parsable_locale(am)

    am = AnsibleModule({})

# Generated at 2022-06-20 15:59:16.197494
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible
    from ansible.module_utils.basic import AnsibleModule

    # Test with no preference list
    test_module = AnsibleModule(argument_spec={})
    test_module.params['ansible_locale'] = 'C.UTF-8'
    assert get_best_parsable_locale(test_module) == 'C'

    # Test with a preference list
    preferences = ['Preferred1', 'Preferred2', 'Preferred3']

    # Test with an empty preference list
    test_module.params['ansible_locale'] = 'C.UTF-8'
    assert get_best_parsable_locale(test_module, preferences=preferences) == 'C'

    # Test with a preference not available in the system

# Generated at 2022-06-20 15:59:26.172589
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({})
    # On a C locale system or if POSIX is not installed,
    # get_best_parsable_locale will try to find the locale.
    # If this fails, it will default to 'C' locale.
    locale = get_best_parsable_locale(module)
    assert locale == 'C'
    # This also tests that specifying a list of precendence for the locale works as expected
    locale = get_best_parsable_locale(module, preferences=['Nonexistent.utf8', 'POSIX', 'C.utf8', 'en_US.utf8'])
    assert locale == 'POSIX'

# Generated at 2022-06-20 15:59:28.149159
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    locale_best = get_best_parsable_locale(None, preferences=['C'])
    assert locale_best == 'C'

# Generated at 2022-06-20 15:59:36.873612
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import os
    import shutil
    import tempfile
    from ansible.module_utils import basic
    from ansible.module_utils.common.text.converters import to_text

    # Create fake locale tool
    (fd, locale_path) = tempfile.mkstemp()
    os.write(fd, to_text('''#!/bin/sh
        case "$*" in
            -*a*)
                echo "C"
            ;;
        esac
    '''))
    os.close(fd)
    os.chmod(locale_path, 0o755)

    # Create a fake module
    tmp = tempfile.mkdtemp()
    if not tmp.endswith(os.sep):
        tmp += os.sep

# Generated at 2022-06-20 15:59:44.093447
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule({'ANSIBLE_MODULE_ARGS': {}})

    # Testing on C (default)
    assert get_best_parsable_locale(module) == 'C'

    # Testing on C.utf8
    assert get_best_parsable_locale(module, preferences=['C.utf8']) == 'C.utf8'

    # Testing on en_US.utf8
    assert get_best_parsable_locale(module, preferences=['en_US.utf8']) == 'en_US.utf8'

    # Testing on C
    assert get_best_parsable_locale(module, preferences=['C']) == 'C'

# Generated at 2022-06-20 15:59:53.455108
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # mock ansible module object
    class AnsibleModule(object):
        def get_bin_path(self, mpath):
            if mpath == 'locale':
                return mpath
            else:
                return None

        def run_command(self, cmd):
            out = 'C\nen_US.utf8\nC.utf8\nen.utf8'
            return 0, out, None

    # test when locale is not available
    am = AnsibleModule()
    am.get_bin_path = lambda self, mpath: None
    assert get_best_parsable_locale(am) == 'C'

    # test when locale is available but locale -a command fails
    am.get_bin_path = lambda self, mpath: 'locale' if mpath == 'locale' else None

# Generated at 2022-06-20 16:00:13.193857
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    """Function can return a list of preferred locale."""
    from ansible.compat.tests.mock import patch, Mock
    from ansible.compat.tests import unittest
    import ansible.module_utils.basic

    class TestModule(object):
        ''' simple test class '''
        class ReturnValues(object):
            ''' returns values for test module '''
            @staticmethod
            def get_bin_path(name):
                return '/test/bin/locale'

        def __init__(self):
            self.params = {}
            self.fail_json = Mock()
            self.exit_json = Mock()
            self.run_command = Mock()
            self.get_bin_path = self.ReturnValues.get_bin_path

    test_module = TestModule
    test_module.run_

# Generated at 2022-06-20 16:00:24.433058
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )

    # The best locale is always the first one in the list
    found = get_best_parsable_locale(module, ['a', 'b', 'c'])
    assert found == 'a'

    # When the list of preferences is empty, 'C' is chosen
    found = get_best_parsable_locale(module, [])
    assert found == 'C'

    # When the list of preferences is None, the default list is used
    found = get_best_parsable_locale(module)
    assert found in ['C.utf8', 'C']


if __name__ == "__main__":
    test_get_

# Generated at 2022-06-20 16:00:34.005010
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Monkey patch module module
    import ansible
    import os
    import sys

    module = ansible.module_utils.ANSIBLE_ARGS
    module = ansible.module_utils.basic.AnsibleModule(**module)

    def get_bin_path(self, executable):
        if executable == 'locale':
            return '/usr/bin/locale'
        else:
            return super(ansible.module_utils.basic.AnsibleModule, self).get_bin_path(executable)


# Generated at 2022-06-20 16:00:43.706602
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible import module_utils
    binary_location = '/usr/bin/local'
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    # Test for non-existence of binary
    module_utils._get_bin_path = Mock(return_value=None)
    locale = get_best_parsable_locale(module_utils, preferences)
    assert locale == 'C'
    # Test for failure of command
    module_utils._get_bin_path = Mock(return_value='/usr/bin/locale')
    module_utils.run_command = Mock(side_effect=RuntimeWarning('Unable to get locale information, rc=1: None'))
    locale = get_best_parsable_locale(module_utils, preferences)

# Generated at 2022-06-20 16:00:54.978166
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    import ansible.utils.module_docs as module_docs

    # Load the module.run_command function
    if sys.version_info[0] < 3:
        from ansible.module_utils.basic import AnsibleModule
    else:
        from ansible.module_utils._text import to_bytes

        class AnsibleModule:
            def __init__(self):
                self.bin_path_cache = {}

            def get_bin_path(self, name):
                if name in self.bin_path_cache:
                    return self.bin_path_cache[name]

                return None


# Generated at 2022-06-20 16:01:07.755114
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys

    if sys.version_info[0] != 2:
        raise Exception("A unit test requires Python 2")

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    if PY3:
        raise Exception("A unit test requires Python 2")

    class AnsibleModuleMock(AnsibleModule):
        def run_command(self, commands):
            if commands == ['locale', '-a']:
                return 0, 'C\nC.utf8\nen_US.utf8\nPOSIX\n', ''
            else:
                raise Exception("Unexpected command %s" % str(commands))

        # There is no 'os' module in Python 2 when you mock AnsibleModule

# Generated at 2022-06-20 16:01:17.066070
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Test no preferred locales
    assert get_best_parsable_locale(None, None) == 'C'

    # Test with English locale
    preferences = ['en_US.utf8', 'C.utf8', 'C', 'POSIX']
    assert get_best_parsable_locale(None, preferences) in ('en_US.utf8', 'C.utf8', 'C', 'POSIX')

    # Test with no locale
    preferences = ['C.UTF-8', 'en_US.UTF-8']
    assert get_best_parsable_locale(None, preferences) == preferences[0]

    # Test with no preferred locales and invalid value

# Generated at 2022-06-20 16:01:23.413633
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes

    module = AnsibleModule()
    locale = get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX'])

    if to_bytes(locale) != to_bytes('C'):
        raise AssertionError('Expected to get C back, got ' + to_native(locale))

    locale = get_best_parsable_locale(module, preferences=['POSIX', 'C.utf8', 'en_US.utf8', 'C'])


# Generated at 2022-06-20 16:01:34.100322
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        This is a simple unit test that requires the 'locale' utility to be available.
        It will validate that the new POSIX standard (C.utf8) is used, followed by
        en_US.utf8, C, or POSIX (in order) if they are available.
    '''

    # fake AnsibleModule
    class fakeAnsibleModule:
        def __init__(self):
            self.run_command_rc = 0

        def run_command(self, args):
            # create a fake list of available locales
            available = ['foo', 'C', 'bar', 'POSIX', 'en_US.utf8', 'C.utf8']
            return self.run_command_rc, "\n".join(available), ""

    # Test the default of the defaults which is the old POSIX standard
    mod

# Generated at 2022-06-20 16:01:41.229442
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Tests the function get_best_parsable_locale()
    '''
    # Creating a dummy AnsibleModule object to use with the function
    module = AnsibleModule(argument_spec=dict())
    module.run_command = Mock(return_value=(0, 'C.utf8\tC.UTF-8\ten_US.utf8\ten_US.UTF-8', ''))

    # Testing for valid found locale
    assert get_best_parsable_locale(module, ['C.utf8', 'en_US.utf8']) == 'C.utf8'

    # Testing for valid found locale with preferences
    assert get_best_parsable_locale(module, ['en_US.utf8', 'C.utf8']) == 'en_US.utf8'

    # Testing for

# Generated at 2022-06-20 16:02:06.614000
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    # Importing locale module for mocking
    try:
        from __main__ import locale
    except ImportError:
        # ansible-test in ansible 2.6+ is importing this function so we need to
        # make sure it's not imported
        try:
            import __main__
        except ImportError:
            __main__ = None

    # Mock 'locale' module so it looks like it doesn't exist
    def mock_get_bin_path(module, binary):
        if binary == "locale":
            return None
        else:
            return "/bin/bin"

    # Mock the run_command function that prints out supported locales
    def mock_run_command(module, command):
        return 0, "C\nen_US.utf8", ""

    #

# Generated at 2022-06-20 16:02:14.595784
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.utils.display import Display
    display = Display()
    display.vv = True

    import sys
    import pytest

    from ansible.module_utils.basic import AnsibleModule

    from ansible.module_utils.facts import facts_cache
    from ansible.module_utils.facts import add_facts
    from ansible.module_utils.facts import set_fact

    # This can be removed once we have a newer version of pytest
    if hasattr(sys.modules['pytest'], 'set_trace'):
        pytest.set_trace()


# Generated at 2022-06-20 16:02:20.298138
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Unit test for function get_best_parsable_locale
        Basic test
    '''
    # Fake module

# Generated at 2022-06-20 16:02:24.105790
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module, preferences=['C']) == 'C'
    assert get_best_parsable_locale(module, preferences=['XYZ']) == 'C'

# Generated at 2022-06-20 16:02:30.049175
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule()

    assert 'C' == get_best_parsable_locale(module)
    assert 'C' == get_best_parsable_locale(module, preferences=None)
    assert 'C' == get_best_parsable_locale(module, preferences=['foo', 'bar'])
    assert 'POSIX' == get_best_parsable_locale(module, preferences=['C', 'POSIX'])

# Generated at 2022-06-20 16:02:43.700385
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Test the function get_best_parsable_locale() from ansible.module_utils.basic
    '''
    # make some mock module objects
    class AnsibleModule:
        def __init__(self):
            self.params = {}
            self.exit_json = lambda **kv: exit(0)
            self.fail_json = lambda **kv: exit(1)

        # mock the module.run_command function
        #   ret: tuple of return code, stdout, stderr
        def run_command(self, cmd):
            if cmd[0] == 'locale':
                if cmd[1] == '-a':
                    return (0, 'C\nen_US.utf8\nC.utf8', '')

# Generated at 2022-06-20 16:02:53.272608
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class AnsibleModule:
        def __init__(self, locale, locale_available, locale_out, locale_err):
            self.locale = locale
            self.locale_available = locale_available
            self.locale_out = locale_out
            self.locale_err = locale_err
        def get_bin_path(self, bin):
            return self.locale
        def run_command(self, cmd):
            if cmd[0] == self.locale:
                return 0, self.locale_out, self.locale_err
            else:
                return -1, '', 'Unexpected command'
    def run_test(expected, **kargs):
        module = AnsibleModule(**kargs)
        ret = get_best_parsable_locale(module)

# Generated at 2022-06-20 16:02:58.561719
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert module.get_best_parsable_locale(module)

# Generated at 2022-06-20 16:03:09.422695
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    preferences = None
    best_locale = get_best_parsable_locale(module, preferences, raise_on_locale=False)
    assert best_locale == 'C'
    preferences = ['foo']
    best_locale = get_best_parsable_locale(module, preferences, raise_on_locale=False)
    assert best_locale == 'C'
    preferences = [None]
    best_locale = get_best_parsable_locale(module, preferences, raise_on_locale=False)
    assert best_locale == 'C'

# Generated at 2022-06-20 16:03:16.792877
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.common.process import AnsibleModule
    from ansible.module_utils.common.text.converters import to_bytes

    preferences = ['C.UTF-8', 'C.UTF8', 'C.utf8']
    available = ['C.UTF-8', 'en_US.UTF-8', 'C.UTF8', 'C.utf8', 'C']

    test_module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True,
    )


# Generated at 2022-06-20 16:03:41.777817
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible import constants as C
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(),
        support_check_mode=False,
    )
    module.params = {}
    assert get_best_parsable_locale(module) == C.DEFAULT_LOCALE
    assert get_best_parsable_locale(module, preferences=['en_US.utf8', 'C.utf8']) == 'en_US.utf8'
    assert get_best_parsable_locale(module, preferences=['en_US.utf8', 'en_US.UTF-8']) == 'en_US.utf8'

# Generated at 2022-06-20 16:03:48.617589
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        This tests the get_best_parsable_locale() function.
        Requires the mock package.
        test_get_best_parsable_locale() can be run as a script.
    '''
    from mock import Mock

    # Create a test module
    module = Mock()
    module.check_mode = False
    module.debug = False
    module.fail_json = False

    # Create the test cases

# Generated at 2022-06-20 16:03:56.171425
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    options = dict(
        ANSIBLE_MODULE_ARGS={},
        ANSIBLE_MODULE_CONSTANTS={},
        ANSIBLE_MODULES=dict(),
    )
    class FakeModule:
        def __init__(self, *args, **kwargs):
            self.run_command = run_command
            self.get_bin_path = get_bin_path
            self.failed = False
            self.warned = False

        def fail_json(*args, **kwargs):
            raise Exception('Failed')

        def exit_json(*args, **kwargs):
            raise Exception('Exit_json')

        def fail_json(self, *args, **kwargs):
            raise Exception('AnsibleModule fail_json')


# Generated at 2022-06-20 16:04:04.899048
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Test the get_best_parsable_locale function
    '''
    from ansible.module_utils.basic import AnsibleModule
    class NullModule:
        def __init__(self):
            self.params = {}
        def get_bin_path(self, a):
            return 'locale'
        class run_command:
            def __init__(self, a):
                self.rc = 0
                self.out = '\n' + 'C\nen_US.utf8\n'
            def __call__(self, a):
                return (self.rc, self.out, '')
    module = NullModule()

    locale = get_best_parsable_locale(module)
    assert(locale == 'en_US.utf8')

# Generated at 2022-06-20 16:04:10.184598
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.modules.system.locale as locale
    from ansible.compat.tests.mock import patch
    import string

    def _mock_run_command(*args):
        if 'locale -a' in args[1]:
            all_locales = '\n'.join(string.ascii_lowercase)
            rc = 0
            out = all_locales
            err = ''
        elif 'locale' in args[1]:
            rc = 0
            out = 'C\n'
            err = ''
        else:
            rc = 0
            out = ''
            err = ''
        return rc, out, err

    def _mock_get_bin_path(*args):
        if 'locale' in args[1]:
            return 'locale'
        else:
            return

# Generated at 2022-06-20 16:04:22.262164
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # This is not actually a test, but it is a requirement to load the module
    # to execute the function we are interested in.

    from ansible.compat.tests import unittest
    from ansible.module_utils.basic import AnsibleModule

    class Result(object):
        '''
        This class is used to have the function return a result which will be
        checked in the test.
        '''

        def __init__(self):
            self.rc = None
            self.out = None
            self.err = None
            self.failed = False

        def exit_json(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err

        def fail_json(self, rc, out, err):
            self.exit_json(rc, out, err)