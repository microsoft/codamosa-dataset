

# Generated at 2022-06-20 15:54:35.720811
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-20 15:54:46.650604
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import os
    import sys

    # Save current LC_ALL so we can return to it
    original_lc_all = os.environ['LC_ALL']

    # Create a fake module to test with
    class FakeModule(object):
        def __init__(self):
            self.run_command_called = 0
            self.fail_json_called = 0

        def run_command(self, cmd):
            self.run_command_called += 1
            return [0, os.linesep.join(['C', 'en_US.utf8', 'en_US.utf8', 'POSIX', 'C', 'C']), '']

        def get_bin_path(self, cmd, required=False):
            if cmd == 'locale':
                return '/usr/bin/locale'
            return None


# Generated at 2022-06-20 15:54:56.681510
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Available locales should contain, at the very least C
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert 'C' == get_best_parsable_locale(module)

    # We should be able to get a specific prefered locale
    module = AnsibleModule(argument_spec={})
    assert 'C' == get_best_parsable_locale(module, preferences=['en_US.utf8', 'C'])

    # If the prefered locale is not available, we should get a backup locale
    module = AnsibleModule(argument_spec={})
    assert 'C' == get_best_parsable_locale(module, preferences=['en_US.utf8'])

    # Assert the first prefered locale is returned if available


# Generated at 2022-06-20 15:55:07.748554
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    test_module = AnsibleModule({})

    # no locale
    test_module.run_command = lambda x: (1, '', 'locale not found')
    assert get_best_parsable_locale(test_module) == 'C'

    # no preferred
    test_module.run_command = lambda x: (0, '', 'locale not found')
    assert get_best_parsable_locale(test_module) == 'C'

    # exact match
    test_module.run_command = lambda x: (0, 'C.utf8\nen_US.utf8', 'locale not found')

# Generated at 2022-06-20 15:55:19.052207
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    # help test coverage by forcing the exception path
    def run_command(self, cmd, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False, path_prefix=None, cwd=None, use_unsafe_shell=False, prompt_regex=None, environ_update=None, umask=None, encoding=None, errors='surrogate_then_replace', expand_user_and_vars=False):
        return (1, '', 'error')
    def get_bin_path(self, arg):
        return None

    my_mod = AnsibleModule({})
    my_mod.run_command = run_command
    my_mod.get_bin_path = get_bin_path

    #

# Generated at 2022-06-20 15:55:31.190980
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.pycompat24 import get_exception

    am = AnsibleModule(argument_spec=dict())

    preferences = ['C.utf8', 'en_US.utf8', 'POSIX']
    locale = None
    try:
        locale = get_best_parsable_locale(am, preferences=preferences, raise_on_locale=True)
    except Exception:
        pass

    # Check if we get 'C'
    assert locale == 'C'

    preferences = ['C', 'C.utf8', 'en_US.utf8', 'POSIX']
    locale = None

# Generated at 2022-06-20 15:55:42.872384
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils import basic
    import sys

    module = basic._AnsiballZModule()

    assert get_best_parsable_locale(module) == 'C'

    # Manipulate the module-util to have the locale command available
    module.get_bin_path = lambda x: '/bin/' + x
    module.run_command = lambda x: (0, 'C\nPOSIX\nen_US.utf8\ntruc', '')

    assert get_best_parsable_locale(module) == 'POSIX'
    assert get_best_parsable_locale(module, preferences=['C.utf8']) == 'C.utf8'

# Generated at 2022-06-20 15:55:45.518952
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    def run_command(modul):
        return (0, "", "")

    module = AnsibleModule(run_command=run_command)

    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-20 15:55:55.475440
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Test the get_best_parsable_locale function
    '''

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import get_exception

    class TestModule(AnsibleModule):
        '''
        Test class for AnsibleModule
        '''
        def get_bin_path(self, name):
            return name

    module = TestModule()


# Generated at 2022-06-20 15:55:55.924993
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    pass

# Generated at 2022-06-20 15:56:11.070669
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    import tempfile

    if sys.version_info[0] == 2:
        from StringIO import StringIO
    else:
        from io import StringIO

    from ansible.module_utils.basic import AnsibleModule

    # Simulate an AnsibleModule

    # stdout/stderr capture for the `locale` command
    stdout = StringIO()
    stderr = StringIO()

    # simulate module.run_command()
    class RunCommand():
        def __init__(self):
            self.stdout = stdout
            self.stderr = stderr

        def run_command(self, cmd, check_rc=False):
            return 0, stdout, stderr

    # simulate module.get_bin_path()

# Generated at 2022-06-20 15:56:21.465592
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})

    assert get_best_parsable_locale(module) == 'C'

    module = AnsibleModule(argument_spec={})
    module.run_command = lambda x: (0, 'C\nen_US.utf8\nPOSIX', '')
    assert get_best_parsable_locale(module) == 'C'

    module = AnsibleModule(argument_spec={})
    module.run_command = lambda x: (0, 'C\nen_US.utf8\nPOSIX', '')
    assert get_best_parsable_locale(module, preferences=['C.UTF-8', 'POSIX']) == 'POSIX'


# Generated at 2022-06-20 15:56:31.848903
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils

    # Construct get_bin_path stub
    def get_bin_path(self, executable):
        if executable == 'locale':
            return executable

    original_get_bin_path = ansible.module_utils.basic.AnsibleModule.get_bin_path
    ansible.module_utils.basic.AnsibleModule.get_bin_path = get_bin_path

    # Construct run_command stub

# Generated at 2022-06-20 15:56:43.071279
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    test_module = AnsibleModule(argument_spec={'lang': dict(default='en_US')})
    test_locale = test_module.get_best_parsable_locale()
    assert test_locale == 'C' or test_locale == 'POSIX'
    test_module = AnsibleModule(argument_spec={'lang': dict(default='fr')})
    test_locale = test_module.get_best_parsable_locale()
    assert test_locale == 'C'
    test_module = AnsibleModule(argument_spec={'lang': dict(default='en_US')},
                                required_bin_env=['locale'])

# Generated at 2022-06-20 15:56:54.089526
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None, preferences=['C.utf8']) == 'C.utf8'
    assert get_best_parsable_locale(None, preferences=['en_US.utf8']) == 'en_US.utf8'
    assert get_best_parsable_locale(None, preferences=['C']) == 'C'
    assert get_best_parsable_locale(None, preferences=['POSIX']) == 'C'
    assert get_best_parsable_locale(None, preferences=['C.utf8', 'POSIX']) == 'C.utf8'
    assert get_best_parsable_locale(None, preferences=['POSIX', 'C.utf8']) == 'C.utf8'
    assert get_best_

# Generated at 2022-06-20 15:56:55.760878
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None) == 'C'

# Generated at 2022-06-20 15:57:06.518139
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils import six

    module = AnsibleModule(
        argument_spec={}
    )

    def run_command(args, check_rc=False, close_fds=True, executable=None, data=None, binary_data=False):
        return (0, 'C\nen_US.UTF-8\nfr_FR.UTF-8\nde_DE.utf8\nC.UTF-8', '')

    module.run_command = run_command

    if six.PY2:
        assert(get_best_parsable_locale(module) == 'C')

# Generated at 2022-06-20 15:57:17.510639
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Unit test to cover both scenarios -
        1. when locale is present, using default preferences
        2. when locale is not present, using default preferences
        3. when locale is present, using custom preferences
        4. when locale is not present, using custom preferences
    '''
    from ansible.module_utils.basic import AnsibleModule
    import os
    import sys

    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    custom_preferences = ['C.utf8', 'en_US.utf8', 'C']

    if sys.version_info[0] == 2:
        from ansible_collections.ansible.community.tests.unit.compat import mock

# Generated at 2022-06-20 15:57:25.368971
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    This tests the get_best_parsable_locale function
    '''

    import sys
    import unittest
    import tempfile

    class fake_module:
        """This class is a fake module class.
        """

        def __init__(self, tmp_dir):
            self.tmp_dir = tmp_dir

        def run_command(self, cmd):
            """This function fakes the run_command function for get_best_parsable_locale.
            """

            return 0, "C\nen_US.utf8", ""

        def get_bin_path(self, name):
            """This function fakes the get_bin_path function for get_best_parsable_locale.
            """


# Generated at 2022-06-20 15:57:28.427033
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    # Run get_best_parsable_locale without any params
    result = get_best_parsable_locale(AnsibleModule(argument_spec={}))
    if not result == 'C':
        raise AssertionError("get_best_parsable_locale() returned '%s'. Expected 'C'" % result)
    return True

# Generated at 2022-06-20 15:57:44.125993
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule({}, {}, {})
    assert get_best_parsable_locale(module, ['POSIX', 'C']) == 'C'
    assert get_best_parsable_locale(module, ['POSIX', 'C', 'C.utf8']) == 'C.utf8'
    assert get_best_parsable_locale(module, ['POSIX', 'en_US.utf8']) == 'en_US.utf8'
    assert get_best_parsable_locale(module, ['POSIX', 'en_US.utf8', 'C.utf8']) == 'en_US.utf8'

# Generated at 2022-06-20 15:57:51.214709
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None, ['C', 'POSIX']) == 'C'
    assert get_best_parsable_locale(None, ['POSIX', 'C']) == 'C'
    assert get_best_parsable_locale(None, ['C']) == 'C'
    assert get_best_parsable_locale(None, ['C.utf8']) == 'C'

# Generated at 2022-06-20 15:58:00.645538
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''Test get_best_parsable_locale, return 'C' if locale not found'''
    import os
    import tempfile
    from ansible.module_utils.common.process import get_bin_path

    locale_path = get_bin_path('locale')
    if locale_path:
        # delete locale from path
        os.environ['PATH'] = os.environ['PATH'].replace(locale_path, '')
    if 'LANG' in os.environ:
        del os.environ['LANG']
    if 'LANGUAGE' in os.environ:
        del os.environ['LANGUAGE']
    if 'LC_ALL' in os.environ:
        del os.environ['LC_ALL']

# Generated at 2022-06-20 15:58:10.949684
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    This function tests function get_best_parsable_locale()
    It should return the first preference that is in the list of available locales
    If the preferences are not in the list, it should return 'C'
    '''
    from mock import Mock
    import locale

    # Create a fake module object
    test_module = Mock()
    test_module.run_command.return_value = (0, locale.getlocale()[0], '')
    locale.setlocale(locale.LC_ALL, 'en_US.utf8')
    assert (get_best_parsable_locale(test_module) == 'en_US.utf8')

    locale.setlocale(locale.LC_ALL, 'C')

# Generated at 2022-06-20 15:58:23.241910
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Mock AnsibleModule
    class MockAnsibleModule:
        def __init__(self, params):
            self.params = params

        def get_bin_path(self, name):
            return self.params['locale_bin']

        def run_command(self, cmd):
            if self.params['rc'] == 0:
                return (self.params['rc'], self.params['locale_out'], None)
            else:
                return (self.params['rc'], None, "RC ERROR")

    # test 1
    params = {
        'locale_bin': 'locale',
        'locale_out': 'en_US.utf8\nC\nPOSIX\n',
        'rc': 0,
    }
    mam = MockAnsibleModule(params)

# Generated at 2022-06-20 15:58:29.248271
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Using the modules defaults, make sure the function meets expectations.
    '''

    # import the module to test
    from ansible.module_utils.basic import AnsibleModule

    am = AnsibleModule()

    assert get_best_parsable_locale(am) == 'C'

    am = AnsibleModule()

    assert get_best_parsable_locale(am, preferences=['test']) == 'C'

    am = AnsibleModule()

    assert get_best_parsable_locale(am, preferences=['test', 'C.utf8']) == 'C'

# Generated at 2022-06-20 15:58:33.798064
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Run a simple test of the function
    '''
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    locale_tested = get_best_parsable_locale(module)

    assert type(locale_tested) == str

# Generated at 2022-06-20 15:58:39.022231
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict()
    )

    # If the locale tool is not installed then we'll get a RuntimeWarning
    # and the default of 'C' will be returned
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-20 15:58:44.391026
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import binary_type

    assert get_best_parsable_locale(None) == 'C'

    module = AnsibleModule(argument_spec=dict(locale=dict(type='str')))
    module.run_command = lambda cmd: (0, 'C', '')
    assert get_best_parsable_locale(module) == 'C'

    module.run_command = lambda cmd: (0, 'C\nen_US\n', '')
    pref = ['C', 'en_US']
    assert get_best_parsable_locale(module, pref) == 'C'

    module.run_command = lambda cmd: (0, 'C\nen_US\n', '')
    pref

# Generated at 2022-06-20 15:58:54.291672
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Fake module
    class FakeModule(object):
        def get_bin_path(self, _):
            return 'locale'

        def run_command(self, cmd):
            if cmd == ['locale', '-a']:
                return (0, "C\nPOSIX\nen_US.utf8\nC.utf8\nPOSIX.utf8", None)
            else:
                raise AssertionError("Invalid command %s" % cmd)

    # Test with default preferences
    fm = FakeModule()
    assert get_best_parsable_locale(fm) == 'C.utf8'

    # Test with specified preferences
    fm = FakeModule()

# Generated at 2022-06-20 15:59:17.284492
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class MockAnsibleModule:
        def __init__(self, command, out, rc, err):
            self.command = command
            self.out = out
            self.rc = rc
            self.err = err

        def run_command(self, command):
            assert command == self.command
            return self.rc, self.out, self.err

        def get_bin_path(self, cmd, required=True):
            if cmd == "locale":
                if self.command[0] == "locale":
                    return "/usr/bin/locale"
            return None

    # get_bin_path

# Generated at 2022-06-20 15:59:24.385004
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    import sys
    import os
    import unittest
    import ansible.module_utils
    from ansible.module_utils.basic import AnsibleModule

    class TestModule(object):
        def __init__(self, run_command_args, run_command_rc, run_command_stdout, fail_json_msg):
            self.run_command_args = run_command_args
            self.run_command_rc = run_command_rc
            self.run_command_stdout = run_command_stdout
            self.fail_json_msg = fail_json_msg

        def get_bin_path(self, tool, required=None, opt_dirs=None):
            return sys.executable


# Generated at 2022-06-20 15:59:32.394279
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.common.process import get_bin_path

    assert get_bin_path('locale') is not None

    locale_bin = get_bin_path('locale')
    assert locale_bin

    rc, out, err = module.run_command([locale_bin, '-a'])

    assert rc == 0
    assert out
    available_locales = out.strip().splitlines()
    assert len(available_locales) > 0

    # test that we return the first specified preference
    assert get_best_parsable_locale(module, available_locales) == available_locales[0]

# Generated at 2022-06-20 15:59:40.470047
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.facts import Facts

    test_module = AnsibleModule(
        argument_spec=dict(
            preferences=dict(default=[], type='list')
        )
    )

    # Default case
    test_module.exit_json(changed=False, ansible_facts=dict(ansible_system_locale=get_best_parsable_locale(test_module)))

    # Preferences given
    test_module = AnsibleModule(
        argument_spec=dict(
            preferences=dict(default=['C.utf8', 'en_US.utf8', 'C', 'POSIX'], type='list')
        )
    )

# Generated at 2022-06-20 15:59:46.459030
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    best_locale_found = get_best_parsable_locale(preferences=['fr_FR.utf8', 'C.utf8', 'en_US.utf8', 'POSIX'])
    assert 'C.utf8' == best_locale_found

# Generated at 2022-06-20 15:59:54.710779
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Available locale is an empty list
    module = Mock()
    module.run_command = Mock(return_value=(0, '', ''))
    module.get_bin_path = Mock(return_value="")

    assert get_best_parsable_locale(module) == "C"

    # locale binary not found
    module = Mock()
    module.run_command = Mock(return_value=(0, '', ''))
    module.get_bin_path = Mock(return_value=None)

    assert get_best_parsable_locale(module) == "C"

    # No output from locale command
    module = Mock()
    module.run_command = Mock(return_value=(0, '', ''))
    module.get_bin_path = Mock(return_value=True)

    assert get_

# Generated at 2022-06-20 15:59:56.500573
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert None == get_best_parsable_locale(None, None)

# Generated at 2022-06-20 16:00:01.414938
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module, preferences=['a', 'b', 'c']) == 'C'
    assert get_best_parsable_locale(module, preferences=['C', 'POSIX'], raise_on_locale=True) in ('C', 'POSIX')

# Generated at 2022-06-20 16:00:11.301133
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    The purpose of this is to make sure we get expected locale
    '''

    import ansible.module_utils.basic
    import ansible.module_utils.six.moves.builtins
    import ansible.module_utils.pycompat24
    import sys

    class BasicModule():
        def __init__(self):
            pass

    class AnsibleModule():
        def __init__(self, basic_module):
            self.basic = basic_module

        def get_bin_path(self, command):
            '''
            Since we don't actually run this, we can just return the string
            '''
            return '/usr/bin/' + command


# Generated at 2022-06-20 16:00:21.251621
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    locale = get_best_parsable_locale(None, preferences=['no', 'such', 'locale'], raise_on_locale=False)
    assert locale == 'C'

    locale = get_best_parsable_locale(None, preferences=['C', 'POSIX'], raise_on_locale=False)
    assert locale == 'C'

    locale = get_best_parsable_locale(None, preferences=['french', 'C', 'POSIX'], raise_on_locale=False)
    assert locale == 'C'

    locale = get_best_parsable_locale(None, preferences=['french', 'C'], raise_on_locale=True)
    assert locale == 'C'
    assert True

# Generated at 2022-06-20 16:00:44.437316
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Unit test for the get_best_parsable_locale function
        this test only runs if you install the pytest tool
        or put ansible.cfg in the same dir with: [defaults] library = this/dir/and/subdirs
    '''

    import pytest
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    assert module

    import os
    import shutil

    def run(cmd, cwd=None):
        return os.system('cd %s && %s' % (cwd, cmd))

    FAILED = 1

    # build mock locale dir with contents
    test_locale_dir = "/tmp/test_get_best_parsable_locale/"

# Generated at 2022-06-20 16:00:55.478863
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3
    if PY3:
        import inspect
        import os
        import sys
        currentdir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
        parentdir = os.path.dirname(currentdir)
        # This will add the parent dir to the path to be able to load the module
        sys.path.insert(0,parentdir)

    mod = AnsibleModule(
        argument_spec=dict(
            langy=dict(type='str', default='en'),
        ),
    )

    # test output
    print('test_get_best_parsable_locale')

# Generated at 2022-06-20 16:01:07.851976
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # fake module
    class Module(object):
        @staticmethod
        def get_bin_path(name, required=True):
            if name == 'locale':
                return 'locale'
            else:
                return None

        @staticmethod
        def run_command(arguments):
            if arguments == ['locale', '-a']:
                output = 'C\nen_US.utf8\nen_US.UTF-8\nen_US.UTF8\nen_US.utf8@modifier\nC.UTF-8'
                return 0, output, ''
            else:
                return 1, '', ''

    # Test case 1: test that all the output is correctly parsed

# Generated at 2022-06-20 16:01:16.856894
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    class AnsibleModule():
        ''' Mocking class AnsibleModule '''

        def __init__(self, *args, **kwargs):
            pass

        def get_bin_path(self, cmd):
            ''' Mocking function get_bin_path '''
            return True

        def run_command(self, cmd):
            ''' Mocking function run_command '''
            return 0, 'C.utf8\nen_US.utf8\nPOSIX\n', ''

    ansible_module = AnsibleModule()
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    locale = get_best_parsable_locale(ansible_module, preferences)
    assert locale == 'C.utf8'

# Generated at 2022-06-20 16:01:23.132276
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # set up our test module instance
    module = FakeModule("get_best_parsable_locale")

    # Mocks of run_command and get_bin_path
    module.run_command = FakeRunCommand
    module.get_bin_path = FakeGetBinPath

    # Test 1: Verify function returns expected locale
    expected_locale = "C"
    assert get_best_parsable_locale(module) == expected_locale

    # Test 2: Verify function returns expected locale in list of preferences
    expected_locale = "POSIX"
    assert get_best_parsable_locale(module, ["POSIX"]) == expected_locale

    # Test 3: Verify function returns default to C for empty list of available locales
    expected_locale = "C"
    module.run_command = Fake

# Generated at 2022-06-20 16:01:33.845548
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class mock_module():
        class run_command():
            def __init__(self, what):
                if what == ['locale', '-a']:
                    self.rc = 0
                    self.out = 'C\nen_US.utf8\nC.utf8\nPOSIX'
                    self.err = ''
                else:
                    self.rc = 1
                    self.out = ''
                    self.err = 'Unable to get locale information'

        def get_bin_path(self, what):
            return 'locale'

    module = mock_module()

    test = get_best_parsable_locale(module)
    assert test == 'C.utf8'

    test = get_best_parsable_locale(module, preferences=['en_US.utf8'])

# Generated at 2022-06-20 16:01:41.018594
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    def run_module():
        module_args = dict(
            name='foo',
        )

        result = dict(
            changed=True,
            language='',
            best_parsable_locale=''
        )

        module = AnsibleModule(
            argument_spec=module_args,
            supports_check_mode=True
        )

        # Run with no locale in path
        result['language'] = module.run_command([u'bash', u'-c', u'echo $LANG'])[1].strip()
        result['best_parsable_locale'] = get_best_parsable_locale(module)
        module.exit_json(**result)

    module = run_module()

# Generated at 2022-06-20 16:01:50.709043
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class FakeAnsibleModule:
        def run_command(self, args):
            if args[0] == "locale":
                return 0, 'C.utf8\nen_US.utf8\nC\nPOSIX\n', ''
            else:
                return 0, '', ''

        def get_bin_path(self, bin_name):
            return "locale"


    assert get_best_parsable_locale(FakeAnsibleModule()) == 'C.utf8'

    class FakeAnsibleModule2:
        def run_command(self, args):
            if args[0] == "locale":
                return 0, 'C.utf8\nPOSIX\nen_US.utf8\nC\n', ''
            else:
                return 0, '', ''


# Generated at 2022-06-20 16:01:56.648721
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    test_module = MockModule()
    test_module.get_bin_path = Mock(return_value='locale')
    test_module.run_command = Mock(return_value=(0, 'C.utf8\nen_US.utf8\nC\nPOSIX\n', ''))
    found_locale = get_best_parsable_locale(test_module)
    assert found_locale == 'C.utf8'
    test_module.run_command.return_value = (0, 'C.utf8\nen_US.utf8\nPOSIX\n', '')
    found_locale = get_best_parsable_locale(test_module)
    assert found_locale == 'C.utf8'

# Generated at 2022-06-20 16:02:07.566322
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import os
    import sys

    # Need to include module_utils.basic for the AnsibleModule
    sys.path.append(os.path.join(os.path.dirname(__file__), '..'))

    from ansible.module_utils.basic import AnsibleModule

    # test preferences
    module = AnsibleModule(argument_spec={'preferences':
                                          {'type': 'list', 'required': False},
                                          'raise_on_locale':
                                          {'type': 'bool', 'required': False}},
                           supports_check_mode=False)
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']

# Generated at 2022-06-20 16:02:31.454556
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.basic import AnsibleModule

    class FakeException(Exception):
        pass

    class FakeModule(AnsibleModule):
        def __init__(self, params):
            pass

        def run_command(self, args):
            if 'locale' in args and args[1] == '-a':
                return 0, '\n'.join([
                    'C', 'POSIX', 'en_US.utf8', 'en_US.us', 'C.utf8', 'en_US.utf8'
                ]), ''
            else:
                raise FakeException("run_command was called with unexpected arguments")


# Generated at 2022-06-20 16:02:35.748424
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    assert get_best_parsable_locale(None, preferences=preferences) == 'C'

# Generated at 2022-06-20 16:02:39.742950
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    expected = 'C'
    actual = get_best_parsable_locale(None, preferences)
    assert expected == actual

# Generated at 2022-06-20 16:02:43.364602
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    from ansible.module_utils.connection import Connection
    connection = Connection(ansible.module_utils.basic.AnsibleModule)
    module = connection.run_command
    locale = get_best_parsable_locale(module)
    assert locale == 'C'

# Generated at 2022-06-20 16:02:48.825523
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    module.run_command = lambda x: (0, 'C\nC.utf8\nen_us.utf8\nen_US.utf8', None)

    assert get_best_parsable_locale(module) == 'en_US.utf8'

# Generated at 2022-06-20 16:02:56.493597
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # stubs
    import json

    class AnsibleModule(object):
        def __init__(self, argument_spec, bypass_checks=False, no_log=False,
                     check_invalid_arguments=True, mutually_exclusive=None, required_together=None,
                     required_one_of=None, add_file_common_args=False, supports_check_mode=False,
                     required_if=None):
            self.params = {'null': None}

        def fail_json(self, *args, **kwargs):
            pass

        def exit_json(self, *args, **kwargs):
            pass

        def get_bin_path(self, *args, **kwargs):
            return True

        def run_command(self, *args, **kwargs):
            return 0, json.dumps

# Generated at 2022-06-20 16:03:04.619098
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())

    found = get_best_parsable_locale(module, preferences=['C', 'en_US.UTF-8'])
    assert found == 'C'

    found = get_best_parsable_locale(module, preferences=['en_US.UTF-8', 'C'])
    assert found == 'en_US.UTF-8'

# Generated at 2022-06-20 16:03:10.600816
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    assert get_best_parsable_locale(AnsibleModule())
    assert get_best_parsable_locale(AnsibleModule(), preferences=['C', 'POSIX'])
    assert get_best_parsable_locale(AnsibleModule(), preferences=['C.utf8', 'POSIX'])
    assert get_best_parsable_locale(AnsibleModule(), preferences=['C.', 'POSIX', 'C'])
    assert get_best_parsable_locale(AnsibleModule(), preferences=['C0', 'POSIX', 'C'])

# Generated at 2022-06-20 16:03:20.244336
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils
    from ansible.module_utils.common.process import get_bin_path

    class Module(object):

        def __init__(self, **kwargs):
            self.params = kwargs
            self.params['_ansible_verbosity'] = 0
            self.params['_ansible_no_log'] = False
            self.check_mode = False
            self.exit_json = self.fail_json = lambda **kwargs: None

        def get_bin_path(self, arg, required=False):
            return get_bin_path(arg, required=required)

        def run_command(self, args):
            return ansible.module_utils.common.run_command(args, check_rc=True)
    # pylint: disable=attribute-defined-outside-init

# Generated at 2022-06-20 16:03:29.925999
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.basic import AnsibleModule

    # Mock an ansible module instance
    module = AnsibleModule(argument_spec=dict())
    # Mock get_bin_path
    module.get_bin_path = get_bin_path

    # Mock run_command
    # We don't mock run_command completely, because we only want to return a
    # predefined output when locale is called.
    real_run_command = module.run_command


# Generated at 2022-06-20 16:03:53.417777
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.six.moves import cStringIO

    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.basic import AnsibleModule

    globals = dict(
        get_bin_path=get_bin_path,
    )

    # python 2.6
    if not hasattr(cStringIO, 'getvalue'):
        cStringIO.getvalue = lambda x: x.getvalue()

    def noop_run_command(*args, **kwargs):
        return 0, 'a b c d e f g j i 1 2 3 4 5 6 7 8 9 0'.strip().split(' '), ''

    def run_command_error(*args, **kwargs):
        return 1, '', ''


# Generated at 2022-06-20 16:04:02.024424
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Test empty available locales
    assert 'C' == get_best_parsable_locale(locales_available=[], raise_on_locale=False)

    # Test C.utf8 is first available
    assert 'C.utf8' == get_best_parsable_locale(locales_available=['C.utf8', 'pl_PL'], raise_on_locale=False)

    # Test en_US.utf8 is second available
    assert 'en_US.utf8' == get_best_parsable_locale(locales_available=['C', 'en_US.utf8', 'pl_PL'], raise_on_locale=False)

    # Test POSIX is last available

# Generated at 2022-06-20 16:04:08.287551
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.basic import AnsibleModule

    # Inputs
    locale_list_out = 'C\nC.utf8\nen_US.utf8\nposix\n'
    preferences = ['en_US.utf8', 'C.utf8', 'POSIX']

    # Init module
    module = AnsibleModule(argument_spec=dict(
        preferences=dict(type='list', default=None),
        raise_on_locale=dict(type='bool')
    ))

    # Mock up AnsibleModule().run_command()
    def mock_run_command(command, *args, **kwargs):
        return 0, locale_list_out, ''

    module.run_command = mock_run_command

   

# Generated at 2022-06-20 16:04:20.847732
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    # These are the only things we can safely assume are available on all platforms
    assert get_best_parsable_locale(AnsibleModule) == 'C'
    assert get_best_parsable_locale(AnsibleModule, preferences=['POSIX']) == 'C'

    # C.UTF-8 is also an always-available locale
    assert get_best_parsable_locale(AnsibleModule, preferences=['C.UTF-8']) == 'C.utf8'
    assert get_best_parsable_locale(AnsibleModule, preferences=['POSIX', 'C.UTF-8']) == 'C.utf8'

    # ...but not POSIX.UTF-8
    assert get_best_parsable_loc